

# Generated at 2022-06-21 01:14:12.311994
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    loader = None
    variable_manager = None

    class TestRole(RoleMetadata):
        def __init__(self, variable_manager, loader):
            self.variable_manager = variable_manager
            self.loader = loader
            self.name = 'test-role'
            self.collections = ['ansible.collections.test']
            self._owner = self

    role = TestRole(variable_manager, loader)
    data = {"allow_duplicates":True, "dependencies": [{'src': 'my.role', 'other_vars': 'here'}]}

    role.deserialize(data)
    assert role.allow_duplicates == True
    assert role.dependencies[0].src == 'my.role'
    assert role.dependencies[0].other_vars == 'here'

# Generated at 2022-06-21 01:14:19.063718
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = []
    role_metadata._argument_specs = {}
    role_metadata._galaxy_info = {}
    result = role_metadata.serialize()
    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []


# Generated at 2022-06-21 01:14:28.713757
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Unit test for method load of class RoleMetadata.

    Note: This method has been marked as deprecated in Ansible v2.10
    TODO: Remove this once Ansible v2.10 is released.
    """
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import collection_loader

    # Testing for a role without a collections path
    gal1 = 'galaxy1'
    col1 = 'collection1'

    path1 = os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/roles/' + col1, gal1)
    path2 = os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/collections/foo/bar/' + col1, gal1)

# Generated at 2022-06-21 01:14:32.682979
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role = RoleMetadata.load(
        {
            'allow_duplicates': True,
            'dependencies': [
                {
                    'role': 'test',
                },
            ]
        },
        "test"
    )

    assert role.allow_duplicates
    assert role.dependencies

    # TODO: test with a RoleIncludedObject
    # TODO: test with the other attrs

# Generated at 2022-06-21 01:14:36.219790
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = ['test_role']
    expect = {
        'allow_duplicates': True,
        'dependencies': ['test_role']
    }
    assert meta.serialize() == expect

# Generated at 2022-06-21 01:14:47.494322
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    def mock_owner(name):
        return _MockOwner(name)

    def mock_dependency(name):
        return _MockRoleRequirement(name)

    # Test case 1
    # Deserialize metadata object with allow_duplicates as true
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_meta.allow_duplicates is True
    assert not role_meta.dependencies

    # Test case 2
    # Deserialize metadata object with dependencies
    # Need to load the dependencies to make sure the dependencies is
    # deserialized correctly
    role_meta = RoleMetadata()

# Generated at 2022-06-21 01:14:53.278479
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[1,2,3]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-21 01:15:04.898104
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = FakeRole()
    data = dict()
    data['dependencies'] = [{'role': 'common'},
                            {'role': 'webservers', 'some_parameter': 42}]
    galaxy_info = {'author': 'Ansible', 'description': 'Common role',
                   'company': 'Ansible', 'license': 'GPL', 'min_ansible_version': '2.9',
                   'platforms': [{'name': 'Ubuntu', 'versions': ['all']}],
                   'issue_tracker_url': 'https://github.com/ansible-collections/community.general/issues',
                   'collection_name': 'community.general'}
    data['galaxy_info'] = galaxy_info
    result = RoleMetadata.load(data, owner)
    assert result

# Generated at 2022-06-21 01:15:14.932064
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

    data = dict(
        allow_duplicates=True,
        dependencies=[RoleRequirement()],
        galaxy_info=dict(author=dict(name='bobo'),
                          description='random description'))
    loader = None
    variable_manager = None
    play = 'test'
    play_path = '/path/to/play'
    role = RoleDefinition(play=play, play_path=play_path, name='test_role')
    rm = RoleMetadata.load(data, role, variable_manager=variable_manager, loader=loader)
    assert rm._allow_duplicates == True
    assert rm._dependencies

# Generated at 2022-06-21 01:15:25.352029
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class GalaxyInfo:
        def __init__(self, name, description):
            self.platforms = []

    class Role:
        def __init__(self, name):
            self.name = name

    test_metadata = RoleMetadata(owner=Role('test_role'))

    test_metadata._galaxy_info = GalaxyInfo('test', 'test')
    test_metadata._argument_specs = {}

    test_metadata._dependencies = ['test_dep']
    test_metadata._allow_duplicates = True

    assert test_metadata.serialize() == {'dependencies': ['test_dep'], 'allow_duplicates': True}

# Generated at 2022-06-21 01:15:46.528088
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_main_yml = 'meta/main.yml'
    role_path = '/path/to/roles/test_role'

    variable_manager = 'variable_manager'
    loader = 'loader'

    from ansible.playbook.role.definition import RoleDefinition

    role_def = RoleDefinition(meta_main_yml, role_path, variable_manager, loader)
    m = RoleMetadata.load(dict(), owner=role_def, variable_manager=variable_manager, loader=loader)

    assert isinstance(m, RoleMetadata)
    assert m._allow_duplicates == False
    assert m._dependencies == []

    dependencies_list = ['role1', 'role2']

# Generated at 2022-06-21 01:15:47.842674
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-21 01:15:57.827183
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test
    '''

# Generated at 2022-06-21 01:16:05.174269
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    allowed_duplicates=True
    dependencies_expected=['role1', 'role2', 'role3']
    dependencies_provided=['role2', 'role3']
    deps=RoleMetadata()
    deps.deserialize({'dependencies':dependencies_provided, 'allow_duplicates':allowed_duplicates})
    assert deps.dependencies == dependencies_expected
    assert deps.allow_duplicates == allowed_duplicates

# Generated at 2022-06-21 01:16:10.622201
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    myRole = RoleMetadata()
    test_input = { 'allow_duplicates': True, 'dependencies': ['test'] }
    myRole.deserialize(test_input)
    assert myRole._allow_duplicates == True
    assert myRole._dependencies[0] == 'test'
    assert myRole._galaxy_info == {}
    assert myRole._argument_specs == {}


# Generated at 2022-06-21 01:16:21.246899
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Owner:
        _role_path = 'path'
        name = 'k8s'
        def __init__(self):
            self._play = Play()
    class Play:
        name = 'test'
    class GalaxyInfo:
        def __init__(self):
            self.platforms = 'centos'
            self.namespace = 'geerlingguy'
            self.issue_tracker_url = 'https://github.com/geerlingguy/ansible-role-k8s/issues'
            self.repository_url = 'https://github.com/geerlingguy/ansible-role-k8s'
    class Role:
        def __init__(self):
            self.name = 'test'
            self.path = 'path'

    owner = Owner()
    galaxy_info

# Generated at 2022-06-21 01:16:25.356432
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_role_dependencies = [{'role': 'file-test-1'}, {'role': 'file-test-2'}]
    test_role_meta = RoleMetadata()
    test_role_meta.dependencies = test_role_dependencies
    assert test_role_meta.dependencies == test_role_dependencies

# Generated at 2022-06-21 01:16:32.187239
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    # print(type(role_metadata))
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = list(range(10))

    d = role_metadata.serialize()
    assert d['allow_duplicates'] == True
    assert d['dependencies'] == list(range(10))


# Generated at 2022-06-21 01:16:35.668085
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True
    )
    obj = RoleMetadata()
    obj.deserialize(data)
    assert obj.allow_duplicates == data['allow_duplicates']

# Generated at 2022-06-21 01:16:39.425635
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class TestRole:
        def __init__(self):
            self._role_name = "test_name"
            self._role_path = "test_path"
    test_role = TestRole()
    test_role_metadata = RoleMetadata(owner=test_role)
    assert test_role_metadata is not None

# Generated at 2022-06-21 01:16:54.576253
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata(owner=None)
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role.deserialize(data)
    assert role._allow_duplicates == False
    assert role._dependencies == []


# Generated at 2022-06-21 01:16:59.984827
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'dependencies': ['role1', 'role2', 'role3'],
        'allow_duplicates': True,
        'collections': ['col1']
    }
    r_metadata = RoleMetadata.load(data, owner=None)
    assert(r_metadata._allow_duplicates == True)
    assert(r_metadata._dependencies == ['role1', 'role2', 'role3'])
    assert(r_metadata._galaxy_info is None)
    assert(r_metadata._argument_specs == {})


# Generated at 2022-06-21 01:17:01.355937
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r is not None


# Generated at 2022-06-21 01:17:08.020225
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    aRoleMetadata = RoleMetadata()
    aRoleMetadata.load('any_data', 'owner')
    print(aRoleMetadata)
    aRoleMetadata.deserialize('data')
    print(aRoleMetadata)
    assert aRoleMetadata.serialize() is not None

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-21 01:17:09.781495
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_RoleMetadata = RoleMetadata()
    print(test_RoleMetadata)

# Generated at 2022-06-21 01:17:16.464197
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ''' Unit test for deserialize of class RoleMetadata '''
    role_metadata_object = RoleMetadata('owner')
    role_metadata_object._allow_duplicates = True
    role_metadata_object._dependencies = [{'role': 'role1'}, 'role2', 'role3']
    serialize_result = {'allow_duplicates': True, 'dependencies': [{'role': 'role1'}, 'role2', 'role3']}
    assert role_metadata_object.serialize() == serialize_result


# Generated at 2022-06-21 01:17:18.200171
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rolm = RoleMetadata()
    assert rolm.allow_duplicates is False
    assert rolm.dependencies == []

# Generated at 2022-06-21 01:17:25.064194
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    setattr(m, 'allow_duplicates', True)
    setattr(m, 'dependencies', ['galaxy.role1', 'galaxy.role2', 'galaxy.role3'])
    assert m.serialize() ==  {'allow_duplicates': True, 'dependencies': ['galaxy.role1', 'galaxy.role2', 'galaxy.role3']}

# Generated at 2022-06-21 01:17:32.206112
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = 'Cisco'
    data = dict(
            allow_duplicates=True,
            dependencies=['Cisco.IOX', 'Cisco.NSO']
            )
    m = RoleMetadata.load(data, owner)
    result = m.serialize()
    assert result.get('allow_duplicates', False) == True
    assert result.get('dependencies', []) == ['Cisco.IOX', 'Cisco.NSO']


# Generated at 2022-06-21 01:17:41.517905
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import collections
    import datetime
    import dateutil.tz
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import CollectionFinder

    if PY3:
        unicode = str

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    fixture_loader = AnsibleCollectionLoader()
    fixture_finder = Collection

# Generated at 2022-06-21 01:18:11.663159
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = []

    # serialize
    serialize = role_metadata.serialize()
    assert serialize == dict(
        allow_duplicates=True,
        dependencies=[]
    ), "RoleMetadata.serialize() is error"

# Generated at 2022-06-21 01:18:21.079700
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.include import RoleInclude
    collection_search_list = ['ansible.legacy']
    metadata = RoleMetadata(owner={'_role_path': 'test/test.yml', 'collections': collection_search_list, '_play':{}, '_role_name':"test"}).load_data({'dependencies': [{'role':'test2'}]}, variable_manager=None, loader=None)
    assert isinstance(metadata.dependencies[0], RoleInclude), 'RoleMetadata constructor fails to convert dependency to RoleInclude object'

# Generated at 2022-06-21 01:18:24.421554
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    assert role.serialize() == {'allow_duplicates': True, 'dependencies': []}


# Generated at 2022-06-21 01:18:34.043722
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.host import Host

    class MockRole(Role):
        def __init__(self, name, path):
            self._role_name = name
            self._role_path = path

        def get_name(self):
            self._role_name

        def get_collections(self):
            return None

        def get_variable_manager(self):
            return None

    class MockPlaybook(object):
        def __init__(self):
            self.basedir = '/home'

        def get_variable_manager(self):
            return None

    class MockInventory(object):
        def __init__(self):
            self.hosts = {}


# Generated at 2022-06-21 01:18:38.519961
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    p = Play()
    p._variable_manager = None
    p._loader = None
    result = RoleMetadata.load(data={'dependencies': []}, owner=p)
    assert isinstance(result, RoleMetadata)

# Generated at 2022-06-21 01:18:42.474067
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.__dict__ == {'_allow_duplicates': False, '_dependencies': [], '_galaxy_info': None, '_argument_specs': {}, '_owner': None}

# Generated at 2022-06-21 01:18:48.626058
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create an instance of a RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data=dict(
        allow_duplicates=True,
        dependencies=[
            {'src': 'an_author.a_role_name'},
        ]
    ))
    assert isinstance(role_metadata.allow_duplicates, bool)
    assert isinstance(role_metadata.dependencies, list)

# Generated at 2022-06-21 01:18:53.290911
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'dependencies': [{'role': 'test.role'}]}
    m.deserialize(data)
    assert type(m.dependencies) is list
    assert len(m.dependencies) == 1

# Generated at 2022-06-21 01:18:55.726681
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    x = RoleMetadata()
    x.deserialize({'allow_duplicates':False, 'dependencies':[]})
    assert x._allow_duplicates == False
    assert x._dependencies == []



# Generated at 2022-06-21 01:19:02.256060
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_data = {
        'allow_duplicates': False,
        'dependencies': [{'role': 'test_role', 'version': 'test_version'}]
    }
    role_metadata = RoleMetadata().load(role_metadata_data, owner=None)
    serialized_role_metadata_data = role_metadata.serialize()
    assert 'dependencies' in serialized_role_metadata_data
    assert 'allow_duplicates' in serialized_role_metadata_data
    assert serialized_role_metadata_data['dependencies'][0] is not None

# Generated at 2022-06-21 01:19:19.782458
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {  'allow_duplicates' : True,
              'dependencies' : [ { 'role' : 'MyRole', 'other_vars' : 'go here'}]
            }
    role_metadata = RoleMetadata().load_data(data)
    result = role_metadata.serialize()
    assert result == data

# Generated at 2022-06-21 01:19:22.970785
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m._allow_duplicates = True
    m._dependencies = ["foo", "bar"]
    m._argument_specs = {"foo": "bar"}
    assert m.serialize() == {
        'allow_duplicates': True,
        'dependencies': ["foo", "bar"]
    }
    assert m._argument_specs == {"foo": "bar"}

# Generated at 2022-06-21 01:19:24.212326
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    result = RoleMetadata()
    assert result is not None

# Generated at 2022-06-21 01:19:32.797919
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    #RoleMetadata._serialized_attrs = ['allow_duplicates', 'dependencies']
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['ansible-role-A', 'ansible-role-B']}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies is not None
    assert role_metadata.dependencies == ['ansible-role-A', 'ansible-role-B']

# Generated at 2022-06-21 01:19:35.518636
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    file_name = "test_RoleMetadata.yml"

    role_metadata = RoleMetadata()
    role_metadata.load_from_file(file_name)

# Generated at 2022-06-21 01:19:44.687035
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import collections
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.become import Become
    from ansible.playbook.play_context import PlayContext

    ####################################################################################


# Generated at 2022-06-21 01:19:53.453674
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata._allow_duplicates = True
    roleMetadata._dependencies = {}

    assert roleMetadata.serialize() == dict(
        allow_duplicates=True,
        dependencies={}
    )

    roleMetadata._allow_duplicates = False
    roleMetadata._dependencies = [1, 2, 3]

    assert roleMetadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[1, 2, 3]
    )


# Generated at 2022-06-21 01:19:54.366161
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role = RoleMetadata()
    assert role.load("", "", "", "") == None

# Generated at 2022-06-21 01:20:04.787662
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook import Play, Playbook
    from ansible.module_utils.six import BytesIO

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='galaxy.role1,1.0.0,name1',
                src='galaxy.role1,1.0.0,name1',
                path='files'
            ),
            dict(
                name='galaxy.role2,1.0.0,name2',
                src='galaxy.role2,1.0.0,name2',
                path='files'
            )
        ]
    )

    pb = Playbook.load(BytesIO(b"[{}, {}, {}]"), variable_manager=None, loader=None)

# Generated at 2022-06-21 01:20:10.737612
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    loader = None
    variable_manager = None
    play = Play()
    role = Role()

    # Load data
    data = dict()
    metadata = RoleMetadata.load(data=data, owner=role)

    # Get dependencies
    dependencies = metadata.dependencies
    assert dependencies == []

    # Load dependencies
    import os
    data = dict(dependencies=os.path.join('..', 'other_role'))
    metadata = RoleMetadata.load(data=data, owner=role)

    # Get dependencies
    dependencies = metadata.dependencies
    assert dependencies == [IncludeRole(name=['../other_role'])]

# Generated at 2022-06-21 01:20:39.771895
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    role_definition = RoleDefinition('../test/lib/ansible/roles/test_role')

    role_metadata = RoleMetadata(owner=role_definition)
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['../test/lib/ansible/roles/test_role_dep']

    expected_result = {
        'allow_duplicates': True,
        'dependencies': ['../test/lib/ansible/roles/test_role_dep']
    }

    assert role_metadata.serialize() == expected_result


# Generated at 2022-06-21 01:20:44.515824
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata(owner=None)
    role.allow_duplicates = True
    role.dependencies = [ 'role1', 'role2' ]
    assert role.serialize() == {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }

# Generated at 2022-06-21 01:20:50.314674
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Description:
    Test if the serialization of the RoleMetadata object is as excepted
    '''

    m = RoleMetadata()
    m._allow_duplicates = True
    m._dependencies = ['b', 'c']
    assert m.serialize() == dict(allow_duplicates=True, dependencies=['b', 'c'])




# Generated at 2022-06-21 01:20:56.287523
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates = False,
        dependencies = ['role1', 'role2']
    )
    m = RoleMetadata().load(data)
    assert m.allow_duplicates == False
    assert len(m.dependencies) == 2
    assert m.dependencies == ['role1', 'role2']
    assert m.serialize() == data



# Generated at 2022-06-21 01:21:06.029378
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import sys
    import tempfile
    import yaml
    import shutil
    import os

    # Create temp directory and role directory
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'meta'))

    # create meta/main.yml
    with open(os.path.join(tmpdir, 'meta', 'main.yml'), 'wb') as f:
        f.write(yaml.dump({'galaxy_info': {'namespace': 'test', 'author': 'test', 'name': 'test', 'description': 'test'},
                           'dependencies': []}))
    # create Role
    class Role:
        def __init__(self):
            self._role_path = tmpdir

    role = Role()
    # load() returns a new

# Generated at 2022-06-21 01:21:17.223329
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import os, sys
    import yaml
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    import lib.galaxy as galaxy
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Normal deserialize scenario
    fakeRoleMetadata = RoleMetadata()
    dependencie1 = RoleRequirement(role_name='dependency1')
    dependencie2 = RoleRequirement(role_name='dependency2')
    data = {'allow_duplicates': True, 'dependencies': [{'role': 'dependency1'}, {'role': 'dependency2'}]}
    fakeRoleMetadata.deserialize(data)
    assert fakeRoleMetadata._allow_dupl

# Generated at 2022-06-21 01:21:19.919042
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    assert rmd.serialize() == dict(
            allow_duplicates=False,
            dependencies=[]
        )

# Generated at 2022-06-21 01:21:28.411160
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'


# Generated at 2022-06-21 01:21:37.037920
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create an RoleMetadata object with empty data
    target_role = RoleMetadata({})

    # Create a test data set for testing
    data = {'allow_duplicates': 'True', 'dependencies': ['database', 'webserver']}

    # Invoke the class method load() to add the data to the target RoleMetadata object
    result_role = RoleMetadata.load(data, target_role)

    assert result_role._allow_duplicates == True
    assert result_role._dependencies == ['database', 'webserver']



# Generated at 2022-06-21 01:21:46.214426
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks

    block = Block()
    play = Play.load(dict(
        name='test',
        hosts='all',
        gather_facts='no',
        roles=[
            dict(
                name='test1'
            )
        ]
    ), variable_manager=None, loader=None)
    play._included_files = []
    play._task_blocks = [block]
    block._parent = play

# Generated at 2022-06-21 01:22:32.393635
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Test that deserialize method of class RoleMetadata sets attributes properly
    """
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = ['test_role']
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata._allow_duplicates == data['allow_duplicates']
    assert role_metadata._dependencies == data['dependencies']

# Generated at 2022-06-21 01:22:41.543382
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    collection_search_list = CollectionSearch()
    collection_search_list.add_directory(os.path.join(os.environ['ANSIBLE_COLLECTIONS_PATHS'], 'ansible_collections', 'test_collection'))

    variable_manager = None
    loader = None
    owner = None

    r = RoleMetadata.load(
        {'dependencies': [{'role': 'test_collection.test'}]},
        owner,
        variable_manager,
        loader,
        collection_search_list=collection_search_list)
    assert r._dependencies[0]._role_collection.collection == 'test_collection'
    assert r._dependencies[0]._role_name == 'test'

# Generated at 2022-06-21 01:22:55.106713
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play = Play.load(dict(
        name='testplayload',
    ), loader=loader, variable_manager=None)

    playbook = Playbook.load(dict(name='test', plays=[play]), loader=loader, variable_manager=None)
    play.set_loader(loader)

    from ansible.playbook.role import Role

    role = Role.load(dict(name='foobar'),
                     play=play,
                     variable_manager=None,
                     loader=loader)


# Generated at 2022-06-21 01:23:00.924054
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [[{'role': 'marvin.test_role'}]]
    assert role_metadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': [[{'role': 'marvin.test_role'}]],
    }

# Generated at 2022-06-21 01:23:07.106274
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    class MockRole:
        name = 'test_role'
        def __init__(self, a, b, c, d):
            self._role_name = None
            self._role_path = None
            self._role_collections = []
            self._play = None
            self._hosts = []

        def get_name(self):
            return self.name

    role = MockRole('a', 'b', 'c', 'd')

    metadata = RoleMetadata(owner=role)
    metadata.deserialize(test_data)

    assert not metadata.allow_duplicates
    assert not metadata.dependencies

# Generated at 2022-06-21 01:23:11.705144
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    m.deserialize(data)
    assert m.allow_duplicates == True
    assert m.dependencies == []
    assert len(m.dependencies) == 0

# Generated at 2022-06-21 01:23:15.934426
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    role_metadata = RoleMetadata.load('/home/sea/ansible/lib/ansible/modules/cloud/amazon/', owner=None)
    assert isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-21 01:23:17.014968
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:23:20.561812
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Set up object
    owner = None
    data = dict()

    # Construct object and try to serialize
    r = RoleMetadata(owner)
    result = r.serialize()

    assert(result is not None)



# Generated at 2022-06-21 01:23:24.890539
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'dependencies': ['common']}
    m.deserialize(data)
    assert(m.dependencies == data['dependencies'])
    assert(m.allow_duplicates == False)