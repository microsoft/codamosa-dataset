

# Generated at 2022-06-21 01:14:12.238864
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta._allow_duplicates is False
    assert meta._dependencies == []

# Generated at 2022-06-21 01:14:21.305773
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class DummyRole(object):
        def __init__(self):
            self.name = "role_name"
            self.collections = []

    test_item = RoleMetadata()
    test_item.dependencies = ['role1', 'role2']
    test_item.allow_duplicates = True
    test_item._owner = DummyRole()

    result = test_item.serialize()

    assert result == {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }


# Generated at 2022-06-21 01:14:27.333417
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    md = RoleMetadata()
    md.allow_duplicates = True
    md.dependencies = [1, 2, 3, 4]
    assert md.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3, 4]}
    md.dependencies = [RoleDefinition('')]
    assert md.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': ''}]}

# Generated at 2022-06-21 01:14:32.348164
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': False,
        'dependencies': ['apache', 'common', 'mysql'],
        'galaxy_info': {
            'author': 'Joe Garcia',
            'description': 'The apache role',
            'company': 'Ansible',
        }
    })
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ['apache', 'common', 'mysql']

# Generated at 2022-06-21 01:14:32.819409
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:37.803845
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata.load({'allow_duplicates': False,
                             'dependencies': ['role1', 'role2', {'role': 'role3'}],
                             'galaxy_info': 'galaxy'
                             }, None)
    assert rmd.serialize() == {'allow_duplicates': False, 'dependencies': ['role1', 'role2', {'role': 'role3'}]}

# Generated at 2022-06-21 01:14:40.894452
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.allow_duplicates == False
    assert role.dependencies == []


# Generated at 2022-06-21 01:14:51.393591
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json
    import yaml
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib

    # Define the mocked values
    owner_hosts = [u'all']
    variable_manager = None
    loader = None

    # Load the yaml output from ansible-galaxy
    with open("tests/data/output/ansible-galaxy_role_info.yml", "r") as stream:
        role_data_yaml = yaml.load(stream)

    # Load the json output from ansible-galaxy
    with open("tests/data/output/ansible-galaxy_role_info.json", "r") as stream:
        role_data_json = json.load(stream)

    # Load the yaml output from

# Generated at 2022-06-21 01:15:03.482789
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = Base()


# Generated at 2022-06-21 01:15:06.903537
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=[])
    roledata = RoleMetadata().deserialize(data)
    assert roledata._allow_duplicates == False
    assert roledata._dependencies == []

# Generated at 2022-06-21 01:15:15.805403
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert isinstance(role, RoleMetadata)
    # TODO: how to assert class attribute has the same type?

# Generated at 2022-06-21 01:15:20.165334
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {'allow_duplicates':True,
            'dependencies':[]
            }
    metadata.deserialize(data)
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == []

# Generated at 2022-06-21 01:15:23.534055
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata(owner=None).serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:15:25.842929
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Assert: no error raised
    try:
        RoleMetadata(owner=None)
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-21 01:15:31.525158
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'dependencies': [{'role': 'foo', 'version': 'v1'}], 'allow_duplicates': False}
    m = RoleMetadata()
    m.load(data, None)
    assert m.allow_duplicates == False
    assert m.dependencies[0].role == 'foo'
    assert m.dependencies[0].params == {'version':'v1'}

# Generated at 2022-06-21 01:15:39.184174
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.collectionsearch import CollectionSearch
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition(name='test', role_path='path')
    rd.collections = ['col1']
    rd.galaxy_info = {'collections': ['col1']}
    rm = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[{'role': 'test'}]
    )
    allow_duplicates, dependencies = rm.deserialize(data)
    assert allow_duplicates is False
    assert len(dependencies) == 1 and isinstance(dependencies[0], RoleDefinition) and dependencies[0].name == 'test'

# Generated at 2022-06-21 01:15:50.653820
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    # RoleMetadata.load should get the PlayContext of the owner which is a Play
    # so first create a PlayContext
    pctx = PlayContext()
    # now create a Play
    owner = Play()
    # a Play has a PlayContext
    owner.load_context(pctx)

    # now we can create the RoleMetadata object
    metadatas = RoleMetadata.load(
        dict(
            dependencies = ["role1", "role2"],
            name = "test-role",
            description = "test role description",
            allow_duplicates = True
        ),
        owner = owner
    )
    assert metadatas.name

# Generated at 2022-06-21 01:15:52.881476
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Success: test_RoleMetadata")


# Make sure the docstring examples work
test_RoleMetadata()

# Generated at 2022-06-21 01:16:04.025299
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates = True,
        dependencies = ['role1', 'role2']
    )
    m.deserialize(data)
    assert m.allow_duplicates == True, 'RoleMetadata.deserialize failed to set allow_duplicates correctly'
    assert isinstance(m.dependencies, list)
    assert len(m.dependencies) == 2, 'RoleMetadata.deserialize failed to set dependencies correctly'
    assert m.dependencies[0] == RoleRequirement('role1'), 'RoleMetadata.deserialize failed to set dependencies correctly'
    assert m.dependencies[1] == RoleRequirement('role2'), 'RoleMetadata.deserialize failed to set dependencies correctly'

# Generated at 2022-06-21 01:16:10.502235
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata.dependencies = [{'role':"first_role"},{'role':'second_role','dir_name':'dir_name'}]
    result = metadata.serialize()
    expected_result = {'dependencies':[{'role':"first_role"},{'role':'second_role','dir_name':'dir_name'}], 'allow_duplicates':False}
    assert result == expected_result

# Generated at 2022-06-21 01:16:15.431796
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass # Nothing to test

# Generated at 2022-06-21 01:16:25.499824
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test the serialize function of class RoleMetadata
    '''
    data = dict(
        allow_duplicates=True,
        dependencies=[
            {
                'name': 'test-role',
                'src': 'git+https://git@github.com/ansible/test-role.git'
            },
            RoleRequirement(
                name='test-role',
                scm='https://git@github.com/ansible/test-role.git',
                scm_branch='devel'
            )
        ]
    )
    m = RoleMetadata(owner="test-role")
    m.load_data(data)
    assert m.serialize() == data

# Generated at 2022-06-21 01:16:37.811240
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    Inventory = namedtuple('Inventory', ['hosts'])
    VariableManager = namedtuple('VariableManager', ['extra_vars'])
    VariableManager.get_vars = lambda self, loader, path=None, entities=None, cache=True: {'item': 'value'}
    Host = namedtuple('Host', ['name'])

# Generated at 2022-06-21 01:16:42.145419
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = True
    role_meta.dependencies = ['foo']

    result = role_meta.serialize()
    assert result == {'allow_duplicates': True, 'dependencies': ['foo']}


# Generated at 2022-06-21 01:16:53.665784
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    test_tmplar = Templar(loader=None)
    test_play = Play().load({'name': 'test_play',
                             'hosts': 'localhost'},
                            variable_manager=None, loader=None)
    test_play._load_play_vars = lambda: {'play_vars': 42}
    # test_play._set_loader = lambda : 42
    test_task = Task()
    test_task._role = Role

# Generated at 2022-06-21 01:16:58.522212
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test variable
    data = dict()

    # Constructor test
    role_metadata = RoleMetadata()

    # Deserialize test
    role_metadata.deserialize(data)

    # Assertion
    assert role_metadata._dependencies == []
    assert role_metadata._allow_duplicates == False



# Generated at 2022-06-21 01:17:09.781283
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    roledef = {'abc': {'role': 'abc'},
               'foo': {'src': 'foo'},
               'bar': {'src': 'bar'}}
    roledef1 = {'foo': {'src': 'foo'},
                'bar': {'src': 'bar'},
                'abc': {'role': 'abc'}}
    roledef2 = {'foo': {'src': 'foo'}}
    roledef3 = {'foo': {'src': 'foo'},
                'abc': {'role': 'abc'}}
    roledef4 = {'foo': {'src': 'foo'},
                'bar': {'src': 'bar'},
                'abc': {'role': 'abc'}}

# Generated at 2022-06-21 01:17:13.385765
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    rm = RoleMetadata.load(data=None, owner=None)
    assert rm._dependencies is not None
    assert rm._galaxy_info is not None
    assert rm._dependencies == []
    assert rm._galaxy_info == {}

# Generated at 2022-06-21 01:17:20.109974
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    meta.deserialize(data)
    # serialize and deserialize for checking
    meta.serialize()
    meta.deserialize(data)
    assert data == meta.serialize(), 'metadata serialization failed'

    meta = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [{'role': 'common', 'collections': ['my_namespace.my_collection', 'ansible.posix']},
                         {'role': 'webserver'}]
    }
    meta.deserialize(data)
    # serialize and deserialize for cheking
    meta.serialize()
    meta.deserialize

# Generated at 2022-06-21 01:17:28.955751
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    data = [
        {
            "allow_duplicates": True,
            "dependencies": [{
                "role1": "1.0",
                "role2": "2.0"
            }]
        },
        {
            "dependencies": [{
                "role1": "1.0",
                "role2": "2.0"
            }]
        }
    ]
    for ds in data:
        obj.load_data(ds, variable_manager=None, loader=None)
        assert obj.serialize() == ds

# Generated at 2022-06-21 01:17:38.961398
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test an empty RoleMetadata object
    rmd = RoleMetadata()
    assert rmd.deserialize({}) == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # Test a full RoleMetadata object
    rmd = RoleMetadata()
    assert rmd.deserialize(dict(
        allow_duplicates=True,
        dependencies=[RoleMetadata()]
    )) == dict(
        allow_duplicates=True,
        dependencies=[RoleMetadata()]
    )

# Generated at 2022-06-21 01:17:49.612496
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    Play = namedtuple('Play', ['collections'])
    play = Play(collections=[])
    Role = namedtuple('Role', ['_role_path', 'collections', '_role_collection', '_play'])
    role = Role(
        _role_path='/foo/roles/bar',
        collections=['ansible.posix'],
        _role_collection=None,
        _play=play,
    )
    RoleInclude = namedtuple('RoleInclude', ['__ansible_module__'])
    RoleDefinition = namedtuple('RoleDefinition', ['role', 'name'])
    RoleRequirement = namedtuple('RoleRequirement', ['role', 'name'])

# Generated at 2022-06-21 01:17:59.319910
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # arrange
    from ansible.playbook.play import Play
    from ansible.module_utils.six import StringIO

    yamlstr = """
    - hosts: localhost
      tasks:
      - debug: msg="Hello World!"
    """
    play = Play.load(yamlstr, loader=None, variable_manager=None)
    role = play.get_roles()[0]

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # act
    rolemetadata = RoleMetadata(owner=role).deserialize(data)

    # assert
    assert not rolemetadata.allow_duplicates
    assert len(rolemetadata.dependencies) == 0

# Generated at 2022-06-21 01:18:04.824996
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Simple controller for verbose
    class Controller():
        def __init__(self):
            self._verbosity = 1

    # Instanciate with verbose = 1
    controller = Controller()
    role_metadata = RoleMetadata(controller)
    role_metadata.deserialize({'allow_duplicates': True})

    assert role_metadata._allow_duplicates == True

# Generated at 2022-06-21 01:18:11.820067
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    t = Task()
    p = Play()
    p._task_cache = [ t ]
    pb = Playbook()
    p._parent = pb
    p._loader = None
    pb._loader = None
    p._variable_manager = None
    pb._variable_manager = None
    p._entries = [ ]
    role_metadata = RoleMetadata.load({ }, p )
    assert role_metadata

# Generated at 2022-06-21 01:18:16.892818
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    d = {
         "allow_duplicates": True,
         "dependencies": ['demo']
    }
    m = RoleMetadata().load(d)
    assert m.allow_duplicates == True
    assert m.dependencies == ['demo']

# Generated at 2022-06-21 01:18:22.180860
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = [{"role": "test"}, {"role": "test2"}]
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': m.dependencies}


# Generated at 2022-06-21 01:18:30.432691
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize of class RoleMetadata
    '''
    #from __main__ import RoleMetadata
    role_metadata = RoleMetadata()

    role_metadata.deserialize({'a': 5})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': [{'a': 5}]})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{'a': 5}]

# Generated at 2022-06-21 01:18:36.832980
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    loader = None
    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

# Generated at 2022-06-21 01:18:47.986243
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    role_path = "/tmp/role_path"
    rolename = "rolename"

    ri = RoleMetadata()
    ri._owner = Play()
    ri._owner._role_path = role_path
    ri._owner._role_name = rolename

    assert ri._owner.get_name() == rolename
    assert ri._owner.get_path() == role_path
    assert ri._owner.is_role()

    ri.load_data([], variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-21 01:18:58.529650
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    role = RoleDefinition.load({'name': 'test',
                                'meta': {
                                    'description': 'test',
                                    'dependencies': ['role_c']
                                }})

    assert len(role.dependencies) == 1
    assert role.dependencies[0].name == 'role_c'
    assert role.metadata.serialize() == dict(allow_duplicates=False,
                                             dependencies=['role_c'])

# Generated at 2022-06-21 01:19:10.392769
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            '/path/to/role',
            {'role': 'role_name'},
            {'name': 'role_name'},
            {'src': 'role_name'},
            {'src': 'some.collection.role_name'}
        ]
    }
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates is True
    assert len(role_metadata._dependencies) == 5
    assert isinstance(role_metadata._dependencies[0], dict)
    assert isinstance(role_metadata._dependencies[1], dict)
    assert isinstance(role_metadata._dependencies[2], dict)

# Generated at 2022-06-21 01:19:17.619243
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class RoleMetadata_sub(RoleMetadata):
        pass
    role_metadata_sub = RoleMetadata_sub()
    role_metadata_sub.allow_duplicates = True
    role_metadata_sub.dependencies = 'so true'
    role_metadata_sub.serialize() == dict(
        allow_duplicates=True,
        dependencies='so true'
    )
    assert role_metadata_sub.serialize() == dict(
        allow_duplicates=True,
        dependencies='so true'
    )

# Generated at 2022-06-21 01:19:26.662037
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    include = RoleInclude()
    include._role_path = '../../../roles/ansible.builtin.k8s_get_secrets'
    include._role_name = 'ansible.builtin.k8s_get_secrets'
    include._role_collection = 'ansible.builtin'

    definition = RoleDefinition()
    definition._role_path = '../../../roles/ansible.builtin.yum'
    definition._role_name = 'ansible.builtin.yum'
    definition._role_collection = 'ansible.builtin'


# Generated at 2022-06-21 01:19:33.318512
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task import TaskInclude
    data = {'dependencies':['name: some-role'], 'allow_duplicates': True}
    m = RoleMetadata().load_data(data)
    assert m._dependencies[0]._role_name == 'some-role'
    assert isinstance(m._dependencies[0], TaskInclude)
    assert m._allow_duplicates == True

# Generated at 2022-06-21 01:19:42.043317
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    import json

    path = os.path.dirname(__file__)
    role_path = os.path.join(path, '../../lib/ansible/galaxy/collection_mock/test_col/roles/test_role')
    role_definition = RoleDefinition.load(role_path)
    ret = role_definition.metadata.serialize()
    expected = json.loads("""
    {
        "allow_duplicates": false,
        "dependencies": [
            "test_col.test_role2"
        ]
    }
    """)
    assert ret == expected


# Generated at 2022-06-21 01:19:49.067758
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata(owner=None)
    role.allow_duplicates = True
    role.dependencies = [{'name': 'roles/test1'}, {'name': 'roles/test2'}]
    data = role.serialize()
    assert data == dict(allow_duplicates=True, dependencies=[{'name': 'roles/test1'}, {'name': 'roles/test2'}])

# Generated at 2022-06-21 01:19:50.941633
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    res = RoleMetadata(owner=None).serialize()
    assert res['allow_duplicates'] == False

# Generated at 2022-06-21 01:19:54.864301
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_dm = {"allow_duplicates": False, "dependencies": []}
    test_rm = RoleMetadata()
    test_rm.deserialize(test_dm)
    assert test_rm._allow_duplicates == False
    assert test_rm._dependencies == []

# Generated at 2022-06-21 01:19:58.506686
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    am = RoleMetadata()
    am.deserialize({'allow_duplicates': True,
                    'dependencies': ['test']})
    assert am._dependencies == ['test']
    assert am._allow_duplicates is True


# Generated at 2022-06-21 01:20:13.036080
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    ansible.galaxy.api.RoleMetadata test
    '''
    _RoleMetadata = RoleMetadata()
    assert(_RoleMetadata.__class__.__name__ == 'RoleMetadata')



# Generated at 2022-06-21 01:20:24.231210
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    import pprint

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    RoleMetadata.serialize()

    # test secret
    secret = str()
    secret = secret.encode("utf-8", "strict")
    secret = secret.decode("utf-8", "ignore")
    secret = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test\n343963336366623262346361643235383530333763653330343937323733383464396238636465332\n66323461663332343239303865363761623433396534\n')

    # create_fake_RoleMetadata_obj
    obj = RoleMetadata()
    obj._attributes

# Generated at 2022-06-21 01:20:26.471675
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == {'dependencies': [], 'allow_duplicates': False}, 'Failed RoleMetadata.serialize()'



# Generated at 2022-06-21 01:20:26.895106
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-21 01:20:36.692551
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # {allow_duplicates: false, dependencies: []}
    data = {
            "allow_duplicates": False,
            "dependencies": []
            }
    # create a empty RoleMetadata object
    rolemetadata = RoleMetadata()
    # test method deserialize
    rolemetadata.deserialize(data)
    # get result
    allow_duplicates = rolemetadata.allow_duplicates
    dependencies = rolemetadata.dependencies
    serialized = rolemetadata.serialize()
    # check result
    assert allow_duplicates == False
    assert dependencies == []
    assert serialized == data


# Generated at 2022-06-21 01:20:39.482597
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    role_definition = RoleDefinition.load({'name': 'blah'}, owner=None)
    assert(role_definition.name == 'blah')

# Generated at 2022-06-21 01:20:44.986639
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    RoleMetadata.deserialize() returns a new RoleMetadata object
    """
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata().deserialize(data)
    assert type(role_metadata.dependencies) == list
    assert type(role_metadata.allow_duplicates) == bool

# Generated at 2022-06-21 01:20:49.989631
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MockRole():
        _role_path = 'role_path'
        def get_name(self):
            return 'name'

    rm = RoleMetadata(MockRole())
    assert rm
    rm.load_data({'dependencies': []})
    assert rm.dependencies == []

# Generated at 2022-06-21 01:21:01.232203
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:21:06.815951
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    m = RoleMetadata()
    data = {'dependencies': [{'role': 'rolename', 'version': '0.0.1'}, RoleDefinition.load({'role': 'rolename2'})]}
    m.deserialize(data)
    assert isinstance(m.dependencies[0], RoleRequirement)
    assert isinstance(m.dependencies[1], RoleDefinition)

# Generated at 2022-06-21 01:21:30.665399
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    data = { "allow_duplicates":True, "dependencies":["role1","role2"] }
    a.deserialize(data)
    assert a.allow_duplicates is True
    assert a.dependencies == ["role1","role2"]

# Generated at 2022-06-21 01:21:41.191987
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    pb = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            'role1',
            {'role': 'role2'},
            {'role': 'role3', 'vars': {'a': 1}},
            {'name': 'role4'},
            {'name': 'role5', 'vars': {'b': 2}},
        ],
    ))

    assert pb.roles[0].get_name() == 'role1'
    assert pb.roles[1].get_name() == 'role2'
    assert pb.roles[2].get_name() == 'role3'
    assert pb.roles[3].get

# Generated at 2022-06-21 01:21:44.083853
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rolemetadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    deserialized = rolemetadata.deserialize(data)
    assert deserialized == data

# Generated at 2022-06-21 01:21:44.884245
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: implement
    assert True

# Generated at 2022-06-21 01:21:52.527981
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """Test serialize method of RoleMetadata class
    """
    role_mdata = RoleMetadata()
    role_mdata.allow_duplicates = True
    role_mdata.dependencies = ['bla', 'blu']
    res = role_mdata.serialize()
    assert res == {'allow_duplicates': True, 'dependencies': ['bla', 'blu']}, \
        "serialize failed"
    print('Test serialize passed.')

if __name__ == '__main__':
    test_RoleMetadata_serialize()

# Generated at 2022-06-21 01:22:02.736297
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play

    # Test RoleMetadata.(_init_)
    # For this test, the following information is used:
    #   * description:
    #       The metadata file 'meta/main.yml' of the role named
    #       'role_name' in the path 'play_path' declares the
    #       role dependency 'dependency'. The path of the role
    #       dependency 'dependency' is 'dependency_path'.
    #       The role dependency 'dependency' has collection ID
    #       'role_collection_id' and role name 'role_name' if it
    #       is a collection role, otherwise, None and 'dependency'
    #      

# Generated at 2022-06-21 01:22:13.815884
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    def assert_AllowedKey(test):
        try:
            RoleMetadata.load(test, None)
        except AnsibleParserError:
            pass
        else:
            assert False, "Expected AnsibleParserError"

    from ansible.playbook.role.requirement import RoleRequirement


# Generated at 2022-06-21 01:22:22.159305
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.plugins.loader as plugins
    import ansible.playbook.role.definition as role_definition
    import ansible.playbook.role.search as role_search
    import ansible.playbook.role.include as role_include

    info_mock = RoleMetadata()
    info_mock._owner = plugins.get('role', 'test', './test_data/test_role_directory')
    info_mock._owner._role_path = 'test_data/test_role_directory/meta/main.yml'
    role_definition_mock = role_definition.RoleDefinition()
    role_definition_mock.register_loader('role', get_role_definition)
    role_search_mock = role_search.RoleSearch()

# Generated at 2022-06-21 01:22:29.220357
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # For the current method load of class RoleMetadata,
    # this test case only verify code of 'deserialize' method.
    # For other code of method load, please refer to test_RoleInclude_load
    data = {'allow_duplicates': False, 'dependencies': []}
    parsed_data = RoleMetadata().deserialize(data)
    assert parsed_data.get('allow_duplicates') == False
    assert parsed_data.get('dependencies') == []
    return True

# Generated at 2022-06-21 01:22:31.521442
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta_data = dict(
        allow_duplicates=True,
        dependencies=['test_key1', 'test_key2']
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data=meta_data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['test_key1', 'test_key2']

# Generated at 2022-06-21 01:23:21.653443
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.role_builder import load_list_of_roles
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Roles are detected in the current directory.
    # The current directory is '.', so a directory named 'r' is created
    # in '.' and contains a role named 'r1' (see below).
    role_base_path = '.'
    role_name = 'r1'
    role_path = os.path.join(role_base_path, role_name)
    role_dependency_path = os.path.join(role_path, 'tasks', 'main.yml')

    # The role contains a tasks file named 'main.y

# Generated at 2022-06-21 01:23:25.151906
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize({'allow_duplicates': True, 'dependencies': 'test_deps'})

    assert obj._allow_duplicates == True
    assert obj._dependencies == 'test_deps'

# Generated at 2022-06-21 01:23:34.321261
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    mock_data = dict(
        allow_duplicates=False,
        dependencies=['test']
    )
    role_def = RoleDefinition(name='test')
    role_def._role_path = '/test/test'
    role_def._role_collection = 'test'
    role_def.collections = ['test']
    role_metadata = RoleMetadata(owner=role_def)
    role_metadata.deserialize(mock_data)
    meta = role_metadata.serialize()
    assert meta['allow_duplicates'] is False
    assert meta['dependencies'] == ['test']

# Generated at 2022-06-21 01:23:40.518976
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class MockRole(object):
        def __init__(self, name="myRole"):
            self.name = name
    r = MockRole()
    rm = RoleMetadata(owner=r)
    rm.deserialize({'allow_duplicates': True, 'dependencies': [{'name': 'testRole'}]})
    assert rm.serialize() == {'allow_duplicates': True, 'dependencies': [{'name': 'testRole'}]}

# Generated at 2022-06-21 01:23:48.457006
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.collectionsearch import CollectionSearch
    rd=RoleDefinition()
    ri = RoleInclude()
    ri._role=rd
    rm = RoleMetadata()
    rm._dependencies=ri
    rm._galaxy_info=rd
    assert rm._owner is None
    assert rm._load_dependencies(rm._dependencies,None) == []
    assert rm.serialize() == dict(allow_duplicates=False,dependencies=[])
    setattr(rm,'_owner',rd)
    assert rm._load_dependencies(rm._dependencies,[{'role':'ratatatat'}]) == [{'role':'ratatatat'}]

# Generated at 2022-06-21 01:23:58.443265
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    role = Role()
    role._role_path = '/path/to/role'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    RoleMetadata.load({}, role, variable_manager=variable_manager, loader=loader)