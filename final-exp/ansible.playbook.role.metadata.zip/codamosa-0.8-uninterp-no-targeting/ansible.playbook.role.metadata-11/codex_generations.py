

# Generated at 2022-06-21 01:14:10.595026
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test init without variable_manager and loader
    role_meta_data = RoleMetadata(owner=None)
    assert role_meta_data is not None

# Generated at 2022-06-21 01:14:18.437246
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [{"role": "some.role"}],
    }
    role = RoleMetadata(None)
    role.deserialize(data)
    assert hasattr(role, 'allow_duplicates')
    assert hasattr(role, 'dependencies')
    assert role.allow_duplicates == True
    assert role.dependencies == [{"role": "some.role"}]

# Generated at 2022-06-21 01:14:27.574538
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(name='test'),
            dict(name='test1'),
        ]
    )

    # Basic deserialize
    m = RoleMetadata()
    m.deserialize(data)

    # Check deserialization

    # Since dependencies is a list of RoleInclude the correct way of
    # comparing is running the serialize method on all elements of
    # dependencies.
    dependency = [r.serialize() for r in m.dependencies]
    assert m.allow_duplicates == data.get('allow_duplicates', False)
    assert dependency == data.get('dependencies', [])

# Generated at 2022-06-21 01:14:30.782704
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # This tests that RoleMetadata.deserialize reads data correctly
    # Currently, there seem to be no tests for this class. It is not
    # clear what the purpose of this class is.

    # Set up test data
    data = dict(dependencies=[1, 2, 3])

    # Instantiate class
    role_meta_data = RoleMetadata()
    role_meta_data.deserialize(data)

    # Assert data has correctly been read
    assert(role_meta_data._dependencies == [1, 2, 3])

# Generated at 2022-06-21 01:14:33.075468
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates is False
    assert role._dependencies == []
    assert role._galaxy_info is None
    assert role._argument_specs == {}

# Generated at 2022-06-21 01:14:41.184783
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    m = RoleMetadata.load({'allow_duplicates': True}, owner=Play().load({'name': 'foo'}), variable_manager=VariableManager())
    assert m.allow_duplicates == True
    assert m.dependencies == []
    m = RoleMetadata.load({'dependencies': ['common']}, owner=Play().load({'name': 'foo'}), variable_manager=VariableManager())
    assert m.allow_duplicates == False
    assert m.dependencies == ['common']

# Generated at 2022-06-21 01:14:43.969754
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata({'name': 'test', 'path': './'})
    assert role.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:14:47.618834
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': False, 'dependencies': []}
    m = RoleMetadata.load(data,None,None)
    assert m.allow_duplicates is False
    assert m.dependencies == []

# Generated at 2022-06-21 01:14:48.958114
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-21 01:14:49.406186
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:57.377300
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:15:03.342057
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Prepare test objects
    data = dict(
        allow_duplicates=True,
        dependencies=['ansible-base', 'ansible.builtin']
    )

    # Run method
    rm = RoleMetadata()
    rm.deserialize(data)
    res = rm.serialize()

    # Assertion
    assert res == data

# Generated at 2022-06-21 01:15:13.840298
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import load_extra_vars

    myplay = Play().load({
        u'hosts': u'all',
        u'name': u'myname',
        u'roles': [
            u'apt',
            u'foo',
            u'far',
            {u'role': u'bar', u'bar': u'baz', u'baz': u'blip'},
            {u'include': u'include.yml'},
            {u'include': u'include.yml'},
        ]
    }, loader=None)

    extra_vars = load_extra_vars(dict(), None, variables={})

# Generated at 2022-06-21 01:15:17.876993
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    assert role_meta._allow_duplicates == False
    assert role_meta._dependencies == []
    assert role_meta._argument_specs == {}
    assert role_meta._galaxy_info is None

# Generated at 2022-06-21 01:15:21.405810
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    print(metadata)
    data = dict(
        dependency=list()
    )
    metadata.deserialize(data)
    print(metadata)


# Generated at 2022-06-21 01:15:32.323266
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    mock_context = PlayContext()
    mock_definition = RoleDefinition(name='test')
    mock_variable_manager = {}
    mock_loader = {}


# Generated at 2022-06-21 01:15:33.627036
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pm = RoleMetadata(owner="owner")
    assert pm.allow_duplicates == False
    assert pm.dependencies == []

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-21 01:15:37.595758
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    
    rm = RoleMetadata()
    rm.deserialize(data)
    assert rm._allow_duplicates == data.get('allow_duplicates', False)
    assert rm._dependencies == data.get('dependencies', [])

# Generated at 2022-06-21 01:15:49.729086
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.role.definition import RoleDefinition
    temp__var_manager = None
    temp__loader = None
    temp__role = RoleDefinition.load("test_role",
                                     {"name": "test_role", "dependencies": [{"role": "test_depen"}, "test_depen2"],
                                      "allow_duplicates": True, "galaxy_info": {}, "tasks": []},
                                     variable_manager=temp__var_manager, loader=temp__loader)
    temp__role_meta = RoleMetadata.load({"allow_duplicates": False, "dependencies": [{"role": "test_depen"}, "test_depen2"], "galaxy_info": {}}, temp__role)
   

# Generated at 2022-06-21 01:15:59.048065
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    my_loader = AnsibleLoader(datastring="{'allow_duplicates': 'True', 'dependencies': 'test'}", loader=dataloader)
    playcontext = PlayContext()
    play = Play()
    play.variable_manager = VariableManager()
    rolemetadata = RoleMetadata()
    rolemetadata.deserialize(my_loader)
    assert(rolemetadata.allow_duplicates == 'True')

# Generated at 2022-06-21 01:16:17.048934
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class Owner(object):
        pass
    owner = Owner()
    owner.get_name = lambda : 'repo-name'
    role_metadata = RoleMetadata(owner)
    assert role_metadata._owner == owner
    assert role_metadata._dependencies == []
    assert role_metadata._allow_duplicates == False
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-21 01:16:18.134339
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass # Nothing to test currently

# Generated at 2022-06-21 01:16:25.165069
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.playbook.role.definition
    inventory = ansible.inventory.Inventory(host_list=[])
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'hostvars': {'127.0.0.1': ansible.vars.HostVars({}, variable_manager)}}
    variable_manager.set_loader(loader)
    play = Play

# Generated at 2022-06-21 01:16:37.810893
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    import os

    ROLE_PATH = '%s/../../../test/units/lib/ansible/playbook/test_role_metadata' % os.path.dirname(__file__)

    loader = DataLoader()
    variable_manager = {
        'some_var': 'value'
    }
    roles = load_list_of_roles([
        '%s/roles/role-1' % ROLE_PATH,
        '%s/roles/role-2' % ROLE_PATH
    ], play=None, current_role_path=ROLE_PATH, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:16:49.244392
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.dependent_role import DependentRole
    from ansible.playbook.role.definition import RoleDefinition

    # test load role_include
    p = Play().load({'hosts': 'all', 'gather_facts': 'no',
                     'roles': [{'role': 'test1', 'other_vars': [123, 234]}, {'role': 'test2'}]},
                    variable_manager=None, loader=None)
    role_include = p.get_roles()[0]
    p.post_validate()
    assert isinstance(role_include, RoleDefinition)

    # test

# Generated at 2022-06-21 01:16:50.911806
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata.deserialize(data=None)


# Generated at 2022-06-21 01:16:59.085697
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role._role
    import ansible.playbook.role.metadata
    import ansible.playbook.role.requirement

    # define a mock _RoleDefinition class
    class _RoleDefinition:
        def __init__(self):
            self._role_name = "my_role"
            self._role_path = "my_role_path"

    # define a mock _Role class
    class _Role:
        def __init__(self):
            self._role_path = "my_role_path"
            self._play = "my_play"
            self.collections = ["my_collection"]

    # define a mock _GalaxyInfo class

# Generated at 2022-06-21 01:16:59.967898
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-21 01:17:11.808846
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    fake_play = "fake_play"
    fake_role_name = "fake_role_name"
    fake_tasks_path = "fake_tasks_path"
    fake_vars_path = "fake_vars_path"
    fake_meta_path = "fake_meta_path"
    fake_file_name = "fake_file_name"
    fake_collection = "fake_collection"
    fake_role_path = "fake_role_path"

    fake_data = dict(
        allow_duplicates=False,
        dependencies=[],
    )


# Generated at 2022-06-21 01:17:13.759135
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(self, 'allow_duplicates', False)
    setattr(self, 'dependencies', [])

# Generated at 2022-06-21 01:17:43.185672
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    
    # RoleMetadata._serialize: deserialisation of a class
    roleMetadata = RoleMetadata()
    roleMetadata._serialize(dict(allow_duplicates=False, dependencies=[]))
    
    # RoleMetadata.serialize: serialisation of a class
    serialized = roleMetadata.serialize()
    assert isinstance(serialized, dict)
    assert 'allow_duplicates' in serialized
    assert 'dependencies' in serialized

# Generated at 2022-06-21 01:17:53.377542
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # method load of class RoleMetadata invoked with argument data equal to the following value:
    data = {"galaxy_info": {}, "dependencies": [], "allow_duplicates": False}
    # method load of class RoleMetadata invoked with argument owner equal to the following value:
    owner = None
    # method load of class RoleMetadata invoked with keyword arguments variable_manager and loader equal to the following values:
    variable_manager = None
    loader = None
    # name of the method: test_RoleMetadata_load
    # calling of the method 'load' of class 'RoleMetadata' with positional arguments (data, owner)
    result_load = RoleMetadata.load(data, owner, variable_manager, loader)
    # value of result_load as output of method 'load' equal to the following value:

# Generated at 2022-06-21 01:18:04.871495
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    my_play_context = PlayContext()

    rmd1 = RoleMetadata(loader=loader, variable_manager=variable_manager, play_context=my_play_context, allow_duplicates=True, dependencies=[])
    rmd1.serialize()

    rmd2 = RoleMetadata(loader=loader, variable_manager=variable_manager, play_context=my_play_context, allow_duplicates=False, dependencies=['foo', 'bar', 'baz'])
    rmd2.serialize()


# Generated at 2022-06-21 01:18:10.900475
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a test role
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition.load('/home/vagrant/ansible/test_role')
    rm = RoleMetadata(owner=rd)
    assert isinstance(rm._dependencies, list)
    assert isinstance(rm.dependencies, list)
    assert rm._owner._role_path == '/home/vagrant/ansible/test_role'


# Generated at 2022-06-21 01:18:23.049395
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[])
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == []

    role_metadata = RoleMetadata()
    data = dict(dependencies=[])
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []


# Generated at 2022-06-21 01:18:30.471751
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    # Create a role
    role1 = Role.load({},
                      playbook=None,
                      defs=[RoleDefinition('role1', None, None, None)])

    # Create a metadata
    meta1 = RoleMetadata(role1)

    assert 'meta1' == meta1.name
    assert False == meta1.allow_duplicates
    assert [] == meta1.dependencies
    assert {} == meta1.argument_spec

# Generated at 2022-06-21 01:18:38.059324
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    role_data = dict(name="test", src="my_role")
    role_definition = RoleDefinition.load(role_data)
    role_dependencies = RoleInclude.load(role_data)
    role_metadata = RoleMetadata()
    role_metadata._load_dependencies("dependencies", [role_data])
    assert isinstance(role_metadata._dependencies[0], RoleInclude)
    assert not role_metadata.allow_duplicates
    assert role_metadata.serialize().get("dependencies")
    assert role_metadata.deserialize(dict(dependencies=["role_dependencies"], allow_duplicates=True))

# Generated at 2022-06-21 01:18:42.768014
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(
        owner=None
    )
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [1]
    assert role_metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=[1]
    )

# Generated at 2022-06-21 01:18:46.490756
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': []}
    roleMetadata.deserialize(data)
    assert roleMetadata.serialize() == data


# Generated at 2022-06-21 01:18:57.314001
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Role:
        def __init__(self, name, ds):
            self._role_name = name
            self._role_path = "test"
            self._collections = ['some_collection']
            self._ds = ds
        def get_name(self):
            return self._role_name
        def get_vars(self, loader, variables):
            return dict()

    import yaml

# Generated at 2022-06-21 01:20:03.539053
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # object instantiate
    role_metadata = RoleMetadata()

    # data generate
    data = {'allow_duplicates': False, 'dependencies': []}
    assert role_metadata.deserialize(data).serialize() == data

    # data generate
    data = {'allow_duplicates': True, 'dependencies': {'role': 'test.test-role'}}
    assert role_metadata.deserialize(data).serialize() == data

    # data generate
    data = {'allow_duplicates': True, 'dependencies': {'role': 'test.test-role'}}
    assert role_metadata.deserialize(data).serialize() == data

    # data generate

# Generated at 2022-06-21 01:20:10.962096
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import os
    import sys
    sys.path.append(".")
    import lib.galaxy_artifacts

    def test_serialize(test_dir, expected_dict, allow_duplicates = False, dependencies = None):
        r = RoleMetadata()
        setattr(r, 'allow_duplicates', allow_duplicates)
        setattr(r, 'dependencies', dependencies)
        serialized = r.serialize()
        assert serialized == expected_dict
        serialized_json = lib.galaxy_artifacts.json_dumps(serialized)
        expected_dict_json = lib.galaxy_artifacts.json_dumps(expected_dict)
        assert serialized_json == expected_dict_json


# Generated at 2022-06-21 01:20:14.363502
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []

# Generated at 2022-06-21 01:20:23.896912
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class owner:
        def __init__(self):
            self._role_path = '~/ansible/playbooks/roles/marvin/meta/main.yml'
            self.collections = ['ansible.builtin', 'ansible.posix']
            self._role_collection = 'ansible.builtin'
            self._play = None
    ansible = owner()
    data = {'allow_duplicates': True,
            'dependencies': [{'role': 'roles/marvin/meta/main.yml'}]}
    r = RoleMetadata.load(data, ansible)
    assert r is not None


# Generated at 2022-06-21 01:20:31.021627
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.plugins.loader import module_loader

    owner = Block()
    variable_manager = None
    loader = None
    data = dict()

    # load a RoleMetadata
    m = RoleMetadata(owner=owner).load_data(data, variable_manager=variable_manager, loader=loader)

    # serialize the role metadata
    serialize = m.serialize()

    # the dict of the serialized role metadata should be a dict
    assert isinstance(serialize, dict)

    # serialize should contain '

# Generated at 2022-06-21 01:20:41.449436
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class MockRole(object):
        def __init__(self):
            self._role_collection = 'mock_role'
            self._play = 'mock_play'
            self._loader = 'mock_loader'
            self._variable_manager = 'mock_variable_manager'
            self.collections = []
    mock_role = MockRole()

    mock_data = {'allow_duplicates': False,
                 'dependencies': [{'role': 'test_role', 'name': 'test_name'}]}
    role_metadata = RoleMetadata(owner=mock_role).deserialize(data=mock_data)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies[0].role == 'test_role'
    assert role_metadata.dependencies

# Generated at 2022-06-21 01:20:44.105244
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta_data = RoleMetadata()
    assert meta_data.allow_duplicates == False
    assert meta_data.dependencies == []

# Generated at 2022-06-21 01:20:47.072489
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rmd = RoleMetadata()
    assert rmd._dependencies == []
    assert rmd._allow_duplicates == False

# Generated at 2022-06-21 01:20:54.742589
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.base import Base

    data = dict(
        allow_duplicates=False,
        dependencies=["b", "c"]
    )

    base = Base.deserialize(data)
    assert base.allow_duplicates == False
    assert base.dependencies == ["b", "c"]

    my_role_metadata = RoleMetadata()
    my_role_metadata.deserialize(data)
    assert my_role_metadata.allow_duplicates == False
    assert my_role_metadata.dependencies == ["b", "c"]

# Generated at 2022-06-21 01:20:59.881353
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [1, 2]
    assert (role_metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=[1, 2]
    ))



# Generated at 2022-06-21 01:22:08.677717
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = []
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': []}



# Generated at 2022-06-21 01:22:17.753545
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import ansible.utils.vars

    _task_included = TaskInclude.load(dict(
        name="test",
    ))

    _tasks = list()
    _tasks.append(Task.load(dict(
        name="test",
        include=_task_included,
    )))

    _block = Block.load(dict(
        name="test",
        tasks=_tasks
    ))

    _play = Play().load(
        dict(
            name="test",
            hosts="all",
            gather_facts="no",
            roles=[],
            blocks=[_block]
        ),
        variable_manager=ansible.utils.vars.VariableManager()
    )



# Generated at 2022-06-21 01:22:29.659535
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play

    play_context = dict(
        foo='bar',
        bar='foo'
    )
    role_path = os.path.join(os.path.dirname(__file__), '..', 'unit', 'utils', 'test_meta', 'nodeps')
    playbook_dir = os.path.dirname(role_path)


# Generated at 2022-06-21 01:22:35.459973
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': False, 'dependencies': [{'role': 'test_role', 'other_vars': 'here'}]}
    result = RoleMetadata.load(data=data, owner=None)
    assert result.allow_duplicates == False
    assert result.dependencies[0].role == 'test_role' and result.dependencies[0].other_vars == 'here'

# Generated at 2022-06-21 01:22:38.346594
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """ Unit test for method deserialize of class RoleMetadata """
    RoleMetadata().deserialize({})
    RoleMetadata().deserialize({'allow_duplicates': True})


# Generated at 2022-06-21 01:22:40.451755
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemetadata = RoleMetadata()
    assert rolemetadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:22:43.528293
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """Verifies that RoleMetadata serializes correcty to a python dictionary"""
    data = {
        'allow_duplicates': False,
        'dependencies': [],
        }
    rm = RoleMetadata(owner=None)
    rm.deserialize(data)
    assert data == rm.serialize()

# Generated at 2022-06-21 01:22:47.756485
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    d = dict(a=1)
    role = RoleMetadata(d)
    assert(role.get_ds() == d)
    assert isinstance(role.get_dependencies(), list)
    assert role.get_allow_duplicates() is False

# Generated at 2022-06-21 01:22:48.659525
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert False

# Generated at 2022-06-21 01:22:57.363083
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role

    d = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2', 'role3']
    )

    role = Role.load({}, 'a_role_name')
    role_metadata = RoleMetadata(owner=role)

    role_metadata.deserialize(d)

    assert role_metadata.allow_duplicates == True
    assert isinstance(role_metadata.dependencies, list)
    assert len(role_metadata.dependencies) == 3