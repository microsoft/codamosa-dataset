

# Generated at 2022-06-21 01:14:09.835705
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test deserialize with valid input
    # Arrange
    test_object = RoleMetadata()
    test_json_data = {"allow_duplicates":False, "dependencies":[]}
    # Act
    test_object.deserialize(test_json_data)
    # Assert
    assert test_object.allow_duplicates == False
    assert test_object.dependencies == []

# Generated at 2022-06-21 01:14:21.983695
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

# Generated at 2022-06-21 01:14:28.830925
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement

    role1 = Role()
    role1._role_name = "test_role1"
    role2 = Role()
    role2._role_name = "test_role2"

    meta = RoleMetadata()
    meta._dependencies = [role1]
    meta._dependencies.append(role2)

    meta._galaxy_info = None
    assert(meta.serialize() == {'allow_duplicates': False, 'dependencies': [role1, role2]})


# Generated at 2022-06-21 01:14:32.351549
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True, 'dependencies':['a','b']})
    assert r.serialize() == {'allow_duplicates': True, 'dependencies':['a','b']}


# Generated at 2022-06-21 01:14:39.438395
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create an empty RoleMetadata. We will fill its attributes
    # afterwards.
    role_metadata_object = RoleMetadata()
    # Create a data structure which is justified to create
    # an RoleMetadata object.
    data = {'galaxy_info': {'author': 'XooVoo'}}
    # Load the object with the data structure. In this case, the owner
    # argument is set to None.
    role_metadata_object.load(data, None)
    # Check if the object is really created and its attribute is filled.
    # The expected result is that the attribute is filled.
    assert (role_metadata_object._galaxy_info.author == 'XooVoo')


# Generated at 2022-06-21 01:14:48.974195
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import pytest
    r = RoleMetadata()
    # verify the __init__ function
    assert r.allow_duplicates == False
    assert r.dependencies == []
    assert r._owner is None
    # verify the __init__ function with given value
    r = RoleMetadata(owner="owner")
    assert r._owner == "owner"
    # verify the _load_dependencies() function
    # with a normal input list
    r = RoleMetadata()
    l = [
            "common",
            { "role": "web", "port": 8080 }
        ]
    assert r._load_dependencies("dependencies",l) == l
    # with a error input list,it will raise AnsibleParserError

# Generated at 2022-06-21 01:15:01.426973
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.collectionsearch import CollectionSearch
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    collection_search_list = CollectionSearch(loader=None, play=None, current_path=None, directories_paths=None, collection_paths=None)
    dependency_role_definition = RoleDefinition(name='role_definition', role_path='/path/to/role/role_definition', collection_search_list=collection_search_list, variable_manager=None, loader=None, play=None)

# Generated at 2022-06-21 01:15:07.150767
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Role():
        def __init__(self):
            self.name = ''
            self.task_blocks=[]
            self.collection = None
            self.collections = []

    r = Role()
    r.name = 'test'
    r.task_blocks = [[]]
    r.collections = ['ansible.builtin','ansible.posix','ansible.windows']

    metadata = RoleMetadata(owner=r)
    assert metadata.deserialize({'dependencies':[]})

# Generated at 2022-06-21 01:15:08.960736
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    def test_param():
        # Unit test for constructor of class RoleMetadata
        pass

# Generated at 2022-06-21 01:15:10.756210
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:15:28.383599
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader

    variable_manager = None
    loader = DataLoader()

    # test valid metadata
    play = Play.load(dict(
        name="Ansible Play",
        hosts=["foo.com","bar.com"],
        gather_facts="no",
        roles=[{
            "name": "first",
            "metadata": dict(
                allow_duplicates=True
            )
        }]
    ), variable_manager=variable_manager, loader=loader)

    assert (play.get_roles()[0].metadata.allow_duplicates)

    # test invalid metadata

# Generated at 2022-06-21 01:15:38.294307
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-21 01:15:40.439832
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Testing constructor
    role_metadata = RoleMetadata()
    assert role_metadata._dependencies is not None

# Generated at 2022-06-21 01:15:45.231898
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = { 'allow_duplicates': True, 'dependencies': ['test_role'] }
    result = RoleMetadata(owner=None).deserialize(data)

    assert result == None, "RoleMetadata deserialize method must return None. Error: {}".format(result)


# Generated at 2022-06-21 01:15:53.160423
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({'allow_duplicates': True,
                      'dependencies': [{"src": "geerlingguy.jenkins", "name": "jenkins"},
                                       {"src": "geerlingguy.docker", "name": "docker", "version": "1.0.0"}]})
    assert role._allow_duplicates is True
    assert "geerlingguy.jenkins" in role._dependencies
    assert "geerlingguy.docker" in role._dependencies



# Generated at 2022-06-21 01:15:56.257538
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    specify_metadata = dict(
        allow_duplicates=False,
        dependencies=[])
    role = RoleMetadata()
    role.deserialize(specify_metadata)

    assert not role._allow_duplicates
    assert not role._dependencies

# Generated at 2022-06-21 01:16:08.427930
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class GalaxyInfo:
        def __init__(self):
            self.author = 'Ansible'
            self.description = 'This is a fake role'
            self.company = 'Ansible'
            self.license = 'GPLv3'
            self.min_ansible_version = '2.7'
            self.min_python_version = '2.7'

    class Role:
        def __init__(self):
            self.name = 'fake_role'

    r = RoleMetadata(owner=Role())

# Generated at 2022-06-21 01:16:19.228986
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    import constants
    import os

    # Test case 1:
    # Test deserialize of role with dependencies that are not dict.
    # Test the name is set correctly.

    # Test case 2:
    # Test deserialize of role with dependencies that are an list of strings.
    # Test the role names variables are set correctly
    # Test the role name is set correctly


# Generated at 2022-06-21 01:16:24.839192
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == set()
    assert not role_metadata._galaxy_info

# Generated at 2022-06-21 01:16:33.746559
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    x = RoleMetadata()
    x.deserialize({
        'allow_duplicates': True,
        'dependencies': ['nginx.role', {'src': 'redis.role', 'version': '2.0'}],
    })

    assert x.allow_duplicates
    assert isinstance(x.dependencies, list)
    assert len(x.dependencies) == 2
    assert isinstance(x.dependencies[0], dict)
    assert isinstance(x.dependencies[1], dict)

# Generated at 2022-06-21 01:16:48.896917
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()

    assert role._allow_duplicates is False
    data = dict(allow_duplicates=True)
    role.deserialize(data)
    assert role._allow_duplicates is True

# Generated at 2022-06-21 01:16:52.122615
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates == False
    assert role._dependencies == []
    assert role._galaxy_info == {}
    assert role._argument_specs == []

# Generated at 2022-06-21 01:16:57.265015
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata.
    '''
    r = RoleMetadata(owner=None)
    assert r is not None
    assert r._owner is None
    assert r._data is None
    assert r._variable_manager is None
    assert r._loader is None
    assert r._ds is None
    assert r._allow_duplicates is False
    assert r._dependencies == []



# Generated at 2022-06-21 01:17:06.306917
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test with valid inputs
    try:
        RoleMetadata.load({"allow_duplicates": True,
                           "dependencies": ["foo.bar"]},
                          owner=None)
    except AnsibleParserError:
        raise AssertionError("RoleMetadata constructor failed with valid inputs")

    # Test with invalid inputs
    try:
        RoleMetadata.load({"allow_duplicates": True,
                           "dependencies": "foo.bar"},
                          owner=None)

        raise AssertionError("RoleMetadata constructor failed to raise AnsibleParserError for invalid input")
    except AnsibleParserError:
        pass


# Generated at 2022-06-21 01:17:08.015667
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-21 01:17:17.406837
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    # test for empty dict
    assert RoleMetadata.serialize(RoleMetadata()) == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # test for non-empty dict
    def task_include(v):
        return TaskInclude(task=dict(action=v), role_name=v)

    def include_role(v):
        return IncludeRole(task=dict(action=v), role_name=v, role_path=v)

    rmd = RoleMetadata()
    rmd.allow_duplicates=True

# Generated at 2022-06-21 01:17:23.642268
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=["dep1", "dep2"]
    )
    rmd.deserialize(data)
    assert rmd._allow_duplicates is True
    assert rmd._dependencies == ["dep1", "dep2"]

# Generated at 2022-06-21 01:17:29.659746
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a fake loader
    loader = mock.MagicMock()
    loader.get_basedir.return_value = os.getcwd()

    # Create a fake variable manager
    variable_manager = mock.MagicMock()

    # Create a fake role
    role = mock.MagicMock()
    role.get_name.return_value = 'test_role'
    role._role_path = 'test/path'

    role_data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    role_metadata = RoleMetadata(owner=role)
    role_metadata.deserialize(role_data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-21 01:17:34.534438
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata(allow_duplicates=True).serialize() == dict(allow_duplicates=True, dependencies=[])
    # TODO: more tests

# Generated at 2022-06-21 01:17:39.788866
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    valid_inputs = {
        'pure_dict': {
            'galaxy_info': {
                'author': 'picard',
                'company': 'starfleet academy'
            },
            'dependencies': [
                'kirk',
                'spock'
            ]
        },
    }

    for key in valid_inputs.keys():
        RoleMetadata.load(valid_inputs[key], None)


# Generated at 2022-06-21 01:18:12.243401
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class MockRole:
        def __init__(self):
            self.collections = ['collections.namespace.1', 'collections.namespace.2']
            self.get_name = lambda: 'myrole'
            self._play = self

    mock_role = MockRole()

    r = RoleMetadata(owner=mock_role)
    assert (r.serialize()) == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    r = RoleMetadata(owner=mock_role).load_data({'dependencies':[{'role':'role1'},{'role':'role2'}]})

# Generated at 2022-06-21 01:18:14.521738
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    r._get_valid_attrs()

# Generated at 2022-06-21 01:18:25.846214
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    utils.write_file("/tmp/ansible_test_playbook/my_first_playbook.yml", "---\n- name: My first play\n  hosts: localhost\n  connection: local\n  gather_facts: False\n  roles:\n  - foo\n  - bar")
    utils.write_file("/tmp/ansible_test_playbook/roles/foo/meta/main.yml", "---\ndependencies: []")
    utils.write_file("/tmp/ansible_test_playbook/roles/foo/tasks/main.yml", "---\n- ping:")

# Generated at 2022-06-21 01:18:31.319362
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    for i in ["dependencies", "allow_duplicates"]:
        assert getattr(rm, i) is None
    rm.deserialize({"allow_duplicates":False, "dependencies": []})
    for i in ["allow_duplicates", "dependencies"]:
        assert getattr(rm, i) == []


# Generated at 2022-06-21 01:18:36.334263
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """deserialize: empty dict returns unchanged object"""
    obj = RoleMetadata()
    obj.allow_duplicates = 'hi'
    obj.dependencies = ['foo', 'bar']
    obj.deserialize({})
    assert obj.allow_duplicates == 'hi'
    assert obj.dependencies == ['foo', 'bar']


# Generated at 2022-06-21 01:18:42.287502
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr_test = RoleMetadata()
    setattr_test.deserialize(dict(allow_duplicates=False))
    assert not setattr_test.allow_duplicates

    setattr_test.deserialize(dict(dependencies=["test.test"]))
    assert setattr_test.dependencies == ["test.test"]



# Generated at 2022-06-21 01:18:54.130611
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    temp_info = RoleDefinition()
    test_RoleMetadata = RoleMetadata(owner=temp_info)

    # assert allow_duplicates field is False
    assert isinstance(test_RoleMetadata._allow_duplicates, bool)
    assert test_RoleMetadata._allow_duplicates is False

    # assert _dependencies field is an instance of list
    assert isinstance(test_RoleMetadata._dependencies, list)
    assert len(test_RoleMetadata._dependencies) == 0

    # assert _galaxy_info field is an instance of GalaxyInfo
    assert isinstance(test_RoleMetadata._galaxy_info, GalaxyInfo)

    # assert _argument_specs field is a dictionary

# Generated at 2022-06-21 01:19:00.935687
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.module_utils.common.collections import ImmutableDict

    filename = "include/test.yml"
    play_context = PlayContext()
    collection_search_list = ['ansible.builtin']


# Generated at 2022-06-21 01:19:12.925380
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    roleMetadata = RoleMetadata()
    assert roleMetadata._allow_duplicates == False
    assert roleMetadata._dependencies == []
    assert roleMetadata._galaxy_info == None
    assert roleMetadata._argument_specs == {}

    # Test the getter and setter of _allow_duplicates
    roleMetadata.set_owner(owner=None)
    roleMetadata.set_data(data={'allow_duplicates': True})
    assert roleMetadata._allow_duplicates == True
    roleMetadata.set_data(data={'allow_duplicates': False})
    assert roleMetadata._allow_duplicates == False
    allow_duplicates = roleMetadata.get_allow_duplicates()
    assert allow_duplicates == False

    # Test the getter and

# Generated at 2022-06-21 01:19:18.074700
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata.load({'allow_duplicates': True}, None)
    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': []}
    meta.deserialize({'dependencies': ['test.test']})
    assert meta._dependencies == ['test.test']
    assert meta.serialize()['dependencies'] == ['test.test']

# Generated at 2022-06-21 01:20:04.362597
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test for method deserialize of class RoleMetadata

    The method deserialize of class RoleMetadata loads the data
    of a RoleMetadata object, from a dictionary.

    This test ensures that a RoleMetadata object is properly
    deserialized from a dictionary.
    '''

    my_role_metadata = RoleMetadata()

    my_dict = dict()
    my_dict['dependencies'] = ['role1']
    my_dict['allow_duplicates'] = True
    my_dict['galaxy_info'] = {}
    my_dict['argument_spec'] = {}
    my_dict['__ansible_module__'] = True

    my_role_metadata.deserialize(my_dict)
    assert my_role_metadata.dependencies == ['role1']

# Generated at 2022-06-21 01:20:05.964340
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata.allow_duplicates == False
    assert metadata.dependencies == []

# Generated at 2022-06-21 01:20:10.455556
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    dependencies = [
        dict(role='some.role', version='v1.2.3'),
        dict(role='other.role', version='v3.2.1')
    ]

    test_metadata = RoleMetadata(owner=None)
    test_metadata.deserialize(data={'allow_duplicates': True,
                                    'dependencies': dependencies})
    assert test_metadata.allow_duplicates
    assert test_metadata.dependencies == dependencies

# Generated at 2022-06-21 01:20:13.939513
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == None
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == None

# Generated at 2022-06-21 01:20:24.830575
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    current_dir = os.getcwd()

    # initalizing the class object
    r = RoleMetadata()

    # to call static method RoleMetadata.load()
    r.load(os.path.join(current_dir, '../../lib/ansible/playbook/base.py'), Templar(None, [], loader=DataLoader()))

    # to call method serialize
    print(r.serialize())

    # to call method deserialize
    r.deserialize({'allow_duplicates': True, 'dependencies': []})


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:20:30.280246
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert isinstance(role_metadata, RoleMetadata)
    dict = {}
    dict['dependencies']=[]
    dict['allow_duplicates']=False
    assert(role_metadata.serialize() == dict)
    dict['dependencies'] = [1,2,3]
    dict['allow_duplicates'] = True
    role_metadata.deserialize(dict)
    assert(role_metadata.serialize() == dict)

# Generated at 2022-06-21 01:20:41.112263
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class TestPlaybook:
        pass

    test_play = TestPlaybook()
    test_play.roles_path = ['test_roles_path']

    class TestRole:
        def __init__(self, role_path, play=None, task_include=None, vars=None):
            self._role_path = role_path
            self._play = play
            self._task_include = task_include
            self._role_collection = 'test_collection'
            self.vars = vars or dict()
            self.collections = ['custom_collection']

    class TestRoleInclude:
        def __init__(self, name, play=None, task_include=None, vars=None):
            self.name = name
            self._role_collection = 'test_collection'


# Generated at 2022-06-21 01:20:47.733189
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    role_obj = Role()
    role_obj._role_path = '/etc/ansible/roles/role1/'
    meta_obj = RoleMetadata(owner=role_obj)
    print('RoleMetadata object built')

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:20:58.871471
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext

    #The following are dummy data for testing constructors of RoleMetadata
    my_loader= None
    my_play = None
    my_variable_manager= None
    my_all_vars={}
    play_context = PlayContext()
    my_inventory =None
    my_host = None
    my_iterator = None
    my_new_stdin = None
    my_no_log = False
    my_new_stdout = None
    my_new_stderr = None
    my_new_run_once = None
    my_options = None
    my_new_job_vars = None
    my_new_task_vars = None
    my_new_extra_vars = None
    my_tmp_path = None
    my

# Generated at 2022-06-21 01:21:02.593500
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=True)
    r.dependencies = [1]
    role_data = r.serialize()
    assert role_data['dependencies'] == [1]
    assert role_data['allow_duplicates'] == False


# Generated at 2022-06-21 01:22:25.494552
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({
        'name': 'empty',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': []}, variable_manager=variable_manager, loader=loader)
    RoleMetadata.load({}, play=play)

# Generated at 2022-06-21 01:22:35.986200
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  # First test: dict contains "allow_duplicates" with True value
  test_role_metadata = RoleMetadata(owner="owner")

  test_dict = { "allow_duplicates": True, "dependencies": ["dependency1", "dependency2"] }

  test_role_metadata.deserialize(test_dict)

  if test_role_metadata._allow_duplicates is not True:
    return False

  # Second test: dict contains "allow_duplicates" with False value
  test_role_metadata = RoleMetadata(owner="owner")

  test_dict = { "allow_duplicates": False, "dependencies": ["dependency1", "dependency2"] }

  test_role_metadata.deserialize(test_dict)


# Generated at 2022-06-21 01:22:40.721310
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata._allow_duplicates = True
    metadata._dependencies = [{'role': 'rolename'}, 'role2']
    assert metadata.serialize()['allow_duplicates'] is True
    assert metadata.serialize()['dependencies'] == [{'role': 'rolename'}, 'role2']


# Generated at 2022-06-21 01:22:41.559789
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-21 01:22:43.669154
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    metadata.deserialize(data)

    assert metadata.serialize() == data

# Generated at 2022-06-21 01:22:55.838492
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.galaxy.collection import CollectionRequirement

    test_dir = os.path.dirname(os.path.abspath(__file__))
    role_dir = os.path.join(test_dir, '../../fixtures/roles/metadata_examples')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:23:03.178771
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Input data
    data = {'allow_duplicates': False, 'dependencies': []}
    # Expected results
    allow_dup = False
    deps = []
    # Object
    role_meta = RoleMetadata()
    # Test
    role_meta.deserialize(data)
    # Check results
    assert hasattr(role_meta, 'allow_duplicates')
    assert role_meta.allow_duplicates == allow_dup
    assert hasattr(role_meta, 'dependencies')
    assert role_meta.dependencies == deps

# Generated at 2022-06-21 01:23:04.242372
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    result = RoleMetadata.load(data={}, owner={})
    assert result is not None

# Generated at 2022-06-21 01:23:15.240799
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create a metadata object for which the deserialize method is going to be tested
    m = RoleMetadata(owner=None)

    # Test basic deserialize
    data = {
        "allow_duplicates": False,
        "dependencies": [
            {
                "name": "geerlingguy.ntp",
                "version": "2.2.1"
            }
        ]
    }
    m.deserialize(data)
    assert m.get_allow_duplicates() == False
    assert len(m.get_dependencies()) == 1
    assert m.get_dependencies()[0].get_name() == "geerlingguy.ntp"
    assert m.get_dependencies()[0].get_version() == "2.2.1"
    assert m.get_dependencies

# Generated at 2022-06-21 01:23:18.276628
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_owner = Base()
    role_owner._role_path = './roles/common'
    role = RoleMetadata(owner = role_owner)
    return role