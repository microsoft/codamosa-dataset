

# Generated at 2022-06-21 01:14:11.369127
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup
    from ansible.playbook.role.definition import RoleDefinition
    r = RoleDefinition()
    r._role_path = './path/to/role'

    r.metadata = RoleMetadata(owner=r)

    role_dependencies = [
        {'role': 'common-server'},
    ]
    role_dependencies_deserialized = [
        {'role': 'common-server',
         'name': 'common-server',
         'collections': [],
         'scm': None, 'version': None,
         '_role_path': 'common-server',
         '_role_collection': None,
         '_role': 'common-server',
         '_src_parent': './path/to/role'}
    ]

    # Test

# Generated at 2022-06-21 01:14:14.737537
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    m._allow_duplicates = False
    m._dependencies = []
    assert m.load(None, None) == None

# Generated at 2022-06-21 01:14:16.463848
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-21 01:14:19.693622
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": True})
    assert role_metadata.serialize() == {"allow_duplicates": True, "dependencies": []}

# Generated at 2022-06-21 01:14:29.140938
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.role.details import RoleDetails
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # initialize required objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader = loader, sources = '')
    play = Play()

# Generated at 2022-06-21 01:14:32.423198
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, Base)
    assert isinstance(m, CollectionSearch)

    assert m._dependencies == [], "_dependencies should be an empty list"



# Generated at 2022-06-21 01:14:40.241282
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    p = PlayContext()
    a = action_loader.get('debug', class_only=True)
    t = Templar(loader=None, variables=VariableManager())
    r = RoleMetadata(a)
    r.load({'dependencies': ['common']}, owner=a)
    r.load({'allow_duplicates': True}, owner=a)
    r.load({'allow_duplicates': '{{allow_duplicates}}'}, owner=a, variable_manager=VariableManager(), loader=None)
    r.serialize()
    r.deserialize({'allow_duplicates': True})

# Generated at 2022-06-21 01:14:43.839054
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Need to pass a 'owner' object to the constructor of RoleMetadata
    r = RoleMetadata()
    assert r._dependencies == list()
    assert r._argument_specs == dict()
    assert r._owner is None

# Generated at 2022-06-21 01:14:47.388633
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass
#     data = dict(
#         Name='nginx',
#         Dependencies=[ "common" ],
#         Version=1.0,
#         Description="Installs nginx"
#     )
#     print type(data)
#     print RoleMetadata(data)

# Generated at 2022-06-21 01:14:51.914380
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    m = RoleMetadata()
    expected_result = data
    result = m.serialize()
    assert result == expected_result


# Generated at 2022-06-21 01:15:03.777912
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(dependencies=list())
    returned_data = RoleMetadata.load(data, owner=None)
    assert returned_data is not None
    import json
    assert json.loads(json.dumps(returned_data.serialize(), indent=4)) == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-21 01:15:14.069172
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from units.mock.vars import MockVarsModule

    collection_path = u'/etc/ansible/roles'

# Generated at 2022-06-21 01:15:26.115999
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # test case 1: simple dependencies list
    role_metadata1 = RoleMetadata.load(
        {'dependencies': [{'role': 'common'}, {'role': 'webservers', 'some_param': 'foo'}]},
        owner=''
    )
    assert isinstance(role_metadata1, RoleMetadata), 'incorrect class'
    assert len(role_metadata1._dependencies) == 2, 'dependency list length error'

    # test case 2: variable dependencies list
    variable_manager = ''
    data = {'dependencies': ['role[common]', 'role[{{ web_role }}]']}
    role_metadata2 = RoleMetadata.load(data, owner='', variable_manager=variable_manager)
    assert isinstance(role_metadata2, RoleMetadata), 'incorrect class'

# Generated at 2022-06-21 01:15:36.086657
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import IncludeRole
    import ansible.constants as C
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    import sys

    C.HOST_KEY_CHECKING = False
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        ansible_connection='local',
        ansible_python_interpreter=sys.executable,
    )
    # FIXME: Define function load_list_of_roles which does not require a Play object.
    # Inject a dummy play object for testing.

# Generated at 2022-06-21 01:15:40.186012
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup test
    role_meta = RoleMetadata()
    role_meta.deserialize({"allow_duplicates": True, "dependencies": ["role1"]})
    # Assert if result
    assert role_meta._allow_duplicates == True
    assert role_meta._dependencies == ["role1"]


# Generated at 2022-06-21 01:15:45.087066
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = ['a', 'b', 'c']

    # default
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': ['a', 'b', 'c']}


# Generated at 2022-06-21 01:15:46.623180
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert isinstance(metadata, RoleMetadata)

# Generated at 2022-06-21 01:15:51.600019
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata.allow_duplicates = True
    roleMetadata.dependencies = []
    roleMetadata._load_dependencies(roleMetadata.dependencies, "test")
    assert roleMetadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': []
    }

# Generated at 2022-06-21 01:16:00.357557
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    role = RoleDefinition.load({'name': 'role1'})
    my_deps = [{'role': 'role2', 'x': 1}, {'name': 'role3'}]
    my_meta = {'dependencies': my_deps}
    meta = RoleMetadata.load(my_meta, role)
    deps = meta.dependencies
    assert len(deps) == 2
    # Check first item
    dep_item = deps[0]
    assert isinstance(dep_item, RoleRequirement)
    assert dep_item.get_info() == {'role': 'role2', 'x': 1}
    # Check second item
    dep_item = de

# Generated at 2022-06-21 01:16:07.978814
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    p = Play()
    m = RoleMetadata(owner=p)
    assert(isinstance(m, RoleMetadata))
    assert(m._allow_duplicates == False)
    assert(m._dependencies == [])
    assert(m._galaxy_info == None)
    assert(m._argument_specs == {})


# Generated at 2022-06-21 01:16:28.992728
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # pylint: disable=redefined-outer-name
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.basedefs import LOAD_CALLBACK_PLUGINS
    VERSION = '1.0'
    playbook = Playbook.load(dict(version=VERSION), loader=None, variable_manager=None, options=LOAD_CALLBACK_PLUGINS)
    play = Play.load(dict(name='test'), playbook=playbook, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:16:39.355664
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import json
    import unittest
    import sys

    if not sys.version_info >= (2, 7):
        # coverage not supported by Python 2.6
        unittest.skip('Python 2.6 not supported by tests')

    class TestRoleMetadata(unittest.TestCase):
        def test_load(self):
            collection_path = '../../../lib/ansible/collections/ansible_collections/nsweb/role_test/'
            data = None
            with open(collection_path + 'meta/main.yml') as meta_file:
                data = meta_file.read()
            data = json.loads(data)
            role_metadata = RoleMetadata.load(data, None)
            #print(role_metadata.__dict__)
            # print(role_metadata._dependencies

# Generated at 2022-06-21 01:16:44.737746
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class MockMetadata(RoleMetadata):
        pass

    metadata = MockMetadata()
    metadata.dependencies = [{'role': 'common'}]
    metadata.allow_duplicates = True

    assert metadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': [{'role': 'common'}]
    }

    metadata2 = MockMetadata()
    metadata2.dependencies = []
    metadata2.allow_duplicates = False

    assert metadata2.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-21 01:16:49.097698
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_dir = '/usr/share/ansible/roles/test'
    role_name = 'test'
    owner = RoleInclude(role_name, play=None, role_path=role_dir)
    m = RoleMetadata(owner=owner)

# Generated at 2022-06-21 01:16:53.173651
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [1, 2, 3]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}

# Generated at 2022-06-21 01:16:54.824403
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta._allow_duplicates == False
    assert meta._dependencies == []

# Generated at 2022-06-21 01:17:01.328418
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    This test is used to check that the load() method of class RoleMetadata
    will raise AnsibleParserError exception if the first argument is not
    an instance of dict
    '''
    owner = MockRole()
    data = None
    variable_manager = None
    loader = None
    # load() will raise exception if the first argument is not a dict
    with pytest.raises(AnsibleParserError):
        RoleMetadata.load(data, owner, variable_manager, loader)
    data = {}
    role_metadata = RoleMetadata.load(data, owner, variable_manager, loader)
    assert isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-21 01:17:12.960127
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from collections import namedtuple

    data = {
        'dependencies': [
            {'name': 'role1'},
            'role2'
        ]
    }
    host_vars = {}
    group_vars = {}
    loader = None
    variable_manager = namedtuple('MockAnsibleVarsManager', ['get_vars', 'get_group_vars'])
    variable_manager.get_vars = lambda x: host_vars
    variable_manager.get_group_vars = lambda x, y: group_vars
    play = namedtuple('MockPlay', ['collections'])
    play.collections = ['ansible']

    role = named

# Generated at 2022-06-21 01:17:17.133765
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """ RoleMetadata - deserialize method unit test"""

    m = RoleMetadata(owner="")
    data = dict(allow_duplicates=True, dependencies=[])
    m.deserialize(data)

    # Check
    assert m._allow_duplicates == data.get('allow_duplicates', False)
    assert m._dependencies == data.get('dependencies', [])


# Generated at 2022-06-21 01:17:17.929594
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-21 01:17:47.206604
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                "role": "ralph.local"
            }
        ]
    }
    m = RoleMetadata().load_data(data)
    assert m.serialize() == data

# Generated at 2022-06-21 01:17:56.066207
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # make sure we can serialize the RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.dependencies = ['role1', 'role2', 'role3']
    role_metadata.allow_duplicates = True
    actual = role_metadata.serialize()

# Generated at 2022-06-21 01:17:57.554924
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ''' Unit test for RoleMetadata class load method '''
    pass # TODO

# Generated at 2022-06-21 01:18:09.292887
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test when owner is None
    role_metadata = RoleMetadata()
    assert role_metadata._owner == None
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    # Test when owner is not None
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    role_metadata1 = RoleMetadata(owner=role_definition)
    assert role_metadata1._owner == role_definition
    assert role_metadata1.allow_duplicates == False
    assert role_metadata1.dependencies == []

    # Test for load(), serialize() and deserialize()
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.role.requirement import RoleRequirement
    # Test when

# Generated at 2022-06-21 01:18:12.485445
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    _RoleMetadata = RoleMetadata()
    assert _RoleMetadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=[
            'dependency1',
            'dependency2',
        ]
    )) == None

# Generated at 2022-06-21 01:18:16.482158
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    string = rmd.serialize()
    assert type(string) == dict
    assert string['allow_duplicates'] == False
    assert string['dependencies'] == []

# Generated at 2022-06-21 01:18:28.315079
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import os
    import sys

    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'unittests'))
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class TestAnsibleModule(object):
        def __init__(self, variable_manager=None, loader=None):
            self.variable_manager = variable_manager
            self.loader = loader

    class TestVariableManager(object):
        def __init__(self, module=None, loader=None):
            self.module = module
            self.loader = loader

    class TestLoader(object):
        def __init__(self):
            self.module_loader = self


# Generated at 2022-06-21 01:18:31.484070
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = False
    m.dependencies = []
    result = m.serialize()
    expected = dict(allow_duplicates=False, dependencies=[])
    assert result == expected

# Generated at 2022-06-21 01:18:35.682258
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # for ds with allow_duplicates as true and dependencies as empty
    ds = {'allow_duplicates': True, 'dependencies': []}
    m = RoleMetadata()
    m.deserialize(ds)
    assert m._allow_duplicates is True
    assert isinstance(m._dependencies, list)
    assert len(m._dependencies) == 0
    assert m._galaxy_info is None
    assert isinstance(m._argument_specs, dict)

# Generated at 2022-06-21 01:18:43.776163
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    role_definition = RoleDefinition()
    role_requirement = RoleRequirement()
    role_metadata = RoleMetadata()
    dict1 = dict()
    dict1['allow_duplicates'] = False
    dict1['dependencies'] = []
    assert role_metadata.serialize() == dict1



# Generated at 2022-06-21 01:18:59.875771
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    md = RoleMetadata()
    md.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert md.allow_duplicates == True
    assert md.dependencies == ['role1', 'role2']

# Generated at 2022-06-21 01:19:05.085032
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    md = RoleMetadata()

    md.allow_duplicates = True
    md.dependencies = ['role_a', 'role_b']

    assert md.serialize().get('allow_duplicates') == True
    assert md.serialize().get('dependencies') == ['role_a', 'role_b']

    return True


# Generated at 2022-06-21 01:19:09.140038
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = False
    r.dependencies = []
    d = r.serialize()
    assert d['allow_duplicates'] == False
    assert d['dependencies'] == []


# Generated at 2022-06-21 01:19:11.842081
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    d = dict(a=10, b=20)
    role = RoleMetadata(d)
    assert(role._data == d)

# Generated at 2022-06-21 01:19:20.917425
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[{'role': 'foo', 'version': '1.0'}, {'role': 'foo', 'version': '2.0'}, {'role': 'foo', 'version': '3.0'}])
    metadata.deserialize(data)

    assert metadata.allow_duplicates
    assert isinstance(metadata.dependencies[0], RoleRequirement)

# Generated at 2022-06-21 01:19:26.860964
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {'allow_duplicates': 'True'}
    metadata.deserialize(data)
    assert hasattr(metadata, 'allow_duplicates')
    assert metadata.allow_duplicates == True
    data = {'dependencies': ['role_a','role_b']}
    metadata.deserialize(data)
    assert hasattr(metadata, 'dependencies')
    assert metadata.dependencies == ['role_a','role_b']

# Generated at 2022-06-21 01:19:32.506671
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Init
    role_metadata = RoleMetadata(owner=None)
    role_metadata._allow_duplicates
    role_metadata._dependencies

    # Execute
    result = role_metadata.serialize()

    # Assert
    assert result == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:19:40.421478
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.collections import AnsibleCollectionLoader
    from ansible.playbook.role.definition import RoleDefinition
    collection_loader = AnsibleCollectionLoader()
    role_def = RoleDefinition()
    role_def.name = 'myrole'
    role_def.collections = ['my.collection']
    metadata = {'dependencies': ['../../relative/path/to/role']}
    real_metadata = RoleMetadata(owner=role_def).load(data=metadata, loader=collection_loader)
    assert real_metadata.dependencies[0].name == 'myrole'

# Generated at 2022-06-21 01:19:49.170542
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    fake_data = {'dependencies': ['geerlingguy.java', 'apache']}
    fake_owner = 'fake_owner'
    fake_var_manager = 'var_manager'
    fake_loader = 'loader'

    m = RoleMetadata.load(fake_data, fake_owner, variable_manager=fake_var_manager, loader=fake_loader)

    assert m._dependencies == fake_data['dependencies']
    assert m._owner == fake_owner
    assert m._variable_manager == fake_var_manager
    assert m._loader == fake_loader


# Generated at 2022-06-21 01:19:59.747666
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    import os

    if (os.path.isfile("./test_playbook_role_meta_main.yaml") is False):
        raise Exception("can not find test_playbook_role_meta_main.yaml")

    playbook = Playbook.load(filename="./test_playbook_role_meta_main.yaml", variable_manager={}, loader = None)

    assert isinstance(playbook, Playbook)

    assert isinstance(playbook._entries[0], Play)

    role_path = playbook._entries[0]._entries[0]._

# Generated at 2022-06-21 01:20:27.447244
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:20:30.436857
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata().deserialize(data) == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:20:33.332027
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # test direct calls
    RoleMetadata._load_dependencies()
    RoleMetadata._load_galaxy_info()
    pass



# Generated at 2022-06-21 01:20:42.313997
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_galaxy_info = {
        'author': 'Test',
        'description': 'Test',
        'company': 'Test',
        'license': 'Test',
        'min_ansible_version': '2.0',
        'platforms': [{'name': 'Test'}],
        'galaxy_tags': [],
        'github_branch': 'Test',
    }
    test_dependencies = [{
        'role': 'Test',
        'collections': ['test_collection'],
        'name': 'Test',
        'src': 'Test',
    }]
    test_metadata = RoleMetadata()
    test_metadata._galaxy_info = test_galaxy_info
    test_metadata._dependencies = test_dependencies

# Generated at 2022-06-21 01:20:42.932005
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert True

# Generated at 2022-06-21 01:20:55.243398
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # test valid yaml
    yaml_str = '---\ndependencies:\n  - { role: test, name: test }\n'
    t = dict(
        a=RoleMetadata(owner=None).load(ds=yaml_str, owner=None, variable_manager=None, loader=None),
        b=RoleMetadata(owner=None).load(ds=yaml_str, owner=None, variable_manager=None, loader=None))
    assert t['b'].dependencies[0].role == 'test'
    assert t['b'].dependencies[0].name == 'test'

    # test invalid yaml, ie role name is missing
    yaml_str = '---\ndependencies:\n  - { src: test, name: test }\n'

# Generated at 2022-06-21 01:20:58.006719
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        dependencies = dict(
            role = dict()
        )
    )

    m = RoleMetadata.load(data)

# Generated at 2022-06-21 01:21:06.898049
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test without any data
    test_data = {}

    # Test without owner
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleMetadata.load(test_data, owner=None)
    assert 'is not a dictionary' in str(excinfo.value)

    # Test with None as data
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleMetadata.load(None, owner='my_owner')
    assert 'not a dictionary' in str(excinfo.value)

    # Test with role owner
    role_metadata = RoleMetadata.load(test_data, owner='my_owner')
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == None
   

# Generated at 2022-06-21 01:21:12.468628
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test that deserialize() works correctly with a sample data
    data = dict(
        allow_duplicates=True,
        dependencies=dict(
            role='foo',
            name='bar')
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-21 01:21:21.939523
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='example.role1', name='test1', tasks_from='main'),
            dict(role='example.role2', name='test2')
        ]
    )

    role_metadata = RoleMetadata(owner=dict(name='test_role'))
    role_metadata._load_data(data)

    serialized_data = role_metadata.serialize()

    assert serialized_data['allow_duplicates'] == data['allow_duplicates']
    assert serialized_data['dependencies'] == data['dependencies']

# Generated at 2022-06-21 01:23:00.501724
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {}
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []


# Generated at 2022-06-21 01:23:03.137710
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-21 01:23:05.428944
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False,
                dependencies=None)
    rm = RoleMetadata()
    rm.deserialize(data)
    assert rm.allow_duplicates == False
    assert rm._dependencies == None

# Generated at 2022-06-21 01:23:12.700832
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class PlaceholderRole:
        def __init__(self, name):
            self._name = name
        def get_name(self):
            return self._name

    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata = RoleMetadata(PlaceholderRole('role1')).deserialize(data)
    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-21 01:23:16.275943
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {"allow_duplicates": False, "dependencies": []}
    role = RoleMetadata()
    role.deserialize(data)
    assert role._allow_duplicates == False
    assert role._dependencies == []


# Generated at 2022-06-21 01:23:17.592968
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass


# Generated at 2022-06-21 01:23:21.083963
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    b = a.serialize()
    assert isinstance(b, dict)
    assert isinstance(b.get('allow_duplicates'), bool)
    assert isinstance(b.get('dependencies'), list)

# Generated at 2022-06-21 01:23:25.714832
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import sys
    if sys.version_info[0] == 2:
        Python3 = False
    else:
        Python3 = True

    md = RoleMetadata()
    md.deserialize({'dependencies': [{'role': 'test'}]})

    if Python3:
        assert(md.allow_duplicates == False)
    else:
        assert(md.allow_duplicates == 0)
    assert(md.dependencies)

# Generated at 2022-06-21 01:23:30.527074
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    r._load_dependencies('dependencies', {})  # should not raise an exception
    r._load_dependencies('dependencies', 'foo')  # should raise an exception
    r._load_galaxy_info('galaxy_info', {})  # should not raise an exception

# Generated at 2022-06-21 01:23:40.770192
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition()
    rd._role_path = '/opt/playbooks/roles/myrole'
    rd._role_name = 'myrole'
    role_metadata_file = '/opt/playbooks/roles/myrole/meta/main.yml'