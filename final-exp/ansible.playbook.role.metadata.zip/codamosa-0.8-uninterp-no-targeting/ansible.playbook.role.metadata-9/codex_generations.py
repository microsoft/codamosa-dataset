

# Generated at 2022-06-21 01:14:20.278078
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    role_metadata = RoleMetadata()
    role_data = dict()
    role_data['dependencies'] = [{'role': 'test_role'}]
    role_data['allow_duplicates'] = False
    role_metadata.deserialize(role_data)

    assert role_metadata.dependencies == [RoleInclude()]
    assert role_metadata.allow_duplicates == False

# Generated at 2022-06-21 01:14:24.097785
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner='owner')
    r._allow_duplicates = True
    r._dependencies = 'dependencies'

    assert r.serialize() == {'allow_duplicates': True, 'dependencies': 'dependencies'}



# Generated at 2022-06-21 01:14:28.791012
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # init
    rm = RoleMetadata()
    # this is what we expect to get back
    exp_result = {
        'allow_duplicates': False,
        'dependencies': []
    }
    # set values
    rm.allow_duplicates = False
    rm.dependencies = []
    # test serialize
    result = rm.serialize()
    assert result == exp_result


# Generated at 2022-06-21 01:14:32.928481
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(owner='owner')
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == None
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner == 'owner'
    assert str(role_metadata)

# Generated at 2022-06-21 01:14:34.717569
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Test to check the constructor of `RoleMetadata` class
    '''
    assert RoleMetadata()

# Generated at 2022-06-21 01:14:47.247799
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from collections import namedtuple

    # Set up mock data
    class Options(object):
        def __init__(self, connection='local', forks=10, become=None, become_method='sudo', become_user='root', check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=None):
            self.connection = connection
            self.forks = forks
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check = check
            self.diff = diff
            self.listhosts = listhosts
            self.listtasks = listtasks
            self.list

# Generated at 2022-06-21 01:14:55.912987
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata
    """

    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['dependency1', 'dependency2']
    serialized_data = role_metadata.serialize()
    assert isinstance(serialized_data, dict)
    assert serialized_data['allow_duplicates'] is True
    assert serialized_data['dependencies'] == ['dependency1', 'dependency2']

# Generated at 2022-06-21 01:15:03.862743
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({'dependencies': [], 'allow_duplicates': False})
    assert roleMetadata.get_allow_duplicates() == False
    assert roleMetadata.get_dependencies() == []

    roleMetadata1 = RoleMetadata()
    roleMetadata1.deserialize({'allow_duplicates': True})
    assert roleMetadata1.get_allow_duplicates() == True
    assert roleMetadata1.get_dependencies() == []


# Generated at 2022-06-21 01:15:04.808961
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role != None

# Generated at 2022-06-21 01:15:14.868427
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    yaml_data = """
    galaxy_info:
      author: Joe Harm
      description: The best role created by Joe and Jane ever
      company: Joe & Jane
      license: MIT
      min_ansible_version: 2.8
    dependencies:
    - role: apache
      name: example.com
      some_variable: foo
    - role: postgresql
      some_other_variable: bar
    allow_duplicates: yes
    """
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition.load('roles/myrole', yaml_data)
    rm = rd._metadata
    data = rm.serialize()
    assert isinstance(data, dict)
    assert data['allow_duplicates'] is True

# Generated at 2022-06-21 01:15:27.527967
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta_data = RoleMetadata(owner=None)
    data = dict(
        allow_duplicates=False,
        dependencies=[1]
    )
    role_meta_data.deserialize(data)
    assert role_meta_data.serialize() == data


# Generated at 2022-06-21 01:15:29.744554
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r._dependencies == list()
    assert r.allow_duplicates is False

# Generated at 2022-06-21 01:15:36.168401
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_metadata = RoleMetadata()
    test_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': ['my_roles']
    })
    assert test_metadata._allow_duplicates == True
    assert test_metadata._dependencies == ['my_roles']

    test_metadata.deserialize({
        'dependencies': ['my_roles']
    })
    assert test_metadata._allow_duplicates == False
    assert test_metadata._dependencies == ['my_roles']

# Generated at 2022-06-21 01:15:46.721323
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.hosts import Host
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    inventory = Host(name="localhost")
    play = Play().load({}, variable_manager=variable_manager, loader=None)
    play._hosts = [inventory]
    play._basedir = u'.'

    yaml_data = '''---
        allow_duplicates: False
        dependencies:
          - {role: geerlingguy.java, version: "1.0.0"}
          - {role: geerlingguy.lamp, version: "1.0.0"}'''

    data = play.load

# Generated at 2022-06-21 01:15:50.971497
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({
        'allow_duplicates': True,
        'dependencies': ['common', 'database']
    })
    assert r._allow_duplicates == True
    assert r._dependencies == ['common', 'database']

# Generated at 2022-06-21 01:15:57.062896
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Task
    owner = Task()
    owner._role_name = "test"
    owner._role_path = "/path/to/role"
    owner._role_collections = ["test.default"]
    owner._hosts = ["host1"]

    role_result = RoleMetadata(owner=owner)

    assert role_result.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:16:02.632681
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    md = RoleMetadata(owner=Play().load({'hosts': 'all', 'name': 'test-play'}, variable_manager=None, loader=None))
    print(md.serialize())

# Generated at 2022-06-21 01:16:10.982605
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role

    role_def = RoleDefinition.load(dict(
        name='test_role_1'
    ), play=None)

    role = Role.load(role_def, None, None, None)

    role_meta = RoleMetadata.load(
        dict(
            dependencies=['test_role_2']
        ),
        owner=role,
        variable_manager=None,
        loader=None
    )

    assert len(role_meta.dependencies) == 1
    assert isinstance(role_meta.dependencies[0], RoleDefinition)

# Generated at 2022-06-21 01:16:21.479017
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.collection import RoleCollection
    from ansible.config.manager import ConfigManager

    # Sample Role
    role_path_test = os.path.join(os.path.dirname(__file__), 'test_data/test_meta/role_meta_test')
    role_path_test_another_roledir = os.path.join(os.path.dirname(__file__), 'test_data/test_meta/role_meta_test_another_roledir')
    role = Role.load(role_path_test)


# Generated at 2022-06-21 01:16:25.818762
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    r = RoleMetadata()
    data = dict(allow_duplicates=True,
                dependencies=[{'role': 'common', 'version': '1.0'}])
    r.deserialize(data)
    assert True == r.allow_duplicates
    assert [{'role': 'common', 'version': '1.0'}] == r.dependencies

# Generated at 2022-06-21 01:16:41.350665
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m._allow_duplicates is False
    assert m.dependencies == []

# Generated at 2022-06-21 01:16:47.873988
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = [{'name': 'galaxy.role_a', 'src': 'galaxy.role_a'}]
    assert role.serialize() == {'allow_duplicates': True, 'dependencies': [{'name': 'galaxy.role_a', 'src': 'galaxy.role_a'}]}

# Generated at 2022-06-21 01:16:57.524565
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class ansible_play_t:
        def __init__(self):
            self.variable_manager = dict()
            self.loader = dict()

    class ansible_role_t:
        def __init__(self):
            self._play = ansible_play_t()
            self._role_path = 'role_path'
            self._role_collection = 'collection'
            self.collections = dict()

        def get_name(self):
            return 'ansible.test'

    obj = RoleMetadata(owner=ansible_role_t())
    ds = dict()
    obj.load_data(ds, variable_manager=None, loader=None)
    data = obj.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == []

    ds

# Generated at 2022-06-21 01:17:07.381241
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext

    play = {"hosts": "all", "name": "PlayName"}
    context = PlayContext(play=play)
    m = RoleMetadata(context)

    # Test constructor of class RoleMetadata
    assert isinstance(m, RoleMetadata)

    # Test deserialize of class RoleMetadata
    data = {"allow_duplicates": "allow"}
    m.deserialize(data)
    assert m.allow_duplicates == "allow"
    assert isinstance(m.dependencies, list)

    # Test serialize of class RoleMetadata
    assert m.serialize() == {"allow_duplicates": "allow", "dependencies": []}

# Generated at 2022-06-21 01:17:12.030030
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = dict(
        allow_duplicates=True,
        dependencies=["geerlingguy.apache"]
    )
    role = RoleMetadata.load(data)
    assert role.allow_duplicates == True
    assert role.dependencies == ["geerlingguy.apache"]

# Generated at 2022-06-21 01:17:14.895005
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    data = {"allow_duplicates": True}
    assert rmd.deserialize(data) is None
    assert rmd.allow_duplicates

test_RoleMetadata_deserialize()

# Generated at 2022-06-21 01:17:19.279924
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Just need to test that a deserialize doesn't fail here.
    # The RoleMetadata class has no methods to test.
    print("Testing that deserialize works for RoleMetadata")
    r = RoleMetadata(owner='role1')
    data = dict()
    res = r.deserialize(data)
    assert res is None
    assert r.allow_duplicates == False
    assert r.dependencies == []
    assert r.allow_duplicates is False
    assert r.dependencies == []

# Generated at 2022-06-21 01:17:25.432654
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rolemeta = RoleMetadata()
    rolemeta.deserialize({})
    assert rolemeta.allow_duplicates == False
    assert rolemeta.dependencies == []

    rolemeta.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert rolemeta.allow_duplicates == True
    assert rolemeta.dependencies == ['role1', 'role2']

# Generated at 2022-06-21 01:17:32.153471
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    owner = RoleDefinition()
    owner.update(dict(
        name=dict(
            name="test-role",
        )
    ))
    m = RoleMetadata(owner=owner)
    m.update(dict(
        dependencies=dict(
            role="test-role"
        )
    ))
    assert m.dependencies[0]['role'] == 'test-role'

# Generated at 2022-06-21 01:17:39.352026
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    test_allow_duplicates=True
    test_dependencies=[RoleDefinition()]
    meta=RoleMetadata()
    meta.allow_duplicates=test_allow_duplicates
    meta.dependencies=test_dependencies
    ans = dict(
        allow_duplicates=test_allow_duplicates,
        dependencies=test_dependencies
    )
    assert meta.serialize() == ans


# Generated at 2022-06-21 01:18:03.489654
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO
    pass

# Generated at 2022-06-21 01:18:13.082855
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    module_utils_path = os.path.join(os.path.dirname(__file__), '..', 'module_utils')
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'integration', 'targets', 'test_collections', 'namespace1', 'test_role')
    variable_manager = None
    loader = None

    try:
        m = RoleMetadata.load(None, None)
    except Exception as e:
        pass
    else:
        raise Exception('Failed to check for invalid load data')

    try:
        m = RoleMetadata.load('test', None)
    except Exception as e:
        pass
    else:
        raise Exception('Failed to check for invalid load data')

    m

# Generated at 2022-06-21 01:18:15.569757
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = None
    m = RoleMetadata(owner)
    m.deserialize(m.serialize())

# Generated at 2022-06-21 01:18:27.261367
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner, variable_manager, loader, data = init_owner()
    m = RoleMetadata.load(data, owner, variable_manager, loader)
    # test with None
    assert m.serialize() == dict(
            allow_duplicates=False,
            dependencies=[],
        )
    # test with dict
    m._allow_duplicates = True
    m._dependencies = [dict(role='role1', src='path1', version='>= 1.0.0, < 2.0.0'), dict(role='role2', src='path1', version='>= 1.0.0, < 2.0.0')]

# Generated at 2022-06-21 01:18:35.397811
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.loader import role_loader

    role_name = 'test_role'
    role_path = role_loader._find_role_path(role_name)

    # Load test role to get owner object
    role = Role.load(role_name, role_path, variable_manager=None, loader=None)
    rmeta = RoleMetadata()
    rmeta.deserialize(dict(allow_duplicates=role.allow_duplicates, dependencies=role.dependencies))

    assert isinstance(rmeta.allow_duplicates, bool)
    assert isinstance(rmeta.dependencies, list)

# Generated at 2022-06-21 01:18:42.524567
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    metadata = RoleMetadata(owner=None)

    ds_str = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    result = metadata._load_dependencies(attr='dependencies', ds=ds_str['dependencies'])

    assert result == ds_str['dependencies']

# Generated at 2022-06-21 01:18:46.246252
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    name = 'webservers'
    owner = 'ansible.builtin'
    meta = RoleMetadata(owner)
    assert(meta.collections[0] == owner)
    assert(isinstance(meta, RoleMetadata))

# Generated at 2022-06-21 01:18:57.100710
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    play = Play().load({
        'name': 'testplay',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [{'action': {'module': 'setup'}}],
        'roles': [
            {'role': 'dummy1'},
            {'role': 'dummy2'},
            {'role': 'dummy3'}
        ]
    }, variable_manager=None, loader=None)

    play.post_validate(PlayContext())


# Generated at 2022-06-21 01:19:08.350641
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    metadata_data = {
        'dependencies': [
            'role1',
            {'role': 'role2', 'some_var': 'foo'},
            'role3',
            'role4',
            {'role': 'role5', 'some_var': 'bar'},
            {'name': 'role6', 'src': 'https://github.com/user/repo', 'scm': 'git'},
        ]
    }
    r = RoleMetadata()
    r.load_data(metadata_data)

# Generated at 2022-06-21 01:19:15.230666
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_list = [{'role': 'Apache'}, {'role': 'MySQL'}]
    role_metadata = RoleMetadata.load(role_list, owner=None)
    meta_data_expected = {"dependencies": [{'role': 'Apache'}, {'role': 'MySQL'}], "allow_duplicates": False}
    meta_data_result = role_metadata.serialize()
    assert meta_data_expected == meta_data_result

# Generated at 2022-06-21 01:19:33.707458
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    de_data = {'allow_duplicates': False, 'dependencies': []}
    assert rmd.deserialize(de_data) == None
    assert rmd.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:19:41.358215
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'some key': 'some data'}

    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    role = Role()
    role._role_path = 'some path'
    role_definition = RoleDefinition()
    role_definition._role_path = 'some path'
    role_definition._role_name = 'test role'
    role.role_definition = role_definition

    loader = DataLoader()
    variable_manager = VariableManager()

    role_metadata = RoleMetadata.load(data, role, variable_manager=variable_manager, loader=loader)
    assert role_metadata._ds == data

# Generated at 2022-06-21 01:19:46.392501
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': ['foo/bar', 'bar/baz']})
    assert m.allow_duplicates == True
    assert m.dependencies == ['foo/bar', 'bar/baz']

# Generated at 2022-06-21 01:19:57.279155
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('tests/hosts'))

    role_metadata = RoleMetadata()
    role_metadata_ds = {'dependencies': ['role1'], 'allow_duplicates': False}

    play_context = PlayContext()
    play_context._var_manager = variable_manager

# Generated at 2022-06-21 01:20:05.805756
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': [{'src': '../..', 'version': '1.0'}, './foo']})
    assert role_metadata.allow_duplicates is True
    assert len(role_metadata.dependencies) == 2
    assert role_metadata.dependencies[0].name == '../..'
    assert role_metadata.dependencies[0].version == '1.0'
    assert role_metadata.dependencies[1].name == './foo'
    assert role_metadata.dependencies[1].version is None

# Generated at 2022-06-21 01:20:12.993687
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(name='foo', src='bar', scm='git', version='v1.0'),
            dict(name='baz', src='qux', scm='git', version='v1.0')
        ]
    )

    r = RoleMetadata().deserialize(data)

    assert isinstance(r, RoleMetadata)
    assert isinstance(r.allow_duplicates, bool)
    assert isinstance(r.dependencies, list)
    assert isinstance(r.dependencies[0], RoleRequirement)
    assert isinstance(r.dependencies[0]._dep_context, PlayContext)

# Generated at 2022-06-21 01:20:17.820085
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create test object
    obj = RoleMetadata()
    # Verify all default attributes are correct
    assert obj._allow_duplicates == False
    assert obj._dependencies == []
    assert obj._galaxy_info == None
    assert obj._argument_specs == {}

# Generated at 2022-06-21 01:20:23.376198
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r._role_name = "rpdehaan.test"
    # Can create object
    m = RoleMetadata(owner=r)
    assert isinstance(m, RoleMetadata)
    assert isinstance(m._owner, Role)
    assert m._owner._role_name == "rpdehaan.test"

# Generated at 2022-06-21 01:20:30.790138
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    serialize = role_metadata.serialize()
    assert serialize == dict(allow_duplicates=False, dependencies=[])

    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [
        {'role': 'Apache'},
        {'role': 'tomcat'},
        {'role': 'Nginx'},
        {'role': 'awstats'},
    ]
    serialize = role_metadata.serialize()
    assert serialize == dict(allow_duplicates=True, dependencies=[
        {'role': 'Apache'},
        {'role': 'tomcat'},
        {'role': 'Nginx'},
        {'role': 'awstats'},
    ])



# Generated at 2022-06-21 01:20:40.178464
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata.deserialize({}) == { 'allow_duplicates': False, 'dependencies': [] }
    assert RoleMetadata.deserialize({'allow_duplicates': True}) == { 'allow_duplicates': True, 'dependencies': [] }
    assert RoleMetadata.deserialize({'dependencies': [1,2]}) == { 'allow_duplicates': False, 'dependencies': [1,2] }
    assert RoleMetadata.deserialize({'allow_duplicates': True, 'dependencies': [1,2]}) == { 'allow_duplicates': True, 'dependencies': [1,2] }

# Generated at 2022-06-21 01:21:08.359755
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition

    ad = ansible.playbook.role.definition.RoleDefinition()
    ad._role_name = 'nginx'

    data = {
        "allow_duplicates": True,
        "dependencies": [
            { "role": "common", "version": "1.0" },
            { "role": "webservers", "tags": [ "bar", "foo" ] }
        ],
        "galaxy_info": {}
    }

    role_metadata = RoleMetadata.load(data, ad)
    assert role_metadata._allow_duplicates == True
    assert len(role_metadata._dependencies) == 2
    assert role_metadata._dependencies[0].get_name() == 'common'
    assert role_metadata._dependencies[1].get_name

# Generated at 2022-06-21 01:21:20.019758
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook

    class Role:
        def __init__(self):
            self.name = "noname"

    class Play:
        def __init__(self):
            self.hosts = ["localhost"]
            self.vars = None
            self.name = "noname"
            self.role_vars = {}

    test_RoleMetadata = RoleMetadata(Role())
    setattr(test_RoleMetadata, 'allow_duplicates', True)
    setattr(test_RoleMetadata, 'dependencies', ["my_dependency"])
    data = test_RoleMetadata.serialize()

# Generated at 2022-06-21 01:21:23.565675
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    rmd.deserialize({'allow_duplicates': True, 'dependencies': ['foobar']})
    assert rmd._allow_duplicates == True
    assert rmd._dependencies == ['foobar']

# Generated at 2022-06-21 01:21:27.668600
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    mydata = dict(
        dependencies=['common', 'webservers'],
        description="my role description",
        allow_duplicates=False,
        galaxy_info={"author": "me", "license": "unknown"})

    myowner = None

    rv = RoleMetadata.load(data=mydata, owner=myowner)
    assert rv['dependencies'][1] == 'webservers'

# Generated at 2022-06-21 01:21:39.688618
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.collection.tests.fixtures.fake_collections import AnsibleFakeCollection
    from ansible.plugins.collection.tests.fixtures.fake_collections import (
        AnsibleFakeCollectionDep,
        AnsibleFakeCollectionDep2
    )

    # First test

    role_path = '/tmp/foo/roles/role1'
    main_file = os.path.join(role_path, 'meta', 'main.yml')


# Generated at 2022-06-21 01:21:44.315540
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# tests for class RoleMetadata
import pytest
from ansible.utils.unsafe_proxy import AnsibleUnsafeText
from ansible.vars.manager import VariableManager

# test_validate_invalid_galaxy_info

# Generated at 2022-06-21 01:21:54.302898
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = mock_class()
    owner.get_name.return_value = "Role One"
    owner._role_path = "path/to/role"
    owner._name = "Role One"
    owner._collections = []
    owner._play = "path/to/play"
    owner._role_collection = None
    data = {
        "galaxy_info": None,
        "dependencies": ["role2", { "role": "role3", "vars": {"var1": "x", "var2": "{{y}}"} }],
        "allow_duplicates": True
    }
    variable_manager = mock_class()
    loader = mock_class()
    result = RoleMetadata.load(data, owner, variable_manager, loader)
    assert result.allow_duplicates is True

# Generated at 2022-06-21 01:22:04.023189
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.galaxy.collection import CollectionRequirement
    from ansible.galaxy.role import GalaxyRole

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-21 01:22:06.050701
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()


# require a main function to not break with python 2.4

# Generated at 2022-06-21 01:22:15.920761
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    role_def = {
        'name': 'foobar',
        'path': '/foo/bar/roles/foobar',
    }
    test_RoleMetadata = RoleMetadata(RoleDefinition.load(data=role_def))
    assert isinstance(test_RoleMetadata._dependencies, list)

    # Test _load_dependencies
    def test_ds_1():
        test_ds_1 = {
            'name': 'foobar',
            'src': 'http://foo.com/foobar.tgz',
        }


# Generated at 2022-06-21 01:23:01.339555
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = [{'role': 'common', 'other_vars': 'here'}]

    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[{'role': 'common', 'other_vars': 'here'}]
    )

# Generated at 2022-06-21 01:23:07.337709
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class MockRole(object):
        def __init__(self):
            self.name = "role_name"

    TEST_FILE = "test/unit/data/test_RoleMetadata_load.yml"
    data = {'dependencies': [{'name': 'test_role'}]}
    m = RoleMetadata.load(data, MockRole())

    assert m.serialize() == data
    assert m._owner.name == "role_name"



# Generated at 2022-06-21 01:23:18.781892
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    module = AnsibleModule(argument_spec={})

    ds = dict(
        allow_duplicates=True,
        dependencies=[{'role': 'foo'}, 'bar'],
        galaxy_info=dict(
            author='John Doe',
            description='foo bar',
        )
    )

    m = RoleMetadata(owner=None).load_data(ds)
    assert m._allow_duplicates is True
    assert m._galaxy_info == dict(
        author='John Doe',
        description='foo bar',
    )
    assert m._dependencies == [{'role': 'foo'}, 'bar']
    assert len(m._dependencies) == 2
    assert isinstance(m._dependencies[0], RoleRequirement)
    assert isinstance(m._dependencies[1], RoleRequirement)


# Generated at 2022-06-21 01:23:24.889601
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {"allow_duplicates": False, "dependencies": ["role1", "role2"]}
    r.deserialize(data)
    assert r._dependencies == data["dependencies"]
    assert r._allow_duplicates == data["allow_duplicates"]

# Generated at 2022-06-21 01:23:34.692446
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata(owner=None)
    data = dict(
        allow_duplicates=False,
        dependencies=[
            {'role': 'common', 'tasks_from': 'main.yml'},
            {'src': 'https://github.com/geerlingguy/ansible-role-apache'}
        ]
    )
    metadata.deserialize(data)
    assert metadata.allow_duplicates is False
    assert metadata.dependencies[0]['role'] == 'common'
    assert metadata.dependencies[0]['tasks_from'] == 'main.yml'
    assert metadata.dependencies[1]['src'] == 'https://github.com/geerlingguy/ansible-role-apache'

# Generated at 2022-06-21 01:23:37.757131
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata._serialize_class('allow_duplicates', True, None) == 'allow_duplicates'
    assert RoleMetadata._serialize_class('dependencies', [], None) == 'dependencies'

# Generated at 2022-06-21 01:23:46.611216
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # load role metadata
    role_metadata_content = '''
        galaxy_info:
          author: "John Doe"
          description: "This is a description"
          company: "Ansible"
          license: "MIT"
          min_ansible_version: "2.4"
          platforms:
            - name: EL
              versions:
                - "7"
              dependencies:
                - foo
          galaxy_tags:
            - Tag1
            - Tag2
        dependencies: []
        allow_duplicates: True
    '''
    from tempfile import mkdtemp
    from shutil import rmtree
    import yaml

    role_path = mkdtemp()
    meta_path = os.path.join(role_path, "meta")
    os.mkdir(meta_path)

# Generated at 2022-06-21 01:23:47.589914
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play

    assert RoleMetadata(owner=Play())

# Generated at 2022-06-21 01:23:53.575950
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    data = dict(allow_duplicates=True, dependencies=["collection1.role", "collection2.role"])

    data_deserialized = role_metadata.deserialize(data)

    assert(data_deserialized.get('allow_duplicates'))
    assert(len(data_deserialized.get('dependencies'))==2)
    assert(data_deserialized.get('dependencies')[0]=="collection1.role")
    assert(data_deserialized.get('dependencies')[1]=="collection2.role")

test_RoleMetadata_deserialize()
