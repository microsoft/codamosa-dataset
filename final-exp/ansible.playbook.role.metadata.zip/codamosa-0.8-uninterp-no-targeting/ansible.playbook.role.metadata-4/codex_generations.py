

# Generated at 2022-06-21 01:14:22.698567
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    role_obj = Role()
    meta_obj=RoleMetadata()
    meta_obj.allow_duplicates=True
    meta_obj._dependencies=['tomcat','mysql']
    role_obj._metadata = meta_obj
    assert meta_obj.serialize() == {'dependencies':['tomcat','mysql'],'allow_duplicates':True}


# Generated at 2022-06-21 01:14:31.149045
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    meta = RoleMetadata.load({}, owner=RoleDefinition.load(dict(name='some_role')))
    assert isinstance(meta, RoleMetadata)
    assert isinstance(meta._owner, RoleDefinition)
    assert len(meta._dependencies) == 0

    meta = RoleMetadata.load(dict(dependencies=[dict(role='some_other_role')]),
                             owner=RoleDefinition.load(dict(name='some_role')))
    assert isinstance(meta, RoleMetadata)
    assert isinstance(meta._owner, RoleDefinition)
    assert len(meta._dependencies) == 1
    assert isinstance(meta._dependencies[0], RoleInclude)

# Generated at 2022-06-21 01:14:32.924663
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta.dependencies == []
    assert meta.allow_duplicates == False


# Generated at 2022-06-21 01:14:33.416881
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:34.185545
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:47.172933
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    role_definition = RoleDefinition()
    role_definition._role_name = 'test_role_name'
    role_definition._role_path = 'test_role_path'
    role_definition._task_blocks = ['test_task_block']

    context = PlayContext()
    context.remote_addr = 'test_remote_addr'
    context.password = 'test_password'
    context.port = 'test_port'
    context.become_method = 'test_become_method'

# Generated at 2022-06-21 01:14:59.753672
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import collection_loader
    from ansible.playbook.collection import AnsibleCollectionRef
    from ansible.collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 01:15:08.876967
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:15:13.190901
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict()
    role_metadata.deserialize(data)
    allow_duplicates = getattr(role_metadata, 'allow_duplicates')
    assert allow_duplicates == False
    dependencies = getattr(role_metadata, 'dependencies')
    assert dependencies == []

# Generated at 2022-06-21 01:15:20.214925
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    data = {
        'allow_duplicates': True,
        'dependencies': [
            { 'role': 'role1' },
            { 'role': 'role2' }
        ]
    }
    m = RoleMetadata()
    m.load(data)

    assert m.allow_duplicates
    assert isinstance(m.dependencies, list)
    for entry in m.dependencies:
        assert isinstance(entry, string_types) or isinstance(entry, dict)

# Generated at 2022-06-21 01:15:31.674362
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # test for empty array/dict
    a = RoleMetadata()
    a_serialize = a.serialize()
    assert a_serialize == {'allow_duplicates': False, 'dependencies': []}, \
        "a_serialize is not equal to {'allow_duplicates': False, 'dependencies': []}"
    assert a_serialize is not None, "a_serialize is undefined"
    assert isinstance(a_serialize, dict), "a_serialize type must be dict, not" + str(type(a_serialize))



# Generated at 2022-06-21 01:15:37.136968
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    tmp = RoleMetadata()

    # allow_duplicates
    d1 = {'allow_duplicates': True}
    tmp.deserialize(d1)
    d2 = tmp.serialize()
    assert d1 == d2

    # dependencies
    d1 = {'dependencies': ['test1', 'test2']}
    tmp.deserialize(d1)
    d2 = tmp.serialize()
    assert d1 == d2


# Generated at 2022-06-21 01:15:40.131446
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rd = RoleMetadata()
    rd.deserialize({'allow_duplicates': False, 'dependencies': []})
    rd.serialize()


# Generated at 2022-06-21 01:15:45.427404
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata.allow_duplicates = True
    metadata.dependencies = [3, 4, 6]
    expected_return = dict(
        allow_duplicates=True,
        dependencies=[3, 4, 6]
    )
    assert metadata.serialize() == expected_return



# Generated at 2022-06-21 01:15:51.378331
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MyRole:
        def __init__(self):
            self._role_name = "initialize_test_role"
            self._role_path = "initialize_test_path"

    role_metadata = RoleMetadata(MyRole())
    assert role_metadata._owner._role_name == "initialize_test_role"
    assert role_metadata._owner._role_path == "initialize_test_path"

# Generated at 2022-06-21 01:15:59.986432
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirements import RoleRequirements

    role_def = RoleDefinition()
    role_req = RoleRequirements()

    assert(isinstance(role_def, Base))

    assert(isinstance(role_req, RoleRequirements))

    assert(isinstance(role_def.load_data({}, variable_manager=None, loader=None), RoleDefinition))
    assert(isinstance(role_req.load_data({}, variable_manager=None, loader=None), RoleRequirements))
    assert(isinstance(role_req.load([], variable_manager=None, loader=None), RoleRequirements))
    

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-21 01:16:11.177406
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata_1 = RoleMetadata.load(dict(
        allow_duplicates=True,
        dependencies=[dict(name='role_1'), dict(name='role_2')],
        galaxy_info=dict(
            author='Michael',
            description='Very good role')
    ), None)
    serialized = metadata_1.serialize()
    assert isinstance(serialized, dict)
    assert serialized == dict(
        allow_duplicates=True,
        dependencies=[dict(name='role_1'), dict(name='role_2')]
    )

    metadata_2 = RoleMetadata.load(dict(
        dependencies=[dict(name='role_1'), dict(name='role_2')],
        galaxy_info=dict(
            author='Michael',
            description='Very good role')
    ), None)


# Generated at 2022-06-21 01:16:13.919542
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.roles.collection import RoleCollection

    m = RoleMetadata(owner=RoleCollection())
    assert m is not None

# Generated at 2022-06-21 01:16:16.402803
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:16:25.853541
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates':False, 'dependencies':[{'role':'common'},{'role':'../some-other-role'},{'role':{'name':'some-galaxy-role'}, 'version':'v1.0'}], 'galaxy_info': {'author': 'me', 'description': 'foo'}}
    r = RoleMetadata()
    r.deserialize(data)
    assert r._dependencies == [{'role':'common'},{'role':'../some-other-role'},{'role':{'name':'some-galaxy-role'}, 'version':'v1.0'}]

# Generated at 2022-06-21 01:16:37.984746
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata(owner=None)
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = []
    obj.deserialize(data)
    assert obj.allow_duplicates == True
    assert obj.dependencies == []

# Generated at 2022-06-21 01:16:42.776130
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': False,
        'dependencies': [{'name': 'sample_role'}]
    }

    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == data['allow_duplicates']


# Generated at 2022-06-21 01:16:54.748812
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import role_loader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task import Task
    from ansible.template import Templar


# Generated at 2022-06-21 01:16:56.921859
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    RoleMetadata_instance = RoleMetadata(owner=None)

    assert RoleMetadata_instance.serialize() == {"allow_duplicates":False,"dependencies":[]}


# Generated at 2022-06-21 01:17:03.522545
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()

    roleMetadata._dependencies = ['roleName']
    roleMetadata._allow_duplicates = False

    roleMetadata.deserialize({'dependencies': ['roleName'], 'allow_duplicates': False})

    assert roleMetadata.deserialize({'dependencies': ['roleName'], 'allow_duplicates': False}) == {'dependencies': ['roleName'], 'allow_duplicates': False}

# Generated at 2022-06-21 01:17:09.227467
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test the deserialize method of class RoleMetadata.
    '''

    role_metadata = RoleMetadata()

    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['foo', 'bar']})

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 01:17:18.168667
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class TestRoleMetadata(RoleMetadata):
        def __init__(self):
            super(TestRoleMetadata, self).__init__()

            # allow_duplicates
            self._allow_duplicates = False

            # dependencies
            self._dependencies = [
                RoleRequirement(
                    collections='geerlingguy.ntp,1.1.0',
                    name='geerlingguy.ntp',
                    scm='',
                    src='geerlingguy.ntp,1.1.0',
                    scm_revision='',
                    scm_username=''
                )
            ]

    t = TestRoleMetadata()
    result = t.serialize()

    assert result['allow_duplicates'] == False

# Generated at 2022-06-21 01:17:29.913520
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import copy
    import sys
    import pprint

    from ansible.utils.display import Display
    from ansible.module_utils import basic

    display = Display()

    from ansible.module_utils.six import iteritems

    fake_loader = basic.AnsibleModule.AnsibleModuleLoader(None, None)

    # create the object
    role_metadata = RoleMetadata()

    # load data into it

# Generated at 2022-06-21 01:17:40.386252
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.utils.path import unfrackpath

    # Role.load expects to find role file in role_path.
    role = Role()
    role._role_path = '/home/user/ansible/test/roles/test_role_1'

# Generated at 2022-06-21 01:17:50.121471
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Mock the parser
    parser = mock.MagicMock()

    # Create a role
    role = Role()
    role._role_path = '/foo/bar/'

    # Create a chunk of role metadata to load
    data = dict(
        allow_duplicates=True,
        dependencies=[
            "../other/some_role",
            "../other/other_role",
            {"src": "some.private.galaxy/ns/some_role", "name": "some_other_role"},
            {"src": "some.private.galaxy/ns/other_role", "name": "another_role"}
        ]
    )

    # Mock and load
    role_metadata = RoleMetadata.load(data, role, parser)

    assert role_metadata.allow_duplicates is True

# Generated at 2022-06-21 01:18:07.968809
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': ['A', 'B']}
    m = RoleMetadata()
    m.deserialize(data)
    print(m.serialize())



# Generated at 2022-06-21 01:18:09.292901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass



# Generated at 2022-06-21 01:18:12.872081
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor
    metadata = RoleMetadata()

    # Test fields are initialized as expected
    assert metadata._allow_duplicates is False
    assert metadata._dependencies == []
    assert metadata._galaxy_info is None
    assert metadata._argument_specs == {}
    assert metadata._owner is None

# Generated at 2022-06-21 01:18:24.988507
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """ test_RoleMetadata_load: test if the method load of class RoleMetadata 
        is working properly.
    """
    # pylint: disable=protected-access
    # create a temporary class to test if the method load is working properly
    class Test_RoleMetadata():
        def __init__(self):
            self.metadata = {}
            self._variable_manager = "variable_manager"
            self._loader = "loader"
            self.collections = None
            self._role_collection = None
            self._play = "play"
            self._role_path = "role_path"

    # create a instance of Test_RoleMetadata class
    test_role_metadata = Test_RoleMetadata()
    # create a instance of RoleMetadata class

# Generated at 2022-06-21 01:18:32.570367
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #Test case with dictionary passed in
    role = RoleMetadata()
    data = {'allow_duplicates': True}
    role.load(data)

    assert role is not None

    #Test case with string passed in
    role = RoleMetadata()
    data = "string data"
    try:
        role.load(data)
    except AnsibleParserError as e:
        assert "the 'meta/main.yml' for role %s is not a dictionary" in e.message
    else:
        raise Exception("Expected error, didn't get one.")

# Generated at 2022-06-21 01:18:35.585788
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    attr = dict()
    attr['allow_duplicates'] = True
    attr['dependencies'] = []
    obj = RoleMetadata(attr)
    assert obj.serialize() == attr


# Generated at 2022-06-21 01:18:38.969884
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMeta = RoleMetadata()
    roleMeta.deserialize({})
    assert(roleMeta.allow_duplicates == False)
    assert(roleMeta.dependencies == [])

# Generated at 2022-06-21 01:18:45.224186
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    unserialized_data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(unserialized_data)
    assert False == role_metadata._allow_duplicates
    assert list == type(role_metadata._dependencies)
    assert 0 == len(role_metadata._dependencies)


# Generated at 2022-06-21 01:18:50.557149
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test of method load of class RoleMetadata
    '''

    role_metadata = RoleMetadata()
    role_metadata.load({'dependencies': []}, owner=None)

    with pytest.raises(AnsibleParserError):
        role_metadata.load('dependencies', owner=None)

# Generated at 2022-06-21 01:18:59.027177
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Tests that a RoleMetadata object can be created.  Does not test
    that the load_list_of_roles function is called, which is the
    primary functionality of the constructor.
    """
    # Creating all the necessary input for the constructor
    owner = None
    data = dict()
    variable_manager = None
    loader = None

    # Create the RoleMetadata object
    roleMetadata = RoleMetadata.load(data, owner, variable_manager, loader)

    # Assert the values are the default values
    assert(roleMetadata._allow_duplicates is False)
    assert(roleMetadata._dependencies == [])
    assert(isinstance(roleMetadata._galaxy_info, dict))
    assert(roleMetadata._argument_specs == {})

# Generated at 2022-06-21 01:19:33.061401
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    new_meta = RoleMetadata()
    assert new_meta.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }
    new_meta = RoleMetadata(owner="myowner")
    assert new_meta.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-21 01:19:35.372473
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    assert metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:19:36.446340
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    a = RoleMetadata()
    assert a is not None

# Generated at 2022-06-21 01:19:45.116276
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class FakeOwner:
        def __init__(self):
            self.name = "fake_owner"
            self.get_name = lambda: self.name
    owner = FakeOwner()
    metadata = RoleMetadata(owner)
    metadata.allow_duplicates = True
    fake_dependency_class = type('FakeDependencyClass', (object, ), {})
    fake_dependency = fake_dependency_class()
    fake_dependency.name = "fake_dependency_name"
    metadata.dependencies = [fake_dependency]
    result = metadata.serialize()
    expected_result = {
        'allow_duplicates': True,
        'dependencies': [{'name': 'fake_dependency_name'}]
    }
    assert result == expected_result

# Generated at 2022-06-21 01:19:47.727153
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''Unit test for constructor of class RoleMetadata.'''
    rm = RoleMetadata()
    assert isinstance(rm, RoleMetadata)

# Generated at 2022-06-21 01:19:58.656085
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    role = RoleMetadata()
    role._allow_duplicates = True
    role._dependencies = [{'role': 'userinfo'}, {'role': 'foo'}]

    block = Block()
    block._block  = []
    block._name   = 'foobar'
    block._parent = None
    block._role_name = 'foobar'
    block._strict = False
    block._loop = None
    block._when = None
    block._rescue = None
    block._always = None
    block._any_errors_fatal = False
    block._changed_when = False


# Generated at 2022-06-21 01:19:59.064223
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-21 01:20:03.120574
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data ={"allow_duplicates": True,
        "dependencies": "test"
    }
    metadate = RoleMetadata()
    metadate.deserialize(data)
    result = metadate.serialize()
    assert result == data

# Generated at 2022-06-21 01:20:05.077094
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Test the constructor of Class RoleMetadata
    '''
    metadata = {}
    RoleMetadata.load(metadata, None)

# Generated at 2022-06-21 01:20:11.650206
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    m.load(dict(
        allow_duplicates=True,
        dependencies=dict(
            other=dict(
                name='geerlingguy.apache',
                src='../other'
            )
        )
    ))
    assert m.allow_duplicates

    # Test with bad allow_duplicates value
    try:
        m.load(dict(
            allow_duplicates=2
        ))
    except AnsibleParserError:
        # This is the expected result
        pass
    else:
        assert False, 'AnsibleParserError not raised'

    # Test with bad dependencies entry

# Generated at 2022-06-21 01:21:06.955151
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()


# Generated at 2022-06-21 01:21:09.326013
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    assert m.load(dict(allow_duplicates=True, dependencies=['foo', 'bar'])) is None

# Generated at 2022-06-21 01:21:11.221208
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    b = RoleMetadata()
    assert isinstance(b, RoleMetadata)


# Generated at 2022-06-21 01:21:22.990765
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import sys

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from collections import namedtuple

    __metaclass__ = type
    class MockRole:
        def __init__(self, role_path):
            self.role_path = role_path
            self.collections = []

    class MockLoader:
        def __init__(self, pkgloc):
            self._basedir = pkgloc

        def _find_path_of_possible_role_file(self, path):
            return path

        def path_dwim(self, basedir, path):
            return os.path.join(basedir, path)


# Generated at 2022-06-21 01:21:27.202449
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    d = {
        'allow_duplicates': "A test",
        'dependencies': "A test"
    }
    # The method load_data will call deserialize in RoleMetadata
    r.load_data(d)
    assert r._allow_duplicates == "A test"
    assert r._dependencies == "A test"

# Generated at 2022-06-21 01:21:34.747032
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = [{'name': 'jdoe.common-role', 'src': 'https://github.com/jdoe/ansible-role-common'}]
    role = RoleMetadata()
    role.deserialize(data)
    assert role.allow_duplicates
    assert role.dependencies
    assert role.dependencies == data['dependencies']

# Generated at 2022-06-21 01:21:44.502970
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-21 01:21:54.536950
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.metadata import RoleMetadata

    class RoleMeta(RoleMetadata):
        pass

    class PlayContext(PlayContext):
        def __init__(self, pb, role=None):
            self._data = dict()
            self._data['run_once'] = True
            self._data['become_user'] = ''
            self._data['become_method'] = ''
            self._data['become'] = False
            self._data['become_ask_pass'] = False
            self._

# Generated at 2022-06-21 01:22:04.161886
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata.deserialize({})

# Generated at 2022-06-21 01:22:14.808443
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    def host_task(name, hosts):
        task = Task()
        task.name = name
        task.block = Block()
        task.block.name = name
        task.block.task_vars = dict()
        task.block