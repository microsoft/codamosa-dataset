

# Generated at 2022-06-21 01:14:21.467088
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    raw_data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )

    data = RoleMetadata().load_data(raw_data)
    assert data.serialize() == raw_data

    data = RoleMetadata(owner=RoleDefinition()).load_data(raw_data)
    assert data.serialize() == raw_data

    with pytest.raises(AnsibleParserError):
        data = RoleMetadata().load_data(1)


# Generated at 2022-06-21 01:14:25.073185
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=["bar"])
    r.deserialize(data)
    assert r._allow_duplicates is True
    assert r._dependencies == ["bar"]


# Generated at 2022-06-21 01:14:27.740453
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dependencies = [{'src': 'test_src'}, {'role': 'test_role'}]
    role_metadata = RoleMetadata(owner=None)
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = dependencies

    assert isinstance(role_metadata.serialize(), dict)
    assert role_metadata.serialize()['allow_duplicates'] == False
    assert role_metadata.serialize()['dependencies'] == dependencies

# Generated at 2022-06-21 01:14:34.324659
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'foo': 'bar',
        'dependencies': [
            {'foo': 'bar'},
            {'role': 'foo', 'bar': 'baz'}
        ],
        'allow_duplicates': True
    }
    class fake_owner:
        def __init__(self):
            self.collections = None
    owner = fake_owner()
    variable_manager = ["ansible_os_family"]
    loader = ['galaxy']
    m = RoleMetadata.load(data, owner, variable_manager, loader)
    assert m.dependencies == [{'foo': 'bar'}, {'role': 'foo', 'bar': 'baz'}]
    assert m.allow_duplicates == True

# Generated at 2022-06-21 01:14:46.213955
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test that an exception is raised when argument is not a dict
    # when the first argument is not a dict
    try:
        RoleMetadata({'role': 'a'})
        assert(False)
    except AnsibleError as e:
        assert('Expected data to be a dictionary' in to_native(e))

    try:
        RoleMetadata(123)
        assert(False)
    except AnsibleError as e:
        assert('Expected data to be a dictionary' in to_native(e))

    try:
        RoleMetadata("123")
        assert(False)
    except AnsibleError as e:
        assert('Expected data to be a dictionary' in to_native(e))


# Generated at 2022-06-21 01:14:58.721952
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import collections
    from ansible.playbook.collectionsearch import CollectionSearch

    class Mock(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MockRoleRequirement(RoleRequirement):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MockGalaxyInfo(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def as_dict(self, **kwargs):
            return self.__dict__.copy()

    class MockBase(Base):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-21 01:15:08.267634
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    new_role = Role()
    assert new_role.get_name() == 'test_RoleMetadata'

    dependency_fake = ansible.playbook.role.requirement.RoleRequirement()
    dependency_fake._role_name = 'test'
    dependency_fake._role_collection = 'collection.test'
    dependency_fake._role_path = 'test'

    meta_fake = RoleMetadata()
    meta_fake._allow_duplicates = False
    meta_fake._dependencies = [dependency_fake]

    new_role._metadata = meta_fake

    result = new_role.serialize()

# Generated at 2022-06-21 01:15:09.248696
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata.load()

# Generated at 2022-06-21 01:15:13.191780
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    data = role_metadata.serialize()
    assert data == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-21 01:15:18.425415
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.utils.display import Display
    from ansible.plugins.loader import find_plugin_filepaths
    import ansible.plugins.loader as ploader
    from ansible.plugins.loader import roles_path
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    display = Display()
    display.verbosity = 4
    ploader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'fixtures', 'fake_role'))
    role_paths = find_plugin_filepaths

# Generated at 2022-06-21 01:15:31.089663
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemetadata = RoleMetadata()
    rolemetadata._allow_duplicates = False
    rolemetadata._dependencies = ['test']
    serialized = rolemetadata.serialize()
    assert serialized.get('allow_duplicates') == False
    assert serialized.get('dependencies') == ['test']



# Generated at 2022-06-21 01:15:35.284640
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    d = dict(
        allow_duplicates=r.allow_duplicates,
        dependencies=r.dependencies
    )

    r.deserialize(d)

    assert r.allow_duplicates == d['allow_duplicates']
    assert r.dependencies == d['dependencies']

# Generated at 2022-06-21 01:15:36.211208
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-21 01:15:40.067479
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.dependencies = ['dependency1', 'dependency2']
    role.allow_duplicates = True

    assert (role.serialize() == {
        'allow_duplicates': True,
        'dependencies': ['dependency1', 'dependency2']
    })

# Generated at 2022-06-21 01:15:51.425276
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    role = RoleDefinition(name='foo')
    rid = RoleInclude(role)
    data = {'dependencies': [ rid, 'role' ]}
    rm = RoleMetadata(owner=role)

    v = VariableManager()
    rm.load(data, loader=None, variable_manager=v)
    assert(rm._allow_duplicates == False)
    assert(rm._dependencies[0] == data['dependencies'][0])
    assert(isinstance(rm._dependencies[1], AnsibleUnicode))

# Generated at 2022-06-21 01:16:00.272214
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.collectionsearch import CollectionSearch

    role_definition = RoleDefinition.load("../ansible_collections/ansible_collections/nsweb/nginx/", None)
    role_metadata = RoleMetadata.load("../ansible_collections/ansible_collections/nsweb/nginx/meta/main.yml", role_definition)
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata.serialize(), dict)
    assert role_metadata.serialize()['allow_duplicates'] is False
    assert isinstance(role_metadata.serialize()['dependencies'], list)
    assert role_metadata.serialize()['dependencies'] == []


# Generated at 2022-06-21 01:16:07.346941
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    mock_play = Mock(name="play")

    # Test default constructor
    md = RoleMetadata()
    assert(isinstance(md, RoleMetadata))

    # Test constructor to wrap a role
    mock_role = Mock(name="role")
    mock_role._role_path=True
    mock_collection = Mock(name="collection")
    mock_role._role_collection = mock_collection
    mock_role.collections = [mock_collection]
    md = RoleMetadata(owner=mock_role)
    assert(isinstance(md, RoleMetadata))

    # Test constructor to wrap play (default)
    md = RoleMetadata(owner=mock_play)
    assert(isinstance(md, RoleMetadata))

    # Test constructor to wrap play (not default)

# Generated at 2022-06-21 01:16:15.142104
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.plugins.loader import role_loader
    from ansible.utils.collection_loaders import AnsibleCollectionLoader

    role_loader._collection_paths.append('/tmp/test-ansible-collections')

    base_definition = RoleDefinition.load(data=dict(name='foobar',
                                                    collection='test.namespace',
                                                    scm_path='/tmp/test-ansible-collections/ansible_collections/test/namespace/roles/foobar'),
                                          variable_manager={})

    my_loader = AnsibleCollectionLoader()

    base_meta = RoleMetadata(base_definition)

# Generated at 2022-06-21 01:16:24.878255
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    data = dict(
        allow_duplicates='True',
        dependencies=['dependency1', 'dependency2']
    )

    pc = PlayContext()
    p = Play().load({}, variable_manager=None, loader=None)

    role = RoleDefinition.load({'name': 'role1'}, p)
    role.deserialize(data)

    assert role.allow_duplicates is True
    assert role.dependencies is ['dependency1', 'dependency2']

# Generated at 2022-06-21 01:16:26.884361
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-21 01:16:43.672645
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import unittest
    import yaml
    from ansible.vars.clean import module_response_deepcopy
    from ansible.inventory.host import Host
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role.requirement import RoleRequirement

    class RoleMetadataTest(unittest.TestCase):
        def test_deserialize(self):
            host = Host()
            host.vars = dict()
            hosts = dict()
            hosts[host.name] = host
            class Object(object):
                pass
            play = Object()
            play.hosts = hosts
            play.vars = dict()
            play.vars['hostvars'] = dict()
            play.vars['hostvars'][host.name] = dict()


# Generated at 2022-06-21 01:16:52.568813
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        "allow_duplicates": False,
        "dependencies": [{
            "name": "geerlingguy.redis"
        }]
    }
    owner = None
    variable_manager = None
    loader = None

    # Expected output
    expected = RoleMetadata()
    expected._allow_duplicates = False
    expected._dependencies = [{
        "name": "geerlingguy.redis"
    }]

    instance_loaded = RoleMetadata.load(data, owner, variable_manager, loader)

    assert instance_loaded == expected

# Generated at 2022-06-21 01:16:55.932553
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates=True
    role_metadata.dependencies=True
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': True}


# Generated at 2022-06-21 01:17:00.256055
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert dict == type(role_metadata.serialize())
    assert 2 == len(role_metadata.serialize())
    assert 0 == len(role_metadata._dependencies)
    assert False == role_metadata._allow_duplicates



# Generated at 2022-06-21 01:17:04.320885
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    serialized_data = role_metadata.serialize()
    expected_data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    assert serialized_data == expected_data

# Generated at 2022-06-21 01:17:15.210841
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    import yaml

    yaml_string = '''
- role: ansible.builtin_test
- role: ansible.galaxy_test
  dependencies:
  - role: ansible.builtin_test
'''

    tasks = yaml.safe_load(yaml_string)

    # Create Play obj

# Generated at 2022-06-21 01:17:25.484669
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({})
    assert r.allow_duplicates == False
    assert r.dependencies == []
    r.deserialize({'allow_duplicates': 'abc'})
    assert r.allow_duplicates == False
    assert r.dependencies == []
    r.deserialize({'allow_duplicates': True})
    assert r.allow_duplicates == True
    assert r.dependencies == []
    r.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert r.allow_duplicates == False
    assert r.dependencies == []
    r.deserialize({'allow_duplicates': True, 'dependencies': ['a', 'b', 'c']})
    assert r.allow_dupl

# Generated at 2022-06-21 01:17:34.313137
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''
    deps = [
        {'role': 'common'},
        {'role': 'web'}
    ]
    allow_duplicates = True
    serial_data = {'allow_duplicates': allow_duplicates, 'dependencies': deps}
    meta = RoleMetadata()
    for attr in serial_data.keys():
        setattr(meta, attr, serial_data[attr])
    assert meta.serialize() == serial_data


# Generated at 2022-06-21 01:17:35.603243
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates':False,'dependencies':[]}
    r = RoleMetadata(owner = None)
    r.deserialize(data)
    assert r._allow_duplicates == False
    assert r._dependencies == []

# Generated at 2022-06-21 01:17:40.833890
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    r = Role(dict(name="galaxy.role,version,name"))
    r._role_path = "/etc/ansible/roles/"
    rd = RoleDefinition(name="galaxy.role,version,name")
    r._role_collection = rd

    m = RoleMetadata(r)
    assert m.load(dict(dependencies=[]), r)

# Generated at 2022-06-21 01:17:57.608136
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert True

# Generated at 2022-06-21 01:17:59.990093
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-21 01:18:05.415182
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    m = RoleMetadata.load(dict(dependencies=['foo']), RoleDefinition.load(dict(name='bar', path='/dev/null'), loader=None))
    assert isinstance(m.dependencies[0], RoleInclude)

# Generated at 2022-06-21 01:18:14.356311
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from collections import namedtuple
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.clean import module_response_deepcopy

# Generated at 2022-06-21 01:18:25.720978
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement

    m = RoleMetadata()
    assert m.allow_duplicates == False
    assert len(m.dependencies) == 0
    assert m._dependencies == []

    data = dict(
        allow_duplicates='True',
        dependencies=[
            {'role': 'some_role'},
            {'role': 'some_other_role'},
        ]
    )

    # create a mock host object
    host = type('Host', (object,), dict(name='localhost'))()

    # create a mock play object

# Generated at 2022-06-21 01:18:29.842305
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    d = m.serialize()
    assert d.get('allow_duplicates', False) == False
    assert len(d.get('dependencies', [])) == 0


# Generated at 2022-06-21 01:18:36.556137
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.collectionsearch import CollectionSearchItem
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 3

    ds = {
        'allow_duplicates': True,
        'dependencies': [
            'geerlingguy.apache',
            {
                'role': 'geerlingguy.mysql',
                'vars': {
                    'mysql_root_password': 'REPLACEME',
                    'mysql_database': 'wordpress',
                    'mysql_user': 'wordpress',
                    'mysql_password': 'wordpress'
                }
            }
        ]
    }

    dep

# Generated at 2022-06-21 01:18:39.404066
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    '''

    role_metadata = RoleMetadata()
    assert(isinstance(role_metadata, RoleMetadata))

# Generated at 2022-06-21 01:18:41.712750
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(allow_duplicates=True, dependencies=["foo.bar"])
    assert m is not None

# Generated at 2022-06-21 01:18:48.681716
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    RoleDefinition._load = lambda self, ds, role_path, variable_manager, loader: None
    variable_manager = None
    loader = None
    data = {'dependencies': ['foo']}
    owner = None
    mymeta = RoleMetadata.load(data, owner, variable_manager, loader)
    assert mymeta.__class__ == RoleMetadata
    assert mymeta._dependencies[0].__class__ == RoleRequirement

# Generated at 2022-06-21 01:19:26.071205
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', {'role': 'dependency_role'})

    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'dependency_role'}]}

# Generated at 2022-06-21 01:19:27.580504
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Pass when the constructor of class RoleMetadata is called
    pass

# Generated at 2022-06-21 01:19:34.180941
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    def test_dependencies(dependencies):
        r = RoleMetadata()
        s = {'dependencies': dependencies}
        r.deserialize(s)
        return r.dependencies

    assert test_dependencies([]) == []
    assert test_dependencies([{'role': 'foo'}, {'role': 'bar'}]) == [{'role': 'foo'}, {'role': 'bar'}]

# Generated at 2022-06-21 01:19:39.906644
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = "test_role"
    data = {"dependencies": [{"role": role}]}
    role_meta = RoleMetadata.load(data, None)
    assert isinstance(role_meta, RoleMetadata)
    assert isinstance(role_meta._dependencies, list)
    assert isinstance(role_meta._dependencies[0], dict)
    assert isinstance(role_meta._dependencies[0], dict)
    assert role_meta._dependencies[0]["role"] == role
    assert role_meta.allow_duplicates == False


# Generated at 2022-06-21 01:19:45.726220
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_data = {
        'dependencies':[{'role': 'docs.ansible.com,1.0,foo'},
                        {'name': 'geerlingguy.mysql'}
        ],
        'allow_duplicates': True
    }

    try:
        RoleMetadata.load(test_data, None)
    except Exception as e:
        assert False, "Unexpected error found: " + str(e)



# Generated at 2022-06-21 01:19:46.699588
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:19:47.339102
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-21 01:19:54.929229
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    class Role:
        pass
    r = Role()
    r._role_collection = None
    r.collections = ['test']
    rm = RoleMetadata(r)
    rm.deserialize(data)
    assert rm._allow_duplicates == False
    assert rm._dependencies == []
    assert rm._owner._role_collection == None
    assert rm._owner.collections == ['test']


# Generated at 2022-06-21 01:19:56.255481
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #TODO: write unit test
    dummy = None
    dummy = 1

# Generated at 2022-06-21 01:20:00.395126
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])

    m = RoleMetadata(allow_duplicates=True)
    assert m.serialize() == dict(allow_duplicates=True, dependencies=[])

# Generated at 2022-06-21 01:21:05.813699
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    meta.deserialize(data)
    assert meta.allow_duplicates == False
    assert meta.dependencies == []


# Generated at 2022-06-21 01:21:17.038745
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Constructing data structure to test
    data = {'dependencies': [], 'allow_duplicates': False, 'galaxy_info': {}}

    # Constructing the loader and context objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Constructing the Task object
    task = Task()
    task._role = None
    task._block = None
   

# Generated at 2022-06-21 01:21:26.027073
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'name': 'test1',
                'src': 'git+https://github.com/user/test1.git',
                'version': '1.2.3'
            },
            {
                'name': 'test2',
                'src': 'git+https://github.com/user/test2.git',
                'version': '4.5.6'
            }
        ]
    }
    m.deserialize(data)
    assert m.allow_duplicates == True
    assert len(m._dependencies) == 2

# Generated at 2022-06-21 01:21:38.027797
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude

    fake_loader = None
    fake_variable_manager = None

# Generated at 2022-06-21 01:21:46.884107
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    m = RoleMetadata(owner="test_owner")

    # Empty RoleMetadata
    m = RoleMetadata(owner="test_owner")
    assert m.allow_duplicates == False
    assert m.dependencies == []

    # Load nothing
    m = m.load(None, variable_manager=None, loader=None)
    assert m.allow_duplicates == False
    assert m.dependencies == []

    # Load the wrong type

# Generated at 2022-06-21 01:21:57.752090
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook import role
    from ansible.playbook.block import Block
    filename = os.path.join(os.path.dirname(__file__), '../../../test/playbook/meta/main.yaml')
    r = RoleDefinition()
    r.name = "test@test.test"
    r._role_path = filename
    r._role_collection = None
    r._play = None
    r._loader = None
    meta = RoleMetadata.load(r._loader.load_from_file(filename), r)
    assert isinstance(meta, RoleMetadata) is True
    assert isinstance(meta._owner, RoleDefinition) is True
    assert meta._owner == r
    assert isinstance(meta._dependencies, list)

# Generated at 2022-06-21 01:22:00.254825
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    t = RoleMetadata()
    assert t.serialize() is not None


# Generated at 2022-06-21 01:22:11.346525
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible_collections.testns.testcoll.plugins.module_utils.common.removed import removed
    from ansible.playbook.role.definition import RoleDefinition

    # test various types of dependencies
    test_data_1 = {
        'dependencies': [
            'testns.testcoll.testrole',
            'testns.testcoll.testrole2',
            {'name': 'testns.testcoll.testrole3'},
            {'name': 'testns.testcoll.testrole4', 'version': '2.0'},
            {'name': 'testns.testcoll.testrole5', 'collections': ['testns.testcoll']}
        ]
    }
    test_metadata = RoleMetadata.load(test_data_1, RoleDefinition(), loader=None)

# Generated at 2022-06-21 01:22:14.254961
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    my_metadata = RoleMetadata(owner="google.com")
    assert my_metadata._allow_duplicates == False
    print("test_RoleMetadata: PASS")

test_RoleMetadata()

# Generated at 2022-06-21 01:22:20.668626
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.utils.context_objects import AnsibleContext

    # basic test - create a RoleMetadata object and verify it has the expected attributes
    rm = RoleMetadata()
    assert rm._allow_duplicates is False
    assert rm._dependencies == list()

    # check parameter owner
    # create a role and a play
    assert rm._owner is None

    # check attribute allow_duplicates
    rm = RoleMetadata()
    rm._load_allow_duplicates(ds={'allow_duplicates': True})
    assert rm._allow_duplicates

    rm = RoleMetadata()
    rm._load_allow_duplicates(ds={'allow_duplicates': False})
    assert not rm._allow_duplicates

    # check attribute dependencies