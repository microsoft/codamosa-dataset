

# Generated at 2022-06-21 01:14:20.168833
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """ role: Create a role object.
    role_metadata: Create two role_metadata objects, one with
        valid dependencies, one with junk.
    """

    # Test with no Dependencies
    owner = MockRole(name = "owner")
    data = {'dependencies': []}
    variable_manager = MockVariableManager(
        extra_vars = {'role_name': "role_name",
                      'role_path': "/path/to/role"})
    loader = MockLoader()
    result = RoleMetadata.load(data,
                               owner,
                               variable_manager,
                               loader)
    assert isinstance(result, RoleMetadata)
    assert result.dependencies == []
    assert result.owner == owner

    # Test with valid dependencies
    owner = MockRole(name="owner")

# Generated at 2022-06-21 01:14:24.875570
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print('test_RoleMetadata_serialize: START')
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata(owner=None).deserialize(data)
    assert role_metadata.serialize() == data
    print('test_RoleMetadata_serialize: END')

# Generated at 2022-06-21 01:14:32.826384
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    rd = RoleDefinition()
    rd._role_path = 'roles/test_1'
    rd._play_context = PlayContext()
    rd.name = 'test_1'
    rd._blocks.append(Block.load(dict(
        tasks=[
            dict(action=dict(module='ping'))
        ]
    )))
    t = Task.load(dict(action=dict(module='ping')), rd, None)

    rd2 = RoleDefinition()
    rd2._role_path = 'roles/test_2'
    rd2._play_

# Generated at 2022-06-21 01:14:36.058306
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_main_yml = open("../../../meta/main.yml", "r")
    data = yaml.load(meta_main_yml)
    print(data)
    r = RoleMetadata.load()

# Generated at 2022-06-21 01:14:39.395917
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert isinstance(m, RoleMetadata)
    assert isinstance(m._dependencies, list)


# Generated at 2022-06-21 01:14:48.942064
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role import Role

    inventory = InventoryManager(
        sources=[],
        variable_manager=VariableManager(),
    )
    variable_manager = VariableManager()

    role = Role.load("name\n", variable_manager=variable_manager, loader=None)
    metadata = RoleMetadata(owner=role).load({"dependencies": ["a", "b"]}, owner=role)
    assert metadata._dependencies == ["a", "b"]

# Generated at 2022-06-21 01:14:59.861312
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    role = Role()
    block = Block()
    role.blocks = [block]
    task = Task()
    block.block = [task]
    role.task_blocks = [block]
    role.tasks = [task]
    meta = RoleMetadata(owner=role)
    data = dict(
        allow_duplicates=False,
        dependencies=['alice', 'bob'],
        galaxy_info=None
    )
    meta.deserialize(data)
    assert (meta.serialize() == data)

# Generated at 2022-06-21 01:15:09.347142
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r1 = RoleMetadata()
    r1.allow_duplicates = True
    r1.dependencies = ['a1.role', 'b2.role', 'c3.role']

    r2 = RoleMetadata()
    r2.allow_duplicates = False
    r2.dependencies = ['d4.role', 'e5.role', 'f6.role']

    assert r1.serialize() == {'allow_duplicates': True, 'dependencies': ['a1.role', 'b2.role', 'c3.role']}
    assert r2.serialize() == {'allow_duplicates': False, 'dependencies': ['d4.role', 'e5.role', 'f6.role']}


# Generated at 2022-06-21 01:15:12.580654
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    # Test case 1: role_def is string_types
    pass

    # Test case 2: role_def is new style
    pass

    return True

# Generated at 2022-06-21 01:15:14.105298
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m._allow_duplicates is False
    assert m._dependencies == []

# Generated at 2022-06-21 01:15:26.252741
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # m = RoleMetadata(owner=None)
    assert True

# Generated at 2022-06-21 01:15:27.577984
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner = None)
    m.serialize()

# Generated at 2022-06-21 01:15:36.418149
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Testing file can be found in tests/functional/meta/main_meta.yml
    test_meta_path = "./tests/functional/meta/main_meta.yml"
    with open(test_meta_path, 'r') as f:
        test_meta_yml = f.read()
        test_meta = RoleMetadata(owner=None).load(test_meta_yml, owner=None)
        assert test_meta.allow_duplicates == False
        assert 'allow_duplicates' in test_meta.serialize()
        assert 'dependencies' in test_meta.serialize()
        assert test_meta.serialize()['allow_duplicates'] == test_meta.allow_duplicates

# Generated at 2022-06-21 01:15:40.548657
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("\n###### test_RoleMetadata_serialize() ######\n")

    s = RoleMetadata()
    s._allow_duplicates = True
    s._dependencies = ['test']
    print(s.serialize())
    print(s.deserialize(s.serialize()))

# Generated at 2022-06-21 01:15:44.986492
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({
            'allow_duplicates': True,
            'dependencies': ['a', 'b']
        })

    assert r.allow_duplicates == True
    assert r.dependencies == ['a', 'b']

# Generated at 2022-06-21 01:15:48.334550
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None
    assert r._argument_specs == {}

# Generated at 2022-06-21 01:15:55.671805
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import pytest
    from ansible.playbook.role.metadata import RoleMetadata

    rm = RoleMetadata()
    setattr(rm, 'allow_duplicates', True)
    setattr(rm, 'dependencies', [1, 2, 3])
    serialized_data = rm.serialize()

    assert isinstance(serialized_data, dict)
    assert serialized_data.get('allow_duplicates') is True
    assert serialized_data.get('dependencies') == [1, 2, 3]


# Generated at 2022-06-21 01:15:58.678811
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=list(['one', 'two']),
    )
    RoleMetadata().deserialize(data)

# Generated at 2022-06-21 01:16:10.284154
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create a collection definition to test the loading of the method load
    # of class RoleMetadata.
    collection = dict(
        name="test_collection",
        version="1.0",
        namespace="test",
        collection_info=dict(
            description="A test collection"
        ),
        roles=[],
        dependencies=[]
    )

    # Create a play definition to test the loading of the method load of class RoleMetadata.
    play = dict(
        name="test_play",
        hosts="all",
        gather_facts=True,
        roles=[]
    )

    # Create a definition of a role to test the loading of the method load
    # of class RoleMetadata.

# Generated at 2022-06-21 01:16:15.897164
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj1 = RoleMetadata()
    obj1.allow_duplicates = False
    obj1.dependencies = ['bar', 'foo']
    obj2 = RoleMetadata()
    obj2.allow_duplicates = False
    obj2.dependencies = ['bar', 'foo']
    assert obj1.serialize() == obj2.serialize()

# Generated at 2022-06-21 01:16:38.340894
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import get_all_plugin_loaders
    my_loader = get_all_plugin_loaders()['role']()
    my_loader.find_role_paths()
    role = Role()
    role_path = None

# Generated at 2022-06-21 01:16:49.642754
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print ("Testing RoleMetadata.serialize()")

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    role_def = RoleDefinition(play=Play().load(dict(
        name="test",
        hosts=['localhost'],
        gather_facts='no',
        roles=[]), variable_manager=None, loader=None))

    metadata = RoleMetadata(owner=role_def)
    metadata.deserialize(dict(
        allow_duplicates=True,
        dependencies="test"
        ))

    assert metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies="test"
    )
    print ("OK")



# Generated at 2022-06-21 01:16:51.232165
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-21 01:16:59.611286
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        dependencies=['common'],
        allow_duplicates=False,
        galaxy_info=dict(
            description='Common role',
            author='author',
            min_ansible_version='2.0',
            platforms=['all'],
            company='example',
            license='GPLv2',
            issues_url='http://example.org/issue/tracker',
            tags=[],
            dependencies=[],
        )
    )
    metadata = RoleMetadata.load(data=data, owner=None)
    assert metadata.allow_duplicates == False
    assert len(metadata.dependencies) == 1
    assert metadata.dependencies[0]['name'] == 'common'
    assert metadata.galaxy_info.description == 'Common role'
    assert metadata.galaxy_info.min

# Generated at 2022-06-21 01:17:04.501902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.collectionsearch import GalaxyInfo
    from ansible.playbook.role.requirement import RoleRequirement
    data = {}
    data['allow_duplicates'] = True
    data['dependencies'] = []
    ds = RoleMetadata(owner=data)
    assert ds.serialize() == data

# Generated at 2022-06-21 01:17:06.066726
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()


# Generated at 2022-06-21 01:17:08.849847
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = dict()
    metadata.deserialize(data)
    assert metadata._allow_duplicates == False
    assert metadata._dependencies == []

# Generated at 2022-06-21 01:17:15.092329
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude

    data = dict(
        allow_duplicates=False,
        dependencies=["foo", "bar"]
    )

    rm = RoleMetadata().deserialize(data)
    assert rm.allow_duplicates == data.get('allow_duplicates')
    assert isinstance(rm.dependencies[0], RoleInclude)
    assert isinstance(rm.dependencies[1], RoleInclude)

# Generated at 2022-06-21 01:17:25.287676
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _get_variable_manager(loader):
        inventory = InventoryManager(loader=loader, sources='localhost,')
        return VariableManager(loader=loader, inventory=inventory)

    parent = os.path.join(os.path.dirname(__file__), '..', '..')
    roles_path = os.path.join(parent, 'test/roles')

    loader = DataLoader()


# Generated at 2022-06-21 01:17:33.419159
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.six import PY3

    if not PY3:
        return

    obj = RoleMetadata()
    obj.owner = None

    # try load one
    with patch.object(obj, "_load_dependencies") as mock_load_dependencies:
        obj._load_dependencies.return_value = "test"

        data = {"dependencies": "test"}
        obj._load_dependencies(None, data)

# Generated at 2022-06-21 01:18:05.843682
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_name = "jdoe.role1"
    role_path = "/home/user/ansible/roles/jdoe.role1"
    ri = RoleMetadata()
    ri._dependencies = [{'name': 'jdoe.role2', 'require': [{'role': 'jdoe.role3'}]}]
    ri._owner = role_name
    ri._allow_duplicates = False
    ri._loader = "/home/user/ansible/roles/jdoe.role1/meta/main.yml"
    ri._variable_manager = None

# Generated at 2022-06-21 01:18:14.643368
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    data = {
        "allow_duplicates": False,
        "dependencies": [
            {
                "role": "github_username.role_name",
                "name": "role_name",
                "collections": [
                    "myorg.mycol",
                    "myorg.mycol2"
                ]
            }
        ]
    }
    role_meta.deserialize(data)
    r = role_meta.serialize()
    assert r['allow_duplicates'] == False

# Generated at 2022-06-21 01:18:18.066853
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.models import Playbook
    my_dict = dict(allow_duplicates=False, dependencies=list())
    assert RoleMetadata(owner=Playbook(base_dir=".")).serialize() == my_dict

# Generated at 2022-06-21 01:18:29.644073
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-21 01:18:33.185669
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_dict = {'allow_duplicates': True, 'dependencies':[]}
    rm = RoleMetadata()
    rm.deserialize(test_dict)
    assert (rm.allow_duplicates ==  True)
    assert (rm.dependencies ==  [])


# Generated at 2022-06-21 01:18:35.960557
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    res = rm.deserialize(data=dict(dependencies=['foo', 'bar']))
    assert res.dependencies == ['foo', 'bar']

# Generated at 2022-06-21 01:18:46.938192
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    # pylint: disable=protected-access
    # Setup
    mock_Play = Play.load(dict(
        name="MockPlay",
        hosts='localhost',
        roles=[]
    ))

    # Test
    role_meta = RoleMetadata.load(
        data={
            'dependencies': [
                {'name': "mockrole"}
            ]
        },
        owner=RoleInclude("MockRole", play_context=mock_Play.get_variable_manager())
    )

    # Assert
    assert role_meta.dependencies[0].name == "mockrole"

# Generated at 2022-06-21 01:18:51.057429
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    m = RoleMetadata(owner=Role())
    print(m)

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:18:57.456350
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class TestRoleMetadata(RoleMetadata):
        def __init__(self,data,owner=None):
            super(TestRoleMetadata,self).__init__(owner)
            self._allow_duplicates = data.get('allow_duplicates',False)
            self._dependencies = data.get('dependencies',[])
    data = {'allow_duplicates': True,
            'dependencies': ['rolea','roleb']}
    r = TestRoleMetadata(data)
    assert (r.serialize()) == data

# Generated at 2022-06-21 01:19:00.312700
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    met = RoleMetadata()
    met._allow_duplicates = True
    met._dependencies = ['role1', 'role2']
    met._variable_manager = 'variable_manager'

    assert met.serialize() == {'allow_duplicates': True,
                               'dependencies': ['role1', 'role2']}

# Generated at 2022-06-21 01:19:57.769497
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:20:07.493738
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    def test_meta():
        role_path = '/test_playbook/roles/test_role'
        role_name = 'test_role'
        role_data = dict(
            allow_duplicates=True,
            dependencies=[]
        )

        rdm = RoleMetadata()
        rdm.deserialize(role_data)

        assert rdm.deserialize(role_data) == rdm.serialize()

    test_meta()


# Generated at 2022-06-21 01:20:10.554895
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'dependencies': [{'role': 'test_role_1', 'some_param': 'some_value'}]}
    result = RoleMetadata(owner='test_owner')

    assert result is not None, "result is None"
    assert not result.allow_duplicates, "allow_duplicates is not False"


# Generated at 2022-06-21 01:20:15.635126
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    role = Role.load('testdata/ansible-test-role', None, None)
    RoleMetadata.load(role, None, None, None)
    assert(role._metadata._dependencies == ['test0', 'test1'])
    assert(role._metadata._allow_duplicates == True)

# Generated at 2022-06-21 01:20:26.071950
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    play_path = '/tmp/ansible_test_role_meta_main/play.yml'
    if os.path.exists(play_path):
        with open(play_path) as f:
            play_data = yaml.load(f, Loader=yaml.BaseLoader)
    else:
        play_data = {}
    play_ = Play().load(play_data, variable_manager=None, loader=None)
    test_role_path = '/tmp/ansible_test_role_meta_main/ansible_test_role'

# Generated at 2022-06-21 01:20:37.386795
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Create a loader
    loader = DataLoader()
    # Create a variable manager
    variable_manager = VariableManager()

    # Create a new play object
    play = Play.load(dict(
        name='Test Play',
        hosts=['localhost'],
        gather_facts='no',
        # The next line is the test, the RoleMetadata class is used
        roles=[dict(name='test_role', meta='test_meta/main.yml')]
    ), variable_manager=variable_manager, loader=loader)

    #

# Generated at 2022-06-21 01:20:40.295554
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(dict(allow_duplicates=True, dependencies=['foo','bar','baz']))
    assert m.allow_duplicates == True
    assert m.dependencies == ['foo','bar','baz']

# Generated at 2022-06-21 01:20:42.366280
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  m = RoleMetadata()
  m.load()
  pass

# Generated at 2022-06-21 01:20:44.564636
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role(name="dummy")
    role.parse()
    assert role.metadata

# Generated at 2022-06-21 01:20:48.476569
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-21 01:21:43.587726
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.dependencies = [
        {'role': 'name'},
        {'role': 'name', 'version': 'v1'}
    ]
    assert role_metadata.serialize() == {'dependencies': [{'role': 'name'}, {'role': 'name', 'version': 'v1'}]}

# Generated at 2022-06-21 01:21:53.401521
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # test to RoleMetadata.serialize()
    # Return a serialized form of the data in this class.
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = False
    role_meta.dependencies = []
    ansible_module = AnsibleModule(
    argument_spec=dict(),
    supports_check_mode=False
    )
    result =  role_meta.serialize()
    assert result["allow_duplicates"] == False
    assert result["dependencies"] == []

    # test to RoleMetadata.serialize()
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = True
    role_meta.dependencies = ["ansible.rolename"]

# Generated at 2022-06-21 01:22:02.292996
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    from .helpers import load_hashes
    from .loader import DataLoader

    loader = DataLoader()
    hashes = load_hashes(loader)

    play_ds = hashes.copy()
    for k in play_ds.copy():
        if 'meta' not in k:
            del play_ds[k]

    for k,v in play_ds.items():
        owner = object()
        role_metadata = RoleMetadata.load(v, owner)
        assert role_metadata._owner == owner
        assert role_metadata.dependencies == []
        assert role_metadata._galaxy_info is None

# Generated at 2022-06-21 01:22:09.370341
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    got = RoleMetadata().load_data({'allow_duplicates': False, 'dependencies': []}, variable_manager=None, loader=None)
    assert not got._allow_duplicates
    assert got._dependencies == []
    assert got.allow_duplicates == False
    assert got.dependencies == []
    assert not got.galaxy_info
    assert got._galaxy_info == None

# Generated at 2022-06-21 01:22:12.895468
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    meta.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert meta.allow_duplicates is True
    assert meta.dependencies == []

# Generated at 2022-06-21 01:22:15.129013
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    my_role = RoleMetadata('my_role')
    assert(my_role.allow_duplicates == False)
    assert(my_role.dependencies == [])

# Generated at 2022-06-21 01:22:21.207465
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                role="role1",
                scm="git",
                src="/src",
                version="0.1.0")
        ])

    play = Play().load(dict(
        name = "a play",
        hosts = 'test1',
        gather_facts = 'no',
        roles = dict(
            role1 = dict(),
            role2 = dict(),
            role3 = dict(),
        )
    ), variable_manager=None, loader=None)


# Generated at 2022-06-21 01:22:32.014215
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import collection_loader
    from ansible.playbook.role.definition import RoleDefinition

    collection_paths = os.getenv("ANSIBLE_COLLECTIONS_PATHS", "")
    collection_paths_splitted = collection_paths.split(os.pathsep) if collection_paths != "" else []

    # This is a list of one entry to test serialize of RoleMetadata
    role = RoleDefinition()
    role.dname = "myrole"
    role._role_name = "myrole"
    role._role_path = collection_loader.get_role_definition_path(role.dname, collection_paths_splitted, role.collection)

# Generated at 2022-06-21 01:22:37.306645
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata(owner=None)
    role.allow_duplicates = False
    role.dependencies= [1,2,2]
    data = role.serialize()
    assert data == {'allow_duplicates': False, 'dependencies': [1,2,2]}

# unit test for method deserialize of class RoleMetadata

# Generated at 2022-06-21 01:22:38.310396
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: implement
    assert False

# Generated at 2022-06-21 01:23:49.737874
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  #Given
  meta_data = {'allow_duplicates': False,
               'dependencies': []}
  #When
  role_meta = RoleMetadata().deserialize(meta_data)
  #Then
  assert role_meta.allow_duplicates == meta_data['allow_duplicates']
  assert role_meta.dependencies == meta_data['dependencies']

# Generated at 2022-06-21 01:23:57.914562
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.role import RoleInclude

    p = RoleMetadata()
    r = RoleInclude()
    d = {
        'dependencies': [{'role': 'common'}]
    }
    p.load(d, r)

    assert isinstance(r._metadata.dependencies[0], RoleInclude)
    assert isinstance(r._metadata.dependencies[0].role, AnsibleUnicode)
    assert r._metadata.dependencies[0].role == 'common'



# Generated at 2022-06-21 01:24:03.011203
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ra = RoleMetadata()
    ra.allow_duplicates = True
    ra.dependencies = ['1','2','3']
    data = ra.serialize()
    assert data == dict(allow_duplicates=True,dependencies=['1','2','3']), data