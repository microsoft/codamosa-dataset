

# Generated at 2022-06-21 01:14:09.631307
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    setattr(meta, 'allow_duplicates', True)
    setattr(meta, 'dependencies', ['a', 'b'])
    assert meta.serialize() == dict(allow_duplicates=True, dependencies=['a', 'b'])

    meta = RoleMetadata()
    assert meta.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-21 01:14:23.594963
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    collection = loader.load("test_namespace", "test_collection", os.path.dirname(os.path.dirname(__file__)))
    play = {'hosts': 'all', 'roles': []}
    r1 = collection.get_role("test_role_1")
    r2 = collection.get_role("test_role_2")
    r3 = collection.get_role("test_role_3")
    role1 = RoleDefinition.load({'role': "test.role1", 'name': "test_role_1"}, r1, play, loader=loader)


# Generated at 2022-06-21 01:14:26.647123
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'dependencies': ['aa', 'bb', 'cc'],'allow_duplicates': True}
    print(RoleMetadata(None, data))

if __name__ == "__main__":
    test_RoleMetadata_deserialize()

# Generated at 2022-06-21 01:14:34.027893
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Crear Play
    context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='webservers',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)

    # Crear Role
    role_source = dict(
        name="Ejemplo",
        tasks=dict(name="task en sample.yml")
    )
    role = Role().load(role_source, play, variable_manager=None, loader=None)

    # Crear objeto RoleMetadata
    role

# Generated at 2022-06-21 01:14:38.567429
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # setup variables
    test_dependencies=['first-role', 'second-role', 'third-role']
    test_allow_duplicates=True

    test_obj = RoleMetadata(test_allow_duplicates, test_dependencies)

    assert test_obj.serialize == dict(
        allow_duplicates=test_allow_duplicates,
        dependencies=test_dependencies
    )


# Generated at 2022-06-21 01:14:44.103578
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    NewRole = type('NewRole', (object,), {})
    r = NewRole()
    r.name = 'newrole'
    metadata = RoleMetadata()
    RoleMetadata(owner=r)
    metadata.serialize()
    metadata.deserialize({'dependencies': [{'role': 'common'}], 'allow_duplicates': False})

# Generated at 2022-06-21 01:14:48.907283
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r._allow_duplicates = [1,2,3]
    r._dependencies = [1,2,3]
    assert r.serialize() == dict(allow_duplicates=[1,2,3], dependencies=[1,2,3])


# Generated at 2022-06-21 01:15:01.375115
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class TestClass1():
        def __init__(self):
            self.name = 'test_role'
            self.ansible_version = '2.9.9'
            self.min_ansible_version = '2.3'
            self.max_ansible_version = '2.9'

    # Test Case 1: check constructor of RoleMetadata class
    test_role1 = TestClass1()
    meta_data1 = RoleMetadata(owner=test_role1)
    assert meta_data1._owner.name == 'test_role'
    assert meta_data1._owner.ansible_version == '2.9.9'
    assert meta_data1._owner.min_ansible_version == '2.3'

# Generated at 2022-06-21 01:15:03.198785
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    print(r.serialize())


# Generated at 2022-06-21 01:15:04.063380
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-21 01:15:22.962092
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create an object of RoleMetadata
    # the dependencies list is only used for the serialize test.
    role_metadata = RoleMetadata()
    role_metadata.dependencies = ['role1', 'role2', 'role3']
    role_metadata.allow_duplicates = False

    # check that we have a list with 3 role names
    assert role_metadata.dependencies == ['role1', 'role2', 'role3']

    # serialize the object and check that a dict has been returned.
    assert isinstance(role_metadata.serialize(), dict)

# Generated at 2022-06-21 01:15:33.642010
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext

    loader = AnsibleCollectionLoader()

    tasks_file = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'examples', 'collections', 'ansible_collections', 'my_namespace', 'my_collection', 'plugins', 'tasks', 'main.yml')
    tasks = loader.load_from_file(tasks_file)


# Generated at 2022-06-21 01:15:35.062808
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    rm = RoleMetadata()
    assert rm is not None

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-21 01:15:38.293946
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_def = RoleDefinition(None, 'role1', '/path')
    role_metadata = RoleMetadata(role_def)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata._owner == role_def

# Generated at 2022-06-21 01:15:50.012476
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:15:59.257137
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Test creation of RoleMetadata object with full options
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext(variable_manager=variable_manager, loader=None)
    fake_loader = None
    block1 = Block(play=play_context, role=play_context)
   

# Generated at 2022-06-21 01:16:01.356438
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata('name_of_role')
    print (a)

# Generated at 2022-06-21 01:16:11.837744
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_path = "roles/test"
    role_path_owner = "roles/owner"
    variable_manager = None
    loader = None
    owner = RoleInclude(role_path_owner, variable_manager, loader)

# Generated at 2022-06-21 01:16:16.206103
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert type(r._allow_duplicates) == bool
    assert type(r._dependencies) == list
    assert type(r._galaxy_info) == type(None)
    assert type(r._argument_specs) == dict

# Generated at 2022-06-21 01:16:21.890278
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class InvalidOwner:
        pass

    try:
        # Verify that constructor of class RoleMetadata raises an exception if no owner is provided
        r = RoleMetadata()
    except Exception as e:
        assert "owner" in str(e)

    # Verify that constructor of class RoleMetadata raises an exception if an invalid owner is provided
    try:
        r = RoleMetadata(owner=InvalidOwner())
    except Exception as e:
        assert "owner" in str(e)


# Generated at 2022-06-21 01:16:53.878309
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    data = dict(
        allow_duplicates=False,
        dependencies=[
            RoleRequirement(name='common', scm='git', src='git@github.com:user/common.git', version='v0.1.0'),
            RoleRequirement(name='common', scm='git', src='git@github.com:user/common.git', version='v1.2.3')
        ]
    )

# Generated at 2022-06-21 01:17:04.264005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    import ansible.constants
    import os
    target = RoleMetadata()
    current_path = os.path.dirname(os.path.realpath(__file__))
    tmp_directory = os.path.join(current_path, "test_files", "tmp_role_metadata")
    target_metadata = os.path.join(tmp_directory, 'meta', 'main.yml')
    target_dependencies = os.path.join(tmp_directory, 'meta', 'dependencies.yml')
    role = Role.load(path=tmp_directory)
    #testing deserialize

# Generated at 2022-06-21 01:17:06.709957
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    s = RoleMetadata()
    assert s._allow_duplicates == False
    assert s._dependencies == []

# Generated at 2022-06-21 01:17:11.002456
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert not m._allow_duplicates
    assert [] == m._dependencies

# Generated at 2022-06-21 01:17:13.343058
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata(owner=None)
    assert isinstance(r, RoleMetadata)
    assert r._allow_duplicates == False


# Generated at 2022-06-21 01:17:16.603968
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup
    data = {'allow_duplicates': False, 'dependencies': list()}
    # Execute
    r = RoleMetadata()
    r.deserialize(data)
    # Assert
    assert r.allow_duplicates == False
    assert r.dependencies == list()

# Generated at 2022-06-21 01:17:17.631371
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    my_role = RoleMetadata()
    assert my_role != None

# Generated at 2022-06-21 01:17:22.445698
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.taggable import Taggable
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import yaml

    yaml_data1 = '''
- src:   https://github.com/my_user/ansible-role-test
  scm:   git
  version: v1
  name:  my_user.test
'''
    data_list = list(yaml.safe_load(yaml_data1))
   

# Generated at 2022-06-21 01:17:34.643112
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import role_loader
    import datetime as dt

    class MockRoleDefinition(RoleDefinition):
        _role_name = FieldAttribute(isa='string')
        _role_path = FieldAttribute(isa='string')
        _role_collection = FieldAttribute(isa='string')

        def __init__(self, play, role_name, role_path=None, role_collection=None):
            self._role_name = role_name
            self._role_path = role_path
            self._role_collection = role_collection
            super(RoleDefinition, self).__init__(play=play)


# Generated at 2022-06-21 01:17:38.358166
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:18:10.823963
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data=dict(
        allow_duplicates=False,
        dependencies=['apache', 'mysql']
    )
    rolemetad=RoleMetadata()
    rolemetad.deserialize(data)
    assert rolemetad._allow_duplicates==data['allow_duplicates']
    assert rolemetad._dependencies==data['dependencies']

import unittest


# Generated at 2022-06-21 01:18:14.297849
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata(owner=None)
    assert r.name == None
    assert r.ccq_prio == 100
    assert r.allow_duplicates == False

# Generated at 2022-06-21 01:18:21.181317
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    meta_data = RoleMetadata()
    meta_data.allow_duplicates = True
    meta_data.dependencies = [ RoleDefinition(None, {}) ]

    serialized_data = meta_data.serialize()

    assert serialized_data == {
        'allow_duplicates': True,
        'dependencies': [ RoleDefinition(None, {}) ],
    }

# Generated at 2022-06-21 01:18:23.376581
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-21 01:18:29.011743
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    dependency1 = RoleRequirement.load("role1").serialize()
    dependency2 = RoleRequirement.load("role2").serialize()
    role_metadata = RoleMetadata.load(
        {
            'allow_duplicates': False,
            'dependencies': [dependency1, dependency2]
        },
        owner=None
    )
    serialized_role_metadata = role_metadata.serialize()
    deserialized_role_metadata = RoleMetadata.deserialize(serialized_role_metadata)
    assert deserialized_role_metadata['allow_duplicates'] is False
    assert len(deserialized_role_metadata['dependencies']) == 2
    assert deserialized_role_metadata['dependencies'][0]['name'] == dependency1['name']
    assert deserialized_role_metadata

# Generated at 2022-06-21 01:18:33.847056
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    assert role_metadata_obj.serialize() ==  { 'allow_duplicates': False, 'dependencies': [] }
    role_metadata_obj._allow_duplicates = True
    role_metadata_obj._dependencies = ['test']
    assert role_metadata_obj.serialize() ==  { 'allow_duplicates': True, 'dependencies': ['test'] }


# Generated at 2022-06-21 01:18:37.921229
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        RoleMetadata().deserialize({'dependencies': [{'name': 'foo'}]})
        assert False
    except AttributeError as err:
        assert 'has no attribute \'_dependencies\'' in str(err)

# Generated at 2022-06-21 01:18:47.378268
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create a fake ansible.playbook.role.definition.RoleInclude
    # to check the serialization of RoleMetadata._dependencies
    ri = type('RoleInclude', (), {'serialize': dict})
    r1 = ri()
    r2 = ri()
    rm = RoleMetadata()
    # Set initial values
    rm._allow_duplicates = True
    rm._dependencies = [r1, r2]
    serialized_data = rm.serialize()
    assert serialized_data == dict(allow_duplicates=True,
                                   dependencies=dict(dependencies=[dict(dependencies=[])] * 2))



# Generated at 2022-06-21 01:18:57.912270
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    print('Testing RoleMetadata with a single role')
    rd = RoleDefinition.load({ "role": "one", 'name': 'name'}, play=None, variable_manager=None, loader=None)
    rm = RoleMetadata(owner=rd)
    print(rm.serialize())
    print('Testing RoleMetadata with a collection role')
    rd = RoleDefinition.load({ "role": "one", 'name': 'name', 'collection': 'collection'}, play=None,
                             variable_manager=None, loader=None)
    rm = RoleMetadata(owner=rd)
    print(rm.serialize())
    print('Testing RoleMetadata with a loaded dependency')

# Generated at 2022-06-21 01:19:09.692670
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    zst = dict(
        allow_duplicates = False,
        dependencies = [ "foo", "bar" ]
    )
    data = dict(
        allow_duplicates = True,
        dependencies = [ "foo", "bar", "baz", "qux", "quux" ]
    )
    rm = RoleMetadata().deserialize(data)
    assert rm._allow_duplicates == True
    assert rm._dependencies == [ "foo", "bar", "baz", "qux", "quux" ]
    rm = RoleMetadata().deserialize(zst)
    assert rm._allow_duplicates == False
    assert rm._dependencies == [ "foo", "bar" ]

# Generated at 2022-06-21 01:19:39.512282
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test = RoleMetadata()
    test.deserialize({'allow_duplicates': False, 'dependencies': []})

    assert test.allow_duplicates == False
    assert hasattr(test, 'dependencies') == True

# Generated at 2022-06-21 01:19:50.396118
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    rm = RoleMetadata()

    ds = dict({'dependencies': [{'role': 'test_role'}]})
    rm.load_data(ds, variable_manager=None, loader=None)
    assert isinstance(rm._dependencies, list)
    assert isinstance(rm._dependencies[0], RoleInclude)

    rm = RoleMetadata()
    ds = dict({'dependencies': [{'role': 'test_role'}, {'role': 'test_role', 'tasks_from': 'main.yml'}]})
    rm.load_data(ds, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:20:00.982043
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    play = dict(
        name="Ansible Play",
        hosts='hosts',
        gather_facts='no',
        roles=[
        dict(
            name="common",
            tasks=[
                dict(action=dict(module="shell", args="ls"), register="result"),
                dict(action=dict(module="debug", args=dict(msg="{{ result.stdout_lines }}")), when="test_condition")
            ]
        ),
        dict(
            name="test1",
            tasks=[
                dict(action=dict(module="shell", args="ls"), register="result"),
                dict(action=dict(module="debug", args=dict(msg="{{ result.stdout_lines }}")), when="test_condition")
            ]
        )
    ])
    from ansible.playbook import Play

# Generated at 2022-06-21 01:20:09.800363
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import sys
    import imp
    import json
    from ansible.parsing.yaml.loader import AnsibleLoader

    # access to module names used in the unit test
    module_names = ('AnsibleError', 'AnsibleParserError')

    # import modules that are used in the unit test
    for module_name in module_names:
        pathname = os.path.dirname(sys.modules['ansible.module_utils.six'].__file__)
        module = imp.load_source(module_name, os.path.join(pathname, module_name + '.py'))
        sys.modules[module_name] = module

    # populate the global variable: RoleMetadata._ALLOWED_ATTRIBUTES

# Generated at 2022-06-21 01:20:12.309217
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert(r._allow_duplicates == False)
    assert(r._dependencies == [])



# Generated at 2022-06-21 01:20:13.841135
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(owner=None)
    assert role_metadata is not None

# Generated at 2022-06-21 01:20:17.125327
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor of class RoleMetadata
    print("Test constructor of class RoleMetadata")
    obj = RoleMetadata()
    assert obj is not None

# Generated at 2022-06-21 01:20:22.633861
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from collections import namedtuple
    a = namedtuple('a', ['loader'])
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({})
    roleMetadata.deserialize({'allow_duplicates': True})
    roleMetadata.deserialize({'dependencies': []})
    roleMetadata.deserialize({'dependencies': [], 'allow_duplicates': True})

# Generated at 2022-06-21 01:20:25.988408
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # serialize should return a dictionary that is the same
    # as the input to deserialize
    r = RoleMetadata(owner=None)
    d = r.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert d == r.serialize()

# Generated at 2022-06-21 01:20:29.930744
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Returns a new RoleMetadata object based on the datastructure passed in.

    Args:
        data (object): This can be a string, an object, or a dict.

    Returns:
        object: Returns a new RoleMetadata object.

    Raises:
        AnsibleParserError: If datastructure passed in is not a dictionary.
    """
    new_obj = RoleMetadata()

# Generated at 2022-06-21 01:21:01.887214
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata(owner=None)

# Generated at 2022-06-21 01:21:03.826338
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj is not None
    assert obj.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:21:09.502503
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd._allow_duplicates = True
    rmd._dependencies=['foo','bar','baz']
    result = rmd.serialize()
    assert result == {'allow_duplicates': True, 'dependencies': ['foo','bar','baz']}


# Generated at 2022-06-21 01:21:21.403562
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_example_role = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src="http://foo.bar/repo1"
            ),
            dict(
                src="http://foo.bar/repo2"
            ),
            dict(
                src="http://foo.bar/repo3"
            )
        ],
        galaxy_info=dict(
            author="Stewart, John",
            description="",
            company="Foo Bar",
            license="GPLv2",
            min_ansible_version="1.3",
            platforms=[
                dict(
                    name="Ubuntu"
                ),
                dict(
                    name="Redhat"
                )
            ]
        )
    )


# Generated at 2022-06-21 01:21:25.873467
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    a = RoleMetadata()
    a.deserialize({"allow_duplicates": False, "dependencies": []})

    assert a.allow_duplicates == False
    assert a.dependencies == []

    a.deserialize({"allow_duplicates": True, "dependencies": ["a", "b", "c"]})

    assert a.allow_duplicates == True
    assert a.dependencies == ["a", "b", "c"]

# Generated at 2022-06-21 01:21:33.115995
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates' : True,
        'dependencies'     : [{'role':'name'}, {'role':'other'}],
        'galaxy_info'      : {}
    }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies[0]['role'] == 'name'

# Generated at 2022-06-21 01:21:43.618111
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    setattr(m, 'allow_duplicates', True)
    setattr(m, 'dependencies', [{'name': 'test_role',
                                 'role': 'test_role',
                                 'collections': ['col1', 'col2'],
                                 'scm': None,
                                 'src': 'test_role',
                                 'version': None,
                                 'internal': False}])
    serialized = m.serialize()

# Generated at 2022-06-21 01:21:48.737902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    try:
        rm = RoleMetadata(owner=None)
        rm.deserialize({'allow_duplicates': True, 'dependencies': []})
        result = rm.serialize()
        assert result == {'allow_duplicates': True, 'dependencies': []}
    except Exception as e:
        assert False, "serialize test failed: " + str(e)

test_RoleMetadata_serialize()

# Generated at 2022-06-21 01:21:53.284784
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude

    role = RoleMetadata()
    role_include = RoleInclude()
    role_include.serialize({'role': 'test_role'})

    setattr(role, 'dependencies', [role_include])
    role.serialize()

# Generated at 2022-06-21 01:22:03.345411
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'connection': 'local',
        'gather_facts': 'no',
        'roles': [
            {'role': 'test', 'a': 1, 'b': 2},
            {'role': 'ansible.legacy.windows', 'c': 3, 'd': 4},
        ]
    }, variable_manager=variable_manager)


# Generated at 2022-06-21 01:22:43.932491
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = None

    # Create test role metadata
    role_metadata = RoleMetadata(owner)
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['fake-dependency']

    # Serialize the role metadata
    serialized_role_metadata = role_metadata.serialize()

    # Check that serialized role metadata contains the correct data
    assert serialized_role_metadata['allow_duplicates'] == True
    assert serialized_role_metadata['dependencies'] == ['fake-dependency']

# Generated at 2022-06-21 01:22:47.306199
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict()
    role = RoleMetadata(owner=None)
    role.load_data(data)
    assert role.allow_duplicates == False

# Generated at 2022-06-21 01:22:59.141500
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    #Test with good inputs
    test = RoleMetadata()
    test.allow_duplicates = True
    test.dependencies = [
            {'role': 'test1', 'name': 'test1_name', 'version': 'test1_version'},
            {'name': 'test2_name', 'version': 'test2_version'},
            'test3'
            ]
    testdata = test.serialize()
    assert isinstance(testdata, dict)
    assert testdata["allow_duplicates"] == True
    assert isinstance(testdata["dependencies"], list)

# Generated at 2022-06-21 01:23:03.793968
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Testing the method deserialize of class RoleMetadata to ensure that the
    # method works as expected.
    #
    # When deserialize method is called with empty dict the defaults
    # value of allow_duplicates and dependencies are set
    #
    # Return True
    a = RoleMetadata()
    a.deserialize({})
    return a.allow_duplicates == False and not a.dependencies

# Generated at 2022-06-21 01:23:15.142901
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-21 01:23:21.041621
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    assert meta.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )
    meta.allow_duplicates = True
    meta.dependencies = ["foo", "bar"]
    assert meta.serialize() == dict(
        allow_duplicates=True,
        dependencies=["foo", "bar"]
    )


# Generated at 2022-06-21 01:23:24.890609
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_data = dict(
        allow_duplicates=True,
        dependencies=['common', ]
    )
    role_meta = RoleMetadata(owner=None).load_data(test_data)
    assert role_meta.serialize() == test_data

# Generated at 2022-06-21 01:23:35.700593
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    empty_meta_main_yaml = '{"galaxy_info": {}}'
    empty_main = '{"galaxy_info": {"role_name": "test_role"}}'
    empty_main_role = '{"galaxy_info": {"role_name": "test_role"}, "dependencies: [{"role": "test_dependency"}]}'
    empty_main_role_namespace = '{"galaxy_info": {"role_name": "test_role"}, "dependencies: [{"role": "test_dependency", "namespace": "test_namespace"}]}'
    empty_main_role_name = '{"galaxy_info": {"role_name": "test_role"}, "dependencies: [{"name": "test_name"}]}'

    owner_path = '.'
    owner_name = ''
   

# Generated at 2022-06-21 01:23:45.133816
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    data = {
        'name': 'foobar',
        'allow_duplicates': True,
        'dependencies': ['role_0.1', 'role_0.2', 'role_0.3'],
    }
    play = Play.load(data, variable_manager=None, loader=None)
    role_definition = RoleDefinition.load(data, play=play, variable_manager=None, loader=None)
    role_metadata = RoleMetadata(owner=role_definition)
    result = role_metadata.serialize()
    assert result.get('allow_duplicates', False)
    assert len(result.get('dependencies', [])) == 3


# Generated at 2022-06-21 01:23:47.777842
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    # values of instance metadata
    allow_duplicates=False
    dependencies=[]
    assert(metadata.serialize()=={'allow_duplicates':allow_duplicates,'dependencies':dependencies})
