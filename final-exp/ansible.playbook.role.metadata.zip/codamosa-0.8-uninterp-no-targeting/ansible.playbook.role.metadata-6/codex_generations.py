

# Generated at 2022-06-21 01:14:10.099176
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Instantiate the class RoleMetadata
    role_metadata = RoleMetadata()

    # Test the constructor of the class RoleMetadata
    assert role_metadata

    # Test if the class RoleMetadata is a subclass of the class Base
    assert issubclass(RoleMetadata, Base)
    # Test if the class RoleMetadata is a subclass of the class CollectionSearch
    assert issubclass(RoleMetadata, CollectionSearch)

# Generated at 2022-06-21 01:14:10.747095
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:14.914003
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dependencies = [{'role': 'foo'}, {'role': 'bar'}]
    metadata = RoleMetadata(owner=None)
    metadata._dependencies = dependencies
    result = metadata.serialize()
    assert result['dependencies'] == dependencies

# Generated at 2022-06-21 01:14:25.995839
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.plugins.loader import role_loader

    r = Role()
    r._role_path = '/path/to/roles/test_role'
    r.name = 'test_role'
    role_loader.populate_role_mapping(r)

    m = RoleMetadata(owner=r)

    assert m.dependencies == []
    assert m._allow_duplicates == False

    # FIXME: this should probably be done in the base class but it fails
    # to serialize
    assert m._valid_attrs == []
    assert m._ds == None

    m = RoleMetadata()

    assert m.dependencies == []
    assert m._allow_duplicates == False

    # FIXME: this should probably be done in the base class but it

# Generated at 2022-06-21 01:14:31.791503
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    rm.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'test', 'collection': 'test_collection'}]})
    assert rm.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test', 'collection': 'test_collection'}]}

    rm.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert rm.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:14:34.665615
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['first', 'second', 'third']}
    r.deserialize(data)


# Generated at 2022-06-21 01:14:39.502295
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    yaml_dict = dict(
        allow_duplicates=True,
        dependencies=[]
    )

    r = RoleMetadata()
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-21 01:14:49.042253
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Most of the tests of this module are done in the test role.
    This test just ensure load() as implemented in this module
    """
    from ansible.playbook.role_include import RoleInclude

    role = RoleMetadata()

    # Simple role declaration
    role_def = {"role": "role1"}
    assert isinstance(role.load(role_def, None), RoleInclude)

    # New-style role declaration
    role_def = {"role": {"role": "role2"}}
    assert isinstance(role.load(role_def, None), RoleInclude)

    # New-style role declaration with version
    role_def = {"role": {"role": "role3", "version": "1.2.3-5"}}

# Generated at 2022-06-21 01:14:51.248554
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    setattr(self, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(self, 'dependencies', data.get('dependencies', []))


# Generated at 2022-06-21 01:15:03.387112
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # create a fake role
    class FakeRole:
        def __init__(self, role_path):
            self._role_path = role_path

    # create a fake variable manager
    class FakeVariableManager:
        def __init__(self):
            self.extra_vars = dict()
            self.vars_cache = dict()
            self.fail_on_undefined_vars = False

        def set_fail_on_undefined_vars(self, fail_bool):
            self.fail_on_undefined_vars = fail_bool

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return dict()

        def get_host_vars(self, host):
            return dict()


# Generated at 2022-06-21 01:15:15.411081
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-21 01:15:19.219857
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert r._allow_duplicates == False
    assert r._dependencies == []

# Generated at 2022-06-21 01:15:30.731005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    class Play(object):
        pass

    class Role(object):
        def __init__(self, name, current_role_path, collection_search_list, variable_manager, loader, play):
            self.name = name
            self._role_path = current_role_path
            self.collections = collection_search_list
            self.variable_manager = variable_manager
            self._loader = loader
            self._play = play

    class MockRole(Role):
        current_role_path = ''
        collection_search_list = None
        variable_manager = None
        loader = None
        play = None


# Generated at 2022-06-21 01:15:34.928870
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = list()

    expected_result = {
        'allow_duplicates': True,
        'dependencies': list(),
    }

    result = role_metadata.serialize()

    assert result == expected_result


# Generated at 2022-06-21 01:15:39.939160
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    module = RoleMetadata()
    module._allow_duplicates = False
    r1 = RoleDefinition()
    r1._role_name = 'common'
    r1._role_collections = []
    list1 = []
    list1.append(r1)
    module._dependencies = list1
    res = module.serialize()
    assert(res.get('allow_duplicates') == False)
    assert(res.get('dependencies') == list1)

# Generated at 2022-06-21 01:15:47.587427
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta.allow_duplicates = True
    meta.dependencies = [
        {'role': 'common', 'name': 'common'},
        {'role': 'web', 'name': 'web'}
    ]
    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'common', 'name': 'common'}, {'role': 'web', 'name': 'web'}]}


# Generated at 2022-06-21 01:15:56.383582
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():  # noqa
    # Load data
    data = dict(dependencies=[
        dict(src='https://galaxy.ansible.com/apache/httpd', name='httpd', version='1.0.0')
    ], allow_duplicates=False)

    # Init
    role = dict(name='common')

    # Create RoleMetadata object
    role_metadata = RoleMetadata(owner=role)

    # Deserialize
    role_metadata.deserialize(data)

    # Assert result
    assert role_metadata.allow_duplicates == data.get('allow_duplicates', False)
    assert role_metadata.dependencies == data.get('dependencies', [])

# Generated at 2022-06-21 01:16:03.767200
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._owner = 'fake_owner'
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = ['fake_dependencies']

    expected_result = {
        'allow_duplicates': False,
        'dependencies': ['fake_dependencies']
    }

    assert role_metadata.serialize() == expected_result

# Generated at 2022-06-21 01:16:09.897266
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata( owner=None )

    assert not hasattr(a, 'allow_duplicates')
    assert not hasattr(a, 'dependencies')

    data = {
        'allow_duplicates': 'a',
        'dependencies': 'b'
    }

    a.deserialize(data)

    assert a._allow_duplicates == 'a'
    assert a._dependencies == 'b'

# Generated at 2022-06-21 01:16:13.874773
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata._allow_duplicates = True
    metadata._dependencies = ['foo', 'bar']
    assert metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}

# Generated at 2022-06-21 01:16:24.716135
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True})
    assert role_metadata.allow_duplicates is True

    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': ['role_one', 'role_two']})
    assert len(role_metadata.dependencies) == 2

# Generated at 2022-06-21 01:16:32.484705
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition.load({'name': 'role_name'}, create_role=True, role_path='unit_test/roles/role_name')
    role_metadata = RoleMetadata.load({'allow_duplicates': True}, owner=role)
    assert role_metadata and isinstance(role_metadata, RoleMetadata)

# Generated at 2022-06-21 01:16:33.544741
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # test deserialize
    assert True == False

# Generated at 2022-06-21 01:16:42.465009
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    fake_loader = object()
    role_metadata = RoleMetadata.load({u'dependencies': [{u'src': u'geerlingguy.java'}]},
                                      owner=RoleInclude.load({u'name': u'geerlingguy.java'}, loader=fake_loader))
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata._owner, RoleInclude)
    assert isinstance(role_metadata._dependencies[0], RoleInclude)
    assert role_metadata._dependencies[0].name == 'geerlingguy.java'
    assert role_metadata._dependencies[0]._loader is fake_loader

# Generated at 2022-06-21 01:16:53.922507
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Owner:
        def __init__(self, path):
            self._role_path = path

    owner = Owner('/root/role/path')
    # Test 1: meta/main.yml is not a dictionary
    try:
        data = 'test'
        RoleMetadata.load(data, owner)
    except AnsibleParserError as e:
        print(e.message)
    else:
        raise Exception('Expected AnsibleParserError exception')

    # Test 2: A malformed list of role dependencies was encountered.
    try:
        data = dict(
            dependencies=['test', 'test']
        )
        RoleMetadata.load(data, owner)
    except AnsibleParserError as e:
        print(e.message)
    else:
        raise Exception('Expected AnsibleParserError exception')

   

# Generated at 2022-06-21 01:17:04.264666
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a simple RoleMetadata object
    # test_id = 0
    # test_str_att = "A test string"
    # test_bool_att = True
    # test_list_att = ['1','2','3']
    # test_dict_att = {1:1, 2:2, 3:3}
    # test_obj_att = Base()
    # test_obj_att.set_initial_data(test_id, test_str_att, test_bool_att, test_list_att, test_dict_att)
    # test_obj = RoleMetadata()
    # test_obj.set_initial_data(test_id, test_str_att, test_bool_att, test_list_att, test_dict_att, test_obj_att)
    return

# Generated at 2022-06-21 01:17:08.016397
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    result = role_metadata.deserialize(data)
    assert result is None

# Generated at 2022-06-21 01:17:12.488667
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data1 = {'allow_duplicates': True, 'dependencies': ['foo']}

    m1 = RoleMetadata()
    m1.deserialize(data1)

    assert m1._allow_duplicates == True
    assert m1._dependencies == ['foo']

# Generated at 2022-06-21 01:17:19.848923
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:17:24.533887
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a._galaxy_info = {'fake':'fake'}
    a._dependencies = [{'fake':'fake'}]

    assert a.serialize() == dict(
        allow_duplicates=False,
        dependencies=[{'fake':'fake'}],
    )

# Generated at 2022-06-21 01:17:39.352238
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = False
    m.dependencies = ['a', 'b', 'c']
    data = m.serialize()

    # because the serialization is in the format of a dictionary and in
    # the format of a YAML, there is no way to get an exact match
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == ['a', 'b', 'c']

# Generated at 2022-06-21 01:17:41.693852
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().data ==  {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:17:49.272446
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Setup
    owner = 'owner'
    allow_duplicates = False
    dependencies = 'dependencies'
    data = {
        'allow_duplicates': allow_duplicates,
        'dependencies': dependencies
    }
    # Test
    role_metadata = RoleMetadata.load(data=data, owner=owner)
    role_metadata.serialize()
    # assert
    # Cleanup - none necessary
    return {
        'role_metadata': role_metadata,
        'owner': owner,
        'allow_duplicates': allow_duplicates,
        'dependencies': dependencies
    }

# Generated at 2022-06-21 01:17:58.712734
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class Role:
        def __init__(self):
            self._role_path = ''
            self._play = 'play2'
            self._role_collection = 'role_collection'
            self.collections = ['ansible.legacy', 'f5networks.f5_modules']

    class Play:
        def __init__(self):
            self._variable_manager = 'variable_manager2'
            self._loader = 'loader2'

    class VariableManager:
        def __init__(self):
            self._fact_cache = 'fact_cache'

    rm = RoleMetadata()


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:18:07.828117
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'Common'},
            {'role': 'Webservers'},
            {'role': 'Database'}
        ]
    })
    assert role_metadata.allow_duplicates is True
    assert len(role_metadata.dependencies) == 3
    assert role_metadata.dependencies[0].role == 'Common'
    assert role_metadata.dependencies[1].role == 'Webservers'
    assert role_metadata.dependencies[2].role == 'Database'


# Generated at 2022-06-21 01:18:10.668239
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    m = RoleMetadata()
    m.deserialize(data)

    assert data == m.serialize()

# Generated at 2022-06-21 01:18:11.625653
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise Exception("Not implemented")

# Generated at 2022-06-21 01:18:18.077657
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    foo = RoleMetadata()
    foo.allow_duplicates = True
    foo.dependencies = [{'role': 'example.foo', 'name': 'foo'}]
    assert foo.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'example.foo', 'name': 'foo'}]}


# Generated at 2022-06-21 01:18:21.556479
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = []
    role_metadata._galaxy_info = None
    role_metadata._argument_specs = None
    expected = {'allow_duplicates': False, 'dependencies': []}
    print("Expecting: ", expected)
    actual = role_metadata.serialize()
    print("Actual: ", actual)
    assert expected == actual, "test_RoleMetadata_deserialize failed"


# Generated at 2022-06-21 01:18:29.644659
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Setup test data
    owner = RoleRequirement()
    owner.name = 'testOwnerName'
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )

    # Initialize class
    roleMetadata = RoleMetadata()
    roleMetadata.allow_duplicates = data.get('allow_duplicates', False)
    roleMetadata.dependencies = data.get('dependencies', [])
    roleMetadata._owner = owner

    # Test assertion(s)
    assert roleMetadata._owner.name == data.get('name')

# Generated at 2022-06-21 01:19:00.188994
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.context_objects import AnsibleContext
    # Create fake data structure
    owner_data = {
      'name': 'test-name',
      '_role_path': 'test-path',
      '_role_collection': 'test-coll',
      'collections': [],
      '_play': 'test-play'
    }
    variable_manager_data = {
      '_extra_vars': 'test-var',
      '_options': 'test-opt',
      '_fact_cache': 'test-cache',
      '_extra_vars_files': [],
      '_play': 'test-play'
    }

# Generated at 2022-06-21 01:19:10.133597
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    m = RoleMetadata(owner=RoleDefinition.load("geerlingguy.java", "geerlingguy.java", "galaxy.role", "geerlingguy.galaxy", "geerlingguy.galaxy"))
    assert isinstance(m, RoleMetadata)
    m.load({"name": "geerlingguy.java"}, m._owner)
    assert isinstance(m, RoleMetadata)
    m.load({"dependencies": [{"role": "geerlingguy.java"}]}, m._owner)
    assert isinstance(m, RoleMetadata)


# Generated at 2022-06-21 01:19:17.764238
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    def test_func(objects):
        for o in objects:
            r = RoleMetadata()
            r.deserialize(o)
            assert type(r.allow_duplicates) is bool
            assert type(r.dependencies) is list

    objects = [
        {'allow_duplicates': False,
         'dependencies': []},
        {'allow_duplicates': False,
         'dependencies': ['foo']},
        {'allow_duplicates': True,
         'dependencies': []}
    ]
    test_func(objects)

# Generated at 2022-06-21 01:19:19.524337
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-21 01:19:22.971290
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import pytest
    from ansible.playbook.role.metadata import RoleMetadata

    role_metadata = RoleMetadata(owner=None)
    data = dict()

    data['allow_duplicates'] = True
    data['dependencies'] = ['name']

    role_metadata.deserialize(data=data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['name']

# Generated at 2022-06-21 01:19:35.066592
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

    # Test with a metadata file that is not a dict
    data = "test"
    owner = RoleDefinition("/foo/bar", "test")
    variable_manager = None
    loader = None
    with pytest.raises(AnsibleParserError) as exc:
        # load method under test
        RoleMetadata.load(data, owner, variable_manager, loader)
    expected_msg = "the 'meta/main.yml' for role test is not a dictionary"
    assert str(exc.value) == expected_msg

    # Test with a metadata file that is a dict with invalid key

# Generated at 2022-06-21 01:19:43.341009
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    task_name = 'meta/main.yml'
    task_data = {'dependencies': [{'role': 'common'}]}
    current_role_path = '/home/vagrant/roles'
    collection_search_list = ['ansible.posix']
    metadata = RoleMetadata.load(task_data, None, None, None)
    dependencies = load_list_of_roles(
        metadata._dependencies, current_role_path, None, None, collection_search_list, None)
    assert len(dependencies) == 1
    assert task_name == dependencies[0]._task_name
    assert task_data == dependencies[0]._task_data

# Generated at 2022-06-21 01:19:46.443714
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata('test')
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-21 01:19:47.528667
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    x = RoleMetadata()
    assert x != None

# Generated at 2022-06-21 01:19:57.570862
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    variables = dict()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(variables)
    loader = DataLoader()

    # json_string defined in json_string.py
    from json_string import json_string
    data = json_string
    m = RoleMetadata()
    m.variable_manager = variable_manager
    m.loader = loader
    m.deserialize(data)

    assert m._allow_duplicates == False
    assert m._dependencies == ['paulo-santos.arangodb']
    assert m._galaxy_info is None
    assert m._argument_specs is None
    assert m.plugin_type == 'role'


# Generated at 2022-06-21 01:20:23.144991
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    constructor test
    '''
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-21 01:20:27.371005
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    r = ansible.playbook.role.definition.RoleDefinition()
    r.name='redis'
    r1=RoleMetadata(owner=r)
    r2=RoleMetadata(owner=r)
    r1.deserialize(r2.serialize())

# Generated at 2022-06-21 01:20:37.244890
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )
    assert RoleMetadata('/path/to/my/role').serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )
    assert RoleMetadata().deserialize(dict(
        allow_duplicates=True,
        dependencies=[dict(role='foo', name='bar')],
    )).serialize() == dict(
        allow_duplicates=True,
        dependencies=[dict(role='foo', name='bar')],
    )

# Generated at 2022-06-21 01:20:42.609965
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict()
    m.deserialize(data)
    assert m._allow_duplicates == False
    assert m._dependencies == []
    data = dict(allow_duplicates=True)
    m.deserialize(data)
    assert m._allow_duplicates == True
    data = dict(allow_duplicates=True, dependencies=['test'])
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert m._dependencies == ['test']

# unit test for method serialize of class RoleMetadata

# Generated at 2022-06-21 01:20:44.885152
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-21 01:20:56.458004
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # we import here to prevent import cycles
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 3

    # input data
    ds_0 = {'dependencies': [{'role': 'ansible.builtin', 'collections': ['ansible.posix']}]}
    collection_search_list = ['foo']

    # expected output
    expected_0 = RoleMetadata.load(ds_0, owner=Role(), collection_search_list=collection_search_list)
    assert str(expected_0.dependencies[0]) == "ansible.builtin,{'collections': ['ansible.posix']}"

# Generated at 2022-06-21 01:21:06.135201
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import define_role_template
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = dict(
        dependencies=[
            dict(src='/path/to/role1', name='role1', version='v1')
        ]
    )

    ds_legacy = dict(
        dependencies=[
            '/path/to/role1'
        ]
    )

    role_definition = define_role_template(
        role_directory='/path/to/test_role',
        role_name='test_role',
        parent_role=None,
        loader=DataLoader(),
        variable_manager=VariableManager()
    )

    rm

# Generated at 2022-06-21 01:21:11.687948
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    v1 = r.serialize()
    ref = {'dependencies': list()}
    assert v1 == ref
    r.allow_duplicates = True
    r.dependencies = list()
    v2 = r.serialize()
    ref = {'allow_duplicates': True, 'dependencies': list()}
    assert v2 == ref


# Generated at 2022-06-21 01:21:14.624756
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({"dependencies":[{"role":"toto"}]})
    assert m.dependencies[0] == {"role":"toto"}

# Generated at 2022-06-21 01:21:21.352711
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'dependencies': [
            {
                'role': 'a.b.c',
                'name': 'a',
                'version': '1.0.0'
            }
        ],
        'allow_duplicates': False
    }
    result = RoleMetadata(owner=None).deserialize(data=data)
    assert 'a.b.c' in result.dependencies

# Generated at 2022-06-21 01:22:18.620503
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    RoleMetadata_data = {
        "allow_duplicates": True,
        "dependencies": [
            {
                "role": "geerlingguy.java"
            },
            {
                "role": "geerlingguy.jenkins"
            }
        ]
    }
    RoleMetadata_instance = RoleMetadata(owner=None)
    RoleMetadata_instance.load_data(RoleMetadata_data, variable_manager=None, loader=None)
    expected_value = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'geerlingguy.java'
            },
            {
                'role': 'geerlingguy.jenkins'
            }
        ]
    }
    assert RoleMetadata_instance.serialize() == expected

# Generated at 2022-06-21 01:22:29.737071
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import os
    import sys
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(test_dir + "/../")
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    data = {'dependencies': ['../../test/ansible_collections/test_namespace/test_collection/roles/test_role', '../../test/ansible_collections/test_namespace2/test_collection2/roles/test_role2', '../../test/ansible_collections/test_namespace3/test_collection3/roles/test_role3']}

# Generated at 2022-06-21 01:22:33.460693
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates='False',
        dependencies='[]'
    )

    rolemetadata = RoleMetadata()
    rolemetadata.deserialize(data)
    assert rolemetadata.allow_duplicates
    assert rolemetadata.dependencies == data['dependencies']

# Generated at 2022-06-21 01:22:37.348016
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": False, "dependencies": []})
    assert role_metadata.serialize() == {"allow_duplicates": False, "dependencies": []}

# Generated at 2022-06-21 01:22:41.473267
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test the constructor
    # Expected behavior: the constructor should return an object of class RoleMetadata
    test_metadata = RoleMetadata()
    assert isinstance(test_metadata, RoleMetadata)
    assert test_metadata._allow_duplicates == False
    assert test_metadata._dependencies == []
    assert not test_metadata._galaxy_info

# Generated at 2022-06-21 01:22:44.437788
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ["test_dep"]

    result = role_metadata.serialize()
    assert result["allow_duplicates"] is True
    assert result["dependencies"][0] == "test_dep"


# Generated at 2022-06-21 01:22:56.640229
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import yaml
    class Playbook:
        def __init__(self, hosts, roles, name):
            self.hosts = hosts
            self.roles = roles
            self.name = name

    class Role:
        def __init__(self, _role_path='', _role_name='role_name'):
            self._role_path = _role_path
            self._role_name = _role_name

    class GalaxyInfo:
        def __init__(self, namespace, name, description, version, author, min_ansible_version):
            self.namespace = namespace
            self.name = name
            self.description = description
            self.version = version
            self.author = author
            self.min_ansible_version = min_ansible_version



# Generated at 2022-06-21 01:23:03.446498
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    data = {u'allow_duplicates': False,
            u'dependencies': []}
    pc = PlayContext()
    pc.prompt = None
    r = RoleMetadata()
    templar = Templar(loader=None, variables=None, shared_loader_obj=None)
    result = r.load(data=data, owner=None, variable_manager=None, loader=None)
    assert result is not None

# Generated at 2022-06-21 01:23:14.659864
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rt = RoleMetadata()
    data = {
        'allow_duplicates': 'True',
        'dependencies': "Dependencies"
    }
    rt.deserialize(data)
    if rt.allow_duplicates != True:
        raise AssertionError("test_RoleMetadata_deserialize  failed")
    if rt.dependencies != "Dependencies":
        raise AssertionError("test_RoleMetadata_deserialize  failed")
    data = {
        'allow_duplicates': False,
        'dependencies': "Dependencies"
    }
    rt.deserialize(data)
    if rt.allow_duplicates != False:
        raise AssertionError("test_RoleMetadata_deserialize  failed")

test_RoleMet

# Generated at 2022-06-21 01:23:21.289708
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_instance = RoleMetadata()
    test_instance._allow_duplicates = False
    test_instance._dependencies = [{u'name': u'Foo'}, {u'name': u'Bar'}]

    expected_deserialize = {'allow_duplicates': False, 'dependencies': [{u'name': u'Foo'}, {u'name': u'Bar'}]}
    assert test_instance.serialize() == expected_deserialize