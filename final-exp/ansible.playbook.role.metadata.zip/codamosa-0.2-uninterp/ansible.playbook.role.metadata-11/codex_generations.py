

# Generated at 2022-06-17 07:56:51.547272
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.file_dependency import RoleFileDependency
    from ansible.playbook.role.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 07:57:00.039718
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata

    # Create a RoleDefinition object
    role_definition = RoleDefinition()
    role_definition._role_name = 'test_role'
    role_definition._role_path = '/path/to/role'

    # Create a RoleInclude object
    role_include = RoleInclude()
    role_include._role_name = 'test_role'
    role_include._role_path = '/path/to/role'

    # Create a RoleRequirement object
    role_requirement = RoleRequirement()
    role_requirement._role_name = 'test_role'

# Generated at 2022-06-17 07:57:09.844054
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:57:21.861864
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_def = RoleDefinition.load({'name': 'test_role'}, None)
    role_inc = RoleInclude.load({'role': 'test_role'}, None)
    role_req = RoleRequirement.load({'role': 'test_role'}, None)

    role_meta = RoleMetadata(owner=role_def)
    role_meta.dependencies = [role_inc, role_req]
    role_meta.allow_duplicates = True

    serialized_data = role_meta.serialize()
    assert serialized_data['allow_duplicates'] == True
    assert serialized_data

# Generated at 2022-06-17 07:57:27.289758
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:57:38.247013
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collectionsearch import CollectionSearch
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 07:57:43.300509
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:57:49.273549
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['test']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['test']}


# Generated at 2022-06-17 07:57:58.078689
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    role_def = RoleDefinition()
    role_def._role_path = '/path/to/role'
    role_def._role_name = 'role_name'
    role_def._role_collection = None

    role_req = RoleRequirement()
    role_req._role_name = 'role_name'
    role_req._role_path = '/path/to/role'
    role_req._role_collection = None

    role_inc = RoleInclude()
    role_inc._role_name = 'role_name'
    role_inc._

# Generated at 2022-06-17 07:58:08.822089
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 07:58:22.273773
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:33.192894
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_task import RoleCollectionTask
    from ansible.playbook.role.collection_vars import RoleCollectionVars
    from ansible.playbook.role.collection_defaults import RoleCollectionDefaults

    # test with a role definition
    role_definition = RoleDefinition()
    role_definition._role_path = '/path/to/role'
    role_definition._role

# Generated at 2022-06-17 07:58:35.736966
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_def = RoleDefinition.load({'name': 'test'})
    role_meta = RoleMetadata(owner=role_def)
    assert role_meta._owner == role_def
    assert role_meta._allow_duplicates == False
    assert role_meta._dependencies == []
    assert role_meta._galaxy_info == None
    assert role_meta._argument_specs == {}

# Generated at 2022-06-17 07:58:41.455077
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner == role


# Generated at 2022-06-17 07:58:53.107891
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:58:55.375167
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 07:59:03.820784
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.when import TaskWhen
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.task import TaskVars

# Generated at 2022-06-17 07:59:11.385566
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # create a role definition
    role_def = RoleDefinition()
    role_def._role_name = 'test_role'
    role_def._role_path = '/tmp/test_role'

    # create a variable manager
    variable_manager = VariableManager()
    loader

# Generated at 2022-06-17 07:59:16.681713
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create a RoleMetadata object
    role_metadata = RoleMetadata()

    # Set the attributes
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['role1', 'role2']

    # Serialize the object
    serialized_role_metadata = role_metadata.serialize()

    # Check the result
    assert serialized_role_metadata['allow_duplicates'] == True
    assert serialized_role_metadata['dependencies'] == ['role1', 'role2']

# Generated at 2022-06-17 07:59:24.117341
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:59:47.046666
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    # Test for empty data
    data = {}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test for data with allow_duplicates and dependencies

# Generated at 2022-06-17 07:59:58.358578
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude
    from ansible.playbook.role.collection import RoleCollectionImport
    from ansible.playbook.role.collection import RoleCollection

# Generated at 2022-06-17 08:00:02.101073
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r.name = 'test'
    r.path = '/tmp/test'
    r.metadata = RoleMetadata(owner=r)
    assert r.metadata.allow_duplicates == False
    assert r.metadata.dependencies == []

# Generated at 2022-06-17 08:00:14.991304
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:00:22.121413
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 08:00:30.952242
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collectionsearch import CollectionSearch
    from ansible.playbook.role.collectionsearch import CollectionSearchList
    from ansible.playbook.role.collectionsearch import CollectionSearchEntry

# Generated at 2022-06-17 08:00:37.906089
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 08:00:47.105197
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-17 08:00:56.346658
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.block import BlockInclude
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 08:01:01.289067
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:01:35.676032
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.galaxy_info import GalaxyInfo
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleTasks
    from ansible.playbook.role.handlers import RoleHandlers
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.files import RoleFiles
   

# Generated at 2022-06-17 08:01:43.495066
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_task import RoleCollectionTask
    from ansible.playbook.role.collection_handler import RoleCollectionHandler


# Generated at 2022-06-17 08:01:52.939933
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test with empty data
    data = {}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test with data
    data = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:01:59.129668
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role.role_path = '/tmp'
    role.metadata = RoleMetadata(owner=role)
    assert role.metadata._owner == role
    assert role.metadata._allow_duplicates == False
    assert role.metadata._dependencies == []
    assert role.metadata._galaxy_info == None
    assert role.metadata._argument_specs == {}

# Generated at 2022-06-17 08:02:02.189958
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:02:11.003335
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.context import RoleContext
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.task_include import TaskIncludeArgs

# Generated at 2022-06-17 08:02:18.825323
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersion
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersionDependency
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersionDependencyRequirement

# Generated at 2022-06-17 08:02:28.087263
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role = Role()
    role._role_path = '/path/to/role'
    role._role_collection = None
    role._play = None
    role._variable_manager = None
    role._loader = None


# Generated at 2022-06-17 08:02:30.775869
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:02:36.515368
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['role1', 'role2']))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:03:37.706796
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.search import RoleSearch
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.task import TaskVars
    from ansible.playbook.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-17 08:03:45.657252
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude

    # test RoleMetadata.load()
    # test RoleMetadata.load() with a role
    # test RoleMetadata.load() with a role and a variable_

# Generated at 2022-06-17 08:03:50.918156
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['test']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['test']}


# Generated at 2022-06-17 08:04:01.258613
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'test'}]})
    assert role_metadata.allow_duplicates is True
    assert isinstance(role_metadata.dependencies[0], RoleRequirement)
    assert role_metadata.dependencies[0].role == 'test'
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'test', 'name': 'test'}]})
    assert role_metadata.allow_duplicates is True

# Generated at 2022-06-17 08:04:11.814263
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 08:04:23.576567
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude

    # Test 1
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test 2

# Generated at 2022-06-17 08:04:30.826256
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r._role_path = './'
    r._role_name = 'test'
    r._role_collection = None
    r._play = None
    r._collections = []
    r._variable_manager = None
    r._loader = None
    r._metadata = RoleMetadata.load({}, r)
    assert r._metadata._owner == r

# Generated at 2022-06-17 08:04:41.058317
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role_def = RoleDefinition.load(dict(name='test_role_name'), play=None)
    role_req = RoleRequirement.load(dict(role='test_role_name'), play=None)
    role_metadata = RoleMetadata(owner=role_def)
    role_metadata._dependencies = [role_req]
    serialized_data = role_metadata.serialize()
    assert serialized_data == dict(
        allow_duplicates=False,
        dependencies=[dict(role='test_role_name')]
    )

# Generated at 2022-06-17 08:04:44.262127
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test_role'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}

# Generated at 2022-06-17 08:04:48.269751
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}
