

# Generated at 2022-06-17 07:56:46.917592
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:56:50.416636
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:56:53.837747
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test with a valid role
    role = RoleMetadata()
    assert role is not None

    # Test with an invalid role
    try:
        role = RoleMetadata(owner=None)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-17 07:57:03.397108
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult

# Generated at 2022-06-17 07:57:10.314141
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    role_metadata = RoleMetadata()
    # Create a dictionary
    data = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    # Call method deserialize of class RoleMetadata
    role_metadata.deserialize(data)
    # Check if the attribute allow_duplicates is True
    assert role_metadata.allow_duplicates == True
    # Check if the attribute dependencies is ['role1', 'role2']
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:57:16.852254
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r.name = 'test'
    r.path = '/tmp/test'
    m = RoleMetadata(owner=r)
    assert m._owner == r
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None
    assert m._argument_specs == {}

# Generated at 2022-06-17 07:57:28.547710
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.action import TaskAction
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
   

# Generated at 2022-06-17 07:57:37.773295
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:57:47.098802
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collectionsearch import CollectionSearch
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.role.file import RoleFile

# Generated at 2022-06-17 07:57:57.496689
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude
    from ansible.playbook.role.collection import RoleCollectionImport
    from ansible.playbook.role.collection import RoleCollectionScenario
    from ansible.playbook.role.collection import RoleCollectionDependency

    # Test constructor of class RoleMetadata
    role_metadata = RoleMetadata()

# Generated at 2022-06-17 07:58:14.414214
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import Play

# Generated at 2022-06-17 07:58:21.361469
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:58:27.733469
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 07:58:31.997998
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:44.770984
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:58:54.140011
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-17 07:59:02.658729
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.meta import GalaxyInfo
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-17 07:59:10.644345
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:59:16.979315
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test_role'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}


# Generated at 2022-06-17 07:59:29.474549
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.tasks import Task
    from ansible.playbook.role.tasks import Tasks

# Generated at 2022-06-17 07:59:47.523200
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 07:59:53.505477
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 07:59:58.109805
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 08:00:06.044084
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.collection_include import RoleCollectionInclude

    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'foo'}, {'role': 'bar'}]})
    assert m.allow_duplicates is True
    assert len(m.dependencies) == 2
    assert isinstance(m.dependencies[0], RoleInclude)
    assert isinstance(m.dependencies[1], RoleInclude)
    assert m.dependencies[0].role == 'foo'

# Generated at 2022-06-17 08:00:18.471021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.name import RoleName
    from ansible.playbook.role.path import RolePath
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play import Play

# Generated at 2022-06-17 08:00:28.043351
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude
    from ansible.playbook.role.collection import RoleCollectionImport

# Generated at 2022-06-17 08:00:40.566508
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play

    # Create a play
    play = Play()

    # Create a role definition
    role_definition = RoleDefinition()
    role_definition._role_path = '/home/user/ansible/roles/test'
    role_definition._role_name = 'test'

    # Create a role metadata
    role_metadata = RoleMetadata()
    role_metadata._owner = role_definition

    # Create a role requirement
    role_requirement = RoleRequirement()
    role_requirement._role_name = 'test'

# Generated at 2022-06-17 08:00:48.231702
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    # Create a RoleDefinition object
    role_def = RoleDefinition()
    role_def._role_name = 'test_role'
    role_def._role_path = '/path/to/test_role'

    # Create a RoleRequirement object
    role_req = RoleRequirement()
    role_req._role_name = 'test_role'
    role_req._role_path = '/path/to/test_role'

    # Create a RoleInclude object
    role_inc = RoleInclude()

# Generated at 2022-06-17 08:00:52.944855
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:01:02.634005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    # test load with empty data
    m = RoleMetadata.load({}, None)
    assert m._allow_duplicates == False
    assert m._dependencies == []

    # test load with data
    m = RoleMetadata.load({'allow_duplicates': True, 'dependencies': ['role1', 'role2']}, None)
    assert m._allow_duplicates == True
    assert len(m._dependencies) == 2
    assert isinstance(m._dependencies[0], RoleRequirement)
    assert isinstance(m._dependencies[1], RoleRequirement)

    # test load with data

# Generated at 2022-06-17 08:01:35.677636
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple role definition
    role_def = {'role': 'test_role'}
    role_metadata = RoleMetadata.load(role_def, owner=None)
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata._dependencies[0], RoleDefinition)
    assert role_metadata._dependencies[0]._role_name == 'test_role'

    # Test with a role definition with a version
    role_def = {'role': 'test_role', 'version': '1.0'}
    role_metadata = RoleMetadata.load(role_def, owner=None)
    assert isinstance(role_metadata, RoleMetadata)

# Generated at 2022-06-17 08:01:39.938297
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    # Test with a simple dictionary
    data = dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2']
    )
    role_metadata = RoleMetadata.load(data, owner=None)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ['role1', 'role2']

    # Test with a dictionary with a list of RoleRequirement objects

# Generated at 2022-06-17 08:01:46.906901
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 08:01:54.709800
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple role definition
    role_def = {'role': 'test'}
    role_metadata = RoleMetadata.load(role_def, RoleDefinition())
    assert role_metadata.dependencies == [RoleRequirement.role_yaml_parse(role_def)]

    # Test with a complex role definition
    role_def = {'role': 'test', 'version': '1.0', 'name': 'test', 'src': 'test'}
    role_metadata = RoleMetadata.load(role_def, RoleDefinition())
    assert role_metadata.dependencies == [RoleRequirement.role_yaml_parse(role_def)]

    # Test with a list of role definitions
   

# Generated at 2022-06-17 08:02:03.884530
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFile
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFileRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFileRequirementSpec

# Generated at 2022-06-17 08:02:16.544973
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.role.include import IncludeRole

# Generated at 2022-06-17 08:02:29.713328
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude

# Generated at 2022-06-17 08:02:35.499328
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    ))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:02:43.389731
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader

    # Create a fake play
    play = Play()
    play._loader = get_plugin_

# Generated at 2022-06-17 08:02:50.576625
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 08:03:54.511262
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.vars.hostvars import HostVars

# Generated at 2022-06-17 08:03:57.968904
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert r.allow_duplicates == True
    assert r.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:04:03.575106
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:04:12.589493
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.defaults import RoleDefault

# Generated at 2022-06-17 08:04:19.149692
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 08:04:31.940802
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:04:42.922172
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.requirement import RoleRequirement

    # Test 1: Test the constructor of class RoleMetadata
    # Create a role object
    role = Role()
    # Create a role definition object
    role_definition = RoleDefinition()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    #

# Generated at 2022-06-17 08:04:52.324404
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch

    # Create a role definition
    role_definition = RoleDefinition()
    role_definition._role_name = 'test_role'
    role_definition._role_path = '/tmp/test_role'
    role

# Generated at 2022-06-17 08:04:59.657126
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test_role'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}

# Generated at 2022-06-17 08:05:14.429410
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy_info import GalaxyInfo
