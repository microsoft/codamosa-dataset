

# Generated at 2022-06-17 07:56:51.566360
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_include import RoleCollectionInclude

# Generated at 2022-06-17 07:56:58.291930
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple dictionary

# Generated at 2022-06-17 07:57:09.078074
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRoleInclude

# Generated at 2022-06-17 07:57:15.524891
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:57:25.572797
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='test_role',
                src='/path/to/test_role',
                scm='git',
                version='v1.0.0',
                path='/path/to/test_role'
            )
        ]
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m.serialize() == data

# Generated at 2022-06-17 07:57:34.381018
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple dictionary
    data = {'dependencies': [{'role': 'test_role_1'}]}
    role_metadata = RoleMetadata.load(data, RoleDefinition())
    assert role_metadata._dependencies[0]._role_name == 'test_role_1'

    # Test with a list of strings
    data = {'dependencies': ['test_role_1']}
    role_metadata = RoleMetadata.load(data, RoleDefinition())
    assert role_metadata._dependencies[0]._role_name == 'test_role_1'

    # Test with a list of dictionaries

# Generated at 2022-06-17 07:57:45.138776
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata

    role_def = RoleDefinition()
    role_def._role_name = 'role_name'
    role_def._role_path = 'role_path'
    role_def._role_collection = 'role_collection'
    role_def._role_collections = ['role_collections']
    role_def._role_dep_chain = ['role_dep_chain']
    role_def._role_deps = ['role_deps']
    role_def._role_params = ['role_params']

# Generated at 2022-06-17 07:57:52.558763
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test with a valid role
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data', 'roles', 'test_role_meta')
    role_metadata = RoleMetadata.load(role_path)
    assert role_metadata.allow_duplicates == False
    assert len(role_metadata.dependencies) == 1
    assert role_metadata.dependencies[0].role == 'test_role_meta_dep'
    assert role_metadata.dependencies[0].name == 'test_role_meta_dep'

    # Test with a role without meta/main.yml

# Generated at 2022-06-17 07:57:56.173756
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:58:06.169651
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 07:58:15.465595
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:58:21.914674
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    serialized = role_metadata.serialize()
    assert serialized == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 07:58:33.156474
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.blockvars import BlockVars

# Generated at 2022-06-17 07:58:41.478946
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    role_metadata = RoleMetadata()

    # Create a dict with the data to deserialize
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )

    # Deserialize the data
    role_metadata.deserialize(data)

    # Assert the deserialization was successful
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:53.147594
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role_collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 07:59:01.681082
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import role_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize
    from ansible.utils.sentinel import Sentinel
   

# Generated at 2022-06-17 07:59:06.245252
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test_role'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}

# Generated at 2022-06-17 07:59:13.496034
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:59:18.201732
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:59:29.581857
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemMatch

# Generated at 2022-06-17 07:59:41.030762
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'common'}, {'role': 'webservers'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'common'}, {'role': 'webservers'}]}


# Generated at 2022-06-17 07:59:47.449757
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:59:52.672263
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:59:58.322918
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:00:03.946769
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role.path = 'test'
    role.role_path = 'test'
    role.collections = ['ansible.builtin']
    role.metadata = RoleMetadata(owner=role)
    assert role.metadata.allow_duplicates == False
    assert role.metadata.dependencies == []
    assert role.metadata.galaxy_info == None
    assert role.metadata.argument_specs == {}

# Generated at 2022-06-17 08:00:17.122878
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult

# Generated at 2022-06-17 08:00:21.986614
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:00:30.884157
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude
    from ansible.playbook.role.collection import RoleCollectionImport
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.collection import AnsibleCollectionRef
    from ansible.playbook.collection import AnsibleCollectionConfig
    from ansible.playbook.collection import AnsibleCollectionRequirement

# Generated at 2022-06-17 08:00:45.201583
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import find_plugin

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:00:55.134705
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.task.template import TaskTemplate
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.vars import Vars

# Generated at 2022-06-17 08:01:15.541297
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersion
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersionFile
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemVersionFileArtifact

# Generated at 2022-06-17 08:01:29.949005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemMatch

# Generated at 2022-06-17 08:01:40.749758
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.collection_search import CollectionSearchList

# Generated at 2022-06-17 08:01:51.567991
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_default import RoleCollectionDefault

    role_def = RoleDefinition()
    role_def._role_name = 'test'
    role_def._role_path = 'test'
    role_def._role_collection = 'test'

    role_req = RoleRequirement()
    role_req._role_name = 'test'

# Generated at 2022-06-17 08:01:55.466805
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = []
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-17 08:02:04.480006
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude

    # test constructor
    role_metadata = RoleMetadata()
    assert role_metadata._owner is None
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

    # test load method

# Generated at 2022-06-17 08:02:11.320530
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 08:02:19.010902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler.task import Handler
    from ansible.playbook.handler.include import HandlerInclude

# Generated at 2022-06-17 08:02:27.155856
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    role_metadata = RoleMetadata()
    # Test deserialize method
    data = {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{'role': 'test_role'}]

# Generated at 2022-06-17 08:02:37.170748
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    rd = RoleDefinition()
    rd.name = 'test'
    rd.role_path = 'test'
    rd.collections = []
    rd.metadata = RoleMetadata(owner=rd)
    rd.metadata.dependencies = [RoleInclude(name='test1', role_path='test1'), RoleRequirement(name='test2', role_path='test2')]
    rd.metadata.allow_duplicates = True


# Generated at 2022-06-17 08:03:11.874308
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementRequirementRequirement

# Generated at 2022-06-17 08:03:15.147593
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-17 08:03:26.894311
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    rd = RoleDefinition()
    rd.name = 'test_role'
    rd.role_path = '/path/to/test_role'
    rd.collections = ['ansible.builtin']

    rm = RoleMetadata(owner=rd)
    rm.allow_duplicates = True
    rm.dependencies = [RoleRequirement('test_role2')]

    assert rm.serialize() == {'allow_duplicates': True, 'dependencies': [{'name': 'test_role2'}]}

# Generated at 2022-06-17 08:03:37.627435
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_def = RoleDefinition.load(dict(
        name='test_role',
        path='/tmp/test_role',
        collection_name='test_collection',
    ))

    role_req = RoleRequirement.load(dict(
        name='test_role',
        path='/tmp/test_role',
        collection_name='test_collection',
    ))

    role_inc = RoleInclude.load(dict(
        role='test_role',
        tasks_from='main',
    ))

    role_meta = RoleMetadata(owner=role_def)

# Generated at 2022-06-17 08:03:45.610753
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # test with a simple string
    data = 'foobar'
    role_def = RoleDefinition.load(data, None)
    role_req = RoleRequirement.load(data, None)
    assert role_def == role_req

    # test with a dict
    data = {'role': 'foobar'}
    role_def = RoleDefinition.load(data, None)
    role_req = RoleRequirement.load(data, None)
    assert role_def == role_req

    # test with a dict with a src
    data = {'src': 'foobar'}
    role_def = RoleDefinition.load(data, None)

# Generated at 2022-06-17 08:03:57.196210
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude

    # Create a playbook
    pb = Playbook()

    # Create a play

# Generated at 2022-06-17 08:04:03.038129
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition()
    rm = RoleMetadata(owner=rd)
    assert rm._owner == rd
    assert rm._allow_duplicates == False
    assert rm._dependencies == []
    assert rm._galaxy_info == None
    assert rm._argument_specs == {}

# Generated at 2022-06-17 08:04:12.325873
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader
   

# Generated at 2022-06-17 08:04:18.263516
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:04:31.575971
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.task.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.collection import RoleCollection

# Generated at 2022-06-17 08:05:36.174433
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.galaxy_info import GalaxyInfo
    from ansible.playbook.role.attribute import FieldAttribute
    from ansible.playbook.role.attribute import RoleAttribute
    from ansible.playbook.role.attribute import RoleMetadataAttribute
    from ansible.playbook.role.attribute import RoleDefinitionAttribute
    from ansible.playbook.role.attribute import RoleRequirementAttribute
    from ansible.playbook.role.attribute import RoleIncludeAttribute

# Generated at 2022-06-17 08:05:43.633173
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.galaxy import GalaxyRole
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.path import RolePath
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 08:05:49.631017
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collection import RoleCollectionRequirement

    # Test with empty RoleMetadata
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # Test with RoleMetadata with dependencies
    role_metadata = RoleMetadata()

# Generated at 2022-06-17 08:05:54.393462
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:06:04.467095
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.file_loader import RoleFileLoader

# Generated at 2022-06-17 08:06:07.824048
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:06:11.188188
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 08:06:18.367826
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    role_definition = RoleDefinition()

# Generated at 2022-06-17 08:06:23.875107
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:06:28.677667
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']