

# Generated at 2022-06-17 07:56:49.225721
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:56:58.559950
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 07:57:09.119092
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_defaults import RoleCollectionDefaults
    from ansible.playbook.role.collection_role import RoleCollectionRole
    from ansible.playbook.role.collection_role_dependency import RoleCollectionRoleDependency
    from ansible.playbook.role.collection_role_default import RoleCollection

# Generated at 2022-06-17 07:57:16.475859
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display

# Generated at 2022-06-17 07:57:23.926840
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role.path = 'test'
    role.collections = ['ansible.builtin']
    role.metadata = RoleMetadata(owner=role)
    assert role.metadata.allow_duplicates is False
    assert role.metadata.dependencies == []

# Generated at 2022-06-17 07:57:33.092255
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo

    # test constructor
    role = Role()
    role.name = 'test_role'
    role.role_path = '/path/to/test_role'
    role_def = RoleDefinition()
    role_def._role_path = '/path/to/test_role'
    role_def._role_collection = None
    role_def._play = None
    role_def._loader = None
    role_def._variable_manager = None


# Generated at 2022-06-17 07:57:44.771375
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.meta import TaskMeta
    from ansible.playbook.task.when import TaskWhen
    from ansible.playbook.vars.hostvars import HostVars

# Generated at 2022-06-17 07:57:54.973169
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                role=dict(
                    name='test_role',
                    collection='test_collection'
                )
            ),
            dict(
                role=dict(
                    name='test_role2',
                    collection='test_collection2'
                )
            )
        ]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert isinstance(role_metadata.dependencies[0], RoleRequirement)
    assert isinstance

# Generated at 2022-06-17 07:57:58.666555
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:09.193673
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_stub import RoleCollectionStub
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

    # test deserialize with empty data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # test deserialize

# Generated at 2022-06-17 07:58:27.506998
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple role definition
    role_def = dict(name='test_role')
    role_def_obj = RoleDefinition.load(role_def, None)
    assert isinstance(role_def_obj, RoleDefinition)
    assert role_def_obj.get_name() == 'test_role'

    # Test with a role definition with a src
    role_def = dict(src='test_role')
    role_def_obj = RoleDefinition.load(role_def, None)
    assert isinstance(role_def_obj, RoleRequirement)
    assert role_def_obj.get_name() == 'test_role'

    # Test with a role definition with a src and a

# Generated at 2022-06-17 07:58:31.458264
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:58:44.517383
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.role.task_include import TaskInclude

# Generated at 2022-06-17 07:58:48.742947
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 07:58:59.901311
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_task import RoleCollectionTask
    from ansible.playbook.role.collection_vars import RoleCollectionVars
    from ansible.playbook.role.collection_meta import RoleCollectionMeta
    from ansible.playbook.role.collection_handler import RoleCollectionHandler
    from ansible.playbook.role.collection_defaults import RoleCollectionDefaults

# Generated at 2022-06-17 07:59:04.272640
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['test']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['test']

# Generated at 2022-06-17 07:59:06.534021
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = True
    r.dependencies = ['role1', 'role2']
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 07:59:19.016696
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.task_include import TaskInclude

# Generated at 2022-06-17 07:59:24.604180
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault

    # test with empty data
    role_metadata = RoleMetadata.load(data={}, owner=None)
    assert role_metadata.dependencies == []
    assert role_metadata.allow_duplicates == False

    # test with data

# Generated at 2022-06-17 07:59:33.523558
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-17 07:59:51.214249
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r.name = 'test'
    r.path = 'test'
    m = RoleMetadata(owner=r)
    assert m._owner == r
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None
    assert m._argument_specs == {}

# Generated at 2022-06-17 08:00:01.899184
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.file import RoleFile

# Generated at 2022-06-17 08:00:05.691048
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-17 08:00:11.178172
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-17 08:00:20.288134
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [
        {
            'role': 'common',
            'version': 'v1'
        },
        {
            'role': 'webservers',
            'version': 'v1'
        }
    ]
    assert role_metadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'common',
                'version': 'v1'
            },
            {
                'role': 'webservers',
                'version': 'v1'
            }
        ]
    }


# Generated at 2022-06-17 08:00:30.257589
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.task import Task
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext

    # Create a RoleMetadata object
    role_metadata = RoleMetadata()

    # Create a RoleDefinition object
    role_definition = RoleDefinition()

    # Create a

# Generated at 2022-06-17 08:00:45.203797
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
   

# Generated at 2022-06-17 08:00:55.136375
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 08:01:00.725878
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']


# Generated at 2022-06-17 08:01:05.165649
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['test']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['test']}


# Generated at 2022-06-17 08:01:36.047636
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.collection_role import CollectionRole
   

# Generated at 2022-06-17 08:01:43.866867
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='test_role',
                src='test_role_src',
                scm='test_role_scm',
                version='test_role_version',
                path='test_role_path',
                collection='test_role_collection'
            )
        ]
    )
    role_metadata.deserialize(data)

    assert role_metadata._allow_duplicates == True
    assert isinstance(role_metadata._dependencies[0], RoleRequirement)

# Generated at 2022-06-17 08:01:54.355508
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

# Generated at 2022-06-17 08:01:56.624877
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:02:07.057558
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.when import TaskWhen
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.task import TaskVars

# Generated at 2022-06-17 08:02:14.968217
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test with empty data
    data = {}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test with data
    data = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:02:28.788133
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collection import RoleCollectionRequirement

    role = Role()
    role._role_path = '/path/to/role'
    role._role_name = 'test_role'
    role._role_collection = None

    role_def = RoleDefinition()
    role_def._role_path = '/path/to/role'
    role_def._role_name = 'test_role'
    role_def._role

# Generated at 2022-06-17 08:02:30.673250
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 08:02:37.437457
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role.path = 'test/path'
    role.collections = ['ansible.builtin']
    role.metadata = RoleMetadata(owner=role)
    assert role.metadata.allow_duplicates == False
    assert role.metadata.dependencies == []
    assert role.metadata._owner == role

# Generated at 2022-06-17 08:02:43.494985
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    role_def = RoleDefinition.load({'name': 'test_role'}, play=None, variable_manager=None, loader=None)
    role_meta = RoleMetadata(owner=role_def)
    assert role_meta._owner == role_def
    assert role_meta._dependencies == []
    assert role_meta._allow_duplicates == False
    assert role_meta._galaxy_info == None
    assert role_meta._argument_specs == {}
    assert role_meta._ds == {}
    assert role_meta._valid_attrs == {'allow_duplicates': True, 'dependencies': True, 'galaxy_info': True, 'argument_specs': True}
   

# Generated at 2022-06-17 08:03:44.394482
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_dependency import RoleCollectionDependency

    # Create a RoleDefinition object
    role_definition = RoleDefinition()

    # Create a RoleRequirement object
    role_requirement = RoleRequirement()

    # Create a RoleInclude object
    role_include = RoleInclude()

    # Create

# Generated at 2022-06-17 08:03:51.624901
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:04:02.831988
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_def = RoleDefinition()
    role_def._role_path = '/home/user/ansible/roles/role1'
    role_def._role_name = 'role1'
    role_def._role_collection = None

    role_inc = RoleInclude()
    role_inc._role_name = 'role2'
    role_inc._role_path = '/home/user/ansible/roles/role2'
    role_inc._role_collection = None

    role_req = RoleRequirement()
    role_req._role_name = 'role3'

# Generated at 2022-06-17 08:04:12.223932
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_task import RoleCollectionTask
    from ansible.playbook.role.collection_vars import RoleCollectionVars
    from ansible.playbook.role.collection_defaults import RoleCollectionDefaults
    from ansible.playbook.role.collection_meta import RoleCollectionMeta
    from ansible.playbook.role.collection_handlers import RoleCollectionHandlers

# Generated at 2022-06-17 08:04:23.939082
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:04:31.740805
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-17 08:04:37.359388
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:04:45.188102
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 08:04:57.312110
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.galaxy_info import GalaxyInfo
    from ansible.playbook.role.attribute import RoleAttribute
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 08:05:00.254115
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['test']))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['test']