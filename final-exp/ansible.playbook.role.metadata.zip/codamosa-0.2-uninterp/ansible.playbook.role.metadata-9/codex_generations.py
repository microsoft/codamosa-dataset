

# Generated at 2022-06-17 07:56:54.955320
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']


# Generated at 2022-06-17 07:56:58.594964
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:57:02.506699
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test'}]}


# Generated at 2022-06-17 07:57:06.075958
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:57:15.563204
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition

    role = Role()
    role._role_path = '/path/to/role'
    role._role_name = 'test_role'
    role._role_collection = None

    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 07:57:19.275441
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']


# Generated at 2022-06-17 07:57:29.310350
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler.task import Handler
    from ansible.playbook.handler.include import HandlerInclude

# Generated at 2022-06-17 07:57:43.250644
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.handler_include import HandlerInclude

# Generated at 2022-06-17 07:57:52.280631
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-17 07:57:54.207876
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-17 07:58:05.089117
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['role1', 'role2']))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:12.327064
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem

    # create a RoleDefinition object
    role_def = RoleDefinition()
    role_def._role_name = 'test_role'
    role_def._role_path = '/path/to/test_role'
    role_def._role_collection = None

    # create a RoleInclude object
    role_inc = RoleIn

# Generated at 2022-06-17 07:58:20.185389
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.vars import TaskVars
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.manager import VariableManager

# Generated at 2022-06-17 07:58:26.876905
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:58:35.713650
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 07:58:45.246788
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # test loading a role with no meta/main.yml
    role = Role()
    role._role_path = './test/data/roles/test_role_no_meta'
    role._role_name = 'test_role_no_meta'
    role._role_collection = None
    role._play = None
    role._collections = []
    role._role_definition = RoleDefinition()
    role._role_definition._role_path = './test/data/roles/test_role_no_meta'
    role._role_definition._role_name = 'test_role_no_meta'
    role._role_definition._

# Generated at 2022-06-17 07:58:58.173409
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.vars import RoleVars

# Generated at 2022-06-17 07:59:02.660697
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src='https://github.com/geerlingguy/ansible-role-apache',
                name='geerlingguy.apache',
                version='1.9.0'
            )
        ]
    )
    role_metadata = RoleMetadata().load(data, None)
    assert role_metadata.serialize() == data

# Generated at 2022-06-17 07:59:08.472009
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # test constructor
    r = RoleMetadata()
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None
    assert r._argument_specs == {}

    # test load
    r = RoleMetadata.load({}, None)


# Generated at 2022-06-17 07:59:20.380889
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultEntry
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultEntryMatch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultEntryNoMatch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultEntryMultipleMatch

# Generated at 2022-06-17 07:59:32.445618
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:59:42.185860
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.collection.collection_search import CollectionSearch
    from ansible.playbook.collection.collections_loader import CollectionsLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader

# Generated at 2022-06-17 07:59:54.331848
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 08:00:04.403025
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import role_loader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:00:17.469515
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 08:00:21.516757
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    role_metadata = RoleMetadata(owner=role_definition)
    assert role_metadata._owner == role_definition

# Generated at 2022-06-17 08:00:30.715930
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import RoleCollectionSearch
   

# Generated at 2022-06-17 08:00:38.915762
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:00:50.142208
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.block import BlockInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude

# Generated at 2022-06-17 08:00:56.030193
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 08:01:14.341716
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_def = RoleDefinition()
    role_def._role_path = '/home/user/ansible/roles/test_role'
    role_def._role_name = 'test_role'
    role_def._role_collection = None
    role_def._collections = []

    role_inc = RoleInclude()
    role_inc._role_name = 'test_role'
    role_inc._role_path = '/home/user/ansible/roles/test_role'
    role_inc._role_collection = None
    role_inc._collections = []

    role_req = RoleRequirement()


# Generated at 2022-06-17 08:01:24.324292
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.galaxy import GalaxyInfo
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.context import RoleContext
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.task_include_args import TaskIncludeArgs
    from ansible.playbook.role.task_include_vars import TaskIncludeVars

# Generated at 2022-06-17 08:01:35.596811
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 08:01:38.807873
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role

# Generated at 2022-06-17 08:01:51.404684
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.block import BlockInclude
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 08:02:01.542322
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block_context import BlockContext

# Generated at 2022-06-17 08:02:10.555281
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collectiondefaults import RoleCollectionDefaults
    from ansible.playbook.role.taskinclude import TaskInclude
    from ansible.playbook.role.tasks import Tasks

# Generated at 2022-06-17 08:02:12.247777
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 08:02:23.421270
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    # test constructor
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

    # test load
    role_metadata = RoleMetadata.load(dict(dependencies=['role1', 'role2']), Role())
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == ['role1', 'role2']
    assert role_metadata._galaxy

# Generated at 2022-06-17 08:02:35.499953
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader

# Generated at 2022-06-17 08:02:58.939009
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.include import IncludeRole

# Generated at 2022-06-17 08:03:04.082670
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:03:08.872201
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:03:18.872094
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.defaults import DefaultInclude
    from ansible.playbook.role.vars import VariableInclude

# Generated at 2022-06-17 08:03:26.463592
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:03:34.245551
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner == role
    assert role_metadata._ds == {}

# Generated at 2022-06-17 08:03:44.542491
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role_definition = RoleDefinition()
    role_definition._role_name = 'test_role'
    role_definition._role_path = 'test_role_path'
    role_definition._role_collection = 'test_role_collection'
    role_definition._role_collections = ['test_role_collection']
    role_definition._role_dependencies = [RoleInclude(role_definition, 'test_role_dependency')]
    role_definition._role_requirements = [RoleRequirement('test_role_requirement')]

    role_metadata = RoleMetadata(owner=role_definition)
    role_metadata._allow

# Generated at 2022-06-17 08:03:57.085542
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem


# Generated at 2022-06-17 08:04:01.477282
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:04:11.989103
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.collection_include import RoleCollectionInclude

    # test with a simple string
    data = 'test_role'
    role_def = RoleDefinition.load(data, variable_manager=None, loader=None)
    role_include = RoleInclude.load(data, variable_manager=None, loader=None)
    role_req = RoleRequirement.load(data, variable_manager=None, loader=None)
    role_col_include = RoleCollectionInclude.load(data, variable_manager=None, loader=None)
    assert role_def.get_name() == 'test_role'


# Generated at 2022-06-17 08:04:43.619347
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.when import TaskWhen
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.task import TaskVars

# Generated at 2022-06-17 08:04:45.544824
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 08:04:57.351253
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 08:05:07.016645
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test 1: Test with a dictionary
    data = {'dependencies': [{'role': 'common', 'some_parameter': 'some_value'}]}
    role = Role()
    role._role_path = '/path/to/role'
    role._role_name = 'test_role'
    role._role_collection = None
    role._play = None
    role._collections = []
    role._variable_manager = None
    role._loader = None
    role_metadata = RoleMetadata.load(data, role)
    assert role_metadata._dependencies[0]._role_name == 'common'
    assert role_metadata

# Generated at 2022-06-17 08:05:17.485867
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.galaxy import GalaxyInfo

    role_definition = RoleDefinition()
    role_definition._role_name = 'test_role'
    role_definition._role_path = 'test_role_path'
    role_definition._role_collection = 'test_role_collection'
    role_definition._role_collections = ['test_role_collection']

    role_include = RoleInclude()
    role_include._role_name = 'test_role'
    role_include._role_path = 'test_role_path'
   

# Generated at 2022-06-17 08:05:28.994783
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.file import RoleFile
    from ansible.playbook.role.task import RoleTask
    from ansible.playbook.role.handler import RoleHandler
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook


# Generated at 2022-06-17 08:05:39.037968
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.loop import TaskLoop
    from ansible.playbook.task.when import TaskWhen

    # Test constructor of class RoleMetadata
    # Test with no arguments
    role_metadata = RoleMetadata()
    assert role_metadata._owner is None
    assert role_metadata._allow_duplicates is False

# Generated at 2022-06-17 08:05:46.637360
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.galaxy import GalaxyInfo

    # Create a Playbook
    pb = Playbook()

    # Create a Play
    play = Play()
    play._playbook = pb

    # Create a RoleDefinition
    role_def = RoleDefinition()
    role_def._

# Generated at 2022-06-17 08:05:51.140663
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 08:05:57.752700
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test with empty RoleMetadata
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

    # Test with non-empty RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['foo', 'bar']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}
