

# Generated at 2022-06-17 07:56:45.772554
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:56:56.269874
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.block import Block
    from ansible.playbook.task.when import When
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:57:01.426973
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 07:57:10.320240
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    role_def = RoleDefinition()
    role_def._role_name = 'test_role'
    role_def._role_path = '/test/path'
    role_def._role_collection = None
    role_def._role_collections = []

    role_req = RoleRequirement()
    role_req._role_name = 'test_role'
    role_req._role_path = '/test/path'
    role_req._role_collection = None
    role_req._role_collections = []

    role_inc = RoleInclude()


# Generated at 2022-06-17 07:57:17.431033
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()

# Generated at 2022-06-17 07:57:28.745917
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFile
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFileContent
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemFileContentEntry

# Generated at 2022-06-17 07:57:43.249605
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role = Role()
    role_definition = RoleDefinition()
    role_definition._role_path = './test/data/roles/test_role'
    role_definition._role_name = 'test_role'
    role._role_definition = role_definition

    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-17 07:57:49.449612
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-17 07:57:58.313021
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import CollectionSearch
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_loader import RoleCollectionLoader

# Generated at 2022-06-17 07:58:08.974325
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.file_dependency import RoleFileDependency
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.vars_prompt import RoleVarsPrompt
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.tasks import RoleTasks
    from ansible.playbook.role.handlers import RoleHandlers

# Generated at 2022-06-17 07:58:27.483555
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_dependency import RoleCollectionDependency

    # Test RoleMetadata.load()
    # Test with a dictionary

# Generated at 2022-06-17 07:58:31.071036
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert r.allow_duplicates == True
    assert r.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:58:33.776667
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:58:44.712851
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:58:48.254335
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:58:59.469925
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-17 07:59:06.238821
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemMatch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemMatchFile
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemMatchFileLine

# Generated at 2022-06-17 07:59:13.496350
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 07:59:18.200789
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 07:59:29.581885
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementGalaxy
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementPath

# Generated at 2022-06-17 07:59:53.481479
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with a simple dictionary
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar'],
    )
    role_metadata = RoleMetadata.load(data, owner=None)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['foo', 'bar']

    # Test with a dictionary containing a list of RoleDefinition

# Generated at 2022-06-17 07:59:58.507372
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:00:05.856006
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test_role'
    role.role_path = 'test_role_path'
    role.collection = 'test_collection'
    role.collections = ['test_collection']
    role.play = 'test_play'
    role.variable_manager = 'test_variable_manager'
    role.loader = 'test_loader'
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:00:18.437478
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.variable import Variable

# Generated at 2022-06-17 08:00:27.988393
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_search import RoleCollectionSearch

# Generated at 2022-06-17 08:00:37.601195
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

    # Test with empty data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test with data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

    #

# Generated at 2022-06-17 08:00:41.321047
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-17 08:00:50.042402
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role.path = 'test'
    role.collections = ['ansible.builtin']
    role.metadata = RoleMetadata(owner=role)
    assert role.metadata.allow_duplicates == False
    assert role.metadata.dependencies == []
    assert role.metadata.galaxy_info == None
    assert role.metadata.argument_specs == {}
    assert role.metadata.owner == role
    assert role.metadata.loader == None
    assert role.metadata.variable_manager == None

# Generated at 2022-06-17 08:01:00.885927
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.collection_include import RoleCollectionInclude

    # Test with a simple role definition
    role_def = {'role': 'test'}
    role_def_res = RoleMetadata.load(role_def, None)
    assert isinstance(role_def_res, RoleMetadata)
    assert role_def_res._dependencies[0] == RoleDefinition(role_def)

    # Test with a simple role requirement
    role_req = {'name': 'test', 'src': 'test'}
    role_req_res = RoleMetadata.load(role_req, None)

# Generated at 2022-06-17 08:01:11.277526
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.handlers import HandlerInclude
    from ansible.playbook.role.block import BlockInclude
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 08:01:43.715772
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.meta import RoleMetadata

# Generated at 2022-06-17 08:01:54.329289
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpec
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementSpecVersion

# Generated at 2022-06-17 08:01:59.436005
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role = Role()
    role._role_path = '/path/to/role'
    role._role_name = 'test_role'
    role._role_collection = None
    role._collections = []

    role_def = RoleDefinition()
    role_def._role_path = '/path/to/role'
    role_def._role_name = 'test_role'
    role_def._role_collection = None
    role_def._collections = []

    role_req = RoleRequirement()
    role_req._role_path = '/path/to/role'
    role_req._role_name = 'test_role'


# Generated at 2022-06-17 08:02:08.085098
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection_search import RoleCollectionSearch

    # Test load with no data
    m = RoleMetadata.load(None, Role())
    assert m._allow_duplicates == False
    assert m._dependencies == []

    # Test load with data
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(role='test_role'),
            dict(role='test_role2'),
        ]
    )
    m = RoleMetadata.load(data, Role())

# Generated at 2022-06-17 08:02:12.544365
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [1,2,3]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [1,2,3]}


# Generated at 2022-06-17 08:02:19.551510
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler.task import Handler
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.collection_search import CollectionSearch

# Generated at 2022-06-17 08:02:28.138394
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.galaxy_info import GalaxyInfo

    # Create a RoleDefinition object
    role_definition = RoleDefinition()
    role_definition._role_path = '/home/user/ansible/roles/test'
    role_definition._role_name = 'test'
    role_definition._role_collection = None

    # Create a RoleInclude object
    role_include = RoleInclude()
    role_include._role_name = 'test'
    role_

# Generated at 2022-06-17 08:02:33.809938
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.playbook.role.collection_search import RoleCollectionSearchResult
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItem
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirement
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementGalaxy
    from ansible.playbook.role.collection_search import RoleCollectionSearchResultItemRequirementPath

# Generated at 2022-06-17 08:02:35.581376
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata._owner == role

# Generated at 2022-06-17 08:02:42.261035
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r._role_path = '/etc/ansible/roles/test'
    r._role_name = 'test'
    r._role_collection = 'ansible.builtin'
    r._collections = ['ansible.builtin']
    r._play = None
    m = RoleMetadata(owner=r)
    assert m._owner == r
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None
    assert m._argument_specs == {}

# Generated at 2022-06-17 08:03:44.392841
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_loader import RoleCollectionLoader
    from ansible.playbook.role.loader import RoleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

# Generated at 2022-06-17 08:03:51.123362
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    ))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-17 08:04:01.433211
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.collection import RoleCollectionRequirement
    from ansible.playbook.role.collection import RoleCollectionInclude

    # Create a play
    play = Play()
    play._variable_manager = None
    play

# Generated at 2022-06-17 08:04:11.963200
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    # test with a role definition
    role_def = RoleDefinition()
    role_def._role_name = 'test_role'
    role_def._role_path = '/path/to/test_role'
    role_def._role_collection = 'test_collection'

    # test with a role requirement
    role_req = RoleRequirement()
    role_req._role_name = 'test_role'
    role_req._role_path = '/path/to/test_role'
    role_req._role_collection = 'test_collection'

    #

# Generated at 2022-06-17 08:04:23.739588
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.file_dependency import RoleFileDependency
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.vars_prompt import RoleVarsPrompt
    from ansible.playbook.role.vars_files import RoleVarsFiles
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.tasks import RoleTasks


# Generated at 2022-06-17 08:04:27.123904
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'test_role'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test_role'}]}


# Generated at 2022-06-17 08:04:30.635023
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-17 08:04:36.591911
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-17 08:04:44.763552
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.collection_include import RoleCollectionInclude
    from ansible.playbook.role.collection_default import RoleCollectionDefault
    from ansible.playbook.role.collection_task import RoleCollectionTask
    from ansible.playbook.role.collection_vars import RoleCollectionVars
    from ansible.playbook.role.collection_defaults import RoleCollectionDefaults

    # test with a simple role

# Generated at 2022-06-17 08:04:51.915896
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['test']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['test']