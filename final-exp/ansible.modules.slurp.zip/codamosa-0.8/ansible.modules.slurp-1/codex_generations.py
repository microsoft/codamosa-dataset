

# Generated at 2022-06-11 07:57:15.259351
# Unit test for function main
def test_main():
    global MODULE_PATH, B64_BAD_FILE
    # Use a temp file for the source
    (fd, tmp_file) = tempfile.mkstemp()
    os.close(fd)
    MODULE_PATH = tmp_file
    B64_BAD_FILE = "This is a bad base64 file"

    # Create the temporary file for testing.  The contents
    # of this file should mirror the return dict.
    with open(MODULE_PATH, 'wb') as tmp_fh:
        tmp_fh.write(B64_BAD_FILE)
    tmp_fh.close()

    # Build a data structure that mirrors that of the arguments
    # passed via AnsibleModule.
    module_args = dict(src=MODULE_PATH)

    # Initialize instance of AnsibleModule
    module = Ansible

# Generated at 2022-06-11 07:57:27.593301
# Unit test for function main
def test_main():
    source_content = """pipeline {
    agent {
        label 'master'
    }
    stages {
        stage('Test') {
            steps {
                sh 'echo This is a test'
            }
        }
    }
}"""
    encoded_source_content = base64.b64encode(source_content)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']


# Generated at 2022-06-11 07:57:32.356190
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            "src": {"type": "path", "required": True, "aliases": ["path"]}
        },
        supports_check_mode=True,
    )

    module.params["src"] = "filepath"
    module.exit_json(changed=False)

# Generated at 2022-06-11 07:57:36.458097
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    source = '/tmp/ansible_test_file'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    file_data = to_bytes('Hello World!\n')
    with open(source, 'wb') as file_h:
        file_h.write(file_data)
    main(module)

    print('Source: {0}'.format(module.params['src']))
    print('Content: {0}'.format(module.params['content']))
    print('Source file is ({0})'.format(source))
   

# Generated at 2022-06-11 07:57:45.303028
# Unit test for function main
def test_main():
  import os
  import tempfile

  (fd, file_to_slurp) = tempfile.mkstemp()
  os.write(fd, b'hello')
  os.close(fd)

  module = AnsibleModule(
      argument_spec=dict(
          src=dict(type='path', required=True, aliases=['path']),
      ),
  )

  module.params = {'src': file_to_slurp}

  source = module.params['src']

  try:
      with open(source, 'rb') as source_fh:
          source_content = source_fh.read()
  except (IOError, OSError) as e:
      if e.errno == errno.ENOENT:
          msg = "file not found: %s" % source
      el

# Generated at 2022-06-11 07:57:55.737750
# Unit test for function main
def test_main():
    # Dummy class for AnsibleModule
    class DummyAnsibleModule():
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()
            self.fail_json = dict()

    # Dummy dict for AnsibleModule params
    dummy_params = dict()

    # Dummy dict for AnsibleModule exit_json
    dummy_exit_json = dict()
    dummy_exit_json['content'] = 'dummy content'
    dummy_exit_json['source'] = 'dummy source'
    dummy_exit_json['encoding'] = 'base64'

    # Dummy dict for AnsibleModule fail_json
    dummy_fail_json = Exception()
    dummy_fail_json.msg = "unable to slurp file: %s"

    # Create object for module
   

# Generated at 2022-06-11 07:58:06.591370
# Unit test for function main
def test_main():
    # test parsing of command line arguments
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    import tempfile

    # create a temporary file for testing
    tmp_f = tempfile.NamedTemporaryFile(delete=False)
    tmp_f.write(b"test file content")
    tmp_f.close()
    module.params['src'] = tmp_f.name

# Generated at 2022-06-11 07:58:17.498298
# Unit test for function main
def test_main():
    class args:
        def __init__(self, src=''):
            self.src = src
            class params:
                def __init__(self, src=''):
                    self.src = src
    class module:
        def __init__(self, argument_spec, supports_check_mode=False):
            self.params = args(src).params
        def fail_json(self, msg='', **kwargs):
            print(msg)
            return False
        def exit_json(self, **kwargs):
            return True
    class file_mock:
        def __init__(self, path):
            self.path = path
            if not os.path.exists(self.path):
                raise OSError(2, 'File does not exist', self.path)

# Generated at 2022-06-11 07:58:27.802115
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.params = {
        'src': 'tests/files/slurp/exaample_file.txt',
    }
    result = main()

# Generated at 2022-06-11 07:58:35.324414
# Unit test for function main
def test_main():
    # check reading a file with length 0
    source_path = "/tmp/test_0_file"
    with open(source_path, "w") as source_file:
        source_file.write("")
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = source_path
    source = module.params['src']
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    assert data == b"", "File with length 0 has data"
    os.unlink(source_path)

    #

# Generated at 2022-06-11 07:58:53.326640
# Unit test for function main
def test_main():
    import unittest
    import mock
    import ansible.module_utils.basic

    class TestClass(unittest.TestCase):
        def test_it(self):
            self.mock_module = mock.Mock(
                params={'src': '/etc/hosts'},
                fail_json=dict,
                exit_json=dict,
                check_mode=False)
            self.mock_module.debug = mock.Mock(return_value=None)
            self.mock_module.warn = mock.Mock(return_value=None)
            self.mock_module.run_command = mock.Mock(return_value=(0, b'127.0.0.1 localhost'))
            main()

            self.mock_module.fail_json.assert_not_called()


# Generated at 2022-06-11 07:59:00.971008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = {
        'src': '/tmp/ansible.test',
    }

    with open('/tmp/ansible.test', 'w') as f:
        f.write('ansible.test')

    main()

    os.remove('/tmp/ansible.test')

# Generated at 2022-06-11 07:59:08.835689
# Unit test for function main
def test_main():
    import os
    tmp_path = os.path.join(os.path.dirname(__file__), '_test_source.txt')
    with open(tmp_path, 'wb') as tmp_fh:
        tmp_fh.write(b'hello world')

    test_args = dict(src=tmp_path)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True
    )
    module.params['src'] = tmp_path
    module.run_command = lambda cmd, tmpdir: (1, b'hello world', b'')

    result = module.main()
    assert result['content'] == b'aGVsbG8gd29ybGQ='

# Generated at 2022-06-11 07:59:17.588775
# Unit test for function main
def test_main():
    import shutil
    path = '/tmp/foo/bar'
    dirname = os.path.dirname(path)
    os.makedirs(dirname)
    with open(path, 'w') as f:
        f.write('foo bar')

    try:
        module = AnsibleModule({'src': path},
                               check_mode=False)
        main()
    finally:
        if os.path.exists(path):
            os.remove(path)
        if os.path.exists(dirname):
            shutil.rmtree(dirname)


# Generated at 2022-06-11 07:59:25.311657
# Unit test for function main
def test_main():
    test_parameters = {
        "src": "/tmp/test_src"
    }

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda **kwargs: kwargs
    module.params = test_parameters

    result = main()
    assert result['source'] == '/tmp/test_src'
    assert result['encoding'] == 'base64'
    assert result['content'] == 'dGVzdF9zY3JpcHQ='
    os.remove('/tmp/test_src')

# Generated at 2022-06-11 07:59:30.821853
# Unit test for function main
def test_main():
    """Function main is tested
    """
    import os
    from ansible.module_utils.common.text.converters import to_native

    exc_class = None
    try:
        main()
    except IOError as e:
        exc_class = e.__class__
        exc = e
    assert exc_class == IOError
    assert to_native(exc) == 'must be run as a module'

# Generated at 2022-06-11 07:59:38.454331
# Unit test for function main
def test_main():
    source = 'test_fetch_source'
    source_content = b'Hello World'
    os.mknod(source)
    with open(source, 'wb') as source_fh:
        source_fh.write(source_content)
    assert os.path.isfile(source)
    res = main()
    assert res['content'] == base64.b64encode(source_content)
    assert res['source'] == source
    assert res['encoding'] == 'base64'
    os.remove(source)

# Generated at 2022-06-11 07:59:49.813861
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 07:59:57.633318
# Unit test for function main
def test_main():
    class fake_module(object):
        params = { 'src': '/var/run/sshd.pid' }
        def fail_json(self, msg):
            self.msg = msg

    with open('/var/run/sshd.pid','r') as source_fh:
        source_content = source_fh.read()

    mymod = fake_module()
    try:
        main()
    except SystemExit as e:
        pass

    assert(mymod.msg.startswith("unable to slurp file:"))


# Generated at 2022-06-11 08:00:05.237052
# Unit test for function main
def test_main():
    content = b'a test'
    with open('test_slurp', 'wb') as f:
        f.write(content)
    try:
        assert main(dict(src='test_slurp')) == dict(content=base64.b64encode(content), source='test_slurp', encoding='base64')
    finally:
        os.remove('test_slurp')


# Generated at 2022-06-11 08:00:26.754195
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='str', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:00:35.010118
# Unit test for function main
def test_main():
    # We mock the built-in open() with a custom class that contains
    # a static file for this unittest. So any call to open()
    # will return a file handler for the file 'foo_file.txt'
    # which resides in the same directory as this unittest module.
    class MockFile:
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode
            self.handle = open(os.path.dirname(__file__) + "/foo_file.txt", mode)

        def __enter__(self):
            return self.handle

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.handle.close()

    # We mock all calls to open() with our custom open class
    # (MockFile)


# Generated at 2022-06-11 08:00:42.106271
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import builtins
    with mock.patch.dict(builtins.__dict__, {'open': Mock(return_value=MockFile()), 'base64': MockBase64()}):
        module = MockModule()
        r = main()
        assert(r['content'] == 'MjE3OQo=')
        assert(r['encoding'] == 'base64')
        assert(r['source'] == '/var/run/sshd.pid')


# Generated at 2022-06-11 08:00:52.798724
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:01:02.157673
# Unit test for function main
def test_main():
    source = os.path.realpath(__file__)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = source
    
    main()

    # We expect the output from this to be a base64 encoded version of the file
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    expected_data = base64.b64encode(source_content)
    assert data == expected_data

# Generated at 2022-06-11 08:01:12.523766
# Unit test for function main
def test_main():
    test_str = os.urandom(1024)
    test_file = '/tmp/test_slurp'
    stream = open(test_file, 'wb')
    stream.write(test_str)
    stream.close()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-11 08:01:23.521997
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = 'test.txt'
    if os.path.exists(source):
        os.remove(source)
    test_data = 'This is a test string'
    with open(source, 'w+') as source_fh:
        source_fh.write(test_data)
    assert main()['content'] == base64.b64encode(test_data), 'failed to return encoded data'
    assert os.path.exists(source), 'failed to find the test file'
    if os.path.exists(source):
        os.remove(source)

# Generated at 2022-06-11 08:01:34.484892
# Unit test for function main
def test_main():
    src_data = os.urandom(100)

    class Args:
        src = None

    class AnsibleModuleMock:
        class ParameterError(Exception):
            pass

        class ReturnValue:
            content = None
            source = None
            encoding = None

        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.fail_json = lambda x: None
            self.exit_json = lambda x: None
            self.params = Args

        def fail_json(self, *args, **kwargs):
            raise self.ParameterError

        def exit_json(self, *args, **kwargs):
            raise self.ReturnValue


# Generated at 2022-06-11 08:01:35.116449
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 08:01:41.311435
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    def fake_open(path, mode):
        class FakeFileHandler:
            def read(self):
                return b'Hello World'
        return FakeFileHandler()

    with patch.object(builtins, 'open', fake_open):
        main()

# Generated at 2022-06-11 08:02:15.710187
# Unit test for function main
def test_main():
    # Arguments
    args = {
        "src": "c:\\ansible\\file.txt"
    }
    
    # Result
    result = {
        "changed": False, 
        "content": "T0hJTlNUQU5H", 
        "encoding": "base64", 
        "msg": "", 
        "source": "c:\\ansible\\file.txt"
    }
    # Create the AnsibleModule object
    module = AnsibleModule(
        argument_spec=args
    )
    # Test
    main()
    assert module.exit_json == result 


# Generated at 2022-06-11 08:02:25.491090
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:02:33.780081
# Unit test for function main
def test_main():
    from ansible.modules.deprecated.slurp import main as slurp_main

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = "./test/ansible_test.py"
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    module.params['src'] = source
    slurp_main()

    assert module.exit_args['content'] == base64.b64encode(source_content)
    assert module.exit_args['source'] == source

# Generated at 2022-06-11 08:02:43.841496
# Unit test for function main
def test_main():
    os.path.isfile = lambda x: True
    open = lambda x, y: NoContent()
    import tempfile
    tmp_fd, tmp_file = tempfile.mkstemp(prefix='ansible_test_slurp_')
    os.close(tmp_fd)
    os.unlink(tmp_file)
    os.path.realpath = lambda x: tmp_file
    module = AnsibleModule(
        argument_spec = dict(
            src=dict(type='path', required=True, aliases=['path']),
        )
    )
    assert main() == { 'content': '', 'source': tmp_file, 'encoding': 'base64' }
    os.unlink(tmp_file)
    assert os.path.isfile(tmp_file) == False


# A file-like object

# Generated at 2022-06-11 08:02:52.909110
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:03:01.816691
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    source_content = None
    data = None
    s = None

    # Test file not found
    def os_error(a, b, c, d, e, f):
        raise OSError(errno.ENOENT, "No such file or directory")
    old_open = os.open
    old_close = os.close
    old_read = os.read
    os.open, os.close, os.read = os_error, os_error, os_error
    try:
       main()
    except SystemExit as e:
        s = e

# Generated at 2022-06-11 08:03:05.155016
# Unit test for function main
def test_main():
    args = dict(
        src = 'tests/units/module_utils/test_slurp.txt'
    )
    module = AnsibleModule(argument_spec={'src': dict(type='path', required=True, aliases=['path'])})
    module.params = args
    module.exit_json(src=module.params['src'])
    assert True

# Generated at 2022-06-11 08:03:13.413003
# Unit test for function main
def test_main():

    # from ansible.compat.tests import unittest
    # from ansible.compat.tests.mock import patch, MagicMock
    # from ansible.module_utils.basic import AnsibleModule
    import unittest
    import sys
    import ansible.module_utils.basic
    from mock import patch, MagicMock
    from ansible.module_utils.basic import AnsibleModule
    sys.modules['ansible'] = MagicMock()
    sys.modules['ansible.module_utils'] = ansible.module_utils
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic
    sys.modules['ansible.compat.tests'] = unittest
    sys.modules['ansible.compat.tests.mock'] = unittest.mock


# Generated at 2022-06-11 08:03:23.095717
# Unit test for function main
def test_main():
    # Unit tests require the mock module
    # python-mock available in epel-testing,
    # python-mock available in Debian Jessie backports
    # python3-mock available in Debian Stretch, Sid and Ubuntu Xenial.
    # python3-mock available in Fedora Rawhide
    try:
        import mock
    except ImportError:
        print("skipping unit tests, python-mock not installed.")
        exit()

    # Test that the function returns correct base64 encoded data
    # when called with valid data
    module_mock = mock.Mock()
    params_mock = {'src': 'data'}
    module_mock.params = params_mock

    fh_mock = mock.MagicMock()
    fh_mock.read.return_value = b"This is a test"
   

# Generated at 2022-06-11 08:03:31.430037
# Unit test for function main
def test_main():
    '''
    Ansible provide a way to test modules.
    https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_testing.html
    Built-in function unit test, module is `setup`.
    '''

    module_args = dict(
        src='/etc/hosts'
    )

    module_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../')

    module = AnsibleModule(argument_spec=module_args)
    result = main()

    assert result['encoding'] == 'base64'

# Generated at 2022-06-11 08:04:32.512008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:04:43.039689
# Unit test for function main
def test_main():
    import json
    import shutil
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(prefix='ansible-', delete=False) as source_file:
        source_file.write(b"Hello, world!")
        source = source_file.name

# Generated at 2022-06-11 08:04:52.554035
# Unit test for function main
def test_main():
    test_string = 'this is a test'
    
    # Create a temporary file to write to
    with tempfile.NamedTemporaryFile() as f:
        tmp_file = f.name
    
    # Write the test string to the temporary file
    with open(tmp_file, 'w') as f:
        f.write(test_string)    

    # Module parameters
    arguments = dict(
        src=tmp_file
    )

    # Create the AnsibleModule used to test main()
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Run the main function

# Generated at 2022-06-11 08:04:53.130438
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 08:05:02.755275
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_bytes
    import ansible.module_utils.action_plugins.slurp
    import base64
    import os
    import sys

    fn = os.path.join(os.path.dirname(sys.argv[0]), "test_slurp.txt")
    with open(fn, 'wb') as f:
        f.write(to_bytes('1 line\n'))

    m = ansible.module_utils.action_plugins.slurp.AnsibleModule(
        argument_spec={'src': {'type': 'path', 'required': True, 'aliases': ['path']}},
        supports_check_mode=False
    )

# Generated at 2022-06-11 08:05:10.556445
# Unit test for function main
def test_main():
    # check if src file not found throws error
    module_args = dict(src='badfile.txt')
    module_mock = Mock(AnsibleModule, return_value=MagicMock())
    with patch('slurp.AnsibleModule', module_mock):
        with pytest.raises(SystemExit):
            main()
    # check src file found is returned
    module_args = dict(src=os.path.join('test/files/test.txt'))
    module_mock = Mock(AnsibleModule, return_value=MagicMock())
    with patch('slurp.AnsibleModule', module_mock):
        main()

# Generated at 2022-06-11 08:05:11.058222
# Unit test for function main
def test_main():
  assert False

# Generated at 2022-06-11 08:05:16.392868
# Unit test for function main
def test_main():
  try:
    import __builtin__ as builtins
  except ImportError:
    import builtins
  builtins.open = lambda *x: open(*x, mode='rb')
  module = AnsibleModule(
      argument_spec=dict(
          src=dict(type='path', required=True, aliases=['path']),
          _ansible_check_mode=dict(type='bool'),
          _ansible_debug=dict(type='bool'),
      ),
      supports_check_mode=True,
  )
  module.params['src'] = __file__
  main()

# Generated at 2022-06-11 08:05:19.979968
# Unit test for function main
def test_main():
    source = 'test_file'
    with open(source, 'w') as temp:
        temp.write('hello')
    try:
        result = main(source)
        assert result['content'] == 'aGVsbG8='
        assert result['source'] == source
        assert result['encoding'] == 'base64'
    finally:
        os.remove(source)

# Generated at 2022-06-11 08:05:20.482126
# Unit test for function main
def test_main():
    assert False