

# Generated at 2022-06-11 07:57:15.374117
# Unit test for function main
def test_main():

    source_data = "This is a test file."
    expected_results = {
        'content': 'VGhpcyBpcyBhIHRlc3QgZmlsZS4=',
        'source': '/tmp/test/test.txt',
        'encoding': 'base64'
    }

    module_args = {
        'src': '/tmp/test/test.txt'
    }

    with open(module_args['src'], 'w') as f:
        f.write(source_data)

    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    m.params = module_args
    main()

    assert m.exit_json

# Generated at 2022-06-11 07:57:27.646699
# Unit test for function main
def test_main():
    # Make sure the following code only runs when invoked as a module.
    import os
    os.system('echo "Test Passed"')
    # module = AnsibleModule(
    #     argument_spec=dict(
    #         src=dict(type='path', required=True, aliases=['path']),
    #     ),
    #     supports_check_mode=True,
    # )
    # source = module.params['src']
    #
    # try:
    #     with open(source, 'rb') as source_fh:
    #         source_content = source_fh.read()
    # except (IOError, OSError) as e:
    #     if e.errno == errno.ENOENT:
    #         msg = "file not found: %s" % source
    #     el

# Generated at 2022-06-11 07:57:38.820301
# Unit test for function main
def test_main():
    source = '/dev/zero'
    assert os.path.isfile(source), "Unit test failed. Expected {0} to be a file".format(source)
    os.environ['ANSIBLE_MODULE_ARGS'] = r'{ "src": "/dev/zero" }'

    import json
    import ansible.modules.files.slurp
    result = ansible.modules.files.slurp.main()

    result['changed'] = False
    assert type(result['content']) is str, "Unit test failed. Expected result['content'] to be a string"
    assert result['encoding'] == 'base64', "Unit test failed. Expected result['encoding'] to be 'base64'"
    assert result['source'] == source, "Unit test failed. Expected result['source'] to be '/dev/zero'"

# Generated at 2022-06-11 07:57:41.289710
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    assert module.fail_json.__name__ == fail_json.__name__
    assert module.exit_json.__name__ == exit_json.__name__

# Generated at 2022-06-11 07:57:50.394054
# Unit test for function main
def test_main():
    # Forming arguments for test
    args_dict = {
        'src' : '/path/to/a/file'
    }
        
    temp_file_name = '.slurp_test_file.txt'
    temp_src_file_name = '/tmp/' + temp_file_name
    temp_dst_file_name = '/tmp/local/' + temp_file_name
    temp_file_content = "This is a test file for module ansible.builtin.slurp"
    
    # Open a temp file to write some content
    temp_src_file = open(temp_src_file_name, 'w+')
    temp_src_file.write(temp_file_content)
    temp_src_file.close()

    # Creating a mock object for module class

# Generated at 2022-06-11 07:58:02.090313
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 07:58:02.665390
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:58:10.523711
# Unit test for function main
def test_main():
    import os
    import sys
    # Add root path, so the test can find the modules
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

    src = __file__

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    try:
        with open(src, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        print(e)

    data = base64.b64encode(source_content)

# Generated at 2022-06-11 07:58:14.630815
# Unit test for function main
def test_main():
    import os
    os.system("chmod +x /usr/local/bin/ansible-playbook")
    assert os.system("ansible-playbook /etc/ansible/roles/L7-slurp/tests/test.yml") == 0

# Generated at 2022-06-11 07:58:15.742096
# Unit test for function main
def test_main():
    assert False

# Test module

# Generated at 2022-06-11 07:58:31.661011
# Unit test for function main
def test_main():
    source = os.path.join(os.path.dirname(__file__), '../../command_modules/ping.py')
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = {'src': source}
    result = main()

# Generated at 2022-06-11 07:58:42.678934
# Unit test for function main
def test_main():
    # Put the path of the test module in the path environment variable
    import os
    import sys
    test_module_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, test_module_path)

    # Create a mock ansible module and insert it into the module import path
    import collections
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock
    mock_ansible_module = MagicMock(name='ansible.module_utils.basic.AnsibleModule')
    sys.modules['ansible.module_utils.basic'] = mock_ansible_module

    # Populate mock_ansible_module with the function to

# Generated at 2022-06-11 07:58:53.760764
# Unit test for function main
def test_main():
    import tempfile
    (fd, tmpfile) = tempfile.mkstemp()
    os.write(fd, b'Hello World')
    os.close(fd)
    # The test relies on the fact that the module is idempotent and does not
    # destroy the temporary file
    args = [
        '-m', 'ansible.builtin.slurp',
        '-a', 'src=%s' % tmpfile,
        '-v',
    ]
    (rc, out, err) = module_test(args, fail_on_parsing=False)
    assert rc == 0
    assert out == '{"changed": false, "content": "SGVsbG8gV29ybGQ=", "encoding": "base64", "source": "%s"}\n' % tmpfile

# Generated at 2022-06-11 07:58:57.303814
# Unit test for function main
def test_main():
    os.path.isdir("./test_dir")
    # Need to write test code

if __name__ == '__main__':
    if os.path.isdir("./test_dir"):
        test_main()

# Generated at 2022-06-11 07:59:02.605021
# Unit test for function main
def test_main():
    import os
    import tempfile
    import ansible.constants as C

    def test_module_parameters():
        from ansible.module_utils._text import to_bytes

        args = dict(
            src='/path/to/a/file.txt',
        )

        p = AnsibleModule(argument_spec=args)

        assert p.params['src'] == '/path/to/a/file.txt'

    def test_normal_file(tmpdir, monkeypatch):
        args = dict(
            src=tmpdir.join('a.txt').strpath,
        )

        with open(tmpdir.join('a.txt').strpath, 'w') as f:
            f.write('hello world\n')


# Generated at 2022-06-11 07:59:11.868140
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.ansible_local_slurp_module import ExitJson
    from ansible.module_utils.ansible_local_slurp_module import FailJson
    from ansible.module_utils.ansible_local_slurp_module import AnsibleModule

    with open("test_files/test_file.txt", "rb") as source_fh:
        source_content = source_fh.read()
    encoded_test_data = base64.b64encode(source_content)
    module_args = dict(
        src="test_files/test_file.txt"
    )

# Generated at 2022-06-11 07:59:21.658924
# Unit test for function main
def test_main():
    import AnsibleModule
    
    def run_test():
        AnsibleModule.exit_json = exit_json
        AnsibleModule.fail_json = fail_json
        main()

    def exit_json(*args, **kwargs):
        assert args[0]['content'] == "MTA0Mg=="
        assert args[0]['source'] == "/tmp/1.txt"
        assert args[0]['encoding'] == "base64"

    def fail_json(*args, **kwargs):
        assert False

    with open('/tmp/1.txt', 'wb') as f:
        f.write("104".encode('utf-8'))

    run_test()
    os.remove('/tmp/1.txt')

# Generated at 2022-06-11 07:59:22.346216
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:59:30.178961
# Unit test for function main
def test_main():
    source = "/tmp/test"
    def test_module(**args):
        args['failed']=False
        return args
    source_fh_contents="Test contents of the source file"
    source_fh = open(source, 'wb')
    source_fh.write(source_fh_contents)
    ansible_module_slurp=dict(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    ansible_module_slurp['params']=dict(
        src=source
    )

# Generated at 2022-06-11 07:59:41.633926
# Unit test for function main
def test_main():
    import base64
    import os
    import tempfile
    import uuid
    from ansible.module_utils.common.text.converters import to_bytes

    (fd, source) = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.write(to_bytes(base64.b64decode("MjE3OQo=")))
    f.close()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True),
        ),
        supports_check_mode=True,
    )
    
    module.params["src"] = source

    data = main()
    os.unlink(source)
    assert data["content"] == "MjE3OQo="
    assert data["encoding"]

# Generated at 2022-06-11 08:00:06.913660
# Unit test for function main
def test_main():
    # Test case #1 - Read file from doc which should not exist and test exception behavior
    # You will have to manually verify the file does not exist for this test to work
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_source = '/usr/share/doc/ansible/slurp.yaml'


# Generated at 2022-06-11 08:00:13.567749
# Unit test for function main
def test_main():
    content = b'A'*(1024**2)
    tmp = open('/tmp/foo', 'wb')
    tmp.write(content)
    tmp.close()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'])
        ),
        supports_check_mode=True
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-11 08:00:24.040239
# Unit test for function main
def test_main():
    # Output from module.params
    module_params = dict(
        src='/var/run/sshd.pid'
    )
    # Content of file
    source_content = b"2179\n"

    # Return code expected
    rc = 0

    # Output to stdout expected
    result = dict(
        changed=False,
        content="MjE3OQo=",
        encoding="base64",
        source="/var/run/sshd.pid",
    )

    # Output to stdout expected (JSON formatted)
    result_json = '{"changed": false, "source": "/var/run/sshd.pid", "content": "MjE3OQo=", "encoding": "base64"}'


# Generated at 2022-06-11 08:00:32.700042
# Unit test for function main
def test_main():

    import tempfile
    try:
        with tempfile.NamedTemporaryFile('w', delete=False) as fh:
            fh.write('The quick brown fox jumps over the lazy dog.')
        source = fh.name
        os.remove(source)  # ensure file does not exist

        # test file does not exist
        module = AnsibleModule(
            argument_spec=dict(
                src=dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
        )
        module.params['src'] = source
        main()
        assert False, 'expected module to exit non-zero'
    except SystemExit as exc:
        assert exc.args == (1,), 'expected module to exit non-zero'

    # test file is not readable

# Generated at 2022-06-11 08:00:42.265434
# Unit test for function main
def test_main():
    # Load module and test data
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
    ),supports_check_mode=True,)
    source = 'testdata/textfile.txt'
    expected_content = base64.b64encode(b'Test Data for Slurp Module\n')
    os.chdir(os.path.dirname(os.path.realpath(__file__)))

    # Run test
    main()
    results = module.exit_json
    assert(results['content'] == expected_content)
    assert(results['source'] == source)
    assert(results['encoding'] == 'base64')

# Generated at 2022-06-11 08:00:53.012822
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    msg = "unable to slurp file: %s" % source

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:01:04.523731
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args):
            self.exit_args = args
            self.exit_called = True

        def exit_json(self, *args):
            self.exit_called = True
            self.exit_args = args

    class MockArgs(object):
        def __init__(self, **kwargs):
            self.src = kwargs['src']

    module = MockModule(src='/tmp/does_not_exist')
    main(module)
    assert module.exit_called == True
    assert module.exit_args == ("file not found: %s" % '/tmp/does_not_exist',)

    # Test: exception other than ENOENT or EACCES

# Generated at 2022-06-11 08:01:12.903619
# Unit test for function main
def test_main():
    source_content = b'hello world'
    data = base64.b64encode(source_content)
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
        ), supports_check_mode=True)
    module.params['src'] = '/tmp/testme'
    with open(module.params['src'], 'wb') as f:
        f.write(source_content)
    main()
    assert module.exit_json() == {'changed': False, 'content': data, 'encoding': 'base64', 'source': '/tmp/testme'}
    os.unlink(module.params['src'])

# Generated at 2022-06-11 08:01:20.359591
# Unit test for function main
def test_main():
    with open("./test_data/slurp.json", "r") as f:
        test_data = json.load(f)
    module, result = main(test_data['params'])
    assert module['content'] == 'bWFyayBkZXZpY2VzCg=='
    assert os.path.abspath(module['source']) == os.path.abspath(test_data['params']['src'])
    assert module['encoding'] == 'base64'

# Generated at 2022-06-11 08:01:31.160965
# Unit test for function main
def test_main():
    # Import Necessary Libs
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:02:02.561665
# Unit test for function main
def test_main():
    """ Unit tests for main """
    # Create dummy ansible args for the unit test
    test_args = {
        'src': 'test_module/test.txt',
    }
    # Create the module object for unit test
    module = AnsibleModule({}, False, False, params=test_args)
    # The module has no exit json function, so we need to create it manually
    module.exit_json = exit_json
    # Call the module
    main()



# Generated at 2022-06-11 08:02:12.169740
# Unit test for function main
def test_main():

    import base64
    import os

    from ansible.module_utils.basic import AnsibleModule

    testfile = "testfile.txt"
    content = "unit test file contents"

    # Write test file
    with open(testfile, 'wb') as testfile_fh:
        testfile_fh.write(content)

    # Test case 1: testcase with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=False, aliases=['path']),
        ),
        supports_check_mode=False,
    )
    module.params['src'] = testfile

    main()

    # Remove test file
    os.remove(testfile)

    testdir = "testdir"

    # Create test directory

# Generated at 2022-06-11 08:02:22.638787
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:02:28.850792
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        )
    )
    module._ANSIBLE_ARGS = {
        'ANSIBLE_MODULE_ARGS': dict(
        src='/proc/mounts'
        )
    }
    module.exit_json = lambda: None
    result = module.main()
    if result['content'][:2] != b'Qn':
        raise AssertionError('Result does not start with Qn')

# Generated at 2022-06-11 08:02:35.325476
# Unit test for function main
def test_main():
    def fake_module(**kwargs):
        class FakeModule(object):
            def __init__(self, **kwargs):
                self.params = kwargs
                self.exit_json = lambda **x: None

        return FakeModule(**kwargs)

    with open('/tmp/testslurp', 'w') as f:
        f.write('hello')

    module = fake_module(src='/tmp/testslurp')
    main()
    os.remove('/tmp/testslurp')

# Generated at 2022-06-11 08:02:36.008120
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 08:02:42.261885
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.params["src"] = "test.txt"
    test_main_return = main(test_module)
    assert test_main_return == {'content': b"dGVzdA==", 'source': "test.txt", 'encoding': 'base64'}

# Generated at 2022-06-11 08:02:51.545864
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Test that file cannot be found
    module.params['src'] = '/tmp/doesnotexist'
    with pytest.raises(AnsibleError) as excinfo:
        main()
    assert 'file not found' in str(excinfo.value)

    # Test that file is a directory
    if os.path.isdir('/tmp/test'):
        shutil.rmtree('/tmp/test')
    os.mkdir('/tmp/test')
    module.params['src'] = '/tmp/test'

# Generated at 2022-06-11 08:02:57.374169
# Unit test for function main
def test_main():
    path = '/etc/hosts'
    content = base64.b64encode(open(path, 'rb').read())

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = path

    assert module.exit_json['content'] == content
    assert module.exit_json['source'] == '/etc/hosts'

# Generated at 2022-06-11 08:03:03.266534
# Unit test for function main
def test_main():
    dummy_args = {'src':'/var/run/sshd.pid'}
    dummy_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    dummy_module.params = dummy_args
    dummy_source = dummy_module.params['src']

    dummy_data = base64.b64encode(os.path.basename(dummy_source))
    dummy_module.exit_json(content=dummy_data, source=dummy_source, encoding='base64')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:04:10.946249
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:04:11.529212
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 08:04:16.184228
# Unit test for function main
def test_main():
    a = AnsibleModule({
        'src': '/proc/mounts'
    })
    result = main()
    with open('./test/data/slurp_test.data', 'rb') as fh:
        content = fh.read()
        assert(result == (content, '/proc/mounts', 'base64'))

# Generated at 2022-06-11 08:04:21.919818
# Unit test for function main
def test_main():
    args = {'src': '/etc/hosts'}
    with patch.object(AnsibleModule, 'exit_json') as exit_json_mock:
        main()
        exit_json_mock.assert_called_with(content='c2VsZi5ob3N0cwogYmxvY2tlZC1ob3N0cy50eHQ=', source='/etc/hosts', encoding='base64')

# Generated at 2022-06-11 08:04:30.195453
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    path = "../tests/unit/data/test_file.txt"
    source = os.path.abspath(path)
    test.params["src"] = source
    content = b"This is a test file.\nThis is only a test file.\n"
    data = module.b64encode(content)
    result = {
        'content': data,
        'source': source,
        'encoding': 'base64'
    }
    assert main() == result

# Generated at 2022-06-11 08:04:30.723660
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 08:04:40.186427
# Unit test for function main
def test_main():
    test_path = '/tmp/test_file'

    # Test if file not exist
    with open(test_path, 'w') as f:
        f.write("test")
    assert os.path.isfile(test_path)

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    with open(test_path, 'rb') as f:
        test_content = f.read()
    test_data = base64.b64encode(test_content)
    result = main()
    print(result)
    #assert test_data == result['content']
    assert test_path == result['source']

# Generated at 2022-06-11 08:04:50.952873
# Unit test for function main
def test_main():
    test_parameters = {
        'src': '/tmp/foo',
    }
    test_ansible_module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
    ))

    module_exit_json = {'content': '0', 'source': '/tmp/foo', 'encoding': 'base64'}
    module_fail_json = {'msg': 'unable to slurp file: 0'}

    with pytest.raises(AnsibleExitJson) as exc:
        main()
    assert exc.value.args[0] == module_exit_json

    with pytest.raises(AnsibleFailJson) as exc:
        main()
    assert exc.value.args[0] == module_fail_json

# Generated at 2022-06-11 08:05:00.493652
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.mounts import get_mount_facts
    import ansible.module_utils.common.collections
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.common.network.linux_ip

    ansible.module_utils.common.collections.__name__ = 'ansible.module_utils.common.collections'
    ansible.module_utils.facts.system.distribution.__name__ = 'ansible.module_utils.facts.system.distribution'

# Generated at 2022-06-11 08:05:09.619728
# Unit test for function main
def test_main():
    def is_str(obj):
        return isinstance(obj, str) or isinstance(obj, unicode)

    def str_to_native(obj):
        try:
            return str(obj)
        except UnicodeEncodeError:
            return unicode(obj).encode('unicode_escape')

    import tempfile
    import random
    import string
    import os.path

    sample_data = u''.join(random.choice(string.lowercase) for _ in range(1024))

    (handle, dest) = tempfile.mkstemp()
    f = os.fdopen(handle, "wb")
    f.write(sample_data)
    f.close()
