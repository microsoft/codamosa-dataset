

# Generated at 2022-06-11 07:57:10.655225
# Unit test for function main
def test_main():
    tempfile = None
    try:
        # Create a temporary file
        tempfile = tempfile.TemporaryFile()
        tempfile.write(b'This is the contents of the file')
        tempfile.seek(0)
        # Define module params
        module_params = dict(src=tempfile.name)
        # Run module
        mm = main(module_params)
        assert mm['changed'] == False
    finally:
        # Close temporary file
        if tempfile:
            tempfile.close()

# Generated at 2022-06-11 07:57:18.597888
# Unit test for function main
def test_main():
    module = AnsibleModule(
        name="Testing",
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 07:57:23.988654
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = 'tests/files/test_slurp_file.txt'

    main()

# Generated at 2022-06-11 07:57:25.143318
# Unit test for function main
def test_main():
    raise Exception("This module has no unit tests")

# Generated at 2022-06-11 07:57:30.345258
# Unit test for function main
def test_main():
    # Provided by AnsibleModule
    module = mock.Mock()
    module.exit_json.side_effect = SystemExit
    module.fail_json.side_effect = SystemExit
    module.params = {
        'src': '/proc/mounts'
    }

    # Provided by os
    os.path.exists.side_effect = lambda x: True
    os.path.isfile.side_effect = lambda x: True
    os.access.side_effect = lambda x, y: True

    # Provided by open
    source_content = mock.Mock()
    source_content.read.return_value = 'TestContent'

    with mock.patch('builtins.open', return_value=source_content) as mock_open:
        main()
        # Assert that module was called with the proper parameters
        module

# Generated at 2022-06-11 07:57:38.496720
# Unit test for function main
def test_main():
    content = "test"
    src = "./file_test.txt"
    with open("file_test.txt", "wb") as file_test:
        file_test.write(content)

    module_args = {'src': src}

    mock_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    mock_module.params = module_args

    assert main(mock_module)

    os.remove(src)

# Generated at 2022-06-11 07:57:42.012088
# Unit test for function main
def test_main():
    input_args = {'src': '/proc/mounts'}
    set_module_args(input_args)
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True
    )
    source = module.params['src']

    output = {'changed': False, 'content': None, 'encoding': 'base64', 'source': source}
    os.environ['ANSIBLE_MODULE_NO_JSON'] = '1'
    os.environ['ANSIBLE_MODULE_NO_URL'] = '1'
    os.environ['ANSIBLE_MODULE_NO_DSL'] = '1'

# Generated at 2022-06-11 07:57:42.364028
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:57:50.448178
# Unit test for function main
def test_main():
    os.path.isfile = lambda path: os.path.normpath(path) == 'some_file'
    os.access = lambda path, mode: False

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    with pytest.raises(SystemExit):
        module.params['src'] = 'some_file'
        main()
    with pytest.raises(SystemExit):
        os.path.isfile = lambda path: False
        main()
    os.access = lambda path, mode: True
    open = lambda path, mode: BytesIO(b'1234567890')
    with pytest.raises(SystemExit):
        main()



# Generated at 2022-06-11 07:58:02.189423
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.params = {'src': r'ansible_module_slurp_test.txt'}
    ansible_module_slurp_test_file = open(r'ansible_module_slurp_test.txt', 'w+')
    ansible_module_slurp_test_file.write(r'testing')
    ansible_module_slurp_test_file.close()
    try:
        test_main_obj = main()
        test_module.exit_json(**test_main_obj)
    except SystemExit as e:
        exception_obj

# Generated at 2022-06-11 07:58:20.209752
# Unit test for function main
def test_main():
    # Create test module input
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 07:58:26.343212
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    # Save off a copy of the module that we can use later
    slurp_module = module

    # Create the function that we are actually going to test
    def main():
        # Restore globals
        global slurp_module

        slurp_module.params['src'] = 'test/data/test_ansible_slurp_space_in_path.txt'

        # Call the function being tested

# Generated at 2022-06-11 07:58:34.502915
# Unit test for function main
def test_main():
    # File exists
    src = 'setup.py'
    source_content = open(src, 'rb').read()
    data = base64.b64encode(source_content)
    assert len(main()) == 3
    assert main()['content'] == data
    assert main()['source'] == src
    assert main()['encoding'] == 'base64'
    # File doesn't exist
    src = 'setup.p'
    try:
        open(src, 'rb').read()
    except IOError as e:
        if e.errno == errno.ENOENT:
            print("File not found: %s" % src)
        elif e.errno == errno.EACCES:
            print("File is not readable: %s" % src)

# Generated at 2022-06-11 07:58:43.051416
# Unit test for function main
def test_main():
    import StringIO
    test_file = StringIO.StringIO()
    test_file.name = 'test'
    test_file.write('abcd')
    test_file.seek(0)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = dict(
        src='/var/run/sshd.pid',
    )
    module.params['src'] = test_file
    main()



# Generated at 2022-06-11 07:58:52.632402
# Unit test for function main
def test_main():
  with tempfile.NamedTemporaryFile() as tmpf:
    tmpf.write("this is a test")
    tmpf.seek(0)
    with pytest.raises(SystemExit) as pytest_wrapped_e:
      main(dict(path=tmpf.name))

    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    result = json.loads(sys.stdout.getvalue())

    assert result['content'] == base64.b64encode("this is a test")
    assert result['encoding'] == 'base64'
    assert result['source'] == tmpf.name

# Generated at 2022-06-11 07:58:55.934451
# Unit test for function main
def test_main():
    # these tests don't work as we use os.fork
    # but perhaps they can be used as a guide in the future
    # https://testinfra.readthedocs.io/en/latest/modules.html
    assert True

# Generated at 2022-06-11 07:59:00.522744
# Unit test for function main
def test_main():
    ''' Test function main() from slurp.py. '''
    # pylint: disable=redefined-outer-name
    # pylint: disable=no-value-for-parameter
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    # pylint: disable=unused-variable

    # Helper functions
    def get_stdin_dict():
        ''' Return a dictionary representing the data passed to
        the module via stdin. '''

        return {'ANSIBLE_MODULE_ARGS': module_args}

    # Placeholder for actual test code

# Generated at 2022-06-11 07:59:07.320621
# Unit test for function main
def test_main():
    import tempfile

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b'Hello World\n')
    test_file.close()

    test_args = dict(
        src=test_file.name
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params = test_args
    main()

    os.remove(test_file.name)

# Generated at 2022-06-11 07:59:16.144810
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import json
    import mock

    # Set up a fake ansible module
    module_args = {'src': __file__}
    fake_ansible_module = mock.Mock()
    fake_ansible_module.params = module_args
    fake_ansible_module.check_mode = False
    fake_ansible_module.exit_json.return_value = {'content': '', 'encoding': 'base64', 'source': ''}

    # Make the function use our fake ansible module
    sys.modules['ansible.module_utils.basic'] = mock.Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = mock.Mock(return_value=fake_ansible_module)

    # Make the function use

# Generated at 2022-06-11 07:59:21.635082
# Unit test for function main
def test_main():
    import os
    import sys
    import shutil
    import signal
    import tempfile

    from ansible.module_utils import basic
    from ansible.module_utils.common.parameters import _load_params
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import StringIO
    #from ansible.module_utils import unittests
    #from ansible.module_utils.unittests import ModuleTestCase

    # set up support for handling stdin, arguments, and exit codes
    fake_args = ["/bin/ansible-fake-command",
                 "--show-content"]

    # we have to look at sys.argv[1:] because of the way
    # ansible-playbook currently passes args to the module

# Generated at 2022-06-11 07:59:39.137494
# Unit test for function main
def test_main():

    # test file not found
    os.environ['ANS_TEST_FILE'] = 'test_file'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'], default="%(ANS_TEST_FILE)s"),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-11 07:59:40.747257
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-11 07:59:42.763294
# Unit test for function main
def test_main():
    os.path.exists('/tmp/testfile')
    assert main() == 'file exists'

# Generated at 2022-06-11 07:59:45.031682
# Unit test for function main
def test_main():
    args = {
        'src': '/var/run/sshd.pid',
    }

    result = main(args)
    assert result.get('content') == 'MjE3OQo='
    assert result.get('encoding') == 'base64'
    assert result.get('source') == '/var/run/sshd.pid'

# Generated at 2022-06-11 07:59:53.685854
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils._text import to_native
    from ansible.module_utils.pycompat24 import get_exception

    here = os.path.dirname(__file__)
    test_file = os.path.join(here, 'test_file')
    test_file_contents = 'test data'
    with open(test_file, 'w') as f:
        f.write(test_file_contents)

    args = "%s arg1 arg2 arg3 arg4" % test_file
    module_args = json.loads(args)
    module_args['src'] = test_file


# Generated at 2022-06-11 08:00:06.491784
# Unit test for function main
def test_main():
    import os
    import tempfile
    import types

    temp_dir = tempfile.gettempdir()
    fd, fn = tempfile.mkstemp(dir=temp_dir)
    fh = os.fdopen(fd, 'w')
    fh.write('The quick brown fox jumps over the lazy dog.')
    fh.close()
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    assert type(module.params['src']) == types.StringType
    source = module.params['src']
    source = fn


# Generated at 2022-06-11 08:00:13.414561
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = './test.txt'
    
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:00:14.068960
# Unit test for function main
def test_main():
    return

# Generated at 2022-06-11 08:00:16.463616
# Unit test for function main
def test_main():
    os.system('cd ansible/modules/remote_management/win/; ansible-test windows -v --python 2.7')

# Generated at 2022-06-11 08:00:20.881580
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    assert source

# Generated at 2022-06-11 08:00:35.027252
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 08:00:41.434322
# Unit test for function main

# Generated at 2022-06-11 08:00:52.102981
# Unit test for function main
def test_main():
    # Read in actual test data.
    source = './test/unittest_data/id_rsa'
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    module_args = {}
    module_args['src'] = source

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    test_args = {}
    test_args['src'] = source
    test_module.params = test_args

    # Run test.
    with open(source, 'rb') as test_fh:
        source_content = test_fh.read()


# Generated at 2022-06-11 08:01:03.617641
# Unit test for function main
def test_main():
    import sys
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.modules.system import slurp
    sys.modules['ansible.module_utils.basic'] = pytest.Mock()
    sys.modules['ansible.module_utils.common.text.converters'] = pytest.Mock()
    sys.modules['ansible.module_utils.common.text.converters'].to_native = to_bytes

    source_file_content = b'12345'
    with open('/source_file', 'wb') as f:
        f.write(source_file_content)

    with pytest.raises(pytest.fail.Exception) as exc:
        slurp.__init__
        slurp.main()


# Generated at 2022-06-11 08:01:13.113339
# Unit test for function main
def test_main():
    def get_dict():
        return {
            "ansible_facts": {
                "testvar1": "test1",
                "testvar2": "test2"
            },
            "changed": False,
            "content": "MjE3OQo=",
            "encoding": "base64",
            "failed": False,
            "source": "/tmp/test",
        }

    def exec_module(params):
        argv = []
        argv.append("ansible_module_slurp.py")
        argv.append("--src=/tmp/test")

        for option, value in params.items():
            argv.append("--" + option)
            argv.append(value)
        return AnsibleModule(argv=argv).exec_module()

    # check parameters
   

# Generated at 2022-06-11 08:01:13.642493
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 08:01:24.836031
# Unit test for function main
def test_main():
    src_path = "/var/run/sshd.pid"
    expected_result = "MjE3OQo="
    expected_loc = "In-memory"
    expected_encoding = "base64"
    source_content = "2179\n"

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = lambda *args, **kwargs: module.exit_json(*args, **kwargs)
    test_module.fail_json = lambda *args, **kwargs: module.fail_json(*args, **kwargs)

    test_module.params['src'] = src_path


# Generated at 2022-06-11 08:01:35.798187
# Unit test for function main
def test_main():
    import json
    import tempfile
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.file import ensure_directory
    from ansible.module_utils._text import to_bytes

    mock_common_utils = "ansible.module_utils.common."

# Generated at 2022-06-11 08:01:43.725681
# Unit test for function main
def test_main():
    # Compare the contents of the files using b64decode
    module_args = {}
    module_args.update(src="test_file")

    result = {}
    result['content'] = 'No Content'
    result['changed'] = False
    result['encoding'] = 'base64'

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    return b64decode.content


# Generated at 2022-06-11 08:01:44.287427
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 08:02:11.531498
# Unit test for function main
def test_main():
    assert 1 == 2
    pass

# Generated at 2022-06-11 08:02:22.058229
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = {}
    module.params['src'] = os.path.join(os.path.dirname(__file__), '../module_utils/basic.py')
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-11 08:02:31.585277
# Unit test for function main
def test_main():
    # First test without file existing
    args = {
        'src': "/tmp/test_slurp_file__doesnotexist",
        'check_mode': False,
        'diff_mode': False,
        'platform': 'Linux',
    }
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True, aliases=['path'])),
                           supports_check_mode=True)

    with pytest.raises(SystemExit):
        main()

    # Then test with file existing
    args = {
        'src': "/tmp/test_ansible__slurp_file",
        'check_mode': False,
        'diff_mode': False,
        'platform': 'Linux',
    }

# Generated at 2022-06-11 08:02:41.297213
# Unit test for function main
def test_main():
    # Test when source file is not found
    import ansible.module_utils.basic
    myexit_json = ansible.module_utils.basic.exit_json
    myfail_json = ansible.module_utils.basic.fail_json
    def fake_exit_json(changed, **kwargs):
        assert changed == False
        assert kwargs['content'] == ''
        assert kwargs['encoding'] == 'base64'
        assert kwargs['source'] == '/fake/src'
    ansible.module_utils.basic.exit_json = fake_exit_json
    def fake_fail_json(**kwargs):
        assert kwargs['msg'] == "unable to slurp file: [Errno 2] No such file or directory: '/fake/src'"
        raise SystemExit(1)
    ans

# Generated at 2022-06-11 08:02:50.638775
# Unit test for function main
def test_main():
    def _protected_open_mock(f):
        if f == 'test_file':
            return open('fixture.txt', 'rb')
        else:
            raise OSError('No such file or directory')

    with open('fixture.txt', 'rb') as f:
        expected_content = f.read()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = 'test_file'

# Generated at 2022-06-11 08:02:59.715034
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.slurp import main
    import base64
    import os
    from io import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils._text import to_bytes


    with open(os.devnull, 'wb') as TEST_STDOUT:
        with open(os.devnull, 'wb') as TEST_STDERR:
            try:
                with open('/proc/mounts', 'rb') as source_fh:
                    source_content = source_fh.read()
            except:
                source_content = to_bytes("12345678")
            data = base64.b64encode(source_content)

            mod = Ansible

# Generated at 2022-06-11 08:03:00.356730
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-11 08:03:00.790755
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 08:03:03.960969
# Unit test for function main
def test_main():
    args = dict(
        src='/proc/mounts',
    )
    data = dict(
        content=base64.b64encode(open(args['src'], 'rb').read()),
        source=args['src'],
        encoding='base64',
    )
    results = main()
    assert results == data

# vim: set et ts=4 sw=4

# Generated at 2022-06-11 08:03:09.930446
# Unit test for function main
def test_main():
    testfile = '/tmp/testfile'
    testdata = 'blah'

    # setup
    f = open(testfile,'w')
    f.write(testdata)
    f.close()

    # test
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']


# Generated at 2022-06-11 08:04:17.897654
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-11 08:04:26.027292
# Unit test for function main
def test_main():
    source = 'test_file'
    content = 'foo'
    with open(source, 'w') as w:
        w.write(content)
    src = {
        'src': source,
        }
    module = AnsibleModule(argument_spec={'src': dict(required=True)})
    module.params = src
    result = main()
    assert result['content'] == base64.b64encode(content)
    assert result['source'] == source
    assert result['encoding'] == 'base64'
    os.remove(source)

# Unit test with mocking

# Generated at 2022-06-11 08:04:30.606772
# Unit test for function main
def test_main():
    source = '/tmp/test.txt'
    with open(source, 'w') as f:
        f.write(u'abcdefghi')
    assert len(open(source).read()) == 9
    module = AnsibleModule(argument_spec={'src': {'type': 'path', 'required': True}})
    module.params['src'] = source
    assert module.params['src'] == source
    main()
    os.unlink(source)

# Generated at 2022-06-11 08:04:31.105007
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 08:04:38.137292
# Unit test for function main
def test_main():
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    f = open(dir_path + "/test_slurp.json")
    data = f.read()
    f.close()
    output = exec_module(data)
    assert output['content'] == 'MjE3OQo='
    assert output['encoding'] == 'base64'
    assert output['source'].find('/var/run/sshd.pid') != -1

# Local unit test

# Generated at 2022-06-11 08:04:49.232682
# Unit test for function main
def test_main():
    # description of test
    class Args(object):
        src = 'src'
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-11 08:04:57.492561
# Unit test for function main
def test_main():
    # source_content = b'\x00\x1A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00'
    source_content = b'\x00\x1A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00?\x00'
    # r['content'] = base64.b64encode(source_content)
    # r['source'] = source_path
    # r['encoding'] = 'base64'
    assert main(source_content) == base64.b64encode(source_content)

# Generated at 2022-06-11 08:05:02.325448
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src="Uno",
        ),
        supports_check_mode=True,
    )

    with open('Uno', 'r') as file_handle:
        file_content = file_handle.read()
    data = base64.b64encode(file_content)

    assert (main()['content'] == data)

# Generated at 2022-06-11 08:05:06.262961
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_modlib.base_module import AnsibleModule
    from ansible.module_utils.ansible_modlib.base_module import AnsibleExitJson, AnsibleFailJson
    from ansible.module_utils._text import to_bytes, to_text
    main()
    main()
    main()

# Generated at 2022-06-11 08:05:07.262623
# Unit test for function main
def test_main():
    r = main()
    assert r is None