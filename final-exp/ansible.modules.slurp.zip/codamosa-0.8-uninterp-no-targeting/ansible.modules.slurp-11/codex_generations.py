

# Generated at 2022-06-20 22:35:17.955756
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:35:25.853539
# Unit test for function main
def test_main():
    file_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'slurp_test.txt')

    module_args = dict(
        src=file_path,
    )
    result = {
        "content": b'Q2F0IEhheQptb3N0IHNtYXJ0IGpveWFyZCBtYW55IHBlb3BsZSBjb3VsZCBhbm5vdW5jZQo=',
        "changed": False,
        "encoding": "base64",
        "source": file_path,
    }


# Generated at 2022-06-20 22:35:37.951230
# Unit test for function main
def test_main():
    res = dict()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    if not os.path.isfile(module.params['src']):
        module.exit_json(msg="File {} does not exist".format(module.params['src']))
    else:
        with open(module.params['src'], 'rb') as source_fh:
            source_content = source_fh.read()

            data = base64.b64encode(source_content)

            res['content'] = data
            res['source'] = module.params['src']
            res['encoding'] = 'base64'

# Generated at 2022-06-20 22:35:42.112212
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Construct argument for function call
    arguments = {'src': '/etc/passwd'}
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True, aliases=['path'])), supports_check_mode=True)
    # run function main
    main()

# Generated at 2022-06-20 22:35:53.483771
# Unit test for function main
def test_main():
    # Mock AnsibleModule and AnsibleModule.exit_json
    test_ansible_module = create_ansible_module_mock()

    test_ansible_module.params = dict(
            src="/etc/motd"
    )

    # Mock module.exit_json, module.fail_json
    (test_ansible_module.exit_json, test_ansible_module.fail_json) = create_exit_json_fail_json(test_ansible_module)

    # Mock open
    open_mock = create_open_mock(read_data="Good morning, Dave")

    # Mock os.path.exists
    exists_mock = create_autospec(os.path.exists)
    exists_mock.return_value = True

    # Mock os.access
    access_mock

# Generated at 2022-06-20 22:35:53.998871
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:36:01.844592
# Unit test for function main
def test_main():
    os.environ["ANSIBLE_MODULE_TEST"] = ""
    test_args = {"src": "/var/run/sshd.pid"}
    with pytest.raises(SystemExit):
        module = AnsibleModule(argument_spec={})
        module.exit_json = lambda x, **kw: None
        main()
        module.exit_json = lambda x, **kw: sys.exit(x)
        main()
        module.exit_json = lambda **kw: sys.exit(kw)
        main()

# Generated at 2022-06-20 22:36:09.282006
# Unit test for function main
def test_main():
    args = {
        'src': 'README.md',
    }
    data = base64.b64encode(open(args['src'], 'rb').read())
    changed = False
    results =  {
        'content': data,
        'source': args['src'],
        'encoding': 'base64',
        'changed': changed,
    }
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.exit_json(**results)

# Generated at 2022-06-20 22:36:19.033436
# Unit test for function main
def test_main():

    # Construct a module object
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    myFile = open("test.txt", "w")
    myFile.write("This is a test")
    myFile.close()

    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-20 22:36:20.818536
# Unit test for function main
def test_main():
    import unittest

    class TestMain(unittest.TestCase):
        def test_success(self):
            pass

    unittest.main()

# Generated at 2022-06-20 22:36:35.315789
# Unit test for function main
def test_main():

    module = AnsibleModule({
        'src': '/etc/hosts',
    }, {
        'changed': False,
        'encoding': 'base64',
        'source': '/etc/hosts',
    })

    with open('/etc/hosts') as f:
        content = f.read()

    assert module.exit_json['content'] == base64.b64encode(content)
    assert module.exit_json['source'] == '/etc/hosts'
    assert module.exit_json['encoding'] == 'base64'

# Generated at 2022-06-20 22:36:35.893725
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:36:45.900638
# Unit test for function main
def test_main():
    module_defaults = dict(
        src=dict(type='path', required=True, aliases=['path'])
    )

    test_path = os.path.dirname(os.path.abspath(__file__))
    src = test_path + '/../ANSIBLE_MODULE_UTILS/basic.py'

    module_args = dict(
        src=src,
    )

    # Construct a new AnsibleModule object
    module = AnsibleModule(argument_spec=module_defaults)
    module.params = module_args
    module.exit_json = (lambda **kwargs: print(kwargs))
    # AnsibleModule.__init__()

    with open(src, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b

# Generated at 2022-06-20 22:36:58.160695
# Unit test for function main
def test_main():
    with open("test_main_src", "w") as f:
        f.write("hello\nworld\n")

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:37:05.949066
# Unit test for function main
def test_main():
    args = dict(
        src='/var/run/sshd.pid',
    )

    with AnsibleModule(argument_spec=args, supports_check_mode=True) as module:
        module = AnsibleModule(**module.params)
        main()

    # Test idempotence: no result but no error
    args = dict(
        src='/var/run/sshd.pid',
    )

    with AnsibleModule(argument_spec=args, supports_check_mode=True) as module:
        module = AnsibleModule(**module.params)
        result = main()
        assert "MjE3OQo=" in result['content']

# Generated at 2022-06-20 22:37:06.900535
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:37:12.052913
# Unit test for function main
def test_main():
    # Test as POSIX
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = os.path.basename(__file__)

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        assert False, "unable to slurp file: %s" % to_native(e, errors='surrogate_then_replace')

    data = base64.b64encode(source_content)

    module.exit_json(content=data, source=source, encoding='base64')

# Generated at 2022-06-20 22:37:21.074161
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']

    if source == '/etc/hosts':
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()

        data = base64.b64encode(source_content)

        module.exit_json(content=data, source=source, encoding='base64')

    elif source == '/etc/hosts2':
        pass

# Generated at 2022-06-20 22:37:32.342008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:37:40.529931
# Unit test for function main
def test_main():
    testfile = os.path.dirname(__file__) + os.sep + 'fixtures' + os.sep + 'testfile'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = testfile
    assert module.params['src'] == testfile
    assert main()['encoding'] == 'base64'
    assert main()['source'] == testfile
    assert base64.b64decode(main()['content']) == b'test_content'
    module.params['src'] = 'NOT_EXISTING_FILE'
    assert main()['msg'] == "file not found: NOT_EXISTING_FILE"

# Generated at 2022-06-20 22:38:02.693812
# Unit test for function main
def test_main():
    # First test case
    module = AnsibleModule(argument_spec = dict(
        src = dict(type = 'path', required = True, aliases = ['path']),
    ), supports_check_mode = True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == 2:
            msg = "file not found: %s" % source
        elif e.errno == 13:
            msg = "file is not readable: %s" % source
        elif e.errno == 21:
            msg = "source is a directory and must be a file: %s" % source

# Generated at 2022-06-20 22:38:03.257437
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:38:14.286955
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:38:23.378241
# Unit test for function main
def test_main():
    import os
    import pytest
    import tempfile
    from ansible.module_utils import basic

    # Create a temporary file to test file slurp
    (fd, tmpFilename) = tempfile.mkstemp()
    tmpFile = os.fdopen(fd, 'wb')
    tmpFile.write('testing file slurp')
    tmpFile.close()

    # The test module's python path needs to be appended to the module_utils for Ansible
    basic._ANSIBLE_ARGS = None
    module_args = dict(
        src=tmpFilename,
    )

    ansible_module = basic.AnsibleModule
    my_module = ansible_module(argument_spec=module_args, supports_check_mode=True)

    # Change the current working dir to the temp file's location
    # This is done because Ans

# Generated at 2022-06-20 22:38:32.442788
# Unit test for function main
def test_main():
    source = tempfile.mkstemp()
    fh = os.fdopen(source[0], 'w+')
    fh.write('ABC\n')
    fh.close()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    results = module.run_command('echo "ABC%0A" | base64 -d', check_rc=True)
    assert results[1] == 'ABC\n'

# Generated at 2022-06-20 22:38:41.734802
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:38:43.322449
# Unit test for function main
def test_main():
    result = main()
    assert 'content' in result
    assert 'encoding' in result
    assert 'source' in result

# Generated at 2022-06-20 22:38:48.356590
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_REMOVE_MODULE_RESULT'] = '1'
    for path in ['/does/not/exist', '/dev/null']:
        module = AnsibleModule(argument_spec=dict(
            src=dict(type='path', required=True)
        ))
        module.params['src'] = path
        # set the mock return
        setattr(module.params['src'], 'read', lambda: 'some result')
        module.run()



# Generated at 2022-06-20 22:38:57.854879
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = os.path.abspath(__file__)

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:39:04.444411
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = 'foo'
    data = test_main.data
    module.exit_json(content=data, source=source, encoding='base64')
test_main.data = "dmFsdWU="

# Generated at 2022-06-20 22:39:37.287703
# Unit test for function main
def test_main():
    '''
    Unit tests for module.main
    '''
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    (tmp_fd, tmp_path) = tempfile.mkstemp()
    os.write(tmp_fd, to_bytes('test'))
    os.close(tmp_fd)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params.update(dict(
        src=tmp_path,
    ))


# Generated at 2022-06-20 22:39:47.406317
# Unit test for function main
def test_main():
    # Test AnsibleModule.fail_json()
    source = 'bad.file'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg

# Generated at 2022-06-20 22:39:59.202679
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = __file__
    os.chmod(source, 0o500)

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:40:04.244306
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = os.path.join(os.path.dirname(__file__), 'ansible.cfg')
    main()

# Generated at 2022-06-20 22:40:11.197714
# Unit test for function main
def test_main():
    args = dict(src='/proc/mounts')
    source = args.get('src')

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg = "source is a directory and must be a file: %s" % source

# Generated at 2022-06-20 22:40:18.637250
# Unit test for function main
def test_main():
    result = {}
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Provide unit test for file that exists
    open('/tmp/test_file', 'a').close()
    # Provide unit test for file that does not exist
    module_args = dict(
        src='/tmp/test_file_not_found.txt',
    )
    my_module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    result = main()
    assert 'content' in result
    assert 'encoding' in result
    assert 'source' in result


# Generated at 2022-06-20 22:40:24.466053
# Unit test for function main
def test_main():
    with open('/tmp/source', 'w+') as fd:
        fd.write('test_data')
    result = {'changed': False, 'content': 'dGVzdF9kYXRh', 'encoding': 'base64', 'source': '/tmp/source'}
    args = {'src': '/tmp/source'}
    assert main(args) == result

    os.remove('/tmp/source')

# Generated at 2022-06-20 22:40:31.757125
# Unit test for function main
def test_main():
    # Set up arguments.
    args = dict(src='/tmp/foobar')
    # Set up a test file.
    with open(args['src'], 'w') as f:
        f.write('This is a test')
    # Run the function.
    json = main()
    assert json is not None
    assert json['results'] is not None
    assert json['results']['content'] == 'This is a test'
    assert json['results']['source'] == '/tmp/foobar'
    assert json['results']['encoding'] == 'base64'

# Generated at 2022-06-20 22:40:36.893669
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    data = 'test'
    source = 'test'
    module.exit_json(content=data, source=source, encoding='base64')

# Generated at 2022-06-20 22:40:44.847273
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    src = os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible.cfg')

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
    )
    module.params['src'] = src


# Generated at 2022-06-20 22:41:47.668614
# Unit test for function main
def test_main():
    # https://github.com/ansible/ansible-modules-core/issues/5641
    pass

# Generated at 2022-06-20 22:41:56.014018
# Unit test for function main
def test_main():

    # Skip the test if an environment variable is set
    # This allows us to skip the test in Jenkins, etc.
    if os.getenv('ANSIBLE_TEST_SLURP', False):
        print('skipping slurp test (environment variable ANSIBLE_TEST_SLURP is set)')
        return

    # Create our fake file
    fake_file = '/tmp/fake-file'
    with open(fake_file, 'wb') as fh:
        fh.write(b'this is a fake file')
    
    # Create a module instance
    # Note: this MUST be imported locally, not from ansible.module_utils
    # or it will not work, since that directory is not in the PYTHONPATH

# Generated at 2022-06-20 22:42:07.849329
# Unit test for function main
def test_main():
    # Create a stub module
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']), ) )

    # Set up OS environment variables
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"src": "testfile.txt"}'

    # Set up return value
    testfile_data = b"test data"
    testfile_encoded_data = base64.b64encode(testfile_data)
    testfile_b64encoded_data = testfile_encoded_data.decode()

    # Create stub for open function, to return encodec test file data
    def _mock_open(*args, **kwargs):
        fh = MagicMock()
        fh.read.return_value = testfile

# Generated at 2022-06-20 22:42:15.344500
# Unit test for function main
def test_main():
    os.system("touch /tmp/test_slurp")
    os.system("echo 'slurp' > /tmp/test_slurp")

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']


# Generated at 2022-06-20 22:42:17.936349
# Unit test for function main
def test_main():
    with patch('__builtin__.open', mock_open(read_data='data')) as m:
        module = AnsibleModule(
            argument_spec=dict(
                src=dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
        )
        main()

# Generated at 2022-06-20 22:42:20.763675
# Unit test for function main
def test_main():
    assert os.getenv('ANSIBLE_CONFIG') is not None
    assert os.getenv('ANSIBLE_CONFIG') == './test/test_ansible_modules.cfg'
    assert main() is None

# Generated at 2022-06-20 22:42:21.297111
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-20 22:42:26.280179
# Unit test for function main
def test_main():
    params = {
        'src': '/',
        'check_mode': False,
    }

    m = AnsibleModule(argument_spec=params)
    with pytest.raises(AnsibleActionFail) as result:
        main()
    assert result.value.args[0] == u'unable to slurp file: [Errno 20] Not a directory: \'/\''

# Generated at 2022-06-20 22:42:36.026407
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    import filecmp

    tmpdir = tempfile.mkdtemp()

    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = testfile
    module.params['dest'] = os.path.join(tmpdir, 'testfile2')

    ret = main()

    assert(ret['content'] == b'MjE3OQo=')
    assert(ret['encoding'] == 'base64')

# Generated at 2022-06-20 22:42:47.045600
# Unit test for function main
def test_main():
    os.chdir('..')
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    src = '././package/fetch.py'
    with open(src, 'rb') as source_fh:
        source_content = source_fh.read()
    module.params['src'] = src
    content = base64.b64encode(source_content)
    content = content.decode('utf8')
    source = src
    encoding = 'base64'
    assert(main()['content'] == content)
    assert(main()['source'] == source)
    assert(main()['encoding'] == encoding)