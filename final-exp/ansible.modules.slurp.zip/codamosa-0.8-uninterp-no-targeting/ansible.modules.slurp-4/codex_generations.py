

# Generated at 2022-06-20 22:35:25.325827
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import base64
    x = base64.b64decode('MjE3OQo=')
    assert x == b'2179\n'
    with open('/etc/slurp_file', 'wb') as f:
        f.write(b'2179\n')
    module = AnsibleModule(
        argument_spec = dict(
            src = dict (type = 'path', required = True, aliases=['path']),
        ),
        supports_check_mode = True,
    )
    source = module.params['src']
    assert source == '/etc/slurp_file'
    source_content = source.read()
    assert source_content == b'2179\n'

# Generated at 2022-06-20 22:35:26.346533
# Unit test for function main
def test_main():
    # Stub for function main
    pass


# Generated at 2022-06-20 22:35:33.809303
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    main_result = main()
    assert main_result['content'] == b'MjE3OQo='
    assert os.path.basename(main_result['source']) == 'sshd.pid'

# Generated at 2022-06-20 22:35:39.770857
# Unit test for function main
def test_main():

    import tempfile
    import os

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file_name = test_file.name
    test_file.write(b"This is a test")
    test_file.close()

    module_arg_spec = dict(
        src=dict(type='path', required=True, aliases=['path']),
    )

    success_exit_json = dict(
        content="VGhpcyBpcyBhIHRlc3Q=",
        source=test_file_name,
        encoding='base64',
        changed=False,
    )

    # Create a mock module object, because the paramiko transport
    # doesn't have a .run() method, and AnsibleModule.run() assumes
    # that if self.transport has a .run()

# Generated at 2022-06-20 22:35:51.329698
# Unit test for function main
def test_main():
    # Unit test case to check main functionality
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True)))
    module.exit_json = mock()
    module.fail_json = mock(side_effect=AssertionError)
    assert main() == True
    assert module.fail_json.called == False
    assert module.exit_json.called == True
    assert module.params['src'] == False
    assert module.params['boolean_false'] == False
    assert module.params['boolean_true'] == True

# Generated at 2022-06-20 22:36:02.638747
# Unit test for function main
def test_main():
    # Test returns failed with a bad file
    with open('tmpfile.txt', 'w') as file:
        file.write('Hello World')
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    with open('tmpfile.txt', 'r') as file:
        source_content = file.read()
    data = base64.b64encode(source_content)
    module.exit_json(content=data, source=source, encoding='base64')
    os.remove('tmpfile.txt')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:36:14.290431
# Unit test for function main
def test_main():
    '''
    Unit test for function main.

    Returns
    -------
    none
    '''
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.text.converters import to_bytes

    dummy_module = basic.AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 22:36:23.724719
# Unit test for function main
def test_main():
    module = AnsibleModule(
        # Shared argument spec
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        # The following section is only used when called as a unit test
        # The state argument is ignored in this case
        check_invalid_arguments=False,
        add_file_common_args=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-20 22:36:35.402857
# Unit test for function main
def test_main():
    try:
        # Store original file descriptors so we can reset them later
        saved_stdin = os.fdopen(os.dup(0), 'rb')
        saved_stdout = os.fdopen(os.dup(1), 'wb')
        saved_stderr = os.fdopen(os.dup(2), 'wb')

        # Capture the output from stdout and stderr
        new_stdout = open(os.devnull, 'wb')
        new_stderr = open(os.devnull, 'wb')
        os.dup2(new_stdout.fileno(), 1)
        os.dup2(new_stderr.fileno(), 2)

        # Execute the main function
        main()
    finally:
        # Restore original file descriptors
        os.dup

# Generated at 2022-06-20 22:36:45.421661
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """

    test_file = '/tmp/slurp_test.txt'
    test_string = b'Hello world!'
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
    ), supports_check_mode=True)
    payload = dict(src=test_file)
    module.params = payload
    module.exit_json = lambda a: a
    open(test_file, 'wb').write(test_string)

    result = main()

    assert result == dict(
        content=base64.b64encode(test_string),
        source=test_file,
        encoding='base64'
    )

    os.unlink(test_file)

# Generated at 2022-06-20 22:36:53.344624
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:37:03.581634
# Unit test for function main
def test_main():
    source_content = b"This is a text file"
    source = "/some/path/that/doesnt/exist"

    def mock_open_fh(self, source, rb):
        return source

    def mock_module_fail_json(self, msg):
        raise Exception(msg)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.open_file = mock_open_fh
    module.fail_json = mock_module_fail_json

    module.params['src'] = source


# Generated at 2022-06-20 22:37:11.044044
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'])
        ),
        supports_check_mode=True,
    )
    test_module.params['src'] = "./test-slurp-content"
    assert main() == test_module.exit_json(content='aGVsbG8=', source='./test-slurp-content', encoding='base64')

# Generated at 2022-06-20 22:37:22.093459
# Unit test for function main
def test_main():
    abs_dir_path = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(abs_dir_path, '../../../../../../tests/utils/ansible-test-data')
    sys.modules['ansible.module_utils.basic'] = __import__('ansible.module_utils.basic')
    sys.modules['ansible.module_utils.common.text.converters'] = __import__('ansible.module_utils.common.text.converters')
    sys.modules['ansible.module_utils.common.text.converters.to_native'] = __import__('ansible.module_utils.common.text.converters.to_native')


# Generated at 2022-06-20 22:37:33.260423
# Unit test for function main
def test_main():
    # Test the case where the file exists
    file = "/etc/hosts"
    f = open(file, 'rb')
    source_content = f.read()
    f.close()
    data = base64.b64encode(source_content)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = file

    assert main() == (0, '', {'encoding': 'base64', 'source': '/etc/hosts', 'content': data})

    # Test the case where the file does not exist
    file = "/etc/hosts2"

# Generated at 2022-06-20 22:37:40.987920
# Unit test for function main
def test_main():
    import sys
    import os

    # This is a hack: we are invoking the module without a full environment
    # which is required by the module, so it will fail.
    # because of this, we will use a 'user' that is allowed to do anything
    # and set that it is running in check mode.

    # create the source file to slurp
    tmp_source = os.path.join('/tmp', 'test_main_source')
    with open(tmp_source, 'w') as f:
        f.write('foo!')
        f.close()

    sys.argv = ['ansible-test', 'slurp', 'src=' + tmp_source]
    _this_dir, this_filename = os.path.split(__file__)

# Generated at 2022-06-20 22:37:51.429068
# Unit test for function main
def test_main():
    module_args = dict(
        src='/var/run/sshd.pid',
    )

    # Note: content returned is not always the same, but the
    # source file will always be the same, so we will check it

    result = dict(
        changed=False,
        content=b'MjE3OQo=',
        encoding='base64',
        source='/var/run/sshd.pid',
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    source = module.params['src']

    if os.path.exists(source):
        module.exit_json(**result)
    else:
        module.fail_json(msg="File does not exist")

test_main()

# Generated at 2022-06-20 22:38:02.020279
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = {'src': {'type': 'path', 'required': True, 'aliases': ['path']}},
        supports_check_mode = True)
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:38:13.016717
# Unit test for function main
def test_main():

    class DummyModule:

        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            self.fail = True

        def exit_json(self, fail=False, *args, **kwargs):
            self.fail_json = False
            self.fail = fail

    class DummyOpen:
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    # Test with a non-existent file
    test_module = DummyModule(
        dict(src='/tmp/does/not/exist')
    )

# Generated at 2022-06-20 22:38:21.719430
# Unit test for function main
def test_main():
    test_src_path = os.path.join(os.path.dirname(__file__), 'test_slurp')
    test_file_path = os.path.join(test_src_path, 'test_slurp_file')
    test_file = open(test_file_path, 'w')
    test_file.write(b'slurp_test')
    test_file.close()
    from ansible.module_utils.ansible_release import __version__

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=False,
    )
    source = 'test_slurp/test_slurp_file'


# Generated at 2022-06-20 22:38:37.253644
# Unit test for function main
def test_main():
    # Run a simple test with the provided fixture data
    assert main() == ('SUCCESS', {'content': 'MjE3OQo=', 'source': '/var/run/sshd.pid', 'encoding': 'base64'}, {})

# Generated at 2022-06-20 22:38:38.160922
# Unit test for function main
def test_main():
    # TODO: add unit test.
    pass

# Generated at 2022-06-20 22:38:46.910254
# Unit test for function main
def test_main():
    src = "/tmp/testfile"
    f = open(src, 'w')
    f.write("ansible")
    f.close()
    for p in ("/var/tmp/ansible", "/var/tmp/", "/var/tmp"):
        os.mkdir(p)
    os.mkdir("/tmp/ansible")
    os.mkdir("/tmp/")
    os.mkdir("/tmp")
    os.mkdir("/var/tmp")
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    with open(source, 'rb') as source_fh:
        source_content

# Generated at 2022-06-20 22:38:57.424556
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = os.path.join(os.path.dirname(__file__), 'files/test.txt')

    try:
        with open(module.params['src'], 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % module.params['src']

# Generated at 2022-06-20 22:38:58.437509
# Unit test for function main
def test_main():
    assert main() == 'test'

# Generated at 2022-06-20 22:39:10.427322
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:39:18.422259
# Unit test for function main
def test_main():
    # Set up arguments
    source = 'tests/data/ansible.cfg'
    data = 'MjE3OQo='

    test_args = dict(
        src=source
    )
    test_ansible_module = AnsibleModule(argument_spec=test_args)

    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    test_ansible_module.exit_json(content=data, source=source, encoding='base64')


# Generated at 2022-06-20 22:39:19.027716
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:39:28.049920
# Unit test for function main
def test_main():
    # Tests for slurp module
    module_args = dict(
        src='/tmp/foo.txt'
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:39:33.222293
# Unit test for function main
def test_main():

    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            src=dict(type='str', required=True),
        )
    )

    module.params = { 'src': '/usr/bin/env' }
    result = main()
    assert result['content'] == 'VVNSSQ=='
    assert result['encoding'] == 'base64'
    assert result['source'] == '/usr/bin/env'

# Generated at 2022-06-20 22:40:08.594555
# Unit test for function main
def test_main():
    source_content = "test_main"

    def mock_open(path, mode):
        class mock_file(object):
            def read(self):
                return source_content

        return mock_file()

    class AnsibleModuleMock(object):
        pass

    module = AnsibleModuleMock()

    try:
        mod = slurp.__package__ + '.slurp'
        from ansible.module_utils import basic
        basic.open = mock_open
        from ansible.module_utils import ansible_module_common
        ansible_module_common.AnsibleModule = lambda *args, **kwargs: module
        from ansible.modules.files import slurp
        main()
    except SystemExit as e:
        assert e.code == 0
        assert module.content == base64.b64encode

# Generated at 2022-06-20 22:40:11.853920
# Unit test for function main
def test_main():
    mod = AnsibleModule(argument_spec={
        'src': dict(type='path', required=True, aliases=['path']),
    })

    assert mod.params['src'] != None

# Generated at 2022-06-20 22:40:18.561320
# Unit test for function main
def test_main():
    # Leaks a tempfile due to https://github.com/ansible/ansible/issues/28490
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('foobar')
    module = MockModule()
    module.params = {'src': path}
    main(module)
    assert module.exit_args['content']
    assert module.exit_args['source']
    assert module.exit_args['encoding']

# Mock module for unit testing

# Generated at 2022-06-20 22:40:29.291945
# Unit test for function main
def test_main():
    def ns(**k):
        return (k['content'], k['encoding'], k['source'])
    # Create test file
    fd = os.open('/tmp/test_slurp_file', os.O_RDWR|os.O_CREAT, 0o644)
    os.write(fd, b'content')
    os.close(fd)
    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    m.params['src'] = '/tmp/test_slurp_file'
    # Test success

# Generated at 2022-06-20 22:40:39.621392
# Unit test for function main
def test_main():
    import tempfile
    from ansible.module_utils.six import b
    from ansible.module_utils.six import PY3
    (tmp, filename) = tempfile.mkstemp()
    testcontent = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    with os.fdopen(tmp, 'w') as f:
        f.write(testcontent)

    m = AnsibleModule(argument_spec=dict(src=dict(type='str', required=True, aliases=['path'])))
    setattr(m, 'params', dict(src=filename))
    m.exit_json = lambda x: None
    main()

# Generated at 2022-06-20 22:40:45.875872
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(
    argument_spec = dict(
        src = dict(type='path', required=True, aliases=['path']),
    ),
    supports_check_mode=True,
    )
    module.params['src'] = 'test_file'
    os.popen('echo -n  "content" > test_file')

    main()
    assert module.exit_json.called
    assert module.exit_json.call_args == call({'encoding': 'base64', 'changed': False, 'source': 'test_file', 'content': 'Y29udGVudA==', 'ansible_facts': {}})
    os.remove('test_file')


# Generated at 2022-06-20 22:40:52.850658
# Unit test for function main
def test_main():
    class Argv:
        def __init__(self, lst):
            self.lst = lst

        def __getitem__(self, i):
            return self.lst[i]

    argv = Argv(['ansible-test', '-vvvv', '-e', 'ansible_python_interpreter=/usr/bin/python3'])
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"src": "/etc/fstab"}'
    os.environ['ANSIBLE_STRATEGY'] = 'free'
    out = main()
    assert 'success' in out

# Generated at 2022-06-20 22:40:53.732549
# Unit test for function main
def test_main():
    assert 3 > 2


# Generated at 2022-06-20 22:41:00.945436
# Unit test for function main
def test_main():
    module = path.basename(__file__)
    module_args = {}
    sys.argv = [module, '-s']
    if os.name == 'nt':
        import locale
        locale.setlocale(locale.LC_ALL, 'English_United States.1252')
    sys.argv.append('-vvvv')
    sys.argv.append('-b')
    sys.argv.append('--timeout=20')
    sys.argv.append('--hosts=localhost')
    sys.argv.append('--force-color')
    sys.argv.append('--force-handlers')
    my_module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    my_module.run(False)
   

# Generated at 2022-06-20 22:41:07.439633
# Unit test for function main
def test_main():
    src = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "unit/files/sudoers"))
    args = {'src': src}

    result = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    ).execute_module(**args)

    assert result

# Generated at 2022-06-20 22:42:06.344849
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:42:15.563468
# Unit test for function main
def test_main():

    def test_module_args(module_args):
        module = AnsibleModule(
            argument_spec=dict(
                src=dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
        )
        module.params = module_args
        main()

    def test_file_exists():
        module_args = dict(
            src='/etc/passwd',
        )

        with open('/etc/passwd') as f:
            passwd = f.read()

        with patch('ansible.modules.files.slurp._load_file_contents', return_value=passwd):
            test_module_args(module_args)


# Generated at 2022-06-20 22:42:16.125485
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:42:24.584433
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:42:35.255183
# Unit test for function main
def test_main():
    mock_module = AnsibleModule(
        argument_spec={'src': {'type': 'path', 'required': True, 'aliases': ['path']}},
        supports_check_mode=True
    )
    mock_module.params = {'src': os.path.join(os.path.dirname(__file__), '../../../examples/files/sample.j2')}

    result = main()

# Generated at 2022-06-20 22:42:44.783199
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = "test_file.txt"
    fh = open(source, "w")
    fh.write("Hello World!")
    fh.close()
    module.params['src'] = source
    data = main()
    assert data == module.exit_json(content=b'SGVsbG8gV29ybGQh', source=source, encoding='base64')
    os.remove(source)

# Generated at 2022-06-20 22:42:47.087609
# Unit test for function main
def test_main():
   source_content = '2179'
   data = base64.b64encode(source_content)
   assert data == 'MjE3OQ=='

# Generated at 2022-06-20 22:42:57.687033
# Unit test for function main

# Generated at 2022-06-20 22:42:58.236663
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:43:06.560444
# Unit test for function main
def test_main():
    '''
    This is an example of a basic unit test.

    It takes the values defined in global_vars and populates the params with the
    values.  The result of the main function is then checked to see if matches
    the expected result.

    On most unix systems, the test can be run by executing the command `python -m doctest
    modules/actions/files/slurp.py`.

    In the future, it may be more appropriate to use a module like pytest (https://pytest.org/).
    '''
    global_vars = {
        'src': '/etc/passwd',
        'path': '/etc/passwd'
    }
