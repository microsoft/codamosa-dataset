

# Generated at 2022-06-20 22:35:16.123794
# Unit test for function main
def test_main():
    # Replace module with a fake one for testing
    # argument_spec=dict(
    #     src=dict(type='path', required=True, aliases=['path']),
    # ),
    # supports_check_mode=True,
    fake_module = object()
    fake_module.params = {'src': './test_main.py'}

# Generated at 2022-06-20 22:35:24.191398
# Unit test for function main
def test_main():
    # Slurp a file '/etc/hosts' on localhost, then compare its contents with
    # an expected result.
    expected = (
        b'127.0.0.1\tlocalhost\n'
        b'\n'
        b'# The following lines are desirable for IPv6 capable hosts\n'
        b'::\t\t\tlocalhost ip6-localhost ip6-loopback\n'
        b'ff02::1\t\tip6-allnodes\n'
        b'ff02::2\t\tip6-allrouters\n'
    )
    with open('/etc/hosts', 'rb') as file:
        content = file.read()
    assert(content == expected)

# Generated at 2022-06-20 22:35:35.822251
# Unit test for function main
def test_main():
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']
    with open(source, 'wb') as source_fh:
        source_content = source_fh.write("test content")

    data = main()
    if data[0] != "content":
        raise AssertionError("Expected content, received %s" % data[0])
    if data[1] != "source":
        raise AssertionError("Expected source, received %s" % data[1])

# Generated at 2022-06-20 22:35:45.726717
# Unit test for function main
def test_main():
    try:
        os.remove("/tmp/ansible_slurp_payload")
    except:
        pass
    os.symlink("/bin/ls","/tmp/ansible_slurp_payload")
    f = open("/tmp/ansible_slurp_check_mode","w")
    f.write("1")
    f.close()
    m = AnsibleModule(argument_spec=dict(src=dict(required=True, type='path', aliases=['path'])), check_mode=True)
    m.params['src'] = "/tmp/ansible_slurp_payload"
    main()
    assert m.params['src'] == "/tmp/ansible_slurp_payload"
    assert m.check_mode
    assert m.check_mode == True
   

# Generated at 2022-06-20 22:35:48.062322
# Unit test for function main
def test_main():
    mock_module = Mock()
    mock_module.params = {'src': '/var/run/sshd.pid'}
    main()

# Generated at 2022-06-20 22:35:48.808877
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-20 22:35:58.485384
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text.converters import to_text
    import base64
    import os
    # Define function
    def get_module_args():
        return dict(
            src='/var/run/sshd.pid',
        )

    def get_mock_module():
        m = AnsibleModule(
            argument_spec=dict(
                src=dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
        )
        return m

    def get_mock_data():
        return 'MjE3OQo='


# Generated at 2022-06-20 22:36:05.635340
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils import basic
    from os import path
    import datetime
    import os
    import tempfile
    id_dir = tempfile.mkdtemp()
    source = path.join(id_dir, 'testfile')
    with open(source, 'w') as source_fh:
        source_fh.write("test123\n")
    module = AnsibleModule(dict(src=source))
    main()
    assert module.exit_json.called

# Generated at 2022-06-20 22:36:14.785025
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    os.makedirs(module,source['content'])
    os.makedirs(module,source['source'])

# Generated at 2022-06-20 22:36:23.344306
# Unit test for function main
def test_main():
  test_module = AnsibleModule(
      argument_spec=dict(
          src=dict(type='path', required=True, aliases=['path']),
      ),
      supports_check_mode=True,
  )
  test_module.params['src'] = 'tests/test.txt'
  test_module.exit_json = lambda r: r
  result = main()
  assert result['content'] == 'aGVsbG8gd29ybGQKCg=='
  assert result['source'] == 'tests/test.txt'
  assert result['encoding'] == 'base64'

# Generated at 2022-06-20 22:36:37.597547
# Unit test for function main
def test_main():
    os.environ["ANSIBLE_REMOTE_TEMP"] = "/tmp"
    os.environ["ANSIBLE_MODULE_ARGS"] = "{'src': '/var/run/sshd.pid'}"
    module_args = to_native(os.environ["ANSIBLE_MODULE_ARGS"])
    fd, path = tempfile.mkstemp()
    os.close(fd)
    with open(path, "wb") as f:
        f.write("33")
    try:
        main()
    finally:
        os.remove(path)

# Generated at 2022-06-20 22:36:47.107407
# Unit test for function main
def test_main():
    test_args = dict(src='/etc/passwd')
    test_ansible_module = AnsibleModule(argument_spec=test_args)
    test_content_pre = base64.b64encode(open('/etc/passwd', 'rb').read())
    test_content_post = main()
    if type(test_content_post) == dict:
        try:
            test_result = dict(changed=False, ansible_facts=dict(content=test_content_pre, source='/etc/passwd', encoding='base64'))
            assert test_content_post == test_result
            return True
        except AssertionError:
            return False
    else:
        return False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:36:49.458489
# Unit test for function main
def test_main():
    # Unit tests are implemented here
    print("Unit test is not implemented here.")
    pass

# Generated at 2022-06-20 22:36:56.713773
# Unit test for function main
def test_main():
    # Set up mock objects for unit testing
    import ansible.module_utils.ansible_modlib_slurp

    # Get the module to test.  We need the args to set up the
    # mock module.
    args = {"src": "/foo/bar"}

    result = ansible.module_utils.ansible_modlib_slurp.main()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:37:06.167928
# Unit test for function main
def test_main():
    errno_mock = Mock()
    errno_mock.ENOENT = 2
    errno_mock.EACCES = 13
    errno_mock.EISDIR = 21
    os_mock = Mock()
    os_mock.open = Mock(side_effect=[
        Mock(),
        open_os_error(errno_mock.ENOENT),
        open_os_error(errno_mock.EISDIR),
        open_os_error(errno_mock.EACCES)
    ])
    ansible_mock = Mock()
    ansible_mock.exit_json = Mock()

# Generated at 2022-06-20 22:37:07.340405
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 22:37:15.224670
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile
    temp_dir = tempfile.gettempdir()
    ansible_module_args = dict(
        src=os.path.join(temp_dir, 'test.txt'),
        encoding='base64',
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    with open(ansible_module_args['src'], 'w') as source_fh:
        source_fh.write("testing")

    result = None
    data = None
    source = None
    encoding = None
    source_content = None

# Generated at 2022-06-20 22:37:26.555962
# Unit test for function main
def test_main():
    import filecmp
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Prepare a test directory, with a test file and test module
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'testfile')
    test_module = os.path.join(test_dir, 'ansible_module_slurp.py')

    shutil.copyfile('ansible_module_slurp.py', test_module)

    with open(test_file, 'w') as f:
        f.write("12345")

    module = AnsibleModule(argument_spec=dict())
    module.params['src'] = test_file
    module.params['encoding'] = 'base64'
    module

# Generated at 2022-06-20 22:37:37.035990
# Unit test for function main
def test_main():
    import os
    import base64
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = dict(
        src=dict(type='path', required=True, aliases=['path']),
    )

    try:
        with open(os.path.join(os.path.dirname(__file__), 'test_fetch_file'), 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        raise Exception("unable to slurp file: %s" % to_native(e, errors='surrogate_then_replace'))

    data = base64.b64encode(source_content)


# Generated at 2022-06-20 22:37:47.023002
# Unit test for function main
def test_main():
    bsrc = os.open('/tmp/ansible-slurp-testing', os.O_CREAT|os.O_RDWR)
    os.write(bsrc, b'hello')
    os.close(bsrc)

    ANSIBLE_MODULE_ARGS = {'src': '/tmp/ansible-slurp-testing'}
    module = AnsibleModule(ANSIBLE_MODULE_ARGS, supports_check_mode=True)
    module.exit_json(content=base64.b64encode(b'hello'), source='/tmp/ansible-slurp-testing', encoding='base64')

    os.remove('/tmp/ansible-slurp-testing')

# Generated at 2022-06-20 22:38:03.346128
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True, aliases=['path'])))
    module.params['src'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), '__init__.py')
    main()

# Generated at 2022-06-20 22:38:13.239212
# Unit test for function main
def test_main():
    module_args = dict(
        src='/does/not/exist',
    )
    result = dict(
        content='',
        source='',
        encoding='',
        failed=True,
        msg='file not found: /does/not/exist',
    )

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=module_args)
    exit_args = dict(failed=True, msg='file not found: /does/not/exist')
    with module.exit_json.expect_call(exit_args):
        module.params['src'] = '/does/not/exist'
        module.params['debug']['support'] = False
        main()

# Generated at 2022-06-20 22:38:14.608467
# Unit test for function main
def test_main():
    # Return true for success, false for failure
    assert(True)

# Generated at 2022-06-20 22:38:22.824184
# Unit test for function main
def test_main():
    from unittest.mock import patch, MagicMock, _patch
    from ansible.module_utils.basic import AnsibleModule

    def test_inner(mocker, side_effect):
        # setup test values
        params = dict(
            src='/path/to/file.yaml',
        )

        # setup the mock
        mock_module = MagicMock(name='AnsibleModule')
        mock_module.params = params
        mock_open = mocker.patch(__name__ + '.open')
        mock_open.side_effect = side_effect
        mock_base64 = mocker.patch(__name__ + '.base64')
        mock_base64.b64encode = lambda x: x.upper()

        # run the command
        main()

        # assert that the mock_open was called as

# Generated at 2022-06-20 22:38:30.762103
# Unit test for function main
def test_main():
    src = os.path.abspath(__file__)
    with open(src, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    in_data = {
        'changed': False,
        'content': str(data, 'utf-8'),
        'encoding': 'base64',
        'source': src,
    }
    assert main() == in_data

# Generated at 2022-06-20 22:38:31.369165
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:38:34.587307
# Unit test for function main
def test_main():
    dict_args = dict(src="./testfile.csv")
    main.__dict__['params'] = dict_args
    main.__dict__['exit_json'] = lambda self, changed, meta: print(meta)
    main()

# Generated at 2022-06-20 22:38:43.932523
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    os.chdir('tests/module_utils/ansible_test_mock')
    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:38:45.862230
# Unit test for function main
def test_main():
    assert(main() is None)


# Generated at 2022-06-20 22:38:56.647957
# Unit test for function main
def test_main():
    # Expected behaviour:
    expected_result = {
        "changed": False,
        "content": "YW5zaWJsZS5saWJyYXJ5Cg==",
        "encoding": "base64",
        "source": "ansible.library"
    }

    # Unit under test
    import ansible.modules.utilities.remote_management.slurp as module_uut

    # Make a temporary file with content: "ansible.library\n"
    import tempfile
    tmp = tempfile.NamedTemporaryFile()
    tmp.write("ansible.library\n".encode('utf-8'))
    tmp.flush()

    # To pass in test as module_uut.AnsibleModule, must be emitted by mock.
    m = mock.Mock()
    m

# Generated at 2022-06-20 22:39:29.637521
# Unit test for function main
def test_main():
    # Empty args
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Args
    module = AnsibleModule(argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'testdata', 'testfile')

    # Fail
    try:
        module.params['src'] = '/invalid/file'
        main()
        assert False
    except Exception as e:
        assert e.args[0] == "file not found: /invalid/file"

    # Fail

# Generated at 2022-06-20 22:39:37.317363
# Unit test for function main
def test_main():
    src = '~/foo/bar.json'
    with open(src, 'r') as f:
        src_content = f.read()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    original_import = __import__
    def import_mock(name, *args):
        if name == 'ansible.module_utils.basic':
            raise ImportError
        return original_import(name, *args)

    # Good case

# Generated at 2022-06-20 22:39:38.432533
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 22:39:47.842713
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                    src=dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
    )

    # Test no src
    with pytest.raises(AnsibleFailJson):
        module.params['src'] = None
        main()

    # Test directory
    with pytest.raises(AnsibleFailJson):
        module.params['src'] = 'test/test_slurp_module/'
        main()

    # Test file
    with mock.patch.object(os, 'open') as mock_open, mock.patch.object(os, 'fdopen') as mock_fdopen:
        mock_open.return_value = 3
        mock_fdopen.return_value.__enter

# Generated at 2022-06-20 22:39:59.287777
# Unit test for function main
def test_main():
    from ansible.module_utils import arguments
    from ansible.module_utils import basic
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.utils import context_objects as co

    # Define a test module
    module_args = dict(src='/etc/hosts')
    module_name = 'ansible.builtin.slurp'
    module_class = arguments.AnsibleModule
    module_class.no_log = True
    module = module_class(module_name, module_args, bypass_checks=True)

    # Set various context objects
    co.GlobalCLIArgs(connection=None, module_path=None, forks=10, become=False, become_method='sudo', become_user='root', check=False, diff=False)
    context = co.An

# Generated at 2022-06-20 22:40:08.269877
# Unit test for function main
def test_main():
    import os
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=False,
    )
    source = module.params['src']

    CreateTestFile = True
    # Create some stuff to test with
    if CreateTestFile == True:
        TestFile = tempfile.NamedTemporaryFile(delete=False)
        TestFile.file.write(b'This is some text\n' * 1024)
        TestFile.file.close()
        TestFileSize = os.path.getsize(TestFile.name)
        TestFileData = open(TestFile.name, 'rb').read(TestFileSize)

# Generated at 2022-06-20 22:40:18.368428
# Unit test for function main
def test_main():
    test_spec = dict(src=dict(type='path', required=True, aliases=['path']),)
    module = AnsibleModule(argument_spec=test_spec)
    source = module.params['src']
    source_content = b'Test Content'
    try:
        with open(source, 'wb') as source_fh:
            source_fh.write(source_content)
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()

    except (IOError, OSError) as e:
        msg = "unable to slurp file: %s" % to_native(e, errors='surrogate_then_replace')
        module.fail_json(msg)

    data = base64.b64encode(source_content)



# Generated at 2022-06-20 22:40:24.520056
# Unit test for function main
def test_main():
    # Set up the stubs for main
    source = '/tmp/source'
    source_content = b'This is source content'

    def open_side_effect(path, mode):
        '''
        Return correct values based on path and mode
        '''
        open_side_effect.obj = type('FakeFile', (), {"read": lambda self: source_content})
        if path == source and mode == 'rb':
            return open_side_effect.obj
        raise OSError(errno.ENOENT)

    def base64_b64encode(data):
        return b'thisisencoded'


# Generated at 2022-06-20 22:40:32.276973
# Unit test for function main
def test_main():
    src = 'test_main_src.txt'
    source_content = b'test content'
    with open(src, 'wb') as f:
        f.write(source_content)
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = src
    try:
        res = main()
        assert res['content'] == b'IHRlc3QgY29udGVudA=='
    finally:
        os.remove(src)

# Generated at 2022-06-20 22:40:35.691665
# Unit test for function main
def test_main():
    import doctest
    results = doctest.testmod(action, raise_on_error=False)
    if results.failed > 0:
        raise RuntimeError("%d test failures" % results.failed)

# Generated at 2022-06-20 22:41:42.330988
# Unit test for function main
def test_main():
    import json

    # Field src = /var/run/sshd.pid
    # Field content = MjE3OQo=
    # Field encoding = base64
    # Field source = /var/run/sshd.pid
    test_data = '''{
  "changed": false,
  "content": "MjE3OQo=",
  "encoding": "base64",
  "source": "/var/run/sshd.pid"
}'''

    args = dict(
        src='/var/run/sshd.pid',
    )
    hostname = 'localhost'
    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True,
    )

    with open('/var/run/sshd.pid', 'wb') as f:
        f

# Generated at 2022-06-20 22:41:51.185886
# Unit test for function main
def test_main():
    # Create a test module
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Create a test file
    test_file = "test_slurp_module.txt"
    output = "Hello World"
    f = open(test_file, "w")
    f.write(output)
    f.close()
    test_module.params['src'] = test_file
    # Call main()
    main()
    # Clean test file
    os.remove(test_file)

# Generated at 2022-06-20 22:41:56.670987
# Unit test for function main
def test_main():
    def fake_read(input_data):
        if input_data == '/etc/hosts':
            return '127.0.0.1\tlocalhost'
        else:
            raise IOError

    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'])
        )
    )
    m._ansible_module._find_needle = fake_read
    out = main()
    assert out['content'] == 'MTI3LjAuMC4xCmxvY2FsaG9zdA=='

# Generated at 2022-06-20 22:42:08.360040
# Unit test for function main
def test_main():
    
    # mock the arguments in module
    src = os.path.dirname(os.path.realpath(__file__)) + '/../../file_to_slurp'
    with open(src, 'w+') as f:
        f.write('slurp')
    module_args = {'src': src,
                  }
    mock_module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']),
     ),
     supports_check_mode=True,
    )
    mock_module.params = module_args
    
    # run the code to test
    main()
    
    # assert
    assert mock_module.exit_json.call_count == 1
    assert mock_module.fail_json.call_count == 0
   

# Generated at 2022-06-20 22:42:11.363378
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

# Generated at 2022-06-20 22:42:20.763466
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:42:31.247815
# Unit test for function main
def test_main():
    # get our module object
    from ansible.modules.packaging.os import slurp
    module = slurp
    # set correct args
    module.params = {'src' :'/etc/services'}
    # test for 'success'
    res = module.main()
    # test for 'failure'
    param_merge = {'src' :'/tmp/does_not_exist'}
    module.params.update(param_merge)
    res = module.main()
    assert res['msg'] == 'file not found: /tmp/does_not_exist'
    from ansible.modules.packaging.os import slurp
    module = slurp
    # set correct args
    param_merge = {'src': '/etc/services'}

# Generated at 2022-06-20 22:42:35.214758
# Unit test for function main
def test_main():
    import tempfile
    # Test file encode to base64
    temp = tempfile.NamedTemporaryFile(mode="w+t")
    temp.writelines("Hello")
    temp.seek(0)
    result = main({'src': temp.name})
    assert result['content'] == 'SGVsbG8='
    temp.close()

# Generated at 2022-06-20 22:42:43.161561
# Unit test for function main
def test_main():
    source = os.path.join(os.path.dirname(__file__), 'ansible_module_slurp.py')
    module = AnsibleModule({'src': source}, check_mode=False)
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    assert main() == {'content': data, 'encoding': 'base64', 'source': source}

# Generated at 2022-06-20 22:42:52.573543
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    source = os.path.join(os.path.dirname(__file__), "main.py")

    def _runner(module_args):
        return basic._ANSIBLE_ARGS

    args, kwargs = _runner({"src": source})

    assert args == [source, '-m', 'ansible.builtin.slurp', '-a', 'src={}'.format(source)]
    assert kwargs['args'] == []
    assert kwargs['private_data_dir'] is not None

    m = main()
    assert m['content'] == b'YQ=='
    assert m['encoding'] == 'base64'
    assert m['source'] == to_bytes(source)

