

# Generated at 2022-06-20 22:35:19.815769
# Unit test for function main
def test_main():
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'foo')
        temp.flush()
        # Can't easily test b64decode() output, so we'll just ensure that the API is consistent with AnsibleModule
        # by checking that the 'source' item exists and is the same as the filename
        module = AnsibleModule(dict(src=temp.name))
        result = main(module)
        assert result['source'] == temp.name

# vim: expandtab shiftwidth=4 tabstop=4

# Generated at 2022-06-20 22:35:26.848998
# Unit test for function main
def test_main():
    # The following arguments and data are what get passed to the module by Ansible
    # (mocks of stdin and stdout in case we need them)
    global __stdout
    global __stdin
    __stdout = StringIO()
    __stdin = StringIO(u'''{
    "changed": false,
    "an_attribute": {
        "key": "value",
        "another_key": "another_value"
    }
}''')

    # Parse the JSON we get from Ansible and pass it in as __ansible_facts__
    class ReturnData(object):
        def __init__(self, params, module):
            self.params = params
            self.module = module

        @staticmethod
        def exit_json(*args, **kwargs):
            sys.exit(0)


# Generated at 2022-06-20 22:35:35.195777
# Unit test for function main
def test_main():
    test_parameters = dict(
        src = __file__
   )

    m = AnsibleModule(argument_spec=test_parameters)
    with open(m.params['src'], 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    assert m.exit_json(content=data, source=m.params['src'], encoding='base64') is None


# Generated at 2022-06-20 22:35:45.205949
# Unit test for function main
def test_main():
    import json
    import tempfile
    import os
    import datetime
    from ansible_collections.ansible.community.plugins.module_utils.common.text.converters import to_bytes
    from ansible_collections.ansible.community.plugins.module_utils.common.collections import is_iterable

    b_text = to_bytes("Hello World!")
    b_text_base64 = b'SGVsbG8gV29ybGQh'

    # Create a temporary file
    tf = tempfile.NamedTemporaryFile()

    # Fill the file with some data
    tf.write(b_text)
    tf.flush()
    tf.seek(0)

    # Create a new module object

# Generated at 2022-06-20 22:35:51.331403
# Unit test for function main
def test_main():
    os.path.exists = lambda x: True
    open = lambda x, y: "File handle"

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    file_handle = main()
    assert file_handle == "File handle"

# Generated at 2022-06-20 22:36:02.639237
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    my_test_file = b'abcdefg\n1234567\n'
    my_src_file = '/tmp/test_file'
    with open(my_src_file, 'wb') as f:
        f.write(my_test_file)
    my_args = {
        'src': my_src_file,
    }
    my_path = os.path.dirname(os.path.abspath(__file__))
    my_tmp_path = os.path.join(my_path, 'unit_test_tmp')
    try:
        import os
        os.mkdir(my_tmp_path)
    except OSError:
        pass

# Generated at 2022-06-20 22:36:10.586940
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:36:15.262142
# Unit test for function main
def test_main():
    # {"args": {"src": "/tmp/test.txt"}, "path": "/home/ansible/ansible-master/bin/ansible-test", "changed": false, "invocation": {"module_args": {"src": "/tmp/test.txt", "warn": false}}, "failed": false, "warnings": []}
    assert True

# Generated at 2022-06-20 22:36:25.446358
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    class Custom1Exception(Exception):
        pass

    class Custom2Exception(Exception):
        pass

    class Custom3Exception(Exception):
        pass

    def fail_json(msg):
        raise Custom1Exception(msg)

    def open(path, mode):
        if path == "foo":
            if mode == "r":
                return StringIO("foo")
            if mode == "rb":
                return StringIO("foo")
            if mode == "rb+":
                return StringIO("foo")
        if path == "bar":
            if mode == "rb":
                raise Custom2Exception("bar")

# Generated at 2022-06-20 22:36:37.160076
# Unit test for function main
def test_main():
    filename = "test_slurp_file"
    test_data = "test data to test config file"
    with open(filename, 'w') as fp:
        fp.write(test_data)
    test_args = {
        'src': filename,
    }
    test_result = {
        'content': base64.b64encode(test_data),
        'encoding': 'base64',
        'source': filename,
    }
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = lambda **args: None
    assert( test_module.params == {} )
    main()
   

# Generated at 2022-06-20 22:36:44.358222
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:36:48.552453
# Unit test for function main
def test_main():
    test_params = {
        'src': '/var/run/sshd.pid',
    }
    return_value = main({'params': test_params})
    assert return_value['content'] == 'MjE3OQo='
    assert return_value['source'] == '/var/run/sshd.pid'
    assert return_value['encoding'] == 'base64'

# Generated at 2022-06-20 22:36:59.736004
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:37:03.674315
# Unit test for function main
def test_main():
    source = '/var/run/sshd.pid'
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    expected = {'content': base64.b64encode(source_content), 'source': source, 'encoding': 'base64'}
    assert main() == expected

# Generated at 2022-06-20 22:37:14.053884
# Unit test for function main
def test_main():
    '''
    Unit test for main
    '''

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Test fail_json(message, kwargs)
    class TestFailJson(object):
        def __init__(self):
            self.message = ""
            self.kwargs = ""

        def __call__(self, message, kwargs):
            self.message = message
            self.kwargs = kwargs

    test_fail_json = TestFailJson()
    module.fail_json = test_fail_json

    # Test exit_json(kwargs)

# Generated at 2022-06-20 22:37:24.949915
# Unit test for function main
def test_main():
    from ansible.constants import DEFAULT_MODULE_PATH
    import os
    import tempfile
    import subprocess

    # create a temporary file
    fd, path = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')
    fh.write('hello')
    fh.close()

    module_path = '%s/%s' % (DEFAULT_MODULE_PATH, 'slurp.py')
    cmd = [
        'python',
        module_path,
        'src=' + path,
    ]
    env = os.environ.copy()
    rc, out, err = subprocess.getstatusoutput('\n'.join(cmd))

# Generated at 2022-06-20 22:37:25.708324
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:37:26.497070
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 22:37:38.291057
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_fetch_slurp.py'))
    module.params = {'src':source}
    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-20 22:37:46.115569
# Unit test for function main
def test_main():
    main_args = ['/var/run/sshd.pid']
    orig_open = __builtins__['open']

    class FakeFileHander(object):
        def __init__(self, *args, **kwargs):
            self.data = 'This is a fake file'
            pass

        def read(self, *args, **kwargs):
            return self.data

        def __call__(self, *args, **kwargs):
            return self

    __builtins__['open'] = FakeFileHander()
    main(main_args)

# Generated at 2022-06-20 22:38:08.051092
# Unit test for function main
def test_main():
    # Create a mock module
    class Module:
        def __init__(self, src):
            self.params = {'src': src}

        def fail_json(self, msg, **kwargs):
            print('FAILED: %s' % msg)

        def exit_json(self, content, source, encoding, **kwargs):
            print('SUCCESS: content:%s, source:%s, encoding:%s' % (content, source, encoding))

    # Create a pretend file for slurping
    tmp = os.path.realpath(__file__)
    dir_tmp = os.path.dirname(tmp)
    pretend_file = os.path.join(dir_tmp, 'pretend')

# Generated at 2022-06-20 22:38:12.800815
# Unit test for function main
def test_main():
    test_module = AnsibleModule({'src': 'test_file', 'check_mode': True})
    assert main() == test_module.exit_json(content=base64.b64encode(b'test_file'), source="test_file", encoding='base64')

# Generated at 2022-06-20 22:38:21.518354
# Unit test for function main
def test_main():
    # Unit test main function
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:38:33.159555
# Unit test for function main
def test_main():
    source = "/var/run/sshd.pid"

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg = "source is a directory and must be a file: %s" % source
        else:
            msg = "unable to slurp file: %s" % to_native(e, errors='surrogate_then_replace')

        module.fail_

# Generated at 2022-06-20 22:38:37.268168
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    assert source == '/test/file/'

# Generated at 2022-06-20 22:38:46.275351
# Unit test for function main
def test_main():
    import tempfile
    source_handle, source_file = tempfile.mkstemp()
    with os.fdopen(source_handle, 'w') as source_handle:
        source_handle.write("line1\nline2\n")

    original_source_content = None
    with open(source_file, 'rb') as source_handle:
        original_source_content = source_handle.read()

    module_args = dict(
        src=source_file,
    )
    result = dict(
        ansible_facts=dict(
            slurp_content=original_source_content,
            slurp_source=source_file,
            slurp_encoding='base64',
        )
    )


# Generated at 2022-06-20 22:38:55.210582
# Unit test for function main
def test_main():
    src = os.path.join(os.path.dirname(__file__), 'test_sslurp.py')
    test = {
        'module': __name__,
        'src': src
    }
    res = None
    with open(src, 'r') as source_fh:
        original_content = source_fh.read()
    try:
        res = main(test)
    except Exception as ex:
        print("Exception from main: %s" % str(ex))
    assert res['content'] == base64.b64encode(original_content)
    assert res['encoding'] == 'base64'
    assert res['source'] == src

# Generated at 2022-06-20 22:38:57.554253
# Unit test for function main

# Generated at 2022-06-20 22:39:09.722674
# Unit test for function main
def test_main():
    # Test running module. Checks return code and matching output.
    src = '/var/run/sshd.pid'
    src_content = b'2179\n'
    expected_b64 = b'MjE3OQo='

    ansible_args = {'src': src}
    module_args = AnsibleModule(argument_spec=dict(src=dict(type='path')), supports_check_mode=True).argument_spec
    with open(src, 'wb') as source_fh:
        source_fh.write(src_content)

    m = AnsibleModule(ansible_args, module_args, supports_check_mode=True)

    main()
    result = m.exit_json.call_args[0][0]
    assert result['content'] == expected_b64

# Generated at 2022-06-20 22:39:21.626042
# Unit test for function main
def test_main():
    import tempfile 
    import shutil
    import os
    import json

    dummy_file = '/tmp/test_file'
    dummy_data = 'test_file data'

    with open(dummy_file, 'w') as fp:
        fp.write(dummy_data)
    
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = dummy_file

    main()
    res_args = module.exit_args
    assert str(res_args['content'], 'utf-8') == "dGVzdF9maWxlIGRhdGE=\n"
    assert res_args['source']

# Generated at 2022-06-20 22:39:59.202561
# Unit test for function main
def test_main():
    filename = "test.txt"
    content ="Hello world!\n"
    with open(filename, 'wb') as f:
        f.write(content.encode('ascii'))

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']
    with open(filename, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)

    assert source == filename
    assert data == 'SGVsbG8gd29ybGQhCg=='
    assert source_content == content.encode('ascii')

# Generated at 2022-06-20 22:40:04.890262
# Unit test for function main
def test_main():
    from ansible.modules.commands.slurp import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except IOError as e:
        if e.errno == os.errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-20 22:40:11.948200
# Unit test for function main
def test_main():
    source = '/tmp/file.txt'
    content = 'test content'
    with open(source, 'w') as f:
        f.write(content)
    o = {'src': source}
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True, aliases=['path'])), supports_check_mode=True)
    module.params = o
    m = test_main()
    assert os.path.exists(source)
    os.remove(source)

# Generated at 2022-06-20 22:40:21.723848
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_general as ag
    import ansible.module_utils.connection as connection
    import json
    import os
    import tempfile
    import shutil

    mock_loader_class = ag.AnsibleModule
    options = {
        'src': '/etc/hosts',
    }
    module_name  = 'slurp'
    module_path = 'ansible.modules.files.slurp'

    # create temp directory and file
    temp_dir = tempfile.mkdtemp()
    test_hosts_file = os.path.join(temp_dir, 'hosts')

    # Create a valid base64 encoded version of the hosts file
    test_hosts_file_bytes = open('/etc/hosts', 'rb').read()
    test_hosts_file

# Generated at 2022-06-20 22:40:31.521049
# Unit test for function main
def test_main():
    # Test module argument parsing
    args = dict(
        src='/var/run/sshd.pid',
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = args
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-20 22:40:34.660058
# Unit test for function main
def test_main():
    # main() called with the wrong arguments
    with pytest.raises(AnsibleFailJson):
        main({'wrong_args' : 123})


# Generated at 2022-06-20 22:40:37.218726
# Unit test for function main
def test_main():

    # Run function and fail if an exception was raised
    try:
        main()
    except Exception as err:
        assert False, str(err)



# Generated at 2022-06-20 22:40:44.623007
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.modules import slurp
    source = b'/proc/mounts'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = source
    slurp.main()
    assert module.exit_json['content'] == base64.b64encode(to_bytes(open(source).read()))
    assert module.exit_json['encoding'] == 'base64'
    assert module.exit_json['source'] == source

# Generated at 2022-06-20 22:40:45.359881
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:40:54.966195
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        mycontent = open(source, 'rb')
        source_content = mycontent.read()
        mycontent.close()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-20 22:42:02.256970
# Unit test for function main
def test_main():
    os.path.isfile = fake_os_path_isfile
    os.path.isdir = fake_os_path_isdir
    os.access = fake_os_access

    open = fake_open
    fake_module = FakeModule()
    main()

    assert fake_module.fail_json.called is True
    assert fake_module.exit_json.called is False
    assert fake_module.params['src'] == 'test'

# Generated at 2022-06-20 22:42:07.887389
# Unit test for function main
def test_main():
    """ pseudo-testing of module.  This just exercises most of the code. """
    # Unit test needs valid args, so make some up
    args = dict(src='/bin/ls')
    # source is a real file, so this should work
    main()

    # Now break things by changing source to a directory
    args.update(src='/tmp')
    main()

# Generated at 2022-06-20 22:42:17.121963
# Unit test for function main
def test_main():
    module_path = os.path.join(os.path.dirname(__file__), "slurp_test.py")
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module_path
    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source


# Generated at 2022-06-20 22:42:24.595267
# Unit test for function main
def test_main():
    # Test module without required arguments
    m = AnsibleModule(dict())

    # Test with missing required argument
    with pytest.raises(AnsibleFailJson):
        m.fail_json.assert_called_with(msg='missing required arguments: src')

    # Test module as if it were triggered by the ansible cmdline
    m = AnsibleModule(
        dict(
            src='/tmp/testfile',
        )
    )
    m.exit_json = exit_json
    m.exit_json.assert_called_with(changed=False, content=base64.b64encode('TEST CONTENTS\n'), encoding='base64', source='/tmp/testfile')

# EOF

# Generated at 2022-06-20 22:42:35.294349
# Unit test for function main
def test_main():
    import tempfile
    tempdir = tempfile.mkdtemp()
    testfile = os.path.join(tempdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('Hello, world!')
    with open(testfile, 'rb') as f:
        expected_content = f.read()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = testfile

    try:
        main()
        assert False, "main() should always exit with exception"
    except SystemExit as e:
        assert e.code == 0
        result = module.exit_args

# Generated at 2022-06-20 22:42:46.565213
# Unit test for function main
def test_main():
    assert os.path.exists('/var/run/sshd.pid')

    args = {
        'src': '/var/run/sshd.pid',
    }

    result = AnsibleModule(argument_spec=args).execute_module()

    assert result['encoding'] == 'base64'
    assert result['source'] == '/var/run/sshd.pid'

    decoded = base64.b64decode(result['content']).decode('utf-8')
    assert decoded.strip() == str(os.getpid())

    assert result['changed'] == False

    args = {
        'src': '/bad/file/path',
    }

    with pytest.raises(SystemExit):
        result = AnsibleModule(argument_spec=args).execute_module()

# Generated at 2022-06-20 22:42:48.876992
# Unit test for function main
def test_main():
    args = dict(src="/etc/passwd")
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = args
    main()

# Generated at 2022-06-20 22:42:59.449588
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    if os.path.exists("ansible_module_slurp"):
        result = main()
        assert result['encoded'] == 'SU1pT1JFb25TdXJyb3VuZGVkUmVwbGFjZQ=='
        assert result['source'] == 'ansible_module_slurp'

    with pytest.raises(Exception) as excinfo:
        main()
    assert excinfo.value.message == "unable to slurp file: [Errno 2] No such file or directory: 'does_not_exist"

# Generated at 2022-06-20 22:43:07.491230
# Unit test for function main
def test_main():
    ''' Unit test for function main '''

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg

# Generated at 2022-06-20 22:43:16.814252
# Unit test for function main
def test_main():
    # Test that an exception is raised when a file is not found.
    test_args = {"src": "/path/to/file"}
    test_cwd = os.getcwd()
    module = AnsibleModule(argument_spec=test_args)
    module.exit_json = lambda x: x
    result = main()
    assert result['msg'] == 'file not found: /path/to/file'
    assert result['failed']
    assert result['changed'] == False