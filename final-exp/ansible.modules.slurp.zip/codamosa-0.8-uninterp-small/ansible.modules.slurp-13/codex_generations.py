

# Generated at 2022-06-25 03:16:59.221974
# Unit test for function main
def test_main():
    assert True



# Generated at 2022-06-25 03:17:00.294740
# Unit test for function main
def test_main():
    try:
        pass
    except Exception as e:
        raise e



# Generated at 2022-06-25 03:17:01.257605
# Unit test for function main
def test_main():
    assert(main() == "MjE3OQo=")

# Generated at 2022-06-25 03:17:06.187211
# Unit test for function main
def test_main():
    # Check that ansible.module_utils.basic.AnsibleModule is implemented
    assert hasattr(ansible.module_utils.basic.AnsibleModule, '__init__')

    # Check that ansible.module_utils.common.text.converters is implemented
    assert hasattr(ansible.module_utils.common.text.converters, 'to_native')

    # Check that main is implemented
    assert hasattr(main, '__call__')

# Generated at 2022-06-25 03:17:16.068241
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = r'\var\run\sshd.pid'
    var_2 = os.path.exists(var_1)
    if var_2 == False:
        var_0 = open(var_1, 'w')
        var_0.close()
    var_3 = b'\x31\x32\x33\x0a'
    var_4 = base64.b64encode(var_3)
    assert var_4 == var_4
    try:
        var_0 = open(var_1, 'r')
        var_0.close()
        var_5 = True
    except:
        var_5 = False
    if var_5 == False:
        os.unlink(var_1)
    return var_4

# Generated at 2022-06-25 03:17:18.890149
# Unit test for function main
def test_main():
    #
    # No return value from the main function?
    # This is a bad thing.
    #
    assert var_0 == 0



if __name__ == '__main__':
    pass

# Generated at 2022-06-25 03:17:19.521753
# Unit test for function main
def test_main():
    # pass
    pass

# Generated at 2022-06-25 03:17:28.644388
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            raise



if __name__ == '__main__':
    import sys
    import unittest
    from unittest.mock import MagicMock, patch

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False


# Generated at 2022-06-25 03:17:35.979458
# Unit test for function main
def test_main():
    # First test
    var_1 = {
        'changed': True,
        'content': 'MjE3OQo=',
        'failed': False,
        'source': '/var/run/sshd.pid',
        'src': '/var/run/sshd.pid',
        'encoding': 'base64',
    }
    var_2 = {'src': '/var/run/sshd.pid'}
    var_3 = main(**var_2)
    assert var_3 == var_1