

# Generated at 2022-06-25 03:17:00.823974
# Unit test for function main
def test_main():
    with patch('builtins.open', mock_open(read_data=''), create=True):
        with patch('base64.b64encode', side_effect=('t1', 't2')):
            main()



# Generated at 2022-06-25 03:17:09.662064
# Unit test for function main
def test_main():

    try:
        os.unlink("/tmp/test.tmp")
    except IOError:
        pass
    fp = open("/tmp/test.tmp", "w")
    fp.write("ABCD")
    fp.close()

    args = {}
    args.update({u'src': u'/tmp/test.tmp'})
    ret = main(**args)
    assert ret["content"] == u'QUJDRA=='
    assert ret["encoding"] == u'base64'
    assert ret["source"] == u'/tmp/test.tmp'

    os.unlink("/tmp/test.tmp")

# vim: expandtab tabstop=4 shiftwidth=4