

# Generated at 2022-06-17 05:18:11.854160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:18:16.530934
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:18:28.250207
# Unit test for function main

# Generated at 2022-06-17 05:18:38.692486
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:18:46.183446
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:18:56.831302
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    result = main()
    assert result['content'] == 'IyAtKi0gY29kZWQgaW4gYmFzZTY0Cg=='
    assert result['source'] == os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    assert result['encoding'] == 'base64'

    # Test with a file that does not exist
    module

# Generated at 2022-06-17 05:19:01.865545
# Unit test for function main
def test_main():
    source = '/var/run/sshd.pid'
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    assert main() == {'content': data, 'source': source, 'encoding': 'base64'}

# Generated at 2022-06-17 05:19:10.942386
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:19:19.671095
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:19:25.993610
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:19:49.522884
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:20:00.090064
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:20:15.336538
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:20:25.413347
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    module.exit_json(content=data, source=source, encoding='base64')
    assert module.params['src'] == source
    assert module.params['encoding'] == 'base64'

# Generated at 2022-06-17 05:20:36.905533
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:20:52.955074
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:21:03.899638
# Unit test for function main
def test_main():
    # Test with a file that does not exist
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg

# Generated at 2022-06-17 05:21:13.691578
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:21:28.115587
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Write some data to the temporary file
    tmpfile.write(b"Hello World!")
    tmpfile.flush()

    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Set the module_utils path
    module.module_utils_path = os.path.join(os.path.dirname(__file__), '..', 'module_utils')



# Generated at 2022-06-17 05:21:35.214750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:22:12.814944
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:22:23.346152
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:22:33.343541
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp.py')

# Generated at 2022-06-17 05:22:44.559607
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = os.path.realpath(__file__)
    main()
    assert module.exit_json_called
    assert module.exit_json_args['content']
    assert module.exit_json_args['source'] == source
    assert module.exit_json_args['encoding'] == 'base64'

    # Test with a file that does not exist

# Generated at 2022-06-17 05:22:56.331587
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:23:06.408805
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = __file__
    main()

    # Test with a file that does not exist
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = __file__ + '.not_there'
    main()

    # Test with a directory

# Generated at 2022-06-17 05:23:16.914409
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    import base64
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Create the module object
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Set module args
    module.params['src'] = os.path.join(tmpdir, 'test')

    # Run the module
    result = main()

    # Remove the temporary directory
    shutil.rmtree

# Generated at 2022-06-17 05:23:26.983371
# Unit test for function main

# Generated at 2022-06-17 05:23:34.887441
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    result = main()
    assert result['content'] == 'IyAtKi0gY29kZWQgaW4gYmFzZTY0Cg=='
    assert result['source'] == os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    assert result['encoding'] == 'base64'

    # Test with a file that does not exist
    module

# Generated at 2022-06-17 05:23:46.576701
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:24:59.507808
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp.py')
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    assert main() == module.exit_json(content=data, source=source, encoding='base64')

    # Test with a file that does not exist

# Generated at 2022-06-17 05:25:09.344915
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    import base64
    import sys
    import json

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_content = 'test_content'

    with open(test_file, 'w') as f:
        f.write(test_content)

    sys.argv = [
        'ansible-test',
        'slurp',
        '-a',
        'src=%s' % test_file,
    ]

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 05:25:22.753203
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:25:34.724942
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:25:45.861499
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:25:56.052268
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = os.path.join(os.path.dirname(__file__), 'test_slurp_file')
    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-17 05:26:06.252105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-17 05:26:17.449362
# Unit test for function main
def test_main():
    # Test with a file that exists
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src'] = __file__
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    module.exit_json(content=data, source=source, encoding='base64')

    # Test with a file that does not exist

# Generated at 2022-06-17 05:26:26.066853
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import base64
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = os.path.join(tmpdir, "tmpfile")
    with open(tmpfile, "wb") as f:
        f.write(b"Hello World")

    # Create the module invocation
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = tmpfile

    # Run the module code
    main()

    # Check the result
    result = json.loads(sys.stdout.getvalue())


# Generated at 2022-06-17 05:26:34.615901
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source