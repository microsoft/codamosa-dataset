

# Generated at 2022-06-23 04:19:13.836349
# Unit test for function main
def test_main():
    from ansible.modules.extras import slurp
    reload(slurp)
    slurp.main()

# Generated at 2022-06-23 04:19:14.668213
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:19:22.809891
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'src': {'type': 'path', 'required': True, 'aliases': ['path']}},
                           supports_check_mode=True,
                           )
    # pylint: disable=unused-variable,unused-argument
    path = os.path.dirname(os.path.realpath(__file__))
    module.params['src'] = os.path.join(path, 'test_data/test_slurp.slurp')

    result = main()
    assert result['changed'] == False
    expected_output = {'changed': False, 'content': 'aGVsbG8K', 'source': 'test_data/test_slurp.slurp',
                       'encoding': 'base64'}
    assert result == expected_output



# Generated at 2022-06-23 04:19:34.630189
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:19:49.246794
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:20:00.970684
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.converters import to_bytes
    with open('/tmp/test_slurp.txt', 'wb') as fr:
        fr.write(b'hello')
    module = AnsibleModule(argument_spec=dict(src=dict(required=True, type='path'), checksum=dict(type='str')))
    module.params['src'] = '/tmp/test_slurp.txt'
    data = base64.b64encode(to_bytes('hello'))
    result = main()
    assert result == {'content': data, 'encoding': 'base64', 'source': '/tmp/test_slurp.txt'}
    os.remove('/tmp/test_slurp.txt')

# Generated at 2022-06-23 04:20:12.903141
# Unit test for function main
def test_main():
    import base64
    import sys

    # parse the filename
    src = sys.argv[1]
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:20:22.960521
# Unit test for function main
def test_main():
    test_src = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test.yml'))
    test_data = "aGVsbG8gd29ybGQK"

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        )
    )

    try:
        with open(test_src, 'rb') as test_src_fh:
            test_src_content = test_src_fh.read()
    except (IOError, OSError) as e:
        raise AnsibleError(to_native(e))

    test_data_encode = base64.b64encode(test_src_content)

    assert test_data_

# Generated at 2022-06-23 04:20:34.547035
# Unit test for function main
def test_main():
    filename = os.path.realpath(os.path.join(__file__, '..', "..", "..", 'examples/files/test.cfg'))
    for key, value in [('src', filename)]:
        with open(filename, 'rb') as f:
            wanted = base64.b64encode(f.read())
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    with open(filename, 'rb') as f:
        module.params[key] = value
        main()
        assert module.exit_json_called
        assert module.json_dict['content'] == wanted
        assert module.json_dict['source'] == filename

# Generated at 2022-06-23 04:20:40.694823
# Unit test for function main
def test_main():
    """ Test module main """

    with open("/etc/hosts", "rb") as source_fh:
        source_content = source_fh.read()

    module = AnsibleModule(dict(src="/etc/hosts"))
    data = base64.b64encode(source_content)

    assert module.exit_json(content=data, source="/etc/hosts", encoding='base64') is None

# Generated at 2022-06-23 04:20:47.506768
# Unit test for function main
def test_main():
    # Test 1
    # Test for missing required argument
    args = dict(
        src='hello.txt'
    )
    result = dict(
        content='SGVsbG8=',
        source='hello.txt',
        encoding='base64'
    )
    module = AnsibleModule(argument_spec={})
    module.exit_json(**result)
    #assert main(args) == result

# Generated at 2022-06-23 04:20:52.161111
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-23 04:21:02.417311
# Unit test for function main
def test_main():
    # Synthesize stubs for called functions
    class ansible_module_exit_json:
        def __init__(self):
            self.exit_args = None
            self.exit_kwargs = None

        def __call__(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        @property
        def msg(self):
            return self.exit_kwargs.get('msg')

    class ansible_module_fail_json:
        def __init__(self):
            self.fail_args = None
            self.fail_kwargs = None

        def __call__(self, *args, **kwargs):
            self.fail_args = args
            self.fail_kwargs = kwargs


# Generated at 2022-06-23 04:21:10.563616
# Unit test for function main
def test_main():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir,'test_main')
    with open(test_file,'w') as f:
        f.write('test')

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    module.params['src'] = test_file
    result = main()
    assert(result['content'] == b'ZGVzdA==')

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 04:21:21.444802
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    f = open('test_file.txt', 'w')
    f.write('test')
    f.close()

    source = 'test_file.txt'

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:21:32.244740
# Unit test for function main
def test_main():
    # Module variables
    params = {
        "src": "/var/run/sshd.pid"
    }
    changed = False
    source = "/var/run/sshd.pid"
    module = AnsibleModule(argument_spec=params, supports_check_mode=True)

    # Test if file exists
    assert os.path.exists(source)

    # Test function return values
    assert main() == module.exit_json(content=base64.b64encode(open(source, "rb").read()), source=source, encoding='base64')
    assert main() != module.fail_json(msg="file not found: %s" % source)

# Generated at 2022-06-23 04:21:42.839839
# Unit test for function main
def test_main():
    _module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    import ansible.module_utils.basic
    ansible.module_utils.basic._ANSIBLE_ARGS = ['/usr/bin/ansible', '-m', 'slurp', '-a', 'src=/tmp/myssh_config']

    open('/tmp/myssh_config', 'w').write('asdfasdf')
    _module.params['src'] = '/tmp/myssh_config'
    _module.main()

# Generated at 2022-06-23 04:21:55.074623
# Unit test for function main
def test_main():
    args = dict(
        src="/tmp/test.txt",
    )
    results = dict(
        changed=False,
        content="c2VjcmV0IGlkCg==",
        encoding="base64",
        source="/tmp/test.txt",
    )
    with open("/tmp/test.txt",'w') as fh:
        fh.write("secret id\n")
    m = AnsibleModule(argument_spec=args)
    m.exit_json = lambda x: None
    with open("/tmp/test.txt",'r') as fh:
        m.params = args
        fh.read = lambda : fh.read()
        main()
        assert m.params == results

# Generated at 2022-06-23 04:22:00.727133
# Unit test for function main
def test_main():
    file_name = 'test_slurp.txt'
    f = open(file_name, 'w')
    f.write('This is a test of slurp')
    f.close()

    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', optional=True),
            file_name=dict(type='str', optional=True, default=file_name),
        ),
        supports_check_mode=True,
    )

    source = m.params['src']
    file_name = m.params['file_name']


# Generated at 2022-06-23 04:22:01.484561
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:22:05.371263
# Unit test for function main
def test_main():
    import os
    os.environ['ANSIBLE_MODULE_ARGS'] = {
        'src': 'test'
    }

    # Get values from main function and test them
    result = main()
    assert result['changed'] == True

# Generated at 2022-06-23 04:22:15.450272
# Unit test for function main
def test_main():
    source = "/tmp/ansible-test/source_file"
    source_fh = open(source, 'w')
    source_fh.write("source file")
    source_fh.close()
    source_content = b"source file"
    data = base64.b64encode(source_content)

    (rc, out, err) = module_execute(['/tmp/ansible-test/source_file'])

    os.remove(source)
    assert rc == 0
    assert err == None
    assert out['content'] == data
    assert out['source'] == source
    assert out['encoding'] == 'base64'

# Generated at 2022-06-23 04:22:28.170774
# Unit test for function main
def test_main():
    # Test with file not found
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = '/tmp/notafile.txt'

    data = dict(
        file_exists = False,
        source = source,
    )

    # Module should fail because source file exists
    rc, out, err = module.run_command("touch %s" % source)
    rc, out, err = module.run_command("test -f %s" % source)
    data['file_exists'] = (rc == 0)
    if data['file_exists']:
        module.exit_json(**data)

# Generated at 2022-06-23 04:22:36.257451
# Unit test for function main
def test_main():
    ## Test for file read
    return_obj = {}

    # TODO
    # Create test file, read it and make sure that the correct base64
    # encoding string is returned
    # - source is a file
    # - source is not a file
    # - source is not a file and does not exist
    # - source is a directory
    # - source is not a file but does not exist
    # - source is a directory but does not exist
    # - source is a file and does not exist
    pass

    return return_obj

# Generated at 2022-06-23 04:22:49.052998
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:22:59.560953
# Unit test for function main
def test_main():
    import json

    testobj = {
        'module': {
            'argument_spec': {
                'src': {
                    'aliases': [
                        'path',
                    ],
                    'required': True,
                    'type': 'path',
                },
            },
            'file': 'ansible/modules/files/slurp.py',
            'mutable': False,
            'name': 'slurp',
            'no_log': False,
            'params': {
                'src': '/tmp/myfile',
            },
            'supports_check_mode': True,
        },
    }

    testobj['module']['params'] = {
        'src': '/tmp/myfile',
    }

    # with open('/tmp/myfile', 'w') as myfile:
    #   

# Generated at 2022-06-23 04:23:08.978381
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = "./test_slurp_1234567890"
    with open(source, 'wb') as source_fh:
        source_content = "base64".encode('utf-8')
        source_fh.write(source_content)

    data = base64.b64encode(source_content)

    module.exit_json(content=data, source=source, encoding='base64')

    os.remove(source)

# Generated at 2022-06-23 04:23:13.816791
# Unit test for function main
def test_main():
    # Test for for module main with check mode enabled and a single valid directory
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    assert source == module.params['src']

# Generated at 2022-06-23 04:23:18.982171
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    data=b'file contents'
    source = 'test.txt'

    with open(source, 'wb') as f:
        f.write(data)

    res = main()
    assert res['content'] == base64.b64encode(data)

# Generated at 2022-06-23 04:23:31.887581
# Unit test for function main
def test_main():
    import ansible.modules.extras.slurp as slurp
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils import basic
    import base64
    slurp.open = open
    slurp.main()
    module = basic.AnsibleModule(argument_spec=dict(src=dict(type='path', required=True)), supports_check_mode=True)
    # The return value of this function is specified in RETURN section of the
    # documentation.  This is a content of variable "data"
    data = base64.b64encode(to_bytes("""hi there"""))

    # This is a content of variable "source"
    source = 'src'
    #

# Generated at 2022-06-23 04:23:40.552385
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes
    from io import StringIO
    if sys.version_info[0] == 2:
        # Python2
        import contextlib
        bytes_str = 'b'
        class BytesIO(StringIO):
            def write(self, s):
                return super(BytesIO, self).write(to_bytes(s))
    else:
        # Python3
        import contextlib
        bytes_str = 'bytes'
    test_path = u'./test/unit/modules/utils/ansible/test_ansible_module.py'
    test_path = os.path.abspath(os.path.expanduser(test_path))

# Generated at 2022-06-23 04:23:50.839170
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    with open(source, 'rb') as source_fh:
        content = source_fh.read()
    assert content == 'some content\n'
    data = main()
    assert data == 'c29tZSBjb250ZW50Cg=='
    assert(data == main())

# Generated at 2022-06-23 04:24:01.452875
# Unit test for function main
def test_main():
    # Create dummy file for testing
    (fd, path) = tempfile.mkstemp()
    os.write(fd, b"Dummy content")
    os.close(fd)

    with open(path, 'rb') as source_fh:
        source_content = source_fh.read()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
    )

    # Test happy path
    module.params['src'] = path
    main()
    assert module.exit_json_called
    assert module.exit_json_args['content'] == base64.b64encode(source_content)
    assert module.exit_json_args['encoding'] == 'base64'
    assert module.exit_json_

# Generated at 2022-06-23 04:24:02.254950
# Unit test for function main
def test_main():
    assert True == main()

# Generated at 2022-06-23 04:24:10.831781
# Unit test for function main
def test_main():
    cmd = [os.getcwd() + "/ansible/modules/system/slurp.py"]
    fd = open(os.getcwd() + "/ansible/modules/system/slurp.py", 'rb')
    cmd.append((fd.readline()).rstrip())
    args = "src=/etc/ansible/ansible.cfg"
    args = args.split()
    args = [cmd[1]] + args
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['content']


# Generated at 2022-06-23 04:24:23.146594
# Unit test for function main

# Generated at 2022-06-23 04:24:32.258803
# Unit test for function main
def test_main():
    src_file = os.path.join(os.path.dirname(__file__), 'src', 'test.conf')

    mock_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ))
    mock_module.params = dict(
        src=src_file
    )

    f = open(src_file, 'rb')
    results = base64.b64encode(f.read())

    with open(src_file, 'rb') as source_fh:
        source_content = source_fh.read()

    assert results == base64.b64encode(source_content)

# Generated at 2022-06-23 04:24:37.563054
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:24:46.693563
# Unit test for function main
def test_main():
    # check if slurp can read a file
    file_path = os.path.join(os.getcwd(), "test_slurp.txt")
    with open(file_path, "w") as f:
        f.write("This is a test file for slurp module")

    src = {'src': file_path}

    module = AnsibleModule(argument_spec=dict(src=dict(type="path", required=True, aliases=["path"])), supports_check_mode=True, )
    module.params.update(src)
    main()

# Generated at 2022-06-23 04:24:57.687175
# Unit test for function main
def test_main():
    # Importing these modules here so that the unit test does
    # not fail with ImportErrors in python 2.6 when running with
    # python3
    import io
    import sys

    # Simulate AnsibleModule
    class AnsibleModuleFake(object):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = kwargs

        def fail_json(self, msg):
            raise AssertionError(msg)

        def exit_json(self, changed=False, results=None, **kwargs):
            self.exit_args = dict(changed=changed, results=results, **kwargs)

    # Simulate open
    def fake_open(filename, mode):
        return io.BytesIO(b"foobar\n")

    # Create a

# Generated at 2022-06-23 04:25:10.860014
# Unit test for function main
def test_main():
    # define a dict for test
    source_pad = os.getcwd() + os.sep + "test.txt"

    # write a local file for test
    test_string = "this is a test for base64 encode."
    test_file = open(source_pad, 'w+')
    test_file.write(test_string)
    test_file.close()

    # this test should pass
    result = {}
    result['src'] = source_pad
    result = main(result)

    # compare the expected result and the real result
    assert result
    assert result['content'] == b"dGhpcyBpcyBhIHRlc3QgZm9yIGJhc2U2NCBlbmNvZGUuCg=="
    assert result['source'] == source_pad
    assert result

# Generated at 2022-06-23 04:25:19.982696
# Unit test for function main
def test_main():
    data = base64.b64encode(bytes(b'foo'))
    with open('/tmp/foo', 'wb') as f:
        f.write(bytes(b'foo'))
    os.chmod('/tmp/foo', 0o777)
    print(main(src='/tmp/foo', module_name='slurp'))
    os.remove('/tmp/foo')

# vim: set ft=python et ts=4 sw=4 :

# Generated at 2022-06-23 04:25:33.746596
# Unit test for function main
def test_main():
    result_1 = dict(changed=False, content="MjE3OQo=", encoding="base64", source="/var/run/sshd.pid")
    result_2 = dict(failed=True, msg="file not found: /proc/mounts", rc=1)
    result_3 = dict(failed=True, msg="source is a directory and must be a file: /usr/local/bin")
    result_4 = dict(failed=True, msg="unable to slurp file: [Errno 13] Permission denied: '/var/lib/jenkins/.ssh/id_rsa'")

    test_module = AnsibleModule(argument_spec=dict(src=dict(type='path')))
    setattr(test_module, 'params', {'src': '/var/run/sshd.pid'})

# Generated at 2022-06-23 04:25:34.994990
# Unit test for function main
def test_main():
    # TO BE IMPLEMENTED
    pass
# END OF TESTS

# Generated at 2022-06-23 04:25:42.578915
# Unit test for function main
def test_main():
    import io
    import tempfile
    import unittest

    class TestLogic(unittest.TestCase):
        def setUp(self):
            self.tmpfd, self.tmpname = tempfile.mkstemp()
            self.tmpfile = io.open(self.tmpname, 'w', encoding='utf-8')

        def tearDown(self):
            self.tmpfile.close()
            os.remove(self.tmpname)

        def test_main_positive(self):
            self.tmpfile.write('hello world')
            self.tmpfile.close()
            with self.assertRaises(SystemExit):
                main()

        def test_main_negative(self):
            self.tmpfile.close()
            with self.assertRaises(SystemExit):
                main()


# Generated at 2022-06-23 04:25:54.819313
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=False
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:26:05.372844
# Unit test for function main
def test_main():
    # Define arguments for function
    argument_spec = dict(
        src=dict(type='path', required=True, aliases=['path']),
    )
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )
    module.load_file_common_arguments=dict(follow=False, path_segment_separator='/')

    # Set up settings used in test cases
    settings_success = dict(
        content=base64.b64encode(os.urandom(1024)),
        encoding='base64',
        source='/tmp/testfile'
    )
    settings_fail = dict(
        source='/tmp/'
    )

    # Create test cases

# Generated at 2022-06-23 04:26:12.557372
# Unit test for function main
def test_main():
    file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'mock_data/src.b64')
    with open(file) as f:
        content = f.read()
    file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'mock_data/slurp')
    with open(file) as f:
        slurp = f.read()
    assert content == slurp
    assert True == True

# Generated at 2022-06-23 04:26:25.640667
# Unit test for function main
def test_main():
    os.mkdir("/tmp/test_main_dir")
    open("/tmp/test_main_dir/file1", "w").close()
    os.mkdir("/tmp/test_main_dir/dir1")
    open("/tmp/test_main_dir/dir1/file2", "w").close()


# Generated at 2022-06-23 04:26:33.254464
# Unit test for function main
def test_main():
    # Dummy module arguments
    module_args = dict(
        src=os.path.dirname(os.path.abspath(__file__)) + '/test_data/test.txt',
    )

    # Dummy module
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Load fixture data
    with open(os.path.dirname(os.path.abspath(__file__)) + '/test_data/test.txt', 'r') as f:
        test_content = f.read()

    # Dummy exit_json
    module.exit_json = lambda x: True

    # Execute the module code
    main()

    #

# Generated at 2022-06-23 04:26:33.943380
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:26:46.547089
# Unit test for function main
def test_main():
    from ansible_collections.internal.parsing.parse import parse
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        pass

    def exit_json(self, **kwargs):
        if 'changed' in kwargs:
            self.exit_json_value = kwargs['changed']
        raise AnsibleExitJson

    def fail_json(self, **kwargs):
        self.fail_json_value = kwargs['msg']
        raise AnsibleExitJson

    mock_module_args = dict(src='/path/to/file')
    mock

# Generated at 2022-06-23 04:26:59.854801
# Unit test for function main
def test_main():
    import tempfile
    import shutil

    sample_data = ['sample data1\n', 'sample data2\n', 'sample data3\n']
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_file_full = os.path.join(tmp_dir, 'tmp_file')
    fh = open(tmp_file, 'w+b')
    fh.writelines(sample_data)
    fh.close()

    # Exercise module's exception handling
    for state in ['src']:
        mod = AnsibleModule({}, supports_check_mode=True)
        module_result = {
            'failed': False,
            'source': tmp_file,
        }

# Generated at 2022-06-23 04:27:05.414233
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)

    module.exit_json(content=data, source=source, encoding='base64')

# Generated at 2022-06-23 04:27:11.723950
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    import os

    test_file = '/tmp/ansible_test_file'
    test_file_contents = 'testfile\n'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']


# Generated at 2022-06-23 04:27:18.400903
# Unit test for function main
def test_main():
    test_file = os.path.join(os.path.dirname(__file__), 'test_file')
    with open(test_file, 'wb') as tf:
        tf.write(b'foo')
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True)))
    # Double check that we can read the file
    with open(test_file) as tf:
        assert tf.read() == 'foo'
    module.params['src'] = test_file
    main()
    os.remove(test_file)

# Generated at 2022-06-23 04:27:28.175786
# Unit test for function main
def test_main():
    os.path.exists = lambda x: True
    os.path.isdir = lambda x: False
    open(return_value=fh)
    fh.read = lambda: 'teststring'
    base64.b64encode = lambda x: 'dGVzdHN0cmluZw=='
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = '/test/path'
    main()
    assert module.exit_json.called
    assert 'dGVzdHN0cmluZw==' == module.exit_json.call_args[0][0]['content']
    assert '/test/path'

# Generated at 2022-06-23 04:27:39.636908
# Unit test for function main
def test_main():
    # JSON args
    set_module_args({
        'src': 'filename.txt',
    })

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # We will pretend we are in check mode, though we have no way to test
    # this at the moment
    module.check_mode = True

    # Mock a return value and exit_json function
    module.exit_json = exit_json
    results = {'content': 'MjE3OQo=', 'source': '/var/run/sshd.pid', 'encoding': 'base64'}

    # Override the builtin open function, so that we can return the base64
    # encoded file

# Generated at 2022-06-23 04:27:49.810092
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(argument_spec=dict(
        src=dict(type='path', required=True, aliases=['path']), ),
        supports_check_mode=True, )
    # pylint: disable=no-member
    ansible_module._ANSIBLE_NO_LOG = False  # pylint: disable=protected-access
    # pylint: enable=no-member
    # Testing
    ansible_module.params = {
        "src": "/etc/hosts",
    }

    main()

# end of unit test

# Generated at 2022-06-23 04:27:53.486164
# Unit test for function main
def test_main():
    import doctest
    test_result = doctest.testmod()
    assert test_result[0] == 0, 'Test suite failed'
    assert test_result[1] == 0, 'Tests failed'

# Generated at 2022-06-23 04:28:05.749265
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:28:09.561254
# Unit test for function main
def test_main():
    args = {
        "src": "/proc/mounts",
    }
    module = AnsibleModule(args, supports_check_mode=True)
    result = main()
    assert result['content'] is not None

# Generated at 2022-06-23 04:28:21.598690
# Unit test for function main
def test_main():
    my_test_dir = "/tmp/ansible-test/"
    my_test_file = my_test_dir + "test_file.txt"
    my_test_file_data = "This is test data\nwith more data\nanother line"
    my_test_file_b64 = b'VGhpcyBpcyB0ZXN0IGRhdGFcbndpdGggbW9yZSBkYXRhXG5hbm90aGVyIGxpbmU='

    try:
        os.mkdir(my_test_dir)
    except:
        pass

    with open(my_test_file, 'wb') as fh:
        fh.write(my_test_file_data.encode())

    source = "/no/such/file"

# Generated at 2022-06-23 04:28:32.467397
# Unit test for function main
def test_main():
    mock_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    mock_module.params['src'] = '/var/run/sshd.pid'
    test_obj = Slurp(mock_module)
    test_obj.main()
    # Assert that module.exit_json was called
    assert mock_module.exit_json.called
    # Assert that the value returned in the exiting json is 'MjE3OQo='
    assert mock_module.exit_json.call_args[0][0]['content'] == 'MjE3OQo='

# Generated at 2022-06-23 04:28:41.580430
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_DEBUG']='true'
    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    m.params['src']='./tests/test_data'
    data = main()
    assert data['changed'] == False
    assert data['encoding'] == 'base64'
    assert type(data['content']) is str
    assert data['source'] == './tests/test_data'
    with open ('./tests/test_data', 'rb') as myfile:
        content=myfile.read()
    assert base64.b64decode(data['content']) == content

# Generated at 2022-06-23 04:28:53.652154
# Unit test for function main
def test_main():
    def check_expected_results(str_content, str_checksum, dict_results):
        assert dict_results['encoding'] == 'base64'
        assert dict_results['source'] == source
        assert dict_results['content'] == base64.b64encode(str_content.encode()).decode()

    source = '/random/file/name'
    dict_args = dict(path=source)
    # File exists
    class open_mock(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode

        def __enter__(self):
            self.content = b'a line'
            self.return_value = self
            return self.return_value


# Generated at 2022-06-23 04:28:54.929880
# Unit test for function main
def test_main():
  assert main() == "slurp"

# Generated at 2022-06-23 04:28:58.485995
# Unit test for function main
def test_main():
    src = "ansible/tst/unit/modules/slurp/testfile.txt"
    module = AnsibleModule( dict ( src = src ))
    main()

# Generated at 2022-06-23 04:29:07.997782
# Unit test for function main
def test_main():
    print("Testing function main")
    test_file = "test_slurp"
    if os.path.exists(test_file):
        os.remove(test_file)
    test_content = "test\n"
    with open(test_file, "w") as f:
        f.write(test_content)
    result = main()
    assert 'content' in result
    print("result=%s" % result)
    assert result['content'] == base64.b64encode(test_content)
    if os.path.exists(test_file):
        os.remove(test_file)

# Generated at 2022-06-23 04:29:11.405480
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.exit_json(changed=False, content=b"cat", source="cat", encoding='base64')

# Generated at 2022-06-23 04:29:24.008004
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source