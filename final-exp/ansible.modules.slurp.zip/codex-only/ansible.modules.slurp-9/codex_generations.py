

# Generated at 2022-06-23 04:19:16.912622
# Unit test for function main
def test_main():
    filename = 'test_file.txt'
    file = open(filename, 'w')
    file.write('This is a test file')
    file.close()
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"src":"/home/test/test_file.txt"}'
    filename = 'test_file.txt'
    file = open(filename, 'w')
    file.write('This is a test file')
    file.close()
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"src":"/home/test/test_file.txt"}'
    main()


# Generated at 2022-06-23 04:19:17.491774
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:19:25.057547
# Unit test for function main
def test_main():
    # Load the module so we can provide a fake file path
    m = AnsibleModule(
        argument_spec = dict(
            src = dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # Create a fake return object
    class FakeReturns(object):
        pass
    fake_returns = FakeReturns()

    # Generate a fake file path
    fake_file_path = os.path.dirname(__file__) + "/slurp.py"

    # Call main
    main(m, fake_returns, fake_file_path)

    assert fake_returns.content == base64.b64encode(open(fake_file_path, 'rb').read())
    assert fake_returns.source == fake_file_path


# Generated at 2022-06-23 04:19:30.852259
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:19:37.846248
# Unit test for function main
def test_main():
    with open('slurp_test.txt', 'w') as f:
        f.write("the quick brown fox jumps over the lazy dog\n")
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    res = main()
    assert (module.exit_json == res)

# Generated at 2022-06-23 04:19:51.872664
# Unit test for function main
def test_main():
    # Run tests
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.sys_info import get_distribution
    from ansible.plugins.loader import connection_loader

    fake_params = {'src': 'test'}
    fake_args = {'check_mode': False, 'diff': False}

    fake_connection = connection_loader.get('local', None)

    context = PlayContext()
    context.network_os = get_distribution()[0]
    context.remote_addr = '127.0.0.1'
    context.remote_user = 'root'
    context.connection = fake_connection

# Generated at 2022-06-23 04:20:03.401240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:20:10.171339
# Unit test for function main
def test_main():
    src_path = os.path.join(os.path.dirname(__file__), 'mounts')
    with open(src_path, 'rb') as src_file:
        src_content = src_file.read()

    src_path = '/proc/mounts'
    with open(src_path, 'rb') as src_file:
        src_content = src_file.read()
    data = base64.b64encode(src_content)



# Generated at 2022-06-23 04:20:20.257397
# Unit test for function main
def test_main():
    from units.compat.mock import patch

    mock_module_args = dict(
        src="/path/to/file",
    )

    mocked_file = "/path/to/file"

    return_content = b"""returned_content"""

    with patch.object(base64, 'b64encode', return_value=return_content):
        with patch.object(os, 'open', return_value=1):
            with patch.object(os, 'read', return_value=b"content"):
                module = AnsibleModule(
                    argument_spec=dict(
                        src=dict(type='path', required=True, aliases=['path']),
                    ),
                    supports_check_mode=True,
                )

    try:
        main()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-23 04:20:21.179749
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:20:32.636813
# Unit test for function main
def test_main():
    src = os.path.dirname(os.path.realpath(__file__)) + '/../../../../../'
    src = os.path.abspath(src)
    module = AnsibleModule(argument_spec = dict(src = dict(type='path', required=True, aliases=['path'])))
    module.params['src'] = src + '/README.rst'
    data = main()
    assert 'content' in data
    assert 'source' in data
    assert 'encoding' in data
    assert data['source'] == src + '/README.rst'
    assert data['encoding'] == 'base64'
    assert b'License' in base64.b64decode(data['content'])
    module.params['src'] = src + '/does-not-exist'

# Generated at 2022-06-23 04:20:37.595381
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(src=dict(type='path', required=True)))
    source = module.params['src']
    data = base64.b64encode(source)
    return (module.exit_json(content=data, source=source, encoding='base64'))

# Generated at 2022-06-23 04:20:50.523534
# Unit test for function main
def test_main():
    test_input_file_name = '$HOME/testfile.txt'
    test_input_file_content = '''This is the test file'''


    test_output_file_name = '$HOME/testfile.decoded'

    with open(os.path.expanduser(test_input_file_name),'w') as fh:
        fh.write(test_input_file_content)

    with open(os.path.expanduser(test_input_file_name),'r') as fh:
        expected_data = base64.b64encode(fh.read())

    main()

    with open(os.path.expanduser(test_output_file_name),'r') as fh:
        actual_data = fh.read()


# Generated at 2022-06-23 04:20:57.803194
# Unit test for function main
def test_main():
    args = dict(
        src = 'test.file',
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    m_open = mock_open(read_data='Hello world!')
    with patch.object(builtins, 'open', m_open, create=True):
        main()


# Generated at 2022-06-23 04:20:59.907280
# Unit test for function main
def test_main():
    #
    # unit test to verify that path exists
    #
    assert os.path.exists("/etc/passwd") == True


# Generated at 2022-06-23 04:21:08.414653
# Unit test for function main
def test_main():
    # Set-up mocks
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    # Make source file with text "text"
    try:
        with open(source, 'w') as source_fh:
            source_fh.write("text")
    except (IOError, OSError) as e:
        print("Unable to create mock file")

    # Invoke function
    main()

    # Delete source file
    os.remove(source)

# Generated at 2022-06-23 04:21:21.069771
# Unit test for function main
def test_main():
    # create a mock module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils._text import to_bytes
    import json

    module_args = dict(
        src='/var/run/sshd.pid'
    )

    m = AnsibleModule(argument_spec=module_args)
    m.fail_json = mock = MagicMock()
    m.exit_json = mock = MagicMock()

    # Get the path of the ansible module file
    module_path = os.path.realpath(os.path.dirname(__file__))
    test_data_path = os.path.join(module_path, './test_data/sshd.pid')

    # Read

# Generated at 2022-06-23 04:21:33.541113
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = '/etc/passwd'
    module.params['dest'] = '/tmp/test'
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source


# Generated at 2022-06-23 04:21:42.454512
# Unit test for function main
def test_main():
    # Test passing in file to slurp
    print("Testing passing in file to slurp")
    f = open("tempfile", "w")
    f.write("Testing")
    f.close()

    source = "tempfile"
    try:
        with open(source, 'r') as source_fh:
            source_content = source_fh.read()
    except (OSError) as e:
        assert "file not found: tempfile" == "file not found: %s" % source
        os.remove("tempfile")
        return

    data = base64.b64encode(source_content)

    assert "Testing" == data.decode("utf-8")
    assert "Testing" == base64.b64decode(data).decode("utf-8")

# Generated at 2022-06-23 04:21:46.006371
# Unit test for function main
def test_main():
    content = b"2179"
    with open('/tmp/sshd-pid', 'wb') as f:
        f.write(content)

    data = {'src': '/tmp/sshd-pid', 'changed': False, 'encoding': 'base64', 'source': '/tmp/sshd-pid'}
    result = main()
    assert result == data

    os.remove('/tmp/sshd-pid')

# Generated at 2022-06-23 04:21:57.959304
# Unit test for function main
def test_main():
    '''
    Slurp module unit tests
    '''
    # Create a mock module
    module = AnsibleModule(argument_spec={'src': {'type': 'path', 'required': True, 'aliases': ['path']}})
    module.params['src'] = 'ansible/test/sanity/code/slurp/test_slurp_source.txt'

    # import copy and the *real* module, though we'd prefer to mock it
    import copy
    from ansible.modules.packaging.os import slurp

    # find a way to mock the module
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Don't need to test the 'with_' and 'without_' variants of the module
    # so we can create a patch for

# Generated at 2022-06-23 04:22:08.027135
# Unit test for function main
def test_main():
    source = "Ansible/ansible/test/unit/modules/ansible_collections_test/ansible_collections/jctanner/misc_test_collection/plugins/modules/slurp_test.py"
    source_content = b"dGVzdA=="
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = source
    try:
        with open(source, 'rb') as source_fh:
            file_content = source_fh.read()
    except (IOError, OSError) as e:
        raise AssertionError(e)
    assert file_content == source_content

# Generated at 2022-06-23 04:22:09.184117
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-23 04:22:20.690828
# Unit test for function main
def test_main():

    import os

    # Create a test file
    source = './test_file'
    sample_content = 'host'

    # Write the sample content to the test file
    with open(source, 'w') as f:
        f.write(sample_content)


# Generated at 2022-06-23 04:22:32.977682
# Unit test for function main
def test_main():
    global __file__
    from ansible.module_utils.basic import AnsibleModule

    if not os.path.exists('test.txt'):
        with open('test.txt','w') as f:
            f.write('test123\n')

    __file__ = os.path.abspath('test.txt')

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)


# Generated at 2022-06-23 04:22:38.718158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    module.fail_json(msg='An error occured')

# Generated at 2022-06-23 04:22:51.160651
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.environ.get('ANSIBLE_COLLECTIONS_PATHS', '/usr/share/ansible/collections')
    # Test AnsibleModule object
    path_to_test_file = os.path.join(os.path.dirname(__file__), 'test_file.txt')
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.params['src'] = path_to_test_file
    with open(path_to_test_file, 'r') as file:
        test_content = file.read()

# Generated at 2022-06-23 04:23:00.957902
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.removed import removed_module
    with removed_module():
        import ansible.modules.extras.basic.slurp
    source = '/etc/passwd'
    source_content = b'root:x:0:0:root:/root:/bin/bash\n'
    data = b'cm9vdDp4OjA6MDpyb290Oi9yb290Oi9iaW4vYmFzaAo='
    module = AnsibleModule(argument_spec={'src': {'type': 'path', 'required': True, 'aliases': ['path']}}, supports_check_mode=True)
    module.params = {'src': source}
    ansible.modules

# Generated at 2022-06-23 04:23:06.507487
# Unit test for function main
def test_main():
    FH = open('./test/ansible_slurp_src', 'w')
    FH.write('test_main')
    FH.close()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path'),
        )
    )
    module.params['src'] = './test/ansible_slurp_src'
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-23 04:23:07.137042
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:23:17.178002
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:23:18.128865
# Unit test for function main
def test_main():
    # Unit test for slurp

    assert 1 == 1

# Generated at 2022-06-23 04:23:31.212263
# Unit test for function main
def test_main():
    import tempfile
    import os

    (fd, fname) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('Sample file')

    try:
        # Fetch file from a non-existing path
        module = AnsibleModule(
            argument_spec=dict(
                src = dict(type='path', required=True, aliases=['path']),
            ),
            supports_check_mode=True,
        )

        module.params['src'] = '/tmp/non-existing-file'
        main()
        assert False  # main() should have exited by now
    except RuntimeError as e:
        assert e.args[0].startswith("unable to slurp file: ")


# Generated at 2022-06-23 04:23:37.051704
# Unit test for function main
def test_main():
  # define the module input
  module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
  )
  # define expected results
  expected = {
      'changed': False,
      'content': 'MjE3OQo=',
      'encoding': 'base64',
      'source': '/var/run/sshd.pid'
  }
  # call main funtion and get results
  main()
  #assert results == expected

# Generated at 2022-06-23 04:23:37.927804
# Unit test for function main
def test_main():
    print('Unit test function failed')
    assert 1 == 2

# Generated at 2022-06-23 04:23:40.403389
# Unit test for function main
def test_main():
    # attempt to read nonexistent file
    fname = '/this/is/a/test/that/should/fail'
    with open(fname, 'rb') as source_fh:
        source_content = source_fh.read()
    assert True

# Generated at 2022-06-23 04:23:54.524288
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    # Test module with arguments and valid input
    with patch('builtins.open', return_value=to_bytes("File content")):
        result = basic.run_command('ansible-test slurp', module_args='src=/test/file/path', capture=True)

    assert result['encoding'] == 'base64'
    assert result['content'].decode("utf-8") == 'RmlsZSBjb250ZW50'
    assert result['source'] == '/test/file/path'
    assert result['stdout'] == ''

# Generated at 2022-06-23 04:24:00.822405
# Unit test for function main
def test_main():
    """Test module"""
    from ansible.modules.remote_management.ansible import slurp
    source = os.path.abspath(__file__)

    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    assert slurp.main() == {'content': data, 'source': source, 'encoding': 'base64'}

# Generated at 2022-06-23 04:24:12.606002
# Unit test for function main
def test_main():
    import tempfile
    import shutil

    class Options(object):
        def __init__(self, src=None, dest=None, checksum=False):
            self.content = None
            self.src = src
            self.dest = dest
            self.checksum = checksum

        def __str__(self):
            return 'dest=%s, src=%s, checksum=%s' % (self.dest, self.src, self.checksum)

    class ModuleResult(object):
        def __init__(self, failed=False, changed=False, msg='', sum='', **kwargs):
            self.failed = failed
            self.changed = changed
            self.msg = msg
            self.sum = sum
            self.args = kwargs


# Generated at 2022-06-23 04:24:13.944159
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:24:25.979286
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'])
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:24:28.568931
# Unit test for function main
def test_main():
    os.system('ansible-playbook ../test/slurp_test.yml')

# Generated at 2022-06-23 04:24:29.264326
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:24:39.203463
# Unit test for function main
def test_main():
    mod_args = {'src': '/tmp/test_slurp'}
    mod_kwargs = {}

    from ansible.module_utils import basic
    from ansible.module_utils.common import text
    from ansible.module_utils.common.text.converters import to_native

    m = basic._ANSIBLE_ARGS
    m = text.to_text(m)
    m = to_native(m)

    foo = main()
    assert foo['content'] == 'dGVzdA=='

# Generated at 2022-06-23 04:24:44.207076
# Unit test for function main
def test_main():
    # Set up a class mock for the module
    mod = type('AnsibleModule', (), {})

    return_args = {}
    return_args.update({'src': os.getcwd()})

    mod.params = return_args
    mod.fail_json = lambda x, y: None

    main(mod)

# Generated at 2022-06-23 04:24:51.200817
# Unit test for function main
def test_main():
    src = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', '.tox', 'py3', 'bin', 'ansible'))
    assert os.path.exists(src)
    test_source = src
    res = main()
    content = res['content']
    source = res['source']
    assert content
    assert source
    assert test_source == source

# Generated at 2022-06-23 04:25:02.322610
# Unit test for function main
def test_main():
    with open('test_file.txt', 'w') as fd:
        fd.write('This is a test\n')

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = 'test_file.txt'
    test_module.params['src'] = source
    result = main()
    assert result['source'] == source
    assert result['content'] == b'VGhpcyBpcyBhIHRlc3QK'
    assert result['encoding'] == 'base64'
    os.remove(source)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:25:13.658582
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import base64
    import re

    (fd, test_file) = tempfile.mkstemp()

    # Create test file
    with open(test_file, 'w') as f:
        f.write('hello\nworld\n')

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    test_module.params['src'] = test_file

    main()

    assert(test_module.exit_json_called)
    result = test_module.exit_json_args
    assert('content' in result)

# Generated at 2022-06-23 04:25:22.019283
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError):
        pass

    source_data = source_content.decode("utf-8")
    data = base64.b64encode(source_content)

    module.exit_json(content=data, source=source, encoding='base64')

# Generated at 2022-06-23 04:25:28.706930
# Unit test for function main
def test_main():
    params = {'src': '/var/run/sshd.pid'}
    lines = [
        '{\n',
        '    "changed": false,\n',
        '    "content": "MjE3OQo=",\n',
        '    "encoding": "base64",\n',
        '    "source": "/var/run/sshd.pid"\n',
        '}'
    ]
    result = {
        "changed": False,
        "content": "MjE3OQo=",
        "encoding": "base64",
        "source": "/var/run/sshd.pid"
    }

# Generated at 2022-06-23 04:25:29.324097
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:25:39.296536
# Unit test for function main
def test_main():
    from ansible.modules.remote.windows.slurp import main
    import json

    src = os.path.abspath('test/test_slurp.py')

# Generated at 2022-06-23 04:25:52.031693
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:25:57.979188
# Unit test for function main
def test_main():
    args = dict(
        src='test.txt',
    )

    # import module and make test
    with AnsibleModule(argument_spec=args) as module:
        module.exit_json(changed=False, meta=dict(ansible=2.10))

# Generated at 2022-06-23 04:26:06.951469
# Unit test for function main
def test_main():
    os.environ['TEST_MAIN'] = 'True'
    import ansible.modules.extras.system.slurp
    source = 'tests/test_slurp.py'
    idx = 0

# Generated at 2022-06-23 04:26:19.249373
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source
        elif e.errno == errno.EISDIR:
            msg = "source is a directory and must be a file: %s" % source

# Generated at 2022-06-23 04:26:29.093150
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:26:43.007346
# Unit test for function main
def test_main():
    import StringIO, StringIO
    import sys, os
    import textwrap
    import ansible.module_slurp

    test_file_p = os.path.join(os.path.dirname(__file__), 'test_file')

    open(test_file_p, 'w').write("""This is a text file""")

    src_file = StringIO.StringIO(textwrap.dedent("""
        [{
            "_ansible_verbose_override": true,
            "_ansible_check_mode": false,
            "changed": false,
            "invocation": {
                "module_name": "slurp"
            },
            "source": "%s"
        }]
    """ % test_file_p))


# Generated at 2022-06-23 04:26:50.655316
# Unit test for function main
def test_main():
    content = base64.b64encode(open('/proc/mounts', 'rb').read())
    result = dict(
        content=content,
        changed=False,
        source='/proc/mounts',
        encoding='base64'
    )
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(type='path', required=True, aliases=['path'])
        ),
        supports_check_mode=True
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:27:00.373540
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_modlib_simpletasker as amlst
    from ansible.module_utils.ansible_modlib_simpletasker import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    from tempfile import NamedTemporaryFile

    fp = NamedTemporaryFile(delete=False)

# Generated at 2022-06-23 04:27:08.750135
# Unit test for function main
def test_main():
    os.path.exists = Mock(return_value=True)
    os.access = Mock(return_value=True)
    open = Mock(return_value="MjE3OQo=")

    with patch.object(base64, 'b64encode', return_value="MjE3OQo="):
        with patch.object(AnsibleModule, 'exit_json'):
            main()
            base64.b64encode.assert_called_with("MjE3OQo=")


# Generated at 2022-06-23 04:27:21.990355
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:27:34.731203
# Unit test for function main
def test_main():

    import tempfile
    import time
    import json

    (fd, tmp_filename) = tempfile.mkstemp()
    with open(tmp_filename, 'w') as f:
        f.write('foobar')
    time.sleep(4)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']


# Generated at 2022-06-23 04:27:41.392511
# Unit test for function main
def test_main():
    source = os.path.dirname(os.path.realpath(__file__)) + '/ansible_test_file_to_slurp.txt'
    with open(source, 'rb') as source_fh:
        source_content = source_fh.read().decode('utf-8')
    os.environ["ANSIBLE_MODULE_ARGS"] = '{"src": "' + source + '"}'
    main()
    assert source_content == "This is a test string\n"

# Generated at 2022-06-23 04:27:54.843870
# Unit test for function main
def test_main():
    import os

    # This should fail when no src is provided
    args = dict(src=None)
    res = main(**args)
    if 'Content-Type' in res and res['Content-Type'] == 'application/json':
        res = res['results']['msg']
    assert 'must be a file' in res

    # This should fail when a directory is given as src
    args = dict(src='/tmp')
    res = main(**args)
    if 'Content-Type' in res and res['Content-Type'] == 'application/json':
        res = res['results']['msg']
    assert 'must be a file' in res

    # This should succeed when a directory is given as src
    args = dict(src='/etc/ansible/hosts')
    res = main(**args)
   