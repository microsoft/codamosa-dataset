

# Generated at 2022-06-23 04:19:14.361930
# Unit test for function main
def test_main():
    import base64
    import os
    
    with open("test_file", "w") as fh:
        fh.write("test line 1\ntest line 2\n");
    os.chmod("test_file", 0o666)

    assert("test line 1\ntest line 2\n" == base64.b64decode(main().contentQ))
    os.unlink("test_file")


# Generated at 2022-06-23 04:19:22.587809
# Unit test for function main
def test_main():
    """
    Main tests
    """
    test_module_path = os.path.join(os.path.dirname(__file__), 'ansible-test-module')
    test_module_path = os.path.normpath(test_module_path)

    test_module_src = os.path.join(os.path.dirname(__file__), 'data/test-module-src.txt')
    test_module_src = os.path.normpath(test_module_src)

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    test_module.params['src'] = test_module_src
    test_module.exit_json

# Generated at 2022-06-23 04:19:34.396928
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_modlib.file_common as file_common

    dest = os.path.join(file_common._tempfile_keeper.tmpdir, 'testfile')


# Generated at 2022-06-23 04:19:34.991906
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:19:42.415916
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    print(module.params['src'])

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:19:44.175266
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:19:57.595084
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    src = '/var/run/sshd.pid'
    result = dict(
        content='MjE3OQo=',
        source=src,
        encoding='base64')
    source_content = b'2179 '
    module = basic.AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    with open(src, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)
    module.exit_json(content=data, source=src, encoding='base64')
    assert module.exit_json == result

# Generated at 2022-06-23 04:20:05.649971
# Unit test for function main
def test_main():
    src = '/var/run/sshd.pid'
    test_data = b'2179'
    test_data_b64 = base64.b64encode(test_data)
    with open(src, 'wb+') as f:
        f.write(test_data)

    args = dict(
        src=src,
    )
    m = AnsibleModule(argument_spec=args)

    assert m.params['src'] == src

    result = main()

    assert result['content'] == test_data_b64
    assert result['encoding'] == 'base64'
    assert result['source'] == src

    os.remove(src)

# Generated at 2022-06-23 04:20:15.701711
# Unit test for function main
def test_main():
    """
    Test the module with loading
    """
    mod_args = dict(
        src="/tmp/file.txt"
    )

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source

# Generated at 2022-06-23 04:20:23.051144
# Unit test for function main
def test_main():
    src = '/etc/hosts'
    with open(src, 'rb') as actual_fh:
        src_content = actual_fh.read()
    module_mock = AnsibleModule({'src': src})
    module_mock.exit_json = lambda **kwargs: kwargs
    result = main()
    assert result['content'] == base64.b64encode(src_content)
    assert result['source'] == src
    assert result['encoding'] == 'base64'

# Generated at 2022-06-23 04:20:24.285154
# Unit test for function main
def test_main():
    # I am not entirely sure how to write this unit test
    pass

# Generated at 2022-06-23 04:20:36.643550
# Unit test for function main
def test_main():
    test_host = {
        "hostname": "127.0.0.1",
        "ansible_host": "127.0.0.1",
        "ansible_port": "2222",
        "ansible_user": "test",
        "ansible_password": "secret",
    }
    test_source = "ansible/test/files/test_file.txt"
    test_source_encoded = test_source.encode("utf-8")
    test_base64 = b"VGhpcyBpcyBhIHRlc3QgZmlsZS4K"
    test_source_os = os.path.join("/tmp", test_source)

    test_source_fh = open(test_source_os, "wb")

# Generated at 2022-06-23 04:20:43.730536
# Unit test for function main
def test_main():
    os.path.isfile = lambda path: True
    open = lambda src: FakeOpen(
        src,
        b''
    )
    base64.b64encode = lambda x: b'MjE3OQo='

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        )
    )
    main = lambda: main()

    assert main() == (
        False,
        b'MjE3OQo=',
        '/var/run/sshd.pid',
        'base64'
    )


# Generated at 2022-06-23 04:20:53.855423
# Unit test for function main
def test_main():
    import os

    def remove_file(fpath):
        try:
            os.remove(fpath)
        except OSError:
            pass

    test_files_path = "./ansible_test_files" # TODO: Use ansible.module_utils.path

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    # Test directory
    test_dir = os.path.join(test_files_path, 'slurp_test_dir')
    test_dir_content = "test_dir_content"

# Generated at 2022-06-23 04:21:04.782586
# Unit test for function main
def test_main():
    """
    This function is the test of the main function.
    """
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    # set up the return values
    results = dict(
        changed=False,
        content='MjE3OQo=',
        encoding='base64',
        source='/var/run/sshd.pid',
    )

    # the source file should exist and readable
    source = module.params['src']

# Generated at 2022-06-23 04:21:11.870710
# Unit test for function main
def test_main():
    import os.path
    import tempfile
    tmp_file = tempfile.mktemp()
    with open(tmp_file, 'w') as f:
        f.write('foo')
    try:
        args = {
            'src': tmp_file
        }
        res = main()
        assert res.get('changed') == False
        assert res.get('content') == 'Zm9v'
        assert res.get('encoding') == 'base64'
        assert res.get('source') == tmp_file
    finally:
        if os.path.exists(tmp_file):
            os.remove(tmp_file)

# Generated at 2022-06-23 04:21:18.000352
# Unit test for function main
def test_main():
    """Function main() test case"""
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_native

    import os

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']
    source = source[1:] if source.startswith('/') else source
    source_content = b'The dude abides'


# Generated at 2022-06-23 04:21:28.393952
# Unit test for function main
def test_main():
    import json
    import sys
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.community.plugins.module_utils.common.file import expand_path

    module_path = expand_path(__file__ + '/../../')

    if module_path not in sys.path:
        sys.path.append(module_path)

    test_file = expand_path(__file__)

    # Right now the only way to do this is to patch the module file
    with open(test_file, 'r') as fb:
        content = fb.read()


# Generated at 2022-06-23 04:21:29.102933
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-23 04:21:40.157007
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:21:45.685555
# Unit test for function main
def test_main():
    # import unittest
    # from ansible.module_utils.common.text.converters import to_bytes
    #
    # class SlurpTest(unittest.TestCase):
    #
    #     def setUp(self):
    #         pass

    return

# Generated at 2022-06-23 04:21:57.686981
# Unit test for function main
def test_main():
    import sys
    import os

    # Hack to get around the fact that AnsibleModule calls exit(1)
    # when it fails. This means we need to add a fake AnsibleModule
    # to our sys.modules and set a try/except block around our
    # import.
    sys.modules['ansible.module_utils.basic'] = os
    sys.modules['ansible.module_utils.common.text.converters'] = os

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']


# Generated at 2022-06-23 04:22:07.875951
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(type = 'path', required = True, aliases = ['path'])
        ),
        supports_check_mode = True
    )
    source = module.params['src']
    data = module.params['data']
    try:
        with open(source, 'w') as source_fh:
            source_content = source_fh.write(data)
    except (IOError,OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:22:19.794639
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:22:22.851443
# Unit test for function main
def test_main():
    from ansible.modules.extras.cloud.cloudstack.slurp import main
    data = main()
    assert (data['content'] == 'Hello World')

# Generated at 2022-06-23 04:22:35.209220
# Unit test for function main
def test_main():
    # AnsibleModule
    assert(type(main()).__name__ == 'AnsibleModule')
    assert(type(test_main()).__name__ == 'NoneType')
    # AnsibleModule.params
    assert(type(main()).params.__name__ == 'dict')
    # AnsibleModule.params['src']
    assert(main().params['src'] == '/proc/mounts')
    # AnsibleModule.exit_json()
    assert(type(main().exit_json()).__name__ == 'NoneType')
    # AnsibleModule._ansible_no_log
    assert(main()._ansible_no_log == False)
    # AnsibleModule.deprecate()
    assert(type(main().deprecate()).__name__ == 'NoneType')

# Generated at 2022-06-23 04:22:47.729872
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.converters import to_bytes
    test_src = os.path.join(os.getcwd(), 'test_files_for_modules', 'config')
    args = {
        'src': test_src,
        'path': test_src,
    }
    with open(test_src, 'rb') as test_src_fh:
        test_src_content = test_src_fh.read()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    assert module.main()[0]['content'] == base64.b64encode(test_src_content)

# Generated at 2022-06-23 04:22:48.869380
# Unit test for function main
def test_main():
	module_name = "ansible.builtin.slurp"
	module = import_module(module_name)
	module.main()

# Generated at 2022-06-23 04:22:59.466734
# Unit test for function main
def test_main():
  from ansible.module_utils._text import to_bytes
  data = to_bytes(
    """
    <?xml version="1.0" encoding="UTF-8"?>
    <note>
      <to>Tove</to>
      <from>Jani</from>
      <heading>Reminder</heading>
      <body>Don't forget me this weekend!</body>
    </note>
    """
  )
  result = base64.b64encode(data)

# Generated at 2022-06-23 04:23:05.871870
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__

    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    test_module.params['src'] = './README.md'
    result = main()

    assert result

# Generated at 2022-06-23 04:23:14.722643
# Unit test for function main
def test_main():
    src = 'myfile.txt'
    # module = AnsibleModule(
    #     argument_spec=dict(
    #         src=dict(type='path', required=True, aliases=['path']),
    #     ),
    #     supports_check_mode=True,
    # )
    # source = module.params['src']
    with open(src, 'wb') as fh:
        fh.write('Hello, World')

    content, source, encoding = main()
    assert content == b'Hello, World'
    assert source == b'myfile.txt'
    assert encoding == 'base64'

# Generated at 2022-06-23 04:23:21.906724
# Unit test for function main
def test_main():
    import tempfile

    tempdir = tempfile.mkdtemp()

    fd, path = tempfile.mkstemp(dir=tempdir)
    os.write(fd, 'foo')
    os.close(fd)

    fd, path = tempfile.mkstemp(dir=tempdir)
    os.write(fd, 'bar')
    os.close(fd)

    args = dict(
        src=path
    )

    with open(path, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)

    result = dict(
        content=data,
        source=path,
        encoding='base64'
    )

    assert main(args) == result

# Generated at 2022-06-23 04:23:23.886064
# Unit test for function main
def test_main():
    # no-op since we don't support check mode
    pass

# Generated at 2022-06-23 04:23:35.172180
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          src=dict(type='path', required=True, aliases=['path']),
      ),
      supports_check_mode=True,
  )
  # create a temporary file for test
  import tempfile
  test_file = tempfile.NamedTemporaryFile(delete=False)
  test_data = b"Test Data\n"
  test_file.write(test_data)
  test_file.flush()
  os.fsync(test_file)
  test_file.close()
  module.params['src'] = test_file.name
  result = main()
  #print result
  assert result['changed'] == False
  assert result['content'] != None
  assert base64.b64decode(result['content']) == test_data

# Generated at 2022-06-23 04:23:46.746022
# Unit test for function main
def test_main():
    import mock
    import tempfile
    class AnsibleModuleMock(mock.MagicMock):
        def exit_json(self, content=None, source=None, encoding='UTF-8'):
            if content is not None:
                if encoding == 'UTF-8':
                    content = to_bytes(content)
                return base64.b64decode(content)
            return source
        def fail_json(self, *args, **kwargs):
            raise Exception("Test failed")
    with tempfile.NamedTemporaryFile(mode='r+b', delete=False) as src:
        src.write(b'12345')
        src.close()
        x = AnsibleModuleMock()
        x.params = { 'src': src.name }
        p = main()
        assert p == b'12345'

# Generated at 2022-06-23 04:23:59.818190
# Unit test for function main
def test_main():

    # These two lines open the file and encode its content
    with open('/Users/alessandrosilacci/Desktop/ansible.cfg', 'r') as source_fh:
        source_content = source_fh.read()

    date = base64.b64encode(source_content)

    path = '/Users/alessandrosilacci/Desktop/ansible.cfg'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=False,
    )
    # Call the function main, with fake data as arguments
    # This is used to test the values returned by the function
    module.main(path)

    # The different variables are compared with the expected one
    assert module.exit_

# Generated at 2022-06-23 04:24:11.686696
# Unit test for function main
def test_main():
    path = '/tmp/test_file.out'
    with open(path, 'w') as f:
        f.write('file contents')
        f.close()

    module = AnsibleModule(argument_spec=dict(src=dict(required=True, type='path')))
    module.params['src'] = path

    # B64 encode the local file for testing
    with open(path, 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    main()
    assert(module.result['content'] == data)
    assert(module.result['source'] == path)
    assert(module.result['encoding'] == 'base64')

    os.remove(path)

# Generated at 2022-06-23 04:24:16.556880
# Unit test for function main
def test_main():
    dest = os.path.join(os.path.dirname(__file__), 'file.txt')
    open(dest, "w").write('Hello world\n')

    import sys
    sys.argv = [sys.argv[0]]
    sys.argv.append('src=' + dest)
    main()

# Generated at 2022-06-23 04:24:18.526863
# Unit test for function main
def test_main():
    # Not applicable this should be a module.
    pass


# Generated at 2022-06-23 04:24:30.480384
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:24:43.034546
# Unit test for function main
def test_main():
    ap = argparse.ArgumentParser()


# Generated at 2022-06-23 04:24:46.362317
# Unit test for function main
def test_main():
  # This is a very basic test just to see if it fails
  src = '/var/run/sshd.pid'
  result = main(src)
  assert result == 'MjE3OQo='

# Generated at 2022-06-23 04:24:46.988485
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-23 04:24:57.254857
# Unit test for function main
def test_main():
    result = '{"changed":false,"content":"MjE3OQo=","encoding":"base64","source":"some/where.txt"}'
    module = AnsibleModule({'src': 'some/where.txt'})
    module.exit_json = lambda x: None
    module.fail_json = lambda x: None

    os.path.exists = lambda x: True
    open = lambda x, y: '2179'

    main()

    assert module.exit_json.called_once_with(encoding='base64', source='some/where.txt', content='MjE3OQo=')
    assert module.exit_json.call_count == 1
    assert module.fail_json.call_count == 0

# Generated at 2022-06-23 04:25:10.087550
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes

    # Basic test
    test_input = dict(src=__file__)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = test_input

    test_content = base64.b64encode(to_bytes(open(__file__).read()))

    assert main()['content'] == test_content

    # Error test
    test_input = dict(src="/tmp/does_not_exist")


# Generated at 2022-06-23 04:25:20.887675
# Unit test for function main
def test_main():
    src = os.path.join(os.path.realpath("."), __file__)
    module_args = {'src': src}
    result = {}
    with open(src, 'rb') as f:
        src_content = f.read()
        result['content'] = base64.b64encode(src_content)
        result['source'] = src
        result['encoding'] = 'base64'

    if os.path.isdir(src):
        raise SystemExit

    assert os.path.exists(src)
    assert result == main(module_args)

# Generated at 2022-06-23 04:25:29.132973
# Unit test for function main
def test_main():
    temp_directory = os.path.dirname(__file__)
    temp_example_file = temp_directory + os.sep + 'test_fetch'
    test_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path'])
        ),
        supports_check_mode=True
    )
    test_module.params['src'] = temp_example_file

    main()

# Generated at 2022-06-23 04:25:30.576862
# Unit test for function main
def test_main():
  assert True


# Generated at 2022-06-23 04:25:39.955036
# Unit test for function main
def test_main():
    source = str(os.path.join(os.path.dirname(__file__), "test_slurp.py"))
    with open(source, "rb") as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)


# Generated at 2022-06-23 04:25:52.491789
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_REMOTE_TEMP'] = "/tmp"
    os.environ['ANSIBLE_REMOTE_USER'] = "root"
    os.environ['ANSIBLE_MODULE_ARGS'] = "src=/etc/passwd encoding=base64"
    os.environ['ANSIBLE_MODULE_RETVALS'] = "{\"content\": \"test file content\"}"
    os.environ['ANSIBLE_MODULE_RETCODE'] = "0"
    os.environ['ANSIBLE_MODULE_ARGS'] = "{\"src\": \"/etc/passwd\", \"encoding\": \"base64\"}"
    os.environ["PWD"] = "/home/ansible"
    os.environ['PATH'] = "/usr/bin:/bin"

# Generated at 2022-06-23 04:26:04.609593
# Unit test for function main
def test_main():
    # (monkey patch the function to avoid actually opening a file, and to make
    # sure it returns something that base64 can handle)
    import sys
    import tempfile

    tmp_path = tempfile.mkdtemp(prefix='ansible-slurp')

# Generated at 2022-06-23 04:26:11.913936
# Unit test for function main
def test_main():
    content = 'This is a test'
    source = 'test.txt'

    with open(source, 'w') as source_fh:
        source_fh.write(content)

    result = main()

    os.remove(source)

    assert result['content'] == base64.b64encode(content), 'Invalid content'
    assert result['encoding'] == 'base64', 'Invalid encoding'
    assert result['source'] == source, 'Invalid source'

# Generated at 2022-06-23 04:26:25.140538
# Unit test for function main
def test_main():
    import os
    import tempfile
    import textwrap

    tfile = tempfile.NamedTemporaryFile(delete=False)
    tfile.write(b'foo bar')
    tfile.close()

    os.environ['ANSIBLE_CONFIG'] = 'foobar'
    module_args = dict(src=tfile.name)

    data = dict(
        content='Zm9vIGJhcg==',
        source=tfile.name,
        encoding='base64',
    )

    tfile2 = tempfile.NamedTemporaryFile(delete=False)

    # python3 does not accept bytes in the open() call
    if os.name == 'posix':
        with open(tfile2.name, 'wb') as tfile2_fh:
            tfile2_fh.write

# Generated at 2022-06-23 04:26:32.039823
# Unit test for function main
def test_main():
    import tempfile

    # Create content for file
    test_str = "Test string"
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(test_str)
    tmp_file.close()

    # Create file module
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params['src'] = tmp_file.name
    main()

    os.unlink(tmp_file.name)

# Generated at 2022-06-23 04:26:39.782232
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    module.params = {'src': 'tests/files/test_slurp.txt'}
    output = main()
    assert output.get('content') == 'VGhpcyBpcyBhIHRlc3Qgc3RyaW5n'

# Generated at 2022-06-23 04:26:51.310216
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:27:05.297444
# Unit test for function main
def test_main():
    src_file = 'tmp/' + os.urandom(4).encode('hex')
    with open(src_file, 'w') as f:
        f.write("test")
    sys.path.append(".")
    from ansible.modules.legacy.misc import slurp
    with open("/dev/null", "w") as fnull:
        old_stdout = sys.stdout
        sys.stdout = fnull
        try:
            slurp.main()
            assert False
        except SystemExit as e:
            assert e.code == 1
        finally:
            sys.stdout = old_stdout
    os.system("ansible localhost -m slurp -a 'src=" + src_file + "'")
    os.remove(src_file)

# Generated at 2022-06-23 04:27:18.184156
# Unit test for function main
def test_main():
    import random
    import string
    import tempfile
    module_args = {}
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(5))
    (test_file,test_file_path) = tempfile.mkstemp(suffix=random_string)
    test_file_content = "this is a test file created by unit test of slurp module"
    with open(test_file, 'w') as test_file_fh:
        test_file_fh.write(test_file_content)

    module_args['src'] = test_file_path
    module_args['dest'] = '/tmp/'
    module_args['state'] = 'latest'
    result = main(module_args)
    assert result['source']

# Generated at 2022-06-23 04:27:28.105928
# Unit test for function main
def test_main():
    import tempfile

    def test_call(module_name='ansible.modules.files.slurp', **kwargs):
        module = importlib.import_module(module_name)
        # Create a temporary file and make sure it is closed.
        tf = tempfile.NamedTemporaryFile(delete=False)
        tf.close()

# Generated at 2022-06-23 04:27:32.295559
# Unit test for function main
def test_main():
    args = dict(
        src='/proc/mounts'
    )
    p = main()
    assert p['changed'] == False
    assert isinstance(p['content'], str)
    assert isinstance(p['encoding'], str)
    assert os.path.isfile(p['source'])

# Generated at 2022-06-23 04:27:43.537720
# Unit test for function main
def test_main():
    # Setup test environment
    if not os.path.isdir('unittest_data'):
        os.mkdir('unittest_data')

    # Setup a test file to slurp and encode
    source_file = 'unittest_data/slurp.txt'
    source_content = b'This is the\nTest Content\n'
    source_encoded = b'VGhpcyBpcyB0aGUKVGVzdCBDb250ZW50Cg=='
    with open(source_file, 'wb') as source_fh:
        source_fh.write(source_content)


# Generated at 2022-06-23 04:27:56.747689
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    m.params['src'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../module_utils/test_utils/test_file.txt')
    results = main()


# Generated at 2022-06-23 04:28:07.763158
# Unit test for function main
def test_main():
    src_file = 'test_file.txt'
    content  = 'Hello World!'

    with open(src_file, 'w') as test_file:
        test_file.write(content)

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']

    data = base64.b64encode(content.encode('utf-8'))

    module.exit_json(content=data, source=source, encoding='base64')


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:28:19.780327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:28:25.225607
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']
    assert source=='./test'
    assert source=='./test'

# Generated at 2022-06-23 04:28:37.158182
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )
    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source

# Generated at 2022-06-23 04:28:48.513903
# Unit test for function main
def test_main():
    module = AnsibleModule({'src': to_native(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'README.md'), errors='surrogate_or_strict')}, supports_check_mode=True)
    with open(module.params['src'], 'rb') as source_fh:
        source_content = source_fh.read()
    data = base64.b64encode(source_content)

    assert module.exit_json(content=data, source=module.params['src'], encoding='base64') == {"content":data, "source":module.params['src'], "encoding":"base64"}

# Generated at 2022-06-23 04:28:49.119582
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:28:52.681091
# Unit test for function main
def test_main():
    test_args = ['src=/etc/passwd']
    module = AnsibleModule(argument_spec={'src': {'type': 'path', 'required': 'True'}})

# Generated at 2022-06-23 04:29:03.894664
# Unit test for function main
def test_main():
    source = "/etc/hosts"
    if os.name == "nt":
        source = "C:\\Windows\\System32\\drivers\\etc\\hosts"

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    with open(source, 'rb') as source_fh:
        source_content = source_fh.read()

    data = base64.b64encode(source_content)

    assert module.exit_json(content=data, source=source, encoding='base64') is not None


# Generated at 2022-06-23 04:29:13.942453
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True, aliases=['path']),
        ),
        supports_check_mode=True,
    )

    source = module.params['src']

    try:
        with open(source, 'rb') as source_fh:
            source_content = source_fh.read()
    except (IOError, OSError) as e:
        if e.errno == errno.ENOENT:
            msg = "file not found: %s" % source
        elif e.errno == errno.EACCES:
            msg = "file is not readable: %s" % source