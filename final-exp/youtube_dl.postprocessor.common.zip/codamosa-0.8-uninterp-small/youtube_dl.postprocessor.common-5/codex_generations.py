

# Generated at 2022-06-26 13:33:33.627692
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = post_processor_0.try_utime('', 0, 0, '')


# Generated at 2022-06-26 13:33:43.133490
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # Create a file
    file_path = os.path.join(os.path.dirname(__file__), "test.txt")
    with open(file_path, "w") as test_file:
        test_file.write("test line in file")
    # Check if the file has been created
    assert os.path.exists(file_path)
    # Update access and modification time of the file using try_utime
    from time import time
    post_processor.try_utime(file_path, time(), time(), errnote="Cannot update utime of file")
    # Check if access and modification time of the file have been updated
    assert os.stat(file_path)[7] == os.stat(file_path)[8]
    # Remove the file
    os.remove

# Generated at 2022-06-26 13:33:47.698390
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, 1, 2)

    return ('unit_test:PostProcessor:try_utime', None)

# Generated at 2022-06-26 13:33:49.903500
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Tests to see if class PostProcessor.try_utime is working.
    """
    pass


# Generated at 2022-06-26 13:33:56.357159
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test with a non-existent file
    pp = PostProcessor()
    pp.try_utime('non-existent-file', 0, 0, '')


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:04.313505
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp0 = PostProcessor()
    from youtube_dl.downloader.common import FileDownloader
    fd = FileDownloader({'outtmpl': 'test'})
    pp0.set_downloader(fd)
    import sys
    import stat
    import tempfile
    import shutil
    import time
    import locale
    locale.setlocale(locale.LC_ALL, "C.UTF-8")
    if sys.platform == 'win32':
        print('Skipping utime test on win32')
    else:
        tmpdir = tempfile.mkdtemp(prefix='ydl-utime-test-')
        # TODO: This is a bit of a hack, but a good enough way to test try_utime
        pp0._downloader = fd

# Generated at 2022-06-26 13:34:12.717540
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    # Test case 0
    post_processor_0.try_utime('0',0,0,'Cannot update utime of file')

    # Test case 1
    post_processor_0.try_utime('1',1,1,'Cannot update utime of file')

    # Test case 2
    post_processor_0.try_utime('param0',0,0,'Cannot update utime of file')


# Generated at 2022-06-26 13:34:23.362700
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import tempfile
    from .downloader import FileDownloader
    from .extractor.youtube import YoutubeIE
    from .utils import compat_urllib_request
    from .utils import sanitize_open
    downloader = FileDownloader({})
    test_path = tempfile.mktemp()
    (fd, test_content) = tempfile.mkstemp()
    post_processor_0 = PostProcessor({})
    # Creation of the parent directories (if any) for the given path.
    # Creation of the file with the given content.
    # The test file is moved to a temporary file
    with sanitize_open(fd, 'wb') as inf:
        inf.write(b'RldHYWQgYmF0dGxlIHRvb3Jk')

# Generated at 2022-06-26 13:34:31.217318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test when file does not exist
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('unit_tests/out/does_not_exist.mp4', 0, 0, 'Unit test')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:35.189635
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'test.ts')
    with open(tmpfile, 'wb'):
        pass
    pp = PostProcessor(Downloader())
    pp.try_utime(tmpfile, 12, 13)
    os.remove(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-26 13:34:43.136468
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import datetime
    post_processor_0 = PostProcessor()
    #TODO: atime and mtime are calculated based on the current time, so this test
    # may fail to assert the correct value if the test is run too fast after it's
    # started
    test_file_name = 'test_file.txt'
    atime = mtime = time.mktime(datetime.datetime.now().timetuple())
    post_processor_0.try_utime(test_file_name, atime, mtime)
    assert os.path.getatime(test_file_name) == atime
    assert os.path.getmtime(test_file_name) == mtime
    os.remove(test_file_name)



# Generated at 2022-06-26 13:34:48.768737
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test_data/video.mp4', 1434459183.0, 1434459183.0, 'Cannot update utime of file')

# Generated at 2022-06-26 13:34:52.430245
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('0', '', '', '')
    return

# Test for class PostProcessor

# Generated at 2022-06-26 13:35:00.257502
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    filepath_0 = 'C:\\Documents and Settings'
    post_processor_0.try_utime(filepath_0, 1, 1)

test_cases_PostProcessor = [
    test_case_0,
    test_PostProcessor_try_utime,
]


# Generated at 2022-06-26 13:35:10.926085
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    mp3_file = os.path.join(os.path.dirname(__file__), '__test__', 'test-audio.mp3')
    mp4_file = os.path.join(os.path.dirname(__file__), '__test__', 'test-video.mp4')

    pp_0 = PostProcessor()
    pp_0.set_downloader(object)
    pp_0.try_utime(mp3_file, 1517503614.0, 1517503614.0)
    pp_0.try_utime(mp4_file, 1517503614.0, 1517503614.0)

    pp_1 = PostProcessor()
    pp_1.set_downloader(object)
    pp_1._downloader = object

# Generated at 2022-06-26 13:35:18.159934
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    temp_file_name = encodeFilename('__temp_file_name')
    try:
        # Create a temporary file with access and modification time from the epoch
        f = open(temp_file_name, 'w')
        f.close()
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime(temp_file_name, 0, 0)
        post_processor_0.try_utime(temp_file_name, 0, 0, 'Nothing')
    except Exception:
        raise
    finally:
        try:
            os.remove(temp_file_name)
        except OSError:
            pass
# except Exception:
#     pass
# finally:
#     try:
#         os.remove(temp_file_name)
#     except OSError:
#

# Generated at 2022-06-26 13:35:19.070286
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:35:20.945866
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(str(),float(),float(),str())
    post_processor_0.try_utime(str(),float(),float())


# Generated at 2022-06-26 13:35:25.806324
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    global test_case_0
    assert test_case_0.try_utime('/dev/null'), "PostProcessor.try_utime() does not return True"


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:33.889438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    path = os.path.realpath(__file__) # real path of this test file : ../youtube_dl/postprocessor/test_PostProcessor.py
    post_processor.try_utime(path, 0, 0)
    assert os.path.isfile(path)



# Generated at 2022-06-26 13:35:36.838569
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:35:46.143908
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    tmp_file = os.tmpfile() # TODO: get a temporary file
    # Convert to seconds since Unix epoch
    # TODO: Support timezone awareness
    atime = time.time()
    mtime = time.time()
    post_processor_1.try_utime(tmp_file, atime, mtime)
    # TODO: Check if tmp_file has the correct atime/mtime
    return True

# Generated at 2022-06-26 13:35:51.529315
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = ''
    atime_0 = 0
    mtime_0 = 0
    errnote_0 = ''
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:35:55.928472
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Test 0 of method try_utime
    test_utime_path_0 = "test_fjkcw2n.py"
    test_utime_atime_0 = 1543912150
    test_utime_mtime_0 = 1543912150
    test_utime_errnote_0 = "Cannot update utime of file"
    post_processor_1.try_utime(test_utime_path_0, test_utime_atime_0, test_utime_mtime_0, test_utime_errnote_0)


# Generated at 2022-06-26 13:36:05.269256
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    atime = 1516043255.2942879
    mtime = 1516043255.2942879
    return (atime, mtime)

test_values_0 = [
    ([test_case_0], 'verbose'),
    ([test_case_0], 'quiet'),
]

test_values_1 = [
    ([test_PostProcessor_try_utime], 'verbose'),
    ([test_PostProcessor_try_utime], 'quiet'),
]



# Generated at 2022-06-26 13:36:09.625028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('path', 'atime', 'mtime', 'errnote=')

# Generated at 2022-06-26 13:36:15.478882
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        postProcessor_0 = PostProcessor()
        try:
            postProcessor_0.try_utime('', 0, '', errnote='Cannot update utime of file')
        except Exception:
            pass
    except AttributeError:
        pass


# Generated at 2022-06-26 13:36:18.396224
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor_1 = PostProcessor()
    path = 'C:\\Users\\Kim\\YoutubeDL\\test\\test-data'
    atime = 1
    mtime = 2
    errnote = 'Cannot update utime of file'
    postprocessor_1.try_utime(path, atime, mtime, errnote)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:21.175411
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(None, None, None)

# Generated at 2022-06-26 13:36:30.290911
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test raises exception for invalid arguments
    with pytest.raises(TypeError):
        post_processor_0.try_utime(None, None, None)
    with pytest.raises(TypeError):
        post_processor_0.try_utime(encodeFilename('test_file'), None, None)
    with pytest.raises(TypeError):
        post_processor_0.try_utime(encodeFilename('test_file'), 2, None)
    with pytest.raises(TypeError):
        post_processor_0.try_utime(encodeFilename('test_file'), 2, 2)


# Generated at 2022-06-26 13:36:35.532747
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor_send = ['path', 1, 1, 'errnote']
    post_processor.try_utime(*post_processor_send)


# Generated at 2022-06-26 13:36:39.428622
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('path', 'atime', 'mtime', 'errnote')


# Generated at 2022-06-26 13:36:50.642369
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    post_processor_3 = PostProcessor()
    post_processor_4 = PostProcessor()
    post_processor_5 = PostProcessor()
    post_processor_6 = PostProcessor()
    post_processor_7 = PostProcessor()
    post_processor_8 = PostProcessor()
    post_processor_9 = PostProcessor()
    post_processor_10 = PostProcessor()
    post_processor_11 = PostProcessor()
    post_processor_12 = PostProcessor()
    post_processor_13 = PostProcessor()
    post_processor_14 = PostProcessor()
    post_processor_15 = PostProcessor()

# Generated at 2022-06-26 13:37:01.727063
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:37:06.998725
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'Cannot update utime of file'
    atime = 1
    mtime = 1
    post_processor_0.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:37:10.368210
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('dummy_path', 1234, 4321, 'not a good note')

# End of test for method try_utime of class PostProcessor


# Generated at 2022-06-26 13:37:21.515255
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create the post_processor_0
    post_processor_0 = PostProcessor()

    # Call the method try_utime of post_processor_0
    #  param(0): path
    #  param(1): atime
    #  param(2): mtime
    #  param(3): errnote
    post_processor_0.try_utime(path=b'/tmp/', atime=None, mtime=None, errnote=None)

    # Call the method try_utime of post_processor_0
    #  param(0): path
    #  param(1): atime
    #  param(2): mtime
    #  param(3): errnote

# Generated at 2022-06-26 13:37:25.594327
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    atime = 0
    mtime = 0
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("video1.mp4", atime, mtime)


# Generated at 2022-06-26 13:37:29.205414
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = os.path.join(os.getcwd(), 'pytube', '__init__.py')
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, 1466448979, 1476648979, 'Test utime')

# Generated at 2022-06-26 13:37:31.955364
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'http://localhost?key='
    atime = 5.0
    mtime = 11.0
    errnote = 'Cannot update utime of file'
    result = post_processor_0.try_utime(path, atime, mtime, errnote)
    assert result is None


# Generated at 2022-06-26 13:37:46.208393
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    post_processor_0 = PostProcessor()
    # Use try_utime(path, atime, mtime, errnote=Cannot update utime of file) method of class PostProcessor to set file modification time on the path
    post_processor_0.try_utime('/home/yasoob/Desktop/Yasoob/youtube-dl/youtube_dl/postprocessor/__init__.py', 1234, 1234, 'Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:48.806305
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(2, 3, 4, 'Cannot update utime of file')

# Generated at 2022-06-26 13:37:54.024013
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    # 1 test case
    assert post_processor_0.try_utime('path1\n', 5, 4) == None



# Generated at 2022-06-26 13:38:02.022685
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_cases = [
        {
            'path': 'this/is/fake/path',
            'atime': 0,
            'mtime': 0,
            'errnote': 'Cannot update utime of file'
        }
    ]
    for test_case in test_cases:
        post_processor_1 = PostProcessor()
        path = encodeFilename(test_case['path'])
        atime = test_case['atime']
        mtime = test_case['mtime']
        errnote = test_case['errnote']
        post_processor_1.try_utime(path, atime, mtime, errnote)



# Generated at 2022-06-26 13:38:12.996995
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    import pytest
    from .test_utils import make_fake_date_range
    from datetime import datetime, time
    from time import mktime
    utime_path = 'utime_path'
    utime_atime = 2.5
    utime_mtime = 1.5
    utime_errnote = 'Cannot update utime of file'
    # fake date to be used in _matching_date_range
    fake_date = datetime(2017, 8, 8, 12)
    fake_date_time_struct = mktime(fake_date.timetuple())

    # test with empty configuration and no date range
    downloader = YoutubeDL({'download_archive': 'download_archive'})

    post

# Generated at 2022-06-26 13:38:19.935665
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create test objects
    post_processor_1 = PostProcessor()
    # Try to set times for a file
    post_processor_1.try_utime(path = "path/to/file", atime = 123456, mtime = 123456)


# Generated at 2022-06-26 13:38:29.725685
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = b'/usr/local/lib/python3.7/dist-packages/youtube_dl/postprocessor/__init__.py'
    atime_0 = ''
    mtime_0 = ''
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:38:31.064575
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(__file__, 0, 0, 'Cannot update utime of file')

# Generated at 2022-06-26 13:38:34.116269
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, 0, 0, None)


# Generated at 2022-06-26 13:38:38.347005
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('post_processor_0', 'atime', 'mtime', 'errnote')



# Generated at 2022-06-26 13:38:50.930828
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    test_case_0()
    if post_processor_0.try_utime('test_case_0', 'test', 'test', 'test'):
        return True
    else:
        return False


# Generated at 2022-06-26 13:38:54.549897
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # try_utime method of class PostProcessor
    # with parameter filepath=test_filepath and atime=test_atime and mtime=test_mtime and errnote=test_errnote
    # no return value
    return

if __name__ == '__main__':
    print('Testing ' + __file__)
    test_case_0()
    print('Tests Finished')

# Generated at 2022-06-26 13:39:05.741737
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Not testing for the actual time change
    # Just for the code to execute without errors
    # (i.e. IOError raised)

    # Create dummy file
    import tempfile
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)

    try:
        import datetime
        import time
        pp = PostProcessor()
        # Set some time in the past
        past_time = time.time() - 100000
        # Set a time in the future
        future_time = time.time() + 90000
        try:
            pp.try_utime(tmp_file, past_time, future_time)
        except Exception:
            # Catch all exceptions
            raise PostProcessingError('Error: cannot update utime of file')
    finally:
        os.remove(tmp_file)

# Generated at 2022-06-26 13:39:10.687018
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'path'
    atime_0 = post_processor_0.try_utime(path_0, 0, 0)


# Generated at 2022-06-26 13:39:15.577655
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create an instance of PostProcessor and test if it works
    downloader = object()
    post_processor_0 = PostProcessor(downloader)
    path = './test_utime_path'
    atime = 1
    mtime = 2
    post_processor_0.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:39:21.895766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor(downloader=None)
    post_processor_0 = PostProcessor()

    # Test.test_PostProcessor_try_utime:0
    test_path = 'unit-tests/tmp'
    test_atime = 7.0
    test_mtime = 7.0
    test_errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(test_path, test_atime, test_mtime, test_errnote)

    # Test.test_PostProcessor_try_utime:1
    test_path = 'unit-tests/tmp'
    test_atime = 7.0
    test_mtime = 7.0
    test_errnote = 'Cannot update utime of file'
    post_processor_0

# Generated at 2022-06-26 13:39:24.546610
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("path", 1, 2)


# Generated at 2022-06-26 13:39:30.431299
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime('test_0',0,0)==None

test_PostProcessor_try_utime()
test_case_0()

# Generated at 2022-06-26 13:39:39.787283
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .YdlFileDownloader import YdlFileDownloader
    os.makedirs('/tmp/test_ydl')
    ydl_opts = {
        'outtmpl': '/tmp/test_ydl/%(id)s.%(ext)s'
    }
    ydl_with_pp = YoutubeDL(ydl_opts)
    with open('/tmp/test_ydl/test_file.txt', 'w') as f:
        f.write('test')
    downloader = YdlFileDownloader(ydl_with_pp)
    post_processor_0 = PostProcessor(downloader)
    path = '/tmp/test_ydl/test_file.txt'
    atime = 1000000000
    mtime = atime

# Generated at 2022-06-26 13:39:50.520515
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test for case of method try_utime
    try:
        test_PostProcessor = PostProcessor()
        try:
            path = 'pass'
            atime = 1
            mtime = 2
            errnote = 3
            assert_equals(test_PostProcessor.try_utime(path, atime, mtime, errnote),)
        except:
            pass
    except:
        assert False
    # Test for case of method try_utime

# Generated at 2022-06-26 13:40:05.668936
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor = PostProcessor()
    postprocessor.try_utime(path='path', atime=123456, mtime=123456)

# Generated at 2022-06-26 13:40:08.039059
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    sample_file_0 = 'sample_file.bin'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(sample_file_0, 0, 10)

# Generated at 2022-06-26 13:40:15.425274
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = None
    post_processor_1 = PostProcessor(downloader)
    path = '/path/to/file'
    atime = 1000
    mtime = 1000
    errnote = 'Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote)



# Generated at 2022-06-26 13:40:21.877992
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_datetime_datetime

    from .test_utils import FakeYDL

    ydl = FakeYDL()
    ydl.params = {'ffmpeg_location': 'ffmpeg', 'outtmpl': '%(id)s-%(ext)s',
                  'sleep_interval': 0, 'download_archive': []}
    post_processor_0 = PostProcessor(ydl)

    # Calling try_utime with invalid arguments
    try:
        post_processor_0.try_utime(path=0, atime=(1,), mtime='1', errnote=1)
    except TypeError:
        pass

# Generated at 2022-06-26 13:40:27.577439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    check_1 = False
    post_processor_1 = PostProcessor()
    try:
        post_processor_1.try_utime('', 0, 0)
    except Exception:
        pass
    else:
        check_1 = True
    assert check_1 == True


# Generated at 2022-06-26 13:40:37.986907
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test error on try_utime of class PostProcessor
    post_processor_0 = PostProcessor()
    assert os.path.exists('files/test_video.mp4'), 'test file does not exist'
    try:
        post_processor_0.try_utime('files/test_video.mp4', 1234, 1234)
    except OSError:
        pass
    else:
        raise AssertionError

# Test error on run of class PostProcessor

# Generated at 2022-06-26 13:40:46.927254
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = '>Juvpai\x87'
    errnote_0 = ';c'
    post_processor_0.try_utime(path=path_0, atime=post_processor_0, mtime=path_0, errnote=errnote_0)
    assert path_0 != path_0


# Generated at 2022-06-26 13:40:52.856912
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # class test_case_0(PostProcessor):
    #     def run(self,information):
    #         print(information)
    #         return information

    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='http://www.youtube.com/watch?v=hEz8H3qm3XE', atime='hEz8H3qm3XE', mtime='hEz8H3qm3XE', errnote='Cannot update utime of file')


if __name__ == "__main__":

    print('Testing class PostProcessor')
    test_case_0()
    print('Testing method try_utime of class PostProcessor')
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:59.409709
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(os.path.join('test_dir', 'test_file'), 0, 0)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:08.734957
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_2 = PostProcessor(post_processor_0)
    post_processor_0.try_utime(encodeFilename("test_post_processor.py"), 1, 1, 'Cannot update utime of file')
    post_processor_2.try_utime(encodeFilename("test_post_processor.py"), 1, 1, 'Cannot update utime of file')
    return

# Generated at 2022-06-26 13:41:51.662537
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    For method "try_utime" of class "PostProcessor"
    """
    ### Test case 0 ###
    temp_file_name = "temp_DummyTest_PostProcessor_try_utime.txt"
    try:
        with open(temp_file_name, "a") as temp_file:
            temp_file.write("Dummy file!")
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime(temp_file_name, 1466135850.035, 1466135850.035, "errnote")
    except:
        print("Unexpected exception!")
    finally:
        os.remove(temp_file_name)


# Generated at 2022-06-26 13:41:56.117003
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test", 2,3, "test_case")


# Generated at 2022-06-26 13:42:01.714135
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(path='test_path', atime=100, mtime=200, errnote='error note')
    return post_processor

test_class_for_PostProcessor_try_utime = test_PostProcessor_try_utime

# Generated at 2022-06-26 13:42:10.815150
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = 'https://www.youtube.com/watch?v=Ik-RsDGPI5Y'
    atime = 1556267747.404074
    mtime = 1556267402.667205
    try:
        post_processor_1.try_utime(path, atime, mtime, errnote='Cannot update utime of file')
    except Exception:
        pass


# Generated at 2022-06-26 13:42:17.961362
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(b'C:\\Users\\user\\Videos\\youtube-dl\\youtube_dl\\__init__.py', 0.0, 0.0)


if __name__ == "__main__":
    pass

# Generated at 2022-06-26 13:42:22.311877
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessortry_utime = PostProcessor()
    postprocessortry_utime.try_utime("path", "atime", "mtime")


# Generated at 2022-06-26 13:42:24.735033
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime(None, None, None)

# Generated at 2022-06-26 13:42:28.694319
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("", 0.816386, 0.693297)


# Generated at 2022-06-26 13:42:32.343893
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Setup input arguments
    path = 'path'
    atime = 'atime'
    mtime = 'mtime'
    errnote = 'errnote'
    # Setup PostProcessor object
    postProcessor = PostProcessor()
    # Invoke method try_utime of PostProcessor
    postProcessor.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:42:39.475439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    file_path = str()
    post_processor_0.try_utime(file_path, 0, 0)
    file_path = str()
    post_processor_0.try_utime(file_path, 0, 0, str())
