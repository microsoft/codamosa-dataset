

# Generated at 2022-06-26 13:33:41.963621
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor_0 = PostProcessor()
    postprocessor_0.try_utime(str(), float(), float(), str())

if __name__ == "__main__":
    import sys, logging

    logging.basicConfig(level=logging.ERROR)

    if len(sys.argv) > 1:
        globals()['test_' + sys.argv[1]]()
    else:
        for k, v in globals().items():
            if k.startswith(('test_', '__')):
                continue
            print('Running test for %s' % k)
            try:
                v()
            except:
                print('FAILED')

# Generated at 2022-06-26 13:33:50.052326
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test with path = None, atime = None, mtime = None, errnote = None
    post_processor_0.try_utime(None, None, None, None)

    # Test with path = bool_0, atime = bool_0, mtime = bool_0, errnote = bool_0
    post_processor_0.try_utime(bool_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-26 13:33:52.595231
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    float_0 = float()
    float_1 = float()
    post_processor_0.try_utime(str(), float_0, float_1, 'Cannot update utime of file')

# Generated at 2022-06-26 13:33:55.860790
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = 'Cannot update utime of file'
    post_processor_0.try_utime('d:\\iso\\a.txt', 0, 0, str_0)


# Generated at 2022-06-26 13:33:58.282135
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor = PostProcessor()
    postprocessor.try_utime()


# Generated at 2022-06-26 13:34:00.677308
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    float_0 = float()
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(str(), float_0, float_0)

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:12.598861
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor
    postprocessor_0 = PostProcessor()

    # Create some dummy arguments
    path_0 = None
    atime_0 = None
    mtime_0 = None
    errnote_0 = None

    # Check if raise exception is true
    if 'raise_exception' in PostProcessor.try_utime.__dict__:
        raise PostProcessingError()

    # Call method without arguments
    postprocessor_0.try_utime()

    # Call method with arguments
    postprocessor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)



# Generated at 2022-06-26 13:34:16.486923
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('', 0.0, 0.0) == None

# Generated at 2022-06-26 13:34:20.266797
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Cases:
    # 1. os.utime raises an exception
    # 2. os.utime doesn't raise an exception
    # TODO: find a way to test both of the cases without resorting to mocking
    pass

# Generated at 2022-06-26 13:34:25.789226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0._downloader == None

    post_processor_0.try_utime(None, None, None)


# Generated at 2022-06-26 13:34:30.777220
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, None, None, None)


# Generated at 2022-06-26 13:34:31.745228
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO: Add tests
    pass


# Generated at 2022-06-26 13:34:32.668383
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:34:37.378071
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:34:46.856858
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Tests for method try_utime(self, path, atime, mtime, errnote='Cannot update utime of file')
    # Line 1380
    test_case_0()

    # Tests for method try_utime(self, path, atime, mtime, errnote='Cannot update utime of file')
    # Line 1390
    test_case_0()

    # Tests for method try_utime(self, path, atime, mtime, errnote='Cannot update utime of file')
    # Line 1400
    test_case_0()

    # Tests for method try_utime(self, path, atime, mtime, errnote='Cannot update utime of file')
    # Line 1409
    test_case_0()


# Generated at 2022-06-26 13:34:48.681330
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("sxK4PqoYzp8,PfhGzBZus1c", 1, 2)


# Generated at 2022-06-26 13:34:49.630070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    var_0 = TestClass_0()
    var_0.test_method_0()


# Generated at 2022-06-26 13:34:54.207593
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(post_processor_0)
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:35:06.275540
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    def test_0(self, path, atime, mtime, errnote='Cannot update utime of file'):
        try:
            os.utime(encodeFilename(path), (atime, mtime))
        except Exception:
            self._downloader.report_warning(errnote)
    self = PostProcessor()
    path = None
    atime = None
    mtime = None
    errnote = 'Cannot update utime of file'
    test_0(self, path, atime, mtime, errnote)
    errnote = 'Cannot update utime of file'
    test_0(self, path, atime, mtime, errnote)
    errnote = 'Cannot update utime of file'
    test_0(self, path, atime, mtime, errnote)
    errnote

# Generated at 2022-06-26 13:35:14.653005
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Creating PostProcessor object
    post_processor_0 = PostProcessor()

    # Assigning False to 'errnote' (variable_0)
    variable_0 = False

    # Calling try_utime with arguments (variable_0, variable_0, variable_0, variable_0)
    # Calling try_utime with arguments (variable_0, variable_0, variable_0, variable_0)
    post_processor_0.try_utime(variable_0, variable_0, variable_0, variable_0)


# Generated at 2022-06-26 13:35:22.722672
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Default arguments
    postProcessor_default = PostProcessor()
    assert postProcessor_default.try_utime(4, 5, 6, 7) == (os.utime(4, 5, 6, 7), 8)



# Generated at 2022-06-26 13:35:26.649115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Default test
    post_processor_0 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    assert var_0 is None

# Generated at 2022-06-26 13:35:34.597972
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    post_processor_3 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_1, post_processor_2, post_processor_3, post_processor_0)

# Generated at 2022-06-26 13:35:41.555386
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except Exception:
        raise AssertionError("failed in try_utime()")


# Generated at 2022-06-26 13:35:45.002244
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor(0)
    post_processor_0.update_hash(0, 0, 0)

# Generated at 2022-06-26 13:35:49.599896
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.set_downloader(post_processor_1)
    post_processor_1.try_utime(post_processor_1, post_processor_1, post_processor_1, post_processor_1)
    test_case_0()


# Generated at 2022-06-26 13:35:50.403564
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert callable(PostProcessor.try_utime)

# Generated at 2022-06-26 13:35:51.513818
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:35:58.937335
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    post

# Generated at 2022-06-26 13:36:04.903529
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    if(os.path.isfile(post_processor_0)):
        print(var_0)


# Generated at 2022-06-26 13:36:20.597800
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Patch _downloader instance used in PostProcessor.try_uTime
    from ..downloader.common import FileDownloader
    from ..downloader.external.rarfile import RarFile
    mock_downloader = FileDownloader({})
    mock_downloader.report_warning = lambda msg: msg

    # Test file with restricted access
    mock_file = RarFile(encodeFilename('./tests/testvideo.rar'), 'r')
    mock_file.set_accessed()
    mock_file.close()

    post_processor_1 = PostProcessor(mock_downloader)
    var_1 = post_processor_1.try_utime('./tests/testvideo.rar', 1425039492, 1425039738, 'Cannot update utime of file ./tests/testvideo.rar')

    # Test file

# Generated at 2022-06-26 13:36:25.795424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # No argument, raise TypeError
    var_1 = PostProcessor()
    try:
        var_1.try_utime()
    except TypeError:
        var_2 = True
    else:
        var_2 = False
    assert var_2

# Generated at 2022-06-26 13:36:28.690186
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    arg_0 = PostProcessor()
    arg_1 = PostProcessor()
    arg_2 = PostProcessor()
    arg_3 = ''
    var_0 = arg_0.try_utime(arg_1, arg_2, arg_3)


# Generated at 2022-06-26 13:36:33.470111
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    var_1 = post_processor_1.try_utime(post_processor_1, post_processor_1, post_processor_1, post_processor_1)


# Generated at 2022-06-26 13:36:38.511851
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Initialize
    post_processor = PostProcessor()
    # Run method and check returned value
    assert post_processor.try_utime(post_processor, post_processor, post_processor, post_processor) is None

# Generated at 2022-06-26 13:36:40.860842
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()


# Generated at 2022-06-26 13:36:47.294895
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    var_0 = post_processor_1.try_utime("abc", 1, 1, "")
    assert var_0 is None
    var_0 = post_processor_1.try_utime("abc", 1, 1, "")
    assert var_0 is None


# Generated at 2022-06-26 13:36:51.929930
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:36:57.017714
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    post_processor_3 = PostProcessor()
    post_processor_4 = PostProcessor()
    post_processor_5 = PostProcessor()
    post_processor_6 = PostProcessor()
    post_processor_7 = PostProcessor()
    post_processor_8 = PostProcessor()
    post_processor_9 = PostProcessor()
    post_processor_10 = PostProcessor()
    post_processor_11 = PostProcessor()
    post_processor_12 = PostProcessor()
    post_processor_13 = PostProcessor()
    post_processor_14 = PostProcessor()
    post_processor_15 = PostProcessor()
    post_processor_16 = PostProcessor()

# Generated at 2022-06-26 13:37:00.574964
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:37:14.618193
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except Exception as e:
        assert(e.contex.startswith("postProcessing of") == True or
               e.contex.startswith("Cannot update utime of") == True)



# Generated at 2022-06-26 13:37:15.936493
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    raise NotImplementedError

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:19.087468
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:37:19.816777
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:37:24.629179
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)



# Generated at 2022-06-26 13:37:28.819235
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert 'Cannot update utime of file' in post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0).__str__()

# Generated at 2022-06-26 13:37:34.191859
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Testing exceptions
    var_0 = PostProcessor()
    try:
        var_0.try_utime(var_0, var_0, var_0, var_0)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-26 13:37:34.942482
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-26 13:37:38.516076
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    var_1 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    assert(var_1 == None)


# Generated at 2022-06-26 13:37:39.893976
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()

# Generated at 2022-06-26 13:38:09.423018
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except Exception as error:
        print(error.message + '\n')


# Generated at 2022-06-26 13:38:15.893453
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except Exception:
        assert 1



# Generated at 2022-06-26 13:38:21.005833
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # test case 0
    post_processor_0 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)



# Generated at 2022-06-26 13:38:22.459112
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert_equals((), test_case_0())

# Generated at 2022-06-26 13:38:29.348050
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    var_1 = PostProcessor()
    var_2 = ''
    var_3 = 0.0
    var_4 = 0.0
    var_5 = ''
    var_1.try_utime(var_2, var_3, var_4, var_5)


# Generated at 2022-06-26 13:38:32.208403
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(var_0, var_1, var_2)


# Generated at 2022-06-26 13:38:33.733577
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # No assertions
    return True 


# Generated at 2022-06-26 13:38:37.535239
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    var_0 = PostProcessor()
    var_0.try_utime("str", 0.0, 0.0)


# Generated at 2022-06-26 13:38:39.810797
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # TODO: write test

# Generated at 2022-06-26 13:38:40.989687
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()



# Generated at 2022-06-26 13:39:37.976289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_1.set_downloader(post_processor_0)
    post_processor_0.report_warning(post_processor_1)
    post_processor_1.run(post_processor_0)
    var_0 = post_processor_0.try_utime(post_processor_1, post_processor_0, post_processor_0, post_processor_0)

# Generated at 2022-06-26 13:39:48.897760
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test with valid arguments
    try:
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except:
        assert False, 'Incorrect behaviour of method try_utime of class PostProcessor with valid arguments'
    # Test with invalid arguments
    try:
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except:
        assert True, 'Expected behaviour of method try_utime of class PostProcessor with invalid arguments'


# Generated at 2022-06-26 13:39:50.174413
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert None


# Generated at 2022-06-26 13:39:59.530073
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1._downloader = '_downloader'
    post_processor_1.try_utime(path='path', atime='atime',
                               mtime='mtime', errnote='errnote')
    post_processor_1.try_utime(path='path', atime='atime',
                               mtime='mtime', errnote='errnote')
    post_processor_1.try_utime(path='path', atime=post_processor_1,
                               mtime='mtime', errnote='errnote')
    post_processor_1.try_utime(path='path', atime='atime',
                               mtime=post_processor_1, errnote='errnote')

# Generated at 2022-06-26 13:40:03.411295
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Basic test
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 13:40:12.564779
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    var_0 = PostProcessor()  # type: object
    var_0.try_utime(var_0, var_0, var_0, var_0)
    var_1 = PostProcessor()  # type: object
    var_1.try_utime(var_1, var_1, var_1, var_1)
    var_1 = PostProcessor()  # type: object
    var_1.try_utime(var_1, var_1, var_1, var_1)
    var_1 = PostProcessor()  # type: object
    var_1.try_utime(var_1, var_1, var_1, var_1)
    var_1 = PostProcessor()  # type: object

# Generated at 2022-06-26 13:40:19.136289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()

    # Testing for when the utime fails to be set
    with mock.patch('os.utime', side_effect=OSError):
        postProcessor.try_utime("path", "atime", "mtime", "errnote")

    # Testing for when the utime succeeds in being set
    with mock.patch('os.utime'):
        postProcessor.try_utime("path", "atime", "mtime", "errnote")

# Generated at 2022-06-26 13:40:24.092668
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:40:27.140444
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except Exception:
        var_0 = True
    else:
        var_0 = False
    assert var_0


# Generated at 2022-06-26 13:40:29.540469
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Case 0: test_case_0
    test_case_0()


# Generated at 2022-06-26 13:42:34.313944
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import nose
    from nose.tools import assert_raises

    # test for errors
    post_processor_2 = PostProcessor()
    with assert_raises(PostProcessingError):
        post_processor_2.try_utime('Cannot update utime of file', 'Cannot update utime of file', 'Cannot update utime of file', 'Cannot update utime of file')

    # test for exceptions
    post_processor_2 = PostProcessor()
    with assert_raises(PostProcessingError):
        post_processor_2.try_utime('Cannot update utime of file', 'Cannot update utime of file')

    # test for when exception is not raised
    post_processor = PostProcessor()

# Generated at 2022-06-26 13:42:41.394888
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        try:
            os.utime(encodeFilename(post_processor_0), post_processor_0)
        except Exception:
            post_processor_0._downloader.report_warning(post_processor_0)
    except Exception:
        pass



# Generated at 2022-06-26 13:42:43.763896
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()


test_cases = [
    test_PostProcessor_try_utime
]



# Generated at 2022-06-26 13:42:49.556860
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:42:54.754672
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    try:
        os.utime(encodeFilename(post_processor_1), (post_processor_1, post_processor_1))
    except Exception:
        post_processor_0._downloader.report_warning('Cannot update utime of file')



# Generated at 2022-06-26 13:42:59.264441
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)



# Generated at 2022-06-26 13:43:04.154498
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)


# Generated at 2022-06-26 13:43:14.307340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Try to create a PostProcessor object and call try_utime
    try:
        post_processor_0 = PostProcessor()
        var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    except PostProcessingError:
        # Confirm that PostProcessingError is raised
        assert True
    else:
        # Confirm that PostProcessingError is raised
        assert False

# Generated at 2022-06-26 13:43:20.250192
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert not isinstance(post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0), bool)


# Generated at 2022-06-26 13:43:26.484029
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    #    post_processor_0 = PostProcessor()
    print('unit_test start')
#    var_0 = post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0, post_processor_0)
    test_case_0()
    print('unit_test end')