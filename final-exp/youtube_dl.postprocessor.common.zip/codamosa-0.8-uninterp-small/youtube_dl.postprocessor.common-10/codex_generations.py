

# Generated at 2022-06-26 13:33:39.379244
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    audio_conversion_error_0 = AudioConversionError()
    postprocessor_0 = PostProcessor()
    postprocessor_0.try_utime(audio_conversion_error_0, False, audio_conversion_error_0)


# Generated at 2022-06-26 13:33:48.659440
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try_utime_0 = PostProcessor()
    path_0 = 'postprocessor_testdata/file.txt'
    atime_0 = 2
    mtime_0 = 2
    errnote_0 = 'Cannot update utime of file'
    try_utime_0.try_utime(path_0, atime_0, mtime_0, errnote_0)
    return True


# Generated at 2022-06-26 13:33:53.848961
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    bool_0 = False
    post_processor_0.try_utime('', 1, 1, 'Cannot update utime of file')


# Generated at 2022-06-26 13:33:59.553661
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    bool_0 = False
    test_case_0()
    if bool_0:
        post_processor_0.try_utime(str_0, long_0, long_0, 'ERROR')
    else:
        post_processor_0.try_utime('', False, False, 'ERROR')

# Generated at 2022-06-26 13:34:09.383405
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    with open('./__downloader_test.txt', 'w'):
        pass
    try:
        os.remove('./__downloader_test.txt')
    except OSError:
        pass
    try:
        post_processor_0.try_utime('./__downloader_test.txt', 0.0, 0.0)
    except OSError:
        pass

# Generated at 2022-06-26 13:34:15.192631
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime = lambda path, atime, mtime: False

    downloader_0 = Downloader()
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(downloader_0)
    post_processor_0.try_utime("", 2.23606797749979, 4.0, "Cannot update utime of file")


# Generated at 2022-06-26 13:34:16.173308
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:34:20.812686
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test of method try_utime of class PostProcessor, with invalid
    # atime and mtime values
    pp_0 = PostProcessor()
    pp_0._downloader = MockYoutubeDL()
    pp_0._downloader.report_warning = youtube_dl.YoutubeDL.report_warning
    pp_0.try_utime('', None, None)


# Generated at 2022-06-26 13:34:31.746404
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, None, None)
    post_processor_0.try_utime()
    post_processor_0.try_utime(None, None)
    post_processor_0.try_utime(None)
    post_processor_0.try_utime(None, None, None, None)
    post_processor_0.try_utime(None, None, None, 'Cannot update utime of file')


# Generated at 2022-06-26 13:34:39.944519
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor_0 = PostProcessor()
    str_0 = 'Cannot update utime of file'
    postprocessor_0.try_utime('C:\\Users\\kpadhikari\\Desktop\\pytube-master\\pytube\\tests', float('inf'), float('inf'), str_0)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:47.714635
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = '+@{}'
    int_0 = 0
    int_1 = 0
    post_processor_0.try_utime(str_0, int_0, int_1)


# Generated at 2022-06-26 13:34:48.781829
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert False


# Generated at 2022-06-26 13:34:50.009729
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test the utime method
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', None, None)


# Generated at 2022-06-26 13:34:52.100289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    atime_0 = 4
    mtime_0 = 0
    errnote_0 = 'cannot update utime of file'
    post_processor_0.try_utime('', atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:35:05.527304
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    os_utime_0 = (1, 1)
    encode_filename_0 = '/path/to/file.txt'
    str_0 = encode_filename_0
    os_utime_1 = os_utime_0
    exc_0 = PostProcessingError('Cannot update utime of file')
    str_1 = 'Cannot update utime of file'
    # Checking the exception is raised
    with pytest.raises(PostProcessingError) as excinfo:
        assert exc_0 == excinfo.value
    # Checking the error message
    assert str_0 == str_1
    try:
        os.utime(encodeFilename(encode_filename_0), os_utime_1)
    except Exception:
        post_processor_1._download

# Generated at 2022-06-26 13:35:09.850959
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = '+@{}'
    post_processor_0.try_utime('+@{}', 1.0, 1.0)


# Generated at 2022-06-26 13:35:15.834056
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test 1
    post_processor_0 = PostProcessor()
    str_0 = '+@{}'
    path_0 = '^]Bz'
    atime_0 = -5.0532665349492822
    mtime_0 = -2.68
    errnote_0 = 'a8i'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)



# Generated at 2022-06-26 13:35:21.857977
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = 'https://example.com'
    post_processor_0.try_utime(str_0, 1, 1)
    post_processor_0.try_utime(str_0, 1, 1, ' ')

# Generated at 2022-06-26 13:35:26.762541
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/home/lds/public_html/video/fetchdata.php', 1421468505.8774, 1421468505.8774)


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:33.762885
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    print ('Testing: try_utime')
    post_processor_0 = PostProcessor()
    try_utime(post_processor_0, '+@{}', 16843938, 8034077, 'Cannot update utime of file')

test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:42.625309
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    error_note_0 = '\n** ERROR: unable to update mtime for file _2.txt\n'
    post_processor_1 = PostProcessor()
    assert post_processor_1._downloader is None


# Generated at 2022-06-26 13:35:49.428886
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = '/tmp/youtube-dl/test'
    atime_0 = 1576122215.980538
    mtime_0 = 1576122215.980538
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:35:51.775350
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test_data/test.mp4', 0, 0)


# Generated at 2022-06-26 13:35:54.526604
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('octopod.py', 11, 11, 'Cannot update utime of file')


# Generated at 2022-06-26 13:35:56.253318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    pass


# Generated at 2022-06-26 13:36:01.300722
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:07.036596
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_10 = PostProcessor()
    path_10 = '+@{}'
    atime_10 = '+@{}'
    mtime_10 = '+@{}'
    errnote_10 = '+@{}'
    post_processor_10.try_utime(path_10, atime_10, mtime_10, errnote_10)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:08.646016
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path_0='', atime_0=None, mtime_0=None, errnote_0='Cannot update utime of file')


# Generated at 2022-06-26 13:36:13.168823
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        os.utime('file')
    except Exception as e:
        assert False, "Try to update utime of file failed"


# Generated at 2022-06-26 13:36:16.295170
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert isinstance(post_processor_0, PostProcessor)

    post_processor_0.try_utime('', 0, 0, 'Cannot update utime of file')

# Generated at 2022-06-26 13:36:26.273899
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    post_processor_3 = PostProcessor()


# Generated at 2022-06-26 13:36:28.173603
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # 1. Test with all parameters
    # 2. Test with no optional parameters
    # 3. Test with no parameters
    # 4. Test with unsupported type of parameter
    post_processor_0 = PostProcessor()
    return str(post_processor_0)


# Generated at 2022-06-26 13:36:29.140902
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = '\\@'

# Generated at 2022-06-26 13:36:31.566874
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # FORMAT_SEPARATOR = '%s'
    # Try utime with a valid file
    post_processor_0 = PostProcessor()
    pass # TODO: implement test



# Generated at 2022-06-26 13:36:38.152068
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    str_1 = 'this is a test'
    atime_0 = 0.0
    mtime_0 = 0.0
    post_processor_0 = PostProcessor()
    errnote_0 = 'this is a test'
    post_processor_0.try_utime(str_1, atime_0, mtime_0, errnote_0)



# Generated at 2022-06-26 13:36:46.702214
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path_0 = 'P5""5'
    atime_0 = tuple()
    mtime_0 = 'e'
    PostProcessingError()
    PostProcessor()
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path_0, atime_0, mtime_0)


# Generated at 2022-06-26 13:36:49.302901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('C:/Users/Dev/Desktop/YTDL/Test/test.txt', 0.0, 0.0)


# Generated at 2022-06-26 13:36:59.125764
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test number of arguments
    post_processor_0 = PostProcessor()
    str_0 = '+@{}'
    int_0 = 0
    int_1 = 0
    str_1 = '+@{}'
    post_processor_0.try_utime(str_0, int_0, int_1, str_1)

if __name__ == '__main__':
    import pytest
    pytest.main('test_PostProcessor.py')

# Generated at 2022-06-26 13:37:11.450779
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Test for PostProcessor class.
    # In this test, I will try to change the utime values of the file
    # to check if the file has been modified.
    # I will also test it with nonexistent files
    # Also, I will test it with various u/a time values.
    import os
    import shutil
    import time
    import sys
    temp_dir = '__temp__'

    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.mkdir(temp_dir)

# Generated at 2022-06-26 13:37:19.641831
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    from shutil import chmod
    import os.path

    import tempfile

    file_path_0 = NamedTemporaryFile().name
    atime_0 = 0.0
    mtime_0 = 0.0
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(PATH=file_path_0, ATIME=atime_0, MTIME=mtime_0)



# Generated at 2022-06-26 13:37:39.157419
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('path', 'atime', 'mtime', 'errnote')
    except PostProcessingError:
        pass
    try:
        post_processor_0.try_utime('path', 0.19, 0.1)
    except PostProcessingError:
        pass
    try:
        post_processor_0.try_utime('path', 'atime', 'mtime')
    except PostProcessingError:
        pass
    try:
        post_processor_0.try_utime('path', 'atime', 0.1)
    except PostProcessingError:
        pass


# Generated at 2022-06-26 13:37:42.010942
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # TODO: implement testing for method PostProcessor.try_utime

# Generated at 2022-06-26 13:37:51.071438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    import datetime  # line: 133
    import time  # line: 134
    str_0 = '/YxpA1/'  # line: 146
    str_1 = 'Cannot update utime of file'  # line: 147
    try:  # line: 148
        import os  # line: 149
        try:  # line: 150
            os.utime(encodeFilename(str_0), (0, 0))  # line: 153
        except Exception as exception_0:  # line: 155
            post_processor_0._downloader.report_warning(str_1)  # line: 156
    except:
        pass


# Generated at 2022-06-26 13:37:54.794851
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0, '')

# Generated at 2022-06-26 13:37:59.325077
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime(encodeFilename('f6de936d32.tmp'), None, None) == (None, None)
# Test for method try_utime

# Generated at 2022-06-26 13:38:04.739706
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # test for try_utime
    test_case_0()

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:07.811297
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', '', '')


# Generated at 2022-06-26 13:38:10.137689
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('')


# Generated at 2022-06-26 13:38:11.971234
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 13:38:18.510536
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_instance = PostProcessor()

    # first input to the method
    path =  "test_path"
    atime = None
    mtime = None

    # call the method
    post_processor_instance.try_utime(path, atime, mtime)

# Generated at 2022-06-26 13:38:48.743686
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:52.779230
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('dtg6j;X+^;dJ\G>P*Y<lA%C8+Q<', 34.989, 32.633)


# Generated at 2022-06-26 13:39:03.326087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    encoding_0 = None
    os_0 = None
    os_1 = None
    os_2 = None
    os_3 = None
    os_4 = None
    os_5 = None
    os_6 = None
    os_7 = None
    os_8 = None
    post_processor_0.try_utime(None, None, None, None)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:08.172992
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('a', 'b', 'c', 'd')


# Generated at 2022-06-26 13:39:13.346670
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('', 12.0, 12.0, 'Cannot update utime of file')
    except Exception:
        pass


# Generated at 2022-06-26 13:39:14.513186
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)



# Generated at 2022-06-26 13:39:18.929215
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename('test_path'), -1, -1754079136)


# Generated at 2022-06-26 13:39:22.362831
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)


# Generated at 2022-06-26 13:39:29.562842
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', '', '', 'Cannot update utime of file')
    str_0 = 'Cannot update utime of file'
    assert str_0 == 'Cannot update utime of file'

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:36.941609
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
#     path = 'B:/public/20140406/20140406000004/tips.json'
    path = 'B:\\public\\20140406\\20140406000004\\tips.json'
    atime = 1
    mtime = 1
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, atime, mtime, 'Cannot update utime of file')


# Generated at 2022-06-26 13:40:42.822544
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('downloads/file.mp3', 1000, 1000, 'Could not update utime of file')

# Generated at 2022-06-26 13:40:45.870865
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', '', '', '')


# Generated at 2022-06-26 13:40:49.930601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_0 = '^b.`xRdwH'
    post_processor_0.try_utime(str_0, '', '', 'Cannot update utime of file')


# Generated at 2022-06-26 13:40:57.439086
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'gelles'
    atime = 270
    mtime = 270
    errnote = 'Cannot update utime of file'
    str_0 = post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:41:00.452892
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime('string_1', 15, 16, 'string_0') == None

# Generated at 2022-06-26 13:41:12.247000
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor
    str_0 = 'H!'
    str_1 = 'a'
    str_2 = '@}iC?&'
    str_3 = 'j%ukb'
    str_4 = '%`p/'
    str_5 = '<'
    str_6 = '&s? '
    str_7 = 'd*'
    str_8 = 'G#&'
    str_9 = 'V'
    str_10 = "'h!1"
    str_11 = '=+&'
    str_12 = '8'
    str_13 = 'CvJ'
    str_14 = '+'
    str_15 = 'Wk'
    str_16 = 's'
    str_17 = '~'
    str_

# Generated at 2022-06-26 13:41:21.085680
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(os.path.join(os.path.sep, 'home', 'cristina', 'Documents', 'youtube-dl_videos'), 0, 1)
    post_processor_0.try_utime(os.path.join(os.path.sep, 'home', 'cristina', 'Documents', 'youtube-dl_videos'), 0, 1, errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:41:28.601292
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Tested method call
    post_processor_0.try_utime('test_file', 1365506571744, 1365506571744, 'Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:29.065446
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:41:42.691536
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # _downloader will be None
    # path does not exits
    errnote = 'Cannot update utime of file'
    res = post_processor_0.try_utime(os.getcwd(), 0, 0, errnote)
    # The utime will be still not be successful, as the file does not exists
    test_case_0()
    # _downloader will be None
    # path exists
    # Change the value of errnote
    errnote = 'Abcd'
    # Call try_utime() again to get a result
    res = post_processor_0.try_utime(os.getcwd(), 0, 0, errnote)
    # The utime will be not be successful, as only the filepath is changed
    test_case_0()
   