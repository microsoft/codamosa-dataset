

# Generated at 2022-06-26 13:33:42.658044
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Constructor test:
    # No arguments
    post_processor_0 = PostProcessor()
    # Two arguments
    post_processor_1 = PostProcessor(None)
    # Three arguments
    post_processor_2 = PostProcessor(None, None)
    # Four arguments
    post_processor_3 = PostProcessor(None, None, None)
    # Five arguments
    post_processor_4 = PostProcessor(None, None, None, None)

    file_name_0 = 'file_name_0'
    file_name_1 = 'file_name_1'
    try:
        post_processor_0.try_utime(file_name_1, 8109, 8109, 'Cannot update utime of file')
    except Exception:
        pass

# Generated at 2022-06-26 13:33:45.950143
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(1, 1, 1)


# Generated at 2022-06-26 13:33:47.477951
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()


# Generated at 2022-06-26 13:33:50.762267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_2 = PostProcessor()
    post_processor_2.try_utime('path', 1436475967, 1436475967)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:02.196312
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_10 = PostProcessor()
    post_processor_10.try_utime("https://www.youtube.com/watch?v=ywY92KB3qIE", "https://www.youtube.com/watch?v=ywY92KB3qIE", "https://www.youtube.com/watch?v=ywY92KB3qIE", "https://www.youtube.com/watch?v=ywY92KB3qIE")
    post_processor_11 = PostProcessor(downloader=None)

# Generated at 2022-06-26 13:34:09.153295
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/tmp/youtube_dl/temp.mkv', 1410276102.0, 1463237715.4, errnote='Cannot update utime of file')
    return True


# Generated at 2022-06-26 13:34:14.829643
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('any.path', 1234, 5678, errnote='test note')
    post_processor.try_utime('any.path', 1234, 5678, errnote='test note 2')


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:19.711438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime(encodeFilename(path), (atime, mtime))
    except Exception:
        post_processor_0._downloader.report_warning(errnote)



# Generated at 2022-06-26 13:34:20.528549
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:34:31.352693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create object PostProcessor
    pp = PostProcessor()

    # Create files audio_file and video_file
    open('audio_file','a').close()
    open('video_file','a').close()

    # Test try_utime method
    pp.try_utime('audio_file', 0, 0)
    pp.try_utime('video_file', 0, 0)

    # Remove files audio_file and video_file
    os.remove('audio_file')
    os.remove('video_file')

# Generated at 2022-06-26 13:34:42.069683
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    fake_downloader_1 = object()
    post_processor_1 = PostProcessor(fake_downloader_1)
    fake_path_1 = u'fake_path_1'
    fake_atime_1 = int()
    fake_mtime_1 = int()
    fake_errnote_1 = u'fake_errnote_1'
    post_processor_1.try_utime(fake_path_1, fake_atime_1, fake_mtime_1, fake_errnote_1)

# Generated at 2022-06-26 13:34:49.078235
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(filename='try_utime.txt', atime=1000, mtime=1000, errnote='Cannot update utime of file')


if __name__ == '__main__':
    from pytest import main
    main()

# Generated at 2022-06-26 13:34:51.898396
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:56.823874
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)


# Generated at 2022-06-26 13:35:07.950197
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # prepare the test
    post_processor_1 = PostProcessor()

# Generated at 2022-06-26 13:35:11.439111
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('data/2012-02-10-11-35-56.mkv', 0, 0)


# Generated at 2022-06-26 13:35:15.031919
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    instance = PostProcessor()
    path = '.'
    atime = 0.0
    mtime = 0.0
    errnote = 'Cannot update utime of file'
    instance.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:35:19.470812
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'path'
    atime = 10
    mtime = 20
    post_processor_0.try_utime(path, atime, mtime)
    pass

# Generated at 2022-06-26 13:35:29.432220
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    post_processor_3 = PostProcessor()
    post_processor_4 = PostProcessor()
    post_processor_5 = PostProcessor()
    post_processor_6 = PostProcessor()
    post_processor_7 = PostProcessor()
    post_processor_8 = PostProcessor()
    post_processor_9 = PostProcessor()
    post_processor_10 = PostProcessor()
    post_processor_11 = PostProcessor()
    post_processor_12 = PostProcessor()
    post_processor_13 = PostProcessor()
    post_processor_14 = PostProcessor()
    post_processor_15 = PostProcessor()

# Generated at 2022-06-26 13:35:33.189962
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    post_processor_0.try_utime('', 1, 1)



# Generated at 2022-06-26 13:35:48.574558
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # unit tests for try_utime in class PostProcessor
    # Initialise instance of class PostProcessor for testing.
    post_processor_1 = PostProcessor()
    # Creating an instance of type Path for testing.
    path_1 = Path(post_processor_1)
    # Creating an instance of type int for testing.
    int_1 = int(0)
    # Creating an instance of type int for testing.
    int_2 = int(0)
    # Creating an instance of type str for testing.
    str_1 = str('test_str')

# Generated at 2022-06-26 13:35:53.092822
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_1 = str()
    try:
        post_processor_0.try_utime(path_1, 0, 0)
    except Exception:
        pass

if __name__ == '__main__':
    
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:59.855660
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'foo'
    path_1 = 'bar'
    try:
        post_processor_0.try_utime(None, None, None)
    except Exception as exception_0:
        assert type(exception_0) == PostProcessingError
    try:
        post_processor_0.try_utime(None, None, None, 'foo')
    except Exception as exception_1:
        assert type(exception_1) == PostProcessingError
    try:
        post_processor_0.try_utime(path_0, None, None)
    except Exception as exception_2:
        assert type(exception_2) == PostProcessingError

# Generated at 2022-06-26 13:36:07.548155
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    file_path_1 = './tests/ffmpeg/test.mp4'
    atime_1 = None
    mtime_1 = None
    errnote_2 = 'Cannot update utime of file'
    # Test with all arguments equal to none
    try:
        post_processor_0.try_utime(file_path_1, atime_1, mtime_1, errnote_2)
    except Exception as exc:
        if exc.message != "global name 'encodeFilename' is not defined":
            print(exc.message)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:12.582331
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    aa = PostProcessor()

# Generated at 2022-06-26 13:36:16.611215
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    # TODO downloader is not None
    # TODO os.utime not called
    # TODO os.utime raises OSError
    # TODO os.utime raises other than OSError
    pass

# Generated at 2022-06-26 13:36:27.926901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    mock_PostProcessor = compat_mock.create_autospec(PostProcessor, instance=True)
    
    mock_PostProcessor.try_utime("test_path", "test_atime", "test_mtime")
    mock_PostProcessor.try_utime.assert_called_once_with("test_path", "test_atime", "test_mtime")
    
    mock_PostProcessor.try_utime("test_path", "test_atime", "test_mtime", "errnote")
    mock_PostProcessor.try_utime.assert_called_once_with("test_path", "test_atime", "test_mtime", "errnote")

# Generated at 2022-06-26 13:36:35.597736
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime(
            "C:/Users/skygl/SkyDrive/Music/iTunes/iTunes Media/Music/Coldplay/X&Y/03 Fix You.m4a",
            os.atime, os.mtime, "Cannot update utime of file")
    except Exception as exception_0:
        pass



# Generated at 2022-06-26 13:36:46.944836
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'some/path'
    atime = 0.0
    mtime = 0.0
    errnote = 'error note'

    # Arrange
    os.utime = lambda x, y: None
    pp = PostProcessor()
    pp._downloader = None

    # Act
    pp.try_utime(path, atime, mtime, errnote)

    # Assert
    os.utime.assert_called_with(encodeFilename(path), (atime, mtime))



# Generated at 2022-06-26 13:36:55.173706
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    import os.path
    post_processor_0.try_utime('./utime_test', os.path.getatime("./utime_test"), os.path.getmtime("./utime_test"))

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:06.845368
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(
        "abpnews_haven_tY0bkCjbb0.mp4",
        None,
        None,
    )


# Generated at 2022-06-26 13:37:10.889584
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'path'
    atime = 1417777200.0
    mtime = 1417777200.0
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:37:16.920304
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename('abc/def/ghi//abcdefg.mp4'), 1337986932, 1337986932, 'Cannot update utime of file')

# Generated at 2022-06-26 13:37:19.546741
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()

    ret0 = post_processor_1.try_utime(None, None, None, None)

# Tests for class PostProcessor

# Generated at 2022-06-26 13:37:27.642573
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = "c:/temp/videos/video.webm"
    atime_0 = 32
    mtime_0 = 16
    errnote_0 = "Cannot update utime of file"
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:37:32.680847
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_downloader_0 = PostProcessor()
    os.utime = lambda x,y: None
    try:
        test_downloader_0.try_utime('', 0, 0)
    except Exception as exc:
        print('Caught exception: ' + str(exc))


# Generated at 2022-06-26 13:37:35.439929
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)


# Generated at 2022-06-26 13:37:38.989365
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    assert post_processor.try_utime("D:\\Installation\\YoutubeDL\\TestFiles\\output\\file_name", 1522241896.661857, 1522241896.661857, 
                                    "Cannot update utime of file") is None

# Generated at 2022-06-26 13:37:49.026073
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'a'
    atime = 1.0
    mtime = 1.0
    path_1 = encodeFilename(path)
    assert os.utime(path_1, (atime,mtime)) == None
    path = 'a'
    atime = 1.0
    mtime = 1.0
    path_1 = encodeFilename(path)
    assert post_processor_0.try_utime(path_1,atime,mtime) == None
# Test class PostProcessor method run

# Generated at 2022-06-26 13:38:00.468840
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import encodeFilename
    import os
    
    f = open("PostProcessor_try_utime.test","w")
    path = "PostProcessor_try_utime.test"
    atime = 1
    mtime = 1
    errnote = "Error"
    
    post_processor = PostProcessor()
    
    post_processor.try_utime(path,atime,mtime,errnote)

    assert os.path.getatime(encodeFilename(path)) == atime
    assert os.path.getmtime(encodeFilename(path)) == mtime
    
    os.remove("PostProcessor_try_utime.test")

# Generated at 2022-06-26 13:38:12.412442
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from tempfile import TemporaryFile
    from io import open
    from io import FileIO
    from ..compat import compat_os_path
    from ..compat import compat_urllib_request
    from ..utils import encodeFilename
    from fake_filesystem_unittest import TestCase
    from ..utils import encodeFilename, decodeFilename
    import os

    class MyIE(InfoExtractor):
        IE_NAME = 'example'


# Generated at 2022-06-26 13:38:25.330681
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:38:35.537924
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_5 = PostProcessor({'a': int, 'b': int})
    assert post_processor_5._configuration_args({}) == ({'a': int, 'b': int},[])
    assert post_processor_5._configuration_args(['a']) == ({'a': int, 'b': int},['a'])
    assert post_processor_5._configuration_args([int]) == ({'a': int, 'b': int},[int])
    post_processor_6 = PostProcessor({'a': int, 'b': int})
    assert post_processor_6._configuration_args({}) == ({'a': int, 'b': int},[])

# Generated at 2022-06-26 13:38:45.390614
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    # create test file
    path = 'test_file'
    with open(path, 'wb') as file:
        pass
    mtime = os.path.getmtime(path)
    atime = os.path.getatime(path)
    # change time by one day
    postProcessor.try_utime(path, atime+60*60*24, mtime+60*60*24)
    # compare new time
    assert(os.path.getmtime(path) == mtime+60*60*24)
    assert(os.path.getatime(path) == atime+60*60*24)
    # remove test file
    os.remove(path)

if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-26 13:38:51.219973
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = 'path'
    atime = 0
    mtime = 0
    post_processor_1.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:39:04.655678
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    utime_arg_spec = {
        'path': ['expect', 'file'],
        'atime': ['expect', 'time'],
        'mtime': ['expect', 'time'],
        'errnote': ['expect', 'str'],
    }
    def utime_mock(*args, **kwargs):
        arg_spec = {}
        for arg in utime_arg_spec:
            if arg not in kwargs:
                kwargs[arg] = utime_arg_spec[arg][0]
            arg_spec[arg] = (utime_arg_spec[arg][1], kwargs[arg])


# Generated at 2022-06-26 13:39:13.920428
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 1290, 1312)
    # Unit test for method run of class PostProcessor
# def test_PostProcessor_run():
#     post_processor_0 = PostProcessor()
#     post_processor_0.set_downloader('')
#     # Class PostProcessor has no run method, so there is no unit test.


# Generated at 2022-06-26 13:39:18.858593
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 1.0, 1.0, 'Cannot update utime of file')



# Generated at 2022-06-26 13:39:24.624252
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Call method try_utime of PostProcessor.
    # Should run without raising an exception
    post_processor_1.try_utime(post_processor_1, post_processor_1, post_processor_1, post_processor_1)


# Generated at 2022-06-26 13:39:31.219637
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(None, None, None)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:57.503931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test success case
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename(os.path.abspath('.')), 0, 0, 'errnote')

    # Test the exception case

# Generated at 2022-06-26 13:40:03.874121
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(None, None, None)


if __name__ == '__main__':
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-26 13:40:08.232516
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_10 = PostProcessor()
    post_processor_10.try_utime('Downloaded-File.mp3', 892, 892)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:12.146818
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test.mp4", 0, 0, errnote='test')

# Generated at 2022-06-26 13:40:15.931587
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor_obj_0 = PostProcessor()
    postProcessor_obj_0.try_utime("", 0.0, 0.0, "Cannot update utime of file")

# Generated at 2022-06-26 13:40:19.287053
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    _downloader = None
    _file = "tmp_file"
    _atime = 1454539471.067366
    _mtime = 1454539471.067366
    pp_0 = PostProcessor(_downloader)
    pp_0.try_utime(_file, _atime, _mtime)

# Generated at 2022-06-26 13:40:25.444041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'path'
    atime = 1
    mtime = 2
    errnote = 'Cannot update utime of file'
    post_processor_1 = PostProcessor()
    output = post_processor_1.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:40:30.634085
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Initialize new instance of object from class PostProcessor
    post_processor_0 = PostProcessor()
    
    # Apply method 'try_utime' to instance from class PostProcessor
    #
    # parameter 'path' =
    #
    # parameter 'atime' =
    #
    # parameter 'mtime' =
    #
    # parameter 'errnote' =
    #
    # return value method 'try_utime' =
    post_processor_0.try_utime(None, None, None, None)

# Generated at 2022-06-26 13:40:39.915583
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # First we will create and instance of class PostProcessor
    post_processor_0 = PostProcessor()
    # Now we create the values that will be passed to the method
    #try_utime.
    # These are set in such a way that only the second one of them,
    # mtime, will be passed to the method as a named argument
    path = None
    atime = None
    mtime = 'wj'
    errnote = None
    # Now we call the method passing the three arguments.
    post_processor_0.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:40:49.882055
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    post_processor = PostProcessor()

    class test_object_1:
        path = '/home/user/file'
        atime = 1565991536.5945625
        mtime = 1565991536.5945625
        def report_warning(self, msg):
            assert msg == 'Cannot update utime of file'

    post_processor._downloader = test_object_1()
    post_processor.try_utime(post_processor._downloader.path, post_processor._downloader.atime, post_processor._downloader.mtime)


# Generated at 2022-06-26 13:41:30.217203
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    file_path = 'file_path'
    atime = 1423835719
    mtime = 1423835739
    errnote = 'errnote'
    post_processor_1.try_utime(file_path, atime, mtime, errnote)


if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-26 13:41:38.139991
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/', 0, 0)
    post_processor_0.try_utime('/', 0, 0, '')


if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-26 13:41:41.972436
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    print(postProcessor.try_utime('../video_file/foo.mp4',
                                  1575940140.14, 1575940140.14,
                                  'Cannot update utime of file.'))


# Generated at 2022-06-26 13:41:49.866528
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class PostProcessor_test0(PostProcessor):
        def run(self, information):
            self.try_utime("abc",1,2, 'test')
            pass
    post_processor_0 = PostProcessor_test0()
    post_processor_test0 = PostProcessor_test0(None)
    PostProcessor_test0.run(post_processor_test0)


# Generated at 2022-06-26 13:41:52.606365
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Call test_case_0
    test_case_0()
    # Call try_utime
    post_processor_0.try_utime('test_file',1,1,'test_message')


# Generated at 2022-06-26 13:42:04.267682
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    post_processor_1 = PostProcessor(YoutubeDL())
    test_file_name_0 = 'v1'
    test_file_name_1 = 'v2'
    file_descriptor_0 = os.open(test_file_name_0, os.O_RDWR | os.O_CREAT)
    os.close(file_descriptor_0)
    file_descriptor_1 = os.open(test_file_name_1, os.O_RDWR | os.O_CREAT)
    os.close(file_descriptor_1)
    os.unlink(test_file_name_0)
    os.unlink(test_file_name_1)

# Test for method _configuration_args of class PostProcessor

# Generated at 2022-06-26 13:42:07.279877
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # TODO: implement test case
    raise NotImplementedError("to do")


# Generated at 2022-06-26 13:42:12.575003
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    test_case = 'test case'
    post_processor.try_utime(test_case, 'fake_atime', 'fake_mtime')
    post_processor.try_utime(test_case, 'fake_atime', 'fake_mtime', errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:42:25.246258
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    logger = logging.getLogger('youtube_dl.PostProcessor')
    post_processor = PostProcessor()
    post_processor._downloader = DummyYDL()
    post_processor._downloader._logger = logger

    path = 'tmp/file.txt'
    atime = 10
    mtime = 20
    errnote = 'Cannot update utime of file'

    import os
    file = open(path, 'w')
    file.write('test')
    file.close()

    import os.path
    assert os.path.exists('tmp/file.txt')

    post_processor.try_utime(path, atime, mtime, errnote)

    import os.path
    assert os.path.exists('tmp/file.txt')

    import os

# Generated at 2022-06-26 13:42:34.215506
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    args = {
        'downloader': None,
    }
    post_processor_0 = PostProcessor(**args)
    args = {
        'path': '',
        'atime': 'atime',
        'mtime': 'mtime',
    }
    post_processor_0.try_utime(**args)
    args = {
        'path': '',
        'atime': 'atime',
        'mtime': 'mtime',
        'errnote': 'Cannot update utime of file',
    }
    post_processor_0.try_utime(**args)
