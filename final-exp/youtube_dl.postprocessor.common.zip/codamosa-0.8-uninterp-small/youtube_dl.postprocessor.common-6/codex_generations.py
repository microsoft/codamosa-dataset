

# Generated at 2022-06-26 13:33:41.577552
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    filename_0 = 'test.txt'
    with open(filename_0, 'w') as file_handle_0:
        file_handle_0.write('I\'m a test\n')
    post_processor_1.try_utime(filename_0, 0, 0)
    if os.path.isfile(filename_0):
        os.unlink(filename_0)

# Test case for configuration argumens of method _configuration_args of class PostProcessor

# Generated at 2022-06-26 13:33:49.156693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = 'home/big_buck_bunny_480p_stereo.ogg'
    atime = 13
    mtime = 13
    errnote = 'Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:33:58.551605
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Exception raised when file cannot be found
    try:
        post_processor_0.try_utime('missing_file', 1, 1)
    except OSError as e:
        return True
    return False

if __name__ == '__main__':
    test_case_0()
    if not test_PostProcessor_try_utime():
        raise RuntimeError('Test for class PostProcessor is broken')

# Generated at 2022-06-26 13:34:01.073201
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    print("\n\ntest_PostProcessor_try_utime()")
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("abc.abc", 0, 0)

# Generated at 2022-06-26 13:34:04.826850
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('path', 'atime', 'mtime', 'errnote')

# Generated at 2022-06-26 13:34:10.544254
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='path(string)',atime=int,mtime=int,errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:34:17.904982
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('This is a test', -3.0, -3.0, 'Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:21.028694
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Input arguments testing
    # No input arguments
    post_processor_1.try_utime(None, None, None, None)



# Generated at 2022-06-26 13:34:24.729789
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('sample.txt', 0, 0)


# Generated at 2022-06-26 13:34:32.288353
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()

    from datetime import datetime
    from datetime import date
    from datetime import time
    from datetime import timedelta

    post_processor.try_utime("video.mp4", "0", datetime(1970, 1, 1) - timedelta(microseconds=1),"")


if __name__ == "__main__":
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:39.944698
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    postProcessor.try_utime("PostProcessor.py", 1514180163, 1514186562)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:43.671927
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = u'abc'
    atime = 1
    mtime = 1
    errnote = u'Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:34:53.308905
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import pytest

    tmpdir = tempfile.mkdtemp()
    post_processor_0 = PostProcessor()
    with pytest.raises(SystemExit):
        post_processor_0.try_utime(tmpdir, 0, 1)
    shutil.rmtree(tmpdir)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:06.012949
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = os.path.abspath('test_data/test_file.txt')
    atime = 0
    mtime = 0
    post_processor_0.try_utime(path_0, atime, mtime)
    post_processor_0.try_utime(path_0, atime, mtime)
    post_processor_0.try_utime(path_0, atime, mtime)
    post_processor_0.try_utime(path_0, atime, mtime)
    post_processor_0.try_utime(path_0, atime, mtime)
    post_processor_0.try_utime(path_0, atime, mtime)

# Generated at 2022-06-26 13:35:11.298868
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, None, None, None)

if __name__ == '__main__':

    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:18.332318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .tmpname import tmpname

    post_processor_0 = PostProcessor()
    assert isinstance(post_processor_0, PostProcessor)
    tmp_path = tmpname()
    with open(tmp_path, 'a'):
        os.utime(tmp_path, (0, 0))
    post_processor_0.try_utime(tmp_path, 0, 0)
    os.remove(tmp_path)
    post_processor_0.try_utime(tmp_path, 0, 0)
    assert post_processor_0._downloader.params['verbose'] is True
    post_processor_0._downloader.params['verbose'] = False
    post_processor_0.try_utime(tmp_path, 0, 0)


# Generated at 2022-06-26 13:35:29.045803
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test without path
    post_processor_0 = PostProcessor()
    path_0 = None
    atime_0 = 1.1
    mtime_0 = 1.1
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)

    # Test with path
    post_processor_1 = PostProcessor()
    path_1 = 'test1'
    atime_1 = 1.1
    mtime_1 = 1.1
    errnote_1 = 'Cannot update utime of file'
    post_processor_1.try_utime(path_1, atime_1, mtime_1, errnote_1)

    # Test error handling
    post_processor

# Generated at 2022-06-26 13:35:34.156592
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime(encodeFilename('123'), (1, 2))
    except Exception as e:
        assert(str(e) != '123')
    else:
        assert(1 == 2)

# Generated at 2022-06-26 13:35:39.609738
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        os.remove("../_temp/temp_file.txt")
    except OSError:
        pass
    with open("../_temp/temp_file.txt",'w') as temp_file:
        temp_file.write("Hello there!")
    pp.try_utime("../_temp/temp_file.txt", 111, 222)
    temp_file.close()
    os.remove("../_temp/temp_file.txt")


if __name__ == "__main__":
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:41.861964
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = ''
    atime = 0
    mtime = 0
    errnote = ''
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:35:46.798767
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime(None, 0, 0, None) == None


# Generated at 2022-06-26 13:35:51.365189
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = encodeFilename('abc')
    atime = 0
    mtime = 0
    errnote = 'Cannot update utime of file'
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime(path, atime, mtime, errnote) is None



# Generated at 2022-06-26 13:35:55.536297
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try_utime_0 = PostProcessor()
    path_0 = 'http://127.0.0.1:8233/'
    os.utime(encodeFilename(path_0), (atime, mtime))
    pass # testcase_PostProcessor_try_utime_0 case is not implemented yet
    assert path_0


# Generated at 2022-06-26 13:36:02.200663
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:36:04.965302
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(os.temppath, None, None)
    return True


# Generated at 2022-06-26 13:36:16.110349
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    try:
        post_processor_1.try_utime('1', 1, 1)
    except Exception:
        exception_message_1 = 'Expected error not thrown'
        raise Exception(exception_message_1)
    else:
        print('[%s:%d] Test for method try_utime of class PostProcessor passed')
# Test for method try_utime of class PostProcessor ended

if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:19.604707
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test normal case
    post_processor_0 = PostProcessor()

    # Test exceptions
    post_processor_1 = PostProcessor()

# Generated at 2022-06-26 13:36:22.313198
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Set to 0 for now because test_PostProcessor_try_utime() is not yet written
    assert 0 == 0

# Generated at 2022-06-26 13:36:26.313252
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    try:
        postProcessor.try_utime("<path>", 1, 2, "errnote")
    except:
        raise


# unit test for method run of class PostProcessor

# Generated at 2022-06-26 13:36:36.374799
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp2 = PostProcessor()
    pp2._downloader = True
    pp._configuration_args = test_PostProcessor_try_utime__downloader_configuration_args
    pp._downloader = pp2
    try:
        os.utime = test_PostProcessor_try_utime__utime
        pp.try_utime(0, 0, 0)
        program_test_result = 'PASS'
    except Exception:
        program_test_result = 'FAIL'

    assert program_test_result == 'PASS', '- The program is crashed'


# Method stub: utime

# Generated at 2022-06-26 13:36:47.218226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('path', 'atime', 'mtime', errnote='Cannot update utime of file')


if __name__ == '__main__':
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    import unittest
    unittest.main()

# Generated at 2022-06-26 13:36:58.827402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    args = (os.path.dirname(__file__), 0, 0, 'Cannot update utime of file')
    # test for valid input
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(*args)
    # test for invalid input(file not present)
    post_processor_1 = PostProcessor()
    try:
        post_processor_1.try_utime(os.path.join(os.path.dirname(__file__), 'kickthebucket'), 0, 0, 'Cannot update utime of file')
    except Exception:
        pass

# Generated at 2022-06-26 13:37:07.587415
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try_utime_0 = PostProcessor()
    try_utime_0.try_utime(
        'files.files',
        'files.files',
        'files.files') # test should pass here
    try_utime_0.try_utime(
        'files.files',
        'files.files',
        'files.files',
        ) # test should pass here


# Generated at 2022-06-26 13:37:11.246711
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Call the method of class PostProcessor
    post_processor = PostProcessor()
    path = 'path'
    atime = 0
    mtime = 0
    errnote = 'Cannot update utime of file'
    post_processor.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:37:19.014286
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = test_case_0()
    post_processor_0 = PostProcessor(downloader)
    post_processor_0.try_utime(encodeFilename('./src/youtube_dl/postprocessor/__init__.py'), None, None, 'Cannot update utime of file')

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:22.650438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        pp.try_utime(5, 6, 7)
    except Exception:
        pass

# Generated at 2022-06-26 13:37:24.562978
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    return


# Generated at 2022-06-26 13:37:27.627501
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('', '', '', 'Cannot update utime of file')
    except BaseException as exception_0:
        return

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:29.161118
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime()


# Generated at 2022-06-26 13:37:32.282862
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('abc', 'def', 'ghi')


# Generated at 2022-06-26 13:37:45.661955
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    path = ''
    atime = 0.0
    mtime = 0.0
    errnote = 'Cannot update utime of file'
    post_processor.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:37:47.669063
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('./file_0', 0.0, 0.0, 'Cannot update utime of file')


# Generated at 2022-06-26 13:37:59.504679
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Check the case that path is character string
    path = 'abc'
    atime = 'abc'
    mtime = 'abc'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, atime, mtime)
    # Check the case that path contains double quotes
    path = '"abc"'
    atime = '"abc"'
    mtime = '"abc"'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, atime, mtime)



# Generated at 2022-06-26 13:38:12.243280
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import platform
    import time
    import subprocess
    from io import open

    from pytube import YouTube
    from pytube import request
    from pytube import __version__
    from pytube import ext

    # get file path
    post_processor_0 = PostProcessor()

    if platform.system().lower() == 'linux':
        path_0 = 'test_utime.txt'
        path_1 = '/tmp/test_utime.txt'
    elif platform.system().lower() == 'windows':
        path_0 = 'test_utime.txt'
        path_1 = 'C:\\temp\\test_utime.txt'
    else:
        path_0 = 'test_utime.txt'
        path_1 = './test_utime.txt'

    # create test file

# Generated at 2022-06-26 13:38:16.429556
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', None, None)


# Generated at 2022-06-26 13:38:19.285287
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    postProcessor.try_utime(None, None, None)

# Generated at 2022-06-26 13:38:21.830617
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('origin', 'atime', 'mtime')


# Generated at 2022-06-26 13:38:34.116407
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Testing with a file
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(__file__, 0, 0)
    # Testing with a directory
    dir_path = 'file_path'
    file_path = encodeFilename(os.path.join(dir_path, 'file_path'))
    try:
        os.mkdir(dir_path)
    except:
        pass
    try:
        open(file_path,'a')
    except:
        pass
    post_processor_1.try_utime(dir_path, 0, 0)
    try:
        os.remove(file_path)
    except:
        pass
    try:
        os.rmdir(dir_path)
    except:
        pass


# Generated at 2022-06-26 13:38:42.664513
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from video_dl.extractor import YoutubeDL

    class pp0(PostProcessor):
        def __init__(self, params={}):
            self._downloader = YoutubeDL({ 'simulate' : True })
            self._downloader.params = params

    tmp_result = pp0().try_utime('path', 'atime', 'mtime')
    assert tmp_result == None, "post_processor_0.try_utime('path', 'atime', 'mtime')"


# Generated at 2022-06-26 13:38:51.415794
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from ..utils import encodeFilename
    dl = PostProcessor()
    try:
        os.utime("", (0,0))
    except Exception:
        pass
    dl.try_utime("", 0, 0)
    dl.try_utime(encodeFilename(""), 0, 0)
    dl.try_utime("", 0, 0, 'error')

# Generated at 2022-06-26 13:39:13.138615
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'path'
    atime = 'atime'
    mtime = 'mtime'
    errnote = 'Cannot update utime of file'
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime(path, atime, mtime, errnote)
    except Exception:
        assert False



# Generated at 2022-06-26 13:39:20.292888
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import time

    mtime = time.time()
    time.sleep(1)
    path = os.path.join(sys.path[0], 'test.txt')
    try:
        f = open(path, 'w')
    except Exception:
        print('Unable to save test file')
        f = None
    if f:
        f.close()
        try:
            os.utime(path, (0, 0))
        except Exception:
            print('Unable to update utime of test file')
    else:
        path = None
    post_processor = PostProcessor()
    post_processor.try_utime(path, 0, mtime, 'Cannot basic update utime of file')
    if path:
        os.remove(path)



# Generated at 2022-06-26 13:39:24.777689
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(u'test.mp3', 1445671897.0, 1445671897.0, u'Cannot update utime of file')


# Generated at 2022-06-26 13:39:32.168432
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(
        path = "0W8SWIzZGk",
        atime = 6,
        mtime = "OS9XVE",
        errnote = "F70nzc"
    )

# Generated at 2022-06-26 13:39:36.616733
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path="abc", atime=2.5, mtime=3.5)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:42.108490
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()  # noqa: F841
    # TODO: generate and test input
    # postProcessor.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:39:45.097752
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post = PostProcessor()
    post.try_utime(__file__, 1, 1)



# Generated at 2022-06-26 13:39:51.993982
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file_path = 'test_file.mp4'
    file_access_time = 'file_access_time.txt'
    file_modify_time = 'file_modify_time.txt'
    post_processor_obj = PostProcessor()

# Generated at 2022-06-26 13:39:55.659143
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test exception
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime("file",1,1)


# Generated at 2022-06-26 13:40:06.654257
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    path = os.path.join('..', '..', 'data', 'post processor', 'test_video.mp4')
    atime = 1428003082
    mtime = 1427003082

    # test file exists
    post_processor.try_utime(path, atime, mtime)

    # test file not exists
    post_processor.try_utime('test_video.avi', atime, mtime)

# Generated at 2022-06-26 13:40:41.402878
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    # Test for the following cases:
    try:
        os.utime(encodeFilename('/Users/mac/Desktop/Youtube_downloader/NCT/NCT DREAM - BOOM/NCT DREAM - BOOM.mp4'), (1,1))
    except Exception:
        post_processor_1._downloader.report_warning('Cannot update utime of file')
    try:
        os.utime(encodeFilename('/Users/mac/Desktop/Youtube_downloader/NCT/NCT DREAM - Go/NCT DREAM - Go.mp4'), (1,1)) 
    except Exception:
        post_processor_0._downloader.report_warning('Cannot update utime of file')



# Generated at 2022-06-26 13:40:42.307730
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:40:46.692668
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path=0, atime=0, mtime=0, errnote='noerrnote')


# Generated at 2022-06-26 13:40:50.553380
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    encodeFilename_0 = encodeFilename('/tmp/1')
    try:
        os.utime(encodeFilename('/tmp/1'), (0, 0))
    except Exception:
        post_processor_0._downloader.report_warning('Cannot update utime of file')


# Generated at 2022-06-26 13:41:01.342472
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime('this_file_should_not_exists', (0,0))
    except Exception:
        pass
    return [os.stat_result(st_mode=33204, st_ino=156765, st_dev=2051, st_nlink=1, st_uid=1000, st_gid=1000, st_size=0, st_atime=1526534802, st_mtime=1526534802, st_ctime=1526534802)] == post_processor_0.try_utime('this_file_should_not_exists', 0, 0)

# Generated at 2022-06-26 13:41:12.530774
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    # Call method try_utime of class PostProcessor with proper arguments.
    # Get from method downloader a property downloader.params with value proper arguments.
    # Try to call encoding file name to utime. Try to call atime and mtime.
    # If the exception occur, report a warning of "Cannot update utime of file".
    # Call method utime with proper arguments.

    ####################################################################################################################
    #                                                                                                                  #
    #   def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):                                 #
    #       try:                                                                                                       #
    #           os.utime(encodeFilename(path), (atime, mtime))                                                         #
    #      

# Generated at 2022-06-26 13:41:23.195613
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from . import PostProcessor
    from .common import _TEST_FILE_NAME
    import os
    import time
    import errno
    try:
        os.makedirs(encodeFilename(_TEST_FILE_NAME))
    except OSError as ose:
        if ose.errno != errno.EEXIST:
            raise
    test_file_0 = os.path.join(encodeFilename(_TEST_FILE_NAME), 'test_file_0')
    with open(test_file_0, 'wb') as f:
        f.write('test')
    test_file_0_atime = time.time()
    time.sleep(1)
    test_file_0_mtime = time.time()
    ydl = YoutubeDL()

# Generated at 2022-06-26 13:41:27.712676
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_obj = PostProcessor()

# Generated at 2022-06-26 13:41:34.158606
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('1', 1, 1)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:40.522581
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = "..."
    atime = 0.0
    mtime = 0.0
    errnote = "Cannot update utime of file"
    post_processor_0.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:42:42.627723
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    test_path_0 = 'test.txt'
    test_atime_0 = 10
    test_mtime_0 = True
    test_errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(test_path_0, test_atime_0, test_mtime_0, test_errnote_0)


# Generated at 2022-06-26 13:42:43.598514
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("",0,0)


# Generated at 2022-06-26 13:42:47.215415
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('test_file', -1, -1) is None


# Generated at 2022-06-26 13:42:53.991208
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = ''
    atime_0 = None
    mtime_0 = None
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:43:06.071687
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    old_atime, old_mtime = os.stat('some_file').st_atime, os.stat('some_file').st_mtime
    
    post_processor_1 = PostProcessor()
    
    # Check that all is OK when test_atime, test_mtime has a float value
    try:
        post_processor_1.try_utime('some_file', 1.0, 1.0)
        assert os.path.getmtime('some_file') == 1.0
    finally:
        os.utime('some_file', (old_atime, old_mtime))
        
    # Check that all is OK when test_atime, test_mtime has an int value

# Generated at 2022-06-26 13:43:08.448683
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_PostProcessor_try_utime_0()


# Generated at 2022-06-26 13:43:13.994017
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename('/home/jiamy/parm/'), 1562728939.6730807, 1562728939.6730807)


# Generated at 2022-06-26 13:43:15.494792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(arg0=3, arg1=1238, arg2='arg2')
    return 0


# Generated at 2022-06-26 13:43:27.335274
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from ..utils import encodeFilename

    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(None)
    path_0, atime_0, mtime_0, errnote_0 = 'path', 1, 1, 'Cannot update utime of file'

    # Test when path is encoded.
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)

    # Test when path is not encoded
    post_processor_0.try_utime(encodeFilename(path_0), atime_0, mtime_0, errnote_0)

# Generated at 2022-06-26 13:43:30.208176
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime('video', 0, 0) == None
