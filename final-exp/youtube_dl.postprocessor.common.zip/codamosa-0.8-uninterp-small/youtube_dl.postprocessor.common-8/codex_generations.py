

# Generated at 2022-06-26 13:33:39.607917
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='path_0', atime=1, mtime=2, errnote='errnote_0')


# Generated at 2022-06-26 13:33:47.981004
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a instance for class PostProcessor
    post_processor_1 = PostProcessor()

    # Try to manually set mtime and atime of file path.
    post_processor_1.try_utime("foo.bar", 0, 0)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:33:51.710073
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test method with a file that doesn't exist
    nonexistent_file_0 = 'nonexistent_file_0'
    errnote_0 = 'errnote_0'
    try:
        post_processor_0.try_utime(nonexistent_file_0, 1, 1, errnote_0)
        raise ValueError()
    except Exception:
        pass

# Generated at 2022-06-26 13:33:56.613532
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime("/dev/null", 0, 0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:00.539382
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postproc = PostProcessor()
    postproc.try_utime('C:/Documents and Settings/Administrador/Escritorio/Youtube-dl-GUI/tests/video.mp4', 1535019030, 1535019030, 'Error al actualizar utime')

# Generated at 2022-06-26 13:34:05.440226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime()
    except Exception:
        pass
    assert post_processor_0.try_utime() == None


# Generated at 2022-06-26 13:34:08.077876
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_instance = PostProcessor()

    try:
        path = 'test_input_filename'
        atime = 1447828336.0
        mtime = 1447828336.0
        errnote = 'Cannot update utime of file'

        post_processor_instance.try_utime(path, atime, mtime, errnote)
    except Exception:
        print('Exception raised')
        return False

    return True


# Generated at 2022-06-26 13:34:18.417435
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..extractor import common
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    import tempfile
    import datetime
    import time
    downloader = FileDownloader({'format': 'bestaudio/best'})

# Generated at 2022-06-26 13:34:23.414693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = os.getcwd() + '/tests/test.txt'
    atime = 1462084459
    mtime = 1462084463
    errnote = 'Cannot update utime of file'
    assert post_processor_1.try_utime(path, atime, mtime, errnote) == None

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:29.421877
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime = lambda *a, **kw: {}
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime(path='path', atime='atime', mtime='mtime', errnote='errnote') == None

# Generated at 2022-06-26 13:34:34.426125
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # call the method try_utime
    # it will return the number of bytes written
    try_utime_value = PostProcessor().try_utime('path', 'atime', 'mtime', 'errnote')
    assert try_utime_value == None

# Generated at 2022-06-26 13:34:40.014610
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor_instance0 = PostProcessor()
    PostProcessor_instance0.try_utime('Test', 'Test', 'Test')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:48.092896
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test when atime and mtime are numbers
    atime = 1565241604
    mtime = 1565241604
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test_case_0.mp4", atime, mtime)
    atime = 1565241604.0
    mtime = 1565241604.0
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test_case_0.mp4", atime, mtime)
    atime = 1565241604.5
    mtime = 1565241604.5
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test_case_0.mp4", atime, mtime)

# Generated at 2022-06-26 13:34:54.676990
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0._downloader = {'params': {}}
    # Test e.g. write permission
    try:
        post_processor_0.try_utime('/tmp/testfile', 1409679728, 1409679728)
    except Exception:
        pass
    # os._exit(0)

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:59.897829
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='filepath', atime=0, mtime=0, errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:35:04.206115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'test.file'
    atime_0 = 0
    mtime_0 = 0
    post_processor_0.try_utime(path_0, atime_0, mtime_0)


# Generated at 2022-06-26 13:35:14.397797
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    from .test_downloader import TestDownloader, TestError

    class FakeDownloader(TestDownloader):
        def report_warning(self, warning):
            TestDownloader.report_warning(self, warning)
            self.warning = warning

    class FakePostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self._downloader = FakeDownloader()

    orig_time = os.path.getmtime(__file__)
    post_processor_0 = FakePostProcessor()
    orig_utime = os.utime(__file__, (orig_time, orig_time))

# Generated at 2022-06-26 13:35:17.368080
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)


# Generated at 2022-06-26 13:35:20.682552
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("", 0.0, 0.0, "")



# Generated at 2022-06-26 13:35:29.812941
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Unit test for method try_utime of class PostProcessor
    import os
    import time
    pp_obj = PostProcessor()
    # creating a test file
    with open("test_file","w+") as temp_file:
        # writing some data
        temp_file.write("Test data")
        # getting the last modified time
        utime1 = time.gmtime(os.path.getmtime("test_file"))
        # changing the last modified time
        pp_obj.try_utime("test_file", time.time(), time.time())
        # getting the new last modified time
        utime2 = time.gmtime(os.path.getmtime("test_file"))
        # checking if the files have been renamed
        assert utime1 != utime2
    os.remove("test_file")

# Generated at 2022-06-26 13:35:36.260638
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime(1, 2, 3, 4) == 'try_utime(1, 2, 3, 4)'

################################################################################
# vim:et:ft=python:nowrap:sts=4:sw=4:ts=4

# Generated at 2022-06-26 13:35:44.613601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'test_path'
    atime = 0
    mtime = 0

    post_processor_1 = PostProcessor()

    def mock_os_utime(path, atime, mtime):
        pass
    os.utime = mock_os_utime
    post_processor_1.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:35:54.601381
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    from ..utils import (
        encodeFilename,
    )
    from ..extractor import GenYoutubeIE
    from ..downloader import Downloader
    from .common import (
        mp4_video,
    )

    class Downloader_test(Downloader):

        def report_warning(self, msg):
            raise Exception(msg)

    class PostProcessor_test(PostProcessor):

        def __init__(self, downloader=None):
            super(PostProcessor_test, self).__init__()
            self.downloader = downloader

        def run(self, information):
            atime = self.downloader.params.get(
                'atime', self.downloader.params['timestamp'])

# Generated at 2022-06-26 13:35:59.923319
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('test_path', 0, 0, 'test_note')
    except Exception:
        pass

# Generated at 2022-06-26 13:36:03.948186
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import mock
    except ImportError:
        import unittest.mock as mock
    # Case 0
    post_processor_0 = PostProcessor()



# Generated at 2022-06-26 13:36:08.350096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path=str(), atime=None, mtime=None, errnote=str())

# Generated at 2022-06-26 13:36:17.411943
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()
    file_path = "test.txt"
    file = open(file_path,"w")
    file.write("testing file writing")
    file.close()
    p.try_utime(file_path,0,0,'Cannot update utime of file')
    file = open(file_path,"r")
    file_content = file.read()
    file.close()
    assert file_content == "testing file writing"
    # assert os.utime(file_path,(atime,mtime)) == os.utime(file_path,(atime,mtime))

# Generated at 2022-06-26 13:36:28.951163
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    if os.path.exists("./test_PostProcessor_try_utime.txt"):
        os.remove("./test_PostProcessor_try_utime.txt")

    file = open("./test_PostProcessor_try_utime.txt","w")
    file.close()
    post_processor_0.try_utime("./test_PostProcessor_try_utime.txt", 20, 20)

    if os.path.exists("./test_PostProcessor_try_utime.txt"):
        os.remove("./test_PostProcessor_try_utime.txt")

if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:33.048644
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    filename = post_processor_0.try_utime('', 1, 1, '')
    if filename != None:
        raise AssertionError("might raise PostProcessingError")

if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:42.624806
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    expected_path = 'c:\\vid\\abc.mp4'
    expected_atime = 123
    expected_mtime = 234
    path = 'c:\\vid\\abc.mp4'
    atime = 123
    mtime = 234
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)
    assert encodeFilename(expected_path) == encodeFilename(path)
    assert expected_atime == atime
    assert expected_mtime == mtime
    assert errnote == 'Cannot update utime of file'

# Generated at 2022-06-26 13:36:47.225032
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(u'youtube_dl/postprocessor/foo.txt', 1, 2)


# Generated at 2022-06-26 13:37:00.464454
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # (1) each parameter is set properly
    # (2) each parameter is set properly
    post_processor_1 = PostProcessor()

# Generated at 2022-06-26 13:37:04.750267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='', atime=0, mtime=0, errnote='')


# Generated at 2022-06-26 13:37:09.235817
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()

    dummy_path = '/test/'
    dummy_atime = 69
    dummy_mtime = 96
    post_processor.try_utime(dummy_path, dummy_atime, dummy_mtime)


# Generated at 2022-06-26 13:37:21.211261
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    # Unit test for method try_utime()
    import os
    from .common import get_temp_filename
    from .embedthumbnail import (
        TempAudioFile,
        FFmpegEmbedSubtitlePP,
        FFmpegAudioInfoPP,
    )
    def get_utime(filepath):
        return os.stat(filepath).st_atime, os.stat(filepath).st_mtime
    def check_utime(filepath, atime, mtime, errnote, utime_ok=True):
        if utime_ok:
            assert get_utime(filepath) == (atime, mtime)
        else:
            assert get_utime(filepath) != (atime, mtime)
            pp._downloader.report_warning.assert_called_

# Generated at 2022-06-26 13:37:25.317847
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('test_filepath', 'test_atime', 'test_mtime', 'test_errnote')
    return


# Generated at 2022-06-26 13:37:30.384557
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_name = 'test_try_utime'
    post_processor = PostProcessor()
    atime = 1441259765.6
    mtime = 1441259766.5
    path = 'test_path'
    errnote = 'Cannot update utime of file'

# Generated at 2022-06-26 13:37:31.850463
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()


if __name__ == '__main__':
    test_case_0()
    #test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:33.802161
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    path = "path"
    atime = 0
    mtime = 0
    postProcessor.try_utime(path, atime, mtime) # Just to check if no exceptions are thrown

# Generated at 2022-06-26 13:37:39.136134
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor(None)

    # Test for method try_utime
    post_processor_0.try_utime('video.avi', 287778, 287778)
    post_processor_1.try_utime('video.avi', 287778, 287778)


# Test for method _configuration_args() of class PostProcessor

# Generated at 2022-06-26 13:37:49.747884
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('test_file', 10, 20)

test_cases = [
    test_case_0,
    test_PostProcessor_try_utime,
]


# Generated at 2022-06-26 13:37:57.740648
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'test_file'
    atime_0 = 89
    mtime_0 = 23
    os.utime = (lambda f, t: None)
    assert post_processor_0.try_utime(path_0, atime_0, mtime_0, 'Cannot update utime of file') is None

# Generated at 2022-06-26 13:38:01.831372
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'v'
    try:
        post_processor_0.try_utime(path, 'kbps', 1, 'video/x-flv')
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-26 13:38:07.673755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor(None)
    post_processor_0.try_utime("file_path", 1, 2)
    post_processor_0.try_utime("file_path", 1, 2, "Error_message")

# Generated at 2022-06-26 13:38:11.561593
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # initialize class PostProcessor
    post_processor_0 = PostProcessor()
    # assert test method try_utime
    assert post_processor_0.try_utime('', 0, 0, '')



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:38:24.867408
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_post_processor_try_utime_0 = PostProcessor()
    test_post_processor_try_utime__path_0 = ''
    test_post_processor_try_utime__atime_0 = 0
    test_post_processor_try_utime__mtime_0 = 0
    class MockDownloader(object):
        def report_warning(self, reason):
            pass
    test_post_processor_try_utime_0._downloader = MockDownloader()
    test_post_processor_try_utime_0.try_utime(test_post_processor_try_utime__path_0, test_post_processor_try_utime__atime_0, test_post_processor_try_utime__mtime_0)

test_classes = [PostProcessor]
test

# Generated at 2022-06-26 13:38:31.758135
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0, atime_0, mtime_0, errnote_0 = '/', 12, 12, 'Cannot update utime of file'
    assert post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0) == None
    

# Generated at 2022-06-26 13:38:39.894580
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path_1 = 'path'
    atime_1 = 1
    mtime_1 = 1
    errnote_1 = 'Cannot update utime of file'
    post_processor_1.try_utime(path_1, atime_1, mtime_1, errnote_1)


# Generated at 2022-06-26 13:38:42.230370
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    ytdl = test_case_0()
    ytdl.try_utime(path=None, atime=None, mtime=None, errnote=None)


# Generated at 2022-06-26 13:38:53.096681
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    try:
        os.makedirs('test\\')
    except OSError:
        pass
    f = open('test\\test.txt', 'w')
    f.write('testing')
    f.close()
    post_processor.try_utime('test\\test.txt', 0, 0, 'Cannot update utime of file')
    assert os.path.getatime('test\\test.txt') == os.path.getmtime('test\\test.txt')


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:02.681674
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test.txt', 1, 1)


# Generated at 2022-06-26 13:39:12.476655
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = unicode('test_path')
    atime = 0.0
    mtime = 0.0
    errnote = 'test_errnote'
    post_processor_0.try_utime(path, atime, mtime, errnote)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:20.052823
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    from tempfile import mkstemp
    from ..compat import PY2
    fd, fname = mkstemp(text=PY2)
    f = os.fdopen(fd, "w")
    f.close()
    old_time = os.path.getmtime(fname)
    pp.try_utime(fname, old_time-99999, old_time-99999)
    assert abs(os.path.getmtime(fname) - old_time) < 5
    assert abs(os.path.getatime(fname) - old_time) < 5
    os.unlink(fname)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:29.415807
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # 1st test, fail on windows
    post_processor_1 = PostProcessor()
    if os.name == 'nt':
        try:
            post_processor_1.try_utime('', 0, 0)
            raise AssertionError('should raise exception')
        except Exception as e:
            assert 'Cannot update utime of file' in str(e)
    # 2nd test, success on OSX
    elif os.name == 'mac':
        path = '/Applications/GarageBand.app/Contents/Resources/AboutThisApp.png'
        atime, mtime = os.stat(encodeFilename(path))[7:9]
        post_processor_1.try_utime(path, atime, mtime)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 13:39:32.824583
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Test method try_utime of PostProcessor"""
    post_processor_0 = PostProcessor()
    try:
        os.utime('./YoutubeDL/postprocessor.py',(1516407932.0,1516407932.0))
    except Exception:
        pass
    post_processor_0.try_utime('./YoutubeDL/postprocessor.py',1516407932.0,1516407932.0,u'Cannot update utime of file')



# Generated at 2022-06-26 13:39:38.256768
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = "/home/dogenpunk/Projects/pytube/yt-dl/yt_dl/yt_dl/postprocessor/test/test_PostProcessor.py"
    atime = 1
    mtime = 1
    errnote = 'Cannot update utime of file'
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:39:43.087940
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename(u"some_file"), 0, 0)


# Generated at 2022-06-26 13:39:50.689348
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime('test_0', 1504450833, 1504450833, 'Cannot update utime of file') == None


if __name__ == "__main__":
    import sys
    import nose
    from nose.tools import assert_equals

    if sys.argv[-1] == "--nocover":
        nose.runmodule()
    else:
        nose.runmodule(
            argv=[sys.argv[0], "--logging-level", "ERROR", "--nocover", "--with-doctest", "--verbose", "--cover-erase"],
            exit=False)

# Generated at 2022-06-26 13:39:55.051204
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Fill up arguments that would normally be passed from command line
    testargs = ["youtube-dl", "-g", "https://www.youtube.com/watch?v=Pw5W5C5c5fU"]
    # Set up a downloader for test purposes
    from youtube_dl import YoutubeDL
    post_processor_1 = PostProcessor(YoutubeDL(testargs))
    post_processor_1.try_utime('filename.mp4',1460861049,1460861071)

if __name__ == '__main__':
    import nose

    os.environ['PYTHONPATH'] = '..'
    nose.runmodule()

# Generated at 2022-06-26 13:39:59.069277
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path_1 = 'test_file.txt'
    atime_1 = 'test_atime'
    mtime_1 = 'test_mtime'
    errnote_1 = 'test_errnote'
    try:
        post_processor_1.try_utime(path_1, atime_1, mtime_1, errnote_1)
    except Exception:
        pass


# Generated at 2022-06-26 13:40:18.489075
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = ""
    atime = 0
    mtime = 0
    errnote = "Cannot update utime of file"
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:40:30.144156
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    names = [
        (1, '1.mp4'),
        (2, '2.mp4'),
        (3, '3.mp4'),
    ]

    for i in names:
        path = i[1]
        assert encodeFilename(path) == i

    atime = 1234
    mtime = 5678
    errnote = 'Cannot update utime of file'

    def mock_utime(path, times):
        assert path == values[0][1]
        assert times == (atime, mtime)
        raise Exception()

    postProcessor = PostProcessor()
    postProcessor.try_utime(names[0][1], atime, mtime, errnote)

    postProcessor.os.path.exists = mock_utime

# Generated at 2022-06-26 13:40:37.987142
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Initialize class PostProcessor
    post_processor_1 = PostProcessor()
    path = 'path'
    atime = 2
    mtime = 3
    errnote = 'Cannot update utime of file'

    # Run method try_utime
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:40:43.374614
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    fake_downloader = None
    post_processor_0 = PostProcessor(fake_downloader)
    post_processor_0.try_utime('', '', '', '')



# Generated at 2022-06-26 13:40:50.041347
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader:
        def report_warning(self, msg):
            pass
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(MockDownloader)
    assert post_processor_0.try_utime('test_filename', 1234, 1234) is None

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:54.020899
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(str(), int(), int(), str())


# Generated at 2022-06-26 13:41:02.715956
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import pytest

    post_processor_1 = PostProcessor()

    # try_utime(path, atime, mtime, errnote='Cannot update utime of file'
    # Sets the access time and modified time of the file specified by path.

    # normal run
    with pytest.raises((IOError, OSError)):
        post_processor_1.try_utime('/tmp/asdasd', datetime.datetime.now(), datetime.datetime.now(), 'Cannot update utime of file')
        # IOError: [Errno 2] No such file or directory: '/tmp/asdasd'

# Generated at 2022-06-26 13:41:12.967512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    parent_dir = tempfile.mkdtemp(prefix='youtube-dl-test_PostProcessor_')
    filename = os.path.join(parent_dir, 'test.tmp')
    with open(filename, 'wb') as f:
        f.write(b'hello world')
    post_processor = PostProcessor()
    post_processor.try_utime(filename, 0, 0, 'a message')
    os.unlink(filename)
    os.rmdir(parent_dir)


if __name__ == '__main__':
    try:
        test_case_0()
    except KeyboardInterrupt:
        import sys
        sys.exit(1)
    test_PostProcessor_try_utime()
    import sys
    sys.exit(0)

# Generated at 2022-06-26 13:41:17.095212
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_try_utime_0 = PostProcessor()
    try:
        assert False
    except AssertionError as exception_0:
        pass


# Generated at 2022-06-26 13:41:24.486074
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor
    from ..utils import FileDownloader

    post_processor_0 = PostProcessor()
    file_downloader_0 = FileDownloader({})
    info_extractor_0 = InfoExtractor()
    info_extractor_0.extract('http://youtu.be/eiHXASgRTcA')
    file_downloader_0._process_info(info_extractor_0.extract('http://youtu.be/eiHXASgRTcA'))
    post_processor_0.set_downloader(file_downloader_0)
    post_processor_0.run(file_downloader_0._process_info(info_extractor_0.extract('http://youtu.be/eiHXASgRTcA')))
    result = post_processor

# Generated at 2022-06-26 13:42:00.696038
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0, '')



# Generated at 2022-06-26 13:42:06.612786
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("path", 2, 5, errnote="Cannot update utime of file")


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:14.743906
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    test_cases = [['path', 'atime', 'mtime', 'errnote'], ['path', 'atime', 'mtime', 'errnote'], ['path', 'atime', 'mtime', 'errnote'], ['path', 'atime', 'mtime', 'errnote'], ['path', 'atime', 'mtime', 'errnote']]
    for test_case in test_cases:
        path = test_case[0]
        atime = test_case[1]
        mtime = test_case[2]
        errnote = test_case[3]
        post_processor_0.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:42:22.425399
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/tmp/youtube_dl/test_video/test.txt', 1, 1)
    post_processor_0.try_utime('/tmp/youtube_dl/test_video/test.txt', 1, 1, errnote='Cannot update utime of file')

# Generated at 2022-06-26 13:42:27.864732
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime(encodeFilename(path), (atime, mtime))
    except Exception:
        post_processor_0._downloader.report_warning(errnote)

# Generated at 2022-06-26 13:42:35.779116
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Try to update utime of file, but it will be failed because the 'path'
    # is not a valid file path.
    post_processor_0.try_utime(None, None, None)
    # Try to update utime of file, but it will be failed because the 'path'
    # is not a valid file path.
    post_processor_0.try_utime('', None, None)
    # Try to update utime of file, but it will be failed because the 'path'
    # is not a valid file path.
    post_processor_0.try_utime('', None, None)
    # Try to update utime of file, but it will be failed because the 'path'
    # is not a valid file path.

# Generated at 2022-06-26 13:42:42.627968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try_utime_0 = PostProcessor()
    try_utime_0.try_utime("vnd.naw.path", 0.876, 0.494418859);

if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:43.777872
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime('filepath')
    except Exception as e:
        assert False


# Generated at 2022-06-26 13:42:49.555747
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('test_value_1', 'test_value_2', 'test_value_3', 'test_value_4')


# Generated at 2022-06-26 13:42:53.786778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime(path='path', atime=1, mtime=2, errnote='errnote')
    except NotImplementedError:
        pass