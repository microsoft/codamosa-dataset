

# Generated at 2022-06-26 13:33:38.748581
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('audio.mp4', 0, 0)
    
# test for instance attributes downloader

# Generated at 2022-06-26 13:33:43.877839
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('encodeFilename(path)', 'atime', 'mtime', 'errnote=Cannot update utime of file')

# Generated at 2022-06-26 13:33:49.624500
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = "./test"
    atime = 100
    mtime = 100
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:33:50.509699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime(None, None, None, None)

# Generated at 2022-06-26 13:33:59.294235
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Configuring a mock downloader
    from mock import Mock
    from youtube_dl.YoutubeDL import YoutubeDL
    from .test_playlist import get_playlist_result
    youtube_dl = YoutubeDL({})

    def report_warning_mock(self, msg):
        return None

    youtube_dl.report_warning = report_warning_mock
    playlist_result = get_playlist_result()

    # Configuring mock info
    info = playlist_result['entries'][0]
    info['filepath'] = b'a/filepath.mp4'

    # Configuring a mock post processor with no downloader
    pp = PostProcessor()

    assert pp.run(info)[1] == info

    # Configuring a mock post processor with a downloader
    pp.set_downloader(youtube_dl)



# Generated at 2022-06-26 13:34:04.672755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='path', atime=0, mtime=0, errnote='errnote')


# Generated at 2022-06-26 13:34:07.325763
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor = PostProcessor()
    postprocessor.try_utime(1, 2, 3)
    return

# Generated at 2022-06-26 13:34:18.053079
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    fout = open('PostProcessor_try_utime.temp', 'w')
    fout.write('foobar')
    fout.close()
    expected_st_atime = os.stat('PostProcessor_try_utime.temp').st_atime
    pp = PostProcessor()
    pp.try_utime('PostProcessor_try_utime.temp', 1, 2)
    actual_st_atime = os.stat('PostProcessor_try_utime.temp').st_atime
    if expected_st_atime == actual_st_atime:
        print("[PASS] PostProcessor_try_utime")
    else:
        print("[FAIL] PostProcessor_try_utime")
    os.remove("PostProcessor_try_utime.temp")



# Generated at 2022-06-26 13:34:23.777955
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # Call method try_utime with test cases
    try:
        path = '/tmp/test'
        atime = 1436992797.607077
        mtime = 1436992797.607077
        errnote = 'Cannot update utime of file'
        pp.try_utime(path, atime, mtime, errnote)
        assert True, 'Successfully created the file'
        # Now remove the file
        os.remove(path)
    except Exception:
        assert False, 'Failed to create the file'


# Generated at 2022-06-26 13:34:34.498991
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import datetime

    # Create a temporary file
    f = open('test.txt', 'w')
    f.close()

    # Get the current time
    now = datetime.datetime.now()

    # Run try_utime function
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test.txt', now.timetuple()[0], now.timetuple()[1])

    # Get the file's modification time
    mtime = os.path.getmtime('test.txt')

    # Check that the modification time was properly updated
    assert mtime == now.timetuple()[1]

# Generated at 2022-06-26 13:34:37.586355
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:34:42.742931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'path'
    atime = 'atime'
    mtime = 'mtime'
    errnote = 'errnote'
    post_processor_try_utime = PostProcessor()
    post_processor_try_utime.try_utime(path, atime, mtime, errnote)



# Generated at 2022-06-26 13:34:55.415356
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    import os
    import tempfile
    temp_filename = tempfile.mkstemp()[1]
    class fake_downloader:
        params = {'outtmpl': os.path.join(temp_filename, '%(extractor)s-%(id)s-%(title)s.%(ext)s')}
        def report_warning(this, errnote='Cannot update utime of file'):
            print('%s %s' % (os.path.join(temp_filename, '%(extractor)s-%(id)s-%(title)s.%(ext)s'),errnote))
    post_processor_0.set_downloader(fake_downloader())

# Generated at 2022-06-26 13:35:06.639930
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    post_processor_1 = PostProcessor()
    # Test try_utime method
    # Test with a file

# Generated at 2022-06-26 13:35:09.721747
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor.try_utime(PostProcessor(), 'E://video', 'atime', 'mtime')



# Generated at 2022-06-26 13:35:17.983601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..YoutubeDL import YoutubeDL
    import os
    import platform
    import shutil
    import tempfile

    if platform.system() == 'Windows':
        return

    tempdir = tempfile.mkdtemp()
    dl = YoutubeDL(params={})
    pp = PostProcessor(dl)

    filename = os.path.join(tempdir, 'testfile')
    with open(filename, 'w') as f:
        f.write('test file')
    dr = DateRange.parse_range('20130301-20130302')


# Generated at 2022-06-26 13:35:28.910142
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:35:35.485933
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(45,45,45,45)
    return




test_cases = [
    test_case_0,
]

if __name__ == '__main__':
    for f in test_cases:
        print(f())

# Generated at 2022-06-26 13:35:47.417734
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestDownloader:
        def __init__(self):
            self.count = 0

        def report_warning(self, errnote):
            assert errnote == 'Cannot update utime of file'
            self.count += 1

    downloader = TestDownloader()
    post_processor_0 = PostProcessor(downloader)
    path = 'path'
    atime = 1.0
    mtime = 2.0
    post_processor_0.try_utime(path, atime, mtime)
    assert downloader.count == 1

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:55.895080
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test if it insert time properly
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime("test.txt", 0, 0)
    # Test if it ignores exceptions
    post_processor_2 = PostProcessor()
    post_processor_2.try_utime("test.txt", 0, 0, 'test exception')
    # Test if it ignores exceptions with another message
    post_processor_3 = PostProcessor()
    post_processor_3.try_utime("test.txt", 0, 0, 'test exception 2')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:07.028658
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'C:\\TEMP\\report.txt'
    atime_0 = 1340970208
    mtime_0 = 1340970208
    errnote_0 = 'Cannot update utime of file'
    error_class_0 = PostProcessingError
    error_0 = None

# Generated at 2022-06-26 13:36:08.463493
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass  # this method is not really testable, it needs proper mocking/stubbing


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:13.715196
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('video.mp4', 1539452523.842, 1539452524.0, 'Cannot update utime of file')




# Generated at 2022-06-26 13:36:17.020151
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_2 = PostProcessor()
    post_processor_2.try_utime(1, 2, 3)
    post_processor_2.try_utime(1, 2, 3, 'Cannot update utime of file')


# Generated at 2022-06-26 13:36:26.685148
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = object()
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(downloader)
    path = "/Users/liquan/Downloads/azuread-poseidon/azuread-poseidon/azuread-poseidon/img/"
    atime = 1300000000
    mtime = 1200000000
    post_processor_0.try_utime(path, atime, mtime)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:28.392891
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('123', 12, 12, 'filepath')



# Generated at 2022-06-26 13:36:29.619954
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post = PostProcessor()
    post.try_utime('test_file', 1, 2)


# Generated at 2022-06-26 13:36:36.552638
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Prepare mock objects
    class MockDownloader():
        def __init__(self):
            self.params = {}
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            self._downloader = MockDownloader()
    # Execute tested method
    post_processor_0 = MockPostProcessor()
    values = post_processor_0.try_utime('filepath', 1, 2)
    # Check results
    assert values == None


# Generated at 2022-06-26 13:36:49.933037
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create an instance of class PostProcessor for testing
    post_processor_0 = PostProcessor()
    post_processor_0.encodeFilename = lambda  path : path
    post_processor_0._downloader = None
    type_list = []
    args = (type_list, )
    # Test case with default values for arguments
    post_processor_0.try_utime('', '', '', 'Cannot update utime of file', *args)


if __name__ == '__main__':
    import sys
    import pytest

    if len(sys.argv) != 2:
        print('Usage: %s FUNCTION' % sys.argv[0])
        print('e.g.: %s test_PostProcessor_try_utime' % sys.argv[0])

# Generated at 2022-06-26 13:36:52.636579
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
   post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:37:00.784469
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    post_processor_0 = PostProcessor()
    path_0 = "vx_hZ0frQZQ"
    atime_0 = 0
    mtime_0 = 0
    errnote_0 = "Cannot update utime of file"

    # Testing method try_utime of class PostProcessor
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:37:06.611545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0_1 = PostProcessor()
    path_0_2 = post_processor_0_1.try_utime("", 0, 0, 'Cannot update utime of file')
    assert(path_0_2 == 'Cannot update utime of file')

# Generated at 2022-06-26 13:37:10.483874
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_3 = PostProcessor()
    try:
        os.utime('C:\Windows\System32\drivers\\video.mp4', (0, 0))
    except:
        post_processor_3._downloader.report_warning('Cannot update utime of file')


# Generated at 2022-06-26 13:37:16.487249
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = tempfile.mkstemp()[1]
    args = (path, 1272361000, 1272361000)
    assert post_processor_0.try_utime(*args) == None


# Generated at 2022-06-26 13:37:19.324317
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
    except Exception as exception_0:
        assert False, exception_0
    else:
        assert True


# Generated at 2022-06-26 13:37:23.535525
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='path', atime=1, mtime=1, errnote='errnote')

# Generated at 2022-06-26 13:37:29.869650
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    with open('sample_file.txt', 'wb') as file:
        file.write(bytes(65))

    test_path = 'sample_file.txt'
    test_atime = 1
    test_mtime = 2
    test_errnote = 'Cannot update utime of file'

    post_processor_0.try_utime(test_path, test_atime, test_mtime, test_errnote)


# Generated at 2022-06-26 13:37:33.327070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'C:\\Users\\VuongNM'
    atime = '2014-12-10'
    mtime = '2014-12-24'
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:37:37.720023
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime("",1,1)
    except Exception:
        pass
    post_processor_0.try_utime("",1,1)
    

# Generated at 2022-06-26 13:37:42.153463
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
  post_processor = PostProcessor()
  # the method try_utime is not suitable for testing
  return


if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-26 13:37:56.141539
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = ''
    atime = None
    mtime = None
    errnote = ''
    post_processor_0 = PostProcessor()
    try:
        result = post_processor_0.try_utime(path, atime, mtime, errnote)
    except Exception as error:
        print(error)



# Generated at 2022-06-26 13:37:56.633565
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True




# Generated at 2022-06-26 13:38:00.200152
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True

if __name__ == "__main__":
    import sys
    import nose
    sys.exit(nose.run(defaultTest=__name__))

# Generated at 2022-06-26 13:38:07.116623
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile

    tmp = NamedTemporaryFile(delete=False)
    tmp.close()
    try:
        pp = PostProcessor()
        pp.try_utime(tmp.name, 1, 2)
    finally:
        os.remove(tmp.name)

# Generated at 2022-06-26 13:38:11.288015
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("hello.mp4", 0, 0, "Cannot modify file")


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:24.082050
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # If a exception is raised, the test is fail, otherwise test is succeed
    # Create a fake _downloader object to test try_utime
    class FakeDownloader(object):
        def report_warning(self, errnote):
            return
    downloader = FakeDownloader()
    # fake file path for test
    test_path = 'test_video.mp4'
    # fake atime and mtime for test
    atime, mtime = None, None
    post_processor_1.try_utime(test_path, atime, mtime)

if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:28.005721
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(0, 0, 0)


# Generated at 2022-06-26 13:38:33.531090
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'welkom'
    atime_0 = 5
    mtime_0 = 5
    post_processor_0.try_utime(path_0, atime_0, mtime_0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:38.975834
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("",2,2,"")

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:41.638805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # It is not possible to test this method, since it is not possible to simulate
    # the desired exception by "hand"
    pass


# Generated at 2022-06-26 13:39:05.475020
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from datetime import datetime
    from shutil import copyfile, rmtree
    from subprocess import check_output
    from tempfile import mkdtemp
    from .testcaser import execute_testcase
    import os

    # Create temporary folder
    tempdir_path = mkdtemp()
    file_in_path = os.path.join(tempdir_path, 'file_in')
    file_out_path = os.path.join(tempdir_path, 'file_out')

    # Create file_in
    with open(file_in_path, 'w') as f:
        f.write('foo')

    # Get timestamp of file_in
    file_in_atime = os.path.getatime(file_in_path)

# Generated at 2022-06-26 13:39:08.495233
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime()

# Generated at 2022-06-26 13:39:14.206243
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    file_name = "random_file.txt"
    file = open(file_name, "w")
    file.close()
    post_processor.try_utime(file_name, 1, 1)
    os.remove("random_file.txt")


# Generated at 2022-06-26 13:39:26.080150
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("/my/file.txt", 0, 0)  # should not raise an exception

    class MockOs:
        def __init__(self):
            self.utime_call_count = 0

        def utime(self, path, times):
            self.utime_call_count += 1

    mock_os = MockOs()
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime("/my/file.txt", 0, 0, os=mock_os)  # should not raise an exception
    assert mock_os.utime_call_count == 1

# Generated at 2022-06-26 13:39:29.759598
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, None, None, None)



# Generated at 2022-06-26 13:39:39.620498
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # Testing for: 
    # Try updating the utime of a file
    # and report a warning if it fails.
    #
    # In order to test post_processor.try_utime, we have to put the downloader's
    # report_warning function into a variable to be called later. We then call
    # post_processor.try_utime and check the value of the variable that it
    # should send to report_warning.
    #
    # In the future, we will want to check whether try_utime sends
    # report_warning to the downloader for all cases, but for now we can
    # only check that it does so for the first case.
    r_warning = None

# Generated at 2022-06-26 13:39:46.608452
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader(params={})
    post_processor_1 = PostProcessor(downloader)
    post_processor_1.try_utime('C:\\Users\\Wanchalearm\\Music', 1469194618.0, 1469194618.0)

# Generated at 2022-06-26 13:39:52.907365
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename(''), 0, 0, encodeFilename(''))
    post_processor_0.try_utime(encodeFilename(''), 00.0, 00.0, encodeFilename(''))


# Generated at 2022-06-26 13:39:58.053115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor_0 = PostProcessor()
    path_name_0 = encodeFilename('test_value_0')
    atime_0 = float()
    mtime_0 = float()
    errnote_0 = 'test_value_0'
    ret_0 = postprocessor_0.try_utime(path_name_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:40:03.807150
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('./youtube_download/test.mp4', 1446175715.59, 1446175715.59)


# Generated at 2022-06-26 13:40:35.280267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('path', 1, 1)

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:39.505541
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test/test_files/test.html', 1453271975, 1453271975)
    pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()
    pass

# Generated at 2022-06-26 13:40:45.385512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0._downloader = {'params': {'verbose': False}}
    post_processor_0.try_utime(encodeFilename('abc'),1,2)


# Generated at 2022-06-26 13:40:50.974687
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = "HnXkvnC"
    atime_0 = 589
    mtime_0 = 589

    post_processor_0.try_utime(path_0, atime_0, mtime_0)
    assert path_0 == "HnXkvnC"
    assert atime_0 == 589
    assert mtime_0 == 589


# Generated at 2022-06-26 13:40:54.381685
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', '', '')

# Generated at 2022-06-26 13:41:01.014983
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()

    main.test_video_exists()
    main.test_video_length()
    main.test_video_url()
    main.test_video_title()
    post_processor_1.try_utime(main.test_video_exists(),main.test_video_length(),main.test_video_url(),main.test_video_title())


# Generated at 2022-06-26 13:41:12.415379
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os

    utime_test_file = './test_file'
    if not os.path.isfile (utime_test_file):
        with open(utime_test_file, 'wb') as f:
            f.write(b'test')

    file_mtime = os.stat(utime_test_file).st_mtime
    file_atime = os.stat(utime_test_file).st_atime

    # Call the method and get the result.
    PostProcessor().try_utime(utime_test_file, time.time(), time.time(), 'test')


# Generated at 2022-06-26 13:41:16.490785
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 3.14, 3.14)



# Generated at 2022-06-26 13:41:19.822596
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('test_file_name', 1, 1)


# Generated at 2022-06-26 13:41:23.855835
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename('test_video_output.mp4'), 1.0, 1.0)



# Generated at 2022-06-26 13:42:24.513280
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from datetime import datetime
    
    file_path = 'C:\\Users\\user\\Desktop\\test.mp4'
    atime = mtime = datetime.now().timestamp()
    
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(file_path, atime, mtime)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:25.871067
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This method is a stub
    pass



# Generated at 2022-06-26 13:42:32.892497
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Invoke try_utime of PostProcessor with some arguments
    post_processor_1 = PostProcessor()
    path = 'some_path.txt'
    atime = 'some_atime'
    mtime = 'some_mtime'
    errnote = 'some_errnote'
    post_processor_1.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:42:43.435715
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # You should check that class PostProcessor is
    # properly initialized here.
    path_0 = 'test_try_utime'
    atime_0 = 0
    mtime_0 = 0
    post_processor_0.try_utime(path_0, atime_0, mtime_0)
    # You should check that class PostProcessor is properly
    # cleaned-up here.


if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-26 13:42:51.370013
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime('test/test', 'atime', 'mtime', 'errnote')
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:54.089754
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO: Test this case passing a value to errnote
    post_processor = PostProcessor()
    post_processor.try_utime('a', 1, 1)



# Generated at 2022-06-26 13:42:56.691128
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test', 1, 2)

# Generated at 2022-06-26 13:43:05.492248
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # default values
    pp = PostProcessor()
    pp.try_utime(2, 3, 4)

    # with errnote
    pp = PostProcessor()
    pp.try_utime(2, 3, 4, 'Cannot update utime of file')

    pp = PostProcessor()
    pp.try_utime(2, 3, 4, 'Cannot update utime of file')


if __name__ == '__main__':
    # print(test_case_0())
    print(test_PostProcessor_try_utime())

# Generated at 2022-06-26 13:43:08.112872
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True
# ################# END OF GENERATED CODE ################# #

# Generated at 2022-06-26 13:43:12.104793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime(path='path', atime=1, mtime=2)


test_case_0()