

# Generated at 2022-06-26 13:33:41.347536
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = '/home/yugant/Downloads/youtube-dl-2018.08.02/test/test_file'
    atime_0 = 1489782975.19672
    mtime_0 = 10.6271555
    errnote_0 = "Cannot update utime of file"
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:33:48.540321
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = '{0}/../DummyPostProcessor.py'.format(os.getcwd())
    atime = 0.0
    mtime = 0.0
    expected = False
    post_processor_0.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:34:01.319977
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Creating a new file with some content
    f = open('test.txt','w')
    f.write('Test')
    f.close()

    # Changing the time
    post_processor_0 = PostProcessor()
    import time
    a = time.time()
    a -= 100
    post_processor_0.try_utime('test.txt', a, a)
    # Testing if the modification went well
    import os
    assert (os.path.getmtime('test.txt') == os.path.getatime('test.txt'))
    # The time is 100 seconds less than the current time
    import time
    assert (os.path.getmtime('test.txt') < time.time() - 99)
    # Deleting the file
    os.remove('test.txt')

# Generated at 2022-06-26 13:34:11.737666
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        os.utime('this_is_not_a_file.mp3', (0,0))
    except Exception:
        pp.try_utime('another_file.mp3', 0, 0)
        return True
    return False


# Generated at 2022-06-26 13:34:21.424424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Check existence and type of attributes
    assert PostProcessor.try_utime.im_class is PostProcessor
    assert (PostProcessor.try_utime.im_func.func_code.co_argcount >=
            PostProcessor.try_utime.func_code.co_argcount)
    assert (PostProcessor.try_utime.im_func.func_code.co_varnames[:
            PostProcessor.try_utime.func_code.co_argcount] ==
            PostProcessor.try_utime.func_code.co_varnames)



# Generated at 2022-06-26 13:34:27.491921
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(0, 0, 0, 'Cannot update utime of file')


if __name__ == "__main__":
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:30.497490
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    string_0 = 'Cannot update utime of file'
    if post_processor_1:
        path_0 = post_processor_1
        post_processor_1.try_utime(path_0, None, None, string_0)


# Generated at 2022-06-26 13:34:34.598021
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor_0 = PostProcessor()
    try:
        os.utime()
        raise AssertionError("PostProcessor_try_utime does not have a test yet")
    except AttributeError:
        pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:40.160696
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Verify that the method behaves as expected
    # for expected input parameters
    assert(post_processor_0.try_utime(path=None, atime=None, mtime=None, errnote=None) == None)


# Generated at 2022-06-26 13:34:42.030905
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # TODO: Define tests



# Generated at 2022-06-26 13:34:48.100440
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(b'1', '1', '1', '1')



# Generated at 2022-06-26 13:34:49.466474
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('temp', 'temp', 'temp', 'Cannot update utime of file')

# Generated at 2022-06-26 13:34:53.548805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    instance = PostProcessor()
    try:
        instance.try_utime(none, none, none)
    except Exception:
        pass
    else:
        assert False, "Exception not raised with incomplete arguments"


# Generated at 2022-06-26 13:35:01.252856
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = '' # provide proper value
    atime = 0 # provide proper value
    mtime = 0 # provide proper value
    errnote = '' # provide proper value
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:35:03.314998
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime()


# Generated at 2022-06-26 13:35:16.028877
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl import YoutubeDL
    from hashlib import md5
    from tempfile import mkdtemp
    from os import unlink, rmdir
    import shutil

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'logger': YoutubeDL().logger,
    }


# Generated at 2022-06-26 13:35:28.113526
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:35:37.135167
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'u8'
    atime = 1467825627
    mtime = 1467825628
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


test_functions = [test_case_0,test_PostProcessor_try_utime]

if __name__ == "__main__":
    for f in test_functions:
        f()
        print('%s passed' % f.__name__)

# Generated at 2022-06-26 13:35:46.609644
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(post_processor_0, post_processor_0, post_processor_0)
    path, atime, mtime, errnote = 'Cannot update utime of file', post_processor_0, post_processor_0, post_processor_0
    post_processor_0.try_utime(path, atime, mtime, errnote)
# Test case for method run of class PostProcessor

# Generated at 2022-06-26 13:35:49.914429
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        test_case_0()
        test_case_1()
    except PostProcessingError as e:
        assert e.message == 'Cannot update utime of file'


# Generated at 2022-06-26 13:35:59.962385
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    path = "test_path"
    atime = 1
    mtime = 2

    # test with successful utime
    os.utime = lambda x, y: None
    post_processor.try_utime(path, atime, mtime, errnote="I'm an error!")

    # test with unsuccessful utime and not quiet
    os.utime = lambda x, y: 1/0
    post_processor.try_utime(path, atime, mtime, errnote="I'm an error!")

    # test with unsuccessful utime and quiet
    os.utime = lambda x, y: 1/0
    post_processor.try_utime(path, atime, mtime, errnote=None)

if __name__ == '__main__':
    test_case

# Generated at 2022-06-26 13:36:03.948166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('path', 'atime', 'mtime', 'errnote') == None


# Generated at 2022-06-26 13:36:08.350771
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime((os.path.sep), (10), (11), (None))


# Generated at 2022-06-26 13:36:09.766259
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:36:18.302284
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    from pytube import Youtube
    from pytube import Playlist
    from pytube import Stream
    from pytube import Caption
    url_0 = "https://www.youtube.com/watch?v=BaW_jenozKc"
    youtube_0 = Youtube(url_0)
    stream_0 = youtube_0.streams.first()
    stream_0.download()


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:28.823710
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    # import os
    # os.utime()
    # post_processor_0.try_utime()
    # utime: cannot access 'post_processor_0': No such file or directory
    try:
        os.utime(encodeFilename('post_processor_0'), (1, 1))
    except Exception:
        assert True
    else:
        assert False
    try:
        os.utime(encodeFilename('post_processor_1'), (1, 1))
    except Exception:
        assert True
    else:
        assert False

## Test for __init__(self, downloader=None) of class PostProcessor

# Generated at 2022-06-26 13:36:32.276928
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os, tempfile
    fn = tempfile.NamedTemporaryFile().name
    PostProcessor().try_utime(fn, 1, 2)
    atime, mtime = os.stat(fn).st_atime, os.stat(fn).st_mtime
    assert atime == 1.0 and mtime == 2.0

# Generated at 2022-06-26 13:36:39.900178
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()

    try:
        os.path.isfile(post_processor_1.try_utime())
        return True
    except TypeError:
        return False


if __name__ == '__main__':
    # Unit test for class PostProcessor
    print('Test case 0:')
    test_case_0()
    print('\nTest case 1 result:', test_PostProcessor_try_utime())

# Generated at 2022-06-26 13:36:51.174768
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-26 13:36:55.481179
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .testcase_test_module_utils import TestCase
    from ..utils import FakeDownloader
    test_case = TestCase()
    downloader = FakeDownloader()
    post_processor = PostProcessor(downloader)
    expected = ['/test/video.avi', 0, 0]
    post_processor.try_utime(expected[0], expected[1], expected[2])
    test_case.assertListEqual(downloader.utime_args, expected)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:07.422128
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("o0Dynne-FpUl.mp4", 1347487660.0, 1347487660.0)



# Generated at 2022-06-26 13:37:09.627291
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path = "test_path", atime = 0, mtime = 0)


# Generated at 2022-06-26 13:37:16.929654
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Add unit test for method run of class PostProcessor here


# More tests should be written for class PostProcessor and the other classes
# developed in this module

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:21.063380
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    path = "C:\File.ext"
    atime = mtime = 0

    post_processor = PostProcessor()

    # Test if try_utime method return None if the os.utime function doesn't raise an exception
    assert post_processor.try_utime(path, atime, mtime) == None


# Generated at 2022-06-26 13:37:27.898272
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime(encodeFilename(''), (0, 0))
    except Exception:
        pass
    try:
        os.utime(encodeFilename('foo'), (0, 0))
    except Exception:
        pass
    try:
        os.utime(encodeFilename(None), (0, 0))
    except Exception:
        pass

# Generated at 2022-06-26 13:37:31.108096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    a = PostProcessor()

    # test for static field downloader
    if not a._downloader == None:
        raise Exception("PostProcessor.downloader is not None !")

# Generated at 2022-06-26 13:37:36.468085
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = None  # TODO: implement...
    atime = None  # TODO: implement...
    mtime = None  # TODO: implement...
    errnote = None  # TODO: implement...
    test_case_0 = PostProcessor.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:37:38.750032
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Tests for specific path
    post_processor = PostProcessor()
    post_processor.try_utime('filename', 0, 0)
    # TODO: Test for post_processor.try_utime

# Generated at 2022-06-26 13:37:49.940804
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post = PostProcessor()
    if os.name == 'nt' and os.path.exists('c:/Windows/System32'):
        path = 'c:/Windows/System32'
        post.try_utime(path, 100, 200)
    else:
        try:
            fp = open('utime.tmp', 'wb')
            fp.write(b'\xde\xad\xbe\xef')
            fp.close()
            post.try_utime('utime.tmp', 100, 200)
            os.remove('utime.tmp')
        except Exception:
            raise

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:01.611759
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os.path
    import sys

    old_path = sys.path[:]
    try:
        sys.path = ["postprocessor_test_dir/test_case_0"]
        from test_case_0_PostProcessor import PostProcessor
        from test_case_0_PostProcessor import test_case_0

        pp = PostProcessor()
        test_case_0()
        pp.try_utime("postprocessor_test_dir/test_case_0/test.dat", 0, 0, "Cannot update utime of file")
    except ImportError:
        sys.path = old_path
    else:
        assert(os.path.exists("postprocessor_test_dir/test_case_0/test.dat"))
        
if __name__ == '__main__':
    test_case_

# Generated at 2022-06-26 13:38:21.782117
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'path'
    atime = 'atime'
    mtime = 'mtime'
    errnote = 'Cannot update utime of file'
    assert post_processor_0.try_utime(path, atime, mtime, errnote) is None


# Generated at 2022-06-26 13:38:29.052512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO(Toni): Complete unit test for PostProcessor method try_utime
    post_processor = PostProcessor()
    path = 'path'
    atime = 1
    mtime = 1
    errnote = 'errnote'
    post_processor.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:38:34.206990
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.unlink = lambda: None 
    class FakeDownloader():
        def report_warning(self, errnote):
            self.errnote = errnote

    pp = PostProcessor(FakeDownloader())

    pp.try_utime('path', 'atime', 'mtime', errnote='Cannot update utime of file')

    assert pp._downloader.errnote == 'Cannot update utime of file'


# Generated at 2022-06-26 13:38:44.180338
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Setup
    postprocessor = PostProcessor()
    os.mkdir('PostProcessor_Test_Dir')
    file_path = os.path.join('PostProcessor_Test_Dir','test_file.txt')
    f = open(file_path,'w')
    f.close()

    # Exercise
    postprocessor.try_utime(file_path, 0, 0)
    post_file_stat = os.stat(file_path)

    # Verify
    assert post_file_stat.st_atime == 0 and post_file_stat.st_mtime == 0

    # Teardown
    os.remove(file_path)
    os.rmdir('PostProcessor_Test_Dir')

# Generated at 2022-06-26 13:38:49.400606
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path='', atime=2, mtime=4, errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:38:52.107389
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # TODO: implement a test case for method try_utime
    raise NotImplementedError('Test for PostProcessor.try_utime not implemented.')


# Generated at 2022-06-26 13:38:59.297971
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create object of class PostProcessor
    post_processor_0 = PostProcessor()
    # Call method try_utime of class PostProcessor
    post_processor_0.try_utime('', 0, 0)


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:03.152627
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test on method try_utime of class PostProcessor
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('test_filepath', 'test_atime', 'test_mtime', 'test_errnote')

# Generated at 2022-06-26 13:39:16.165743
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:39:20.475596
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path=u'C:/Users/vyomkesh_j/Videos/RevisitingPorn-TheWholeStory-1.flv', atime=12345, mtime=12345, errnote='Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:53.930666
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    if post_processor_1.try_utime("path", "atime", "mtime", "errnote") is not None:
        pass
    else:
        raise RuntimeError("Test fail")


# Generated at 2022-06-26 13:39:58.193601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/dev/null', 1476729053.169952, 1476729053.169952, 'Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:02.563750
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    return post_processor_0.try_utime('path', 'atime', 'mtime', 'errnote')


# Generated at 2022-06-26 13:40:07.751207
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Create a PostProcessor instance
    post_processor_0 = PostProcessor()

    # Step 1: Call method try_utime of post_processor_0
    # Type warning
    post_processor_0.try_utime('file', 'atime', 'mtime', 'errnote')



# Generated at 2022-06-26 13:40:14.438839
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = "5vKhs"
    path = encodeFilename(path)
    atime = 1
    mtime = 1
    post_processor_0.try_utime(path, atime, mtime, errnote='')


# Generated at 2022-06-26 13:40:15.664636
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(None, None, None, None)



# Generated at 2022-06-26 13:40:24.013376
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Mock object
    class Mock_post_processor_0(object):
        def report_warning(self, *args, **kwargs):
            return
    post_processor_0._downloader = Mock_post_processor_0()
    post_processor_0.try_utime(path=str(''),
                               atime=float(),
                               mtime=float(),
                               errnote=str(''))


# Generated at 2022-06-26 13:40:27.135988
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(downloader=None)
    pp.try_utime("foo", 0, 0, errnote='hi')

# Generated at 2022-06-26 13:40:29.768012
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(None, None, None, None)

# Generated at 2022-06-26 13:40:35.202105
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Raise exception in case the method 'try_utime' of class 'PostProcessor' does not return 'None'
    pp = PostProcessor()
    assert pp.try_utime('', 0, 0) is None


# Generated at 2022-06-26 13:41:51.470558
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass
    path = '/tmp/YoutubeDL/test/test.mp4'
    atime = 0.0
    mtime = 0.0
    errnote = 'Cannot update utime of file'
    pp = PostProcessor()
    pp.try_utime(path, atime, mtime, errnote)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:02.324108
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    information_0 = {"description": "description", "thumbnail": "thumbnail", "uploader_id": "id", "uploader": "author", "title": "title", "webpage_url": "url"}
    filepath_0 = ""
    try:
        assert os.utime(encodeFilename(filepath_0), None)
    except:
        pass
    a = post_processor_0.try_utime(filepath_0, None, None)

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:06.475412
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('path', time.time(), time.time())


# Generated at 2022-06-26 13:42:08.957000
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    assert post_processor.try_utime('filename', 0, 0) == None

# Generated at 2022-06-26 13:42:14.057328
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    filename = 'filename'
    atime = 'atime'
    mtime = 'mtime'
    errnote = 'Cannot update utime of file'
    post_processor = PostProcessor()
    post_processor.try_utime(filename, atime, mtime, errnote)
    assert os.utime(filename, (atime, mtime)) == None

if __name__ == '__main__':
    test_PostProcessor_try_utime()


# Generated at 2022-06-26 13:42:21.536104
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime(encodeFilename(path), (atime, mtime))
    except:
        pass
    try:
        os.utime(encodeFilename(path), (atime, mtime))
    except:
        pass


# Generated at 2022-06-26 13:42:24.678843
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    post_processor_0 = PostProcessor()

    post_processor_0.try_utime('test_file', 'test_atime', 'test_mtime')

    assert(post_processor_0.try_utime('test_file', 'test_atime', 'test_mtime', 'test_errnote'))

# Generated at 2022-06-26 13:42:33.337908
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # test with args atime = datetime.datetime(2016, 9, 10, 0, 0) and mtime = datetime.datetime(2016, 9, 10, 0, 0)
    # expected result: 0
    # assert post_processor_0.try_utime(atime = datetime.datetime(2016, 9, 10, 0, 0), mtime = datetime.datetime(2016, 9, 10, 0, 0), errnote = 'Cannot update utime of file') == 0
    pass

# Generated at 2022-06-26 13:42:40.186744
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = ""
    atime = 0
    mtime = 0
    errnote = "Cannot update utime of file"
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:42:43.399427
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(path='path', atime=1, mtime=2, errnote='errnote')
