

# Generated at 2022-06-26 13:33:43.014598
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    post_processor_0.try_utime(os.path.join('test', 'logs'), None, None, 'Cannot update utime of file')

    post_processor_0.try_utime(os.path.join('test', 'logs'), None, None, 'Cannot update utime of file')

    post_processor_0.try_utime(os.path.join('test', 'logs', 'youtube-dl.log'), None, None, 'Cannot update utime of file')


# Generated at 2022-06-26 13:33:51.710800
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    pp = PostProcessor()

    # Create a test file
    with open('./testfile', 'w') as f:
        f.write('1')

    # Get the file's mtime
    st = os.stat('./testfile')
    mtime = st.st_atime

    # Call try_utime with a bad time, then check that the file's mtime is not changed
    pp.try_utime('./testfile', 0, 0)
    st = os.stat('./testfile')
    assert(mtime == st.st_mtime)

    # Cleanup
    os.remove('./testfile')

# Generated at 2022-06-26 13:33:56.613778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(None)
    post_processor_0.try_utime(None, None, None, 'Cannot update utime of file')


# Generated at 2022-06-26 13:34:02.605758
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    global os, encodeFilename
    from .. import utils
    from . import PostProcessor
    from . import downloader
    os = utils.__dict__['os']
    encodeFilename = utils.__dict__['encodeFilename']
    PostProcessor = PostProcessor.__dict__['PostProcessor']
    Downloader = downloader.__dict__['Downloader']
    post_processor_0 = PostProcessor(Downloader())
    post_processor_0.try_utime('path', 10, 20)
    post_processor_0.try_utime('path', 10, 20, 'Cannot update utime of file')
    post_processor_0.try_utime()
    post_processor_0.try_utime()
    post_processor_0.try_utime('path')
    post_processor_

# Generated at 2022-06-26 13:34:15.905330
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    HTTPError = None
    path = 'C:/PycharmProjects/tactical-code/venv/lib/python2.7/site-packages/pytube/__main__.py'
    atime = 'C:/PycharmProjects/tactical-code/venv/lib/python2.7/site-packages/pytube/__main__.py'
    mtime = 'C:/PycharmProjects/tactical-code/venv/lib/python2.7/site-packages/pytube/__main__.py'
    errnote = 'Cannot update utime of file'
    if post_processor_1.try_utime(path, atime, mtime, errnote) == None:
        print('\n')

# Generated at 2022-06-26 13:34:20.464718
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Initialization
    test_processor = PostProcessor()
    test_path = './test/files/test_file.txt'
    test_atime = 1438956657.0
    test_mtime = 1438956657.0
    # Operation
    test_processor.try_utime(test_path, test_atime, test_mtime)
    # Verification


# Generated at 2022-06-26 13:34:25.788425
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = "./downloads/"
    atime = 1
    mtime = 1
    post_processor_0.try_utime(path, atime, mtime)

# Generated at 2022-06-26 13:34:34.753952
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test the try_utime method of class PostProcessor
    # This ensures that try_utime is compatible with both Python 2 and Python 3
    pp = PostProcessor()
    # Create a nonexistent file
    nonexistent_filepath = 'nonexistent_file'
    assert not os.path.isfile(nonexistent_filepath)
    # This statement must run without exceptions
    pp.try_utime(nonexistent_filepath, 1, 2)
    # Remove the nonexistent file
    os.remove(nonexistent_filepath)

if __name__ == '__main__':
    unittest_main()

# Generated at 2022-06-26 13:34:45.300115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp
    from time import time, sleep

    # Create a temporary file and unlink it (delete after closing) to get a name
    file_fd, file_path = mkstemp(prefix='youtube-dl_test_PostProcessor_try_utime')
    os.close(file_fd)
    os.unlink(file_path)

    pp = PostProcessor()

    ftime = time()
    sleep(1)

    pp.try_utime(file_path, ftime, ftime)
    (atime, mtime) = os.stat(file_path).st_atime, os.stat(file_path).st_mtime
    os.unlink(file_path)
    assert ftime - atime < 1.0 and ftime - mtime < 1.0


# Generated at 2022-06-26 13:34:50.012980
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime(1,2,3)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:54.937524
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime('test_file.txt', 3, 3)
    assert os.stat('test_file.txt').st_atime == 3
    pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:55.731636
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime("/downloads/1.mp4", 20, 30)


# Generated at 2022-06-26 13:34:57.005021
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('', -33, -33)
    except Exception:
        pass


# Generated at 2022-06-26 13:35:08.300249
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    from .common import FileDownloaderTestCase
    from .test_downloader import TestDownloader

    class TestPostProcessor(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Cannot update access and modification time of file'):
            # do not touch original file
            TestPostProcessor.path = path
            TestPostProcessor.atime = atime
            TestPostProcessor.mtime = mtime
            TestPostProcessor.errnote = errnote

    class TestFileDownloader(FileDownloader):
        def report_warning(self, message):
            TestFileDownloader.warning_message = message

    TestPostProcessor.path = None
    TestFileDownloader.warning_message = None


# Generated at 2022-06-26 13:35:17.274304
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import sys
    import shutil
    import subprocess

    sfd, temp_filename = tempfile.mkstemp(prefix="youtubedl_test-")
    os.close(sfd)
    original_filename = os.path.join(os.path.dirname(__file__), __name__ + '.py')
    shutil.copyfile(original_filename, temp_filename)
    times = os.stat(original_filename)[stat.ST_MTIME:]
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(temp_filename, times[0], times[1])

    result = os.stat(temp_filename)
    shutil.rmtree(temp_filename)
    assert result.st_mtime == times[1]



# Generated at 2022-06-26 13:35:22.863559
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    import time
    
    # Create a temporary file.
    file_path = NamedTemporaryFile().name
    
    # Get modification time in seconds since the epoch of file_path
    mtime = os.stat(file_path).st_mtime
    
    # Initialize PostProcessor object
    pp = PostProcessor()
    
    # Call try_utime to set the modification time of file_path to the current time
    pp.try_utime(file_path, mtime, mtime)
    
    # Check if the modification time of file_path was set to the current time
    assert os.stat(file_path).st_mtime == time.time()
    
    # Test try_utime with a non-existing file_path

# Generated at 2022-06-26 13:35:25.793847
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path='path', atime='atime', mtime='mtime')

# Generated at 2022-06-26 13:35:38.181652
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'dummy_path'
    atime = 'dummy_atime'
    mtime = 'dummy_mtime'
    errnote = 'dummy_errnote'
    post_processor_1 = PostProcessor()
    exception_0 = Exception()
    post_processor_1._downloader = {}
    post_processor_1._downloader['report_warning'] = lambda x : None
    os.utime = lambda x, y : None
    post_processor_1.try_utime(path, atime, mtime, errnote)
    os.utime = lambda x, y : None
    post_processor_1.try_utime(path, atime, mtime, errnote)
    os.utime = lambda x, y : None

# Generated at 2022-06-26 13:35:45.801041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_PostProcessor_object = PostProcessor()
    test_path = 'test_file_name'
    test_atime = 1
    test_mtime = 2
    test_errnote = 'test_errnote'
    test_PostProcessor_object.try_utime(test_path, test_atime, test_mtime, test_errnote)


# Generated at 2022-06-26 13:35:53.710846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test with this exact argument set
    post_processor_0.try_utime('ob3T1wZBCV', 'MdI', 'V7JQ')
    # Test with an arbitrary argument set
    post_processor_0.try_utime('djjEa', 'l2Q', 'eo7P')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:05.530427
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        pp.try_utime("", 1, 2)
    except:
        assert False, "try_utime() raises an unexpected exception"

    try:
        pp.try_utime("", -1, -1)
        assert False, "try_utime() did not raised an exception"
    except ValueError as e:
        assert True, "try_utime() raises a ValueError exception"

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:11.043204
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(u'video.mp4',
                               3,
                               3,
                               'Cannot update utime of file')


# Generated at 2022-06-26 13:36:20.625146
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..compat import compat_open
    fd1, path1 = tempfile.mkstemp()
    emptyFile = os.path.join(tempfile.gettempdir(), 'emptyFile.tmp')
    fd = compat_open(emptyFile, 'w', encoding='utf-8')
    fd.close
    post_processor_2 = PostProcessor()
    os.utime(path1, (0, 0))
    os.utime(emptyFile, (0, 0))
    atime1 = os.stat(path1).st_atime
    atime2 = os.stat(emptyFile).st_atime
    post_processor_2.try_utime(path1, atime1, atime1)

# Generated at 2022-06-26 13:36:30.905548
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os, sys
    import tempfile
    import time

    # Create a temporary file
    file_descriptor, file_name = tempfile.mkstemp()


# Generated at 2022-06-26 13:36:38.106965
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = "C:\\Users\\user\\Desktop\\YDL-master\\YDL-master\\3.mp3"
    atime_0 = 1479562881
    mtime_0 = 1479575081
    errnote_0 = "Cannot update utime of file"
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)

# Generated at 2022-06-26 13:36:50.704432
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from logging import INFO, WARNING
    from pytube.util.f4mtest import F4MFile
    from pytube.util.f4mtest import F4MFileTestCase
    from pytube.util.f4mtest import F4MManifest
    from pytube.util.f4mtest import F4MManifestTestCase
    from pytube.util.f4mtest import MPDFile
    from pytube.util.f4mtest import MPDFileTestCase
    from pytube.util.f4mtest import XMLFile
    from pytube.util.f4mtest import XMLFileTestCase
    from pytube.util.cmdoptions import enable_subparser
    from pytube.util.html import HTMLParser

    # test_try_utime_1
    post_processor_0 = PostProcessor()
   

# Generated at 2022-06-26 13:36:58.510468
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = "mp3s/temp.txt"
    atime = 1442000000
    mtime = 1442000000
    post_processor = PostProcessor()
    try:
        f = open(path, "w")
        f.close()
        post_processor.try_utime(path, atime, mtime)
    finally:
        os.remove(path)

# Generated at 2022-06-26 13:37:01.053380
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'data/postprocessortest.txt'

# Generated at 2022-06-26 13:37:08.916975
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Try to use utime for a file under nonexisting folder    
    p = os.path.abspath("__nonexisting__/a")
    post_processor_0 = PostProcessor()
    try:
        os.utime(p, (10, 20))
    except OSError:
        pass
    post_processor_0.try_utime(p, 10, 20)  # Should not fail


# Generated at 2022-06-26 13:37:16.707094
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # self._downloader.params (Dict) does not have key 'postprocessor_args'
    post_processor_0._configuration_args()

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:27.253772
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:37:29.658900
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    ppro = PostProcessor()

    # Try to update file time
    ppro.try_utime("test", "atime", "mtime")


# Generated at 2022-06-26 13:37:30.060785
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:37:32.154233
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    dummy_download_post_processor = PostProcessor()
    dummy_download_post_processor.try_utime("temp.txt", 111, 222)
    dummy_download_post_processor.try_utime("temp.txt", 111, 222, "erroneous note")


# Generated at 2022-06-26 13:37:38.866211
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    temp_path = os.path.join(os.getcwd(), "temp.txt")
    f = open(temp_path, "w")
    f.write("test")
    f.close()
    post_processor = PostProcessor()
    atime = os.path.getatime(temp_path)
    mtime = os.path.getmtime(temp_path)
    post_processor.try_utime(temp_path, atime, mtime)
    os.remove(temp_path)

# Generated at 2022-06-26 13:37:45.265570
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_1 = PostProcessor()
        post_processor_1.try_utime('test_value', 'test_value', 'test_value', 'Cannot update utime of file')
    except:
        pass


# Generated at 2022-06-26 13:37:47.402874
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    post_processor_1 = PostProcessor()
    # Execute the function with correct arguments
    post_processor_1.try_utime('test_path', atime=0, mtime=0)


# Generated at 2022-06-26 13:37:52.827934
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader_0 = PostProcessor()
    downloader_0.try_utime(path=str(), atime=float(), mtime=float(), errnote=str())


# Generated at 2022-06-26 13:38:02.401946
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_downloader = ""
    test_path = ""
    test_atime = ""
    test_mtime = ""
    test_errnote = ""
    test_errnote_except = ""
    test_instance_method_try_utime = PostProcessor(test_downloader)

    try:
        # Test whether an exception is raised when errnote argument is empty
        test_instance_method_try_utime.try_utime(test_path, test_atime, test_mtime, test_errnote_except)
    except:
        # Test whether an exception is raised when downloader argument is empty
        test_instance_method_try_utime.try_utime(test_path, test_atime, test_mtime, test_errnote)

# Generated at 2022-06-26 13:38:05.296851
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime()



# Generated at 2022-06-26 13:38:11.454062
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    return_value = post_processor_0.try_utime('', 1.0, 2.0, 'hZpyoTlTmu')
    assert return_value is None


# Generated at 2022-06-26 13:38:22.889472
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0, 'Cannot update utime of file')
    post_processor_0.try_utime('C:/Users/astepanov/Downloads/', 0, 0, 'Cannot update utime of file')
    post_processor_0.try_utime('C:/Users/astepanov/Downloads/', 0, 0, 'Cannot update utime of file')


if __name__ == '__main__':
    test_case_0()
    test_PostProce

# Generated at 2022-06-26 13:38:27.944390
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    encodeFilename_0 = encodeFilename(path)
    assert post_processor_0.try_utime(path, atime, mtime, errnote) == None

# Generated at 2022-06-26 13:38:34.990133
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test basic usage
    post_processor = PostProcessor()
    post_processor.try_utime(path='path_0', atime=1, mtime=1)
    # test for if os.utime fail
    try:
        post_processor.try_utime(path=None, atime=1, mtime=1)
    except Exception as e:
        pass
    # test for if os.utime fail
    try:
        post_processor.try_utime(path='path_3', atime=1, mtime=1)
    except Exception as e:
        pass

# Generated at 2022-06-26 13:38:41.335385
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # arrange
    post_processor = PostProcessor()
    path = 'path'
    atime = 0
    mtime = 0
    errnote = 'Error note'

    # act/assert
    post_processor.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:38:51.529486
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    try:
        os.utime(encodeFilename('test_file'), (0, 0))
    except Exception:
        # Should raise PostProcessingError
        raise AssertionError('Should not have raised PostProcessingError')
    else:
        post_processor_1.try_utime('test_file', 0, 0, 'Cannot update utime of file')

if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-26 13:38:59.219026
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(post_processor_1)
    post_processor_0.try_utime(1, 1, 1)
    assert 1 == 1


# Generated at 2022-06-26 13:39:06.863326
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Create a dummy class which behave like InfoExtractor
    class InfoExtractorDummy(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, errnote):
            pass

    # Create an instance of our dummy class
    infoExtractorDummy = InfoExtractorDummy()

    # Create a Post Processor
    postProcessorDummy = PostProcessor(infoExtractorDummy)

    # Set the file path
    filepath = r'C:\dummy\path\to\the\file'

    # Set the access time
    atime = 0

    # Set the modification time
    mtime = 0

    # Set the error note
    errnote = 'Cannot update utime of file'

    # Call try_utime

# Generated at 2022-06-26 13:39:10.500070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # path = 'abc'
    path = 'abc'
    # atime = 'abc'
    atime = 'abc'
    # mtime = 'abc'
    mtime = 'abc'
    # errnote = 'abc'
    errnote = 'abc'
    post_processor_0.try_utime(path, atime, mtime, errnote)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:13.666419
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("Path", "a time", "a time")


# Generated at 2022-06-26 13:39:23.957905
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime(encodeFilename('/tmp/foo'), (1, 10))


# Generated at 2022-06-26 13:39:27.731438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'Be_the_First'
    atime_0 = int()
    mtime_0 = int()
    errnote_0 = 'PostProcessor.try_utime error message'
    PostProcessor.try_utime(post_processor_0, path_0, atime_0, mtime_0, errnote_0)



# Generated at 2022-06-26 13:39:29.121538
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    assert post_processor.try_utime('test', None, None)

# Generated at 2022-06-26 13:39:29.908997
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-26 13:39:31.085841
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    #self.assertEqual(expected, post_processor.try_utime(path, atime, mtime, errnote))
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:39:32.653808
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO:
    pass

# Generated at 2022-06-26 13:39:38.163473
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Test case 1: no exception raised
    post_processor_1.try_utime('path', 10, 20)
    # Test case 2: no exception raised
    post_processor_1.try_utime('path', 10.2, 20.9)
    # Test case 3: no exception raised
    post_processor_1.try_utime('path', -10, -20)


# Generated at 2022-06-26 13:39:46.354438
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # assert_raises(PostProcessingError, post_processor_0.try_utime, 123)  # TODO: Should raise error
    post_processor_0.try_utime(123)


if __name__ == '__main__':
    test_case_0()

# vim: set ts=4 sw=4 sts=4 et:

# Generated at 2022-06-26 13:39:51.663900
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # no exception expected
    pp.try_utime('', 0, 0)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_case_0()

# Generated at 2022-06-26 13:39:56.984592
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path_0 = os.path.dirname(os.path.dirname(__file__)) + '/test/media/test.mp3'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path_0, 0, 0, 'Cannot update utime of file')



# Generated at 2022-06-26 13:40:13.042330
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # Create dummy file
    f = open('../dummy', 'wb')
    f.close()
    # Get atime and mtime of dummy file
    # We need to store it because every time atime and mtime are accessed
    # mtime is updated to current time
    f_stat = os.stat('../dummy')
    f_atime = f_stat.st_atime
    f_mtime = f_stat.st_mtime
    # Test the method
    pp.try_utime('../dummy', f_atime, f_mtime)
    # Check is the test was succesful
    assert os.stat('../dummy').st_atime == f_atime
    assert os.stat('../dummy').st_mtime == f_mtime
    #

# Generated at 2022-06-26 13:40:19.109771
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    paths = ['/dev/null', 'c:\\Windows\\System32\\bitlocker.dll']
    for path in paths:
        try:
            os.utime(encodeFilename(path), (0, 0))
        except PermissionError:
            post_processor = PostProcessor()
            post_processor.try_utime(path, 0, 0)
        except OSError:
            pass


# Generated at 2022-06-26 13:40:24.094598
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import YoutubeDL

    post_processor_0 = PostProcessor(YoutubeDL())
    post_processor_0.try_utime('abc', 1, 1)


# Generated at 2022-06-26 13:40:29.542054
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

    try:
        post_processor_0.try_utime('sample_path',1476234654.05,1476234654.05,'Cannot update utime of file')
    except PostProcessingError as err:
        assert(False)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:39.114370
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test for case when os.utime fails
    post_processor = PostProcessor()
    post_processor.try_utime('test', 1, 2, 'Cannot update utime of file')
    # Test for case when os.utime succeeds
    post_processor.try_utime('test', 1, 2, 'Cannot update utime of file')
    # Test for case when file name is in unicode
    post_processor.try_utime('非常好', 1, 2, 'Cannot update utime of file')

# Generated at 2022-06-26 13:40:49.386499
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os.path
    test_file = '/tmp/test_file.mp4'
    test_file_encoded = encodeFilename(test_file)
    try:
        open(test_file_encoded, 'w').close()
        post_processor_1 = PostProcessor()
        post_processor_1.try_utime(test_file, 0.0, 0.0)
        os.remove(test_file_encoded)
    except Exception as e:
        raise AssertionError('unexpected exception thrown: ' + str(e))

# Generated at 2022-06-26 13:40:59.407321
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    try:
        # TODO:
        #assert post_processor_1.try_utime(path, atime, mtime)
        assert True
    except NotImplementedError as e:
        raise(e)
    except Exception:
        print('line: {}'.format(sys.exc_info()[-1].tb_lineno))
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-26 13:41:10.533506
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test when utime works
    path = 'C:\\Users\\user\\Music\\SomeSong.flac'
    atime = 5
    mtime = 10
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, atime, mtime)
    # Test when utime does not work
    path = 'C:\\Users\\user\\Music\\SomeSong.flac'
    atime = 5
    mtime = 10
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path, atime, mtime)

# Generated at 2022-06-26 13:41:17.680954
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('/Users/kunkka/Downloads/ixigua_vlist.txt', 0, 0, 'Cannot update utime of file')
    except IOError as e:
        pass


# Generated at 2022-06-26 13:41:20.746233
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path="test_path", atime=30, mtime=30, errnote="test_errnote")


# Generated at 2022-06-26 13:41:46.861806
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This test FAILS
    import time
    import os
    import sys
    import tempfile


    class MockDownloader(object):
        def report_warning(self, message):
            pass


    mimetype = 'video/webm; codecs="vp8.0, vorbis"'
    path = tempfile.mkstemp(suffix='.%s' % mimetype.split('/')[1])[1]
    post_processor_0 = PostProcessor(MockDownloader())

    # atime = time.time()
    mtime = time.time() - 24 * 3600 * 140
    post_processor_0.try_utime(path, mtime, mtime)

# Generated at 2022-06-26 13:41:52.731142
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class FakeDownloader():
        def __init__(self):
            self.params = {}

        def report_warning(self, errnote):
            print(errnote)

    post_processor_1 = PostProcessor(downloader=FakeDownloader())
    post_processor_1.try_utime('No_such_path', 1, 1)

    if __name__ == '__main__':
        test_case_0()
        test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:59.346108
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file_name = 'test_file'
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(file_name, 4, 3, 'Exception thrown')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:42:01.749307
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(None, None, None,None)


# Generated at 2022-06-26 13:42:13.559824
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test with invalid path and valid atime and mtime.
    invalid_path = "./invalid_path.mp4"
    test_atime = -1 # int
    test_mtime = 1000000000 # long
    expected_errnote = 'Cannot update utime of file'
    post_processor_1 = PostProcessor()
    exception_thrown = False
    try:
        error_note = post_processor_1.try_utime(invalid_path, test_atime, test_mtime)
    except Exception as exception:
        exception_thrown = True
        if exception.__class__.__name__ == 'PostProcessingError':
            assert exception_thrown and exception.message == expected_errnote
        else:
            assert exception_thrown


# Generated at 2022-06-26 13:42:21.683216
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # Possible scenarios
    post_processor.try_utime('-1', 1, 1)
    post_processor.try_utime('-1', -1, 1)
    post_processor.try_utime('-1', 1, -1)

import unittest


# Generated at 2022-06-26 13:42:27.486989
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Unit-test for method try_utime of class PostProcessor
    pp = PostProcessor()
    from types import ListType
    from test_utils import FakeYDL
    # Create a file to modify
    import urllib
    file_name = os.path.join(os.path.dirname(os.path.realpath(__file__)), "test_post_processor.tmp")
    urllib.urlretrieve("http://www.youtube.com/watch?v=BaW_jenozKc",file_name)
    # Set the file to read-only.
    os.chmod(file_name,400)
    # Modify mtime and atime of file.
    import time
    mtime = time.time()-7777
    atime = time.time()-2424
    # Change the file

# Generated at 2022-06-26 13:42:35.660903
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .testutils import TestDeprecationUtils
    import datetime
    import os
    import re
    import sys
    import tempfile
    import unittest
    # Create an instance of PostProcessor Class
    post_processor_0 = PostProcessor()
    # Create an instance of TestDeprecationUtils Class
    test_deprecation_utils_0 = TestDeprecationUtils()
    # Inject TestDeprecationUtils into PostProcessor
    post_processor_0.test_deprecation_utils = test_deprecation_utils_0
    # Write contents in a temp file
    temp_file_0 = tempfile.NamedTemporaryFile(delete=True)
    temp_file_0.write(b'hello')
    # Test try_utime method
    post_processor_0.try_

# Generated at 2022-06-26 13:42:41.892226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(b'test_file.txt', time.time(), time.time())

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:46.357967
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Constructor call
    post_processor_1 = PostProcessor()
    # Constructor call with arguments
    post_processor_2 = PostProcessor()
    path_1 = 'file.mp4'
    atime_1 = 2
    mtime_1 = 2
    errnote_1 = 'Cannot update utime of file'
    post_processor_2.try_utime(path_1, atime_1, mtime_1, errnote_1)


# Generated at 2022-06-26 13:43:12.293331
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path_1 = '/path/to/file'
    atime_1 = 20000
    mtime_1 = 30000
    errnote_1 = 'Could not update atime of file'
    post_processor_1.try_utime(path_1, atime_1, mtime_1, errnote_1)

# Generated at 2022-06-26 13:43:15.213549
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()  # invoke constructor

    assert True  # FIXME: implement your test here

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:43:22.530350
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'C:/Users/kai/AppData/Local/Temp/2/tmp5i72uvw/test.txt'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, 0, 0)
# Test method run of class PostProcessor

# Generated at 2022-06-26 13:43:27.554891
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = '/test/test'
    atime = 1
    mtime = 2
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)

# unit test for method "_configuration_args" of class PostProcessor

# Generated at 2022-06-26 13:43:28.282223
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:43:32.349900
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime(__file__, 0, 0) == None
