

# Generated at 2022-06-26 13:33:38.950163
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime("C:\\Users\\jferr\\Documents\\test_postprocessor\\test.txt", 0, 0)


# Generated at 2022-06-26 13:33:46.445372
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file_path = 'filename'
    atime = 1
    mtime = 2
    errnote = 'Error Note'
    post_processor_0 = PostProcessor()
    exception_0 = PostProcessingError('Error')
    post_processor_0.try_utime(file_path, atime, mtime, errnote)

# Generated at 2022-06-26 13:33:49.679480
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # Replace 'pass' with test code
    post_processor.try_utime(('', ''), ('', ''), ('', ''))
    return

# Generated at 2022-06-26 13:33:58.229191
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'path'
    atime_0 = 0
    mtime_0 = 0
    errnote_0 = 'errnote'
    try:
        os.utime(encodeFilename(path_0), (atime_0, mtime_0))
    except Exception:
        post_processor_0._downloader.report_warning(errnote_0)


# Generated at 2022-06-26 13:34:01.418489
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        assert isinstance(post_processor_0.try_utime('path', 0, 0, 'errnote'), tuple)
    except Exception:
        raise PostProcessingError('Cannot update utime of file')


# Generated at 2022-06-26 13:34:04.672538
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()
    test_PostProcessor_try_utime_0()


# Generated at 2022-06-26 13:34:16.757576
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    check the try_utime method of the PostProcessor class works correctly.

    The unit test assumes that the function os.utime is tested in isolation
    by the python package. The function os.utime is mocked by a lambda method
    to throw an exception on purpose.
    """
    from unittest import TestCase
    from unittest.mock import patch
    import tempfile

    class MockDownloader(object):
        def __init__(self):
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)
    with tempfile.NamedTemporaryFile() as tmp_file:
        # Arrange
        downloader = MockDownloader()
        post_processor = PostProcessor(downloader)

        # Act

# Generated at 2022-06-26 13:34:24.041008
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    In this testcase we will test method try_utime of class PostProcessor
    The test scenario is that we will try to update utime (the last modified time of a file)
    of a file and check whether the utime is being updated
    """
    import os
    import time
    import unittest
    class PostProcessor_try_utime_test(unittest.TestCase):
        """
        In this testcase, we will try to update utime (the last modified time of a file)
        of a file and check whether the utime is being updated
        """
        def testcase_try_utime(self):
            """
            This testcase is to test method try_utime of class PostProcessor
            """

# Generated at 2022-06-26 13:34:31.266759
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor() # test with and without downloader
    post_processor_2 = PostProcessor()
    post_processor_2.set_downloader(object())
    for pp in (post_processor_1, post_processor_2):
        pp.try_utime('unit_test_file', 0, 0)

# Generated at 2022-06-26 13:34:37.166572
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    path = "test_PostProcessor_try_utime_path"
    atime = 1
    mtime = 2
    postProcessor.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:34:43.074922
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    post_processor = PostProcessor()
    file = tempfile.TemporaryFile(mode='w+b')
    file.close()

    filename = file.name
    post_processor.try_utime(filename, 0, 0)
    # Check that no error was thrown



# Generated at 2022-06-26 13:34:51.798855
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'test.mp4'
    path_1 = encodeFilename(path_0)
    post_processor_0.try_utime(path_1, 120, 125, 'Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:02.780070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # DEFAULT_TIMEOUT_TRAVIS = 30
    post_processor = PostProcessor()
    path = 'path'
    atime = 1434353971.0
    mtime = 1434353971.0
    errnote = 'Cannot update utime of file'
    post_processor.try_utime(path, atime, mtime, errnote)

    # print("\nTEST completed")
# test_case_0()
# test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:14.724155
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_try_utime_obj = PostProcessor()
    post_processor_try_utime_path = r"test_path"
    post_processor_try_utime_atime = 1000000.0
    post_processor_try_utime_mtime = 1000000.0
    post_processor_try_utime_errnote = r"test_errnote"
    post_processor_try_utime_obj.try_utime(post_processor_try_utime_path, post_processor_try_utime_atime, post_processor_try_utime_mtime, post_processor_try_utime_errnote)



# Generated at 2022-06-26 13:35:23.553834
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'G1DyRRp.PU'
    atime_0 = 0.0
    mtime_0 = 0.0
    errnote_0 = 'Cannot update utime of file'
    assert post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0) == None


# Generated at 2022-06-26 13:35:27.341771
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    # dummpy data
    path = 'video.avi'
    atime = 1000
    mtime = 2000
    # call the testing method
    post_processor.try_utime(path, atime, mtime)

# Test method run of class PostProcessor

# Generated at 2022-06-26 13:35:37.828101
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    from datetime import datetime
    post_processor_0.try_utime('path', datetime.now(), datetime.now())


test_cases_PostProcessor = [
    test_case_0,
    test_PostProcessor_try_utime,
]

if __name__ == "__main__":
    for test_case in test_cases_PostProcessor:
        print(test_case)
        test_case()
        print('****************************************************************************')
else:
    from ..YoutubeDL import YoutubeDL
    ydl_post_processor = YoutubeDL(params={})
    PostProcessor.set_downloader(ydl_post_processor)

# Generated at 2022-06-26 13:35:45.973211
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path_1 = pathlib.Path('Desktop/Bugs_Bunny/Play_Pen.txt')
    atime_1 = int()
    mtime_1 = int()
    errnote_1 = str()
    post_processor_1.try_utime(path_1, atime_1, mtime_1, errnote_1)


# Generated at 2022-06-26 13:35:55.190515
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import pytest

    # create a test file with the current time
    test_path = 'test_file.txt'
    open(encodeFilename(test_path), 'w').close()
    os.utime(encodeFilename(test_path), None)

    # test with current time
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(test_path, None, None)
    cur_atime = time.time()
    cur_mtime = cur_atime
    assert abs(os.path.getatime(encodeFilename(test_path)) - cur_atime) < 1.0
    assert abs(os.path.getmtime(encodeFilename(test_path)) - cur_mtime) < 1.0

    # test with

# Generated at 2022-06-26 13:36:02.338764
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime("undefined", None)
    except Exception:
        import pytest
        pytest.fail("utime call with undefined argument failed")


if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:15.054024
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = ''
    atime_0 = 0
    mtime_0 = 0
    errnote_0 = ''
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:25.313081
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    with open('./test/postprocessor.txt', 'w') as file_0:
        file_0.write('test')
    os.utime('./test/postprocessor.txt', None)
    post_processor_0.try_utime('./test/postprocessor.txt', 0, 0, 'Cannot update utime of file')
    os.remove('./test/postprocessor.txt')



# Generated at 2022-06-26 13:36:29.051017
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert post_processor_1.try_utime('',0,0,'') == None


# Generated at 2022-06-26 13:36:32.770387
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = object()
    downloader.report_warning = lambda x: x
    post_processor_1 = PostProcessor()
    post_processor_1.set_downloader(downloader)
    args = str('')
    output = post_processor_1.try_utime(args, args, args, args)


# Generated at 2022-06-26 13:36:38.239733
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert not post_processor_1.try_utime('', '', '', '')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:46.743168
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename(path='test_data/test_video'), atime=1512702937, mtime=1512702937)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:48.658532
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(None)
    path = '.'
    atime = 0.0
    mtime = 0.0
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:36:50.672309
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('./test_utime',1,2)


# Generated at 2022-06-26 13:36:57.763489
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path_0 = u'downloads/test'
    atime_0 = 0
    mtime_0 = 0
    post_processor_1.try_utime(path_0, atime_0, mtime_0)


# Generated at 2022-06-26 13:37:02.662109
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    path = 'file.py'
    atime = 10
    mtime = 20

    post_processor.try_utime(path, atime, mtime)

# Generated at 2022-06-26 13:37:10.746267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'somewhere'
    atime_0 = 42
    mtime_0 = 42
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:37:19.610354
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_file_path = './unit_test_files/utime_test_file.txt'
    open(test_file_path, 'a').close()
    test_pp = PostProcessor()
    test_pp.try_utime(test_file_path, 10, 0)
    assert os.stat(test_file_path).st_atime == 10
    assert os.stat(test_file_path).st_mtime == 0
    os.remove(test_file_path)


# Generated at 2022-06-26 13:37:30.547514
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test case 1: Try to update utime of a file
    dl1 = downloader.YoutubeDL()
    tmp_ini_file1 = tempfile.NamedTemporaryFile(suffix=".ini", delete=False)
    tmp_ini_file1.write(b'[YoutubeDL]\nformat=bestaudio\npostprocessor_args=["-vn"]')
    tmp_ini_file1.close()
    dl1.params["config_filename"] = tmp_ini_file1.name

    tmp_file1 = tempfile.NamedTemporaryFile(delete=False)
    tmp_file1.close()
    t1 = ModifiedDateTest(tmp_file1.name, dl1)
    t1.start()

# Generated at 2022-06-26 13:37:32.006832
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("path", "atime", "mtime")


# Generated at 2022-06-26 13:37:35.135430
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_2 = PostProcessor()
    file_path_0 = 'C:\\Users\\Admin-PC.PMCLAB\\Music\\ajit\\Cococomic\\115.mp4'
    # Path exists
    assert os.path.exists(file_path_0)
    post_processor_2.try_utime(file_path_0, 0, 0)
    # os.utime method works

# Generated at 2022-06-26 13:37:38.063576
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    file_path_0 = '/Users/deeplas/Downloads/downloading/Downloading-Part2-final.mp4'
    time_0 = os.path.getmtime(file_path_0)
    time_1 = os.path.getmtime(file_path_0)
    post_processor_0.try_utime(file_path_0, time_0, time_1, "Cannot update utime of file")


# Generated at 2022-06-26 13:37:41.074384
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    result = post_processor_0.try_utime("","","")


# Generated at 2022-06-26 13:37:47.971391
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("test_file_0", 0, 0, "test_errnote_0")
    
if __name__ == '__main__':
    # test_case_0()
    # test_PostProcessor_try_utime()
    pass

# Generated at 2022-06-26 13:37:56.791215
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'ZiYug.mp4'
    atime = 1454189575
    mtime = 1454189575
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:38:04.579420
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    if post_processor_0.try_utime("./test_file", 0, 0, "Cannot update utime of file") != None:
        raise Exception
    if post_processor_0.try_utime("./test_file", 0, 0, "Cannot update utime of file") != None:
        raise Exception
    if post_processor_0.try_utime("./test_file", 0, 0, "Cannot update utime of file") != None:
        raise Exception



# Generated at 2022-06-26 13:38:17.114237
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('./file.txt', None, None)
    except Exception as exception:
        print(str(exception))


# Generated at 2022-06-26 13:38:27.431011
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Instantiate an instance of class PostProcessor with an assignation of an instance of class FileDownloader
    # to the field _downloader of the just instantiated class
    # The just instantiated instance of class PostProcessor would be a field of the instance of class FileDownloader,
    # when the post_processor method of class FileDownloader is called
    post_processor_1 = PostProcessor(FileDownloader())
    # Create an instance of class PostProcessingError with the message args
    post_processing_error_1 = PostProcessingError('args')
    # Get the result of calling the method try_utime of class PostProcessor with as parameter
    # the instance of class PostProcessingError with the message args
    post_processor_1.try_utime(post_processing_error_1)

    # Create an instance of class PostProcessingError

# Generated at 2022-06-26 13:38:33.035344
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = 'E:/Downloads/Test'
    atime = 1531280347.0
    mtime = 1531280347.0
    errnote='Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:38:42.735299
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    file_path = 'test_file'
    post_processor.try_utime(file_path, 100, 100, 'Cannot update utime of file')
    # file 'test_file' does not exist, so exception will be raised
    post_processor.try_utime(file_path, 100, 100, 'Cannot update utime of file')
    # return 
    return 0

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:54.273967
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'path'
    atime_0 = 1
    mtime_0 = 2
    errnote_0 = 'errnote'
    post_processor_0.try_utime(path_0, atime_0, mtime_0)
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote='Cannot update utime of file')
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote='Cannot update utime of file')

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:00.816031
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:39:03.906397
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('a', 1, 1, 'a')
    except:
        raise Exception("try_utime() fails")


# Generated at 2022-06-26 13:39:14.172275
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'test_PostProcessor_try_utime'
    atime_0 = 'test_PostProcessor_try_utime'
    mtime_0 = 'test_PostProcessor_try_utime'
    errnote_0 = 'test_PostProcessor_try_utime'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:39:26.873367
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    import sys
    import tempfile
    import os
    import os.path
    import shutil
    import errno

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix='youtubetest-')
            self.temppath = os.path.join(self.tmpdir, 'temppath.txt')
            self.dir_temppath = os.path.join(self.tmpdir, 'dirtemppath')
            self.f = open(self.temppath, 'w')
            self.f.close()
            self.mtime = 1408962974.0 #"2014-08-21 19:09:34.00000"
            self.atime = 1408962975.0

# Generated at 2022-06-26 13:39:30.983694
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(path=None, atime=None, mtime=None, errnote=None)



# Generated at 2022-06-26 13:39:43.772675
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime(
        '',
        '',
        '') == None


# Generated at 2022-06-26 13:39:46.637531
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    ret_value = post_processor.try_utime('path', 'atime', 'mtime', 'errnote=')

# Generated at 2022-06-26 13:39:57.438508
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    with tempfile.NamedTemporaryFile('wb', prefix="test_PostProcessor_try_utime-", suffix=".txt") as fp:
        new_atime = 10010
        new_mtime = 10011
        os.utime(fp.name, (new_atime, new_mtime))
        pp = PostProcessor()
        pp.try_utime(fp.name, 1, 10)
        statinfo = os.stat(fp.name)
        assert(statinfo.st_atime == new_atime)
        assert(statinfo.st_mtime == new_mtime)

# Generated at 2022-06-26 13:40:04.368111
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0._downloader.report_warning = lambda x:x
    post_processor_0.try_utime("""C:\\Users\\mahui\\Documents\\GitHub\\you-get\\doc\\source\\_static""","","","")

# Generated at 2022-06-26 13:40:07.149958
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_10 = PostProcessor()
    post_processor_10.try_utime('test_video.avi', 100, 100)


# Generated at 2022-06-26 13:40:17.805739
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    exist = 0
    if os.path.exists('/tmp/test'):
        exist = 1
    file = open('/tmp/test', 'w')
    file.write('test file')
    file.close()
    post_processor_0.try_utime('/tmp/test', 0, 0, 'Cannot update utime of file')
    if exist == 0:
        os.remove('/tmp/test')


if __name__ == '__main__':
    print('Cannot be run independently')

# Generated at 2022-06-26 13:40:24.106879
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'test_path'
    atime = 1
    mtime = 1
    errnote = 'test_errnote'
    post_processor_0.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:40:26.388687
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1._downloader = None  # TODO: mock
    assert post_processor_1.try_utime('path', 'atime', 'mtime', 'errnote') is None


# Generated at 2022-06-26 13:40:30.248359
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, 1, 2, 'Cannot update utime of file')



if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:39.589780
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test.')
    path = os.path.join(temp_dir, 'tmp.txt')
    with open(path, 'w') as f:
        f.write('test')
    t0 = os.stat(path).st_mtime

    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path, 0, 0)

    t1 = os.stat(path).st_mtime
    assert t1 > t0

# Generated at 2022-06-26 13:40:53.246534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Test case for try_utime with original filename
    post_processor_1 = PostProcessor()
    try:
        post_processor_1.try_utime("/home/sajal/Desktop/lwp-tutorial/1.html", 0, 0, "")
    except Exception as e:
        assert False, "try_utime failed with original filename"

    # Test case for try_utime with special characters
    post_processor_2 = PostProcessor()
    try:
        post_processor_2.try_utime("/home/sajal/Desktop/lwp-tutorial/{}-{}-{}-{}".format("chat", "#", "$", "&"), 0, 0, "")
    except Exception as e:
        assert False, "try_utime failed with special characters in the filename"

# Generated at 2022-06-26 13:40:57.508542
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    assert pp.try_utime('path', 1, 2, 'Cannot update utime of file') == None


# Generated at 2022-06-26 13:41:02.092271
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test with a good path
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime("test", 0, 0)
    # Test with a bad path    
    post_processor_2 = PostProcessor()
    post_processor_2.try_utime("test/test", 0, 0)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:10.279631
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # PostProcessor.try_utime should raise a PostProcessingError given a path that does not exists
    post_processor_1 = PostProcessor()
    test_path = encodeFilename('/home/test/test.avi')
    try:
        post_processor_1.try_utime(test_path, 123, 123)
        assert False
    except PostProcessingError:
        assert True


# Generated at 2022-06-26 13:41:22.462082
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_file_path = 'src/extractor/test/test_file.txt'
    try:
        os.remove(test_file_path)
    except:
        pass
    test_file = open(test_file_path, 'w')
    test_file.close()
    test_file_time = os.path.getmtime(test_file_path)
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(test_file_path, test_file_time+1, test_file_time+1, 'Cannot update utime of file')
    test_file_time = os.path.getmtime(test_file_path)
    assert test_file_time == test_file_time+1 and test_file_time == test_file_time+1

# Generated at 2022-06-26 13:41:25.589743
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime(None, 1, 2) == None


# Generated at 2022-06-26 13:41:30.411726
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    PostProcessor.try_utime(post_processor_0, 'cannot_update_utime_of_file', 'cannot_update_utime_of_file', 'cannot_update_utime_of_file')


# Generated at 2022-06-26 13:41:35.965474
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    expected_video_exten = "m4v"
    post_processor_0.try_utime("", "", "", "")


# Generated at 2022-06-26 13:41:40.700464
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(encodeFilename(u'Räksmörgås'), 0, 0)
# test_PostProcessor_try_utime()


# Generated at 2022-06-26 13:41:47.095045
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert isinstance(post_processor_0, PostProcessor)
    # Test path not exists
    post_processor_0.try_utime(None, None, None, 'Cannot update utime of file')


# Generated at 2022-06-26 13:42:13.622137
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    assert os.path.isfile("PostProcessor.py") is True
    #time.time() is float
    atime = time.time()
    mtime = time.time()
    post_processor_1.try_utime("PostProcessor.py",atime,mtime)
    assert os.path.isfile("PostProcessor.py") is True
    assert os.path.isdir("PostProcessor.py") is False


if __name__ == '__main__':
    post_processor_1 = PostProcessor()
    post_processor_1.run("PostProcessor.py")
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:22.500459
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'https://www.youtube.com/watch?v=L-5X5j5H5QQ'
    atime = 1.00014806
    mtime = 1.00014806
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:42:25.804944
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(1, 2, 3, 4)



# Generated at 2022-06-26 13:42:32.304122
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_1 = PostProcessor()
    post_processor_2 = PostProcessor()
    if post_processor_1.try_utime('Test', -1, -1, 'Test', -1) != 0:
        raise AssertionError('return_value != 0')


# Generated at 2022-06-26 13:42:37.025658
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    tmp_dir = './tmp/'
    os.makedirs(tmp_dir)
    open(tmp_dir+'test.txt', 'w').close()
    post_processor_0.try_utime(tmp_dir+'test.txt', 1, 2)
    import os.path
    import time
    stat_info = os.stat(tmp_dir+'test.txt')
    os.remove(tmp_dir+'test.txt')
    os.removedirs(tmp_dir)
    assert stat_info.st_atime == 1 and stat_info.st_mtime == 2


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    test_case_0()
    test_PostProcess

# Generated at 2022-06-26 13:42:44.980557
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # initialization
    post_processor_0 = PostProcessor()
    path_1 = 'check.txt'
    atime_0 = 17
    mtime_1 = 18
    path_0 = 'check.txt'
    errnote_0 = 'Some message'

    post_processor_0.try_utime(path_1, atime_0, mtime_1)
    post_processor_0.try_utime(path_0, atime_0, mtime_1, errnote_0)

# Testing configuration args method

# Generated at 2022-06-26 13:42:52.754990
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Setting user defined attributes for PostProcessor object
    post_processor_0.downloader = None
    try:
        post_processor_0.try_utime("file_name", 0.0, 0.0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 13:42:54.184526
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor();
    post_processor_0.try_utime("a", 1, 2);

# Generated at 2022-06-26 13:42:59.261391
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    expected = 'Cannot update utime of file'
    result = post_processor_0.try_utime(path, atime, mtime, errnote='Cannot update utime of file')
    assert result == expected


# Generated at 2022-06-26 13:43:03.100556
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('path', 'atime', 'mtime')
