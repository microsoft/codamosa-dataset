

# Generated at 2022-06-26 13:33:41.348053
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    postprocessor_0 = PostProcessor()
    # Test case where path exists, atime is a float, and mtime is an int
    try:
        postprocessor_0.try_utime('youtube-dl/__main__.py', 5.3, 44)
    except Exception as e:
        print('%s: %s' % (type(e), e))


# Generated at 2022-06-26 13:33:46.092041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test_file', 1.0, 1.0, 'Cannot update utime of file')


# Generated at 2022-06-26 13:33:49.510898
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(1.0, 2.0, 3.0)


# Generated at 2022-06-26 13:33:53.136324
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():    
    post_processor_0=PostProcessor()
    post_processor_0.try_utime("", "", "", "")


# Generated at 2022-06-26 13:34:01.110795
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    float_0 = 1.5
    # float_0 is float not bool
    try_utime(float_0)
    import os.path
    # path is not bool
    path = os.path.expanduser('/tmp/c8DuPR/')
    # path is not bool
    path = os.path.expanduser('/tmp/c8DuPR/')
    str_0 = 'Cannot update utime of file'
    # path is not bool
    try_utime(path, path, path, str_0)

# Generated at 2022-06-26 13:34:06.128938
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    int_0 = -1
    post_processor_0.try_utime(int_0, int_0, int_0)


# Generated at 2022-06-26 13:34:11.693120
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    float_0 = 1.008
    float_1 = 3.0
    float_2 = 3.0
    postprocessor_0 = PostProcessor()
    postprocessor_0.try_utime(float_0, float_1, float_2, 'Exception in try_utime')

# Generated at 2022-06-26 13:34:21.390676
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file_0 = 'j6Ue'
    float_0 = 1.6
    float_1 = 0.06
    exception_0 = PostProcessingError(file_0)
    string_1 = 'Cannot update utime of file'
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(file_0, float_0, float_1, string_1)
    post_processor_0.run(exception_0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:30.159067
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    str_6 = 'Cannot update utime of file'
    float_0 = -9.2
    try:
        post_processor_0.try_utime(str_6, float_0, float_0, str_6)
    except Exception:
        pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:38.026791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    string_0 = 'Cannot update utime of file'
    string_1 = 'Cannot update utime of file'
    postprocessor_0 = PostProcessor()
    atime_0 = 1.0
    mtime_0 = 9.2
    path_0 = ''
    postprocessor_0.try_utime(path_0, atime_0, mtime_0, string_0)
    atime_1 = -9.2
    mtime_1 = -1.0
    path_1 = ''
    postprocessor_0.try_utime(path_1, atime_1, mtime_1, string_1)
    postprocessor_0.try_utime(path_1, atime_1, mtime_1, string_1)
    return

# Generated at 2022-06-26 13:34:42.070904
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()


if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-26 13:34:43.696895
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:34:51.444935
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = 'file'
    atime = 1
    mtime = 1
    post_processor_self = PostProcessor()
    try:
        os.utime(encodeFilename(path), (atime, mtime))
    except Exception:
        post_processor_self._downloader.report_warning('Cannot update utime of file')

# Generated at 2022-06-26 13:34:58.715723
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    expected_utime_0 = None
    result_utime_0 = post_processor_1.try_utime('path', 'atime', 'mtime')
    assert result_utime_0 == expected_utime_0


# Generated at 2022-06-26 13:35:04.570683
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.downloader = TestDownloader()
    post_processor_0.try_utime('', '', '', 'Cannot update utime of file')
    post_processor_0.downloader.log_message.assert_called_with('[postprocessor] Cannot update utime of file')


# Generated at 2022-06-26 13:35:13.325008
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = '2'
    atime_0 = 1585167261.4165518
    mtime_0 = 1585167261.4165518
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:35:27.058875
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os

    from . import FakeYDL
    from .extractor.youtube import YoutubeIE
    from .postprocessor.metadatafromtitle import MetadataFromTitlePP
    from .postprocessor.xattrpp import XAttrMetadataPP
    from .postprocessor.ffmpeg import FFmpegMetadataPP
    from .postprocessor.execafterdownload import ExecAfterDownloadPP

    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(FakeYDL())
    post_processor_0.try_utime('', 1, 2)

    post_processor_1 = FFmpegMetadataPP()
    post_processor_1.set_downloader(FakeYDL())
    post_processor_1._configuration_args()
    post_processor_1._configuration_args()

    post_processor_2 = XAtt

# Generated at 2022-06-26 13:35:34.027599
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('/tmp/yt_temp/test', 12, 12)
    post_processor_0.try_utime('/tmp/yt_temp/test', 12, 12, 'Cannot update utime of file')

# Generated at 2022-06-26 13:35:38.606138
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test for positive case
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('./post_processor.py', 1222794821.0, 1222794821.0)
    # Test for negative case
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('./utime.py', 1222794821.0, 1222794821.0)


# Generated at 2022-06-26 13:35:45.532757
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    path = './community/__init__.py'
    atime = 1.0
    mtime = 1.0
    errnote = 'Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:35:51.736130
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    a = PostProcessor()
    b = [100,100]
    a.try_utime('test_case_0.py', b[0], b[1])

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:53.939788
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('path', 100, 100, errnote='x')


# Generated at 2022-06-26 13:35:56.317139
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create an instance of class PostProcessor
    post_processor_0 = PostProcessor()


# Generated at 2022-06-26 13:36:02.473869
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime("filedoesnotexist", 0, 0)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:06.866342
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = ''
    atime = 0
    mtime = 0
    errnote = ''
    try:
        os.utime(path, (atime, mtime))
    except Exception:
        post_processor_0._downloader.report_warning(errnote)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:19.094884
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import FileDownloader

    fd = HttpFD(None, {}, '../..')
    ie = InfoExtractor(FileDownloader())
    pp = PostProcessor(None)

    # Parameters like the ones used in class YoutubeDL
    pp.set_downloader(FileDownloader(params=dict(format='best', format_limit=20, outtmpl='./video.%(ext)s')))
    pp.run(dict(filepath=fd, ext='mp4', fulltitle='Video by YouTube', id='8fA7VyBR1JE'))

    # Parameters like the ones used in class YoutubeDL

# Generated at 2022-06-26 13:36:23.042797
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        raise NotImplementedError
    except Exception:
        pass


if __name__ == "__main__":
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:27.035919
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import os.path
    import tempfile
    if not os.path.isdir(tempfile.gettempdir()):
        # TODO: create fake dir and delete when done
        return
    import shutil
    tempdir = tempfile.mkdtemp(prefix='yt-yt-download-test', dir=tempfile.gettempdir())

# Generated at 2022-06-26 13:36:32.502240
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'test.txt'
    atime = 1
    mtime = 2
    errnote = 'test'
    post_processor_0.try_utime(path, atime, mtime, errnote)


# Generated at 2022-06-26 13:36:36.420794
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(__file__, 0, 0)


# Generated at 2022-06-26 13:36:42.221375
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path=None, atime=1, mtime=1, errnote='errnote')


# Generated at 2022-06-26 13:36:46.499686
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Default value
    post_processor_0 = PostProcessor()
    path_0 = str()
    atime_0 = float()
    mtime_0 = float()
    post_processor_0.try_utime(path_0, atime_0, mtime_0)


# Generated at 2022-06-26 13:36:54.762360
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from .test_utils import TEST_FILE

    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(encodeFilename(TEST_FILE), 1, 2, errnote='post_processor_0_err')
    assert True  # when using this format, it is necessary to assert True at end of function



# Generated at 2022-06-26 13:36:58.011836
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('file_name', 2, 1)

# Generated at 2022-06-26 13:37:08.139147
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.utils.utime = lambda path, a,b : True
        post_processor_0.try_utime('path', 'a', 'b')
    except Exception:
        pass
    try:
        post_processor_0.utils.utime = lambda path, a,b : False
        post_processor_0.try_utime('path', 'a', 'b')
    except Exception:
        pass


# Generated at 2022-06-26 13:37:18.458274
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from pytube.downloader import Downloader

    path = 'test/test_PostProcessor_try_utime'
    downloader = Downloader()
    downloader.download('http://example.com')
    post_processor = PostProcessor(downloader)
    post_processor.try_utime(path, 0, 0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:21.313992
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.run({})


# Generated at 2022-06-26 13:37:28.561283
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # this is a test for try_utime method of class PostProcessor

    # making a PostProcessor class object
    post_processor_0 = PostProcessor()

    # accessing the method
    post_processor_0.try_utime(path="e:\YouTube-DL\Video\Guns N' Roses - Sweet Child O' Mine (Official Music Video).mp3", atime=None, mtime=None, errnote=None)



# Generated at 2022-06-26 13:37:35.512885
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime('', '', '', 'Cannot update utime of file')
    except Exception as e:
        print('Caught exception: ' + str(e))
        raise

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:38.688816
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime(path='path', atime=1, mtime=2)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:49.164669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('path/path/path', 'atime', 'mtime', 'Cannot update utime of file')

# Generated at 2022-06-26 13:37:49.885122
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()


# Generated at 2022-06-26 13:37:59.195545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('\u3053\u3093\u306b\u3061\u306f\uff0f\u65e5\u672c\u8a9e\u5b66\u7fd2\u52c9\u5f37\u4f1a', 1501962504.0, 1501962504.0, 'Cannot update utime of file')



# Generated at 2022-06-26 13:38:07.954767
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    self = post_processor_1
    path = 'test.txt'
    atime = 1525113617
    mtime = 1525113618
    errnote = 'Cannot update utime of file'
    post_processor_1.try_utime(path, atime, mtime, errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:38:11.705199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    f = '/usr/share/locale/en_US/en_US.mo'
    atime = 'w'
    mtime = 'q'
    assert post_processor_0.try_utime(f, atime, mtime) == None

# Generated at 2022-06-26 13:38:24.984366
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # See: https://github.com/rg3/youtube-dl/issues/11018
    from .pytest_resolve_tests import open, mtimesleep
    from tempfile import mkdtemp
    import time
    import shutil
    tmpdir = mkdtemp()
    fpath = os.path.join(tmpdir, 'file')
    mtime = time.time()
    mtimesleep(fpath)
    with open(fpath, 'wb') as f:
        f.write(b'video')
    assert os.stat(fpath).st_mtime == mtime

    postProcessor = PostProcessor()
    postProcessor.try_utime(fpath, mtime, mtime + 10)
    assert os.stat(fpath).st_mtime == mtime + 10

    shutil.rmt

# Generated at 2022-06-26 13:38:31.538974
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('abc', 1, 2, errnote='Cannot update utime')
    post_processor_0.try_utime('abc', 1, 2, errnote='Cannot update utime')


# Generated at 2022-06-26 13:38:35.394679
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:44.691130
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    data = {'_downloader': 'test_downloader'}
    path_0 = 'path_0'
    atime_0 = 'atime_0'
    mtime_0 = 'mtime_0'
    errnote_0 = 'errnote_0'
    post_processor_0 = PostProcessor()
    for i in range(0, 6):
        if callable(post_processor_0.try_utime):
            post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:48.172035
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test for constructor of class PostProcessor


# Generated at 2022-06-26 13:39:11.677501
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_000 = PostProcessor()
    path_000 = ''
    atime_000 = 0
    mtime_000 = 0
    errnote_000 = ''
    return post_processor_000.try_utime(path_000, atime_000, mtime_000, errnote_000)


# Generated at 2022-06-26 13:39:17.614809
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL

    post_processor_0 = PostProcessor()
    ydl = YoutubeDL()
    post_processor_0.set_downloader(ydl)
    post_processor_0.try_utime(encodeFilename(encodeFilename('../YoutubeDL/__main__.py')), 0.0, 0.0, 'Error')


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:39:24.234189
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("", 0.0, 0.0, "")


if __name__ == "__main__":
    import sys
    import unittest

    reload(sys)
    sys.setdefaultencoding("utf-8")

    unittest.main()

# Generated at 2022-06-26 13:39:26.914340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 13:39:28.025538
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-26 13:39:31.462519
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = "/tmp/path"
    atime_0 = 1488675075
    mtime_0 = 1488675075
    errnote_0 = "Cannot update utime of file"
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)



# Generated at 2022-06-26 13:39:33.249697
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        os.utime(None, 'Hb8')
    except Exception:
        pass
    else:
        post_processor_0.try_utime('GQ', '1', 'gU', 'v*')

# Generated at 2022-06-26 13:39:36.278482
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path=None, atime=None, mtime=None, errnote=None)

# Generated at 2022-06-26 13:39:42.591338
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # prepare the test case

    # invoke the method to be tested
    post_processor_1.try_utime(path="path", atime=1, mtime=1, errnote=str())


# Generated at 2022-06-26 13:39:51.151074
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    if not os.path.isdir("post_processor_test_data"):
        os.mkdir("post_processor_test_data")
    open("post_processor_test_data/test_file_0.txt", "w+").close()
    os.utime("post_processor_test_data/test_file_0.txt", (0, 0))
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime("post_processor_test_data/test_file_0.txt", 1, 1)
    except Exception:
        os.remove("post_processor_test_data/test_file_0.txt")
        os.rmdir("post_processor_test_data")
        raise

# Generated at 2022-06-26 13:40:09.080252
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    file_path = "file_path"
    atime = "atime"
    mtime = "mtime"
    errnote = "errnote"
    result = post_processor.try_utime(file_path, atime, mtime, errnote)


# Generated at 2022-06-26 13:40:19.813547
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    assert os.path.isfile(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.log')) == True
    post_processor.try_utime(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.log'), 0, 100)
    assert os.path.getatime(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.log')) == 0
    assert os.path.getmtime(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.log')) == 100


# Generated at 2022-06-26 13:40:24.170071
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("Desktop\sample", 0, 0, 'Cannot update utime of file')

# Generated at 2022-06-26 13:40:31.494920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.FileDownloader import FileDownloader
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_common import FakeDownloader
    from .test_InfoExtractor import (
        FakeInfoExtractor,
        basic_extract_info,
    )

    post_processor_0 = PostProcessor()
    file_downloader_0 = FileDownloader(FakeYDL(), {}, {'logger': FakeYDL()})
    fake_ie_0 = FakeInfoExtractor({'id': 'test_id', 'playlist': 'test_playlist'})
    fake_ie_1 = FakeInfoExtractor({'id': 'test_id', 'playlist': 'test_playlist'})

# Generated at 2022-06-26 13:40:36.302554
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass
    # Create a PostProcessor object
    # Use the method
    #assert ... == PostProcessor.try_utime(arg0, arg1, arg2, arg3)


# Generated at 2022-06-26 13:40:37.841912
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:40:39.328053
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('path',1,1)


# Generated at 2022-06-26 13:40:45.801334
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("hello world", 0, 1)
    post_processor_0.try_utime("hello world", 0, 1, "Cannot update utime of file")



# Generated at 2022-06-26 13:40:48.820086
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:54.601901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 0)
    post_processor_0.try_utime('', 0, 0, 'Cannot update utime of file')


# Generated at 2022-06-26 13:41:36.431041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('',1,2)
    except PostProcessingError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:46.123679
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_2 = PostProcessor()
    def set_downloader( self, downloader):
        self._downloader = downloader
    post_processor_2._downloader = None
    post_processor_2.set_downloader = set_downloader.im_func
    os.utime = object()
    try:
        post_processor_2.try_utime(None, None, None)
    except Exception:
        pass
    try:
        post_processor_2.try_utime(None, None, None)
    except Exception:
        pass
    try:
        post_processor_2.try_utime(None, None, None)
    except Exception:
        pass
    try:
        post_processor_2.try_utime(None, None, None)
    except Exception:
        pass

# Generated at 2022-06-26 13:41:50.149736
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime('/home/x/Downloads/video_test.mp4', 1524601958.0, 1524601958.0)


if __name__ == "__main__":
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:52.982721
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = 'test_path'
    atime = 0
    mtime = 0
    post_processor_0.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:42:01.157654
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def mock1_utime(file_name, atime, mtime):
        return None
    path = "filename"
    atime = "12345"
    mtime = 112345
    errnote = "Error"
    PostProcessor.os.utime = mock1_utime
    PostProcessor.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-26 13:42:11.796929
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from __main__ import PostProcessor
    pp = PostProcessor(None)
    test_path = '/home/user/file.mp4'
    pp.try_utime(test_path, 10, 20, 'Cannot update utime of file')
    # Testing with not existing path
    test_path = 'home/user/file.mp4'
    pp.try_utime(test_path, 10, 20, 'Cannot update utime of file')


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:19.444525
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import YoutubeDL
    from io import BytesIO
    post_processor_0 = PostProcessor(YoutubeDL())
    post_processor_0.try_utime('path', 1, 1, "Cannot update utime of file")
    return post_processor_0._downloader.to_stderr()

# Generated at 2022-06-26 13:42:23.077276
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try_utime_0_var = PostProcessor()
    try_utime_0_var.try_utime(path, atime, mtime, errnote='Cannot update utime of file')


# Generated at 2022-06-26 13:42:32.532609
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    t = PostProcessor()

    for filename in ['a.txt', 'b.txt', 'c.txt']:
        t.try_utime(filename, 1, 2)
        t.try_utime('', 0, 0)

        try:
            t.try_utime(filename, 0, 0)
        except:
            pass

        t.try_utime('', 2, 3)


if __name__ == '__main__':
    test_case_0()

    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:42:40.187962
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime(__file__, (0, 0))
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(__file__, 1, 1, 'error do nothing')
    post_processor_1.try_utime(__file__, 0, 0, 'error do nothing')
