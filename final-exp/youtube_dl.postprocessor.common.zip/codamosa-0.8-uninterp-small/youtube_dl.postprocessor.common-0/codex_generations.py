

# Generated at 2022-06-26 13:33:36.905816
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-26 13:33:41.494407
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    filepath = """H:\\test.exe"""
    atime = 1680891735
    mtime = 1680891735
    errnote = 'Cannot update utime of file'
    post_processor_0.try_utime(filepath, atime, mtime, errnote)


# Generated at 2022-06-26 13:33:46.243768
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Test for exception with out of range argument
    post_processor_1.try_utime('./test/test.mp4', 0, 0)

# Generated at 2022-06-26 13:33:53.396422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    import os
    import time
    import datetime
    # Test with a utime that is not in the past
    file_0 = NamedTemporaryFile(suffix='.txt')
    file_0.close()
    # Test that there is no error
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(file_0.name, time.time(), time.time(), 'error')
    # Test with a utime that is in the past
    before = datetime.datetime(1900, 1, 1, tzinfo=datetime.timezone.utc)
    after = datetime.datetime(2100, 1, 1, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 13:33:57.637313
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test that in case of exception, an informative message is displayed
    post_processor_0 = PostProcessor()
    # test case
    post_processor_0.try_utime("", 0, 0)


# Generated at 2022-06-26 13:33:58.823482
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()

# Generated at 2022-06-26 13:34:05.824679
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor_instance_0 = PostProcessor()
    PostProcessor_instance_0.try_utime("path", 0, 0, "errnote")

if __name__ == '__main__':
    # test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:17.355939
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    import time
    import sys
    import os

    if sys.version_info <= (2, 6):
        print('SKIP PostProcessor_try_utime test due to missing os.utime support on %s %s'
              % (sys.platform, sys.version.split(' ', 1)[0]))
        return

    with NamedTemporaryFile() as f:
        fn = f.name
        try:
            os.stat(fn)
        except OSError:
            # We're on Windows and the stat() call failed. This is normal
            return

        os.utime(fn, None)
        t1 = os.stat(fn).st_mtime
        time.sleep(0.1)
        post_processor = PostProcessor()
        t2 = os.stat

# Generated at 2022-06-26 13:34:22.811863
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    filepath = '/usr/local/bin/youtube-dl'
    atime = 1439851745
    mtime = 1447043593
    __args__ = ({'errnote': 'Cannot update utime of file'},)
    __result__ = post_processor_0.try_utime(filepath, atime, mtime)
    __expected__ = None
    assert __result__ == __expected__



# Generated at 2022-06-26 13:34:32.042969
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # AssertionError: None is not a string
    # try:
    #     post_processor_0.try_utime()
    # except AssertionError, e:
    #     print(e)
    post_processor_0.try_utime('', 0, 0)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:34:40.961901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..compat import compat_makedirs

    dl = Downloader(params={})
    dl.report_warning = lambda msg: print(msg)
    p = PostProcessor(dl)
    dirname = 'tests/test_try_utime'
    basename = os.path.join(dirname, 'test_file')
    filename = basename

# Generated at 2022-06-26 13:34:43.002205
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path='path', atime=1.36, mtime=1.36)


# Generated at 2022-06-26 13:34:52.882035
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('/home/ncw/yt-dl/yt_dl/postprocessor/tests/data/AvatarTheLastAirbenderIntro.webm',1424360456.0,1424360456.0)
    os.utime('/home/ncw/yt-dl/yt_dl/postprocessor/tests/data/AvatarTheLastAirbenderIntro.webm', (0, 0)) # Restore default access and modified dates

# Generated at 2022-06-26 13:34:57.052950
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('try_utime.py',0,0)

# Generated at 2022-06-26 13:35:02.776165
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(
        'test /home/ylbuzz/test/test.txt',
        0,
        0,
        'Cannot update utime of file',
    )

# Generated at 2022-06-26 13:35:10.059545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('.gitignore', 1479001666, 1479001666, 'Cannot update utime of file')

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:13.306272
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_unit_test_0 = PostProcessor()
    post_processor_unit_test_0.run(lambda: test_case_0())


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:27.060252
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
  import os
  import stat
  import time
  import unittest
  import tempfile
  import shutil
  from .YoutubeDL import YoutubeDL
  from .PostProcessor import PostProcessor

  pp = PostProcessor()
  temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-26 13:35:34.818754
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test file, class, & functions
    post_processor_0 = PostProcessor()
    # Test try_utime method
    post_processor_0.try_utime( "", 0, 0, "" )

# End: Test cases


if __name__ == "__main__":
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:35:40.558333
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    post_processor.try_utime('/home/jlucas/Desktop/python-youtube-dl/youtube_dl/__init__.py', '1467980391', '1467980391')


# Generated at 2022-06-26 13:35:46.941252
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test the method when there is no error
    try:
        post_processor_0.try_utime("test_path", 1, 1)
    except Exception:
        assert False
    try:
        post_processor_0.try_utime("test_path")
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-26 13:35:51.477255
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    filepath = r'd:/python/ytdownloader/ytdownloader/yt-dl.log'
    PostProcessor().try_utime(filepath, 2, 3)

if __name__ == '__main__':
    # test_PostProcessor_try_utime()

    test_case_0()

# Generated at 2022-06-26 13:35:58.936450
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    from ..downloader.common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from ..utils import DateRange
    from ..compat import compat_str

    import datetime
    import time
    import tempfile
    import os
    import shutil
    import subprocess
    import tempfile
    import unittest

    class MockFFmpegPostProcessor(FFmpegPostProcessor):
        def __init__(self, downloader, target_filename, before_video_id, after_video_id):
            super(MockFFmpegPostProcessor, self).__init__(downloader, target_filename, before_video_id, after_video_id)

            self.converted_file_path = ""


# Generated at 2022-06-26 13:36:03.729607
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Set up a PostProcessor
    post_processor_1 = PostProcessor()
    # Test the try_utime of post_processor_1
    post_processor_1.try_utime()



# Generated at 2022-06-26 13:36:05.926871
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    path = "/tmp/some_file.mp3"
    atime = 2534234
    mtime = 2534232

    post_processor = PostProcessor()

    # should not throw exception
    post_processor.try_utime(path, atime, mtime)

# Generated at 2022-06-26 13:36:09.697439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:36:19.181920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from sys import platform
    from os import utime, unlink, path, utime
    from youtube_dl.utils import encodeFilename

    if platform == 'win32':
        file_path = 'C:/1.mp4'
        with open(file_path, 'wb') as f:
            f.write('test')
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime(file_path, 0, 0, errnote='Cannot update utime of file')
        os.unlink(file_path)
    else:
        pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:36:23.115550
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_0 = PostProcessor()
        post_processor_0.try_utime()

    except NotImplementedError:
        pass

# Generated at 2022-06-26 13:36:26.759018
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    assert post_processor_0.try_utime('path', 'atime', 'mtime', errnote='Cannot update utime of file') is None

    return "Success"


# Generated at 2022-06-26 13:36:29.335110
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    assert None != post_processor.try_utime



# Generated at 2022-06-26 13:36:43.724100
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert os.path.exists('test_utime.txt') == True
    post_processor = PostProcessor()
    current_time = os.stat('test_utime.txt').st_atime
    post_processor.try_utime('test_utime.txt', current_time + 1, current_time + 1)
    assert os.stat('test_utime.txt').st_atime == current_time + 1
    assert os.stat('test_utime.txt').st_mtime == current_time + 1
    post_processor.try_utime('test_utime.txt', current_time, current_time)
    assert os.stat('test_utime.txt').st_atime == current_time
    assert os.stat('test_utime.txt').st_mtime == current_time

# Generated at 2022-06-26 13:36:49.196947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor_0 = PostProcessor()

    exception_0 = None

    try:
        postProcessor_0.try_utime(path=None, atime=None, mtime=None, errnote=None)
    except Exception as exception_0:
        pass

    assert exception_0 is not None



# Generated at 2022-06-26 13:36:51.609296
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(path="jqtL67q2XyM.mp4", atime=1041.3, mtime=1041.3)


# Generated at 2022-06-26 13:36:59.959346
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    if not os.path.exists('/tmp/test_PostProcessor_try_utime.txt'):
        with open('/tmp/test_PostProcessor_try_utime.txt', 'w'):
            pass
    post_processor_0 = PostProcessor()

    post_processor_0.try_utime('/tmp/test_PostProcessor_try_utime.txt', 1412403299, 1412403299, 'Cannot update utime of file')


# Generated at 2022-06-26 13:37:04.294158
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test_file_name.txt', None, None, 'Cannot update utime of file')

# Generated at 2022-06-26 13:37:08.347524
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    try:
        post_processor_0.try_utime('path', 'atime', 'mtime')
    except Exception:
        assert False


# Generated at 2022-06-26 13:37:18.901947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    path = os.path.abspath("./test_url.txt")
    with open(path, 'w') as fp:
        fp.write("test_url")
    atime = os.path.getatime(path)
    mtime = os.path.getmtime(path)
    post_processor_1 = PostProcessor()
    post_processor_1.try_utime(path, atime, mtime, "Cannot update utime")
    os.remove(path)


# Generated at 2022-06-26 13:37:29.421793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    try:
        import os
        import os.path
        import time
        # Create a temporary file to test method try_utime of class PostProcessor
        (fileDescriptor, path) = os.tmpfile()
        # Change the atime and mtime of the temporary file
        postProcessor.try_utime(path, time.time(), time.time())
        # Close the temporary file
        os.close(fileDescriptor)
        # Remove the temporary file
        os.remove(path)
    except Exception as inst:
        print("Cannot test method try_utime for PostProcessor.")
        print(inst)

# Generated at 2022-06-26 13:37:31.827457
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 13:37:37.751795
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('0', 122063217.05, 122063217.05, '0', 122063217.05, 122063217.05)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:50.810380
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object for testing
    post_processor_1 = PostProcessor()
    # Initialize the path with r'C:/Users/' for testing
    path = r'C:/Users/'
    # This try-except block is executed to verify that the method return the correct path
    try:
        post_processor_1.try_utime(path, 100, 100)
    except:
        pass
    else:
        assert(path == r'C:/Users/')
# Unit test method test_case_0 ends here
# Unit test method test_PostProcessor_try_utime ends here

# Start the unit test
test_case_0()
test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:37:58.763139
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    # Test case configuration
    path_0 = '~/test.py'
    atime_0 = 1028
    mtime_0 = 816
    # Call the method under test
    post_processor_0.try_utime(path_0, atime_0, mtime_0)


# Generated at 2022-06-26 13:38:02.418444
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_case_0()


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:38:11.914632
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    test_file = 'test.txt'
    with open(test_file, 'wb') as f:
        f.write('test'.encode('utf-8'))
    utime, mtime = os.stat(test_file).st_atime, os.stat(test_file).st_mtime
    post_processor_0.try_utime(test_file, utime, mtime)
    with open(test_file, 'rb') as f:
        assert f.read() == 'test'.encode('utf-8')
    os.remove(test_file)

# Generated at 2022-06-26 13:38:23.142454
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = '-1'
    atime_0 = -2.0
    mtime_0 = -1.0
    post_processor_0.try_utime(path_0, atime_0, mtime_0, 'Cannot update utime of file')
    path_1 = 'C:\\Users\\admin\\Documents\\GitHub\\youtube-dl\\__main__.py'
    post_processor_0.try_utime(path_1, atime_0, mtime_0, 'Cannot update utime of file')



# Generated at 2022-06-26 13:38:25.817656
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_utime = PostProcessor()
    test_utime.try_utime()


# Generated at 2022-06-26 13:38:31.913665
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test 0: instance construction
    post_processor_0 = PostProcessor()
    # test 1: default behaviour
    path = 'downloads/test/'
    atime = 1
    mtime = 1
    post_processor_0.try_utime(path, atime, mtime)


# Generated at 2022-06-26 13:38:43.321836
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # First arg is path, second is atime, third is mtime
    post_processor_1.try_utime('/home/user/downloads/file.mp4', 1426296622, 1426296623)
    post_processor_1.try_utime('/home/user/downloads/file.mp4', 1426296623, 1426296623)
    post_processor_1.try_utime('/home/user/downloads/file.mp4', 1426296623, 1426296622)
    post_processor_1.try_utime('/home/user/downloads/file.mp4', 0, 0)

# Generated at 2022-06-26 13:38:48.025312
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime('', 0, 0)
    # self.assertTrue(False)
    return 0


# Generated at 2022-06-26 13:38:56.092340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from pytube.extractor.common import InfoExtractor
    from pytube.downloader.common import FileDownloader
    from pytube.compat import compat_str
    def set_downloader():
        """Test set downloader function.
        """

# Generated at 2022-06-26 13:39:14.285393
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('text', 1, 1, 'Cannot update utime of file')

test_cases = [
    test_case_0,
    test_PostProcessor_try_utime,
]


if __name__ == '__main__':
    for t in test_cases:
        print('%s %s' % (t.__name__, '.' * 60))
        t()
        print('%s %s' % ('-' * 60, 'success'))

# Generated at 2022-06-26 13:39:19.198837
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        post_processor_1 = PostProcessor()
        post_processor_1.try_utime('video1', '10', '20')
    except Exception:
        assert False



# Generated at 2022-06-26 13:39:27.278579
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    from ..utils import encodeFilename

    current_dir = os.path.dirname(os.path.realpath(__file__))
    temp_dir = os.path.join(current_dir, tempfile.gettempdir())
    file_path = encodeFilename(os.path.join(temp_dir, "test"))
    file = open(file_path, "w+")
    file.close()
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(file_path, 1, 2)


# Generated at 2022-06-26 13:39:33.715470
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path = "The path"
    atime = 3
    mtime = 3
    errnote = "Cannot update utime of file"
    
    post_processor_0.try_utime(path, atime, mtime, errnote)



# Generated at 2022-06-26 13:39:37.086268
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-26 13:39:46.079987
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def raiseException():
        raise Exception

    PostProcessor(downloader=lambda: None).try_utime('test case', 1.0, 1.0)
    PostProcessor(downloader=lambda: None)._downloader.report_warning = raiseException
    try:
        PostProcessor(downloader=lambda: None).try_utime('test case', raiseException, raiseException, 'test case')
    except Exception:
        return True
    return False

# Generated at 2022-06-26 13:39:58.319319
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import Extractor
    from ..compat import compat_str
    from ..downloader import sanitize_open
    import calendar
    import time
    import tempfile
    import shutil
    import sys
    import os

    tmp_dir = tempfile.mkdtemp(prefix='ytdl-test')

# Generated at 2022-06-26 13:40:07.684897
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    post_processor_0 = PostProcessor()

    # test without specifying the time
    post_processor_0.try_utime("music/foo.html", 0, 0, "")

    # test with specifying the time
    modified_time = datetime.datetime.now()
    atime = modified_time - datetime.timedelta(seconds = 10)
    post_processor_0.try_utime("music/foo.html", atime, modified_time, "")

# Generated at 2022-06-26 13:40:13.737942
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime = lambda path, times: None
    p = PostProcessor()
    p.try_utime('dummy', 1, 1)

if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:40:15.014486
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0, 1, 'Cannot update utime of file')

# Generated at 2022-06-26 13:40:35.862945
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(
        'F:\\deploy\\src\\paf\\paf_agent\\paf_agent\\bin\\test_result.xml',
        None,
        None,
        'Cannot update utime of file')


# Generated at 2022-06-26 13:40:39.213287
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('test_file.abc', 0, 0)


# Generated at 2022-06-26 13:40:51.158927
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import Bunch
    from .compat import compat_mock
    from .extractor import InfoExtractor
    from .downloader import FileDownloader

    class DummyInfoExtractor(InfoExtractor):

        def extract(self, *args, **kwargs):
            raise ValueError('should not be called')
    
    class DummyFileDownloader(FileDownloader):

        def report_warning(self, msg):
            DummyFileDownloader._warning_message = msg

    # Mock some objects
    ie = DummyInfoExtractor(DummyFileDownloader())
    ie._downloader.params = Bunch()
    
    # Try to delete the file after processing:
    # 1. file doesn't exist
    # 2. file can be deleted

# Generated at 2022-06-26 13:41:00.565802
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = "I5v5n5m5k5j5q5y5V5c5e5h5V"
    atime_0 = 1
    mtime_0 = 1
    errnote_0 = "Cannot update utime of file"
    post_processor_0.try_utime(path=path_0, atime=atime_0, mtime=mtime_0, errnote=errnote_0)



# Generated at 2022-06-26 13:41:11.436629
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..exceptions import PostProcessingError
    from ..YoutubeDL import YoutubeDL
    post_processor = PostProcessor(YoutubeDL())
    post_processor.try_utime('nonexistent file', 1, 2)
    import tempfile
    fd, path = tempfile.mkstemp(prefix='youtubedl_test_PostProcessor_try_utime_')
    post_processor.try_utime(path, 1, 2)
    os.close(fd)
    os.unlink(path)


if __name__ == '__main__':
    test_case_0()
    test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:41:22.934406
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    # Test with path equal to 'file.mp4' and atime equal to 1525284626.6339231 and
    # mtime equal to 1525284626.63792319 and errnote equal to 'Cannot update utime of file'

    # Test with path equal to 'file.mp4' and atime equal to 1525284626.6339231 and
    # mtime equal to 1525284626.63792319 and errnote equal to 'Cannot update utime of file'
    post_processor_1.try_utime('file.mp4', 1525284626.6339231, 1525284626.63792319, 'Cannot update utime of file')
    #assert_equals(post_processor_1.try_utime('file

# Generated at 2022-06-26 13:41:30.920584
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    with post_processor_1.try_utime(atime, mtime, errnote):
        if (os.utime != os.utime):
            raise AssertionError('os.utime != os.utime')
        elif (post_processor_1.try_utime != post_processor_1.try_utime):
            raise AssertionError('post_processor_1.try_utime != post_processor_1.try_utime')



# Generated at 2022-06-26 13:41:34.643813
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime(None, None, None, None)


# Generated at 2022-06-26 13:41:43.725157
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    post_processor_0 = PostProcessor()
    path_0 = tempfile.mkstemp()
    atime_0 = 1
    mtime_0 = 1
    errnote_0 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)
    path_1 = tempfile.mkstemp()
    atime_1 = 1
    mtime_1 = 1
    errnote_1 = 'Cannot update utime of file'
    post_processor_0.try_utime(path_1, atime_1, mtime_1, errnote_1)

# Generated at 2022-06-26 13:41:50.795792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime('', 0.0, 0.0, 'Cannot update utime of file')
    return 'unit_test_success'



# Generated at 2022-06-26 13:42:22.235412
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("path")


# Generated at 2022-06-26 13:42:29.395000
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_try_utime = PostProcessor()
    post_processor_try_utime.set_downloader(downloader=None)
    post_processor_try_utime.try_utime(path='path', atime=1, mtime=2, errnote='Cannot update utime of file')



# Generated at 2022-06-26 13:42:31.935265
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()
    p.try_utime('file.txt', 12, 12)


# Generated at 2022-06-26 13:42:34.862459
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    path_0 = 'a'
    atime_0 = 3.14
    mtime_0 = 0.0
    errnote_0 = 'errnote'
    post_processor_0.try_utime(path_0, atime_0, mtime_0, errnote_0)


# Generated at 2022-06-26 13:42:41.182818
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    post_processor_0.try_utime("cache/test.txt", 0, 0, "Cannot update utime of file")

if __name__ == "__main__":
    from test import test_common
    test_common.run(__file__)

# Generated at 2022-06-26 13:42:43.945284
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_1 = PostProcessor()
    parameter_1 = post_processor_1._configuration_args(default=[])
    assert parameter_1 == []


# Generated at 2022-06-26 13:42:55.393985
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():  
    import os
    from ..utils import encodeFilename
    from .YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .executor import ExternalFD
    from .format import VideoFormat
    bdir = os.path.dirname(os.path.abspath(__file__))
    fd = ExternalFD(YoutubeDL({}), FileDownloader(YoutubeDL({}), {'format': 'best'}), YoutubeDL({}).params, bdir, 'videoid')
    post_processor_0 = PostProcessor()
    post_processor_0.set_downloader(YoutubeDL({'format': 'best'}))
    post_processor_0.run(fd)

test_PostProcessor_try_utime()

# Generated at 2022-06-26 13:43:06.529209
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Passing in a valid filename that exists and is able to update the utime
    post_processor = PostProcessor()
    filename = os.path.abspath(__file__)
    atime = os.path.getatime(filename)
    mtime = os.path.getmtime(filename)
    post_processor.try_utime(filename, atime, mtime)
    assert os.path.getatime(filename) == atime and os.path.getmtime(filename) == mtime

    # Passing in a valid filename that exists but is not able to update the utime
    post_processor = PostProcessor()
    filename = os.path.abspath(__file__)
    atime = os.path.getatime(filename)
    mtime = os.path.getmtime(filename)
   

# Generated at 2022-06-26 13:43:15.017568
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor_0 = PostProcessor()
    arg_path_0 = 'test.flv'
    arg_atime_0 = 1
    arg_mtime_0 = 1
    arg_errnote_0 = 'cannot update utime of file'
    try:
        post_processor_0.try_utime(arg_path_0, arg_atime_0, arg_mtime_0, arg_errnote_0)
    except PostProcessingError:
        pass

# Generated at 2022-06-26 13:43:22.530154
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test that it works
    pp = PostProcessor()
    assert pp.try_utime('test.mp3', 0, 0) == None
    # test that it doesn't fail
    pp.try_utime('test.mp3', 0, 0, errnote='Failed')
    return True