

# Generated at 2022-06-18 15:37:26.778726
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification times of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Get the access and modification times of the file

# Generated at 2022-06-18 15:37:34.551359
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_file')
    with open(temp_file, 'w') as f:
        f.write('test')

    # get current time
    current_time = time.time()

    # create a postprocessor
    pp = PostProcessor(None)

    # change the time of the file
    pp.try_utime(temp_file, current_time, current_time)
    assert os.path.getatime(temp_file) == current_time
    assert os.path.getmtime(temp_file) == current_time

    # change the time of the file to a different time

# Generated at 2022-06-18 15:37:44.797534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            self.to_screen(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:55.348236
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from .common import PostProcessorTestCase

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    class TestInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test IE'
        _VALID_URL = r'(?i)^https?://.*\.test$'


# Generated at 2022-06-18 15:38:06.218481
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()
    # Get current time
    current_time = time.time()
    # Create PostProcessor object
    pp = PostProcessor(None)
    # Set access and modification time of temporary file to current time
    pp.try_utime(temp_file.name, current_time, current_time)
    # Get access and modification time of temporary file
    file_stat = os.stat(temp_file.name)
    # Check if access and modification time of temporary file are equal to current time
    assert file_stat.st_

# Generated at 2022-06-18 15:38:16.830587
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    def _test_try_utime(path, atime, mtime, errnote):
        pp = PostProcessor(None)
        pp.try_utime(path, atime, mtime, errnote)

    def _test_try_utime_exception(path, atime, mtime, errnote):
        pp = PostProcessor(None)
        try:
            pp.try_utime(path, atime, mtime, errnote)
        except Exception:
            pass

    def _test_try_utime_exception_with_open(path, atime, mtime, errnote):
        pp = PostProcessor(None)

# Generated at 2022-06-18 15:38:25.574713
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test'), 'w')
        f.write('test')
        f.close()
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:38:32.599992
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.file')
    with open(temp_file, 'w') as f:
        f.write('test')

    pp = PostProcessor(None)
    pp.try_utime(temp_file, time.time(), time.time())

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:38:42.869452
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test'), now, now)

    # Check that the time of the file has been updated
    st = os.stat(os.path.join(tmpdir, 'test'))
    assert st.st_atime == now

# Generated at 2022-06-18 15:38:54.679716
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (3, 0):
        from urllib import pathname2url
    else:
        from urllib.request import pathname2url

    from ..utils import (
        encodeFilename,
        PostProcessor,
    )

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = os.path.join(temp_dir, 'test.txt')
    with open(encodeFilename(temp_file), 'w') as f:
        f.write('test')

    # Get the file modification time
    file_mtime = os.path.getmtime(encodeFilename(temp_file))

    # Create a Post

# Generated at 2022-06-18 15:39:04.674822
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys
    from ..utils import DateRange

    class DummyDownloader():
        def __init__(self):
            self.params = {'outtmpl': '%(id)s.%(ext)s'}
            self.to_screen = sys.stderr.write
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)


# Generated at 2022-06-18 15:39:13.006336
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:23.098206
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        fpath = os.path.join(tmpdir, 'test_file')
        with open(fpath, 'w') as f:
            f.write('test')

        pp = PostProcessor(None)
        pp.try_utime(fpath, 0, 0)
        assert os.path.getatime(fpath) == 0
        assert os.path.getmtime(fpath) == 0

        pp.try_utime(fpath, time.time(), time.time())
        assert os.path.getatime(fpath) == os.path.getmtime(fpath)
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:39:32.520091
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    downloader = Downloader(params={'noprogress': True})
    downloader.add_info_extractor(gen_extractors()[0])
    downloader.add_post_processor(PostProcessor())

    # Create a dummy file
    f = open('test.txt', 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime('test.txt')

    # Change the modification time of the file
    downloader.post_process({'filepath': 'test.txt', 'date': DateRange(mtime + 1)})

    # Check that the modification time of the file has changed

# Generated at 2022-06-18 15:39:43.263314
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the temporary file
    pp.try_utime(tmpfile, now, now)

    # Check if the utime of the temporary file was updated
    assert os.path.getatime(tmpfile) == now
    assert os.path.getmtime(tmpfile) == now

    # Remove the temporary directory
    shutil.rmtree

# Generated at 2022-06-18 15:39:51.232020
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    from ..compat import compat_makedirs

    from .common import PostProcessorTestCase

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    class TestPostProcessorTestCase(PostProcessorTestCase):
        def test_try_utime(self):
            tmp_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, tmp_dir)
            test_file = os.path.join(tmp_dir, 'test_file')
            compat

# Generated at 2022-06-18 15:40:01.966580
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_str
    from tempfile import mkdtemp
    from shutil import rmtree
    import os
    import time

    # Create a temporary directory
    tmp_dir = mkdtemp()
    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a downloader

# Generated at 2022-06-18 15:40:13.978841
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    class FakeDownloader:
        def __init__(self):
            self.params = {'outtmpl': '%(id)s'}
            self.to_stderr = lambda x: sys.stderr.write(x + '\n')

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:18.729617
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), time.time(), time.time())

    # Check if the modification time has

# Generated at 2022-06-18 15:40:28.944230
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.version_info < (3, 0):
        from urllib import pathname2url
    else:
        from urllib.request import pathname2url

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the file path
    temp_file_path = temp_file.name

    # Get the file name
    temp_file_name = os.path.basename(temp_file_path)

    # Get the file URL

# Generated at 2022-06-18 15:40:38.080801
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    filepath = os.path.join(tmpdir, 'file')
    with open(filepath, 'wb') as f:
        f.write(b'content')

    # Get the current time
    curtime = time.time()

    # Set the file's access time to the current time
    os.utime(filepath, (curtime, curtime))

    # Get the file's access time
    atime = os.stat(filepath)[stat.ST_ATIME]

    # Check that the file's access time is the current time
    assert atime == curtime

    # Create a PostProcessor object
    pp

# Generated at 2022-06-18 15:40:47.451973
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'restrictfilenames': True,
            }
            self.to_stderr = lambda x: x
            self.to_screen = lambda x: x

        def report_warning(self, msg):
            self.to_stderr(msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:59.651424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:11.807051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = os.path.join(tmpdir, 'test.txt')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(tmpfile, curtime, curtime)

    # Check that the time of the file is the current time
    assert os.stat(tmpfile).st_mtime == curtime

    # Remove the temporary directory
    shutil

# Generated at 2022-06-18 15:41:21.913067
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from .common import PostProcessorTestCase

    class TestPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    class TestFD(FileDownloader):
        def report_warning(self, msg):
            self.warnings.append(msg)

    pp = TestPP()
    fd = TestFD(params={})
    fd.warnings = []
    pp.set_downloader(fd)

    class FakeInfo(dict):
        def __init__(self, filepath):
            super(FakeInfo, self).__init__(filepath=filepath)

    # Test with a file that does not exist
    info = Fake

# Generated at 2022-06-18 15:41:30.611149
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import os
    import stat

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a post processor
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), now, now)

    # Check that the time of the file has been changed

# Generated at 2022-06-18 15:41:41.176368
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = os.path.join(tmpdir, 'test.txt')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a postprocessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(tmpfile, curtime, curtime)

    # Check that the time of the file is the current time
    assert os.path.getmtime(tmpfile) == curtime

    # Remove the temporary directory

# Generated at 2022-06-18 15:41:52.332186
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a post processor
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test'), now, now)

    # Check that the utime has been updated
    stat = os.stat(os.path.join(tmpdir, 'test'))
    assert stat.st_atime == now
    assert stat.st

# Generated at 2022-06-18 15:42:03.216692
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        # Create a file
        f = open(os.path.join(tmpdir, 'test'), 'w')
        f.close()

        # Get the current time
        now = time.time()

        # Set the file's mtime to the current time
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test'), now, now)

        # Check that the file's mtime has been set correctly
        assert os.path.getmtime(os.path.join(tmpdir, 'test')) == now
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:42:14.643824
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import sys
    from ..utils import PostProcessor

    if sys.version_info < (3, 0):
        from ..compat import compat_str
        from ..compat import compat_urllib_request

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:26.528378
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test.file')
    with open(test_file, 'wb') as f:
        f.write(b'Test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(test_file, current_time, current_time)

    # Check that the time of the file has been changed
    st = os.stat(test_file)
    assert st.st_atime == st.st

# Generated at 2022-06-18 15:42:36.844064
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check if the file has been modified

# Generated at 2022-06-18 15:42:44.112656
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'wb')
    f.write(b'hello world')
    f.close()

    # Get the file's modification time
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Create a post processor object
    pp = PostProcessor(None)

    # Try to modify the file's modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime + 1)

    # Check that the file's modification time has been

# Generated at 2022-06-18 15:42:54.490757
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:43:04.049761
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from .common import PostProcessorTestCase

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    class TestFileDownloader(FileDownloader):
        def report_warning(self, msg):
            raise AudioConversionError(msg)


# Generated at 2022-06-18 15:43:14.730191
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FakeYDL

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.utime_called = False

        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            self.utime_called = True
            return [], info

    dl = Downloader(FakeYDL())
    dl.params['nooverwrites'] = True
    dl.params['continuedl'] = True
    dl.params['noprogress'] = True
    dl.params['logger'] = dl
    dl.params['test'] = True

# Generated at 2022-06-18 15:43:21.813354
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import errno

    class FakeDownloader(object):
        def __init__(self):
            self.to_stderr = sys.stderr
            self.params = {}

        def report_warning(self, msg):
            print(msg, file=self.to_stderr)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class FakeFile(object):
        def __init__(self, path, mode):
            self.path = path
            self.mode = mode
            self.closed = False

        def close(self):
            self.closed = True


# Generated at 2022-06-18 15:43:30.903219
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    from ..compat import compat_os_name
    from ..utils import DateRange

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the time of the file
    file_time = os.path.get

# Generated at 2022-06-18 15:43:39.526592
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(file_path, current_time, current_time)

    # Check that the time of the file is the current time
    assert os.path.getmtime(file_path) == current_time

# Generated at 2022-06-18 15:43:46.765356
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    pp = PostProcessor()
    pp._downloader = None

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Set the file's modification time to the current time
    pp.try_utime(test_file, current_time, current_time)

    # Check that the file's modification time is the current time
    assert os.path.getmtime(test_file) == current_time

    # Remove the

# Generated at 2022-06-18 15:44:03.189407
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)

    class MockDownloader(Downloader):
        def __init__(self):
            super(MockDownloader, self).__init__()

# Generated at 2022-06-18 15:44:13.143588
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.test_path = None
            self.test_atime = None
            self.test_mtime = None

        def run(self, information):
            self.test_path = information['filepath']
            self.test_atime = information['atime']
            self.test_mtime = information['mtime']
            return [], information

    dl = Downloader(params={'noprogress': True, 'quiet': True, 'logger': True})
    gen_extractors(dl)
    pp

# Generated at 2022-06-18 15:44:21.687355
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'verbose': True,
            }

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:44:31.825434
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the file's modification time
    mtime = os.stat(os.path.join(tmpdir, 'test.txt'))[stat.ST_MTIME]

    # Change the file's modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), time.time(), time.time() + 100)

    # Check if the file's modification

# Generated at 2022-06-18 15:44:41.712669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:44:49.555693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a postprocessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the access and modification time of the file

# Generated at 2022-06-18 15:45:01.391132
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from ..compat import compat_str

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 1, 2)
            return [], information

    downloader = FileDownloader({'outtmpl': '%(id)s%(ext)s'})
    downloader.add_info_extractor(None)
    downloader.add_post_processor(TestPostProcessor(downloader))
    downloader.params['writedescription'] = True
    downloader.params['writeinfojson'] = True
    downloader.params['writethumbnail'] = True
    downloader.params['writesubtitles'] = True

# Generated at 2022-06-18 15:45:09.847127
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    curr_time = time.time()

    # Set the current time as the last access and modification time of the temporary file
    pp.try_utime(temp_file.name, curr_time, curr_time)

    # Get the last access and modification time of the temporary file
    stat_info = os.stat(temp_file.name)

    # Check that the last access

# Generated at 2022-06-18 15:45:21.237875
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import stat

    from ..utils import DateRange

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file inside the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file's access and modification times to the current time
    pp.try_utime(test_file, current_time, current_time)

    # Get the file's access and modification times
    st = os.stat(test_file)

# Generated at 2022-06-18 15:45:31.011870
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .ffmpegthumbnail import FFmpegThumbnailPP
    from .embedsubtitles import EmbedSubtitlesPP
    from .fixup import FixupPP
    from .execafterdownload import ExecAfterDownloadPP
    from .postprocessor_tests import PostProcessorTestCase
    from .metadatafromtitle import MetadataFromTitlePP

# Generated at 2022-06-18 15:45:54.471419
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    from .downloader import FileDownloader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Create a FileDownloader
    ydl = FileDownloader({})

    # Create a PostProcessor
    pp = PostProcessor(ydl)

    # Get the file's atime and mtime
    st = os.stat(os.path.join(tmpdir, 'test'))
    atime = st[stat.ST_ATIME]
    mtime = st[stat.ST_MTIME]

    # Set the file

# Generated at 2022-06-18 15:46:00.692010
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    import datetime
    import os
    import tempfile
    import time

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], info['filetime'], info['filetime'])
            return [], info

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestInfoExtractor, self).__init__(downloader)
            self._filetime = None


# Generated at 2022-06-18 15:46:09.481131
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the utime of the file

# Generated at 2022-06-18 15:46:19.254618
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(temp_dir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file's modification time to the current time
    pp.try_utime(os.path.join(temp_dir, 'test.txt'), current_time, current_time)

    # Check that the file's modification time is the current time

# Generated at 2022-06-18 15:46:26.866955
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    mtime = os.stat(os.path.join(tmpdir, 'test.txt'))[stat.ST_MTIME]

    # Wait a second
    time.sleep(1)

    # Update the file's modification time
    pp = PostProcessor(None)
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), None, None)

    # Get the file's modification time again
    mtime2

# Generated at 2022-06-18 15:46:35.458096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        filepath = os.path.join(tmpdir, 'test.txt')
        with open(filepath, 'w') as f:
            f.write('test')
        mtime = time.time() - 3600
        atime = mtime - 3600
        pp = PostProcessor(None)
        pp.try_utime(filepath, atime, mtime)
        assert os.path.getmtime(filepath) == mtime
        assert os.path.getatime(filepath) == atime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:46:46.704613
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test'))

    #

# Generated at 2022-06-18 15:46:55.131807
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    import datetime
    import tempfile
    import shutil
    import os
    import sys

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.errnote = 'Cannot update utime of file'

        def run(self, information):
            self.try_utime(information['filepath'], 0, 0, self.errnote)
            return [], information

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:47:05.422044
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.atime = None
            self.mtime = None

        def run(self, information):
            self.atime = information['filepath']
            self.mtime = information['filepath']
            return [], information

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:47:16.724085
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), now, now)

    # Check if the time of the file has been changed
    assert os.path.getmtime(os.path.join(tmpdir, 'test.txt')) == now

    # Remove the