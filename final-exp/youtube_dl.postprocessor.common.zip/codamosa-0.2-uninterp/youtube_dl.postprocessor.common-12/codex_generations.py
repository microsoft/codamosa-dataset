

# Generated at 2022-06-18 15:37:30.278103
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

# Generated at 2022-06-18 15:37:36.637097
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Get the time of the file
    file_time = os.path.getmtime(os.path.join(tmpdir, 'test'))

# Generated at 2022-06-18 15:37:47.564318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime of the PostProcessor object
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the last modification time of the file

# Generated at 2022-06-18 15:37:56.485281
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

    # Get the file name
    temp_file_name = temp_file.name

    # Close the file
    temp_file.close()

    # Get the file modification time
    file_mtime = os.stat(temp_file_name).st_mtime

    # Wait for a second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the file modification time

# Generated at 2022-06-18 15:38:07.761838
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from ..utils import (
        DateRange,
        DateRangeError,
        encodeFilename,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(TestPostProcessor, self).__init__(*args, **kwargs)
            self.utime_called = False

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.utime_called = True
            self.utime_path = path
            self.utime_atime = atime
            self.utime_mtime = mtime
            self.utime_errnote = errnote


# Generated at 2022-06-18 15:38:17.545855
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

    # Set the atime and mtime of the temporary file to the current time
    pp.try_utime(temp_file_path, current_time, current_time)

    # Get the atime and mtime of the temporary file
    file_stat = os.stat(temp_file_path)
    atime = file_stat.st_at

# Generated at 2022-06-18 15:38:29.470567
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import YoutubeIE
    from ..postprocessor import FFmpegMetadataPP
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_str
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_tempfile
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_request
    from ..compat import compat

# Generated at 2022-06-18 15:38:40.521635
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.version_info < (3, 0):
        from urllib import unquote
    else:
        from urllib.parse import unquote

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmppath = os.path.join(tmpdir, 'test.tmp')
    tmpfile = open(tmppath, 'w')
    tmpfile.close()
    # Get current time
    curtime = time.time()
    # Set mtime and atime to current time
    os.utime(tmppath, (curtime, curtime))
    # Get mtime and atime of file
    st = os.stat(tmppath)
   

# Generated at 2022-06-18 15:38:51.716642
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Get the file path
    filepath = tmpfile.name
    # Close the file, we don't need it
    tmpfile.close()
    # Create a PostProcessor object
    pp = DummyPostProcessor()
    # Get the current time
    now = time.time()
    # Set the file's access and modification times
    pp

# Generated at 2022-06-18 15:39:01.961927
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:12.588741
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    curr_time = time.time()

    # Set the access and modification time of the temporary file
    pp.try_utime(tmpfile, curr_time, curr_time)

    # Get the access and modification time of the temporary file
    st = os.stat(tmpfile)

    # Check if the access and modification time of the temporary file is correct
    assert st.st_at

# Generated at 2022-06-18 15:39:21.727033
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import tempfile
    from ..utils import PostProcessor

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the temporary file to the current time
    pp.try_utime(fname, current_time, current_time)

    # Check that the time of the temporary file is the current time
    assert os.stat(fname).st_mtime == current_time

    # Remove the temporary file
    os.remove(fname)

# Generated at 2022-06-18 15:39:28.775268
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    if sys.version_info < (3, 0):
        from urllib2 import urlopen
    else:
        from urllib.request import urlopen

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Download an image
    image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Example.jpg/320px-Example.jpg'
    image_filename = image_url.split('/')[-1]
    image_path = os.path.join(tmpdir, image_filename)
    with open(image_path, 'wb') as image_file:
        image_file.write(urlopen(image_url).read())

    #

# Generated at 2022-06-18 15:39:40.168911
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_str
    from ..compat import compat_os_path
    from ..compat import compat_shutil
    from ..compat import compat_tempfile
    from ..compat import compat_urlparse
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_struct_calcsize
    from ..compat import compat_socket
    from ..compat import compat_urllib_error
   

# Generated at 2022-06-18 15:39:49.101528
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (2, 6):
        return

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:00.592618
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    st = os.stat(os.path.join(tmpdir, 'test.txt'))
    mtime = st[stat.ST_MTIME]

    # Change the file's modification time
    time.sleep(1)
    f = open(os.path.join(tmpdir, 'test.txt'), 'a')
    f.write('test')
    f.close()

    # Get the file's new modification time
   

# Generated at 2022-06-18 15:40:07.888115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor
    from ..cache import Cache
    from .common import get_testdata_file

    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)


# Generated at 2022-06-18 15:40:17.968667
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the file's modification time
    file_mtime = os.path.getmtime(temp_file.name)

    # Wait a second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file's modification time to its creation time
    pp.try_utime(temp_file.name, file_mtime, file_mtime)

    # Check that the file's modification time has been updated

# Generated at 2022-06-18 15:40:28.305627
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(filepath, curr_time, curr_time)

    # Check that the time of the file has been updated
    file_stat = os.stat(filepath)
    assert file_stat.st_atime == curr

# Generated at 2022-06-18 15:40:36.594719
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)

    dl = Downloader(params={'noprogress': True, 'logger': None, 'extractors': gen_extractors()})
    pp = MockPostProcessor(dl)
    pp.try_utime('/tmp/foo', 0, 0)
    assert len(pp.warnings) == 0


# Generated at 2022-06-18 15:40:48.366615
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    if sys.platform.startswith('win'):
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:59.773817
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_makedirs

    dl = Downloader({'outtmpl': '%(id)s.%(ext)s', 'nooverwrites': True})
    pp = PostProcessor(dl)

    # Create a file
    compat_makedirs(os.path.dirname(encodeFilename('test_file.txt')))
    with open(encodeFilename('test_file.txt'), 'w') as f:
        f.write('test')

    # Get the current time
    now = DateRange().end

    # Try to update the time of the file
    pp.try_utime('test_file.txt', now, now)

    # Check if the time of the file has been updated

# Generated at 2022-06-18 15:41:11.855055
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys
    import stat

    class FakeDownloader(object):
        def __init__(self):
            self.to_stderr = sys.stderr
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'restrictfilenames': True,
            }

        def report_warning(self, msg):
            self.to_stderr.write('WARNING: ' + msg + '\n')

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:19.861293
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(tmpfile, current_time, current_time)

    # Get the file modification time
    file_mtime = os.path.getmtime(tmpfile)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check that the file modification time is the same as

# Generated at 2022-06-18 15:41:29.595383
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import stat
    import os
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the time of the file

# Generated at 2022-06-18 15:41:40.086726
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    class DummyDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:50.711600
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class MockInfoExtractor(object):
        def __init__(self, ie_name):
            self._name = ie_name


# Generated at 2022-06-18 15:41:58.261002
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (3, 0):
        from io import open

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'restrictfilenames': True,
                'nooverwrites': True,
                'logger': None,
            }

        def report_warning(self, msg):
            self.msg = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    def _test_try_utime(atime, mtime):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:06.752453
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeYDL
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.utime_called = False

        def run(self, info):
            self.try_utime(info['filepath'], info['upload_date'], info['upload_date'])
            self.utime_called = True
            return [], info

    # Create a test file
    test_file = open('test.tmp', 'wb')
    test_file.write(b'0123456789')
    test_file.close()

    # Create a downloader

# Generated at 2022-06-18 15:42:14.187136
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()
    try:
        tempfilepath = os.path.join(tempdir, 'test_file')
        with open(tempfilepath, 'w') as f:
            f.write('test')

        pp = PostProcessor(None)
        pp.try_utime(tempfilepath, time.time(), time.time())
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-18 15:42:28.090560
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import stat
    import sys

    if sys.version_info < (3, 0):
        from io import open

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the file's modification time
    file_mtime = os.stat(os.path.join(tmpdir, 'test.txt'))[stat.ST_MTIME]

    # Set the file's modification time

# Generated at 2022-06-18 15:42:38.949733
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import stat

    from ..utils import PostProcessor

    pp = PostProcessor()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    curtime = time.time()

    # Set the file's modification time to the current time
    os.utime(path, (curtime, curtime))

    # Get the file's modification time
    st = os.stat(path)
    mtime = st[stat.ST_MTIME]

    # Check that the file's modification time is the current time
    assert mtime == curtime

    # Set the file's modification time

# Generated at 2022-06-18 15:42:50.104672
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    from ..utils import PostProcessor

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()
    try:
        fname = os.path.join(tmpdir, 'test.txt')
        with open(fname, 'w') as f:
            f.write('test')
        atime = time.time()
        mtime = atime - 3600
        pp = PostProcessor(None)
        pp.try_utime(fname, atime, mtime)
        assert os.path.getatime(fname) == atime
        assert os.path.getmtime(fname) == mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:42:59.646826
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os
    import time
    import stat
    import unittest

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class TestDownloader(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, errnote):
            pass

    class TestPostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')

# Generated at 2022-06-18 15:43:07.892761
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Check if the time has been updated
    if os.stat(os.path.join(tmpdir, 'test')).st_mtime != current_time:
        sys

# Generated at 2022-06-18 15:43:18.417325
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    tmpfile = os.path.join(tmpdir, 'foo')
    with open(tmpfile, 'wb') as f:
        f.write(b'foo')

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(tmpfile, cur_time, cur_time)

    # Check if the time has been changed
    st = os.stat(tmpfile)
    assert st.st_atime == st.st_mtime == cur_time

   

# Generated at 2022-06-18 15:43:29.412734
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

# Generated at 2022-06-18 15:43:37.380712
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(downloader=None)

    # Update the utime of the file

# Generated at 2022-06-18 15:43:47.270944
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import subprocess
    import platform

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(filepath, current_time, current_time)

    # Check if the time of the file is the current time
    file_stat = os.stat(filepath)

# Generated at 2022-06-18 15:43:57.765950
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time

    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'test.txt')
        with open(path, 'w') as f:
            f.write('test')
        atime = time.time() - 1000
        mtime = time.time() - 2000
        pp = PostProcessor(None)
        pp.try_utime(path, atime, mtime)
        assert os.path.getatime(path) == atime
        assert os.path.getmtime(path) == mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:44:20.985520
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    from ..utils import PostProcessor
    from ..compat import compat_stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:44:31.414178
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime + 3600)

    # Check

# Generated at 2022-06-18 15:44:41.375828
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import sys
    from ..utils import encodeFilename

    if sys.platform == 'win32':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(tmpfile, current_time, current_time)

    # Get the file modification time
    file_mtime = os.path.getmtime(encodeFilename(tmpfile))

    #

# Generated at 2022-06-18 15:44:49.321544
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat

    if sys.platform == 'win32':
        import ctypes
        import ctypes.wintypes

        class FILETIME(ctypes.Structure):
            _fields_ = [
                ('dwLowDateTime', ctypes.wintypes.DWORD),
                ('dwHighDateTime', ctypes.wintypes.DWORD),
            ]

        def dt_to_filetime(dt):
            ft = FILETIME()
            ft.dwLowDateTime = dt & 0xFFFFFFFF
            ft.dwHighDateTime = dt >> 32
            return ft

        def filetime_to_dt(ft):
            return (ft.dwHighDateTime << 32) + ft.dwLow

# Generated at 2022-06-18 15:45:00.551894
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys
    import os
    import stat
    import errno
    import platform

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    cur_time = time.time()

    # Try to update the access and modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), cur_time, cur_time)

    # Get the new access and modification time of the file
    new_atime, new_

# Generated at 2022-06-18 15:45:09.668031
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Check that the time of the file is the current time

# Generated at 2022-06-18 15:45:21.111705
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)

    fd = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    pp = TestPostProcessor(fd)

    # Test with a file that doesn't exist
    pp.try_utime('/path/to/file', 0, 0)
    assert pp.warnings == ['Cannot update utime of file']
    pp.warnings = []

    # Test with a file that exists
   

# Generated at 2022-06-18 15:45:26.094822
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from .common import PostProcessingTest

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information


# Generated at 2022-06-18 15:45:34.319920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..downloader import Downloader
    from ..postprocessor import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Create a downloader
    downloader = Downloader(params={})

    # Create a postprocessor
    postprocessor = PostProcessor(downloader)

    # Get the file modification time
    mtime = os.path.getmtime(filepath)

    # Try to update the file modification time
    postprocessor.try_utime(filepath, mtime, mtime)

    #

# Generated at 2022-06-18 15:45:43.137435
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    class DummyDownloader:
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'restrictfilenames': True,
            }
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)


# Generated at 2022-06-18 15:46:21.246880
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the utime of the file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Get the utime of the file
    file_stat = os.stat(temp_file.name)

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

    # Check

# Generated at 2022-06-18 15:46:30.294574
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    from ..utils import PostProcessor

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s%(ext)s',
                'verbose': True,
            }

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    # Create a temporary directory

# Generated at 2022-06-18 15:46:37.784286
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Close the temporary file
    os.close(fd)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    curr_time = time.time()

    # Set the mtime and atime of the temporary file
    pp.try_utime(tmpfile, curr_time, curr_time)

    # Get the mtime and atime of the temporary file
    st = os.stat(tmpfile)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:46:48.410399
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from ..utils import PostProcessor
    from ..compat import compat_os_name

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(test_file, cur_time, cur_time)

    # Check if the time of the file has been changed

# Generated at 2022-06-18 15:46:57.281003
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from .common import PostProcessingTestCase

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    class TestInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

# Generated at 2022-06-18 15:47:05.448110
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test.txt'), 'w')
        f.write('test')
        f.close()

        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test.txt'), time.time(), time.time())
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:47:16.741037
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    class FakeDownloader(object):
        def __init__(self):
            self.to_stderr = sys.stderr

        def report_warning(self, msg):
            print(msg, file=self.to_stderr)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.set_downloader(downloader)

    def _test_try_utime(path, atime, mtime, errnote, expected_warning=False):
        downloader = FakeDownloader()
        pp = FakePostProcessor(downloader)
        pp.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-18 15:47:23.296488
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

    # Create a downloader object