

# Generated at 2022-06-18 15:37:25.390255
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmppath = os.path.join(tmpdir, 'test.txt')
    with open(tmppath, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file modification time
    pp.try_utime(tmppath, curtime, curtime)

    # Check that the file modification time has been changed
    assert os.path.getmtime(tmppath) == curtime

    # Change

# Generated at 2022-06-18 15:37:34.542329
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s'}

        def report_warning(self, msg):
            self.msg = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:44.758925
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), now, now)

    # Check that the modification time has changed
    st = os.stat(os.path.join(tmpdir, 'test.txt'))

# Generated at 2022-06-18 15:37:55.308327
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s.%(ext)s'}
            self.to_screen = lambda x: None

        def report_warning(self, msg):
            self.warning = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:05.809913
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'testfile'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call try_utime method
    pp.try_utime(os.path.join(tmpdir, 'testfile'), curtime, curtime)

    # Get the file status
    st = os.stat(os.path.join(tmpdir, 'testfile'))

    # Check if the file access time and modification time

# Generated at 2022-06-18 15:38:16.680920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'nooverwrites': True,
            }

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:28.969424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from ..compat import (
        compat_os_name,
        compat_path_exists,
        compat_rename,
        compat_tempfile_gettempdir,
        compat_urllib_parse_urlparse,
    )
    from ..utils import (
        encodeFilename,
        PostProcessingError,
    )

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.tempdir, 'test_file')
            self.test_file

# Generated at 2022-06-18 15:38:34.991810
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')
            self.test_pp = TestPostProcessor()


# Generated at 2022-06-18 15:38:44.155004
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix="ytdl_test_")

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file modification time
    pp.try_utime(temp_file.name, curr_time, curr_time)

    # Check if the file modification time was changed
    assert os.path.getmtime(temp_file.name) == curr_time

    # Remove the temporary

# Generated at 2022-06-18 15:38:52.685023
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test.txt'), 'w')
        f.write('test')
        f.close()

        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test.txt'), time.time(), time.time())
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:38:57.676771
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import os
    from ..utils import encodeFilename

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'restrictfilenames': True,
            }

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='youtubedl-test-utime-')
    # Create a file in the temporary directory
    tmpfile

# Generated at 2022-06-18 15:39:05.594025
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:08.505152
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()
    try:
        filename = os.path.join(tempdir, 'test.txt')
        with open(filename, 'w') as f:
            f.write('test')
        os.chmod(filename, stat.S_IREAD)
        pp = PostProcessor(None)
        pp.try_utime(filename, time.time(), time.time())
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-18 15:39:19.382213
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import tempfile
    import shutil
    from ..utils import PostProcessor

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Test try_utime method
    pp.try_utime(tmp_file.name, current_time, current_time)
    assert os.path.getatime(tmp_file.name) == current_time
    assert os.path.getmtime(tmp_file.name) == current_time

    #

# Generated at 2022-06-18 15:39:26.716289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    tmpdir = tempfile.mkdtemp()
    try:
        filepath = os.path.join(tmpdir, 'test.txt')
        with open(filepath, 'w') as f:
            f.write('test')
        atime = time.time() - 3600
        mtime = time.time() - 7200
        pp = PostProcessor(None)
        pp.try_utime(filepath, atime, mtime)
        st = os.stat(filepath)
        assert st.st_atime == atime
        assert st.st_mtime == mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:39:37.638667
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s'}

        def report_warning(self, message):
            self.message = message

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.set_downloader(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:47.241456
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import shutil
    import tempfile
    from ..utils import PostProcessor
    from ..compat import compat_urllib_request

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test'))

    # Change the modification time of the file

# Generated at 2022-06-18 15:39:53.298013
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.version_info < (3, 0):
        from urllib2 import urlopen
    else:
        from urllib.request import urlopen

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Download an image
    image_url = 'http://upload.wikimedia.org/wikipedia/commons/4/47/PNG_transparency_demonstration_1.png'
    image_name = 'test_image.png'
    image_path = os.path.join(temp_dir, image_name)
    image_file = open(image_path, 'wb')
    image_file.write(urlopen(image_url).read())

# Generated at 2022-06-18 15:40:03.382805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 15:40:15.312359
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..compat import compat_setenv
    from ..compat import compat_getenv
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse

    class TestDownloader(Downloader):
        def __init__(self, params):
            self.params = params
            self.to_stderr = lambda s: None
            self.to_screen = lambda s, n: None
            self.report_warning = lambda s: None

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init

# Generated at 2022-06-18 15:40:27.180995
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_postprocessor import _test_pp_try_utime
    ydl = FakeYDL({'writedescription': True, 'writeinfojson': True, 'writethumbnail': True, 'writeautomaticsub': True, 'outtmpl': '%(id)s.%(ext)s', 'format': 'bestaudio/best', 'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}], 'nooverwrites': True, 'continuedl': True, 'daterange': DateRange('20000101', '20000131')})
    ydl.add_default_info_extractors()
    y

# Generated at 2022-06-18 15:40:33.608045
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    def _test_try_utime(path, atime, mtime, errnote):
        pp = DummyPostProcessor(DummyDownloader())
        pp.try_utime(path, atime, mtime, errnote)



# Generated at 2022-06-18 15:40:41.133279
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os
    import time
    import stat

    from ..utils import (
        encodeFilename,
    )

    from .common import (
        PostProcessorTestCase,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestPostProcessorTestCase(PostProcessorTestCase):
        def setUp(self):
            super(TestPostProcessorTestCase, self).setUp()
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'file')
            self.pp = TestPostProcessor(self.ydl)


# Generated at 2022-06-18 15:40:49.423816
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    # Create a downloader
    ydl = Downloader(params={'noplaylist': True, 'quiet': True, 'forcejson': True})
    ydl.add_info_extractor(gen_extractors()[0])

    # Create a postprocessor
    pp = PostProcessor(ydl)

    # Create a file
    import tempfile
    import time
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, 'test.txt')
    with open(filename, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Try

# Generated at 2022-06-18 15:40:59.845562
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test'), 'w')
        f.write('test')
        f.close()
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())
        st = os.stat(os.path.join(tmpdir, 'test'))
        assert stat.S_IMODE(st.st_mode) == 33188
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:41:11.945326
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    class FakePostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information


# Generated at 2022-06-18 15:41:19.896247
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys
    import os

    if sys.version_info < (3, 0):
        from cStringIO import StringIO
    else:
        from io import StringIO

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s%(ext)s',
                'nooverwrites': True,
                'restrictfilenames': True,
            }
            self.to_stderr = StringIO()
            self.to_screen = StringIO()

        def report_warning(self, msg):
            self.to_stderr.write(msg + '\n')


# Generated at 2022-06-18 15:41:29.634376
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.called = False

        def run(self, information):
            self.called = True
            return [], information

    class MockDownloader(Downloader):
        def __init__(self, params):
            Downloader.__init__(self, params)
            self.to_screen = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None


# Generated at 2022-06-18 15:41:40.127033
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    def _test_try_utime(path, atime, mtime, errnote):
        pp = PostProcessor(None)
        pp.try_utime(path, atime, mtime, errnote)

    def _test_try_utime_raises(path, atime, mtime, errnote):
        pp = PostProcessor(None)
        try:
            pp.try_utime(path, atime, mtime, errnote)
        except PostProcessingError:
            pass
        else:
            raise AssertionError('PostProcessingError not raised')


# Generated at 2022-06-18 15:41:50.804455
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the utime of the file
    file_stat = os.stat(os.path.join(tmpdir, 'test.txt'))

   

# Generated at 2022-06-18 15:42:02.354553
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test.txt'), 'w')
        f.write('test')
        f.close()

        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test.txt'), time.time(), time.time())
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:42:13.323259
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (2, 6):
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:18.944722
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'test.txt')
        with open(path, 'w') as f:
            f.write('test')
        atime = mtime = time.time()
        pp = PostProcessor(None)
        pp.try_utime(path, atime, mtime)
        assert os.path.getatime(path) == atime
        assert os.path.getmtime(path) == mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:42:27.026701
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    class DummyDownloader():
        def __init__(self):
            self.params = {
                'outtmpl': '%(title)s-%(id)s.%(ext)s',
                'restrictfilenames': True,
            }

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:37.730535
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..compat import compat_setenv
    from ..compat import compat_getenv
    from ..compat import compat_shlex_split
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 15:42:44.470761
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        import ctypes

        def _get_file_attributes(file_name):
            file_attributes = ctypes.windll.kernel32.GetFileAttributesW(file_name)
            if file_attributes == -1:
                raise ctypes.WinError()
            return file_attributes

        def _set_file_attributes(file_name, file_attributes):
            if not ctypes.windll.kernel32.SetFileAttributesW(file_name, file_attributes):
                raise ctypes.WinError()

    def _get_file_attributes(file_name):
        return os.stat(file_name)[stat.ST_MODE]


# Generated at 2022-06-18 15:42:54.901535
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import sys

    if sys.version_info < (3, 0):
        from cStringIO import StringIO
    else:
        from io import StringIO

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

    # Set the current time as the last modification time

# Generated at 2022-06-18 15:43:04.376062
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..compat import compat_str


# Generated at 2022-06-18 15:43:15.252830
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os.path
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Get the file path
    path = tmpfile.name
    # Close the file, we don't need it
    tmpfile.close()

    # Get the current time
    curr_time = time.time()
    # Get the modification time of the file
    file_mtime = os.path.getmtime(path)
    # Get the access time of the file
    file_atime = os.path.getatime(path)

    # Check that the modification time is the current time
    assert file_m

# Generated at 2022-06-18 15:43:26.606078
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os
    import time
    import stat

    from ..utils import PostProcessor

    class FakeDownloader:
        def __init__(self):
            self.params = {}

        def report_warning(self, msg):
            sys.stderr.write('WARNING: ' + msg + '\n')

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    def test_utime(path, atime, mtime):
        pp = FakePostProcessor(FakeDownloader())
        pp.try_utime(path, atime, mtime)
        st = os.stat(path)
        assert st.st_atime == atime
        assert st

# Generated at 2022-06-18 15:43:40.244962
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    from ..utils import (
        encodeFilename,
    )

    from .common import (
        PostProcessorTestCase,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class TestPostProcessor_try_utime(PostProcessorTestCase):
        def setUp(self):
            PostProcessorTestCase.setUp(self)
            self.tmp_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.tmp_dir, 'test_file')
            self.test_file_enc = encodeFilename(self.test_file)

# Generated at 2022-06-18 15:43:49.228227
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

    # Try to update the utime of the temporary file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Check if the utime of the temporary file has been updated
    assert os.path.getatime(temp_file.name) == current_time

# Generated at 2022-06-18 15:43:59.211988
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrcopy import XAttrMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .embedsubtitles import EmbedSubtitlePP
    from .fixthumbnail import FixThumbnailPP
    from .minmetadata import MinMetadataPP
    from .postprocessortrue import PostProcessorTrue
    from .postprocessorfalse import PostProcessorFalse
    from .metadatafromtitle import MetadataFromTitlePP

# Generated at 2022-06-18 15:44:07.737896
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil
    import sys

    if sys.version_info < (2, 6):
        return

    class DummyDownloader(object):
        def report_warning(self, msg):
            self.msg = msg

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a dummy downloader
    downloader = DummyDownloader()

    # Create a dummy postprocessor

# Generated at 2022-06-18 15:44:18.418207
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import YoutubeIE
    from ..postprocessor import PostProcessor
    from ..cache import Cache
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_http_client
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_response
    from ..compat import compat_urllib_parse_urlparse

# Generated at 2022-06-18 15:44:27.815430
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curr_time, curr_time)

    # Check if the utime of the file has been updated

# Generated at 2022-06-18 15:44:37.938462
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'restrictfilenames': True,
            }

        def to_screen(self, message):
            print(message)

        def to_stderr(self, message):
            print(message, file=sys.stderr)

        def report_warning(self, message):
            print(message, file=sys.stderr)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tempdir = tempfile

# Generated at 2022-06-18 15:44:47.080119
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import unittest

    from ..compat import PY2

    from .common import FakeYDL

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.test_file = tempfile.NamedTemporaryFile(delete=False)
            self.test_file.close()
            self.test_file_name = self.test_file.name
            self.test_file_time = time.time()
            self.test_file_time_2 = self.test_file_time + 1
            self.test_

# Generated at 2022-06-18 15:44:57.910649
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat

# Generated at 2022-06-18 15:45:07.672559
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import stat

    class FakeDownloader():
        def report_warning(self, msg):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.close()
    # Create a PostProcessor object
    pp = FakePostProcessor(FakeDownloader())
    # Get the file's modification time

# Generated at 2022-06-18 15:45:27.436578
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    filepath = os.path.join(tmpdir, 'file')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get current time
    curtime = time.time()

    # Set a new time
    newtime = curtime - 100

    # Set a new time
    pp = PostProcessor(None)
    pp.try_utime(filepath, newtime, newtime)

    # Check that the new time is correct
    stat = os.stat(filepath)
    assert stat.st_atime == newtime
    assert stat.st_mtime == newtime

    # Remove temporary directory


# Generated at 2022-06-18 15:45:35.066931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:45:43.004503
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_postprocessor import _test_try_utime

    ydl = FakeYDL()
    ydl.params['download_archive'] = 'archive'
    ydl.params['daterange'] = DateRange('20010101', '20010101')
    ydl.add_post_processor(PostProcessor())
    ydl.add_info_extractor(None)
    ydl.add_default_info_extractors()
    ydl.download(['http://example.com/video.mp4'])

    _test_try_utime(ydl.post_processors[0])

# Generated at 2022-06-18 15:45:52.752262
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        raise Exception('This test does not work on Windows')

    pp = PostProcessor(None)
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:45:59.496340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:08.645644
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:18.285484
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the try_utime method
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Get the modification time of the file
    modtime = os.path

# Generated at 2022-06-18 15:46:25.759261
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (2, 6):
        return

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:35.990676
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the time of the file

# Generated at 2022-06-18 15:46:46.837449
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    from .downloader import FileDownloader
    from .extractor import gen_extractors

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:47:18.954549
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the modification time of the temporary file to the current time
    pp.try_utime(tmpfile, curtime, curtime)

    # Check that the modification time of the temporary file is the current time
    assert os.path.getmtime(tmpfile) == curtime

    # Remove the temporary directory
    shutil.rmtree(tmpdir)