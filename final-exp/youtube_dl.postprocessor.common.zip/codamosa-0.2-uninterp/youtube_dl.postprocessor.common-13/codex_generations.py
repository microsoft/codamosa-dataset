

# Generated at 2022-06-18 15:37:26.327735
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    from ..utils import (
        encodeFilename,
    )

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the atime and mtime to the current time
    pp.try_utime(tmpfile, curtime, curtime)

    # Get the atime and mtime
    st = os.stat(encodeFilename(tmpfile))

    # Check if the atime and mtime are correct

# Generated at 2022-06-18 15:37:34.247437
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .embedthumbnail import EmbedThumbnailPP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrmpp import XAttrMetadataPP

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class TestDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.add_post_processor(TestPostProcessor())


# Generated at 2022-06-18 15:37:44.458066
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class MockDownloader(object):
        def report_warning(self, msg):
            self.msg = msg

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:54.317627
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        temp_file = os.path.join(temp_dir, 'test_file')
        with open(temp_file, 'w') as f:
            f.write('test')
        atime = time.time() - 100
        mtime = time.time() - 50
        pp = PostProcessor(None)
        pp.try_utime(temp_file, atime, mtime)
        assert os.path.getatime(temp_file) == atime
        assert os.path.getmtime(temp_file) == mtime
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:38:04.472918
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the atime and mtime of the file to now
    pp.try_utime(filepath, now, now)

    # Get the atime and mtime of the file
    st = os.stat(filepath)
    atime = st[stat.ST_ATIME]

# Generated at 2022-06-18 15:38:15.728377
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..compat import compat_os_name
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..postprocessor.common import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegVideoConvertorPP
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestFileDownloader(FileDownloader):
        def __init__(self, params):
            super(TestFileDownloader, self).__

# Generated at 2022-06-18 15:38:27.523941
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import sys

    from ..utils import PostProcessor

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:38.538309
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse

# Generated at 2022-06-18 15:38:46.261044
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Get the file path
    filepath = tmpfile.name
    # Close the temporary named file
    tmpfile.close()
    # Set the file path read-only
    os.chmod(filepath, stat.S_IREAD)

    # Create a PostProcessor object
    pp = PostProcessor(None)
    # Get the current time
    atime = time.time()
    mtime = atime + 10
    # Try to update the utime of the file

# Generated at 2022-06-18 15:38:57.222854
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:05.872915
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    from ..compat import compat_os_name
    from ..utils import DateRange

    if compat_os_name == 'nt':
        return

    pp = PostProcessor(None)
    fd, fname = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-18 15:39:15.456531
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test_PostProcessor_try_utime-')

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the last modification time of the temporary file
    pp.try_utime(temp_file, current_time, current_time)

    # Get the last modification time of the temporary file
    file_stat = os.stat(temp_file)

    # Check if the last modification

# Generated at 2022-06-18 15:39:20.941971
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test'), 'w')
        f.close()
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:39:28.335663
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import DateRange


# Generated at 2022-06-18 15:39:39.829205
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.utime_called = False

        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            self.utime_called = True
            return [], info


# Generated at 2022-06-18 15:39:48.827211
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), curtime, curtime)

    # Get the access and modification time of the file
    st = os.stat(os.path.join(tmpdir, 'test'))

    # Remove the temporary directory

# Generated at 2022-06-18 15:40:00.382746
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file modification time to the current time
    pp.try_utime(filepath, cur_time, cur_time)

    # Get the file modification time
    file_time = os.path.getmtime(filepath)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:40:07.725311
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp(dir=temp_dir)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

    # Set the current time as the access and modification time of the temporary file
    pp.try_utime(temp_file_path, current_time, current_time)

    # Get the access and modification time of the temporary file
    file_stat = os.stat(temp_file_path)

    # Check that the access and modification time of the temporary file are the same

# Generated at 2022-06-18 15:40:17.773631
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the temporary file
    pp.try_utime(tmpfile, curr_time, curr_time)

    # Check if the utime of the temporary file has been updated
    assert os.path.getatime(tmpfile) == curr_time
    assert os.path.getmtime(tmpfile) == curr_

# Generated at 2022-06-18 15:40:28.173745
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test'))

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test'), mtime, mtime)

    # Get the modification time of the file

# Generated at 2022-06-18 15:40:38.730581
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a postprocessor
    pp = PostProcessor(None)

    # Update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the time of the file has been updated

# Generated at 2022-06-18 15:40:47.924772
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Close the temporary file
    os.close(fd)

    # Remove the temporary file
    os.remove(temp_file)

    # Create a new temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Close the temporary file
    os.close(fd)

    # Get the current time
    curr_time = time.time()

    # Set the access and modification times of the temporary file

# Generated at 2022-06-18 15:40:59.734759
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat

    def _test_try_utime(pp, path, atime, mtime, errnote='Cannot update utime of file'):
        pp.try_utime(path, atime, mtime, errnote)
        assert os.path.getatime(path) == atime
        assert os.path.getmtime(path) == mtime

    def _test_try_utime_fail(pp, path, atime, mtime, errnote='Cannot update utime of file'):
        pp.try_utime(path, atime, mtime, errnote)
        assert os.path.getatime(path) != atime
        assert os.path.getmtime(path) != mtime


# Generated at 2022-06-18 15:41:11.853395
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    from ..downloader import Downloader
    from ..utils import DateRange

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    now = time.time()

    # Create a downloader
    dl = Downloader(params={'noprogress': True, 'quiet': True})

    # Create a postprocessor
    pp = PostProcessor(dl)

    # Set the file modification time to now
    pp.try_utime(tmp_file, now, now)

    # Get the file modification time
    file_mtime = os.path.getmtime(tmp_file)

    # Check if the file modification time is now
    assert file_mtime == now

    # Set the file modification

# Generated at 2022-06-18 15:41:21.968724
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str

    # Create a downloader
    downloader = Downloader({
        'outtmpl': '%(id)s.%(ext)s',
        'format': 'bestaudio/best',
        'postprocessor_args': ['ffmpeg_location', '/usr/bin/ffmpeg'],
        'nooverwrites': True,
        'noplaylist': True,
        'logger': False,
        'age_limit': DateRange('0-11'),
    })
    downloader.add_info_extractor(gen_extractors()[0])

    # Create a postprocessor
    postprocessor = PostProcessor(downloader)

    # Create a file

# Generated at 2022-06-18 15:41:30.640968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    from ..utils import PostProcessor

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:41.214039
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    class DummyDownloader():
        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Get the file name
    temp_file_name = temp_file.name
    # Close the temporary file
    temp_file.close()
    # Create a dummy downloader
    dummy_downloader = DummyDownloader()
    # Create

# Generated at 2022-06-18 15:41:52.330680
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()
    tempfilepath = os.path.join(tempdir, 'tempfile')
    with open(tempfilepath, 'w') as f:
        f.write('test')

    pp = PostProcessor(None)
    pp.try_utime(tempfilepath, 0, 0)
    assert os.path.getatime(tempfilepath) == 0
    assert os.path.getmtime(tempfilepath) == 0

    pp.try_utime(tempfilepath, time.time(), time.time())
    assert os.path.getatime(tempfilepath) == os.path.getmtime(tempfilepath)


# Generated at 2022-06-18 15:42:03.563695
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    from ..utils import DateRange

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get the current time
    now = time.time()
    # Set the file timestamp to the current time
    os.utime(tmpfile, (now, now))
    # Create a PostProcessor object
    pp = PostProcessor(None)
    # Set the file timestamp to the current time + 1
    pp.try_utime(tmpfile, now + 1, now + 1)
    # Get the file timestamp
    stat = os.stat(tmpfile)
    # Check if the file timestamp is the current time +

# Generated at 2022-06-18 15:42:14.987927
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the time of the file has been changed

# Generated at 2022-06-18 15:42:29.803221
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import os

    from ..utils import (
        PostProcessor,
    )

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:40.165091
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s%(ext)s',
                'nopart': True,
                'quiet': True,
            }

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)


# Generated at 2022-06-18 15:42:51.629414
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor
    pp = PostProcessor(None)

    # Try to update the file's time
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Check that the file's time has been updated
    st = os.stat(os.path.join(tmpdir, 'test'))
    assert st.st_

# Generated at 2022-06-18 15:43:01.250422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import stat
    import os

    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:43:08.836307
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:43:18.714856
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor
    import os
    import time
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Create a temporary downloader
    downloader = Downloader(params={'noprogress': True, 'quiet': True, 'outtmpl': tmpfile.name})
    # Create a temporary postprocessor
    postprocessor = PostProcessor(downloader)
    # Get the file path
    file

# Generated at 2022-06-18 15:43:29.443778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), cur_time, cur_time)

    # Check if the utime of the file is updated

# Generated at 2022-06-18 15:43:37.393325
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    from .test_postprocessor import _make_fake_info
    from .test_postprocessor import _make_fake_file
    import os
    import time
    import sys
    import stat

    def _fake_utime(path, times):
        pass

    def _fake_report_warning(msg):
        pass

    def _fake_report_error(msg):
        pass

    def _fake_report_info(msg):
        pass

    def _fake_report_file_progress(percent):
        pass

    def _fake_to_screen(msg):
        pass

    def _fake_to_stderr(msg):
        pass

    def _fake_to_console_title(msg):
        pass


# Generated at 2022-06-18 15:43:47.318205
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:43:54.818511
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    pp.try_utime('/tmp/foo', 1, 2)
    assert ydl.warnings == []
    pp.try_utime('/tmp/foo', 1, 2, 'Cannot update utime of file')
    assert ydl.warnings == ['Cannot update utime of file']

# Generated at 2022-06-18 15:44:18.266100
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import errno
    import platform

    if platform.system() == 'Windows':
        import ctypes
        import ctypes.wintypes

        CreateFile = ctypes.windll.kernel32.CreateFileW
        CloseHandle = ctypes.windll.kernel32.CloseHandle
        SetFileTime = ctypes.windll.kernel32.SetFileTime
        GetFileTime = ctypes.windll.kernel32.GetFileTime
        GetLastError = ctypes.windll.kernel32.GetLastError

        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        FILE_SHARE_READ = 1
        FILE_SHARE_WRITE = 2

# Generated at 2022-06-18 15:44:27.682831
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeYDL
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .xattrmpp import XAttrSetPP
    from .ffmpegembedthumbnail import FFmpegEmbedThumbnailPP

    # Create a fake downloader
    ydl = FakeYDL()
    ydl.params['writethumbnail'] = True
    ydl.params['writeinfojson'] = True

# Generated at 2022-06-18 15:44:37.801392
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    t = time.time()

    # Set the file's modification time to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), t, t)

    # Get the file's modification time
    t2 = os.path.getmtime(os.path.join(tmpdir, 'test'))

    # Remove the temporary

# Generated at 2022-06-18 15:44:46.979553
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Wait one second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the file's modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime)

    # Check that the file's

# Generated at 2022-06-18 15:44:57.824711
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import shutil
    import tempfile
    import unittest

    from ..utils import (
        encodeFilename,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(title)s.%(ext)s',
                'restrictfilenames': True,
            }

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

    class TestPostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.tempdir

# Generated at 2022-06-18 15:45:07.596461
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import stat
    from ..compat import compat_get_terminal_size

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    tmpfile = os.path.join(tmpdir, 'test.file')
    with open(tmpfile, 'wb') as f:
        f.write(b'foo')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(tmpfile, current_time, current_time)

    # Get the file stats
    file_stats = os.stat(tmpfile)

    # Check if the file

# Generated at 2022-06-18 15:45:18.519505
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a downloader
    ydl = YoutubeDL(params={'logger': YoutubeDL.logger_class('test')})

    # Create a postprocessor
    pp = PostProcessor(ydl)

    # Set the time of the file to the current time

# Generated at 2022-06-18 15:45:22.454177
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeYDL
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from .common import PostProcessorTest

    class TestPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    test_cases = [
        {
            'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
            'note': 'Test utime of file',
        },
    ]

    for t in test_cases:
        with PostProcessorTest(t['url'], ie=YoutubeIE, pp=TestPP) as test:
            test.run()

# Generated at 2022-06-18 15:45:32.080324
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class DummyDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s.%(ext)s'}

        def report_warning(self, errnote):
            self.errnote = errnote

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a dummy file
    dummy_file = os.path.join(tmpdir, 'dummy.txt')

# Generated at 2022-06-18 15:45:41.985711
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import shutil
    import tempfile
    import unittest

    from ..utils import (
        encodeFilename,
    )

    class FakeDownloader(object):
        def report_warning(self, msg):
            self.msg = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class TestPostProcessor(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.downloader = FakeDownloader()
            self.pp = FakePostProcessor(self.downloader)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-18 15:46:14.447911
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    if sys.version_info < (2, 6):
        return

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    pp = DummyPostProcessor(DummyDownloader())

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:23.183021
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file time to the current time
    pp.try_utime(file_path, current_time, current_time)

    # Get the file time
    file_time = os.path.getmtime(file_path)

    # Remove the temporary directory


# Generated at 2022-06-18 15:46:34.133448
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtubedl_test_')

    # Create a file in the temporary directory
    f = open(os.path.join(temp_dir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a YoutubeDL object
    ydl = YoutubeDL({'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s')})

    # Create a PostProcessor object
    pp = PostProcessor(ydl)

    # Get the path of the file
    path = os

# Generated at 2022-06-18 15:46:44.605247
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_downloader import MockYDL
    from .test_extractor import MockIE
    from .test_postprocessor import MockPP

    class MockPP2(MockPP):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    class MockPP3(MockPP):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0, 'Cannot update utime of file')
            return [], info


# Generated at 2022-06-18 15:46:53.355723
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (3, 0):
        import codecs
        open_mode = 'wb'
    else:
        open_mode = 'w'


# Generated at 2022-06-18 15:47:04.412402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    import tempfile
    import os
    import time
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': tmpfile})

    # Create a PostProcessor
    pp = PostProcessor(ydl)

    # Create a DateRange
    dr = DateRange(0, 0)

    # Test try_utime
    pp.try_utime(tmpfile, dr.start_time, dr.end_time)

    # Check if the file has been modified

# Generated at 2022-06-18 15:47:15.372038
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class DummyDownloader():
        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tempdir = tempfile.mkdtemp()