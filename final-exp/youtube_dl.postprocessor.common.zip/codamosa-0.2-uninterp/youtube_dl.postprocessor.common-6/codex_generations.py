

# Generated at 2022-06-18 15:37:28.661097
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.close()

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the access and modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test'), now, now)

    # Check that the access and modification time of the file have been updated
    assert os.stat(os.path.join(tmpdir, 'test')).st_atime == now

# Generated at 2022-06-18 15:37:35.526569
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class FakeDownloader():
        def __init__(self):
            self.params = {'verbose': True}

        def report_warning(self, msg):
            self.msg = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:46.699582
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import shutil
    import os

    from ..utils import PostProcessor

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            return [], information

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.txt')

# Generated at 2022-06-18 15:37:55.992413
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.test_path = None
            self.test_atime = None
            self.test_mtime = None
            self.test_errnote = None

        def run(self, information):
            self.test_path = information['filepath']
            self.test_atime = information['atime']
            self.test_mtime = information['mtime']
            self.test_errnote = information['errnote']
            return [], information


# Generated at 2022-06-18 15:38:06.309699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    downloader = Downloader(params={'noplaylist': True, 'age_limit': 18, 'download_archive': 'archive.txt'})
    downloader.add_info_extractor(gen_extractors()[0])
    downloader.add_post_processor(TestPostProcessor(downloader))
    downloader.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 15:38:16.903766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    from ..utils import encodeFilename

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:29.243409
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    cur_time = time.time()

    # Set the atime and mtime of the file to the current time
    pp = PostProcessor(None)
    pp.try_utime(temp_file.name, cur_time, cur_time)

    # Get the atime and mtime of the file
    file_stat = os.stat(temp_file.name)
    file_atime = file_stat

# Generated at 2022-06-18 15:38:40.253262
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from ..compat import compat_os_name
    from ..utils import (
        DateRange,
        encodeFilename,
        PostProcessingError,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

        def run(self, information):
            self.try_utime(information['filepath'], 0, 0, 'Cannot update utime of file')
            return [], information

    class TestPostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.test_file = tempfile.NamedTemporaryFile(delete=False)
            self.test_file.close()

# Generated at 2022-06-18 15:38:50.797496
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file
    file_path = os.path.join(temp_dir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the file
    pp.try_utime(file_path, current_time, current_time)

    # Check if the time of the file has been updated
    assert os.path.getmtime(file_path) == current_time

    # Remove the temporary directory

# Generated at 2022-06-18 15:39:01.369750
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    from ..utils import PostProcessor

    def _test_try_utime(atime, mtime):
        tmpdir = tempfile.mkdtemp()
        try:
            tmpfile = os.path.join(tmpdir, 'test_file')
            with open(tmpfile, 'w') as f:
                f.write('test')
            pp = PostProcessor(None)
            pp.try_utime(tmpfile, atime, mtime)
            assert os.path.getatime(tmpfile) == atime
            assert os.path.getmtime(tmpfile) == mtime
        finally:
            shutil.rmtree(tmpdir)

    _test_try_utime(0, 0)
    _test_try_

# Generated at 2022-06-18 15:39:12.465700
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    class FakeDownloader(object):
        def __init__(self):
            self.to_stderr = sys.stderr

        def report_warning(self, msg):
            print(msg, file=self.to_stderr)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    pp = FakePostProcessor(FakeDownloader())

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:22.611876
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmppath = os.path.join(tmpdir, 'test.tmp')
    with open(tmppath, 'wb') as f:
        f.write(b'Hello World!')

    # Get the file's modification time
    mtime = os.stat(tmppath).st_mtime

    # Wait a second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the file's modification time
    pp.try_utime(tmppath, None, mtime)

    # Check that the file's modification time has been updated


# Generated at 2022-06-18 15:39:31.361919
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check if the utime of the file has been updated

# Generated at 2022-06-18 15:39:42.086230
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    if sys.version_info < (3, 0):
        from urllib import pathname2url
    else:
        from urllib.request import pathname2url

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:50.478790
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    def _test_try_utime(atime, mtime):
        tmpdir = tempfile.mkdtemp()
        try:
            fname = os.path.join(tmpdir, 'test.txt')
            with open(fname, 'w') as f:
                f.write('test')
            pp = PostProcessor(None)
            pp.try_utime(fname, atime, mtime)
            stat = os.stat(fname)
            assert stat.st_atime == atime
            assert stat.st_mtime == mtime
        finally:
            shutil.rmtree(tmpdir)

    _test_try_utime(0, 0)
    _test_try

# Generated at 2022-06-18 15:39:57.281656
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_file')
    with open(temp_file, 'w') as f:
        f.write('test')
    time.sleep(1)
    pp = PostProcessor(None)
    pp.try_utime(temp_file, 0, 0)
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:40:00.594560
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification times of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the access and modification times of the file

# Generated at 2022-06-18 15:40:07.888510
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..compat import compat_setenv
    from ..compat import compat_getenv
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 15:40:17.968545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import stat

    class DummyDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a dummy downloader
    downloader = DummyDownloader()

    # Create a dummy postprocessor
    postprocessor = DummyPostProcessor(downloader)

    # Get the

# Generated at 2022-06-18 15:40:28.305929
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 15:40:37.610087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str

    class FakeInfoExtractor(object):
        def __init__(self, ie_name):
            self._ie_name = ie_name


# Generated at 2022-06-18 15:40:46.763530
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:52.307291
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(DummyPostProcessor, self).__init__(downloader)
            self.utime_called = False

        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            self.utime_called = True
            return [], info

    class DummyDownloader(Downloader):
        def __init__(self, params):
            super(DummyDownloader, self).__init__(params)
            self.ie = gen_extractors()[0]


# Generated at 2022-06-18 15:41:02.002898
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()
    # Get the file's modification time
    mtime = os.stat(os.path.join(tmpdir, 'test.txt')).st_mtime
    # Create a PostProcessor object
    pp = PostProcessor(None)
    # Call the try_utime method
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime)
    # Check that the file's modification time has not changed
    assert m

# Generated at 2022-06-18 15:41:13.639892
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    # Create a downloader
    ydl = Downloader()
    ydl.add_info_extractor(YoutubeIE())

    # Create a PostProcessor
    pp = PostProcessor(ydl)

    # Create a file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Set the file's mtime to a date in the future
    import time
    future_date = int(time.time()) + 100000
    os.utime(path, (future_date, future_date))

    # Check that the file's mtime is in the future
    assert os.path.getmtime(path) > int(time.time())

    # Run the

# Generated at 2022-06-18 15:41:20.477746
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    temp_dir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(temp_dir, 'test_file')
        with open(test_file, 'w') as f:
            f.write('test')

        pp = PostProcessor(None)
        pp.try_utime(test_file, time.time(), time.time())

    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:41:30.070947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:40.644458
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import stat
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a test file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    curtime = time.time()

    # Set the file's access and modification times
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Get the file's access and modification times

# Generated at 2022-06-18 15:41:52.028833
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(filepath, cur_time, cur_time)

    # Check that the access and modification time of the file are the current time

# Generated at 2022-06-18 15:41:58.555179
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time

    # Create a temporary file
    fd, filename = tempfile.mkstemp(prefix='youtubedl_test_')
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the temporary file
    pp.try_utime(filename, current_time, current_time)

    # Check that the utime of the temporary file has been updated
    assert os.path.getatime(filename) == current_time
    assert os.path.getmtime(filename) == current_time

    # Remove the temporary file
    os.remove(filename)

# Generated at 2022-06-18 15:42:11.289199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    class TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(TestInfoExtractor, self).__init__(downloader)


# Generated at 2022-06-18 15:42:18.420554
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import tempfile
    import shutil
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    fpath = os.path.join(tmpdir, 'test.txt')
    with open(fpath, 'w') as f:
        f.write('test')
    # Get the current time
    now = time.time()
    # Create a PostProcessor object
    pp = PostProcessor(None)
    # Call try_utime
    pp.try_utime(fpath, now, now)
    # Check the file's time
    stat = os.stat(fpath)
    assert stat.st_atime == now
    assert stat.st_mtime == now
    # Remove the temporary directory


# Generated at 2022-06-18 15:42:26.778301
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class FakeInfo(object):
        def __init__(self, url, upload_date):
            self.url = url
            self.upload_date = upload_date

    class FakeExtractor(object):
        def __init__(self, ie_key):
            self._type = ie_key

        def _real_extract(self, url):
            return FakeInfo(url, None)

    class FakeDownloader(Downloader):
        def __init__(self, params):
            Downloader.__init__(self, params)
            self.to_stderr = self.to_screen

# Generated at 2022-06-18 15:42:37.369881
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the file's mtime
    mtime = os.stat(os.path.join(tmpdir, 'test'))[stat.ST_MTIME]

    # Create a PostProcessor
    pp = PostProcessor(None)

    # Change the file's mtime
    pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())

    # Check if the file's mtime has changed
    assert mtime != os

# Generated at 2022-06-18 15:42:43.337916
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader(object):
        def report_warning(self, msg):
            self.msg = msg

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.path = 'path'
            self.atime = 1
            self.mtime = 2

    pp = FakePostProcessor(FakeDownloader())
    pp.try_utime(pp.path, pp.atime, pp.mtime)
    assert pp._downloader.msg == 'Cannot update utime of file'

# Generated at 2022-06-18 15:42:54.128551
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(filepath, curr_time, curr_time)

    # Get the time of the file
    file_time = os.path.getmtime(filepath)

    # Remove the temporary directory
    shut

# Generated at 2022-06-18 15:43:03.724315
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the

# Generated at 2022-06-18 15:43:10.097792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor
    pp = PostProcessor(None)

    # Get the file's atime and mtime
    st = os.stat(os.path.join(tmpdir, 'test.txt'))
    atime = st[stat.ST_ATIME]
    mtime = st[stat.ST_MTIME]

    # Change the file's atime and mtime

# Generated at 2022-06-18 15:43:17.695087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import time
    import tempfile
    import os
    import shutil
    import stat

    def _test_try_utime(path, atime, mtime, errnote):
        pp = PostProcessor(YoutubeDL())
        pp.try_utime(path, atime, mtime, errnote)
        assert os.stat(path).st_atime == atime
        assert os.stat(path).st_mtime == mtime

    def _test_try_utime_fail(path, atime, mtime, errnote):
        pp = PostProcessor(YoutubeDL())
        pp.try_utime(path, atime, mtime, errnote)
        assert os.stat(path).st_atime != atime
        assert os.stat(path).st

# Generated at 2022-06-18 15:43:29.066616
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_postprocessor import TestPostProcessor

    class TestPP(TestPostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info


# Generated at 2022-06-18 15:43:42.532761
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil
    import stat
    import sys

    if sys.platform == 'win32':
        return

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Close the temporary file
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the temporary file
    pp.try_utime(temp_file, current_time, current_time)

    # Get the access and modification time of the temporary file

# Generated at 2022-06-18 15:43:50.547198
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor
    from ..cache import Cache
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 15:44:00.892467
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the modification time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the modification time of the file has been changed

# Generated at 2022-06-18 15:44:08.500238
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    class DummyDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:44:19.202467
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    # Create a downloader
    ydl = Downloader(params={'noplaylist': True, 'quiet': True, 'simulate': True})
    ydl.add_info_extractor(gen_extractors()[0])

    # Create a postprocessor
    pp = PostProcessor(ydl)

    # Create a file
    import tempfile
    import time
    import os
    import stat

    fd, filename = tempfile.mkstemp()
    os.close(fd)
    os.remove(filename)

    # Create a file with the current time
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    current_

# Generated at 2022-06-18 15:44:28.463294
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    from .downloader import FileDownloader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a FileDownloader
    ydl = FileDownloader({})

    # Create a PostProcessor
    pp = PostProcessor(ydl)

    # Get the current time
    t = time.time()

    # Set the time of the temporary file
    pp.try_utime(tmpfile, t, t)

    # Check that the time of the temporary file has been set
    assert os.path.getmtime(tmpfile) == t

    # Remove the temporary directory
    shut

# Generated at 2022-06-18 15:44:38.786730
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Get the time of the file

# Generated at 2022-06-18 15:44:47.556001
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL
    from .test_postprocessor import PostProcessorTest

    class TestPostProcessor(PostProcessorTest):
        def test_try_utime(self):
            ydl = FakeYDL()
            pp = PostProcessor(ydl)
            pp.try_utime('file', 1, 2)
            self.assertEqual(ydl.msgs, ['Cannot update utime of file'])
            ydl.msgs = []
            pp.try_utime('file', 1, 2, 'msg')
            self.assertEqual(ydl.msgs, ['msg'])


# Generated at 2022-06-18 15:44:58.591724
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test_PostProcessor_try_utime-')

    # Create a file
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, dir=temp_dir)
    temp_file.close()

    # Get the file's modification time
    mtime = os.path.getmtime(temp_file.name)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the file's modification time
    pp.try_utime(temp_file.name, mtime, mtime)

    # Check that the file's modification time has been updated

# Generated at 2022-06-18 15:45:08.181183
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s.%(ext)s'}

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:45:25.192446
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)
            self.utime_called = False

        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            self.utime_called = True
            return [], information


# Generated at 2022-06-18 15:45:33.982239
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.txt')
    with open(temp_file, 'w') as f:
        f.write('test')

    pp = PostProcessor(None)
    pp.try_utime(temp_file, 0, 0)
    assert os.path.getmtime(temp_file) == 0
    assert os.path.getatime(temp_file) == 0

    pp.try_utime(temp_file, time.time(), time.time())
    assert os.path.getmtime(temp_file) == os.path.getatime(temp_file)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:45:42.889969
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(os.path.join(tmpdir, 'test'), current_time, current_time)

    # Get the last modification time
    mtime = os.stat(os.path.join(tmpdir, 'test')).st_mtime

    # Remove the

# Generated at 2022-06-18 15:45:52.642420
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file inside the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file modification time
    pp.try_utime(filepath, current_time, current_time)

    # Check that the file modification time has been changed
    assert os.stat(filepath).st_mtime == current_time

    # Remove the temporary directory
    shut

# Generated at 2022-06-18 15:45:58.634441
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_request_urlopen
    from ..compat import compat_urllib_request

# Generated at 2022-06-18 15:46:07.867237
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curr_time, curr_time)

    # Get the time of the file

# Generated at 2022-06-18 15:46:17.231043
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import sys

    if sys.version_info < (2, 6):
        return

    tmpdir = tempfile.mkdtemp()
    try:
        fpath = os.path.join(tmpdir, 'test.file')
        with open(fpath, 'wb') as f:
            f.write(b'a')
        atime = mtime = time.time() - 3600
        os.utime(fpath, (atime, mtime))
        pp = PostProcessor(None)
        pp.try_utime(fpath, atime, mtime)
        assert os.path.getatime(fpath) == atime
        assert os.path.getmtime(fpath) == mtime
    finally:
        shutil

# Generated at 2022-06-18 15:46:24.971294
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}
            self.to_stderr = lambda x: x

        def report_warning(self, errnote):
            self.errnote = errnote

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:35.927070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    class TestDownloader(Downloader):
        def __init__(self, params):
            self.params = params
            self.to_stdout = lambda x: x
            self.to_stderr = lambda x: x
            self.to_screen = lambda x: x
            self.report_warning = lambda x: x
            self.report_error = lambda x: x
            self.report_file_already_downloaded = lambda x: x


# Generated at 2022-06-18 15:46:46.847317
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    from ..compat import compat_os_name

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(tmpfile, current_time, current_time)

    # Check that the time of the file has changed

# Generated at 2022-06-18 15:47:21.439744
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the time of the file has been updated