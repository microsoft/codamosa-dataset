

# Generated at 2022-06-18 15:37:29.248048
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # test with valid time
    pp = PostProcessor(None)
    pp.try_utime(test_file, time.time(), time.time())

    # test with invalid time
    pp.try_utime(test_file, -1, -1)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:37:35.965118
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import stat
    import os
    import subprocess

    from ..utils import (
        encodeFilename,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Get the file's path
    tmpfile_path = tmpfile.name
    # Get the file's modification time
    tmpfile_mtime = os.stat(tmpfile_path).st_mtime
   

# Generated at 2022-06-18 15:37:47.072043
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class MockDownloader:
        def __init__(self):
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:56.216467
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    from ..utils import PostProcessor
    from ..compat import compat_os_name

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the temporary file
    pp.try_utime(tmp_file.name, cur_time, cur_time)

    # Check the time of the temporary file
    stat_info = os.stat(tmp_file.name)
    assert stat_info

# Generated at 2022-06-18 15:38:07.761769
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    from ..compat import compat_os_name
    from ..utils import DateRange

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test file')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), curr_time, curr_time)

    # Get the modification time of the file

# Generated at 2022-06-18 15:38:17.543418
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the temporary file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Check if the utime of the temporary file has been updated
    assert os.stat(temp_file.name).st_atime == current_time

# Generated at 2022-06-18 15:38:29.475157
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    if sys.version_info < (3, 0):
        from backports import tempfile
    else:
        import tempfile

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class TestDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': '%(id)s'}

        def report_warning(self, errnote):
            print(errnote)

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

# Generated at 2022-06-18 15:38:40.522869
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name

    class MockDownloader(Downloader):
        def __init__(self, params):
            super(MockDownloader, self).__init__(params)
            self.report_warning_msgs = []

        def report_warning(self, msg):
            self.report_warning_msgs.append(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)

    if compat_os_name == 'nt':
        # Windows does not support utime
        return

    # Create a mock downloader

# Generated at 2022-06-18 15:38:51.718291
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor

    tmpdir = tempfile.mkdtemp()
    try:
        fpath = os.path.join(tmpdir, 'test.txt')
        with open(fpath, 'w') as f:
            f.write('test')
        ftime = time.time() - 1000
        os.utime(fpath, (ftime, ftime))
        pp = PostProcessor(YoutubeDL())
        pp.try_utime(fpath, time.time(), time.time())
        assert os.path.getmtime(fpath) == os.path.getatime(fpath)
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:39:01.960981
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the utime of the file has been updated

# Generated at 2022-06-18 15:39:11.749493
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import tempfile

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    t = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file's modification time to the current time
    pp.try_utime(fname, t, t)

    # Get the file's modification time
    t2 = os.path.getmtime(fname)

    # Remove the temporary file
    os.remove(fname)

    # Check if the file's modification time is the same as the current time
    assert t == t2

# Generated at 2022-06-18 15:39:21.811920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import errno
    import platform
    import subprocess
    from ..utils import encodeFilename

    if sys.platform == 'win32':
        import ctypes
        import ctypes.wintypes
        from ctypes.wintypes import DWORD

        CreateSymbolicLink = ctypes.windll.kernel32.CreateSymbolicLinkW
        CreateSymbolicLink.argtypes = (ctypes.c_wchar_p, ctypes.c_wchar_p, DWORD)
        CreateSymbolicLink.restype = ctypes.c_ubyte

        def create_symlink(source, link_name):
            flags = 1 if os.path.isdir(source) else 0

# Generated at 2022-06-18 15:39:28.825463
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    class MockDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(title)s.%(ext)s',
                'restrictfilenames': True,
            }

        def report_warning(self, msg):
            print(msg)

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:40.216183
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    from ..utils import PostProcessor
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:49.137542
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    import os

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    now = datetime.datetime.now()

    # Get the current time in seconds since the epoch
    now_epoch = time.mktime(now.timetuple())

    # Get the current time in microseconds since the epoch
    now_epoch_micro = now_epoch * 1000000 + now.microsecond

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the utime of the temporary file
    pp.try_utime(path, now_epoch, now_epoch)

    # Get the utime of the temporary file

# Generated at 2022-06-18 15:40:00.636481
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.to_stderr = sys.stderr.write
            self.params = {}

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    pp = DummyPostProcessor(DummyDownloader())

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:07.916768
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import stat

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file
    pp.try_utime(filepath, curtime, curtime)

    # Check if the access and modification time of the file are correct
    st = os.stat(filepath)
    assert st.st_at

# Generated at 2022-06-18 15:40:18.017364
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file's modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime + 1)

    # Check that the file's modification time has been updated

# Generated at 2022-06-18 15:40:28.412740
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import errno
    import platform

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    t = time.time()

    # Set the file's modification time to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), t, t)

    # Get the file's modification time

# Generated at 2022-06-18 15:40:36.775056
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    class FakeDownloader():
        def __init__(self):
            self.params = {
                'outtmpl': '%(title)s.%(ext)s',
                'restrictfilenames': True,
                'nooverwrites': True,
            }

        def to_screen(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:40:48.766604
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    class DummyDownloader:
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s%(ext)s',
                'restrictfilenames': True,
            }

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            print(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file

# Generated at 2022-06-18 15:40:59.809669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    from ..utils import (
        encodeFilename,
        PostProcessingError,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            self.test_dir = None
            self.test_file = None
            self.test_file_path = None
            self.test_file_atime = None
            self.test_file_mtime = None

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = tempfile.NamedTemporaryFile(dir=self.test_dir, delete=False)
            self.test_file_path = self.test_file.name

# Generated at 2022-06-18 15:41:11.861386
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..postprocessor.common import FFmpegPostProcessor
    from ..postprocessor.xattrpp import XAttrMetadataPP
    from ..postprocessor.embedthumbnail import EmbedThumbnailPP
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP
    from ..postprocessor.metadatafromtitle import MetadataFromTitlePP
    from ..postprocessor.xattrpp import XAttrMetadataPP
    from ..postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from ..postprocessor.ffmpegthumbnail import FFmpegThumbnailPP
    from ..postprocessor.fixup import FixupPP
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP

# Generated at 2022-06-18 15:41:19.851394
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_request_urlopen
    from ..compat import compat_urllib_request_build_opener
    from ..compat import compat_urllib

# Generated at 2022-06-18 15:41:29.595542
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    class DummyDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:41:40.086906
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor
    from ..cache import Cache

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestDownloader(Downloader):
        def __init__(self, params):
            super(TestDownloader, self).__init__(params)
            self.cache = Cache(params)
            self.params = params
            self.to_screen = lambda *args, **kargs: None

    class TestInfoExtractor(object):
        IE_NAME = 'test'

# Generated at 2022-06-18 15:41:50.712157
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.close()

    # Get the file's modification time
    mtime = os.stat(os.path.join(tmpdir, 'test'))[stat.ST_MTIME]

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())

    # Check if the file's modification time has changed

# Generated at 2022-06-18 15:41:58.287202
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import sys
    import stat

    if sys.platform == 'win32':
        print('Skipping test_PostProcessor_try_utime on Windows')
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:06.751746
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Change the file's modification time
    os.utime(os.path.join(tmpdir, 'test.txt'), (curr_time, curr_time))

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file's modification time to the current time

# Generated at 2022-06-18 15:42:15.495068
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()
    try:
        filename = os.path.join(tempdir, 'test.mp4')
        with open(filename, 'wb') as f:
            f.write(b'\0' * 100)

        pp = PostProcessor(None)

        # Test that utime works
        pp.try_utime(filename, time.time(), time.time())

        # Test that utime fails
        pp.try_utime(filename, None, None)

    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-18 15:42:27.398394
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tempdir, 'test.file')
        with open(testfile, 'w') as f:
            f.write('test')

        pp = PostProcessor(None)
        pp.try_utime(testfile, time.time(), time.time())
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-18 15:42:38.239908
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the temporary file
    pp.try_utime(temp_file, current_time, current_time)

    # Check if the utime of the temporary file has been updated
    assert os.path.getatime(temp_file) == current_time
    assert os.path.getmtime(temp_file) == current_time

   

# Generated at 2022-06-18 15:42:48.680635
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys
    import stat

    if sys.platform == 'win32':
        import ctypes
        import ctypes.wintypes


# Generated at 2022-06-18 15:42:58.347876
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange

    class MockDownloader(Downloader):
        def __init__(self, params):
            self.params = params
            self.to_stderr = self.to_screen = self.report_warning

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.set_downloader(downloader)

    # Test that try_utime doesn't fail when the file doesn't exist
    pp = MockPostProcessor(MockDownloader({}))
    pp.try_utime('/path/to/file', 0, 0)

    # Test that try_utime doesn't fail when the file exists
    with open('/tmp/test_PostProcessor_try_utime', 'w') as f:
        f

# Generated at 2022-06-18 15:43:06.929777
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    downloader = Downloader({'outtmpl': '%(id)s.%(ext)s',
                             'format': 'best',
                             'nooverwrites': True,
                             'postprocessor_args': ['-ar', '44100'],
                             'daterange': DateRange(),
                             'noplaylist': True,
                             'nocheckcertificate': True,
                             'ignoreerrors': True,
                             'logger': True,
                             'test': True})

# Generated at 2022-06-18 15:43:18.298651
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .embedthumbnail import EmbedThumbnailPP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .embedthumbnail import EmbedThumbnailPP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

# Generated at 2022-06-18 15:43:29.413612
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import encodeFilename

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:43:37.380051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s%(ext)s',
                'verbose': True,
            }
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader


# Generated at 2022-06-18 15:43:45.008534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    from ..downloader import Downloader
    from ..utils import DateRange

    # Create a temporary file
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)

    # Create a downloader
    downloader = Downloader(params={})

    # Create a postprocessor
    pp = PostProcessor(downloader)

    # Get the current time
    now = time.time()

    # Set the file modification time to now
    pp.try_utime(filename, now, now)

    # Check that the file modification time is now
    assert os.stat(filename).st_mtime == now

    # Set the file modification time to now - 1
    pp.try_utime(filename, now - 1, now - 1)

    # Check that the file

# Generated at 2022-06-18 15:43:50.490580
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile

    # Create a temporary file
    fd, filename = tempfile.mkstemp()
    os.close(fd)

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the time of the temporary file
    pp.try_utime(filename, now, now)

    # Get the time of the temporary file
    stat = os.stat(filename)

    # Check if the time of the temporary file was updated
    assert stat.st_atime == now
    assert stat.st_mtime == now

    # Remove the temporary file
    os.remove(filename)

# Generated at 2022-06-18 15:44:15.592958
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the file's modification time
    pp.try_utime(filepath, curtime, curtime)

    # Check that the file's modification time has been changed
    st = os.stat(filepath)
    assert st.st_mtime == curtime



# Generated at 2022-06-18 15:44:22.799428
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    from ..utils import PostProcessor

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f.write('test')
    atime = time.time()
    mtime = atime - 100
    pp = PostProcessor(None)
    pp.try_utime(temp_file, atime, mtime)
    assert os.path.getatime(temp_file) == atime
    assert os.path.getmtime(temp_file) == mtime
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:44:33.058540
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Get the file's modification time
    file_mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Check that the file's modification time is not the current time
    assert curr_time != file_mtime



# Generated at 2022-06-18 15:44:42.880938
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    if sys.version_info < (3, 0):
        from io import open

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(temp_dir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the access and modification time of the file
    pp.try_utime(os.path.join(temp_dir, 'test.txt'), curr_time, curr_time)

    # Check that

# Generated at 2022-06-18 15:44:52.094544
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from ..compat import compat_os_name

    from ..utils import (
        PostProcessor,
        encodeFilename,
    )

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self.downloader = downloader
            self.utime_called = False

        def run(self, information):
            return [], information

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.utime_called = True
            super(TestPostProcessor, self).try_utime(path, atime, mtime, errnote)

    class TestDownloader(object):
        def __init__(self):
            self

# Generated at 2022-06-18 15:45:03.064923
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(title)s.%(ext)s',
                'restrictfilenames': True,
                'nooverwrites': False,
            }

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake file

# Generated at 2022-06-18 15:45:10.761548
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'wb')
    f.close()

    # Get the file's modification time
    mtime = os.stat(os.path.join(tmpdir, 'test')).st_mtime

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the file's modification time to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), time.time(), time.time())

    # Check that the file's modification time has been updated

# Generated at 2022-06-18 15:45:21.862030
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys
    from ..compat import compat_os_name
    from ..utils import DateRange

    if compat_os_name == 'nt':
        return

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    cur_time = time.time()

    # Get the file's modification time
    file_mtime = os.path.getmtime(temp_file.name)

    # Get the file's access time
    file_atime = os.path.get

# Generated at 2022-06-18 15:45:31.560646
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the access and modification time of the file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Check that the access and modification time of the file is the current time
    assert os.path.getatime(temp_file.name) == current_

# Generated at 2022-06-18 15:45:41.794266
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from ..utils import PostProcessor

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Check the utime of the file
    file_stat = os.stat(temp_file.name)
    assert file_stat.st_atime == current

# Generated at 2022-06-18 15:46:20.530753
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Change the time of the file
    pp.try_utime(file_path, curr_time, curr_time)

    # Check that the time of the file is correct
    file_stat = os.stat(file_path)

# Generated at 2022-06-18 15:46:29.701079
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curr_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curr_time, curr_time)

    # Get the access and modification time of the file

# Generated at 2022-06-18 15:46:37.527865
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()
    try:
        filepath = os.path.join(tmpdir, 'test_file')
        with open(filepath, 'w') as f:
            f.write('test')
        mtime = time.time() - 1000
        atime = mtime - 1000
        os.utime(filepath, (atime, mtime))
        pp = PostProcessor(None)
        pp.try_utime(filepath, atime, mtime)
        assert os.path.getmtime(filepath) == mtime
        assert os.path.getatime(filepath) == atime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:46:48.155734
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Check that the time of the file is the current time

# Generated at 2022-06-18 15:46:55.210380
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..compat import compat_makedirs

    tmpdir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(tmpdir, 'test.file')
        compat_makedirs(os.path.dirname(test_file))
        with open(test_file, 'wb') as f:
            f.write(b'foobar')
        pp = PostProcessor(None)
        pp.try_utime(test_file, time.time() - 100, time.time() - 100)
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:47:05.448407
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    class FakeDownloader(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            pass

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a fake downloader
    downloader = FakeDownloader()

    # Create a fake postprocessor

# Generated at 2022-06-18 15:47:11.977683
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.txt')
    with open(temp_file, 'w') as f:
        f.write('test')

    pp = PostProcessor(None)
    pp.try_utime(temp_file, time.time(), time.time())
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:47:21.383107
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    from ..utils import PostProcessor

    def get_mtime(path):
        return os.stat(path)[stat.ST_MTIME]

    def get_atime(path):
        return os.stat(path)[stat.ST_ATIME]

    def get_ctime(path):
        return os.stat(path)[stat.ST_CTIME]

    def get_utime(path):
        return get_atime(path), get_mtime(path)

    def get_ctime_utime(path):
        return get_ctime(path), get_utime(path)

    def get_ctime_utime_mtime(path):
        return get_ctime(path), get_utime(path), get