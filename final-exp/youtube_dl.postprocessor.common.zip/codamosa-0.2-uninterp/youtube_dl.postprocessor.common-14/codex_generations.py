

# Generated at 2022-06-18 15:37:26.295619
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    fd, path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-18 15:37:35.703506
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os
    import sys

    from ..utils import (
        PostProcessor,
        encodeFilename,
    )

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(encodeFilename(os.path.join(tmpdir, 'test')), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test'), now, now)

    # Get the time of the file

# Generated at 2022-06-18 15:37:46.919467
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    from ..utils import encodeFilename

    if sys.platform == 'win32':
        return

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:37:56.066970
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    from ..utils import PostProcessor

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:07.518337
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    if sys.version_info < (3, 0):
        from backports import tempfile
    else:
        import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the atime and mtime of the temporary file
    pp.try_utime(temp_file.name, current_time, current_time)

    # Get the atime and mtime of the temporary file
   

# Generated at 2022-06-18 15:38:17.438825
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from ..utils import PostProcessor

    class DummyDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:38:29.423549
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time
    from ..utils import PostProcessor

    def _test_try_utime(pp, path, atime, mtime, errnote):
        pp.try_utime(path, atime, mtime, errnote)
        assert os.path.getatime(path) == atime
        assert os.path.getmtime(path) == mtime

    with tempfile.NamedTemporaryFile() as f:
        pp = PostProcessor(None)
        _test_try_utime(pp, f.name, time.time(), time.time(), 'Cannot update utime of file')
        _test_try_utime(pp, f.name, 0, 0, 'Cannot update utime of file')

# Generated at 2022-06-18 15:38:40.475271
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(temp_dir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(file_path, current_time, current_time)

    # Get the access and modification time of the file
    file_stat = os.stat(file_path)

    # Check that the access and modification

# Generated at 2022-06-18 15:38:51.619051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Get the file's modification time
    file_mtime = os.path.getmtime(filepath)

    # Check that the file's modification time is not the current time
    assert file_mtime != current_time

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime to update the file's modification time

# Generated at 2022-06-18 15:39:01.885137
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:14.918852
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    import tempfile
    import os
    import time
    import shutil
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a downloader

# Generated at 2022-06-18 15:39:18.387765
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    from .downloader import FileDownloader

    def _try_utime(path, atime, mtime, errnote):
        try:
            os.utime(encodeFilename(path), (atime, mtime))
        except Exception:
            pass

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(TestPostProcessor, self).__init__(downloader)
            self.try_utime = _try_utime

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:39:26.522228
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    now = time.time()

    # Update the modification time of the file
    pp = PostProcessor(None)
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), now, now)

    # Check the modification time of the file
    st = os.stat(os.path.join(tmpdir, 'test.txt'))
    assert st.st_mtime == now

    # Remove the temporary directory
    shut

# Generated at 2022-06-18 15:39:37.360689
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()

    # Get the current time
    curtime = time.time()

    # Get the file's modification time
    filemtime = os.path.getmtime(tmpfile.name)

    # Check that the file's modification time is close to the current time
    assert abs(filemtime - curtime) < 2

    # Set the file's access and modification times to the current time
    try:
        os.utime(tmpfile.name, (curtime, curtime))
    except Exception:
        pass

    #

# Generated at 2022-06-18 15:39:44.412572
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    temp_dir = tempfile.mkdtemp()
    try:
        filename = os.path.join(temp_dir, 'test.txt')
        with open(filename, 'w') as f:
            f.write('test')
        pp = PostProcessor(None)
        pp.try_utime(filename, time.time(), time.time())
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 15:39:51.975000
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info


# Generated at 2022-06-18 15:40:02.511839
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.mkstemp(dir=tmpdir)[1]

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    now = time.time()

    # Set the mtime and atime of the temporary file
    pp.try_utime(tmpfile, now, now)

    # Get the mtime and atime of the temporary file
    st = os.stat(tmpfile)
    atime = st[stat.ST_ATIME]
    mtime = st[stat.ST_MTIME]

    # Remove the temporary directory

# Generated at 2022-06-18 15:40:14.483418
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil
    from ..utils import PostProcessor

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()

    # Create a PostProcessor object
    pp = PostProcessor({})

    # Get the file's modification time
    file_mtime = os.path.getmtime(tmp_file.name)

    # Change the file's modification time
    pp.try_utime(tmp_file.name, time.time(), time.time())

    # Check that the file's modification time has changed
    assert os.path.getmtime(tmp_file.name) != file_m

# Generated at 2022-06-18 15:40:22.849738
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(tmpdir, 'test_file'), 'w')
        f.write('test')
        f.close()
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tmpdir, 'test_file'), time.time(), time.time())
        os.remove(os.path.join(tmpdir, 'test_file'))
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:40:31.120752
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a test file
    test_file = os.path.join(tmpdir, 'test')
    with open(test_file, 'w') as f:
        f.write('test file')

    # Get the current time
    cur_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the test file to the current time
    pp.try_utime(test_file, cur_time, cur_time)

    # Check if the time of the test file is the current time
    assert os.stat(test_file).st_mtime == cur_time



# Generated at 2022-06-18 15:40:42.392991
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Wait one second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Update the file's modification time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), None, None)

    # Check that the file's modification time has been updated


# Generated at 2022-06-18 15:40:50.136405
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_socket
    from ..compat import compat_str
    from ..compat import compat_os_path
    from ..compat import compat_os_name
    from ..utils import encodeFilename

    # Create a FileDownloader object
    fd = FileDownloader({'noprogress': True})
    # Create a PostProcessor object
    pp = PostProcessor(fd)

    # Create a temporary file

# Generated at 2022-06-18 15:41:00.673364
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'testid',
                'title': 'testtitle',
                'ext': 'mp4',
                'upload_date': '20120101',
                'uploader': 'testuploader',
            }

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    ie = FakeInfoExtractor()
    pp = FakePostProcessor()

# Generated at 2022-06-18 15:41:12.309166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
            }

        def to_screen(self, message):
            print(message)

        def report_warning(self, message):
            self.to_screen(message)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class DummyFile(object):
        def __init__(self, path):
            self.name = path

    class DummyInfo(object):
        def __init__(self, path):
            self.filepath = path

# Generated at 2022-06-18 15:41:20.159342
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the file's modification time
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Instantiate a PostProcessor object
    pp = PostProcessor(None)

    # Call the method try_utime
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), mtime, mtime)

    # Get the file's new modification time
    new_mtime = os.path.getmtime

# Generated at 2022-06-18 15:41:29.874802
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    class DummyDownloader():
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Get the file name
    filename = tmpfile.name
    # Close the file
    tmpfile.close()
    # Get the file creation time
    file_creation_time = os.path.getctime(filename)
    # Get

# Generated at 2022-06-18 15:41:40.408637
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file
    file_path = os.path.join(temp_dir, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the file's modification time
    file_mtime = os.stat(file_path).st_mtime

    # Wait one second
    time.sleep(1)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the file's modification time
    pp.try_utime(file_path, None, None)

    # Check the file's modification time

# Generated at 2022-06-18 15:41:51.524307
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'restrictfilenames': True,
            }

        def report_warning(self, msg):
            print(msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    class FakeFile(object):
        def __init__(self, path, mode='r'):
            self.path = path
            self.mode = mode
            self.closed = False

        def __enter__(self):
            return self


# Generated at 2022-06-18 15:41:58.516242
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification times of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Get the access and modification times of the file

# Generated at 2022-06-18 15:42:06.853845
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the time of the file

# Generated at 2022-06-18 15:42:25.405022
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys
    from .YoutubeDL import YoutubeDL

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a PostProcessor object
    ydl_opts = {
        'logger': YoutubeDL().logger,
        'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s'),
    }
    pp = PostProcessor(ydl_opts)

    # Get the current time
    current_time = time.time()

    # Try to update the access and modification time

# Generated at 2022-06-18 15:42:36.008456
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time
    from ..utils import PostProcessor

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:42:43.647029
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse

# Generated at 2022-06-18 15:42:54.169581
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the atime and mtime of the file
    (atime, mtime) = os.stat(os.path.join(tmpdir, 'test.txt'))[stat.ST_ATIME:stat.ST_MTIME+1]

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the atime and mtime of the file

# Generated at 2022-06-18 15:43:03.764837
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check that the utime of the file has been updated

# Generated at 2022-06-18 15:43:10.108543
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import stat
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()
    # Get the file path
    temp_file_path = temp_file.name
    # Get the file name
    temp_file_name = os.path.basename(temp_file_path)
    # Get the file directory
    temp_file_dir = os.path.dirname(temp_file_path)

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Get the current time
    current_time = time.time()

   

# Generated at 2022-06-18 15:43:14.824055
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    dl = Downloader({'outtmpl': '%(id)s.%(ext)s'})
    pp = PostProcessor(dl)
    pp.try_utime('/tmp/test', 0, 0)
    pp.try_utime('/tmp/test', DateRange(0), DateRange(0))

# Generated at 2022-06-18 15:43:21.868806
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from ..extractor import gen_extractors

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)
            self.utime_called = False

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.utime_called = True


# Generated at 2022-06-18 15:43:30.955594
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

    # Create a downloader object

# Generated at 2022-06-18 15:43:39.564778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a dummy file
    dummy_file = os.path.join(tmpdir, 'dummy.txt')
    with open(dummy_file, 'w') as f:
        f.write('dummy')

    # Create a dummy PostProcessor
    pp = DummyPostProcessor()

    # Get the current time
    now = time.time()

    # Try to update the time of the dummy file
    pp.try_utime(dummy_file, now, now)

# Generated at 2022-06-18 15:44:02.953609
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import stat

    from ..utils import PostProcessor

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:44:11.653095
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Close the temporary file
    tmpfile.close()
    # Get the path of the temporary file
    tmpfile = tmpfile.name
    # Get the last modification time of the temporary file
    file_mtime = os.path.getmtime(tmpfile)
    # Get the last access time of the temporary file
    file_atime = os.path.getatime(tmpfile)
    # Create a PostProcessor object
    pp = PostProcessor(None)
    # Update the last access time and the last modification time of

# Generated at 2022-06-18 15:44:21.387114
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP

# Generated at 2022-06-18 15:44:31.535600
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check if the time of the file is the current time

# Generated at 2022-06-18 15:44:41.472382
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the time of the file to the current time
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), curtime, curtime)

    # Check that the time of the file is the current time
    assert os.path.getmtime(os.path.join(tmpdir, 'test.txt')) == curtime

# Generated at 2022-06-18 15:44:49.381877
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Create a postprocessor object
    pp = PostProcessor(None)

    # Wait a second to ensure that the modification time of the file will be different
    time.sleep(1)

    # Update the modification time of the file

# Generated at 2022-06-18 15:45:00.658301
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    def _test_try_utime(path, atime, mtime, errnote):
        pp = DummyPostProcessor(DummyDownloader())

# Generated at 2022-06-18 15:45:09.668782
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)

    class TestDownloader(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, msg):
            self.msg = msg

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(temp_dir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Get the current time
    current_time = time.time()

    # Create

# Generated at 2022-06-18 15:45:20.091514
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        fname = os.path.join(tmpdir, 'testfile')
        with open(fname, 'wb') as f:
            f.write(b'a' * 100)
        atime = mtime = time.time() - 3600
        os.utime(fname, (atime, mtime))
        pp = PostProcessor(None)
        pp.try_utime(fname, atime, mtime)
        assert os.stat(fname).st_mtime == mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 15:45:29.856819
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.version_info < (2, 6):
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:08.495258
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os
    import sys

    if sys.version_info < (3, 0):
        from io import open

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Get the utime of the file
    file

# Generated at 2022-06-18 15:46:18.091818
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import stat
    import sys
    import subprocess
    from ..utils import encodeFilename

    if sys.platform.startswith('win'):
        raise Exception('This test is not available on Windows')

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(path, current_time, current_time)

    # Check if the utime of the file has been updated


# Generated at 2022-06-18 15:46:25.616954
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    class DummyDownloader(object):
        def __init__(self):
            self.params = {}
            self.to_stderr = sys.stderr.write
            self.to_stdout = sys.stdout.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:46:35.990527
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import os

    from ..utils import PostProcessor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    filepath = os.path.join(tmpdir, 'test.txt')
    with open(filepath, 'w') as f:
        f.write('test')

    # Get the current time
    curtime = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Set the access and modification time of the file to the current time
    pp.try_utime(filepath, curtime, curtime)

    # Check that the access and modification time of the file are the current time
    assert os.path.getmtime(filepath) == curtime

# Generated at 2022-06-18 15:46:46.876434
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_str
    from ..compat import compat_os_path
    from ..compat import compat_os_name
    from ..compat import compat_os_environ
    from ..compat import compat_tempfile
    from ..compat import compat_shutil
    from ..compat import compat_cookiejar
    from ..compat import compat_xml_parse_error
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack


# Generated at 2022-06-18 15:46:55.287503
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the current time
    current_time = time.time()

    # Create a PostProcessor object
    pp = PostProcessor(None)

    # Try to update the utime of the file
    pp.try_utime(os.path.join(tmpdir, 'test.txt'), current_time, current_time)

    # Check if the utime of the file has been updated

# Generated at 2022-06-18 15:47:05.526745
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        import win32file
        import pywintypes

    class FakeDownloader(object):
        def report_warning(self, msg):
            print(msg)

    class FakePostProcessor(PostProcessor):
        def __init__(self):
            self.set_downloader(FakeDownloader())

    pp = FakePostProcessor()

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:47:16.724787
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time
    import stat
    import sys

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()