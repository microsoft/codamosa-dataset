

# Generated at 2022-06-22 09:10:44.904422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from ..compat import PY2, PY3

    def _test_PostProcessor_try_utime(test_filepath):
        # Create dummy file for testing
        with open(test_filepath, 'wb') as test_file:
            test_file.write('test test test test')
            test_file.flush()

        # Create dummy post processor
        pp = PostProcessor(None)

        # Get mtime and ctime for dummy file
        stat = os.stat(test_filepath)
        atime = stat.st_atime
        mtime = stat.st_mtime

        # Create fake mtime and ctime
        if PY2:
            import time
            fake_time = time.mktime((2017, 1, 1, 00, 00, 00, 0, 0, 0))

# Generated at 2022-06-22 09:10:46.329052
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    if pp is None:
        assert pp != None
    else:
        assert pp == None

# Generated at 2022-06-22 09:10:48.951714
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:10:52.654810
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    assert pp._downloader is None
    fd = FileDownloader({})
    pp.set_downloader(fd)
    assert pp._downloader is fd


# Generated at 2022-06-22 09:10:58.736950
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        def __init__(self):
            self.run_called = 0
            self.run_arg = None
            self.run_ret = None

        def run(self, information):
            self.run_called += 1
            self.run_arg = information
            return self.run_ret

    pp1 = MockPP()
    pp2 = MockPP()
    pp1.run_ret = (['1'], {})
    pp2.run_ret = (['2'], {})

    pp1.add_post_processor(pp2)

    information = {}

    to_delete, information = pp1.run(information)

    assert to_delete == ['1', '2']
    assert information == {}
    assert pp2.run_arg == {}
    assert pp1.run

# Generated at 2022-06-22 09:11:06.039323
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('abc')
    assert str(e) == 'abc'
    assert e.cause is None

    e = AudioConversionError(Exception())
    assert str(e) == str(Exception())
    assert e.cause is not None

    e = AudioConversionError('abc', cause=Exception())
    assert str(e) == 'abc'
    assert e.cause is not None

# Generated at 2022-06-22 09:11:16.591177
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    import sys
    import datetime
    if sys.version_info[0] > 2:
        from unittest import mock
    else:
        import mock

    from .test_downloader import TestDownloader

    unit = mock.Mock()
    unit.report_warning = mock.Mock()
    unit._configuration_args = mock.Mock(return_value=[])
    downloader = TestDownloader()
    downloader.params = dict()
    post_processor = PostProcessor(downloader)
    post_processor.set_downloader(downloader)

    TEST_FILE_NAME = 'file.html'

    post_processor.try_utime(TEST_FILE_NAME, None, None,
                             errnote='Cannot update utime of file')


# Generated at 2022-06-22 09:11:19.273043
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:11:21.339540
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('message')
    assert error.message == 'message'



# Generated at 2022-06-22 09:11:28.151433
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPP(PostProcessor):
        def run(self, information):
            return (['file1.mp4'], {'a': 1})

    pp = TestPP()
    class TestDownloader():
        def download(self, ydl_request):
            pass
        def to_screen(self, message, skip_eol=False):
            pass
        def report_error(self, message, tb=None):
            pass
        def report_warning(self, message):
            pass
    downloader = TestDownloader()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:11:35.924235
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    class pp_A(PostProcessor):
        def test(self, arg):
            print('pp_A: arg = %d' % arg)
            return arg + 2

    class pp_B(PostProcessor):
        def test(self, arg):
            print('pp_B: arg = %d' % arg)
            return arg * 3

    class pp_C(PostProcessor):
        def test(self, arg):
            print('pp_C: arg = %d' % arg)
            return arg * 5

    class DummyDl(object):
        def __init__(self):
            self.pp_chain = [pp_A(self), pp_B(self), pp_C(self)]

    dl = DummyDl()
    ret = dl.pp_chain[0].run

# Generated at 2022-06-22 09:11:38.238391
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    PostProcessor_obj = PostProcessor()
    # set_downloader method called without downloader
    PostProcessor_obj.set_downloader(None)
    assert PostProcessor_obj._downloader == None,\
        'PostProcessor_obj._downloader should be None after None downloader is set.'



# Generated at 2022-06-22 09:11:50.653552
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Unit test method run of class PostProcessor"""

    def _print(i=''):
        print('postprocessor_test: %s' % i)

    class Info(object):
        """Information class"""

        def __init__(self, filepath, title):
            self.filepath = filepath
            self.title = title

    class TestPP1(PostProcessor):
        """Test PostProcessor which prints the information argument"""

        def run(self, information):
            """Test PostProcessor run"""
            _print(information.filepath)
            return []

    class TestPP2(PostProcessor):
        """Test PostProcessor which adds the title to information argument"""

        def run(self, information):
            """Test PostProcessor run"""
            information.title += '-PP2'
            return []


# Generated at 2022-06-22 09:11:53.132856
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test for the constructor of class PostProcessor"""
    p = PostProcessor()
    assert p._downloader == None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:12:03.845474
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from .testsupport import temp_filename
    from .testsupport import unittest

    class DummyDownloader(object):
        def __init__(self):
            self.postprocessor = PostProcessor(self)

        def report_warning(self, msg):
            self.msg = msg

    # try_utime is not supposed to throw exception
    d = DummyDownloader()
    p = temp_filename()
    with open(p, 'wb') as f:
        f.write(b'foo')
    d.postprocessor.try_utime(encodeFilename(p), 1.1, 2.2)
    os.remove(encodeFilename(p))
    # It's supposed to report warning
    d = DummyDownloader()
    p = temp_filename()

# Generated at 2022-06-22 09:12:06.263519
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor(object())

# Generated at 2022-06-22 09:12:13.513191
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors

    def _DemoIE_download_return(self, *args, **kwargs):
        return True
    _DemoIE = type('DemoIE', (object,), {'_download_return': _DemoIE_download_return})
    gen_extractors({'test': [{'ie': 'DemoIE', 'extractor': 'demo_extractor'}]})
    from ..downloader import gen_ydl

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl._ies['test']['demo_extractor'].add_post_processor(PostProcessor())
    ydl._ies['test']['demo_extractor']._do_download()



# Generated at 2022-06-22 09:12:21.949193
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .test_utils import FakeDownloader
    from .common import PostProcessorTestCase

    class PostProcessorTest(PostProcessor):
        def __init__(self, expected):
            PostProcessor.__init__(self)
            self._expected = expected
            self._called = []

        def run(self, information):
            assert self._expected
            assert information['id'] == self._expected.pop(0)
            self._called.append(information['id'])
            return [], information

        def _check_result(self, expected):
            assert self._expected == []
            assert self._called == expected

    dl = FakeDownloader()

    pp1 = PostProcessorTest(['a', 'b'])
    pp2 = PostProcessorTest(['1', '2'])

    dl.add_post

# Generated at 2022-06-22 09:12:27.007162
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import __builtin__
        setattr(__builtin__, 'input', lambda x: 'y')
        util = PostProcessor()
        util.try_utime('test', 123.456, 654.321, errnote='Cannot update utime of file')
    except ImportError:
        pass

# Generated at 2022-06-22 09:12:30.740110
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    post_processor = PostProcessor()
    downloader = YoutubeDL()
    post_processor.set_downloader(downloader)
    assert post_processor._downloader == downloader

# Generated at 2022-06-22 09:12:36.216540
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor(downloader=None)._downloader is None
    assert PostProcessor(downloader=123)._downloader == 123



# Generated at 2022-06-22 09:12:40.923161
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=protected-access
    pp = PostProcessor()
    assert pp._downloader is None

    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-22 09:12:43.880294
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    def try_PostProcessor():
        class DummyPostProcessor(PostProcessor):
            def run(self, information):
                return [], information
        dp = DummyPostProcessor()

    try_PostProcessor()

# Generated at 2022-06-22 09:12:47.401158
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor({})
    assert pp.run({'filepath': 'filename.mp4'}) == ([], {'filepath': 'filename.mp4'})

# Generated at 2022-06-22 09:12:52.332937
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test message', 123)
    except AudioConversionError as err:
        assert str(err) == 'test message'
        assert err.actual_retcode == 123
    else:
        assert False, 'AudioConversionError not raised'



# Generated at 2022-06-22 09:12:53.529089
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert isinstance(AudioConversionError('message'), Exception)


# Generated at 2022-06-22 09:13:00.897100
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a dummy instance of a PostProcessor
    class DummyPP(PostProcessor):
        def __init__(self, arg, arg2="default", unicode_arg=None):
            PostProcesor.__init__(self)
            self.arg = arg
            self.arg2 = arg2
            self.unicode_arg = unicode_arg

        def run(self, info):
            assert 'arg' in info
            assert info['arg'] == self.arg
            assert 'arg2' in info
            assert info['arg2'] == self.arg2
            assert 'unicode_arg' in info
            assert info['unicode_arg'] == self.unicode_arg
            return ([], info)
    # All the arguments are passed to the PostProcessor

# Generated at 2022-06-22 09:13:03.443569
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    ensure that PostProcessor.set_downloader works.
    """
    PP = PostProcessor()
    assert PP._downloader == None
    PP.set_downloader(object())
    assert PP._downloader != None

# Generated at 2022-06-22 09:13:05.484399
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__.__name__ == "PostProcessor"

# Generated at 2022-06-22 09:13:10.275678
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Make sure PostProcessor constructor works."""
    pp = PostProcessor()

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:20.292942
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__()
    testPP = TestPP()

    testPP.try_utime('test_filename', 0, 0)

# Generated at 2022-06-22 09:13:26.559923
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    test_PP = TestPostProcessor()
    assert test_PP._downloader == None

    class DummyDownloader():
        pass

    dummy_downloader = DummyDownloader()
    test_PP.set_downloader(dummy_downloader)
    assert test_PP._downloader == dummy_downloader

# Generated at 2022-06-22 09:13:29.946660
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    byte_io = io.BytesIO()
    downloader = YoutubeDL(params=dict(outtmpl=byte_io))
    pp = PostProcessor(downloader)
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-22 09:13:39.084332
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create an instance of a PostProcessor subclass
    # (we will use one of the existing ones)
    pp = PostProcessor(None)
    # Run the method run on it
    # (the interesting part of the method is in its subclass,
    #  that is why we need to test it)
    retval = pp.run({})
    # Check if the return value has the right type
    assert isinstance(retval, tuple)
    assert len(retval) == 2
    assert isinstance(retval[0], list)
    assert isinstance(retval[1], dict)

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:13:40.832504
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:41.479943
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    return

# Generated at 2022-06-22 09:13:51.473512
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    from ..utils import format_bytes

    pp1 = PostProcessor(None)
    assert(pp1._downloader is None)
    pp1.set_downloader(Downloader({'outtmpl':'test'}))
    assert(pp1._downloader.params['outtmpl'] == 'test')
    assert(pp1._downloader.params['outtmpl'] == 'test' == Downloader({'outtmpl': 'test'}).params['outtmpl'])
    assert(isinstance(pp1._downloader, Downloader))
    assert(isinstance(Downloader({'outtmpl': 'test'}), Downloader))

# Generated at 2022-06-22 09:14:01.612802
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Just make sure that PostProcessor is properly checking the types of the
    # parameters it is passing to os.utime.
    import os
    import tempfile
    import shutil
    # Create a file with current time as its modification time.
    test_file = tempfile.mktemp()
    with open(test_file, 'w') as f:
        f.write('test')
    # Create a PostProcessor object.
    pp = PostProcessor(None)
    # Call try_utime with a negative time that won't fit in an int32.
    # Windows will fail for other reasons, we only care about negative values.
    # Currently this returns silently as the "except Exception" does not fail.
    pp.try_utime(test_file, -1, -1)
    # Clean up test file

# Generated at 2022-06-22 09:14:04.302515
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('error message', 'audio_conversion') as exc:
        assert exc.args == ('error message', 'audio_conversion')

# Generated at 2022-06-22 09:14:14.971091
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor

    mp4_tmp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mp4_tmp.mp4')
    ogg_tmp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ogg_tmp.ogg')

    def test_run(ydl_opts, postprocessors):
        if os.path.exists(mp4_tmp):
            os.remove(mp4_tmp)
        if os.path.exists(ogg_tmp):
            os.remove(ogg_tmp)


# Generated at 2022-06-22 09:14:35.135716
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Tests of PostProcessor objects.
    """

    # Import here because of circular import
    from ..downloader import Downloader

    class MockPostProcessor(PostProcessor):

        def run(self, information):
            assert information['filepath'] == 'testfile'
            assert information['somekey'] == 'somevalue'
            return ['testfile'], information

    class MockDownloader(Downloader):
        def report_warning(self, message):
            pass

    i = {'filepath': 'testfile', 'somekey': 'somevalue'}
    d = MockDownloader()
    pp = MockPostProcessor(d)
    ppa = pp.run(i)
    assert ppa[0] == ['testfile']
    assert ppa[1]['somekey'] == 'somevalue'

# Generated at 2022-06-22 09:14:37.440835
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('Error')
    assert str(a) == 'Error'

# Generated at 2022-06-22 09:14:42.959678
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postProcessor = PostProcessor()
    from ..extractor.common import YoutubeIE
    from ..downloader.common import YoutubeDl
    youtubeDl = YoutubeDl()
    youtubeDl.add_info_extractor(YoutubeIE())
    postProcessor.set_downloader(youtubeDl)
    assert postProcessor._downloader == youtubeDl


# Generated at 2022-06-22 09:14:44.303311
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass



# Generated at 2022-06-22 09:14:49.558038
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('some message', exitcode=1, an_arg=10)
    except AudioConversionError as e:
        assert e.exitcode == 1
        assert e.an_arg == 10
        assert str(e) == 'some message'

# Generated at 2022-06-22 09:14:51.129946
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    assert hasattr(pp, 'try_utime')

# Generated at 2022-06-22 09:14:53.204131
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-22 09:14:55.041478
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader == None

# Generated at 2022-06-22 09:14:59.272989
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    pp.set_downloader(None)
    assert pp._downloader is None
    pp.set_downloader(0)
    assert pp._downloader == 0
    pp.set_downloader(1)
    assert pp._downloader == 1

# Generated at 2022-06-22 09:15:10.877942
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    file = {
        'title'      : 'test',
        'upload_date': '20131231',
        'ext'        : 'mp4',
        'format'     : 'mp4',
        'format_id'  : '0',
        'url'        : 'http://www.youtube.com/watch?v=aqxDFk8jWw0',
        'id'         : 'aqxDFk8jWw0',
        'filepath'   : '/path/to/video/test.mp4',
    }

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            info['filepath'] = info['title'] + '_' + info['format']
            return [], info

    pp = TestPostProcessor()

# Generated at 2022-06-22 09:15:35.030894
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert True

# Generated at 2022-06-22 09:15:37.215854
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert isinstance(AudioConversionError('test'), PostProcessingError)
    assert isinstance(AudioConversionError('test'), Exception)



# Generated at 2022-06-22 09:15:38.512688
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-22 09:15:39.082748
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()

# Generated at 2022-06-22 09:15:47.744334
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import shutil
    import tempfile
    import unittest

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class TestPostProcessor2(TestPostProcessor):
        def run(self, info):
            return [], info

    class TestPostProcessor3(TestPostProcessor2):
        def run(self, info):
            return [], info

    class TestPostProcessorChainable(TestPostProcessor3):
        def run(self, info):
            return [], info

    class MockInfoExtractor(object):
        pass

    class MockYDL(object):
        params = []
        def report_warning(self, warning):
            pass


# Generated at 2022-06-22 09:15:59.456114
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader(object):
        def __init__(self):
            self.report_warning_called = False

        def report_warning(self, message):
            self.report_warning_called = True

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(MockPostProcessor, self).__init__(downloader)
            self.try_utime_called = False

        def try_utime(self, path, atime, mtime, errnote):
            self.try_utime_called = True
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote

    mock_downloader = MockDownloader()
    pp = MockPostProcessor(mock_downloader)


# Generated at 2022-06-22 09:16:09.057269
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from .downloader import FileDownloader
    from .common import FileDownloaderTest
    tdir = tempfile.gettempdir()
    test_file_path = os.path.join(tdir, 'yt-dl-test.txt')
    if os.path.exists(test_file_path):
        os.remove(test_file_path)

    # find a song file to use as a test case
    songpath = FileDownloaderTest.get_testcases_dir()
    songs = [os.path.join(songpath, fn) for fn in os.listdir(songpath) if fn.endswith('.m4a')]
    s = FileDownloader(songs[0], params={'outtmpl': test_file_path})
    s.download()
    # record the original times

# Generated at 2022-06-22 09:16:14.829515
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    downloader = Downloader()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    downloader_new = Downloader()
    pp.set_downloader(downloader_new)
    assert pp._downloader == downloader_new

# Generated at 2022-06-22 09:16:25.408750
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # mock class for testing try_utime
    class MockDl(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, errnote):
            pass

    if os.name == 'nt':
        class MockOS(object):
            def __init__(self):
                pass

            def utime(self, a, b):
                raise Exception('Invalid argument')

        try:
            os.utime('foo', (0,0))
        except Exception:
            print('Error: os.utime() failed with valid arguments')
            assert False

        os = MockOS()
        dl = MockDl()
        pp = PostProcessor(dl)

        try:
            os.utime('foo', (0,0))
        except Exception:
            print('Test failed')

# Generated at 2022-06-22 09:16:28.752618
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        a = AudioConversionError('message')
        assert isinstance(a, PostProcessingError)
        assert a.message == 'message'
    except AudioConversionError as e:
        assert False, 'Caught AudioConversionError exception'

# Generated at 2022-06-22 09:17:30.118883
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("string")
    except AudioConversionError as e:
        assert e.msg == "string"
        assert e.cause is None

    try:
        raise AudioConversionError("string", AudioConversionError("cause"))
    except AudioConversionError as e:
        assert e.msg == "string"
        assert e.cause.msg == "cause"

# Generated at 2022-06-22 09:17:41.584659
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This function is only a test function
    from ..downloader.common import FileDownloader
    from time import time
    from .xattrpp import XAttrMetadataPP
    import shutil
    import os

    test_dir = './test_dir'
    if not os.path.isdir(test_dir):
        os.mkdir(test_dir)
    test_file_path = os.path.join(test_dir, 'test.mp4')
    test_video_url = 'http://test.test/test.mp4'

    fd = FileDownloader({'outtmpl': test_file_path})
    fd._download_retcode = lambda: 0
    fd._do_download = lambda: open(fd.temp_name, 'wb').close()
    mp = XAttrMetadataPP

# Generated at 2022-06-22 09:17:45.434692
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError()
    err = AudioConversionError(msg='spam')
    err = AudioConversionError(cause='egg')
    err = AudioConversionError(msg='spam', cause='egg')
    assert err.cause == 'egg'
    assert err.msg == 'spam'

# Generated at 2022-06-22 09:17:45.938962
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:17:51.998313
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile
    from ..compat import compat_os_name
    from ..extractor import get_info_extractor

    tmpdir = tempfile.mkdtemp()
    infos = [{'id': 'test_video', 'ext': 'mp4', 'duration': 10, 'upload_date': '20100101', 'uploader': 'Uploader'}]
    info_dict = infos[0]


# Generated at 2022-06-22 09:17:55.726233
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    info = {'filepath': 'test.mp4', 'format': 'mp4', 'title': 'test'}
    result = pp.run(info)
    assert result[1]['filepath'] == 'test.mp4'
    assert result[1]['format'] == 'mp4'
    assert result[1]['title'] == 'test'
    assert result[0] == []

# Generated at 2022-06-22 09:17:57.672340
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:18:00.282767
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run({'filepath': 'something.flv'}) == ([], {'filepath': 'something.flv'})

# Generated at 2022-06-22 09:18:04.478439
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    PostProcessor_obj = PostProcessor()
    assert PostProcessor_obj._downloader == None  # check _downloader if None
    PostProcessor_obj.set_downloader('downloader')
    assert PostProcessor_obj._downloader == 'downloader'  # check _downloader if set

# Generated at 2022-06-22 09:18:13.664244
# Unit test for constructor of class PostProcessor
def test_PostProcessor():

    # Replace with True if you have ffmpeg installed and you would like to run
    # the command line tests
    RUN_CMD_LINE_TESTS = False

    import sys
    import re
    import subprocess

    if RUN_CMD_LINE_TESTS:
        # Test if ffmpeg command is available
        try:
            subprocess.check_call(['ffmpeg', '-h'],
                                  stderr=subprocess.STDOUT,
                                  stdout=subprocess.PIPE)
        except Exception:
            print('WARNING: ffmpeg command was not found. Please install and make it available on the system path')
            print('    in order to run the command line test')
            sys.exit(0)

    FFMPEG_BIN = 'ffmpeg'
    FFMPEG_CODEC_OPTIONS

# Generated at 2022-06-22 09:20:34.066274
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postProcessor = PostProcessor()
    assert postProcessor

