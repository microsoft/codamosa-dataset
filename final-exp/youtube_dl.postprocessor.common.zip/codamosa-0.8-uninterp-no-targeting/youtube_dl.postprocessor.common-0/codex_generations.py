

# Generated at 2022-06-22 09:10:32.641663
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('ERROR')

# Generated at 2022-06-22 09:10:34.938976
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exception = AudioConversionError("Hello world")
    assert exception.args[0] == "Hello world"

# Generated at 2022-06-22 09:10:45.179994
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import filecmp
    import os
    import time
    import unittest

    # Define methods that are used to test method try_utime of class PostProcessor
    def create_test_file(source_file_name, source_file_contents):
        with open(source_file_name, 'w') as source_file:
            source_file.write(source_file_contents)

    def compare_files(first_file_name, second_file_name):
        return filecmp.cmp(first_file_name, second_file_name)

    def delete_test_file(file_name):
        os.remove(file_name)

    class DummyDownloader(object):
        def report_warning(self, warning_message):
            pass


# Generated at 2022-06-22 09:10:48.884807
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        p = PostProcessor()
    except Exception as e:
        assert False, 'Could not create instance of PostProcessor'

# Generated at 2022-06-22 09:10:57.354137
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from YoutubeDLTest import (
        YoutubeDLTest,
        DEFAULT_OUTTMPL,
        assertRegex
    )
    from .test_PostProcessor import PPTestPostProcessor
    outtmpl = '%(title)s.%(ext)s'
    ydl = YoutubeDLTest(YoutubeDL({'outtmpl': outtmpl, 'ignoreerrors': True}))
    IE = InfoExtractor(ydl)
    info = {'title': 'a_video'}
    pp = PPTestPostProcessor(ydl)
    IE.add_info_extractor(lambda x: info)
    IE.download(['foo'])
    assertEqual(pp._called, 1)

# Generated at 2022-06-22 09:11:08.713474
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import types
    import unittest
    import urllib

    from . import FakeYDL, PostProcessorTest
    from ..downloader.common import FileDownloader

    old_stdout = sys.stdout
    sys.stdout = FakeYDL(max_tempfiles=100)

    fd = FileDownloader({})
    fd.add_info_extractor(PostProcessorTest())
    fd.download(["testid"])
    assert fd._screen_file_num == 9

    pp = PostProcessor(fd)
    pp.run({"testnum": 0, "filepath": "testfile0"})
    assert fd._screen_file_num == 8
    pp.run({"testnum": 1, "filepath": "testfile1"})
    assert fd._screen

# Generated at 2022-06-22 09:11:10.830666
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError("This is an error")
    assert unicode(err) == 'This is an error'


# Generated at 2022-06-22 09:11:16.504802
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..loader import YoutubeDL

    downloader = YoutubeDL(params={'simulate': True})
    dl = downloader.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])[0]
    post_processor = dl.get('PP', None)
    assert post_processor is not None
    assert downloader is post_processor._downloader

# Generated at 2022-06-22 09:11:19.219303
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('msg')
    assert err.args[0] == 'msg'

# Generated at 2022-06-22 09:11:24.897611
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return ['file1'], info
    # Test one
    info = dict(id='testid', title='testtt', url='testurl')
    pp = TestPP()
    pp_result = pp.run(info)
    assert pp_result == (['file1'], info)



# Generated at 2022-06-22 09:11:31.510727
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE

    pp = PostProcessor(YoutubeDL({}))
    pp.set_downloader(YoutubeDL({}))

    pp_ie = PostProcessor(YoutubeIE({}))
    pp_ie.set_downloader(YoutubeIE({}))

# Generated at 2022-06-22 09:11:36.629968
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=pointless-statement
    PostProcessor


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:11:44.495193
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    filepath = os.path.join(basedir, 'test_try_utime.testfile')
    touch_cmd = 'touch %s' % filepath
    os.system(touch_cmd)
    os.utime(filepath, (0, 0))
    assert os.path.isfile(filepath)
    os.remove(filepath)
    class DummyDownloader():
        def report_warning(self, errnote):
            return errnote

    dl = DummyDownloader()
    pp = PostProcessor(dl)
    errnote = pp.try_utime

# Generated at 2022-06-22 09:11:54.751564
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import copy
    import os
    import tempfile
    import shutil

    # Store current working directory
    cwd = os.getcwd()

    # Create a temporary folder
    tmp_dir = tempfile.mkdtemp()
    # Create folder under temporary folder
    os.mkdir(os.path.join(tmp_dir, 'downloads'))
    os.chdir(tmp_dir)

    # Create a downloader instance
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.YoutubeDL import __main__
    ydl = YoutubeDL({})

    # Create post processsing chain
    from youtube_dl.downloader.postprocessor import (
        PostProcessor, FFmpegMetadataPP, FFmpegVideoConvertor, FFmpegExtractAudioPP)
    ydl.postproc

# Generated at 2022-06-22 09:11:55.384261
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-22 09:11:58.413229
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postprocessor = PostProcessor()
    assert postprocessor


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:12:06.928806
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    post_processor = PostProcessor()
    # mock the utime
    import __builtin__
    old_utime = __builtin__.utime
    found = [False]
    __builtin__.utime = lambda path, t: found.append(True)
    # Replace report_warning with a lambda to check if it was called
    old_report_warning = post_processor._downloader.report_warning
    post_processor._downloader.report_warning = lambda msg: found.append(msg)
    # Create a temp file
    import tempfile
    path = os.path.join(tempfile.gettempdir(), 'pytube_utime.tmp')
    # Open and write the file
    f = open(path, 'w')
    f.close()
    # Now we can proceed to the test


# Generated at 2022-06-22 09:12:07.627784
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-22 09:12:11.412844
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__.__name__ == 'PostProcessor'

# Generated at 2022-06-22 09:12:20.759594
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..downloader import Downloader
    from ..YoutubeDL import YoutubeDL
    from .common import setup_mock_downloader

    setup_mock_downloader(YoutubeDL)

    # On Windows Vista and above, os.utime() does not accept a float timestamp
    dl = Downloader(params=dict(
        utils=dict(
            time=lambda: 1322953028.8,
            datetimestr=lambda format, tm: DateRange(time=lambda: tm).strftime(format),
            win32=os.name == 'nt',
            win_version=tuple(
                sys.getwindowsversion().major,
                sys.getwindowsversion().minor,
                sys.getwindowsversion().build,
            )
        )
    ))
    d

# Generated at 2022-06-22 09:12:27.372304
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    s = 'test exception'
    try:
        raise AudioConversionError(s)
    except AudioConversionError as e:
        assert str(e) == s

# Generated at 2022-06-22 09:12:34.770677
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import tempfile
    import time
    from .testutils import FakeYDL

    with open(encodeFilename(os.path.join(tempfile.mkdtemp(), 'foo.txt')), 'wb') as fh:
        fh.write(b'foo')
    ydl = FakeYDL({'writedescription': True, 'writethumbnail': True, 'outtmpl': '%(id)s.%(ext)s', 'quiet': True})
    ydl.add_post_processor(PostProcessor(ydl))
    with open(encodeFilename(os.path.join(tempfile.mkdtemp(), 'bar.txt')), 'w') as fh:
        fh.write('bar')

# Generated at 2022-06-22 09:12:45.392458
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .postprocessor  import FFmpegExtractAudioPP

    file_path = 'test'
    file_dowloader = FileDownloader({'postprocessor_args': ['-x', '--audio-format', 'mp3']})
    file_dowloader.add_info_extractor(YoutubeIE())
    file_dowloader.add_post_processor(FFmpegExtractAudioPP())
    file_dowloader.params['outtmpl'] = '%(id)s' + file_path
    test_info = YoutubeIE().extract('http://www.youtube.com/watch?v=BaW_jenozKc')

    assert not os.path.isfile(file_path)
    file

# Generated at 2022-06-22 09:12:52.154187
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..utils import YdlFileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .execafterdownload import ExecAfterDownloadPP

    def get_class(pp_name):
        pp_cls = None
        for pp_cls in [FFmpegPostProcessor, XAttrMetadataPP, EmbedThumbnailPP, ExecAfterDownloadPP]:
            if pp_cls.__name__ == pp_name:
                return pp_cls
        return None


# Generated at 2022-06-22 09:13:04.333119
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from ..utils import url_basename
    from .common import FileDownloader

    try:
        os.utime
    except AttributeError:
        return

    fd, fname = tempfile.mkstemp(suffix='youtube-dl-utime.txt')
    os.chmod(fname, 0o777)
    os.close(fd)

    with open(fname, 'wb') as stream:
        stream.write(b'youtube-dl test file - utime')

    atime = time.time() - 6000
    mtime = time.time() - 3000


# Generated at 2022-06-22 09:13:12.074319
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeDownloader
    from .common import FakeInfoExtractor
    dummy_path = 'file_path.mp4'
    dl = YoutubeDL(FakeDownloader())
    dl.add_info_extractor(FakeInfoExtractor())
    pp = PostProcessor(dl)
    info = {'filepath': dummy_path}
    pp.run(info)

# Generated at 2022-06-22 09:13:22.545203
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    import os

    if os.name == 'nt':
        import time
        import tempfile

        temp_folder = tempfile.gettempdir()
        test_file = os.path.join(temp_folder, 'ytdl_test_file')

        f = open(test_file,'w')
        f.close()

        atime = time.time()
        time.sleep(0.001)
        pp.try_utime(test_file, atime, 0)
        mtime = os.path.getmtime(test_file)
        os.unlink(test_file)


        if mtime != atime:
            raise AssertionError('mtime %s != atime %s' % (mtime, atime))


# Generated at 2022-06-22 09:13:33.717474
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import os
    from ..utils import encodeFilename

    from .common import PostProcessorTest

    class MockDownloader():
        def __init__(self, params):
            self.params = params

        def report_warning(self, warning):
            print(warning, file=sys.stderr)

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class PP_Test_try_utime(PostProcessorTest):
        def test_try_utime(self):
            params = {"simulate": True}
            downloader = MockDownloader(params)
            pp = TestPostProcessor(downloader)

# Generated at 2022-06-22 09:13:37.849048
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(object())
    assert pp._downloader is not None
    # test the downloader setter
    pp.set_downloader(object())
    assert pp._downloader is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:40.408362
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:55.823766
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    # Test set_downloader
    ydl = YoutubeDL({})
    class MyPP(PostProcessor):
        def __init__(self, downloader = None, ie = None):
            PostProcessor.__init__(self, downloader)
            self.ie = ie
    pp = MyPP()
    try:
        pp.set_downloader(ydl)
        assert pp._downloader == ydl
    except:
        raise AssertionError("PostProcessor set_downloader method is not working")



# Generated at 2022-06-22 09:13:59.154550
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('This is test', True)
    except AudioConversionError as e:
        assert str(e) == 'This is test'
        assert e.original_exc is True



# Generated at 2022-06-22 09:14:08.097937
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.downloader = TestDownloader()

    class TestDownloader():
        def report_warning(self, message):
            self.message = message

    post = TestPostProcessor()
    post.try_utime("somepath", 1, 2)
    assert not hasattr(post.downloader, "message")
    post.try_utime("somepath", 1, 2, "some message")
    assert hasattr(post.downloader, "message")
    assert post.downloader.message == "some message"

# Generated at 2022-06-22 09:14:11.823921
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        PostProcessor().try_utime(__file__, 0, 0)
    except NameError:
        # This method is not supported on Windows
        pass

# Generated at 2022-06-22 09:14:22.721784
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # test_PostProcessor_run() tests method run from class PostProcessor
    from ..compat import compat_configparser
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from .xattr_setter import XAttrMetadataSetterPP

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return ['test.tmp'], information

    class TestDateRangePostProcessor(PostProcessor):
        def run(self, information):
            if information['age_limit'] > 12:
                return ['test.tmp'], information
            else:
                return ['test.tmp'], information

    class TestErrorPostProcessor(PostProcessor):
        def run(self, information):
            raise PostProcessingError

    available_extractors = gen_extractors

# Generated at 2022-06-22 09:14:29.902593
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        class Dummy:
            class params:
                pass
            def report_warning(self, msg):
                print(msg)
    except NameError:
        pass

# Generated at 2022-06-22 09:14:38.503553
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # Downloader: provide 'test_dir'
    pp._downloader = type('Downloader', (), {'params': {'test_dir': True}})()
    # Test if file exists
    path = 'abc'
    pp.try_utime(path, 100, 100)
    assert os.path.isfile(path)
    os.remove(path)
    # Test if file doesn't exist
    pp.try_utime(path, 100, 100)
    assert not os.path.isfile(path)

# Generated at 2022-06-22 09:14:43.544049
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    # Creating downloader and PostProcessor instances
    p = PostProcessor()
    d = YoutubeDL()
    # set_downloader() does not return a value,
    # it just sets the reference for the downloader
    p.set_downloader(d)

    assert p._downloader == d

# Generated at 2022-06-22 09:14:52.374994
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os.path
    import tempfile
    import time
    import sys
    import unittest

    import shutil
    from ..utils import (ExtractorError,
        get_exe_version,
        match_filter_func,
        prepend_extension,
        args_to_str,
        encodeFilename,
    )
    from ..downloader import (get_suitable_downloader,
        get_info_extractor,
    )
    from ..extractor import gen_extractors
    from ..postprocessor import (ffmpeg_audio_convertor,
        FFmpegExtractAudioPP,
        FFmpegMetadataPP,
        FFmpegVideoConvertor,
        PostProcessor,
    )

# Generated at 2022-06-22 09:14:55.148557
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test the constructor of the class
    pp = PostProcessor()
    assert pp._downloader is None

# Generated at 2022-06-22 09:15:13.077128
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..YoutubeDL import YoutubeDL
    class TestPP(PostProcessor):
        pass
    class TestDl(YoutubeDL):
        pass
    dl = TestDl({})
    pp = TestPP(dl)
    assert pp._downloader.params == dl.params
    assert str(pp) == 'TestPP'

# Generated at 2022-06-22 09:15:16.854596
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    # test for correct object type
    assert isinstance(pp, PostProcessor)


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:19.037178
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:21.782406
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp
    assert pp._downloader is None



# Generated at 2022-06-22 09:15:32.677025
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    import sys
    pp = PostProcessor(downloader = youtube_dl.YoutubeDL(params = {}))
    pp.set_downloader(youtube_dl.YoutubeDL(params = {}))
    assert pp._downloader == youtube_dl.YoutubeDL(params = {})
    pp.set_downloader(None)
    assert pp._downloader == None
    try:
        raise PostProcessingError('test_PPE')
    except PostProcessingError as err:
        assert str(err) == 'test_PPE'
        assert err.args == ('test_PPE',)

    try:
        raise PostProcessingError('test_PPE', 'test_PPE2')
    except PostProcessingError as err:
        assert str(err) == 'test_PPE'

# Generated at 2022-06-22 09:15:33.432813
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()



# Generated at 2022-06-22 09:15:41.761904
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import datetime

    # Prepare an object for testing and modified time for setting
    pp = PostProcessor()
    path = sys.argv[0]
    now = datetime.datetime.now()
    atime = mtime = now.timestamp()

    # Check that setting mtime using try_utime works
    current_mtime = os.path.getmtime(path)
    pp.try_utime(path, atime, mtime)
    assert '{:.0f}'.format(current_mtime) != '{:.0f}'.format(mtime), \
        'mtime not updated: current mtime "{}", expected "{}"'.format(current_mtime, mtime)

# Generated at 2022-06-22 09:15:47.510526
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # AudioConversionError can be raised with or without arguments
    try:
        raise AudioConversionError
    except AudioConversionError as e:
        e.args
    try:
        raise AudioConversionError('argument for constructor')
    except AudioConversionError as e:
        e.args
    try:
        raise AudioConversionError('argument for constructor', 'another argument')
    except AudioConversionError as e:
        e.args

# Generated at 2022-06-22 09:15:50.328390
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    assert PostProcessor(YoutubeDL())._downloader is not None

# Generated at 2022-06-22 09:15:54.613469
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL(params={'logger': YoutubeDL.NOOP_LOGGER})

    pp = PostProcessor(None)
    pp.set_downloader(ydl)
    assert pp._downloader is ydl


# Generated at 2022-06-22 09:16:23.786553
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class DummyDownloader(object):
        def __init__(self):
            self.pp = True

    class DummyPostProcessor(PostProcessor):
        pass

    dl = DummyDownloader()
    pp = DummyPostProcessor()
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Generated at 2022-06-22 09:16:25.919715
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # This function is intentionally left empty.
    # A dummy test is needed so that PostProcessor can be referenced from
    # other tests.
    pass

# Generated at 2022-06-22 09:16:27.927516
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
	PostProcessor()

# Generated at 2022-06-22 09:16:31.896855
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:16:41.747588
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile

    class TestPP1(PostProcessor):
        def run(self, info):
            return [], info

    class TestPP2(PostProcessor):
        def run(self, info):
            return [], info

    class TestPP3(PostProcessor):
        def run(self, info):
            return [], info

    class TestPP4(PostProcessor):
        def run(self, info):
            return None, None

    class TestPP5(PostProcessor):
        def run(self, info):
            return [], info

    class TestPP6(PostProcessor):
        def run(self, info):
            return None, None

    dl = object()
    tp1 = TestPP1(dl)
    tp2 = TestPP2(dl)
    tp

# Generated at 2022-06-22 09:16:44.745591
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-22 09:16:46.599700
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-22 09:16:47.718130
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()

# Generated at 2022-06-22 09:16:54.143939
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from .common import new_temp_file, new_temp_path
    from ..utils import encodeFilename

    filepath = encodeFilename(new_temp_file())
    atime = mtime = int(os.stat(filepath).st_atime) - 60 * 60 * 24  # yesterday
    PostProcessor(None).try_utime(filepath, atime, mtime)

    filepath = encodeFilename(new_temp_path())
    atime = mtime = int(os.stat(filepath).st_atime) - 60 * 60 * 24  # yesterday
    PostProcessor(None).try_utime(filepath, atime, mtime)

    filepath = encodeFilename(new_temp_path())

# Generated at 2022-06-22 09:16:57.563620
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockInfo(dict):
        pass
    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return (), info
    pp = MockPostProcessor()
    assert isinstance(pp.run(MockInfo()), tuple)

# Generated at 2022-06-22 09:18:08.907284
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import tempfile
    from ..YoutubeDL import YoutubeDL
    from ..postprocessor import PostProcessor

    TESTFN = os.path.join(tempfile.gettempdir(), 'ydl-test-%s' % os.getpid())

    try:
        os.unlink(TESTFN)
    except OSError:
        pass

    with open(TESTFN, 'w') as outf:
        outf.write('test contents')

    utime = os.stat(TESTFN).st_atime, os.stat(TESTFN).st_mtime
    os.chmod(TESTFN, stat.S_IRUSR | stat.S_IRGRP)

    ydl = YoutubeDL()
    ydl.params['verbose'] = False

# Generated at 2022-06-22 09:18:12.002961
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # There is no constructor for AudioConversionError
    # We try to put it into a function in order to not mess up nosetest's output
    foo = AudioConversionError('Msg', [])
    foo.msg
    foo.output


# Generated at 2022-06-22 09:18:14.871890
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert isinstance(AudioConversionError(encodeFilename('תאילנד')), Exception)



# Generated at 2022-06-22 09:18:19.787901
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    ie = gen_extractors()[0]
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info['filepath'] = '/tmp/test.mp4'
    pp = PostProcessor(None)
    pp.run(info)

# Generated at 2022-06-22 09:18:23.161970
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor
    """
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:18:32.984154
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import unittest
    class MockDownloader(object):
        def __init__(self):
            self.params = { 'test': True }
        def report_warning(self, msg):
            self.msg = msg
    class testPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime('does_not_exist.txt', 0, 0)
            return [], info
    downloader = MockDownloader()
    processor = testPostProcessor(downloader)
    processor.run({})
    if sys.version_info < (3, 0):
        expected_msg = "Cannot update utime of file"
    else:
        expected_msg = "Cannot update utime of file does_not_exist.txt: No such file or directory"
    assert downloader

# Generated at 2022-06-22 09:18:35.898770
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = object()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-22 09:18:38.407947
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('ERROR')
    except AudioConversionError as e:
        assert isinstance(e, AudioConversionError)

# Generated at 2022-06-22 09:18:40.078983
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert (p is not None)

# Generated at 2022-06-22 09:18:47.545282
# Unit test for method try_utime of class PostProcessor