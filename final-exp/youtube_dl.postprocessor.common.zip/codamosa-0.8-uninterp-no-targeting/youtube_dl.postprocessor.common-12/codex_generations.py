

# Generated at 2022-06-22 09:10:33.173029
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.downloader.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-22 09:10:34.238342
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test only constructor
    PostProcessor()

# Generated at 2022-06-22 09:10:38.054006
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['verbose'] = False
    ydl.add_post_processor(PostProcessor())
    assert ydl.postprocessors[0]._downloader is ydl

# Generated at 2022-06-22 09:10:39.780467
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postprocessor = PostProcessor()
    class Downloader(object):
        pass
    downloader = Downloader()
    postprocessor.set_downloader(downloader)
    assert postprocessor._downloader == downloader, 'Could not set a downloader for PostProcessor'

# Generated at 2022-06-22 09:10:42.399716
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """tests if set_downloader is working."""
    from ..extractor import gen_extractors
    from ..downloader import gen_downloader

    class DummyPostProcessor(PostProcessor):
        pass

    postProcessor = DummyPostProcessor()
    postProcessor.set_downloader(gen_downloader(gen_extractors(), ['download']))
    assert isinstance(postProcessor._downloader, type)

# Generated at 2022-06-22 09:10:43.008067
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:10:46.473115
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('unit_test', dict())
    except AudioConversionError as e: # check that the unit test works
        assert e.args[0] == 'unit_test'
        assert e.args[1] == dict()
test_AudioConversionError()

# Generated at 2022-06-22 09:10:49.663547
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-22 09:10:50.637573
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-22 09:10:57.638057
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..utils import DEFAULT_OUTTMPL

    ydl = FileDownloader()

    ydl.add_info_extractor(YoutubeIE())
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

    assert(os.path.exists(DEFAULT_OUTTMPL % dict(
        ext='flv', autonumber=1, id='BaW_jenozKc', uploader='', title='youtube-dl test video "')))
    os.remove(DEFAULT_OUTTMPL % dict(
        ext='flv', autonumber=1, id='BaW_jenozKc', uploader='', title='youtube-dl test video "'))

# Generated at 2022-06-22 09:11:05.125612
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = object()
    pp = PostProcessor(downloader)
    pp.set_downloader(None)
    assert pp._downloader is None
    pp2 = PostProcessor()
    pp2.set_downloader(downloader)
    assert downloader is pp2._downloader

# Generated at 2022-06-22 09:11:15.852061
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # encoding: utf-8
    """
    This test unit tests a method of class PostProcessor: try_utime()
    """

    from pytube.extractor.common import FileDownloader
    from pytube.postprocessor import PostProcessor
    from pytube.exceptions import PostProcessingError

    from .testutils import FakeFile

    class Dummy(PostProcessor):
        def __init__(self, downloader=None, params={}):
            PostProcessor.__init__(self, downloader)

    dummy = Dummy()
    dummy.set_downloader(FileDownloader(params={}))

    string1 = 'string1'
    string2 = 'string2'
    fd = FakeFile(string1)

    # test1: open file and write correct utime

# Generated at 2022-06-22 09:11:20.010906
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', 'bar')
    except AudioConversionError as err:
        assert isinstance(err, PostProcessingError)
        assert err.args == ('foo', 'bar')

# Generated at 2022-06-22 09:11:28.825941
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Tests on a non existing file
    a = PostProcessor(None)
    try:
        a.run(dict(filepath="qwerty"))
        assert(False), "Should not succeed"
    except PostProcessingError:
        pass
    # Tests on a non existing file
    b = PostProcessor(None)
    try:
        b.run(None)
        assert(False), "Should not succeed"
    except PostProcessingError:
        pass
    # Tests on a non existing file
    c = PostProcessor(None)
    try:
        c.run(dict())
        assert(False), "Should not succeed"
    except PostProcessingError:
        pass

# Generated at 2022-06-22 09:11:31.051504
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('foo') as err:
        assert str(err) == 'foo'

# Generated at 2022-06-22 09:11:35.447252
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyDownloader:
        pass
    downloader = DummyDownloader()
    pp = PostProcessor()
    pp.set_downloader(downloader)
    if pp._downloader is not downloader:
        raise TypeError('_downloader is not downloader')


# Generated at 2022-06-22 09:11:40.105425
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL

    from tempfile import mkstemp
    from subprocess import Popen, PIPE

    # Prepare a file
    _, path = mkstemp(prefix='youtube-dl_test_')

# Generated at 2022-06-22 09:11:44.447944
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    pp.set_downloader(None)
    assert pp._downloader == None

# Generated at 2022-06-22 09:11:56.358284
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
  pp = PostProcessor(None)

# Generated at 2022-06-22 09:11:59.380903
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    pp = PostProcessor(ie)

    assert pp._downloader == ie

# Generated at 2022-06-22 09:12:11.592719
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test1: Test object creation of PostProcessor
    pp = PostProcessor(None)

    # Test2: Test try_utime with correct path.
    pp.try_utime('correct_path', 1, 2)

    # Test3: Test try_utime with non-existing path.
    pp.try_utime('non_existing_file', 1, 2)

    # Test4: Test try_utime with correct directory path.
    pp.try_utime('.', 1, 2)

    # Test5: Test try_utime with non-existing directory path.
    pp.try_utime('non_existing_dir', 1, 2)

# Generated at 2022-06-22 09:12:12.778952
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__.__name__ == "PostProcessor"


# Generated at 2022-06-22 09:12:20.534329
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)  # No downloader is needed for testing
    path = 'file'
    atime = 1.1
    mtime = 2.2
    errnote = 'Cannot update utime of file'

    # Test with failing os.utime
    def mock_os_utime(path, times):
        raise OSError
    pp.try_utime(path, atime, mtime, errnote)
    pp.try_utime = mock_os_utime
    pp.try_utime(path, atime, mtime, errnote)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-22 09:12:33.068582
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import stat
    import tempfile
    import time

    from ..utils import (
        encodeFilename,
        PY2,
    )
    from .common import PostProcessorTestCase

    tempdir = None
    filepath = None
    utime = None

    def remove_testfile():
        try:
            os.remove(filepath)
        except (IOError, OSError) as e:
            if e.errno != 2:
                raise

    def setUp():
        global tempdir, filepath, utime
        if PY2:
            super(PostProcessorTestCase, self).setUp()
        tempdir = tempfile.mkdtemp()
        filepath = os.path.join(tempdir, 'testfile')

# Generated at 2022-06-22 09:12:36.651196
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        # pylint:disable=redefined-variable-type
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert(str(err) == 'test')

# Generated at 2022-06-22 09:12:44.238102
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor(None)
    assert pp.run({"filepath": "foo.avi",
                   "ext": "avi"}) == ([], {"filepath": "foo.avi",
                                          "ext": "avi"})

    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = TestPP(None)
    assert pp.run({"filepath": "foo.avi",
                   "ext": "avi"}) == ([], {"filepath": "foo.avi",
                                          "ext": "avi"})

# Generated at 2022-06-22 09:12:45.744238
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-22 09:12:52.297451
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import youtube_dl

    # Stub class
    class MyPostProcessor(PostProcessor):
        def run(self, info):
            info['title'] = '_' + info['title'] + '_'
            info['ext'] = 'txt'
            return [], info

    # Create a fake downloader with a fake postprocessor chain (MyPostProcessor)
    ydl = youtube_dl.YoutubeDL({'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }, {
        'key': 'FFmpegMetadata'
    }, MyPostProcessor]})

    # Fake info dict

# Generated at 2022-06-22 09:12:56.765555
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    pp = PostProcessor()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-22 09:12:59.200224
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as e:
        assert str(e) == 'test'

# Generated at 2022-06-22 09:13:16.679666
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import YoutubeDL

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.errnote = None

        def try_utime(self, path, atime, mtime, errnote=None):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote

    ydl = YoutubeDL()
    fpp = FakePostProcessor(ydl)

    assert fpp.path is None
    assert fpp.atime is None
    assert fpp.mtime is None
    assert fpp.errnote is None

    fpp.run({'filepath': 'fake file path'})

    assert fpp.path

# Generated at 2022-06-22 09:13:24.481569
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2

    import tempfile
    import shutil
    import os

    import pytest

    from ..utils import PostProcessor

    pp = PostProcessor()

    # Create a temporary directory to test the function
    tmpd = tempfile.mkdtemp()

    # Get the current time
    import time
    now = time.time()
    # File def check_file(tmpd, name, atime=None, mtime=None):
    def check_file(tmpd, name, atime=None, mtime=None):
        path = os.path.join(tmpd, name)
        stat = os.stat(path)
        # Check the time
        if atime is not None:
            assert stat.st_atime == atime

# Generated at 2022-06-22 09:13:34.601747
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from datetime import datetime
    from .downloader import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_struct_time
    from .postprocessor import PostProcessor

    class TestInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'ext': 'mp3',
                'title': 'Test Video'
            }

    ie = TestInfoExtractor()
    ydl = FakeYDL({'quiet': True, 'forcefilename': True, 'format': 'bestaudio'})
    ydl.add_info_extractor(ie)
    postproc = PostProcessor(ydl)

# Generated at 2022-06-22 09:13:45.817533
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        def __init__(self, downloader=None, ie=None, ie_key=None):
            PostProcessor.__init__(self, downloader)
            self.ie = ie
            self.ie_key = ie_key
            self.calls = 0

        def run(self, info):
            self.calls += 1
            if self.calls > 4: # stop the chain after 4 calls
                return ([], info)
            return ([], self.ie.result())

    pp1 = MockPP(ie=object(), ie_key='pp1')
    pp2 = MockPP(ie=object(), ie_key='pp2')
    pp3 = MockPP(ie=object(), ie_key='pp3')

# Generated at 2022-06-22 09:13:49.557768
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Initialize variable
    postProcessor = PostProcessor()

    # The given downloader is set to the PostProcessor
    postProcessor.set_downloader("downloader")

    # The downloader is returned
    assert postProcessor._downloader == "downloader"



# Generated at 2022-06-22 09:13:50.865373
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor

# Generated at 2022-06-22 09:14:01.035357
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    ae = AudioConversionError('test', [])
    assert ae.original_message == 'test'
    assert ae.converted_message == 'test'
    assert ae.converted_with_ffmpeg == True
    assert ae.converted_with_avconv == True

    ae = AudioConversionError('test', ['ffmpeg'])
    assert ae.original_message == 'test'
    assert ae.converted_message == 'test'
    assert ae.converted_with_ffmpeg == True
    assert ae.converted_with_avconv == False

    ae = AudioConversionError('test', ['avconv'])
    assert ae.original_message == 'test'
    assert ae.converted_message == 'test'
    assert ae.converted_with_

# Generated at 2022-06-22 09:14:10.534432
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # pylint: disable=protected-access
    # pylint: disable=missing-docstring
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            pass
        def run(self, information):
            self.try_utime('abc', 123, 456, 'abc')
    pp = TestPostProcessor()
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)
    import time
    # Create a file with a different timestamp
    with open(path, 'wb') as f:
        f.write(os.urandom(10))
    time.sleep(0.01)
    mtime1 = os.path.getmtime(path)
    # Test for correct handling of file not existing

# Generated at 2022-06-22 09:14:21.728821
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)

    src_downloader = FileDownloader(None)
    p1 = MockPostProcessor()
    p1.set_downloader(src_downloader)
    assert p1._downloader is src_downloader

    p2 = MockPostProcessor()
    p2.set_downloader(p1)
    assert p2._downloader is p1._downloader

    p3 = MockPostProcessor(downloader=p2)
    assert p3._downloader is p2._downloader


# Generated at 2022-06-22 09:14:28.771343
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader.common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from ..utils import write_json_file

    class FakePostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    class FakeInfoExtractor(object):
        def __init__(self):
            self.IE_NAME = 'fake_ie'
            self._TEST = None

        def _real_initialize(self):
            pass

        @classmethod
        def suitable(cls, url):
            return True

        @classmethod
        def ie_key(cls):
            return 'fake'


# Generated at 2022-06-22 09:14:46.237958
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.downloader = downloader

    # Subclass of PostProcessor with modified run() method
    # that checks if it is called with the correct downloader
    class TestPostProcessor2(TestPostProcessor):
        def run(self, information):
            if not self.downloader:
                return [], information

            for d in self.downloader.get_post_processors():
                if d == self:
                    return [], information

            # Set downloader to None to distinguish between
            # the error in the following instance of TestPostProcessor
            self.downloader = None
            raise Exception('self not in list of post processors')


# Generated at 2022-06-22 09:14:50.774877
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPP(PostProcessor):
        def run(self, info):
            return [info['filepath']], info

    pp = MyPP()
    info = {
        'filepath': 'video',
        'title': 'video title'
    }
    (deletelist, new_info) = pp.run(info)
    assert deletelist == ['video']
    assert info['title'] == 'video title'

# Generated at 2022-06-22 09:14:55.566463
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    yt = type('FakeYoutubeDL', (object,), {})()
    pp = PostProcessor(downloader=yt)
    assert pp._downloader == yt

# Generated at 2022-06-22 09:14:57.663661
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp
    assert pp.__class__.__name__ == "PostProcessor"

# Generated at 2022-06-22 09:15:05.670623
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import utils
    import tempfile
    import subprocess

    post_processor = PostProcessor()
    filename = tempfile.mkstemp()[1]
    with open(filename, 'wb') as f:
        f.write(b"bla")
    utils.write_json_file(filename + ".info", {'a': 1})
    post_processor.try_utime(filename, 1, 1)
    post_processor.try_utime(filename + ".info", 1, 1)

    try:
        time.sleep(2)
        subprocess.call(['touch', '-at', '197001020000.00', filename])
        post_processor.try_utime(filename, 1, 1)
        assert False
    except:
        assert True


# Generated at 2022-06-22 09:15:15.426409
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time

    try:
        tmpfile = tempfile.NamedTemporaryFile(delete=False)
        tmpfile.close()
        old_atime = int(time.time()) - 100
        old_mtime = old_atime - 100

        pp = PostProcessor({})
        pp.try_utime(tmpfile.name, old_atime, old_mtime, 'test')
        new_atime = int(os.path.getatime(tmpfile.name))
        new_mtime = int(os.path.getmtime(tmpfile.name))
        assert 0 < new_atime - old_atime < 10
        assert 0 < new_mtime - old_mtime < 10
    finally:
        os.remove(tmpfile.name)

# Generated at 2022-06-22 09:15:28.324616
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.YoutubeDL import PostProcessor as YTPostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    test_file = 'test.mp3'
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_func_name = 'updateMetaData'
    test_params = {'noplaylist': True,  # Force only 1 video
                   'outtmpl': test_file,
                   'format': 'bestaudio/best',
                   'quiet': True}


# Generated at 2022-06-22 09:15:34.672041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    temp_file = tempfile.NamedTemporaryFile()
    try:
        pp = PostProcessor(None)
        pp.try_utime(temp_file.name, 0, 0, errnote='test note')
        # Test that the warning was logged
        assert(pp._downloader. reports[-1]['level'] == 'WARNING')
        assert(pp._downloader. reports[-1]['message'] == 'test note')
    finally:
        temp_file.close()

# Generated at 2022-06-22 09:15:36.068178
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postProcessorExample = PostProcessor()
    assert postProcessorExample

# Generated at 2022-06-22 09:15:42.028692
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info_dict):
            super(TestPP, self).run(info_dict)
            return [], {'title': 'A'}

    info = {'title': 'B'}
    pp = TestPP()
    post_info = pp.run(info)
    assert post_info[1]['title'] == 'A'

# Generated at 2022-06-22 09:16:12.104483
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    ace = AudioConversionError('foo')
    assert str(ace) == 'foo'



# Generated at 2022-06-22 09:16:16.900335
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Method call chain.

    set_downloader ---> run
    """
    class DummyPostProcessor(PostProcessor):
        """
        Dummy PostProcessor class for testing.
        """

# Generated at 2022-06-22 09:16:20.590081
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Arrange
    downloader = object()
    post_processor = PostProcessor()

    # Act
    post_processor.set_downloader(downloader)

    # Assert
    assert post_processor._downloader is downloader

# Generated at 2022-06-22 09:16:21.297573
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    p = PostProcessor(None)

# Generated at 2022-06-22 09:16:25.506996
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor(None)
    dl = FileDownloader(None)
    pp.set_downloader(dl)
    assert pp._downloader is dl
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-22 09:16:32.495445
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class FakePostProcessor:
        """Dummy PostProcessor class that calculates the length of the first part of a
        string.
        """
        def __init__(self, length):
            self.length = length

        def run(self, info):
            return [], {'title': info['title'][:self.length]}

    info = {'title': 'test'}

    pp = FakePostProcessor(3)
    pp.set_downloader(None)
    assert pp.run(info) == ([], {'title': 'tes'})
    assert pp.run(info)[1]['title'] == 'tes'

    pp = FakePostProcessor(200)
    pp.set_downloader(None)
    assert pp.run(info) == ([], {'title': 'test'})
    assert pp.run

# Generated at 2022-06-22 09:16:34.584282
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('a', 'b', 'c')
    assert isinstance(e, PostProcessingError)



# Generated at 2022-06-22 09:16:38.183954
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    post_processor = PostProcessor()
    assert post_processor._downloader is None
    post_processor.set_downloader(1)
    assert post_processor._downloader == 1

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:16:39.464776
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None


# Generated at 2022-06-22 09:16:48.935903
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Try changing access and modification time of a file.
    """

    import tempfile
    import shutil
    from .common import FakeYDL
    from .downloader import FileDownloader
    from .postprocessor import PostProcessor

    with tempfile.NamedTemporaryFile() as f:
        tmp_dir = f.name
        f.close()
        shutil.rmtree(tmp_dir, ignore_errors=True)
        os.mkdir(tmp_dir)
        tmp_file = os.path.join(tmp_dir, 'foo')
        with open(tmp_file, 'w') as f:
            f.write('bar')

        pp = PostProcessor(FileDownloader(FakeYDL()))
        pp.try_utime(tmp_file, 1, 1)
        shutil.rmt

# Generated at 2022-06-22 09:17:54.166726
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP1(PostProcessor):
        def run(self, information):
            a = information.get('a', 0)
            return [], {'a': a + 1}

    class TestPP2(PostProcessor):
        def run(self, information):
            b = information.get('b', 0)
            return [], {'b': b + 1}
    pp = TestPP1()
    pp.set_downloader(object())
    pp.add_post_processor(TestPP2())
    assert pp.run({}) == ([], {'a': 1, 'b': 1})

# Generated at 2022-06-22 09:18:05.584802
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            downloader = self._downloader
            downloader.to_screen('Testing VideoConvertPP.run')
            assert downloader == test_downloader
            return [], information
    class TestDownloader():
        def __init__(self, test=True):
            self.params = {'test': test}
    test_downloader = TestDownloader()
    test_pp = TestPostProcessor(test_downloader)
    test_pp.run(None)
    test_pp = TestPostProcessor()
    test_pp.set_downloader(test_downloader)
    test_pp.run(None)


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:18:08.562920
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:18:14.988399
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    import tempfile
    import os
    import time
    file_ = tempfile.NamedTemporaryFile(delete=False)
    file_.close()
    atime = time.time()
    mtime = atime - 10
    pp.try_utime(file_.name, atime, mtime)
    (atime_, mtime_) = os.stat(file_.name).st_atime, os.stat(file_.name).st_mtime
    assert atime_ == atime and mtime_ == mtime
    os.unlink(file_.name)

# Generated at 2022-06-22 09:18:23.958287
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys

    # Make a temporary directory for the test
    temp_dir = tempfile.mkdtemp(prefix="ytdl-test_PostProcessor_try_utime_")

    # (try_)utime is not supported on Windows.
    # https://docs.python.org/2/library/os.html#os.utime
    if sys.platform == 'win32':
        shutil.rmtree(temp_dir)
        return

    test_file = os.path.join(temp_dir, 'test_file.txt')
    with open(test_file, 'w') as file_fd:
        file_fd.write('')

    p = PostProcessor(None)

# Generated at 2022-06-22 09:18:25.221282
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None

# vim:et:sw=4:sts=4:ts=4

# Generated at 2022-06-22 09:18:28.151229
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postProcessor = PostProcessor()
    assert postProcessor._downloader is None
    downloader = object()
    postProcessor.set_downloader(downloader)
    assert postProcessor._downloader == downloader

# Generated at 2022-06-22 09:18:28.832385
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-22 09:18:34.709905
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo.avi', 'mp3', 'stderr', 'command')
    except Exception as e:
        assert isinstance(e, AudioConversionError)
        assert str(e) == 'foo.avi: mp3: stderr: command'
        assert e.original_path == 'foo.avi'
        assert e.format == 'mp3'
        assert e.stderr == 'stderr'
        assert e.command == 'command'
    else:
        assert False



# Generated at 2022-06-22 09:18:39.022936
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    if pp._downloader is not None:
        raise Exception('PostProcessor.__init__ fails.')
    return True


if __name__ == '__main__':
    test_PostProcessor()