

# Generated at 2022-06-22 09:10:36.498305
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader

    # Create file downloader
    ie = gen_extractors()['youtube']()
    params = ie.DEFAULT_OUTTMPL_FORMAT
    params.update({'batch_file': 'test.csv'})

    ydl = FileDownloader(params)

    # Create postprocessor
    from .embedthumbnail import EmbedThumbnailPP
    pp = EmbedThumbnailPP(ydl)

    pp.set_downloader(ydl)

    # Test if downloader is set
    assert pp._downloader is ydl

# Generated at 2022-06-22 09:10:40.474896
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        if str(err) == 'test':
            print('AudioConversionError test passed')
        else:
            raise RuntimeError('AudioConversionError test failed!')

# Generated at 2022-06-22 09:10:41.376585
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass



# Generated at 2022-06-22 09:10:51.278423
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    p = PostProcessor()
    assert p.run({}) == ([], {})
    assert p.run({'filepath': '/foo/bar.flv'}) == ([], {'filepath': '/foo/bar.flv'})
    assert p.run({'filepath': '/foo/bar.flv', 'ext': 'flv'}) == ([], {'filepath': '/foo/bar.flv', 'ext': 'flv'})
    assert p.run({'filepath': '/foo/bar.flv', 'ext': 'flv'}) == ([], {'filepath': '/foo/bar.flv', 'ext': 'flv'})


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:11:01.105373
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # This test is designed to check the correct behavior of class PostProcessor.
    # The idea is simple: we create a new class implementing the method run,
    # and we check whether this method is correctly called by the method you
    # want to test.
    #
    # You can add, if you want, a method called setUpClass to the class to
    # create the useful object(s) to run the test. The class constructor
    # is called before any test.
    #
    # The tests of this class (methods whose name starts with 'test') are
    # automatically called by the test file.
    #
    # Note that all the tests in this file should run, whatever the
    # configuration is.

    class DummyPP(PostProcessor):
        def run(self, info):
            self.called = True
            return [], info

# Generated at 2022-06-22 09:11:13.057029
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)
            self.test_information = None
            self.test_files_to_delete = None
        def run(self, information):
            self.test_information = information
            self.test_files_to_delete = [information['filepath']]
            information['filepath'] += '.tmp'
            return self.test_files_to_delete, information

    ydl = YoutubeDL()
    ydl.add_post_processor(FakePostProcessor(ydl))
    test_filepath = '/tmp/__postprocessor_test__.tmp'
    open(test_filepath, 'w').close()
   

# Generated at 2022-06-22 09:11:15.949836
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    pp.try_utime('test_postprocessor.py', 1000000000, 1000000000)

# Generated at 2022-06-22 09:11:22.570115
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('Test')
    assert err.message == 'Test'
    assert err.cause == None
    err = AudioConversionError('Test', RuntimeError("Test message"))
    assert err.message == 'Test'
    assert err.cause.message == "Test message"
    # using raise with AudioConversionError and the cause parameter populated is
    # tested by the ffmpeg_postprocessor_test.

# Generated at 2022-06-22 09:11:34.236620
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    from ..compat import PY2, str, text_type

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    if PY2:
        # Bytes
        with tempfile.TemporaryFile() as f:
            p = MockPostProcessor()
            result = p.run({
                'filepath': f.name,
                'format': 'mp4',
                'nonexistent': 'abcde'})
            assert result == ([], {
                'filepath': f.name,
                'format': 'mp4',
                'nonexistent': 'abcde',
            })

            # No unicode
            with tempfile.TemporaryFile() as f:
                p = MockPostProcessor()

# Generated at 2022-06-22 09:11:40.271876
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            assert information["testfield"] == 42
            information["filepath"] = "testfilepath"
            return ["testfile1", "testfile2"], information

    tp = TestPostProcessor()
    files_to_delete, information = tp.run({"testfield": 42})
    assert files_to_delete == ["testfile1", "testfile2"]
    assert information["filepath"] == "testfilepath"

# Generated at 2022-06-22 09:11:54.096751
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_etree_fromstring

    class PPTest(PostProcessor):
        def run(self, info):
            return [], info

    pp = PPTest()

# Generated at 2022-06-22 09:11:58.675113
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('a', 'b', 'c')
    except AudioConversionError as err:
        assert str(err) == 'a'
        assert err.cause == 'b'
        assert err.original_message == 'c'

# Generated at 2022-06-22 09:12:00.847001
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message')
    except AudioConversionError as e:
        assert str(e) == 'error message'

# Generated at 2022-06-22 09:12:04.397749
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Create a temporary file
    Call PostProcessor with that file
    Check if PostProcessor returned list is correct
    """
    import tempfile
    filename = tempfile.mkstemp(suffix='.tmp')[1]

    class test_PostProcessor(PostProcessor):
        def run(self, information):
            return [information['filepath']], information
    test_PostProcessor().run({'filepath':filename})

# Generated at 2022-06-22 09:12:04.813339
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    pass

# Generated at 2022-06-22 09:12:09.936535
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    dl = object()

    class TestPP(PostProcessor):
        def __init__(self):
            self.dl = None

        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            self.dl = downloader

    pp = TestPP()
    pp.set_downloader(dl)
    assert pp._downloader is dl
    assert pp.dl is dl

# Generated at 2022-06-22 09:12:15.698279
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    t = PostProcessor()
    t.set_downloader(1)
    assert t._downloader == 1
    t.set_downloader(2)
    assert t._downloader == 2
    t.set_downloader("3")
    assert t._downloader == "3"


# Generated at 2022-06-22 09:12:21.383279
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('123', '456', '789')
    except AudioConversionError as e:
        assert e.args[0] == '123'
        assert e.args[1] == '456'
        assert e.args[2] == '789'
        assert e.args[3] == '%s: %s' % ('123', '789')
        assert '123' in str(e)
        assert '456' in str(e)
        assert '789' in str(e)
    else:
        assert False, 'test failed'

# Generated at 2022-06-22 09:12:23.555837
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp != None


# Generated at 2022-06-22 09:12:35.347049
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPP(PostProcessor):

        def __init__(self, downloader=None, test_setgo_value=False):
            PostProcessor.__init__(self, downloader)
            self.test_setgo_value = test_setgo_value

        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            if self.test_setgo_value:
                self._downloader = True

    pp1 = TestPP(test_setgo_value=True)
    assert pp1._downloader == None
    pp1.set_downloader(True)
    assert pp1._downloader == True

    pp2 = TestPP(test_setgo_value=False)
    assert pp2._downloader == None

# Generated at 2022-06-22 09:12:41.968396
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, information):
            return [], {'title': 'test'}
    pp = TestPP()
    assert pp.run({}) == ([], {'title': 'test'})

# Generated at 2022-06-22 09:12:44.688126
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 2)
    except AudioConversionError as e:
        assert e.args[0] == 1
        assert e.args[1] == 2



# Generated at 2022-06-22 09:12:49.041092
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import YoutubeDL

    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    pp = DummyPostProcessor()
    ydl = YoutubeDL({'preferredcodec': 'mp3'})
    ydl.add_post_processor(pp)

    assert pp._downloader == ydl

# Generated at 2022-06-22 09:13:01.271962
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_http_client

    class FakeInfo:
        def __init__(self, filepath):
            self.filepath = filepath

    class FakeDownloader:
        def __init__(self):
            self.downloaded_info_dicts = {'fake_id': FakeInfo('fake_filepath')}
            self.params = {}

    class FakePostProcessor(PostProcessor):
        def run(self, information):
            return ['fake_filepath'], information

    postprocessor = FakePostProcessor(FakeDownloader())
    removed_files, result = postprocessor.run({'id': 'fake_id'})
    assert removed_files == ['fake_filepath']
    assert result == {'id': 'fake_id', 'filepath': 'fake_filepath'}

# Unit test

# Generated at 2022-06-22 09:13:03.544918
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Check the default value of run method
    d = PostProcessor()
    assert d.run({"filepath": "test"}) == ([], {"filepath": "test"})



# Generated at 2022-06-22 09:13:04.649150
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        PostProcessor()
    except:
        raise AssertionError('Could not instantiate an empty PostProcessor object')

# Generated at 2022-06-22 09:13:07.929826
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert not pp._downloader
    pp.set_downloader(True)
    assert pp._downloader
    pp.set_downloader(None)
    assert not pp._downloader

# Generated at 2022-06-22 09:13:13.122728
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    info = {
        'id': 'testid',
        'ext': 'testext',
    }
    pp = MyPostProcessor()
    assert pp.run(info) == ([], info)


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:13:16.880582
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = PostProcessor()
    pp1 = PostProcessor(ydl)
    pp.set_downloader(ydl)
    assert pp._downloader is ydl
    assert pp1._downloader is ydl


# Generated at 2022-06-22 09:13:20.548074
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import youtube_dl

    pp_noset = youtube_dl.PostProcessor()


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:13:29.869031
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message', 'output')
    except  AudioConversionError as e:
        out_string = u'[ffmpeg] error message: output'
        assert(e.args[0] == out_string)

# Generated at 2022-06-22 09:13:33.529465
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    assert pp._downloader is None
    downloader = FileDownloader({})
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:13:35.416853
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Just instantiating the class should work."""
    PostProcessor()


# vim:ts=4:sw=4:expandtab

# Generated at 2022-06-22 09:13:36.925198
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        pass

    pp = TestPP()
    assert pp.__class__ == TestPP

# Generated at 2022-06-22 09:13:41.519254
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            assert info['filepath'] == 'test'
            info['filepath'] = 'ok'
            return ['file1', 'file2'], info

    pp = TestPP()
    to_delete, info = pp.run({'filepath': 'test'})
    assert to_delete == ['file1', 'file2']
    assert info['filepath'] == 'ok'



# Generated at 2022-06-22 09:13:44.497405
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError(u'error', u'1.00')



# Generated at 2022-06-22 09:13:54.455799
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_struct_time

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            info['new_field'] = 'test'
            return ['file1'], info

    class FakeDownloader():
        params = {}
        to_stderr = to_screen = lambda x: x
        trouble = lambda *x: None
        report_warning = lambda *x: None


# Generated at 2022-06-22 09:13:57.398202
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError(None, None)
    assert e.audio_format is None
    assert e.code is None
    assert str(e) == ''
    assert e.cause is None



# Generated at 2022-06-22 09:14:05.351462
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    try:
        from ..downloader.common import FileDownloader
    except ImportError:
        return

    downloader = FileDownloader(None)
    pp = PostProcessor(downloader)

    print('Downloader is set') if pp._downloader else print('Downloader is not set')
    assert pp._downloader

    pp.set_downloader(None)
    print('Downloader is set') if pp._downloader else print('Downloader is not set')
    assert not pp._downloader

# Generated at 2022-06-22 09:14:07.809160
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import doctest
    doctest.run_docstring_examples(PostProcessor.try_utime, globals(), verbose=True)

# Generated at 2022-06-22 09:14:23.977887
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(2, 3, 4, 5)
    except AudioConversionError as err:
        assert err.original_error == 2
        assert err.format is 3
        assert err.filepath is 4
        assert err.audio_codec is 5
    else:
        assert False



# Generated at 2022-06-22 09:14:30.948776
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    gen_extractors()

    from ..downloader.common import FileDownloader
    downloader = FileDownloader({})

    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    postprocessor = FFmpegExtractAudioPP({})
    postprocessor.set_downloader(downloader)

    assert downloader == postprocessor._downloader


# Generated at 2022-06-22 09:14:42.213424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest2
    import tempfile
    from ..compat import compat_open

    class post_processor_test(PostProcessor):
        def run(self, info):
            with compat_open(info['filepath'], 'wb') as f:
                f.write('test string')
            self.try_utime(info['filepath'], 0, 0, "")
            self.try_utime(info['filepath'], 1, 1, "")
            self.try_utime(1, 0, 0, "")
            return [], info

    class TestPostProcessor(unittest2.TestCase):
        def test_utime(self):
            info = {'filepath': tempfile.NamedTemporaryFile().name}
            post_processor_test(None).run(info)

    un

# Generated at 2022-06-22 09:14:51.469939
# Unit test for method run of class PostProcessor

# Generated at 2022-06-22 09:14:57.503885
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1,2,3)
    except (AudioConversionError) as err:
        assert err.args[0] == 1
        assert err.args[1] == 2
        assert err.args[2] == 3



# Generated at 2022-06-22 09:15:09.401059
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test method run() of class PostProcessor.
    """
    class PostProcessor1(PostProcessor):
        def run(self, info):
            info['key1'] = 'value1'
            return [], info

    class PostProcessor2(PostProcessor):
        def run(self, info):
            info['key2'] = 'value2'
            return [], info

    class PostProcessor3(PostProcessor):
        def run(self, info):
            info['key3'] = 'value3'
            return [], info

    class PostProcessor4(PostProcessor):
        def run(self, info):
            return [], None

    class PostProcessor5(PostProcessor):
        def run(self, info):
            raise PostProcessingError('Test exception')


# Generated at 2022-06-22 09:15:12.645513
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessor(PostProcessor):
        demands = ['filepath']

        def run(self, information):
            return [], information
    pp = MockPostProcessor()
    pp.set_downloader(object)
    assert pp.run({'filepath': 1}) == ([], {'filepath': 1})

# Generated at 2022-06-22 09:15:17.832104
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockDownloader:
        def __init__(self):
            self._pp = False

        def add_post_processor(self, pp):
            self._pp = pp

    d = MockDownloader()
    pp = PostProcessor(d)
    assert pp._downloader is d
    assert not d._pp
    pp.set_downloader(d)
    assert pp._downloader is d
    assert d._pp is pp

# Generated at 2022-06-22 09:15:21.118376
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor."""
    pp = PostProcessor()
    assert pp

if __name__ == "__main__":
    test_PostProcessor()

# Generated at 2022-06-22 09:15:22.557873
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # No need to test constructor as it's an abstract class
    pass

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:47.371068
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-22 09:15:51.303323
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(
            'postprocessor_error', 'too many failed conversions')
    except AudioConversionError as e:
        assert e.args == ('postprocessor_error: too many failed conversions',)

# Generated at 2022-06-22 09:15:52.447528
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._configuration_args() == []

# Generated at 2022-06-22 09:15:54.614111
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postProcessor = PostProcessor()
    assert isinstance(postProcessor, PostProcessor)

# Generated at 2022-06-22 09:15:56.559106
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('TEST')
    except AudioConversionError as e:
        assert str(e) == 'TEST'
        assert repr(e) == '<AudioConversionError> TEST'

# Generated at 2022-06-22 09:16:06.803889
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # we need to use the real PostProcessor class with the real downloader
    # because we need a real downloader to call report_error() and
    # report_warning() functions
    from ..extractor import get_downloader
    downloader = get_downloader()

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            downloaded_file_path = info['filepath']
            assert downloaded_file_path == 'file'

            return [], info

    tp = TestPostProcessor(downloader)
    tp.run({'filepath': 'file'})

# Generated at 2022-06-22 09:16:13.522380
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.test_dl = None

        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            self.test_dl = downloader

        @staticmethod
        def test_get_test_dl():
            return self.test_dl

    testDownloader = object()
    testPP = TestPP()
    testPP.set_downloader(testDownloader)
    assert(testPP.test_dl is testDownloader)

# Generated at 2022-06-22 09:16:16.397181
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    t = TestPostProcessor()
    assert t._downloader is None

# Generated at 2022-06-22 09:16:24.121243
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Test if the method set_downloader of class PostProcessor can set the downloader
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            self._downloader = None

        def run(self, info):
            if self._downloader is not None:
                return [], info
            else:
                return [], {}

    p = TestPostProcessor()
    p.set_downloader('MyDownloader')
    # The method run should return [], info
    assert p.run('MyInfo') == ([], 'MyInfo')

# Generated at 2022-06-22 09:16:25.261454
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        PostProcessor()
    except:
        raise AssertionError("Constructor of class PostProcessor should not raise Exception")

# Generated at 2022-06-22 09:17:19.720288
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import os

    class Downloader():
        def __init__(self):
            self.params = {'sleep_interval': 0}
        def to_stderr(self, str):
            sys.stderr.write(str + '\n')
        def report_warning(self, str):
            self.to_stderr(str)

    dl = Downloader()

    pp = PostProcessor(dl)
    os.utime = lambda path, atime, mtime: 0
    assert pp.try_utime("path", "atime", "mtime") == None
    os.utime = lambda path, atime, mtime: sys.exit("PostProcessorTestError")

# Generated at 2022-06-22 09:17:23.116098
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('test message')
    assert error.message == 'test message', 'Invalid exception message'
    assert error.cause is None, 'Invalid exception cause'
    error = AudioConversionError('test message', 'test cause')
    assert error.message == 'test message', 'Invalid exception message'
    assert error.cause == 'test cause', 'Invalid exception cause'



# Generated at 2022-06-22 09:17:26.222778
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('a', 'b', 'c').args[0] == 'Cannot convert audio file a: b: c'

# Generated at 2022-06-22 09:17:28.842385
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    postProcessor = PostProcessor()
    assert postProcessor._downloader is None
    postProcessor.set_downloader(youtube_dl)
    assert postProcessor._downloader == youtube_dl

# Generated at 2022-06-22 09:17:32.463389
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:17:34.886109
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Check that set_downloader() works as expected.
    """
    pp = PostProcessor()
    pp.set_downloader('dummy')
    assert pp._downloader == 'dummy'

# Generated at 2022-06-22 09:17:44.513243
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from .common import CommonPostProcessor, PostProcessingTestCase

    class PostProcessorForTest(CommonPostProcessor):

        def test_run(self, information, tmpfilename):
            self._downloader.params['ranges'] = DateRange('1970-01-01')
            self.run(information)

        def run(self, information):
            super(PostProcessorForTest, self).run(information)
            path = information['filepath']
            self.try_utime(path, 100, 100)
            self.try_utime(path, 100, 100, 'Cannot update utime of file')
            os.remove(encodeFilename(path))

    PostProcessorForTest.test()

# Generated at 2022-06-22 09:17:50.487954
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import YoutubeDL
    from ..extractor.common import InfoExtractor

    class IE(InfoExtractor):
        def __init__(self, downloader):
            super(IE, self).__init__(downloader)
        def _real_extract(self):
            pass
    ydl = YoutubeDL()
    ydl.add_info_extractor(IE)
    pp = PostProcessor(ydl)
    pp.set_downloader(ydl)
    assert pp._downloader is ydl

# Generated at 2022-06-22 09:17:57.164604
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Checks if the class PostProcessor is working properly."""

    # Test for the trivial case
    class TestPostProcessor1(PostProcessor):
        def run(self, information):
            assert information["filepath"] == "test.flv"
            return [], information

    info = dict(filepath="test.flv")
    tp1 = TestPostProcessor1(None)
    files_to_delete, new_info = tp1.run(info)
    assert files_to_delete == []
    assert new_info is info

    # Test for the non-trivial case
    class TestPostProcessor2(PostProcessor):
        def run(self, information):
            assert information["filepath"] == "test.flv"
            information["filepath"] = "test.avi"
            return [],

# Generated at 2022-06-22 09:17:57.847710
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    post_processor = PostProcessor()
    assert post_processor

# Generated at 2022-06-22 09:19:56.904938
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import os
    import shutil
    import tempfile

    from ..utils import get_suitable_downloader

    # Create working folder
    workdir = tempfile.mkdtemp()

    # Create "PostProcessor"
    test_result = (os.path.join(workdir, 'test_result_file'), 'test_result_information')
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            return test_result

    # Create downloader
    downloader = get_suitable_downloader()

# Generated at 2022-06-22 09:20:00.447181
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Test set_downloader method of class PostProcessor"""
    p1 = PostProcessor()
    p2 = PostProcessor()
    p1.set_downloader(p2)
    assert p1._downloader == p2

# Generated at 2022-06-22 09:20:09.171892
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .test_postprocessors_common import MockYDL

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': url,
                'title': url,
                'ext': 'mp4',
            }

    ie = FakeInfoExtractor()
    ie.add_info_extractor(ie)
    ydl = MockYDL()
    ydl.add_info_extractor(ie)
    test_post_processor = PostProcessor(ydl)


# Generated at 2022-06-22 09:20:16.315046
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    from ..extractor import gen_extractors
    downloader = FileDownloader(params=None, outtmpl='unit_test')
    downloader.add_default_info_extractors()
    gen_extractors(downloader)
    p = PostProcessor(downloader)
    p.try_utime('/Parent/',1,0,'Cannot update utime of file')
    p.try_utime('/Child/',1,1,'Cannot update utime of file')

# Generated at 2022-06-22 09:20:25.087705
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    import stat

    dir = tempfile.mkdtemp()
    file = os.path.join(dir, 'test')
    with open(file, 'wb'):
        pass
    atime = datetime.datetime.now()
    mtime = atime - datetime.timedelta(hours=1)
    time.sleep(1)
    pp = PostProcessor(None)
    pp.try_utime(file, atime, mtime)
    st = os.stat(file)
    assert(st[stat.ST_ATIME] == time.mktime(atime.timetuple()))
    assert(st[stat.ST_MTIME] == time.mktime(mtime.timetuple()))
    time.sleep(1)
    os

# Generated at 2022-06-22 09:20:31.835429
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return ['test\\file\\to\\delete.avi'], info


    information = {
        'filepath': 'test/file/to/process.avi',
        'ext': 'avi',
        'title': 'example',
        'format': 'avi',
        'format_id': 'avi',
        'player_url': '',
    }

    postprocessor = MockPostProcessor()
    files_to_delete, new_information = postprocessor.run(information)

    assert files_to_delete == ['test\\file\\to\\delete.avi']