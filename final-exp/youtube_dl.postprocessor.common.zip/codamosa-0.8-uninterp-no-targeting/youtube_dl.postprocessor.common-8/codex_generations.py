

# Generated at 2022-06-22 09:10:40.427145
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    downloader = Downloader()

    postProcessor = PostProcessor(downloader)

    # Call set_downloader() method and check if _downloader value is correctly set
    postProcessor.set_downloader(downloader)
    assert(postProcessor._downloader == downloader)

    # Call set_downloader() method without parameters and check if the _downloader value is still the same
    postProcessor.set_downloader()
    assert(postProcessor._downloader == downloader)

# Generated at 2022-06-22 09:10:51.315436
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This class is for testing the try_utime method of class PostProcessor
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            # Test utime method
            # If all files are successfully update the file 'test1.mp4'
            # And if one of files fails to update the file 'test2.mp4'
            import time
            now = time.time()
            for f in information['filepath']:
                self.try_utime(f, now, now, 'Cannot update utime of file')
            self.try_utime(information['filepath'][0], now, now, 'Cannot update utime of file')
            return [information['filepath'][0]], information
    import tempfile
    import shutil
    import os
    from ..downloader import FileDownloader

# Generated at 2022-06-22 09:10:54.229631
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():  # pylint: disable=unused-variable,invalid-name
    try:
        raise AudioConversionError('foo', 'bar', 'baz')
    except AudioConversionError as e:
        pass
    else:
        assert False



# Generated at 2022-06-22 09:11:02.005015
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    import os
    import sys
    import tempfile
    # Create temporary files
    dummy_path = encodeFilename(tempfile.NamedTemporaryFile().name)
    # Make sure the files doesn't exist to be created as empty
    os.remove(dummy_path)
    # Create the class
    post_processor = PostProcessor()
    # Run the method
    post_processor.try_utime(dummy_path, 1, 1)
    # Check the returned value
    assert os.path.exists(dummy_path)

# Generated at 2022-06-22 09:11:03.428440
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    a = PostProcessor()
    assert a


# Test OpenGraphPP

# Generated at 2022-06-22 09:11:14.565794
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['postprocessor_args'] = []
    # Test that _configuration_args returns default value on creation of class
    p = PostProcessor(ydl)
    assert p._configuration_args() == []
    # Test that _configuration_args returns correct value after set_downloader
    p.set_downloader(ydl)
    assert p._configuration_args() == []
    # Test that _configuration_args returns correct value after set_downloader
    ydl.params['postprocessor_args'] = ['--foo', 'bar']
    p.set_downloader(ydl)
    assert p._configuration_args() == ['--foo', 'bar']

# Generated at 2022-06-22 09:11:17.461099
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-22 09:11:21.342244
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Simple test for method set_downloader of class PostProcessor
    """
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(object())
    assert pp._downloader is not None

# Generated at 2022-06-22 09:11:22.716661
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError



# Generated at 2022-06-22 09:11:25.785997
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader('foo')
    assert pp._downloader == 'foo'

# Generated at 2022-06-22 09:11:33.343601
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    This will test the PostProcessor initialization
    """
    import youtube_dl

    test_PostProc = PostProcessor()
    test_downloader = youtube_dl.YoutubeDL()
    test_PostProc.set_downloader(test_downloader)
    # test_PostProc._downloader should be a YoutubeDL object
    assert (isinstance(test_PostProc._downloader, youtube_dl.YoutubeDL))

# Generated at 2022-06-22 09:11:38.071883
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPP(PostProcessor):
        def run(self, information):
            return [], information

    d = DummyPP()
    assert d.__class__ == DummyPP
    assert not d._downloader

# Generated at 2022-06-22 09:11:41.412144
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(3, 'test', 'details')
    except AudioConversionError as err:
        assert(err.error_code == 3)
        assert(err.msg == 'test')
        assert(err.details == 'details')
    else:
        assert(False)

# Generated at 2022-06-22 09:11:45.074784
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    post_processor = PostProcessor()
    downloader = object()
    post_processor.set_downloader(downloader)
    assert downloader is post_processor._downloader

# Generated at 2022-06-22 09:11:52.123375
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    global _downloader
    _downloader = 'Test downloader'

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            global _downloader
            assert self._downloader == _downloader, \
                'Wrong downloader in postprocessor'
            return information

    tp = TestPostProcessor()
    tp.set_downloader(_downloader)
    tp.run('Test information')

# Generated at 2022-06-22 09:11:55.243113
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor."""
    pp = PostProcessor()
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:11:58.783676
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass
    except:
        raise Exception('AudioConversionError does not inherit from PostProcessingError')



# Generated at 2022-06-22 09:12:00.980768
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test PostProcessor constructor."""
    # pylint: disable=no-value-for-parameter
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:12:05.479405
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_str
    postprocessor = PostProcessor()
    postprocessor.run({'a': 'b', 'c': 'd'})
    postprocessor.run({'a': 'b', 'c': 'd', 'filepath': 'f'})
    postprocessor.run({'a': 'b', 'c': 'd', 'filepath': compat_str('f')})

# Generated at 2022-06-22 09:12:10.823998
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import FakeYDL
    from .common import PostProcessorTest

    # Create a downloader instance
    ydl = FakeYDL()

    # Create a test PostProcessor instance
    pp_test = PostProcessorTest(ydl)

    # The downloader instance wasn't set
    assert pp_test._downloader is None

    # We call set_downloader
    pp_test.set_downloader(ydl)

    # The downloader instance is set
    assert pp_test._downloader is not None


# Generated at 2022-06-22 09:12:15.973260
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return ['a', 'b'], info
    pp = DummyPostProcessor()
    assert pp.run({}) == (['a', 'b'], {})

# Generated at 2022-06-22 09:12:20.720156
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    import sys
    try:
        raise AudioConversionError('foo', 42)
    except AudioConversionError as err:
        assert type(err) is AudioConversionError
        assert str(err) == 'foo'
        assert sys.exc_info()[1].code == 42
    else:
        assert False, 'Expected exception'

# Generated at 2022-06-22 09:12:32.446498
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            if info.get('filepath', None) is None:
                return None, None
            return [], {
                'title': 'test',
                'filepath': info['filepath'],
                'ext': info['ext'],
            }
    pp = TestPP()
    filepath = 'fakepath/haha.ext'
    ext = 'ext'
    info = {'filepath': filepath, 'ext': ext}
    filepaths, info = pp.run(info)
    assert len(filepaths) == 0
    assert not info is None
    assert info['filepath'] == filepath
    assert info['ext'] == ext

# Generated at 2022-06-22 09:12:43.480805
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..utils import FileDownloader as FileDownloaderModule

    class MyPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    class MyIE(InfoExtractor):
        def __init__(self, downloader=None):
            InfoExtractor.__init__(self, downloader)

    class MyFD(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self._ies = [MyIE(downloader=self)]

    myfd = MyFD({})
    myie = myfd._ies[0]

# Generated at 2022-06-22 09:12:45.134959
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    assert pp.run({}) == ([], {'filepath': None})


# Generated at 2022-06-22 09:12:46.661514
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert err.cause == 'test'



# Generated at 2022-06-22 09:12:51.808789
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor
    """
    pp = PostProcessor()
    pp.try_utime('filename', 'atime', 'mtime')
    assert (pp.run({'filepath': 'fake'}))

# Generated at 2022-06-22 09:12:52.442150
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:12:56.465110
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 'test_file', 2)
    except AudioConversionError as error:
        assert error.error_code == 1
        assert error.input_filename == 'test_file'
        assert error.output_filename == None
        assert error.reason == 2
    else:
        assert False, 'Failed to raise AudioConversionError'

# Generated at 2022-06-22 09:13:08.290882
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class PD(PostProcessor):
            def test(self):
                return self._downloader is not None
    d = 'a_downloader'
    pd = PD()
    if ( pd.test() ):
        raise TypeError('PostProcessor._downloader must be None after construction')
    pd.set_downloader(d)
    if ( pd._downloader != d ):
        raise TypeError('PostProcessor.set_downloader does not set _downloader or sets it to wrong value')
    pd._downloader = 'changed value'
    pd.set_downloader(d)
    if ( pd._downloader != d ):
        raise TypeError('PostProcessor.set_downloader does not set _downloader or sets it to wrong value')


if __name__ == '__main__':
    test

# Generated at 2022-06-22 09:13:16.562087
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('test_input.m4a', 'test_output.wav')
    expected = "Converting 'test_input.m4a' to 'test_output.wav' failed!"
    assert error.args == (expected,)

# Generated at 2022-06-22 09:13:22.102318
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    dp = PostProcessor(downloader)
    assert dp._downloader == downloader
    new_downloader = YoutubeDL()
    dp.set_downloader(new_downloader)
    assert dp._downloader == new_downloader


# Generated at 2022-06-22 09:13:32.163616
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('Downloader', 'msg', 'cause')
    assert a.downloader == 'Downloader'
    assert a.msg == 'msg'
    assert a.cause == 'cause'
    assert str(a) == 'msg'
    assert a.caused_by() == 'caused by cause'
    assert a.format_traceback() == 'caused by cause'

    a = AudioConversionError('Downloader', 'msg')
    assert a.downloader == 'Downloader'
    assert a.msg == 'msg'
    assert not a.cause
    assert str(a) == 'msg'
    assert not a.caused_by()
    assert not a.format_traceback()

# Generated at 2022-06-22 09:13:33.739047
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:37.566099
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'error message'
    exc = AudioConversionError(msg)
    assert(exc.msg == msg)
    assert(exc.reason is None)

    reason = 'reason message'
    exc = AudioConversionError(msg, reason)
    assert(exc.msg == msg)
    assert(exc.reason == reason)

# Generated at 2022-06-22 09:13:38.754858
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postprocessor = PostProcessor()

# Generated at 2022-06-22 09:13:42.111036
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    pp.set_downloader(None)
    assert pp._downloader is None
    pp.set_downloader(True)
    assert pp._downloader is True

# Generated at 2022-06-22 09:13:50.137776
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            # We simply reverse the filename
            info['filepath'] = info['filepath'][::-1]
            return [], info
    
    info = {
        'filepath': '/tmp/test.mp4'
    }
    from ..compat import compat_urllib_request

    downloader = compat_urllib_request.URLopener()
    test = TestPostProcessor(downloader)
    files, new_info = test.run(info)
    assert new_info['filepath'] == '/pmt/tset'

# Generated at 2022-06-22 09:13:51.812924
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    '''
    Just test that creating a PostProcessor does not throw any exception
    '''
    PostProcessor()

# Generated at 2022-06-22 09:13:58.864983
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(downloader = None)
    try:
        assert pp._downloader == None
        pp.set_downloader(downloader = YoutubeDL())
        assert pp._downloader != None
    except AssertionError:
        return False
    return True


if __name__ == '__main__':
    def test():
        if not test_PostProcessor_set_downloader():
            return "Test fail"
        return "Test success"

    print(test())

# Generated at 2022-06-22 09:14:08.258533
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('The message')
    except AudioConversionError as err:
        assert str(err) == 'The message'



# Generated at 2022-06-22 09:14:10.461443
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    t = PostProcessor()
    assert t._downloader is None


# Generated at 2022-06-22 09:14:21.573799
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.common import InfoExtractor
    from ..utils import Downloader

    class FakeIE(InfoExtractor):

        _VALID_URL = r'https?://.+'
        _FILENAME = 'file'

        def __init__(self, downloader=None):
            super(FakeIE, self).__init__(downloader)
            self._count = 0

        def _real_extract(self, url):
            self._count += 1
            return {
                'id': 'id',
                'title': 'title',
                'description': 'description',
            }

    class FakePostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)
            self._count = 0


# Generated at 2022-06-22 09:14:24.536899
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader is ydl

# Generated at 2022-06-22 09:14:27.788039
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor."""
    pp = PostProcessor()
    pp.set_downloader(None)
    assert pp.run({'filepath': 'test.m4a'}) == ([], {'filepath': 'test.m4a'})

# Generated at 2022-06-22 09:14:31.201908
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DerivedPostProcessor(PostProcessor):
        def run(self, info):
            return info
    p = DerivedPostProcessor()
    assert p.run({}) == {}



# Generated at 2022-06-22 09:14:36.924615
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # method run must return a tuple
    downloader = FakeDownloader()
    downloader.add_info_extractor(FakeInfoExtractor())
    downloader.add_post_processor(FakePostProcessor())
    ret = downloader.download(FakeYoutubeIE()._TEST_RESULTS[0])
    assert (len(ret) == 2)



# Generated at 2022-06-22 09:14:47.778661
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import unittest

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.notes = []

        def report_warning(self, note):
            self.notes.append(note)

    class TestDownloader(object):
        def __init__(self):
            self.params = {}

    DummyFile = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'DummyFile')

    class Test(unittest.TestCase):
        def setUp(self):
            open(DummyFile, 'w').close()

        def tearDown(self):
            os.unlink(DummyFile)


# Generated at 2022-06-22 09:14:55.630951
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError("message", "stdout", "stderr")
    assert error.message == "message"
    assert error.stdout is "stdout"
    assert error.stderr is "stderr"
    assert str(error) == "message\n\nstdout\n\nstderr"
    assert error.args == ("message", "stdout", "stderr")

# Generated at 2022-06-22 09:14:59.658565
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_try_utime import TestUtime
    postprocessor = PostProcessor()
    postprocessor.try_utime = TestUtime.try_utime
    postprocessor._downloader = TestUtime()
    postprocessor.try_utime('file', 1, 1)

# Generated at 2022-06-22 09:15:15.072377
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.legacy import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..utils import match_filter_func
    from .exec import FFmpegPostProcessor

    ie = YoutubeIE()
    downloader = FileDownloader({
        'format': 'best',
        'outtmpl': '%(id)s',
        'writedescription': True,
    })
    downloader.add_info_extractor(ie)

    ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    # get the info
    info = downloader._match_entry(ie.ie_key(),
                                   lambda _, x: match_filter_func('BaW_jenozKc', x)
                                   )

# Generated at 2022-06-22 09:15:24.310397
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    assert (pp.run({}) == ([], {}))
    assert (pp.run({'title': 'Test'}) == ([], {'title': 'Test'}))
    assert (pp.run({'filepath': 'test'}) == ([], {'filepath': 'test'}))
    assert (pp.run({'filepath': 'test', 'title': 'Test'}) == ([], {'filepath': 'test', 'title': 'Test'}))

# Generated at 2022-06-22 09:15:28.122124
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Hello World')
    except AudioConversionError:
        pass
    else:
        raise Exception('AudioConversionError not raised')



# Generated at 2022-06-22 09:15:31.247020
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message')
    except AudioConversionError as exception:
        assert str(exception) == 'error message'
    else:
        assert False



# Generated at 2022-06-22 09:15:36.318462
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class FakePP(PostProcessor):
        def run(self, info):
            return [], info
    # Run method with a fake PP
    pp = FakePP()
    assert pp.run({}) == ([], {}), 'run method of class PostProcessor does not work'

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:15:44.983205
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [], info
    pp = TestPP()

# Generated at 2022-06-22 09:15:52.696222
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Test of the method run of class PostProcessor
    class PostProcessorMock(PostProcessor):
        def run(self, information):
            # We don't use this method
            self.information = information
            return information['filepath']

    post_processor = PostProcessorMock()
    result = post_processor.run({'filepath': 'somefile.txt', 'other': 'information'})
    assert result == 'somefile.txt'
    assert post_processor.information == {
        'filepath': 'somefile.txt',
        'other': 'information',
    }

# Generated at 2022-06-22 09:16:02.894855
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Unit test for method try_utime of class PostProcessor
    """
    import tempfile
    import shutil
    import sys


# Generated at 2022-06-22 09:16:08.223142
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    class DummyPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

        def run(self, information):
            return [], information  # by default, keep file and do nothing

    pp = DummyPostProcessor()
    assert pp._downloader is None
    downloader = FileDownloader({})
    pp.set_downloader(downloader)
    assert pp._downloader == downloader



# Generated at 2022-06-22 09:16:17.861662
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.called = False
            self.run_returns = ''

        def run(self, information):
            self.called = True
            return self.run_returns

    pp = MockPostProcessor()
    test_information = {'filename': 'test', 'filepath': 'test'}
    assert pp.run(test_information) == '', 'MockPostProcessor must return string'
    assert pp.called, 'MockPostProcessor must be called'


# Generated at 2022-06-22 09:16:36.684741
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p._downloader is None
    assert p.run({'filepath': '/tmp/foo.tmp'}) == ([], {'filepath': '/tmp/foo.tmp'})
    p = PostProcessor(None)
    assert p._downloader is None

if __name__ == '__main__':
    test_PostProcessor()
    print('Tests succeeded')

# Generated at 2022-06-22 09:16:43.679034
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_postprocessor_run import TestPostProcessorRun
    from .test_downloader_postprocessor_common import test_postprocessor

    # Initialize a postprocessor and override try_utime to not call os.utime
    pp = TestPostProcessorRun()
    pp.try_utime = lambda path, atime, mtime, errnote: None

    # Run the test
    test_postprocessor(pp)



# Generated at 2022-06-22 09:16:45.124391
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert isinstance(AudioConversionError(), PostProcessingError)



# Generated at 2022-06-22 09:16:57.398606
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange


# Generated at 2022-06-22 09:16:57.860584
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:17:02.266391
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor(None)

    # Test call without argument
    pp.set_downloader(None)
    assert pp._downloader is None

    # Test call with argument
    from youtube_dl.YoutubeDL import YoutubeDL
    pp.set_downloader(YoutubeDL({}))
    assert isinstance(pp._downloader, YoutubeDL)
    assert pp._downloader.params == {}

    # Test call with argument None
    pp.set_downloader(None)
    assert pp._downloader is None

    # Test call with argument
    from youtube_dl.YoutubeDL import YoutubeDL
    pp.set_downloader(YoutubeDL({}))
    assert isinstance(pp._downloader, YoutubeDL)
    assert pp._downloader.params == {}

# Generated at 2022-06-22 09:17:03.096325
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('foo')

# Generated at 2022-06-22 09:17:05.854043
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import FakeYDL
    pp = PostProcessor()
    dl = FakeYDL()
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-22 09:17:15.775328
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..utils import format_bytes

    class _Info(object):
        pass

    class _Downloader(object):
        def to_screen(self, *args):
            print(*args)

    class _PostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(_PostProcessor, self).__init__(downloader)

        def run(self, info):
            info.name = 'postprocessed'
            return [], info

    info = _Info()
    info.name = 'unprocessed'
    info.total_bytes = 1024
    info.downloaded_bytes = 1024

    dl = _Downloader()
    dl.params = {'noprogress': True}
    dl._screen_file = None

    pp = _PostProcessor(dl)


# Generated at 2022-06-22 09:17:24.347162
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    expected = 0, 0

# Generated at 2022-06-22 09:18:00.993294
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    # Test method set_downloader of PostProcessor
    postprocessor = PostProcessor()
    downloader = YoutubeDL()
    postprocessor.set_downloader(downloader)
    assert(postprocessor._downloader == downloader)
    return

# Generated at 2022-06-22 09:18:04.004931
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    postprocessor = PostProcessor()
    assert(postprocessor.run(['test']) == ([], 'test'))

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:18:11.066788
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    class MyPostProcessor(PostProcessor):
        def __init__(self, dl):
            PostProcessor.__init__(self, dl)
        def run(self, info):
            assert(self._downloader == dl)
            return [], info
    dl = YoutubeDL()
    pp = MyPostProcessor(dl)
    dl.add_post_processor(pp)
    dl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 09:18:21.934716
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # In order to test try_utime it must be run in a context that has
    # at least permissions to change the file access and modification times.
    # Create a file, similar to the one that downloader creates,
    # and the PostProcessor will have to change its timestamps.
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile(delete=False) as test_file:
        test_file.write(b'test')
    # Create a PostProcessor object
    postprocessor = PostProcessor()
    # set_downloader is needed to create a report object
    postprocessor.set_downloader(None)
    # Set timestamps to be changed
    atime = 0
    mtime = 1
    # Call try_utime and extract the filename

# Generated at 2022-06-22 09:18:30.235899
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from .common import PostProcessorTest
    def pp_run(self, information):
        self._downloader.to_screen('PP called for ' + information['filepath'])
        return ['somefile'], information
    pp = PostProcessor(YoutubeDL())
    pp.run = pp_run.__get__(pp, PostProcessor)
    pp.set_downloader(PostProcessorTest())
    pp.run({
        'id': 'fakevideoid',
        'filepath': 'fake/file/path.ext',
    })
# End of method unit test

# Generated at 2022-06-22 09:18:32.831523
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader == None
    pp.set_downloader("my_downloader")
    assert pp._downloader == "my_downloader"


# Generated at 2022-06-22 09:18:44.022456
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import os.path

    # Return the temporary directory of the operating system.
    # In Windows, tempfile.gettempdir() returns in native format
    # (e.g., C:\\SOME\\PATH), but os.path.join() converts that
    # to a format like that returned by os.getcwd() (e.g., C:/SOME/PATH).
    tmpdir = os.path.join(tempfile.gettempdir())

    # Create a file, since utime needs something to work with
    tmpfile = os.path.join(tmpdir, '.youtube-dl-test-file')
    tmp = open(tmpfile, 'wb')
    tmp.write('youtube-dl test file')
    tmp.close()

    # Get the current atime and mtime

# Generated at 2022-06-22 09:18:46.930594
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('a', 1, 'b', 2)
    except Exception as e:
        assert e.converter == 'a'
        assert e.original_path == 1
        assert e.new_file == 'b'
        assert e.new_path == 2
    else:
        assert False

# Generated at 2022-06-22 09:18:58.641443
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_http_server

    import threading

    # Let's define a test InfoExtractor class. It'll be as simple as possible
    class TestIE(InfoExtractor):
        def _real_initialize(self):
            self._html_webpage_regex = r'[0-9]+'
        def _real_extract(self, url):
            return {'id': 'testid',
                    'ext': 'mp4',
                    'description': 'foobar',
                    'title': 'title'}

    # We also need a server that serves a file while the content is being
    # downloaded, since the PostProcessor will need to access the file while
    # it's being downloaded

    # First let's create a test file
    server_started = threading

# Generated at 2022-06-22 09:19:09.659819
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # should not raise any exception.
    import tempfile
    from ..downloader import Downloader
    from ..utils import prepend_extension

    temp_filename = prepend_extension(tempfile.NamedTemporaryFile().name, 'temp')
    with open(temp_filename, 'wb') as temp_file:
        temp_file.write(b"test")
    post_processor = PostProcessor(Downloader(params={'outtmpl': '%(id)s'}))
    post_processor.try_utime(temp_filename, 0, 0)
    post_processor.try_utime(temp_filename, 0, 0, 'Failed to update utime of file %s')
    post_processor.try_utime(temp_filename, -1, -1)

# Generated at 2022-06-22 09:20:31.545392
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Make sure AudioConversionError is raised.

    This dummy test just makes sure that AudioConversionError is raised at
    all.
    """
    try:
        raise AudioConversionError("fail")
        assert False, "No exception was raised"
    except AudioConversionError as e:
        return
    except Exception:
        assert False, "Incorrect exception was raised"
    assert False, "No exception was raised"
