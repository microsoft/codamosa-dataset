

# Generated at 2022-06-22 09:10:40.089389
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .common import FakePostProcessor
    from .downloader import Downloader
    from .extractor import gen_extractor

    class FakeDownloader(Downloader):
        def __init__(self):
            self.ie = gen_extractor()

    d = FakeDownloader()
    pp = FakePostProcessor(d)
    assert pp._downloader == d

    d2 = FakeDownloader()
    pp.set_downloader(d2)
    assert pp._downloader == d2

# Generated at 2022-06-22 09:10:42.485435
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor(None)
    assert pp.run({'filepath': 1}) == ([], {'filepath': 1})

# Generated at 2022-06-22 09:10:51.170515
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(downloader=None)
    path = os.path.abspath(__file__)  # absolute path of this file
    import time
    atime = mtime = time.time()
    pp.try_utime(path, atime, mtime)
    stat = os.stat(encodeFilename(path))
    assert stat.st_atime == atime
    assert stat.st_mtime == mtime
    pp.try_utime(path, 0, 0)
    stat = os.stat(encodeFilename(path))
    assert stat.st_atime == 0
    assert stat.st_mtime == 0

# Generated at 2022-06-22 09:10:54.526045
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .YoutubeDL import YoutubeDL
    p = PostProcessor()
    d = YoutubeDL()
    p.set_downloader(d)
    assert p._downloader == d
    p.set_downloader(None)
    assert p._downloader is None

# Generated at 2022-06-22 09:10:55.339963
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError("Error")

# Generated at 2022-06-22 09:11:01.362079
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPostProcessor(PostProcessor):

        def run(self, info):
            if self._downloader is not None:
                return []
            else:
                return None

    pp = TestPostProcessor()
    assert pp.run({}) is None
    pp.set_downloader(None)
    assert pp.run({}) is None
    pp.set_downloader('Fake downloader')
    assert pp.run({}) == []

# Generated at 2022-06-22 09:11:05.356972
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    a = PostProcessor()
    b = FileDownloader()
    a.set_downloader(b)
    assert a._downloader == b

# Generated at 2022-06-22 09:11:08.219961
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p
    assert p.run([]) == ([], [])
    assert p.try_utime(__file__, 0, 0) == None

# Generated at 2022-06-22 09:11:13.967069
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    result = PostProcessor().run({
        'filepath': 'dummy.file',
        'webpage_url': 'dummy.url',
        'playlist': 'playlist'
    })
    assert result == ([], {
        'filepath': 'dummy.file',
        'webpage_url': 'dummy.url',
        'playlist': 'playlist'
    })

# Generated at 2022-06-22 09:11:26.473302
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange

    # Downloader with file
    downloader = Downloader(params={'nopart': True, 'quiet': True})
    with open(encodeFilename('temp_file'), 'w') as f:
        f.write('content')
    downloader.add_info_extractor(DummyIE(downloader, 'temp_file', [{
        'id': 'test_id',
        'title': 'Test',
        'ext': 'mp4',
        'upload_date': '20120101',
    }]))
    downloader.download(['test_id'])

    # Test utime failure
    pp = PostProcessor(downloader)

# Generated at 2022-06-22 09:11:32.521661
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postprocessor = PostProcessor(downloader=None)
    postprocessor.set_downloader(downloader=None)
    assert postprocessor._downloader == None, \
        'PostProcessor set_downloader is failed!'


# Generated at 2022-06-22 09:11:36.911191
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    TestClass = type('TestClass', (PostProcessor,), {})
    assert TestClass(downloader=None) is not None

# Generated at 2022-06-22 09:11:37.820723
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:11:41.487441
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # create a file
    f = os.path.join(os.getcwd(), 'test.tmp')
    f = encodeFilename(f)
    open(f, 'w').close()
    # test try_utime
    pp.try_utime(f, 0, 0)
    os.remove(f)

# Generated at 2022-06-22 09:11:46.346859
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo.bar')
    except AudioConversionError as err:
        assert str(err) == 'foo.bar'
        assert err.message == 'foo.bar'
    else:
        assert False, 'Failed to raise AudioConversionError!'

# Generated at 2022-06-22 09:11:56.044124
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys

    import mock
    import pytest

    from ..utils import PostProcessor
    from ..__main__ import main

    with mock.patch('sys.argv', ['youtubedl',
                                 '--no-warnings',
                                 '--skip-download',
                                 '--ffmpeg-location', 'test',
                                 '-o', 'test_%(format)s.%(ext)s']):
        main()
        # Disabling downloader. report_warning because downloader.py
        # prints a warning when no postprocessors
        # have been chosen, we don't want that in this unit test
        sys.modules['youtube_dl.downloader'].report_warning = lambda x: None

    pp = PostProcessor(sys.modules['__main__'].ydl)

# Generated at 2022-06-22 09:11:59.473209
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    downloader = Downloader()
    pp = PostProcessor(downloader)
    assert(pp._downloader == downloader)

# Generated at 2022-06-22 09:12:02.641018
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert str(err) == 'test', 'Could not use exception correctly'
    else:
        assert False, 'Could not raise exception'



# Generated at 2022-06-22 09:12:11.072536
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    import shutil
    from .testdownloader import TestDownloader

    class MyPP(PostProcessor):
        def run(self, info):
            return [], info
    pp = MyPP()
    with tempfile.NamedTemporaryFile(delete=False) as t:
        t.write(b'data')
        t.close()
        ydl = TestDownloader()
        info = {'filepath': t.name}
        try:
            pp.run(info)
        finally:
            try:
                os.remove(t.name)
            except OSError:
                pass

# Generated at 2022-06-22 09:12:20.600932
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from ..compat import PY2
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from .common import PostProcessorTestCase

    with PostProcessorTestCase(PostProcessor, downloader_cls=FileDownloader, downloader_kwargs={'params': {'download_archive': True}}) as pp:
        fpath = os.path.join(pp.tmpdir, 'test.mp4')
        with open(fpath, 'wb') as f:
            f.write(b'a' * 10)
        pp.postprocessor.set_downloader(pp.downloader)
        pp.postprocessor.try_utime(fpath, 1, 1)
        expected = 1, 1 if PY2 else None
        actual = os.stat(fpath).st

# Generated at 2022-06-22 09:12:25.278172
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:12:29.202651
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import youtube_dl.downloader
    d = youtube_dl.downloader.Downloader({})
    p = PostProcessor(d)
    d.postproc = p
    p.set_downloader(d)

# Generated at 2022-06-22 09:12:34.849987
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test the PostProcessor.run() method
    """
    class TestPostProcessor(PostProcessor):
        """
        A dummy test post processor
        """
        TEST_VALUE = 0

        def run(self, information):
            return ([], information)

    test_postprocessor_1 = TestPostProcessor()
    ret_info = test_postprocessor_1.run({})
    assert len(ret_info) == 2
    assert type(ret_info[0]) is list
    assert type(ret_info[1]) is dict
    assert ret_info[1] == {}

# Generated at 2022-06-22 09:12:45.482891
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Generates a PostProcessor object and unit tests its run method."""
    from ..extractor import (
        YoutubeIE,
    )

    from .common import (
        FakeYDL,
        ANY,
        subTest,
    )

    from .test_YoutubeDL import (
        MockYoutubeDL,
    )

    class MockPostProcessor(PostProcessor):
        """Mock PostProcessor."""
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)

        def run(self, information):
            return [], information

    class MockDownloader(FakeYDL):
        """Mock downloader"""
        def __init__(self):
            super(MockDownloader, self).__init__()
            self.postprocessors

# Generated at 2022-06-22 09:12:46.975892
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('my message')
    assert error.message == 'my message'
    assert error.code == 0

# Generated at 2022-06-22 09:12:53.557036
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # A PostProcessor must implement method run
    assert hasattr(PostProcessor, 'run')
    assert callable(PostProcessor.run)
    # Method run must accept one argument
    assert PostProcessor().run.func_code.co_argcount == 2
    # Method run must return a tuple
    assert hasattr(PostProcessor().run({}), '__iter__')

# Generated at 2022-06-22 09:12:56.334015
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    tpp = TestPostProcessor()
    assert tpp.run({'test': 'ten'}) == ([], {'test': 'ten'})

# Generated at 2022-06-22 09:13:02.776272
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockDownloader(object):
        def __init__(self):
            self.pp = PostProcessor(self)

    dl = MockDownloader()
    assert dl.pp._downloader is dl

    dl2 = MockDownloader()
    dl2.pp.set_downloader(dl)
    assert dl2.pp._downloader is dl



# Generated at 2022-06-22 09:13:08.341094
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class
    """
    from ..downloader.common import FileDownloader

    pp = PostProcessor()
    fd = FileDownloader({})
    pp.set_downloader(fd)
    assert(pp._downloader == fd)


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:13.935541
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'Invalid format'
    err = AudioConversionError(msg)
    assert hasattr(err, 'msg') and err.msg == msg
    assert hasattr(err, 'cause') and err.cause is None
    err = AudioConversionError(msg, cause='cause_of_the_error')
    assert hasattr(err, 'cause') and err.cause == 'cause_of_the_error'

# Generated at 2022-06-22 09:13:32.118244
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import os
    import tempfile
    from .common import FileDownloader

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary files
    pre_file = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    post_file = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

# Generated at 2022-06-22 09:13:40.709452
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.postprocess_counter = 0

        def run(self, information):
            self.postprocess_counter += 1
            if self.postprocess_counter == 1:
                return [], information
            return [information.get('filepath')], information

    downloader = object()
    pp = TestPostProcessor(downloader=downloader)
    information = {'filepath': 'file'}

    # Test the case that run is called twice, then file deletion occurs
    assert pp.run(information) == ([], information)
    assert pp.run(information) == ([information.get('filepath')], information)

# Generated at 2022-06-22 09:13:50.530405
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from os.path import exists
    from .compat import compat_open
    from .downloader import _real_main
    from .postprocessor import PostProcessor

    # Create a temporary test file
    temp_fd, temp_path = tempfile.mkstemp()
    os.close(temp_fd)

    # Change timestamp of file right now
    current_utime = os.path.getmtime(temp_path)
    os.utime(temp_path, (current_utime + 3600, current_utime + 3600))

    # Test the post processor try_utime method to restore timestamp after an hour
    post_processor = PostProcessor()

# Generated at 2022-06-22 09:13:52.482063
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('test1', 'test2')
    assert a.converted == 'test1'
    assert a.output == 'test2'

# Generated at 2022-06-22 09:13:56.857333
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.f4m import F4mFD
    pp = PostProcessor()
    result = pp.set_downloader(F4mFD(InfoExtractor(), 'http://www.example.com', 'videoid'))
    assert result == pp



# Generated at 2022-06-22 09:14:08.017226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 1, 2)
            return [], info
    pp = FakePostProcessor()
    import tempfile
    _, fname = tempfile.mkstemp()
    import os
    atime = os.stat(fname).st_atime
    mtime = os.stat(fname).st_mtime
    _, info = pp.run({'filepath': fname})
    os.unlink(fname)
    assert atime != 1
    assert mtime != 2

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-22 09:14:20.205915
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test method set_downloader of class PostProcessor.
    """
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    pp = PostProcessor()

    assert pp._downloader == None, 'Initial state of attribute _downloader of class PostProcessor is not None.'
    # Set up a downloader instance
    dl = FileDownloader({'noplaylist': True})

    # Add an InfoExtractor
    dl.add_info_extractor(YoutubeIE())

    # Add a PostProcessor
    pp.set_downloader(dl)

    assert pp._downloader == dl, 'State of attribute _downloader of class PostProcessor is not the expected.'


if __name__ == '__main__':
    import nose
    nose.core.runmodule()

# Generated at 2022-06-22 09:14:20.759274
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:14:27.539565
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test utime method
    import tempfile
    import time
    import os
    import shutil
    path = tempfile.mkstemp()[1]
    atime = time.time()
    mtime = time.time()
    pp = PostProcessor(None)
    pp.try_utime(path, atime, mtime)
    # Ensure that atime and mtime have been changed
    assert atime != os.stat(path).st_atime
    assert mtime != os.stat(path).st_mtime
    # Cleanup
    os.remove(path)

# Generated at 2022-06-22 09:14:34.072342
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import ydl_opts
    from ydl_opts import postproc_options, downloader_params
    from __main__ import FileDownloader
    p = PostProcessor()
    assert p._downloader is None
    d = FileDownloader(ydl_opts.YDL(ydl_opts=postproc_options), params=downloader_params)
    p.set_downloader(d)
    assert p._downloader == d


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:14:53.801088
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import sys
    from ..compat import compat_os_name

    sys.argv = [sys.argv[0]]

    from .. import YoutubeDL

    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:14:56.001001
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('test')
    print(error)
    assert 'test' in str(error)

# Generated at 2022-06-22 09:14:57.902100
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyPP(PostProcessor):
        def __init__(self, downloader):
            self._downloader = downloader

    pp = DummyPP(None)
    pp.set_downloader(object())
    assert pp._downloader is not None

# Generated at 2022-06-22 09:15:01.873204
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class MockDownloader:
        def __init__(self):
            self.params = dict()

    postProcessor = PostProcessor(MockDownloader())

    assert postProcessor != None
    assert postProcessor != ''

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:10.792577
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, information):
            assert 'filepath' in information
            return [], information

    pp = TestPP()
    info = {
        'id': 'test',
        'title': 'test',
        'formats': [],
        'ext': 'test',
        'url': 'test://',
        'player_url': None,
        '_type': 'url',
        'ie_key': None,
        'filepath': 'abc',
    }

    pp.run(info)


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:15:11.419935
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:15:15.197815
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = object()
    post_processor = PostProcessor(downloader)
    assert post_processor.downloader == downloader

    new_downloader = object()
    post_processor.set_downloader(new_downloader)
    assert post_processor.downloader == new_dowloader

# Generated at 2022-06-22 09:15:22.881190
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """ tests the constructor and run of PostProcessor """

    # Test with an undefined downloader
    pp = PostProcessor()
    assert pp.run(None) == ([], None)

    # Test with a defined downloader
    import youtube_dl
    pp = PostProcessor(youtube_dl)
    assert pp.run(None) == ([], None)

# Generated at 2022-06-22 09:15:23.729983
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True == True

# Generated at 2022-06-22 09:15:35.317167
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL

    def test_try_utime(self):
        _ = os.mkdir(self.temp_name('test'))
        tmp_file = self.temp_name('test/testfile')
        with open(tmp_file, 'wb') as f:
            f.write(b'')
        self.yp.try_utime(tmp_file, 1, 1)
        os.remove(tmp_file)

    test_instance = FakeYDL()
    test_instance.add_default_info_extractors()
    test_instance.add_default_downloader()
    test_instance.add_info_extractor(test_try_utime)
    YoutubeDL(test_instance).download(['http://a.b/test'])

# Generated at 2022-06-22 09:16:10.303306
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import get_suitable_downloader

    class MyPP(PostProcessor):
        def run(self, info_dict):
            return [info_dict['filepath'] + '.bak'], info_dict

    td = get_suitable_downloader({})
    td.add_post_processor(MyPP())
    fd, path = td._make_tmp_file(td.params)
    info_dict = {'filepath': path}
    files_to_delete, updated_info_dict = td._do_post_process(info_dict)
    assert files_to_delete == [path + '.bak']
    assert updated_info_dict == info_dict

# Generated at 2022-06-22 09:16:13.010497
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        AudioConversionError('foo')
    except Exception as e:
        assert False, 'Constructor of class AudioConversionError failed: ' + str(e)

# Generated at 2022-06-22 09:16:22.384709
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()
    import tempfile
    filename = tempfile.mkstemp()[1]
    p.try_utime(filename, 0, 0)
    p.try_utime(filename, 1, 2)
    import time
    assert time.localtime(os.path.getatime(filename)) == time.localtime(1)
    assert time.localtime(os.path.getmtime(filename)) == time.localtime(2)
    os.remove(filename)
    import dummy_downloader
    p = PostProcessor(dummy_downloader.DummyDownloader())
    p.try_utime(filename, 0, 0)

# Generated at 2022-06-22 09:16:24.375638
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    audioConversionError = AudioConversionError('message')
    assert audioConversionError.message == 'message'


# Generated at 2022-06-22 09:16:31.720315
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys
    import stat

    path = os.path.join(tempfile.gettempdir(), 'youtubedl_test.tmp')
    sys.stderr = open('/dev/null', 'w')

# Generated at 2022-06-22 09:16:34.541003
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader is ydl



# Generated at 2022-06-22 09:16:42.334835
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Test for set_downloader method for non-empty downloader
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)

    pp = TestPP()
    class TestDownloader:
        pass

    td = TestDownloader()
    pp.set_downloader(td)
    assert pp._downloader == td

    # Test for set_downloader method for empty downloader
    class TestPPWithEmpty(PostProcessor):
        def __init__(self, downloader=None):
            pass

    tp = TestPPWithEmpty()
    tp.set_downloader(td)
    assert hasattr(tp, '_downloader')
    assert tp._downloader == td

# Generated at 2022-06-22 09:16:45.912495
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError as e:
        assert str(e) == 'Audio conversion failed'
        assert repr(e) == '<AudioConversionError: Audio conversion failed>'
    else:
        assert False



# Generated at 2022-06-22 09:16:50.545553
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message', 'exit_code', 'stderr', 'stdout')
    except AudioConversionError as err:
        assert 'message' in str(err)
        assert 'exit_code' in str(err)
        assert 'stderr' in str(err)
        assert 'stdout' in str(err)

# Generated at 2022-06-22 09:16:56.940956
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    from ..extractor import bool_or_none
    from ..utils import DEFAULT_OUTTMPL

    d = Downloader()
    pp = PostProcessor(d)
    pp.set_downloader(d)
    assert pp._downloader is d

    # Test for #115
    d = Downloader()
    d.params['outtmpl'] = DEFAULT_OUTTMPL
    pp = PostProcessor(d)
    pp.set_downloader(d)
    assert pp._downloader is d

# Generated at 2022-06-22 09:17:58.063206
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    dl = object()
    pp = PostProcessor(dl)
    assert pp._downloader == dl

# Generated at 2022-06-22 09:18:03.097886
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    downloader = None
    PPOld = PostProcessor(downloader)
    PPOld.run(None)
    PPNew = PostProcessor(downloader)
    PPNew.run(None)
    while True:
        PPNew.run(PPOld.run(None)[1])


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:18:12.545263
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Simple unit test for method run of class PostProcessor.

    Returns True if everything is ok.
    """
    import tempfile
    import shutil

    def test_pp(info):
        """
        A test postprocessor.
        """
        tmpf = tempfile.NamedTemporaryFile(delete=False, prefix='postproc_test_')
        f = open(tmpf.name, 'wb')
        f.write(info['filepath'])
        f.write(b'\n')
        f.close()
        return [info['filepath']], info

    dir = tempfile.mkdtemp(prefix='postproc_test_')
    outf = open(os.path.join(dir, 'out'), 'wb')
    outf.write(b'in')
    outf.close()



# Generated at 2022-06-22 09:18:22.990288
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class InfoExtractor(object):

        def __init__(self):
            self.postprocessors = [MyPostProcessor()]

# Generated at 2022-06-22 09:18:33.195515
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys

    class FakeDownloader():
        params = {
            'nooverwrites': True,
            'format': 'best',
        }

        def report_warning(self, msg):
            sys.stderr.write(msg + '\n')

    class FakeInfoExtractor():
        def __init__(self):
            self.ie_key = 'test'

    class TestPP(PostProcessor):
        def run(self, information):
            return [information['filepath']], information

        def _configuration_args(self, default=[]):
            return cli_configuration_args(self._downloader.params, 'postprocessor_args', default)

    downloader = FakeDownloader()
    ie = FakeInfoExtractor()

# Generated at 2022-06-22 09:18:44.130731
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request, compat_urllib_error, compat_urllib_parse
    from ..extractor import common
    from ..YoutubeDL import YoutubeDL

    class TestInfoExtractor(common.InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid',
                    'title': 'testttitle',
                    'url': url,
                    'ext': 'mp4'}

        def _real_download(self, url):
            compat_urllib_request.urlopen(url)

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            assert info['id'] == 'testid'
            assert info['title'] == 'testttitle'

# Generated at 2022-06-22 09:18:48.760134
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    class DummyDownloader():
        pass
    dummy_dl = DummyDownloader()
    pp.set_downloader(dummy_dl)
    assert pp._downloader == dummy_dl

# Generated at 2022-06-22 09:18:50.190295
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert isinstance(pp, PostProcessor)

# Generated at 2022-06-22 09:18:57.040547
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # Test if constructor of AudioConversionError is working
    msg = 'Audio Conversion Error'
    e = AudioConversionError(msg)
    assert e.msg == msg
    assert e.path is None
    assert e.exit_code is None

    e = AudioConversionError(msg, 'foo', 42)
    assert e.msg == msg
    assert e.path == 'foo'
    assert e.exit_code == 42



# Generated at 2022-06-22 09:19:01.222105
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Wrong input format')
    except AudioConversionError as err:
        assert err.args[0] == 'Wrong input format'
    else:
        assert False, 'AudioConversionError not raised'

