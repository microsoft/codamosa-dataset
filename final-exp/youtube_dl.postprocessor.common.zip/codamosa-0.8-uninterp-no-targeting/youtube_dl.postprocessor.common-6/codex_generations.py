

# Generated at 2022-06-22 09:10:36.598382
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Check if PostProcessor.set_downloader works.
    """
    pp_object = PostProcessor()
    pp_object.set_downloader(None)
    assert (pp_object._downloader is None)

# Generated at 2022-06-22 09:10:46.699520
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..__main__ import ydl
    ydl = YoutubeDL(params={'outtmpl': '%(title)s.%(ext)s', 'quiet':True})
    pp = PostProcessor(ydl)
    # In order to test 'try_utime', we need to create a file first
    # We use the method 'download' of YoutubeDL
    # Note: This may fail in case of ffmpeg problem
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    # Create a dummy object 'information' for postprocessor
    information = {'filepath': 'BaW_jenozKc.mp4',
        'title': 'BaW_jenozKc',
        'ext': 'mp4'}
   

# Generated at 2022-06-22 09:10:53.300136
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestDownloader:
        def __init__(self):
            self.value_of_set_downloader = None

    test_downloader = TestDownloader()
    test_postprocessor = PostProcessor()
    test_postprocessor.set_downloader(test_downloader)

    assert test_downloader.value_of_set_downloader == test_postprocessor, \
        'Setter method of PostProcessor does not work as expected'

# Generated at 2022-06-22 09:10:59.150138
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyDownloader(object):
        pass
    pp = PostProcessor()
    downloader = DummyDownloader()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:11:10.861660
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    from ..downloader import gen_downloaders
    from ..downloader.common import FileDownloader

    def _create_PostProcessor(dummy_downloader):
        class DummyPostProcessor(PostProcessor):
            def __init__(self):
                PostProcessor.__init__(self)
        return DummyPostProcessor()

    downloader = FileDownloader({})
    downloader.add_info_extractor(gen_extractors()[0])
    downloader.add_post_processor(_create_PostProcessor)
    downloader.add_post_processor(_create_PostProcessor)

    for _ in gen_downloaders():
        downloader.download(['http://youtube.com/watch?v=BaW_jenozKc'])
        downloader

# Generated at 2022-06-22 09:11:18.204468
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from pytube import Downloader
    # Create a PostProcessor object
    pp = PostProcessor()
    # Create a downloader object
    dl = Downloader('http://www.youtube.com/watch?v=BaW_jenozKc')
    # Set the PostProcessor downloader to downloader object
    pp.set_downloader(dl)
    # Check if both downloaders are same
    assert pp._downloader == dl

# Generated at 2022-06-22 09:11:28.825713
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from collections import namedtuple
    from .common import FakeYDL
    from .extractor import gen_extractor
    info = namedtuple('info', ['video_id', 'title', 'filename', 'ext'])

    def extractor(url):
        return info(url, url, url, url)

    class PostProcessorPP(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

        def run(information):
            return None

    ydl = FakeYDL()
    gen_extractor(ydl, 'test', 'http://qq.com', extractor)
    ydl.params['postprocessor_args'] = ['test2']
    pp = PostProcessorPP(ydl)

# Generated at 2022-06-22 09:11:35.869064
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    from ..compat import compat_os_name
    from ..downloader import Downloader

    class FakePP(PostProcessor):
        def __init__(self):
            super(FakePP, self).__init__()
            self.downloader = Downloader()

    pp = FakePP()

    orig_atime, orig_mtime = 10, 10
    path = "test"
    import tempfile
    fd, fpath = tempfile.mkstemp()
    os.close(fd)
    os.utime(fpath, (orig_atime, orig_mtime))
    atime, mtime = os.path.getatime(fpath), os.path.getmtime(fpath)
    pp.try_utime(fpath, atime, mtime)
    ret_atime,

# Generated at 2022-06-22 09:11:36.499031
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()



# Generated at 2022-06-22 09:11:38.190661
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("Cannot convert audio")
    except AudioConversionError as exc:
        assert exc.args == ("Cannot convert audio",)
    else:
        raise AssertionError("Exception AudioConversionError not raised")

# Generated at 2022-06-22 09:11:43.084695
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postProcessor = PostProcessor(None)
    assert postProcessor._downloader is None
    from ..downloader.YoutubeDL import YoutubeDL
    postProcessor.set_downloader(YoutubeDL())
    assert postProcessor._downloader is not None


# Generated at 2022-06-22 09:11:48.203624
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a PostProcessor object
    pp = PostProcessor()
    # Prepare a information dict to be passed to run()
    information = {'filepath': 'filepath.mp4'}
    # Test PostProcessor object's run method
    assert pp.run(information) == ([], information)


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:11:49.555583
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader is None

# Generated at 2022-06-22 09:11:57.526683
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    postprocessor = PostProcessor()

# Generated at 2022-06-22 09:12:03.568007
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.utime = lambda *x: True
    assert PostProcessor().try_utime(
        'path',
        'atime',
        'mtime',
        'errnote'
    ) is None

    os.error = OSError
    os.utime = lambda *x: os.error
    assert PostProcessor().try_utime('path', 'atime', 'mtime', 'errnote') is None

# Generated at 2022-06-22 09:12:07.244850
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    print(pp)

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:12:09.640336
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except PostProcessingError:
        pass


# Generated at 2022-06-22 09:12:12.967639
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError("AudioConversionError")
    assert str(err) == "AudioConversionError"

# Generated at 2022-06-22 09:12:21.629143
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    try:
        import pytest
        import py
    except ImportError:
        print('pytest or py is not installed. Skipping PostProcessor.try_utime test')
        return

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'testfile.txt')

    with open(test_file, 'w') as f:
        f.write("This is some text\n")

    test_time = datetime.datetime(2015, 6, 29, 1, 2, 3)
    test_time_unix = 1435532923
    assert test_time.timestamp() - test_time_unix < 1.0

    # change atime and mtime
    p = PostProcessor

# Generated at 2022-06-22 09:12:29.667356
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import InfoExtractor
    from ..downloader import FileDownloader
    from tempfile import mkstemp
    from ..utils import DateRange
    from random import randint
    from time import time, sleep

    fd, temp_filename = mkstemp()
    os.close(fd)

# Generated at 2022-06-22 09:12:44.038624
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def __init__(self, name):
            self._name = name
        def run(self, info):
            print(u'TestPostProcessor %s called: %s' % (self._name, info['filepath']))
            info['testdata'] = self._name
            return [info['filepath']], info

    class FakeDownloader():
        def __init__(self):
            self.pp = TestPostProcessor(1)
            self.pp.set_downloader(self)
            self.pp2 = TestPostProcessor(2)
            self.pp2.set_downloader(self)

            self.add_post_processor(self.pp)
            self.add_post_processor(self.pp2)


# Generated at 2022-06-22 09:12:44.940199
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = object()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-22 09:12:47.479806
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    dl = YoutubeDL()
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Generated at 2022-06-22 09:12:48.792281
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError(1, 2, 3)

# Generated at 2022-06-22 09:13:00.939439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import io
    import tempfile
    import time
    import unittest
    import sys

    class MockDownloader():
        def __init__(self):
            self.warning_count = 0

        def report_warning(self, errnote):
            self.warning_count += 1

    class PostProcessorSubclass(PostProcessor):
        def __init__(self, downloader):
            super(PostProcessorSubclass, self).__init__(downloader)

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.downloader = MockDownloader()
            self.post = PostProcessorSubclass(self.downloader)

        def test_try_utime_normal(self):
            """Check if try_utime normal work"""
            tfd,

# Generated at 2022-06-22 09:13:03.292369
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None, 'Could not instantiate a PostProcessor'

# Generated at 2022-06-22 09:13:10.417344
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..utils import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    fd = FileDownloader(ydl, {})
    test_post_processor = PostProcessor(fd)
    assert test_post_processor._downloader == fd
    test_post_processor.set_downloader(None)
    assert test_post_processor._downloader is None

# Generated at 2022-06-22 09:13:13.162727
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader.common import FileDownloader
    x = PostProcessor()
    assert x._downloader == None
    x = PostProcessor(FileDownloader())
    assert x._downloader != None


# Generated at 2022-06-22 09:13:21.306096
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.common import InfoExtractor

    global_counter = []

    class DummyPP(PostProcessor):
        def run(self, info):
            global_counter.append(1)
            return [], info

    ie = InfoExtractor()
    ie.add_info_extractor(lambda url: {'id': 'test'}, ie_key='IE1')
    ie.add_post_processor(DummyPP())
    pp_res = ie._run_ie('IE1', 'test', 'Test Download')

    if len(global_counter) != 1:
        raise Exception('PostProcessor.run() method not called!')

# Generated at 2022-06-22 09:13:30.211372
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as e:
        assert str(e) == 'test'
        assert e.orig_exc is None

    try:
        raise IOError
    except IOError as exc:
        try:
            raise AudioConversionError('test', exc)
        except AudioConversionError as e:
            assert str(e) == 'test: I/O error'
            assert e.orig_exc is exc
        else:
            assert False, 'cannot raise AudioConversionError'
    else:
        assert False, 'cannot raise IOError'

# Generated at 2022-06-22 09:13:36.281703
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class PP(PostProcessor):
        def run(self, data):
            self.try_utime(None, 1234, 1234)
            return [[], data]
    pp = PP()
    pp.run(None)

# Generated at 2022-06-22 09:13:43.033921
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from .test_postprocessor import TestPostProcessor

    tp = TestPostProcessor()
    assert tp.downloader is None
    fd = FileDownloader(params={'outtmpl': "%(id)s"})
    tp.set_downloader(fd)
    assert tp.downloader == fd

# Generated at 2022-06-22 09:13:53.434766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    for ie in gen_extractors():
        if not ie.IE_NAME:
            continue


# Generated at 2022-06-22 09:13:57.396520
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError('message')
    assert str(exc) == 'message'
    assert repr(exc) == 'AudioConversionError("message",)'
    assert isinstance(exc, AudioConversionError)
    assert isinstance(exc, PostProcessingError)


# Generated at 2022-06-22 09:14:01.449004
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    message = 'message'
    try:
        raise AudioConversionError(message)
    except AudioConversionError as e:
        assert e.msg == message

# Generated at 2022-06-22 09:14:02.771928
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-22 09:14:07.639947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeDownloader
    downloader = FakeDownloader()
    downloader.params['nooverwrites'] = True
    pp = PostProcessor(downloader)
    pp.try_utime('./fake_file', 1506937565, 1506937565)
    assert downloader.tmpfilename == './fake_file'

# Generated at 2022-06-22 09:14:20.154628
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractor_classes
    from ..downloader.common import FileDownloader

    for ie_cls in gen_extractor_classes():
        info = {
            'url': 'http://foo.com/video123',
            'id': 'video123',
            'title': 'Video 123 - www.youtube.com',
            'ext': 'mp4',
            'upload_date': '20160101',
        }
        ie = ie_cls(FileDownloader({}))
        info = ie.extract(info['url'])
        assert info is not None
        assert 'formats' in info
        assert len(info['formats']) > 0
        f = info['formats'][0]
        assert 'url' in f
        assert f['url'] == info['url']

# Generated at 2022-06-22 09:14:25.093385
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Test that the constructor of PostProcessingError works as expected."""

    no_arg_err = AudioConversionError()
    assert str(no_arg_err) == 'None'
    assert no_arg_err.cause is None

    err_with_cause = AudioConversionError('error description', 'the cause')
    assert str(err_with_cause) == 'error description'
    assert err_with_cause.cause == 'the cause'

# Generated at 2022-06-22 09:14:28.366877
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    ytdl = PostProcessor()
    downloader = object()
    ytdl.set_downloader(downloader)
    assert ytdl._downloader is downloader


# Generated at 2022-06-22 09:14:44.526811
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("message", "output", {'format': 'mp3', 'preferredcodec': 'mp3'})
    except AudioConversionError as exc:
        assert str(exc) == "message; see --postprocessor-args '-f mp3 -codec:a mp3'"
    try:
        raise AudioConversionError("message", "output")
    except AudioConversionError as exc:
        assert str(exc) == "message"
    try:
        raise AudioConversionError("message")
    except AudioConversionError as exc:
        assert str(exc) == "message"


# Generated at 2022-06-22 09:14:48.678015
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    d = object()
    pp.set_downloader(d)
    assert pp._downloader is d

# Generated at 2022-06-22 09:14:50.561007
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None
    assert PostProcessor(downloader='foo')._downloader == 'foo'

# Generated at 2022-06-22 09:15:02.782535
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-22 09:15:09.705033
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def run(self, info):
            return [], info

    PP = TestPP(YoutubeDL({}))
    PP.set_downloader(YoutubeDL({}))
    assert PP._downloader is not None

# Generated at 2022-06-22 09:15:15.404342
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError().args[0] == 'Converting audio failed'
    assert AudioConversionError('foo').args[0] == 'foo'
    assert AudioConversionError('foo', 'bar').args[0] == 'foo'
    assert AudioConversionError('foo', 'bar').args[1:] == ('bar',)



# Generated at 2022-06-22 09:15:17.216551
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-22 09:15:28.669799
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from .compat import TemporaryDirectory
    from .downloader import FileDownloader

    with TemporaryDirectory(prefix='youtubedl_test_PostProcessor_utime_') as temp_path:
        filename = os.path.join(temp_path, 'test')

        open(filename, 'wb').close()

        # Test that utime is called correctly
        downloader = FileDownloader({
            'postprocessor_args': [
                '-f', 'mp4', '-k', '-i', '--',
                '--test_video_id=test_video',
            ],
        }, {'outtmpl': filename})


# Generated at 2022-06-22 09:15:34.046993
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            self.downloader = None

        def set_downloader(self, downloader):
            self.downloader = downloader

    test_post_processor = TestPostProcessor()
    test_post_processor.set_downloader('TEST')
    assert test_post_processor.downloader == 'TEST'

# Generated at 2022-06-22 09:15:35.498980
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('a','b','c','d','e','f','g')

# Generated at 2022-06-22 09:15:56.293134
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessor(PostProcessor):
        def __init__(self, t):
            self.t = t

        def run(self, info):
            return [(self.t, info)]

    pp0 = MockPostProcessor(0)
    pp1 = MockPostProcessor(1)
    pp2 = MockPostProcessor(2)
    pp0.append_pp(pp1)
    pp1.append_pp(pp2)
    info = {}
    res = pp0.run(info)
    assert res == [(0, info), (1, info), (2, info)]

# Generated at 2022-06-22 09:16:00.834608
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message')
    except AudioConversionError as err:
        assert str(err) == str('message')

# Generated at 2022-06-22 09:16:03.853589
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(123)
    assert pp._downloader == 123

# Generated at 2022-06-22 09:16:07.633374
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['postprocessor_args'] = ['key1=val1', 'key2=val2']
    pp = PostProcessor(ydl)
    pp.set_downloader(ydl)
    assert pp._downloader == ydl


# Generated at 2022-06-22 09:16:19.496407
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import datetime
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..utils import sanitize_open

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(FakePostProcessor, self).__init__(downloader)
            self._utime_errnote = 'utime errnote'
            self._utime_errnote_regex = '^%s$' % self._utime_errnote
            self._utime_path = None
            self._utime_atime = None
            self._utime_mtime = None

        def run(self, information):
            super(FakePostProcessor, self).run(information)

# Generated at 2022-06-22 09:16:26.407842
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test mesg', 'output_file', 'input_file', 'cmd')
    except AudioConversionError as err:
        assert err.output_file == 'output_file'
        assert err.input_file == 'input_file'
        assert err.cmd == 'cmd'
        assert str(err) == 'test mesg'

# Generated at 2022-06-22 09:16:28.823020
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass

# Generated at 2022-06-22 09:16:33.933726
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', 2, 'bar', 'baz')
    except AudioConversionError as ve:
        assert ve.cause == 'foo'
        assert ve.code == 2
        assert ve.original_line == 'bar'
        assert ve.extra_info == 'baz'



# Generated at 2022-06-22 09:16:35.471012
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor."""
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:16:43.517907
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.tests.test_common import make_test_downloader
    from .common import ForbidParallelDownloadsPP
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP

    def fd_downloader_factory():
        return make_test_downloader(params={'noparallel': True, 'xattr_set_filesize': True, 'logger': False},
                                    downloader_cls=ForbidParallelDownloadsPP,
                                    postprocessors=[XAttrMetadataPP, FFmpegPostProcessor])

    import tempfile
    import time
    tempdir = tempfile.mkdtemp(prefix='ytdl-test_PostProcessor-try_utime-')
    dl = fd_downloader_factory()

    #

# Generated at 2022-06-22 09:17:16.568719
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PP(PostProcessor):
        def run(self, info):
            info['a'] = 2
            return [], info

    pp = PP()
    info = dict(a=1)
    files, info = pp.run(info)
    assert info['a'] == 2

# Generated at 2022-06-22 09:17:17.110025
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:17:24.098512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Run some simple cases with the _try_utime() method.

    This method is wrapped in a test case so we can catch any
    exception that may be raised and fail in an obvious way.
    """

    def get_mtime(path):
        return os.stat(encodeFilename(path)).st_mtime

    import tempfile
    import shutil
    import time

    tmpdir = tempfile.mkdtemp(prefix='youtubedl-test_pp-')
    fname = 'test.file'
    path = os.path.join(tmpdir, fname)

# Generated at 2022-06-22 09:17:29.270832
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('message') as e:
        pass
    assert e.message == 'message'
    with AudioConversionError('message', 'stdout', 'stderr', 'cmd') as e:
        pass
    assert e.message == 'message'
    assert e.stdout == 'stdout'
    assert e.stderr == 'stderr'
    assert e.cmd == 'cmd'

# Generated at 2022-06-22 09:17:41.020751
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..downloader import FileDownloader

    file_info = { 'fulltitle': 'John Doe - Test Video',
                  'title': 'Test Video',
                  'ext': 'mp4',
                  'uploader': 'John Doe',
                  'duration': '10:41' }

    temp_file = tempfile.NamedTemporaryFile(suffix=file_info['ext'], delete=False)
    temp_file.close()
    file_info['filepath'] = temp_file.name

    dl = FileDownloader({})
    pp = PostProcessor(dl)
    pp.try_utime(temp_file.name, 0, 0)  # Should not fail
    os.unlink(temp_file.name)



# Generated at 2022-06-22 09:17:44.548576
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except PostProcessingError as err:
        assert str(err) == ''
    try:
        raise AudioConversionError('foo')
    except PostProcessingError as err:
        assert str(err) == 'foo'

# Generated at 2022-06-22 09:17:46.737742
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run({}) == ([], {})


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:17:50.115668
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    class DummyPostProcessor(PostProcessor):
        pass
    downloader = YoutubeDL()
    pp = DummyPostProcessor()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader



# Generated at 2022-06-22 09:17:50.894001
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    assert PostProcessor().run({}) == ([], {})

# Generated at 2022-06-22 09:17:54.982657
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    assert pp._downloader == None
    fd = FileDownloader()
    pp.set_downloader(fd)
    assert pp._downloader == fd

# Generated at 2022-06-22 09:19:10.002199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test try_utime method of class PostProcessor
    """
    import sys
    import pytest
    import tempfile
    import atexit
    import shutil
    import os

    from ..compat import PY2

    from ..utils import PostProcessor

    # Python 3 has no 'file' type
    if not PY2:
        class File(object):
            def __init__(self, path, mode):
                self.path = path
                self.mode = mode
                self.fp = open(path, mode)
            def close(self):
                self.fp.close()
    else:
        File = file

    # Create a temporary directory
    tempdir = tempfile.mkdtemp()
    # Remove the directory after tests
    atexit.register(shutil.rmtree, tempdir)



# Generated at 2022-06-22 09:19:20.783793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    import tempfile
    import shutil
    import subprocess
    import time

    import youtube_dl.postprocessor

    class DummyDownloader(object):
        def report_warning(self, message):
            pass

    class TestPostProcessor(youtube_dl.postprocessor.PostProcessor):
        def __init__(self, downloader):
            youtube_dl.postprocessor.PostProcessor.__init__(self, downloader)

    class TestPostProcessor_try_utime(unittest.TestCase):

        def setUp(self):
            self.dldir = tempfile.mkdtemp(prefix='youtubedl_test_utime_')
            self.downloader = DummyDownloader()
            self.pp = TestPostProcessor(self.downloader)


# Generated at 2022-06-22 09:19:25.612367
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import subprocess

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return info['filepath']

    d = DummyPostProcessor()
    f = {'filepath': 'test'}
    r = d.run(f)

    assert r == ['test'], 'DummyPostProcessor.run returned %s instead of ["test"]' % r

# Generated at 2022-06-22 09:19:28.876954
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    p1 = PostProcessor()
    assert p1._downloader == None, "p1._downloader is not None"
    d1 = Downloader()
    p1.set_downloader(d1)
    assert p1._downloader == d1, "p1._downloader != d1"

# Generated at 2022-06-22 09:19:32.577061
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("error", 2)
    except AudioConversionError as e:
        if not aiequal(e.args, ("error", 2)):
            raise AssertionError("AudioConversionError.__init__() failed")

# Generated at 2022-06-22 09:19:34.174542
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError as err:
        pass

# Generated at 2022-06-22 09:19:36.721755
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-22 09:19:46.698524
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import __main__
    import youtube_dl

    __main__.params = {}
    __main__.ys = youtube_dl.YoutubeDL(__main__.params)

    class NewPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    pp = NewPostProcessor()
    assert pp.__class__.__name__ == 'NewPostProcessor'
    assert pp._downloader is None

    pp.set_downloader(__main__.ys)

    assert pp.__class__.__name__ == 'NewPostProcessor'
    assert pp._downloader.__class__.__name__ == 'YoutubeDL'

# Generated at 2022-06-22 09:19:48.160679
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError()
    assert isinstance(error, PostProcessingError)

# Generated at 2022-06-22 09:19:57.005172
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    pp = PostProcessor(None)

    t = tempfile.NamedTemporaryFile()
    t.write(b'1234')
    t.flush()
    path = t.name

    now = time.time()
    atime = now - 1
    mtime = now - 2

    pp.try_utime(path, atime, mtime)

    f = open(path)
    assert f.read() == '1234'
    f.close()

    assert os.path.getatime(path) == atime
    assert os.path.getmtime(path) == mtime

    shutil.rmtree(path)

    # TODO: test with a path that doesn't exist