

# Generated at 2022-06-22 09:10:40.378291
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError(u'\nA\x03u\x03d\x03i\x03o\x03 \x03C\x03o\x03n\x03v\x03e\x03r\x03s\x03i\x03o\x03n\x03 \x03E\x03r\x03r\x03o\x03r\x03\n')
    assert error.msg == (
        'Audio Conversion Error')


# Generated at 2022-06-22 09:10:51.268702
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    # we cannot test on windows because os.utime cannot change timestamp of the file
    if os.name == 'nt':
        return

    filename = 'PostProcessor test file'
    p = PostProcessor(downloader=FileDownloader(params={}))

# Generated at 2022-06-22 09:11:01.105264
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor

    from .common import FileDownloader
    from .common import PostProcessor
    from .common import _download_testdata

    # Dummy file to get some data
    url = 'http://localhost/'
    testdata_filename = _download_testdata(url)

    # Dummy downloader
    ydl = FileDownloader(InfoExtractor())
    ydl._ies = [object()]

    # Dummy postprocessor
    pp = PostProcessor(ydl)
    pp._downloader = ydl

    # Test a successfull utime
    testfile = 'postprocessor_testfile.tmp'
    with open(testfile, 'w'):
        pass
    pp.try_utime(testfile, 0, 0)
    os.remove(testfile)

    #

# Generated at 2022-06-22 09:11:03.677432
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor.PostProcessor()
    assert pp

# Generated at 2022-06-22 09:11:08.056100
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():  # pylint:disable=invalid-name
    try:
        raise AudioConversionError
    except AudioConversionError as err:
        assert str(err) == 'Audio conversion failed'



# Generated at 2022-06-22 09:11:18.076630
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import pytest
    from tempfile import mkstemp
    from .postprocessor import PostProcessor
    from ..utils import encodeFilename

    pp = PostProcessor({})
    fd, path = mkstemp()
    os.close(fd)
    os.remove(path)

    try:
        pp.try_utime(path, 42, 42)
    except Exception as exc:
        assert isinstance(exc, PostProcessingError)
    else:
        raise AssertionError('Failed to raise PostProcessingError')

    with open(encodeFilename(path), 'w') as f:
        f.write('test!')

    stat_result = os.stat(path)  # Use the system decoding here for getting the real path
    atime = stat_result.st_atime

# Generated at 2022-06-22 09:11:21.392802
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    dl = YoutubeDL()
    pp.set_downloader(dl)
    assert(pp._downloader == dl)

# Generated at 2022-06-22 09:11:24.900040
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime('NoExistFile', (0, 0))
    except Exception as e:
        PostProcessor().try_utime('NoExistFile', 0, 0)
        try:
            os.utime('NoExistFile', (0, 0))
        except OSError as e:
            assert 'NoExistFile' in str(e)

# Generated at 2022-06-22 09:11:27.212356
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert 'msg' == AudioConversionError('msg', 'cmd').msg
    assert 'cmd' == AudioConversionError('msg', 'cmd').command


# Generated at 2022-06-22 09:11:37.669760
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import encodeFilename

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None, amkdir=False, test_file=''):
            super(TestPostProcessor, self).__init__(downloader)
            self._amkdir = amkdir
            self._test_file = test_file


# Generated at 2022-06-22 09:11:41.223007
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Unit test for constructor of class AudioConversionError"""
    AudioConversionError("test")


# Generated at 2022-06-22 09:11:53.878237
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Make sure that run() is doing what it should
    """
    from ytdl.compat import compat_etree_fromstring
    from ..InfoExtractor import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import sanitize_open

    videos = [
        {
            'title': 'test1',
            'id': 'test1',
            'url': 'http://www.test.com/test1.mp4',
            'ext': 'mp4'
        },
        {
            'title': 'test2',
            'id': 'test2',
            'url': 'http://www.test.com/test2.flv',
            'ext': 'flv'
        },
    ]

    ie = InfoExtractor()
    ie.add_info_ext

# Generated at 2022-06-22 09:12:00.801173
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """test set_downloader function of class PostProcessor"""
    from ..extractor.youtube import YoutubeIE
    from ..downloader.f4m import F4mDownloader
    ieObj = YoutubeIE()
    ppObj = PostProcessor()
    ppObj.set_downloader(F4mDownloader(ieObj, 'http://test_url'))
    assert ppObj._downloader == F4mDownloader(ieObj, 'http://test_url')

# Generated at 2022-06-22 09:12:03.099070
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Make a test
    pp = PostProcessor()
    pp.set_downloader('test')
    assert pp._downloader == 'test'


# Generated at 2022-06-22 09:12:07.244602
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:12:14.515336
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    class MockPP(PostProcessor):
        def run(self, information):
            return ([],[])
    dl = FileDownloader({})
    pp = MockPP()
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Unit tests for method try_utime of class PostProcessor

# Generated at 2022-06-22 09:12:22.412368
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor import (
        gen_extractor,
        LookupGenericIE,
    )
    from ..downloader.common import FileDownloader
    from ..utils import (
        compat_str,
        compat_urllib_parse,
    )


# Generated at 2022-06-22 09:12:26.557960
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    pp.set_downloader(None)
    assert pp._downloader == None

# Generated at 2022-06-22 09:12:32.138807
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def report_warning(self, msg):
            self.msg = msg
            raise Exception('Error')

    def test(self, path, atime, mtime):
        self.downloader = DummyDownloader()
        self.try_utime(path, atime, mtime)

    pp = PostProcessor(None)
    pp.try_utime = lambda *args: test(pp, *args)

    # test a real file
    path = '/etc/hosts'
    atime = os.stat(path).st_atime
    mtime = os.stat(path).st_mtime
    pp.try_utime(path, atime, mtime)

    # test an invalid path
    path = 'invalid/path'
    atime = mtime = 144689

# Generated at 2022-06-22 09:12:34.236054
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = type('MockDownloader', (object,), {'params': {}})
    pp = PostProcessor(downloader=downloader)
    assert pp._downloader == downloader

    # test if set_downloader() sets downloader correctly
    pp.set_downloader(None)
    assert pp._downloader is None
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-22 09:12:38.389908
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    audio_conversion_error = AudioConversionError(['test_message'])
    assert(audio_conversion_error.msg == ['test_message'])



# Generated at 2022-06-22 09:12:44.224414
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        # Trying to create a file with a name that is not suitable
        f = open(u'\xe9\xe9', 'w')
        f.close()
    except OSError:
        pass
    else:
        return False
    # Trying to utime a file that does not exist
    pp = PostProcessor(downloader=None)
    pp.try_utime(u'\xe9\xe9', None, None)
    return True

# Generated at 2022-06-22 09:12:53.136098
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PostProcessor1(PostProcessor):
        def run(self, info):
            info['title'] = 'Testing PostProcessor1'
            return [], info

    class PostProcessor2(PostProcessor):
        def run(self, info):
            info['title'] = 'Testing PostProcessor2'
            return [], info

    class PostProcessor3(PostProcessor):
        def run(self, info):
            info['title'] = 'Testing PostProcessor3'
            return [], info

    class Downloader:
        def __init__(self):
            self.pp_chain = [PostProcessor1(), PostProcessor2(), PostProcessor3()]

        def report_warning(self, errnote):
            pass

    i = {'id': 1, 'title': 'Test'}
    d = Download

# Generated at 2022-06-22 09:12:56.234443
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    assert pp._configuration_args() == []
    assert pp._configuration_args(default=['foo']) == ['foo']

# Generated at 2022-06-22 09:12:58.666767
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    downloader = Downloader()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-22 09:13:07.402105
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test for method run of class PostProcessor
    """
    class DummyPP(PostProcessor):
        def __init__(self, downloader=None):
            self.runCalled = False
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            self.runCalled = True
            return [], information

    dpp = DummyPP()
    assert not dpp.runCalled

    info = {'filepath': 'abc'}
    dpp.run(info)
    assert dpp.runCalled

# Generated at 2022-06-22 09:13:08.853628
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=W0612
    pp = PostProcessor()

# Generated at 2022-06-22 09:13:11.584432
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.YoutubeDL import YoutubeDL
    p = PostProcessor()
    d = YoutubeDL()
    p.set_downloader(d)
    assert p._downloader == d

# Generated at 2022-06-22 09:13:13.356314
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()

# Generated at 2022-06-22 09:13:18.608163
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader import Downloader
    D = Downloader()
    D.params = {}
    PP = PostProcessor(downloader=D)
    # Downloader is saved
    assert PP._downloader == D
    # Downloader is set
    D2 = Downloader()
    PP.set_downloader(D2)
    assert PP._downloader == D2


# Generated at 2022-06-22 09:13:27.322683
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPP(PostProcessor):
        pass
    #Importing mock
    try:
        import mock
    except ImportError:
        print('Please install mock in order to test PostProcessor')
        import sys
        sys.exit(0)

    pp = TestPP()
    mockdl = mock.MagicMock()
    pp._downloader = mockdl

    pp.try_utime("", 0, 0)
    pp.try_utime("", 0, 0, "")
    pp.try_utime("", 0, 0)
    mockdl.log.error.assert_called_once_with("Cannot update utime of file")
    mockdl.log.error.reset_mock()
    pp.try_utime("", 0, 0, "")
    mockdl.log.error.assert_called_once

# Generated at 2022-06-22 09:13:33.754455
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    assert pp.run({ 'filepath': 'blah.mp3', 'ext': 'mp3' }) == ([], { 'filepath': 'blah.mp3', 'ext': 'mp3' })
    assert pp.run({ 'filepath': 'blah.mp3', 'ext': 'mp3', 'format': 'best' }) == ([], { 'filepath': 'blah.mp3', 'ext': 'm4a', 'format': 'best' })

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:13:36.782645
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('audio', 'format', 'error message')
    except AudioConversionError as e:
        assert str(e) == 'audio: format: error message'
        assert e.video_id == 'audio'
        assert e.format == 'format'
        assert e.original_message == 'error message'
        assert e.cause is None



# Generated at 2022-06-22 09:13:38.661455
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:13:40.780217
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPostProcessor(PostProcessor):
        pass
    DummyPostProcessor()

# Generated at 2022-06-22 09:13:44.517164
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()


# "Abstract" test case for PostProcessor
# Subclasses must define _TEST_SUCCESS, _TEST_FAILURE, _TEST_FILE, _TEST_TEMPDIR, _TEST_ARGS and _TEST_OUT

# Generated at 2022-06-22 09:13:54.504781
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def __init__(self):
            self.warnings = []
        def report_warning(self, msg):
            self.warnings.append(msg)

    pp = PostProcessor(DummyDownloader())

    f = open('_test_file', 'w')
    f.write('a' * 1000000)
    f.close()

    # sanity check
    assert os.path.exists('_test_file')

    # try to update float atime and mtime
    pp.try_utime('_test_file', 1.5, 2.5)

    # check that I have exactly one warning
    assert len(pp._downloader.warnings) == 1

    # try to update atime and mtime

# Generated at 2022-06-22 09:13:59.217103
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    post_processor = PostProcessor()
    post_processor.set_downloader(downloader)
    assert post_processor._downloader == downloader, 'Set downloader method of PostProcessor is not working as expected'

# Generated at 2022-06-22 09:14:03.061580
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class _PostProcessor(PostProcessor):
        def run(self, information):
            print(information)
            return [], information
    _PostProcessor().run({})
    print('Tests finished')

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:14:06.821738
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    pp = PostProcessor(None)
    downloader = FileDownloader()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader



# Generated at 2022-06-22 09:14:23.428223
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil, stat, tempfile, time
    from ..compat import compat_open


# Generated at 2022-06-22 09:14:25.785232
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass



# Generated at 2022-06-22 09:14:34.987973
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # It only tests that the method does not raise exception
    # It does not test that the method returns the expected output
    from ..downloader import FakeYDL
    from ..extractor import gen_extractors

    ydl = FakeYDL()
    ydl.params['writethumbnail'] = True
    ydl.add_post_processor(FFmpegExtractAudioPP(ydl))
    ydl.add_info_extractor(gen_extractors()[0])

# Generated at 2022-06-22 09:14:39.929660
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    dl = YoutubeDL()
    pp = PostProcessor(dl)
    pp.set_downloader(None)
    assert pp._downloader is dl
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Generated at 2022-06-22 09:14:41.838117
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None
    assert PostProcessor(1)._downloader == 1

# Generated at 2022-06-22 09:14:42.302480
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:14:43.052828
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # TODO: Complete this
    return

# Generated at 2022-06-22 09:14:53.321375
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    try:
        import pytest
        raise Exception('PostProcessor unit tests are skipped due to the import issue of pytest')
    except ImportError:
        from nose.tools import assert_equals
        from ..downloader import YoutubeDL
        from ..compat import compat_str

        ydl = YoutubeDL()
        ydl.params['test'] = True  # Simulate that we are running from the test suite

        class DummyPP(PostProcessor):
            def run(self, info):
                return ['file_to_delete'], info

        ydl.add_post_processor(DummyPP())

        res = ydl.extract_info('http://example.com/video', download=True)

# Generated at 2022-06-22 09:14:56.706400
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message')
    except AudioConversionError:
        pass
    else:
        raise AssertionError('AudioConversionError constructor test failed!')

# Generated at 2022-06-22 09:14:57.344155
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:15:10.467221
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    # TODO: implement more tests


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:13.385754
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPP(PostProcessor):
        pass

    pp = TestPP()
    assert pp._downloader is None
    pp.set_downloader(object())
    assert pp._downloader



# Generated at 2022-06-22 09:15:15.441120
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(1)
    assert pp._downloader == 1

# Generated at 2022-06-22 09:15:16.850233
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('foo')
    return err.message == 'foo'

# Generated at 2022-06-22 09:15:18.620777
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p._downloader is None

# Generated at 2022-06-22 09:15:22.624531
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test instance creation and checks
    foo_pp = PostProcessor()  # Should create an instance of PostProcessor
    assert isinstance(foo_pp, PostProcessor)

# Generated at 2022-06-22 09:15:29.502551
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader is None

    class Downloader(object):
        def __init__(self):
            self.pp = None

        def add_post_processor(self, downloader):
            self.pp = downloader

    d = Downloader()
    pp.set_downloader(d)
    d.add_post_processor(pp)
    assert d._downloader is None

# Generated at 2022-06-22 09:15:34.156546
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    print(type(pp))
    print(type(pp._configuration_args()))
    pp2 = PostProcessor()
    pp2.set_downloader(pp)
    print(type(pp2._downloader))
    print(type(pp2._downloader._configuration_args()))

# Generated at 2022-06-22 09:15:43.801335
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class FauxPostProcessor(PostProcessor):
        def __init__(self):
            class FauxDownloader(object):
                def report_warning(self, errnote):
                    self.errnote = errnote
            self.downloader = FauxDownloader()

    pp = FauxPostProcessor()

    path = os.path.join(os.getcwd(), '__test_file_do_not_remove__')
    first = time.time()
    time.sleep(1)
    open(path, 'a').close()
    last = time.time()

    pp.try_utime(path, first, last)
    assert abs(os.path.getatime(path) - first) < 2
    assert abs(os.path.getmtime(path) - last) < 2

    pp.try_

# Generated at 2022-06-22 09:15:45.424514
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError as err:
        pass

# Generated at 2022-06-22 09:16:13.026406
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a PostProcessor
    pp = PostProcessor(None)

    # Test the run method
    assert pp.run({}) == ([], {})

# Generated at 2022-06-22 09:16:17.952994
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message', 'output file name', 'error text')
    except AudioConversionError as e:
        assert e.output_file == 'output file name'
        assert e.error_text == 'error text'
        assert e.message == 'message'



# Generated at 2022-06-22 09:16:27.770982
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    import time
    import tempfile
    import subprocess
    import shutil
    import os.path

    tempdir = tempfile.mkdtemp()
    testfile = os.path.join(tempdir, "postproc_test")
    f = open(testfile, "w")
    f.close()
    ctime = time.time() - 1000
    atime = time.time() - 500
    mtime = time.time() - 200
    pp.try_utime(testfile, atime, mtime)
    (a,m,c) = getmtime(testfile)
    if abs(a-atime) > 1:
        raise Exception("atime was not set correctly")

# Generated at 2022-06-22 09:16:33.585547
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .common import FakeYDL
    downloader = FakeYDL()
    pp = PostProcessor(downloader)
    pp2 = PostProcessor()
    pp.set_downloader(None)
    assert pp._downloader is None
    pp2.set_downloader(downloader)
    assert pp2._downloader is downloader

# Generated at 2022-06-22 09:16:36.429650
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    pp = PostProcessor(downloader=None)
    ydl = YoutubeDL(params={})
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-22 09:16:46.548203
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(downloader=None)
    # Test that the PostProcessor class has been initialized with _downloader=None
    assert pp._downloader is None, 'PostProcessor class has not been initialized with _downloader=None'
    # Test that self._downloader has been set to a YoutubeDL object
    pp.set_downloader(YoutubeDL())
    assert pp._downloader == YoutubeDL(), 'self._downloader has not been set to a YoutubeDL object'
    # Test that self._downloader is of type YoutubeDL
    assert isinstance(pp._downloader, YoutubeDL), 'self._downloader is not of type YoutubeDL'

# Generated at 2022-06-22 09:16:49.535434
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    pp = PostProcessor()
    dl = FileDownloader({})
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-22 09:16:50.130099
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pass

# Generated at 2022-06-22 09:17:02.520691
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FileDownloader
    import sys
    from .extractor.common import InfoExtractor
    from .compat import compat_tempfile

    class MockInfoDownloader(FileDownloader):
        def __init__(self):
            self.to_stdout = sys.stdout
            self.params = {
                'outtmpl': '%(id)s',
                'nooverwrites': False,
            }

    class MockInfoExtractor(InfoExtractor):
        IE_NAME = ie_name = 'mock'

        def __init__(self, downloader=None):
            super(MockInfoExtractor, self).__init__(downloader)
            self.filepath = compat_tempfile.mkstemp()[1]

        def _real_extract(self, url):
            return

# Generated at 2022-06-22 09:17:11.459762
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import unittest
    from tempfile import mkstemp
    from ..utils import tmp_file_name

    class FakeDownloader():

        def __init__(self):
            self.warnings = []

        def report_warning(self, text):
            self.warnings.append(text)

    class FakePP(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class TestPP(unittest.TestCase):
        def setUp(self):
            self.tmpfile = tmp_file_name('.tmp')
            f = open(self.tmpfile, 'w')
            f.close()
            self.pp = FakePP(FakeDownloader())


# Generated at 2022-06-22 09:18:03.053344
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # test PostProcessor constructor
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:18:05.612143
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    obj = PostProcessor()
    assert obj._downloader is None
    assert obj._configuration_args() == []


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:18:13.645326
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    pp = PostProcessor(FileDownloader({}))
    import tempfile
    from ..utils import make_temp_file

    # first create a temporary file
    fd = make_temp_file()
    fullfilename = fd.name
    fd.close()

    # get current time of temporary file
    st = os.stat(fullfilename)

    # dummy time in the future
    future_time = st.st_mtime + 100

    # run try_utime method of Post Processor
    pp.try_utime(fullfilename, future_time, future_time, 'Cannot update utime of file')

    # get future time of temporary file
    stn = os.stat(fullfilename)

    # verify if future time of temporary file was changed

# Generated at 2022-06-22 09:18:23.161389
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FakeYDL
    from .compat import urllib2

    def utime_fails(*args, **kwargs):
        raise urllib2.URLError('message')
    test_dl = FakeYDL()
    test_pp = PostProcessor(test_dl)
    test_dl.params['verbose'] = False
    test_pp.try_utime('test', 0, 0)
    test_dl.params['verbose'] = True
    test_pp.try_utime('test', 0, 0)
    test_pp.try_utime('test', 0, 0, 'Cannot update utime of file')
    test_pp.try_utime('test', 0, 0, errnote=None)
    test_pp.try_utime = utime_fails


# Generated at 2022-06-22 09:18:33.218991
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from .downloader import FileDownloader
    from .hooks import FileDownloaderHook
    from .utils import prepend_extension

    # Create temporary test directory.
    test_dir = os.path.join(os.getcwd(), 'test_dir')
    shutil.rmtree(test_dir, True)
    os.mkdir(test_dir)

    def hook(d):
        # Make sure we have a hook when we run the test.
        assert d._hooks is not None
        # Change the downloader's default temp dir to our test directory
        d.params['dl_path'] = test_dir
        d.params['temp_path'] = test_dir
        d.params['no_mtime'] = True

    # Create and initialize the downloader.
    dl = FileDownload

# Generated at 2022-06-22 09:18:44.166420
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class MockPostProcessor(object):
        def __init__(self, result_mock):
            self.result_mock = result_mock
        def run(self, information):
            return self.result_mock

    # Start with a simple mock
    information = {}
    result = MockPostProcessor((['a', 'b'], {'title': 'c'})).run(information)
    assert result == (['a', 'b'], {'title': 'c'})

    # Now continue to test the actual implementation

    class TruePostProcessor(PostProcessor):
        def run(self, information):
            return ([], information)

    # Test that the chain keeps going
    information = {}
    result = TruePostProcessor().run(information)
    assert result == ([], information)


# Generated at 2022-06-22 09:18:53.218526
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test method run in class PostProcessor.
    """
    class PP1(PostProcessor):
        def run(self, info):
            info['pp1_result'] = info.get('pp1_arg', -1) * 2
            return [], info

    class PP2(PostProcessor):
        def run(self, info):
            info['pp1_arg'] = info.get('pp1_arg', -1) * 2
            info['pp2_result'] = info.get('pp2_arg', -1) * 2
            return [], info

    class PP3(PostProcessor):
        def run(self, info):
            info['pp2_arg'] = info.get('pp2_arg', -1) * 2

# Generated at 2022-06-22 09:19:05.415455
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class SimpleFileInfo(dict):
        def __init__(self, title, ext, path):
            dict.__init__(self, title=title, ext=ext, path=path, thumbnail='dummy', format_id='dummy')

    class DummyPP1(PostProcessor):
        def run(self, info):
            info['downloaded_file'] = info['path'] + '.downloaded'
            os.rename(info['path'], info['downloaded_file'])
            return [], info

    class DummyPP2(PostProcessor):
        def run(self, info):
            os.remove(info['downloaded_file'])
            return [], info

    def test_pp(pp1cls, pp2cls):
        pp1 = pp1cls(None)
        pp2 = pp

# Generated at 2022-06-22 09:19:08.761272
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    (del_files, info) = pp.run({'id': 'test', 'filepath': 'test.mp4'})
    assert info['id'] == 'test'
    assert del_files == []



# Generated at 2022-06-22 09:19:09.944096
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('error message')
    AudioConversionError