

# Generated at 2022-06-22 09:10:41.619006
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # test that try_utime does not crash and reports warning on non existing file
    pp.try_utime('non-existing-file', 0, 0)
    # test that try_utime does not crash and reports warning on read-only file
    file_path = 'file.foo'
    open(file_path, 'w').close()
    os.chmod(file_path, 0o444)
    pp.try_utime(file_path, 0, 0)
    os.remove(file_path)

# Generated at 2022-06-22 09:10:43.739720
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('Error Message', 'FilePath')
    assert error.msg == 'Error Message'
    assert error.filename == 'FilePath'

# Generated at 2022-06-22 09:10:52.512401
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    post_processor = PostProcessor()
    test_file = 'files/try_utime_test.txt'
    import time
    current_time = time.time()
    with open(encodeFilename(test_file), 'wb') as f:
        f.write(b'Hello World!')
    post_processor.try_utime(test_file, current_time - 100, current_time - 100)
    statinfo = os.stat(encodeFilename(test_file))
    assert statinfo.st_atime == current_time - 100
    assert statinfo.st_mtime == current_time - 100



# Generated at 2022-06-22 09:10:57.251815
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import FFmpegMetadataPP
    ydl = FileDownloader({})
    ffmd = FFmpegMetadataPP(ydl)
    assert ffmd._downloader == ydl
    ffmd.set_downloader(None)
    assert ffmd._downloader is None

# Generated at 2022-06-22 09:11:02.058965
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat

    class MockDownloader():
        def report_warning(self, msg):
            self.warning = "%s" % (msg)

    mock_downloader = MockDownloader()
    p = PostProcessor(mock_downloader)
    os.environ['LANG'] = 'en_US.UTF-8'
    test_file = os.pipe()
    os.fchmod(test_file[1], stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH | stat.S_IWOTH)
    p.try_utime(os.path.realpath(__file__), 0, 0, errnote='Test errnote')

# Generated at 2022-06-22 09:11:14.016585
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import youtube_dl
    import errno
    import tempfile
    import os

    test_filepath = tempfile.mktemp()
    test_file = open(test_filepath, 'wb')
    test_file.write(b'This file is used in youtube_dl unittest')
    test_file.close()

    # change only mtime
    t_mtime = int(os.path.getmtime(test_filepath) + 10)
    t_atime = os.path.getatime(test_filepath)

    pp = PostProcessor(None)
    pp.try_utime(test_filepath, t_atime, t_mtime)

    assert (int(os.path.getmtime(test_filepath)) == t_mtime)

# Generated at 2022-06-22 09:11:15.237256
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    test_error = AudioConversionError()
    assert test_error is not None



# Generated at 2022-06-22 09:11:27.644363
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL, FileDownloader
    import os
    import time

    def pp_test(info):
        filename = info['filepath']
        outf = os.path.join(os.getcwd(), 'test.txt')
        print('Test postprocessor creating', outf)
        with open(encodeFilename(outf), 'w') as out:
            out.write(filename)
        return [outf], info

    downloader = FileDownloader(YoutubeDL())
    downloader.params['outtmpl'] = '%(id)s.%(ext)s'
    downloader.add_info_extractor(MyIE(downloader))
    downloader.add_post_processor(pp_test)


# Generated at 2022-06-22 09:11:39.105491
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    sample_info = {'filepath': encodeFilename(__file__),}

    class FakeDownloader(object):
        def report_warning(self, msg):
            pass

    # Make sure that the file exists to prevent false-positive tests
    assert os.path.exists(sample_info['filepath'])

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            # Modify a file time to trigger tests
            self.try_utime(info['filepath'], atime=100, mtime=100, errnote='Test error')
            return [], info

    def call_unit_test():
        # Create a new instance of PostProcessor
        post_processor = FakePostProcessor(downloader=FakeDownloader())

        # Run fake post processor to let it modify the

# Generated at 2022-06-22 09:11:46.709560
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, information):
            return ['test',information]

    info = { 'somefield':'somevalue', 'someotherfield':'someothervalue' }
    pp = TestPP()
    tb1, tb2 = pp.run(info)
    assert tb1 == ['test']
    assert tb2 == info
    assert pp._downloader == None

# Unit tests for method try_utime of class PostProcessor

# Generated at 2022-06-22 09:11:53.702483
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(99, 'msg')
    except AudioConversionError as e:
        assert e.code == 99
        assert e.msg == 'msg'
        assert e.original_message == 'Audio conversion failed: msg'
    else:
        assert False



# Generated at 2022-06-22 09:12:04.349913
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyDownloader(object):
        def to_screen(self, message):
            print(message)
        def to_stderr(self, message):
            print(message, file=sys.stderr)
        def temp_name(self, filename):
            return 'TEMP_' + filename
        def report_warning(self, message):
            self.to_screen(message)
        def report_error(self, message):
            self.to_stderr(message)

    class DummyPP1(PostProcessor):
        def run(self, information):
            information['title'] = 'DUMMY1'
            return [], information

    class DummyPP2(PostProcessor):
        def run(self, information):
            information['title'] = 'DUMMY2'
            return [], information



# Generated at 2022-06-22 09:12:15.622552
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from tempfile import NamedTemporaryFile
    from collections import namedtuple
    from copy import copy

    Downloader = namedtuple('YoutubeDL', ['report_warning'])
    downloader = Downloader(lambda x: None)
    p = PostProcessor(downloader)

    tmpfile = NamedTemporaryFile(delete=False)
    tmpfile.close()


# Generated at 2022-06-22 09:12:22.065249
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

    from .tests.test_utils import make_temp_file

    with make_temp_file() as temp_file:
        downloader = None
        postprocessor = FakePostProcessor(downloader)
        # Check if try_utime() doesn't throw an exception
        # when it is called with valid values
        path = temp_file
        atime = int(time.time()) - 100
        mtime = int(time.time()) - 100
        postprocessor.try_utime(path, atime, mtime)

# Generated at 2022-06-22 09:12:31.054601
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # Test empty constructor
    try:
        raise AudioConversionError()
    except AudioConversionError as err_AudioConversionError:
        assert not err_AudioConversionError.wrapped_exception
    # Test constructor with wrapped_exception
    try:
        raise ValueError('wrapped_exception')
    except ValueError as wrapped_exception:
        try:
            raise AudioConversionError(wrapped_exception)
        except AudioConversionError as err_AudioConversionError:
            assert err_AudioConversionError.wrapped_exception == wrapped_exception


# Generated at 2022-06-22 09:12:42.216715
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    # Create test file for test_PostProcessor_try_utime
    file_name = "test_PostProcessor_try_utime.txt"
    test_file = open(file_name,'wb')
    test_file.write(b'Hello, this is test file')
    test_file.close()

    # Get the atime and mtime of test file
    stat = os.stat(file_name)
    atime = stat.st_atime
    mtime = stat.st_mtime
    # Initialize PostProcessor
    pp = PostProcessor(None)
    # Change the atime and mtime of test file
    pp.try_utime(file_name,atime + 60,mtime + 60)
    # Get the atime and mtime of test file after method try_utime

# Generated at 2022-06-22 09:12:50.930046
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL, FakeYDL

# Generated at 2022-06-22 09:13:03.005846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FileDownloader
    fd = FileDownloader(params={})

    class Test_PostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(Test_PostProcessor, self).__init__(downloader)

    test_pp = Test_PostProcessor(fd)

    import tempfile
    from time import sleep
    import datetime
    path = tempfile.mkstemp()[1]
    ts = datetime.datetime.now()
    test_pp.try_utime(path, ts.timestamp(), ts.timestamp())
    sleep(0.001)  # Make sure the file modification times are different
    test_pp.try_utime(path, ts.timestamp(), ts.timestamp(), 'test try_utime')
    test_pp.try_

# Generated at 2022-06-22 09:13:10.561660
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    class MockDownloader:
        def report_warning(self, error):
            print(error)
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader, path):
            PostProcessor.__init__(self, downloader)
            self.path = path
        def run(self, information):
            self.try_utime(self.path, 0, 0)
    mp = MockPostProcessor(MockDownloader(), __file__)
    mp.run(information={})

# Generated at 2022-06-22 09:13:15.022217
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())
    import time
    pp.try_utime(__file__, time.time(), time.time() + 14097 - 14096)
    # If we can set the atime and mtime to the same value, we assume
    # utime works correctly.

# Generated at 2022-06-22 09:13:19.511443
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor().run({}) == ([],{})

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:13:24.333332
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            print('running')
            return [info['filepath']], info

    print('Testing PostProcessor objects')
    tpp = TestPP()
    tpp.run({'filepath': 'x', 'playlist': 'heh'})

# Generated at 2022-06-22 09:13:25.068877
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-22 09:13:34.632896
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    import shutil
    import sys
    import os.path
    from ydl.downloader.common import FileDownloader
    from ydl.postprocessor import PostProcessor
    from ydl.compat import compat_http_client
    from ydl.test.test_downloader import MockServerThread, MockServerRequestHandler
    from ydl.test.fake_youtube import (
        FakeYoutubeDL, FakeInfoExtractor, MockYTDLServer,
        MockFileDownloader, Link,
        download,
    )
    from ydl.utils import make_HTTPServer, encodeFilename

    with MockYTDLServer() as mockserver:
        download = lambda path: download(Link(path))

    tempdir = tempfile.mkdtemp()

    # Create post-processor class

# Generated at 2022-06-22 09:13:45.855630
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeYDL
    from .extractor import get_info_extractor

    class FakePP(PostProcessor):
        def run(self, info_dict):
            self.try_utime('./test_file.mp4', 643, 667, 'Wrong time')
            return [], info_dict

    ydl = FakeYDL()
    ie = get_info_extractor('YoutubeIE')
    ie._downloader = ydl
    info_dict = {
        'format': '22',
        'id': '1',
        'upload_date': '20130810',
        'ext': 'mp4',
        'uploader': 'TEST'
    }
    pp = FakePP(ydl)
    pp.run(info_dict)

# Generated at 2022-06-22 09:13:54.963133
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..downloader.external import ExternalFD
    downloader = FileDownloader({})
    downloader.add_info_extractor(gen_extractors()[0])
    external_pp = ExternalFD({})
    external_pp.set_downloader(downloader)
    assert external_pp._downloader == downloader
    ext_pp = external_pp.info_extractors[0].pp
    assert ext_pp._downloader == downloader

# Generated at 2022-06-22 09:14:00.980139
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return information['filepath']

    pp = TestPostProcessor()
    info = {
        'id': 'id',
        'title': 'title',
        'filepath': 'filepath',
    }
    assert pp.run(info) == 'filepath'

# Generated at 2022-06-22 09:14:10.499072
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os, sys
    sys.path.append("../youtube_dl/")
    from YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'outtmpl':'%(id)s%(ext)s'})

    pp = PostProcessor(downloader=ydl)

    f = open("test_file", "w")
    try:
        f.write("That's all folks!")
    finally:
        f.close()

    import time
    time.sleep(1)
    pp.try_utime("test_file", None, None)

    stat = os.stat("test_file")
    mtime_new = stat.st_mtime

    time.sleep(1)
    import shutil
    shutil.move("test_file", "test_file_backup")

    pp.try_ut

# Generated at 2022-06-22 09:14:21.623177
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_struct_time
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    original_tie = InfoExtractor.TIE_VIDEO
    InfoExtractor.TIE_VIDEO = 1

# Generated at 2022-06-22 09:14:26.932780
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(
            'test', 2,
            'The test message',
            ['ffmpeg', '-v', 'fatal'])
    except AudioConversionError as e:
        assert str(e) == 'ERROR: test: The test message'
        assert e.original_message == 'ERROR: test: The test message'
        assert e.exit_code == 2
        assert e.command == 'ffmpeg -v fatal'
        assert e.stdout == ''
        assert e.stderr == ''



# Generated at 2022-06-22 09:14:33.411619
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    post_processor = PostProcessor()
    information = {"filepath": "test.mp3", "ext": "mp3", "title": "Test"}
    filepath = post_processor.run(information)[1]["filepath"]
    print("filepath: " + filepath)
    assert filepath == "test.mp3"

# Generated at 2022-06-22 09:14:42.401103
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class DummyPostProcessor(PostProcessor):
        _downloader = None
        def __init__(self, downloader):
            super(DummyPostProcessor, self).__init__(downloader)
            self.__class__._downloader = downloader

    class DummyDownloader(object):
        def __init__(self):
            # As in the YoutubeDL class:
            self.params = {
                'verbose': True,
                'dump_intermediate_pages': True,
            }

    dl = DummyDownloader()
    pp = DummyPostProcessor(dl)
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Generated at 2022-06-22 09:14:48.872766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor({})
    assert pp.try_utime("", 0, 0) == None
    assert pp.try_utime("", 0, 0, errnote="") == None

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-22 09:14:54.181994
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=no-member
    pp = PostProcessor()
    assert pp is not None, 'It should create a pp, instead of returning None'


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:03.999575
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys

    # Simple test of run() method
    class MockPostProcessor1(PostProcessor):
        def run(self, info):
            return ['a'], info

    class MockPostProcessor2(PostProcessor):
        def run(self, info):
            return ['b'], info

    class MockPostProcessor3(PostProcessor):
        def run(self, info):
            return ['c'], info

    class MockInfo:
        def __init__(self, filepath, title):
            self.filepath = filepath
            self.title = title

        def __str__(self):
            return '<MockInfo: %s (%s)>' % (self.title, self.filepath)


# Generated at 2022-06-22 09:15:12.726737
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader import Downloader
    from ..compat import compat_urlparse

    dl = Downloader()
    bp = PostProcessor(dl)

    assert bp.__class__.__name__ == 'PostProcessor'
    assert bp._downloader == dl
    assert dl == bp._downloader

    dl = Downloader()
    bp = PostProcessor()
    bp.set_downloader(dl)

    assert bp.__class__.__name__ == 'PostProcessor'
    assert bp._downloader == dl
    assert dl == bp._downloader

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:15.153172
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = DummyDownloader()
    post_processor = PostProcessor(downloader)
    assert post_processor._downloader is downloader


# Generated at 2022-06-22 09:15:28.327323
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime('./test_try_utime', (1, 1))
    except OSError:
        pass
    except IOError:
        pass
    f = open('./test_try_utime', 'w')
    f.close()
    # First test case
    atime = os.path.getatime('./test_try_utime')
    mtime = os.path.getmtime('./test_try_utime')
    PostProcessor().try_utime('./test_try_utime', 100, 100)
    assert os.path.getatime('./test_try_utime') == atime
    assert os.path.getmtime('./test_try_utime') == mtime
    # Second test case
    os.remove

# Generated at 2022-06-22 09:15:32.959603
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    class PostProcessor(object):
        def test_method(self, path, info):
            raise AudioConversionError(path, 'unit test error message')

    postprocessor = PostProcessor()
    info = {'title': 'dummy', 'extractor': 'playlist', 'format': 'dummy', 'uploader_id': 'dummy', 'extractor_key': 'dummy', 'format_id': 'dummy'}
    try:
        postprocessor.test_method('dummy', info)
    except AudioConversionError as e:
        assert e.info == info
        assert str(e) == 'dummy: unit test error message'

# Generated at 2022-06-22 09:15:36.364893
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    vals = ['error1', 'error2']
    err = AudioConversionError(vals[0], vals[1])
    assert err.converter_name == 'error1'
    assert err.original_line == 'error2'

# Generated at 2022-06-22 09:15:47.258307
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [info['filepath']], info

    pp = TestPP()
    info = {'filepath': 'file.mp4', 'ext': 'mp4'}
    deleted, info = pp.run(info)
    assert deleted[0] == 'file.mp4'

# Generated at 2022-06-22 09:15:59.044013
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class _FakeDownloader(object):
        def __init__(self, retcode):
            self.retcode = retcode

        def to_stdout(self, message):
            pass

        def to_stderr(self, message):
            pass

        def report_warning(self, message):
            pass

        def report_error(self, message):
            pass

        @property
        def params(self):
            return {
                'outtmpl': 'test'
            }

    class _FakePostProcessor(PostProcessor):
        def run(self, info):
            if self._downloader.retcode == 0:
                info['abridged'] = True
            else:
                info['abridged'] = False
            return [], info

    downloader = _FakeDownloader(0)
    proc = _

# Generated at 2022-06-22 09:16:05.243751
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            return ([], information)

    from . import YoutubeDL

    d = YoutubeDL()
    pp = DummyPostProcessor()
    pp.set_downloader(d)
    d.add_post_processor(pp)

    assert pp._downloader is d

# Generated at 2022-06-22 09:16:11.815822
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        def __init__(self, downloader=None, outcome=None):
            PostProcessor.__init__(self, downloader)
            self.outcome = outcome

        def run(self, info):
            return self.outcome

    assert MockPP().run({'a': 'b'}) == ({}, {'a': 'b'})
    assert MockPP(outcome=([], {'a': 'c'})).run({'a': 'b'}) == ([], {'a': 'c'})
    assert MockPP(outcome=(['abc'], {'a': 'd'})).run({'a': 'b'}) == (['abc'], {'a': 'd'})

# Generated at 2022-06-22 09:16:13.712156
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-22 09:16:24.495612
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..extractor.common import InfoExtractor

    ie = InfoExtractor()
    ie.ie_key = 'YouTube'
    ie.ie_bands = YoutubeIE.ie_bands

    dl = Downloader()
    dl.add_info_extractor(ie)

    p1 = PostProcessor(dl)

    # if the downloader is already set, it shouldn't change
    p1.set_downloader(dl)
    assert p1._downloader is dl

    # if the downloader wasn't set before, it should be set
    p2 = PostProcessor()
    dl2 = Downloader()
    p2.set_downloader(dl2)
    assert p2._downloader is dl2


# Test for method _

# Generated at 2022-06-22 09:16:26.954040
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Test empty list
    assert PostProcessor().run({'filepath': '/tmp/test.mp4'}) == ([], {'filepath': '/tmp/test.mp4'})

# Generated at 2022-06-22 09:16:35.296566
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..compat import compat_mock

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
            self.utime_called = 0

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.utime_called += 1
            self.utime_called_with = [path, atime, mtime, errnote]

    ydl = Downloader({})
    pp = TestPostProcessor(ydl)

    with compat_mock.patch('os.utime') as utime:
        utime.side_effect = OSError()

# Generated at 2022-06-22 09:16:40.605677
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockDownloader:
        pass
    class MockPostProcessor(PostProcessor):
        def run(self, info):
            self.called = True
            self.info = info
            return info
    info = {}

    dl = MockDownloader()
    pp = MockPostProcessor(dl)
    pp.set_downloader(dl)
    new_info = pp.run(info)

    assert new_info is info
    assert pp.called
    assert pp.info is info

# Generated at 2022-06-22 09:16:52.860808
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    import filecmp

    # We need to use a NamedTemporaryFile since we will be deleting
    # it and then creating another file with the same name to check
    # that the run() method of the postprocessor works correctly
    with tempfile.NamedTemporaryFile() as original_outtmpl:
        with tempfile.NamedTemporaryFile() as downloaded_file:
            original_outtmpl.write('foo')
            original_outtmpl.flush()
            downloaded_file.write('bar')
            downloaded_file.flush()

            class TestPP(PostProcessor):
                def run(self, information):
                    return [(original_outtmpl.name, downloaded_file.name)], information

        # Test normal file
        pp = TestPP()

# Generated at 2022-06-22 09:17:07.390033
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass

# Generated at 2022-06-22 09:17:16.981732
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from . import YoutubeDL
    from .compat import compat_urllib_error

    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            if not isinstance(information, dict):
                return False, information
            return True, information

    p = DummyPostProcessor()
    d = YoutubeDL()

    assert(p.run(None) == (True, None))
    assert(p.run('test') == (True, 'test'))
    assert(p.run({'a': 'test'}) == (True, {'a': 'test'}))

    # Test try_utime:
    fname = 'test_PostProcessor_try_utime.file'
    f = open(fname, 'wb')
    f.close()

# Generated at 2022-06-22 09:17:19.456896
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(123, 'Test', 'Test output')
    assert err.exit_code == 123
    assert err.reason == 'Test'
    assert str(err) == 'Test output'



# Generated at 2022-06-22 09:17:27.726752
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    return  # test no longer relevant because of the refactoring
    # The success case
    class TestPP1(PostProcessor):
        def run(self, info):
            return ['a', 'b', 'c'], info
    assert TestPP1().run({}) == (['a', 'b', 'c'], {}) # success
    assert TestPP1().run({'filepath': 'f'}) == (['a', 'b', 'c'], {'filepath': 'f'}) # success

    # The fail case
    class TestPP2(PostProcessor):
        def run(self, info):
            return None, info
    assert TestPP2().run({}) == ([], {}) # success
    assert TestPP2().run({'filepath': 'f'}) == ([], {'filepath': 'f'}) #

# Generated at 2022-06-22 09:17:34.831427
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-22 09:17:42.505197
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Unit test for method set_downloader of class PostProcessor."""
    class Mock(PostProcessor):
        def run(self, information):
            """Unit test for method set_downloader of class PostProcessor."""
            self._downloader = 'abc123'
            return ([] , information)

    # Declare the instance
    mp_obj = Mock()

    # Check the return of the run method
    assert mp_obj.run({}) == ([], {})

    # Check the return of the set_downloader method
    assert mp_obj._downloader == 'abc123'

# Generated at 2022-06-22 09:17:43.025165
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-22 09:17:44.513403
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor

# Generated at 2022-06-22 09:17:48.755532
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    pp = PostProcessor(ydl)
    assert pp._downloader is ydl
    pp1 = PostProcessor(ydl)
    ydl.add_post_processor(pp1)
    assert pp1._downloader is ydl

# Generated at 2022-06-22 09:17:59.021654
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from .common import FakeYDL
    from .utils import make_fake_info

    def tst(path, atime, mtime, errnote):
        ydl = FakeYDL()
        dl = Downloader(ydl)

        pp = PostProcessor(dl)
        pp.try_utime(path, atime, mtime, errnote)

    test_cases = [
        ('path', 0, 0, 'errnote'),
        ('path', 1, 1, 'errnote'),
        ('path', None, None, 'errnote'),
    ]

    for path, atime, mtime, errnote in test_cases:
        yield tst, path, atime, mtime, errnote

# Generated at 2022-06-22 09:18:37.112793
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import io
    import shutil
    import sys
    import tempfile
    import unittest

    class TestPP(PostProcessor):
        def run(self, information):
            information['title'] = 'test_title'
            return ['tmp.txt'], information

    tmpdir = tempfile.mkdtemp()
    original_stderr = sys.stderr
    original_stdout = sys.stdout

# Generated at 2022-06-22 09:18:41.545310
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # Arrange
    from ..__main__ import YoutubeDL
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    exception = AudioConversionError('msg', ydl)
    # Assert
    assert exception.msg == 'msg'
    assert exception.ydl is ydl

# Generated at 2022-06-22 09:18:49.788555
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class FakeDownloader:

        def __init__(self):
            self.warnings = 0

        def report_warning(self, message):
            self.warnings += 1

    test_file = 'test_utime'
    open(encodeFilename(test_file), 'w').close()
    p = PostProcessor(downloader=FakeDownloader())
    p.try_utime(test_file, 0, 0)
    assert p._downloader.warnings == 0
    os.remove(encodeFilename(test_file))

# Generated at 2022-06-22 09:18:52.187069
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor
    assert pp._downloader is None

# Generated at 2022-06-22 09:18:59.629913
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Tests for PostProcessor."""
    # Test with a fake downloader
    d = type('FakeDownloader', (object,), {
        'to_screen': lambda *args, **kargs: None,
        'report_error': lambda *args, **kargs: None,
        'tmpfilename': lambda *args, **kargs: 'tmpfilename',
        'params': {},
    })()
    pp = PostProcessor(d)
    assert pp.downloa

# Generated at 2022-06-22 09:19:11.378429
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class Run_adding_foo_PostProcessor(PostProcessor):
        def run(self, information):

            # This line is only for checking that the filepath is correctly passed
            assert 'filepath' in information

            information['foo'] = 'bar'

            return [], information

    class Run_removing_foo_PostProcessor(PostProcessor):
        def run(self, information):

            assert 'foo' in information

            del information['foo']

            return [], information

    class Run_raising_PostProcessor(PostProcessor):
        def run(self, information):
            raise PostProcessingError('error')

    downloader = object

    infos = {}
    infos['filepath'] = '/tmp/file'

    pp1 = Run_adding_foo_PostProcessor(downloader)
    pp2 = Run_

# Generated at 2022-06-22 09:19:15.215782
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test method run of class PostProcessor."""
    x = PostProcessor()
    assert(x.run({'x': 'y'}) == ([], {'x': 'y'}))


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-22 09:19:15.807953
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:19:17.957514
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-22 09:19:20.701354
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader()

    pp = PostProcessor(downloader=None)
    assert pp._downloader is None

    pp.set_downloader(downloader)
    assert pp._downloader == downloader