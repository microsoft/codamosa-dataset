

# Generated at 2022-06-22 09:10:41.001461
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    import sys
    try:
        raise AudioConversionError('foo')
    except AudioConversionError:
        exc = sys.exc_info()[1]
        assert str(exc) == 'foo', 'invalid exception message: ' + str(exc)
        assert exc.caused_by_faulty_media, 'caused_by_faulty_media should be True'
        assert not exc.caused_by_faulty_stream, 'caused_by_faulty_stream should be False'



# Generated at 2022-06-22 09:10:42.960439
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p.__class__.__name__ == 'PostProcessor'

# Generated at 2022-06-22 09:10:45.311681
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('msg', 'out', 'err')
    a.msg == 'msg'
    a.output == 'out'
    a.error == 'err'

# Generated at 2022-06-22 09:10:55.570942
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    from .postprocessor import FFmpegExtractAudioPP
    from .downloader import YoutubeDL
    from .extractor import gen_extractors

    # Set up a MockYoutubeDL object
    params = {
        'outtmpl': '%(id)s',
        'format': 'best[ext=mp4]/best',
        'postprocessor_args': '-ext mp3',
        'nooverwrites': True,
        'noplaylist': True,
    }
    ydl = YoutubeDL(params)
    ydl.add_info_extractor(gen_extractors(ydl)[0])
    ydl.params['extractors'] = gen_extractors(ydl)
    ydl.add_post_processor(FFmpegExtractAudioPP(ydl))



# Generated at 2022-06-22 09:10:58.417303
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', 'bar')
    except AudioConversionError as err:
        assert 'foo' in str(err)
        assert 'bar' in str(err)


# Generated at 2022-06-22 09:11:00.862976
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    test_PostProcessor = PostProcessor()
    assert test_PostProcessor is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:11:07.675394
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class Test_PostProcessor(PostProcessor):
        def run(self, information):
            return [], {'key1': information['key1']+1}

    info = {'key1': 0}
    post_processor = Test_PostProcessor()
    info = post_processor.run(info)[1]
    assert info['key1'] == 1, 'PostProcessor failed to run'

# Generated at 2022-06-22 09:11:10.063722
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test message')
    assert err.msg == 'test message'
    assert str(err) == 'test message'

# Generated at 2022-06-22 09:11:15.229964
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint:disable=missing-docstring
    import io
    from ..compat import str

    class DummyPP(PostProcessor):
        def run(self, info):
            return [], info

    ydl = DummyYDL()
    pp = DummyPP(ydl)
    assert pp.get_downloader() == ydl



# Generated at 2022-06-22 09:11:27.656135
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import common
    from ..downloader.common import FakeYDL
    from ..downloader.FileDownloader import FileDownloader
    from .embedthumbnail import EmbedThumbnailPP
    import unittest.mock

    def execute(method, exc):
        pp = EmbedThumbnailPP(ydl=FakeYDL())
        pp.report_warning = unittest.mock.Mock()
        method = getattr(pp, method)
        with unittest.mock.patch('os.utime') as utime_mock:
            utime_mock.side_effect = exc
            method(path='/path/to/file', atime=1, mtime=2)
        pp.report_warning.assert_called_with('Cannot update utime of file')


# Generated at 2022-06-22 09:11:35.880737
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import tempfile
    import time

    p = PostProcessor(None)
    # Create temporary file
    (_, filename) = tempfile.mkstemp(prefix='yt-dl-postprocessor-test')
    # Save its modification time
    mtime = int(os.path.getmtime(encodeFilename(filename)))
    # Remove file
    os.remove(encodeFilename(filename))
    # Try to update its modification time
    p.try_utime(filename, 0, mtime)
    # Try again with a different modification time
    p.try_utime(filename, 0, mtime + 1)
    # Check if file has been created
    assert os.path.exists(encodeFilename(filename))
    # Check if modification time has been updated

# Generated at 2022-06-22 09:11:37.743479
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import _common_post_process
    _common_post_process.test_PostProcessor_try_utime()

# Generated at 2022-06-22 09:11:40.811582
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    print('Trying to initialize PostProcessor...')
    try:
        PostProcessor()
    except Exception as e:
        print('Error while initializing PostProcessor: ' + str(e))
        return False
    else:
        return True

# Utilities


# Generated at 2022-06-22 09:11:51.632336
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class test_downloader():
        """Fake downloader class to be used in tests."""
        def __init__(self):
            self.outtmpl = None

    class test_postprocessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            assert self._downloader.outtmpl == 'test_outtmpl', 'Downloader outtmpl was not correctly set.'
            return [], information

    dl = test_downloader()
    pp = test_postprocessor(dl)
    dl.outtmpl = 'test_outtmpl'

    pp.run({})

# Generated at 2022-06-22 09:12:03.183353
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.youtube import YoutubeIE
    from ..downloader.common import FakeInfoExtractor
    from ..downloader.f4m import F4mFD
    from ..utils import _set_downloader
    class FakeFD(object):
        def __init__(self):
            self.fp = None
            self.cookie_jar = None
        def read(self, n):
            return b'-' * n
        def close(self):
            pass
        def release(self):
            pass
    class FakeFD2(FakeFD):
        def read(self, n):
            return b'%' * n
    class FakeFD3(FakeFD):
        def read(self, n):
            return b'#' * n

    def fake_downloader_constructor(_, *args, **kwargs):
        return FakeDownload

# Generated at 2022-06-22 09:12:07.414917
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.set_downloader(object)
    try:
        pp.run(object)
    except SystemExit as e:
        assert e.code == 1, 'run() raises an exception when called'
    try:
        pp.try_utime(object, object, object)
    except SystemExit as e:
        assert e.code == 1, 'try_utime() raises an exception when called'

# Generated at 2022-06-22 09:12:19.343028
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'Generic':
            downloader = FileDownloader({'outtmpl': '%(id)s%(ext)s'}, ie, None, None)
            break
    if not downloader:
        sys.exit('ERROR: unable to test PostProcessor.run()')
    ie.download = lambda *a, **k: {'id': 'test'}
    filename = downloader.prepare_filename('test')

# Generated at 2022-06-22 09:12:23.361201
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    # test constructor with downloader parameter
    dl = object()
    pp = PostProcessor(dl)
    assert dl == pp._downloader

# Generated at 2022-06-22 09:12:25.888576
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp=PostProcessor()
    pp.set_downloader('dummy downloader')
    assert pp._downloader == 'dummy downloader'

# Generated at 2022-06-22 09:12:30.112498
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class PP(PostProcessor):
        def run(self, information):
            assert self._downloader is not None

    pp = PP()
    pp.set_downloader("Downloader")
    pp.run("Information")

# Generated at 2022-06-22 09:12:37.358062
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        pp = PostProcessor()
        assert pp
    except Exception as e:
        assert False, 'Cannot create PostProcessor object: %r' % e
    return True

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:12:46.859031
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL

    class PostProcessor_try_utime_test(PostProcessor):
        def __init__(self, downloader):
            super(self.__class__, self).__init__()
            self.exception = None

        def run(self, info):
            try:
                self.try_utime(info['filepath'], 0, 0)
            except Exception as e:
                self.exception = e

        def set_downloader(self, downloader):
            # No downloader needed, but override so we can set our custom PP
            self._downloader = downloader
            self._downloader.add_post_processor(self)

    ydl = YoutubeDL({'quiet': True, 'ignoreerrors': True, 'writedescription': True})
    pp = PostProcess

# Generated at 2022-06-22 09:12:49.083080
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None



# Generated at 2022-06-22 09:12:54.217023
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.FakeYdl import FakeYdl
    p = PostProcessor()
    assert p._downloader is None
    p.set_downloader(FakeYdl())
    assert p._downloader is not None


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:12:57.744831
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor import gen_extractors

    pp = PostProcessor()
    assert pp._downloader == None

    downloader = FileDownloader(gen_extractors(), {})

    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-22 09:13:09.421082
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader.common import Downloader
    from ..compat import compat_str
    from ..utils import PostProcessingError
    from .xattrpp import XAttrMetadataPP
    from .ffmpeg import FFmpegPostProcessor

    class PostProcessorMock(PostProcessor):
        def __init__(self, downloader):
            super(PostProcessorMock, self).__init__(downloader)
            self.return_value = True

        def run(self, information):
            return PostProcessingError(
                'PostProcessorMock run failed.'), information

    class PostProcessorMock2(PostProcessor):
        def __init__(self, downloader):
            super(PostProcessorMock2, self).__init__(downloader)
            self.return_value = True


# Generated at 2022-06-22 09:13:18.630642
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    from .common import FakeYDL


# Generated at 2022-06-22 09:13:22.152980
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    obj = AudioConversionError(msg='msg')

    # test attributes msg and cause
    obj.msg
    obj.cause
    obj.__cause__
    obj.__context__
    obj.with_traceback(None)



# Generated at 2022-06-22 09:13:33.324360
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import encodeFilename
    from time import time
    import os
    import tempfile

    class MyPostProcessor(PostProcessor):
        def run(self, info):
            now = time()
            self.try_utime(info['filepath'], now, now)

    temp_dir = tempfile.mkdtemp()
    temp_filename = os.path.join(temp_dir, 'temp-file.txt')
    temp_file = open(encodeFilename(temp_filename), 'w')
    temp_file.write('Unit test for method try_utime of class PostProcessor')
    temp_file.close()

    pp = MyPostProcessor()

    # Test for valid case
    pp.set_downloader(None)
    test_info = {'filepath': temp_filename}

# Generated at 2022-06-22 09:13:41.340402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FileDownloader

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], info['atime'], info['mtime'], errnote='Test')
            return [], info
    
    info = {
        'title': 'Test',
        'ext': '.mp3',
        'id': 'test',
        'format': 'TestFormat',
        'filesize': 1024,
        'url': 'http://localhost/',
        'format_id': 'TestFormatId',
        'filepath': 'Test.mp3',
        'atime': 0,
        'mtime': 0
    }

# Generated at 2022-06-22 09:13:49.899890
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError("FFmpeg", "Could not encode audio", "file.mp3", -15)
    assert "Failed to convert audio file.mp3 to mp3: Could not encode audio\n" == error.message



# Generated at 2022-06-22 09:13:54.887286
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, information):
            return [information['filepath'] + '.test'], information

    pp = TestPP()
    info = {'filepath': 'abc'}
    files, out = pp.run(info)
    assert files == ['abc.test']
    assert info is out

# Generated at 2022-06-22 09:13:57.764801
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    assert p._downloader is None
    p.set_downloader(object())
    assert p._downloader is not None

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-22 09:14:09.470413
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    test_file_path = 'test_file'
    _file = open(test_file_path, 'w')
    _file.write('test')
    _file.close()

    # Test postprocessor without downloader (downloader - None)
    pp = PostProcessor(None)
    try:
        os.utime(encodeFilename(test_file_path), (0, 0))
    except OSError:
        pass
    pp.try_utime('test_file', 0, 0, 'Cannot update utime of file')
    mtime, atime = os.stat(encodeFilename(test_file_path))[8:10]
    if not (mtime, atime) == (0, 0):
        raise Exception('Try to reutime test_file without downloader failed.')

# Generated at 2022-06-22 09:14:21.138165
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request
    from ..extractor import get_info_extractor

    info = {'id': 'p_12345'}
    filepath = 'dummy.mp4'

    class TestPP(PostProcessor):
        def run(self, info):
            assert info['filepath'] == filepath
            assert info['id'] == 'p_12345'
            return ['file1.mp3', 'file2.mp3'], info

    # Test case 1: no downloader, no IE
    pp = TestPP()
    deleted, info = pp.run(info)
    assert deleted == []
    assert info == {'id': 'p_12345', 'filepath': 'dummy.mp4'}

    # Test case 2: downloader, no IE (downloader is not used

# Generated at 2022-06-22 09:14:30.241499
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import errno
    from ..utils import date_from_str

    filename_in = 'test_video.mp4'
    filename_out = 'test_video.ogg'
    filepath_in = os.path.join(tempfile.gettempdir(), filename_in)
    filepath_out = os.path.join(tempfile.gettempdir(), filename_out)

    # Prepare the input file
    shutil.copyfile(os.path.join('tests', 'testdata', 'test.mp4'), filepath_in)

    # Prepare the output file
    shutil.copyfile(os.path.join('tests', 'testdata', 'test.mp4'), filepath_out)

    # Initialize a PostProcessor object
    pp = PostProcessor(None)

    #

# Generated at 2022-06-22 09:14:31.157755
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor(None)


# Generated at 2022-06-22 09:14:34.511003
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError(2, 3, 'Foo happened')
    assert e.exit_code == 2
    assert e.out_code == 3
    assert str(e) == 'Foo happened'

# Generated at 2022-06-22 09:14:46.279238
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class Mock_PostProcessor(PostProcessor):
        def run(self, information):
            return [information['filepath']], None

    info = {'filepath': 'test'}
    PostProcessor_instance = Mock_PostProcessor()
    result = PostProcessor_instance.run(info)
    assert result[0][0] == 'test'

    class Mock_PostProcessor_with_downloader(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

        def run(self, information):
            return [information['filepath']], None

    PostProcessor_instance = Mock_PostProcessor_with_downloader(downloader=object)
    result = PostProcessor_instance.run(info)
    assert result[0][0] == 'test'

# Generated at 2022-06-22 09:14:59.045964
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import unittest

    from ..compat import (
        compat_os_name,
        compat_urllib_error,
    )

    # avoid test failures on FAT filesystems
    if compat_os_name == 'nt':
        return

    from .test_downloads import setup
    from ..utils import (
        DateRange,
    )

    downloader = setup()

    # Testing file that does not exist
    pp = PostProcessor(downloader)
    pp.try_utime('nonexistant', 1, 1)
    pp.try_utime('nonexistant', 1, 1, errnote='errnote')

    # Testing valid utime
    filename = downloader.temp_name('.tmp')
    open(filename, 'w').close()
    pp = PostProcessor

# Generated at 2022-06-22 09:15:16.925296
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl.downloader
    youtube_dl.postprocessor.PostProcessor._downloader = None
    pp = PostProcessor()
    try:
        pp.set_downloader(youtube_dl.downloader.FileDownloader())
        assert pp._downloader != None
    except SystemExit:
        raise youtube_dl.downloader.PostProcessingError("Exit")
    except Exception:
        raise youtube_dl.downloader.PostProcessingError("Error")

# Generated at 2022-06-22 09:15:20.045378
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert err.args[0] == 'test'

# Generated at 2022-06-22 09:15:21.079062
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    a = PostProcessor()

# Generated at 2022-06-22 09:15:24.634411
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MyPP(PostProcessor):
        def __init__(self):
            self._downloader = None

    pp = MyPP()
    pp.set_downloader(True)
    assert pp._downloader

# Generated at 2022-06-22 09:15:27.958945
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Basic test for the constructor of class PostProcessor."""
    pp = PostProcessor()
    assert pp._downloader is None


# Utility functions

# Generated at 2022-06-22 09:15:28.646603
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-22 09:15:31.730682
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message', code=2)
    except AudioConversionError as err:
        assert err.error_message == 'message'
        assert err.exit_code == 2

# Generated at 2022-06-22 09:15:37.861769
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .common import FakeDownloader

    def _run_pp(pp, *a, **ka):
        pp.set_downloader(FakeDownloader())
        return pp.run(*a, **ka)

    pp1 = PostProcessor()
    assert _run_pp(pp1, None) == ([], None)

    pp2 = PostProcessor()
    pp1.add_post_processor(pp2)
    assert _run_pp(pp1, None) == ([], None)

# Generated at 2022-06-22 09:15:39.508532
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:15:41.596019
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError("%s: %s" % ('foo', 'bar'))
    assert error.msg == 'foo: bar'

# Generated at 2022-06-22 09:16:09.504545
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader
    pp._downloader = None
    pp.set_downloader(downloader)
    assert pp._downloader is downloader


# Generated at 2022-06-22 09:16:13.026470
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    fail, info = pp.run(dict())
    assert fail is not None
    assert info is not None



# Generated at 2022-06-22 09:16:17.952992
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError(('infile', 'outfile', 'error'),
                                 True)
    assert error.convert_error is True
    assert error.infile == 'infile'
    assert error.outfile == 'outfile'
    assert error.msg == 'error'



# Generated at 2022-06-22 09:16:25.503896
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    class MockPP(PostProcessor):
        pass

    ydl = YoutubeDL()
    fdl = FileDownloader(ydl, {})
    pp = MockPP()
    pp.set_downloader(fdl)
    assert pp._downloader == fdl

    pp = MockPP(fdl)
    assert pp._downloader == fdl

# Generated at 2022-06-22 09:16:27.798829
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    pp = PostProcessor(ydl)
    pp.set_downloader(None)
    assert pp._downloader == None

# Generated at 2022-06-22 09:16:31.018197
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    assert pp


# Test for method run of class PostProcessor

# Generated at 2022-06-22 09:16:36.430289
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..compat import stdout
    from ..utils import FakeYDL

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self.set_downloader(downloader)

    ydl = FakeYDL()
    fake_pp = FakePostProcessor(FileDownloader(ydl, {'logger': stdout}))
    assert fake_pp._downloader is not None

# Generated at 2022-06-22 09:16:38.941133
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__.__name__ == "PostProcessor"



# Generated at 2022-06-22 09:16:40.657763
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postprocessor = PostProcessor()
    postprocessor.try_utime(__file__, 100, 100, 'Test')

# Generated at 2022-06-22 09:16:44.895720
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    postProcessor = PostProcessor()
    downloader = FileDownloader({})
    postProcessor.set_downloader(downloader)
    assert downloader == postProcessor._downloader

# Generated at 2022-06-22 09:17:43.885862
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    TestPP = type('TestPP', (PostProcessor, object), {'run': lambda self, info: (None if info.get('filepath') is None else [], info)})
    pp = TestPP()
    assert (None, {'test': 4}) == pp.run({'test': 4}), 'PostProcessor.run() must return the original info'
    assert ([], {'test': 4, 'filepath': 'test'}) == pp.run({'test': 4, 'filepath': 'test'}), 'PostProcessor.run() must add a filepath'
    assert ([], {'test': 4, 'filepath': ''}) == pp.run({'test': 4, 'filepath': ''}), 'PostProcessor.run() must add a filepath'

# Generated at 2022-06-22 09:17:45.627571
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor(None)
    assert pp.run(None) == ([], None)

# Generated at 2022-06-22 09:17:48.526288
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, information):
            return ['A'], {'a': True}

    pp = TestPP()
    assert pp.run({}) == (['A'], {'a': True})



# Generated at 2022-06-22 09:17:51.156215
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor."""

    # Test empty constructor:
    pp = PostProcessor()
    assert pp._downloader is None

# Generated at 2022-06-22 09:17:56.949460
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Test message', 'mock_format', 'mock_path')
    except AudioConversionError as exception:
        assert exception.format == 'mock_format'
        assert exception.path == 'mock_path'
    else:
        assert False, 'AudioConversionError not raised'

# Generated at 2022-06-22 09:17:59.110662
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor(None)
    assert p._downloader is None
    assert p._configuration_args() == []

# Generated at 2022-06-22 09:18:01.186121
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # Create an AudioConversionError
    ace = AudioConversionError("a test error", "test_output_file.mp3")

    # Check if it has correct error message
    assert ace.msg == "a test error"

    # Check if it has correct output file
    assert ace.output_file == "test_output_file.mp3"

# Generated at 2022-06-22 09:18:04.590785
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-22 09:18:09.478167
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import datetime
    import stat
    import time

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create temporary file
    (_, tmp_file) = tempfile.mkstemp(dir=tmp_dir)

    # create PostProcessor with dummy downloader
    pp = PostProcessor(downloader='dummy')

    # get current time
    now = datetime.datetime.now()

    # set access and modification time to "now"
    pp.try_utime(tmp_file, now.timestamp(), now.timestamp())

    # get file and access modification time from tmp_file
    st = os.stat(tmp_file)
    mtime = st[stat.ST_MTIME]

# Generated at 2022-06-22 09:18:11.425161
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor().run({'filepath': 'file'}) == ([], {'filepath': 'file'})

# Generated at 2022-06-22 09:20:21.965430
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.downloader import common as dl_common
    from youtube_dl.YoutubeDL import YoutubeDL

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 1000, 2000)
            return ([], info)

    ydl = YoutubeDL({'format': 'bestaudio/best',
                     'outtmpl': '%(id)s.%(ext)s',
                     'ignoreerrors': True,
                     'restrictfilenames': True,
                     'nooverwrites': True,
                     'logger': dl_common.FakeLogger()})
    ydl.add_post_processor(FakePostProcessor())
    ydl.download(['http://example.com/foo.mp4'])

# Generated at 2022-06-22 09:20:25.074122
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert(str(err) == 'test')


# Generated at 2022-06-22 09:20:33.005248
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import sys
    import tempfile

    # Create temporary directory for testing
    tempdir = tempfile.mkdtemp(suffix='_pytube_test_PostProcessor_set_downloader')
    sys.stderr.write('Testing PostProcessor set_downloader in %s\n' % tempdir)
    sys.stderr.flush()

    from .. import YoutubeDL
    from .common import FileDownloader
    from .xattrpp import XAttrMetadataPP

    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self._testval = 42

        def run(self, information):
            # Test that downloader was set
            self._testval = self._downloader.params.get('testval')
