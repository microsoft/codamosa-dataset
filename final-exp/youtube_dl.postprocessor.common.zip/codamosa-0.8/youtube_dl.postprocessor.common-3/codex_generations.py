

# Generated at 2022-06-12 19:09:56.925379
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from tempfile import mkstemp
    from shutil import rmtree
    from .testcases import TestCase

    class MockDownloader:

        def __init__(self, verbose):
            self._verbose = verbose

        def report_warning(self, msg):
            if self._verbose:
                print('warning: %s' % msg)

    test_dir = os.path.dirname(os.path.realpath(__file__))

    def _test_PostProcessor_try_utime(verbose):
        (fd, path) = mkstemp(dir=test_dir)
        os.close(fd)


# Generated at 2022-06-12 19:10:01.666898
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()

    def call_with_utime_exception(path, atime, mtime):
        raise OSError('Error from os.utime()')

    p.try_utime = call_with_utime_exception
    p.try_utime('path', 1400000000, 1400000000)

# Generated at 2022-06-12 19:10:11.017145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    composed_info = {
        'format': 'test',
        'ext': 'test',
        'title': 'test',
        'webpage_url': 'http://www.test.com/test.html',
        'filepath': 'test.test',
        'fulltitle': 'test',
        'id': 'test'
    }
    MockDownloader = type('MockDownloader', (object,), {'params': {}})
    MockDownloader.report_warning = lambda self, message: print('warning: %s' % message)
    pp = PostProcessor(MockDownloader())
    pp.try_utime('test', 1, 2, 'Cannot update utime of file')

# Generated at 2022-06-12 19:10:14.617793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    try:
        pp.try_utime('/path/to/nonexistent', 0, 0)
    except Exception:
        assert False, 'try_utime raised an exception'
    assert True



# Generated at 2022-06-12 19:10:17.729792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL(params={'quiet': True})
    pp = PostProcessor(downloader)
    pp.try_utime('', 0, 0)  # this must not raise an exception

# Generated at 2022-06-12 19:10:18.216059
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:10:28.329160
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # class LoaderMock
    class LoaderMock(object):
        report_warning_count = 0

        def report_warning(self, msg):
            LoaderMock.report_warning_count += 1

    # test
    p = PostProcessor(downloader=LoaderMock())
    p.try_utime('file', 0, 0)
    p.try_utime('file', 1, 0)
    p.try_utime('file', 1, 1)
    if LoaderMock.report_warning_count != 3:
        raise SystemExit("test_PostProcessor_try_utime failed: report_warning_count should be 3, but is %d" % LoaderMock.report_warning_count)

test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:10:39.157392
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeFileDownloader

    def _test_utime(path, atime, mtime, errnote, expected_out):
        dl = FakeFileDownloader(params={'outtmpl':'%(id)s'})
        pp = PostProcessor(dl) # create postprocessor
        pp.try_utime(path, atime, mtime, errnote)
        assert expected_out == dl.report.getvalue()

    _test_utime('', 1, 2, '', '')
    _test_utime('test.flv', 1, 2, '', '')
    _test_utime('test.flv', None, 2, '', 'WARNING: Cannot update utime of file\n')

# Generated at 2022-06-12 19:10:45.988611
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2
    # Test for Python 2
    if PY2:
        from StringIO import StringIO
        from unittest.mock import patch
        with patch('sys.stdout', new=StringIO()) as fake_out:
            from ..utils import PostProcessor
            pp = PostProcessor()
            # Works fine when the file can be accesed
            pp.try_utime(__file__, 0, 0, errnote='')
            assert not fake_out.getvalue()
            # Prints the error message when the file can't be accessed
            pp.try_utime('', 0, 0, errnote='Error')
            assert fake_out.getvalue()
    # Test for Python 3
    else:
        import io
        import unittest.mock

# Generated at 2022-06-12 19:10:55.087133
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeYDL
    from .extractor import VideoExtractor
    from .downloader import FileDownloader
    from .compat import compat_setenv
    from .compat import compat_environ_get

    test_file = 'http://example.org/video.mp4'
    test_dir = os.path.dirname(encodeFilename(__file__))

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            filename = info['filepath']
            dirname = os.path.dirname(filename)
            self.try_utime(dirname, 1, 1)
            self.try_utime(filename, 2, 2)
            return [], info


# Generated at 2022-06-12 19:11:06.336557
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .YoutubeDL import YoutubeDL
    pp = PostProcessor({})
    ydl = YoutubeDL({'writedescription': False, 'writeinfojson': False, 'writethumbnail': False})
    pp.set_downloader(ydl)

    txt = b'''
    <!DOCUMENT html><html><body>HTML</body></html>
    '''

    with open('test.html', 'wb') as myfile:
        myfile.write(txt)

    pp.try_utime('test.html', 1131314019.0, 1162125981.0)
    assert os.path.getmtime('test.html') == 1162125981.0
    assert os.path.getatime('test.html') == 1131314019.0

    os.remove('test.html')

# Generated at 2022-06-12 19:11:16.864889
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import check_executable
    from .common import FakeYDL

    class PP(PostProcessor):

        def __init__(self, ydl):
            super(PP, self).__init__(ydl)
            self.n_calls = 0

        def run(self, info):
            path = info['filepath']
            last_atime = os.stat(encodeFilename(path)).st_atime
            last_mtime = os.stat(encodeFilename(path)).st_mtime
            self.try_utime(path, 1, 2)
            new_atime = os.stat(encodeFilename(path)).st_atime
            new_mtime = os.stat(encodeFilename(path)).st_mtime
            assert new_atime == 1 and new_mtime == 2 and new

# Generated at 2022-06-12 19:11:27.769371
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test case for method try_utime of class PostProcessor.
    """

    import sys
    import os
    import tempfile
    import shutil

    from ..utils import determine_ext


    class TestDownloader(object):
        def __init__(self):
            self.params = {}

        def to_stdout(self, message, skip_eol=False):
            if not skip_eol:
                message += os.linesep
            sys.stdout.write(message)
            sys.stdout.flush()

        def to_stderr(self, message):
            sys.stderr.write(message)
            sys.stderr.flush()

        def report_warning(self, message):
            self.to_stderr(message)


# Generated at 2022-06-12 19:11:39.255371
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    from ..compat import compat_tempfile

    test_file_name = 'post_process_test.txt'
    test_file = compat_tempfile.NamedTemporaryFile(mode='w', delete=False)
    test_file.write('TESTTESTTEST')
    test_file.close()

    ref_time = os.stat(test_file_name)[7]
    time.sleep(1)

    pp = PostProcessor(None)
    pp.try_utime(test_file_name, ref_time, ref_time)
    test_time = os.stat(test_file_name)[7]
    assert ref_time == test_time

    os.remove(test_file_name)

# Generated at 2022-06-12 19:11:47.053702
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Mock PostProcessor class
    class MockPostProcessor(object):
        def __init__(self):
            pass
        def report_warning(self, msg):
            self._reported_warning_msg = msg
    pp = MockPostProcessor()
    # Mock utime method
    pputime = os.utime
    def mock_utime(fname, atime, mtime):
        raise OSError('Test exception')
    os.utime = mock_utime
    # Test for utime exception
    pp.try_utime('utime.txt', 0, 0)
    assert pp._reported_warning_msg == 'Cannot update utime of file'
    # Reset mocked method
    os.utime = pputime

# Generated at 2022-06-12 19:11:56.225004
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test for method try_utime of class PostProcessor.
    """
    from ..downloader import (
        FakeYDL,
    )

    class FakePP(PostProcessor):
        """
        FakePP for testing if utime can be set.
        """
        def run(self, information):
            from ..compat import (
                compat_os_utime,
            )
            path = information['filepath']
            try:
               # Call os.utime without reporting error
               self.try_utime(path, 0, 0, '')
               raise Exception('os.utime was called with no error')
            except PostProcessingError:
               pass

# Generated at 2022-06-12 19:12:02.835297
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    class DummyDL(object):
        pass
    dl = DummyDL()
    dl.report_warning = lambda s: pytest.fail(s)
    pp = PostProcessor(dl)
    from tempfile import mkstemp
    import time
    handle, name = mkstemp()
    try:
        pp.try_utime(name, time.time(), time.time())
    finally:
        os.close(handle)
        os.unlink(name)

# Generated at 2022-06-12 19:12:12.391261
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            super(TestPostProcessor, self).__init__()
            self.call_os_utime_count = 0
            self.call_report_warning_count = 0

        def run(self, information):
            self.try_utime(information['filepath'], 1, 1, 'Warning')

            os.utime = self.mock_os_utime
            self.try_utime(information['filepath'], 1, 1, 'Warning')

            assert self.call_os_utime_count == 1
            assert self.call_report_warning_count == 1

            return [], information


# Generated at 2022-06-12 19:12:12.977352
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:12:21.754871
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import stat
    import time

    class TestDownloader(object):
        def report_warning(self, msg):
            pass
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    # Change access time
    os.utime(tmp_file.name, (time.time() - 500, time.time() - 500))
    # Create PostProcessor instance
    pp = PostProcessor(TestDownloader())
    # Change access time
    pp.try_utime(tmp_file.name, time.time() - 500, time.time() - 500)
    # Check if access time is equal to expected
    assert os.stat(tmp_file.name)[stat.ST_ATIME] == int(time.time() - 500)
    # Remove

# Generated at 2022-06-12 19:12:35.206694
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .SamplePopenPostProcessor import SamplePopenPostProcessor
    from ..utils import DateRange
    post = PostProcessor(YoutubeDL({
        'writedescription': True,
        'writeannotations': True,
        'writethumbnail': True,
        'outtmpl': 'test.%(ext)s',
        'download_archive': 'test-archive.txt',
        'restrictfilenames': True,
        'matchtitle': 'test',
        'age_limit': 18,
        'download_archive_from_date': DateRange('20120101'),
    }))


# Generated at 2022-06-12 19:12:45.181302
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import locale

    pp = PostProcessor()

    tempdir = tempfile.mkdtemp()

    testFile1 = os.path.join(tempdir, 'test1.txt')
    testFile2 = os.path.join(tempdir, 'test2.txt')

    # create files
    with open(testFile1, 'w') as tf1:
        tf1.write("A" * 1000)
    with open(testFile2, 'w') as tf2:
        tf2.write("B" * 1000)

    # save old locale
    old_locale = locale.getlocale()

    atime = mtime = time.time() - 5000
    path = 'x'
    # first test run
    pp.try_utime(path, atime, mtime)



# Generated at 2022-06-12 19:12:56.545212
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import stat
    import sys
    import tempfile
    from ..utils import encodeFilename, deletefile

    p = PostProcessor(None)
    # Create a file with a known timestamp
    fd, path = tempfile.mkstemp(prefix='ytdl-test_utime')
    os.close(fd)
    atime = mtime = int(time.time()) - 3600
    os.utime(encodeFilename(path), (atime, mtime))
    # Update the timestamp of the file
    p.try_utime(path, atime, mtime)
    # Check if the timestamp was updated
    st = os.stat(encodeFilename(path))

# Generated at 2022-06-12 19:13:05.357804
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import datetime
    import time
    import tempfile
    import shutil
    class FakeInfoDict(dict):
        def __init__(self, **kwargs):
            dict.__init__(self, **kwargs)
            self.filename = 'test_file.txt'
        def __getitem__(self, k):
            return dict.__getitem__(self, k)
    class FakeDownloader(object):
        def __init__(self):
            self._report_warnings = []
        def report_warning(self, msg):
            self._report_warnings.append(msg)
    class FakePostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self._downloader = FakeDownloader()
            self._tmp

# Generated at 2022-06-12 19:13:13.240194
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from ..compat import PY2
    from ..utils import PostProcessingError
    import os
    import shutil
    import tempfile
    import time

    class MockDownloader():
        def report_warning(self, msg):
            # Check the message is correct
            if msg is not 'Cannot update utime of file':
                raise PostProcessingError('Wrong message, expected \'Cannot update utime of file\'')
    
    # creating temporary directories
    temp_dir = tempfile.mkdtemp(suffix='youtube-dl-test_PostProcessor_try_utime')
    temp_dir2 = tempfile.mkdtemp(suffix='youtube-dl-test_PostProcessor_try_utime')

    # creating a temporary file

# Generated at 2022-06-12 19:13:17.354054
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            obj = TestPostProcessor()
            obj.try_utime('/tmp', 1, 2)
            assert True

    tester = TestPostProcessor()
    tester.run(None)

# Generated at 2022-06-12 19:13:27.535118
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    def pw(errnote):
        pp.postProcessingError = errnote

    # --
    pp.postProcessingError = None
    pp.try_utime('test3', 10, 20, 'cannot update utime')
    assert pp.postProcessingError is None

    # --
    pp.postProcessingError = None
    pp.try_utime('test3', 10, 20, '')
    assert pp.postProcessingError is None

    # --
    pp.postProcessingError = None
    pp.try_utime('test3', 10, 20)
    assert pp.postProcessingError is None

    # --
    pp.postProcessingError = None
    pp.try_utime('test1', 10, 20, 'cannot update utime')

# Generated at 2022-06-12 19:13:30.916199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # pylint: disable=protected-access
    class FakePP(PostProcessor):
        def __init__(self, test):
            self.test = test

    pp = FakePP(test=None)
    pp.try_utime('test', 0, 0)


test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:13:41.282166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from tempfile import mkdtemp
    from .common import FileDownloader

    filename = 'test.txt'
    content = 'test\ntest\ntest\n'
    pp = PostProcessor(None)
    dl = FileDownloader(None, None, None)
    dl.params = {}
    pp._downloader = dl
    tmp_folder = mkdtemp()
    try:
        tmp_file = os.path.join(tmp_folder, filename)
        with open(tmp_file, 'w') as f:
            f.write(content)
        pp.try_utime(tmp_file, 0, 0)
        assert True # No exception was raised and assert was not skipped
    finally:
        shutil.rmtree(tmp_folder)

# Generated at 2022-06-12 19:13:48.235472
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import YoutubeIE
    from .integration import download_playlist

    ie = YoutubeIE()
    download_playlist(ie,  ['https://www.youtube.com/playlist?list=PLw-VjHDlEOgt9QI40bjyEYKvqg6m0IA3H'])

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:14:04.138055
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile

    pp = PostProcessor(None)
    # Create a testfile for utime testing
    testfile_fd, testfile_path = tempfile.mkstemp()
    testfile = os.fdopen(testfile_fd, 'wb')
    testfile.write(b"test")
    testfile.close()
    # Try to set the mtime with a wrong time
    try:
        pp.try_utime(testfile_path, 0, sys.maxsize + 1)
    except OverflowError:
        # This exception is normal on 32-bits systems
        pass

    # Remove testfile
    os.remove(encodeFilename(testfile_path))

# Generated at 2022-06-12 19:14:15.194028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    def test_function(self, path, atime, mtime, errnote='Cannot update utime of file'):
        if not os.path.exists(path):
            os.makedirs(path)
        test_file = os.path.join(path, '.ydl_test_file')
        open(test_file, 'w').close()

        pp = PostProcessor(None)
        pp.try_utime(test_file, atime, mtime, errnote)
        info = os.stat(test_file)
        modified = datetime.datetime.fromtimestamp(info.st_mtime)
        accessed = datetime.datetime.fromtimestamp(info.st_atime)
        os.remove(test_file)
        assert(modified == mtime)

# Generated at 2022-06-12 19:14:16.069931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:14:26.399810
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import os
    import sys
    import stat
    import tempfile
    import time
    import platform

    def check_file_times(filename, atime=None, mtime=None):
        if platform.system() == 'Windows':
            return None, None
        stat_res = os.stat(filename)
        if atime is None:
            atime = stat_res.st_atime
        if mtime is None:
            mtime = stat_res.st_mtime
        return atime, mtime

    # Create a temporary directory
    tempdir = tempfile.mkdtemp()
    orig = os.path.join(tempdir, 'orig')
    with open(orig, 'wb') as f:
        f.write(b'hello')
    atime, mtime = check_file_

# Generated at 2022-06-12 19:14:32.071922
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor class
    class PP(PostProcessor):
        pass

    # Set downloader
    downloader = None

    # Instanciate a PostProcessor
    pp = PP(downloader)

    # Call try_utime method
    pp.try_utime('', 0, 0)

# Generated at 2022-06-12 19:14:39.792649
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import time
    import unittest
    import tempfile

    class TestDownloader(object):
        def report_warning(self, msg):
            print('WARNING: %s' % msg)

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class TestPostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix='test_youtube-dl_')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-12 19:14:45.104996
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MyPostProcessor(PostProcessor):
        def __init__(self, pp=None):
            self.pp = pp

        def run(self, info):
            return self.pp.try_utime(info['filepath'], info['atime'], info['mtime'], info['errnote'])
    from ..compat import compat_makedirs, compat_open
    from ..downloader import get_suitable_downloader
    from ..utils import RandomByteStream
    from tempfile import tmpdir
    from .test import _run_async, get_testcases
    # Test if method try_utime works for non-empty files
    for d in get_suitable_downloader([]):
        dl = d(params={})
        pp = MyPostProcessor(dl)
        dl.add_post

# Generated at 2022-06-12 19:14:56.122775
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os

    import mock
    from nose.tools import assert_equal, assert_raises

    from .downloader import Downloader

    downloader = Downloader(params={})
    pp = PostProcessor(downloader)

    with open('file_with_mtime.txt', 'wb') as f:
        f.write('Some text')

    with open('file_with_mtime.txt', 'r') as f:
        old_mtime = os.stat(f.name).st_mtime

    with mock.patch('os.utime') as mock_utime:
        # Test 1: no exception raised
        pp.try_utime('file_with_mtime.txt', old_mtime + 100, old_mtime + 200)
        assert_equal(mock_utime.call_count, 1)


# Generated at 2022-06-12 19:15:05.130846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'file')
    open(path, 'w').close()
    # fetch current utime
    atime = os.stat(path).st_atime
    mtime = os.stat(path).st_mtime
    # wait a second
    time.sleep(1)
    # set utime to the future
    PostProcessor(None).try_utime(path, atime, mtime)
    # check that utime was updated
    assert os.stat(path).st_atime != atime
    assert os.stat(path).st_mtime != mtime
    # remove tempdir
    shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:15:15.154753
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        assert False
        return False
    except AssertionError:
        pass

    class DownloaderMock(object):
        def __init__(self, pp, path, atime, mtime, note):
            self.pp = pp
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.note = note

        def report_warning(self, note):
            assert note == self.note
            assert os.path.exists(self.path)
            assert os.stat(self.path).st_atime == self.atime
            assert os.stat(self.path).st_mtime == self.mtime


# Generated at 2022-06-12 19:15:29.246325
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:15:39.133050
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile

    old_atime = 10
    old_mtime = 12
    new_atime = 15
    new_mtime = 18

    _, file_name = tempfile.mkstemp()
    file_name = file_name.decode('utf-8')
    os.close(_)
    os.utime(file_name, (old_atime, old_mtime))
    time.sleep(1)

    pp = PostProcessor(None)
    pp.try_utime(file_name, new_atime, new_mtime, 'test')
    mtime = os.stat(file_name).st_mtime
    os.remove(file_name)
    assert abs(mtime - new_mtime) <= 1

# Generated at 2022-06-12 19:15:40.025967
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO
    pass

# Generated at 2022-06-12 19:15:46.538084
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import io

    class FakeDownloader():
        def report_warning(self, x):
            self.warnings = self.warnings + [x]

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=FakeDownloader()):
            PostProcessor.__init__(self, downloader)

    pp = FakePostProcessor()

    # Create a file for testing
    path = 'test_PostProcessor_try_utime.test'
    f = io.open(path, 'wb')
    f.close()

    # Test raising of exception
    try:
        pp.try_utime(path, sys.maxint, sys.maxint, 'test')
    except:
        pass  # An exception must be raised
    else:
        assert False

    # Test warning
    pp

# Generated at 2022-06-12 19:15:55.117073
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import io
    import mock

    outtmp = tempfile.mkdtemp()
    if os.path.exists(outtmp):
        shutil.rmtree(outtmp)
    os.mkdir(outtmp)

    _, path = tempfile.mkstemp(dir=outtmp)

    atime = time.time()
    mtime = atime - 100000

    try:
        raise IOError()
    except IOError as err:
        with io.open(path, 'w') as f:
            f.write(b'foo')


# Generated at 2022-06-12 19:16:03.898137
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Create a file and update utime
    """
    import datetime

    import tempfile
    import pytest

    post_processor = PostProcessor()

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp_file_name = temp.name
        file_time = os.stat(temp_file_name).st_mtime
        now = datetime.datetime.now().replace(microsecond=0)
        new_file_time = now.timestamp()
        post_processor.try_utime(temp_file_name, new_file_time, new_file_time)

        # check new file timestamp
        new_time = os.stat(temp_file_name).st_mtime
        assert new_time == new_file_time

        # Clean up.

# Generated at 2022-06-12 19:16:13.495662
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from ytdl.postprocessor import PostProcessor

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    class TempDirTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix='ytdltest')

        def tearDown(self):
            os.rmdir(self.tmpdir)

    class TestPostProcessor_try_utime(TempDirTestCase):
        def setUp(self):
            TempDirTestCase.setUp(self)
            self.pp = PostProcessor({})
            self.filename = os.path.join(self.tmpdir, 'test')

# Generated at 2022-06-12 19:16:17.865153
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.downloader.common import FileDownloader
    import tempfile
    import time
    import os

    with tempfile.TemporaryFile() as tfile:
        tfile.write('test')

        fd = FileDownloader({})
        pp = PostProcessor(fd)

        time.sleep(2)
        # Make file older
        os.utime(tfile.name, (time.time()-2000, time.time()-2000))

        # Try to update time of file
        pp.try_utime(tfile.name, time.time(), time.time())

        # Check if file is not older than 1 second
        assert abs(os.stat(tfile.name)[8] - time.time()) < 1

# Generated at 2022-06-12 19:16:25.089383
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader():
        def report_warning(self, errnote):
            assert errnote == 'Cannot update utime of file'

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(MockPostProcessor, self).__init__(downloader)

    postProcessor1 = MockPostProcessor(MockDownloader())
    postProcessor1.try_utime(None, 30, 30, errnote='Cannot update utime of file')

# Generated at 2022-06-12 19:16:25.632375
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    return


# Generated at 2022-06-12 19:16:57.941522
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime("abc", 1, 2)

    downloader = object() # noqa: F841
    tp = TestPostProcessor()
    assert tp._configuration_args([]) == []

# Generated at 2022-06-12 19:17:06.089561
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fp = open(os.path.join(tmpdir, 'temp.txt'), 'wb')
    fp.write(b'hello world')
    fp.close()

    # Get the current timestamp
    timestamp = time.time()

    # Create a new post processor
    pp = PostProcessor(None)

    # Update the utime for the file using the post processor
    pp.try_utime(fp.name, timestamp, timestamp, 'Cannot update utime of file')

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:17:16.878072
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    class Test:
        def __init__(self, value):
            self.value = value
        def report_warning(self, x):
            print('Warning: ' + x)
    def test_utime(fail):
        p = PostProcessor(Test(fail))
        path = 'test.txt'
        f = open(path, 'w')
        atime = int(time.time())
        mtime = atime + 1
        if fail:
            os.chmod(path, 0)
        p.try_utime(path, atime, mtime)
        f.close()
        os.remove(path)
    for fail in [False, True]:
        test_utime(fail)

# Generated at 2022-06-12 19:17:23.223883
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import time

    # Create temporary directory
    tmpdir = tempfile.mkdtemp(prefix='yt-test_PostProcessor_try_utime-')
    oldcwd = os.getcwd()
    os.chdir(tmpdir)
    # Create dummy file
    open('test.file', 'w').write('')
    # Get current modification time of dummy file
    oldmtime = os.path.getmtime('test.file')
    # Update modification time of dummy file
    newmtime = time.time()
    os.utime('test.file', (newmtime, newmtime))
    # Verify that the modification time of dummy file is equal to new modification time
    assert(os.path.getmtime('test.file') == newmtime)

# Generated at 2022-06-12 19:17:30.622590
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE
    from ..utils import encodeFilename

    if sys.version_info < (3, 0):
        from mock import patch
    else:
        from unittest.mock import patch

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'video')
    with open(encodeFilename(tmpfile), 'w') as f:
        f.write('foo')

    atime = time.time() - 100
    mtime = time.time() - 30


# Generated at 2022-06-12 19:17:38.213820
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    if os.name == 'nt':
        import pytest
        pytest.skip()  # This method is not available on Windows
    import tempfile
    import time
    import shutil
    from ..downloader.common import FileDownloader
    filename = encodeFilename('unicode\u2603')
    dirname = tempfile.mkdtemp()

# Generated at 2022-06-12 19:17:49.406002
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeYDL
    from ..extractor import gen_extractors
    from ..utils import DateRange

    date_range = DateRange(None, None, "%Y")
    gen_extractors()
    params = {
        'keepvideo': False,
        'writethumbnail': False,
        'postprocessor_args': '-codec copy -strict -2'
    }
    downloader = FakeYDL(params)
    downloader.add_post_processor(PostProcessor(downloader))
    downloader.add_info_extractor(gen_extractors.get_IE_for_url('http://example.com'))
    path = downloader.prepare_filename('test')

# Generated at 2022-06-12 19:17:57.917815
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    p = PostProcessor(None)

    dir = tempfile.mkdtemp()
    try:
        file_path = os.path.join(dir, 'file')
        shutil.copy(__file__, file_path)
        now = int(time.time()) + 1
        p.try_utime(file_path, now, now)
        assert int(os.stat(file_path).st_mtime) == int(now)
    finally:
        shutil.rmtree(dir)



# Generated at 2022-06-12 19:17:59.990540
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    '''
    Function test_PostProcessor_try_utime() is located in
    "test/test_utils.py"
    '''
    pass

# Generated at 2022-06-12 19:18:11.949827
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..postprocessor.ffmpeg import FFmpegPostProcessor

    def test_utime(test_input):
        (filename, expected_result, ref_time) = test_input
        # create dummy file
        with open(filename, 'w') as f:
            f.write('test')
        # process file
        pp_args = ['-x', '--audio-format', 'mp3']
        pp = FFmpegPostProcessor(YoutubeDL(params={}), downloader=None, preferedformat='bestaudio/best', ext='mp3', prepared_pp_args=pp_args)
        pp.run({'filepath': filename})
        # check result
        if not os.path.exists(filename):
            raise Exception("File not found")

# Generated at 2022-06-12 19:19:17.469138
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import shutil
    import tempfile
    import datetime
    import time
    import os
    import stat

    import pytest

    from ..now import NOW

    from ..downloader.common import FileDownloader

    from .common import FFmpegPostProcessor, PostProcessingError

    if not shutil.which('ffmpeg'):
        pytest.skip('ffmpeg not found')

    # Create a file downloader and test video
    fd = FileDownloader(params={'outtmpl': '%(id)s'})

# Generated at 2022-06-12 19:19:25.616096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    ydl.params['simulate'] = False
    ydl.report_warning = lambda msg: None
    pp.try_utime(None, None, None)  # should not fail
    ydl.report_warning = ydl.FatalError
    ydl.params['simulate'] = True
    ydl.params['quiet'] = True
    pp.try_utime(None, None, None)  # should not fail
    ydl.params['simulate'] = False
    ydl.params['quiet'] = False
    try:
        pp.try_utime(None, None, None)
    except YoutubeDL.FatalError as err:
        pass


# Generated at 2022-06-12 19:19:35.478443
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import chardet
    from io import open
    from tempfile import NamedTemporaryFile
    from time import time
    from six.moves import reload_module

    from youtube_dl.utils import encodeFilename
    reload_module(youtube_dl.youtube_dl)
    reload_module(youtube_dl.extractor.common)
    reload_module(youtube_dl.postprocessor.ffmpeg)
    reload_module(youtube_dl.postprocessor.ffmpeg)
    reload_module(youtube_dl.postprocessor.ffmpeg)

    filename = encodeFilename('abc')

    with NamedTemporaryFile(prefix=filename, delete=False) as tf:
        pass

    try:
        os.remove(filename)
    except OSError:
        pass

    pp = youtube_dl.postprocessor.ffmpeg.FFmpegPostProcessor

# Generated at 2022-06-12 19:19:40.441736
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # from https://stackoverflow.com/a/53928675
    class DummyException(Exception):
        pass

    import unittest
    import unittest.mock
    import os
    import os.path


# Generated at 2022-06-12 19:19:44.837318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Fake a downloader object, a file object, and check if the utime
       of the file have been updated"""
    import time
    import tempfile
    from ..YoutubeDL import YoutubeDL

    dl = YoutubeDL({'outtmpl': 'temp'})
    dl._setup_opener()
    pp = PostProcessor(dl)
    fd, temp_path = tempfile.mkstemp('.tmp', 'utime', '.')
    old_time = time.time()
    os.close(fd)
    # sleep for 1 seconds to ensure we can modify the utime
    time.sleep(1)
    pp.try_utime(temp_path, int(old_time), int(old_time))
    assert os.stat(temp_path).st_atime == int(old_time)
   

# Generated at 2022-06-12 19:19:49.867534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestInfo():
        def __init__(self, filepath, orig_atime, orig_mtime):
            self.filepath = filepath
            self.orig_atime = orig_atime
            self.orig_mtime = orig_mtime

    class TestDownloader():
        def __init__(self):
            self.params = {}

    class TestPostProcessor(PostProcessor):
        pass

    pp = TestPostProcessor(downloader=TestDownloader())

    pp.try_utime(__file__, None, None)
    pp.try_utime(__file__, None, os.path.getmtime(__file__))
    pp.try_utime(__file__, os.path.getatime(__file__), None)

# Generated at 2022-06-12 19:19:59.258824
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeYDL
    from .downloader import FileDownloader
    from .extractor import InfoExtractor

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            super(TestPP, self).__init__(downloader)
            self.test_result = None

        def run(self, information):
            path = information['filepath']
            self.try_utime(path, 10, 20)
            st = os.stat(encodeFilename(path))
            self.test_result = (st.st_atime, st.st_mtime)
            return [], information


    class TestIE(InfoExtractor):
        def __init__(self, downloader):
            super(TestIE, self).__init__(downloader)
            self.test_result = None

