

# Generated at 2022-06-12 19:10:04.088236
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import shutil
    import tempfile
    import time
    from unittest import TestCase

    import youtube_dl.downloader.postprocessor

    path = None
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl_test_post_processor_try_utime_')

    @staticmethod
    def report_warning(msg):
        TestPostProcessor.warnings.append(msg)

    class TestPostProcessor(youtube_dl.downloader.postprocessor.PostProcessor):
        warnings = []

        def __init__(self):
            youtube_dl.downloader.postprocessor.PostProcessor.__init__(self)
            self._downloader = lambda: 0
            self.report_warning = TestPostProcessor.report_warning

    class TestDownloader:
        params = dict()



# Generated at 2022-06-12 19:10:13.369034
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import errno
    import time
    import shutil
    import subprocess
    import platform

    if platform.system() == 'Windows':
        import msvcrt

    tmp_dir = tempfile.mkdtemp(prefix='ytdl-test_PostProcessor_try_utime')

    # Create a file that has different atime and mtime
    fd, fname = tempfile.mkstemp(dir=tmp_dir, prefix='test', suffix='.dat')
    os.write(fd, b'content\n')
    os.close(fd)
    os.utime(fname, (0, 2**32 - 1))

    class TestPostProcessor(PostProcessor):
        def __init__(self, fname):
            self.fname = fname
           

# Generated at 2022-06-12 19:10:21.870064
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import shutil
    import time
    import tempfile
    import unittest

    # Create temporary directory in current working directory
    test_dir = os.path.abspath(tempfile.mkdtemp())

    # Change current working directory so that temporary directory is the base path
    old_wd = os.getcwd()
    os.chdir(test_dir)

    # Create a test file
    f = open("test.tmp", "w")
    f.close()

    # Get file atime/mtime
    atime = os.path.getatime("test.tmp")
    mtime = os.path.getmtime("test.tmp")

    # Wait before trying to update utime (time.sleep may not be accurate enough)
    time.sleep(1)

    # Update file

# Generated at 2022-06-12 19:10:32.087175
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..Extractor import GenYoutubeIE
    from ..utils import DateRange
    from ..downloader import FileDownloader
    from ..compat import compat_os_name

    downloader = FileDownloader(
        {'usenetrc': False, 'username': 'unittest', 'password': 'unittest'})
    downloader.add_info_extractor(GenYoutubeIE())
    urls = ['https://www.youtube.com/watch?v=BaW_jenozKc']
    with open(os.path.join(os.path.expanduser(u'~'), 'youtube-dl-test-file'), 'wb') as f:
        f.write('Downloaded youtube-dl test video\n')

# Generated at 2022-06-12 19:10:42.141015
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import YoutubeDL
    from .utils import DateRange

    class TestPostProcessor(PostProcessor):
        """
        PostProcessor that keeps file and pretends to update its utime.

        If its constructor is passed with a bool, if True it will raise
        an exception when try_utime is called.
        """

        def __init__(self, downloader, fail=False):
            super(TestPostProcessor, self).__init__(downloader)
            self._fail = fail

        def run(self, info):
            if self._fail:
                raise OSError
            else:
                return [], info

    test_dl = YoutubeDL(params={'call_home': False, 'nooverwrites': True})


# Generated at 2022-06-12 19:10:42.697901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    return

# Generated at 2022-06-12 19:10:49.899240
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """test_PostProcessor"""
    from ..downloader.common import FileDownloader

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

        def run(self, info):
            if not (info.get('filepath') and os.path.isfile(encodeFilename(info['filepath']))):
                self._downloader.report_warning('File does not exist')
                return [], info
            super(TestPostProcessor, self).try_utime(info['filepath'],100,100)
            return [], info

    test_PP = TestPostProcessor()
    # Crete a generic downloader

# Generated at 2022-06-12 19:10:57.049720
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def test_try_utime(self):
            import os
            f = open('test_file', 'wb')
            f.write(b'a')
            f.close()
            import datetime
            atime = 1416742649.77
            mtime = 1416742649.77
            os.utime('test_file', (atime, mtime))
            atime2, mtime2 = os.stat('test_file').st_atime, os.stat('test_file').st_mtime
            if not abs(atime2 - atime) < 1e-6 and abs(mtime2 - mtime) < 1e-6:
                raise SystemError
            from os import utime
            bak = utime

# Generated at 2022-06-12 19:11:02.266479
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile

    import youtube_dl
    from youtube_dl.postprocessor.common import PostProcessor

    def touch(fpath, times=None):
        with open(fpath, 'a'):
            os.utime(fpath, times)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a fake executables
    exe_file = os.path.join(tmpdir, 'touch')
    with open(exe_file, 'wb') as f:
        f.write('#!/bin/sh\necho "Exist"\n')
    os.chmod(exe_file, 0o755)
    # Create a fake file
    ffpath = os.path.join(tmpdir, 'file')
    touch(ffpath)


# Generated at 2022-06-12 19:11:08.252742
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    postProcessor = PostProcessor()
    os.environ['TEST_HOME'] = tempfile.mkdtemp()
    file = os.path.join(os.environ['TEST_HOME'], 'file.bin')
    with open(file, 'wb') as f:
        f.write(b'0123456789')
    postProcessor.try_utime(file, 0, 0)
    postProcessor.try_utime(os.path.join(os.environ['TEST_HOME'], 'missing'), 0, 0)
    shutil.rmtree(os.environ['TEST_HOME'])

# Generated at 2022-06-12 19:11:13.951080
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    post_processor = PostProcessor(YoutubeDL())
    assert post_processor.try_utime('/path/to/test_try_utime.txt', 1, 2) is None

# Generated at 2022-06-12 19:11:22.726197
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.PostProcessor import PostProcessor
    from ytdl.YoutubeDLHandler import YoutubeDLHandler
    from ytdl.FileDownloader import FileDownloader
    post_processor = PostProcessor()

# Generated at 2022-06-12 19:11:33.554585
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import stat

    class DummyPostProcessorPP(PostProcessor):
        def run(self, information):
            return [], information


# Generated at 2022-06-12 19:11:43.542783
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # mock a downloader
    class D(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda x:x
        def report_error(self, txt):
            raise Exception(txt)
    d = D()
    # mock a postprocessor
    pp = PostProcessor(downloader=d)
    # mock a file descriptor
    fd = open(__file__, "r")
    # now test the method
    pp.try_utime(fd, 0, 0, errnote='test')
    # normally, the above statement should raise an exception 
    # but it doesn't.
    # this is because the utime function won't really work on 
    # file descriptors, so instead of returning an error, it returns None
    # this check is here to make sure that

# Generated at 2022-06-12 19:11:53.776709
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import encodeFilename

    import os
    import pytest
    from .common import FakeYDL

    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    testfile_path = b'foo.bar'

    def run_utime_test(atime, mtime):
        # create test file
        with open(encodeFilename(testfile_path), 'wb') as f:
            pass
        # set atime and mtime for test file
        os.utime(encodeFilename(testfile_path), (atime, mtime))
        # run test
        pp.try_utime(testfile_path, atime, mtime)
        # read atime and mtime of test file

# Generated at 2022-06-12 19:12:00.510298
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    from .downloader import FakeYDL

    t0 = time.time()

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], t0, t0, errnote='wtf?')
            return ([], info)

    class PostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()

        def test_try_utime(self):
            pp = DummyPostProcessor(self.ydl)
            pp.set_downloader(self.ydl)
            t1 = time.time()
            temp_filepath = tempfile.mkstemp()[1]
            t2

# Generated at 2022-06-12 19:12:09.813669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import time
    import unittest
    import tempfile
    from subprocess import Popen, PIPE
    from .downloader import Downloader
    from .utils import (
        encodeFilename,
        html_to_clean_html,
    )

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(encodeFilename(info['filepath']), info['atime'], info['mtime'])
            return [encodeFilename(info['filepath'])], info

    class TestPostProcessor(unittest.TestCase):
        def setUp(self):
            self.postprocessor = FakePostProcessor()
            self.postprocessor_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:12:19.171733
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:12:23.025681
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import utils
    # Check if it is a valid utc time
    assert utils.is_valid_utc_datetime("2015-01-02T01:02:03.12345Z")
    # Check if it is a invalid utc time
    assert not utils.is_valid_utc_datetime("01:02:03.12345Z")

# Generated at 2022-06-12 19:12:33.720442
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import DateRange

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader
            self._called = []

        def run(self, info):
            self._called.append(info)
            return [], info

    post_processor = MockPostProcessor()

    old_stderr = open('stderr.txt', 'w')
    class FakeStderr(object):
        def write(self, *args, **kwargs):
            pass
    f_stderr = FakeStderr()
    old_downloader = FileDownloader(params={})
    old_downloader.add_info_extractor(YoutubeIE())
   

# Generated at 2022-06-12 19:12:44.748729
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import stat
    import os

    (fd, filename) = tempfile.mkstemp(prefix='youtube-dl-test_PostProcessor-try_utime-')
    os.close(fd)

    pp = PostProcessor(None)
    pp.try_utime(filename, 0, 0)
    file_stat = os.stat(filename)
    os.unlink(filename)
    assert file_stat[stat.ST_ATIME] == 0
    assert file_stat[stat.ST_MTIME] == 0

# Generated at 2022-06-12 19:12:56.170525
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    file_path = tempfile.mkdtemp() + '/'

# Generated at 2022-06-12 19:13:05.085207
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import stat
    from io import open

    from ..compat import (
        compat_tempfile,
    )
    from ..utils import (
        write_json_file,
    )


# Generated at 2022-06-12 19:13:09.702184
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    from .common import FakeYDL

    ydl = FakeYDL()

# Generated at 2022-06-12 19:13:19.904292
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import os
    import sys

    if sys.version_info >= (3, 0):
        from io import StringIO as FakeFile
    else:
        from io import BytesIO as FakeFile

    output = FakeFile()
    def w(s):
        output.write(s)

    # Create some file
    dir_path = tempfile.mkdtemp()
    file_path = os.path.join(dir_path, 'test')
    with open(file_path, 'wb') as f:
        f.write('test')
    # Get current time
    current_time = time.time()
    # Check that both mtime and atime are equals to current time
    assert abs(os.path.getmtime(file_path) - current_time) < 1

# Generated at 2022-06-12 19:13:29.621087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Test the method try_utime of class PostProcessor."""
    import time
    import tempfile
    import shutil
    import os

    # Test on an existing file
    tmpdir = tempfile.mkdtemp(prefix='ytdl_test_')
    assert os.path.exists(tmpdir)
    tmppath = os.path.join(tmpdir, "test_file.txt")
    with open(tmppath, "w") as f:
        f.write("Hello World!")

    atime = time.time() - 50000
    mtime = time.time() - 100000

# Generated at 2022-06-12 19:13:37.276476
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    import _ytdl_postprocessor_test
    import tempfile
    fd, tmp = tempfile.mkstemp()
    os.close(fd)
    pp.try_utime(tmp, 0, 0)
    try:
        atime, mtime = _ytdl_postprocessor_test.test_utime(tmp)
    finally:
        os.remove(tmp)

    assert atime != 0
    assert mtime != 0

# Generated at 2022-06-12 19:13:43.648099
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    from ..compat import detect_platform

    test_file_path = ''
    try:
        if detect_platform() == 'win32':
            fd, test_file_path = tempfile.mkstemp(prefix='ytdl_test_')
        else:
            fd, test_file_path = tempfile.mkstemp()
        os.close(fd)
        pp = PostProcessor(None)
        pp.try_utime(test_file_path, 1, 1, None)
    except Exception:
        assert 1 == 2
    finally:
        os.remove(encodeFilename(test_file_path))



# Generated at 2022-06-12 19:13:53.410689
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os.path

    from .Extractor import gen_extractor
    from .YoutubeDL import YoutubeDL

    # Create a file to handle it
    file_path = 'test_try_utime.txt'
    open(file_path, 'a').close()

    # Retrieve the current utime
    file_stat = os.stat(file_path)
    orig_atime = file_stat.st_atime
    orig_mtime = file_stat.st_mtime

    # Create an Extractor for the TestInfoExtractor and a PostProcessor
    info_extractor = gen_extractor({'ie_key': 'TestInfoExtractor', 'ie': 'TestInfoExtractor', 'test': True}, YoutubeDL)

# Generated at 2022-06-12 19:14:04.742601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Mocks would be nice, but I'm not sure how to do that in python2.6
    class _MockDownloader(object):

        def __init__(self):
            self._log = []

        def report_warning(self, s):
            self._log.append(s)

    class _MockPostProcessor(PostProcessor):
        def __init__(self):
            self._downloader = _MockDownloader()

    pp = _MockPostProcessor()

    # Test utime error
    pp.try_utime('/nonexistent', 0, 0, 'test')
    assert len(pp._downloader._log) == 1
    assert pp._downloader._log[0] == 'test'

    # Test utime success (note we don't test the actual utime() call
    # because that

# Generated at 2022-06-12 19:14:14.785743
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    os.path.getmtime = lambda f:1000
    os.utime = lambda f, atime, mtime: None
    p = PostProcessor()
    info = {'id':'id', 'title':'title', 'ext':'mp4', 'filepath':'/tmp/test.mp4'}
    p.run(info)
    p.try_utime(info['filepath'], 0, 0)

# Generated at 2022-06-12 19:14:25.447187
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    # Create a fake FileDownloader instance for testing purposes
    class TestFileDownloader(FileDownloader):
        params = {
            'format': 'bestaudio/best',
            'noplaylist': True,
            'quiet': True,
            'verbose': False,
            'forcetitle': True,
            'forceurl': True,
            'forcethumbnail': True,
            'forcedescription': True,
            'simulate': True,
            'format_limit': 'bestaudio/best',
            'skip_download': True,
            'outtmpl': '%(id)s.%(ext)s',
            'nooverwrites': False,
        }



# Generated at 2022-06-12 19:14:33.390002
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(DummyPostProcessor, self).__init__(downloader)
            self.errnote = None

        def report_warning(self, errnote):
            self.errnote = errnote

    pp = DummyPostProcessor()
    pp.try_utime('/path/to/nonexistent/file', 10, 10)
    assert pp.errnote == 'Cannot update utime of file'

    pp = DummyPostProcessor()
    pp.try_utime('/path/to/nonexistent/file', 10, 10, 'Cannot update file modification time')
    assert pp.errnote == 'Cannot update file modification time'

# Generated at 2022-06-12 19:14:40.710145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    path = 'test.txt'
    atime = mtime = 0
    # test that os.utime is called
    with open(path, 'w') as f:
        f.write('foo')
    pp.try_utime(path, atime, mtime)
    stat = os.stat(path)
    assert atime == stat.st_atime and mtime == stat.st_mtime
    # test that os.utime is not called
    with open(path, 'w') as f:
        f.write('foo')
    pp.try_utime('somedir/' + path, atime, mtime, errnote='')
    stat = os.stat(path)
    assert atime != stat.st_atime and mtime != stat.st_mtime

# Generated at 2022-06-12 19:14:50.709695
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import types
    pp = PostProcessor(None)
    assert type(pp.try_utime) == types.MethodType
    path = 'PostProcessorTestPath'
    try:
        file = open(path, 'w')
        file.close()
        time.sleep(0.1) # To make sure that later atime is bigger than mtime
        pp.try_utime(path, 0, 0)
        stat = os.stat(path)
        os.remove(path)
        assert stat.st_atime == stat.st_mtime == 0
    finally:
        if os.path.exists(path):
            os.remove(path)

# Generated at 2022-06-12 19:15:01.485773
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from tempfile import NamedTemporaryFile
    from ..utils import FileDownloader
    from .compat import compat_makedirs
    from ..downloader.common import PostProcessingError

    test_directory = NamedTemporaryFile(suffix='yli_test').name
    os.close(NamedTemporaryFile(suffix='yli_test'))
    compat_makedirs(test_directory)
    fd = FileDownloader({
        'format': 'bestaudio/best',
        'outtmpl': os.path.join(test_directory, '%(title)s.%(ext)s'),
        'postprocessor_args': ['-x', test_directory, '--audio-format', 'mp3'],
    })
    pp = fd.pps[0]

    # Test utime update on

# Generated at 2022-06-12 19:15:09.670968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors
    from ..downloader import gen_ytdl_class
    from ..utils import DateRange

    testrange = (DateRange(None, None))
    ts = testrange.start_time()

    # Fake downloader
    class FakeDownloader:
        def __init__(self):
            self.params = {'logger': None}
            self.params['writedescription'] = True
            self.params['writethumbnail'] = True
            self.params['writeinfojson'] = True
            self.params['forcetitle'] = True
            self.params['forcedescription'] = True
            self.params['forcefilename'] = True

        def to_screen(self, msg):
            print(msg)


# Generated at 2022-06-12 19:15:19.328843
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import datetime
    import tempfile
    import shutil
    tmp_dir = tempfile.mkdtemp(prefix='ytdl-test_PostProcessor_try_utime-')

# Generated at 2022-06-12 19:15:30.934416
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import unittest

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                    '..', '..')))
    from youtube_dl import YoutubeDL
    from youtube_dl.downloader import FileDownloader

    class FakeInfoExtractor(object):
        def __init__(self, ie_name, ie_downloader=None, ie_info_dict=None):
            self.ie_name = ie_name
            self.ie_downloader = ie_downloader
            self.ie_info_dict = ie_info_dict

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return self.ie_info_

# Generated at 2022-06-12 19:15:41.296806
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import os

    class TestPostProcessor(PostProcessor):
        OUTPUT_FILE_EXTENSION = 'mp4'
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.converter = None
            self.converterconfig = None
            from ..extractor.common import InfoExtractor
            from ..utils import FileDownloader
            ie = InfoExtractor()
            ie.params['outtmpl'] = '%(id)s.%(ext)s'
            ie.add_default_info_extractors()
            fd = FileDownloader(ie, params={})
            self.set_downloader(fd)

    current_directory = sys.path[0]

# Generated at 2022-06-12 19:16:04.049685
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os.path
    from ..extractor import get_info_extractor
    
    # Fake file with utime information
    test_file_path = "test_file.ts"
    test_file = open(test_file_path, 'wb')
    test_file.close()
    atime = mtime = 100
    os.utime(test_file_path, (atime, mtime))

    # Fake downloader
    class FakeInfoExtractor(object):
        def __init__(self):
            self.params = {'test': True}

# Generated at 2022-06-12 19:16:13.592699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os
    from collections import namedtuple
    from ..YoutubeDL import YoutubeDL

    class DummyDownloader:
        def __init__(self, params, dir):
            self.params = params
            self.to_stderr = sys.stderr
            self.dir = dir

        def report_warning(self, msg):
            self.warning = msg

    FakeInfo = namedtuple('FakeInfo', 'upload_date')
    FakeInfo.sanitized_filename = 'test'
    upload_date = '20120101'
    fake_info = FakeInfo(upload_date)
    dir = tempfile.mkdtemp()
    f = tempfile.NamedTemporaryFile(dir=dir, delete=False)
    f.close()
    temp_

# Generated at 2022-06-12 19:16:20.360810
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp
    from time import time
    from ..utils import PostProcessor

    pp = PostProcessor()

    (fd, filename) = mkstemp(prefix='youtube-dl-utime-test-file')
    post_time = time()

    pp.try_utime(filename, post_time, post_time)  # nothing should happen

# Generated at 2022-06-12 19:16:29.356375
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    temp_dir = tempfile.mkdtemp()
    filename = "a"
    filepath = os.path.join(temp_dir, filename)
    open(filepath, 'wb').close()
    try:
        atime = mtime = time.time() - 1000
        pp = PostProcessor(None)
        pp.try_utime(filepath, atime, mtime, '')
        assert os.path.getmtime(filepath) == mtime
        assert os.path.getatime(filepath) == atime
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-12 19:16:40.644697
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import os
    import time
    from ..utils import PostProcessor

    pp = PostProcessor(None)

    dir_test = tempfile.mkdtemp(prefix="ytdl_utime_test")
    file_test = os.path.join(dir_test, "test_file.txt")
    shutil.copy(__file__, file_test)

    time.sleep(2)
    pp.try_utime(file_test, 0, 0, 'test error')
    assert os.stat(file_test).st_mtime == os.stat(file_test).st_atime

    time.sleep(2)
    pp.try_utime(file_test, 0, int(time.time()) - 100000)

# Generated at 2022-06-12 19:16:52.636662
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    from ..downloader.common import DownloadDir

    # Create a PostProcessor object
    pp = PostProcessor(downloader=None)

    # Create a test file
    ddir = DownloadDir()
    filepath = ddir.prepare('test', 'test_PostProcessor_try_utime.')

    # Set the test file date
    mtime = time.mktime(datetime.datetime.utcnow().timetuple())
    pp.try_utime(filepath, mtime, mtime)

    # Get the test file date
    stat = os.stat(filepath)

    # Check the test file date
    assert datetime.datetime.utcnow().year == datetime.datetime.utcfromtimestamp(stat.st_mtime).year
    assert datetime

# Generated at 2022-06-12 19:16:55.672632
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class DummyPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            # Create a fake downloader
            self.set_downloader({'params': {}})

    pp = DummyPostProcessor()
    assert pp.try_utime("some_file", 1, 2) == None

# Generated at 2022-06-12 19:17:05.452734
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_postprocessor import *

    downloader = DummyDownloader()
    downloader.params['ignoreerrors'] = False
    downloader.report_warning = DummyReportWarning()
    pp = PostProcessor(downloader)

    # file doesn't exist
    pp.try_utime(TEST_FILE, 10, 20)
    assert downloader.report_warning.msgs == ["Cannot update utime of file"]
    downloader.report_warning.msgs = []

    # file exists
    with open(TEST_FILE, 'w') as f:
        f.write('foobar')

    pp.try_utime(TEST_FILE, 10, 20)
    assert downloader.report_warning.msgs == []

    # file is read-only

# Generated at 2022-06-12 19:17:09.222062
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    f = open(encodeFilename('__test_try_utime__'), 'wb')
    f.close()
    import time
    atime = time.time()
    time.sleep(1)
    mtime = time.time()
    pp.try_utime('__test_try_utime__', atime, mtime)
    (a, m) = os.stat(encodeFilename('__test_try_utime__'))[7:9]
    os.remove(encodeFilename('__test_try_utime__'))
    assert a == atime
    assert m == mtime

# Generated at 2022-06-12 19:17:13.347053
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest

    try:
        import stat as stat_module
    except ImportError:
        import nt as stat_module

    # TODO
    pytest.skip("Not implemented yet")


# per-module util cache
_postprocessor_classes = None



# Generated at 2022-06-12 19:17:53.422988
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time

    temp_dir = tempfile.mkdtemp(prefix='yt-audio-test-')

# Generated at 2022-06-12 19:18:03.400191
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import unittest
    import tempfile
    from ..extractor import get_info_extractor
    from ..downloader import Downloader

    class PostProcessorUnTest(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Test'):
            return errnote

    class DownloaderTest(Downloader):
        def report_warning(self, errnote):
            return errnote

    class TestPostProcessor(unittest.TestCase):
        def test_try_utime(self):
            (fd, filename) = tempfile.mkstemp(prefix='ytdl_test_')
            os.close(fd)

# Generated at 2022-06-12 19:18:11.696738
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time

    tempdir = tempfile.mkdtemp(prefix='youtubedl')
    fpath = os.path.join(tempdir, 'f')
    with open(fpath, 'w') as f:
        f.write('foobar')
    mtime = time.time() - 10000
    os.utime(fpath, (mtime, mtime))

    pp = PostProcessor(None)
    pp.try_utime(fpath, 10000, mtime, errnote='Error')
    assert os.path.getmtime(fpath) == mtime

    os.remove(fpath)
    os.rmdir(tempdir)

# Generated at 2022-06-12 19:18:21.995491
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile

    f = open('test.mkv', 'w')
    f.close()

    utime_failed = False
    tmp_dir = tempfile.mkdtemp()
    try:
        shutil.move('test.mkv', tmp_dir)
    except Exception:
        utime_failed = True
    finally:
        shutil.rmtree(tmp_dir)

    if not utime_failed:
        import time
        import filecmp
        import datetime

        # create a temporary copy of the test file
        temp_file_1 = tempfile.NamedTemporaryFile(delete=False).name
        shutil.copy('test.mkv', temp_file_1)

        # make a timestamp in the past, and set the timestamp on the test file
        temp_file_1

# Generated at 2022-06-12 19:18:27.320548
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    class FakeDownloader(object):
        def __init__(self):
            self.warning = False

        def report_warning(self, errnote):
            if errnote == 'Cannot update utime of file':
                self.warning = True
            else:
                raise RuntimeError('Unexpected errnote: ' + errnote)
    pp = PostProcessor()
    pp._downloader = FakeDownloader()

    pp.try_utime(sys.executable, -1, -1)
    if pp._downloader.warning:
        raise RuntimeError('test_PostProcessor_try_utime failed')

# Generated at 2022-06-12 19:18:34.600555
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import calendar
    import time
    import os

    filename = tempfile.mktemp(prefix='youtube-dl-test_PostProcessor-try_utime')
    f = open(filename, 'wb')
    f.close()
    old_time = calendar.timegm(time.gmtime())
    new_time = old_time + 3600
    p = PostProcessor()
    p.try_utime(filename, new_time, new_time)
    time.sleep(1)
    assert os.stat(filename).st_mtime != old_time
    time.sleep(1)
    os.remove(filename)

# Generated at 2022-06-12 19:18:44.337682
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    import datetime

    class FakeDownloader():
        def report_warning(self, a):
            pass

    class FakePP(PostProcessor):
        def run(self, information):
            # We create a temporary directory and a file in it.
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = tempfile.NamedTemporaryFile(dir=self.tempdir)
            # We simulate a downloader passing the whole path to the file
            information['filepath'] = self.tempfile.name
            # We fake the usual dictionary passed by an InfoExtractor
            information['fulltitle'] = information['filename'] = 'test'
            # We fake the file creation time to be yesterday
            creationTime = datetime.datetime.now() - datetime.timed

# Generated at 2022-06-12 19:18:54.534011
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO

    from ..downloader.common import FakeFile
    from ..extractor import gen_extractors

    f = BytesIO(b'foobar')
    fl = FakeFile(f, None)
    fl.name = 'test.mp4'

    test_cases = [
        (
            {'keep_time': True, 'noplaylist': True},
            [(lambda x: None, 'Cannot update utime of file')],
        ),

        (
            {'keep_time': False, 'noplaylist': True},
            [],
        ),
    ]

    for td in gen_extractors():
        for (default_params, expected_logs) in test_cases:
            params = default_params.copy()
            params.update(td.get('params', {}))

# Generated at 2022-06-12 19:18:57.737145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def __init__(self, d):
            super(MockPostProcessor, self).__init__(d)
            self.tested_method = self.try_utime

    p = MockPostProcessor(None)
    import tempfile
    file_for_testing = tempfile.NamedTemporaryFile()
    filename = file_for_testing.name
    import time
    atime = time.time()
    mtime = atime - 7200
    p.tested_method(filename, atime, mtime)
    file_for_testing.close()

# Generated at 2022-06-12 19:19:01.715969
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import utils
    pp = PostProcessor(utils.FakeYDL({}))
    pp.try_utime('mtime.txt', 0, 0, 'Cannot update utime of file')