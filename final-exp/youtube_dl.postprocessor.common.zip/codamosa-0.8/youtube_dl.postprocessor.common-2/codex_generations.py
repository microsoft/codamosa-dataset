

# Generated at 2022-06-12 19:10:00.206792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2

    from tempfile import mkstemp
    from sys import platform
    from time import time
    from os import utime
    from os import fdopen


# Generated at 2022-06-12 19:10:04.577465
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_os_name
    import time
    import os
    import sys
    if compat_os_name != 'nt':
        return
    if sys.version_info < (3, 0):
        import __builtin__ as builtins
    else:
        import builtins
    p = PostProcessor(YoutubeDL())
    path = 'test_file.txt'

# Generated at 2022-06-12 19:10:11.460394
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def report_warning(self, text):
            raise Exception(text)

    pp = PostProcessor(DummyDownloader())
    pp.try_utime('test', 1, 2)
    try:
        pp.try_utime('test', -5, -5)
        assert False
    except Exception as e:
        assert 'Cannot update utime of file' in str(e)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:10:16.599340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor
    from ..downloader.f4m import F4mFD
    from ..downloader.http import HttpFD
    from ..utils import FakeFileDownloader

    class InfoExtractorMock(InfoExtractor):
        def _real_extract(self, url): return {}

    class FileDownloaderMock(FakeFileDownloader):
        """FileDownloaderMock class
        """
        def report_warning(self, errnote):
            raise errnote

    ie = InfoExtractorMock({})
    fd = FileDownloaderMock({}, ie)

    def get_path(self, *args, **kargs):
        return '/tmp/foo'
    HttpFD.get_temp_filename = get_path
    F4mFD.get_temp_filename = get_path

# Generated at 2022-06-12 19:10:21.618046
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import datetime

    fd, fname = tempfile.mkstemp(suffix='.tmp', prefix='youtube-dl.postprocessor.', dir='.')
    f = os.fdopen(fd, "w+b")
    f.close()
    pp = PostProcessor(None)
    initial_mtime = os.path.getmtime(fname)
    pp.try_utime(fname, time.time(), time.time() - 1200)
    assert initial_mtime != os.path.getmtime(fname)
    pp.try_utime(fname, time.time(), datetime.datetime.now())
    assert initial_mtime != os.path.getmtime(fname)
    os.unlink(fname)

# Generated at 2022-06-12 19:10:26.786541
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..ytdl_mock import MockYoutubeDL

    p = PostProcessor(MockYoutubeDL())
    with open('test_try_utime_nonwritable', 'w') as f:
        f.write('this file should not be deleted')
    os.chmod('test_try_utime_nonwritable', 0o0444)
    p.try_utime(path='test_try_utime_nonwritable', atime=1, mtime=2, errnote='foo')

# Generated at 2022-06-12 19:10:38.336536
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    from .common import get_testdata_file

    class FakeFileDownloader(FileDownloader):
        params = {
            'outtmpl': '%(id)s.%(ext)s',
            'quiet': True,
        }

        def report_warning(self, msg):
            self.errmsg = msg

    # Create downloader instance
    fd = FakeFileDownloader({}, {})
    # Create postprocessor instance and set downloader instance
    pp = PostProcessor(fd)

    testfile_path = get_testdata_file()
    pp.try_utime(testfile_path, 1, 2)


# Generated at 2022-06-12 19:10:45.512443
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FakeYDL

    ydl = FakeYDL()
    pp = PostProcessor(ydl)

    # Create file with specific access and modification time
    from tempfile import NamedTemporaryFile
    from time import mktime
    from datetime import datetime

    f = NamedTemporaryFile(delete=False)
    f.close()

    ftime = datetime(year=2011, month=1, day=1, hour=0, minute=0, second=0)
    ftime_epoch = mktime(ftime.timetuple())
    os.utime(f.name, (ftime_epoch, ftime_epoch))

    # First try:
    #   - use modification and access times from input file
    #   - (success)

# Generated at 2022-06-12 19:10:55.054309
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile

    now = int(time.time())

    # Create some files and directories
    tempdir = tempfile.mkdtemp(prefix='youtubedl-test_PostProcessor_try_utime-')
    tempfile1 = os.path.join(tempdir, 'you-are-the-best')
    tempfile2 = os.path.join(tempdir, 'you-are-the-worst')
    tempfile3 = os.path.join(tempdir, 'not-existed')
    not_existed_dir = os.path.join(tempdir, 'not-existed-dir')
    with open(tempfile1, 'w') as f:
        f.write('...')

    # Test if files and dirs are accessible and readable
    assert os.path

# Generated at 2022-06-12 19:10:55.619966
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:11:06.669977
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.log = []
            PostProcessor.__init__(self, *args, **kwargs)

        def report_warning(self, msg):
            self.log.append(msg)

    pp = MockPostProcessor()
    pp.try_utime(None, None, None)
    assert pp.log == ['Cannot update utime of file']
    del pp.log[:]

    pp.try_utime(None, None, None, errnote='Fail')
    assert pp.log == ['Fail']
    del pp.log[:]

    # Mock os.utime to raise error
    mock_utime = lambda *args, **kwargs: None
    mock_utime.side_effect = Exception

# Generated at 2022-06-12 19:11:17.339028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os

    def _test_try_utime():
        tempfile.tempdir = tempfile.mkdtemp(prefix='youtubedl-test_PostProcessor_try_utime')
        try:
            self = PostProcessor()
            filename = os.path.join(tempfile.tempdir, 'file_to_test.txt')
            if os.path.exists(filename):
                os.remove(filename)
            shutil.copy(sys.argv[0], filename)
            self.try_utime(filename, 0, 0)
            stat = os.stat(filename)
            assert stat.st_atime == 0
            assert stat.st_mtime == 0
            assert stat.st_ctime != 0
        finally:
            shut

# Generated at 2022-06-12 19:11:24.651175
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os

    temp_dir = tempfile.mkdtemp()
    f = open(os.path.join(temp_dir, 'A'), 'w')
    f.close()
    atime_before = os.path.getatime(os.path.join(temp_dir, 'A'))
    mtime_before = os.path.getmtime(os.path.join(temp_dir, 'A'))
    time.sleep(1)
    try:
        pp = PostProcessor({})
        pp.try_utime(os.path.join(temp_dir, 'A'), atime_before, mtime_before)
    except Exception as e:
        raise e

# Generated at 2022-06-12 19:11:35.102702
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    try:
        from io import BytesIO as StringIO
    except ImportError:
        from StringIO import StringIO
    import tempfile

    class DummyDownloader(object):
        def __init__(self, params):
            self.params = params
            self.to_stderr_fo = None
            self.to_stderr = None

        def to_stderr_start(self):
            assert self.to_stderr_fo is None
            self.to_stderr_fo = StringIO()
            self.to_stderr = sys.stderr
            sys.stderr = self.to_stderr_fo

        def to_stderr_end(self):
            assert self.to_stderr_fo is not None

# Generated at 2022-06-12 19:11:40.653065
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        # If a test fails, it will raise an exception, that is, the test will fail.
        pp.try_utime("not_a_valid_path",1,2)
    except Exception:
        pass
    else:
        assert False, "try_utime doesn't fail if given a not existent path."

# Generated at 2022-06-12 19:11:50.611128
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import os

    class DummyError(Exception):
        pass

    class DummyDownloader(object):
        def __init__(self):
            self.warning_called = False

        def report_warning(self, msg):
            self.warning_called = True

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

    pp = DummyPostProcessor(DummyDownloader())
    original_utime = os.utime

# Generated at 2022-06-12 19:11:55.629888
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.log = []
        def try_utime(self, path, atime, mtime, errnote):
            self.log.append(errnote)
    p = TestPostProcessor()
    p.try_utime('path', 0, 0, 'errnote')
    assert p.log == ['errnote']

# Generated at 2022-06-12 19:12:05.339468
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    from ..downloader import FileDownloader
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..compat import compat_str, compat_urllib_request
    from six import BytesIO

    class FakeServer(object):
        def __init__(self, server):
            self.server = server

        def request(self, _, data):
            self.data = data
            return BytesIO(b'FAKE')

    def test_func(**kwargs):
        server = FakeServer({})

# Generated at 2022-06-12 19:12:11.034481
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    f = open("/tmp/PostProcessor_try_utime.txt", "w+")
    p = PostProcessor()
    f.write("Lorem ipsum")
    p.try_utime("/tmp/PostProcessor_try_utime.txt", 123456, 123456)
    assert os.utime("/tmp/PostProcessor_try_utime.txt") == (123456, 123456)

# Generated at 2022-06-12 19:12:20.127690
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    import nose.tools
    import shutil
    import tempfile
    import stat
    import calendar
    import datetime

    import os

    import pytube


    class MyDownloader(object):

        def __init__(self, params=None):

            self.params = params or {}


        def report_warning(self, desc):
            pass


    class MyPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            super(MyPostProcessor, self).__init__(downloader)


        def run(self):
            # create a test file
            tmp_filename = 'test_file.txt'


# Generated at 2022-06-12 19:12:26.780051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from tempfile import gettempdir

    def current_seconds():
        import time
        return time.time()

    def vfs_utime_seconds(path, atime, mtime):
        import os
        return os.utime(encodeFilename(path), (atime, mtime))

    class Downloader():
        def __init__(self):
            self.params = {
                'ffmpeg_location': os.path.join(gettempdir(), 'ffmpeg'),
                'keep_video': True,
                'outtmpl': os.path.join(gettempdir(), '%(id)s.%(ext)s')
            }

        def report_warning(self, x):
            pass


# Generated at 2022-06-12 19:12:37.741028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from .compat import compat_urllib_parse_unquote, compat_urllib_parse_urlparse
    from .fake_filesys import FakeFilesys

    # Regression test for https://github.com/rg3/youtube-dl/issues/9255
    # Ensure that PostProcessors.try_utime doesn't try to os.utime
    # a filename with percent-encoded characters.

    # Mock PostProcessor class
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

    # Mock Downloader class
    class MockDownloader:
        """
        Mock Downloader class
        """
        @staticmethod
        def report_warning(errnote):
            pass

    # Set up a fake filesystem

# Generated at 2022-06-12 19:12:48.542782
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tests
    import os
    import shutil

    if os.name != 'nt':
        import time

        class PostProcessorMock(PostProcessor):
            def run(self, information):
                os.mkdir(encodeFilename(information['filepath']))
                self.try_utime(information['filepath'], time.time() - 60, time.time() - 60)

        with tests.get_temp_download_dir() as temp_download_dir:
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': os.path.join(temp_download_dir, '%(title)s-%(id)s.%(ext)s'),
                'extract_flat': 'in_playlist',
            }
            postprocessor = PostProcessorMock

# Generated at 2022-06-12 19:12:49.130260
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:13:00.075073
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from types import ModuleType
    from sys import modules
    import os

    # Create fake downloader
    downloader = ModuleType('youtubedl')
    downloader.params = {}
    downloader.to_stderr = lambda s: None
    modules[downloader.__name__] = downloader

    # Fake file path
    path = '/path/to/file'

    # Create and test PostProcessor
    pp = PostProcessor(downloader)
    pp._downloader.report_warning = lambda s: None

    pp.try_utime(path, 0, 0)
    assert os.stat(path).st_atime == 0
    assert os.stat(path).st_mtime == 0

    pp.try_utime(path, 1000, 1000)

# Generated at 2022-06-12 19:13:04.021422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.Downloader import Downloader
    from ..utils import DateRange
    from .compat import mock

    try:
        import stat as stat_module
        import tempfile
        import time
    except ImportError:
        # Can't run this test
        return

    TIMESTAMP = '20071013'
    SONG = 'ba the ba the ba'
    SONG_PATH = os.path.join(tempfile.gettempdir(), SONG)

    with mock.patch('os.utime', create=True):
        pp = PostProcessor(Downloader(params={"writedescription": True}))
        assert pp is not None

# Generated at 2022-06-12 19:13:12.957652
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def _utime(path, atime, mtime):
        assert atime == 12345
        assert mtime == 23456

    # Test in a folder that does not exists
    p = PostProcessor(None)
    p.try_utime('/does/not/exist/audio.ogg', 12345, 23456, None)

    # Test in a folder that exists, but with a file that does not exists
    old_utime = os.utime
    os.utime = _utime
    p.try_utime('/does/not/exist/audio.ogg', 12345, 23456, None)
    os.utime = old_utime

# Generated at 2022-06-12 19:13:23.497846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .fake_filesystem import FakeFilesystem
    from .fake_downloader import FakeDownloader
    from .fake_filesystem_handler import FakeFilesystemHandler

    import tempfile
    import shutil
    import datetime
    import time

    downloader = FakeDownloader({})
    tmpdir = tempfile.mkdtemp()
    fh = FakeFilesystemHandler(FakeFilesystem(tmpdir))
    fh.open('foo', 'wb')
    fh.write('foo', 'foo')
    fh.close('foo')
    postprocess = PostProcessor(downloader)
    try:
        postprocess.try_utime('foo', 1000., 2000., 'error')
        postprocess.try_utime('bar', 1000., 2000., 'error')
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:13:28.428623
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from tempfile import TemporaryDirectory
    from datetime import datetime

    with TemporaryDirectory() as tempdir:
        test_file = 'test.txt'
        test_file_full = os.path.join(tempdir, test_file)

        # Write file
        with open(test_file_full, 'wb') as f:
            f.write(b'test')

        # Get file stats
        stat_1 = os.stat(test_file_full)

        # Instantiate postprocessor
        pp = PostProcessor(YoutubeDL())

        # Update stats
        pp.try_utime(test_file_full, stat_1.st_atime, int(datetime(2012, 1, 1).strftime('%s')))

        # Check if stats are updated
        stat_

# Generated at 2022-06-12 19:13:34.901921
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test_file.ts')
    with open(test_file, "w") as output:
        output.write("test")

    # Get the current modification time
    test_time = os.stat(test_file).st_mtime

    # Call try_utime with a time that is the same as the current one
    # This should do nothing
    pp = PostProcessor(None)
    pp.try_utime(test_file, test_time, test_time)

    # After the call, the modification time should not have changed
    assert int(os.stat(test_file).st_mtime) == int(test_time)

    # TODO: Add more tests

# Generated at 2022-06-12 19:13:39.644737
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeYDL

    pp = PostProcessor(FakeYDL())
    pp.try_utime('/tmp/ytdl_test_file', 150000000, 160000000)



# Generated at 2022-06-12 19:13:50.841837
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    This test is a "unit test" that shows how to use
    the method try_utime of class class PostProcessor
    to change the modified and access time of a file.

    Note that this test is not a unit test in the strict sense
    of the term, but it is written with the idea and the structure
    of a unit test in mind.

    Please, pay attention that it is not necessary to use class
    PostProcessor for that purpose. You can easily use other python
    constructs and even the shell to change the modified and access
    time of a file. The purpose of this test is just to show a
    concrete usage of method try_utime of class PostProcessor.

    """
    from ..downloader import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..compat import compat_http_client

# Generated at 2022-06-12 19:14:02.596528
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil

    from ..compat import (
        compat_makedirs,
        compat_os_name,
        compat_path,
        compat_tempfile,
        compat_wget,
    )

    if compat_os_name == 'nt':
        import stat

        def set_readonly(filename):
            os.chmod(encodeFilename(filename), stat.S_IREAD)

        def set_writable(filename):
            os.chmod(encodeFilename(filename), stat.S_IWRITE)
    else:
        def set_readonly(filename):
            os.chmod(encodeFilename(filename), 0o444)

        def set_writable(filename):
            os.chmod(encodeFilename(filename), 0o666)


# Generated at 2022-06-12 19:14:12.834061
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader:
        def report_warning(self, message):
            print(message)

    pp = PostProcessor(DummyDownloader())
    path = '/foo/bar'

    # os.utime raises OSError with errno.ENOENT
    try:
        os.utime = lambda path, t: 1/0 # Raise exception
    except Exception:
        pp.try_utime(path, 0, 0)

    # os.utime raises OSError with other errno's
    try:
        os.utime = lambda path, t: 1/0 # Raise exception
    except Exception:
        pp.try_utime(path, 0, 0, errnote='foo')

# Generated at 2022-06-12 19:14:22.495160
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..compat import compat_tempfile
    from .files import FileDownloader
    from .extractor import gen_extractors
    d = FileDownloader({'nopart': True, 'prefer_ffmpeg': True, 'quiet': True, 'skip_download': True})
    d.add_info_extractor(gen_extractors()[0])
    d.add_post_processor(FFmpegMetadataPP(d), 'ffmpeg_metadata')
    tmp_filename = tempfile.NamedTemporaryFile(suffix='.mp3').name
    with open(tmp_filename, 'wb') as f:
        f.write(b'hi')  # A file too small to be playable but bigger than 0

# Generated at 2022-06-12 19:14:30.786789
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys

    if sys.platform.startswith('win'):
        raise unittest.SkipTest('utime not supported on Windows')

    class FakeDownloader():
        def __init__(self, test):
            self._test = test

        def report_warning(self, message):
            self._test.assertEqual(message, "Cannot update utime of file")

    class TestPostProcessor(PostProcessor):
        pass

    with tempfile.NamedTemporaryFile(delete=False) as f:
        name = f.name


# Generated at 2022-06-12 19:14:40.047664
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """test try_utime method of class PostProcessor"""
    post_processor = PostProcessor()
    class TestDownloader:
        """test class of TestDownloader"""
        def report_warning(self, errnote):
            """test method of class TestDownloader"""
            if errnote == 'Cannot update utime of file':
                print('Test pass')
        params = {'postprocessor_args': ['Test']}
    from types import MethodType
    post_processor.try_utime('/', '', '')
    post_processor.try_utime = MethodType(PostProcessor.try_utime, post_processor, TestDownloader())
    post_processor.try_utime('/', '', '')

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:14:42.071803
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Unit test will not build at the moment due to issues with the
    # test infrastructure
    pass

# Generated at 2022-06-12 19:14:48.389789
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        # pylint: disable=attribute-defined-outside-init
        class Downloader(object):
            params = {}
        class PostProcessor(object):
            def __init__(self):
                self._downloader = Downloader()
        pp = PostProcessor()
        pp.try_utime('/tmp/1', 1, 1)
    except Exception:
        pass



# Generated at 2022-06-12 19:14:58.779676
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import stat
    import tempfile
    import shutil
    import os
    import sys

    if sys.platform == 'win32':
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:15:10.937865
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    pp = PostProcessor(None)
    # create a temporary file
    tmpfile = tempfile.mkstemp()[1]
    # touch the temporary file and save the current timestamp
    (modtime, actime) = time.time(), time.time()
    os.utime(tmpfile, (actime, modtime))
    # wait 1 second and call try_utime with the old time stamp
    time.sleep(1)
    pp.try_utime(tmpfile, actime, modtime)
    # if the timestamp were updated, then the following would raise an OSError exception
    os.utime(tmpfile, (actime, modtime))
    os.unlink(tmpfile)

# Generated at 2022-06-12 19:15:15.617410
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        pp = PostProcessor()
        pp.try_utime('not_existing_file', 0, 0)
    except PostProcessingError:
        assert False, 'try_utime should not raise exception with not existing file'


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:15:22.249836
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func

    ie = get_info_extractor('Youtube', 'test')
    test = ie.suitable(u'http://www.youtube.com/watch?v=BaW_jenozKc')
    assert test is True

    params = {'noplaylist': True, 'preferredcodec': 'mp3', 'preferredquality': '1', 'format': 'bestaudio/best', 'postprocessor_args': '-ss %(start_time)s -to %(end_time)s'}

# Generated at 2022-06-12 19:15:32.834302
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_postprocessor_helpers import _PostProcessorHelper

    class _PostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(_PostProcessor, self).__init__(downloader)
            self.testhelper = _PostProcessorHelper()
        def run(self, information):
            self.try_utime(self.testhelper.fname, 1, 2)
            return []

    helper = _PostProcessorHelper(
        fname='filename',
        fsize=1,
    )

    pp = _PostProcessor(helper.downloader)
    pp.testhelper = helper
    pp.run({})

    helper.check_atime(1)
    helper.check_mtime(2)

# Generated at 2022-06-12 19:15:39.626289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .compat import mock

    pp = PostProcessor(None)

    with mock.patch('os.utime') as m:
        pp.try_utime(None, None, None)
        m.assert_called_with(None, (None, None))

    with mock.patch('os.utime') as m:
        m.side_effect = IOError()
        pp.try_utime(None, None, None)

# Generated at 2022-06-12 19:15:46.314994
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import os
    import sys
    import tempfile
    import subprocess as sp

    if os.name == 'nt':
        import ctypes
        # make sure that there is write permission to the directory
        # by removing the read-only attribute
        def remove_readonly(func, path, _):
            "Clear the readonly bit and reattempt the removal"
            os.chmod(path, stat.S_IWRITE)
            func(path)

        ctypes.windll.kernel32.SetErrorMode(1)
        ctypes.windll.kernel32.SetErrorMode(0)
        shutil.rmtree("tests/temp", onerror=remove_readonly)
    else:
        shutil.rmtree("tests/temp")

# Generated at 2022-06-12 19:15:54.614241
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    # Create a temporary file
    import tempfile
    (tf, tf_path) = tempfile.mkstemp(prefix='postprocessor_test', suffix='_ext')
    os.close(tf)

    # Remove it
    os.remove(tf_path)

    # Try to update its modification time
    pp.try_utime(tf_path, 0, 0)

    # Check whether it exists
    assert os.path.exists(tf_path)

if __name__ == '__main__':
    # Run the tests
    import sys
    import nose

    sys.argv.append('--verbose')
    sys.argv.append('--nocapture')
    nose.runmodule()

# Generated at 2022-06-12 19:16:02.383167
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os

    testfile = tempfile.NamedTemporaryFile(delete=False)
    testfile.close()
    try:
        # Modify time
        os.utime(testfile.name, (1330963585, 1330963585))

        postProcessor = PostProcessor(None)
        postProcessor.try_utime(testfile.name, 1330963585, 1330963589, errnote="test")
        # Check time is modified
        assert os.stat(testfile.name).st_mtime == 1330963589
    finally:
        os.unlink(testfile.name)


# Generated at 2022-06-12 19:16:12.369091
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import calendar
    import errno
    from ..downloader.common import FileDownloader

    class FakeOs(object):
        def utime(self, path, times):
            self.path = path
            self.times = times

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote
            raise IOError(errno.EACCES, 'Permission denied')

    # test with a real os, without error
    pp = PostProcessor()

# Generated at 2022-06-12 19:16:24.402196
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys

    # Create Postprocessor object to test
    postprocessor = PostProcessor()

    # Mocking of the method report_warning to avoid error
    # (we do not want to test this method)
    def report_warning(self, str):
        print(str)

    # Mocking of the method params[] to avoid error
    # (we do not want to test this method)
    def params(self, str):
        None

    # Add the mocking method to the object
    postprocessor.report_warning = report_warning
    postprocessor.params = params

    # To test the method, we need a file

# Generated at 2022-06-12 19:16:39.260778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO
    pass

# Generated at 2022-06-12 19:16:51.292929
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import tempfile
    from ..utils import encodeFilename

    if sys.platform.startswith('win32'):
        print('No test for utime on Windows')
        return

    tfn = encodeFilename(tempfile.mkstemp()[1])

    with open(tfn, 'w') as f:
        f.write('test')

    # os.utime(fn, None) calls os.stat() and sets the access/modified times
    # of the file to the current time
    test_time = os.stat(tfn).st_atime + 1

    pp = PostProcessor(None)
    pp.try_utime(tfn, test_time, test_time)

    s = os.stat(tfn)
    assert s.st_atime == test_time
   

# Generated at 2022-06-12 19:16:55.987019
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # PostProcessor.try_utime does not error out when file does not exist
    try:
        PostProcessor().try_utime('does-not-exist', 0, 0, 'test_msg')
    except OSError as e:
        raise AssertionError('When file does not exist OSError should not be raised')
    except Exception as e:
        raise AssertionError('When file does not exist exception %s should not be raised' % type(e))
    else:
        pass

# Generated at 2022-06-12 19:17:05.552953
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from ..YoutubeDL import YoutubeDL
    from ..utils import encodeFilename
    dl = YoutubeDL(params={'outtmpl': tempfile.mktemp(suffix='.%(ext)s')})
    pp = PostProcessor(dl)
    # Create temp file to avoid unpredicted error
    test_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    # Get access and modification time of test_file
    test_file_stat_info = os.stat(test_file.name)
    # Set timestamp
    try:
        os.utime(test_file.name, None)
    except OSError:
        # Set fallback timestamp
        timestamp = time.time()

# Generated at 2022-06-12 19:17:16.919384
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeYDL
    from .FakeFileDownloader import FakeFileDownloader

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            file_name = info['filepath']
            atime = int(info['mtime'])
            mtime = int(info['mtime'])
            self.try_utime(file_name, atime, mtime, errnote='Throws an error')
            return file_name

    ffdl = FakeFileDownloader({}, FakeYDL())
    pp = DummyPostProcessor(ffdl)
    test_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    test_file_name = '04-baw_jenozkc.webm'

# Generated at 2022-06-12 19:17:23.248409
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        pass

    # Use mock for reporting warnings
    from unittest.mock import MagicMock
    class MockDownloader(object):
        report_warning = MagicMock()

    pp = TestPostProcessor(downloader=MockDownloader())
    path = 'path_to_file'

    # Test working utime()
    pp.try_utime(path, 1, 2)
    assert MockDownloader.report_warning.called is False

    # Test failing utime()
    MockDownloader.report_warning.reset_mock()    # Reset Mock for new test
    pp.try_utime(path, 1, 2, errnote='Test_Message')
    MockDownloader.report_warning.assert_called_with('Test_Message')

# Generated at 2022-06-12 19:17:29.979554
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL

    class MockDownloader(YoutubeDL):
        def __init__(self):
            YoutubeDL.__init__(self)
            self.report_warning_called = False

        def report_warning(self, msg):
            self.report_warning_called = True

    downloader = MockDownloader()
    p = PostProcessor(downloader)
    p.try_utime("/dummy/path", 1, 2)
    assert not downloader.report_warning_called

    from pytest import raises
    raises(Exception, p.try_utime, "/dummy/path", 1, 2, errnote="")
    assert downloader.report_warning_called

# Generated at 2022-06-12 19:17:32.503005
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor(None)
    # create a dummy file
    TESTFN = '$testfile'
    with open(encodeFilename(TESTFN), 'wb') as f:
        f.write(b'foo')
    p.try_utime(TESTFN, 0, 0)
    os.remove(encodeFilename(TESTFN))

# Generated at 2022-06-12 19:17:34.773778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    postprocessor = PostProcessor(ydl)
    postprocessor.try_utime('', 0.0, 0.0)



# Generated at 2022-06-12 19:17:45.886065
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test PostProcessor's method try_utime.
    """

    import unittest

    import shutil

    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from .common import PostProcessorTestCase

    class FakeFileDownloader(FileDownloader):
        def __init__(self, params, report_warning):
            self.params = params
            self.report_warning = report_warning

    class TestPP(PostProcessor):
        def __init__(self, *args, **kargs):
            PostProcessor.__init__(self, *args, **kargs)
            self.last_name = None

        def test_utime(self, path, atime, mtime):
            self.last_name = path

# Generated at 2022-06-12 19:18:13.229962
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    return True

# Generated at 2022-06-12 19:18:18.910819
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import tempfile
    import time
    import shutil
    from ..compat import compat_os_name

    def _get_atime_mtime(dummy_postprocessor, file_path):
        """
        Get atime and mtime of a file, which may be express as float (Windows)
        or int (Linux).
        """
        atime = os.path.getatime(encodeFilename(file_path))
        mtime = os.path.getmtime(encodeFilename(file_path))
        if not (sys.platform == 'win32' or sys.platform == 'cygwin'):
            assert isinstance(atime, int), \
                '%r is not an int but a %r' % (atime, type(atime))

# Generated at 2022-06-12 19:18:26.879197
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Mocking fails on Windows: http://bugs.python.org/issue5105
    import sys
    if sys.platform == 'win32':
        return

    import os
    import time
    import mock
    from ..utils import encodeFilename
    from ..compat import compat_os_name

    def get_utime(path):
        return os.stat(encodeFilename(path)).st_atime, os.stat(encodeFilename(path)).st_mtime

    pp = PostProcessor(None)

    if not compat_os_name == 'nt':  # on Windows, os.utime raises OSError 'Operation not permitted'
        pp.try_utime('jkfh', 1, 2, errnote='test')

    with mock.patch('os.utime') as mock_utime:
        mock_ut

# Generated at 2022-06-12 19:18:31.777140
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    dl = None

    class FakeDownloader:
        def report_warning(self, text):
            assert text == 'Cannot update utime of file'
    dl = FakeDownloader()
    pp.set_downloader(dl)
    pp.try_utime('dummy', 1000000000, 1000000000, 'Cannot update utime of file')

# Generated at 2022-06-12 19:18:33.302595
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO: implement this
    assert 2 == 1, "Not implemented yet"


# Generated at 2022-06-12 19:18:42.416541
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test that try_utime updates utime of the file twice.
    """
    class MyPostProcessor(PostProcessor):
        def run(self, information):
            return self.try_utime(information['filepath'], 1483228800, 1483228800)
    import sys
    import time
    import datetime
    from .test_download import global_tests_dir
    from .test_download import _FakeYDL
    # Create a fake file for testing
    file_name = os.path.join(global_tests_dir, 'test_utime')
    with open(file_name, 'wb') as f:
        f.write('')
    f.close()
    # get modification time
    mod_time = os.path.getmtime(file_name)
    st = os

# Generated at 2022-06-12 19:18:47.198269
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import io

    # pretend stdout is a terminal, so progress bar will start
    sys.stdout = io.BytesIO()
    _downloader = None
    pp = PostProcessor(_downloader)
    try:
        pp.try_utime("test_downloader.py", 1, 2)
    except IOError:
        pass  # that's what we expected to have
    else:
        assert False, "Should have raised IOError"

    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 19:18:47.770205
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:18:56.301046
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    from .tests import PostProcessorTest

    date_range = DateRange(start=0, end=None)
    params = {'format': 'best'}
    downloader = FileDownloader(params)
    preprocessor = PostProcessor(downloader)
    preprocessor.try_utime(PostProcessorTest.FAKEFILEPATH,
                           PostProcessorTest.MODIFICATION_TIME, PostProcessorTest.MODIFICATION_TIME)

    assert os.stat(PostProcessorTest.FAKEFILEPATH).st_mtime == PostProcessorTest.MODIFICATION_TIME
    os.remove(PostProcessorTest.FAKEFILEPATH)

# Generated at 2022-06-12 19:19:01.256061
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader(object):
        def report_warning(self, msg):
            if msg != 'Cannot update utime of file':
                raise AssertionError('Wrong failure message: ' + msg)
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader
    pp = MockPostProcessor(MockDownloader())
    pp.try_utime('', 0, 0)
    pp.try_utime(None, 0, 0)
    pp.try_utime('foo', 0, 0)