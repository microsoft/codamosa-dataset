

# Generated at 2022-06-12 19:09:56.710813
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Unit test for method try_utime of class PostProcessor
    """
    pass

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:10:08.240599
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..utils import get_filesystem_encoding
    from .common import FakeYDL

    with tempfile.NamedTemporaryFile() as temp:
        fs_encoding = get_filesystem_encoding()
        temp_fn = encodeFilename(temp.name)
        ydl = FakeYDL()
        pp = PostProcessor(ydl)
        pp.run({'filepath': temp_fn, 'title': 'Sample video'})
        assert not os.path.exists(temp_fn + '.part')
        assert os.path.exists(temp_fn)

    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    pp._downloader.params['outtmpl'] = temp_fn + '.%(ext)s'

# Generated at 2022-06-12 19:10:18.157758
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import metadata_compat_test
    code = metadata_compat_test.test_metadata_compat()

    # Test is useful only if the test file is in a directory where you
    # can write
    import stat
    st = os.stat(code[0])
    mode = st[stat.ST_MODE]
    if (mode & stat.S_IWUSR) == 0:
        return

    pp = PostProcessor(downloader=None)

    atime, mtime = code[2], code[3]
    pp.try_utime(code[0], atime, mtime)

    st = os.stat(code[0])
    atime_new = st[stat.ST_ATIME]
    mtime_new = st[stat.ST_MTIME]
    assert atime_new == atime

# Generated at 2022-06-12 19:10:20.227257
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    from tempfile import NamedTemporaryFile

# Generated at 2022-06-12 19:10:26.126078
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import compat_tempfile
    from .common import PostProcessorTest

    class test_PostProcessor_try_utime_PostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info["filepath"], 666, 777)
            return ([], info)

    info = {
        'id': '0',
        'title': 'test_PostProcessor_try_utime_PostProcessor',
        'ext': 'unknown',
    }
    with PostProcessorTest(test_PostProcessor_try_utime_PostProcessor) as pp_test:
        pp_test.run_and_raise(info, raise_all=True)

    with PostProcessorTest(test_PostProcessor_try_utime_PostProcessor) as pp_test:
        pp

# Generated at 2022-06-12 19:10:37.663107
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp
    from time import sleep
    from datetime import datetime
    (fd, filepath) = mkstemp()
    # Create a file and leave it empty
    os.close(fd)
    # Sleep because utime doesn't work correctly if the timestamp is equal to the moment the file was created
    sleep(1)
    current_time = datetime.utcnow()  # This is the atime to set
    pp = PostProcessor(None)
    pp.try_utime(filepath, current_time.timestamp(), current_time.timestamp())

# Generated at 2022-06-12 19:10:47.622329
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from tempfile import mkstemp
    from ..YoutubeDL import YoutubeDL
    from ..extractor import *

    def my_hook(d):
        if d.get('status') == 'finished':
            d['postprocessor_args'] = {
                'key': 'value',
            }
        else:
            d['postprocessor_args'] = {
                'extra': ['-x', 'arg'],
            }
    ydl = YoutubeDL(params={
        'logger': YoutubeDL.logger_object,
        'simulate': True,
        'progress_hooks': [my_hook],
    })
    ext = object.__new__(TypeRegistry.downloader_classes()['generic'])
    ext.ydl = ydl

# Generated at 2022-06-12 19:10:52.989405
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from tempfile import NamedTemporaryFile
    from time import gmtime, strftime, strptime, mktime

    class InfoObject(object):
        pass

    class DownloaderObject(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *args, **kwargs: None
            self.report_warning = lambda *args, **kwargs: None

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], information['timestamp'],
                           information['timestamp'])
            return [], information

    info = InfoObject()

# Generated at 2022-06-12 19:10:59.184589
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from io import open
    from tempfile import NamedTemporaryFile
    from .compat import filesystem_encoding

    # Create a non-existing file
    with NamedTemporaryFile(delete=False) as f:
        f.close()
        os.remove(f.name)
    file_path = f.name

    # When trying to update the utime of a non-existing file,
    # the method should show a warning message
    pp = PostProcessor(None)
    pp.try_utime(file_path, 0, 0)

    # Create the file
    with open(file_path, 'w'):
        pass

    # Update the utime of the file
    pp.try_utime(file_path, 0, 0)

    os.unlink(file_path)

# Generated at 2022-06-12 19:11:07.867202
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import shutil

    class DummyPostProcessor(PostProcessor):
        def __init__(self):
            self.calls = []
            self.errnote = ''

        def run(self, info):
            self.calls.append(('run', info))
            return [], info

        def report_warning(self, errnote):
            self.calls.append(('warning', errnote))
            self.errnote = errnote

    tmpdir = tempfile.mkdtemp()
    pp = DummyPostProcessor()
    info = { 'filepath': tmpdir }

    # test file to test utime function with
    test_file = os.path.join(tmpdir, "test_file")
    open(test_file, 'wb').close()


# Generated at 2022-06-12 19:11:18.141846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os

    # Create dummy file
    fd, tmp = tempfile.mkstemp()
    os.close(fd)

    # Create PostProcessor
    pp = PostProcessor(None)

    # Change times of dummy file
    old_atime = -1
    old_mtime = -1
    pp.try_utime(tmp, old_atime, old_mtime)

    # Assert has changed
    assert os.stat(tmp).st_atime == old_atime
    assert os.stat(tmp).st_mtime == old_mtime

    # Clean up
    os.remove(tmp)

# Generated at 2022-06-12 19:11:26.407428
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile

    test_path = tempfile.mkstemp()[1]
    test_mtime = sys.maxsize if sys.maxsize <= 2**32 else 2**32
    test_atime = int(test_mtime/2)

    class TestPostProcessor(PostProcessor):
        pass

    tpp = TestPostProcessor()
    tpp.try_utime(test_path, test_atime, test_mtime)

# Generated at 2022-06-12 19:11:31.801166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 1000, 2000)
            return [], info

    dpp = DummyPP()
    assert dpp._configuration_args() == []
    assert dpp._configuration_args(['-c', 'best']) == ['-c', 'best']

# Generated at 2022-06-12 19:11:35.446283
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test try_utime of PostProcessor class
    import tempfile
    import time
    from ..downloader import FileDownloader
    from ..postprocessor import PostProcessor
    postprocessor = PostProcessor(FileDownloader())
    filename = os.path.join(tempfile.gettempdir(), 'YTDL_PostProcessor_Test.tmp')
    with open(filename, 'w') as f:
        f.write('content')
    postprocessor.try_utime(filename, 1000, 1000)
    assert os.path.getatime(filename) == os.path.getmtime(filename) == 1000
    os.remove(filename)

# Generated at 2022-06-12 19:11:44.080458
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    from tempfile import mkstemp
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        pytest.skip('Not running postprocessing tests on Windows. See https://github.com/rg3/youtube-dl/issues/1463')

    # create dummy file
    fd, tmp = mkstemp()
    os.close(fd)
    atime = os.path.getatime(tmp)
    mtime = os.path.getmtime(tmp)

    pp = PostProcessor(None)
    pp.try_utime(tmp, atime, mtime,
                 errnote='failed to adjust file time')

    os.unlink(tmp)

# Unit test PostProcessor class

# Generated at 2022-06-12 19:11:48.448223
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    from .postprocessor import FFmpegPostProcessor
    pp = FFmpegPostProcessor(ydl)
    pp.try_utime(None, None, None)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:11:57.270721
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import YoutubeDL
    import os
    import sys

    def fakeutime(*args): # pylint: disable=unused-argument
        raise OSError(1, '(utimefake) Operation not permitted', 'utimefake')

    orig_utime = os.utime
    orig_excepthook = sys.excepthook
    os.utime = fakeutime

# Generated at 2022-06-12 19:12:04.727122
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    pp = PostProcessor()

    # Create a file
    tempfilename = os.path.join(os.path.dirname(__file__), "test.tmp")
    open(tempfilename, "w").close()

    # Get the current timestamp
    timestamp = os.path.getmtime(tempfilename)

    # Change the modification and access times
    pp.try_utime(tempfilename, timestamp + 10, timestamp + 10)

    # Check that the modification and access times have been modified
    assert timestamp != os.path.getmtime(tempfilename)
    assert timestamp != os.path.getatime(tempfilename)

# Generated at 2022-06-12 19:12:11.034663
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        from ..downloader.common import FileDownloader
        from ..extractor.common import InfoExtractor
    except ImportError:
        return
    d = FileDownloader({})
    d.add_info_extractor(InfoExtractor())
    pp = PostProcessor(d)
    pp.try_utime("testdata/testvideo.mp4", 0, 0, "")

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:12:18.572267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Mock class for testing
    class Downloader(object):
        def report_warning(self, errnote):
            self.errnote = errnote

    pp = PostProcessor(Downloader())

    test_path = 'test_path'
    # Test it works
    pp.try_utime(test_path, 1477633658, 1477633658)
    assert not hasattr(pp._downloader, 'errnote')

    # Test failure
    pp.try_utime('non_existent_file', 1477633658, 1477633658)
    assert pp._downloader.errnote == 'Cannot update utime of file'


# Generated at 2022-06-12 19:12:26.818117
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.downloader.common import FileDownloader
    # Create a new FileDownloader
    fd = FileDownloader()
    # Create a new PostProcessor
    pp = PostProcessor(fd)
    # Initialize
    fd.initialize()
    # Get the temp file
    temp_file = os.path.join(fd.writedir, 'youtube-dl_tmp_id')
    # Create a new file
    open(temp_file, mode='w').close()
    # Try utime
    pp.try_utime(temp_file, None, None)
    # Check if it has been modified
    stat = os.stat(temp_file)
    assert stat.st_atime != 0 and stat.st_mtime != 0
    # Remove the file
    os.remove(temp_file)

# Generated at 2022-06-12 19:12:37.784057
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import datetime
    from tempfile import mkstemp
    import os, sys

    class TestDownloader(object):
        def report_warning(self, msg):
            self.warning_msg = msg

    pp = PostProcessor(TestDownloader())

    # Try to set the utime of a non-existing file
    self_closed, fname = mkstemp()

# Generated at 2022-06-12 19:12:38.325462
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:12:49.225291
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)

# Generated at 2022-06-12 19:12:58.005425
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestDownloader():
        def __init__(self):
            self._errnote = None
            self._warning_count = 0

        def report_warning(self, msg):
            self._errnote = msg
            self._warning_count += 1

    td = TestDownloader()
    pp = PostProcessor(td)

    path = encodeFilename('/tmp/')
    pp.try_utime(path, 1, 2)

    path = encodeFilename('/tmp/foo')
    pp.try_utime(path, 1, 2)
    assert td._errnote == 'Cannot update utime of file'
    assert td._warning_count == 1

# Generated at 2022-06-12 19:13:06.204613
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # See https://github.com/ytdl-org/youtube-dl/issues/10103
    # This test reproduces that issue and checks that the
    # method PostProcessor.try_utime() doesn't raise an exception.
    # That method can't change the time of a file on Windows if
    # that file is open. Unfortunately, the Windows test bots
    # open the downloaded file and this breaks this test.
    # So we skip this test on the Windows bots.
    import sys
    if sys.platform not in ['win32', 'cygwin']:
        import shutil
        import tempfile
        import atexit
        import time
        import errno
        from ..utils import locked_file
        from ..compat import setutime

        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:13:14.510128
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import re
    import tempfile
    import shutil
    import mock
    import time
    from datetime import datetime
    from ..utils import has_unicode_filename

    tmppath = tempfile.mkdtemp()
    if not has_unicode_filename():
        tmppath = tmppath.encode('utf-8')

    # Create a temporary file
    fn = os.path.join(tmppath, 'a')
    shutil.copyfile(os.path.join(os.path.dirname(__file__), 'test.mp4'), fn)

    # Check initial modification time
    stat_a = os.lstat(fn)

    # Prepare PostProcessor
    pp = PostProcessor(None)

    # Check utime on file when given correct arguments
    pp.try_utime

# Generated at 2022-06-12 19:13:22.585791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader(object):
        def report_warning(self, errnote):
            pass

    class MockPostProcessor(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            pass

    mock_pp = MockPostProcessor(MockDownloader())
    mock_pp.try_utime('temp', 0, 0, errnote='Cannot update utime of file')


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:13:25.559664
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader({})
    postprocessor = PostProcessor(downloader)
    postprocessor.try_utime('test', 'test', 'test')

# Generated at 2022-06-12 19:13:33.400129
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    def get_lmt(fn):
        st = os.stat(fn)
        return (st[stat.ST_MTIME], st[stat.ST_ATIME])

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:13:47.206072
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        pass

    class MockDownloader():
        def report_warning(self, errnote):
            assert errnote == 'Cannot update utime of file'

    mock_pp = MockPostProcessor(MockDownloader())
    os.utime = lambda *args: None
    mock_pp.try_utime('/tmp/foo', 10, 20, errnote='Cannot update utime of file')

    os.utime = lambda *args: 1 / 0
    mock_pp.try_utime('/tmp/foo', 10, 20)

# Generated at 2022-06-12 19:13:55.251062
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .YoutubeDL import YoutubeDL
    from .utils import DateRange

    class MockPostProcessor(PostProcessor):
        def __init__(self):
            super(MockPostProcessor, self).__init__()
            self.utime_errors = []

        def run(self, information):
            self.try_utime(information, 1111, 2222, 'fail1')
            self.try_utime(information, 1111, 2222, 'fail2')
            return [], information

        def report_warning(self, msg):
            self.utime_errors.append(msg)


# Generated at 2022-06-12 19:14:05.450866
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2
    from functools import partial
    from tempfile import NamedTemporaryFile

    # For this unit test, we create a post-processor class that
    # will save a list of call arguments
    global target_utime
    target_utime = []
    class PostProcessor(object):
        def try_utime(self, path, atime, mtime, errnote):
            global target_utime
            target_utime.append((path, atime, mtime, errnote))

    # We also create a fake os module that will prevent os.utime from
    # updating the file timestamps.
    class FakeOsModule(object):
        def utime(self, path, times):
            """
            We emulate a utime system call that fails
            """

# Generated at 2022-06-12 19:14:15.864366
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import sys
    try:
        import pytest
        from py._path.local import LocalPath
    except ImportError:
        pytest = None
    try:
        from mutagen.mp3 import MP3
    except ImportError:
        MP3 = None

    if sys.version_info >= (3, 0, 0) and pytest is not None:
        import io
        # python 3.x
        # create a temporary directory
        tmpdir = LocalPath(tempfile.mkdtemp())

        # create a test file
        f = tmpdir.join('test.mp3')
        f.write('hello world')

        # run method try_utime with different parameters
        pp = PostProcessor(None)

# Generated at 2022-06-12 19:14:26.257791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil, tempfile, time
    from ..utils import DateRange

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:14:26.726282
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:14:35.608882
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    from ..compat import _create_unverified_https_context

    # Since Python 2.6.3, ssl is imported only when accessing the module
    # _create_unverified_https_context is available from Python 2.7.9 and 3.4.3.
    # For 3.2 and 3.3, this is necessary to avoid an error on Travis
    if hasattr(time, 'strptime') and hasattr(tempfile, 'mkdtemp'):
        import ssl
        if not hasattr(ssl, '_create_unverified_context'):
            ssl._create_unverified_context = _create_unverified_https_context

        import stat
        import shutil
        import subprocess
        import os

        from ..utils import date_from_str

        pp = PostProcess

# Generated at 2022-06-12 19:14:46.807808
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:14:57.416424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # For this test, we pretend the file does not exist
    import tempfile
    filename = tempfile.mktemp()

    # We create a PostProcessor object (but we don't need to call
    # its run() method)
    from ..extractor import YoutubeDL
    downloader = YoutubeDL({})
    pp = PostProcessor(downloader)

    # First, we test that utime is called with proper arguments
    import os.path
    import time
    import os
    atime = time.time() - 1000
    mtime = time.time() - 2000
    os.utime = lambda path, times: pp.try_utime(path, *times)
    pp.try_utime(filename, atime, mtime)
    assert os.path.getatime(filename) == atime
    assert os.path.get

# Generated at 2022-06-12 19:15:07.037853
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'writedescription': False, 'forcejson': True, 'ignoreerrors': False})

    def mock_report_warning(msg):
        print(msg)

    ydl._report_warning = mock_report_warning

    ydl.add_post_processor(PostProcessor(ydl))

    import tempfile
    import shutil
    import time
    import os

    tmpdir = tempfile.mkdtemp()
    print(tmpdir)
    filepath = os.path.join(tmpdir, "foo.txt")
    open(filepath, 'w').close()

    oldtime = time.time()
    time.sleep(0.01)

# Generated at 2022-06-12 19:15:19.256013
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This test must be present in all PostProcessor class
    # because we only test for try_utime method.
    pass

# Generated at 2022-06-12 19:15:30.895956
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    import time
    import stat

    # Make a temporary file
    _fd, file_name = NamedTemporaryFile(delete=False)
    _fd.close()

    # Note the time of file creation
    creation_time = time.time()
    assert creation_time < time.time()

    # Post-process the file
    # (Note that we call both functions with creation_time as argument)
    info = {'filepath': file_name, 'creation_time': creation_time}
    pp = PostProcessor('test')
    deletable_files, info = pp.run(info)

    # Check that the file has been successfully updated
    assert creation_time < time.time()  # If this fails, then the process is too fast to be usable

# Generated at 2022-06-12 19:15:39.627693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import errno
    try:
        os.chmod(__file__, 0)
    except OSError as ose:
        if ose.errno != errno.EPERM:
            raise
    try:
        pp = PostProcessor(None)
        if os.path.exists(__file__):
            pp.try_utime(__file__, 0, 0)
    finally:
        try:
            os.chmod(__file__, 0o666)
        except OSError as ose:
            if ose.errno != errno.EPERM:
                raise

# Generated at 2022-06-12 19:15:51.098841
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO

    from . import YoutubeDL
    from .postprocessor import FFmpegEmbedSubtitlePP

    def _make_faked_downloader(params={}, embed_subtitles=False, subtitles=None):
        class FakeYoutubeDL(YoutubeDL):
            def __init__(self):
                YoutubeDL.__init__(self, params)
                self.to_stdout = BytesIO()
                self.to_stderr = BytesIO()

            def report_warning(self, errnote):
                self.to_stderr.write(errnote.encode('utf-8'))

        ydl = FakeYoutubeDL()

# Generated at 2022-06-12 19:15:59.608699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from unittest import main
    from tempfile import NamedTemporaryFile
    from datetime import datetime
    from pytube.compat import http_server
    import pytube.extractors as extractors
    import pytube.postprocessor as postprocessor
    import pytube.downloader as downloader
    import pytube.exceptions as exceptions
    import pytube.extractor.common as common
    import pytube.request as request
    import os

    class FakeFile:
        def __init__(self, path):
            self.path = path
            self.info = {'url': 'http://127.0.0.1:40000/%s' % path}

        def read(self):
            return open(self.path).read()

    class FakeInfoExtractor(extractors.GenericIE):
        _VALID_

# Generated at 2022-06-12 19:16:06.873039
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdl.YoutubeDL import YoutubeDL
    from .common import FakeYDL
    import datetime
    import time
    import os

    filename = 'test.mp3'
    filedata = b'test data'

    # Create a temporary file
    with open(filename, 'wb') as f:
        f.write(filedata)
    # Set file modification and access times
    now = datetime.datetime.now()
    now = time.mktime(now.timetuple())
    os.utime(filename, (now - 10, now - 10))
    # Initialize the PostProcessor object
    ydl = YoutubeDL(FakeYDL())
    pp = PostProcessor(ydl)
    # Set file modification and access times to future

# Generated at 2022-06-12 19:16:14.654699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
#   from .postprocessor import PostProcessor
    from ..utils import sanitize_open
    from sys import version_info
    import tempfile
    import platform
    import os
    import atexit
    import time

    if platform.system() == 'Windows': # windows does not support utime()
        return
    # Create a temporary directory
    tmp = tempfile.mkdtemp(prefix="yt-pp-test")
    atexit.register(lambda: os.removedirs(tmp))
    # Create a dummy downloader
    downloader = FileDownloader(params={})
    # Create a dummy postprocessor
    pp = PostProcessor(downloader)
    testfile = os.path.join(tmp, "utime_testfile")

# Generated at 2022-06-12 19:16:26.685764
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import platform

    test_dir = tempfile.mkdtemp(prefix='yl_unittests')

    old_stat_follow_symlinks = None
    if hasattr(os, 'stat'):
        old_stat_follow_symlinks = os.stat_float_times
        os.stat_float_times = False

    def _clean_up():
        if old_stat_follow_symlinks is not None:
            os.stat_float_times = old_stat_follow_symlinks
        shutil.rmtree(test_dir)


# Generated at 2022-06-12 19:16:38.764598
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL
    from ..compat import compat_mock

    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    path = 'TEST_FILE'

    m = compat_mock.Mock()
    with compat_mock.patch('os.utime', m):
        pp.try_utime(path, 1, 2)
        m.assert_called_with('TEST_FILE', (1, 2))

    m = compat_mock.Mock()
    with compat_mock.patch('os.utime', m):
        pp.try_utime(path, 1, 2, errnote='ERR_NOTE')
        m.assert_called_with('TEST_FILE', (1, 2))
        ydl.to_screen.assert_not_called

# Generated at 2022-06-12 19:16:50.926235
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil

    class _TestDownloader(object):
        def __init__(self):
            self._warning_count = 0
        def to_screen(self, message):
            print(message)
        def report_warning(self, message):
            self._warning_count += 1
        def warning_count(self):
            return self._warning_count

    class _TestPostProcessor(PostProcessor):
        pass

    with open('test_file', 'w') as f:
        f.write('1')

    old_mtime = os.path.getmtime('test_file')
    dld = _TestDownloader()
    pp = _TestPostProcessor(dld)
    pp.try_utime('test_file', old_mtime, old_mtime)

# Generated at 2022-06-12 19:17:23.075090
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    import time
    import tempfile
    import shutil

    class _DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
            self.has_been_called = False

        def run(self, information):
            self.try_utime(information['filepath'], information['atime'], information['mtime'])
            self.has_been_called = True
            return [], {}

    pp = _DummyPostProcessor(None)

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-12 19:17:30.520143
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(
                information[u'filepath'],
                information.get(u'test_atime', None),
                information.get(u'test_mtime', None))
            return [], information

    import os
    import tempfile
    import shutil

    ffmpeg_postprocessor = TestPostProcessor()
    tmpdir = tempfile.mkdtemp(u'testyoutubedl')
    filepath = os.path.join(tmpdir, u'file')
    with open(filepath, 'w') as f:
        f.write(u'')

    # test filepath with non-ascii character

# Generated at 2022-06-12 19:17:38.022579
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import random
    import time
    import unittest

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    class TestPostProcessor_try_utime(unittest.TestCase):
        def _read_file(self, file_path):
            with open(file_path, 'rb') as file_handler:
                return file_handler.read()
        def _make_stat(self, file_path):
            from ..utils import _decodeFilename
            from stat import ST_ATIME, ST_MTIME
            stat_result = os.stat(file_path)
            stat_dict = {ST_ATIME: stat_result[ST_ATIME], ST_MTIME: stat_result[ST_MTIME]}
            return stat_dict

# Generated at 2022-06-12 19:17:41.677649
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import postprocessor
    import time
    import os

    p = postprocessor.PostProcessor(None)
    p.try_utime('/', time.time(), time.time(), errnote='Cannot update utime of file')

# Generated at 2022-06-12 19:17:52.791637
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    temp_path = tempfile.mkstemp()[1]
    f = open(temp_path, 'w')
    f.write('test_text')
    f.close()
    # Get the original time of the file
    time1 = os.path.getmtime(temp_path)
    time2 = os.path.getmtime(temp_path) + 10
    # Create a PostProcessor
    pp = PostProcessor(None)
    # Change the time of the file
    pp.try_utime(temp_path, time2, time2)
    # Check that time of the file has been changed
    time3 = os.path.getmtime(temp_path)
    assert(time2 == time3)
    # Change the time of the file to the original time
    pp.try_

# Generated at 2022-06-12 19:17:57.163439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        pp.try_utime('/dummy', 1477561770, 1477561770)
    except Exception:
        assert False, 'PostProcessor.try_utime raised an exception'

# Generated at 2022-06-12 19:18:03.758363
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor({})
    testfile = 'postprocessor_test_file'
    open(testfile, 'w').close()
    try:
        os.utime(testfile, ( 1234, 1234))
        pp.try_utime(testfile, 1235, 1235)
        assert os.stat(testfile).st_atime == 1235
        pp.try_utime(testfile, 1236, 1236, errnote='foo')
    finally:
        os.remove(testfile)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:18:10.027997
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    from time import sleep
    p = PostProcessor(None)
    f = NamedTemporaryFile(delete=False)
    atime = mtime = int(f.file.atime())
    sleep(1)
    p.try_utime(f.name, atime, mtime)
    assert (atime, mtime) == (int(f.file.atime()), int(f.file.mtime()))
    os.unlink(f.name)



# Generated at 2022-06-12 19:18:16.064961
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil

    def get_utime(path):
        return os.path.getatime(encodeFilename(path)), os.path.getmtime(encodeFilename(path))

    dir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:18:25.070455
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    class TestingPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.stderr = []

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            PostProcessor.try_utime(self, path, atime, mtime, errnote)

        def to_stderr(self, message):
            self.stderr.append(message)

    pp = TestingPostProcessor()
    pp.to_stderr = lambda message: sys.stderr.write(message)
    pp.try_utime('/path/to/file', 1, 2)

# Generated at 2022-06-12 19:19:24.800845
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from .downloader import FakeYDL
    from .extractor import gen_extractor
    from .info import InfoExtractor
    from ..compat import compat_os_name

    class MockHLSDownloader(object):

        def __init__(self, dl):
            self.ydl = dl

        def report_error(self, msg, tb=None):
            self.ydl.report_warning(msg)

    class MockPostProcessor(PostProcessor):

        def run(self, info):
            hls_dl = MockHLSDownloader(self._downloader)
            tmp_file, tmp_filename = tempfile.mkstemp()
            self.try_utime(tmp_filename, time.time(), time.time(), 'error')

# Generated at 2022-06-12 19:19:25.202516
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:19:31.983977
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..ytdl_config import config
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FFmpegExtractAudioPP
    pp = FFmpegExtractAudioPP(YoutubeDL(params=config.defaults))
    fn = 'utime_test'
    pp.try_utime(fn, 1, 2)
    pp.try_utime(fn, 3, 4, errnote='')
    DateRange.utcfromtimestamp(1)

# Generated at 2022-06-12 19:19:41.824996
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile

    downloader = object()

    def report_warning(testcase, note):
        testcase.assertEqual(note, 'Cannot update utime of file')
    downloader.report_warning = report_warning

    pp = PostProcessor(downloader)

    tmpdir = tempfile.mkdtemp(prefix='ytdl_postprocessor_test_')

# Generated at 2022-06-12 19:19:44.918695
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test if 'errnote' is optional
    # TODO: Add more test cases.
    pp = PostProcessor()
    pp.try_utime('file_name', 0, 0)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:19:50.786857
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    from ..compat import PY2
    from .helpers import temp_dir

    if PY2:
        import imp
    else:
        import importlib.machinery
        import importlib.util

    mod_name = 'mock_downloader'
    if PY2:
        mod = imp.load_source(mod_name, os.path.join(temp_dir, '__init__.py'))
    else:
        loader = importlib.machinery.SourceFileLoader(mod_name, os.path.join(temp_dir, '__init__.py'))
        spec = importlib.util.spec_from_loader(loader.name, loader)
        mod = importlib.util.module_from_spec(spec)
        loader.exec_module(mod)



# Generated at 2022-06-12 19:19:56.925578
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # First, we will create a test file
    TESTFN = 'test.txt'
    with open(TESTFN, 'wb') as f:
        f.write(b'blabla')
    # Second, we will test try_utime
    pp = PostProcessor(None)
    pp.try_utime(TESTFN, 100000, 100000)
    # Third, delete test file
    os.remove(TESTFN)
    return