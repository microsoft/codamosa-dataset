

# Generated at 2022-06-12 19:10:05.980256
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from .common import FileDownloader
    from .rtmpdump import RTMPDownloadErrors

    save_stdout = __builtins__.get('print')

# Generated at 2022-06-12 19:10:10.583803
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Assert that PostProcessor.try_utime() gives the expected results.
    """
    from youtube_dl.YoutubeDL import YoutubeDL
    from io import BytesIO
    post_processor = PostProcessor(YoutubeDL(params={}))

    assert post_processor.try_utime({}, 1, 1, errnote='msg') == None

# Generated at 2022-06-12 19:10:18.715116
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    parent_file = __file__
    if parent_file.endswith('.pyc') or parent_file.endswith('.pyo'):
        parent_file = parent_file[:-1]
    pp = PostProcessor(YoutubeDL())
    assert not os.path.exists(parent_file + '.test')
    open(parent_file + '.test', 'w').close()
    pp.try_utime(parent_file + '.test', 0, 1)
    assert os.path.exists(parent_file + '.test')
    os.remove(parent_file + '.test')

# Generated at 2022-06-12 19:10:24.681650
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information

    postprocessor = TestPostProcessor(downloader=ydl)
    postprocessor.run({'filepath': 'foo'})

# Generated at 2022-06-12 19:10:36.090599
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os.path
    import youtube_dl.postprocessor

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.file')


# Generated at 2022-06-12 19:10:38.895215
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try:
        pp.try_utime('dir/not_existing', 0, 0)
    except OSError:
        pass

# Generated at 2022-06-12 19:10:39.459545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:10:42.227202
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import types
    import errno
    import tempfile
    import shutil
    import time
    import os.path

    tmpdir = encodin

# Generated at 2022-06-12 19:10:49.600259
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    try:
        os.remove('test')
    except os.error:
        pass
    with open('test', 'w') as f:
        pass
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            class MockYDL(object):
                def report_warning(self, errnote):
                    import sys
                    sys.stderr.write(errnote)
            self.set_downloader(MockYDL())

    pp = MockPostProcessor()

    # Test for utime success
    pp.try_utime('test', 0, 0, errnote="test")
    os.remove('test')

    # Test for utime failure
    with open('test', 'w') as f:
        pass

# Generated at 2022-06-12 19:10:56.619617
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    post_processor = PostProcessor()
    path = 'file.txt'
    atime = 3
    mtime = 5
    errnote = 'Test Error Note'
    post_processor_mock = compat_mock.Mock()
    post_processor.set_downloader(post_processor_mock)

    # Test for regular case
    post_processor.try_utime(path, atime, mtime, errnote)
    post_processor_mock.report_warning.assert_not_called()

    # Test for exception case
    post_processor.try_utime(path, atime, mtime, errnote)
    post_processor_mock.report_warning.assert_called_with(errnote)

# Generated at 2022-06-12 19:11:07.432188
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    from shutil import rmtree
    from ..compat import compat_makedirs
    from .common import FileDownloader

    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)

    ydl_opts = {
        'logger': FileDownloader(ydl_opts).logger,
        'outtmpl': '%(id)s.%(ext)s',
        'restrictfilenames': True,
        'noplaylist': True,
        'nocheckcertificate': True,
    }
    downloader = FileDownloader(ydl_opts)

    test_file = os.path.join(tmp_dir, 'test.txt')
    absolute_

# Generated at 2022-06-12 19:11:18.017387
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Test method try_utime of class PostProcessor."""
    import datetime
    import time

    import pytest

    from ..postprocessor import PostProcessor

    pp = PostProcessor({})

    # write a file
    fname = '.test_try_utime'
    f = open(fname, 'w+')
    f.write('test_try_utime')
    f.close()
    # modify its time
    now = time.mktime(datetime.datetime.now().timetuple())
    os.utime(fname, (now, now))
    # try to modify the time
    pp.try_utime(fname, now - 100, now - 100)
    st = os.stat(fname)

# Generated at 2022-06-12 19:11:27.892512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    import tempfile
    from ..compat import compat_pathlib
    test_file = tempfile.mkstemp()[1]
    test_file_path = compat_pathlib.Path(test_file)
    print('Temporary test file: %s' % test_file)
    import time
    pp.try_utime(test_file, time.time(), time.time())
    print('Test file utime: %s' % test_file_path.stat().st_mtime)
    test_file_path.unlink()
    print('Temporary test file deleted')


# Generated at 2022-06-12 19:11:32.483138
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    # Simple class in order to test method try_utime
    class DummyPostProcessorClass(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

        def run(self, information):
            self.try_utime(information['filepath'], 132, 132)

    # Create a temporary file
    with open(os.path.join(os.path.dirname(__file__), 'test_postprocessor.tmp'), "wb") as tmp:
        tmp.write(b'\0'*100);
        tmp.flush()

    atime = os.stat(tmp.name).st_atime
    mtime = os.stat(tmp.name).st_mtime

    # Update utime of temporary file
    PostProcessor

# Generated at 2022-06-12 19:11:42.819075
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from ..extractor import InfoExtractor
    from ..downloader import Downloader
    from ..utils import format_bytes
    from ..compat import compat_os_name, compat_shlex_split
    from ..compat import compat_os_path_exists
    from ..postprocessor import FFmpegMetadataPP, FFmpegExtractAudioPP

    class FakeDownloader(Downloader):
        def __init__(self, params):
            self._params = params

        def report_error(self, message):
            raise AudioConversionError(message)

        def report_warning(self, message):
            self.warning = message


# Generated at 2022-06-12 19:11:53.682841
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Unit test for method try_utime of class PostProcessor
    """
    from . import YoutubeDL
    from .utils import DateRange
    from .compat import format_bytes
    from .extractor import (
        get_info_extractor,
        gen_extractors,
        list_extractors,
    )
    import os
    import tempfile
    import time
    import shutil
    import sys

    def _test_PostProcessor_try_utime(ydl, params, filename, atime, mtime, expected_warning_notes):
        fmt = None
        for f in ydl.extract_info(params, download=True)['formats']:
            if 'url' in f:
                fmt = f['format_id']
                break


# Generated at 2022-06-12 19:12:00.456728
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os

    # Create a test file
    f = open('test.mp4', 'w')
    f.close()

    # Create postprocessor for that file
    p = PostProcessor({})

    # Get the file creation time
    ts1 = os.path.getctime('test.mp4')

    # Run the check with non-matching atime, mtime, and valid file
    p.try_utime('test.mp4', 1, 1)

    # The above should not change the file creation time
    ts2 = os.path.getctime('test.mp4')
    assert ts1 == ts2

    # Run the check with matching atime, mtime, and valid file
    p.try_utime('test.mp4', ts1, ts1)

    # The above should not change the file creation time

# Generated at 2022-06-12 19:12:09.814769
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import shutil
    try:
        from unittest import mock
    except ImportError:  # Python 2
        import mock
    from ..utils import (
        PatchedThreadingEvent,
    )

    # pylint: disable=missing-docstring
    tempdir = tempfile.mkdtemp()

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    sys.stdout = sys.stderr = open(os.devnull, 'w')
    ydl = mock.create_autospec(YoutubeDL)  # pylint: disable=E1120
    ydl.params = {}
    ydl.to_screen.side_effect = lambda *args, **kargs: None
    ydl.to_screen

# Generated at 2022-06-12 19:12:11.187433
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(downloader=None)
    # TODO: test me

# Generated at 2022-06-12 19:12:20.340958
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def _mocked_os_utime(path, times):
        _mocked_os_utime.path = path
        _mocked_os_utime.times = times
    class PostProcessorTester(PostProcessor):
        def __init__(self, downloader=None):
            self._error_notes = []
            PostProcessor.__init__(self, downloader)
        def report_warning(self, msg):
            self._error_notes.append(msg)
    pp = PostProcessorTester()
    os.utime = _mocked_os_utime
    pp.try_utime('foo.bar', 1, 2)
    assert _mocked_os_utime.path == 'foo.bar'
    assert _mocked_os_utime.times == (1, 2)
   

# Generated at 2022-06-12 19:12:24.204101
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True

# Generated at 2022-06-12 19:12:35.068831
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import _download_file_with_retries
    from .youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.params['logtostderr'] = False
    ext = 'mp4'
    tmp_name = 'tmp_download_' + ext
    tmp_file = open(tmp_name, 'w')
    tmp_file.close()

# Generated at 2022-06-12 19:12:45.046551
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TmpPP(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], information['accessedTime'], information['modifiedTime'])
            return [], information

    import time
    import os
    import sys

    tmpPath = os.path.join(sys.prefix, 'tmp', "PostProcessor_try_utime.txt")
    with open(tmpPath, 'w') as f:
        f.write("123")

    tmpFile = {'filepath': tmpPath,
               'accessedTime': time.time() - 60*60,
               'modifiedTime': time.time() - 2*60*60}

    tmpPP = TmpPP()
    _, tmpFile = tmpPP.run(tmpFile)


# Generated at 2022-06-12 19:12:56.459904
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import os
    import tempfile

    class testPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    now = datetime.datetime.now()
    past = now - datetime.timedelta(seconds=100)
    future = now + datetime.timedelta(seconds=100)

    temp_dir = tempfile.gettempdir()
    filename = os.path.join(temp_dir, '__youtubedl_try_utime__')
    with open(filename, 'w') as f:
        f.write('test PostProcessor try_utime')

    pp = testPostProcessor()

    # The default setting is to stay silent in case of failure

# Generated at 2022-06-12 19:13:05.300246
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..downloader import get_suitable_downloader
    from ..YoutubeDL import YoutubeDL

    dummy_file = open('dummy_file', 'wb')
    dummy_file.write(b'a' * (1024 ** 2))  # 1 MB
    dummy_file.close()


# Generated at 2022-06-12 19:13:08.329518
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.warning_calls = 0

        def report_warning(self, message):
            self.warning_calls += 1

    postprocessor = FakePostProcessor()
    postprocessor.try_utime('test_file', 1, 2)
    # No warning should be displayed
    assert postprocessor.warning_calls == 0

# Generated at 2022-06-12 19:13:15.193777
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from ..extractor.common import InfoExtractor
    from ..utils import sanitize_open

    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'test_ie'
        _VALID_URL = r'(?:https?://)?(?:\w+\.)?example\.com/video/(?P<id>[\da-fA-F]+)'

        def _real_extract(self, url):
            video_id = self._match_id(url)
            title = 'test'
            return {
                'id': video_id,
                'ext': 'mp4',
                'title': title,
            }

    # mock downloader
    class MockedYoutubeDL():
        def __init__(self, downloader_params):
            self.params = downloader_params

# Generated at 2022-06-12 19:13:26.088808
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL
    ydl = FakeYDL()
    import tempfile
    from ..compat import filesystem_encoding
    from ..utils import sanitize_open

    a_time, m_time = (1, 2)
    fpath = os.path.join(tempfile.mkdtemp(), 'foo')
    enc_fpath = encodeFilename(fpath)
    with sanitize_open(fpath, 'w') as f:
      f.write("bar")

    assert os.stat(fpath).st_atime != a_time
    assert os.stat(fpath).st_mtime != m_time

    pp = PostProcessor(ydl)
    pp.try_utime(fpath, a_time, m_time)
    assert os.stat(enc_fpath).st

# Generated at 2022-06-12 19:13:33.580051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    '''
    First create a dummy file. Then create an instance of class PostProcessor.
    Then call the try_utime method of that instance to update access / modification time of the file.
    '''
    import tempfile
    fp = tempfile.NamedTemporaryFile()
    fp.close()
    with open(encodeFilename(fp.name), 'wb') as f:
        f.write(b'FOO')

    pp = PostProcessor(None)
    pp.set_downloader(None)
    pp.try_utime(fp.name, 0, 0)

# Generated at 2022-06-12 19:13:42.419263
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    ydl_opts = {}
    p = PostProcessor(YoutubeDL(ydl_opts))
    class test_strerr(object):
        def __get__(self, instance, owner):
            return instance._errnote
        def __set__(self, instance, value):
            instance._errnote = value
    p.strerror = test_strerr()
    utimetest_file = open('utimetest_file', 'w')
    p._errnote = 'Error'
    p.try_utime('utimetest_file', None, None)
    assert p._errnote == 'Error'
    p.strerror = ''
    p._errnote = None
    p.try_utime('utimetest_file', None, None)
   

# Generated at 2022-06-12 19:13:56.159489
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import os

    class FakeDownloader():
        def __init__(self, d):
            self.d = d

        def to_screen(self, s):
            self.d['to_screen'].append(s)

        def report_warning(self, s):
            self.d['report_warning'].append(s)

    p = PostProcessor(None)
    d = {}
    d['to_screen'] = []
    d['report_warning'] = []
    p._downloader = FakeDownloader(d)
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'a' * 10)
    f.close()

# Generated at 2022-06-12 19:14:05.579619
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ...compat import unittest

    import os
    import shutil
    import sys

    from .common import (get_testcases_directory, get_temp_file,
                         get_temp_directory, get_temp_path)
    from .extractor import ExtractorError
    from .downloader import FileDownloader
    from .options import FakeYDL
    from .postprocessor import PostProcessor, AudioConversionError

    class MessageCounter(object):
        '''Counts and reports the number of times a method has been called.'''
        def __init__(self):
            self.count = 0

        def __call__(self):
            self.count += 1
            self.message = '{0} times'.format(self.count)


# Generated at 2022-06-12 19:14:10.136366
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest

    test = PostProcessor()

    test.try_utime("/tmp/file", 0, 0)

    # _try_utime() attempts to set utime on a file
    # currently, the only source of any failure is when the file is not present
    with pytest.raises(PostProcessingError):
        test.try_utime("/tmp/", 0, 0)

    # check utime update on a file with non-existing path
    with pytest.raises(PostProcessingError):
        test.try_utime("/tmp/I/do/not/exist", 0, 0)

    # check utime update on a non-existing file

# Generated at 2022-06-12 19:14:17.834538
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os.path
    import tempfile
    from .testutils import FakeYDL

    # Create a file
    tmpfd, tmpfn = tempfile.mkstemp(prefix="ydl-test-")
    os.close(tmpfd)

    # Get its mtime
    orig_mtime = os.path.getmtime(tmpfn)

    # Run PostProcessor.try_utime
    pp = PostProcessor(downloader=FakeYDL())
    pp.try_utime(tmpfn, 0, orig_mtime)

    # Check that mtime has changed
    new_mtime = os.path.getmtime(tmpfn)
    if new_mtime == orig_mtime:
        raise AssertionError("PostProcessor.try_utime didn't change mtime")

    # Clean

# Generated at 2022-06-12 19:14:21.960306
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import pytest
    from six.moves import StringIO

    from .test_calculate_install_date import FactoryFactory as FactoryFactory
    from .test_calculate_culture_date import FakeDownloader

    if not sys.platform.startswith('linux'):
        pytest.skip('This test is only relevant on linux')

    def _test_utime(monkeypatch):
        factory_factory = FactoryFactory(monkeypatch)
        monkeypatch.setattr(sys, 'argv', ['youtube-dl', '--no-color', '--no-progress', '--no-warnings', '--ignore-errors'])
        with factory_factory.create(FakeDownloader) as dl:
            orig_stdout = sys.stdout
            sys.stdout = StringIO()

# Generated at 2022-06-12 19:14:30.369291
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import os
    import shutil
    import stat
    import sys
    import tempfile
    import unittest

    from ..utils import (
        PostProcessor,
    )

    # TODO: test cross-platform behavior, for now it's only tested on
    # Linux

    class MockDownloader():
        def __init__(self):
            pass

        def to_screen(self, *args, **kwargs):
            pass

        def report_warning(self, warning):
            pass

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader, *args, **kwargs):
            super(TestPostProcessor, self).__init__(downloader, *args, **kwargs)
            self.warning_emitted = False


# Generated at 2022-06-12 19:14:34.585594
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    try_utime_func = pp.try_utime
    os_utime_orig = os.utime

# Generated at 2022-06-12 19:14:45.436700
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import YoutubeIE
    from ..downloader import common
    from ..utils import DateRange
    from .common import FFmpegExtractAudioPP
    from .execafterdownload import ExecAfterDownloadPP

    class Downloader(object):
        params = {
            'writedescription': True,
            'writethumbnail': True,
            'outtmpl': '%(id)s%(ext)s',
        }

    class InfoExtractor(object):
        IE_NAME = 'youtube'

        @staticmethod
        def generate_extractors():
            return [YoutubeIE()]

        def __init__(self):
            pass

        def extract(self, *args, **kargs):
            video_id = 'wo6QKZbqoEM'
            description = 'Test - Test'

# Generated at 2022-06-12 19:14:52.078947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from .compat import mock
    from ..utils import PostProcessingError

    pp = PostProcessor(Downloader())
    try:
        pp.try_utime('nonexistent', 0, 0)
    except PostProcessingError:
        pass

    try:
        with mock.patch('os.utime', side_effect=IOError):
            pp.try_utime('', 0, 0)
    except PostProcessingError:
        pass

# Generated at 2022-06-12 19:15:02.716419
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    """
    This is a unit test which tests the method try_utime in the class PostProcessor.
    The cases tested by this unit test include:

    1. The normal case when it is able to update the utime of the file.
    2. The test case when it is unable to update the utime of the file.
    """

    # Import the package needed to test the method try_utime
    import os

    # Create a downloader
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()

    # Create a PostProcessor
    from ..postprocessor.common import PostProcessor
    pp = PostProcessor(downloader)

    # Create a temp file to test the method try_utime in the class PostProcessor for the normal case
    # when it is able to update the utime of the file

# Generated at 2022-06-12 19:15:22.588087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import mock
    import os
    import shutil
    import subprocess
    import tempfile
    import time

    from ..utils import PostProcessor

    # NOTE: Video is always newer than Audio, so we can mock the timestamps of both correctly
    initial_time = datetime.datetime(2000, 1, 1, 0, 0, 0).timetuple()

    video_path = os.path.join(tempfile.gettempdir(), 'video')

# Generated at 2022-06-12 19:15:33.187414
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import Downloader
    from .extractor.common import InfoExtractor
    from .compat import (
        compat_urllib_error,
    )
    from .utils import (
        SameFileError,
    )

    class PostProc1(PostProcessor):
        def run(self, info):
            return [], info

    class PostProc2(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 1, 2)
            return [], info

    class PostProc3(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 3, 4, 'Note')
            return [], info


# Generated at 2022-06-12 19:15:43.263218
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:15:53.814744
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import sys
    from ytdl.postprocessor.common import PostProcessor

    # set up a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='ytdl-test-utime')
    # set up a dummy FileDownloader
    class DummyFileDownloader:
        def __init__(self):
            pass

        def report_warning(self, msg):
            sys.stderr.write(msg)
            sys.stderr.write('\n')

    dummyfd = DummyFileDownloader()
    # create a dummy file
    fp = open(os.path.join(tmpdir, 'foo.bar'), 'wb')
    fp.write(b'foo')
    fp.close()

    # get the current mtime of

# Generated at 2022-06-12 19:16:02.153316
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    if sys.version_info >= (3, 0):
        from unittest import mock
    else:
        import mock
    from ..postprocessor import PostProcessor

    pp = PostProcessor()
    pp._downloader = mock.Mock()
    pp._downloader.report_warning = mock.Mock(return_value=None)

    # Do nothing if utime doesn't raise an exception
    with mock.patch('os.utime') as mock_utime:
        pp.try_utime(path='file1', atime=123456, mtime=123456)
        mock_utime.assert_called_once_with('file1', (123456, 123456))
        pp._downloader.report_warning.assert_not_called()

    # Call report_warning if utime raises an exception
   

# Generated at 2022-06-12 19:16:12.138670
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..compat import text_type, PY2

    if not PY2:
        import time
        import math
        import datetime

    class TestPostProcessor(PostProcessor):

        def __init__(self, downloader=None, stdout=None):
            PostProcessor.__init__(self, downloader)
            self.stdout = stdout

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote

        def run(self, information):
            return [], information


# Generated at 2022-06-12 19:16:17.031868
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    tmpDir = tempfile.gettempdir()
    testFile = tempfile.NamedTemporaryFile(dir=tmpDir)
    pp = PostProcessor(None)
    # Get file attributes
    _mode, _ino, _dev, _nlink, _uid, _gid, _size, atime, mtime, _ctime = os.stat(testFile.name)
    # Change modification time
    mtime = time.time() - 1000
    pp.try_utime(testFile.name, atime, mtime)
    # Test if modification time changed
    _mode, _ino, _dev, _nlink, _uid, _gid, _size, atime, mtime2, _ctime = os.stat(testFile.name)
    assert mtime == mtime2


# Generated at 2022-06-12 19:16:21.999864
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    filename = 'testfile.tmp'
    try:
        with open(filename, 'w'):
            pass
        pp = PostProcessor(None)
        pp.try_utime(filename, 1, 1)
        assert os.path.exists(filename)
    finally:
        os.remove(filename)

# Generated at 2022-06-12 19:16:29.444254
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import os

    dir = tempfile.mkdtemp()
    try:
        path = os.path.join(dir, 'test.file')
        open(path, 'w').close()
        os.utime(path, (0, 0))

        pp = PostProcessor(None)
        pp.try_utime(path, 5, 10, errnote='test')

        assert os.stat(path).st_atime == 5
        assert os.stat(path).st_mtime == 10
    finally:
        shutil.rmtree(dir)

# Generated at 2022-06-12 19:16:40.678733
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..compat import compat_getenv
    from ..utils import DateRange

    fake_info = {'id': 'dummy'}

# Generated at 2022-06-12 19:17:15.131801
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create an instance of PostProcessor and invoke try_utime
    pp = PostProcessor()
    path = os.path.join(os.getcwd(), 'test_PostProcessor_try_utime.txt')
    try:
        with open(path, 'w') as f:
            f.write('test')
            f.close()
        pp.try_utime(path, 0, 0)
    finally:
        if os.path.exists(path):
            os.unlink(path)

# Generated at 2022-06-12 19:17:21.896217
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..compat import compat_os_name

    dl = Downloader()
    pp = PostProcessor(dl)
    if compat_os_name == 'nt':
        import tempfile
        path = os.path.join(tempfile.gettempdir(), 'ytdl_temp_utime_file')
    else:
        path = 'ytdl_temp_utime_file'
    with open(path, 'wb'):
        pass
    pp.try_utime(path, 0, 0)
    os.remove(path)

# Generated at 2022-06-12 19:17:29.636995
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from pytube.compat import namedtuple
    from pytube.downloader import YouTubeDL
    from pytube.extractor import YoutubeIE
    from pytube import PostProcessor, YoutubeDLHandler
    from pytube.utils import DateRange

    # Create a Downloader
    ydl_opts = {
        'logger': YoutubeDLHandler(),
    }
    ydl = YouTubeDL(ydl_opts)

    # Create a InfoExtractor
    ydl.add_info_extractor(YoutubeIE())

    # Create a PostProcessor
    ydl.add_post_processor(PostProcessor())

    # Create a Fake Info

# Generated at 2022-06-12 19:17:34.371235
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import make_HTTPServer

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            path = info['filepath']
            self.try_utime(path, 1, 2)
            return [], info

    server = make_HTTPServer()
    server.serve_content(b'foobar', b'video/mp4')
    video_url = server.get_url()
    server.serve_content(b'foobar', b'audio/mp3')
    audio_url = server.get_url()

# Generated at 2022-06-12 19:17:45.332098
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    from .downloader import FakeYDL
    from .common import FileDownloader

    tmp_dir = tempfile.mkdtemp()

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 123456, 123456)
            return [], info

    ydl = FakeYDL()
    ydl.params['logger'] = FileDownloader(ydl).std_logger
    dl = FileDownloader(ydl)

    dl.add_info_extractor(None)
    dl.add_post_processor(DummyPostProcessor(dl))

    dl.result = lambda *x: None
    dl.report_warning = lambda *x: None
    dl.to_

# Generated at 2022-06-12 19:17:55.602932
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    file_path = os.path.join(tmp_dir, 'test_file')
    try:
        with open(file_path, 'w') as f:
            f.write("some content")

        # At this point, the file created by Python 3 has no access or modification time,
        # and will report zero values if queried.
        # We will now try to set the modification time to zero, which is invalid and should raise an exception.
        pp = PostProcessor(None)
        pp.try_utime(file_path, 0, 0)
    finally:
        os.remove(file_path)
        os.rmdir(tmp_dir)



# Generated at 2022-06-12 19:18:04.596150
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    # Test if try_utime changes the time of a file
    path = tempfile.mkstemp()[1]
    now = time.time()
    a = PostProcessor(None)
    a.try_utime(path, now, now)
    newnow = os.stat(path).st_mtime
    assert -1 < newnow - now < 1
    # Test if try_utime works properly also if the time has changed since the
    # time of the last call
    tomorrow = now + datetime.timedelta(days=1).total_seconds()
    a.try_utime(path, tomorrow, tomorrow)
    newnow = os.stat(path).st_mtime
    assert -1 < newnow - tomorrow < 1
    # Test if try_

# Generated at 2022-06-12 19:18:13.016153
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)

    from .common import FakeYDL
    from .extractor import get_info_extractor
    ydl = FakeYDL()
    ie = get_info_extractor('YoutubeIE', ydl)
    pp.set_downloader(ydl)

    def tu(path, atime, mtime, errnote='Cannot update utime of file'):
        pp.try_utime(path, atime, mtime, errnote)
    tu('/dev/null', 0, 0)
    tu('/dev/null', 1.2, 1.2)
    tu('/root/test', 1.2, 1.2, errnote='Cannot update utime of file /root/test')

# Generated at 2022-06-12 19:18:22.699610
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MyPostProcessor(PostProcessor):
        pass

    class MyDownloader():
        def report_warning(self, errnote):
            return

    pp = MyPostProcessor(MyDownloader())

    class WrongPath():
        def __init__(self):
            return

        def __str__(self):
            return "a"

    class WrongMtime():
        def __str__(self):
            return "b"

    class WrongAtime():
        def __str__(self):
            return "c"

    pp.try_utime(WrongPath(), WrongAtime(), WrongMtime())
    return True


# Test case: AudioConversionError
testcases = [test_PostProcessor_try_utime]

# Generated at 2022-06-12 19:18:34.332384
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    from .common import FileDownloader

    output_dir = tempfile.mkdtemp()

    dl = FileDownloader({
        'outtmpl': os.path.join(output_dir, '%(id)s.%(ext)s')
    })

    pp = PostProcessor(dl)
    filepath = os.path.join(output_dir, 'abcdef.mp3')

    with open(filepath, 'w') as fd:
        fd.write('foo')

    pp.try_utime(filepath, 1, 2)
    st = os.stat(filepath)
    assert st.st_atime == 1
    assert st.st_mtime == 2


# Generated at 2022-06-12 19:19:39.954618
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os.path
    import os
    import subprocess

    # Because Python < 2.6.2 doesn't have subprocess.check_output
    def subprocess_check_output(*popenargs, **kwargs):
        process = subprocess.Popen(stdout=subprocess.PIPE, *popenargs, **kwargs)
        output, unused_err = process.communicate()
        retcode = process.poll()
        if retcode:
            cmd = kwargs.get("args")
            if cmd is None:
                cmd = popenargs[0]
            raise subprocess.CalledProcessError(retcode, cmd)
        return output

    def get_utime(path):
        if not os.path.exists(path):
            return None

# Generated at 2022-06-12 19:19:47.684074
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    import tempfile
    import os

    class MockDownloader():

        def report_warning(self, note):
            self.note = note

    class TestPostProcessor_try_utime(unittest.TestCase):

        def test_success(self):
            tempdir = tempfile.mkdtemp()
            p = PostProcessor(downloader=MockDownloader())
            path = os.path.join(tempdir, 'temp.txt')

            with open(path, 'w') as f:
                f.write("temp")

            p.try_utime(path, 10, 20)

            stat = os.stat(path)
            self.assertEqual(stat.st_atime, 10)
            self.assertEqual(stat.st_mtime, 20)
            os.remove

# Generated at 2022-06-12 19:19:58.129934
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, 'foo')