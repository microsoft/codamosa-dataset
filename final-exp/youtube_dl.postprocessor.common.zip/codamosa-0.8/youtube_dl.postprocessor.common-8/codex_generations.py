

# Generated at 2022-06-12 19:09:54.877318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:09:58.126067
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors

    for ie_module in gen_extractors():
        ie_module.embedded_webpage_version()
        ie_module.working()

# Generated at 2022-06-12 19:10:02.334774
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange

    a = YoutubeDL({})

    p = PostProcessor(a)
    p.try_utime('fake_file', 1, 2)
    p.try_utime('fake_file', DateRange(1), DateRange(2))

# Generated at 2022-06-12 19:10:07.463867
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    pp.try_utime('nonexistent/path', 1, 2)
    assert ydl.has_warning



# Generated at 2022-06-12 19:10:16.267947
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    post_processor = PostProcessor()
    post_processor._downloader = compat_mock.MagicMock()
    post_processor.try_utime('file_path', 1450244757.0, 1450244757.0)
    post_processor._downloader.report_warning.assert_not_called()
    post_processor.try_utime('file_path', 1450244757.0, 1450244757.0, 'Cannot update utime of file')
    post_processor._downloader.report_warning.assert_called_once_with('Cannot update utime of file')

# Generated at 2022-06-12 19:10:23.833228
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime, time
    import tempfile, os
    import shutil
    import nose.tools

    # create test directory and file
    old_dir = os.getcwd()

# Generated at 2022-06-12 19:10:32.149339
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil


# Generated at 2022-06-12 19:10:42.177857
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import sys
    import tempfile
    import time
    import unittest

    from ..utils import (
        DateRange,
        encodeFilename,
    )
    from .common import (
        FakeYDL,
        mocked_post_prepend_funcs,
    )

    from .test_utils import (
        DataTestCase,
    )

    def test_func(param):
        if param == 'prepend_funcs':
            return mocked_post_prepend_funcs()
        return None

    @unittest.skipIf(sys.platform.startswith('win') or sys.platform == 'darwin',
                     'Cannot test utime on Windows or macOS')
    class TestPostProcessorTryUtime(DataTestCase):

        def setUp(self):
            self

# Generated at 2022-06-12 19:10:49.560611
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        pass
    postProcessor = TestPostProcessor()
    import errno
    try:
        os.mkdir(encodeFilename('./test_PostProcessor_try_utime_dir'))
    except:
        pass
    assert postProcessor.try_utime(
        '/test_PostProcessor_try_utime_dir/a_file_not_exist',
        11,
        22,
        'error message') == None
    filename = './test_PostProcessor_try_utime_dir/test_file.txt'
    filehandle = open(encodeFilename(filename), 'w')
    postProcessor.try_utime(filename, 11, 22, 'error message')
    assert os.stat(
        encodeFilename(filename))[7]

# Generated at 2022-06-12 19:11:00.133778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime
    except AttributeError:
        return
    import tempfile
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    (test_file, test_file_path) = tempfile.mkstemp(dir=temp_dir)
    # Get times before utime
    stat = os.stat(test_file_path)
    atime_before = stat.st_atime
    mtime_before = stat.st_mtime
    # Set times
    atime = 42
    mtime = 69
    # Run try_utime
    postprocessor = PostProcessor()
    postprocessor.try_utime(test_file_path, atime, mtime)
    # Get times after utime

# Generated at 2022-06-12 19:11:02.289660
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:11:07.401651
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    downloader = compat_mock.create_autospec(spec=['report_warning'])
    pp = PostProcessor(downloader)
    path = 'fakefile.txt'
    atime = mtime = None
    errnote = 'Cannot update utime'
    pp.try_utime(path, atime, mtime, errnote)
    downloader.report_warning.assert_called_once_with('Cannot update utime', None)

# Generated at 2022-06-12 19:11:18.018107
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    class MockPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

    mock_downloader = FileDownloader({})
    mock_downloader.add_info_extractor(InfoExtractor())
    mock_postprocessor = MockPostProcessor()
    mock_postprocessor.set_downloader(mock_downloader)

    if sys.version_info < (3,): # win32fs utime modifies the file createtime
        try:
            dum = mock_postprocessor.try_utime(__file__, 0, 0)
        except:
            pass
        else:
            assert False, "Exception not raised"

# Generated at 2022-06-12 19:11:24.468040
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .FakeDl import FakeYDL
    d = FakeYDL()
    pp = PostProcessor(d)
    pp.try_utime('path', 1, 1)
    d.reports.reverse()
    assert d.reports[0]['message'] == 'Cannot update utime of file'

# Generated at 2022-06-12 19:11:30.587332
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    from ..downloader import Downloader
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    downloader = Downloader()
    (fd, fname) = tempfile.mkstemp(prefix='youtube-dl-test_')
    os.close(fd)
    # The postprocessor has to exist, so we create one as a dummy
    postprocessor = FFmpegPostProcessor(downloader=downloader)
    postprocessor.set_downloader(downloader)
    # Get the current time
    current_time_tuple = time.localtime()
    current_time = time.mktime(current_time_tuple)
    # Create a temporary file and give it some time in the past
    # (The first and the second is the access time, the third and the fourth is

# Generated at 2022-06-12 19:11:32.279873
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime(__file__, 0, 0)

# Generated at 2022-06-12 19:11:32.837187
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:11:33.828834
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO
    pass

# Generated at 2022-06-12 19:11:43.790870
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # For this test we need to create a new PostProcessor object.
    import ydl_opts
    from youtube_dl.downloader import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = FileDownloader(ydl_opts.parseOpts(['--no-warnings']))
    downloader.add_info_extractor(YoutubeDL(ydl_opts.parseOpts(['--no-warnings'])))
    pp = PostProcessor(downloader)
    import tempfile

    tempdir = tempfile.gettempdir()
    tmp_path = os.path.join(tempdir, 'utime_test')

    # Create the test file.
    f = open(tmp_path, 'w+')
    f.close()
    import time

# Generated at 2022-06-12 19:11:53.820041
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    class DummyDownloader():
        def report_warning(self, msg):
            print(msg)

    class DummyPostProcessor(PostProcessor):
        def run(self, info_dict):
            path = info_dict['filepath']


# Generated at 2022-06-12 19:12:02.093169
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader:
        def report_warning(self, errnote):
            self.errnote_called = errnote
    class DummyPP(PostProcessor):
        def run(self, information):
            self.information = information

    d = DummyDownloader()
    pp = DummyPP(d)

    pp.try_utime("test_file", 0, 0, "test error")
    assert d.errnote_called == "test error"
    assert os.path.isfile("test_file")
    assert os.utime("test_file") == (0, 0)

    with open("test_file", "wb") as f:
        f.write(b"This is a test file")

    pp.try_utime("test_file", 0, 0, "test error")
    assert d.err

# Generated at 2022-06-12 19:12:11.378991
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    # Create test file
    fd, filename = mkstemp()
    os.close(fd)
    import time

    # Get file creation time and modify times
    ctime = time.time() - 10
    atime = ctime - 10
    mtime = ctime - 5
    os.utime(filename, (atime, mtime))
    # List of implemented classes of PostProcessor and the args
    # that they take in the constructor
    classes = [
        (FFmpegExtractAudioPP, {}),
        (FFmpegMergerPP, {'merge': True}),
    ]
    while classes:
        # Get a class and remove it from the list
        klass, args = classes.pop()
        # Create a downloader
        downloader = DummyDict()

# Generated at 2022-06-12 19:12:20.574516
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from tempfile import mkstemp
    from .downloader import Downloader
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    from .utils import Devnull

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'FakeId',
                'title': 'FakeTitle',
                'ext': 'mp4',
                'format': 'fake-format',
                'duration': 10,
            }

    yt_ie = YoutubeIE(FakeInfoExtractor(Downloader(params={})))
    _, outf = mkstemp(suffix='.mp4')

# Generated at 2022-06-12 19:12:26.802518
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time, stat
    import shutil
    # Create a new temp folder
    tempname = 'youtube_dl_test'
    tempdir = os.path.join(os.path.expanduser('~'), tempname)
    try:
        shutil.rmtree(tempdir)
    except os.error:
        pass
    os.mkdir(tempdir)
    # Change directory to it
    old_dir = os.getcwd()
    os.chdir(tempdir)

# Generated at 2022-06-12 19:12:37.741728
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime('unexisting', None)
    except Exception as e:
        from ..compat import compat_str, compat_shlex_quote
        # we need to use the same exception
        errnote = '%s: %s' % (type(e).__name__, str(e).replace('\n', ' '))
        # we need to use the same exception
        errnote = '%s: %s' % (type(e).__name__, str(e).replace('\n', ' '))
        errnote = '%s: %s' % (type(e).__name__, compat_str(e).replace('\n', ' '))
        errnote = '%s: %s' % (type(e).__name__, compat_str(e).replace('\n', ' '))

# Generated at 2022-06-12 19:12:43.436772
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader
        def run(self, information):
            pass

    import time
    import tempfile
    tempdir = tempfile.mkdtemp(prefix='yt-postprocessor')
    tempfile = os.path.join(tempdir, 'tempfile')
    os.close(os.open(tempfile, os.O_CREAT))
    t = TestPostProcessor(None)
    t.try_utime(tempfile, None, None)
    t.try_utime(tempfile, None, int(time.time()))
    t.try_utime(tempfile, int(time.time()), None)

# Generated at 2022-06-12 19:12:54.798119
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import sys

    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write(b'abc')

    t = time.time()
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)

    post_proc = PostProcessor(None)
    post_proc.try_utime(tmp_file.name, t, t)

    assert os.stat(tmp_file.name).st_mtime >= t


# Generated at 2022-06-12 19:13:04.230957
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time

    # Test on file
    test_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    name = test_file.name
    test_file.close()
    file_stat = os.stat(encodeFilename(name))
    atime = file_stat.st_atime
    mtime = file_stat.st_mtime
    time.sleep(1.0)
    PostProcessor({}).try_utime(name, atime, mtime)
    file_stat = os.stat(encodeFilename(name))
    assert file_stat.st_atime != atime
    assert file_stat.st_mtime == mtime
    os.remove(encodeFilename(name))

    # Test on directory


# Generated at 2022-06-12 19:13:10.926031
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader

    class FakeFileDownloader(FileDownloader):
        def report_warning(self, errnote):
            self.errnote = errnote

    pp = PostProcessor(downloader=FakeFileDownloader())
    pp.try_utime('/path', 1, 2, errnote='errnote')
    assert pp._downloader.errnote == 'errnote'

# Generated at 2022-06-12 19:13:21.111328
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from .common import PostProcessorTest

    class TestPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 2, 1, errnote='_test_')
            return ([], info)

    # Set up a FileDownloader
    params = {'verbose': False,
              'nocheckcertificate': True,
              'simulate': True,
              'format': 'best',
              'ignoreerrors': True,
              'outtmpl': '%(id)s',
              'test': True,
              }
    fd = FileDownloader({
        'outtmpl': '%(id)s'
    })
    fd.params.update(params)

    # Start test

# Generated at 2022-06-12 19:13:33.920043
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import mock
    import os
    import shutil
    os.path.abspath = mock.Mock(return_value='/path/to/file')

    downloader = mock.Mock()
    downloader.params = {}
    pp = PostProcessor(downloader)

    fn = 'asdf'
    shutil.move(fn, fn)
    pp.try_utime(fn, 0, 0, 'error_note')
    os.path.abspath.assert_called_with(fn)
    downloader.report_warning.assert_called_with('error_note')

    fn = 'asdf'
    shutil.move(fn, fn + '.part')
    pp.try_utime(fn, 0, 0, 'error_note')
    os.path.abspath.assert_called_

# Generated at 2022-06-12 19:13:40.111169
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class _DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None, filename=None):
            PostProcessor.__init__(self, downloader)
            self.filename = filename

    filename = '123.txt'
    pp = _DummyPostProcessor(filename=filename)
    path = os.path.join(pp._downloader.get_property('ytdl_cookies_path'), filename)
    pp.try_utime(path, 0, 0)

# Generated at 2022-06-12 19:13:51.549529
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time

    class TemporaryError(Exception):
        pass

    class FakeDownloader(object):
        def __init__(self):
            self.tmp = tempfile.mkstemp()[1]
            self.tmp = os.path.realpath(self.tmp)

        def report_warning(self, msg):
            pass

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            raise TemporaryError

    pp = FakePostProcessor()
    pp.set_downloader(FakeDownloader())

    pp.try_utime(pp._downloader.tmp, 0, 0)
    info = os.stat(pp._downloader.tmp)

    time.sleep(2)
    pp._downloader.params['nooverwrites'] = False
    # force overwrite exception


# Generated at 2022-06-12 19:13:58.320198
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeYDL
    ydl = FakeYDL()
    ydl.add_post_processor(PostProcessor(ydl))


# Generated at 2022-06-12 19:14:07.653610
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YDLFileDownloader import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import DateRange


# Generated at 2022-06-12 19:14:16.649963
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    class FakePostProcessor(PostProcessor):
        @staticmethod
        def _to_utime(t):
            return t.year, t.month, t.day, t.hour, t.minute, t.second

    now = datetime.datetime.now()
    next_month = now + datetime.timedelta(days=30)
    # The method should not raise any exception given valid values
    FakePostProcessor().try_utime('test_file', *FakePostProcessor._to_utime(next_month))
    FakePostProcessor().try_utime('test_file', *FakePostProcessor._to_utime(now))
    # The method should not raise any exception if an exception is raised updating the utime

# Generated at 2022-06-12 19:14:26.801698
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'] + 'x', 100, 200)
            return [], info

    class DummyDownloader:
        def __init__(self):
            self.params = {}
            self.warned = []

        def report_warning(self, msg):
            self.warned.append(msg)

    dp = DummyPostProcessor()
    dd = DummyDownloader()
    dp.set_downloader(dd)

    info = {'filepath': 'test_PostProcessor_try_utime.tmp'}


# Generated at 2022-06-12 19:14:37.889050
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import format_bytes
    from tempfile import mkdtemp
    import os
    import shutil
    from .test_utils import FakeYDL, FakeFile
    from .test_test import BaseTest, setUp
    # This is a test for try_utime method of class PostProcessor
    # We will check if the method returns None when it can not
    # update utime of a file or skip this action
    # First we create a temporary directory
    tmp_dir = mkdtemp()
    # Now we create a subdirectory to create a test file
    tmp_sub_dir = tmp_dir + "/test_sub_dir"

    # Create a temporary file to test try_utime method
    test_file_path = tmp_sub_dir + "/test_file"

    # Create a temporary directory and a file
    os.mk

# Generated at 2022-06-12 19:14:49.341385
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """test_PostProcessor_try_utime: test for method try_utime of class PostProcessor"""
    import tempfile

    # Use some non UTF-8 file names

# Generated at 2022-06-12 19:14:56.454886
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.stat(encodeFilename('noexiste.bat'))
    except Exception:
        pass
    else:
        raise Exception('File noexiste.bat should not exist')
    try:
        os.utime(encodeFilename('noexiste.bat'), None)
    except Exception:
        pass
    else:
        raise Exception('File noexiste.bat should not exist')
    pp = PostProcessor()
    pp.try_utime('noexiste.bat',1,1)

# Generated at 2022-06-12 19:15:17.770532
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    from tempfile import NamedTemporaryFile, mkdtemp
    import time
    import shutil
    # create a temp file
    with NamedTemporaryFile(delete=False) as temp_file:
        temp_name = temp_file.name

    # create a temp dir
    temp_dir = mkdtemp()
    # create a temp file in this dir
    with open(os.path.join(temp_dir, 'test_file'), 'wb') as f:
        f.write(b'test')

    # create a temp downloader with standard output redirected
    out_file = BytesIO()
    cfg = {'outtmpl': temp_name, 'nooverwrites': True}
    dl = object.__new__(object)
    dl.params = cfg

    #

# Generated at 2022-06-12 19:15:27.534885
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
  from ..utils import DateRange
  import time

  # Since we don't know the time in the future, we set the date
  # range to "now" to "now + 2 seconds"
  date_range = DateRange()
  date_range.start_time = time.time()
  date_range.end_time = date_range.start_time + 2

  pp = PostProcessor(None)
  pp.try_utime_date_range = date_range
  pp.try_utime('/dev/null', 0, 0)

  # Test that try_utime is not affected by the argument "errnote"
  pp.try_utime('/dev/null', 0, 0, 'some error note')
  return True

# Generated at 2022-06-12 19:15:35.333542
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    p = PostProcessor(None)
    m = compat_mock.mock_open()
    path = compat_mock.NonCallableMock(
        filename='/foo/bar',
        spec=['filename', 'readlines', 'name', 'mode'])
    m.return_value = path
    with compat_mock.patch('ytdl.postprocessor.open', m, create=True) as open_mock:
        p.try_utime(path, 1, 2)
        m.assert_called_once_with('/foo/bar', 'rb')
        open_mock.assert_called_once_with('/foo/bar', 'rb')
        assert open_mock.return_value is path

# Generated at 2022-06-12 19:15:38.678967
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = None
    postprocessor = PostProcessor(downloader)
    postprocessor.try_utime('test', 0, 0)

# Generated at 2022-06-12 19:15:39.646315
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:15:51.099879
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import subprocess
    import sys
    import tempfile

    # create test directory for procedure
    tmp_test_dir = tempfile.mkdtemp(prefix='tmp_pytube_test_')

# Generated at 2022-06-12 19:15:54.302722
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader(object):
        def report_warning(self, text):
            self._text = text

    x = PostProcessor(FakeDownloader())
    x.try_utime('foo', 1, 2)
    assert x._downloader._text == 'Cannot update utime of file'

# Generated at 2022-06-12 19:16:01.593262
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import TemporaryDirectory as temporary_directory
    import time

    with temporary_directory() as tempdir:
        with open(os.path.join(tempdir, 'testfile'), 'w') as testfile:
            testfile.write('Test string')
        atime = mtime = time.time()
        pp = PostProcessor(None)
        pp.try_utime(os.path.join(tempdir, 'testfile'), atime, mtime)
        st = os.stat(os.path.join(tempdir, 'testfile'))
        assert st.st_atime == atime
        assert st.st_mtime == mtime



# Generated at 2022-06-12 19:16:11.596072
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_io
    # Create a YoutubeDL object with a valid tmpdir
    ydl_opts = {'postprocessor_args': ['--sleep-interval=10']}
    ydl = YoutubeDL(ydl_opts)
    # Create a PostProcessor and set the YoutubeDL object as downloader
    pp = PostProcessor(ydl)
    # Create a file and store in filepath the name of the file
    with tempfile.NamedTemporaryFile(delete=False, dir=ydl.params['tmpdir']) as temp_file:
        temp_file.write(b'Hello World')
        filepath = temp_file.name
    # Rename the file and write again 'Hello World'

# Generated at 2022-06-12 19:16:12.676762
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert (
        PostProcessor().try_utime('foo', 0, 0)
        ==
        None
    )

# Generated at 2022-06-12 19:16:34.541840
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from types import ModuleType
    from ..utils import DateRange
    p = PostProcessor()
    p.try_utime('test.txt', -1, -1, 'not a file')
    # add a dummy module in sys.modules
    t = ModuleType('time')
    t.time = lambda : 2000000000
    import sys
    sys.modules['time'] = t
    # test errors
    p.try_utime('test.txt', -1, -1, 'not a file')
    os.mkdir('test')
    p.try_utime('test', -1, -1, 'not a file')
    open('test.txt', 'w').close()

# Generated at 2022-06-12 19:16:39.972004
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class FakePostProcessor(PostProcessor):
        def __init__(self):
            pass

    class FakeDownloader():
        debug = True
        verbose = True
        params = {}

        def to_stdout(self, message):
            pass

        def report_warning(self, message):
            pass

    pp = FakePostProcessor()
    pp.set_downloader(FakeDownloader())
    # FIXME write unit test for try_utime

# Generated at 2022-06-12 19:16:44.147202
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test when file cannot be accessed
    pipe_path = 'pipe://foo'

# Generated at 2022-06-12 19:16:52.928014
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    #pylint: disable=protected-access
    pp = PostProcessor()
    d = pp._downloader
    d.params['nooverwrites'] = True
    d.report_warning = lambda s: print('Warning: %s' % s)
    d.report_error = lambda s: print('Error: %s' % s)

    def get_cwd(path):
        return {
            'cwd': path,
        }

    try:
        #pylint: disable=protected-access
        pp._print_status(get_cwd('/'))
    except OSError:
        # utime can't be updated if selinux is enabled
        pass

# Generated at 2022-06-12 19:17:03.646472
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from nose.tools import assert_raises
    from ..downloader import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import DateRange

    # Mock FileDownloader with fake params
    downloader = FileDownloader({})

# Generated at 2022-06-12 19:17:06.732140
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    def failUtimes(*args):
        raise OSError(1, 'Fail Utimes')
        return
    pp = PostProcessor(None)
    pp.try_utime('None', 0, 0)
    pp.try_utime = failUtimes
    pp.try_utime('None', 0, 0)

# Generated at 2022-06-12 19:17:17.929729
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor.common import InfoExtractor

    downloader = Downloader(params={})
    generator = 'dummy'

    class DummyExtractor(InfoExtractor):
        def extract(self, url):
            return {'id': '1234'}

    DummyExtractor._download = DummyExtractor._download_webpage
    DummyExtractor.IE_NAME = 'dummy'
    DummyExtractor.IE_DESC = 'Dummy'
    downloader.add_info_extractor(DummyExtractor)

    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            from ..compat import compat_str
            filename = information['filepath']
            self.try_utime(filename, 100, 200)
            import stat


# Generated at 2022-06-12 19:17:25.021695
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # make a test downloader
    from ..downloader.common import FileDownloader
    ydl = FileDownloader({})
    # make two postprocessors
    pp1 = PostProcessor(ydl)
    pp2 = PostProcessor(ydl)
    # test try_utime should fail with relative path for pp1
    # test try_utime should succeed with absolute path for pp2
    import os
    pp1.try_utime('test', 100, 100, errnote='relative-path')
    pp2.try_utime(os.getcwd() + '/test', 100, 100, errnote='absolute-path')
    assert True

# Generated at 2022-06-12 19:17:25.873099
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkste

# Generated at 2022-06-12 19:17:32.165504
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import tempfile

    with tempfile.NamedTemporaryFile() as mobj:
        mobj.write(b'Fake file for testing')
        mobj.flush()
        ar = PostProcessor()
        ar.try_utime(mobj.name, 1111111111, 2222222222)
        mobj_stat = os.stat(mobj.name)
        assert mobj_stat.st_atime == 1111111111
        assert mobj_stat.st_mtime == 2222222222
        ar.try_utime(mobj.name, 1000000002, 3000000004)
        mobj_stat = os.stat(mobj.name)
        assert mobj_stat.st_atime == 1000000002
        assert mobj_stat.st_mtime == 3000000004

# Generated at 2022-06-12 19:18:11.984616
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import unittest
    from ..utils import encodeFilename

    class TestPP(PostProcessor):
        def __init__(self, downloader=None, **kwargs):
            super(TestPP, self).__init__(downloader, **kwargs)
            self._atime = kwargs['atime']
            self._mtime = kwargs['mtime']
            self._filename = encodeFilename(kwargs['filename'])

        def run(self, information):
            self.try_utime(self._filename, self._atime, self._mtime)
            return [], information

    class PostProcessorTest(unittest.TestCase):
        def test_try_utime(self):
            import time

            filename = 'test_file.txt'
            open(filename, 'w').close()

# Generated at 2022-06-12 19:18:22.357773
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def report_warning(self, msg):
            print('Warning: {0}'.format(msg))

    class DummyPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

    import tempfile
    import time
    import os
    from .testutils import make_temp_directory

    def time_valid(atime, mtime):
        # this is too much involved for a unit test, so let's just assume it worked
        return True

    with make_temp_directory() as directory:
        test_file = os.path.join(directory, 'test')
        fp = open(test_file, 'w')
        fp.close()

        old_time = time.time() - 1000


# Generated at 2022-06-12 19:18:24.112814
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPP(PostProcessor):
        pass

    pp = DummyPP()
    pp.try_utime('path', 1, 1)

# Generated at 2022-06-12 19:18:27.528523
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_pp = PostProcessor()
    test_pp.try_utime('/tmp/test_file', 1000, 1000)



# Generated at 2022-06-12 19:18:34.672771
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    postprocessor = PostProcessor()
    fd, tmp_filename = tempfile.mkstemp()
    os.close(fd)
    old_stime = time.time()
    time.sleep(0.01)
    postprocessor.try_utime(tmp_filename, old_stime, old_stime)
    if os.stat(tmp_filename).st_mtime != old_stime or os.stat(tmp_filename).st_mtime != old_stime:
        raise Exception('Postprocessor.try_utime failed')
    os.remove(tmp_filename)

# Generated at 2022-06-12 19:18:40.225934
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def _faux_utime(path, atime, mtime):
        raise Exception('faux utime')

    import types
    old_utime = os.utime
    os.utime = types.MethodType(_faux_utime, 'utime')

    pp = PostProcessor(None)

    pp.try_utime('some/file', 1, 2)
    os.utime = old_utime

# Generated at 2022-06-12 19:18:47.810805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import BytesIO
    import tempfile
    import time
    from ytdl.extractor import PostProcessor
    from ytdl.utils import check_executable

    def _create_temp_file(contents):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'wb') as f:
            f.write(contents)
        return path

    def _get_temp_file_contents(path):
        with open(path, 'rb') as f:
            return f.read()

    if not check_executable('ffmpeg', ['-h']):
        print('ffmpeg not available: Skipping test_PostProcessor_try_utime')
        return

    old_atime = 1000000000
    old_mtime = 900000000


# Generated at 2022-06-12 19:18:56.341024
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self, None)
        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            print('Path: ' + path)
            print('atime: ' + str(atime))
            print('mtime: ' + str(mtime))
            print('errnote: ' + errnote)
    test = TestPostProcessor()
    test.try_utime('/path/to/file', 1, 2, 'errnote')

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:19:07.598752
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a dummy PostProcessor object
    pp = PostProcessor()
    # Create a dummy downloader object
    import youtube_dl
    ytdl = youtube_dl.YoutubeDL({})
    pp.set_downloader(ytdl)
    from ..compat import TemporaryDirectory
    with TemporaryDirectory(prefix='youtube-dl-utime-test-') as temp_dir:
        dummy_filename = os.path.join(temp_dir, 'dummy')

# Generated at 2022-06-12 19:19:16.940709
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'test')
    with open(testfile, 'w') as f:
        pass

    pp = PostProcessor({})

    # Set atime to 0
    atime = os.path.getatime(testfile)
    mtime = os.path.getmtime(testfile)
    os.utime(testfile, (0, mtime))
    assert os.path.getatime(testfile) == 0

    # Restore atime
    pp.try_utime(testfile, atime, mtime)
    assert os.path.getatime(testfile) == atime

    # Restore atime even if an error is raised