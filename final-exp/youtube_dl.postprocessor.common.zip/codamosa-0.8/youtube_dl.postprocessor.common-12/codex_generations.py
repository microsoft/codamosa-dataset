

# Generated at 2022-06-12 19:09:57.426920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file = open('testfile', 'w')
    file.close()
    PostProcessor().try_utime('testfile', 1, 2)
    os.remove('testfile')

# Generated at 2022-06-12 19:10:08.756102
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    p = PostProcessor(None)

    def _mock_report_warning(_self, errnote):
        raise Exception(errnote)

    # Create a foo file
    path = os.path.join(tmpdir, 'foo')
    with open(path, 'wb') as fh:
        fh.write(b'FOO')

    # Create bar file and create a hardlink of foo
    path_b = os.path.join(tmpdir, 'bar')
    with open(path_b, 'wb') as fh_b:
        fh_b.write(b'BAR')
    os.link(path, path_b)

    # Ensure that foo and bar have different utime

# Generated at 2022-06-12 19:10:11.349534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FakeYDL
    pp = PostProcessor(downloader=FakeYDL({}))
    pp.try_utime('/path/to/file', 0, 0)

# Generated at 2022-06-12 19:10:14.527928
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..postprocessor import PostProcessor
    pp = PostProcessor()
    print(pp.try_utime('test_PostProcessor_try_utime', None, None, errnote='test'))

# Generated at 2022-06-12 19:10:22.676195
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .compat import unittest
    from .downloader import FileDownloader

    test_file_path = 'test_file'


# Generated at 2022-06-12 19:10:31.287533
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import YoutubeDL
    from .YoutubeDL import DownloadXAttrsUtimeError
    from ..utils import encodeFilename

    class TestDownloader(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestDownloader, self).__init__(*args, **kwargs)
            self.test_tried_utime = False
            self.test_os_errno = None
            self.test_os_strerror = None
            self.test_os_filename = None

        def to_stderr(self, message):
            pass

        def report_warning(self, message):
            pass


# Generated at 2022-06-12 19:10:41.459880
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2
    from ..utils import is_outdated_version
    from shutil import rmtree
    if PY2:
        from tempfile import mkdtemp
    if is_outdated_version(os.uname()[0]):
        return
    from .common import FakeYDL
    from .get_sed_expr import get_sed_expr
    import subprocess
    import time
    import os
    import stat
    tempdir = mkdtemp(prefix='ytdl-test_PostProcessor_try_utime-')
    os.chmod(tempdir, 0o755)
    ffmpeg_bin, ffprobe_bin = FakeYDL().get_binaries()
    test_files = {}

# Generated at 2022-06-12 19:10:48.918427
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil  # TODO: remove dependency on shutil
    from tempfile import NamedTemporaryFile
    from ..utils import timeconverter

    # Create a file with a known timestamp
    from datetime import datetime
    # Python2.6 does not have the microsecond argument
    try:
        timestamp = datetime(2017, 1, 1, 5, 5, 5, microsecond=500000)
    except TypeError:
        timestamp = datetime(2017, 1, 1, 5, 5, 5)

    tmp = NamedTemporaryFile()
    tmp_path = tmp.name
    tmp.close()

    os.utime(tmp_path, (timeconverter(timestamp), timeconverter(timestamp)))
    assert os.stat(tmp_path).st_mtime == timeconverter(timestamp)

    timestamp

# Generated at 2022-06-12 19:10:57.266954
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    import os
    import time

    pp = PostProcessor(None)
    errnote = 'Cannot update utime of file'
    path = NamedTemporaryFile().name
    tmpfile = open(path, 'w')
    tmpfile.close()
    orig_utime = time.gmtime(os.path.getmtime(path))
    pp.try_utime(path, *orig_utime)
    new_utime = time.gmtime(os.path.getmtime(path))
    assert orig_utime == new_utime
    os.remove(path)

# Generated at 2022-06-12 19:11:06.436040
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import filecmp
    import os

    tmppath = tempfile.mkstemp()[1]
    touch_time = 15010000000.0
    os.utime(tmppath, (touch_time, touch_time))
    old_timestamp = os.path.getmtime(tmppath)
    PostProcessor(None).try_utime(tmppath, touch_time, touch_time)
    new_timestamp = os.path.getmtime(tmppath)

    try:
        assert old_timestamp == new_timestamp
    finally:
        os.remove(tmppath)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:11:18.577909
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    import tempfile
    t = tempfile.NamedTemporaryFile()
    path = t.name
    t.close()

    import os
    import time
    now = time.time()
    os.utime(path, (now, now))
    time.sleep(2)
    pp.try_utime(path, now, now)
    assert int(now) == int(os.stat(path).st_mtime)

    os.utime(path, (now, now))
    time.sleep(2)
    pp.try_utime(path, now-1, now)
    assert int(now)-1 == int(os.stat(path).st_mtime)

    os.utime(path, (now, now))
    time.sleep(2)

# Generated at 2022-06-12 19:11:22.108787
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    file_path = 'file_path'
    atime = 123456789
    mtime = 987654321
    error_note = 'Cannot update utime of file'
    try:
        os.utime(file_path, (atime, mtime))
    except Exception as e:
        raise AudioConversionError(str(e))

# Generated at 2022-06-12 19:11:30.409696
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    from ..utils import format_bytes

    video_file = b'\0' * 1024 * 1024 * 10
    dir_tmp = tempfile.mkdtemp()
    file_path = os.path.join(dir_tmp, 'file_tmp')
    with open(file_path, 'wb') as f:
        f.write(video_file)
    pp = PostProcessor(None)
    pp.try_utime(file_path, 0, 0)
    shutil.rmtree(dir_tmp)

# Generated at 2022-06-12 19:11:37.113480
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class Downloader(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, text):
            warnings.append(text)

    pp = PostProcessor(Downloader())
    warnings = []
    pp.try_utime('/tmp/abc', 10, 10)
    assert warnings == []
    pp.try_utime('/tmp/abc/def', 10, 10)
    assert warnings == ['Cannot update utime of file']

# Generated at 2022-06-12 19:11:45.035669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    fname = 'unittestfile'
    open(fname, 'w').close()
    pp = PostProcessor(None)
    pp.try_utime(fname, 0, 0)
    pp.try_utime(fname, 1, 1)
    pp.try_utime(fname, 2, 2)
    pp.try_utime(fname, 3, 3)
    pp.try_utime(fname, 4, 4)
    pp.try_utime(fname, 5, 5)
    pp.try_utime(fname, 6, 6)
    pp.try_utime(fname, 7, 7)
    pp.try_utime(fname, 8, 8)
    pp.try_utime(fname, 9, 9)
    pp.try_ut

# Generated at 2022-06-12 19:11:53.860557
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..pytest_extensions import make_temp_directory

    # Preparation
    with make_temp_directory() as tmp_dir:
        path = tmp_dir / 'file_without_utime'
        with open(path, 'w') as f:
            f.write('hey, I am a file')

        # Action
        pp = PostProcessor(downloader=None)
        pp.try_utime(
            path=path,
            atime=100,
            mtime=100,
            errnote='Chyba',
        )

        # Assertions
        stat = os.stat(path)
        assert stat.st_atime == 100
        assert stat.st_mtime == 100

# Generated at 2022-06-12 19:12:00.552940
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil

    # Make a temporary directory and change the current directory to it
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a file and set the file access time and modification time
    f = open('temp.txt', 'w')
    f.close()
    atime = time.time()
    mtime = atime - 1000
    os.utime('temp.txt', (atime, mtime))

    # Create a PostProcessor object, change the access time and modification time
    post_processor = PostProcessor()
    atime = time.time()
    mtime = atime - 1000

    # Change the file name to non-ascii
    if os.name == 'nt':
        import locale

# Generated at 2022-06-12 19:12:09.820695
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile

    from ..utils import PostProcessor

    class TestPP(PostProcessor):

        def run(self, info):
            return [], info

    pp = TestPP()
    tmpdir = tempfile.mkdtemp()
    fpath = os.path.join(tmpdir, 'test-postprocess')
    with open(fpath, 'w'):
        os.utime(fpath, (0, 0))

    st = os.stat(fpath)
    atime, mtime = st.st_atime, st.st_mtime

    # Because os.utime doesn't work correctly with atime,
    # This test only checks mtime
    pp.try_utime(fpath, atime + 10, mtime + 10)
    st = os.stat(fpath)

# Generated at 2022-06-12 19:12:19.171402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import os.path
    import tempfile

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:12:21.931375
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        raise PostProcessor('this is an error')
    except PostProcessor as e:
        print(e)


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:12:35.862410
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_downloader import FakeYDL
    from .test_downloader import _prepare_fake_file, _write_fake_file

    # Creation of temporary test file
    temp_filename = 'file_no_exist.tmp'
    _prepare_fake_file([(temp_filename, 0)])

    # Creation of PostProcessor object for the test
    pp = PostProcessor(FakeYDL())

    # Try the method with the temp file
    pp.try_utime(temp_filename, 0, 0)

    # Check that the file has been deleted
    assert not os.path.exists(temp_filename)

    # Creation of temporary test file
    temp_filename = 'file_no_exist.tmp'
    _write_fake_file(temp_filename)

    # Try the method with the temp file
   

# Generated at 2022-06-12 19:12:45.925166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    def get_python_version_string():
        return '%s.%s.%s' % (sys.version_info[0], sys.version_info[1], sys.version_info[2])

    if get_python_version_string() == '2.7.12':
        from backports import lzma
    else:
        import lzma

    if get_python_version_string() == '3.4.4':
        from backports import shutil_which
    else:
        from shutil import which as shutil_which

    description = ('This is a unit test for method try_utime of class PostProcessor to make sure,'
                   ' it can be executed without errors.')


# Generated at 2022-06-12 19:12:57.257367
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import io
    import shutil
    import tempfile
    import datetime
    import zipfile
    import subprocess
    import re
    import time
    import subprocess
    import collections

    import pytest

    if not shutil.which('ffmpeg'):
        pytest.skip("ffmpeg required for this test")

    from ytdl.postprocessor import PostProcessor

    def run(video_file, audio_file, start_time, end_time, out_file):
        pp = PostProcessor()
        ffmpeg_path = shutil.which('ffmpeg')

# Generated at 2022-06-12 19:13:03.610387
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import sys
    import stat
    import tempfile

    if sys.platform == 'win32':
        return

    atime = time.time()
    mtime = atime - 60
    with tempfile.NamedTemporaryFile() as f:
        pp = PostProcessor(None)
        pp.try_utime(f.name, atime, mtime, errnote='test note')
        st = os.stat(f.name)
        assert stat.S_IMODE(st.st_mode) == 0o600
        assert st.st_mtime == mtime

# Generated at 2022-06-12 19:13:14.135855
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    dummy_file = tmpdir + "/dummy_file"
    # Create a dummy file
    open(dummy_file, "w").close()

    # Get the timestamp of the dummy file
    mtime = time.localtime(os.stat(dummy_file).st_mtime)
    atime = time.localtime(os.stat(dummy_file).st_atime)
    # Change the timestamp of the dummy file
    os.utime(dummy_file, (0, 0))
    # Create a postprocessor object and launch the method try_utime
    pp = PostProcessor(None)

# Generated at 2022-06-12 19:13:25.606352
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeYDL
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor

    class TestPP(PostProcessor):
        pass

    class DummyInfoExtractor(InfoExtractor):
        IE_NAME = 'dummy'

        def __init__(self, downloader=None):
            super(DummyInfoExtractor, self).__init__(downloader)

        def _real_extract(self, url):
            return {'id': '123', 'title': 'dummy'}

    InfoExtractor._ALL_CLASSES.append(DummyInfoExtractor)
    ie = YoutubeIE(FakeYDL())

# Generated at 2022-06-12 19:13:33.424932
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This code is for the benefit of future developers, not for you
    try:
        import unittest2 as unittest  # for Python2.6
    except ImportError:
        import unittest
    from ..compat import PY2

    class MockDownloader(object):
        def __init__(self):
            self.result = None

        def report_warning(self, message):
            self.result = message

    class TestPostProcessor(unittest.TestCase):
        @staticmethod
        def test_try_utime():
            import tempfile
            import shutil
            import datetime
            from ..utils import get_filesystem_encoding
            # create a temporary directory
            targetdir = tempfile.mkdtemp()
            # create a temporary file
            targetfile = tempfile.NamedTemporaryFile

# Generated at 2022-06-12 19:13:40.030096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import YoutubeDL
    class FakePP(PostProcessor):
        def run(self, information):
            self.try_utime(os.path.join('test_try_utime.txt'), 0, 0)
            return [], information
    ydl = YoutubeDL()
    ydl.add_post_processor(FakePP())
    open('test_try_utime.txt', 'w').close()
    ydl.download(['http://example.com/'])
    os.remove('test_try_utime.txt')

# Generated at 2022-06-12 19:13:51.422907
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create test object
    pp = PostProcessor(None)
    # Create a file for testing
    f = open('test.txt', 'w')
    f.write('Test')
    f.close()
    # Default behaviour, cannot update utime of file: no error raised
    pp.try_utime('test.txt', 0, 0)
    # It can take a name of the exception
    pp.try_utime('test.txt', 0, 0, 'Cannot update time')
    # It can take a filename
    pp.try_utime('test.txt', 0, 0, 'test.txt')
    # It can take a message
    pp.try_utime('test.txt', 0, 0, 'Cannot update time of file test.txt')
    # The file is successfully deleted

# Generated at 2022-06-12 19:13:57.347667
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.remove('./test_file')
    except OSError:
        pass
    try:
        os.remove('./test_file_utime')
    except OSError:
        pass
    test_file = open('./test_file', 'w')
    assert test_file != None
    test_file.close()
    import shutil
    shutil.copy('./test_file', './test_file_utime')
    import time
    import datetime
    atime = time.mktime(datetime.datetime.strptime('2011-01-01 00:00:00', '%Y-%m-%d %H:%M:%S').timetuple())

# Generated at 2022-06-12 19:14:04.019118
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:14:15.157037
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class Dummy(object):
        def __init__(self):
            self.params = {}
            self._warned = None

        def report_warning(self, msg):
            self._warned = msg

    class TestPP(PostProcessor):
        def __init__(self, downloader=None, *args, **kwargs):
            self._downloader = downloader
            self._warned = None

    def is_file_older_than(path, mtime):
        return os.path.exists(path) and os.path.getmtime(path) < mtime

    import tempfile
    import shutil
    import time
    import os

    dir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:14:25.866935
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeYDL
    from .extractor import fake_extractor
    from .postprocessor import PostProcessor
    ie = fake_extractor()
    ydl = FakeYDL()
    pp = PostProcessor(ydl)

# Generated at 2022-06-12 19:14:34.723437
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL
    from tempfile import NamedTemporaryFile

    def _test_try_utime(method):
        ydl = YoutubeDL()
        ydl.params['verbose'] = True
        pp = PostProcessor(ydl)
        tmpfile = NamedTemporaryFile(delete=False)
        os.utime(tmpfile.name, (1470168000, 1470168000))
        atime, mtime = os.path.getatime(tmpfile.name), os.path.getmtime(tmpfile.name)
        try:
            method(pp, tmpfile.name)
        except Exception:
            pass
        finally:
            tmpfile.close()
            os.unlink(tmpfile.name)
        assert (atime, mtime) == os.path.get

# Generated at 2022-06-12 19:14:45.944448
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    print('testing try_utime()')
    import codecs
    import tempfile
    import time
    from ..downloader import FakeDownloader

    dl = FakeDownloader()
    original = b'Hello world'
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
        f.write(original)
        path = f.name
        postprocessor = PostProcessor(downloader=dl)
        atime = time.time()
        mtime = atime - 1234     # some time in the past
        postprocessor.try_utime(path, atime, mtime)
        with codecs.open(path, 'rb', encoding='utf-8') as f2:
            assert f2.read() == original
        postprocessor.try_utime(path, -1, -1)

# Generated at 2022-06-12 19:14:56.625993
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    import calendar
    import datetime
    import time
    import tempfile
    import os

    def _datetime_to_timestamp(dt):
        return int(calendar.timegm(dt.utctimetuple()))

    # Create a dummy file
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()

    # Get mtime and atime of dummy file
    stat = os.stat(tmp_file.name)
    mtime = _datetime_to_timestamp(datetime.datetime.utcfromtimestamp(stat.st_mtime))

# Generated at 2022-06-12 19:15:00.786424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor(None)
    f = open('test.txt', 'w')
    f.close()
    p.try_utime('test.txt', 0, 1)
    os.unlink('test.txt')

# Generated at 2022-06-12 19:15:09.224355
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    from ..downloader import get_suitable_downloader

    def check_utime_accuracy(utime_set, utime_get, accuracy=5):
        if abs(utime_set - utime_get) > accuracy:
            raise AssertionError("utime lost accuracy while setting %s, getting %s" %
                                (utime_set, utime_get))
    downloader = get_suitable_downloader(None, None, None, None)
    PP = PostProcessor(downloader)
    fd, temp_filename = tempfile.mkstemp()
    for filepath in [b"", b"/", b"\\a", b"\\a", encodeFilename(temp_filename)]:
        now = time.time()

# Generated at 2022-06-12 19:15:18.563086
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from .common import FakeYDL
    class TestPostProcessor(PostProcessor):
        def __init__(self, ydl):
            self._downloader = ydl
            self.mtime = datetime.datetime(2006, 1, 12, 12, 34, 56)
    pp = TestPostProcessor(FakeYDL({}))
    path = 'test-video.flv'
    with open(path, 'w') as f:
        f.write('test-video')
    pp.try_utime(path, None, pp.mtime, errnote='Test utime')
    stat = os.stat(path)
    assert int(stat.st_mtime) == int(pp.mtime.strftime("%s"))

# Generated at 2022-06-12 19:15:19.256213
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # This method will be tested in test_utils
    pass

# Generated at 2022-06-12 19:15:42.401489
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from .compat import mock
    from .downloader import Downloader

    # date and time information of file
    atime = 1409929608.0
    mtime = 1409929609.0
    # information that can be checked
    dt_atime = datetime.datetime.fromtimestamp(atime)
    dt_mtime = datetime.datetime.fromtimestamp(mtime)
    # general information
    filename = 'filename.txt'

    # mock os.utime
    with mock.patch('os.utime') as mocked_utime:
        # test, if utime not changed
        pp = PostProcessor(Downloader())
        pp.try_utime(filename, atime, mtime)

# Generated at 2022-06-12 19:15:53.105079
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import shutil
    import tempfile
    import os
    import errno

    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile = tmpfile.name
    f = open(tmpfile, 'w+')
    pp = PostProcessor(None)
    # Test that the atime, mtime are changed
    stats = os.stat(tmpfile)
    pp.try_utime(tmpfile, atime=stats.st_atime - 100, mtime=stats.st_mtime - 100)
    new_stats = os.stat(tmpfile)
    assert new_stats.st_atime - 100 == stats.st_atime
    assert new_stats.st_mtime - 100 == stats.st_mtime

    # Test that if the file is deleted after we create it the time is not

# Generated at 2022-06-12 19:16:02.458774
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import platform
    # Windows has not chmod
    if platform.system().lower() == 'windows':
        return
    from ..YoutubeDL import YoutubeDL
    from .common import DownloadDirTest
    from .test_postprocessor import PostProcessorTest

    def _run_test_PostProcessor_try_utime(file_to_test, path_to_test):
        """Download file_to_test and compare its modification time with that of path_to_test"""

        ydl = YoutubeDL(DownloadDirTest.params)
        pp = PostProcessorTest(ydl)
        printed_lines = list(ydl.my_print(args=[file_to_test]))
        assert printed_lines

        # Look for the line that has the downloaded file
        downloaded_file_line = None

# Generated at 2022-06-12 19:16:12.445607
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Unit test for PostProcessor method try_utime.

    This test is also useful to check that utime works as expected in
    your system.
    """
    import time
    import tempfile
    import os
    import shutil
    import stat

    # We create a temporary file to test the functionality of try_utime
    # method.

# Generated at 2022-06-12 19:16:17.621755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from datetime import datetime

    # Create a folder in the system temporary directory
    folder_name = tempfile.mkdtemp()

    file_name = os.path.join(folder_name, "out.flv")

    # Create a file in the folder
    f = open(file_name, 'w')
    f.close()

    # Set last modification date of the file to a future date
    t = (datetime(2030, 1, 1, 0, 0, 0) -
            datetime(1970, 1, 1, 0, 0, 0)).total_seconds()

    try:
        os.utime(file_name, (t, t))
    except Exception:
        assert False, 'Cannot update utime of file'

    # Get

# Generated at 2022-06-12 19:16:28.651485
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import info_dict
    from ..downloader import Downloader
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .xattrs import XAttrMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    from .ffmpegmetadata import FFmpegMetadataPP

    files_to_clean = []
    file_to_clean = 'postprocessor.test'
    PostProcessor.try_utime(file_to_clean, 0, 0)
    files_to_clean.append(file_to_clean)
    PostProcessor.try_utime(file_to_clean, 0, 0)

# Generated at 2022-06-12 19:16:36.876786
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    from .common import FakeYDL

    def mock_utime(fn, atime, mtime):
        raise OSError('Fake OSError')

    pp = PostProcessor(FakeYDL())
    pp.try_utime('fake/file.txt', 1, 1)

    os.utime = mock_utime
    pp.try_utime('fake/file.txt', 1, 1)

# Generated at 2022-06-12 19:16:44.828006
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Initialize a PostProcessor object, make it try to update
    the access/modification time of a nonexistent file, report
    that the access/modification time of the nonexistent file
    wasn't updated, and check with assertRaises that
    a RuntimeError has been raised while reporting that the access/
    modification time of the nonexistent file wasn't updated.
    """
    postprocessor = PostProcessor()

    # Specify a nonexistent file.
    path = 'nonexistent_file'

    # Specify arbitrary integer values for access and modification times.
    atime = 42
    mtime = 128

    # The access/modification time of the nonexistent file hasn't been updated.
    errnote = 'The access/modification time of %s hasn\'t been updated.' %path


# Generated at 2022-06-12 19:16:54.391264
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import platform
    import calendar
    import time
    import unittest
    import tempfile

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            import io
            PostProcessor.__init__(self)
            self.returned_list = io.BytesIO()

        def run(self, information):
            self.try_utime(information['filepath'], *time.gmtime(calendar.timegm((2019, 2, 5, 2, 1, 2, 0, 0, 0)))[:3], errnote='Cannot update utime of file')
            return [self.returned_list], None

    class TestDownloader(object):
        def report_warning(self, msg):
            self.msg = msg


# Generated at 2022-06-12 19:17:04.504894
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Mocking downloader class
    class Downloader:
        def __init__(self):
            self.warning_count = 0

        def report_warning(self, message):
            self.warning_count += 1
    downloader = Downloader()

    # Mocking self in PostProcessor class
    class PostProcessor_:
        def __init__(self, downloader=downloader):
            self._downloader = downloader
        try_utime = PostProcessor.try_utime

    # Test exist file
    current_file = __file__
    PostProcessor_().try_utime(current_file, atime=10, mtime=10)
    assert downloader.warning_count == 0

    # Test unexist file
    unexist_file = 'unexist_file'
    PostProcessor_().try_ut

# Generated at 2022-06-12 19:17:33.563420
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            os.utime(encodeFilename(path), (atime, mtime))

    p = TestPostProcessor()
    p.try_utime('testfile', 'testatime', 'testmtime')

# Generated at 2022-06-12 19:17:44.111449
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import tempfile
    import os
    import shutil
    import sys

    try:
        os.utime('', None)  # Check if utime accepts None
    except TypeError:
        # Python 2 raise TypeError
        return

    if not sys.platform.startswith('linux'):
        # https://bugs.python.org/issue29093
        return

    dir_temp = tempfile.mkdtemp()
    filename = dir_temp + '/temp.txt'

# Generated at 2022-06-12 19:17:48.406624
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class _FakeDownloader(object):
        def report_warning(self, errnote):
            pass
    _downloader = _FakeDownloader()
    pp = PostProcessor(_downloader)
    assert pp.try_utime('example_path', 'example_atime', 'example_mtime') is None

# Generated at 2022-06-12 19:17:59.575791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil

    # create temp file
    test_fp = tempfile.NamedTemporaryFile(delete=False)
    test_fp.close()

    class FakeDownloader:
        def report_warning(self, message):
            pass

    pp = PostProcessor(FakeDownloader())

    # create an arbitrary timestamp for test purpose
    class arbitrary:
        atime = 1133157466.3372000
        mtime = 1133157856.4842000

    pp.try_utime(test_fp.name, arbitrary.atime, arbitrary.mtime)

    # test if the file's timestamp has been updated
    t = os.stat(test_fp.name)
    assert t.st_atime == arbitrary.atime
    assert t.st_mtime == arbitrary.mtime

    # clean up temp file

# Generated at 2022-06-12 19:18:11.220415
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import get_testdata_file

    # Preparing downloader
    d = YoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'writedescription': True,
        'writeinfojson': True,
        'simulate': True,
        'restrictfilenames': True,
        'no_warnings': True,
        'logger': YoutubeDL.std_logger,
        'daterange': DateRange(),
    })

    # Preparing post processor
    pp = PostProcessor(d)

    pp.try_utime(get_testdata_file('postprocessor', 'subs.en.srt'), 0, 0)

# Generated at 2022-06-12 19:18:21.332996
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors
    from ..downloader import gen_ytdl_downloader
    from ..postprocessor import PostProcessor

    # Prepare a fake downloader
    downloader = gen_ytdl_downloader()

    # Extractors are loaded to be able to get one
    gen_extractors(downloader)

    id_ = 'test'
    # Prepare a fake information dictionary

# Generated at 2022-06-12 19:18:26.537072
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader():
        def report_warning(self, message):
            pass
    class FakePostProcessor(PostProcessor):
        def __init__(self):
            self._configuration = []
            self._downloader = FakeDownloader()
    fake_postprocessor = FakePostProcessor()
    fake_postprocessor.try_utime('/path/to/non/existing/file', 0, 0)
    fake_postprocessor.try_utime('/path/to/existing/file', 0, 0, 'Error')

# Generated at 2022-06-12 19:18:27.527485
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO Implement a test
    pass

# Generated at 2022-06-12 19:18:35.812816
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from .common import FileDownloader
    from .ffmpeg import FFmpegVideoConvertorPP
    from .xattrpp import XAttrMetadataPP
    import time

    d = Downloader(params={'format': 'bestaudio'})
    fd = FileDownloader(d, {'outtmpl': '%(id)s-%(title)s.%(ext)s'}, YoutubeIE(), 'videoid', {'title': 'video title'})
    fd.add_info_extractor(YoutubeIE())  # register the extractor
    fd.process_info(fd.ie.extract('http://youtube.com/watch?v=BaW_jenozKc'))


# Generated at 2022-06-12 19:18:45.370497
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    import os

    # Create a temp file
    fd, fn = tempfile.mkstemp('.test')
    os.write(fd, 'test')
    os.close(fd)

    # Get mtime of the temp file
    mtime = os.stat(fn).st_mtime
    mtime_dt = datetime.datetime.fromtimestamp(mtime)

    # Create a PostProcessor
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())

    # Set mtime of the temp file to now + 3600
    pp.try_utime(fn, time.time() + 3600, time.time() + 3600)
    assert os.stat(fn).st_mtime > mtime + 3500

    #

# Generated at 2022-06-12 19:19:57.576569
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Test that PostProcessor.try_utime() raises an OSError exception"""
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..utils import FakeYDL

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)

    # Instantiate a FileDownloader object