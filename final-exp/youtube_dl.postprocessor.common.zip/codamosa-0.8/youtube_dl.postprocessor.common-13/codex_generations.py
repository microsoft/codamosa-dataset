

# Generated at 2022-06-12 19:10:01.278506
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os

    # Create a temp folder to be used during the test
    # It will be deleted at the end of the test
    temp_directory = tempfile.mkdtemp()

    # Create a temp file to be tested
    temp_file = tempfile.NamedTemporaryFile(suffix=".tmp", dir=temp_directory)

    # Store the current modification time of the file
    prev_mtime = os.path.getmtime(temp_file.name)

    # Wait a second
    time.sleep(1)


# Generated at 2022-06-12 19:10:11.528986
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL
    from .compat import TemporaryFile
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    import shutil
    import sys
    import tempfile
    import time

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.to_stderr = self.to_stdout = self.to_screen
            self.params['logger'] = self
            self._err_counts = {}

        def warning(self, message):
            super(FakeYDL, self).report_warning(message)
            self._err_counts['warning'] += 1


# Generated at 2022-06-12 19:10:16.507942
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader:
        def report_warning(self, errnote):
            self.errnote = errnote


    post_processor = PostProcessor(DummyDownloader())

    # Test if exception message is correct when utime raises exception
    post_processor.try_utime(path='path', atime=1427897040.0, mtime=1427897040.0)
    assert post_processor._downloader.errnote == 'Cannot update utime of file'

    # Test if error message is empty when utime does not raise exception
    post_processor.try_utime(path='path', atime=1427897040.0, mtime=1427897040.0, errnote='')
    assert post_processor._downloader.errnote == ''

# Generated at 2022-06-12 19:10:23.969670
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp
    import time
    import shutil

    # Create a file with the current time encoded in its name
    fd, name = mkstemp(prefix='utime.', suffix='.test')
    time_str = time.asctime(time.gmtime(time.time()))
    name = name.replace('utime.', 'utime.' + time_str + '.')
    os.close(fd)

    # Create a dummy postprocessor class. We need to patch this class
    # to avoid logging any warning while testing
    class TestPostProcessor(PostProcessor):
        def __init__(self, params=None):
            PostProcessor.__init__(self)
            self._downloader = lambda: None
            self._downloader.params = params or {}

# Generated at 2022-06-12 19:10:35.854746
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader(object):
        def __init__(self):
            self._errors = 0
        def report_warning(self, *args):
            self._errors += 1
    import time
    pp = PostProcessor(downloader=MockDownloader())
    path = 'test'
    def _utime(path, times):
        if len(times) != 2:
            raise Exception('ERR!')
    builtins_utime = os.utime
    os.utime = _utime
    cur_time = time.time()
    pp.try_utime(path, cur_time, cur_time)
    assert pp._downloader._errors == 0
    pp.try_utime(path, cur_time, cur_time, 'ERR!')
    assert pp._downloader._errors == 1
   

# Generated at 2022-06-12 19:10:44.412354
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..postprocessor import PostProcessor
    import time
    import os
    import tempfile

    def touch(fname, times=None):
        with open(fname, 'a'):
            os.utime(fname, times)

    fd, fname = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-12 19:10:54.917941
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys, tempfile, time

    sys.modules['__main__'].params = {'outtmpl': '%(id)s-%(ext)s'}
    path = '%(id)s-%(ext)s'
    pp = PostProcessor(downloader=None)

    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)
    try:
        os.utime(tmp_path, (0, 0))
    except:
        pytest.skip("Cannot set access/modification time to zero")

    # Test successfully setting mtime
    pp.try_utime(tmp_path, None, 10)
    assert os.stat(tmp_path).st_mtime == 10

    # Test successfully setting atime

# Generated at 2022-06-12 19:11:00.045358
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        atime = lambda self: 0
        mtime = lambda self: 0
        path = 'test'
        errnote = 'This is a utime test'

    TestPostProcessor().try_utime(TestPostProcessor.path, TestPostProcessor.atime, TestPostProcessor.mtime, TestPostProcessor.errnote)

# Generated at 2022-06-12 19:11:08.353096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import shutil
    from tempfile import mkdtemp
    from ..compat import is_py2
    from ..utils import encodeFilename
    from ..downloader.common import FileDownloader

    tmpdir = mkdtemp()

# Generated at 2022-06-12 19:11:12.776045
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    pp = PostProcessor(FileDownloader())
    path = 'path'
    atime = 11111
    mtime = 22222
    errnote = 'errnote'
    pp.try_utime(path, atime, mtime, errnote)

# Generated at 2022-06-12 19:11:20.667346
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    import time
    import sys
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'\x7fELF' + bytearray(os.path.getsize(sys.executable) - 4))
    f.close()
    pp.try_utime(f.name, *time.gmtime(os.path.getmtime(sys.executable))[:3])
    os.unlink(f.name)

# Generated at 2022-06-12 19:11:32.407785
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import time
    import tempfile
    from ..utils import PostProcessor

    def check_utime(path, atime, mtime):
        stat = os.stat(path)
        return stat.st_atime == atime and stat.st_mtime == mtime

    def check_utime_warning(path, atime, mtime, errnote):
        postprocessor = PostProcessor()
        postprocessor._downloader = MockDownloader()
        postprocessor.try_utime(path, atime, mtime, errnote)
        assert postprocessor._downloader.get_warning() == errnote

    def check_utime_no_warning(path, atime, mtime, errnote):
        postprocessor = PostProcessor()
        postprocessor._downloader = MockDownloader()
       

# Generated at 2022-06-12 19:11:42.739575
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import os
    import stat

    # prepare example tempdir and filepath
    example_tempdir = tempfile.mkdtemp(prefix='youtube-dl-test-PostProcessor-try_utime-')
    example_filepath = os.path.join(example_tempdir, 'downloaded_video')
    with open(example_filepath, "wb") as outf:
        outf.write(b"test")

    # example file time
    now_time = time.time()
    past_time = now_time - 3600
    futu_time = now_time + 3600
    os.utime(example_filepath, (past_time, past_time))

    pp = PostProcessor(None)

# Generated at 2022-06-12 19:11:53.683229
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL
    from .compat import compat_os_name
    import time
    import platform

    ydl = FakeYDL()

    pp = PostProcessor(ydl)
    # Create a file and get its mtime
    curr_mtime = time.time()
    f = open('test.bin', 'w')
    f.write('random binary content')
    f.close()
    if compat_os_name == 'nt':
        curr_mtime -= 60*60*24  # os.utime in windows cannot set dates in future
    # Change mtime of file
    pp.try_utime('test.bin', curr_mtime, curr_mtime + 1000)
    new_mtime = os.path.getmtime('test.bin')
    assert time.strftime

# Generated at 2022-06-12 19:12:01.986341
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import os
    class FakePostProcessor:
        def report_warning(self,warning):
            print("Warning: " + warning)
    pp = FakePostProcessor()
    tmpdir = tempfile.mkdtemp()
    try:
        filename = tempfile.mkstemp(dir=tmpdir)[1]
        pp.try_utime(filename,0,1)
        assert os.path.getatime(filename) == 0
        assert os.path.getmtime(filename) == 1
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:12:06.516234
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()

    class downloader:
        def report_warning(self, msg):
            self.msg = msg

    pp._downloader = downloader()
    pp.try_utime('', 0, 0)
    assert pp._downloader.msg is None
    pp.try_utime('', 0, 0, errnote='foo')
    assert pp._downloader.msg == 'foo'

# Generated at 2022-06-12 19:12:16.507528
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())
    import time
    import os
    import tempfile
    import shutil
    TEST_PATH = os.path.join(tempfile.gettempdir(), 'youtube-dl_test_utime')

# Generated at 2022-06-12 19:12:24.249502
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    from time import time
    from .compat import compat_makedirs
    from .extractor import get_info_extractor


    class TestPostProcessor(PostProcessor):
        def run(self, info):
            assert 'filepath' in info

            atime, mtime = time(), time() - 1000
            for i in range(5):
                self.try_utime(info['filepath'], atime, mtime)

            # Update time
            atime, mtime = time(), time() - 1000

            return [info['filepath']], info


    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create the downloader

# Generated at 2022-06-12 19:12:34.734418
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from datetime import datetime
    try:
        # check if file exists
        os.unlink('test.test')
    except:
        pass
    open('test.test', 'w').close()

    pp = PostProcessor(None)
    pp.try_utime('test.test', 0, 0, None)
    utime = datetime.fromtimestamp(os.path.getmtime('test.test'))
    try:
        # check if file's utime is 0
        assert (utime - datetime(1970, 1, 1)).seconds == 0
    finally:
        os.unlink('test.test')

    # if file does not exist, utime should not be changed
    pp.try_utime('test.test', 0, 0, None)

# Generated at 2022-06-12 19:12:39.443207
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class _PostProcessor(_PostProcessor):
        def try_utime(self, path, atime, mtime, errnote):
            super(_PostProcessor, self).try_utime(path, atime, mtime, errnote)
    pp = _PostProcessor()
    pp.try_utime(None, 1, 2, 3)
    # TODO: Find a way to test that os.utime is called

# Generated at 2022-06-12 19:12:45.137775
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        PostProcessor().try_utime('/a/b/c', 1000, 2000)
    except Exception:
        assert False

# Generated at 2022-06-12 19:12:56.502346
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile

    path = os.path.join(tempfile.gettempdir(), 'ytdl_test_tmp_file')
    with open(path, 'wb') as f:
        f.write(b'ytdl_test_tmp_file contents')

    time.sleep(1.1)

    # Test that method does not raise any exception
    # when file does exist and file system permission allow it to change the file's timestamp
    postprocessor = PostProcessor(None)
    postprocessor.try_utime(path, 1.0, 1.1, 'Unexpected exception: %s')

    # Test that method does not raise any exception
    # even when file system permission does not allow it to change the file's timestamp
    old_permissions = os.stat(path).st_mode
   

# Generated at 2022-06-12 19:13:02.706545
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    import pytest
    from ytdl.utils import PostProcessor
    from ytdl.extractor.common import InfoExtractor

    _downloader = InfoExtractor()
    _downloader.report_warning = pytest.fail

    pp = PostProcessor(_downloader)
    pp.try_utime(__file__,
            datetime.datetime.now().timestamp(),
            datetime.datetime.now().timestamp(),
            errnote='Cannot update utime of file')

# Generated at 2022-06-12 19:13:06.791436
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test import (
        FakeYDL,
        setUpPostProcessor,
        tearDownPostProcessor,
    )
    import os

    class TestPostProcessor(PostProcessor):

        def utime(self, path, atime, mtime):
            raise ValueError()

    pp = TestPostProcessor()

    setUpPostProcessor(pp)
    pp.set_downloader(FakeYDL())

    pp.try_utime('/path/', 0, 0)
    pp.try_utime('/path', 0, 0)

    tearDownPostProcessor(pp)

# Generated at 2022-06-12 19:13:14.662535
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import stat
    import time
    import sys
    import tempfile


# Generated at 2022-06-12 19:13:24.760795
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import os

    tmp_path = os.path.join(tempfile.gettempdir(), 'test_PostProcessor_try_utime')

    with open(tmp_path, 'w') as f:
        f.write('test')

    def mock_report_warning(message):
        assert message == 'Cannot update utime of file'

    pp = PostProcessor(downloader=object())
    pp.set_downloader(object())
    pp.run = mock_report_warning

    pp.try_utime(tmp_path, 1, 2, errnote='Cannot update utime of file')

    try:
        os.remove(tmp_path)
    except OSError:
        pass

# Generated at 2022-06-12 19:13:32.958238
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import time
    import shutil
    from ..utils import PostProcessor
    import filecmp

    # Create a temporary directory
    work_dir = tempfile.mkdtemp(prefix='ytdl_test_PostProcessor_try_utime')
    tmp_dir = tempfile.mkdtemp(prefix='ytdl_test_PostProcessor_try_utime', dir=work_dir)

# Generated at 2022-06-12 19:13:33.533700
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:13:40.780281
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPP(PostProcessor):
        def run(self, info):
            try:
                os.unlink(encodeFilename(info['filepath']))
            except (IOError, OSError):
                pass
            return [], info

    info = {
        'filepath': 'fake'
    }
    pp = TestPP()
    pp.run(info)
    os.utime = None
    try:
        pp.try_utime('fake', 1, 1)
    except TypeError:
        pass
    else:
        raise AssertionError('Test for try_utime failed!')

# Generated at 2022-06-12 19:13:52.164789
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL

    def test_sanity(test_instance):
        test_instance.report_warning.assert_called_with(u'Cannot update utime of file')
        test_instance.report_warning.reset_mock()

    def test_utime(test_instance):
        test_instance.report_warning.assert_not_called()

    # Mock utime to fail
    original_utime = os.utime

    def mock_utime(path, times):
        raise IOError

    os.utime = mock_utime

    with FakeYDL(YoutubeDL) as ydl:
        pp = PostProcessor(ydl)
        pp.try_utime('file', 1, 0)
        test_sanity(ydl)

       

# Generated at 2022-06-12 19:14:06.396497
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import sys
    import os

    class _MockDownloader():
        @staticmethod
        def report_warning(message):
            print('Warning: ' + message)

    postprocessor = PostProcessor(_MockDownloader())

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'test_PostProcessor_try_utime')

# Generated at 2022-06-12 19:14:15.960109
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test that try_utime actually sets file modification time to argument provided
    from .downloader import Downloader
    from .extractor.common import InfoExtractor, _match_id
    from .fileutils import temp_name, AtomicSaver, AtomicSavingError

    with temp_name(suffix='.test_utime') as temp_file:
        with open(temp_file, 'wt') as f:
            f.write('test_PostProcessor_try_utime\n')
        downloader = Downloader(params={})
        postprocessor = PostProcessor(downloader=downloader)

# Generated at 2022-06-12 19:14:24.996925
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors

    tmp = Downloader(params={
        'username': 'foo', 'password': 'bar',
        'nopart': True, 'quiet': True, 'forcetitle': True,
        'format': 'best', 'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    })
    list_extractors(tmp)
    tmp.add_post_processor(DummyPostProcessor(tmp))
    tmp.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])



# Generated at 2022-06-12 19:14:33.312856
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from datetime import datetime

    import pytz
    from ytdl.extractor import YoutubeIE
    from ytdl.downloader import Downloader
    from ytdl.compat import stdout
    from ytdl.postprocessor.common import PostProcessor


# Generated at 2022-06-12 19:14:35.886169
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()
    # There isn't any file with this name, so os.utime should fail
    p.try_utime("nonexistentfile",0,0)

# Generated at 2022-06-12 19:14:39.908559
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    p = PostProcessor()
    class Dummy:
        def report_warning(self, message):
            assert message == 'Cannot update utime of file'

    p._downloader = Dummy()
    # test for no exception
    p.try_utime('foo', 1, 1)
    # test for exception
    p.try_utime(None, 1, 1)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:14:50.612168
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    files = []
    class FakeDownloader():
        class FakeYDL():
            class FakeParams():
                logtostderr = False
            params = FakeParams()
        ydl = FakeYDL()
        def to_screen(self, string):
            return string
        def report_warning(self, warn_string):
            files.append(warn_string)
    pp = PostProcessor(FakeDownloader())
    try:
        pp.try_utime('test.txt', 1234567890, 1234567890, 'File system does not support utime')
    except Exception as e:
        pass
    else:
        assert False, 'Expected error'
    assert files[0] == 'File system does not support utime'

# Generated at 2022-06-12 19:14:58.248731
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    from youtube_dl.downloader.common import FileDownloader

    with tempfile.NamedTemporaryFile() as f:
        ydl = FileDownloader({})
        ydl.add_info_extractor(None)
        ydl.params['outtmpl'] = f.name
        pp = PostProcessor(ydl)
        t = 1234567
        pp.try_utime(f.name, t, t)
        assert os.path.getmtime(f.name) == t

# Generated at 2022-06-12 19:15:07.816766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import time
    import shutil
    from ..utils import PostProcessor
    import pytest
    import errno

    class mock_downloader(object):
        def __init__(self):
            self.params = {'writedescription': False}

        def report_warning(self, warning):
            pass

    pp = PostProcessor(downloader=mock_downloader())


# Generated at 2022-06-12 19:15:09.291148
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # should not raise an exception
    PostProcessor().try_utime(__file__, None, None)

# Generated at 2022-06-12 19:15:21.986966
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader(object):
        def __init__(self):
            self.warnings = 0

        def report_warning(self, errnote):
            self.warnings += 1

    import datetime
    from .test_utils import FakeFile
    from .test_utils import TEMPDIR
    from .test_utils import TemporaryTestFile
    from .test_utils import unittest

    class UtimeTest(unittest.TestCase):
        def test_utime(self):
            pp = PostProcessor(MockDownloader())
            tmpfile = TemporaryTestFile(TEMPDIR, 'utime.')
            with tmpfile as path:
                f = FakeFile(path)
                atime = mtime = datetime.datetime(2011, 12, 13, 14, 15, 16)
                pp.try_

# Generated at 2022-06-12 19:15:29.717972
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdlnow.downloader import YoutubeDL
    from ytdlnow.postprocessor import PostProcessor
    # Test normal case
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    # Create a dummy file
    path = 'test.txt'
    f = open(encodeFilename(path), 'w')
    f.close()
    pp.try_utime(path, 1, 2)
    os.remove(encodeFilename(path))

# Generated at 2022-06-12 19:15:39.586108
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import six
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    pp = PostProcessor(downloader=ydl)

# Generated at 2022-06-12 19:15:46.294088
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_mock

    def mock_report_warning(self, note):
        self._warning = note
    ydl = YoutubeDL()
    ydl._warning = None
    ydl.report_warning = mock_report_warning
    pp = PostProcessor(ydl)

    # Test that a PostProcessingError is raised if os.utime raises a TypeError
    m = compat_mock.Mock(side_effect=TypeError)
    with compat_mock.patch('os.utime', m):
        pp.try_utime('', 0, 0)
        assert isinstance(ydl._warning, PostProcessingError)
        assert 'Cannot update utime of file' in str(ydl._warning)

    # Test that a PostProcessingError is

# Generated at 2022-06-12 19:15:55.015871
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import os
    from .common import FileDownloader

    # Create a FileDownloader instance and a temp file
    ydl = FileDownloader()
    unused_fd, temp_filename = tempfile.mkstemp(prefix='youtubedl_test_try_utime_')

    # Create a temp file

# Generated at 2022-06-12 19:16:03.796918
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import shutil
    import tempfile
    import time
    import sys

    # First of all, Python 2.6 bug
    # (http://bugs.python.org/issue3905)
    # the os.utime(path, None) do not preserve the access time
    # (only the modification time is preserved)
    #
    # In order to fix this bug, we temporarily monkey patch
    # os.utime in Python 2.6

# Generated at 2022-06-12 19:16:13.396583
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import sys
    # Python 2 and 3 implementation of function get_file_mtime
    if sys.version_info < (3, 3, 0):
        from os.path import getmtime
    else:
        from os import stat

        def getmtime(filename):
            return stat(filename).st_mtime

    # Create a file for testing
    import tempfile
    _, tmp_file = tempfile.mkstemp()
    assert isinstance(tmp_file, str)
    assert tmp_file
    tmp_file = encodeFilename(tmp_file)

    # Get the modification time of the file
    mtime = getmtime(tmp_file)

    # Set datetime_original and datetime_digitized

# Generated at 2022-06-12 19:16:26.472340
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil

    from ..downloaders.external import ExternalFD

    temp_dir = tempfile.mkdtemp()
    try:
        temp_file = os.path.join(temp_dir, "pytube_test")
        with open(temp_file, 'wb'):
            pass
        atime = time.time()
        mtime = atime + 100000
        post_processor = PostProcessor(downloader=ExternalFD(""))
        post_processor.try_utime(temp_file, atime, mtime)
        at, mt = os.stat(temp_file).st_atime, os.stat(temp_file).st_mtime
        assert abs(at - atime) <= 1
        assert abs(mt - mtime) <= 1
    finally:
        shutil

# Generated at 2022-06-12 19:16:38.388650
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    PostProcessor_try_utime
    """
    import tempfile
    import time
    import os
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange

# Generated at 2022-06-12 19:16:50.878755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from pytube import YouTube
    import time

    # Set the following variable to the location of the test file
    test_filepath = os.path.join(os.pardir, 'test', 'test.mp4')

    # Create a test Youtube object
    yt_object = YouTube('https://www.youtube.com/watch?v=S_PtPKlp8pE')

    # Download a test file
    yt_object.set_filename('test')
    video = yt_object.get('mp4')
    video.download(os.path.join(os.pardir, 'test'))

    # Set the file date and time to the old date and time
    os.utime(test_filepath, (1, 1))

    # Get the old date and time
    file_time = os.path.getmtime

# Generated at 2022-06-12 19:17:14.610874
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import stat
    import shutil
    import sys

    if sys.version_info >= (3, 0):
        from unittest import mock
    else:
        from mock import mock

    test_file = 'test.file'
    date = time.time() - 1000

    f = open(test_file, 'wb')
    f.close()

    pp = PostProcessor(None)
    with mock.patch('os.utime') as utime:
        pp.try_utime(test_file, None, None)
        utime.assert_called_once_with(test_file, None)

    with mock.patch('os.utime') as utime:
        pp.try_utime(test_file, date, None)

# Generated at 2022-06-12 19:17:23.498999
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..postprocessor.xattrpp import XAttrMetadataPP

    downloader = FileDownloader()
    pp = XAttrMetadataPP(downloader)
    fname = os.path.join('test', 'downloader', 'test.mp4')
    assert os.path.exists(fname)

    # Set up the destination file
    fdst = os.path.join('test', 'downloader', 'test.dest.mp4')
    os.rename(fname, fdst)
    assert os.path.exists(fdst)

    # Test the method
    pp.try_utime(fdst, 1234, 1234)
    assert os.path.exists(fdst)

    # Clean up
    os.remove(fdst)

# Generated at 2022-06-12 19:17:27.539331
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    import time

    def utime(path, atime, mtime, errnote=None):
        assert False, 'called utime'

    downloader = FileDownloader({})
    downloader.to_stdout = lambda value: None
    downloader.report_warning = lambda errnote: None

    class TestPP(PostProcessor):
        _downloader = downloader

    pp = TestPP()
    pp.try_utime = utime
    try:
        pp.try_utime(__file__, time.time(), time.time(), 'test error')
    except AssertionError:
        pass

# Generated at 2022-06-12 19:17:34.375941
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        from nose.tools import assert_raises
    except ImportError:
        from pytest import raises as assert_raises
    from tempfile import NamedTemporaryFile
    from sys import platform

    class DummyPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.errnote = kwargs.pop('errnote')
            self.warning = False
            super(DummyPostProcessor, self).__init__(*args, **kwargs)

        def report_warning(self, errnote):
            self.warning = True

    with NamedTemporaryFile(delete=False) as f:
        path = f.name

# Generated at 2022-06-12 19:17:45.381435
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    #pylint: disable=missing-docstring
    #pylint: disable=protected-access
    import errno
    import tempfile
    import time
    import shutil

    errnote = 'Cannot update utime of file'

    # Try to modify utime of a non-existing file
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, 'tempfile')
    pp = PostProcessor(None)
    pp.try_utime(temp_path, 1111, 1111, errnote)
    shutil.rmtree(temp_dir)

    # Try to modify utime of existing file
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, 'tempfile')

# Generated at 2022-06-12 19:17:55.144264
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.rename('test1', 'test2')
    except OSError:
        pass
    try:
        os.mkdir('test1')
    except OSError:
        pass
    try:
        os.utime('test1', (1, 1))
    except OSError:
        pass
    try:
        f = open('test1/test2', 'wb')
        f.close()
    except Exception:
        pass

    pp = PostProcessor(None)

    paths = ['test1', 'test2', 'test1/test2']
    for path in paths:
        pp.try_utime(path, 1, 1)
        pp.try_utime(path, 0, 0)

# Generated at 2022-06-12 19:18:04.279278
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from . import FakeInfoExtractor
    from .downloader import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import str, compat_HTTPError

    class BadInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'bad_field'}

    class PostProcessorUTimeTest(PostProcessor):
        def run(self, info):
            if info['id'] == 'bad_field':
                path = os.path.abspath(__file__)
            else:
                path = os.path.abspath(__file__) + '.xxx' # file not exists

# Generated at 2022-06-12 19:18:08.816879
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL
    from tempfile import mkstemp

    (fd, fn) = mkstemp()

    ydl = YoutubeDL()
    pp = PostProcessor(ydl)

    pp.try_utime(fn, 0, 0)
    pp.try_utime(fn, 1, 1)

# Generated at 2022-06-12 19:18:15.344510
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPostProcesesor(PostProcessor):
        def __init__(self):
            self._downloader = object()
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)
            return [], information
            
    import tempfile
    import shutil
    import time
    with tempfile.NamedTemporaryFile() as ntf:
        pp = DummyPostProcesesor()
        try:
            pp.run({'filepath': ntf.name})
        except Exception:
            shutil.rmtree(ntf.name)

    with tempfile.NamedTemporaryFile() as ntf:
        pp = DummyPostProcesesor()

# Generated at 2022-06-12 19:18:24.473083
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test try_utime() by mocking PostProcessor
    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(*args, **kwargs)
            self.warnings = []

        def report_warning(self, msg):
            self.warnings.append(msg)

    # create test file and set current modification time
    import tempfile
    file = tempfile.NamedTemporaryFile()
    import time
    original_time = time.time()
    os.utime(encodeFilename(file.name), (original_time, original_time))
    # Tries to set modification and access times to the original ones
    # which should succeed and do nothing
    pp = MockPostProcessor()
    pp.try_

# Generated at 2022-06-12 19:18:57.336798
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    post_processor = PostProcessor()
    post_processor._downloader = unittest.mock.Mock()
    post_processor.try_utime('filename', 1, 2)

    post_processor._downloader.report_warning.assert_called_with('Cannot update utime of file')

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:19:07.291104
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    PostProcessor._downloader = None
    pp = PostProcessor()
    f = tempfile.NamedTemporaryFile(delete=False)
    orig_time = time.localtime(f.file.stat().st_mtime)
    pp.try_utime(f.name, orig_time.tm_atime, orig_time.tm_mtime, errnote='test')
    assert orig_time.tm_atime == time.localtime(f.file.stat().st_atime)
    assert orig_time.tm_mtime == time.localtime(f.file.stat().st_mtime)
    f.file.close()
    os.unlink(f.name)

# Generated at 2022-06-12 19:19:16.695112
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    from tempfile import NamedTemporaryFile
    from datetime import datetime

    PP = PostProcessor(None)

    # Creating a temporary file
    with NamedTemporaryFile() as f:
        assert f.name is not None

        # Checking file time
        st = os.stat(f.name)

        # Updating file time
        PP.try_utime(f.name, st.st_atime, st.st_mtime, errnote='Test error')

        # Checking again file time
        st2 = os.stat(f.name)

        # Comparing old and new time
        assert st.st_atime == st2.st_atime
        assert st.st_mtime == st2.st_mtime

        # Changing the time of the file
        st = os.stat(f.name)

        #

# Generated at 2022-06-12 19:19:17.246239
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:19:25.152957
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2

    if PY2:
        return

    class FakeDownloader(object):
        def __init__(self):
            self.params = {}

        def report_warning(self, errnote):
            print(errnote)

    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    with open(tmp_file, 'w') as f:
        f.write('')

    pp = PostProcessor(FakeDownloader())

    pp.try_utime(tmp_file, 20, 20, errnote='Cannot update utime of file')
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-12 19:19:29.553485
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..ytdl_mocks import FileDownloaderForTest

    downloader = FileDownloaderForTest()
    pp = PostProcessor(downloader)
    import os.path
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix='.test') as temp_f:
        temp_f.close()
        expectation = os.path.getmtime(temp_f.name)
        pp.try_utime(temp_f.name, 0, expectation)
        assert expectation == os.path.getmtime(temp_f.name)

# Generated at 2022-06-12 19:19:39.487057
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import prepend_extension
    import tempfile
    import shutil
    from .common import FileDownloader

    with tempfile.NamedTemporaryFile(delete=False) as t:
        temp_file_path = t.name
        temp_file_name = t.name.split(os.sep)[-1]
    temp_dir = tempfile.mkdtemp()
    # Download a sample file

# Generated at 2022-06-12 19:19:47.344571
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import stat

    from ..compat import compat_struct_time
    from ..utils import DateRange, date_from_str

    class Downloader(object):
        def report_warning(self, errnote):
            print("Warning: {0}".format(errnote))

    pp = PostProcessor(downloader=Downloader())

    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.tmp')
    tp = open(encodeFilename(path), 'w')
    tp.write("test")
    tp.close()
    pp.try_utime(path, time.time() - 10, time.time() - 8, 'Cannot update utime of file')
    st = os.stat(path)
    assert st.st_

# Generated at 2022-06-12 19:19:57.926411
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FileDownloader
    from .youtubedl import YoutubeDL
    from .extractor import gen_extractors
    from .postprocessor import PostProcessor
    from .utils import DateRange

    import time, os, shutil
    from tempfile import mkdtemp

    # Create dummy FileDownloader instance with fake params