

# Generated at 2022-06-12 19:10:03.402349
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader(object):
        def report_warning(self, msg):
            FakeDownloader.warnings.append(msg)
    class FakePostProcessor(PostProcessor):
        pass

    # Make a FakePostProcessor object
    postprocessor = FakePostProcessor()
    # Make a FakeDownloader object
    downloader = FakeDownloader()
    # Attach the FakeDownloader to the FakePostProcessor
    postprocessor.set_downloader(downloader)

    # Create a temporary text file
    import tempfile
    (testfile_fd, testfile_name) = tempfile.mkstemp(text=True)
    # Get the current mtime of the file
    old_mtime = os.path.getmtime(testfile_name)
    # Change the mtime of the file to the past
    past_

# Generated at 2022-06-12 19:10:12.879184
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import filecmp
    import os
    import shutil
    import stat
    import sys
    import tempfile
    import time
    import unittest

    sys.path.insert(0, os.path.abspath('..'))
    import postprocessor

    # Create a small file to work with
    small_file = tempfile.NamedTemporaryFile(delete=False)
    small_file.write(b'1234\n')
    small_file.close()

    # set creation time in the furture
    os.utime(encodeFilename(small_file.name), (time.time()+3600, time.time()+3600))
    # Set modification time in the past

# Generated at 2022-06-12 19:10:21.529439
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import Downloader
    from .compat import PY2, is_osx

    if not PY2 and is_osx:
        return
    import pytest

    # create a temporary file
    tmpfd, tmpfilepath = tempfile.mkstemp(suffix='.webm')
    os.close(tmpfd)

    # create an empty Downloader
    d = Downloader()
    # PostProcessor.try_utime needs the downloader, so we set it
    pp = PostProcessor(d)

    # get the original modify and access time
    mtime = os.path.getmtime(tmpfilepath)
    atime = os.path.getatime(tmpfilepath)

    # Test the case that the times are not changed
    # try_utime will do nothing

# Generated at 2022-06-12 19:10:30.894743
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    test_path = 'path'
    test_atime = 'atime'
    test_mtime = 'mtime'
    test_errnote = 'errnote'

    class Downloader(object):
        def report_warning(self, errnote):
            self.errnote = errnote

    class Test(PostProcessor):
        def test_method(self, path, atime, mtime, errnote):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote
            self.return_value = super(Test, self).try_utime(path, atime, mtime, errnote)
            return self.return_value

    downloader = Downloader()
    tester = Test(downloader)

# Generated at 2022-06-12 19:10:41.187387
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    postprocessor.py: test for method try_utime of class PostProcessor
    """
    import unittest2
    import shutil
    import errno
    import tempfile
    import sys
    import os

    class fake_downloader:
        def __init__(self):
            self.params = {}
        def to_screen(self, message):
            print(message)
        def report_warning(self, message):
            print(message)

    @unittest2.skipUnless(
        os.name == 'nt', 'Requires Windows')
    class TestPostProcessor_try_utime_win(unittest2.TestCase):
        """
        postprocessor.py: test for method try_utime of class PostProcessor
        """

# Generated at 2022-06-12 19:10:47.076095
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    from subprocess import Popen, PIPE, STDOUT

    TOUCH_NEW_FILE = 0
    TOUCH_NEW_FILE_BEFORE = 1
    TOUCH_CHANGE_ACCESS_TIME = 2
    TOUCH_CHANGE_MODIFICATION_TIME = 3
    TOUCH_CHANGE_ACCESS_AND_MODIFICATION_TIME = 4

    def _post_processor_utime(touch_type, file_path, atime, mtime):
        class FakeDownloader():
            def __init__(self):
                self.report_warning = lambda x: x

        class PPTryUtime(PostProcessor):
            def __init__(self):
                super(PPTryUtime, self).__init__(FakeDownloader())


# Generated at 2022-06-12 19:10:52.440149
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    import tempfile
    import shutil

    _, temp_filename = tempfile.mkstemp(prefix='youtubedl_test_file')

# Generated at 2022-06-12 19:10:58.833994
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class PPStub(PostProcessor):
        def __init__(self, path):
            self.path = path
            self.utime_exception = False

        def try_utime(self, path, atime, mtime, errnote):
            if self.utime_exception:
                raise Exception(errnote)
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote

        def run(self, information):
            self.try_utime(self.path, 0, 0, 'Failed')
            return [], information

    pp = PPStub('/foo.txt')
    pp.run({'filepath': '/foo.txt'})
    assert pp.path == '/foo.txt', 'filepath is incorrect'

# Generated at 2022-06-12 19:11:07.680882
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdl.downloader import FileDownloader
    from ytdl.postprocessor import PostProcessor
    import os
    import datetime
    import tempfile
    import shutil


    tmpdir = tempfile.mkdtemp()

    filename = os.path.join(tmpdir, 'audio.mp3')
    open(filename, "w")

    # Set a old time on the file
    olddate = datetime.datetime(2014, 1, 1)
    os.utime(filename, (olddate.timestamp(), olddate.timestamp()))

    downloader = FileDownloader(params={})
    processor = PostProcessor(downloader)
    processor.run({'filepath':filename, 'title':'title'})

    # Check the file time is actual
    newdate = datetime.datetime.now()

# Generated at 2022-06-12 19:11:18.262916
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import os
    import stat
    import time
    path = sys.argv[1]
    pp_full_class = os.environ['YTDL_POSTPROCESSOR_FULLCLASS']
    mod = sys.modules[pp_full_class.rpartition('.')[0]]
    pp_class = getattr(mod, pp_full_class.rpartition('.')[2])
    pp = pp_class(downloader=None)
    st = os.stat(path)
    try:
        pp.try_utime(path, st.st_atime+10, st.st_mtime+10)
    except:
        pass
    st = os.stat(path)
    assert stat.S_IMODE(st.st_mode) & stat.S_IRGRP
   

# Generated at 2022-06-12 19:11:24.229113
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

        def run(self, information):
            self.try_utime('test_file', 1, 2)
            return ['test_file']

    tpp = TestPostProcessor()
    tpp.set_downloader(FakeYTDLL())
    retcode = tpp.run('test_information')
    assert retcode == ['test_file']



# Generated at 2022-06-12 19:11:26.490751
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor
    from ..downloader import Downloader

    downloader = Downloader(params={})
    post_processor = PostProcessor(downloader)

# Generated at 2022-06-12 19:11:38.052087
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Arrange:
    #
    # Mocking methods and objects needed
    import os

    class SystemExit(Exception):
        pass

    class FakeConsole:
        def __init__(self):
            self.reset()
            self.columns = 80

        def print_y_n(self, *args):
            self.y_n_called = True
            self.y_n_args = args

        def exit(self, *args):
            raise SystemExit()

        def reset(self):
            self.y_n_called = False
            self.y_n_args = ()

    class Downloader:
        def __init__(self):
            self.params = {}

        def report_warning(self, *args):
            pass

    class PostProcessor:
        DOWNLOADER_CLS = Downloader

       

# Generated at 2022-06-12 19:11:45.241323
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    def test_raise_OSError(utime):
        class PostProcessor(object):

            def __init__(self, downloader):
                self.downloader = downloader

            def try_utime(self, path, atime, mtime, errnote):
                utime(path, (atime, mtime))

            def report_warning(self, msg):
                raise OSError(msg)

        class Downloader(object):
            pass

        downloader = Downloader()
        post_processor = PostProcessor(downloader)

        # This test is use to make sure that any error of function try_utime
        # will be thrown to class Downloader

# Generated at 2022-06-12 19:11:54.909811
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import time
    import errno

    class FakeDownloader:
        def report_warning(self, errnote):
            print(errnote)

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            filename = 'resume_download.txt'
            try:
                with open(filename, 'w') as f:
                    f.write('hi')
            except IOError as e:
                if e.errno == errno.ENOENT:
                    # If file not found, just skip the test
                    return
                else:
                    raise
            self.try_utime(filename, 0, 0)

# Generated at 2022-06-12 19:12:04.688501
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import time
    import os
    import shutil
    import tempfile

    #sys.modules[__name__] = sys.modules['youtube_dl.postprocessor']

    postprocessor = PostProcessor()

    (osfh, ospath) = tempfile.mkstemp()
    os.close(osfh)

    s_atime = time.time() - 100
    s_mtime = time.time() - 50

    postprocessor.try_utime(ospath, s_atime, s_mtime)

    (ns_atime, ns_mtime) = os.stat(ospath)[7:9]

    assert s_atime == ns_atime
    assert s_mtime == ns_mtime

    shutil.rmtree(ospath)

# Generated at 2022-06-12 19:12:07.381303
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    filename = 'test_file'
    open(filename,'w').close()
    pp = PostProcessor()
    pp.try_utime(filename, 1, 2)
    os.remove(filename)

# Generated at 2022-06-12 19:12:12.438066
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import B
    pp = PostProcessor(YoutubeDL())
    pp.try_utime(None, None, None, None)
    pp.try_utime(B(encodeFilename('a')), None, None, None)
    pp.try_utime(B(encodeFilename('a')), None, None, 'b')

# Generated at 2022-06-12 19:12:21.304653
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    from .YoutubeDL import YoutubeDL

    # This method return the number of files in a directory
    def num_files_in_dir(dirpath):
        count = 0
        for _ in os.listdir(dirpath):
            count = count + 1
        return count

    # This method creates a file named 'test_file' in a given directory and returns its path
    def create_file_in_dir(dirpath):
        filepath = os.path.join(dirpath, 'test_file')
        with open(encodeFilename(filepath), 'w') as f:
            f.write('test')
        return filepath

    # We need to save the standard error since we will redirect it for the test
    real_stderr = sys.stderr

# Generated at 2022-06-12 19:12:26.402115
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp, mkdtemp
    from ..downloader import FakeYDL
    from ..compat import PY2, PY3
    from ..utils import write_json_file


# Generated at 2022-06-12 19:12:38.323830
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote=None):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote

    mock_post_processor = MockPostProcessor()
    test_path = 'test/path'
    test_atime = 1
    test_mtime = 2
    test_errnote = 'cannot update utime of file'

    mock_post_processor.try_utime(test_path, test_atime, test_mtime, test_errnote)
    assert mock_post_processor.path == test_path
    assert mock_post_processor.atime == test_atime
    assert mock_post_processor.mtime == test

# Generated at 2022-06-12 19:12:43.688059
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader():
        def __init__(self):
            self.warning_calls = 0
        def report_warning(self, errnote):
            self.warning_calls += 1

    class PD(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader

    # Mock the os.utime function, because utime in windows requires read and write
    # privileges on the file
    orig_utime = os.utime
    def _utime(path, times):
        raise OSError

    os.utime = _utime
    post_processor = PD(FakeDownloader())
    post_processor.try_utime('/tmp/foo', 0, 0)
    assert post_processor._downloader.warning_calls == 1
    os.utime

# Generated at 2022-06-12 19:12:54.927280
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import time
    import shutil
    import tempfile
    import unittest

    # Define a dummy PostProcessor that does nothing
    class DummyPostProcessor(PostProcessor):
        pass

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a dummy file to test utime
    path = os.path.join(tmp_dir, 'dummy')
    with open(path, 'w') as f:
        f.write('Hello, World!')


# Generated at 2022-06-12 19:13:02.186699
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MyTestDownloader(object):
        def __init__(self, *args, **kwargs):
            self.warned = False

        def report_warning(self, msg):
            self.warned = True

    class MyTestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.set_downloader(downloader)

    p = MyTestPostProcessor(MyTestDownloader())
    p.try_utime(__file__, 0, 0, 'Test error note')
    assert p._downloader.warned



# Generated at 2022-06-12 19:13:02.794978
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:13:13.634872
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # pylint: disable=missing-docstring,too-few-public-methods

    class TestPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0)
            return [], info

    class TestInfo:
        def __init__(self, path):
            self.filepath = path

    import tempfile
    import time
    import shutil
    from collections import namedtuple

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.close()

    test_info = TestInfo(test_file.name)
    test_pp = TestPP()

    old_stderr = os.dup(2)
    os.close(2)

# Generated at 2022-06-12 19:13:19.898091
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # No exception raised
    print("No exception raised")
    pp = PostProcessor()
    pp.try_utime(".", 0, 0)

    # FileNotFoundError exception raised
    print("FileNotFoundError exception raised")
    pp = PostProcessor()
    pp.try_utime("/I/don't/exist", 0, 0)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:13:29.621803
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .youtube_dl import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_mock
    from .downloader.common import FileDownloader

    pp = PostProcessor(YoutubeDL(params={'postprocessor_args': ['test_post_processor_param']}))
    info = {
        'filename': 'test.m4a',
        'ext': 'm4a',
        'format': 'bestaudio/best',
        'format_id': 'bestaudio',
    }
    downloader = FileDownloader(YoutubeDL(), InfoExtractor(), 'test.m4a', info)
    pp.set_downloader(downloader)

    mock_utime = compat_mock.MagicMock()
    mock_utime.side_effect = Exception

# Generated at 2022-06-12 19:13:34.193543
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # 'import' is needed to avoid circular imports
    from _PostProcessor import PostProcessor
    # path is dummy, so ignore the exception
    PostProcessor().try_utime('path', 0, 0, 'error msg')

# Generated at 2022-06-12 19:13:42.757908
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile

    # Create a temporary directory (class PostProcessor do not do it)
    oldcwd = os.getcwd()
    tmpdir = tempfile.mkdtemp(prefix='youtubedl_postprocessor_test_')
    os.chdir(tmpdir)

    # Create a temporary file
    tmpfile = tempfile.mkstemp()[1]

    pp = PostProcessor(None)
    pp.try_utime(tmpfile, 1, 2)

    # Check if file in tmpdir has been changed
    (atime, mtime) = os.stat(tmpfile)[7:9]
    assert (atime, mtime) != (1, 2)

    # Restore old working directory and remove tmpdir
    os.chdir(oldcwd)

# Generated at 2022-06-12 19:13:54.509473
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # If a utime cannot be set, the PostProcessor should print a warning
    from ..downloader import Downloader
    from ..compat import compat_os_name

    downloader = Downloader()
    pp = PostProcessor(downloader)
    downloader.params['verbose'] = True

    # No warning should be given if the utime is set successfully
    pp.try_utime('file_path', 0, 0, errnote='error')

    # A warning should be given if the utime is not set successfully
    # Only test on windows
    if compat_os_name == 'nt':
        import ctypes
        ctypes.windll.kernel32.SetErrorMode = lambda a: None
        ctypes.windll.kernel32.SetErrorMode.err_proto = None


# Generated at 2022-06-12 19:14:03.542236
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL

    ydl = FakeYDL()
    pp = PostProcessor(ydl)

    # Test initialization of class
    assert pp._downloader == ydl

    # Test default values of method run
    dummy_information = {'filepath': 'dummy_file'}
    result = pp.run(dummy_information)
    assert len(result) == 2

    # Test return value of method try_utime when exception is raised
    pp.try_utime('dummy_file', 1, 1)
    assert ydl.result['warning'] == 'Cannot update utime of file'

# Generated at 2022-06-12 19:14:14.703320
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os.path
    import tempfile
    from ..compat import file
    from ..downloader.common import FileDownloader

    # Create some temporary file
    test_filename = os.path.join(tempfile.gettempdir(), 'youtubedl_test.tmp')

# Generated at 2022-06-12 19:14:19.386145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FileDownloader
    fd = FileDownloader({'logger': None, 'nocheckcertificate': True})
    pp = PostProcessor(downloader=fd)
    pp.try_utime('', 0, 0)  # make sure no exception is thrown

# Generated at 2022-06-12 19:14:28.108525
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = Mock()
    postprocessor = PostProcessor(downloader)
    filename = 'foo.bar'

    # Make sure that os.utime is called even with a bad filename
    # (see https://github.com/ytdl-org/youtube-dl/pull/3816)
    # This test will fail if the os.utime is not called
    postprocessor.try_utime(encodeFilename(filename), 0, 0)

    # Make sure that the warning is produced
    os.utime = MagicMock(side_effect=Exception)
    with patch('youtube_dl.postprocessor.PostProcessor.report_warning') as report_warning:
        postprocessor.try_utime(encodeFilename(filename), 0, 0)
        report_warning.called_once()



# Generated at 2022-06-12 19:14:38.433844
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys
    import shutil
    import time
    import random
    import unittest
    import subprocess

    from ..YoutubeDL import YoutubeDL

    # Skip this test if we don't have access to a shell
    if not os.access(u'/bin/sh', os.X_OK):
        from nose import SkipTest
        raise SkipTest(u"need a shell for this test")

    # Disable buffering
    sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)
    sys.stderr = os.fdopen(sys.stderr.fileno(), 'w', 0)

    class FakeDownloader():
        """
        A fake downloader that only implements report_warning.
        """

# Generated at 2022-06-12 19:14:45.334630
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import datetime

    tfn = tempfile.mktemp()
    pp = PostProcessor(None)
    with open(tfn, 'w') as tfile:
        tfile.write('test')
    tfile = open(tfn, 'r+')
    pp.try_utime(tfn, 1333384794, 1333384794)


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:14:56.369120
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os

    filename = 'filename'
    try:
        os.utime('filename', (1, 1))
    except Exception:
        raise AssertionError('Expected try_utime to succeed')
    try:
        os.utime('filename', (1, 1))
        raise AssertionError('Expected try_utime to fail')
    except Exception:
        pass

    class TestDownloader(object):
        def report_warning(self, *args, **kwargs):
            self.reported = True

    pp = PostProcessor(TestDownloader())
    try:
        pp.try_utime('filename', 1, 1)
    except Exception:
        raise AssertionError('Expected try_utime to succeed')

    pp = PostProcessor(TestDownloader())

# Generated at 2022-06-12 19:14:56.941304
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:15:05.362785
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    from ..downloader.common import FileDownloader
    from . import FFmpegPostProcessor
    from ..utils import DateRange, DateRangeError

    downloader = FileDownloader(params={})
    pp = FFmpegPostProcessor(downloader)

    prefix = 'youtubedownloadertest_'
    with NamedTemporaryFile(prefix=prefix) as temp_file:
        pp.try_utime(temp_file.name, 300, 400)

        # test make sure that the timestamp of the file is 300, 400
        atime, mtime = os.stat(temp_file.name).st_atime, os.stat(temp_file.name).st_mtime
        assert int(atime) == 300
        assert int(mtime) == 400

    # test make sure that the

# Generated at 2022-06-12 19:15:19.359809
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # The path is a file which will be deleted after the test
    path = 'test_PostProcessor_try_utime.txt'
    with open(path, 'w') as f:
        f.close()
    # atime and mtime should be floating-point numbers, not integers
    atime = 1484238969.0
    mtime = 1484238969.0
    # If no exceptions are raised, the utime of the file will be updated using os.utime
    pp.try_utime(path, atime, mtime)
    os.remove(path)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:15:30.974750
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os, tempfile, sys, os.path
    import time
    import subprocess

    if subprocess.mswindows:
        import ctypes

        class FILETIME(ctypes.Structure):
            _fields_ = [("dwLowDateTime", ctypes.c_uint32), ("dwHighDateTime", ctypes.c_uint32)]

        dll = ctypes.WinDLL("kernel32")
        set_file_times = dll._SetFileTime
        set_file_times.restype = ctypes.c_int
        set_file_times.argtypes = [ctypes.c_void_p, ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME)]


# Generated at 2022-06-12 19:15:41.301523
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import stat
    except ImportError:
        # PostProcessor.try_utime can not be tested
        return

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            atime = information['atime'] if 'atime' in information else None
            mtime = information['mtime'] if 'mtime' in information else None
            self.try_utime('unexits_file_path', atime, mtime)
            self.try_utime('.', atime, mtime)

    postprocessor = TestPostProcessor()
    postprocessor.run({'filename': '.', 'atime': 100, 'mtime': 100})
    postprocessor.run({'filename': '.', 'atime': 100})
    postprocessor.run({'filename': '.'})
   

# Generated at 2022-06-12 19:15:52.095158
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from datetime import datetime, timedelta
    import unittest


# Generated at 2022-06-12 19:16:01.471534
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL as YDL
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class TestPostProcessor(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            super(TestPostProcessor, self).try_utime(path, atime, mtime, errnote)

    class TestPostProcessorError(PostProcessor):
        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            raise PostProcessingError(path, 'Error in postprocess')

    class PostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mk

# Generated at 2022-06-12 19:16:11.475206
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a dummy PostProcessor object
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    fd = FileDownloader(ydl, {'downloader': 'dummy'})
    pp = PostProcessor(fd)

    # Create a dummy file with some content
    import tempfile
    f = tempfile.NamedTemporaryFile()
    s = f.write('test')
    f.flush()

    # Check if the file was created and if the content is correct
    filename = f.name
    with open(filename, 'r') as g:
        assert g.read() == 'test'

    # Check if the modification time of the file is correct
   

# Generated at 2022-06-12 19:16:16.600283
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import os
    import time
    import tempfile
    fd, fname = tempfile.mkstemp()
    os.write(fd, b'a')
    os.close(fd)
    t = time.time()
    os.utime(fname, (t, t))
    ftime = os.stat(fname).st_mtime
    assert ftime == t

    downloader = YoutubeDL()
    pp = PostProcessor(downloader)

    # try_utime with valid file, should not change modification time
    pp.try_utime(fname, t, t)
    assert os.stat(fname).st_mtime == ftime

    # try_utime with invalid file, should not raise exception

# Generated at 2022-06-12 19:16:27.734296
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .FakeYDL import FakeYDL
    from .FakeFile import FakeFile
    from .test_downloader import FakeYoutubeDL
    from .extractor import GenericIE  # GenericIE is just a stub

    ydl = FakeYDL({'logger': FakeYoutubeDL().logger})

    class FakePostProcessor(PostProcessor):

        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    assert ydl.postprocessor == None

    pp = FakePostProcessor(ydl)

    assert ydl.postprocessor != None
    assert isinstance(ydl.postprocessor, FakePostProcessor)

    # This is the "filepath"

# Generated at 2022-06-12 19:16:38.519028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    filename = os.path.join(tmpdir, 'foo')
    f = open(filename, 'w')
    f.close()
    orig = os.stat(filename)
    time.sleep(0.1)
    pp = PostProcessor(None)
    pp.try_utime(filename, orig.st_atime, orig.st_mtime)
    new = os.stat(filename)
    shutil.rmtree(tmpdir)
    return orig.st_atime == new.st_atime and orig.st_mtime == new.st_mtime

# Generated at 2022-06-12 19:16:50.926688
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:17:05.913750
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ytdl.utils import DateRange
    import unittest
    import tempfile
    import time
    import shutil
    import os

    class TestPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], time.time() - 10, time.time() - 20)
            return [], info

    class TestPPTester(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp(prefix='ytdl_test_')
            self.pp = TestPP(None)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-12 19:17:12.145259
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    dirname = tempfile.mkdtemp()
    filename = dirname + "/try_utime.file"
    file = open(filename, "w")
    file.close()

    pp = PostProcessor(None)
    pp.try_utime(filename, 0, 1)

# Generated at 2022-06-12 19:17:18.160633
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def __init__(self):
            self.warned = False
        def report_warning(self, note):
            assert note == 'Cannot update utime of file'
            self.warned = True
    pp = PostProcessor(DummyDownloader())
    pp._downloader.report_warning = lambda note: pp.report_warning(note)
    pp.try_utime('/tmp/dummy', 100, 200, 'Cannot update utime of file')
    assert pp._downloader.warned == True

# Generated at 2022-06-12 19:17:26.840269
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    from ..downloader.common import FileDownloader

    d = FileDownloader()
    d.params = {}
    p = PostProcessor(d)
    tmpd = tempfile.mkdtemp()
    f1 = tempfile.mkstemp(dir=tmpd)
    f2 = tempfile.mkstemp(dir=tmpd)
    try:
        p.try_utime(f1[1], 1, 2, 'errnote')
        assert os.path.getatime(f1[1]) == 1
        p.try_utime(f2[1], 3, 4, 'errnote')
        assert os.path.getatime(f2[1]) == 3
    finally:
        os.unlink(f1[1])
        os

# Generated at 2022-06-12 19:17:33.689756
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..compat import compat_str
    from ..utils import check_executable
    from ..extractor import gen_extractors
    from tempfile import mkdtemp

    if not check_executable('ffmpeg', ['-version']):
        return

    class _TokenCounter(object):
        def __init__(self):
            self.count = 0
        def __call__(self, *args, **kwargs):
            self.count += 1

    postprocessor = PostProcessor(downloader=None)

    with Downloader(params={}) as d:
        d.report_warning = _TokenCounter()
        d._post_processors = {'a': [postprocessor]}
        gen_extractors()

        d.params['format'] = 'bestaudio'

# Generated at 2022-06-12 19:17:44.108946
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    # Create an empty file
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.tmp')
    open(tmp_file, 'w')

    # Set the atime and mtime for 1 hour ago
    now = time.time()
    one_hour_ago = now - 3600
    os.utime(tmp_file, (one_hour_ago, one_hour_ago))

    postprocessor = PostProcessor()

    # Test without error
    postprocessor.try_utime(tmp_file, now, now)

    # Test with error
    import errno
    old_utime = os.utime

    def no_utime(path, times):
        raise OSE

# Generated at 2022-06-12 19:17:54.678501
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a empty temp directory
    import shutil
    path = tempfile.mkdtemp()

    # Create a empty file
    filename = 'mp4.txt'
    filepath = os.path.join(path, filename)
    f = open(filepath, 'w')
    f.close()

    # Try to change creation date of the file to current date
    import time
    (atime, mtime) = time.time(), time.time()
    try:
        os.utime(filepath, (atime, mtime))
    except Exception:
        pass

    # Set a downloader and its params

# Generated at 2022-06-12 19:18:04.247553
# Unit test for method try_utime of class PostProcessor

# Generated at 2022-06-12 19:18:12.844118
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    class _FakeDownloader(object):
        def report_warning(self, msg):
            pass

    class _FakePostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self, _FakeDownloader())

    post_processor = _FakePostProcessor()

    # try_utime can take both float and integer
    # for float value, it will only keep time part and ignore date part
    time_value = 1342921929.858
    post_processor.try_utime('/tmp/a', time_value, time_value)
    time_tuple = os.stat('/tmp/a').st_atime_ns, os.stat('/tmp/a').st_mtime_ns

# Generated at 2022-06-12 19:18:23.349192
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import sys

    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.postprocessor import PostProcessor

    class test_PostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(test_PostProcessor, self).__init__(downloader)

        def run(self, information):
            self.try_utime('/not/exist/file.mp4', 1, 1)
            return [], information

    pp = test_PostProcessor()

# Generated at 2022-06-12 19:18:44.261660
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import tempfile
    import shutil
    import os

    from ..utils import (
        encodeFilename
    )

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test.file')
    with open(encodeFilename(test_file), 'wb') as temp_file:
        temp_file.write(b'Test')

    pp = PostProcessor(None)
    mtime = os.path.getmtime(test_file)
    atime = datetime.datetime.fromtimestamp(mtime)
    pp.try_utime(test_file, atime.timestamp(), mtime)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-12 19:18:54.372343
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader

    # Test for a simple case, see 'a' is a file
    d = FileDownloader({})
    a = PostProcessor({})
    a.set_downloader(d)
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close() # f.file will be deleted if object is deleted
    a.try_utime(f.name, 1, 2)

    # Test for a simple case, see 'a' is a directory
    a = PostProcessor({})
    a.set_downloader(d)
    import tempfile
    import os
    os.makedirs(tempfile.NamedTemporaryFile(delete=False).name)
    a.try_utime(f.name, 1, 2)

   

# Generated at 2022-06-12 19:19:01.542858
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors
    ext_dict = gen_extractors()

    # Mock PostProcessor object
    mock_PostProcessor = PostProcessor(ext_dict['generic'])

    # Mock atime and mtime as datetime.datetime objects
    import datetime
    mock_atime = datetime.datetime(2000,1,1,0,0,0,0)
    mock_mtime = datetime.datetime(2000,2,2,0,0,0,0)

    # Mock path as a StringIO object
    import StringIO
    mock_path = StringIO.StringIO()

    # A test case of PostProcessor with a mock path object

# Generated at 2022-06-12 19:19:09.670040
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from io import open
    from tempfile import NamedTemporaryFile

    pp = PostProcessor(None)

    with NamedTemporaryFile(mode='w+') as tf:
        before = os.path.getmtime(tf.name)
        tf.write('Hello World')
        tf.flush()
        after = os.path.getmtime(tf.name)
        assert before != after
        pp.try_utime(tf.name, before, before)
        assert os.path.getmtime(tf.name) == before

    with NamedTemporaryFile(mode='w+') as tf:
        pp.try_utime(tf.name, 0, 0)
        assert os.path.getmtime(tf.name) != 0

# Generated at 2022-06-12 19:19:18.907033
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import stat
    import os
    import shutil
    import sys
    import stat

    if sys.version_info[0] == 2:
        from urllib import urlopen
    else:
        from urllib.request import urlopen

    # Create a temp directory and chmod it to prevent utime
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:19:26.776791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..YoutubeDL import YoutubeDL
    from .common import FakeYDL
    ydl = YoutubeDL(FakeYDL())
    ydl.params['nooverwrites'] = True
    ydl.params['continuedl'] = False
    ydl.params['nocheckcertificate'] = True
    fd = FileDownloader(ydl, {'url': 'http://127.0.0.1/'})
    fd._do_download()
    fd._do_post_process(True)
    assert os.path.exists('test')
    from .ffmpeg import FFmpegPostProcessor
    pp = FFmpegPostProcessor(fd)
    pp.run({'filepath': 'test'})
    os.unlink('test')

# Generated at 2022-06-12 19:19:37.527574
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import encodeFilename
    import sys
    import tempfile
    import time

    # Create tempfile
    temp_file_handle, temp_file_name = tempfile.mkstemp(text=False)

    class FakeDownloader(object):
        def report_warning(self, message):
            sys.stderr.write(message)

    pp = PostProcessor(FakeDownloader())
    # change mtime of temp_file_name
    new_mtime = time.time() - 10000  # 10 seconds ago
    pp.try_utime(encodeFilename(temp_file_name), new_mtime, new_mtime)

# Generated at 2022-06-12 19:19:43.893543
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            self.tried_touch = False
        def touch(self, filename, atime, mtime):
            self.tried_touch = True

    import time
    mtime = time.time()

    pp = MockPostProcessor()
    pp.touch = MockPostProcessor.touch
    pp.try_utime('test', mtime, mtime)
    assert pp.tried_touch

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:19:44.811936
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert not PostProcessor().try_utime('./fake_file', 0, 0)

# Generated at 2022-06-12 19:19:50.685691
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self._values = []
            self._errnote = ''
            super(DummyPostProcessor, self).__init__(downloader)

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self._values.append((path, atime, mtime))
            self._errnote = errnote
            self._downloader.report_warning(errnote)

    class DummyDownloader(object):
        def __init__(self):
            self._warning_count = 0

        def report_warning(self, error):
            self._warning_count += 1

    ydl = DummyDownloader()
    pp = DummyPostProcessor(ydl)
