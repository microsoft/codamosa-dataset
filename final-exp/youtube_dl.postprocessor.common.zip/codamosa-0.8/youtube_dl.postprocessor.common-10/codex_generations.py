

# Generated at 2022-06-12 19:09:54.619422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime('path', 1.0, 2.0)

# Generated at 2022-06-12 19:10:03.403220
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import time

    file_path = os.path.join(tempfile.mkdtemp(), 'test_file')

    with open(file_path, 'wb') as f:
        f.write(b'test')
        f.flush()

    time.sleep(1)
    PostProcessor().try_utime(file_path, 1, 1)
    assert os.path.getatime(file_path) == 1
    assert os.path.getmtime(file_path) == 1

    os.remove(file_path)


# Generated at 2022-06-12 19:10:12.880306
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    from ..downloader import FileDownloader

    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime('/tmp/cannot/update/this', atime=1, mtime=2)
            return [], information

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:10:15.325921
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader:
        def report_warning(self, *args, **kwargs):
            pass
    d = DummyDownloader()
    f = PostProcessor(d)
    f.try_utime("/tmp/abc", 1, 2)
    f.try_utime("/tmp/abc", 1, 2, errnote="Warning")

# Generated at 2022-06-12 19:10:17.975381
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockDownloader():
        _errnote = ''
        def report_warning(self, errnote):
            self._errnote = errnote

    pp = PostProcessor(None)
    pp.set_downloader(MockDownloader())

    try:
        os.utime = lambda path, times: None
        pp.try_utime('', 0, 0)
    except Exception:
        pass

# Generated at 2022-06-12 19:10:22.759222
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange

    class TestPostProcessor(PostProcessor):
        def __init__(self, ie):
            PostProcessor.__init__(self)
            self.ie = ie
            self.utime_success = False
            self.utime_path = None
            self.utime_atime = None
            self.utime_mtime = None

        def run(self, info):
            self.try_utime(info['id'] + '.mp3',
                           self.utime_atime, self.utime_mtime)
            return [], info

        def try_utime(self, path, atime, mtime, errnote=None):
            self.utime_success = True
            self.utime_path = path


# Generated at 2022-06-12 19:10:31.431586
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL
    ydl = YoutubeDL() # default downloader has no params
    pp = PostProcessor(ydl)
    # os.utime(name: str, times: Union[Tuple[float, float], NoneType] = None)
    # os.utime(encodeName, (atime, mtime))
    # where encodeName = encodeFilename(name),
    # and times = (atime, mtime),
    # where atime=None, and mtime = None.
    # so, call os.utime(encodeFilename(name), None) which seems to work.
    # use pp to try utime, which will call os.utime(name, times) and return None.
    utime_result = pp.try_utime('name', None, None)

# Generated at 2022-06-12 19:10:41.575709
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # pylint: disable=protected-access
    import shutil
    import datetime
    import tempfile
    import platform

    if platform.system() == 'Windows':
        # On windows, temporary file is created with atime and mtime set to the current time
        return

    origin_filename = b'origin'
    old_atime = datetime.datetime(2000, 1, 1)
    old_mtime = datetime.datetime(2000, 1, 1)
    old_times = (old_atime, old_mtime)
    test_filename = b'test_filename'

    def mock_report_warning(errnote):
        assert errnote == 'Cannot update utime of file'


# Generated at 2022-06-12 19:10:48.460792
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class testDownloader(object):
        def report_warning(self, errnote):
            assert errnote=='Cannot update utime of file'
    class testPostProcessor(PostProcessor):
        def __init__(self):
            super(testPostProcessor, self).__init__(downloader=testDownloader())
    p=testPostProcessor()
    # testing with non existent file
    p.try_utime('/nonexistent/file', 0,0)
    # testing with existent file
    import tempfile
    fd, tempPath = tempfile.mkstemp()
    os.close(fd)
    p.try_utime(tempPath, 0, 0)
    os.remove(tempPath)

# Generated at 2022-06-12 19:10:58.616690
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import sys
    import time

    # Make a temp file
    file_descriptor, path = tempfile.mkstemp()
    # Close it
    os.close(file_descriptor)
    # Remove it
    os.remove(path)

    # Open it again as text file
    file_obj = open(path, 'wt')
    # Close it
    file_obj.close()

    # Try to update timestamp of the file
    pp = PostProcessor(None)
    # Sort out Python 3.x vs 2.x way of representing exceptions
    try:
        exception = BaseException
    except NameError:
        exception = Exception
    # If it does not fail

# Generated at 2022-06-12 19:11:08.432739
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    pp = PostProcessor(None)

    # Create a temp file
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(delete=False) as t:
        f = t.name

    # Check try_utime with success
    # Create a time to use as reference in this test
    from time import gmtime, strftime, mktime
    time = strftime("%Y-%m-%d %H:%M:%S", gmtime())  # time format: YYYY-MM-DD HH:MM:SS
    time = mktime(gmtime())  # time format in seconds

    import time

    time.sleep(1)  # time between time.time() and os.utime() need to be 1 at least
    pp.try_utime(f, time, time)

    #

# Generated at 2022-06-12 19:11:18.848968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import tempfile
        tmp_dir = tempfile.gettempdir()
        if not os.access(tmp_dir, os.W_OK):
            tmp_dir = os.getcwd()
    except:
        tmp_dir = os.getcwd()
    filename = "youtubedl_test_file"
    f = open(os.path.join(tmp_dir, filename), 'w')
    try:
        f.write("test")
        f.close()
    except:
        os.remove(os.path.join(tmp_dir, filename))
        raise
    assert os.path.exists(os.path.join(tmp_dir, filename))

# Generated at 2022-06-12 19:11:25.572161
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import ctypes
    import mock
    import datetime
    from nose.tools import assert_equals

    class PostProcessor(object):

        def __init__(self, downloader=None, utime=None):
            self._downloader = downloader
            self._utime = utime

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self._utime(path, atime, mtime)

    utime = mock.Mock()

    # Assert that we handle utime failures properly
    utime.side_effect = ctypes.WinError()
    pp = PostProcessor(utime=utime)
    pp.try_utime('some file', 'some time', 'some time')

# Generated at 2022-06-12 19:11:25.880688
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-12 19:11:31.966951
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from pytube.compat import PY2
    from pytube.extractor.common import FileDownloader

    if PY2:
        from io import BytesIO
    else:
        from io import StringIO
    from pytube.postprocessor import PostProcessor

    # Create a test file for utime
    if PY2:
        f = open('test.txt', 'wb')
    else:
        f = open('test.txt', 'w', encoding='utf-8')
    f.write('test line\n')
    f.close()

    # Check mtime and atime
    print('test.txt mtime:', os.path.getmtime('test.txt'))
    print('test.txt atime:', os.path.getatime('test.txt'))

    dl

# Generated at 2022-06-12 19:11:36.410082
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    from ..compat import (
        compat_os_name,
        compat_tempfile_gettempdir,
        compat_urllib_request,
    )
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['writethumbnail'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['keepvideo'] = True
    ydl.params['writeannotations'] = True
    ydl.params['simulate'] = True

    orig_sys_argv = sys.argv

# Generated at 2022-06-12 19:11:44.664931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import time
    import tempfile

    def fake_report_warning(msg):
        sys.stderr.write('WARNING: %s\n' % msg)

    old_utime = os.utime
    old_time = time.time
    old_report_warning = None
    saved_stderr = sys.stderr
    generation = 0

# Generated at 2022-06-12 19:11:54.432171
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os
    import time

    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
    )

    from ..downloader import (
        Downloader,
        FileDownloader,
    )

    from ..postprocessor import (
        PostProcessor,
    )

    from ..utils import (
        DateRange,
        DateRangeError,
    )

    # Create a folder
    test_folder = tempfile.mkdtemp(prefix='youtube-dl-test-folder-')

    # Downloader writes its output to stderr
    # We replace stderr with a StringIO object
    # to catch the output
    import sys
    import io
    stdout = sys.stdout
    stderr = sys.stderr



# Generated at 2022-06-12 19:12:04.275791
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import PostProcessor
    import os.path
    import tempfile
    import shutil

    # Create tempdir
    dir = tempfile.mkdtemp()
    print(dir)

    # Create tempfile
    (fd, fname) = tempfile.mkstemp(dir=dir)
    test = os.path.join(dir, fname)
    f = open(test, 'w+')
    f.close()

    # Set original mtime
    old_mtime = 1350000000
    old_atime = old_mtime
    os.utime(test, (old_atime, old_mtime))
    # Check mtime of tempfile
    (atime, mtime) = os.stat(test)[7:9]
    assert old_atime == atime
    assert old_mtime == mtime

# Generated at 2022-06-12 19:12:07.011138
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class Test(object):
        def report_warning(self, msg):
            self.msg = msg

    pp = PostProcessor(Test())
    pp.try_utime(None, None, None)

# Generated at 2022-06-12 19:12:19.513530
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_str
    from .test_utils import make_temp_directory

    ydl = YoutubeDL()
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writethumbnail'] = True
    ydl.params['writeannotations'] = True
    with make_temp_directory() as d:
        ydl.params['outtmpl'] = os.path.join(d, '%(id)s.%(ext)s')
        ydl.params['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
        ydl._opener = compat_str
        ydl.cache.remove()

# Generated at 2022-06-12 19:12:26.309199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL
    from .real_downloader_test import RealDownloaderTest

    class FakePostProcessor(PostProcessor):
        pass

    FakePostProcessor.test_preference = -1

    ydl = FakeYDL()
    dl = RealDownloaderTest(
        ydl, DateRange(), downloader_options={'postprocessors': [FakePostProcessor()]})

    with NamedTemporaryFile() as temp_file:
        atime = mtime = os.path.getmtime(temp_file.name)
        dl.post_process(temp_file.name, {})
        assert os.path.getmtime(temp_file.name) == mtime
       

# Generated at 2022-06-12 19:12:26.797317
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    return

# Generated at 2022-06-12 19:12:31.365766
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import common

    # Create downloader
    downloader = common.Downloader(common.params())

    # Create PostProcessor
    pp = PostProcessor(downloader)

    # Try to set utime to file
    pp.try_utime('../LICENSE', 1, 2)

# Generated at 2022-06-12 19:12:41.261355
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange
    class Info:
        pass

    info = Info()
    info.date = DateRange('now')
    info.uploader = 'foo'
    info.uploader_id = 'bar'
    info.uploader_url = 'http://youtube.com/user/foo'


# Generated at 2022-06-12 19:12:53.204936
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    gen_extractors()
    dl = Downloader()
    tmp_dir = dl.parameters['outtmpl'].rpartition('%(title)s')[0] + '%(title)s.tmp'
    dl.params['outtmpl'] = tmp_dir
    file_path = dl.parameters['outtmpl'] % {'id': 'xyz', 'upload_date': 'abc', 'title': 'abc'}
    f = open(file_path,'w')
    f.write('Testing')
    f.close()
    dl.params['postprocessor_args'] = '-prefer_ffmpeg'
    pp = dl.postprocessor

# Generated at 2022-06-12 19:13:03.059276
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from .common import MockPostProcessor
    from .fake_filesystem_unittest import TestCase
    from .test_utils import DEFAULT_OUTTMPL
    class MockFD(object):
        def __init__(self):
            self.data = b''
        def write(self, data):
            self.data += data
        def close(self):
            pass

    class _TestCase(TestCase):
        def setUp(self):
            TestCase.setUp(self)
            self.filename = os.path.join('path', 'to', 'file.mp3')
            self.tmpfilename = os.path.join('path', 'to', 'file.mp3.tmp')
            open(self.tmpfilename, 'w').close()

# Generated at 2022-06-12 19:13:13.845971
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    # When program is being unit tested, there is no need to import all framework.
    class FakeDownloader(object):
        def __init__(self):
            self.params = { 'nooverwrites': False, 'continuedl': False, 'nopart': False, 'updatetime': False, }
        def report_warning(self, errnote):
            raise Exception(errnote)
    # Create a temporary file.
    (fd, temp_filepath) = tempfile.mkstemp()
    # Close temporary file descriptor.
    os.close(fd)
    # Set fake file creation time.
    now = 1393605977
    os.utime(temp_filepath, (now, now))
    # Create a PostProcessor object and set a downloader.
    post_processor = PostProcess

# Generated at 2022-06-12 19:13:24.568169
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import tempfile
    import time
    import shutil
    import os
    import sys
    from ytdl.utils import PostProcessor

    if sys.platform == 'win32':
        from ytdl.utils import _find_exe
        if _find_exe('ffmpeg') is None:
            raise unittest.SkipTest('ffmpeg not installed')

        @unittest.skipIf('TRAVIS' in os.environ, 'cannot run on Travis')
        class TestPostProcessorTryUtime(unittest.TestCase):
            def setUp(self):
                self.requested_atime = 1234.5
                self.requested_mtime = 6789.0
                self.tem

# Generated at 2022-06-12 19:13:32.864498
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import temporary_file, TemporaryDirectory
    from ..downloader import Downloader
    import time

    with TemporaryDirectory() as tmpdir:
        ydl_opts = {'outtmpl': tmpdir + '/%(id)s.%(ext)s', 'postprocessor_args': ['-f', 'mp3']}
        dl = Downloader(ydl_opts)
        pp = PostProcessor(dl)
        with temporary_file(tmpdir) as tfile:
            tfile.write(b'hello world')
            tfile.flush()
            pp.try_utime(tfile.name, 0, 1)
            updated_time = os.stat(tfile.name).st_mtime
            if abs(time.time() - updated_time) > 5:  # file was updated
                raise

# Generated at 2022-06-12 19:13:49.542216
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os.path

    downloader = {'params': {}}
    pp = PostProcessor(downloader)

    with tempfile.NamedTemporaryFile(delete=False) as f:
        pass

# Generated at 2022-06-12 19:13:56.442408
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import unittest
    from io import BytesIO

    from ..utils import sanitize_open

    class MockDownloader(object):
        def __init__(self):
            self.to_stdout_value = b''
            self.to_stderr_value = b''
            self.params = {}
            self.known_extractors = set()
            self.ie_key_map = {}
            self.extractor_desc = {}
            self.extractor_proxy = {}
            self.compiled_regex_type = type(re.compile(''))


# Generated at 2022-06-12 19:13:58.797540
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:14:00.522063
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    pp.try_utime('filename', 1, 2)

# Generated at 2022-06-12 19:14:03.546867
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import common
    dl = common.Downloader({})
    pp = PostProcessor(dl)
    pp.try_utime('', '', '')

# Generated at 2022-06-12 19:14:14.702752
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import datetime
    import os
    test_file_path = 'foo/bar.txt'

    def mtime_gmtime_mock_datetime(path):
        return datetime.datetime.utcfromtimestamp(os.path.getmtime(path))

    def test_try_utime(self):
        with utils.isolated_filesystem():
            # Create test file with 0 time
            test_file = open(test_file_path, 'w')
            test_file.write('Test data\n')
            test_file.close()

            # Get current time in seconds
            current_time_in_secs = int(time.time())
            # Get mtime of file in seconds

# Generated at 2022-06-12 19:14:22.946757
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class _FakeDownloader():
        def report_warning(self, errnote):
            pass

    pp = PostProcessor(_FakeDownloader())
    filename = '/tmp/test.mp3'
    atime = mtime = 1255265501
    f = open(filename, 'w')
    f.close()
    pp.try_utime(filename, atime, mtime)
    import time
    atime, mtime = time.localtime(os.path.getmtime(filename))[:6]
    assert atime == 2010 and mtime == 9

# Generated at 2022-06-12 19:14:28.430499
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    upload_date = [0]
    filedate = [0]
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.tmp')
    open(filepath, 'wb').close()

    # Create a new PostProcessor object
    P = PostProcessor(None)
    # Check that if neither --no-post-overwrites nor --no-overwrites are passed
    # try_utime raises no exception
    P.try_utime(filepath, *upload_date)
    P.try_utime(filepath, *filedate)

    # Check that if --no-post-overwrites is passed and upload date is set to
    # the current date (equals to filedate), atime and mtime remain equal
    P._downloader

# Generated at 2022-06-12 19:14:38.485646
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    global os
    import unittest
    import tempfile
    import shutil
    import time
    import sys
    class DummyOs(object):
        def __init__(self):
            self.times = {}
        def utime(self, path, t):
            self.times[path] = t
    class DummyDownloader(object):
        def __init__(self):
            self.warnings = []
        def report_warning(self, msg):
            self.warnings.append(msg)
    class DummyPostProcessor(PostProcessor):
        pass
    class TestPostProcessorMethods(unittest.TestCase):
        def setUp(self):
            self.oldos = os
            os = DummyOs()

# Generated at 2022-06-12 19:14:45.388956
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL
    from .common import FakeYDL

    class MockPP(PostProcessor):
        pass

    pp = MockPP(downloader=FakeYDL({}))
    try:
        os.utime
    except AttributeError:
        raise Exception('test_PostProcessor_try_utime relies on os.utime, but it is not available.')
    pp.try_utime('some/path', 0, 0)  # should not raise exception



# Generated at 2022-06-12 19:15:05.744661
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['restrict_filenames'] = True
    ydl.params['outtmpl'] = 'test_%(extractor)s_%(format_id)s_%(id)s_%(uploader)s'
    ydl.params.pop('keep_video')
    ydl.params.pop('format')
    ydl.params['verbose'] = True
    ydl.add_post_processor(PostProcessor())
    ydl.download(('http://www.youtube.com/watch?v=BaW_jenozKc',))

# Generated at 2022-06-12 19:15:12.728093
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .compat import PY2
    ydl = YoutubeDL({})
    pp = PostProcessor(ydl)
    if PY2:
        from StringIO import StringIO
    else:
        from io import StringIO
    file = StringIO()
    file.name = 'test_file.txt'
    file.close()
    pp.try_utime(file.name, 0, 0) # utime throws errors on this test, but we don't want it to


# Generated at 2022-06-12 19:15:20.855192
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0)

    class TestDownloader(object):
        def __init__(self, params):
            self.params = params

        def report_warning(self, msg):
            raise RuntimeError('Unexpected report_warning while testing')

    import os
    import time
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-12 19:15:32.021719
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader(object):
        def __init__(self):
            self.params = {'outtmpl': 'dummy.%(ext)s'}
        def to_screen(self, msg): pass
        def report_warning(self, msg): pass
    class DummyPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self, DummyDownloader())
            self.utime_argv = []
        def _utime(self, path, atime, mtime):
            self.utime_argv.append([path, atime, mtime])
    dpp = DummyPostProcessor()
    dpp.try_utime('/tmp/dummy.mp4', 1466233510, 1466233510)
    assert dpp

# Generated at 2022-06-12 19:15:32.540192
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    pass

# Generated at 2022-06-12 19:15:42.640038
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .extractor.youtube import YoutubeIE

    def TestIE_results(url):
        TestIE = type('TestIE_%s' % url, (InfoExtractor, object), {'_VALID_URL': url, '_TEST': {
            'url': url,
            'file': 'test.mp4',
            'info_dict': {
                'ext': 'mp4',
                'title': 'test'
            },
        }})
        ie = TestIE(FileDownloader())
        return ie.extract('', download=False)

    orig_utime = os.utime

# Generated at 2022-06-12 19:15:53.323054
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from install_binaries import install_binaries
    from tempfile import mkdtemp
    from shutil import rmtree
    import datetime as dt
    import os as os

    test_dir = mkdtemp()
    filename = os.path.join(test_dir, 'test.mp3')
    open(filename, 'w').close()

    postProcessor = PostProcessor(downloader=FileDownloader())

    file_stat = os.stat(filename)
    atime = file_stat.st_atime
    mtime = file_stat.st_mtime

    postProcessor.try_utime(path=filename, atime=atime, mtime=mtime)

    file_stat = os.stat(filename)
    assert file_stat.st_

# Generated at 2022-06-12 19:16:02.567573
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os
    import tempfile
    import shutil
    import random

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.file')
    open(test_file, 'w+b').close()

    pp = PostProcessor(None)

    # Retrieve the original mtime and atime
    orig_mtime = os.path.getmtime(test_file)
    orig_atime = os.path.getatime(test_file)

    # Set the atime and mtime to the original times (should not fail, since
    # these are the current times)
    pp.try_utime(test_file, orig_atime, orig_mtime)

    # Set the atime and mtime to new random numbers
    new

# Generated at 2022-06-12 19:16:12.521852
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegPostProcessor
    from youtube_dl.downloader.common import FileDownloader
    import unittest
    import sys
    import os
    import stat

    test_file = 'test'
    test_file_size = 10
    test_file_time = 1000000000

    params = { 'verbose': True,
               'postprocessor_args': ['-ss', '0', '-t', '1']}

    test_file = open(encodeFilename(test_file), 'w')
    test_file.close()

    class MockFD(FileDownloader):
        def to_screen(self, s, skip_eol=False):
            pass
        def to_stderr(self, s):
            pass

# Generated at 2022-06-12 19:16:24.708035
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Test failed to update utime
    import shutil
    import tempfile
    import datetime
    import time
    from .YoutubeDL import YoutubeDL

    TEST_FILE_NAME = 'test_try_utime.txt'
    TEST_FILE_NAME_COPY = 'test_try_utime_copy.txt'
    TEST_FILE_CONTENT = 'test_try_utime'
    FAKE_FILENAME = 'test_try_utime_fake_file.txt'

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp('', '', tempfile.gettempdir())

    def _get_fake_filename():
        return os.path.join(tmp_dir, FAKE_FILENAME)


# Generated at 2022-06-12 19:16:57.476204
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import get_info_extractor

    # test available formats
    formats = set()
    for ie in get_info_extractor('youtube'):
        formats.update(ie._available_formats)

    for i in len(formats):
        format = formats[i]
        formats[i] = format.replace('-', '_')

    # test list of formats
    params = {
        'outtmpl': '%(format)s.%(ext)s',
    }
    pp = PostProcessor(None)
    pp._downloader = None
    pp._configuration_args(formats)

    class TestArgs(object):
        params = params

    pp._downloader = TestArgs()

# Generated at 2022-06-12 19:17:06.257821
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import sys
    import shutil
    import re
    import time
    import os
    import platform

    if platform.system() == 'Windows':
        hasattr(os, 'utime') and os.uname or skip('utime is not available on this system')
        if sys.version_info < (3, 3):
            from unittest2 import skip

    class FakeDownloader():
        tostderr = ''
        tostderr_fd, tostderr_fn = tempfile.mkstemp()
        os.close(tostderr_fd)

        def report_warning(self, msg):
            self.tostderr += msg + '\n'

    def get_tostderr():
        f = open(FakeDownloader.tostderr_fn, 'r')


# Generated at 2022-06-12 19:17:17.595659
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader(object):
        def report_warning(self, errnote):
            print(errnote)
    class test_PP(PostProcessor):
        def __init__(self):
            self.errnote = None
            self.atime = None
            self.mtime = None
            self.path = None
        def try_utime(self, path, atime, mtime, errnote):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote
    test_pp = test_PP()
    downloader = FakeDownloader()
    test_pp.set_downloader(downloader)
    filename = '_test_PostProcessor_try_utime'
    testfile = open(filename, 'wb')
    testfile

# Generated at 2022-06-12 19:17:23.579203
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import sanitize_open

    class DummyPostProcessor(PostProcessor):
        pass

    pp = DummyPostProcessor()
    pp._downloader = FileDownloader({})
    with sanitize_open(b'test', 'wb') as f:
        f.write(b'a' * 1024)
        f.flush()
        f.seek(0)
        pp.try_utime('test', f.fileno(), f.fileno())

# Generated at 2022-06-12 19:17:30.209409
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime('_invalid_filename_', (1, 1))
    except OSError as ose:
        if ose.errno != 2:
            raise

        # OSError: can not find file '_invalid_filename_'
        # not raise PostProcessingError
        pp = PostProcessor({})
        pp.try_utime('_invalid_filename_', 0, 0)

    else:
        # No exception, means file exists
        # raise PostProcessingError
        pp = PostProcessor({})
        try:
            pp.try_utime('_invalid_filename_', 0, 0)
        except PostProcessingError:
            pass

# Generated at 2022-06-12 19:17:36.256775
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile

    def assert_utime(filename, atime, mtime):
        assert int(os.path.getmtime(filename)) == mtime
        assert int(os.path.getatime(filename)) == atime

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp_filename = temp.name

# Generated at 2022-06-12 19:17:47.218158
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Set atime and mtime to REF_TIME, if this is possible
    (utime_error is None else raise audio conversion error)."""

    import os
    import stat
    import sys
    import unittest
    import tempfile

    from ..utils import encodeFilename

    from .common import PostProcessorTest, PostProcessorTestCase

    try:
        from mock import patch
    except ImportError:
        from unittest.mock import patch # Python 3.3 and 3.4

    POSTPROCESSOR_ARGS = {
        'version': '2014.07.08',
        'postprocessor_args': ['--extract-audio', '--audio-format', 'wav', '--audio-quality', '0', '-k'],
    }

    TEST_FILE_CONTENT = b'foobar'


# Generated at 2022-06-12 19:17:58.472104
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import GenYoutubeIE
    import time
    import datetime
    from ..downloader.common import FileDownloader

    if not os.path.exists("temp"):
        os.mkdir("temp")
    fd = FileDownloader(GenYoutubeIE())

    # Create a fake video file
    temp_video_filename = "temp/temp_video.mp4"
    with open(temp_video_filename, 'wb') as temp_video_file:
        temp_video_file.write(b"A" * 1000000)
    # Create fake mtime and atime
    mtime = datetime.datetime(2016, 10, 10, 22, 10, 0, 0)
    atime = datetime.datetime(2015, 10, 10, 22, 10, 0, 0)

    # Try to update

# Generated at 2022-06-12 19:18:05.977814
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile

    tmppath = None

# Generated at 2022-06-12 19:18:13.661374
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import mock
    import pytest

    class TestPP(PostProcessor):
        def __init__(self):
            self._downloader = mock.MagicMock()

    def test_no_error():
        pp = TestPP()
        pp.try_utime('test.mp3', 1, 2)
        assert not pp._downloader.report_warning.called

    def test_file_not_found():
        pp = TestPP()
        with pytest.raises(IOError):
            pp.try_utime('test_file_not_found.mp3', 1, 2)

    def test_error():
        pp = TestPP()
        pp.try_utime('test.mp3', 1, 2,
                     errnote='AudioConversionError')
        pp._downloader.report_warning.assert_called_

# Generated at 2022-06-12 19:19:17.368790
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import PY2, compat_os_name, compat_os_environ
    if compat_os_name == 'nt':
        import pytest
        pytest.skip('Skipping test on Windows')

    import subprocess
    import tempfile
    import shutil
    import sys
    import time

    from ..utils import DateRange

    path = tempfile.mkdtemp()

    def check_utime(path, atime, mtime, errnote=None):
        pp = PostProcessor(None)
        pp.try_utime(path, atime, mtime, errnote)
        st = os.stat(path)
        return st.st_atime, st.st_mtime


# Generated at 2022-06-12 19:19:25.558164
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import sys
    import tempfile
    from ..utils import encodeFilename

    pp = PostProcessor(None)

    atime = mtime = time.time() - 100000
    # Since Windows is not able to set atime and mtime of a file to an earlier timestamp
    # with utime we need to create a temporary file where we can set any timestamp we want to
    if sys.platform == 'win32':
        temp_filename = tempfile.mkstemp(suffix='.test_PostProcessor_try_utime')[1]
        os.close(os.open(temp_filename, os.O_WRONLY))
    else:
        temp_filename = tempfile.mkstemp(suffix='.test_PostProcessor_try_utime')[1]

# Generated at 2022-06-12 19:19:35.440997
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeYDL
    from .extractor import GenYoutubeIE
    from .downloader import FakeFD
    from .postprocessor import FFmpegExtractAudioPP

    ie = GenYoutubeIE()
    ydl = FakeYDL({})

    fd = FakeFD(name="test.mp4", size=0)

    processed = ie.process_video_result(
        {'id': 'blahblah', 'url': 'http://example.com/test.mp4'}, dl=False)

    assert 'formats' in processed
    assert len(processed['formats']) >= 1

    f = processed['formats'][0]
    f['url'] = 'http://example.com/test.mp4'
    f['vcodec'] = 'none'

# Generated at 2022-06-12 19:19:40.398106
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import os.path
    import tempfile
    from ..utils import PostProcessor

    try:
        os.utime
    except AttributeError:
        raise unittest.SkipTest('Cannot update utime of file')

    directory = tempfile.mkdtemp()

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            self.errnote = ''

        def run(self, information):
            self.try_utime(os.path.join(directory, 'test'), 0, 0, self.errnote)
            return [], information

    # Test "Cannot update utime of file"
    pp = TestPostProcessor()
    pp.errnote = 'Cannot update utime of file'
    # If post processing failed exception PostProcessingError must be raised

# Generated at 2022-06-12 19:19:47.711126
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import os.path
    import os
    import sys
    import time

    class FakeDownloader():
        def __init__(self, pp):
            self.postprocessor = pp
            self.warning_count = 0
            self.errnote = ""

        def report_warning(self, errnote):
            self.errnote = errnote
            self.warning_count += 1

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(DummyPostProcessor, self).__init__(downloader)

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-12 19:19:58.130092
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import unittest
    import shutil
    import os
    import time
    import errno

    class TestPP(PostProcessor):
        def __init__(self, *args, **kwargs):
            self.deleted_files = []
            self.utime_failed = False
            self.utime_warned = False
            PostProcessor.__init__(self, *args, **kwargs)

        def run(self, information):
            if 'filepath' in information:
                self.deleted_files = [information['filepath']]
            return self.deleted_files, {}

        def _report_warning(self, message):
            assert message.startswith('Cannot update utime of file')
            self.utime_warned = True
