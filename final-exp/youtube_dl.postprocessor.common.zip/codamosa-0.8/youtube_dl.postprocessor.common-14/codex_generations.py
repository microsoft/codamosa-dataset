

# Generated at 2022-06-12 19:10:06.138051
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import test as _test
    # In package test, class _FakeInfo.
    from tests.fake_info import FakeInfo

    # Prepare a fake file and information.
    fake_file = tempfile.NamedTemporaryFile()
    fake_info = FakeInfo()
    fake_info.filename = fake_file.name
    fake_info.filepath = fake_file.name

    # Make post-processor.
    pp = _test.postprocessor.PostProcessor(None)
    pp.try_utime = _test.postprocessor.PostProcessor.try_utime

    # Try to "update the time-stamp".
    pp.try_utime(fake_info.filepath, 0, 0)

    # Check if warning is reported.

# Generated at 2022-06-12 19:10:15.097070
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import DateRange
    from ..YoutubeDL import YoutubeDL
    class _TestPostProcessor(PostProcessor):
        def __init__(self, downloaded_filepath, *args, **kargs):
            self._downloaded_filepath = downloaded_filepath
            self._downloader = YoutubeDL()
            super(_TestPostProcessor, self).__init__(*args, **kargs)

        def run(self, information):
            self.try_utime(self._downloaded_filepath, 1000, 1001)
    from .test_YoutubeDL import FakeYDL
    from .test_utils import FakeFile
    from .fake_filesystem_unittest import TestCase
    test_file = FakeFile('/fake/path/test.txt', size=1024)

# Generated at 2022-06-12 19:10:17.466318
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class PPTest(PostProcessor):
        pass

    pp = PPTest()
    pp.try_utime('', None, None)  # bok, no exception

# Generated at 2022-06-12 19:10:24.337046
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import datetime

    from ytdl.downloader.PostProcessor import PostProcessor as PostProcessor

    try:
        fd, temppath = tempfile.mkstemp()
        os.close(fd)
        os.utime(temppath, (0, 0))

        # common test, set time from 0 to now
        post_processor = PostProcessor()
        post_processor.try_utime(temppath, 0, datetime.datetime.utcnow().timestamp())
        assert datetime.datetime.utcnow().timestamp() - os.stat(temppath).st_mtime < 1

    finally:
        shutil.rmtree(temppath)

# Generated at 2022-06-12 19:10:32.215777
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from tempfile import mkdtemp
    tmpdir = mkdtemp()
    path = os.path.join(tmpdir, 'file')
    open(path, 'w').close()
    atime = 815362000.0
    mtime = 815362000.0
    errnote = 'Cannot update utime of file'
    p = PostProcessor(None)
    p.try_utime(path, atime, mtime, errnote)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:10:42.249245
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    from .common import FakeYDL
    from .test_common import FakeFile
    from sys import version_info

    # This test does not work with Python 2
    if version_info[0] == 2: return

    params = {
        'embedthumbnail': True,
        'outtmpl': 'test_%(ext)s',
        'postprocessor_args': ['-vn'],
        'keepvideo': False,
    }
    fd = FileDownloader(params, FakeYDL(), {'format': 'bestaudio'})
    pp = fd._requested_postprocessing
    file_obj = pp._files_to_process[0]

# Generated at 2022-06-12 19:10:43.108864
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass


# Generated at 2022-06-12 19:10:50.330657
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Utility method to test try_utime of class PostProcessor
    """

    import tempfile
    import shutil
    import time

    def _create_file(name, ctime, atime, mtime):
        f = open(name, 'w')
        os.utime(name, (atime, mtime))
        os.utime(name, (ctime, ctime))
        f.close()


# Generated at 2022-06-12 19:10:57.365168
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp(prefix='youtubedl_test_PostProcessor_try_utime_')
    tempfile_path = os.path.join(tempdir, 'tempfile.txt')
    try:
        os.makedirs(tempdir)
    except OSError:
        pass
    with open(tempfile_path, 'w'):
        pass

    class MockDownloader:
        def __init__(self, params):
            self.params = params
            self.report_warnings = []

        def report_warning(self, errnote):
            self.report_warnings.append(errnote)

    atime = None
    mtime = None


# Generated at 2022-06-12 19:10:59.209875
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime('', 0, 0)
    return True

# Generated at 2022-06-12 19:11:07.308308
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class TestDownloader():

        def __init__(self):
            self.report = []
            self.notice = []
            self.warning = []
            self.error = []

        def report_warning(self, msg):
            self.warning.append(msg)

    pp = PostProcessor(downloader=TestDownloader())

    try:
        os.utime = None
        pp.try_utime('/tmp/file', 1, 2, errnote='Test error')
        assert pp._downloader.warning[0] == 'Test error'
    finally:
        os.utime = os.utime

# Generated at 2022-06-12 19:11:17.940774
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import stat
    import tempfile
    import time
    from ..utils import encodeFilename

    tfile = tempfile.NamedTemporaryFile()
    tfile = encodeFilename(tfile.name)

    pp = PostProcessor(None)

    orig_st = os.stat(tfile)
    orig_atime = orig_st.st_atime
    orig_mtime = orig_st.st_mtime
    orig_mode = orig_st.st_mode

    # try to change st_atime and st_mtime to bring them beyond the resolution of os.utime()
    # (it's usually 1 sec at least on Unix)
    pp.try_utime(tfile, orig_atime + 10.0, orig_mtime + 10.0)


# Generated at 2022-06-12 19:11:24.992198
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class MockDownloader:
        def report_warning(*args):
            assert True

    class MockPostProcessor(PostProcessor):
        def __init__(self):
            super(MockPostProcessor, self).__init__()

        def utime(self, path, times):
            return MockUtime(path, times)

    class MockUtime:
        def __init__(self, path, times):
            self.path = path
            self.times = times

        def __call__(self, *a):
            assert False

    def test_errnote(errnote):
        pp = MockPostProcessor()
        pp.set_downloader(MockDownloader())
        mock_utime = MockUtime('path', (1, 2))
        pp._utime = mock_utime
        pp.try_ut

# Generated at 2022-06-12 19:11:35.802860
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import tempfile
    import os
    try:
        import posix
    except ImportError:
        posix = None

    pp = PostProcessor(None)
    fd, path = tempfile.mkstemp(suffix='.mp3')
    t = time.time()-5000

# Generated at 2022-06-12 19:11:38.973147
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    assert 'Cannot update utime of file' in pp.try_utime(None, 0, 0, errnote='Cannot update utime of file')

# Generated at 2022-06-12 19:11:39.355749
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-12 19:11:48.037597
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    file_atime = os.stat(temp_file.name).st_atime
    file_mtime = os.stat(temp_file.name).st_mtime

    downloader = object
    post_processor = PostProcessor(downloader)

    post_processor.try_utime(temp_file.name, file_atime, file_mtime)

    file_atime = os.stat(temp_file.name).st_atime
    file_mtime = os.stat(temp_file.name).st_mtime

    assert file_atime == file_atime
    assert file_mtime == file_mtime

    os.remove(temp_file.name)

# Generated at 2022-06-12 19:11:51.476088
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader

    class MockPP(PostProcessor):
        pass

    pp = MockPP()
    pp.set_downloader(FileDownloader())
    pp.try_utime('file', 1, 2)



# Generated at 2022-06-12 19:11:56.248453
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import prepend_extension
    from ..compat import TemporaryFile

    pp = PostProcessor(None)

    # Test with a non-existing file (should be skipped)
    fd, tmp1 = prepend_extension(TemporaryFile(), '.tmp')
    os.unlink(tmp1)
    pp.try_utime(tmp1, 0, 0)

    # Test with an existing file
    fd.close()
    pp.try_utime(tmp1, 0, 0)
    os.unlink(tmp1)

# Generated at 2022-06-12 19:12:05.675778
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """ Unit test for method try_utime of class PostProcessor """
    from ..downloader import HttpFD

    # fake file descriptor
    class FakeFD(HttpFD):
        def __init__(self, desc):
            if desc == 'a'*4096:
                raise OSError('should not happen')
            if desc == 'b'*4096:
                raise IOError('should not happen')
        def getheaders(self):
            return {'content-length': '0'}
        def read(self, amt):
            return 'a'*amt

    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    orig_http_fd = ydl._HttpFD = HttpFD
    ydl._HttpFD = FakeFD

    # create temporary file
    import tempfile
    temp_

# Generated at 2022-06-12 19:12:18.172564
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import mock
    import os
    import stat
    import time
    import unittest
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

    class TestDownloader():
        def report_warning(self, msg):
            print ("TestDownloader report_warning: " + msg)

    class TestFile(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode
        def __enter__(self):
            pass
        def __exit__(self, type, value, traceback):
            pass
        def chmod(self, mode):
            self.mode = mode
        def stat(self):
            return TestFileStat(self.mode)

# Generated at 2022-06-12 19:12:22.179620
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .extractor import YoutubeIE
    ie = YoutubeIE()

    from .downloader import FileDownloader
    downloader = FileDownloader({})

    from .postprocessor import FFmpegMetadataPP
    FFmpegMetadataPP = FFmpegMetadataPP(downloader)


# Generated at 2022-06-12 19:12:32.393925
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time

    class FakeDownloader:
        def report_warning(self, msg):
            pass

    class FakePP(PostProcessor):
        def __init__(self, downloader, tmp_path):
            PostProcessor.__init__(self, downloader)
            self._tmp_path = tmp_path

        def run(self, information):
            return [], information

    # Make temporary directory
    tmp_path = tempfile.mkdtemp()

    # Create test file
    tmp_dir = os.path.join(tmp_path, 'dir')
    os.mkdir(tmp_dir)
    tmp_file = os.path.join(tmp_dir, 'test_file')
    file(tmp_file, 'w').close()

    # Get initial

# Generated at 2022-06-12 19:12:41.633602
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import shutil
    from ..utils import DateTime
    def calc_mtime(datetime):
        return time.mktime(datetime.timetuple())

    olddir = os.getcwd()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:12:53.566089
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import sys

    class FakePostProcessor(PostProcessor):
        pass

    tmpdir = tempfile.mkdtemp()
    orig_stderr = sys.stderr

# Generated at 2022-06-12 19:12:59.631512
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import gettempdir
    import shutil

    pp = PostProcessor(None)
    tmpdir = gettempdir()
    filename = os.path.join(tmpdir, 'testfile')
    with open(encodeFilename(filename), 'w') as f:
        f.write('')

    pp.try_utime(filename, 0, 0)

    # Remove generated file
    shutil.rmtree(tmpdir)

# Generated at 2022-06-12 19:13:06.366867
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a fake file in temporary directory
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(prefix='PostProcessor_try_utime', delete=False) as f:
        pass

    # Test method try_utime
    fake_PostProcessor = PostProcessor()
    fake_PostProcessor.try_utime(f.name, 123, 456)

    # Get modification time of temporary file and compare it with expected value
    assert os.stat(f.name).st_mtime == 456

    # Cleanup
    os.remove(f.name)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:13:14.556784
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..utils import DateRange

# Generated at 2022-06-12 19:13:25.464155
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time

    # Create a PostProcessor object without a downloader
    pp = PostProcessor(None)

    # Create a temporary file and set file access and modification time (atime, mtime)
    fd, tmp_file = tempfile.mkstemp(prefix='PostProcessor.', suffix='.test')
    os.close(fd)
    old_atime = old_mtime = time.time() - 100  # About three minutes ago
    os.utime(tmp_file, (old_atime, old_mtime))

    # Modify file access and modification time with PostProcessor method try_utime
    new_atime = new_mtime = time.time() - 10  # About ten seconds ago

# Generated at 2022-06-12 19:13:33.345286
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import shutil
    import time
    import os
    import platform
    # Create temporary directory and file
    os_system = platform.system()
    if os_system == 'Windows':
        temp_dir = os.path.join(os.getenv('TEMP'), 'youtube_dl-test-dir')
        temp_dir = encodeFilename(temp_dir)
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.mkdir(temp_dir)
        temp_file = os.path.join(temp_dir, 'youtube-dl-test-file')
        temp_file = encodeFilename(temp_file)
        with open(temp_file, 'w') as f:
            f.write(os_system)
   

# Generated at 2022-06-12 19:13:50.557402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil

    class DummyDl:
        def report_warning(self, message):
            print(message)

    my_time = time.gmtime(time.time())

    a = PostProcessor(DummyDl())
    a.try_utime('nonexistingfile', my_time, my_time) # Should succeed with this warning
    tmp_dir = tempfile.mkdtemp(prefix='ytdl_test_')
    try:
        tmp_file = os.path.join(tmp_dir, 'test')
        file(tmp_file, 'w').write('test')
        a.try_utime(tmp_file, my_time, my_time) # Should succeed with this warning
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-12 19:14:02.293156
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import unittest

    class TestPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader=downloader)
            self.tmpdir = None

        def run(self, information):
            self.tmpdir = tempfile.mkdtemp()
            filename = 'file1'
            path = os.path.join(self.tmpdir, filename)
            with open(path, 'w') as f:
                f.write('some data')
            self.try_utime(path, -1, -1, 'none')
            return [], information

        def __del__(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-12 19:14:04.715726
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    pp.try_utime(__file__, 0, 0)  # force reading of this file with utime.utime

# Generated at 2022-06-12 19:14:15.618400
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import time
    from .YoutubeDL import YoutubeDL

    tempdir = tempfile.mkdtemp(prefix='youtubedl_utime_test_')

    fname = os.path.join(tempdir, 'test.file')
    with open(fname, 'w'):
        pass

    orig_atime = os.path.getatime(fname)
    orig_mtime = os.path.getmtime(fname)

    pp = PostProcessor(YoutubeDL())

# Generated at 2022-06-12 19:14:22.854069
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader(object):
        def report_warning(self, note):
            print(note)

    pp = PostProcessor(FakeDownloader())
    try:
        pp.try_utime('./test', 10000, 20000, 'error')
    except UnicodeDecodeError:
        pass
    else:
        assert False

if __name__ == '__main__':
    test_PostProcessor_try_utime()
    print('Test passed.')

# Generated at 2022-06-12 19:14:26.973281
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    downloader = object()
    postprocessor = PostProcessor(downloader)
    postprocessor.try_utime("/tmp/pafy-test-utime", 1, 1, "errnote: sample")  # Change utime of a non existing file

# Generated at 2022-06-12 19:14:34.997848
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    test function for PostProcessor._try_utime
    """
    # Create a PostProcessor object (because the function is a method)
    pp = PostProcessor()
    import time
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf_name = tf.name
    tf.close()
    pp.try_utime(tf_name, 0, 1)
    assert os.path.getatime(tf_name) == 0
    assert os.path.getmtime(tf_name) == 1

# Generated at 2022-06-12 19:14:40.176238
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FileDownloader
    from pytube import YouTube
    yt = YouTube()
    fd = FileDownloader(yt, params={
        'postprocessor_args': ['-vn', '-acodec', 'pcm_s16le']
    })
    pp = PostProcessor(fd)
    pp.try_utime('/video.mp4', 0, 0)


# Generated at 2022-06-12 19:14:51.745067
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from tempfile import TemporaryFile, gettempdir

    from .common import FileDownloader
    from .extractor import gen_extractors

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)

        def run(self, info):
            # Implicitly tests PostProcessor.set_downloader
            assert self._downloader.params['outtmpl'] == '%(title)s.%(ext)s'

            # Remove temporary files in case this method fails
            tmpfiles = []

# Generated at 2022-06-12 19:15:02.416491
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Tests try_utime method of class PostProcessor.

    Verify it works correctly, even in directories that the user running
    the test may not have write permission.
    """
    import tempfile
    import errno
    import shutil

    # Rename a file to a temporary directory that we know we can write to
    filename = tempfile.mktemp(prefix='20140809')
    shutil.move(__file__, filename)

    # Change utime() to raise a PermissionDenied exception
    old_utime = os.utime


# Generated at 2022-06-12 19:15:22.180715
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import sys
    import shutil

    temp_dest_dir = tempfile.mkdtemp()
    sys.path.append(temp_dest_dir)
    temp_dest_file = os.path.join(temp_dest_dir, "file")
    shutil.copy(__file__, temp_dest_file)
    file_timestamp = os.path.getmtime(temp_dest_file)
    time.sleep(1)

    class TestPostProcessor(PostProcessor):
        def test_utime(self, path):
            self.try_utime(path, file_timestamp, file_timestamp)
            assert os.path.getmtime(path) == file_timestamp

# Generated at 2022-06-12 19:15:33.087732
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time


# Generated at 2022-06-12 19:15:43.228220
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # First put in place a fake class for downloader, then a fake class for postprocessor
    # and finally we run the test
    class FakeDownloader(object):
        def __init__(self):
            self.params = {'keep_date': False}
            self.report_warning = lambda *args: None

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)

    os.utime = lambda *args, **kwargs: None

    p = FakePostProcessor(FakeDownloader())
    p.try_utime('t', 1, 2)  # Keep original file datetime
    p.try_utime('t', 1, 2, 'Warning')  # Keep original file datetime and display a warning

    p

# Generated at 2022-06-12 19:15:53.787219
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(FakePostProcessor, self).__init__(downloader)
            self.utime_path = None
            self.utime_atime = None
            self.utime_mtime = None

        def try_utime(self, path, atime, mtime, errnote=None):
            self.utime_path = path
            self.utime_atime = atime
            self.utime_mtime = mtime

    class FakeDownloader(object):
        def __init__(self):
            self.params = {
                'outtmpl': 'test_outtmpl',
            }

        def report_warning(self, errnote):
            pass


# Generated at 2022-06-12 19:16:02.072623
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import unittest
    import tempfile
    import time
    import os
    import sys
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
        def test_try_utime(self, path, atime, mtime, errnote):
            files = self.run({'filepath': path})[0]
            return files

    class TestPostProcessor_try_utime(unittest.TestCase):
        def setUp(self):
            self.path = tempfile.mkstemp()[1]
            self.time_format = '%Y%m%d%H%M.%S'
            self.mtime = '201709221700.10'
            self.atime = '201709221701.00'


# Generated at 2022-06-12 19:16:10.125447
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from tempfile import mkdtemp
    from ..downloader import FakeDownloader

    try:
        tmpdir = mkdtemp()
        fd = open(tmpdir + '/atime', 'w')
        fd.close()

        pp = PostProcessor(FakeDownloader())
        pp.try_utime(tmpdir + '/atime', 10000, 20000)
        assert os.stat(tmpdir + '/atime').st_atime == 10000
        shutil.rmtree(tmpdir)
    except:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-12 19:16:15.366213
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class Downloader(object):
        def report_warning(self, errnote):
            print(errnote)
    pp = PostProcessor(Downloader())

    # Error case: cannot change access and modification time of file.
    # The function should report an error.
    path = './dummy_file'
    pp.try_utime(path, 10, 10)

    # Normal case: access and modification time of file can be changed.
    # The function should not report an error.
    path = './audioConverterTest.wav'
    pp.try_utime(path, 10, 10)

# Generated at 2022-06-12 19:16:27.061351
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeDownloader
    from .test_utils import FakeFile

    downloader = FakeDownloader()
    pp = PostProcessor(downloader)

    fake_file = FakeFile('/opt/file.txt')


# Generated at 2022-06-12 19:16:39.109755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .utils import DateRange
    import time

    test_range = DateRange(int(time.time()) - 300, int(time.time()) + 300)
    import tempfile
    import os
    d = tempfile.mkdtemp(prefix='youtubedl_test_utime')
    open(os.path.join(d, 'test'), 'wb').close()
    test_path = os.path.join(d, 'test')
    p = PostProcessor(None)
    p.try_utime(test_path, test_range.start, test_range.end)
    t = os.stat(test_path)
    assert t.st_mtime >= test_range.start
    assert t.st_mtime <= test_range.end
    assert t.st_atime >= test_range.start

# Generated at 2022-06-12 19:16:51.128688
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ydl_test.base_test import BaseTest

    class Dummy(PostProcessor):
        def __init__(self, downloader=None, outtmpl=None, errnote=None):
            super(Dummy, self).__init__()
            self.downloader = downloader
            self.outtmpl = outtmpl
            self.errnote = errnote

        def run(self, path):
            self.try_utime(path, 100, 200, self.errnote)

    class MockDownloader(object):
        def __init__(self, params):
            self.params = params

        def to_screen(self, msg):
            self.msg = msg

    test_utils = BaseTest()

# Generated at 2022-06-12 19:17:24.391325
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    fd, path = tempfile.mkstemp(prefix='try_utime')
    f = os.fdopen(fd, 'wb')
    f.write(b'foo')
    f.close()
    import time
    before = time.time()
    time.sleep(3)
    pp = PostProcessor(None)
    pp.try_utime(path, None, None)
    after = time.time()
    assert os.path.getmtime(path) >= before \
        and os.path.getmtime(path) <= after
    os.remove(path)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-12 19:17:25.596383
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # FIXME: Add unit tests for method try_utime
    pass

# Generated at 2022-06-12 19:17:30.435901
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader():
        def __init__(self):
            self.to_stderr_counts = 0

        def to_stderr(self, message):
            self.to_stderr_counts += 1

    class TestPostProcessor(PostProcessor):
        pass

    pp = TestPostProcessor()
    pp._downloader = DummyDownloader()
    pp.try_utime('test', 0,0, 'Test')
    assert pp._downloader.to_stderr_counts == 1

# Generated at 2022-06-12 19:17:35.850996
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractor
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    postprocess = PostProcessor(FileDownloader(HttpFD()))
    class DummyInfo(object):
        pass
    info = DummyInfo()
    info.extractor_key = 'dummy'
    info.video_id = 'dummy'
    info.title = 'dummy'
    info.uploader = 'dummy'
    info.uploader_url = 'dummy'
    gen_extractor.gen_extractors()
    try:
        postprocess.run(info)
    except PostProcessingError:
        pass

# Generated at 2022-06-12 19:17:42.804711
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time

    fd, fn = tempfile.mkstemp()
    os.close(fd)

    pp = PostProcessor(None)
    mtime = time.time()
    pp.try_utime(fn, mtime, mtime)
    f_mtime = os.stat(fn).st_mtime
    assert abs(mtime - f_mtime) <= 1, 'Utimes differ: %r %r' % (mtime, f_mtime)

    os.remove(fn)  # cleanup

# Generated at 2022-06-12 19:17:54.076835
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor()
    import shutil
    import tempfile
    import time
    # mtime and atime are the same.
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)
    time1 = os.stat(filename).st_mtime
    time.sleep(1)
    p.try_utime(filename, time1, time1)
    assert time1 != os.stat(filename).st_mtime
    os.unlink(filename)
    # atime is changed and mtime is the same
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)
    time1 = os.stat(filename).st_mtime
    time2 = time1 - 100
    time.sleep(1)

# Generated at 2022-06-12 19:18:03.901448
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def test_try_utime(self=PostProcessor(), path=None, atime=None, mtime=None, errnote='Cannot update utime of file'):
        self.try_utime(path, atime, mtime, errnote)
    test_try_utime(path=None, atime=None, mtime=None, errnote='Cannot update utime of file')
    test_try_utime(path='path', atime=None, mtime=None, errnote='Cannot update utime of file')
    test_try_utime(path='path', atime=1, mtime=None, errnote='Cannot update utime of file')
    test_try_utime(path='path', atime=None, mtime=1, errnote='Cannot update utime of file')
   

# Generated at 2022-06-12 19:18:12.697983
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.f4m import F4MDownloader
    from ..extractor.channel import YoutubeChannelIE
    from ..extractor.playlist import YoutubePlaylistIE
    import datetime
    import tempfile
    import shutil
    import os
    import sys

    #
    # a simple PostProcessor that allows to set the desired atime and mtime
    #
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None, atime=None, mtime=None):
            super(TestPostProcessor, self).__init__(downloader)
            self._atime = atime
            self._mtime = mtime
        def run(self, information):
            path = information['filepath']

# Generated at 2022-06-12 19:18:15.479523
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass
    # TODO:
    # add 'try_utime' to PostProcessor class, then add a test for

# Generated at 2022-06-12 19:18:19.400123
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    # Test exception
    try:
        pp.try_utime(1,1,1)
    except Exception:
        pass
    # Test success
    try:
        pp.try_utime(__file__,1,1)
    except Exception:
        assert False

# Generated at 2022-06-12 19:19:21.996446
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os

    if os.name == 'nt':
        from ..downloader import FileDownloader  # pylint: disable=no-name-in-module
        downloader = FileDownloader({})
        pp = PostProcessor(downloader)
        content = b'foobar'
        with open('test.test', 'wb') as outf:
            outf.write(content)
        try:
            pp.try_utime('test.test', 1.1, 1.2)
            os.remove('test.test')
        except Exception:
            assert False
            os.remove('test.test')
        else:
            assert True

# Generated at 2022-06-12 19:19:28.882331
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import atexit
    import copy
    import stat

    import downloader
    import FileDownloader
    import extractor

    info = {
        'url':'http://www.test.test/test.test',
        'title':'test',
        'ext':'test'
    }

    temp_dir = tempfile.mkdtemp()
    atexit.register(shutil.rmtree, temp_dir)

    ydl = downloader.FileDownloader({'outtmpl':temp_dir+'/%(title)s.%(ext)s'})

    info_new = copy.copy(info)
    info_new['filepath'] = temp_dir+'/'+info['title']+'.'+info['ext']

# Generated at 2022-06-12 19:19:38.798135
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    from ytdl.utils import (
        DownloadError,
        encodeFilename,
        PostProcessingError,
        read_batch_urls,
        retain_default_filename,
        sanitize_path,
        std_headers,
    )

    class MockDownloader(object):
        params = {}
        to_screen = lambda self, mess: sys.stderr.write( (mess + '\n').encode('utf-8') )
        to_stderr = lambda self, mess: sys.stderr.write( (mess + '\n').encode('utf-8') )

# Generated at 2022-06-12 19:19:45.265912
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
        PostProcessor.try_utime(self, path, atime, mtime, errnote)
    PostProcessor.try_utime = try_utime
    fd = FileDownloader()
    fd.params.update({"verbose":True})
    pp = PostProcessor(downloader=fd)
    pp.try_utime("test_utime", 0, 0, "test_utime");
    assert True

# Generated at 2022-06-12 19:19:51.075310
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .helpers import make_video_info

    ydl_opts = {'quiet': True}
    ydl = YoutubeDL(ydl_opts)

    fake_file_path = 'fake_file_path'
    post_processor = PostProcessor(ydl)

    atime = 'atime'
    mtime = 'mtime'
    errnote = 'errnote'

    # mock the utime method so it raises an exception, then catch that exception
    # when it is raised by try_utime

# Generated at 2022-06-12 19:19:52.346402
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert False

# Generated at 2022-06-12 19:20:00.070309
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    import os
    import sys
    import subprocess
    import re
    import stat

    def utime_INVALID_ARGUMENT(path, atime, mtime):
        # Windows ERROR_INVALID_PARAMETER == 22
        raise OSError(22, 'Invalid argument')

    def run_tests(self, f, errnote='Cannot update utime of file'):
        old_utime = os.utime

        # Test normal operation
        path = os.path.join(temp_dir, 'test_file')
        f(path)
        self.try_utime(path, 0, 0)
        mtime = os.stat(path).st_mtime
        os.utime(path, (mtime, mtime))
