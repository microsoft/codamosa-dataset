

# Generated at 2022-06-24 14:00:35.216281
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import platform
    import unittest

    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from .common import PostProcessorTest

    # many tests for utime break filesystems with symlinks
    # so ignore them on systems that support them
    if not hasattr(os, 'symlink'):
        class TestPostProcessor(PostProcessorTest):
            def test_utime_ENOENT(self):
                pp = PostProcessor(None)
                pp.try_utime('not_real_file', 0, 0, errnote='Ignore')
                self.assertTrue(True)

            def test_utime_EPERM(self):
                pp = PostProcessor(None)
                # create a file in a directory without write permissions
                temp_d

# Generated at 2022-06-24 14:00:38.985218
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("Some message", "more information")
    except AudioConversionError as err:
        assert err.message == "Some message"
        assert err.caused_by == "more information"



# Generated at 2022-06-24 14:00:43.503734
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp1 = PostProcessor()
    pp2 = PostProcessor(downloader=True)
    pp1.set_downloader(True)
    assert pp1._downloader
    assert pp2._downloader

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:00:45.103705
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('message', output=None, error=None)

# Generated at 2022-06-24 14:00:46.132648
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:00:51.990063
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 'a', 'b')
    except AudioConversionError as exception:
        assert exception.original_path == 1
        assert exception.real_path == 'a'
        assert exception.format == 'b'
        assert str(exception) == 'a: b'
    else:
        assert False, 'AudioConversionError not raised'

# Generated at 2022-06-24 14:00:57.277580
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    postprocessor = MockPostProcessor()
    assert postprocessor._downloader is None
    postprocessor.set_downloader(None)
    assert postprocessor._downloader is None

# Generated at 2022-06-24 14:01:04.646804
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest

    def test_func(path, atime, mtime, errnote):
        pp = PostProcessor(downloader=None)
        pp.try_utime(path, atime, mtime, errnote)

    test_func(None, 0, 0, None)
    test_func('postprocessor_test', 0, 0, None)

    with pytest.raises(Exception):
        test_func(None, 0, 0, None)



# Generated at 2022-06-24 14:01:12.254284
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class PostProcessorTest(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

    class DownloaderTest:
        def __init__(self):
            self.test_variable = None

    downloader_test = DownloaderTest()
    postprocessor_test = PostProcessorTest(downloader_test)
    postprocessor_test.set_downloader(downloader_test)
    assert postprocessor_test.downloader is downloader_test


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:01:16.716731
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class FakeDownloader(object):
        def __init__(self):
            self.name = 'test_downloader'
    downloader = FakeDownloader()
    postprocessor = PostProcessor()
    postprocessor.set_downloader(downloader)
    assert postprocessor._downloader == downloader
    assert postprocessor._downloader.name == 'test_downloader'



# Generated at 2022-06-24 14:01:19.888115
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class _TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information
    p = _TestPostProcessor()
    assert p.run({}) == ([], {})

# Generated at 2022-06-24 14:01:21.302418
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:01:23.894192
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # We can call constructor of class AudioConversionError
    AudioConversionError()



# Generated at 2022-06-24 14:01:27.792336
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)
    pp = TestPP()
    assert pp._downloader is None
    pp = TestPP('foo')
    assert pp._downloader == 'foo'

# Generated at 2022-06-24 14:01:28.758991
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError()


# Generated at 2022-06-24 14:01:38.054280
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Test PostProcessor.run() with simple PostProcessor subclass
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    # Test PostProcessor.run() with simple PostProcessor subclass
    class TestPostProcessorReturnsNone(PostProcessor):
        def run(self, information):
            return None

    # Test PostProcessor.run() with simple PostProcessor subclass
    class TestPostProcessorRaisesException(PostProcessor):
        def run(self, information):
            raise PostProcessingError('Test exception')

    info_dict = {'ext': 'flv', 'url': 'http://example.com/example.flv', 'id': 'example'}
    test_postprocessor = TestPostProcessor(None)

    # No exception is raised, deleted file list is empty

# Generated at 2022-06-24 14:01:42.825155
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPP(PostProcessor):
        def __init__(self):
            self.downloader = None

        def set_downloader(self, downloader):
            self.downloader = downloader

    pp = TestPP()
    pp.set_downloader({'test': 'qwerty'})
    assert pp.downloader['test'] == 'qwerty'



# Generated at 2022-06-24 14:01:50.001847
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Unit test for method set_downloader of class PostProcessor
    """
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            assert self._downloader == downloader
            return [], information
    pp = DummyPostProcessor()
    downloader = 'DUMMY DOWNLOADER'
    pp.set_downloader(downloader)
    pp.run(information='information')

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:01:59.739704
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO
    from ydl.downloader.downloader import FileDownloader
    from ydl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ydl.postprocessor.xattrpp import XAttrMetadataPP


# Generated at 2022-06-24 14:02:09.409483
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    from ..compat import compat_stat
    from ..downloader.common import FileDownloader

    def app(parameters):
        fd = FileDownloader(parameters)
        import tempfile
        tf = tempfile.NamedTemporaryFile(delete=False)
        tf.write(b'123')
        tf.close()
        t = fd.postprocessor.run({'filepath': tf.name})
        os.remove(tf.name)

    app(['--test'] + ['--postprocessor-args'] + ['a'] + ['--postprocessor-args'] + ['b'])
    app(['--test'] + ['--no-postprocessor'])
    app(['--test'])



# Generated at 2022-06-24 14:02:11.643073
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    dummy_message = 'Dummy message'
    try:
        raise AudioConversionError(dummy_message)
    except Exception as e:
        assert e.args[0] == dummy_message

# Generated at 2022-06-24 14:02:16.687561
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('abc', '', '', '', '', '', '', '')
    msg = str(err)
    assert msg == 'abc: \n\n'


# Generated at 2022-06-24 14:02:23.317453
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def __init__(self, param1, param2, param3):
            self.param1 = param1
            self.param2 = param2
            self.param3 = param3

        def run(self, information):
            return self.param1, (self.param2, self.param3)

    information = {'title': 'Foo'}

    pp = TestPP('argument1', 'argument2', 'argument3')
    assert pp.run(information) == (
        'argument1',
        ('argument2', 'argument3')
    )

# Generated at 2022-06-24 14:02:25.323910
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message', 'output', 'error')
    except AudioConversionError as e:
        assert str(e) == 'message\noutput\nerror'

# Generated at 2022-06-24 14:02:30.200297
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor object
    pp = PostProcessor()
    # Create a TestFile
    with open(encodeFilename('TestFile'), 'w') as f:
        f.write('test')
    # Call method try_utime
    pp.try_utime('TestFile', 0, 0, 'Error')
    pass


# Generated at 2022-06-24 14:02:31.930925
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("some error")
    except AudioConversionError as e:
        assert str(e) == "some error"


# Generated at 2022-06-24 14:02:43.248536
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request

    class MockInfoExtractor(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def extract(self, url):
            return self.ie_result

    class MockYoutubeDL(object):
        def __init__(self, ie, params):
            self.ie = MockInfoExtractor(ie)
            self.params = params

    class MockPostProcessor(PostProcessor):
        def __init__(self, ie_result, params):
            super(MockPostProcessor, self).__init__()
            self._downloader = MockYoutubeDL(ie_result, params)

    class MockDownloader(object):
        def report_warning(self, msg):
            pass


# Generated at 2022-06-24 14:02:47.374072
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('[PafyUnitTest] AudioConversionError')
    except AudioConversionError as err:
        assert str(err) == '[PafyUnitTest] AudioConversionError'

# Generated at 2022-06-24 14:02:54.528621
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import __main__
    assert '__main__' == __main__.__name__
    obj = PostProcessor()
    assert None == obj._downloader
    assert [] == obj._configuration_args()
    assert [] == obj._configuration_args(default=None)
    assert None == obj._configuration_args(default=None, key='a-key')
    assert None == obj._configuration_args(default=None)
    assert None == obj._configuration_args(default=None, key='a-key')

# Generated at 2022-06-24 14:02:55.984337
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    from ..utils import Excep

# Generated at 2022-06-24 14:03:04.064648
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import tempfile
    import os
    import shutil
    import sys

    if sys.platform == 'win32':
        import ctypes

        # Fake an EPERM error
        # See https://docs.python.org/2/library/errno.html
        EPERM = 1
        EPERM_STR = 'Operation not permitted'

        def fake_utime(filename, times=None):
            import ctypes.wintypes
            from ctypes import WinError

            SetFileTime = ctypes.windll.kernel32.SetFileTime

# Generated at 2022-06-24 14:03:04.675285
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:03:07.945602
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    postProcessor = PostProcessor()
    information = {'filepath': 'counters'}
    files_to_delete, information = postProcessor.run(information)
    assert information == {'filepath': 'counters'}
    assert files_to_delete == []

# Generated at 2022-06-24 14:03:17.768292
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PP1(PostProcessor):
        def run(self, info):
            if "version" in info:
                info["version"] = 1
            else:
                info["version"] = 2
            return [], info

    class PP2(PostProcessor):
        def run(self, info):
            if "version" in info:
                info["version"] = 3
                return [], info
            else:
                return [], None

    pp1 = PP1()
    pp2 = PP2()
    pp1.set_downloader(pp2)  # pp2 is a downloader
    pp2.add_post_processor(pp1)  # pp1 is a post processor
    info = pp1.run(pp2.run({"key": "value"}))[1]  # This is the function call we want to test

# Generated at 2022-06-24 14:03:19.906506
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
  assert "PostProcessor"
  pp = PostProcessor()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 14:03:21.463000
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None
    assert PostProcessor(1)._downloader == 1

# Generated at 2022-06-24 14:03:28.767578
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from types import MethodType
    from collections import namedtuple
    from mock import Mock
    from tempfile import NamedTemporaryFile

    # mock downloader object
    mock_downloader = Mock()
    mock_downloader.params = {}
    mock_downloader.report_warning = MethodType(lambda x, y: None, mock_downloader)
    mock_downloader.report_error = MethodType(lambda x, y: None, mock_downloader)

    # mock file
    dummy_file = NamedTemporaryFile(delete=False)
    tmpfile_name = dummy_file.name
    dummy_file.close()

    information = {
        'filepath': tmpfile_name,
    }

    # run empty post processor
    pp = PostProcessor(mock_downloader)
    result = pp.run(information)



# Generated at 2022-06-24 14:03:34.632990
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    import os
    import datetime
    import calendar
    p = PostProcessor(ydl)
    test_file = ydl.prepare_filename("test_file")
    target_time = datetime.datetime.utcnow()
    target_time_utc = calendar.timegm(target_time.utctimetuple())
    open(test_file, 'a').close()
    p.try_utime(test_file, target_time_utc, target_time_utc)
    assert round(os.path.getmtime(test_file)) == round(target_time_utc)
    assert round(os.path.getatime(test_time)) == round(target_time_utc)

# Generated at 2022-06-24 14:03:36.245448
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Tests whether the constructor of PostProcessor class works correctly."""
    pp = PostProcessor()
    assert pp != None


# Generated at 2022-06-24 14:03:40.223456
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test if PostProcessor initializes properly
    pp = PostProcessor()
    assert pp
    assert not hasattr(pp, '_downloader')

    # Test if set_downloader method works properly
    d = {}
    pp.set_downloader(d)
    assert pp._downloader == d


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:03:50.458039
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .concat import ConcatPP
    from .execafterdownload import ExecAfterDownloadPP
    from .xattrpp import XAttrMetadataPP
    from .metadatafromtitle import MetadataFromTitlePP
    # Defining the two required static methods
    def TEST_PP_run(self, information):
        pass
    def TEST_PP_set_downloader(self, downloader):
        # Checking if the downloader has been added to self
        assert downloader is self._downloader
    # Setting up the class
    TEST_PP = type('TEST_PP', (PostProcessor,), {'run': TEST_PP_run, 'set_downloader': TEST_PP_set_downloader})
    # Creating the downloader
    downloader = YoutubeDL(params={})
    #

# Generated at 2022-06-24 14:03:51.014115
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError()

# Generated at 2022-06-24 14:03:52.477608
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('foo')
    assert 'foo' in str(err)

# Generated at 2022-06-24 14:03:54.741583
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    'Test PostProcessor constructor'
    d = object()
    pp = PostProcessor(d)
    assert pp._downloader is d

# Generated at 2022-06-24 14:03:56.702984
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None, 'Cannot initialize class PostProcessor'

# Generated at 2022-06-24 14:03:59.008774
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("MESSAGE", "OUTPUT_FILE", "ERROR")
    except AudioConversionError as e:
        assert str(e) == "MESSAGE: ERROR"
        assert e.output_file == "OUTPUT_FILE"
        assert e.error == "ERROR"

# Generated at 2022-06-24 14:04:02.445294
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(format='mp3', audio_codec='libmp3lame')
    except AudioConversionError as a:
        assert a.format == 'mp3'
        assert a.audio_codec == 'libmp3lame'



# Generated at 2022-06-24 14:04:03.914480
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

if __name__ == '__main__':
    test_PostProcessor()
    print('Test completed successfully')

# Generated at 2022-06-24 14:04:06.558935
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL({})
    pp = PostProcessor(downloader)
    assert pp._downloader is not None
    pp.set_downloader(downloader)
    assert pp._downloader is not None


# Generated at 2022-06-24 14:04:08.855790
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def set_downloader_test(self, downloader):
            pass
    tpp = TestPostProcessor()
    tpp.set_downloader_test(tpp._downloader)

# Generated at 2022-06-24 14:04:15.889389
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a downloader and a fake info
    downloader = object()

# Generated at 2022-06-24 14:04:19.676081
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    # Create an empty PostProcessor object
    obj = PostProcessor()
    # Check that set_downloader sets its _downloader field properly
    obj.set_downloader(FileDownloader({}))

# Generated at 2022-06-24 14:04:22.103483
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class
    """
    pp_obj = PostProcessor()
    assert pp_obj


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:28.989734
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    try:
        PostProcessor().run(None)
    except TypeError:
        pass
    else:
        raise Exception('run method of class PostProcessor must raise exception if information argument is not defined')
    try:
        PostProcessor().run({})
    except KeyError:
        pass
    else:
        raise Exception('run method of class PostProcessor must raise exception if filepath not in information argument')
    pp = PostProcessor()
    assert pp.run({'filepath': 'test'}) == ([], {'filepath': 'test'})

# Generated at 2022-06-24 14:04:29.564076
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:04:32.663357
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError(Exception()).args[0] == 'Audio conversion failed: '



# Generated at 2022-06-24 14:04:34.683535
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = "Some message"
    err = AudioConversionError(msg)
    assert err.msg == msg


# Generated at 2022-06-24 14:04:35.924364
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert (str(AudioConversionError(Exception('xyz'))) == 'xyz')

# Generated at 2022-06-24 14:04:41.112852
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ is PostProcessor
    assert pp._downloader is None
    pp = PostProcessor(downloader='dummy_downloader')
    assert pp._downloader == 'dummy_downloader'


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:44.595267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPP(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader
    pp = MockPP()
    pp.try_utime("", "", "")

# Generated at 2022-06-24 14:04:49.245632
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert hasattr(err, 'msg') and err.msg == 'test'
        assert hasattr(err, 'convert_info') and err.convert_info == []



# Generated at 2022-06-24 14:04:51.469466
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        pp = PostProcessor()
    except:
        assert False, 'Could not construct PostProcessor'
    assert pp != None

# Generated at 2022-06-24 14:04:54.235056
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:57.192675
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'test exception'
    try:
        raise AudioConversionError(msg)
    except PostProcessingError as e:
        assert e.args[0] == msg

# Generated at 2022-06-24 14:05:03.062280
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Check for audio conversion

    class _FakeDownloader(object):
        params = {}

        @staticmethod
        def to_screen(msg):
            print(msg)

        @staticmethod
        def report_error(msg):
            raise AudioConversionError(msg)

    p = PostProcessor(downloader=_FakeDownloader())
    info = {'filepath': '/fake/path'}

    assert p.run(info) == (info, [])

# Generated at 2022-06-24 14:05:10.447918
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.params['outtmpl'] = '%(upload_date)s-%(id)s.%(ext)s'
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    assert pp._configuration_args() == []
    pp.set_downloader(None)
    assert pp._downloader is None
    assert pp._configuration_args() == []

# Generated at 2022-06-24 14:05:14.377910
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create a PostProcessor
    pp = PostProcessor()

    # Unit test of set_downloader with None as value of _downloader
    pp.set_downloader(None)

    # Unit test of set_downloader with a downloader object
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp.set_downloader(ydl)


# Generated at 2022-06-24 14:05:17.781432
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class _FakeDownloader:

        @staticmethod
        def report_warning(text):
            pass

    _FakeDownloader.params = {}
    pp = PostProcessor(_FakeDownloader)
    pp.try_utime(path=None, atime=None, mtime=None)

# Generated at 2022-06-24 14:05:27.200489
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractor
    from ..downloader.common import FileDownloader

    class TestInfoExtractor(gen_extractor(object, None, [])):
        def __init__(self):
            super(TestInfoExtractor, self).__init__()
            self.params["audioformat"] = "best"  # Force AudioConversionPP to be added

        def _real_extract(self, url):
            return {
                'url': url,
                'title': 'test',
                'id': 'test',
            }

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            assert self._downloader is not None  # Check downloader was set
            return [], information

    ie = TestInfoExtractor()

# Generated at 2022-06-24 14:05:31.838615
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor"""
    # Start with a blank instance of PostProcessor
    pp = PostProcessor()

    # call constructor of class PostProcessor
    pp = PostProcessor()
    try:
        pp.run('foo')
    except TypeError:
        pass
    else:
        raise TypeError('Expected TypeError')

# Generated at 2022-06-24 14:05:42.691638
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pass
#class PostProcessor(object):
#    def __init__(self,downloader = None):
#        self.downloader = downloader
#        if self.downloader == None:
#            raise PostProcessingError("You can't run the extractor without a downloader")
#
#    def run(self,information):
#        return [],information
#
#    def set_downloader(self,downloader):
#        self.downloader = downloader
#
#    def try_utime(self,path,atime,mtime,errnote = "Cannot update utime of file"):
#        try:
#            os.utime(encodeFilename(path),(atime,mtime))
#        except Exception:
#            self.downloader.report_warning(errnote)
#
#   

# Generated at 2022-06-24 14:05:45.622529
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError()
    assert err is not None


# Generated at 2022-06-24 14:05:46.643397
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pass

# Generated at 2022-06-24 14:05:48.118054
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert err.args[0] == 'test'

# Generated at 2022-06-24 14:05:49.565560
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    assert PostProcessor()._downloader is None
    assert PostProcessor(downloader=1)._downloader == 1

# Generated at 2022-06-24 14:05:53.354591
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError:
        pass
    else:
        assert False

# Generated at 2022-06-24 14:05:54.634279
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError:
        pass

# Generated at 2022-06-24 14:05:57.582939
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    post_processor = PostProcessor(None)
    downloader = FileDownloader(None, {})
    post_processor.set_downloader(downloader)
    assert post_processor._downloader is downloader

# Generated at 2022-06-24 14:05:59.518560
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Test audio postprocessing.
    """
    pp = PostProcessor()
    if pp is None:
        raise TypeError

# Generated at 2022-06-24 14:06:04.792489
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    def test_inner_object_method(self):
        self.a_class_method_has_been_called = True
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            test_inner_object_method(self)
            return [], information
    i = TestPostProcessor()
    i.set_downloader(object())
    i.run({})
    assert i.a_class_method_has_been_called

# Generated at 2022-06-24 14:06:06.496707
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:06:07.685655
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('test').args == ('test',)

# Generated at 2022-06-24 14:06:14.604402
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    pp = PostProcessor()
    dl = YoutubeDL()
    pp.set_downloader(dl)
    assert isinstance(pp._downloader, YoutubeDL)
    dl2 = FileDownloader()
    pp.set_downloader(dl2)
    assert isinstance(pp._downloader, FileDownloader)
    assert pp._downloader is dl2

# Generated at 2022-06-24 14:06:22.670516
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert 'something went wrong' == AudioConversionError('something went wrong').msg
    assert 'foo' == AudioConversionError('something went wrong', 'foo').reason
    assert 'something went wrong' == AudioConversionError('something went wrong', 'foo').msg
    assert 'Trying to download foo, but something went wrong' == AudioConversionError(
        'Trying to download foo, but something went wrong').msg


# Generated at 2022-06-24 14:06:24.725590
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp2 = PostProcessor(object)
    assert pp._downloader == None
    assert pp2._downloader == object

# Generated at 2022-06-24 14:06:35.280855
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Create a dummy PostProcessor object
    class DummyPP(PostProcessor):
        def __init__(self):
            pass

    pp = DummyPP()

    # Patch report_warning method
    pp._downloader = type('DummyDL', (object,), {'report_warning': lambda self, str: self.warn_count + 1})()
    pp._downloader.warn_count = 0

    # Test try_utime with none existing file
    pp.try_utime('none_existing_file', 0, 0)

    # Test try_utime with existing file
    import tempfile
    fd, fp = tempfile.mkstemp()
    os.close(fd)
    pp.try_utime(fp, 0, 0)
    os.remove(fp)

# Generated at 2022-06-24 14:06:36.372841
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    return p

# Generated at 2022-06-24 14:06:48.519889
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test that PostProcessor.set_downloader works.
    """
    class TestDownloader(object):
        def __init__(self, test_logs):
            self.test_logs = test_logs

        def to_stdout(self, message, skip_eol=False, check_quiet=False):
            pass

        def report_warning(self, message):
            self.test_logs.append(message)

    class TestPostProcessor(PostProcessor):
        def __init__(self, test_logs, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.test_logs = test_logs


# Generated at 2022-06-24 14:06:55.837815
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Unit test constructor of class AudioConversionError"""

    # Initialize AudioConversionError object
    audio_conversion_error_obj = AudioConversionError('a', 'b')

    # Test values of member variables
    assert audio_conversion_error_obj.converter_name == 'a'
    assert audio_conversion_error_obj.original_message == 'b'
    assert audio_conversion_error_obj.encoding == 'utf-8'
    assert audio_conversion_error_obj.cause is None

# Generated at 2022-06-24 14:06:59.730274
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    pp = PostProcessor(None)
    assert pp._downloader is None

    file_downloader = FileDownloader({})
    pp.set_downloader(file_downloader)
    assert pp._downloader == file_downloader

# Generated at 2022-06-24 14:07:02.320337
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestDownloader: pass
    class TestPostProcessor(PostProcessor): pass
    p = TestPostProcessor()
    d = TestDownloader()
    p.set_downloader(d)
    assert p._downloader is d

# Generated at 2022-06-24 14:07:04.131906
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message')
    except AudioConversionError as e:
        assert str(e) == 'message'

# Generated at 2022-06-24 14:07:11.081710
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Test a PostProcessor using a downloader
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)
            self.downloader = downloader
        def run(self, info):
            assert self._downloader is not None
            assert self.downloader is not None
            return [], info
    tpp = TestPP()
    class TestDownloader:
        url = 'http://foo'
        filename = '-'
        params = {}
    td = TestDownloader()
    tpp.set_downloader(td)
    tpp.run({'filepath': 'foo.flv'})

    # Test a PostProcessor without a downloader

# Generated at 2022-06-24 14:07:15.131908
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 'dummy', 'dummy')
    except AudioConversionError as err:
        pass
    except Exception as err:
        raise TypeError('AudioConversionError constructor has changed, failing test')
        # raise TypeError('Incorrect type of exception raised: %r' % err)

# Generated at 2022-06-24 14:07:18.142877
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader is ydl



# Generated at 2022-06-24 14:07:21.544230
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    pp = DummyPostProcessor()
    pp.run({})



# Generated at 2022-06-24 14:07:22.258706
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    return p

# Generated at 2022-06-24 14:07:23.301717
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass # TODO

# Generated at 2022-06-24 14:07:25.590586
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    if pp is None:
        assert False, 'Can not create an instance of PostProcessor'
    else:
        assert True

# Generated at 2022-06-24 14:07:27.014243
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:28.292447
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

# Generated at 2022-06-24 14:07:29.460636
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()

# Generated at 2022-06-24 14:07:31.010202
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError()
    AudioConversionError('Some message')

# Generated at 2022-06-24 14:07:35.091267
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Method set_downloader return True when set downloader is null.
    """
    pp = PostProcessor()
    assert pp.set_downloader(None) is True


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:07:37.870876
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    PostProcessor(Downloader()).try_utime(os.path.realpath(__file__), 0, 0, 'test')

# Generated at 2022-06-24 14:07:45.986102
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyDownloader(object):
        _mypp = None

        def __init__(self, mypp):
            self._mypp = mypp

        def postproc(self):
            return self._mypp

    class DummyPostProcessor(PostProcessor):
        def __init__(self, mypp):
            PostProcessor.__init__(self, mypp)

    pp = DummyPostProcessor(DummyDownloader('mypp'))
    assert pp._downloader is DummyDownloader('mypp')

    pp.set_downloader(DummyDownloader('mypp2'))
    assert pp._downloader is DummyDownloader('mypp2')

# Generated at 2022-06-24 14:07:51.362462
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """
    Test constructor of class AudioConversionError
    """
    video_info = {'id': 'someid', 'fulltitle': 'some fulltitle', 'ext': 'some extension'}
    try:
        raise AudioConversionError(video_info, 'some msg', None)
    except AudioConversionError as e:
        assert e.video_info == video_info
        assert e.msg == 'some msg'
        assert e.outfile == 'some fulltitle.some extension'
    else:
        raise AssertionError('AudioConversionError not raised')



# Generated at 2022-06-24 14:07:57.007005
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader for PostProcessor class
    """
    from youtube_dl.downloader import FileDownloader
    from ..utils import fake_YDL

    ydl = fake_YDL()
    pp = PostProcessor(ydl)
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:08:00.633353
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    downloader = FileDownloader()
    pp.set_downloader(downloader)
    # expected result: attribute _downloader of pp is set to downloader
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:08:02.633586
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    PP = PostProcessor(None)
    assert PP.run({}) == ([], {})

# Generated at 2022-06-24 14:08:07.975128
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test parent directory of file
    pp = PostProcessor(None)

    # temp file name in current dir
    fname = '.test_PostProcessor_try_utime'

    # create temp file
    open(fname, 'w').close()

    # test if the file is successfully removed
    pp.try_utime(fname,0,0)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-24 14:08:08.493273
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:08:13.630745
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl.YoutubeDL
    # Example of a Downloader object
    d = youtube_dl.YoutubeDL({})

    # Example of a PostProcessor
    class PP(PostProcessor):
        pass

    pp = PP()
    pp.set_downloader(d)
    assert(pp._downloader == d)

# Generated at 2022-06-24 14:08:17.683660
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()

    # Initial state of PostProcessor object
    assert pp._downloader is None

    # Create object of class YoutubeDL
    ydl = YoutubeDL()

    # Set downloader of pp to ydl and check if it is done
    pp.set_downloader(ydl)
    assert pp._downloader is ydl

# Generated at 2022-06-24 14:08:27.934527
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    temp_file = tempfile.TemporaryFile()
    temp_file.close()
    # Get the modification time
    old_atime = time.time() - 100
    old_mtime = old_atime + 20
    os.utime(temp_file.name, (old_atime, old_mtime))
    assert os.path.getatime(temp_file.name) == old_atime
    assert os.path.getmtime(temp_file.name) == old_mtime
    # PostProcessor should be able to reset the time
    pp = PostProcessor(None)
    pp.try_utime(temp_file.name, old_atime, old_mtime)
    assert os.path.getatime(temp_file.name) == old_at

# Generated at 2022-06-24 14:08:30.802315
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
        raise AssertionError('Exception AudioConversionError raised')
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:08:34.030740
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime = None
        pp = PostProcessor()
        pp.try_utime('', 0, 0)
    except:
        return False
    return True

# Generated at 2022-06-24 14:08:43.909044
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    import shutil

    class TestPP(PostProcessor):
        def __init__(self):
            self.data = ''

        def run(self, info):
            self.data = info['somefield']
            return [], info

    with tempfile.NamedTemporaryFile(suffix='.mp4') as tf:
        info = {
            'somefield': 'hello',
            'filepath': tf.name,
        }

        test_pp = TestPP()
        files_to_delete, updated_info = test_pp.run(info)
        assert test_pp.data == 'hello'
        assert updated_info is info
        assert files_to_delete == []



# Generated at 2022-06-24 14:08:54.432935
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # create test video file
    video_size = 10 * 10 * 10
    test_video_file = open(encodeFilename('test.file'), 'wb')
    test_video_file.seek(video_size)
    test_video_file.write(b'0')
    test_video_file.close()
    # create test post processor
    class test_PostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    pp = test_PostProcessor()
    # no exception
    pp.try_utime(encodeFilename('test.file'), 0, 0)
    # check if file exists
    assert os.path.isfile(encodeFilename('test.file'))
    # delete test file
    os.remove(encodeFilename('test.file'))

# Generated at 2022-06-24 14:09:01.598897
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..utils import YoutubeDL

    class MyInfoExtractor(InfoExtractor):
        pass

    class TestPP(PostProcessor):
        pass

    ie = MyInfoExtractor(YoutubeDL())
    pp = TestPP()
    pp.set_downloader(ie)
    assert pp._downloader == ie
    assert ie.post_processors == [pp]


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:09:07.779850
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.downloader.common import FileDownloader
    # Create some downloader
    ydl = FileDownloader(params={})
    # Create some PostProcessor with dummy run method
    pp = PostProcessor(ydl)

    # Set the downloader of the PostProcessor
    pp.set_downloader(ydl)

    # Check if the downloader is set correctly
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:09:17.998161
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..compat import compat_urllib_error

    old_downloader = Downloader()
    old_downloader.add_info_extractor(YoutubeIE())
    old_downloader.add_post_processor(PostProcessor())
    tmpfilename = old_downloader.prepare_filename('test')
    fake_cmd_line_opts = {
        'format': 'best',
        'format_limit': '3',
        'nooverwrites': True,
    }

# Generated at 2022-06-24 14:09:20.079746
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp
    assert pp.run({}) == ([], {})


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:27.332289
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)

    # Check that it works if os.utime does too
    utime_orig = os.utime
    try:
        os.utime = lambda x, y: 42
        eq_(pp.try_utime('filename', 1,  2), 42)
    finally:
        os.utime = utime_orig

    # Check that it works also if os.utime doesn't
    utime_orig1 = os.utime
    try:
        os.utime = lambda x, y: None
        eq_(pp.try_utime('filename', 1,  2), None)
    finally:
        os.utime = utime_orig1

# Generated at 2022-06-24 14:09:29.595488
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPostProcessor(PostProcessor):
        pass
    test_postprocessor = TestPostProcessor()
    assert test_postprocessor is not None

# Generated at 2022-06-24 14:09:32.646529
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test PostProcessor class"""
    pp = PostProcessor()
    return pp.__class__ == PostProcessor and pp.run == PostProcessor.run

# Generated at 2022-06-24 14:09:35.721047
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test initialization of the PostProcessor class."""
    # kwargs is used in place of an actual downloader instance
    assert PostProcessor(**{})._downloader is None

# Generated at 2022-06-24 14:09:38.941778
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("message", "outname", "errname")
    except AudioConversionError as e:
        assert e.outname == "outname"
        assert e.errname == "errname"

# Generated at 2022-06-24 14:09:44.262764
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class FakeDummyPP(PostProcessor):
        def run(self, information):
            return []

    d = FakeDummyPP()
    assert d._downloader is None
    d.set_downloader(1)
    assert d._downloader == 1


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:09:51.936973
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Test without a file to delete and without updating information
    pp = PostProcessor(None)
    info = {'filepath': 'test.flv'}
    assert pp.run(info) == ([], info)

    # Testing when the downloader is setted
    pp = PostProcessor()
    pp.set_downloader(object)
    info = {'filepath': 'test.flv'}
    assert pp.run(info) == ([], info)

    # Test with one file to delete and updating information
    pp = PostProcessor()
    info = {'filepath': 'test.flv'}
    assert pp.run(info) == ([], info)

# Generated at 2022-06-24 14:09:54.186137
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:10:01.166937
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    postprocessor = PostProcessor()

    class FakeInfo(dict):
        def __init__(self, filepath):
            self.filepath = filepath
            super(FakeInfo, self).__init__()

    info = FakeInfo('some_file')
    assert postprocessor.run(info) == ([], info)

    class FakePostProcessor(PostProcessor):
        """Fake post processor"""
        def run(self, info):
            """Fake run"""
            files = ['file1', 'file2']
            info['new_field'] = files
            return (files, info)

    postprocessor = FakePostProcessor()
    files_to_delete, info = postprocessor.run(info)
    assert files_to_delete == ['file1', 'file2']

# Generated at 2022-06-24 14:10:03.215396
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1000, None)
    except (PostProcessingError, AudioConversionError) as err:
        assert type(err) is AudioConversionError
        assert err.args[0] == 1000
        assert err.args[1] is None

# Generated at 2022-06-24 14:10:05.978280
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    post_processor = PostProcessor()
    assert post_processor._downloader is None
    post_processor.set_downloader(object())
    assert post_processor._downloader is not None

# Generated at 2022-06-24 14:10:08.859845
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def run(self, information):
            assert self._downloader is not None
            return [], information

    pp = TestPP()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:10:17.582017
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock

    dummy_file = object()
    dummy_downloader = compat_mock.MagicMock()
    dummy_pp = PostProcessor(downloader=dummy_downloader)

    with compat_mock.patch('os.utime', return_value=None) as mock:
        dummy_pp.try_utime(dummy_file, 1, 2)
        mock.assert_called_once_with(dummy_file, (1, 2))

    with compat_mock.patch('os.utime', side_effect=OSError):
        dummy_pp.try_utime(dummy_file, 1, 2, 'mocked error')
        dummy_downloader.report_warning.assert_called_once_with('mocked error')

# Generated at 2022-06-24 14:10:24.635655
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import stat

    # Setup a temporary directory and create an empty file
    tmpdir = tempfile.mkdtemp()
    path = tmpdir + "/test_try_utime"
    open(path, "a").close()

    # Get the current time values
    now = time.time()
    atime = now
    mtime = now - 60

    # Change the previous time values for the file
    p = PostProcessor(None)
    p.try_utime(path, atime, mtime)
    assert os.stat(path)[stat.ST_ATIME] == atime
    assert os.stat(path)[stat.ST_MTIME] == mtime

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-24 14:10:34.820927
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Test a PostProcessor that does nothing
    class TestPostProcessor1(PostProcessor):
        def run(self, information):
            return [], information

    test_PostProcessor1 = TestPostProcessor1()
    test_files1 = [os.path.join(temp_dir, 'test_file_1.out')]
    for test_file1 in test_files1:
        with open(test_file1, 'wb') as f:
            f.write(b'test file')
    information1 = {'filepath': test_files1[0]}
    files_to_delete, information = test_PostProcessor1.run(information1)
    assert sorted(files_to_delete) == test_files1  # nothing should be