

# Generated at 2022-06-24 14:00:34.052043
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """If you're changing this test, make sure you're changing the test file
    postprocessor_test.py!

    This is a test of the function PostProcessor().try_utime, which should work correctly
    on both win32 and posix systems.
    """
    # Create a file
    TESTFN = '%s_123' % os.path.basename(__file__) + '.test'

# Generated at 2022-06-24 14:00:36.177837
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except Exception as exc:
        assert type(exc) == AudioConversionError
        assert str(exc) == 'Audio conversion failed'

# Generated at 2022-06-24 14:00:40.289267
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Test_set_downloader video and audio
    pp = PostProcessor()
    pp.set_downloader(None)
    # Test_set_downloader audio
    pp2 = PostProcessor()
    pp2.set_downloader(None)

# Generated at 2022-06-24 14:00:40.956592
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:00:43.504341
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:00:46.761696
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.set_downloader(None)

    try:
        assert pp.run(None, None) == ([], None)
    except PostProcessingError:
        assert False

# Generated at 2022-06-24 14:00:47.806219
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # TODO
    pass

# Generated at 2022-06-24 14:00:54.305455
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class ExamplePP(PostProcessor):
        def run(self, information):
            information['arg1'] = 'test'
            return ['test.file'], information

    information = { 'filepath': 'test.file' }
    pp = ExamplePP()
    files, information = pp.run(information)
    assert information['arg1'] == 'test'
    assert files == ['test.file']

# Generated at 2022-06-24 14:01:05.357895
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import errno
    import platform
    import time
    import datetime
    import tempfile
    import shutil
    import os
    import stat

    # Test that the method sets the time on a file.
    # It should work with or without the utime() in os.
    # Test in a temp dir because we are going to mess with the times
    if platform.system() == 'Windows':
        import win32file

        def set_times(path, atime, mtime):
            win32file.SetFileTime(encodeFilename(path), atime, atime, mtime)
    else:
        def set_times(path, atime, mtime):
            os.utime(encodeFilename(path), (atime, mtime))

    # Some values to use

# Generated at 2022-06-24 14:01:14.890701
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import mock
    import datetime
    from ..compat import get_system

    # Initialize test parameters
    pp = PostProcessor(None)
    path = 'path'
    atime = datetime.datetime.fromtimestamp(1400239977)
    mtime = datetime.datetime.fromtimestamp(1400239977)
    errnote = 'Cannot update utime of file'

    # Execute run for Windows OS
    with mock.patch('os.utime', autospec=True) as mock_utime:
        with mock.patch('os.path.getmtime', autospec=True) as mock_getmtime:
            mock_getmtime.return_value = 1400239977


# Generated at 2022-06-24 14:01:16.740620
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None
    assert pp.run(None) == ([], None)

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:01:25.488948
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import locale
    locale.setlocale(locale.LC_ALL, '')
    import os
    import random
    import string
    import tempfile
    import time
    import unittest
    import shutil

    chars = string.ascii_lowercase + string.digits
    tmpdir = tempfile.mkdtemp()
    tmpfilename = ''.join([random.choice(chars) for i in range(6)])

# Generated at 2022-06-24 14:01:35.302148
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import os

    # create test directory
    test_dir = os.path.join(os.path.dirname(__file__), 'test_dir')
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)

    # create a file
    fp = open(os.path.join(test_dir, 'test_file'), 'wb')
    fp.write(b'a')
    fp.close()

    # get current time
    current_time = time.time()

    # test, file is created at current time
    fp = open(os.path.join(test_dir, 'test_file'), 'rb')
    assert fp.read() == b'a'
    fp.close()

# Generated at 2022-06-24 14:01:38.559960
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    assert p._downloader is None
    d = object()
    p.set_downloader(d)
    assert p._downloader is d

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:01:43.504332
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from .XAttrMetadataPP import XAttrMetadataPP
    xattr_meta_pp = XAttrMetadataPP()
    assert xattr_meta_pp._downloader is None
    youtube_dl = YoutubeDL()
    xattr_meta_pp.set_downloader(youtube_dl)
    assert xattr_meta_pp._downloader is youtube_dl

# Generated at 2022-06-24 14:01:48.841246
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor import SubtitlesConvertorPP

    downloader = FileDownloader()
    pp1 = SubtitlesConvertorPP(downloader)
    pp1.set_downloader(downloader)

    assert downloader == pp1._downloader

# Generated at 2022-06-24 14:01:59.083708
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class DummyPP(PostProcessor):
        def __init__(self, return_value):
            self._return = return_value

        def run(self, information):
            return self._return

    d = DummyPP([])
    adict = {'a':'b'}
    output = d.run(adict)
    assert output == (['b'], adict)

    d = DummyPP(None)
    adict = {'a':'b'}
    output = d.run(adict)
    assert output == ([], adict)

    d = DummyPP([])
    adict = {'a':1, 'b':2}
    output = d.run(adict)
    assert output == (['1', '2'], adict)

    d = DummyPP([])


# Generated at 2022-06-24 14:02:09.756264
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Remove the utime method, like if the OS doesn't support it
    try:
        os.utime
    except AttributeError:
        del os.utime
    # Mocking PostProcessor class
    class MockPostProcessor(PostProcessor):
        pass
    # Mocking object downloader
    class MockDownloader(object):
        def __init__(self):
            self.dirname_warnings = []
        def report_warning(self, errnote):
            self.dirname_warnings.append(errnote)
    # Object downloader instance
    downloader = MockDownloader()
    # Object PostProcessor instance
    post_processor = MockPostProcessor(downloader)
    # Testing utime method for a file
    # Create a test file
    dirname = 'PostProcessor_try_utime'


# Generated at 2022-06-24 14:02:11.740942
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 2)
    except AudioConversionError as err:
        assert err.converted == 1
        assert err.original == 2

# Generated at 2022-06-24 14:02:15.427673
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    t = PostProcessor()
    t.run(None)
    t.set_downloader(None)

# Generated at 2022-06-24 14:02:15.838277
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass



# Generated at 2022-06-24 14:02:17.257234
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor(None)
    pp.set_downloader(True)
    assert pp._downloader == True

# Generated at 2022-06-24 14:02:19.400938
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    obj = AudioConversionError('error_message', 'output_file')
    assert obj.msg == 'error_message'
    assert obj.output_file == 'output_file'

# Generated at 2022-06-24 14:02:21.659891
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test_AudioConversionError')
    except PostProcessingError as e:
        assert e.args[0] == 'test_AudioConversionError'

# Generated at 2022-06-24 14:02:31.672627
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.youtube import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..FileDownloader import FileDownloader

    # Test falsy post processor
    noop = PostProcessor()
    downloader = FileDownloader(params={})
    downloader.add_info_extractor(YoutubeIE())
    noop.set_downloader(downloader)
    assert noop._downloader == downloader

    # Test post processor that returns None.
    # See https://github.com/ytdl-org/youtube-dl/issues/12453
    noop = PostProcessor()
    downloader = FileDownloader(params={})
    downloader.add_info_extractor(YoutubeIE())
    noop.set_downloader(downloader)


# Generated at 2022-06-24 14:02:34.187215
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('msg'):
        pass # does nothing
    with AudioConversionError('msg2'):
        raise Exception()

# Generated at 2022-06-24 14:02:35.420650
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('error message')



# Generated at 2022-06-24 14:02:36.440386
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp != None

# Generated at 2022-06-24 14:02:46.647849
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import UTF8_WRITABLE
    tmp_filename = 'PostProcessor_try_utime_test' + os.path.extsep + 'txt'
    with open(tmp_filename, 'wb') as f:
        f.write(b'TESTING PostProcessor_try_utime')

# Generated at 2022-06-24 14:02:48.182980
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    desc = 'Audio conversion error'
    try:
        raise AudioConversionError(desc)
    except AudioConversionError as e:
        assert str(e) == desc


# Generated at 2022-06-24 14:02:50.012526
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = None
    post_processor = PostProcessor(downloader)
    assert post_processor._downloader == downloader

# Generated at 2022-06-24 14:02:51.382042
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('Test')
    assert err.args == ('Test',)

# Generated at 2022-06-24 14:03:01.426863
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockInfoExtractor(object):
        def __init__(self, ie_params):
            self.ie_params = ie_params

        def get_downloader(self):
            return self.ie_params
    
    IE = MockInfoExtractor({'test': 1})

    class MockPostProcessor(PostProcessor):
        def __init__(self, pp_params):
            super(MockPostProcessor, self).__init__()
            self.pp_params = pp_params

    PP = MockPostProcessor({'test': 0, 'IE': IE})
    PP.set_downloader({'test': 1})
    assert PP._downloader == {'test': 1}
    assert PP.pp_params == {'IE': IE}

# Generated at 2022-06-24 14:03:10.094935
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import os
    import pytest
    from ..utils import encodeFilename
    from .common import Downloader

    # Create test file
    fname = 'test_PostProcessor_try_utime'
    with open(encodeFilename(fname), 'w') as test_file:
        test_file.write('Hello\n')
    atime = mtime = datetime.datetime(2015, 12, 9, 16, 52, 0, 0)
    atime = int(atime.strftime('%s'))
    mtime = int(mtime.strftime('%s'))
    os.utime(encodeFilename(fname), (atime, mtime))
    os.chmod(encodeFilename(fname), 0o444)

# Generated at 2022-06-24 14:03:19.838018
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import os
    import shutil
    import tempfile

    class MockDownloader(object):
        def report_warning(self, msg):
            pass

    class MockPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(MockPostProcessor, self).__init__(downloader=MockDownloader())

    tempdir = tempfile.mkdtemp()

    p = MockPostProcessor()

# Generated at 2022-06-24 14:03:27.622744
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test if _postprocessors.PostProcessor.run works as expected
    """
    from collections import namedtuple

    def process_it(arg):
        assert arg.pp_mode == 'test_mode'
        assert arg.get('status') == 'OK'
        return namedtuple('result', ['files_to_delete', 'result'])([], {'status': 'OK', 'pp_mode': 'test_mode', 'next_step': arg['next_step'] + 1, 'info': arg['info'] + 1})

    test_info = {
        'status': 'OK',
        'pp_mode': 'test_mode',
        'next_step': 1,
        'info': 1,
    }

    pp = PostProcessor(None)

    # Test with simple PostProcessor chain

# Generated at 2022-06-24 14:03:36.123793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Ensure PostProcessor.try_utime() method works properly."""
    # create test files and folders
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    assert not os.access(data_dir, os.W_OK)  # ensure it does not exist

# Generated at 2022-06-24 14:03:38.608641
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    assert pp._downloader is None
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:03:46.032730
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    ydl = YoutubeDL()
    fd = FileDownloader(ydl)
    fd.add_info_extractor(None) # dummy IE
    fd.params['postprocessor_args'] = []
    pp = FFmpegPostProcessor(fd)
    assert pp.get_info_filename() == '' # downloader not set
    pp.set_downloader(fd)
    assert pp.get_info_filename() != '' # downloader set

# Generated at 2022-06-24 14:03:56.325195
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import set
    from ..utils import sanitize_open

    class FakePostProcessor(PostProcessor):
        def run(self, information):
            assert isinstance(information, dict)
            assert 'filepath' in information
            return [information['filepath']], information

    class FakeDownloader(object):
        def __init__(self, directories):
            self.directories = directories
            self.to_screen = lambda *args, **kargs: self
            self.to_stderr = lambda *args, **kargs: self
            self.report_warning = lambda *args, **kargs: self

        def temp_name(self, filename):
            return os.path.join(self.directories['temporary'], filename)

    downloader = FakeDownloader({'temporary': '/tmp'})


# Generated at 2022-06-24 14:03:56.768245
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:04:01.787473
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    from ..utils import cmd_function

    test_filename = 'test.mp4'

    class MockExtractor(InfoExtractor):
        IE_NAME = 'Mock'
        _VALID_URL = r'^Mock$'

        def _real_extract(self, url):
            return {'id': 'TestID'}

    class MockPostProcessor(PostProcessor):
        def run(self, information):
            assert self._downloader is not None
            assert isinstance(self._downloader, FileDownloader)
            self._downloader.to_stderr(compat_str(information))
            return [test_filename, information]


# Generated at 2022-06-24 14:04:05.059444
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError(3, 4, 5)
    # Test that args are set properly
    err = AudioConversionError(3, 4, 5)
    assert err.original_status == 3
    assert err.converted_status == 4
    assert err.conversion_command == 5

# Generated at 2022-06-24 14:04:12.562474
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .youtube_dl import YoutubeDL

    class MockYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYDL, self).__init__(*args, **kwargs)
            self._pp = []

        def add_post_processor(self, pp):
            self._pp.append(pp)

    class MockPP(PostProcessor):
        pass

    ydl_inst = MockYDL({})
    pp_inst = MockPP()
    pp_inst.set_downloader(ydl_inst)
    assert pp_inst._downloader == ydl_inst

    ydl_inst = MockYDL({})
    pp_inst = MockPP(ydl_inst)
    assert pp_inst._downloader == ydl_inst

# Generated at 2022-06-24 14:04:16.570789
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.set_downloader(None)
    pp.run({})

# Generated at 2022-06-24 14:04:20.273763
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test1', 'test2')
    except AudioConversionError as err:
        assert(err.converter == 'test1')
        assert(err.original_path == 'test2')

# Generated at 2022-06-24 14:04:22.230659
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.set_downloader(object)
    assert pp.run(object) == ([], object)
    assert pp._configuration_args() == []

# Generated at 2022-06-24 14:04:27.380531
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Test if PostProcessor.set_downloader() properly sets the downloader for this PP"""
    class downloader:
        pass
    class PostProcessor(PostProcessor):
        pass
    d = downloader()
    pp = PostProcessor()
    pp.set_downloader(d)
    assert pp._downloader == d

# Generated at 2022-06-24 14:04:29.554913
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # trivial construction test
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:40.567561
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader


# Generated at 2022-06-24 14:04:44.079095
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.set_downloader(True)
    assert pp.run({"filepath": "mock_file"}) == ([], {"filepath": "mock_file"})

# Generated at 2022-06-24 14:04:46.010167
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """Ensure that PostProcessor._try_utime works"""
    # FIXME: Find a way to unit test this code

# Generated at 2022-06-24 14:04:47.230709
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:54.984291
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # pylint: disable=protected-access
    pp = PostProcessor()
    info = {'filepath': 'file'}
    out = pp.run(info)
    assert out == ([], info)

    pp._downloader = True
    try:
        pp.run(info)
    except PostProcessingError:
        pass
    else:
        assert False, 'This should fail'

    pp = PostProcessor()
    try:
        pp.run(info)
    except PostProcessingError:
        pass
    else:
        assert False, 'This should fail'

# Generated at 2022-06-24 14:05:03.043612
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import six

    class MockInfoExtractor(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def extract(self, url):
            return self.ie_result

    class MockYdl(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def add_post_processor(self, pp):
            self.pp = pp
            self.pp.set_downloader(self)

        def read_ie_results(self):
            return [self.ie_result]

    class MockPP(PostProcessor):
        def __init__(self, return_value):
            PostProcessor.__init__(self)
            self.return_value = return_value

        def run(self, info):
            return

# Generated at 2022-06-24 14:05:07.417641
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            """Test method to run  PostProcessor.
            """
            return [], information
    retval = DummyPostProcessor()
    assert retval

# Generated at 2022-06-24 14:05:11.029024
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    # Create a file 'file'
    (fd, filename) = tempfile.mkstemp(prefix='post-processor-test')
    os.close(fd)
    os.remove(filename)

    def postprocessor(info):
        if info['filepath'] == filename:
            return [], info  # keep file and do nothing
        else:
            return [], None  # pop postprocessor from chain and continue

    class FakeDownloader:
        params = {
            'format': 'best',  # needed to force postprocessors
        }

        def __init__(self):
            self.postprocessors = [postprocessor]
            self.downloaded_info_dicts = []

# Generated at 2022-06-24 14:05:12.708743
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = "downloader"
    PP = PostProcessor()
    PP.set_downloader(downloader)
    assert PP._downloader == downloader

# Generated at 2022-06-24 14:05:18.836167
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """


    test_PostProcessor_run method verifies that PostProcessor's run method
    correctly stops the chain when receiving None.

    """

    pp = PostProcessor()
    info = {}

    def returns_none(info):
        return None

    def returns_info(info):
        return info

    pp.run(info)  # must not raise exception
    pp.run(None)  # must not raise exception

    pp.run(None)
    pp.add_post_processor(returns_none)
    pp.run(info)  # must not raise exception

    pp.run("test")
    pp.add_post_processor(returns_none)
    pp.run("test")  # must not raise exception

    pp.add_post_processor(returns_info)
    pp.run("test")

# Generated at 2022-06-24 14:05:19.620128
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Constructor test
    """
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:05:28.436637
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    # A InfoExtractor object test object
    ie = InfoExtractor()
    ie.IE_NAME = 'TestInfoExtractor'
    ie.ie_key = 'testie'
    ie.pattern = r'^Test$'
    ie._WORKING = True

    # A FileDownloader object test object
    fd = FileDownloader()
    fd._ies = [ie]

    # A PostProcessor object test object
    pp = PostProcessor()
    pp.set_downloader(fd)

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    filename = 'test'
    test_file = os.path.join(cur_dir, filename)
    fd

# Generated at 2022-06-24 14:05:39.221047
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test whether PostProcessor.run() method can append metadata to a file properly.
    """
    import json
    import os

    from ..compat import compat_tempfile
    from ..utils import determine_ext

    from .common import FakeYDL

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None, test_metadata=None):
            self.output_file = None
            self.test_metadata = test_metadata
            super(FakePostProcessor, self).__init__(downloader)

        def run(self, information):
            ext = determine_ext(information['url'], information['filename'])
            self.output_file = compat_tempfile.NamedTemporaryFile(
                suffix=ext, delete=False)
            self.output_file.close()
           

# Generated at 2022-06-24 14:05:40.282553
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:05:42.118185
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    p.set_downloader('foo')
    assert p._downloader == 'foo'

# Generated at 2022-06-24 14:05:46.636748
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__dict__ == {'_downloader': None}
    assert pp.run({'filepath': 'filepath'}) == ([], {'filepath': 'filepath'})

# Generated at 2022-06-24 14:05:55.122045
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    assert issubclass(PostProcessor, object)
    assert hasattr(PostProcessor, '__init__')
    assert PostProcessor.__init__.__code__.co_argcount == 2
    assert PostProcessor.__init__.__code__.co_varnames == ('self', 'downloader')
    assert hasattr(PostProcessor, '_downloader')
    assert hasattr(PostProcessor, 'set_downloader')
    assert PostProcessor.set_downloader.__code__.co_argcount == 2
    assert PostProcessor.set_downloader.__code__.co_varnames == ('self', 'downloader')
    assert hasattr(PostProcessor, 'run')
    assert PostProcessor.run.__code__.co_argcount == 2

# Generated at 2022-06-24 14:06:04.042716
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import shutil
    import unittest

    from .fake_downloader import FakeDownloader

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader)
            self.filepath = ''
            self.atime = 0
            self.mtime = 0

        def run(self, information):
            super(TestPostProcessor, self).run(information)
            self.filepath = information['filepath']
            self.atime = information['atime']
            self.mtime = information['mtime']
            return [], information

    class TestPPutimeMethod(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile

# Generated at 2022-06-24 14:06:07.337766
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('spam')
    except AudioConversionError as err:
        assert (str(err) == 'spam')

# Generated at 2022-06-24 14:06:13.497587
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    pp = PostProcessor()
    assert pp._downloader is None

    ie = InfoExtractor()
    ie.set_downloader(FileDownloader())
    pp.set_downloader(ie.get_downloader())
    assert pp._downloader is not None

# Generated at 2022-06-24 14:06:17.727354
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Test PostProcessor.set_downloader()."""
    from ..downloader.common import FileDownloader
    from .xattrs import XAttrMetadataPP
    downloader = FileDownloader({})
    metadata_pp = XAttrMetadataPP()
    metadata_pp.set_downloader(downloader)
    assert metadata_pp._downloader == downloader

# Generated at 2022-06-24 14:06:27.245260
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakeYDL
    from .extractor import InfoExtractor
    from .downloader import FileDownloader
    from .compat import compat_os_name, compat_os_open

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = FakeYDL()
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ie = InfoExtractor()
    ie.set_downloader(ydl)
    info = ie.extract(url)
    fd = FileDownloader(ydl=ydl, info_dict=info)
    fd.add_info_extractor(ie)
    fd.params['postprocessor_args'] = ['--ffmpeg-location', 'nonexistent']
    pp

# Generated at 2022-06-24 14:06:35.769712
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    from .compat import (
        compat_os_name,
        compat_os_path
    )
    import tempfile

    dl = None
    pp = PostProcessor(dl)
    temp_path = tempfile.mkdtemp()

# Generated at 2022-06-24 14:06:42.296454
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.common import InfoExtractor
    from ..Downloader import Downloader
    ie = InfoExtractor()
    ie.set_downloader(Downloader())
    ie.add_info_extractor(lambda x: {'id': 'testid'})
    pp = PostProcessor(ie.get_downloader())

    info = ie._real_extract('testid')
    pp.run(info)

# Generated at 2022-06-24 14:06:52.196299
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .common import FakeYDL
    from .extractor.youtube import YoutubeIE
    from .downloader.http import HttpFD
    from .utils import DateRange
    from .compat import compat_str

    ydl = FakeYDL()
    dl = ydl.params.get('downloader', None)
    test_pp = PostProcessor(dl)
    dl.add_info_extractor(YoutubeIE())
    information = {
        'id': 'BaW_jenozKc',
        'title': 'youtube-dl test video "\'/\\ä↭𝕐',
        'formats': [{
            'url': 'http://localhost/0.flv',
        }]
    }
    td = dl.prepare_filename(information)
    td_tmp = td + '.part'


# Generated at 2022-06-24 14:06:55.100866
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("test")
    except AudioConversionError as e:
        assert str(e) == "test"


# Generated at 2022-06-24 14:06:56.814003
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('description')
    assert error.description == 'description'

# Generated at 2022-06-24 14:06:58.294086
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-24 14:06:59.387976
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None



# Generated at 2022-06-24 14:07:00.722292
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError as a:
        assert a != None

# Generated at 2022-06-24 14:07:06.073207
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=W0212
    pp = PostProcessor()
    pp._downloader = 'foo'
    assert pp._downloader == 'foo'
    pp.set_downloader('bar')
    assert pp._downloader == 'bar'
    assert pp.run({'filepath': '/foo/bar.mp4'}) == ([], {'filepath': '/foo/bar.mp4'})

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:12.028223
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():  # pylint: disable=missing-docstring
    from ..downloader import Downloader

    class MockInfoExtractor(object):
        """Mock InfoExtractor for testing PostProcessor."""
        _counter = 0

        def __init__(self, downloader=None):
            self._counter = 0

        def _real_extract(self, url):
            self._counter += 1
            return {'id': url, 'ext': 'mp4', 'title': 'mytitle%s' % self._counter, 'formats': [{'ext': 'm4a'}, {'ext': 'webm'}]}

    class MockPostProcessor(PostProcessor):
        """Mock PostProcessor for testing PostProcessor."""

# Generated at 2022-06-24 14:07:22.689007
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    from io import BytesIO
    from tempfile import NamedTemporaryFile
    from .common import FakeYDL

    # prepare fake downloader
    downloader = FakeYDL()
    downloader.params['logger'] = None

    # prepare fake PP
    pp = PostProcessor(downloader)

    # testing try_utime method
    # 1. we should be able to change the utime without exception
    tempfile = NamedTemporaryFile(mode='w', delete=False)
    tempfile.write(u'foo')
    tempfile.close()
    pp.try_utime(tempfile.name, atime=1.0, mtime=2.0)
    tempfile.close()

    # 2. opening the file in write mode should raise exception and not change the utime

# Generated at 2022-06-24 14:07:28.291580
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('Message', None)
    assert a.msg == 'Message'
    assert a.original_error is None
    assert a.exit_code == 1
    a = AudioConversionError('Message', 'bad')
    assert a.msg == 'Message'
    assert a.original_error == 'bad'
    assert a.exit_code == 0



# Generated at 2022-06-24 14:07:38.414321
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request, compat_urllib_parse

    class TestInfo(dict):
        def __init__(self, title, url, ext):
            super(TestInfo, self).__init__()
            self['title'] = title
            self['url'] = url
            self['ext'] = ext
            # A real Info object wouldn't have filepath and
            # ie_key, which is specific to our test setup.
            self['filepath'] = 'xyz'
            self['ie_key'] = 'test'

        def __repr__(self):
            return repr((self['title'], self['url'], self['ext']))

    class TestInfoExtractor:
        IE_NAME = 'Test Info Extractor'

        def __init__(self, ie_key):
            self

# Generated at 2022-06-24 14:07:40.920994
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import youtube_dl

    pp = PostProcessor(youtube_dl.FileDownloader())
    assert pp.__class__.__name__ == 'PostProcessor'

# Generated at 2022-06-24 14:07:49.669001
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_tempfile
    from ..compat import compat_urllib_error
    from ..downloader.common import FileDownloader
    from .common import PostProcessorTest

    class MockFileDownloader(FileDownloader):
        def __init__(self, params, report_warning=None, report_error=None):
            self.params = params
            self.report_warning = report_warning
            self.report_error = report_error

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self._downloader = downloader

    class MockInfoExtractor(InfoExtractor):
        def __init__(self):
            InfoExtractor.__init__(self)


# Generated at 2022-06-24 14:07:51.948442
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('test')
    assert error.message == 'test'
    assert error.cause == None



# Generated at 2022-06-24 14:07:56.845121
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl.FileDownloader
    downloader = youtube_dl.FileDownloader()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-24 14:08:00.235695
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exception = AudioConversionError('foo', 'bar', 'baz')
    assert(exception.func == 'foo')
    assert(exception.file == 'bar')
    assert(exception.msg == 'baz')



# Generated at 2022-06-24 14:08:03.870403
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(message='test message', code='test code')
    except AudioConversionError as e:
        assert str(e) == 'test message'
    else:
        assert False



# Generated at 2022-06-24 14:08:06.955786
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader('downloader')
    assert pp._downloader == 'downloader'

# Generated at 2022-06-24 14:08:09.581068
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test_error_msg')
    except AudioConversionError as err:
        assert str(err) == 'test_error_msg'



# Generated at 2022-06-24 14:08:12.889877
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    assert pp._downloader == None
    setter = YoutubeDL({})
    pp.set_downloader(setter)
    assert pp._downloader == setter

# Generated at 2022-06-24 14:08:20.577618
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time

    from youtube_dl.utils import (
        encodeFilename,
        PostProcessor,
    )

    class MyDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda x: True

        def report_warning(self, warning):
            self.params['last_warning'] = warning

    dl = MyDL()
    pp = PostProcessor(dl)
    # Testing on a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a test file with a filename containing an non ascii character
    tmpfile = os.path.join(tmpdir.encode('utf-8'), 'test file üäö.test')

    # create a file with a size of 100 bytes


# Generated at 2022-06-24 14:08:25.281261
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            information['title'] = 'abc'
            return [], information

    ph = DummyPostProcessor()

    ret = ph.run({})

    assert ret[1].get('title', None) == 'abc'

# Generated at 2022-06-24 14:08:27.344135
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    pp = PostProcessor(None)
    downloader = YoutubeDL()
    pp.set_downloader(downloader)
    assert downloader == pp._downloader

# Generated at 2022-06-24 14:08:33.044699
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..downloader.f4m import F4mFD
    ie1 = InfoExtractor()
    ie1.ie_key = 'IE1'
    ie2 = InfoExtractor()
    ie2.ie_key = 'IE2'
    ie1.add_info_extractor(ie2)
    downloader = FileDownloader({'outtmpl': 'test-%(ie_key)s-%(id)s.f4m'})
    downloader.add_info_extractor(ie1)
    fd = F4mFD(downloader, 'test', {})
    pp = PostProcessor(downloader)
    pp.run(fd.result)
    assert pp._downloader is downloader


# Unit

# Generated at 2022-06-24 14:08:43.702530
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test if PostProcessor.run() returns the correct values.
    """
    postprocessor = PostProcessor()


# Generated at 2022-06-24 14:08:46.975670
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test error')
    except AudioConversionError:
        pass
    try:
        raise AudioConversionError('test error', None, None)
    except AudioConversionError:
        pass

# Generated at 2022-06-24 14:08:48.293665
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p.run({})[1] == {}

# Generated at 2022-06-24 14:08:59.253288
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import unittest

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 2, 3)
            return [], info

    class TestPostProcessorTest(unittest.TestCase):
        def test_PostProcessor_try_utime(self):
            dummy_path = tempfile.mkdtemp(prefix='youtube-dl-utime-test-')
            dummy_file = tempfile.mkstemp(prefix='youtube-dl-utime-test-', dir=dummy_path)
            dummy_file_path = dummy_file[1]
            dummy_file_atime = time.time() - 100
            dummy_file_mtime = time.time() - 50


# Generated at 2022-06-24 14:09:11.139037
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    from ..downloader import Downloader
    from ..postprocessor import PostProcessor
    from ..compat import compat_os_name
    from ..utils import get_temp_filename
    from datetime import datetime

    def raise_OSError(path, times):
        raise OSError()

    pp = PostProcessor(Downloader())

    test_file = get_temp_filename()
    with open(test_file, 'w'):
        pass

    # Check if utime is called with right args to update mtime
    with compat_mock.patch('os.utime') as utime:
        stat_result = os.stat(test_file)
        atime, mtime = stat_result.st_atime, stat_result.st_mtime
        pp.try_

# Generated at 2022-06-24 14:09:17.268924
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    # Make a PostProcessor
    class _Dummy_PostProcessor(PostProcessor):
        pass

    # Make a downloader
    class _Dummy_Downloader(object):
        def report_warning(self, message):
            return

    downloader = _Dummy_Downloader()
    downloader.params = {}

    pp = _Dummy_PostProcessor(downloader)

    # Create a temporal file
    test_file = open(encodeFilename('test_file.tmp'), 'w')
    test_file.close()

    # Change the utime of test_file
    os.utime(encodeFilename('test_file.tmp'), (0,0))
    # Get current stat
    stat = os.stat(encodeFilename('test_file.tmp'))

    # Call to the method try_utime


# Generated at 2022-06-24 14:09:25.984652
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import Downloader
    
    #Create a downloader for test
    d = Downloader(params=None)

    #Create a postprocessor for test
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            #Check if the filepath key exists
            if information.get("filepath") is None:
                raise KeyError("filepath key must exist in information.")

            #Check if the filepath is not empty
            if os.stat(information.get("filepath")).st_size == 0:
                raise PostProcessingError("File is empty.")

            #Check if the filepath is not None
            try:
                file = open(information.get("filepath"), 'r')
                file.close()
            except IOError:
                raise PostProcessingError("File does not exist.")



# Generated at 2022-06-24 14:09:34.357306
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import errno
    import tempfile
    import shutil
    import stat
    import sys
    import time
    import unittest

    # Define test case class
    class TestCase(unittest.TestCase):
        def setUp(self):
            # Create temporary test directory
            self.directory = tempfile.mkdtemp()

        def tearDown(self):
            # Remove temporary test directory
            shutil.rmtree(self.directory)

        @staticmethod
        def _create_temp_file(directory):
            # Create temporary test file
            file_handle, file_name = tempfile.mkstemp(dir=directory)
            os.close(file_handle)
            return file_name

        def _get_atime(self, file_name):
            # Retrieve access time
            stat

# Generated at 2022-06-24 14:09:43.183586
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request
    from ..utils import sanitize_open
    import tempfile

    text_url = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/test/testfiles/test_subtitles.srt'

    request = compat_urllib_request.Request(
        text_url,
        headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
        },
    )
    with sanitize_open(request) as web_file:
        with tempfile.NamedTemporaryFile() as downloaded_file:
            downloaded_file.write(web_file.read())
            downloaded_file.flush()

# Generated at 2022-06-24 14:09:53.603453
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import unittest

    # We don't have time.time_ns, so we use a time_ns function that returns the fractional part
    # of time.time() * 1e9
    def time_ns():
        return int((time.time() % 1) * 1e9)

    class TestPostProcessor(PostProcessor):
        def __init__(self, *args, **kwargs):
            super(TestPostProcessor, self).__init__(*args, **kwargs)
            self.utime_calls = []
            self.warnings = []

        def run(self, information):
            return self.try_utime('file', time_ns(), time_ns(), 'Warn message')

        def _configuration_args(self, default=[]):
            return cli_configuration_args

# Generated at 2022-06-24 14:09:54.310975
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    audioConversionError = AudioConversionError()



# Generated at 2022-06-24 14:09:55.804949
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except PostProcessingError:
        pass
    else:
        raise Exception('PostProcessingError not raised')

# Generated at 2022-06-24 14:09:56.396672
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Placeholder, we should have some unit tests
    pass

# Generated at 2022-06-24 14:10:01.975163
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    downloader = FileDownloader()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader

    pp2 = PostProcessor()
    pp2.set_downloader(downloader)
    assert pp2._downloader is downloader

# Generated at 2022-06-24 14:10:06.119447
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError(u'Message', u'Error', u'Output', u'Command')
    assert error.output == 'Output'
    assert error.command == 'Command'
    assert error.std_err == 'Error'
    assert error.message == 'Message'

# Generated at 2022-06-24 14:10:11.828746
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    import tempfile
    with tempfile.NamedTemporaryFile() as tempy:
        test_file = tempy.name
    c = AudioConversionError(test_file, 8, None, 'test_file_name')
    assert c.errorcode == 8
    assert c.file == test_file
    assert c.orig_file == 'test_file_name'

# Generated at 2022-06-24 14:10:22.694963
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    from .common import FakeYDL
    from .utils import _fill_file

    fd, out_file = tempfile.mkstemp(prefix='test_results_')
    os.close(fd)

# Generated at 2022-06-24 14:10:29.643294
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from test.test_utils import raise_os_error
    from types import MethodType
    from tempfile import TemporaryFile

    # Create a simple PostProcessor object
    p = PostProcessor()
    assert isinstance(p, PostProcessor)

    # Define a failed utime function
    def failed_utime(s, t):
        raise_os_error(s)

    # Pass a non-existing file to try_utime
    try:
        p.try_utime('/non-existing/file', 0, 0)
    except Exception as e:
        assert str(e) == 'Cannot update utime of file'

    # Pass a existing file to try_utime
    with TemporaryFile(mode='w+b') as f:
        old_utime = os.utime

        # Pass an error-raising function