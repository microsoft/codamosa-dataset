

# Generated at 2022-06-24 14:00:31.314637
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.report_warning = lambda x: None
    p = PostProcessor(ydl)
    import tempfile
    f = tempfile.NamedTemporaryFile()
    p.try_utime(None, 0, 0)
    p.try_utime(f.name, 0, 0, errnote='NF')

# Generated at 2022-06-24 14:00:32.865505
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('foo'):
        pass
    with AudioConversionError('bar'):
        raise ValueError()



# Generated at 2022-06-24 14:00:36.208555
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    import youtube_dl
    from .common import FileDownloader

    pp = PostProcessor(downloader=None)
    downloader = FileDownloader(params={})
    pp.set_downloader(downloader)
    assert(pp._downloader == downloader)

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:00:40.751730
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class Dummy(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader

    dummy = Dummy(None)
    dummy.set_downloader('test_downloader')
    assert dummy._downloader == 'test_downloader'

# Generated at 2022-06-24 14:00:43.347975
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class constructor
    """

    pp = PostProcessor()
    assert pp
    return pp

# Generated at 2022-06-24 14:00:47.022387
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # When invoked with one argument, error_message
    AudioConversionError('some_text')

    # When invoked with two arguments, error_message and orig_message
    AudioConversionError('some_text', 'some_other_text')



# Generated at 2022-06-24 14:00:51.425939
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    def x():
        raise TypeError
    class YTDL(object):
        def __init__(self):
            self.params = {}
        def report_warning(self, msg):
            x()
    pp = PostProcessor(YTDL())
    with pp:
        pass

# Generated at 2022-06-24 14:01:01.459259
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PP1(PostProcessor):
        def run(self, info):
            info['PP1'] = '1'
            return ([], info)
    class PP2(PostProcessor):
        def run(self, info):
            info['PP2'] = '2'
            return ([], info)
    class PP3(PostProcessor):
        def run(self, info):
            info['PP3'] = '3'
            return ([], info)

    class D:
        def __init__(self):
            self.pp_chain = [PP1(), PP2(), PP3()]

        def report_warning(self, msg):
            pass

    d = D()
    info = {}
    (deleted, info) = d.pp_chain[0].run(info)
    assert info.get('PP1')

# Generated at 2022-06-24 14:01:03.816770
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == "__main__":
    test_PostProcessor()

# Generated at 2022-06-24 14:01:06.912074
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test error')
    except PostProcessingError as e:
        assert(e.message == 'test error')
        print('[PASS] PostProcessingError constructor unit test')

# Generated at 2022-06-24 14:01:09.536780
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    a = PostProcessor()
    assert a._downloader is None
    b = "Fake downloader"
    a.set_downloader(b)
    assert a._downloader is b

# Generated at 2022-06-24 14:01:11.532045
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert 'foo' == AudioConversionError('foo').msg


# Generated at 2022-06-24 14:01:13.537661
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    test_downloader = None
    test_pp = PostProcessor(test_downloader)
    assert test_pp._downloader == test_downloader

# Generated at 2022-06-24 14:01:16.621799
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = DummyPP()
    assert pp.__class__ is DummyPP
    assert pp.run({})

# Generated at 2022-06-24 14:01:25.390852
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import os
    import sys
    import shutil

    if sys.version_info[0] == 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock
    
    test_file_name = os.path.join(tempfile.gettempdir(), 'test')
    file_mock = MagicMock()

    test_time = time.time()

    pp = PostProcessor(downloader=None)
    pp.set_downloader(MagicMock())

    # Test without a file
    pp.try_utime(test_file_name, test_time, test_time)
    file_mock.assert_not_called()

    # Create a file
    f = open(test_file_name, 'w')
   

# Generated at 2022-06-24 14:01:28.990436
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader()
    PostProcessor.set_downloader(downloader)
    assert downloader == PostProcessor.downloader


if __name__ == '__main__':
    test_set_downloader()

# Generated at 2022-06-24 14:01:31.578029
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError(1,2)
    assert exc.video_id == 1
    assert exc.audio_codec == 2

# Generated at 2022-06-24 14:01:40.534931
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import io
    import os
    import tempfile

    from ytdl.postprocessor import PostProcessor

    pp = PostProcessor()
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)
    pp.try_utime(tmpname, atime=1, mtime=2, errnote='Error')

    # simulate an error in utime
    try:
        os.remove(tmpname)
    except OSError:
        pass

    fd = io.open(tmpname, 'wb')
    fd.close()

    pp.try_utime(tmpname, atime=1, mtime=2, errnote='Error')

    os.remove(tmpname)

# Generated at 2022-06-24 14:01:41.059441
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:01:43.687170
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Unit test for constructor of class AudioConversionError"""
    err = AudioConversionError("msg", "stdout", "stderr")
    assert err.msg == "msg"
    assert err.stdout == "stdout"
    assert err.stderr == "stderr"

# Generated at 2022-06-24 14:01:47.120871
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test with default config values
    pp = PostProcessor()
    assert pp._downloader == None

    # Test with specific config values
    pp_ = PostProcessor(downloader='Dummy')
    assert pp_._downloader == 'Dummy'



# Generated at 2022-06-24 14:01:48.921447
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(object())
    assert pp._downloader is not None

# Generated at 2022-06-24 14:01:59.150637
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # This is a dummy class
    class PostProcessorSubclass(PostProcessor):
        def run(self, information):
            assert information["filepath"] == "file"

# Generated at 2022-06-24 14:02:09.756417
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile

    # import module so that global 'sys' can be used
    if sys.version_info[0] == 3:
        import imp
        import io
        import shutil
        import time

        fd, filename = tempfile.mkstemp(prefix="ytdl-pp-u-", suffix='-tmp')
        test_file = io.open(fd, 'w', encoding='utf-8')
        test_file.write('\ufeff\u20ac')
        test_file.flush()
        test_file.close()
        utimes = (time.time() - 10, time.time() - 5)
        if hasattr(os, 'utime'):
            os.utime(filename, None)
            orig_stat = os.stat(filename)

# Generated at 2022-06-24 14:02:13.510179
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import sys

    pp = PostProcessor(downloader=None)
    pp.set_downloader(sys.stdout)

    assert pp._downloader == sys.stdout

    # Mode (see PostProcessor.__init__)
    pp = PostProcessor(downloader=None, mode=None)
    pp.set_downloader(sys.stdout)

    assert pp._downloader == sys.stdout

# Generated at 2022-06-24 14:02:19.222372
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        """PostProcessor that multiplies the value of field "num" by 10.

        The value of field "num" is stored in the "information" dict which
        is passed to the run() method. The TestPostProcessor saves the result
        to the "result" field of the "information" dict.

        Doesn't touch any other field.
        """

        def run(self, information):
            if not 'num' in information:
                raise PostProcessingError('Missing "num" field')
            try:
                information['result'] = information['num'] * 10
            except ValueError:
                raise PostProcessingError('Wrong datatype of value of "num" field')
            return information

    # Create a TestPostProcessor and add it to the test downloader
    tpp = TestPostProcess

# Generated at 2022-06-24 14:02:28.409243
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import sys

    if sys.platform == 'win32':
        print('test_PostProcessor_try_utime skipped on Windows')
        return
    if sys.platform == 'darwin':
        print('test_PostProcessor_try_utime skipped on macOS')
        return

    if os.geteuid() != 0:
        print('test_PostProcessor_try_utime skipped: only root can change utime')
        return

    import tempfile
    (handle, path) = tempfile.mkstemp()
    os.close(handle)

# Generated at 2022-06-24 14:02:40.110418
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # we fake a downloader and a file to test
    class FakeDownloader(object):
        def report_warning(self, message):
            pass

    class FakeFile(object):
        pass

    file = FakeFile()
    file.path = 'path/of/fake/file'
    file.atime = 0
    file.mtime = 0

    downloader = FakeDownloader()

    pp = PostProcessor(downloader=downloader)

    # We assume that utime works here
    pp.try_utime(file.path, file.atime, file.mtime)

    # We disable utime for this specific file
    pp.try_utime = None

    # We try to call try_utime, but we catch the warning message

# Generated at 2022-06-24 14:02:41.516195
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError(1, 2, 3)
    assert error.exit_code == 2
    assert error.stdout == 1
    assert error.stderr == 3

# Generated at 2022-06-24 14:02:47.635226
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestDownloader(object):
        _warning_count = 0
        _warning_message = None

        def __init__(self, params={}):
            self.params = params

        def report_warning(self, message):
            self._warning_count += 1
            self._warning_message = message

        def get_warnings(self):
            return (self._warning_count, self._warning_message)

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self._downloader = downloader

    def _test_try_utime(file_path, message):
        assert isinstance(file_path, str)
        td = TestDownloader()
        pp = TestPostProcessor(td)
        pp.try_utime(file_path, 0, 0)
       

# Generated at 2022-06-24 14:02:57.649462
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    ydl = gen_extractors()
    ydl.add_default_info_extractors()

    class _fakePostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    pp = _fakePostProcessor(ydl)
    pp.run({
        'id': 'testID',
        'url': 'http://example.com/test.mp4',
        'title': 'testTitle',
        'uploader': 'testUploader',
        'uploader_id': 'testUploaderID',
        'uploader_url': 'http://example.com/',
        'extractor_key': 'Generic'
    })

# Generated at 2022-06-24 14:02:59.947086
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    dl = YoutubeDL()
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-24 14:03:00.897100
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:03:04.573143
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError("test")
    assert e.args[0] == "test"
    assert e.cause is None
    e = AudioConversionError("test", cause="cause")
    assert e.args[0] == "test"
    assert e.cause == "cause"

# Generated at 2022-06-24 14:03:06.960299
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('format', 'format')



# Generated at 2022-06-24 14:03:12.701375
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def __init__(self, signal):
            PostProcessor.__init__(self)
            self._signal = signal

        def run(self, information):
            assert information['title'] == 'test'
            self._signal['called'] = True
            return [information['filepath']], information

    signal = {'called': False}
    pp = TestPP(signal)
    pp.run({'title': 'test', 'filepath': 'test.mp3'})
    assert signal['called']

# Generated at 2022-06-24 14:03:15.135513
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    t = PostProcessor()
    return t

# Generated at 2022-06-24 14:03:24.314982
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..downloader.f4m import F4mFD
    from ..utils import (
        DEFAULT_OUTTMPL,
    )

    downloader = FileDownloader(params={'outtmpl': DEFAULT_OUTTMPL})
    downloader.add_progress_hook(lambda d: None)
    f4mfd = F4mFD(downloader, params={})

    from ..extractor.niconico import NiconicoIE
    nicoie = NiconicoIE(downloader=downloader)
    nicoie._real_initialize()

    nicoie.report_download_page('http://www.nicovideo.jp/watch/sm10886469')
    nicoie.ie_key = 'niconico'

# Generated at 2022-06-24 14:03:33.224700
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import pwd
    import shutil
    import os
    curuser = pwd.getpwuid(os.getuid())[0]
    homedir = "/home/%s" % curuser
    tempdir = os.path.join(homedir, "temp")
    if not os.path.isdir(tempdir):
        os.mkdir(tempdir)

    # Change directory to home
    current_dir = os.getcwd()
    os.chdir(homedir)

    # Create temporary file
    fd, name = tempfile.mkstemp(dir=tempdir, prefix="ytdl_", suffix=".tmp")
    f = os.fdopen(fd, "w")
    f.write("")
    f.close()

    # Try to change modification time


# Generated at 2022-06-24 14:03:41.254068
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from subprocess import call
    from tempfile import mkstemp
    from .testcases import unittest
    import time

    class TestPostProcessor(PostProcessor):
        test = None
        method = None
        atime = None
        mtime = None
        fd = None

        def __init__(self, test, method, atime, mtime):
            self.method = method
            self.test = test
            self.atime = atime
            self.mtime = mtime
            self.fd, self.path = mkstemp()

        def run(self, information):
            self.method(self, self.path, self.atime, self.mtime)

# Generated at 2022-06-24 14:03:44.723845
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # subclass constructor should set description, ffmpeg_output and
    # tall_output
    try:
        raise AudioConversionError('descr', 'ffmpeg', 'tool')
    except AudioConversionError as err:
        assert err.description == 'descr'
        assert err.ffmpeg_output == 'ffmpeg'
        assert err.tool_output == 'tool'
    else:
        raise AssertionError('AudioConversionError not raised')



# Generated at 2022-06-24 14:03:48.650701
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """ Test whether set_downloader method of PostProcessor class works correctly """
    try:
        from ..YoutubeDL import YoutubeDL
        downloader = YoutubeDL()
        postprocessor = PostProcessor(downloader)
        postprocessor.set_downloader(downloader)
    except BaseException as e:
        print ('ERROR in test_PostProcessor_set_downloader(%s)' % str(e))
        return False
    return True

# Generated at 2022-06-24 14:03:59.244181
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..utils import prepare_executable
    exec_count = 0
    class MockDownloader(object):
        def __init__(self):
            pass
        def to_screen(self, *args, **kargs):
            pass
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
    class MockInfoExtractor(InfoExtractor):
        _WORKING = True
        _TEST = {
            'url': 'http://testurl.test',
            'info_dict': {
                'id': 'testid',
            },
        }

# Generated at 2022-06-24 14:04:01.990073
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    dl = FileDownloader(None, None)
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-24 14:04:07.947073
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    info_extractor = InfoExtractor()
    ydl = YoutubeDL({'logger': None})
    ydl.add_info_extractor(info_extractor)
    dl = HttpDownloader(ydl)
    pp = FFmpegExtractAudioPP(ydl)
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-24 14:04:13.218924
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    try:
        os.remove('/tmp/test_PostProcessor_try_utime')
    except OSError:
        pass
    open('/tmp/test_PostProcessor_try_utime', 'w').close() # Create file
    calltime = time.time()
    PostProcessor().try_utime('/tmp/test_PostProcessor_try_utime', calltime, calltime)
    os.remove('/tmp/test_PostProcessor_try_utime')



# Generated at 2022-06-24 14:04:16.211039
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p._downloader is None

# Generated at 2022-06-24 14:04:21.412891
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    acs = AudioConversionError('Test message')
    # Check if message is set correctly
    assert acs.message == 'Test message'
    # Check if message is stored during init
    acs = AudioConversionError()
    assert acs.message is None
    acs = AudioConversionError('Test message')
    assert acs.message == 'Test message'

# Generated at 2022-06-24 14:04:30.931310
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Arrange
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..compat import compat_str
    import tempfile

    # Create a temporary file and store its path
    f = tempfile.NamedTemporaryFile(delete=False)
    f.close()

    tfile = f.name
    assert tfile is not None

    # Create an InfoExtractor and download a video to the temporary file
    downloader = Downloader()
    downloader.add_info_extractor(gen_extractors()[0])
    downloader.download(['http://www.youtube.com/watch?v=Bg2cn4nhZv4'])

    # Get the file path

# Generated at 2022-06-24 14:04:31.878281
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:04:40.202395
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import unittest

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    pp = TestPostProcessor()
    assert pp.run('foo') == ([], 'foo')

    class TestPostProcessor2(PostProcessor):
        def run(self, information):
            raise PostProcessingError('test')

    pp = TestPostProcessor2()
    try:
        pp.run('foo')
        assert False
    except PostProcessingError as e:
        assert str(e) == 'test'

# Generated at 2022-06-24 14:04:44.542370
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(AudioConversionError.ENCODE_ERROR, 'blah', 'blah')
    assert err.cause == AudioConversionError.ENCODE_ERROR
    assert err.file == 'blah'
    assert err.msg == 'blah'



# Generated at 2022-06-24 14:04:49.197816
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    youtube_dl = 'test'
    postprocessor = PostProcessor(youtube_dl)
    assert postprocessor._downloader == youtube_dl
    postprocessor = PostProcessor()
    postprocessor.set_downloader(youtube_dl)
    assert postprocessor._downloader == youtube_dl

# Generated at 2022-06-24 14:04:51.813755
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    testPP = PostProcessor()
    downloader = object()
    testPP.set_downloader(downloader)
    assert testPP._downloader == downloader

# Generated at 2022-06-24 14:05:00.704357
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)

    # Create a file
    test_filename = u'elpais.pdf'
    with open(test_filename, 'wb') as f:
        f.write(b'content')

    # Set a timestamp
    test_timestamp = 235
    os.utime(test_filename, (test_timestamp, test_timestamp))

    # Set a new timestamp that should raise an error
    try:
        test_newtimestamp = 666
        pp.try_utime(test_filename, test_newtimestamp, test_newtimestamp, 'utime error')
    except:  # noqa: E722
        pass

    # Check that the timestamp did not change
    old_timestamp = os.stat(test_filename).st_mtime

# Generated at 2022-06-24 14:05:07.511954
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=protected-access
    # Just check for inheritance
    assert issubclass(PostProcessor, object)
    assert PostProcessor._downloader is None
    pp = PostProcessor()
    assert pp._downloader is None
    downloader = object()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader
    assert pp.run({'filepath': '.'}) == ([], {'filepath': '.'})

# Generated at 2022-06-24 14:05:13.356129
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    # Functions are not pickable, and mock is not available in python < 3.3, so
    # use a lambda and "throw" an exception instead
    def throw_exception(*args, **kwargs):
        raise Exception()
    pp._downloader = type('MockDownloader', (), {
        'report_warning': lambda *args: None
    })()
    pp.try_utime('testfilename', throw_exception, throw_exception)
    # No exception should be thrown

# Generated at 2022-06-24 14:05:22.809961
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def download(self, *args, **kwargs):
            path = tempfile.mkstemp()[1]
            open(path, 'w').close()
            return path

    ie = FakeInfoExtractor({}, downloader=None)

    # Create information for testing purposes

# Generated at 2022-06-24 14:05:30.690531
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import unittest
    class PostProcessorTest(PostProcessor):
        def run(self, info):
            if not os.path.exists(encodeFilename(info['filepath'])):
                raise PostProcessingError('400', info['filepath'])
            if not os.path.isfile(encodeFilename(info['filepath'])):
                raise PostProcessingError('401', info['filepath'])
            return [[], info]
    class FakeInfo(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfo, self).__init__(*args, **kwargs)
            self['filepath'] = 'a'

    class FakeDownloader():
        def report_warning(self, a):
            pass
        def to_screen(self, message):
            pass



# Generated at 2022-06-24 14:05:33.122545
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    try:
        pp = PostProcessor()
        pp.run()
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 14:05:36.721289
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class testPostProcessor(PostProcessor):
        def run(self, info):
            return ([], info)

    pp = testPostProcessor()
    pp.set_downloader(object())
    assert pp._downloader


# Generated at 2022-06-24 14:05:46.973022
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .common import FileDownloader

    class TestPP(PostProcessor):
        def __init__(self):
            self.run_count = 0
            self.ppresult_count = 0
            self.initial = {}
            self.final = {}

        def run(self, information):
            self.run_count += 1
            self.initial = information.copy()
            self.ppresult = PostProcessor.run(self, information)
            self.final = information.copy()
            self.ppresult_count += 1
            return self.ppresult

    pp1 = TestPP()
    pp2 = TestPP()
    pp3 = TestPP()


# Generated at 2022-06-24 14:05:50.292971
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Tests PostProcessor.set_downloader method
    """

    # construct object of class PostProcessor
    pp = PostProcessor()

    # test if downloader attribute is set correctly
    pp.set_downloader("downloader1")
    assert pp._downloader == "downloader1"

# Generated at 2022-06-24 14:06:00.953442
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class CC1(PostProcessor):
        def run(self, info):
            info['name'] += '_CC1'
            return [], info

    class CC2(PostProcessor):
        def run(self, info):
            info['name'] += '_CC2'
            return [], info

    class CC3(PostProcessor):
        def run(self, info):
            info['name'] += '_CC3'
            return [], info

    class CC4(PostProcessor):
        def run(self, info):
            info['name'] += '_CC4'
            return [], info
            # CC4 returns None to stop postprocessing chain

    cc1 = CC1()
    cc1.set_downloader(None)

    cc2 = CC2()
    cc2.set_downloader(None)

# Generated at 2022-06-24 14:06:02.832957
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error messgae')
    except Exception as e:
        assert str(e) == 'error messgae'

# Generated at 2022-06-24 14:06:03.714417
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor

# Generated at 2022-06-24 14:06:06.912302
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('error_message')
    assert e.msg == 'error_message'
    assert e.cause is None
    e = AudioConversionError('error_message', 'cause message')
    assert e.msg == 'error_message'
    assert e.cause == 'cause message'



# Generated at 2022-06-24 14:06:17.471439
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .common import PostProcessorTest
    from ..extractor import gen_extractors
    pp = PostProcessorTest()

# Generated at 2022-06-24 14:06:27.143861
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    # create temp file and directory
    with tempfile.NamedTemporaryFile(delete=False) as file:
        tempdir = tempfile.mkdtemp()
        filename = file.name

    # set timestamp for temp file and directory
    old_utime = time.time() - 100
    os.utime(filename, (old_utime, old_utime))
    os.utime(tempdir, (old_utime, old_utime))

    # test for timestamp after conversion
    postprocessor = PostProcessor(None)
    postprocessor.try_utime(filename, old_utime, old_utime)
    postprocessor.try_utime(tempdir, old_utime, old_utime)


# Generated at 2022-06-24 14:06:32.144975
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    def constructor_test():
        raise AudioConversionError('test msg')

    def constructor_test_msg_None():
        raise AudioConversionError()

    try:
        constructor_test()
        assert False, 'Expected error about AudioConversionError with msg'
    except AudioConversionError:
        pass

    try:
        constructor_test_msg_None()
        assert False, 'Expected error about AudioConversionError with msg=None'
    except AudioConversionError:
        pass



# Generated at 2022-06-24 14:06:37.926769
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class test_PostProcessor(PostProcessor):
        def run(self, information):
            return set_downloader_test, information
    set_downloader_test = None
    tpp = test_PostProcessor()
    assert tpp._downloader == None
    trm = lambda *args: None
    tpp.set_downloader('dummy_downloader', trm)
    assert set_downloader_test == 'dummy_downloader'


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:06:41.379289
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'test'

# Generated at 2022-06-24 14:06:51.628237
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import io
    import sys
    import tempfile
    import time
    import unittest
    import shutil
    from ..utils import encodeFilename

    class FakeDownloader():
        def report_warning(self, message):
            return

    downloader = FakeDownloader()

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    f = io.open(encodeFilename(tmp_file.name), 'wb')
    f.close()
    f = io.open(encodeFilename(tmp_file.name), 'rb')
    unix_time = time.mktime(f.get_stat().st_birthtime)
    f.close()

    # Create a temporary PP
    tmp_pp = PostProcessor(downloader)

    # Call the try_

# Generated at 2022-06-24 14:07:02.750678
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import sys
    import os

    from ..compat import compat_open

    # Generate a temporary file, with content
    tmp_dir = tempfile.mkdtemp()
    test_file_name = os.path.join(tmp_dir, "test_utime_file")
    test_file = compat_open(test_file_name, 'wb')
    test_file.write(b'hello')
    test_file.close()

    # Update its modification time
    new_time = time.time()
    os.utime(encodeFilename(test_file_name), (new_time, new_time))

    # Retrieve it
    current_time = os.path.getmtime(test_file_name)

    # Modify it
    test_

# Generated at 2022-06-24 14:07:09.788732
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            return [information['filepath'] + '.new'], information
    p = PostProcessor()
    res = p.run({'filepath': 'video'})
    assert res == ([], {'filepath': 'video'})
    p.add_post_processor(DummyPostProcessor())
    res = p.run({'filepath': 'video'})
    assert res == ([], {'filepath': 'video'})
    p.add_post_processor(DummyPostProcessor())
    res = p.run({'filepath': 'video'})
    assert res == (['video.new'], {'filepath': 'video.new'})

# Generated at 2022-06-24 14:07:14.774209
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Unit test for method run of class PostProcessor."""
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            information['test'] = 42
            return [], information

    information = {'filepath': 'test.mp4'}
    t = TestPostProcessor()
    t.run(information)
    assert information['test'] == 42

# Generated at 2022-06-24 14:07:15.158906
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError()

# Generated at 2022-06-24 14:07:26.029267
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        import time
        import tempfile
    except ImportError:
        return

    p = PostProcessor(None)

    temp_dir = tempfile.gettempdir()
    test_file = os.path.join(temp_dir, 'ytdl_test.tmp')
    tmp_file_fd = open(test_file, 'wb')
    tmp_file_fd.write(b'a')
    tmp_file_fd.close()

    test_file_stat = os.stat(test_file)

    p.try_utime(test_file, test_file_stat.st_atime, test_file_stat.st_mtime + 1000)

    with open(test_file, 'rb') as f:
        assert f.read() == b'a'

    updated_test_file_stat

# Generated at 2022-06-24 14:07:34.791524
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    class TestInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            pass
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            pass
    downloader = FileDownloader()
    dl = TestInfoExtractor()
    pp = TestPostProcessor()
    downloader.add_info_extractor(dl)
    dl.add_post_processor(pp)
    assert pp._downloader == downloader


# Generated at 2022-06-24 14:07:44.857263
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    fd, outname = tempfile.mkstemp(prefix='youtubedl_test_pp_run_')
    os.write(fd, 'asdf')
    os.close(fd)
    info = {
        'filepath': outname,
        'format': '0',
        'ext': '0',
        'format_note': '0',
        'playlist': None,
        'playlist_index': None,
        'playlist_id': None,
        'uploader': '0',
        'uploader_id': '0',
        'uploader_url': '0',
        'channel': '0',
        'channel_id': '0',
        'channel_url': '0',
        'autonumber': 0,
    }
    assert pp

# Generated at 2022-06-24 14:07:48.754628
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    apple = AudioConversionError(250, 'Apple', 424)
    assert apple.code == 250
    assert apple.format == 'Apple'
    assert apple.actual_filesize == 424
    assert str(apple) == 'Apple: ffmpeg encountered the following error while trying to convert the file: code: 250, actual_filesize: 424'

# Generated at 2022-06-24 14:07:50.429105
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader is None



# Generated at 2022-06-24 14:07:51.038531
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-24 14:07:52.039466
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    pp.downloader

# Generated at 2022-06-24 14:08:02.563258
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # stub out os.utime so it fails
    import os
    import sys
    import tempfile
    import shutil
    from .downloader import FakeYDL
    from .extractor.common import InfoExtractor

    os.utime = lambda *ignored: sys.exit(1)

    # make a temporary directory for testing
    tmpdir = tempfile.mkdtemp()
    # create a fake file for testing
    (fd, path_testfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # create a fake downloader
    ie = InfoExtractor()
    ie._ies = [ie]
    ie._downloader = FakeYDL()
    ie._downloader.params = {}

    # run the test
    pp = PostProcessor(ie)

# Generated at 2022-06-24 14:08:03.660020
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:08:09.937422
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Function run of class PostProcessor should return a tuple with list and dict

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    ff = DummyPostProcessor()

    info = {}

    assert isinstance(ff.run(info), tuple)
    assert isinstance(ff.run(info)[0], list)
    assert isinstance(ff.run(info)[1], dict)

# Generated at 2022-06-24 14:08:11.907189
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader import Downloader

    ydl = Downloader()
    pp = PostProcessor(ydl)
    assert ydl == pp._downloader

# Generated at 2022-06-24 14:08:13.511345
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:08:13.911197
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:08:18.254277
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    # Test with valid input
    p1 = PostProcessor(None)
    assert p1.run({'filepath': 'filename', 'title': 'title'}) == ([], {'filepath': 'filename', 'title': 'title'})

    # Test with invalid input
    assert p1.run(None) is None

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-24 14:08:28.543124
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    from ..downloader.f4m import F4mFD
    class DummyFD(F4mFD):
        def __init__(self, ydl):
            F4mFD.__init__(self, ydl)
        def report_error(self, msg):
            return
        def report_warning(self, msg):
            return
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    downloader = FileDownloader(
        HttpFD(
            gen_extractors(),
            {'test_downloader': True, 'test_postprocessor': True}
        )
    )
    dummy_fd = DummyFD(downloader)

# Generated at 2022-06-24 14:08:40.493227
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    sys.path.append('./')
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP, FFmpegEmbedSubtitlePP
    ydl = YoutubeDL()

    # Create post processor objects
    ydl.add_post_processor(FFmpegMergerPP(ydl, {'preferredcodec': 'mp4'}))
    ydl.add_post_processor(FFmpegEmbedSubtitlePP(ydl, {'skip_download': True}))

    # Prepare data to be processed
    info = {}
    info['ext'] = 'flv'
    info['format_id'] = '5'
    info['width'] = 320
    info['height'] = 240
    info['filesize'] = 158492

# Generated at 2022-06-24 14:08:44.259415
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .common import FakePostProcessor
    p = FakePostProcessor()
    # Raise a PostProcessingError exception if try_utime fails
    os.utime = lambda *args, **kargs: None
    filename = 'test_try_utime'
    p.try_utime(filename, 1, 1)

# Generated at 2022-06-24 14:08:45.567407
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'test'
    err = AudioConversionError(msg)
    assert str(err) == msg


# Generated at 2022-06-24 14:08:56.192423
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def _mock_downloader_report_warning(self, warning):
        # capture warning text in a field
        self.warning_text = warning
    # create class where report_warning is a mock
    class MockDownloader:
        # set field where warning text is captured
        warning_text = None
    # create instance of the mock
    downloader = MockDownloader()
    # change class method of mock
    downloader.report_warning = _mock_downloader_report_warning
    # create instance of PostProcessor
    pp = PostProcessor(downloader)
    # create a test file
    with open('try_utime_test_file', 'w'):
        pass
    # run try_utime without error
    pp.try_utime('try_utime_test_file', 0, 0)
    # check

# Generated at 2022-06-24 14:08:58.957985
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    ytdl = object()

    pp = PostProcessor(ytdl)

    assert pp._downloader is ytdl
    assert not pp._configuration_args()

# Generated at 2022-06-24 14:09:03.169435
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader({'nopostoverwrites': True})
    pp = PostProcessor(downloader)
    pp.set_downloader(None)
    downloader.add_post_processor(pp)

# Generated at 2022-06-24 14:09:05.278344
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = object()

    pp = PostProcessor()
    pp.set_downloader(downloader)

    assert pp._downloader is downloader


# Generated at 2022-06-24 14:09:07.680310
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        PostProcessor()
    except:
        raise AssertionError("Unable to instantiate PostProcessor")

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:09.954098
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 2)
    except AudioConversionError as e:
        assert str(e) == 'ffmpeg exited with code 1, command line:\n2'

# Generated at 2022-06-24 14:09:11.257211
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Verify that AudioConversionError can be instantiated with no arguments."""
    AudioConversionError()

# Generated at 2022-06-24 14:09:12.665378
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message')
    except AudioConversionError as err:
        assert str(err) == 'message'



# Generated at 2022-06-24 14:09:16.857217
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl
    ydl.add_post_processor(pp)
    assert ydl._postprocessors[0] == pp


# Generated at 2022-06-24 14:09:25.733844
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class mock_downloader:
        def report_warning(self, errnote):
            print(errnote)

    # Create a mock downloader
    downloader = mock_downloader()

    # Create a test file
    with open('./tmpfile', 'w') as f: f.write('test')

    # Fetch original file time
    before_utime = os.path.getatime('./tmpfile')

    # Get PP object
    pp = PostProcessor(downloader=downloader)
    pp.try_utime('./tmpfile', 1111, 1111)

    # Check if file time has been changed
    after_utime = os.path.getatime('./tmpfile')
    assert(before_utime != after_utime)

    # Check if fail report warning
    pp.try_

# Generated at 2022-06-24 14:09:34.298846
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test method try_utime of PostProcessor
    """
    import unittest

    class MockDownloader():
        def report_warning(self, x):
            pass

    class MyPP(PostProcessor):
        def __init__(self):
            super(MyPP, self).__init__(None)
            self.set_downloader(MockDownloader())

    # Create a file, to check if it is updated
    file_path = "test_PostProcessor_try_utime.txt"
    with open(encodeFilename(file_path), 'w') as f:
        f.write("dummy")
    # Get previous values of mtime, atime
    file_stat = os.stat(file_path)
    old_mtime = file_stat.st_mtime
    old_at

# Generated at 2022-06-24 14:09:39.796432
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors

    PostProcessor.set_downloader(None)
    for ie in gen_extractors():
        if ie.IE_NAME in ie.GENERIC_IE_NAME:
            continue
        for pp in ie.ie.get_postprocessors():
            # print(pp.__module__,pp.__name__)
            assert pp._downloader is None

# Generated at 2022-06-24 14:09:41.955573
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:45.243703
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    post_processor = PostProcessor()
    e = AudioConversionError('foo', post_processor)
    assert e.cause == 'foo'
    assert e.post_processor == post_processor

# Generated at 2022-06-24 14:09:46.016874
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p != None

# Generated at 2022-06-24 14:09:54.089921
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Method run() of class PostProcessor should have following behaviour:
    1. It requres a parameter.
    2. Its returned value should be a tuple.
    3. Its first element of the returned tuple should be a list of files
       that can be deleted.
    4. Its second element of the returned tuple should be an updated
       information.
    5. It could raise PostProcessingError exception if post processing fails.
    """
    test_cases = (
        # TestCase format: (arg, expected_retval)
        # Successful run with a dictionary
        ({'filepath': 'http://example.com'},
         ([], {'filepath': 'http://example.com'}),
         ),
    )
    for case in test_cases:
        pp = PostProcessor('_downloader')
        assert pp.run

# Generated at 2022-06-24 14:09:59.141917
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo.mp3', 'aac', 'mp3', 'aac: error: message')
    except AudioConversionError as err:
        assert err.source_filename == 'foo.mp3'
        assert err.source_ext == 'aac'
        assert err.target_ext == 'mp3'
        assert err.reason == 'aac: error: message'

    # Test that repr works
    repr(err)

# Generated at 2022-06-24 14:10:04.268823
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # test_PostProcessor1:
    # basic test, create class PostProcessor
    # and return it.
    pp = PostProcessor()
    s = type(pp)
    assert (s.__name__ == 'PostProcessor')
    assert (type(pp._downloader) == type(None))



# Generated at 2022-06-24 14:10:05.399436
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:10:07.103743
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import FakeYDL
    post_processor = PostProcessor()
    fake_ydl = FakeYDL()
    post_processor.set_downloader(fake_ydl)
    assert post_processor._downloader == fake_ydl

# Generated at 2022-06-24 14:10:08.128063
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    t = PostProcessor()
    assert t

# Generated at 2022-06-24 14:10:11.932043
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test Message')
    except AudioConversionError as err:
        if str(err) != 'test Message':
            raise Exception('test Message')

# Generated at 2022-06-24 14:10:22.848008
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def run(self, information):
            return [], information

    d = MockDownloader()
    pp = MockPostProcessor(d)
    fn = 'test_PostProcessor_try_utime.file'
    with open(fn, 'w') as f:
        f.write('test')
    os.utime(fn, (3, 4))
    pp.try_utime(fn, 1, 2)
    assert os.stat(fn).st_atime == 1
    assert os.stat(fn).st_mtime == 2
    # make sure warnings do not happen
    pp.try_utime(fn, 1, 2)
    os.remove(fn)


if __name__ == '__main__':
    test_PostProcessor_try_utime

# Generated at 2022-06-24 14:10:24.859979
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:10:26.666236
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(u'error')
    except AudioConversionError:
        pass

# Generated at 2022-06-24 14:10:27.853187
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None


# Generated at 2022-06-24 14:10:32.800477
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from pytube.downloader import FileDownloader
    from pytube.postprocessor import PostProcessor

    # Create a downloader
    downloader = FileDownloader()

    # Create a PostProcessor object
    pp = PostProcessor(downloader)

    # Check if the PostProcessor object has an attribute _downloader
    assert pp._downloader == downloader, 'Failed to create a PostProcessor object!'
