

# Generated at 2022-06-24 14:00:34.202180
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import time
    from . import FakeDownloader

    fd = FakeDownloader({})
    path = os.path.join('does', 'not', 'exist')
    pp = PostProcessor(fd)
    try:
        os.path.exists(path)
    except OSError as e:
        # The file does not exist
        assert not os.path.exists(path)
        # Try to change utime
        pp.try_utime(path, None, None)
        # The above should not raise any exception
        assert True
    else:
        # The file exists
        assert os.path.exists(path)
        # Try to change utime
        pp.try_utime(path, None, None)
        # The above should not raise any exception
        assert True
        # Try

# Generated at 2022-06-24 14:00:38.540963
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 2, 3)
    except AudioConversionError as e:
        assert e.audio_id == 1
        assert e.video_id == 2
        assert e.format == 3
    else:
        assert False, 'Cannot instantiate AudioConversionError'



# Generated at 2022-06-24 14:00:41.078388
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Test')
    except AudioConversionError as e:
        assert str(e) == 'Test'



# Generated at 2022-06-24 14:00:52.945371
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # dummy class for testing purposes
    class DummyDownloader():
        def __init__(self):
            self.params = {'nooverwrites': True, 'retries': 0}

        def to_stdout(self, message):
            return

        def report_warning(self, message):
            print(message)
            return

    # dummy class for testing purposes
    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            self._downloader = downloader

        def run(self, information):
            path = information['filepath']
            atime = information['atime']
            mtime = information['mtime']
            errnote = information['errnote']

            self.try_utime(path, atime, mtime, errnote)

    # create a dummy post-

# Generated at 2022-06-24 14:00:55.947043
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo')
    except AudioConversionError as err:
        assert err.args == ('foo',)
    else:
        assert False, 'BaseException not raised'



# Generated at 2022-06-24 14:01:00.534035
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('what', 'why', 'video_id')
    assert e.what == 'what'
    assert e.why == 'why'
    assert e.video_id == 'video_id'
    assert str(e) == '[what] what'

# Generated at 2022-06-24 14:01:02.836961
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = object()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader

    pp.set_downloader(None)
    assert pp._downloader is None

    pp.set_downloader(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-24 14:01:05.126852
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert err.args == ('test',)



# Generated at 2022-06-24 14:01:09.012984
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import ydl_opts
    from ydl_downloader import YouTubeDownloader

    d = YouTubeDownloader(ydl_opts)

    pp = PostProcessor(d)
    assert pp._downloader is d
    assert pp._configuration_args() is None

    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-24 14:01:10.815188
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert issubclass(PostProcessor, object)

# Generated at 2022-06-24 14:01:17.747793
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def _test_try_utime(monkeypatch, filename, path, atime, mtime, errnote, log_code, expected=None):
        pp = PostProcessor(None)
        pp._downloader = get_test_downloader(path)
        monkeypatch.setattr(pp._downloader, 'report_warning', lambda *args: log_code)
        pp.try_utime(filename, atime, mtime, errnote)
        return log_code

    def dummy_os_utime_raise(filename, times):
        raise OSError

    def dummy_os_utime_success(filename, times):
        pass

    from ..downloader import Downloader


# Generated at 2022-06-24 14:01:21.141294
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('This is just a test', 'test.aac', 'test.mp3')
    except AudioConversionError as err:
        assert 'converting test.aac to test.mp3: This is just a test' == str(err)

# Generated at 2022-06-24 14:01:25.755314
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', 'bar', 'baz')
    except AudioConversionError as err:
        assert err.input_file == 'foo'
        assert err.output_file == 'bar'
        assert err.error_message == 'baz'

# Generated at 2022-06-24 14:01:35.218554
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.downloaded = []

        def run(self, information):
            assert self._downloader is not None
            self.downloaded.append(information['filepath'])
            return [], information

    p1 = DummyPostProcessor()
    assert p1.downloaded == []
    d1 = object()
    p1.set_downloader(d1)
    assert p1._downloader is d1
    p1.run({'filepath': 'a'})
    assert p1.downloaded == ['a']


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:01:36.332031
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:01:38.634558
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error_message = 'Message of error'
    try:
        raise AudioConversionError(error_message)
    except AudioConversionError as e:
        assert e.args[0] == error_message

# Generated at 2022-06-24 14:01:43.315354
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    a = PostProcessor()

    # Test default behavior (keep file and do nothing)
    (deleted_files, info) = a.run({'filepath': 'file.mp3'})
    assert deleted_files == [], 'PostProcessor: unexpected deleted files'
    assert info['filepath'] == 'file.mp3', 'PostProcessor: unexpected filepath'



# Generated at 2022-06-24 14:01:52.779069
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request
    from ..downloader import FakeYDL
    class TestPP(PostProcessor):
        pass

    class TestInfo(dict):
        pass

    ydl = FakeYDL()
    ydl.params = {}
    fd = compat_urllib_request.urlopen(
        'http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 14:01:59.449200
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPP(PostProcessor):
        def run(self, info):
            assert 'filepath' in info
            info['filepath'] += u'.log'
            return ['old.log'], info

    p = MyPP()
    info = {'id': 'test', 'filepath': 'somefile.mp4'}
    files_to_delete, info = p.run(info)
    assert files_to_delete == ['old.log']
    assert info['filepath'] == 'somefile.mp4.log'

# Generated at 2022-06-24 14:02:09.801898
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile

    from ..downloader import Downloader

    test_data_dir = 'test'
    outtmpl = tempfile.mkdtemp(prefix='youtubedl_test_')
    ydl = Downloader(params={'format': '5', 'outtmpl': outtmpl + os.sep + '%(id)s.%(ext)s'})
    ydl.add_post_processor(PostProcessor(ydl))

    info = {
        'id': 'abc',
        'ext': 'flv',
        'title': 'test',
        'url': 'http://localhost/video.flv',
        'thumbnail': 'http://localhost/thumb.jpg',
        'description': 'This is a test',
        'webpage_url': 'http://localhost/page',
    }

# Generated at 2022-06-24 14:02:16.106904
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class MyPostProcessor(PostProcessor):

        def __init__(self):
            def report_warning(self, msg):
                self.msg = msg
        self._downloader = report_warning
        self.msg = None

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote
            super(MyPostProcessor, self).try_utime(path, atime, mtime, errnote)

    mpp = MyPostProcessor(None)

    path = 'path/to/file'
    atime = 1234.0
    mtime = 5678.0


# Generated at 2022-06-24 14:02:24.763955
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime

    # Set up a PostProcessor and mock the report_warning method so it doesn't do anything
    pp = PostProcessor()
    pp.report_warning = lambda *args, **kwargs: None

    # Create a file for testing
    with open('test_PostProcessor_try_utime', 'w') as f:
        f.write('testing')
    # Get the time before trying to change it
    time_before = datetime.datetime.fromtimestamp(os.path.getmtime('test_PostProcessor_try_utime'))
    pp.try_utime('test_PostProcessor_try_utime', 0, 0)  # Change the file modification time to 0
    # If there were no errors, the file modification time should have changed
    time_after = datetime.datetime.fromtim

# Generated at 2022-06-24 14:02:27.294760
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass
    else:
        raise Exception('AudioConversionError constructor does not raise exception')

# Generated at 2022-06-24 14:02:31.038649
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    p = PostProcessor(downloader=YoutubeDL())
    assert p._downloader == YoutubeDL()
    p.set_downloader(None)
    assert p._downloader is None

# Generated at 2022-06-24 14:02:42.491372
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL
    from tempfile import mkstemp
    from time import time
    from .common import FileDownloader
    from .test_postprocessor import PostProcessorTestHelper

    ydl = YoutubeDL({'logger': FileDownloader()})
    pp = PostProcessorTestHelper(ydl)

    # Create a file
    fd, fname = mkstemp(prefix='yl_test_', suffix='.tmp')
    os.close(fd)
    # Set the file creation time
    os.utime(fname, (0, 0))
    # Set the file modification time in the future
    os.utime(fname, (time() + 3600, time() + 3600))

    # Set the modification time in the past
    mtime = time() - 3600

# Generated at 2022-06-24 14:02:46.107287
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class ExamplePostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    pp = ExamplePostProcessor()
    assert pp._downloader is None
    pp.set_downloader('a_downloader')
    assert pp._downloader == 'a_downloader'

# Generated at 2022-06-24 14:02:50.855988
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo.mp3', 'ffmpeg', 'exit 1')
    except AudioConversionError as e:
        assert e.input == 'foo.mp3'
        assert e.output == 'ffmpeg'
        assert e.error == 'exit 1'
    else:
        assert False, 'should raise invalid argument exception'


# Generated at 2022-06-24 14:02:56.651201
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor import info_dict
    post_processor = PostProcessor(downloader=None)
    assert post_processor._downloader == None
    post_processor.set_downloader(downloader=None)
    assert post_processor._downloader == None
    post_processor.run(information=info_dict) == ([], info_dict)

# Generated at 2022-06-24 14:03:00.733993
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Method set_downloader of class PostProcessor sets the downloader for this PP
    # First create a PostProcessor object
    p=PostProcessor()
    # Downloader is default None, assert it
    assert p._downloader is None
    # Assign a downloader
    p.set_downloader('test_downloader')
    # Now check if downloader is no longer None
    assert p._downloader == 'test_downloader'



# Generated at 2022-06-24 14:03:06.553002
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create a PostProcessor
    post_processor = PostProcessor()
    # Check that downloader is None
    assert post_processor._downloader is None
    # Set downloader
    downloader = object()
    post_processor.set_downloader(downloader)
    # Check that downloader is not None
    assert downloader == post_processor._downloader


# Generated at 2022-06-24 14:03:07.569120
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError("error")



# Generated at 2022-06-24 14:03:10.125939
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor(downloader=None)

if __name__ == "__main__":
    test_PostProcessor()

# Generated at 2022-06-24 14:03:20.452857
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..compat import PY2

    downloader = YoutubeDL()
    downloader.params['outtmpl'] = os.path.join(os.path.dirname(__file__), 'test.%(ext)s')

    # Make a test file
    f = open(downloader.params['outtmpl'] % {'ext': 'test'}, 'wb')
    f.write(b'This is a test')
    f.close()

    # PostProcessor for test

# Generated at 2022-06-24 14:03:28.087908
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    sys.path.append("..")

    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            InfoExtractor.__init__(self, downloader)
            self._count = 0

        def _real_extract(self, url):
            self._count += 1
            return [{
                'id': 'test%d' % self._count,
                'upload_date': '20130101',
            }]

    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
            self._count = 0


# Generated at 2022-06-24 14:03:30.162781
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    class DummyDownloader():
        def __init__(self):
            self.pp = pp
    dd = DummyDownloader()
    pp.set_downloader(dd)
    assert pp._downloader is dd

# Generated at 2022-06-24 14:03:35.012433
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Test method set_downloader of class PostProcessor."""
    # Test with a downloader
    downloader = object()
    PP = PostProcessor(downloader)
    assert PP.set_downloader is None
    # Test without a downloader
    PP = PostProcessor()
    PP.set_downloader(downloader)
    assert PP._downloader == downloader

# Generated at 2022-06-24 14:03:38.351175
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from . import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    pp = PostProcessor()
    assert pp._downloader == None
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:03:40.275555
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError(1, 2, 3)
    assert exc.exit_code == 1
    assert exc.audio_format == 2
    assert exc.output_file == 3

# Generated at 2022-06-24 14:03:44.788008
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    pp = PostProcessor()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:03:53.173829
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import platform
    from ..utils import PostProcessor
    
    pp = PostProcessor()
    path = 'test_utime.txt'
    atime_init = time.time()

    f = open(path, 'a')
    f.close()
    if platform.system() == 'Windows':
        # Windows does not support nanoseconds
        atime = atime_init
        mtime = atime_init + 10
        pp.try_utime(path, atime, mtime)
        assert atime == os.path.getatime(path)
        assert mtime == os.path.getmtime(path)
    else:
        # Other systems that support nanoseconds
        atime = atime_init*1000000
        mtime = atime_init*1000000 + 10


# Generated at 2022-06-24 14:03:59.219968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeDownloader
    from ..utils import DateRange
    class FakeInfoDict():
        def __init__(self, upload_date=None, release_date=None):
            self.upload_date = upload_date
            self.release_date = release_date
            self.age_limit = 0
        def get_age_limit(self):
            return self.age_limit
    dl = FakeDownloader()
    pp = PostProcessor(dl)
    # Test that we silently skip date_range test if age_limit is 0

# Generated at 2022-06-24 14:04:00.680447
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('abc')
    assert err.args == ('abc',)



# Generated at 2022-06-24 14:04:05.480449
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', -1, 'bar', 'test_AudioConversionError')
    except AudioConversionError as err:
        assert err.msg == 'foo'
        assert err.code == -1
        assert err.detail == 'bar'
        assert err.pp_name == 'test_AudioConversionError'
    else:
        assert False, 'Expected exception'


# Generated at 2022-06-24 14:04:07.897491
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Error aa', 'Error bb')
    except AudioConversionError as err:
        # Test error message
        assert str(err) == 'ffmpeg reported error:\nError aa\nError bb'

# Generated at 2022-06-24 14:04:15.158416
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Assert that the utime method is up-to-date
    import time
    import os

# Generated at 2022-06-24 14:04:23.670881
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil

    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'test')
    shutil.copyfile(__file__, testfile)

    try:
        # Change file's mtime
        orig_mtime = os.path.getmtime(testfile)
        time.sleep(1)
        PostProcessor(None).try_utime(testfile, None, time.time())
        assert os.path.getmtime(testfile) > orig_mtime
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-24 14:04:25.029037
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:04:32.156711
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    class MockPostProcessor(PostProcessor):
        def run(self, information):
            return YoutubeDL().process_ie_result(information)
    pp = MockPostProcessor()
    assert pp._downloader is None
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader is ydl


# Generated at 2022-06-24 14:04:43.823510
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'ext': 'mkv',
                'title': 'faketitle',
                'thumbnail': 'fakethumbnail',
                'description': 'fakedescription',
            }

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return [], {'id': 'fakeid', 'title': 'newfaketitle'}

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.postprocessors = []

    ie = FakeInfoExtractor()
    pp = Fake

# Generated at 2022-06-24 14:04:44.851323
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError


# Generated at 2022-06-24 14:04:55.886751
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_post_processor(PostProcessor())
    info = {'filepath': 'file.mp4'}
    assert ([], info) == ydl.post_processors[0].run(info)
    ydl.add_post_processor(PostProcessor())
    assert ([], info) == ydl.post_processors[0].run({'filepath': 'file.mp4'})
    assert ([], info) == ydl.post_processors[1].run(info)
    ydl.add_post_processor(PostProcessor())
    assert ([], info) == ydl.post_processors[0].run({'filepath': 'file.mp4'})
    assert ([], info) == ydl.post_processors

# Generated at 2022-06-24 14:04:57.844875
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor import gen_extractor_classes

    for ie in gen_extractor_classes():
        ie(None).add_post_processor(None)

# Generated at 2022-06-24 14:05:08.718896
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Unit test for method run of class PostProcessor
    """
    import sys
    import unittest
    import tempfile
    import shutil
    import os
    from ..downloader.common import FileDownloader

    class MockPostProcessor(PostProcessor):
        """Mock PostProcessor class."""

        def __init__(self, downloader):
            self.has_run = False
            PostProcessor.__init__(self, downloader)

        def run(self, info):
            self.has_run = True
            return []

    class TestPostProcessor(unittest.TestCase):
        """Subclass of unittest.TestCase for testing PostProcessor."""


# Generated at 2022-06-24 14:05:11.066976
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    post = PostProcessor()
    assert post._downloader is None


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:14.592550
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    p = PostProcessor([])
    info = {'filepath': 'foo'}
    (del_files, new_info) = p.run(info)
    assert del_files == []
    assert new_info['filepath'] == 'foo'
    assert not new_info == info

# Generated at 2022-06-24 14:05:24.296968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import datetime
    import tempfile
    import subprocess

    def get_utime(path):
        return int(subprocess.check_output(["stat", "-c", "%Y", path]).strip())

    with tempfile.NamedTemporaryFile() as fp:
        t0 = time.time()
        fp.write(b'foo')
        fp.flush()

        pp = PostProcessor(None)
        pp.try_utime(fp.name, t0, t0)

        assert get_utime(fp.name) == t0

        pp.try_utime(fp.name, t0, t0 + 1)

        assert get_utime(fp.name) == t0 + 1

if __name__ == '__main__':
    test_PostProcessor_try

# Generated at 2022-06-24 14:05:25.673654
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    d = object()
    p.set_downloader(d)
    assert p._downloader is d

# Generated at 2022-06-24 14:05:30.554386
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MyPostProcessor(PostProcessor):
        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            assert self._downloader == downloader

    pp = MyPostProcessor()
    assert pp._downloader is None
    pp.set_downloader('foo')
    assert pp._downloader == 'foo'

# Generated at 2022-06-24 14:05:31.429348
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()

# Generated at 2022-06-24 14:05:42.343184
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    import tempfile
    import shutil

    class MockDownloader(object):
        def to_screen(self, msg):
            print(msg)

        def temp_name(self, *args, **kargs):
            return tempfile.mkstemp()

        def report_warning(self, msg):
            print('WARNING: ' + msg)

        def params(self):
            return {}

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    def download(ies, url):
        dl = MockDownloader()
        for ie in gen_extractors(dl):
            if ie.suitable(url):
                ie.download(url)
                break


# Generated at 2022-06-24 14:05:52.542500
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil
    import time
    # Save old current working directory
    old_cwd = os.getcwd()

    # Create a temporary directory and chdir to it
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

# Generated at 2022-06-24 14:05:55.424805
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl


# Generated at 2022-06-24 14:06:00.179437
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    p = PostProcessor(None)
    (t1, t2) = (1412743773.0, 1412743773.0)
    p.try_utime(__file__, t1, t2)  # It should not throw an exception
    # It should not throw an exception even when the file does not exist
    nonexistent_file = 'nonexistent_file'
    p.try_utime(nonexistent_file, t1, t2)

# Generated at 2022-06-24 14:06:07.268817
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from glob import glob
    from datetime import datetime
    from time import sleep

    # Prepare some file for the unit test
    for f in ('/tmp/test_pp_utime.1', '/tmp/test_pp_utime.2'):
        with open(f, 'w') as fh:
            fh.write('test')

    # Collect their timestamps
    ts_initial = []
    for f in ('/tmp/test_pp_utime.1', '/tmp/test_pp_utime.*'):
        ts_initial.append(datetime.fromtimestamp(os.path.getmtime(f)))

    # Run the unit test
    pp = PostProcessor(None)

# Generated at 2022-06-24 14:06:17.804756
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile

    # Create a temp directory to run test
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a temporary file
        filepath = os.path.join(tmpdir, 'test.txt')
        f = open(filepath, 'w', encoding='utf-8')
        f.write('test')
        f.close()

        # Get atime and mtime of the temporary file before
        atime1 = os.path.getatime(filepath)
        mtime1 = os.path.getmtime(filepath)

        # Run try_utime
        post = PostProcessor()
        post.try_utime(filepath, atime1, mtime1)

        # Get atime and mtime of the temporary file after

# Generated at 2022-06-24 14:06:27.276799
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a PostProcessor
    pp = PostProcessor()
    # Create a file to test
    test_file = './test_file'
    f = open(test_file, 'w')
    f.close()
    # Get atime and mtime for the file
    atime_before_test, mtime_before_test = os.path.getatime(test_file), os.path.getmtime(test_file)
    # Change the atime and mtime of the file with try_utime
    pp.try_utime(test_file, atime_before_test + 604800, mtime_before_test + 604800)
    # Get atime and mtime of the file
    atime_after_test, mtime_after_test = os.path.getatime(test_file),

# Generated at 2022-06-24 14:06:30.192413
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def run(self, path):
            return path
    pp = TestPP()
    assert pp.run("This is test string") == "This is test string"

# Test constructor of class AudioConversionError

# Generated at 2022-06-24 14:06:38.589231
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegExtractAudioPP
    from youtube_dl.downloader import HttpFD

    my_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    # Open an empty temp file
    temp_file_handle, temp_file_name = tempfile.mkstemp(suffix='.flv')
    os.close(temp_file_handle)
    os.remove(temp_file_name)
    assert not os.path.isfile(temp_file_name)

    # Init downloader
    ydl = YoutubeDL({'outtmpl': temp_file_name})
    ydl.add_info_extractor(MyIE(my_url, temp_file_name))

    # Init

# Generated at 2022-06-24 14:06:50.192914
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test PostProcessor method run; uses a dummy PP class."""

    class DummyPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            self.num_run = 0
            self.ran = []
            self.processed = []
            PostProcessor.__init__(self, downloader)

        def run(self, info):
            self.num_run += 1
            self.ran.append(info)
            return self.processed.pop(0)

    pp = DummyPostProcessor()
    pp.processed = [([], {}), ([], {}), ([], {}), ([], {}), ([], {})]

    # Test that a PP is run only as many times as expected
    info0 = {}
    info1 = pp.run(info0)
    assert pp.num

# Generated at 2022-06-24 14:06:52.390013
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    pp.try_utime('abcde', 1234, 1234)

# Generated at 2022-06-24 14:06:54.845633
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError:
        pass



# Generated at 2022-06-24 14:06:58.604843
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], {'a': 'b'}
    information = TestPostProcessor().run({})
    assert information == ({'a': 'b'}, [])

# Generated at 2022-06-24 14:07:06.540098
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Test PostProcessor run.

    It is not possible to run unit-tests without a fully functional
    downloader, because the postprocessor works with the results
    of previous downloader (InfoExtractor) stage.
    But we may test postprocessor alone, without downloader.

    This test set up two postprocessors.
    The first converts file to mp3.
    The second converts mp3 to ogg.
    """
    # set up downloader
    class InfoExtractorDummy(object):
        def __init__(self, downloader):
            self._downloader = downloader

        def extract(self, url):
            return {
                'id': 'test',
                'duration': 42,
                'ext': 'wav',
            }


# Generated at 2022-06-24 14:07:12.483845
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def run(self, information):
            path = information['filepath']
            if os.path.exists(path):
                self.try_utime(path, 1, 2)
                st = os.stat(path)
                return [st.st_atime, st.st_mtime]
            return []

    pp = FakePostProcessor(None)
    pp.run({'filepath': 'test'})

# Generated at 2022-06-24 14:07:14.378291
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError("test_message")
    assert a.msg == "test_message"

# Generated at 2022-06-24 14:07:15.367978
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    PostProcessor(None)

# Generated at 2022-06-24 14:07:17.957814
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test 1 2 3')
    except AudioConversionError as err:
        assert str(err) == 'test 1 2 3'



# Generated at 2022-06-24 14:07:29.323261
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile

    testfile = tempfile.NamedTemporaryFile(delete=False)
    filename = testfile.name
    testfile.close()

    # To not mess with the time of the real file, we'll use a fake
    # "time.time" function
    import time
    time_counter = [1330953172.1175]  # Fri Feb 17 15:39:32 CET 2012
    def time_time():
        time_counter[0] += 1.0
        return time_counter[0]

    time_orig = time.time
    time.time = time_time

    pp = PostProcessor(None)
    pp.try_utime(filename, 1234, 5678)

    # Restore "time.time" function
    time.time = time_orig

    stat = os.stat(filename)


# Generated at 2022-06-24 14:07:30.912008
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert str(AudioConversionError('test')) == 'test'



# Generated at 2022-06-24 14:07:40.152779
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import io
    import sys
    class File(object):
        def __init__(self, name):
            self._name = name
        def __enter__(self):
            self._io = open(self._name, 'w')
            return self._io
        def __exit__(self, *args):
            self._io.close()
    class Wrapper(object):
        def __init__(self):
            self._chain = []
        def add_post_processor(self, *args, **kwargs):
            self._chain.append(args)
        def process_info(self, *args, **kwargs):
            self._info = args
            self._kwargs = kwargs
        def to_screen(self, *args, **kwargs):
            self._screen = args

# Generated at 2022-06-24 14:07:41.114498
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor()



# Generated at 2022-06-24 14:07:43.510268
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run({}) == ([], {})


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:53.767155
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from ..utils import DateRange

    from .subtitles import SubtitlesProcessor
    from .xattrpp import XAttrMetadataPP
    from .ffmpegmeta import FFmpegMetadataPP

    class DumbPP(PostProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0, errnote='run')
            return [], info

    class DumbSPP(SubtitlesProcessor):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0, errnote='run')
            return info

    class DumbXMPP(XAttrMetadataPP):
        def run(self, info):
            self.try_utime(info['filepath'], 0, 0, errnote='run')

# Generated at 2022-06-24 14:08:04.661191
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class myPostProcessor(PostProcessor):
        def run(self,info):
            pass
    from ..downloader import FileDownloader
    import tempfile
    pp = myPostProcessor(downloader = FileDownloader())
    pp.set_downloader(FileDownloader())
    (fd, fname) = tempfile.mkstemp()
    os.utime(fname, (0, 0))
    pp.try_utime(fname, 100, 200)
    assert os.stat(fname).st_atime == 100
    assert os.stat(fname).st_mtime == 200
    os.close(fd)
    os.remove(fname)
    import time
    import shutil
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)
    shut

# Generated at 2022-06-24 14:08:08.997603
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message', 'output', 'error')
    except AudioConversionError as err:
        assert str(err) == 'message\n\noutput\n\nerror'
        assert err.output == 'output'
        assert err.error == 'error'

# Generated at 2022-06-24 14:08:13.056574
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor(None)
    assert None == pp._downloader
    d = object()
    pp.set_downloader(d)
    assert d == pp._downloader


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:08:17.801843
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    def t_run(self, information):
        return ['a', 'b', 'c'], information

    PP = PostProcessor()
    PP.run = t_run.__get__(PP, PostProcessor)
    assert PP.run({'a': 'b', 'filepath': '/aa/bb.cc'}) == (['a', 'b', 'c'], {'a': 'b', 'filepath': '/aa/bb.cc'})

# Generated at 2022-06-24 14:08:28.081246
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    import shutil
    # create a PostProcessor object
    pp = PostProcessor()
    # create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # create a temporary file
    fd, temp_file_path = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)
    # create a dummy file
    dummy_file_path = os.path.join(temp_dir, 'dummy file')
    open(dummy_file_path, 'w').close()
    # try to update utime of temp_file and check if it has been updated
    pp.try_utime(temp_file_path, 1, 2)

# Generated at 2022-06-24 14:08:33.156973
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Subclass it just to be sure there are no unwanted side effects
    class TestPostProcessor(PostProcessor):
        pass
    pp = TestPostProcessor()
    assert pp._downloader is None
    downloader = object()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-24 14:08:37.158948
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    assert pp._downloader == None
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:08:39.517467
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('error message', 42)
    assert 'error message' in str(err)
    assert 42 == err.exit_code

# Generated at 2022-06-24 14:08:42.078974
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    if str(AudioConversionError(99, "Test")) == "Test (exit code: 99)":
        print("ok")
    else:
        print("fail")


# Generated at 2022-06-24 14:08:48.047822
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def try_utime(self, path, atime, mtime, errnote):
        return (path, atime, mtime, errnote)

    pp = PostProcessor(None)
    pp.try_utime = try_utime

    path = 'foo/bar'
    atime = 42
    mtime = 43

    assert pp.try_utime(path, atime, mtime) == (path, atime, mtime, 'Cannot update utime of file')
    assert pp.try_utime(path, atime, mtime, 'Foo') == (path, atime, mtime, 'Foo')



# Generated at 2022-06-24 14:08:57.743115
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    class Test(PostProcessor):
        def run(self, information):
            return [],information
    process = Test()
    def test_func(d):
        assert isinstance(d,FileDownloader)
        assert d.params['outtmpl'] == '%(id)s_%(ext)s'
        return {}
    downloader = FileDownloader({'outtmpl':'%(id)s_%(ext)s'},None,test_func)
    downloader.add_post_processor(process)
    downloader.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:09:02.213875
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    class DummyPP(PostProcessor):
        def run(self, info): pass

    ydl = YoutubeDL()
    dpp = DummyPP()
    dpp.set_downloader(ydl)
    assert dpp._downloader == ydl


# Generated at 2022-06-24 14:09:02.965914
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass # nothing to test

# Generated at 2022-06-24 14:09:03.536602
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-24 14:09:06.899908
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # pylint: disable=too-few-public-methods
    class PostProcessorTest(PostProcessor):
        pass
    # pylint: enable=too-few-public-methods
    PP = PostProcessorTest()
    PP.try_utime('', 0, 0, 'Test')

# Generated at 2022-06-24 14:09:13.756944
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader.common import FileDownloader
    from ..extractor import gen_extractors
    # Preparation
    # Create a FileDownloader object
    downloader = FileDownloader({})
    # Create a PostProcessor object
    pp = PostProcessor(downloader)
    # Create an InfoExtractor object
    ie = gen_extractors()['youtube']()
    # Create a fake 'fatal' error
    fake_fatal = lambda: 1/0
    ie._downloader.report_warning = fake_fatal
    # Create a fake 'non fatal' error
    fake_nonfatal = lambda: None
    ie._downloader.trouble = fake_nonfatal

    # Now, if we run pp.run, it should return ([], None), since
    # we haven't set up a file for it to

# Generated at 2022-06-24 14:09:21.661629
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import io
    import tempfile
    import time
    import unittest

    class MockDownloader(object):
        def report_warning(self, note):
            pass

    def _write_content(content):
        f = tempfile.NamedTemporaryFile(delete=False)
        f.write(content.encode('utf-8'))
        f.close()
        return f.name

    # Create a test file with utime of time.gmtime(0)
    path1 = _write_content('test file 1')
    os.utime(encodeFilename(path1), (0, 0))

    # Create a test file with utime of now
    path2 = _write_content('test file 2')
    os.utime(encodeFilename(path2), (time.time(), time.time()))

   

# Generated at 2022-06-24 14:09:23.948982
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:09:24.939040
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:09:26.872635
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    foo = AudioConversionError('test')
    assert foo.args[0] == 'test'

# Generated at 2022-06-24 14:09:30.145284
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = DummyYDL()
    p = PostProcessor(downloader)
    p.set_downloader(downloader)
    assert isinstance(p, PostProcessor)
    assert p._downloader is downloader


# Dummy class for testing PostProcessor

# Generated at 2022-06-24 14:09:36.539964
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create test post-processor
    pp = PostProcessor()

    # Create test downloader
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()

    # Test set_downloader
    pp.set_downloader(ydl)
    assert pp._downloader == ydl, 'set_downloader() does not set _downloader'


# Generated at 2022-06-24 14:09:45.191890
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test if PostProcessor.run rejects and accepts"""
    class MyPP(PostProcessor):
        def run(self, info):
            if info and info.get("format") == "reject":
                raise PostProcessingError("reject")
            return [], info
    pp = MyPP()
    assert None == pp.run(None)
    assert None == pp.run(1)
    assert None == pp.run({"format": 1})
    assert None == pp.run({"format": "ok"})
    try:
        pp.run({"format": "reject"})
    except PostProcessingError:
        pass
    else:
        assert False


# Generated at 2022-06-24 14:09:53.597805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)

    # test for exception when utime not supported
    try:
        tmp_fname = 'test_PostProcessor_try_utime.txt'
        open(tmp_fname, 'w').close()
        os.utime = lambda path, times: None
        pp.try_utime(tmp_fname, 1, 2)
        raise AssertionError()
    except:
        pass
    finally:
        try:
            os.remove(tmp_fname)
        except:
            pass
    os.utime = lambda path, times: None

    # test for success when utime is supported

# Generated at 2022-06-24 14:09:56.751052
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..test import get_test_data_path

    testfile = os.path.join(get_test_data_path(), 'random_file')
    open(testfile, 'w').close()

    pp = PostProcessor()
    pp.try_utime(testfile, None, None)

    os.remove(testfile)

# Generated at 2022-06-24 14:09:59.083695
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError as err:
        print(err)

# Generated at 2022-06-24 14:10:10.048170
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import time
    import sys

    path = os.path.join(tempfile.gettempdir(), 'test_try_utime')
    f = open(path, 'wb')
    f.write('test')
    f.close()

    try:
        pp = PostProcessor(None)
        pp.try_utime(path, 1, 2)
    except Exception:
        e = sys.exc_info()[1]
        print('Failed to update utime of file: ' + str(e))
        return

    if not os.path.exists(path):
        print('No file after update utime of file')
        return

    stat = os.stat(path)
    atime = stat.st_atime
    mtime = stat.st_mtime
    now

# Generated at 2022-06-24 14:10:18.558737
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        _counter = 1

        def run(self, information):
            information['title'] = 'Post-processed'
            if self._counter == 1:
                self._counter += 1
                return [], information
            elif self._counter == 2:
                self._counter += 1
                return ['dummy'], information
            else:  # self._counter == 3
                return [], None
    from ..downloader import Downloader
    dl = Downloader()
    pp = TestPostProcessor(dl)

# Generated at 2022-06-24 14:10:29.711918
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..postprocessor import FFmpegPostProcessor, FFmpegMetadataPP
    from ..compat import compat_urllib_request
    from ..utils import format_bytes

    # Create a temporary file to store the downloaded video
    tmpfilename = 'test.m4a'

    def _progress_hook(x):
        print('Downloaded %s bytes' % format_bytes(x.downloaded_bytes))

    class MyDownloader(Downloader):
        def to_screen(self, s, skip_eol=False):
            pass

        def to_stdout(self, s, skip_eol=False):
            pass

        def to_stderr(self, s):
            pass
