

# Generated at 2022-06-24 14:00:27.213959
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.f4m import F4mFD
    p = PostProcessor()
    d = F4mFD(None, {'outtmpl': '-'})
    p.set_downloader(d)
    assert p._downloader == d

# Generated at 2022-06-24 14:00:33.102134
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    import youtube_dl

    out = StringIO()
    post = youtube_dl.postprocessor.FFmpegExtractAudioPP(ydl=youtube_dl.YoutubeDL({'logger': youtube_dl.logger.Logger(out, True)}))
    assert post._downloader is None
    ydl = youtube_dl.YoutubeDL({'outtmpl': '%(id)s'})
    post.set_downloader(ydl)
    assert post._downloader == ydl

# Generated at 2022-06-24 14:00:43.717571
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..utils import PostProcessor

    global postproc1_state, postproc2_state, postproc3_state
    postproc1_state = postproc2_state = postproc3_state = None

    class P1(PostProcessor):
        def run(self, information):
            global postproc1_state
            postproc1_state = information
            return None, information

    class P2(PostProcessor):
        def run(self, information):
            global postproc2_state
            postproc2_state = information
            return None, information

    class P3(PostProcessor):
        def run(self, information):
            global postproc3_state
            postproc3_state = information
            return None, information

    chain = [P1(), P2(), P3()]


# Generated at 2022-06-24 14:00:46.971012
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('foo', 'bar', 'baz')
    assert err.msg == 'foo'
    assert err.original_error == 'baz'
    assert err.audio_codec == 'bar'

# Generated at 2022-06-24 14:00:58.774637
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime as dt
    import shutil
    import tempfile
    import time
    import unittest

    from ..utils import (
        DateRange,
        DateRangeError,
        encodeFilename,
    )

    class TestDateRange(DateRange):
        def __init__(self, str_dates):
            super(TestDateRange, self).__init__(str_dates)

        def __eq__(self, other):
            return (
                isinstance(other, TestDateRange) and
                set(self._list_dates) == set(other._list_dates)
            )

        def _parse_date(self, date):
            if date is None:
                return None
            elif date.lower() == 'now':
                return dt.datetime.now()

# Generated at 2022-06-24 14:01:00.143977
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('a', 'b', 'c')

# Generated at 2022-06-24 14:01:02.061341
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    str(AudioConversionError('message', 'cmd', 'output', 'error'))



# Generated at 2022-06-24 14:01:06.374248
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo', 4, 'file1.mp3', 'file2.ogg')
    except AudioConversionError as err:
        assert str(err) == 'foo', 'AudioConversionError not properly initialized'

# Generated at 2022-06-24 14:01:09.754151
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Raise an error if run is called without arguments.
    pp = PostProcessor()

    try:
        pp.run()
    except TypeError:
        pass
    else:
        assert False, 'PostProcessor.run() should raise TypeError if not given any arguments'

# Generated at 2022-06-24 14:01:11.178457
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test method run().
       TODO
    """
    pass


# Generated at 2022-06-24 14:01:17.993544
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import os
    import atexit
    import shutil

    import pytest
    from .test_app import FakeYDL


    @atexit.register
    def clean_tmpdir():
        shutil.rmtree(temp_dir)

    @pytest.fixture(autouse=True)
    def inject_fixtures(do_run):
        self = do_run.obj
        self._errnote = 'Cannot update utime of file'
        self.postprocessor = PostProcessor(FakeYDL())
        self.postprocessor._downloader.report_warning = lambda x: sys.stderr.write(x + '\n')
        self.postprocessor.set_downloader(FakeYDL())


# Generated at 2022-06-24 14:01:22.364584
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPostProcessor(PostProcessor):
        def run(self, information):
            information['title'] = 'abc'
            return [], information

    pp = MyPostProcessor()
    assert pp.run({'title': 'def'}) == ([], {'title': 'abc'})
    assert pp.run({}) == ([], {'title': 'abc'})

# Generated at 2022-06-24 14:01:26.871993
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('ERROR', 'ffmpeg', 'reason')
    except AudioConversionError as ae:
        assert ae.error == 'ERROR'
        assert ae.program == 'ffmpeg'
        assert ae.reason == 'reason'



# Generated at 2022-06-24 14:01:31.393062
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader()
    postprocessor = PostProcessor(downloader)
    postprocessor.set_downloader(None)
    assert postprocessor._downloader is None
    postprocessor.set_downloader(downloader)
    assert postprocessor._downloader is downloader

# Generated at 2022-06-24 14:01:40.980078
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_HTTPError

    class TestProcessor1(PostProcessor):
        def run(self, info):
            assert info['title'] == 'test'
            assert info['ext'] == 'mp4'
            return ['1'], {}

    class TestProcessor2(PostProcessor):
        def run(self, info):
            assert info['title'] == 'test'
            assert info['ext'] == 'mp4'
            return ['2'], {}

    class TestProcessor3(PostProcessor):
        def run(self, info):
            assert info['title'] == 'test'
            assert info['ext'] == 'mp4'
            return [], {
                'title': 'test_new',
                'ext': 'mp4',
                'format': 'not a format',
            }


# Generated at 2022-06-24 14:01:42.594410
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.set_downloader(None) is None
    assert pp.run('information') == ([], 'information')

# Generated at 2022-06-24 14:01:44.938580
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(3, 'AudioConversionError')
    except AudioConversionError as e:
        assert e.errorcode == 3



# Generated at 2022-06-24 14:01:53.494276
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    downloader = FileDownloader(params={})
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    pp.set_downloader(None)
    assert pp._downloader is None
    pp.set_downloader(downloader)
    assert pp._downloader == downloader
    downloader.add_info_extractor(YoutubeIE())
    output_template = '%(id)s.%(ext)s'
    downloader.download(['http://www.youtube.com/watch?v=BaW_jenozKc'], output_template)

# Generated at 2022-06-24 14:01:55.556884
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    return pp

# Generated at 2022-06-24 14:02:02.267335
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .youtube_dl import downloader
    from .infoextractors import gen_extractors
    from .extractor import Gen_Extractor

    ydl = downloader.YoutubeDL({'outtmpl': '%(id)s.%(ext)s',
                                'format': 'bestaudio',
                                'postprocessors': ['FFmpegExtractAudio']})
    ydl.add_info_extractor(gen_extractors(ydl).next())
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

    assert os.path.exists('BaW_jenozKc.m4a')

    os.unlink('BaW_jenozKc.m4a')

# Generated at 2022-06-24 14:02:06.394378
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        os.utime(__file__, None)
    except TypeError:  # older Python versions raise this exception
        pass
    else:
        raise AssertionError('Allowed updating utime of unchangeable file')

# Generated at 2022-06-24 14:02:12.929402
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('message', 'out_file')
    assert err.out_file == 'out_file'
    assert err.msg == 'message'
    assert err.exc_info == None

    err = AudioConversionError('message', 'out_file', (Exception, Exception("error"), None))
    assert err.out_file == 'out_file'
    assert err.msg == 'message'
    assert err.exc_info == (Exception, Exception("error"), None)

    try:
        raise err
    except AudioConversionError as raised_err:
        assert raised_err.msg == err.msg
        assert raised_err.out_file == err.out_file
        assert raised_err.args == err.args

# Generated at 2022-06-24 14:02:18.715390
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        pass

    class MockYDL(object):
        def __init__(self, info):
            self.info = info
            self.postproc = []

        def add_post_processor(self, pp):
            self.postproc.append(pp)

    ydl = MockYDL({
        'id': 'foo',
        'upload_date': 'bar',
        'url': 'http://youtube.com',
        'thumbnail': 'http://thumbnail.com',
        'ext': 'mp3',
        'title': 'foo'
    })
    pp = MockPP(ydl)
    ydl.add_post_processor(pp)

    class MockFD(object):
        def __init__(self, path):
            self.path = path

# Generated at 2022-06-24 14:02:23.606819
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create a class
    class Cls(PostProcessor):
        pass

    # Create an instance
    instance = Cls()

    # Call the set_downloader method
    instance.set_downloader(True)

    # Check the downloader was set
    assert instance._downloader is True

    # Call the set_downloader method again
    instance.set_downloader(False)

    # Check the downloader was updated
    assert instance._downloader is False

# Generated at 2022-06-24 14:02:29.312902
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_error
    class MockDownloader():
        """Mock class for testing."""
        params = {'test': 'test'}
        def report_warning(self, msg):
            """Mock method for testing."""
            pass
    class MockPostProcessor(PostProcessor):
        """Mock class for testing."""
        def __init__(self, downloader=None):
            self._downloader = downloader
        def run(self, information):
            """Mock method for testing."""
            self.information = information
            return ['file.txt']
    downloader = MockDownloader()
    postprocessor = MockPostProcessor(downloader)
    print(downloader.params)

# Generated at 2022-06-24 14:02:29.980938
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:02:32.948988
# Unit test for method run of class PostProcessor

# Generated at 2022-06-24 14:02:33.990149
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PostProcessor(object())



# Generated at 2022-06-24 14:02:34.742884
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    assert True

# Generated at 2022-06-24 14:02:39.101467
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    # Check if the downloader is not set
    assert pp._downloader == None
    # Set the downloader
    pp.set_downloader(object())
    # Check if the downloader is now set
    assert pp._downloader != None

# Generated at 2022-06-24 14:02:43.456197
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL

    ie = InfoExtractor()
    ie.set_downloader(FakeYDL())
    assert ie._downloader is not None


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:02:47.016377
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = 'Audio Conversion Error'
    try:
        raise AudioConversionError(msg)
    except AudioConversionError as e:
        assert e.args[0] == msg

# Generated at 2022-06-24 14:02:47.585791
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    pass



# Generated at 2022-06-24 14:02:58.658442
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import time
    import os
    from tempfile import mkstemp

    # The purpose of the test is to verify the behavior of the try_utime
    # method of the PostProcessor class. This method calls the utime function
    # of the OS. Since it is difficult to simulate an OS that does not support
    # the utime method, we will create a file for which it is impossible to
    # modify the access and modification times.
    # Note that the called utime method does not cause an exception on Windows.
    fd, fp = mkstemp()
    os.close(fd)
    p = PostProcessor('test_downloader')

    # Get the current access and modification time.
    current_atime = datetime.datetime.fromtimestamp(os.path.getatime(fp))
    current_

# Generated at 2022-06-24 14:03:09.753299
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    from ..YoutubeDL import YoutubeDL
    from .thumbnail import ThumbnailPP
    from .concat import ConcatPP
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .execafterdownload import FFmpegFixupM3u8PP
    from .metadatafromtitle import MetadataFromTitlePP
    from .execafterdownload import EmbedSubtitlePP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .xattrpp import XAttrSubtitlePP
    from .embedthumbnail import EmbedThumbnailPP

    class MyYDL(YoutubeDL):
        def process_info(self, ie_info):
            return ie_info

    ydl = MyYDL()
    ydl.params['writesubtitles'] = True
    ydl

# Generated at 2022-06-24 14:03:11.086460
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    a = PostProcessor()
    assert a is not None



# Generated at 2022-06-24 14:03:16.759587
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    x = AudioConversionError(1, 2, 3)
    assert x.exit_code == 1
    assert x.audio_codec == 2
    assert x.video_codec == 3
    x.exit_code = 4
    x.audio_codec = 5
    x.video_codec = 6
    assert x.exit_code == 4
    assert x.audio_codec == 5
    assert x.video_codec == 6


# Generated at 2022-06-24 14:03:20.829751
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Checks that try_utime accepts unicode strings
    pp = PostProcessor()
    pp._downloader = MockDownloader()
    pp.try_utime(u'foo\u2603.bar', 1, 2)
    assert pp._downloader.notified == ['Cannot update utime of file']


# Generated at 2022-06-24 14:03:28.291481
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    class DummyPostProcessor(PostProcessor):

        def test_try_utime_success(self, temporary_directory, initial_path, existing_file, existing_file_mtime):
            self.try_utime(existing_file, 42, 42)
            assert os.path.getmtime(existing_file) == 42

        def test_try_utime_failure(self, temporary_directory, initial_path, existing_file, existing_file_mtime):
            self.try_utime(existing_file, 42, 42, errnote='error_note')
            assert os.path.getmtime(existing_file) == existing_file_mtime


# Generated at 2022-06-24 14:03:34.215030
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.called = False

        def run(self, information):
            self.called = True
            assert information == {'filepath': 'filepath'}
            return ['to_delete'], information

    pp1 = MockPostProcessor()
    pp2 = MockPostProcessor()

    info1 = {'filepath': 'filepath'}
    info2, to_del = pp1.run(info1)
    assert info2 == info1
    assert to_del == ['to_delete']
    assert pp1.called
    assert not pp2.called

    pp1.called = False
    info2, to_del = pp2.run(info2)
    assert info2 == info

# Generated at 2022-06-24 14:03:36.828523
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(u'This is a test error')
    assert isinstance(err, PostProcessingError)
    assert unicode(err) == u'This is a test error'
    return True


# Generated at 2022-06-24 14:03:42.861675
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """ Test constructor of class PostProcessor """
    # Create a PostProcessor object
    pp = PostProcessor()
    # Test exception cases
    try:
        # Run method without arguments, this must raise an exception
        pp.run()
    except PostProcessingError:
        pass
    except AttributeError:
        pass
    else:
        raise Exception('run() without arguments must raise an exception')
    # Test normal case
    # Create a dictionary that simulates the ones created inside
    # class InfoExtractor
    information = {'filepath': 'test', 'format': 'test', 'title': 'test', 'ext': 'test'}
    # Run method with an argument, this must not raise an exception
    pp.run(information)

# Generated at 2022-06-24 14:03:44.810752
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    p = PostProcessor()
    dl = YoutubeDL()
    p.set_downloader(dl)
    assert p._downloader is dl



# Generated at 2022-06-24 14:03:51.756679
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Unit test of method run of class PostProcessor.
    """
    class ModifyingPostProcessor(PostProcessor):
        def run(self, information):
            information['new_field'] = 'new_value'
            return [], information

    information = {
        'filename': 'some_video',
        'ext': 'mkv',
        'format': 'best',
        'title': 'test title',
        'alt_title': 'alt test title'
    }

    postprocessor = ModifyingPostProcessor()
    to_delete, information = postprocessor.run(information)

    assert information['new_field'] == 'new_value'
    assert to_delete == []

# Generated at 2022-06-24 14:03:53.639205
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    message = "Post processing failed"
    cause = Exception("Unknown Error")
    AudioConversionError(message, cause)

# Generated at 2022-06-24 14:04:00.742188
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PP(PostProcessor):
        def run(self, info):
            assert info['filepath'] == 'abc'
            return [], {'key': 'value'}
    pp = PP()
    (deleted, info) = pp.run({'filepath': 'abc'})
    assert deleted == []
    assert info == {'key': 'value'}
    (deleted, info) = pp.run(info)
    assert deleted == []
    assert info == {'key': 'value'}



# Generated at 2022-06-24 14:04:07.795805
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    pp = PostProcessor(downloader=dl)
    # Test for setting error message with utime error
    pp.try_utime(None, None, None)
    assert dl.has_warned('Cannot update utime of file')
    dl = YoutubeDL({})
    pp = PostProcessor(downloader=dl)
    # Test for setting custom error message with utime error
    pp.try_utime(None, None, None, 'Custom error message')
    assert dl.has_warned('Custom error message')

# Generated at 2022-06-24 14:04:12.525948
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader=None, foo=None):
            super(self.__class__, self).__init__(downloader)
            self.foo = foo

        def run(self, information):
            assert self.foo == 'bar'
            return [], information

    dl = FakeYDL()
    pp = DummyPostProcessor(downloader=dl, foo='bar')
    pp.run(None)

# Generated at 2022-06-24 14:04:24.541788
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    A unit test for try_utime method of class PostProcessor.
    """
    from ..compat import WIN_OS, compat_os_name

    # Get a PostProcessor instance
    postprocessor = PostProcessor()

    # Create a file
    tmp_file = open('tmp_file', 'w')
    tmp_file.close()

    # Get the utime of the created file
    utime_tuple = os.stat('tmp_file').st_atime_ns, os.stat('tmp_file').st_mtime_ns

    # Change the utime of the created file
    atime, mtime = utime_tuple[0] + 100, utime_tuple[1] + 100
    postprocessor.try_utime('tmp_file', atime, mtime)

    # Get the ut

# Generated at 2022-06-24 14:04:29.077701
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('file.txt', 'reason')
    except AudioConversionError as err:
        assert err.convertedfile == 'file.txt'
        assert str(err) == 'reason'
        # Test that we can access the original exception instance
        assert err.cause.args[0] == 'reason'
    else:
        assert False, 'Expected exception'

# Generated at 2022-06-24 14:04:37.515020
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Use a custom class for testing
    class FakePP(PostProcessor):
        def run(self, data):
            assert isinstance(data, dict)
            assert 'filepath' in data
            data.update({'foo': 'bar'})
            return [], data

    # Create a downloader and put a FakePP into the chain
    downloader = object()
    pp = FakePP(downloader)
    pp.set_downloader(downloader)

    # Run the PP
    info = pp.run({'filepath': 'bla'})
    assert info['foo'] == 'bar'

# Generated at 2022-06-24 14:04:38.545155
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    obj = AudioConversionError()

# Generated at 2022-06-24 14:04:45.908928
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            info['title'] = 'PostProcessor title'
            return ['deletefile1', 'deletefile2'], info
    pp = TestPostProcessor()
    info = {'ext': 'mp3'}
    deleted_files, info = pp.run(info)
    assert info == {'ext': 'mp3', 'title': 'PostProcessor title'}
    assert deleted_files == ['deletefile1', 'deletefile2']

# Generated at 2022-06-24 14:04:50.068797
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:04:59.447873
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import FakeDownloader
    from .common import PostProcessorTest

    class DummyPP(PostProcessor):
        def run(self, information):
            return [(information['filepath'], 'output.mp3')], information

    ydl = FakeDownloader(
        params={'postprocessors': [
            {
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            },
            {
                'key': 'DummyPP',
            }
        ]}
    )


# Generated at 2022-06-24 14:05:03.183821
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    downloader = object()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader
    pp = PostProcessor()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:05:05.021942
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass



# Generated at 2022-06-24 14:05:10.761260
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        pass
    tp = TestPostProcessor()
    assert tp._downloader is None

    class TestDownloader(object):
        pass

    td = TestDownloader()
    tp.set_downloader(td)
    assert tp._downloader == td


# Generated at 2022-06-24 14:05:20.332851
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractor
    from ..downloader import gen_downloader

    # We should not manage more than one downloader of a IPP at the same time
    ipp = PostProcessor()
    downloader1 = gen_downloader()
    ipp.set_downloader(downloader1)
    downloader2 = gen_downloader()
    try:
        ipp.set_downloader(downloader2)
    except Exception as e:
        assert isinstance(e, AssertionError), '"set_downloader" does not throw AssertionError'

    # Check the downloader of the IPP
    assert downloader1 is ipp._downloader, 'The downloader of the IPP is not the first installed'

    # Check the "postprocessor" field of the downloader
    assert downloader1.post

# Generated at 2022-06-24 14:05:26.260316
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return ['%s.delete' % info['filepath']], info
    test_pp = TestPP()
    info = {
        'filepath': 'testfile',
        'format': 'testformat',
    }
    files_to_delete, new_info = test_pp.run(info)
    assert files_to_delete == ['%s.delete' % info['filepath']]
    assert new_info == info



# Generated at 2022-06-24 14:05:28.478774
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class
    """
    pp = PostProcessor(None)
    pp.run(None)

# Generated at 2022-06-24 14:05:29.391620
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    raise NotImplementedError

# Generated at 2022-06-24 14:05:33.569674
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Test the PostProcessor class."""
    from ..YoutubeDL import YoutubeDL

    p = PostProcessor(None)
    assert p._downloader is None
    ydl = YoutubeDL()
    p.set_downloader(ydl)
    assert p._downloader == ydl

# Generated at 2022-06-24 14:05:38.977311
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Tests the constructor of class PostProcessor."""
    pp = PostProcessor()
    pp = PostProcessor(downloader="dummy")
    assert pp.downloader == "dummy"
    pp = PostProcessor(downloader=None)
    assert pp.downloader is None


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:40.782765
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('Upload failed').message == 'Upload failed'

# Generated at 2022-06-24 14:05:49.668271
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            print('DummyPostProcessor called with %s' % info)
            return [], info

    d = tempfile.NamedTemporaryFile(delete=False)
    d.close()
    info = {'filepath': d.name}

    pp = DummyPostProcessor()
    pp1 = DummyPostProcessor()
    pp._downloader = object()
    pp1._downloader = object()
    pp.set_downloader(pp._downloader)
    pp1.set_downloader(pp._downloader)

    pp.run(info)
    pp.add_post_processor(pp1)
    pp.run(info)
    pp.remove_post_processor(pp1)
    pp

# Generated at 2022-06-24 14:05:54.872484
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_error

    pp = PostProcessor(None)
    filepath = 'none'
    info = {}
    result = pp.run(filepath, info)
    assert result == (None, None)



# Generated at 2022-06-24 14:05:59.454435
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    downloader.params['forcejson'] = True
    assert downloader.params['forcejson']
    class MockPostProcessor(PostProcessor):
        def run(self, _):
            return ([], {})
    pp = MockPostProcessor()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:06:02.682423
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor
    assert pp._downloader == None
    assert pp.__dict__ == {'_downloader': None}

    pp = PostProcessor(downloader='foo')
    assert pp._downloader == 'foo'

# Generated at 2022-06-24 14:06:03.962543
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # TODO: Add unit test
    pass


# Generated at 2022-06-24 14:06:07.555142
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    yt = object()
    pp = PostProcessor(downloader=yt)
    assert pp._downloader is yt
    assert pp.set_downloader(yt) is None
    assert pp._downloader is yt

# Generated at 2022-06-24 14:06:09.674439
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert err.cause == 'test'

# Generated at 2022-06-24 14:06:19.119295
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import unittest

    class TestPP(PostProcessor):
        def __init__(self, downloader):
            self._downloader = downloader

        def run(self, info):
            return info

    class DownloaderMockup(object):
        def __init__(self):
            self.info = {"format": "best", "ext": "mp4", "url": "http://video_url/"}
            self.filename = "video.mp4"
            self.downloaded_bytes = 0
            self.total_bytes = 0

        def to_screen(self):
            return u'Downloaded video.mp4'

        def report_warning(self):
            return u'Warning'

        def to_stdout(self):
            return u'\r[download] Downloaded video.mp4'

    pp = Test

# Generated at 2022-06-24 14:06:23.647377
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import YoutubeDL
    d = YoutubeDL.YoutubeDL()
    pp = PostProcessor(d)
    assert pp._downloader == d
    pp = PostProcessor(None)
    assert pp._downloader is None
    assert pp.run(None) == ([], None)
    assert pp.try_utime(None, None, None) is None

# Generated at 2022-06-24 14:06:26.533550
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('msg', 'out', 'err')
    assert error.msg == 'msg'
    assert error.output == 'out'
    assert error.stderr == 'err'



# Generated at 2022-06-24 14:06:28.750769
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass


# Generated at 2022-06-24 14:06:30.219996
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    postprocessor = PostProcessor(None)
    information = {'filepath': 'abc'}
    assert postprocessor.run(information) == ([], information)



# Generated at 2022-06-24 14:06:38.620189
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class TestPostProcessor(PostProcessor):

        # The lines below are just to override the specification by the
        # constructor of the class PostProcessor
        _downloader = None

        # The lines below are just to override the specification by the
        # constructor of the class PostProcessor
        def __init__(self, downloader=None):
            self._downloader = downloader

        def run(self, information):
            return [['file_to_delete.txt']], dict(name='File to delete', filepath='file_to_delete.txt')

    # Specify a dictionary that is consistent with the information that is
    # expected by the method run of the class TestPostProcessor
    test_information = dict(name='File to delete', filepath='file_to_delete.txt')

    # Specify a downloader object just to initialize the

# Generated at 2022-06-24 14:06:41.636921
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError(123, 'test message')
    assert exc.errorcode == 123
    assert str(exc) == 'test message'



# Generated at 2022-06-24 14:06:51.791896
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import tempfile
    import time
    from .common import get_testdata_video_url
    from .downloader import Downloader

    class DummyPostProcessor(PostProcessor):
        def __init__(self, name, times):
            self.name = name
            self.times = times
            self.fname = None
            PostProcessor.__init__(self, Downloader(params={}))

        def run(self, information):
            self.fname = information['filepath']
            self.try_utime(self.fname, self.times[0], self.times[1], 'Cannot change file time')
            return ([], information)

    def test_file_time(fname, times):
        st = os.stat(fname)

# Generated at 2022-06-24 14:06:53.962767
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor

# Generated at 2022-06-24 14:07:03.951598
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    from ..utils import DateRange

    from .common import get_testdata_path

    dl = FileDownloader({
        'outtmpl': get_testdata_path(u'postprocessor-test.%(ext)s')
    })

    pp = PostProcessor(dl)

    pp.try_utime(get_testdata_path('audio.mp3'), 0, 0)
    pp.try_utime(get_testdata_path('audio.m4a'), None, None)

    dl.params['daterange'] = DateRange('20101010')
    pp.try_utime(get_testdata_path('audio.mp3'), 0, 0)
    pp.try_utime(get_testdata_path('audio.m4a'), None, None)

# Generated at 2022-06-24 14:07:05.631761
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor([])
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:08.121969
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Creates an instance of PostProcessor class

    This will be used as a base class for other post processors.
    """
    dl = object()
    pp = PostProcessor(dl)
    assert pp._downloader is dl

# Generated at 2022-06-24 14:07:11.026962
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run(None) == ([], None)
    assert not pp._configuration_args()

# Generated at 2022-06-24 14:07:15.086226
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Dummy class for testing PostProcessor class
    class PostProcessorMock(PostProcessor):
        def run(self, info):
            return [], info  # by default, keep file and do nothing

    postprocessor = PostProcessorMock()
    assert [], postprocessor.run({})



# Generated at 2022-06-24 14:07:20.431403
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    from . import FakeDownloader

    downloader = FakeDownloader()
    pp = PostProcessor(downloader)
    pp.try_utime('/path/to/file', 0, 0, errnote='Cannot update utime of file')
    if sys.platform != 'win32':
        assert downloader.has_warning('Cannot update utime of file')

# Generated at 2022-06-24 14:07:22.595587
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor(None)
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:25.216559
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        a = PostProcessor()
    except Exception:
        assert False, 'Can not instantiate class PostProcessor'


# Generated at 2022-06-24 14:07:30.424534
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class Dummy(PostProcessor):
        def run(self, information):
            return [], information
    pp = Dummy()

    class File(object):
        def __init__(self, name):
            self.name = name

        def __del__(self):
            if os.path.exists(self.name):
                os.remove(self.name)

    # Dummy PostProcessor
    f = File('output1')
    info = {'filepath': f.name}
    deleted, inf = pp.run(info)
    assert deleted == []
    assert inf == info

    # File exists and is unchanged
    f = File('output2')

# Generated at 2022-06-24 14:07:34.180713
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return ['test'], information
    t = TestPostProcessor()
    (filelist, info) = t.run({'filepath': 'test'})
    assert filelist == ['test']
    assert info == {'filepath': 'test'}

# Generated at 2022-06-24 14:07:35.009280
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p

# Generated at 2022-06-24 14:07:38.177214
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    PostProcessor._downloader = FileDownloader(params={'logger': None})
    PostProcessor.try_utime('hoge', 1, 2)

# Generated at 2022-06-24 14:07:39.295997
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    c = AudioConversionError('hello')
    assert c.message == 'hello'

# Generated at 2022-06-24 14:07:48.446121
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .XAttrMetadataPP import XAttrMetadataPP
    import os
    import errno
    import stat

    class FakeDownloader():
        def __init__(self, params):
            self.params = params
            self.warnings = []

        def report_warning(self, errnote):
            self.warnings.append(errnote)

    dir_with_test_file = os.path.join('tests', 'files')
    file_to_change_date = os.path.join(dir_with_test_file, 'test.mp3')
    file_to_change_date_copy = os.path.join(dir_with_test_file, 'test_mp3_copy.mp3')
    os.path.exists(file_to_change_date)

# Generated at 2022-06-24 14:07:52.559361
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(downloader=None)
    assert pp._downloader is None
    
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl


# Generated at 2022-06-24 14:07:59.786844
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    from ..downloader.common import FileDownloader

    class DummyPP(PostProcessor):
        def run(self, info):
            return [info['filepath']]

    # Dummy info is needed for testing
    info = {}
    info['filepath'] = 'some/path/file'

    # Create the post processor and check if the file can be deleted
    pp = DummyPP()
    result = pp.run(info)
    assert result == ['some/path/file']

# Generated at 2022-06-24 14:08:11.221416
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Use a mock object to avoid the need of a file 'a'
    class MockDownloader(object):
        def __init__(self):
            self.report_warning_called = 0
            self.report_warning_args = []
        def report_warning(self, errnote):
            self.report_warning_called += 1
            self.report_warning_args.append(errnote)

    downloader = MockDownloader()
    pp = PostProcessor(downloader)
    assert downloader.report_warning_called == 0
    assert downloader.report_warning_args == []
    pp.try_utime('a', 1, 2)
    assert downloader.report_warning_called == 1
    assert downloader.report_warning_args == ["Cannot update utime of file"]

# Generated at 2022-06-24 14:08:12.732104
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None

# Generated at 2022-06-24 14:08:18.901254
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # test when downloader is None
    pp = PostProcessor()
    assert pp._downloader == None

    # test when downloader is not None
    from ..extractor.common import YoutubeIE
    downloader = YoutubeIE()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader

    # test set downloader method
    downloader_new = YoutubeIE()
    pp.set_downloader(downloader_new)
    assert pp._downloader == downloader_new
    return pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:08:23.786328
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    PostProcessor_instance = PostProcessor()
    # Dummy class
    class Dummy_downloader():
        pass
    dummy_downloader_instance = Dummy_downloader()
    PostProcessor_instance.set_downloader(dummy_downloader_instance)
    assert PostProcessor_instance._downloader == dummy_downloader_instance

# Generated at 2022-06-24 14:08:26.861773
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    instance = AudioConversionError(1, 'a', 'b')
    assert instance.exit_code == 1
    assert instance.out_file == 'a'
    assert instance.err_file == 'b'



# Generated at 2022-06-24 14:08:34.672911
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPostProcessor(PostProcessor):
        def run(self, info):
            return [], {'a': info['a'] + 1}
    pp = MyPostProcessor()
    info = {'a': 1}
    result = pp.run(info)
    assert result == ([], {'a': 2})

    class MyPostProcessor_StopChain(PostProcessor):
        def run(self, info):
            return None, None
    pp = MyPostProcessor_StopChain()
    result = pp.run(info)
    assert result == (None, None)

    class MyPostProcessor_Error(PostProcessor):
        def run(self, info):
            raise PostProcessingError('Error!')
    pp = MyPostProcessor_Error()

# Generated at 2022-06-24 14:08:36.181764
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

# Generated at 2022-06-24 14:08:45.597894
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeD:
        pass
    downloader = FakeD()
    downloader.report_warning = lambda s: s
    pp = PostProcessor(downloader)
    import tempfile, os
    from ..compat import file_open, compat_stat
    fd, path = tempfile.mkstemp(prefix='youtubedl_test_try_utime')
    os.close(fd)

# Generated at 2022-06-24 14:08:46.546996
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:08:49.402524
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError('msg'):
        raise AudioConversionError('msg')
    try:
        raise AudioConversionError('msg')
    except AudioConversionError as e:
        assert e.msg == 'msg'

# Generated at 2022-06-24 14:08:58.756747
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .testpostprocessor_test_PostProcessor_run import TestPostProcessor
    from .testpostprocessor_test_PostProcessor_run import TestPostProcessor_run
    TestPostProcessor.run = TestPostProcessor_run
    postprocessor = TestPostProcessor()
    test_info = {'path': 'test_path', 'filepath': 'test_filepath'}
    test_info = postprocessor.run(test_info)[1]
    assert test_info['path'] == 'test_path'
    assert test_info['filepath'] == 'test_filepath_new'
    assert test_info['new_field'] == 'new_field_value'

# Generated at 2022-06-24 14:08:59.798560
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('message')

# Generated at 2022-06-24 14:09:00.946523
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    assert pp.run(None) == ([], None)

# Generated at 2022-06-24 14:09:01.602017
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:09:12.101627
# Unit test for method run of class PostProcessor

# Generated at 2022-06-24 14:09:15.272371
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        post_processor = PostProcessor()
        assert(post_processor, 'PostProcessor() returned None!')

    except Exception as err:
        assert(False, 'PostProcessor() returned None!' + str(err))

# Generated at 2022-06-24 14:09:18.524280
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader({})
    pp = PostProcessor(downloader=downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:09:25.458577
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    # Create test downloader and post processor
    class TestDownloader:
        pass

    class TestPostProcessor(PostProcessor):
        def __init__(self, test_downloader):
            super(TestPostProcessor, self).__init__()
            self.set_downloader(test_downloader)

    # Check the behaviour
    test_downloader = TestDownloader()
    test_post_processor = TestPostProcessor(test_downloader)
    assert test_post_processor._downloader == test_downloader

# Generated at 2022-06-24 14:09:31.592804
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import compat_mock
    pp = PostProcessor(None)
    pp.set_downloader(compat_mock.MagicMock())
    pp.run = lambda information: [], information
    assert pp.run({'filepath': 'testfile'}) == ([], {'filepath': 'testfile'})
    assert pp.run({'filepath': os.path.join('some', 'dir', 'testfile')}) == ([], {'filepath': os.path.join('some', 'dir', 'testfile')})

# Generated at 2022-06-24 14:09:38.965733
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Simple test
    def run(information):
        return [], information
    pp = PostProcessor(None)
    pp.run = run
    assert pp.run({}) == ([], {})
    assert pp.run({'a': 'b'}) == ([], {'a': 'b'})
    assert pp.run({'a': 'b', 'filepath': 'c'}) == ([], {'a': 'b', 'filepath': 'c'})

    # Test that list returned by run() is not modified
    def run(information):
        return [], information
    pp = PostProcessor(None)
    pp.run = run
    information = {'a': ['b', 'c']}
    pp.run(information)
    assert information['a'] == ['b', 'c']

# Generated at 2022-06-24 14:09:39.546156
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    pass

# Generated at 2022-06-24 14:09:49.746878
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import stat
    from .downloader import FakeYDL
    from .extractor import fake_extractor
    from .FileDownloader import FileDownloader
    from .compat import compat_makedirs

    # Create the fake directories
    compat_makedirs('/tmp/yt-dl-test/test_PostProcessor_try_utime/')
    input_file = '/tmp/yt-dl-test/test_PostProcessor_try_utime/input_file'
    with open(input_file, 'wb') as f:
        f.write(b'pouet')

    # Create the fake downloader
    ydl = FakeYDL()
    fd = FileDownloader(ydl, {})
    ie = fake_extractor()
    ie._downloader = fd # pylint: disable

# Generated at 2022-06-24 14:09:59.175581
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..compat import compat_urllib_request, compat_urllib_error
    from ..downloader import FakeYDL
    ydl = FakeYDL()
    pp = PostProcessor(ydl)
    assert pp._downloader is ydl

    class FakePostProcessor(PostProcessor):
        def run(self, info):
            return []
    pp = FakePostProcessor(ydl)
    assert pp._downloader is ydl

    def my_run(self, info):
        return [info['filepath']]
    FakePostProcessor.run = my_run
    pp = FakePostProcessor(ydl)

    class MyFileHandler(compat_urllib_request.HTTPHandler, compat_urllib_request.HTTPSHandler):
        def http_open(self, req):
            return self

# Generated at 2022-06-24 14:10:03.968170
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors.values():
        for pp in ie.get_postprocessors():
            pp.set_downloader(None)
            pp.run(None)

# Generated at 2022-06-24 14:10:06.308815
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor() 
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:10:06.928958
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:10:09.728235
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message', 'filename')
    except AudioConversionError as err:
        assert err.filename == 'filename'
        assert str(err) == 'error message'

# Generated at 2022-06-24 14:10:12.780006
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    processor = PostProcessor(downloader)
    assert processor._downloader == downloader

# Generated at 2022-06-24 14:10:19.330574
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .FakeYDL import FakeYDL
    x = PostProcessor(FakeYDL())
    x.try_utime('examples/test.mp4', 0, 0)
    x.try_utime('examples/an example video.webm', 0, 0)
    try:
        x.try_utime('examples/invalid-file-name', 0, 0)
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:10:22.943788
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            self.set_downloader(downloader)

    class TestDownloader(object):
        pass

    TestPP(TestDownloader())



# Generated at 2022-06-24 14:10:33.169940
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    from ..downloader import gen_downloaders

    info = {'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
            'upload_date': '20121002',
            'uploader': 'TheLinuxFoundation',
            'title': 'LinuxCon Europe 2011: Inbup Ebcioglu, "A Pragmatic Approach to Achieving Continuous Integration"',
            'ext': 'webm',
            'format': '320x240',
            'format_id': '240',
            'thumbnail': 'http://i.ytimg.com/vi/BaW_jenozKc/hqdefault.jpg'}
    filename = 'test'