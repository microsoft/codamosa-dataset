

# Generated at 2022-06-24 14:00:23.898837
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:00:33.636513
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a dummy PostProcessor object
    pp = PostProcessor(None)

    # Create a dummy file
    dummy_file = open('test_try_utime_file', 'w')
    dummy_file.close()

    # Update dummy file's access and modified time
    pp.try_utime('test_try_utime_file', 1, 2)

    # Check whether utime of dummy file has been updated
    if os.stat('test_try_utime_file').st_mtime != 2:
        print('Failed to update utime of the file')

    # Delete dummy file
    os.remove('test_try_utime_file')


if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-24 14:00:34.077802
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:00:34.524935
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:00:34.991755
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:00:46.550781
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    if sys.platform == 'win32':
        # This test will fail on Windows
        # because it doesn't accept utime_available
        return

    class MockDownloader(object):
        def __init__(self, utime_available):
            self.utime_available = utime_available

        def to_screen(self, *args, **kargs):
            pass

        def report_warning(self, msg):
            self.warning_msg = msg

    pp = PostProcessor(MockDownloader(False))
    pp.try_utime('some-file', 0, 0)
    assert pp._downloader.warning_msg == 'Cannot update utime of file'

    pp = PostProcessor(MockDownloader(True))
    pp.try_utime('some-file', 0, 0)


# Generated at 2022-06-24 14:00:50.342246
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    d = YoutubeDL({})
    pp = PostProcessor(d)
    assert d == pp._downloader
    pp.set_downloader(None)
    assert None is pp._downloader

# Generated at 2022-06-24 14:00:55.388681
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    info = dict(filepath='/tmp/foo.mp4')
    pp = PostProcessor()
    assert ('/tmp/foo.mp4', info) == pp.run(info)
    pp.set_downloader(None)
    assert ('/tmp/foo.mp4', info) == pp.run(info)

# Generated at 2022-06-24 14:01:01.265933
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import PostProcessorTest
    pp = PostProcessor(YoutubeDL())
    pp.try_utime = lambda path, atime, mtime: PostProcessorTest.assertEqual(path, 'test_path')
    pp.try_utime('test_path', 'test_atime', 'test_mtime')

# Generated at 2022-06-24 14:01:03.354668
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('message', 'stdout', 'stderr')
    assert e.stdout == 'stdout'
    assert e.stderr == 'stderr'
    assert str(e) == 'message'

# Generated at 2022-06-24 14:01:10.913529
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from ..utils import match_filter_func

    ydl = YoutubeDL()
    ydl.params['prefer_ffmpeg'] = False
    ydl.params['simulate'] = True
    ydl.add_info_extractor('test_ie')
    ydl.add_post_processor(MatchFilterPP, ie='test_ie', filter_func=match_filter_func('test_ie'))
    ydl.download(['test_ie:test_video'])

# Post Processor that only runs on downloadable video

# Generated at 2022-06-24 14:01:11.492384
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:01:13.494036
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    test_pp = PostProcessor(None)
    test_pp.set_downloader({})
    assert test_pp._downloader == {}

# Generated at 2022-06-24 14:01:21.288756
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import sys
    from ..compat import compat_struct_time
    from ..utils import DateRange

    class FakeDownloader:
        def __init__(self):
            self.params = {}
            self.to_stdout_func = lambda x: sys.stdout.write(x)
            self.to_stderr_func = lambda x: sys.stderr.write(x)

    class FakePostProcessor(PostProcessor):
        pass


# Generated at 2022-06-24 14:01:22.364453
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:01:30.698876
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Simple test of the PostProcessor class
    """
    class TestPP(PostProcessor):
        def run(self, info):
            print(info)
            return ([], info)
    info = {'ext': 'flv', 'uploader': 'test', 'format': 'format', 'url': 'url', 'player_url': 'player',
            'id': 'id', 'title': 'title', 'thumbnail': 'thumb', 'description': 'desc', 'uploader_url': 'up_url'}
    pp = TestPP()
    pp.run(info)

# Generated at 2022-06-24 14:01:32.117041
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:01:41.405831
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import DownloadError
    from .common import FileDownloader
    from .get_info import GetInfoPacket
    from .embedthumbnail import EmbedThumbnailPP
    from .execafterdownload import ExecAfterDownloadPP

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test.mp3'}

    class TestPP(ExecAfterDownloadPP, EmbedThumbnailPP):
        def __init__(self, downloader=None):
            ExecAfterDownloadPP.__init__(self, downloader)
            EmbedThumbnailPP.__init__(self, downloader)

    ie = TestIE()
    ie._real_initialize()

# Generated at 2022-06-24 14:01:49.364048
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractor

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            pass
    pp = MockPostProcessor()

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        _VALID_URL = r'.*'

        def __init__(self):
            self._downloader = gen_extractor()

    ie = MockInfoExtractor()
    ie._downloader.download.postprocessors = [pp]
    ie.extract(ie._VALID_URL)



# Generated at 2022-06-24 14:01:59.419070
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .common import FakeYDL
    from .extractor import gen_extractor
    from .downloader.common import FileDownloader
    from .utils import prepend_extension

    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    def run_pp(y):
        ex = gen_extractor()
        y.add_info_extractor(ex)
        y.add_post_processor(TestPP())

    # Creation test
    ydl1 = FakeYDL()
    run_pp(ydl1)
    assert ydl1._ies[0]._downloader is ydl1
    assert ydl1._pps[0]._downloader is ydl1

    # Unset test
    ydl2 = FakeYDL()
    run_pp(ydl2)


# Generated at 2022-06-24 14:02:03.426545
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:02:04.811527
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass



# Generated at 2022-06-24 14:02:05.844445
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

# Generated at 2022-06-24 14:02:13.423559
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Assert PostProcessor.try_utime() raises no exceptions if file exists and has the right type
    pp = PostProcessor(None)
    pp.try_utime('youtube-dl/__init__.py', 0, 0)
    pp.try_utime('LICENSE', 0, 0)

    # Assert PostProcessor.try_utime() raises no exceptions if file doesn't exist
    pp.try_utime('youtube-dl/non-existing-file', 0, 0)

    # Assert PostProcessor.try_utime() raises no exceptions if called with an os.DirEntry
    pp.try_utime(os.scandir('youtube-dl/__init__.py').__next__(), 0, 0)

# Generated at 2022-06-24 14:02:23.141214
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    from pytest import raises
    import tempfile
    import time

    def getmtime(path):
        return os.stat(path).st_mtime

    (fd, path) = tempfile.mkstemp()

# Generated at 2022-06-24 14:02:29.221028
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    from pytube import postprocessor
    from ..utils import (
        date_from_str,
        sanitize_open,
    )

    a = postprocessor.PostProcessor()
    a.set_downloader(None)
    fname = 'pytube_test.txt'
    old_atime = time.time() - 200
    old_mtime = time.time() - 100
    with sanitize_open(fname, 'wb') as tfile:
        tfile.write('py-tube testing')
    os.utime(fname, (old_atime, old_mtime))

    a.try_utime(fname, old_atime, old_mtime)
    (atime, mtime) = os.stat(fname).st_atime,

# Generated at 2022-06-24 14:02:31.569819
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Unit test for constructor of class PostProcessor"""
    pp = PostProcessor()  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-24 14:02:36.285279
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        pass
    pp = MockPP()
    files_to_delete, info = pp.run({'filepath': 'test-file.mp3'})
    assert info['filepath'] == 'test-file.mp3'
    assert isinstance(files_to_delete, list)

# Generated at 2022-06-24 14:02:46.494840
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile

    downloader = FakeDownloader()
    postprocessor = PostProcessor(downloader)
    postprocessor.run({'test': 'abc'})

    # With a file
    _, filename = tempfile.mkstemp(prefix='%(test)s')

    try:
        assert postprocessor.run({'test': 'abc', 'filepath': filename}) == ([filename], {'test': 'abc', 'filepath': filename})
    finally:
        os.unlink(filename)

    # With a file and extra_args
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            assert self._configuration_args() == ['a', 'b', 'c']
            return self.run_old(info)
    postprocessor = TestPostProcessor(downloader)
    _,

# Generated at 2022-06-24 14:02:57.523639
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class FakePostProcessor(PostProcessor):
        def __init__(self, downloader=None, name='Fake'):
            PostProcessor.__init__(self, downloader)
            self.passed_info = None
            self.name = name

        def run(self, info):
            self.passed_info = info
            return [info['filepath'] + '.delete'], info

    info = {'filepath': 'test.file', 'ext': 'mp4', 'format': 'fake'}
    a = FakePostProcessor(name='A')
    b = FakePostProcessor(name='B')
    c = FakePostProcessor(name='C')
    a.add_post_processor(b)
    b.add_post_processor(c)

# Generated at 2022-06-24 14:03:08.278424
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    from datetime import datetime, timedelta

    pp = PostProcessor(None)

    with tempfile.NamedTemporaryFile() as f:
        # Given an incorrect path, an exception is raised
        try:
            pp.try_utime(f.name + 'does_not_exist', 0, 0)
        except Exception:
            pass
        else:
            assert False, 'No exception raised'

        # Given a correct path and no exception, utime is updated
        old_utime = os.path.getatime(f.name)
        pp.try_utime(f.name, 0, 0)
        new_utime = os.path.getatime(f.name)
        assert old_utime < new_utime, 'utime was not updated'

        #

# Generated at 2022-06-24 14:03:10.860747
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

    pp = TestPP()
    assert pp



# Generated at 2022-06-24 14:03:14.745346
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    d = object()
    pp = PostProcessor(d)
    assert pp._downloader == d

    pp.set_downloader(None)
    assert pp._downloader is None

    pp.set_downloader(d)
    assert pp._downloader == d

# Generated at 2022-06-24 14:03:19.992318
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class FakePP(PostProcessor):
        def __init__(self, downloader=None):
            self.val = None
        def run(self, info):
            self.val = info
            return [], info
    pp = FakePP()
    info = dict(filepath='foobar', ext='ogg')
    pp.run(info)
    assert pp.val == info

# Generated at 2022-06-24 14:03:21.545935
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(None, None)
    assert isinstance(err, PostProcessingError)

# Generated at 2022-06-24 14:03:24.314979
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run(dict(
        filepath=None,
    )) == ([], dict(
        filepath=None,
    ))

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:03:30.587918
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    from tempfile import mkdtemp

    try:
        import mutagen
    except ImportError:
        mutagen = None

    from ..compat import (
        compat_os_name,
        compat_getenv,
    )

    from .common import FileDownloader

    class FakePostProcessor(PostProcessor):

        def run(self, info):
            return [], info

    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.mp3'), 'rb') as f:
        data = f.read()
    tmpd = mkdtemp(prefix='youtube-dl-test-')

    # Fake an non-writable file
    if compat_os_name == 'nt':
        fp1 = os.path

# Generated at 2022-06-24 14:03:34.752481
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPP(PostProcessor):
        def run(self, info):
            return [], info
    dummy_pp = DummyPP()
    dummy_file = {
        'filepath': 'foo'
    }
    assert dummy_pp.run(dummy_file) == ([], {'filepath': 'foo'})

# test_PostProcessor_run()

# Generated at 2022-06-24 14:03:39.888484
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(
            'test message', 'test orignal file', 'test generated file', 'test output', 'test error message')
    except AudioConversionError as expected:
        assert expected.original_file == 'test orignal file'
        assert expected.generated_file == 'test generated file'
        assert expected.output == 'test output'
        assert expected.error == 'test error message'
    else:
        assert False, 'exception not raised'

# Generated at 2022-06-24 14:03:47.561457
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    If a PostProcessor doesn't have a _downloader, the PostProcessor's set_downloader method
    sets the PostProcessor's _downloader to the downloader.
    """
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    class FakePostProcessor(PostProcessor):
        pass
    fakepostprocessor = FakePostProcessor()
    ydl = YoutubeDL({})
    fakepostprocessor.set_downloader(ydl)
    assert ydl == fakepostprocessor._downloader

# Generated at 2022-06-24 14:03:55.749296
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    import tempfile
    from ..extractor import get_info_extractor
    from ..downloader import get_suitable_downloader

    # Create a file
    test_file = tempfile.NamedTemporaryFile()

    # Get an InfoExtractor object
    ie = get_info_extractor('Generic')
    info_dict = get_suitable_downloader('http://www.youtube.com/watch?v=BaW_jenozKc')().result()
    ie.extract(info_dict)

    # Get a PostProcessor object
    pp = get_suitable_downloader('http://www.youtube.com/watch?v=BaW_jenozKc')().pp

    # Get the creation time of the file
    ctime = os.path.getctime(test_file.name)

    #

# Generated at 2022-06-24 14:03:57.656427
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except PostProcessingError:
        pass


# Generated at 2022-06-24 14:04:00.135451
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(4)
    except AudioConversionError as err:
        assert str(err) == 'ffmpeg exited with code 4'

# Generated at 2022-06-24 14:04:07.880920
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import tempfile
    from .compat import compat_tempfile

    class FakeDownloader():
        def __init__(self, params):
            self.params = params
            self.warning_count = 0
            self.warnings = []

        def to_screen(self, message):
            pass

        def report_warning(self, message):
            self.warning_count += 1
            self.warnings.append(message)

    # Create temporary test file
    def_umask = os.umask(0)
    tmp_fd, tmp_path = compat_tempfile.mkstemp(prefix='youtubedl_test_', dir='.')
    os.umask(def_umask)
    os.close(tmp_fd)
    os.unlink(tmp_path)

    p = PostProcess

# Generated at 2022-06-24 14:04:14.257948
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    try:
        os.mkdir('testdir')
    except OSError:
        pass
    path = os.path.join('testdir', 'testfile')
    open(path, 'w').close()
    pp = PostProcessor(None)

    atime = time.time() - 100
    mtime = atime + 50
    pp.try_utime(path, atime, mtime)

    st = os.stat(path)
    assert st.st_atime == atime
    assert st.st_mtime == mtime

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 14:04:15.130210
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    # Test constructor
    assert pp



# Generated at 2022-06-24 14:04:25.062653
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..utils import prepend_extension
    from .common import FileDownloader
    from .ffmpeg import FFmpegPostProcessor
    from .xattrpp import XAttrMetadataPP
    from .embedthumbnail import EmbedThumbnailPP

    params = {
        'outtmpl': 'test.%(ext)s',
        'postprocessor_args': [
            '-d', 'testdir', '--embed-thumbnail', '--add-metadata', '--prefer-ffmpeg'
        ]
    }

    ydl = FileDownloader(params)
    ydl.add_post_processor(FFmpegPostProcessor(ydl))
    ydl.add_post_processor(XAttrMetadataPP(ydl))
    ydl.add_post_processor(EmbedThumbnailPP(ydl))


# Generated at 2022-06-24 14:04:29.601397
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError(msg="test", out_file=None, err=None, cmd=None, exit_code=None)
    assert exc.msg == "test"
    assert exc.out_file is None
    assert exc.err is None
    assert exc.cmd is None
    assert exc.exit_code is None

# Generated at 2022-06-24 14:04:32.106951
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    for result in [AudioConversionError('foo'), AudioConversionError(None)]:
        assert isinstance(result, Exception)
        assert result.__str__() == result.msg

# Generated at 2022-06-24 14:04:40.460095
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.test_executed = []

        def run(self, info):
            self.test_executed.append(True)
            return [], info

    class TestIE(object):
        def __init__(self):
            self.pp = TestPP()

    ie = TestIE()
    ie.pp.run({'id': 'test', 'filepath': 'filepath'})
    assert ie.pp.test_executed == [True]

# Generated at 2022-06-24 14:04:49.245735
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestDownloader():

        def __init__(self):
            self.set_downloader = ''

        def to_screen(self, *a, **k):
            pass

    class TestPostProcessor(PostProcessor):

        def __init__(self):
            PostProcessor.__init__(self)
            self.test = ''

        def run(self, information):
            pass

    postprocessor = TestPostProcessor()
    downloader = TestDownloader()
    postprocessor.set_downloader(downloader)
    assert postprocessor._downloader == downloader

# Generated at 2022-06-24 14:04:52.502982
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('SomeMessage')
    except AudioConversionError as expected:
        assert expected.args[0] == 'SomeMessage'
        assert expected.exc_info is None
    else:
        assert False, "Didn't raise an exception"



# Generated at 2022-06-24 14:04:55.523714
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPP(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

    pp = DummyPP()
    info = {}
    pp.run(info)

# Generated at 2022-06-24 14:04:58.886161
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    mock_downloader = type('MockDownloader', (object,), {'report_warning': lambda self, str : print(str)})
    mock = PostProcessor(mock_downloader())
    mock.try_utime(None, None, None)

# Generated at 2022-06-24 14:05:09.847691
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile

    pp = PostProcessor()
    # On Windows NamedTemporaryFile does not allow to set file attributes
    if os.name != 'nt':
        with NamedTemporaryFile('w', delete=False) as f:
            f.write('foo')
            name = f.name
            pp.try_utime(name, 1234.54, 6789.55)  # Set it to a time in the future
            atime, mtime = os.stat(name).st_atime, os.stat(name).st_mtime
            assert atime >= 1234.54, 'Setting atime failed'
            assert mtime >= 6789.55, 'Setting mtime failed'
            pp.try_utime(name, 4321.54, 9876.55)  # Set it to an earlier time


# Generated at 2022-06-24 14:05:10.594526
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    obj = AudioConversionError()



# Generated at 2022-06-24 14:05:15.017147
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [(info['filepath'] + '1', info['filepath'] + '2')], info

    pp = TestPP()
    assert pp.run({
        'filepath': 'abc',
    }) == ([('abc1', 'abc2')], {
        'filepath': 'abc',
    })

# Generated at 2022-06-24 14:05:15.713926
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:05:17.306941
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    if not pp:
        raise TypeError('Invalid PostProcessor constructor')

# Generated at 2022-06-24 14:05:20.068620
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('Some message', 'Some output')
    assert isinstance(err, PostProcessingError)
    assert err.output == 'Some output'

# Generated at 2022-06-24 14:05:28.791248
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    import os
    class MyPP(PostProcessor):
        def run(self, info):
            self.assertEqual(self._downloader, 'test_downloader')
            return [], info
    self.assertTrue(MyPP().set_downloader('test_downloader'))
    ydl_opts = {
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s%(ext)s',
        'postprocessors': [{'key': 'MyPP'}],
    }
    with FileDownloader(ydl_opts) as fd:
        fd.result = {'id': 'test', 'ext': '.dummy'}
        fd.add_

# Generated at 2022-06-24 14:05:32.885666
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyDownloader():
        pass

    class DummyPP(PostProcessor):
        pass

    pp = DummyPP()
    assert pp._downloader is None
    assert pp.set_downloader(DummyDownloader()) is None
    assert pp._downloader is not None

# Generated at 2022-06-24 14:05:37.839622
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test1', 'test2', original_exc='test3')
    except AudioConversionError as err:
        assert str(err) == 'test1'
        assert err.output == 'test2'
        assert err.original_exc == 'test3'
    else:
        assert False



# Generated at 2022-06-24 14:05:47.410619
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader method of class PostProcessor
    """
    class downloader_test(object):
        downloader = None

        def __init__(self):
            self.downloader = None

        def to_stdout(self, message, skip_eol=False, check_quiet=False):
            self.downloader = self

    class PostProcessor_test(PostProcessor):
        downloader = None

        def __init__(self, downloader):
            self.downloader = downloader

    downloader = downloader_test()
    postprocessor = PostProcessor_test(downloader)
    postprocessor.set_downloader(downloader_test())

    assert postprocessor.downloader == downloader
    assert downloader.downloader == downloader

# Generated at 2022-06-24 14:05:48.558329
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor

# Generated at 2022-06-24 14:05:56.589259
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessorModule(object):
        class MyPostProcessor1(PostProcessor):
            def run(self, information):
                return information['filepath'], information

        class MyPostProcessor2(PostProcessor):
            def run(self, path):
                return [path], {}

    mp = MockPostProcessorModule()
    mp1 = mp.MyPostProcessor1()
    mp2 = mp.MyPostProcessor2()
    information = {'filepath': 'file'}
    mp1.to_stdout = False
    mp2.to_stdout = False

    mp1.set_downloader(mp2)
    mp2.set_downloader(mp1)

    # Test with mp1 -> mp2
    mp2.add_post_processor(mp1)
    _, information = mp

# Generated at 2022-06-24 14:05:58.354954
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('test')
    assert a.args == ('test',)



# Generated at 2022-06-24 14:05:59.870050
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postprocessor = PostProcessor()
    assert postprocessor


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:06:01.737943
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:06:04.369115
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    downloader2 = YoutubeDL()
    pp.set_downloader(downloader2)
    assert pp._downloader == downloader2


# Generated at 2022-06-24 14:06:06.045197
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # TODO
    return True



# Generated at 2022-06-24 14:06:09.276922
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPP(PostProcessor):
        pass

    pp = MyPP()
    pp.set_downloader(None)
    assert pp.run(None) == ([], None)

# Generated at 2022-06-24 14:06:18.836895
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    import shutil

    class TestPP(PostProcessor):
        def run(self, info):
            fn, ext = os.path.splitext(info['filepath'])
            return [(fn + '.ttt')], info

    pp = PostProcessor()
    pp.set_downloader(object)
    test_pp = TestPP()
    test_pp.set_downloader(object)
    pp.add_post_processor(test_pp)
    tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test_PostProcessor_run')

# Generated at 2022-06-24 14:06:27.966134
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_etree_fromstring
    
    video_id = '123'
    title = 'myVideo'
    ext = 'mp4'
    filename = '%s.%s' % (title, ext)
    filepath = '%s/%s' % (video_id, filename)
    seed = 15 # Seed the random number generator to get a fixed result in hash_file

# Generated at 2022-06-24 14:06:29.533167
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    obj = PostProcessor()
    assert obj is not None


# Generated at 2022-06-24 14:06:38.265456
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import PY3
    from ..downloader.common import FileDownloader
    import tempfile
    import shutil
    import os
    import os.path

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 14:06:49.911440
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # test_filepath = '/a/random/file/path'
    test_filepath = b'/a/random/file/path'
    fake_downloader = None
    # Test all of the 'except' situations
    from unittest.mock import MagicMock
    fake_os = MagicMock()
    fake_os.utime = MagicMock(side_effect=PermissionError)
    utime = PostProcessor(fake_downloader).try_utime
    try:
        utime(test_filepath, 0, 0)
    except PostProcessingError:
        pass
    except Exception:
        raise AssertionError('Unexpected exception when utime failed due to PermissionError.')

# Generated at 2022-06-24 14:06:51.058169
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('test') == 'test'

# Generated at 2022-06-24 14:06:54.121643
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:06:57.989516
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('error message')
    except PostProcessingError as e:
        assert e.msg == 'error message'
        return
    assert 0, 'AudioConversionError did not raise PostProcessingError'



# Generated at 2022-06-24 14:07:06.548520
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import datetime
    import unittest

    class MockReportWarning(object):
        def __init__(self):
            self.warning = None

        def report_warning(self, warning):
            self.warning = warning

    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    class PostProcessorTest(unittest.TestCase):
        def setUp(self):
            self.downloader = MockReportWarning()
            self.postprocessor = TestPostProcessor(self.downloader)
            self.path = "test.tmp"
            self.fh = open(self.path, 'w')
            self.fh.close()


# Generated at 2022-06-24 14:07:09.681840
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo')
    except AudioConversionError as err:
        assert str(err) == 'foo'
        assert 'foo' in str(err)
    else:
        raise AssertionError('Expected AudioConversionError to be raised')


# Generated at 2022-06-24 14:07:20.953405
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    import sys
    import os

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            self.test_result = info
            return [], info

    class DummyDownloader():
        def __init__(self, params):
            self.params = params

        def report_warning(self, msg):
            self.test_result = 'warning'

    p = DummyPostProcessor(DummyDownloader({}))
    info = {}
    info['a'] = 'b'
    info['c'] = 'd'
    info['filepath'] = '/foo/bar'
    p.run(info)
    assert p.test_result == info
    assert p.test_result is not info


if __name__ == '__main__':
    test_PostProcess

# Generated at 2022-06-24 14:07:32.318468
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class BadPP(PostProcessor):
        def run(self, info):
            return [], None

    class GoodPP(PostProcessor):
        def run(self, info):
            return [], info

    class BadPP2(PostProcessor):
        def run(self, info):
            return [], info

    class GoodPP2(PostProcessor):
        def run(self, info):
            return [], info

    info = {'title': 'Sample title', 'ext': 'mp4', 'format': 'Format', 'format_id': 'fmt1', 'url': 'url'}
    pp1 = BadPP()
    pp2 = GoodPP()
    pp3 = BadPP2()
    pp4 = GoodPP2()
    pp2.set_downloader(pp1._downloader)
    pp3.set

# Generated at 2022-06-24 14:07:36.155053
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """test_PostProcessor_run tests the method PostProcessor.run."""
    # mock class for return value of run
    class MockPostProcessor(PostProcessor):
        def run(self, info):
            return ['python', '-c', 'pass'], ['python', '-c', 'pass']

    # mock class for return value of run of PostProcessor
    class MockPostProcessorPP(PostProcessor):
        def run(self, info):
            return ['python', '-c', 'pass'], ['python', '-c', 'pass']

    post_processor = MockPostProcessor()
    post_processor_PP = MockPostProcessorPP()
    post_processor.add_post_processor(post_processor_PP)
    post_processor_list = post_processor.get_post_processors()

# Generated at 2022-06-24 14:07:42.481810
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test PostProcessor run method.

    Test that a PP can return a tuple of (empty list,information)
    and that is interpreted correctly.
    """
    class DummyPP(PostProcessor):
        def run(self, info):
            return [], info
    dummyPP = DummyPP()
    information = {'filepath': 'file.mp4'}
    (files_to_delete, new_information) = dummyPP.run(information)
    assert not files_to_delete
    assert new_information == information

# Generated at 2022-06-24 14:07:47.306389
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err_msg = 'Error'
    err_exc = Exception(err_msg)
    result1 = AudioConversionError(err_msg, err_exc)
    assert result1.msg == err_msg
    assert result1.converted == None
    assert result1.original == None
    assert result1.cause == err_exc

    inp_file = 'inp_file'
    out_file = 'out_file'
    result2 = AudioConversionError(err_msg, err_exc, converted=False, original=inp_file)  # pylint: disable=unexpected-keyword-arg
    assert result2.msg == err_msg
    assert result2.converted == inp_file
    assert result2.original == None
    assert result2.cause == err_exc

    result3 = AudioConversion

# Generated at 2022-06-24 14:07:48.790762
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert isinstance(pp, PostProcessor)


# Generated at 2022-06-24 14:07:51.324612
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class A(PostProcessor):
        def run(self, result):
            return []

    assert A().run("") == []



# Generated at 2022-06-24 14:07:55.166806
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    test_string = 'Test String'
    err = AudioConversionError(test_string)

    assert str(err) == test_string
    # Should be False now
    assert not err.result



# Generated at 2022-06-24 14:07:58.220321
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    downloader = object()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:07:59.342486
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except:
        pass


# Generated at 2022-06-24 14:08:10.709294
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import os
    import shutil
    import stat

    from ..extractor import gen_extractors
    from ..utils import (
        DateRange,
        DateRangeLimit,
    )
    from .common import FileDownloader

    def time_in_range(timestamp, timerange):
        """Return true if timestamp is in range timerange."""
        return timerange[0] <= timestamp <= timerange[1]

    # Create a temporary directory for testing
    tmp_dir = tempfile.mkdtemp()
    os.chmod(tmp_dir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    # Test filename
    tmp_file = os.path.join(tmp_dir, 'foo')

    # Test atime and

# Generated at 2022-06-24 14:08:12.305769
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(u'Unicode')
    except AudioConversionError:
        pass

# Generated at 2022-06-24 14:08:13.869625
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp._downloader is None, 'PostProcessor _downloader is not initialized as None'

# Generated at 2022-06-24 14:08:15.009464
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('foo') == 'foo'



# Generated at 2022-06-24 14:08:17.163684
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass
    else:
        raise RuntimeError('Construnctor AudioConversionError failed')



# Generated at 2022-06-24 14:08:23.532877
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import Downloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromTIT2 import MetadataFromTIT2PP
    from .ffmpegmetadata import FFmpegMetadataPP
    from .embedthumbnail import EmbedThumbnailPP
    d = Downloader({})
    x = XAttrMetadataPP(d)
    e = ExecAfterDownloadPP(d)
    t = MetadataFromTIT2PP(d)
    f = FFmpegMetadataPP(d)
    pp = (t, x, e, f, EmbedThumbnailPP(d))

    information = {}
    information['filepath'] = 'testfile'
    assert x.run(information) == ([], information)

    information['title'] = 'TestTitle'
    assert x.run

# Generated at 2022-06-24 14:08:28.456247
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(downloader=None)
    ydl = YoutubeDL()
    ydl2 = YoutubeDL()
    pp.set_downloader(ydl)
    pp.set_downloader(ydl2)
    assert pp._downloader == ydl2

# Unit tests for method _configuration_args of class PostProcessor

# Generated at 2022-06-24 14:08:40.395095
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .downloader import FakeDownloader
    import tempfile
    import os
    import time

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()
    downloader = FakeDownloader()
    tmpfile_atime = time.time() - 100
    tmpfile_mtime = time.time() - 200
    pp = PostProcessor(downloader)
    pp.try_utime(tmpfile.name, tmpfile_atime, tmpfile_mtime, 'Cannot update utime of test file')
    file_atime = os.path.getatime(tmpfile.name)
    file_mtime = os.path.getmtime(tmpfile.name)
    os.remove(tmpfile.name)
    assert tmpfile_atime == file_atime
    assert tmp

# Generated at 2022-06-24 14:08:41.368950
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
  pp = PostProcessor()
  assert pp is not None

# Generated at 2022-06-24 14:08:48.316029
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    import tempfile

    class DummyPostProcessor(PostProcessor):
        def __init__(self, ie, *args, **kwargs):
            super(DummyPostProcessor, self).__init__(*args, **kwargs)
            self.ie = ie

        def run(self, info):
            self.info = info
            self.path = self._downloader.downloaded_info_path
            return [], info

    class DummyIE(InfoExtractor):
        def __init__(self, downloader, *args, **kwargs):
            super(DummyIE, self).__init__(*args, **kwargs)
            self.downloader = downloader


# Generated at 2022-06-24 14:08:54.987261
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    with AudioConversionError as e:
        assert e.args[0] == 'Audio conversion failed'
        assert e.cause == None
    with AudioConversionError(cause='cause') as e:
        assert e.args[0] == 'Audio conversion failed'
        assert e.cause == 'cause'
    with AudioConversionError('msg', 'cause') as e:
        assert e.args[0] == 'msg'
        assert e.cause == 'cause'

# Generated at 2022-06-24 14:08:57.055800
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    if pp is None:
        print('Failed to create PostProcessor')

    pp.set_downloader("downloader")

    if pp.run("information") is None:
        print('PostProcessor.run returned None')

# Generated at 2022-06-24 14:08:59.501615
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1)
    except AudioConversionError as err:
        assert err.args[0] == 1



# Generated at 2022-06-24 14:09:03.321225
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test', ['command', 'output'])
    except AudioConversionError as e:
        assert 'test' == str(e)
        assert ['command', 'output'] == e.cause
    else:
        assert False

# Generated at 2022-06-24 14:09:06.099377
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    assert pp._downloader is None
    dl = YoutubeDL()
    pp.set_downloader(dl)
    assert pp._downloader is dl

# Generated at 2022-06-24 14:09:09.923304
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    You can run this test for checking if constructor of class PostProcessor work or not.
    This test will run if you run this script directly.
    """
    dl = None
    PostProcessor(dl)._downloader

# Generated at 2022-06-24 14:09:14.883067
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            info['newkey'] = 'newvalue'
            return ([], info)

    pp = TestPP()
    info = {}
    (del_files, new_info) = pp.run(info)
    assert new_info.get('newkey') == 'newvalue'

# Generated at 2022-06-24 14:09:15.417382
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:09:18.689902
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test message')
    except AudioConversionError as e:
        assert str(e) == 'test message'



# Generated at 2022-06-24 14:09:20.534518
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader import YoutubeDL
    pp = PostProcessor(YoutubeDL())

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 14:09:23.948869
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class _DummyPP(PostProcessor):
        def run(self, info):
            info['test'] = True
            return [], info

    pp = _DummyPP()
    info = {}
    pp.run(info)
    assert info['test']

# Generated at 2022-06-24 14:09:25.370368
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('foo', 12)


# Generated at 2022-06-24 14:09:26.525386
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    assert PostProcessor()._downloader is None

# Generated at 2022-06-24 14:09:28.213648
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = object()
    pp = PostProcessor(downloader)
    pp.set_downloader(downloader)

# Generated at 2022-06-24 14:09:40.087111
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import calendar

    import filecmp
    import tempfile
    from ..downloader.common import FileDownloader

    postprocessor_class = PostProcessor

    video_filename = "test.mp4"
    video_filepath = os.path.join(tempfile.gettempdir(), video_filename)

    video_date = calendar.timegm((2016, 9, 5, 0, 15, 0))
    audio_date = calendar.timegm((2016, 9, 6, 0, 15, 0))

    with open(video_filepath, 'w') as f:
        f.write('This is a fake file')

    # Set creation date of video file
    os.utime(video_filepath, (video_date, video_date))

    # Initialize FileDownloader to check utime of temporary audio file
    ydl = FileDownloader

# Generated at 2022-06-24 14:09:46.678837
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Check the function with a non-existing file
    pp_instance = PostProcessor()
    testfile = 'the_file_does_not_exist'
    # We expect a warning message
    pp_instance._downloader.report_warning = lambda msg: pp_instance._downloader.to_screen('[warning]' +  msg)
    pp_instance.try_utime(testfile, 0, 0)
    # Now, remove executable bit from the file and try again
    filename = open(testfile, 'w')
    filename.close()
    os.chmod(filename.name, os.stat(filename.name).st_mode | stat.S_IEXEC)
    pp_instance.try_utime(testfile, 0, 0, 'Cannot update utime of video')
    os.remove(testfile)

# Generated at 2022-06-24 14:09:49.900130
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError(1, 2, 3).args == (1, 2, 3)



# Generated at 2022-06-24 14:09:57.498900
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    import DataCollector

    ydl = youtube_dl.YoutubeDL(DataCollector.MyLogger())
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl # Check that the downloader given in __init__ is set properly
    pp.set_downloader(None)
    assert pp._downloader == None
    ydl2 = youtube_dl.YoutubeDL(DataCollector.MyLogger())
    pp.set_downloader(ydl2)
    assert pp._downloader == ydl2 # Check that the downloader given in set_downloader is set properly

# Generated at 2022-06-24 14:09:59.522584
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('err_msg')
    assert error.msg == 'err_msg'

# Generated at 2022-06-24 14:10:10.613907
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    succeed = lambda x: x
    fail = lambda x: None
    pp1 = PostProcessor(None)
    pp1.run = succeed
    pp2 = PostProcessor(None)
    pp2.run = succeed
    pp3 = PostProcessor(None)
    pp3.run = succeed
    pp4 = PostProcessor(None)
    pp4.run = succeed
    pp5 = PostProcessor(None)
    pp5.run = succeed
    pp6 = PostProcessor(None)
    pp6.run = succeed
    pp7 = PostProcessor(None)
    pp7.run = succeed
    pp8 = PostProcessor(None)
    pp8.run = succeed
    pp9 = PostProcessor(None)
    pp9.run = succeed
    pp10 = PostProcessor(None)
   

# Generated at 2022-06-24 14:10:11.309481
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pass

# Generated at 2022-06-24 14:10:12.700284
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:10:14.317497
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:10:16.823890
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(2, 3)
    except AudioConversionError as e:
        assert e.original_length == 2
        assert e.downloaded_length == 3

# Generated at 2022-06-24 14:10:20.200793
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Make sure PostProcessor constructor can be called successfully
    try:
        PostProcessor()
    except:
        raise AssertionError("PostProcessor constructor failed")

# Generated at 2022-06-24 14:10:23.346447
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def run(self, information):
            return [], information

    pp = TestPP()


if __name__ == '__main__':
    test_PostProcessor()