

# Generated at 2022-06-24 14:00:30.576835
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        postprocessor = ie.ie_key()
        postprocessor = globals()[postprocessor]
        if 'youtube' in postprocessor.__name__:
            pp_inst = postprocessor(None)
            pp_inst.try_utime('test_file', 1, 2)

# vim: expandtab:shiftwidth=4

# Generated at 2022-06-24 14:00:35.676345
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    pp.try_utime('foo.txt', 1, 2)
    os.chmod = lambda x, y: True
    os.utime = lambda x, y: True
    pp.try_utime('foo.txt', 1, 2)
    os.utime = lambda x, y: False
    pp.try_utime('foo.txt', 1, 2)

# Generated at 2022-06-24 14:00:41.334228
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)
            self.called = False

        def run(self, info):
            self.called = True
            return []
    pp = TestPP()
    info = {'filepath': 'blabla'}
    # If the file is present, returns a tuple (list_to_delete, info_dict)
    assert isinstance(pp.run(info), tuple)
    # If the file is not present, raises an exception
    info['filepath'] = None
    try:
        pp.run(info)
        assert False, 'Exception not raised'
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:00:49.392430
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create an object of class PostProcessor
    pp = PostProcessor()

    # Test if self._downloader of the PostProcessor object is None
    assert pp._downloader == None

    # Create an object of class YoutubeDL
    ydl_obj = YoutubeDL()

    # Call the method set_downloader with parameter ydl_obj
    pp.set_downloader(ydl_obj)

    # Test if self._downloader of the PostProcessor object was set
    # to the object ydl_obj
    assert pp._downloader == ydl_obj



# Generated at 2022-06-24 14:00:52.789201
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('spam', dict(foo='bar'))
    assert hasattr(err, 'format_message')
    assert err.format_message()

# Generated at 2022-06-24 14:01:01.972856
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    try:
        import json
    except ImportError:
        import simplejson as json
    import os
    import shutil
    import tempfile
    import traceback

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information
    t = TestPostProcessor()
    t.set_downloader(None)
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tf_name = tf.name
        tf.write(b'a')
    try:
        information = {'filepath': tf_name}
        files_to_delete, information = t.run(information)
        assert information['filepath'] == tf_name
        assert files_to_delete == []
    finally:
        os.remove(tf_name)

# Generated at 2022-06-24 14:01:05.680628
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PostProcessor().try_utime('test', 0, 0)
    # Nothing to test, this method uses only
    # functions of the standard library.
    # Only return code is tested

# Generated at 2022-06-24 14:01:15.200441
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    from .common import FileDownloader
    from .extractor import get_info_extractor, YoutubeIE

    # Create temp folder for testing
    temp_dir = tempfile.mkdtemp()

    # Create testing file
    temp_file = os.path.join(temp_dir, "test.txt")
    open(temp_file, 'a').close()

    # Create testing postprocessor
    class TestPostprocessor(PostProcessor):
        def run(self, information):
            self.try_utime(temp_file, 0, 0, "Test Error")
            return [], information

    # Create FileDownloader with testing postprocessor
    params = { 'outtmpl': temp_file }

# Generated at 2022-06-24 14:01:15.911933
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    PP = PostProcessor()

# Generated at 2022-06-24 14:01:16.718174
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:01:25.455427
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a test PostProcessor object
    from ..extractor import gen_extractor
    from .common import common_tests
    tests = common_tests.copy()
    tests.append(({
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'filepath': 'test.mp4',
        'info_dict': {
            'id': 'BaW_jenozKc',
            'ext': 'mp4',
            'title': 'google',
            'filepath': 'test.mp4',
        }
    }, [], [], None, False, False, [], 'test_postprocessor_run'))
    downloader = gen_extractor(tests, 'test_postprocessor')

    test_postprocessor = PostProcessor(downloader)
    result = test

# Generated at 2022-06-24 14:01:27.133524
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError:
        pass



# Generated at 2022-06-24 14:01:28.201077
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError('test')

# Generated at 2022-06-24 14:01:30.697549
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:01:39.102946
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    from ..utils import DateRange
    from .common import FileDownloader
    from .http import HttpFD
    from .http import HttpRequest


# Generated at 2022-06-24 14:01:45.236376
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            assert information['filepath'] == 'test_file_name'
            information['test_key'] = 'test_value'
            return [], information

    test_pp = TestPostProcessor()
    test_information = {'filepath': 'test_file_name'}
    test_files, test_information = test_pp.run(test_information)
    assert test_files == []
    assert test_information['test_key'] == 'test_value'
    assert test_information['filepath'] == 'test_file_name'



# Generated at 2022-06-24 14:01:48.407908
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError()
    except AudioConversionError as e:
        assert isinstance(e, PostProcessingError)
        assert not hasattr(e, 'cause')
        assert str(e) == ''

# Generated at 2022-06-24 14:01:58.707033
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    class MockYoutubeDL(YoutubeDL):
        def __init__(self):
            self.my_pp = None
    class MockPostProcessor(PostProcessor):
        def __init__(self):
            super(MockPostProcessor, self).__init__()
            self.downloader = None
    my_pp = MockPostProcessor()
    my_dl = MockYoutubeDL()
    my_dl.add_post_processor(my_pp)
    my_dl.add_post_processor(my_pp)
    my_dl.add_post_processor(my_pp)
    assert my_pp.downloader == None
    my_dl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert my

# Generated at 2022-06-24 14:02:04.861309
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)

        def run(self, info):
            pass

    t = TestPostProcessor()
    assert t._downloader is None
    t.set_downloader('random_string')
    assert t._downloader == 'random_string'

# Generated at 2022-06-24 14:02:13.333601
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time
    import unittest

    from ..utils import (
        DateRange,
        DateRangeLimit
    )

    from .internal import FileDownloader

    class PP(PostProcessor):
        def __init__(self):
            self.set_downloader(FileDownloader(params={}))

    class TestPP(unittest.TestCase):

        def setUp(self):
            self._temp_dir = tempfile.mkdtemp()
            self._temp_file = os.path.join(self._temp_dir, 'test')

        def tearDown(self):
            shutil.rmtree(self._temp_dir)

        def _temp_time(self, delta):
            return time.time() + delta


# Generated at 2022-06-24 14:02:14.592262
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("", "", "")
    except AudioConversionError:
        pass
    else:
        raise

# Generated at 2022-06-24 14:02:24.145910
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    info_dict = {
        'id': 'XbGs_qK2PQA',
        'extractor': 'Youtube',
        'upload_date': '20121002',
        'description': 'md5:3cb8ac60532a3bfe3da1ceb4a46817a6',
        'uploader': 'GoogleDevelopers',
        'title': 'Google I/O 101: Q&A On Using Google APIs',
        'thumbnail': 're:^https?://.*\.jpg$',
        'uploader_id': 'GoogleDevelopers',
        'ext': 'mp4',
        'format': '57'
        }


# Generated at 2022-06-24 14:02:35.048503
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    if sys.platform == 'win32':
        from ..downloader.common import FileDownloader
    else:
        from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import compat_urllib_request, compat_urllib_error

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return ['test']

    class TestInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': url, 'title': 'test'}

    class TestYoutubeIE(YoutubeIE):
        def _real_extract(self, url):
            return {'id': url, 'title': 'test'}

    # M

# Generated at 2022-06-24 14:02:36.531590
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:02:38.789352
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    downloader = Downloader()
    PostProcessor.set_downloader(downloader)

# Generated at 2022-06-24 14:02:42.822646
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError('foo', 'out', 'err', 26, 'details')
    assert exc.exit_code == 26
    assert exc.out == 'out'
    assert exc.err == 'err'
    assert exc.details == 'details'



# Generated at 2022-06-24 14:02:50.054295
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    import sys
    import re
    from ..compat import PY2, compat_urllib_request, compat_urllib_error

    if not PY2:
        from urllib.error import URLError
    else:
        from urllib2 import URLError

    if not sys.platform.startswith('linux'):
        raise SystemExit('test_PostProcessor_try_utime is intended to be run on Linux')

    # Windows has no utime
    class WindowsPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime('/proc/version', 1, 2)  # Use a safe file

    # Execute a PostProcessor on Linux
    WindowsPostProcessor(downloader=None).run(None)

    # Execute a PostProcessor on

# Generated at 2022-06-24 14:02:53.862000
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('message1', 'message2')
    except AudioConversionError as err:
        assert err.message1 == 'message1' and err.message2 == 'message2'
    else:
        assert False

# Generated at 2022-06-24 14:02:59.903447
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import common

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            if self._downloader is None:
                raise Exception('TestPostProcessor has no downloader.')
            return super(TestPostProcessor, self).run(info)

    t = TestPostProcessor()
    d = common.FileDownloader({}, TestPostProcessor())
    t.set_downloader(d)

# Generated at 2022-06-24 14:03:11.093005
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from tempfile import mkstemp
    import time
    import os

    (fd, name) = mkstemp()

    def _test(atime, mtime):
        try:
            os.utime(name, (atime, mtime))
            return True
        except OSError:
            return False

    def _methodtest(downloader, atime, mtime, success):
        p = PostProcessor(downloader)
        p.try_utime(name, atime, mtime, 'should fail')
        downloader.to_stderr.seek(0)
        res = downloader.to_stderr.read()
        downloader.to_stderr.seek(0)
        downloader.to_stderr.truncate()

# Generated at 2022-06-24 14:03:13.872948
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    if pp.__class__.__name__ is not 'PostProcessor':
        print("Error in constructor of PostProcessor.")
    if pp._downloader:
        print("Error in constructor of PostProcessor.")



# Generated at 2022-06-24 14:03:19.738449
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    assert PostProcessor()._downloader is None
    dler = "instantiate YoutubeDL class"
    postprocessor = PostProcessor(dler)
    assert postprocessor._downloader == dler
    postprocessor.set_downloader(None)
    assert postprocessor._downloader is None
    postprocessor.set_downloader(dler)
    assert postprocessor._downloader == dler



# Generated at 2022-06-24 14:03:25.103229
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test PostProcessor.run method"""
    class PP(PostProcessor):
        def run(self, info):
            return [(info['filepath'], info['title']), info]
    pp = PP()
    (files, info) = pp.run({'filepath': 'A', 'ext': 'B', 'title': u'φχ'})
    assert files[0] == ('A', 'φχ')
    assert info['filepath'] == 'A'



# Generated at 2022-06-24 14:03:28.585876
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # example of how to use set_downloader
    class MyPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    pp = MyPostProcessor()
    d = object()
    pp.set_downloader(d)
    assert pp._downloader == d

# Generated at 2022-06-24 14:03:30.625054
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('foo')
    except PostProcessingError as err:
        assert str(err) == 'foo'

# Generated at 2022-06-24 14:03:38.073161
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    try:
        file_path = os.path.join(temp_dir, "test_file")
        file_obj = open(file_path, 'w')
        file_obj.close()
        class Downloader():
            def report_warning(self, msg):
                self.msg = msg
        pp = PostProcessor(downloader=Downloader())
        pp.try_utime(file_path, 1, 2)
        os.remove(file_path)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-24 14:03:40.492862
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    mock_downloader = object()
    pp.set_downloader(mock_downloader)
    assert pp._downloader is mock_downloader


# Generated at 2022-06-24 14:03:50.505615
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # create temporary file
    fd = os.open(encodeFilename('test_PostProcessor_try_utime'), os.O_WRONLY | os.O_CREAT)
    os.close(fd)

    # get current file's time
    fstat = os.stat(encodeFilename('test_PostProcessor_try_utime'))
    atime = fstat.st_atime
    mtime = fstat.st_mtime

    mtime += 20
    atime -= 30

    postprocessor = PostProcessor()
    postprocessor.try_utime('test_PostProcessor_try_utime', atime, mtime)

    fstat = os.stat(encodeFilename('test_PostProcessor_try_utime'))
    assert fstat.st_atime - atime < 1
   

# Generated at 2022-06-24 14:04:00.784290
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader(self, downloader) of PostProcessor

    Test if the PostProcessor has the correct properties after being
    set as an attribute of a downloader.
    """
    # Create a downloader with known parameters and attributes
    from .YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    downloader.params = {'format': 'best'}
    downloader.add_default_info_extractors()

    # Create a PostProcessor
    pp = PostProcessor(downloader)

    # Check for the 'test' format
    assert not hasattr(pp, '_test')

    # Create a 'test' format
    from .extractor import get_info_extractor
    ie = get_info_extractor('Test')

    # Test the existence of the 'test' format
    download

# Generated at 2022-06-24 14:04:09.818093
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_str

    pp1 = PostProcessor(None)
    pp2 = PostProcessor(None)
    pp3 = PostProcessor(None)

    class MyInfo:
        def __init__(self, i):
            self.i = i

        def a_method(self):
            return 3 * self.i

        def a_property(self):
            return 4 * self.i

    class MyDownloader:
        def __init__(self):
            self.pp1 = pp1
            self.pp2 = pp2
            self.pp3 = pp3

    def test_pp3(info):
        info.i *= 5
        return info

    def test_pp2(info):
        info.i *= 7
        return info


# Generated at 2022-06-24 14:04:13.189238
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl.YoutubeDL
    downloader = youtube_dl.YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader
    pp._downloader = None
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:04:24.576943
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import unittest
    import stat
    import time
    import tempfile
    from .YoutubeDL import YoutubeDL
    from .utils import DateRange

    class MyPostProcessor(PostProcessor):
        def run(self, info):
            # Check that try_utime() works for files and directories
            self.try_utime(info['filepath'], int(time.time() - 3600), int(time.time()))
            self.try_utime(os.path.dirname(info['filepath']), int(time.time() - 3600), int(time.time()))
            return []

    class MyLogger(object):
        """A logger that records warnings."""

        def __init__(self):
            self._warnings = []


# Generated at 2022-06-24 14:04:32.276514
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(1, 2, 3, 4, 5, 'foo')
    assert(err.original_file == 1)
    assert(err.format_name == 2)
    assert(err.target_format == 3)
    assert(err.acodec == 4)
    assert(err.audio_codec_name == 5)
    assert(err.video_codec_name == 'foo')



# Generated at 2022-06-24 14:04:43.922102
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..utils import match_filter_func
    downloader = FileDownloader(params={})
    downloader.add_info_extractor(YoutubeIE())
    test_match_filter_func = match_filter_func('youtube', downloader)
    assert downloader.post_processors
    for post_processor in downloader.post_processors:
        assert post_processor._downloader == None
        post_processor.set_downloader(downloader)
        assert post_processor._downloader == downloader
        assert post_processor._downloader.params == downloader.params
        assert post_processor._downloader.match_filter == test_match_filter_func

if __name__ == '__main__':
    test_PostProcess

# Generated at 2022-06-24 14:04:48.578875
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class FakeDownloader():
        def report_warning(self, message):
            pass

    tp = TestPostProcessor(FakeDownloader())
    tp.run({})

# Generated at 2022-06-24 14:04:58.292170
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import stat
    import shutil
    import time
    import sys

    if sys.platform == 'win32':
        return

    curr_time = time.time()
    dirname = tempfile.mkdtemp()

# Generated at 2022-06-24 14:05:08.757211
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    from ..utils import DEFAULT_OUTTMPL
    from .common import PostProcessorTest

    test_filename = 'postprocessor_test'
    new_filename = test_filename + '.new'
    yt_url = 'url'

    class TestPostProcessor(PostProcessorTest):
        def run(self, info):
            assert isinstance(self._downloader, FileDownloader)
            assert self._downloader.params['outtmpl'] == DEFAULT_OUTTMPL % info
            assert self._downloader.params['outtmpl'] == test_filename
            return ([], {'id': 'url', 'title': 'postprocessor_test', 'ext': 'new'})


# Generated at 2022-06-24 14:05:14.751191
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .test_files import _TEST_FILES_PATH

    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    test_file_path = os.path.join(_TEST_FILES_PATH, 'test_video.mp4')
    atime = os.stat(test_file_path).st_atime
    mtime = os.stat(test_file_path).st_mtime
    pp.try_utime(test_file_path, atime, mtime)
    # TODO : Add an assertion

# Generated at 2022-06-24 14:05:19.280455
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ytdl.Downloader import FakeDownloader
    post_processor = PostProcessor()
    fake_downloader = FakeDownloader(downloader_kwargs={'postprocessors': [post_processor]})
    post_processor.set_downloader(fake_downloader)
    assert post_processor._downloader == fake_downloader


# Generated at 2022-06-24 14:05:20.201968
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader == None

# Generated at 2022-06-24 14:05:28.883825
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    t1 = [1, 2, 3]
    t2 = [4, 5, 6]
    t3 = [7, 8, 9]

    class PP1(PostProcessor):
        def run(self, t):
            return (t1, t + t1)

    class PP2(PostProcessor):
        def run(self, t):
            return (t2, t + t2)

    class PP3(PostProcessor):
        def run(self, t):
            return (t3, t + t3)

    pp1 = PP1()
    pp2 = PP2()
    pp3 = PP3()
    pp1.add_post_processor(pp2)
    pp2.add_post_processor(pp3)

    # The chain is pp1->pp2->pp3

# Generated at 2022-06-24 14:05:35.288607
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    # Test Postprocessor set_downloader
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPP, self).__init__(downloader)
            self._downloader = downloader
    t = TestPP()
    t.set_downloader(YoutubeDL())
    assert t._downloader is not None


# Generated at 2022-06-24 14:05:38.360955
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test for PostProcessor constructor."""
    # pylint: disable=protected-access
    pp = PostProcessor()
    assert pp._downloader is None

# Generated at 2022-06-24 14:05:44.118693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..compat import windows_stdout_errors

    if windows_stdout_errors == 'replace':
        import pytest

        errnote = 'Cannot update utime of file'
        pa_error = PostProcessor()
        pa_error.set_downloader(object())

        with pytest.raises(IOError):
            pa_error.try_utime(os.devnull, None, None, errnote)

# Generated at 2022-06-24 14:05:46.514956
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:47.686414
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    a_pp = PostProcessor()
    assert a_pp

# Generated at 2022-06-24 14:05:48.208119
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:05:49.094317
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:55.514007
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MyPP(PostProcessor):
        def __init__(self, downloader):
            self.downloader = downloader
        def run(self, info):
            self.try_utime('file', 1, 2, 'error')

    my_pp = MyPP(None)
    my_pp.run(None)

# Generated at 2022-06-24 14:05:57.349652
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    ydl = PostProcessor()

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:06:05.945566
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_HTTPError
    from ..downloader import FakeYDL
    from ..extractor.common import InfoExtractor

    # Create a fake downloader
    downloader = FakeYDL()
    downloader.params.update({
        'outtmpl': '%(id)s',
        'quiet': True,
    })

    # Create dummy InfoExtractor object and add it to downloader
    class DummyIE(InfoExtractor):
        _VALID_URL = r'(?i)^https?://.*\.webm$'

# Generated at 2022-06-24 14:06:13.266845
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_downloader import FakeYDL
    from .test_downloader_http import DateRangeHTTPRequestHandler

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            self.try_utime('', 0, 0)
            return [], info

    ydl = FakeYDL(handler=DateRangeHTTPRequestHandler)
    TestPostProcessor(ydl).run({})
    assert ydl.report_warnings == ["Cannot update utime of file"]

# Generated at 2022-06-24 14:06:16.945619
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    downloader = FileDownloader()
    pp = PostProcessor(downloader)
    pp.set_downloader(None)
    assert pp._downloader == None
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:06:19.716078
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:06:28.917021
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # PostProcessor class is an abstract class
    # To test method run, a subclass is needed
    class DummyPostProcessor(PostProcessor):
        def run(self, information):
            # A dummy postprocessor alway return the same value
            return 'foo', information

    # An instance of DummyPostProcessor is created
    postprocessor = DummyPostProcessor()
    # PostProcessor need a downloader objet to be able to display message
    downloader = object()
    postprocessor.set_downloader(downloader)

    # To test method run, a information dictionnary is needed

# Generated at 2022-06-24 14:06:36.825812
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .utils import DownloadContext

    class FakePostProcessor(PostProcessor):
        def run(self, information):
            atime = information.get('atime')
            mtime = information.get('mtime')
            filename = information.get('filepath')
            self.try_utime(filename, atime, mtime)

            return [], information

    dl = DownloadContext(supported=['dummy'], params={})

    information={'filepath': 'dummy_file', 'atime': '12345678', 'mtime': '12345678'}
    pp = FakePostProcessor(dl)
    [], information = pp.run(information)
    assert information['filepath'] == encodeFilename(information['filepath'])

# Generated at 2022-06-24 14:06:48.978851
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    downloader = Downloader()

    from .common import FilePostProcessor
    file_pp = FilePostProcessor(downloader)

    import time
    import stat
    import os

    test_file_name = 'test.file'
    test_file = open(test_file_name, 'w')
    test_file.close()


# Generated at 2022-06-24 14:06:53.132914
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # set_downloader(downloader)
    # set_downloader should set the downloader for this PP.
    pp = PostProcessor()
    downloader = object()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-24 14:07:03.435088
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader method of class PostProcessor.
    """
    import os
    test_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'PostProcessor.py')

    from ..configuration import Configuration
    from ..downloader import Downloader
    from ..compat import compat_etree_fromstring
    from ..extractor import gen_extractors
    from ..postprocessor import gen_postprocessors

    ydl_opts = {
        'format': 'best',
        'skip_download': True,
    }
    cfg = Configuration(ydl_opts)


# Generated at 2022-06-24 14:07:05.120904
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test method set_downloader of class PostProcessor.
    """
    d = object()
    pp = PostProcessor()
    pp.set_downloader(d)
    assert pp._downloader is d

# Generated at 2022-06-24 14:07:07.713605
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor({})
    files_to_delete, information = pp.run({'filepath': 'testfile'})
    assert files_to_delete == []
    assert information == {'filepath': 'testfile'}

# Generated at 2022-06-24 14:07:14.081480
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('input.ogg', 'output.mp3', 2, 'ffmpeg says something went wrong')
    except AudioConversionError as err:
        assert err.source == 'input.ogg'
        assert err.dest == 'output.mp3'
        assert err.exit_code == 2
        assert err.msg == 'ffmpeg says something went wrong'
        assert str(err) == 'ffmpeg says something went wrong'

# Generated at 2022-06-24 14:07:19.605253
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockDownloader(object):
        def __init__(self):
            self.is_mock_downloader = True

    ydl = MockDownloader()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl

    pp2 = PostProcessor()
    pp2.set_downloader(ydl)
    assert pp2._downloader == ydl



# Generated at 2022-06-24 14:07:30.864211
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .fake_filesystem_unittest import TestCase
    from .test_utils import FakeYDL

    class TestPostProcessor(PostProcessor):
        pass

    ydl = FakeYDL()
    pp = TestPostProcessor()
    pp.set_downloader(ydl)

    class MyTest(TestCase):
        def setUp(self):
            self.setUpPyfakefs()

        def test_PostProcessor_try_utime(self):
            os.makedirs(os.path.dirname(u'foo/bar.txt'))
            with open(u'foo/bar.txt', 'w') as f:
                f.write('Hello World!')

            # File exists, utime works:
            pp.try_utime('foo/bar.txt', 0, 0)

# Generated at 2022-06-24 14:07:35.249728
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return ['file1', 'file2'], info
    pp = DummyPostProcessor()
    assert (['file1', 'file2'], {'key': 'value'}) == pp.run({'key': 'value'})


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-24 14:07:36.157671
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:07:45.821873
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class TestPostProcessor(PostProcessor):

        def __init__(self, downloader=None):
            self.test_path = None
            self.test_atime = None
            self.test_mtime = None
            self.test_errnote = None

            self.called_utime = False

            PostProcessor.__init__(self, downloader=downloader)


        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.test_path = path
            self.test_atime = atime
            self.test_mtime = mtime
            self.test_errnote = errnote

            self.called_utime = True
            return True



# Generated at 2022-06-24 14:07:49.804204
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    fd = FileDownloader(params={})
    pp = PostProcessor(downloader=fd)
    pp.try_utime(None, 1, 2)

# Generated at 2022-06-24 14:08:00.908365
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import stat
    import time
    import pytest
    from tempfile import mkstemp
    # Create a file
    fd, fpath = mkstemp()
    t = time.time() - 60
    os.utime(fpath, (t, t))
    # Confirm that this file's modify time was updated
    assert stat.S_IFMT(os.stat(fpath).st_mode) == stat.S_IFREG
    assert os.stat(fpath).st_mtime == pytest.approx(t, abs=1)
    # Create a PostProcessor instance
    pp = PostProcessor(downloader=None)
    pp.try_utime(fpath, t, t + 120)
    # Confirm that this file's modify and access times were updated

# Generated at 2022-06-24 14:08:12.241687
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    # TODO: this method is not used anywhere and can be removed in Python 3.
    # Unfortunately it introduces a backwards-incompatible change in Python 2
    #   https://github.com/rg3/youtube-dl/issues/10738
    # So it is not safe to remove in the Python 2 series.
    #
    # This can be removed once we drop Python 2 support.

    from ..extractor.common import InfoExtractor
    from ..utils import FileDownloader

    class MockPostProcessor(PostProcessor):
        NAMES = ['mock']

        def run(self, info):
            return [], info

    class MockInfoExtractor(InfoExtractor):
        IE_NAME = 'MockInfoExtractor'
        IE_DESC = 'Mock info extractor'


# Generated at 2022-06-24 14:08:13.467868
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class.
    """
    PostProcessor()

# Generated at 2022-06-24 14:08:14.985642
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    msg = "An error"
    err = AudioConversionError(msg)
    assert err.msg == msg, err.msg

# Generated at 2022-06-24 14:08:16.811421
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class DummyPP(PostProcessor):
        def run(self, info):
            return info
    pp = DummyPP()
    assert pp is not None

# Generated at 2022-06-24 14:08:18.797357
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(1, 2, 3)
    assert err.original_error == 1
    assert err.codec == 2
    assert err.target == 3

# Generated at 2022-06-24 14:08:22.089003
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor()
    info = {}
    assert (None, info) == pp.run(info)

if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-24 14:08:25.228434
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    pp.set_downloader(ydl)
    assert ydl == pp._downloader

# Generated at 2022-06-24 14:08:30.815472
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Tests if PostProcessors are correctly chained."""

    class TestPP1(PostProcessor):
        def run(self, info):
            assert(info['in'] == 0)
            assert('out1' not in info)
            info['out1'] = info['in'] + 1
            return [], info

    class TestPP2(PostProcessor):
        def run(self, info):
            assert(info['in'] == 0)
            assert(info['out1'] == 1)
            assert('out2' not in info)
            info['out2'] = info['out1'] + 1
            return [], info

    orig = {'in': 0}
    t1 = TestPP1(None)
    t2 = TestPP2(None)
    t1.run(orig)

# Generated at 2022-06-24 14:08:32.857778
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass
    else:
        assert False

# Generated at 2022-06-24 14:08:40.642666
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader = None):
            PostProcessor.__init__(self, downloader)
        def run(self, information):
            return []
    class TestDownloader:
        ydl = None
        def __init__(self):
            self.ydl = TestPostProcessor()
            self.ydl.set_downloader(self)
    test_downloader = TestDownloader()
    assert(test_downloader.ydl._downloader == test_downloader)

# Generated at 2022-06-24 14:08:46.871905
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.downloader_set = False

        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            self.downloader_set = True

        def run(self, information):
            return [], information

    pp = TestPostProcessor()
    assert not pp.downloader_set
    from youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    pp.set_downloader(dl)
    assert pp.downloader_set

# Generated at 2022-06-24 14:08:51.558776
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def run(self, information):
            pass

    pp = FakePostProcessor()
    path = 'a.txt'
    atime = 1
    mtime = 1
    errnote = "test"
    pp.try_utime(path, atime, mtime, errnote=errnote)

# Generated at 2022-06-24 14:08:57.580838
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    from .compat import unittest

    from .test_postprocessor import _PostProcessorTest

    class TestPostProcessor_try_utime(unittest.TestCase):
        postprocessor_module_name = 'PostProcessor'

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix=self.__class__.__name__)
            self.filename = os.path.join(self.tmpdir, 'foo.txt')
            with open(self.filename, 'w') as f:
                f.write('Test file')

        def tearDown(self):
            import shutil

            shutil.rmtree(self.tmpdir)

        def test_try_utime(self):
            import os


# Generated at 2022-06-24 14:08:59.799011
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError("test")
    AudioConversionError("test", downloader=None)
    AudioConversionError("test", downloader={})


# Generated at 2022-06-24 14:09:08.030763
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Tests for method run of class PostProcessor"""

    class MockInfoExtractor(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def extract(self, url):
            return self.ie_result

    class MockYoutubeDL(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result

        def extract_info(self, url, download=True):
            return self.ie_result

    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None, pp_result=None):
            PostProcessor.__init__(self, downloader)
            self.pp_result = pp_result
            self.run_calls = []


# Generated at 2022-06-24 14:09:10.805833
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:12.189083
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    test = AudioConversionError('test message')
    assert('test message' in str(test))



# Generated at 2022-06-24 14:09:16.868455
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    # tests the return value of PostProcessor.run()
    class TestPP(PostProcessor):
        def run(self, info):
            return ['test.file'], info
    test_pp = TestPP()
    test_dir = tempfile.mkdtemp()
    test_filepath = os.path.join(test_dir, 'test.mp4')
    info = {'filepath': test_filepath}
    files_to_delete, new_info = test_pp.run(info)
    assert files_to_delete == ['test.file']
    assert info == new_info

# Generated at 2022-06-24 14:09:18.006218
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:09:20.816653
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YtdlHooks import YoutubeDL
    pp = PostProcessor(downloader=None)
    ydl = YoutubeDL(params={})
    pp.set_downloader(ydl)
    assert ydl == pp._downloader

# Generated at 2022-06-24 14:09:22.803577
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postprocessor = PostProcessor()
    assert postprocessor

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:27.991960
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """test the method set_downloader of class PostProcessor"""

    from ..YoutubeDL import YoutubeDL
    from .ffmpeg import FFmpegPostProcessor

    post_processor = FFmpegPostProcessor()

    post_processor.set_downloader(YoutubeDL())

    assert post_processor._downloader == YoutubeDL()

# Generated at 2022-06-24 14:09:33.221634
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class PP(PostProcessor):

        def run(self, information):
            return [], information

    pp = PP()

    # Check with empty dict
    information = {}

    files, information = pp.run(information)

    assert files == []
    assert information == {}

# Generated at 2022-06-24 14:09:42.530567
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import mkstemp
    from .YoutubeDL import YoutubeDL
    from .compat import get_filesystem_encoding
    from .infoextractor import InfoExtractor
    from .utils import DateRange
    import time

    with YoutubeDL(params={
        'format': 'best',
        'forcetitle': True,
        'outtmpl': u'%(id)s_%(title)s.%(ext)s',
        'extractaudio': True,
        'audioformat': 'best',
        'audio_nopostoverwrites': True,
        'writethumbnail': True,
        'noplaylist': True,
        'quiet': True}) as ydl:
        # Create a file
        testfile = mkstemp(suffix='.flv')[1]
        # Write

# Generated at 2022-06-24 14:09:44.388981
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('test message')
    assert error.args[0] == 'test message'
    error = AudioConversionError(object())
    assert error.args[0] is object()

# Generated at 2022-06-24 14:09:47.073156
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('something')
    except AudioConversionError as e:
        assert str(e) == 'something'
    else:
        raise


# Generated at 2022-06-24 14:09:50.381234
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as e:
        assert str(e) == 'test'


# Generated at 2022-06-24 14:09:52.292841
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader == None
    pp.set_downloader('downloader')
    assert pp._downloader == 'downloader'


# Generated at 2022-06-24 14:09:53.968389
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    class MyAudioConversionError(AudioConversionError):
        pass
    assert MyAudioConversionError('foo') == 'foo'

# Generated at 2022-06-24 14:09:55.799931
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('audio conversion failed')
    except AudioConversionError as e:
        assert isinstance(e, PostProcessingError)
test_AudioConversionError()

# Generated at 2022-06-24 14:09:56.227012
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:10:08.020145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import pytest
    from ..utils import DateRange, FileDownloader

    class MockDateRange(DateRange):
        def unix2date(self, timestamp):
            return timestamp

        def date2unix(self, inputDate):
            return inputDate

    class MockDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            with open(filename, 'w') as outf:
                outf.write('test')

        def report_warning(self, message):
            raise AudioConversionError(message)


    downloader = MockDownloader()
    downloader.params['writedescription'] = False
    downloader.params['restrictfilenames'] = True
    downloader.params['writesubtitles'] = False
    downloader.params['nooverwrites'] = False



# Generated at 2022-06-24 14:10:08.633669
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:10:17.665387
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    from .downloader import FakeYDL

    class FakeFile(object):
        def __init__(self, path):
            self.path = path

    class PPStub(PostProcessor):
        def run(self, information):
            tmpdir = tempfile.mkdtemp(prefix='youtubedl-test_')
            self.try_utime(os.path.join(tmpdir, 'cant_touch_this.txt'), 0, 0)
            shutil.rmtree(tmpdir)
            return [], information

    with FakeYDL({}) as ydl:
        fd, fname = tempfile.mkstemp(suffix='.mp4')
        os.close(fd)

# Generated at 2022-06-24 14:10:20.350321
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    postProcessor = PostProcessor()
    assert postProcessor.downloader is None

    downloader = type('', (), {})()
    postProcessor.set_downloader(downloader)
    assert postProcessor.downloader is downloader

# Generated at 2022-06-24 14:10:31.162956
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create an instace of PostProcessor
    postprocessor = PostProcessor()
    # Create an instace of FakeYDL
    from ..YoutubeDL import YoutubeDL
    from ..extractor import (
        gen_extractors,
        list_extractors,
        get_extractor,
        get_info_extractor,
        get_info_extractors,
    )
    ydl = YoutubeDL(params={'noplaylist': True, 'quiet': True, 'simulate': True})
    # Set the downloader to our FakeYDL class
    postprocessor.set_downloader(ydl)
    # Make sure the downloader was set
    assert postprocessor._downloader == ydl, 'Downloader not set correctly'
    # See if youtube-dl modules still work correctly