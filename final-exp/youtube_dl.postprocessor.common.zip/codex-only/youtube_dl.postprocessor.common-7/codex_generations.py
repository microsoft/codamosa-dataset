

# Generated at 2022-06-24 14:00:28.630467
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    PP = PostProcessor()
    try:
        PP.try_utime(None, 0, 0, None)
    except PostProcessingError:
        pass
    try:
        PP.try_utime('/no/file/existent', 0, 0, None)
    except PostProcessingError:
        pass
    try:
        PP.try_utime('/no/file/existent', 0, 0, 'Custom Error')
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:00:31.170337
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('a', b='c')
    except AudioConversionError as err:
        assert err.conversion_type == 'a'
        assert err.original_message == 'c'
        assert err.args[0] == 'Audio conversion failed: c'



# Generated at 2022-06-24 14:00:35.406593
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Check if we can set the value of self._downloader of class PostProcessor."""
    class TestPostProcessor(PostProcessor):
        pass
    TestPostProcessor_instance = TestPostProcessor()
    try:
        TestPostProcessor_instance.set_downloader(None)
    except NotImplementedError:
        pass
    assert TestPostProcessor_instance._downloader == None, 'self._downloader of class PostProcessor has not been set.'

# Generated at 2022-06-24 14:00:37.037040
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    def _run(self, information):
        return information

    import types
    PostProcessor.run = types.MethodType(_run, None, PostProcessor)



# Generated at 2022-06-24 14:00:43.039321
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    def test_equal(a, b):
        assert a == b and b == a and hash(a) == hash(b)

    test_equal(
        AudioConversionError('foo', 'bar', 'baz'),
        AudioConversionError('foo', 'bar', 'baz'))

    test_equal(
        AudioConversionError('foo', 'bar', 'baz'),
        AudioConversionError('foo', 'bar', ['baz']))

    test_equal(
        AudioConversionError('foo', 'bar', 'baz'),
        AudioConversionError('foo', 'bar', tuple(['baz'])))

    test_equal(
        AudioConversionError('foo', 'bar', ['baz', 'qux']),
        AudioConversionError('foo', 'bar', tuple(['baz', 'qux'])))

# Generated at 2022-06-24 14:00:46.706812
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Test default constructor
    processor = PostProcessor()
    assert processor is not None

    # Test constructor with downloader
    processor = PostProcessor(downloader=None)
    assert processor is not None

test_PostProcessor()

# Generated at 2022-06-24 14:00:49.649498
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader('downloader0')
    assert pp._downloader == 'downloader0'

# Generated at 2022-06-24 14:01:00.566725
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class downloader:
        def report_warning(self, errnote):
            pass

    class pp:
        def __init__(self, downloader):
            self._downloader = downloader

        def try_utime(self, path, atime, mtime, errnote):
            return downloader.try_utime(self, path, atime, mtime, errnote)

    pp = pp(downloader())
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_try_utime.txt')

# Generated at 2022-06-24 14:01:11.064885
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import types
    import unittest

    def simple(v):
        return [], dict(filepath=v)

    def raise_exception(v):
        raise StandardError('test of exception')

    class TestPP(PostProcessor):
        def run(self, information):
            return simple(information['filepath'])

    class TestPPException(PostProcessor):
        def run(self, information):
            return raise_exception(information['filepath'])

    class TestPPExit(PostProcessor):
        def run(self, information):
            sys.exit()

    class TestPPExitCode(PostProcessor):
        def run(self, information):
            sys.exit(2)


# Generated at 2022-06-24 14:01:15.262814
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    from ..compat import compat_str

    assert compat_str(test_PostProcessor_set_downloader.__doc__, 'utf-8') == 'test_PostProcessor_set_downloader'

    pp = PostProcessor(Downloader())
    assert isinstance(pp._downloader, Downloader)
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-24 14:01:21.751613
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL
    import tempfile
    tmpfd, tmpfname = tempfile.mkstemp()
    info = {
        'id': 'video',
        'ext': 'ogg',
        'title': 'video',
        'url': 'http://example.com/video',
        'uploader': 'someone',
        'upload_date': 'today',
        'duration': 60,
        'filepath': tmpfname,
        'format': 'video-format',
        'thumbnail': 'http://example.com/thumbnail.jpg',
    }

    def side_effect_downloader_report_warning(message):
        raise Exception(message)
    def side_effect_downloader_report_error(message):
        raise Exception(message)


# Generated at 2022-06-24 14:01:26.571176
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    ' Test class PostProcessor and method _set_downloader '
    test_downloader = PostProcessor()
    test_downloader.set_downloader('sample_downloader')
    assert test_downloader._downloader == 'sample_downloader'
    return

# Generated at 2022-06-24 14:01:36.349840
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    dirpath = tempfile.mkdtemp(prefix='youtube-dl-utime-')
    filepath = os.path.join(dirpath, 'foo')

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            # get old timestamp
            a = b = os.path.getmtime(filepath)
            # wait 1 second
            time.sleep(1)
            # set timestamp to one second ago
            self.try_utime(path=filepath, atime=a, mtime=b)
            return ([], info)

    p = TestPostProcessor()

    # get old timestamp
    a = b = time.time()
    # wait 1 second
    time.sleep(1.0)
    # create a file that has old timestamp

# Generated at 2022-06-24 14:01:43.460658
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    downloader = FileDownloader()
    postProcessor = FFmpegMetadataPP(downloader)
    assert(postProcessor._downloader == downloader)
    assert(downloader._postprocessors == [postProcessor])
    downloader2 = FileDownloader()
    postProcessor.set_downloader(downloader2)
    assert(postProcessor._downloader == downloader2)
    assert(downloader2._postprocessors == [postProcessor])
if __name__ == '__main__':
    test_PostProcessor_set_downloader()
    print('Test passed!')

# Generated at 2022-06-24 14:01:43.961992
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:01:52.170909
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    '''
    Test the function _set_downloader of class PostProcessor.
    '''
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from .common import FileDownloader

    downloader = Downloader()
    fd = FileDownloader(downloader, {'outtmpl': '%(id)s'})
    fd.add_info_extractor(YoutubeIE())
    fd.add_post_processor(PostProcessor())
    fd._real_download(
        {'id': '0'}, YoutubeIE('https://www.youtube.com/watch?v=0'))
    downloader.close()

# Generated at 2022-06-24 14:01:54.570656
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())
    assert pp._downloader == YoutubeDL()

# Generated at 2022-06-24 14:02:02.134487
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Dummy PostProcessor
    class DummyPP(PostProcessor):
        def run(self, information):
            return [], information
    pp = DummyPP()

    # try_utime should be a class method, so we need to bind it
    # to the class first.
    bound_try_utime = pp.try_utime
    import sys
    if sys.version_info < (3,):
        import types
        bound_try_utime = types.MethodType(bound_try_utime, pp)

    # Create a dummy file
    import tempfile
    try:
        f = tempfile.NamedTemporaryFile(delete=False)
        filename = f.name
    finally:
        f.close()

    # utime() shouldn't throw exception here
    import time
    bound_try_ut

# Generated at 2022-06-24 14:02:07.835601
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl #pylint:disable=protected-access
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl #pylint:disable=protected-access

# Generated at 2022-06-24 14:02:09.837329
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyDownloader():
        def report_warning(self, warning):
            self.warning = warning
    PP = PostProcessor(DummyDownloader())
    PP.try_utime('path', 0, 0)

# Generated at 2022-06-24 14:02:14.645965
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader method of class PostProcessor.
    """
    # Create a PostProcessor instance
    pp = PostProcessor(None)
    # Check that downloader is None
    assert pp._downloader is None
    # Create a downloader instance
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({'verbose': True})
    # set the downloader for the PostProcessor instance
    pp.set_downloader(ydl)
    # Check that downloader is the same one
    assert pp._downloader is ydl

# Generated at 2022-06-24 14:02:17.716147
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    ac = AudioConversionError('error message', 'filename', 123)
    assert ac.msg == 'error message'
    assert ac.filename == 'filename'
    assert ac.duration == 123



# Generated at 2022-06-24 14:02:21.242803
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    ie = YoutubeIE(downloader)
    downloader.add_info_extractor('YoutubeIE', ie)
    ie.add_post_processor(pp)

# Generated at 2022-06-24 14:02:27.715682
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .test_downloader import TDownloader
    # pylint: disable=protected-access

    # Mock downloader
    def mock_report_warning(d, msg):
        # pylint: disable=unused-argument
        d._warning_count += 1
    downloader = TDownloader()
    downloader.params = {}
    downloader._warning_count = 0
    downloader.report_warning = mock_report_warning

    PostProcessor._downloader = downloader  # pylint: disable=protected-access

    # Mock a filepath
    filepath = 'test-file-path'

    # If os.utime raises any exception, the warning should be shown

# Generated at 2022-06-24 14:02:39.358882
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    import tempfile
    import time

    # create temporary file
    fp = tempfile.NamedTemporaryFile(delete=False)
    fp.close()
    # copy the file to the same location (to get the same inode and thus
    # the same metadata)
    # shutil.copy2 is not used since it copies the content of the file
    shutil.copyfile(fp.name, fp.name + '.copy')
    # delete the original file
    os.unlink(fp.name)
    # rename the copy to the original file's name
    os.rename(fp.name + '.copy', fp.name)

    # get the original file's access and modification times
    stat_result = os.stat(fp.name)
    atime = stat_result.st_atime
   

# Generated at 2022-06-24 14:02:42.591855
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    class TestDownloader(object):
        pass
    td = TestDownloader()
    pp.set_downloader(td)
    assert pp._downloader is td

# Generated at 2022-06-24 14:02:43.891808
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    post = PostProcessor()
    post.set_downloader('downloader')
    assert post._downloader == 'downloader'

# Generated at 2022-06-24 14:02:56.044918
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    import pytest
    from ..compat import compat_os_name
    from ..utils import PostProcessor

    pp = PostProcessor(downloader=None)

    # Skip the test on Windows
    if compat_os_name == 'nt':
        pytest.skip()

    def utime_example(self, path, atime, mtime, errnote='Cannot update utime of file'):
        try:
            os.utime(path, (atime, mtime))
        except Exception:
            print(errnote)

    @pytest.fixture(autouse=True)
    def setup(self):
        self.tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-24 14:02:58.443317
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('hello', 'world')
    except AudioConversionError as e:
        assert str(e) == 'hello: "world".'

# Generated at 2022-06-24 14:03:09.520159
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    from ..Downloader import FakeDownloader
    from . import formats
    from .AudioConversion import AudioConverterError

    test_file = tempfile.NamedTemporaryFile(suffix='.mp4')
    file_timestamp = int(time.time())
    test_file.write(b'blabla bla')
    test_file.file.flush()
    pp = formats.postprocessors[0](FakeDownloader())
    pp.try_utime(test_file.name, file_timestamp, file_timestamp, 'foo')

# Generated at 2022-06-24 14:03:10.500356
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

# Generated at 2022-06-24 14:03:20.140845
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import sys
    import tempfile
    from ..extractor.common import InfoExtractor
    from ..utils import prepend_extension
    from ..downloader.common import FileDownloader

    # Create temporary file
    tmpfd, tmpfname = tempfile.mkstemp(prefix='youtubedl-test_')
    os.close(tmpfd)

    # Create a FileDownloader
    fd = FileDownloader({})
    fd.params['outtmpl'] = tmpfname

    # Test PostProcessor.set_downloader
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return ([tmpfname], None)

    ie = InfoExtractor()
    ie.add_info_extractor(_test_IE)
    ie.add_post_processor(TestPostProcessor)


# Generated at 2022-06-24 14:03:22.648913
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class MyPP(PostProcessor):
        def run(self, information):
            return [], information
    pp = MyPP()
    assert pp.__class__.__name__ == 'MyPP'

# Generated at 2022-06-24 14:03:29.532519
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # monkey-patching is used because we cannot create instance of class PostProcessor without filling in all parameters
    def patched_encodeFilename(path):
        return path

    def patched_report_warning(errnote):
        pass

    import sys
    import stat
    import time
    import tempfile
    import shutil
    import unittest

    class PostProcTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            # simulate that PostProcessor is an instance of class PostProcessor
            PostProcessor.encodeFilename = patched_encodeFilename
            PostProcessor.report_warning = patched_report_warning
            PostProcessor.params = {'outtmpl': self.tempdir+'/%(title)s.%(ext)s'}
           

# Generated at 2022-06-24 14:03:30.239806
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:03:32.615483
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a=AudioConversionError(msg='test message', outfile='test_file', errcode=1, stdout='stdout message', stderr='stderr message')


# Generated at 2022-06-24 14:03:34.866858
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('foo', 1, 'bar')
    assert e.outfile == 'foo'
    assert e.errcode == 1
    assert str(e) == 'bar'
    assert e.stdout == e.stderr == None



# Generated at 2022-06-24 14:03:36.732452
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('abc', 'def', 'ghi').args == ('abc', 'def', 'ghi')



# Generated at 2022-06-24 14:03:37.780636
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # Just create a PostProcessor instance
    pp = PostProcessor()


# Generated at 2022-06-24 14:03:40.989551
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor(None)
    pp.set_downloader(1)
    result = pp._downloader
    expected_result = 1
    if result != expected_result:
        raise AssertionError('Value of _downloader is {result}. Expected {expected_result}'.format(result=result, expected_result=expected_result))


# Generated at 2022-06-24 14:03:43.095562
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    post_processor = PostProcessor()
    assert post_processor != None, 'Can not instantiate PostProcessor object'
    assert post_processor.run != None, 'PostProcessor must have "run" method'

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:03:44.752642
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:03:47.494872
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Checks correct construction of AudioConversionError
    """
    try:
        raise AudioConversionError('test')
    except AudioConversionError as exc:
        assert str(exc) == 'test'
    else:
        assert False, 'AudioConversionError not raised'

# Generated at 2022-06-24 14:03:52.187993
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(downloader=ydl)
    assert pp._downloader == ydl
    pp.set_downloader(None)
    assert pp._downloader is None


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:03:57.854094
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    post_processor = PostProcessor(ydl)
    assert post_processor._downloader == ydl

    from youtube_dl.utils import FakeYDL

    fake_downloader = FakeYDL()
    post_processor.set_downloader(fake_downloader)
    assert post_processor._downloader == fake_downloader

# Generated at 2022-06-24 14:04:05.948105
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile
    import shutil
    import os
    from ..compat import compat_HTTPError

    # Creating an empty temporary directory
    tmp_directory = tempfile.mkdtemp()
    # Creating a temporary 'post-processor'
    class EmptyPP(PostProcessor):
        def run(self, info):
            return [info['filepath']], info

    pp = EmptyPP()
    # Creating a fake 'file' (empty)
    real_file = tempfile.NamedTemporaryFile(dir=tmp_directory, delete=False)
    # Creating a fake 'downloader'
    class FakeDownloader(object):
        params = {'outtmpl': tmp_directory + '%(title)s-%(id)s.%(ext)s'}
        def report_warning(self, msg):
            pass
       

# Generated at 2022-06-24 14:04:13.426704
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    if sys.version_info[0] == 3:
        return  # No utime test on Python 3 - it's always failing
    import time
    import datetime
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    from ..downloader import FakeYDL
    ydl = FakeYDL()
    from ..extractor import get_info_extractor
    test_file = 'http://repo.lab.fi-ware.org/webdav/demobrowser/DemoBrowser_video.mp4'
    test_file_ie = get_info_extractor(test_file, ydl)
    test_file_ie.extract(test_file)
    test_file_path = ydl.prepare_filename

# Generated at 2022-06-24 14:04:15.937644
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def run(self, information):
            return [], information
    pp = TestPostProcessor()
    from ..extractor import YoutubeDL
    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:04:25.276331
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import tempfile

    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange

    class DummyDownloader(object):
        def __init__(self):
            self._ies = [YoutubeIE()]
            self.params = {
                'nooverwrites': True,
                'format': 'bestaudio/best',
                'outtmpl': '%(title)s.%(ext)s',
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
            }

        def to_screen(self, s):
            pass

        def to_stdout(self, s):
            pass

        def to_stderr(self, s):
            pass



# Generated at 2022-06-24 14:04:28.405465
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    pp = PostProcessor(None)
    pp.set_downloader(youtube_dl.YoutubeDL())
    assert not pp._downloader

# Generated at 2022-06-24 14:04:37.852541
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import tempfile
    import os
    import shutil
    from ..utils import PostProcessor

    def _test_case(path, xst_res, xch_res):
        pp = PostProcessor(None)
        if xst_res:
            if os.path.exists(path):
                st_atime = os.stat(path).st_atime
                st_mtime = os.stat(path).st_mtime
            else:
                st_atime = -1
                st_mtime = -1
            pp.try_utime(path, st_atime, st_mtime)
            if os.path.exists(path):
                ch_atime = os.stat(path).st_atime
                ch_mtime = os.stat(path).st_mtime

# Generated at 2022-06-24 14:04:49.561110
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request

    class MockInfoExtractor(object):
        def __init__(self, downloader, ie_key, ie_obj):
            self._downloader = downloader
            self.ie_key = ie_key
            self.ie_obj = ie_obj

        def extract(self, url):
            return {'id': 'test', 'ext': 'flv', 'title': 'test', 'url': url, 'extractor': self.ie_key, 'extractor_key': self.ie_obj.IE_NAME}

    class MockYoutubeIE(object):
        IE_NAME = 'Youtube'

    class MockPostProcessor1(PostProcessor):
        def run(self, info):
            return [], info


# Generated at 2022-06-24 14:04:56.107766
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MyPostProcessor(PostProcessor):
        def run(self, info):
            return ['this', 'is', 'a', 'test'], info

    pp = MyPostProcessor()
    info = {'id': 'test_id', 'title': 'test_title', 'url': 'test_url'}
    to_delete, new_info = pp.run(info)
    assert to_delete == ['this', 'is', 'a', 'test']
    assert new_info == info

# Generated at 2022-06-24 14:05:01.821738
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class AlwaysNonNonePP(PostProcessor):
        def run(self, information):
            return [], information

    class AlwaysNonePP(PostProcessor):
        def run(self, information):
            return None

    pp = PostProcessor()
    assert pp.run('abc') is None
    assert pp.run(None) is None
    assert AlwaysNonNonePP().run('abc') == ([], 'abc')
    assert AlwaysNonNonePP().run(None) == ([], None)
    assert AlwaysNonePP().run('abc') is None
    assert AlwaysNonePP().run(None) is None

# Generated at 2022-06-24 14:05:08.317755
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test import get_test_data
    from ..utils import sanitize_open

    path = get_test_data()
    pp = PostProcessor(None)
    with sanitize_open(path, 'r+') as (outfd, _):
        pp.try_utime(path, 1, 1)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-24 14:05:10.447547
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    e = AudioConversionError('error')
    assert e.args[0] == 'error'

# Generated at 2022-06-24 14:05:17.348969
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Mock class
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def run(self, information):
            return self.try_utime('', 0, 0)

    # Initialize classes
    downloader = object()
    pp = MockPostProcessor(downloader)
    pp._downloader.report_warning = lambda x: None

    # Test
    pp.run([])

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-24 14:05:18.980949
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError:
        pass

# Generated at 2022-06-24 14:05:25.723954
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..extractor import gen_extractors
    ydl = type('', (object,), {'params': {}})
    ydl.params['prefer_ffmpeg'] = False
    ydl.params['postprocessor_args'] = None
    ydl.params['logger'] = type('', (object,), {'warning': print})
    ydl.params['extractors'] = gen_extractors(ydl)
    pp = PostProcessor(ydl)


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:28.305602
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    downloader = None
    pp.set_downloader(downloader)
    # Do test
    assert pp._downloader == downloader



# Generated at 2022-06-24 14:05:30.416113
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(msg="msg")
    except AudioConversionError as e:
        assert e.msg == 'msg'

# Generated at 2022-06-24 14:05:31.686930
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    AudioConversionError("")

# Generated at 2022-06-24 14:05:42.562674
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPostProcessor(PostProcessor):
        """A dummy PostProcessor subclass used
        in the tests below."""

        def run(self, information):
            information['title'] = 'Test'
            return [], information


# Generated at 2022-06-24 14:05:47.183699
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = TestPP()
    pp.set_downloader(object())

    assert pp._downloader is not None

# Generated at 2022-06-24 14:05:55.523718
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # We don't have to test os.utime calls in other methods

    import tempfile
    import time

    # Create temporary file
    _, path = tempfile.mkstemp()

    # We make a fake downloader without real logger
    class FakeDownloader():
        def __init__(self):
            self.params = { 'nooverwrites': True }

        def to_screen(self, data):
            pass

        def report_warning(self, errnote):
            pass

    def remove_temp_file():
        if os.path.isfile(path):
            os.remove(path)

    downloader = FakeDownloader()
    post_processor = PostProcessor(downloader)

    # Check case of missing file
    remove_temp_file()

# Generated at 2022-06-24 14:06:03.273943
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import shutil

    class TestDownloader():
        params = {}

        def report_warning(self, msg):
            self.reported_warning = msg

    downloader = TestDownloader()
    
    pp = PostProcessor(downloader)
    tmpdir = tempfile.mkdtemp()
    

# Generated at 2022-06-24 14:06:10.129625
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys, logging
    import subprocess

    class FakeDownloader():
        def __init__(self):
            self.params = {'writedescription': False,
                           'writeinfojson': False,
                           'writethumbnail': False}

        def to_screen(self, message, skip_eol=False):
            pass

        def to_stderr(self, message):
            sys.stderr.write(message)
            sys.stderr.flush()

        def report_warning(self, message):
            self.to_stderr('WARNING: ' + message)

    class MyPostProcessor(PostProcessor):
        def run(self, info):
            return ['BINGO']
    pp = MyPostProcessor(FakeDownloader())

# Generated at 2022-06-24 14:06:15.915022
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PostProcessorSubclass(PostProcessor):
        def run(self, info):
            for x in range(0, 100):
                info = (x, info)

            return info

    pp = PostProcessorSubclass()
    assert pp.run('test') == (0, ('test',))


if __name__ == '__main__':
    test_PostProcessor_run()
    print('Test finished successfully!')

# Generated at 2022-06-24 14:06:24.237236
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Check that in PostProcessor, set_downloader sets downloader"""
    from ..extractor.common import InfoExtractor

    pp = PostProcessor(downloader=None)
    pp.set_downloader('test')
    assert pp._downloader == 'test'
    # test that this also works for subclasses
    class SubPP(PostProcessor):
        pass
    pp = SubPP(downloader=None)
    pp.set_downloader('test')
    assert pp._downloader == 'test'


# Generated at 2022-06-24 14:06:34.992327
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    class MockDownloader(object):
        def report_warning(self, message):
            self._warning_message = message
        def get_warning_message(self):
            return self._warning_message

    class MockPostProcessor(PostProcessor):
        pass

    post_processor = MockPostProcessor(MockDownloader())
    temp_file_name = 'mock_post_processor_temp_file.txt'
    atime = time.time() - 500
    mtime = time.time() - 500
    with open(temp_file_name, 'w') as test_file:
        test_file.write('')
    post_processor.try_utime(temp_file_name, atime, mtime, 'Cannot update utime of file')

# Generated at 2022-06-24 14:06:47.285206
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class DummyP(PostProcessor):
        pass

    class DummyPP(PostProcessor):
        def __init__(self):
            self._files = []

        def run(self, information):
            path = information['filepath']
            self._files.append(path)
            return self._files, information

    class DummyD(object):
        def __init__(self):
            self.troublesome_files = []

        def report_warning(self, note):
            self.troublesome_files.append(note)

    old_epoch = 315532800  # 1980-01-01
    dummy_d = DummyD()
    dummy_pp = DummyPP()
    empty_files = []

    dummy_pp.set_downloader(dummy_d)
    empty_files,

# Generated at 2022-06-24 14:06:49.949749
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .. import YoutubeDL

    p = PostProcessor(YoutubeDL(params={}))
    open('test.txt', 'w').close()

    p.try_utime('test.txt', 0, 0, errnote='Error')
    os.remove('test.txt')

# Generated at 2022-06-24 14:06:53.288358
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p
    assert p._downloader is None


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:06:55.959949
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError('video_id', 12, 'some error message').format_message() == 'some error message'



# Generated at 2022-06-24 14:07:00.186048
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()
    assert not pp._downloader
    fd = FileDownloader()
    assert not fd.postprocessor
    pp.set_downloader(fd)
    assert pp._downloader is fd
    assert fd.postprocessor is pp

# Generated at 2022-06-24 14:07:07.869417
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    get_info = lambda d: next(i for i in d.processors.object_list if isinstance(i, PostProcessor))
    from ..downloader import get_suitable_downloader

    d = get_suitable_downloader('http://ytdl-org.github.io/youtube-dl/index.html')
    assert get_info(d)._downloader == d
    d.add_post_processor(PostProcessor())
    pp = get_info(d)
    assert pp._downloader == d
    pp.set_downloader(get_suitable_downloader('http://sample.org/video.mp4'))
    pp = get_info(d)
    assert pp._downloader.params['url'] == 'http://sample.org/video.mp4'

# Generated at 2022-06-24 14:07:19.361002
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import shutil
    import tempfile
    import pytest
    from ytdl.YoutubeDL import YoutubeDL

    class _MockPostProcessor(PostProcessor):
        def run(self, information):
            assert(isinstance(information, dict))
            assert('filepath' in information)
            assert('ext' in information)
            return [], {'title': 'Lorem ipsum'}

    with tempfile.NamedTemporaryFile() as tmpf:
        shutil.copyfile(pytest.data_path('test.mp3'), tmpf.name)
        information = {'title': 'Dolor sit amet', 'ext': 'mp3', 'filepath': tmpf.name}
        ydl = YoutubeDL()
        ydl.add_post_processor(_MockPostProcessor())
        new_information

# Generated at 2022-06-24 14:07:21.951006
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    assert p._downloader == None
    d = object()
    p.set_downloader(d)
    assert p._downloader == d

# Generated at 2022-06-24 14:07:33.346374
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile

    class MockPostProcessor(PostProcessor):
        def run(self, information):
            return ([], information)

    temp_fd, temp_output_file = tempfile.mkstemp()
    os.close(temp_fd)

    try:
        information = {'filepath': temp_output_file, 'title': 'test video title'}
        pp = MockPostProcessor(None)
        files_to_delete, information = pp.run(information)
        assert(files_to_delete == [])
        assert(information['filepath'] == temp_output_file)
        assert(information['title'] == 'test video title')
    finally:
        os.unlink(temp_output_file)  # Remove temporary file

# Generated at 2022-06-24 14:07:38.878281
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert err.msg == 'test'
    err = AudioConversionError('test', 'path')
    assert err.msg == 'test'
    assert err.path == 'path'
    err = AudioConversionError('test', 'path', 'exit_code')
    assert err.msg == 'test'
    assert err.path == 'path'
    assert err.exit_code == 'exit_code'

# Generated at 2022-06-24 14:07:41.778492
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader
    pp = PostProcessor()
    dl = Downloader()
    pp.set_downloader(dl)
    assert pp._downloader == dl


# Generated at 2022-06-24 14:07:44.011013
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:07:51.662116
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..__main__ import main


# Generated at 2022-06-24 14:07:56.908624
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Simple unit test for PostProcessor.run
    """

    class TestPP(PostProcessor):
        def run(self, info):
            info['a'] = 1
            return [], info

    pp = TestPP()
    _, out = pp.run({})
    assert 'a' in out

# Generated at 2022-06-24 14:08:00.276602
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except AudioConversionError as e:
        assert e.msg == "Converting audio failed"
    except Exception as e:
        assert False, 'Unexpected exception raised: ' + type(e).__name__

# Generated at 2022-06-24 14:08:06.731421
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    c = AudioConversionError('Audio post processing', 'ffmpeg output')
    assert c.args[0] == 'Audio post processing ffmpeg output'
    c = AudioConversionError('Audio post processing', 'ffmpeg output', 'more info')
    assert c.args[0] == 'Audio post processing ffmpeg output more info'
    assert str(c) == 'Audio post processing ffmpeg output more info'

# Generated at 2022-06-24 14:08:10.457460
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError('conversion failed')
    assert str(exc) == 'conversion failed'
    exc = AudioConversionError('conversion failed', 'input.ogg')
    assert str(exc) == 'conversion failed: input.ogg'

# Generated at 2022-06-24 14:08:14.065512
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    pp = PostProcessor()
    assert pp.run({'filepath': 'file.mp3', 'title': 'title'}) == ([], {'filepath': 'file.mp3', 'title': 'title'})


if __name__ == '__main__':
    test_PostProcessor_run()

# Generated at 2022-06-24 14:08:17.802657
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MyPostProcessor(PostProcessor):
        def test_try_utime(self, path, atime, mtime):
            self.try_utime(path, atime, mtime)

    pp = MyPostProcessor()
    pp.test_try_utime('/path/to/file', 123, 456)

# Generated at 2022-06-24 14:08:28.109925
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import sys

    if sys.version_info[:2] >= (3, 3):
        # The subprocess.call method used in PostProcessor accepts unicode strings
        # in Python 3.3 (see issue #1370).
        # Let's create a file containing unicode characters
        unicode_filename = '\xe9\xe9.txt'
        with open(unicode_filename, 'wb') as f:
            f.write(b'\xe9\xe9')
        test_file = unicode_filename
    else:
        # In Python 2.6 and 2.7, os.utime doesn't accept unicode strings.
        # In order to run our tests we must use ascii strings.
        ascii_filename = 'ee.txt'

# Generated at 2022-06-24 14:08:30.930139
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    a = AudioConversionError('a', 'b')
    assert a.name == 'a'
    assert a.err == 'b'

# Generated at 2022-06-24 14:08:33.408247
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    obj = AudioConversionError('audio', 'some error')
    assert obj.audio is 'audio'
    assert str(obj) is 'some error'

# Generated at 2022-06-24 14:08:44.032221
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import os
    import tempfile
    import shutil
    import json


# Generated at 2022-06-24 14:08:54.581843
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader.common import FileDownloader
    from ..utils import DateRange

    # Mock a FileDownloader to not do anything
    class Dummy(FileDownloader):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-24 14:09:05.711930
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import Downloader
    from ..utils import DateRange
    from .ffmpeg import FFmpegPostProcessor
    from .exec_cmd import ExecAfterDownloadPP
    from ..compat import compat_os_name, compat_shlex_quote

    class FakeFile:
        def __init__(self, filename, contents):
            self.filename = filename
            self.contents = contents
            self.closed = False
            self.written = False

        def close(self):
            self.closed = True

        def read(self, _):
            return self.contents

        def write(self, _):
            self.written = True

    # To avoid failures on windows, we don't use a pipe
    # and we don't quote the filename

# Generated at 2022-06-24 14:09:07.481689
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('youhou')
    except AudioConversionError as err:
        assert (str(err) == 'youhou')

# Generated at 2022-06-24 14:09:09.770232
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(1, 2, 3)
    except AudioConversionError as e:
        assert e.exit_code == 1
        assert e.out == 2
        assert e.err == 3

# Generated at 2022-06-24 14:09:14.235618
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP

    downloader = FileDownloader()
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_post_processor(FFmpegExtractAudioPP())

    postProcessor = downloader._ies[0]._pps[0]

    assert(postProcessor._downloader is None)

    postProcessor.set_downloader(downloader)

    assert(postProcessor._downloader == downloader)

# Generated at 2022-06-24 14:09:14.772783
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pass

# Generated at 2022-06-24 14:09:18.935124
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from . import YoutubeDL
    downloader = YoutubeDL()
    pp = PostProcessor(downloader)
    assert pp._downloader is downloader
    pp = PostProcessor()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-24 14:09:19.969739
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert AudioConversionError(25, 'test').args == (25, 'test')

# Generated at 2022-06-24 14:09:28.374185
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os.path
    import platform
    from .YoutubeDL import YoutubeDL
    def _test_utime(path, atime, mtime):
        p = PostProcessor(YoutubeDL())
        try:
            p.try_utime(path, atime, mtime)
        except Exception as e:
            return e.__class__
        return 0

    def _test_utime_nonexists(path, atime, mtime):
        p = PostProcessor(YoutubeDL())
        try:
            p.try_utime(path + 'nonexists.file', atime, mtime)
        except Exception as e:
            return e.__class__
        return 0

    tmpdir = tempfile.gettempdir()
    # Test the utime method with a new file that doesn

# Generated at 2022-06-24 14:09:31.376462
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:38.410963
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp1 = PostProcessor()
    pp2 = PostProcessor()
    ydl = YoutubeDL()
    ydl.add_post_processor(pp1)
    ydl.add_post_processor(pp2)
    ydl._setup_opener()  # the downloader should not be set until opener is configured
    assert pp1._downloader == ydl
    assert pp2._downloader == ydl

# Generated at 2022-06-24 14:09:44.468366
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    test_pp = PostProcessor()
    assert test_pp._downloader is None

    test_fd = FileDownloader()
    test_pp = PostProcessor(test_fd)
    assert test_pp._downloader == test_fd

    test_fd2 = FileDownloader()
    test_pp.set_downloader(test_fd2)
    assert test_pp._downloader == test_fd2

# Generated at 2022-06-24 14:09:55.625852
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader():
        def report_warning(self, n):
            self.note = n

    class FakePostProcessor(PostProcessor):
        def __init__(self):
            self.set_downloader(FakeDownloader())

    import time
    import pytest
    t = time.time()
    with open('test.txt', 'wb') as f:
        f.write('Hello World')

    f = FakePostProcessor()
    f.try_utime('test.txt', t, t)
    atime, mtime = time.localtime(os.path.getatime('test.txt'))[:6]
    assert atime == mtime == time.localtime(t)[:6]

    import os
    import sys
    if sys.platform.startswith('win'):
        os

# Generated at 2022-06-24 14:09:56.878839
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    PostProcessor(downloader)

# Generated at 2022-06-24 14:10:01.346674
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    This tests the PostProcessor class.
    """
    class PP(PostProcessor):
        def run(self, info):
            return [], info
    pp = PP()
    # Check that a PostProcessor runs without triggering any exception.
    pp.run({})



# Generated at 2022-06-24 14:10:05.400706
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPP(PostProcessor):
        def run(self, info):
            return ['a'], info

    dummy_pp = DummyPP()
    assert dummy_pp.run({}) == (['a'], {})

# Generated at 2022-06-24 14:10:15.312212
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create a dummy PostProcessor
    postprocessor = PostProcessor()
    # Create a dummy downloader and set it as the downloader of the dummy PostProcessor
    postprocessor._downloader = type('DummyDownloader', (object,), {'report_warning': lambda s, m: None})()
    # Create a dummy file
    f = tempfile.NamedTemporaryFile()
    # Get the path of the dummy file
    path = f.name
    # Close the dummy file
    f.close()
    # Call the method try_utime with arbitrary arguments
    try:
        postprocessor.try_utime(path, 0, 0)
    except Exception as e:
        assert False, 'PostProcessor.try_utime raises a %s exception with argument %s' % (type(e).__name__, path)
   

# Generated at 2022-06-24 14:10:24.167260
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test that PostProcessor.set_downloader sets the
    downloader for the PostProcessor
    """
    # Make a PostProcessor Object
    pp = PostProcessor()
    # Assert that the downloader is None
    assert pp._downloader == None
    # Set the downloader
    from ydl.YoutubeDL import YoutubeDL
    pp.set_downloader(YoutubeDL())
    # Assert that the downloader is set
    assert pp._downloader != None
    # Assert that the set downloader is an instance of YoutubeDL
    assert isinstance(pp._downloader, YoutubeDL)