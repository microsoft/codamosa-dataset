

# Generated at 2022-06-24 14:00:24.994617
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor() is not None

# Generated at 2022-06-24 14:00:28.376953
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class MockDownloader:
        def __init__(self):
            pass
    sut = PostProcessor(MockDownloader())
    assert sut != None
    assert sut._downloader != None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:00:30.914220
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    import YoutubeDL
    a = YoutubeDL.YoutubeDL()
    b = a.post_processors[0]
    assert isinstance(b, PostProcessor)

# Generated at 2022-06-24 14:00:39.644465
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakeDownloader:
        def __init__(self):
            self.params = {"verbose": 0, "quiet": False, "ignoreerrors": False, "no_warnings": False}
    class FakePostProcessor(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self, downloader=FakeDownloader())

    # Test 1: Fake downloader.report_warning is called when utime fails
    pp = FakePostProcessor()
    pp.report_warning_orig = pp._downloader.report_warning
    def fake_report_warning(message):
        assert message.startswith('Cannot update utime of file')
    pp._downloader.report_warning = fake_report_warning
    pp.try_utime('/nonexistent_path', 127, 128)

    #

# Generated at 2022-06-24 14:00:43.186151
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    obj = PostProcessor()
    assert obj._downloader is None
    fake_downloader = object()
    obj.set_downloader(fake_downloader)
    assert obj._downloader is fake_downloader

# Generated at 2022-06-24 14:00:54.845704
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """testPostProcessor_try_utime: test for utime method of class PostProcessor"""
    import unittest
    import tempfile

    class DummyDownloader(object):
        def report_warning(self, msg):
            pass

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def try_utime(self, path, atime, mtime, errnote='Cannot update utime of file'):
            self.path = path
            self.atime = atime
            self.mtime = mtime
            self.errnote = errnote
            PostProcessor.try_utime(self, path, atime, mtime, errnote)


# Generated at 2022-06-24 14:01:06.202693
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import time
    import shutil
    import os.path

    pp = PostProcessor(None)
    tmpd = tempfile.mkdtemp()
    filename = os.path.join(tmpd, 'file')

    f = open(filename, 'wb')
    f.write('dummy file')
    f.close()

    ftime = time.mktime(time.strptime('2004-12-05 04:18:54', '%Y-%m-%d %H:%M:%S'))
    os.utime(filename, (ftime, ftime))

    if sys.platform == 'win32':
        # Useless on Windows - time is always rounded to seconds
        return

    ftime = int(ftime)

# Generated at 2022-06-24 14:01:15.702363
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    ' Test that constructing PostProcessor subclass does not throw any exception '
    from ..compat import compat_shlex_quote
    from ..extractor.common import InfoExtractor
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'testid',
                'ext': 'mp4',
                'url': 'http://example.org/test.mp4',
                'title': 'testtitle',
                'duration': 42,
            }
    pp = TestPostProcessor()
    assert pp.__class__.__name__ == 'TestPostProcessor'
    ie = TestIE()
    ie.add_post_processor(pp)
    testurl

# Generated at 2022-06-24 14:01:21.183266
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor(downloader=None)
    assert pp._downloader is None
    pp.set_downloader(downloader=object)
    assert pp._downloader == object
    pp.set_downloader(downloader=None)
    assert pp._downloader is None


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 14:01:24.482113
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:01:33.919295
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..YoutubeDL import YoutubeDL
    from .common import GenericPostProcessor

    downloader = YoutubeDL()
    pp1 = PostProcessor(downloader)
    pp2 = GenericPostProcessor(downloader)

    info = {'id': 'abc123', 'title': 'test video', 'ext': 'mp4', 'format': 'best',
            'alt_title': 'alternative title', 'url': 'http://example.com/test.mp4',
            'webpage_url': 'http://example.com/testvideo.html',
            'extractor': 'Test extractor', 'extractor_key': 'test_extractor'}

    assert pp1.run(info) == pp2.run(info), 'PostProcessor.run() does not work as expected'

# Generated at 2022-06-24 14:01:36.365387
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    p = PostProcessor()
    assert p._downloader is None
    d = object()
    p.set_downloader(d)
    assert p._downloader == d

# Generated at 2022-06-24 14:01:38.523908
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
  try:
    pp = PostProcessor()
  except:
    assert False, 'Unable to create PostProcessor object'

  assert pp._downloader == None, 'PostProcessor object\'s downloader not initialized correctly'

# Generated at 2022-06-24 14:01:39.296894
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass


# Generated at 2022-06-24 14:01:40.069982
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert isinstance(PostProcessor(), PostProcessor)

# Generated at 2022-06-24 14:01:42.376455
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    """Test for instantiating AudioConversionError class."""
    try:
        raise AudioConversionError('Wrong format')
    except AudioConversionError as ace:
        assert str(ace) == 'Wrong format'

# Generated at 2022-06-24 14:01:52.129288
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import sys
    import tempfile
    import shutil
    import os
    from ..utils import encodeFilename

    class DummyDownloader:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def to_screen(self, message):
            sys.stdout.write('[debug] ' + message + '\n')

        def report_warning(self, message):
            self.to_screen(message)

        def temp_name(self, filename):
            return os.path.join(self.tmpdir, filename)

    # Generate a test file
    fd, tmpfile = tempfile.mkstemp(prefix='youtubedl-test_PostProcessor_try_utime')
    os.write(fd, b'foobarbaz')
    os.close(fd)
   

# Generated at 2022-06-24 14:01:57.324721
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    ydl = object()
    pp = PostProcessor(ydl)
    assert pp._downloader == ydl
    assert pp.set_downloader(None) is None
    pp.set_downloader(ydl)
    assert pp._downloader == ydl


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:02:00.048904
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(ydl)
    pp.set_downloader(ydl)
    pp._downloader is ydl


# Generated at 2022-06-24 14:02:01.804349
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """
    Simple unit test for PostProcessor class constructor
    """
    pp = PostProcessor()
    assert pp

# Generated at 2022-06-24 14:02:05.104403
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeDownloader
    class FakePostProcessor(PostProcessor):
        def run(self, information):
            return [], information  # by default, keep file and do nothing

    p = FakePostProcessor()
    p.set_downloader(FakeDownloader())
    p.try_utime('path', 'atime', 'mtime')

# Generated at 2022-06-24 14:02:07.576142
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert isinstance(pp, PostProcessor)


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:02:08.640566
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postProcessor1 = PostProcessor()
    assert(postProcessor1)

# Generated at 2022-06-24 14:02:10.399797
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("This is a test")
    except PostProcessingError as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-24 14:02:16.526335
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    class PostTestProcessor(PostProcessor):
        def run(self, info):
            return [], info

    class InfoTestProcessor(InfoExtractor):
        IE_DESC = 'InfoTestProcessor'
        def _real_extract(self, url):
            return {'id': 'test'}

    InfoTestProcessor.add_info_extractor(InfoTestProcessor)
    ydl = FileDownloader(params={'format': 'test'})
    ydl.add_post_processor(PostTestProcessor)
    ret = ydl.download(['http://example.com'])
    assert ydl.postproc.__class__.__name__ == 'PostTestProcessor'

# Generated at 2022-06-24 14:02:25.287088
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import YoutubeDL
    from .exec_cmd import ExecAfterDownloadPP
    from .xattr import XAttrMetadataPP
    from .metadata_injector import MetadataFromTitlePP

    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return [info['filepath']], info

    # Create downloader
    ydl_opts = {
        'logger': YoutubeDL().logger,
        'progress_hooks': [lambda d, p, s: None],
    }
    ydl = YoutubeDL(ydl_opts)

    # Create chain of three post processors
    # PP1: DummyPP
    pp1 = DummyPostProcessor(ydl)
    # PP2: exec_cmd
    tmp_file = 'temp'
    pp2 = Exec

# Generated at 2022-06-24 14:02:36.390199
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from ..utils import DateRange
    from .common import FakeYDL

    ydl = FakeYDL({
        'quiet': True,
        'dump_intermediate_pages': False,
        'format': 'bestaudio/best',
        'download_archive': os.path.join(os.path.dirname(__file__), 'ar.archive'),
        'skip_download': True,
        'format_limit': 'mp3',
        'match_filter': DateRange('20100101', '20101231').match,
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(FakeIE())
    ydl.add_post_processor(FakePP())

# Generated at 2022-06-24 14:02:44.304872
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPP(PostProcessor):
        def run(informations):
            assert informations == {'key': 'value'}, 'Wrong informations value'
            return ['file1', 'file2'], {'key': 'value2'}

    pp = MockPP()
    ret_files, informations = pp.run({'key': 'value'})
    assert ret_files == ['file1', 'file2'], 'Wrong return value for ret_files'
    assert informations == {'key': 'value2'}, 'Wrong return value for informations'



# Generated at 2022-06-24 14:02:56.652085
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import (
        common as ex_common,
    )
    from ..downloader import common as dl_common

    class TestPP(PostProcessor):
        def run(self, info):
            ex_common.post_processing_step1(info)
            return ([], info)


# Generated at 2022-06-24 14:02:58.797511
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test message', 'test inputfile')
    except AudioConversionError as exc:
        assert str(exc) == 'test message'
        assert exc.inputfile == 'test inputfile'

# Generated at 2022-06-24 14:03:02.167746
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class DummyPP(PostProcessor):
        pass
    class DummyDownloader():
        pass
    dl = DummyDownloader()
    pp = DummyPP()
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-24 14:03:04.770456
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Method set_downloader of PostProcessor should assign to self._downloader
    the instance of YoutubeDL passed to it.
    """
    pass


# Generated at 2022-06-24 14:03:13.347920
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import tempfile
    temp_files = []

# Generated at 2022-06-24 14:03:19.992069
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    # Test 1: Set downloader to PostProcessor
    ie = YoutubeIE(Downloader())
    pp = ie.pp
    assert pp._downloader is ie._downloader
    # Test 2: Set downloader to PostProcessor (different instance)
    downloader = Downloader()
    pp.set_downloader(downloader)
    assert pp._downloader is downloader

# Generated at 2022-06-24 14:03:26.286434
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..extractor import gen_extractors
    gen_extractors()  # Load extractors
    from ..downloader import gen_downloaders
    from ..utils import parseOpts
    from . import get_suitable_downloader

    downloader = get_suitable_downloader({})
    downloader.params['noplaylist'] = True
    downloader.add_default_info_extractors()
    downloader.add_default_downloader()
    (opts, args) = parseOpts()

    # Extract information from a youtube video
    # This should be changed since the video may get unavailable
    # in the future.
    info = downloader.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', download=False)

    # Test all postprocessors in all

# Generated at 2022-06-24 14:03:30.131405
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Verify that the PostProcessor.set_downloader() method sets the downloader property"""
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    pp = PostProcessor(None)
    pp.set_downloader(ydl)
    assert pp._downloader is ydl

# Generated at 2022-06-24 14:03:32.488746
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    p = PostProcessor()
    assert p.__class__.__name__ == "PostProcessor"
    assert p.__doc__ == "Post Processor class."

# Generated at 2022-06-24 14:03:34.046032
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test message')
    except AudioConversionError as e:
        assert str(e) == 'test message'



# Generated at 2022-06-24 14:03:35.933478
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()

    assert pp is not None

if __name__ == "__main__":
    test_PostProcessor()

# Generated at 2022-06-24 14:03:37.572971
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None, 'postprocessor initialization should succeed'
    print('PostProcessor initialization succeed!')

# Generated at 2022-06-24 14:03:39.347404
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:03:43.757157
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """Tests the set_downloader method of class PostProcessor"""

    from youtube_dl.downloader.common import FileDownloader
    postProcessor = PostProcessor()

    downloader = FileDownloader({})
    postProcessor.set_downloader(downloader)

    assert postProcessor._downloader == downloader

# Generated at 2022-06-24 14:03:45.413275
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    """Test constructor of class PostProcessor."""
    pp = PostProcessor()
    assert pp is not None


# Generated at 2022-06-24 14:03:53.690248
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FileDownloader
    pp = PostProcessor(FileDownloader())

    def test_utime(self):
        f = os.path.join(self.tempdir, 'test')
        open(f, 'w').close()
        os.utime(f, (0, 0))
        self.assertEqual(os.path.getmtime(f), 0)
        self.assertEqual(os.path.getatime(f), 0)
        #
        pp.try_utime(f, 1, 2)
        self.assertEqual(os.path.getmtime(f), 2)
        self.assertEqual(os.path.getatime(f), 1)
        #
        pp.try_utime(f, 3, 4, errnote='customerr')
        self

# Generated at 2022-06-24 14:04:03.540368
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_urllib_request
    import json
    import os
    import shutil
    import tempfile
    import unittest
    import urllib.parse
    import subprocess

    # Test class for the run of class PostProcessor
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            self.head = {}
            self.data = None
            self.times = 0
            self.mock_info = None

        def run(self, info):
            self.times += 1
            return [(None, None)], info

    class TestPostProcessorMethods(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.downloader = MockYoutubeDL()
           

# Generated at 2022-06-24 14:04:12.146390
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import os
    from ..compat import compat_urlparse

    class FakeDownloader():
        def to_screen(self, text):
            print('to_screen:' + text)
        def to_stdout(self, text):
            print('to_stdout:' + text)
        def to_stderr(self, text):
            print('to_stderr:' + text)
        def temp_name(self, filename):
            return 'dummy'
        def report_warning(self, text):
            print('report_warning:' + text)
        def report_error(self, text):
            print('report_error:' + text)

# Generated at 2022-06-24 14:04:21.142418
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    def test_run(self, information):
        return information['a']

    class TestPostProcessor(PostProcessor):
        pass

    TestPostProcessor.run = test_run

    class TestDownloader():
        params = {'a': 'b'}

    info = {'a': 'b'}

    pp = TestPostProcessor(downloader=TestDownloader())
    pp_ret = pp.run(info)
    assert pp_ret == 'b'

# Generated at 2022-06-24 14:04:30.555270
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from . import YoutubeDL
    from .extractor import get_info_extractor

    class TestPP(PostProcessor):
        def run(self, info):
            return ['A', 'B'], info.copy()

    ydl = YoutubeDL({'quiet': True})
    video_ie = get_info_extractor('YoutubeVideoOnlyIE')
    ydl.add_info_extractor(video_ie)
    ydl.add_post_processor(TestPP())

    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True

    def check_test_pp(url, expected_return_code, expected_files_to_delete, expected_info):
        result = ydl.extract_info(url, download=False)

# Generated at 2022-06-24 14:04:33.994659
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.youtube import YoutubeIE
    pp = PostProcessor()
    ydl = YoutubeIE('youtube')
    pp.set_downloader(ydl)
    assert pp._downloader == ydl

# Generated at 2022-06-24 14:04:45.159915
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Unit test for method `run` of class PostProcessor
    """
    import sys
    import unittest

    class TestPostProcessor(PostProcessor):
        def test_run(self):
            self.run({"filepath": "filename"})

    class TestPrePostProcessor(TestPostProcessor):
        def test_run(self):
            self.run({"filepath": "filename", "filename": "test.mp4"})

    class TestPostProcessorRunTest(unittest.TestTestCase):
        def test_run(self):
            try:
                TestPostProcessor().test_run()
            except Exception:
                self.fail("test_run() raised Exception unexpectedly!")


# Generated at 2022-06-24 14:04:49.810535
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import types
    pp = PostProcessor()
    assert isinstance(pp.run, types.MethodType)
    assert 'information' in pp.run.__code__.co_varnames
    assert pp.run.__code__.co_argcount == 2

# Generated at 2022-06-24 14:04:52.016716
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor(None)
    a = {}
    a1 = pp.run(a)
    print(a1)

# Generated at 2022-06-24 14:05:00.835382
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    Simple unit test for class PostProcessor.
    It checks behaviour of method run of class PostProcessor.
    """
    import sys
    import unittest

    # We patch sys.stderr to avoid printing messages
    # during the test.
    class _PatchedStdErr(object):
        def __init__(self):
            self._stderr = sys.stderr
            self._stringio = StringIO()
            self._stringio.name = '<stdout>'
            sys.stderr = self._stringio

        def __enter__(self):
            return self

        def __exit__(self, *args):
            sys.stderr = self._stderr

        def getvalue(self):
            return self._stringio.getvalue()


# Generated at 2022-06-24 14:05:11.528531
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..downloader import FakeDownloader
    from ..compat import unittest
    from ..utils import write_json_file
    from ..extractor import YoutubeIE

    class TestPostProcessor(PostProcessor):
        pass

    ok_ie = YoutubeIE()
    ok_info = ok_ie.extract('http://youtu.be/BaW_jenozKc')
    ok_info['filepath'] = 'BaW_jenozKc.%s' % ok_info['ext']
    ok_info['fulltitle'] = ok_info['title']

    info_dict = {'id': 'BaW_jenozKc',
                 'ext': 'webm',
                 'title': 'XBMC YouTube Addon Test Video'}

# Generated at 2022-06-24 14:05:22.006106
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Tests run() method of class PositProcessor."""

    import re
    import subprocess
    from .common import FakeYDL

    class FakePostProcessor(PostProcessor):
        """"Fake PostProcessor for testing purposes."""

        def run(self, info):
            """Modifies initial download information."""

            if info['filepath'] is not None:
                video_title = info['title']
                video_ext = info['ext']
                video_format = info['format']

                modified_title = re.sub(r'[^a-zA-Z0-9-]', '_', video_title)
                filepath = '{0}-{1}.{2}'.format(modified_title, video_format, video_ext)
                info['filepath'] = filepath

            return [], info

# Generated at 2022-06-24 14:05:22.584100
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    assert 1 == 1

# Generated at 2022-06-24 14:05:24.721624
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import FakeYDL
    pp = PostProcessor(FakeYDL())
    assert pp.run({}) == ([], {})

# Generated at 2022-06-24 14:05:30.915210
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from ..compat import compat_os_name

    if compat_os_name == 'nt':
        return

    # Create a downloader
    ydl = FileDownloader({})

    # Create some PostProcessor
    xattr_pp = XAttrMetadataPP(ydl)
    exec_pp = ExecAfterDownloadPP(ydl)

    # Set downloader on the PostProcessors
    xattr_pp.set_downloader(ydl)
    exec_pp.set_downloader(ydl)

# Generated at 2022-06-24 14:05:34.110149
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    downloader = object()
    pp = PostProcessor(downloader)
    assert pp._downloader == downloader


if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:05:38.255514
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(None, None, None, 1)
    except AudioConversionError as e:
        assert e.exit_code == 1
        assert e.converter == None
        assert e.filepath == None
        assert e.reason == None

# Generated at 2022-06-24 14:05:40.066724
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO: write unit test for method try_utime of class PostProcessor
    pass

# Generated at 2022-06-24 14:05:49.143705
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader

    ext_dict = gen_extractors()

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            self.try_utime(information['filepath'], 0, 0, errnote='Cannot modify utime')
            return [information['filepath']], information

    ydl_opts = {
        'format': 'bestvideo+bestaudio',
        'extractors': ext_dict.keys(),
        'postprocessors': [{
            'key': 'TestPostProcessor'
        }],
        'logger': None,
        'noprogress': True,
        'forcejson': True,
    }
    fd = FileDownloader(ydl_opts)

   

# Generated at 2022-06-24 14:06:00.748374
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class MockPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
            self.utime_path = None
            self.utime_times = None
            self.utime_warnings = []
        def try_utime(self, path, atime, mtime, errnote=None):
            self.utime_path = path
            self.utime_times = (atime, mtime)
            self.utime_warnings.append(errnote)
    p = MockPostProcessor(None)
    p.try_utime('abc/de f', 1, 2, 'error1')
    p.try_utime('abc/de g', 3, 4, 'error2')

# Generated at 2022-06-24 14:06:02.802145
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time

    pp = PostProcessor()
    test_time = time.time() - 1000
    pp.try_utime(__file__, test_time, test_time)

# Generated at 2022-06-24 14:06:05.286519
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test 123')
    except AudioConversionError as err:
        assert str(err) == 'test 123'
    else:
        assert False



# Generated at 2022-06-24 14:06:16.361531
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .embedthumbnail import EmbedThumbnailPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP
    from .thumbnail import ThumbnailPP
    from ..compat import is_win32

    dl = YoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
    })
    dl.add_post_processor(EmbedThumbnailPP())
    dl.add_post_processor(ThumbnailPP())
    if is_win32:
        dl.add_post_processor(ExecAfterDownloadPP(['powershell', '-command', '$i=0; $i++']))

# Generated at 2022-06-24 14:06:26.931490
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader.common import FileDownloader
    from .common import PostProcessorTest
    from ..downloader.f4m import F4mFD
    from ..extractor import gen_extractors

    fd = F4mFD(gen_extractors(), FileDownloader())
    fd.params.update({
        'outtmpl': '%(title)s.f4m',
    })
    assert fd.prepare_filename(u'Título') == u'Título.f4m'

    pp = PostProcessor(fd)
    pp0 = PostProcessorTest()
    pp1 = PostProcessorTest(lambda x: x)

    assert pp.run({'title': 'abc'}) == ([], {'title': 'abc'})

# Generated at 2022-06-24 14:06:36.134192
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader.common import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import make_HTTPServer

    with make_HTTPServer() as http_server:
        http_server.serve_content('test', headers={'Content-type': 'video/unknown'})

        ydl = FileDownloader({'outtmpl': '%(id)s%(ext)s'})
        ydl.add_info_extractors(gen_extractors())
        ydl.add_default_info_extractors()
        ydl.download([http_server.get_url()])

    assert os.path.isfile('test')
    os.remove('test')

# Generated at 2022-06-24 14:06:42.196449
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test set_downloader of PostProcessor.
    """
    pp = PostProcessor()
    dl = "downloader"
    pp.set_downloader(dl)
    assert pp._downloader == dl, 'set_downloader test failed!'


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:06:52.137023
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    import tempfile
    td = tempfile.mkdtemp()
    f = os.path.join(td, 'f')
    open(f, 'w').close()
    f_atime = os.stat(f).st_atime
    f_mtime = os.stat(f).st_mtime
    import time
    f_atime_new = time.time()
    f_mtime_new = f_atime_new - 1
    pp.try_utime(f, f_atime_new, f_mtime_new)
    assert os.stat(f).st_atime == f_atime_new
    assert os.stat(f).st_mtime == f_mtime_new
    from ..compat import compat_os_name

# Generated at 2022-06-24 14:06:56.913650
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

        def run(self, info):
            return [], info
    pp = TestPP(None)
    assert pp != None

# Generated at 2022-06-24 14:07:05.819134
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class FakePostProcessor(PostProcessor):
        def __init__(self):
            pass
        def run(self, info):
            return self.try_utime(info['filepath'], 123, 456)

    class FakeDownloader:
        def __init__(self):
            self.pp = FakePostProcessor()
            self.pp.set_downloader(self)

        def report_warning(self, msg):
            print(msg)

    dl = FakeDownloader()

    info = {'filepath': 'a/path'}
    dl.pp.run(info)

    import stat
    import time
    import os

    # In case of error, the file should not be removed
    assert stat.S_ISREG(os.stat(info['filepath']).st_mode)

    # In

# Generated at 2022-06-24 14:07:11.898352
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from tempfile import NamedTemporaryFile
    from pytube.compat import std_err, stdin, stdout, WIN32

    from pytube.downloader import FileDownloader
    from pytube.postprocessor import PostProcessor
    from pytube.extractor import YoutubeIE

    ie = YoutubeIE(downloader=FileDownloader())
    pp = PostProcessor(downloader=FileDownloader())

# Generated at 2022-06-24 14:07:19.708143
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Unit test for method set_downloader of class PostProcessor.
    """
    class MockDownloader(object):
        """Mocked downloader."""
        pass

    class MockPostProcessor(PostProcessor):
        """Mocked post processor."""

        def __init__(self, downloader=None):
            PostProcessor.__init__(self)
            pass

    downloader = MockDownloader()
    postprocessor = MockPostProcessor()

    postprocessor.set_downloader(downloader)
    assert postprocessor._downloader is downloader



# Generated at 2022-06-24 14:07:26.951055
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    This unit test checks the method PostProcessor.try_utime.
    """

    import tempfile
    import shutil
    import os.path
    import time
    from ydl.utils import PostProcessor


# Generated at 2022-06-24 14:07:32.523941
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test', 'test.mp3', 'test.mp4')
    assert err.src == 'test.mp3'
    assert err.dst == 'test.mp4'
    assert str(err) == 'Audio conversion failed: test'
    assert err.converter == 'test'
    assert err.encoding_options == tuple()
    assert err.write_errmsg is False



# Generated at 2022-06-24 14:07:33.198890
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    pass

# Generated at 2022-06-24 14:07:36.364183
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    test_dict = {"filepath": "/tmp/file"}
    pp = PostProcessor()
    files, out = pp.run(test_dict)
    assert 'filepath' in out
    assert out['filepath'] == test_dict['filepath']

# Generated at 2022-06-24 14:07:41.875239
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    Test setting the downloader for PostProcessor.
    """
    global downloader
    downloader = None

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            global downloader
            assert downloader == self._downloader
            return [], information  # by default, keep file and do nothing

    downloader = object()
    testPP = TestPostProcessor(downloader)
    testPP.run({})

# Generated at 2022-06-24 14:07:44.858091
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError('a', 'b', 'c', 'd')
    assert (str(exc) == "a failed: exit code was b, output was 'c' and stderr was 'd'")



# Generated at 2022-06-24 14:07:47.486806
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        error = AudioConversionError('message')
    except Exception as err:
        if str(err) != 'message':
            raise clsException('test_AudioConversionError', 'test failed')



# Generated at 2022-06-24 14:07:50.842177
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader

    pp = PostProcessor()
    downloader = Downloader(YoutubeIE())
    pp.set_downloader(downloader)

    assert pp._downloader is downloader

# Generated at 2022-06-24 14:08:01.718321
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class PP1(PostProcessor):
        id = 'pp1'

    class PP2(PostProcessor):
        id = 'pp2'

    class Downloader(object):

        def __init__(self):
            self.pp_chain = []

        def report_warning(self, message):
            return

        def add_post_processor(self, pp):
            self.pp_chain.append(pp)

    pp1 = PP1()
    pp2 = PP2()

    pp1.set_downloader(Downloader())
    pp1.add_post_processor(pp2)

    pp1.run({'a': 1})

    assert pp1.id == pp1._downloader.pp_chain[0].id
    assert pp2.id == pp1._downloader.pp_chain[0]._downloader

# Generated at 2022-06-24 14:08:12.939355
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.common import PostProcessor
    pp = PostProcessor(YoutubeDL({}))

    class Mock_File:
        def __init__(self):
            self.permission_denied = False

        def __call__(self, *args, **kwargs):
            if args[0] == "cannot write":
                raise IOError("cannot write")
            elif args[0] == "permission denied":
                self.permission_denied = True
                raise IOError("permission denied")
            elif args[0] == "exception":
                raise Exception("exception")
            else:
                pass

    ff = Mock_File()
    pp._downloader.report_warning = ff

    # normal case

# Generated at 2022-06-24 14:08:17.323572
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    from ..downloader import Downloader

    dl = Downloader(params={})

    pp = PostProcessor(dl)

    if pp._downloader is not dl:
        raise AssertionError('Failed to set downloader for PostProcessor')

    pp.set_downloader(None)

    if pp._downloader is not None:
        raise AssertionError('Failed to reset downloader for PostProcessor')

# Generated at 2022-06-24 14:08:20.485190
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    test_audio_conversion_error = AudioConversionError('Test audio conversion error.')
    if test_audio_conversion_error.message == 'Test audio conversion error.':
        return True
    else:
        return False


# Generated at 2022-06-24 14:08:30.592654
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Test of class PostProcessor that all it's methods are correctly called
    # The class arguments are not tested as they are already tested
    from ..downloader.common import FileDownloader

    class DummyPP(PostProcessor):

        def __init__(self, dl):
            PostProcessor.__init__(self, dl)
            DummyPP.__init__ = lambda x, y: None
            DummyPP.run = lambda x, y: None

        def __init__(self, dl):
            pass

        def run(self, info):
            return [], None

    class DummyIE(object):
        IE_NAME = ''
        _WORKING = False

        def __init__(self, downloader):
            self.downloader = downloader

        def report_warning(self, msg):
            pass



# Generated at 2022-06-24 14:08:34.548901
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    assert pp._downloader == None

    ydl = YoutubeDL()
    pp.set_downloader(ydl)
    assert pp._downloader == ydl
test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:08:44.884998
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .downloader import Downloader
    # Create an object with a method "run" that returns its argument
    class DummyPP1(PostProcessor):
        def run(self, information):
            return information
    # Create an object with a method "run" that returns the value of a
    # field of its argument
    class DummyPP2(PostProcessor):
        def run(self, information):
            return information['somefield']
    # Create an object with a method "run" that will fail with a
    # PostProcessingError
    class DummyPP3(PostProcessor):
        def run(self, information):
            raise PostProcessingError('boum')

    # Create an object with a method "run" that will fail with a
    # KeyError

# Generated at 2022-06-24 14:08:46.170411
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:08:56.819165
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        from ..downloader.common import FileDownloader
        from ..YoutubeDL import YoutubeDL
        from .common import get_testdata_file
    except ImportError:
        return

    downloader = FileDownloader(
        params={'quiet': True},
        ydl=YoutubeDL(params={'quiet': True}))
    postprocessor = PostProcessor(downloader)
    testfile = get_testdata_file('postprocessor_test.bin')
    try:
        os.remove(testfile)
    except OSError:
        pass
    open(testfile, 'wb')
    postprocessor.try_utime(testfile, 1510199377, 1510199377, errnote='We can\'t change the date of a file (ok).')
    os.remove(testfile)

# Generated at 2022-06-24 14:09:01.495699
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    def test_pp(information):
        assert information["filepath"] == 'video'
        return ['video']

    file_name = 'video'

    pp = PostProcessor(None)
    pp.run = test_pp

    assert pp.run({'filepath': file_name}) == (['video'], {})

# Generated at 2022-06-24 14:09:03.471250
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    exc = AudioConversionError("message")
    assert str(exc) == "message"



# Generated at 2022-06-24 14:09:04.310808
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:09:07.639566
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.set_downloader is not None
    assert pp.run is not None
    assert pp.try_utime is not None
    assert pp._configuration_args is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:09:12.783968
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        # create a temp file
        import tempfile
        _, path = tempfile.mkstemp()
        # create a temp PostProcessor object
        pp = PostProcessor(None)
        # try to update atime and mtime
        pp.try_utime(path, 0, 0, 'test_try_utime')
        import os
        os.unlink(path)
    except PostProcessingError:
        pass
    else:
        # We should raise error if we cannot update utime
        raise AssertionError('This should raise error')

# Generated at 2022-06-24 14:09:21.110863
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():

    class FakePostProcessor(PostProcessor):

        def run(self, information):
            information['title'] = 'FakePostProcessor'
            return [], information

    class FakeInfoExtractor(object):

        def extract(self, url):
            information = {
                'id': 'FakePostProcessor',
                'title': 'Original',
                'url': 'http://example.com/original',
                'ext': 'mp4',
            }
            return information

    class FakeYDL(object):
        def __init__(self):
            self.tmpfilename = 'tmpfile'
            self.params = {}

        def to_screen(self, s):
            print(s)

        @staticmethod
        def prepare_filename(s):
            return s.replace(' ', '_')


# Generated at 2022-06-24 14:09:26.709465
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('ERROR', 'INPUT', 'OUTPUT', 'ENCODER_OUT', 'ERR_MSG')
    except AudioConversionError as ace:
        assert ace.encoder_out == 'ENCODER_OUT'
        assert ace.err_msg == 'ERR_MSG'
        assert ace.input_file == 'INPUT'
        assert ace.output_file == 'OUTPUT'
    else:
        assert False, 'AudioConversionError not raised'

# Generated at 2022-06-24 14:09:34.885177
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """ Unit test for method try_utime of class PostProcessor. """
    # Make PostProcessor instance
    downloader = None
    pp = PostProcessor(downloader)

    # Create file
    import tempfile
    import time

    temp_file, temp_filename = tempfile.mkstemp()
    os.close(temp_file)

    # Set timestamp to current time
    os.utime(temp_filename, None)

    # Get timestamp
    stat = os.stat(temp_filename)
    old_atime, old_mtime = stat.st_atime, stat.st_mtime

    # Wait a second
    time.sleep(1)

    # Set timestamp to current time
    pp.try_utime(temp_filename, time.time(), time.time())

    # Get timestamp
    stat = os

# Generated at 2022-06-24 14:09:41.955725
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor()
    assert pp._downloader == None
    assert pp.run({'filepath':"test.flv"}) == ([], {'filepath':"test.flv"})
    pp.set_downloader(object())
    assert pp._downloader != None
    assert pp._configuration_args() == []
    assert pp._configuration_args(default=[b'foo']) == [b'foo']
    assert pp.run({'filepath':"test.flv"}) == ([], {'filepath':"test.flv"})

# Generated at 2022-06-24 14:09:46.812865
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class MyPostProcessor(PostProcessor):
        def run(self, information):
            return information, information

    my_post_processor = MyPostProcessor()
    assert isinstance(my_post_processor, MyPostProcessor)
    assert my_post_processor.run({}) == ({}, {})

# Generated at 2022-06-24 14:09:53.736569
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
            self.has_run = False
        def run(self, information):
            self.has_run = True
            return [], information
    pp = TestPP()
    pp.run({'filepath': True})
    assert pp.has_run

# Generated at 2022-06-24 14:09:55.986404
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors.values():
        for pp in ie.get_postprocessors():
            pp.set_downloader(None)

# Generated at 2022-06-24 14:10:01.747361
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockInfoExtractor(object):
        pass

    class MockDownloader(object):
        def __init__(self):
            self.filesToDelete = []

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def trouble(self, msg):
            pass

        def temp_name(self, filename):
            return filename + '.tmp'

    class MockPostProcessor(PostProcessor):
        def run(self, info):
            self._downloader.filesToDelete.append(info['filepath'])
            return [], info

    ie = MockInfoExtractor()
    ie. IE_NAME = 'mock'
    ie.params = {}


# Generated at 2022-06-24 14:10:05.549473
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp._downloader is None
    pp.set_downloader(downloader=object())
    assert pp._downloader


if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:10:15.454551
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys

    class MockInfoExtractor(object):
        def __init__(self, test_instance):
            self.test_instance = test_instance
            self.test_instance.expected_data_dicts = []

        def extract(self, url):
            self.test_instance.assertEqual(url, 'url')

            # This has all the data dictionaries for each of the three
            # post processors. The last element is the file path post
            # processors use.

# Generated at 2022-06-24 14:10:23.294993
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # This PostProcessor always returns the unchanged information
    # dictionary
    class UnchangedPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = UnchangedPP()
    info = {}
    assert pp.run(info) == ([], info)
    info = {'one': 'two'}
    assert pp.run(info) == ([], info)
    info['filepath'] = 'C:\\Windows\\System32\\con.exe'
    assert pp.run(info) == ([], info)



# Generated at 2022-06-24 14:10:32.468422
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import shutil
    from ..utils import TempFile

    with TempFile(prefix='doc-test-') as path:
        test_file = open(path,'w')
        test_file.close()

        try_utime = PostProcessor().try_utime
        import time
        atime = mtime = time.time() - 100

        try_utime(path, atime, mtime)
        assert os.path.getatime(path) == atime
        assert os.path.getmtime(path) == mtime

        try_utime(path + '-not-existing', atime, mtime)


if __name__ == '__main__':
    test_PostProcessor_try_utime()