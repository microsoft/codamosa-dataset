

# Generated at 2022-06-24 14:00:37.191166
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .test_utils import FakeDownloader
    from .test_utils import FakeYDL
    from .test_utils import FakeFile
    from .test_utils import expect_warning
    from test.test_utils import FakeStdout

    class FakePostProcessor(PostProcessor):
        def __init__(self):
            super(FakePostProcessor, self).__init__()

    fp = FakePostProcessor()
    dl = FakeDownloader()
    fp.set_downloader(dl)

    # Test that warning message is printed if os.utime fails
    with expect_warning(FakeYDL(), 'Cannot update utime of file'):
        with FakeStdout():
            fp.try_utime('file', 0, 0)

# Generated at 2022-06-24 14:00:43.028093
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    pp = PostProcessor()

    # Test with a FileDownloader object
    file_downloader = FileDownloader({})
    pp.set_downloader(file_downloader)
    assert pp._downloader == file_downloader

    # Test with a None object
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-24 14:00:45.455777
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        pass

    pp = TestPP()
    assert pp
    assert not pp._downloader

# Generated at 2022-06-24 14:00:57.579544
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class TestPostProcessor(PostProcessor):
        def set_downloader(self, downloader):
            self.downloader = downloader
    class TestDownloader(object):
        def __init__(self):
            self.warnings = []
        def report_warning(self, msg):
            self.warnings.append(msg)
    class TestFile(object):
        def __init__(self, path):
            self.path = path
            self.utime = []
        def utime(self, atime, mtime):
            self.utime.append((atime, mtime))
        def close(self):
            pass

    # Prepare the test
    postprocessor = TestPostProcessor()
    downloader = TestDownloader()
    postprocessor.set_downloader(downloader)

    # Test that utime

# Generated at 2022-06-24 14:00:58.660843
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:01:09.497972
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    # AudioConversionError()
    error_obj = AudioConversionError()
    assert(isinstance(error_obj, Exception))
    # AudioConversionError(msg)
    error_msg = 'test error'
    error_obj = AudioConversionError(error_msg)
    assert(isinstance(error_obj, Exception))
    assert(str(error_obj) == error_msg)
    # AudioConversionError(msg, filename)
    filename = r'C:\test.txt'
    error_obj = AudioConversionError(error_msg, filename)
    assert(isinstance(error_obj, Exception))
    assert(str(error_obj) == error_msg + ': \'' + filename + '\'')
    # AudioConversionError(msg, filename, cmd)

# Generated at 2022-06-24 14:01:10.767932
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:01:14.488718
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError(5)
    assert err.conversion_code == 5
    assert err.error_msg == 'Unknown error'

    err = AudioConversionError(6, 'test msg')
    assert err.conversion_code == 6
    assert err.error_msg == 'test msg'

# Generated at 2022-06-24 14:01:21.386505
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from unittest.mock import patch

    from .test_utils import FakeYDL

    with patch('os.utime') as mock_utime:
        with patch('os.path.getatime') as mock_getatime, \
                patch('os.path.getmtime') as mock_getmtime:

            mock_getatime.return_value = 0
            mock_getmtime.return_value = 0

            ydl = FakeYDL()
            pp = PostProcessor(ydl)
            path = '/path/to/file'
            atime = 1234
            mtime = 5678
            pp.try_utime(path, atime, mtime)
            mock_utime.assert_called_with(path, (atime, mtime))

            mock_getatime.assert_called_

# Generated at 2022-06-24 14:01:24.041719
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    test = PostProcessor()
    assert isinstance(test, PostProcessor)

# Generated at 2022-06-24 14:01:24.695046
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:01:34.125983
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    def raise_oserror():
        raise OSError(0, 'msg', 'path')
    from ..utils import post_processing
    import sys
    import pytest
    post_proc = post_processing.PostProcessor(None)
    with pytest.raises(PostProcessingError) as excinfo:
        os_error = OSError(0, 'msg', 'path')
        post_proc.try_utime('path', 0, 0, errnote='Cannot update utime of file')
    assert 'Cannot update utime of file: msg: path' == str(excinfo.value)
    post_proc.try_utime('path', 0, 0, errnote='Cannot update utime of file')


# Static method useful for downloader tests

# Generated at 2022-06-24 14:01:42.080480
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    import types

    class DummyDownloader():
        def __init__(self):
            self.params = {"a" : True}

    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            super(DummyPostProcessor, self).__init__(downloader)
            self.pp_args = self._configuration_args(["testarg"])

        def run(self, information):
            if information["a"] == self.pp_args[0]:
                information["a"] = False
            return [], information

    pp = DummyPostProcessor(DummyDownloader())
    information = {"a" : True, "filepath" : open(sys.argv[0], "rb")}
    pp.run(information)
    assert not information["a"]



# Generated at 2022-06-24 14:01:45.060574
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    import sys
    try:
        raise AudioConversionError('video', 'mp3', sys.exc_info())
    except AudioConversionError as err:
        assert 'video' in err.message
        assert 'mp3' in err.message

# Generated at 2022-06-24 14:01:47.240573
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor(YoutubeDL())
    assert pp._downloader



# Generated at 2022-06-24 14:01:57.671500
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from youtube_dl.downloader.YoutubeDLDownloader import YoutubeDLDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor.FFmpegPostProcessor import FFmpegPostProcessor

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    def test_hook(_):
        pass

    ydl.add_post_processor(FFmpegPostProcessor(ydl, nopostoverwrites=False, downloader=YoutubeDLDownloader(ydl, {})))
    ydl.add_progress_hook(test_hook)

    p = PostProcessor(ydl)
    p.set_downloader(ydl)

# Generated at 2022-06-24 14:02:09.023189
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t')
    except AudioConversionError as e:
        e.stdout == 'a'
        e.stderr == 'b'
        e.exit_code == 'c'
        e.postprocessor_name == 'd'
        e.basename == 'e'
        e.dirname == 'f'
        e.dst_basename == 'g'
        e.dst_dirname == 'h'
        e.reason == 'i'
        e.type == 'j'
        e.format == 'k'
        e.ext == 'l'

# Generated at 2022-06-24 14:02:14.193498
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [], info
    pp = TestPP()
    pp.set_downloader(None)
    # the info field is needed and it must contain the "filepath" field
    assert pp.run({}) == ([], {})
    assert pp.run({'filepath': 'foo.mp4'}) == ([], {'filepath': 'foo.mp4'})
    # the "filepath" field may not be empty
    assert pp.run({'filepath': ''}) == ([], {'filepath': 'foo.mp4'})

# Generated at 2022-06-24 14:02:17.762636
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        assert False, 'test-created error'
    except AssertionError as err:
        exc = AudioConversionError(err)
        assert str(exc) == 'test-created error'
        assert exc.cause == err

# Generated at 2022-06-24 14:02:20.622448
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    dl = YoutubeDL()
    pp = PostProcessor(dl)
    assert pp._downloader is dl
    pp.set_downloader(None)
    assert pp._downloader is None

# Generated at 2022-06-24 14:02:22.485927
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=no-member
    """Unit test for constructor of class PostProcessor."""
    PostProcessor()



# Generated at 2022-06-24 14:02:24.031977
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError
    except PostProcessingError as e:
        pass

# Generated at 2022-06-24 14:02:34.948280
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = TestPP()

# Generated at 2022-06-24 14:02:35.627096
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:02:39.101799
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pp = PostProcessor(None)
    assert pp.run({}) == ([], {})
    assert pp.run({'filepath': 'spam'}) == ([], {'filepath': 'spam'})

# Generated at 2022-06-24 14:02:48.128123
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():

    class TestPostProcessor1(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader
            self.downloader_set = False
            super(TestPostProcessor1, self).__init__(downloader)

        def set_downloader(self, downloader):
            self.downloader_set = True

    class TestPostProcessor2(PostProcessor):
        def __init__(self, downloader=None):
            self._downloader = downloader
            self.downloader_set = False
            super(TestPostProcessor2, self).__init__(downloader)

        def set_downloader(self, downloader):
            self.downloader_set = True

    class TestDownloader(object):
        def __init__(self):
            self.pp1

# Generated at 2022-06-24 14:02:50.714849
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(u'test message')
    except AudioConversionError as err:
        assert str(err) == u'test message'


# Generated at 2022-06-24 14:03:00.080202
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import time
    import shutil
    import os

    tf = tempfile.NamedTemporaryFile()

    old_utime = os.stat(tf.name).st_atime, os.stat(tf.name).st_mtime
    time.sleep(1)

    pp = PostProcessor(None)
    pp.try_utime(tf.name, 1, 1)
    new_utime = os.stat(tf.name).st_atime, os.stat(tf.name).st_mtime

    tf.close()

    assert old_utime != new_utime
    assert new_utime == (1, 1)

# Generated at 2022-06-24 14:03:00.633456
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()

# Generated at 2022-06-24 14:03:11.824867
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from ..YoutubeDL import YoutubeDL
    import tempfile
    from ..utils import sanitize_open
    tmp_name = tempfile.mktemp(prefix='postprocessor_test')
    # Create empty temporary file
    with sanitize_open(tmp_name, 'wb') as f:
        pass

    # Test if os.utime is called
    from .test_FileDownloader import DummyYDL
    DummyYDL.called = False
    class DummyPostProcessor(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)
        def try_utime(self, path, atime, mtime, errnote=None):
            if path == tmp_name:
                DummyYDL.called = True
            return PostProcessor.try_

# Generated at 2022-06-24 14:03:21.031739
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """
    test PostProcessor.run()
    """
    # Mocked objects
    class MockFP():
        def __init__(self, fname, mode):
            pass

        def read(self, len):
            return 'mock'

        def tell(self):
            return 0

        def seek(self, pos, rel):
            pass

        def close(self):
            pass

    class MockInfoExtractor():
        def __init__(self, ydl):
            pass

        def get_filename(self, info_dict):
            return 'mock.mp4'

    class MockYDL():
        def __init__(self):
            pass

        def to_screen(self, msg):
            pass

        def to_stdout(self, msg):
            pass


# Generated at 2022-06-24 14:03:23.224161
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test_error')
    except AudioConversionError as err:
        assert err.args[0] == 'test_error'



# Generated at 2022-06-24 14:03:29.279285
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import datetime
    import tempfile
    import shutil
    from pytube import __main__
    from pytube.compat import HTMLParseError
    from pytube.exceptions import RegexMatchError

    # Create directory for unit test
    tests_dir = os.path.join(os.path.dirname(__file__), 'test_files')
    temp_dir = tempfile.mkdtemp()
    # Copy file to directory
    test_file_name = 'data-example-youtube-001.txt'
    test_file_src = os.path.join(tests_dir, test_file_name)
    test_file_dst = os.path.join(temp_dir, test_file_name)
    shutil.copy(test_file_src, test_file_dst)
    # Run unit test

# Generated at 2022-06-24 14:03:29.949486
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    assert PostProcessor()._downloader is None



# Generated at 2022-06-24 14:03:31.605902
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    instance = AudioConversionError("message")
    assert instance.message == "message"
    assert str(instance) == "message"

# Generated at 2022-06-24 14:03:32.647602
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp is not None

# Generated at 2022-06-24 14:03:34.213123
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert pp.downloader == None

    downloader = object()
    pp.set_downloader(downloader)
    assert pp.downloader == downloader

# Generated at 2022-06-24 14:03:39.242775
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import youtube_dl
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    argv = ['', '-v']
    ydl = youtube_dl.YoutubeDL(argv)
    pp = PostProcessor(ydl)
    assert pp.set_downloader(ydl) == None
    assert pp._downloader == ydl

if __name__ == "__main__":
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:03:42.020332
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    try:
        PostProcessor()
    except Exception as e:
        assert False, 'PostProcessor() raises "%s"!' % str(e)


# Generated at 2022-06-24 14:03:47.192981
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # No error
    class _DummyPostProcessor(PostProcessor):
        def run(self, info):
            return [info['filepath']], info

    # Error
    class _DummyPostProcessor2(PostProcessor):
        def run(self, info):
            raise AudioConversionError

    # Subclass of error
    class _DummyPostProcessor3(PostProcessor):
        def run(self, info):
            raise PostProcessingError

    pp = _DummyPostProcessor()
    pp2 = _DummyPostProcessor2()
    pp3 = _DummyPostProcessor3()

    # 'False' means 'keep file'
    assert ([], {'filepath': 'abc'}) == pp.run({'filepath': 'abc'})

    # Raise error if not subclass

# Generated at 2022-06-24 14:03:48.106852
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__ == PostProcessor

# Generated at 2022-06-24 14:03:51.196730
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    ydl = object()
    pp = PostProcessor(ydl)
    assert pp._downloader is ydl
    pp.set_downloader(ydl)
    assert pp._downloader is ydl

# Generated at 2022-06-24 14:04:01.441571
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL

    class TestPP(PostProcessor):
        def __init__(self, downloader=None):
            PostProcessor.__init__(self, downloader)
        def run(self, information):
            return [information['filepath']], information

    ydl = YoutubeDL({'logger': YoutubeDL.noop_print})
    pp = TestPP(downloader=ydl)

    # Downloads 5 files and waits for each to finish

# Generated at 2022-06-24 14:04:02.726131
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(None, None, None, None, None)
    except AudioConversionError:
        pass

__all__ = ['PostProcessor']

# Generated at 2022-06-24 14:04:06.019059
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    # pylint: disable=redefined-outer-name
    """
    Test case for class PostProcessor
    """
    from ..downloader import Downloader
    d = Downloader()
    pp = PostProcessor(d)
    assert pp._downloader is d
    assert isinstance(pp, PostProcessor)
    pp.set_downloader(d)
    assert pp._downloader is d

# Generated at 2022-06-24 14:04:08.718358
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """ Test if PostProcessor.set_downloader(downloader) method can return the
    right value.
    """
    pp = PostProcessor()
    downloader = object()
    pp.set_downloader(downloader)
    assert pp._downloader == downloader

# Generated at 2022-06-24 14:04:12.937271
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class _Fake_Dummy(object):
        def __init__(self):
            self.dummy = None

        def set_dummy(self, d):
            self.dummy = d
    d = _Fake_Dummy()
    p = PostProcessor(d)
    p.set_downloader(d)
    assert p._downloader == d
    assert p.dummy == d

# Generated at 2022-06-24 14:04:24.542843
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import sys
    from ..downloader import Downloader

    class MockPostProcessor(PostProcessor):
        """A mock postprocessor that simply returns the file path."""
        def run(self, info):
            return [], info

    class MockDownloader(Downloader):
        """A mock downloader that uses the mock postprocessor."""
        def __init__(self):
            Downloader.__init__(self, params=None)
            self.add_post_processor(MockPostProcessor(self))
            self.to_stdout = lambda s: sys.stdout.write(s + '\n')
            self.to_stderr = lambda s: sys.stderr.write(s + '\n')

# Generated at 2022-06-24 14:04:27.458777
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Create a PostProcessor
    pp = PostProcessor()

    # Verity set_downloader of class PostProcessor
    pp.set_downloader('test_downloader')
    assert pp._downloader == 'test_downloader'

# Generated at 2022-06-24 14:04:28.894952
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    postProcessor = PostProcessor()
    assert postProcessor is not None

# Generated at 2022-06-24 14:04:39.782900
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_str
    from ..extractor import gen_extractors
    from ..downloader import gen_downloader

    class MyPP(PostProcessor):
        def run(self, info):
            assert isinstance(info, dict)
            assert 'filepath' in info

            assert isinstance(info['filepath'], compat_str)
            assert os.path.exists(info['filepath'])

            return [info['filepath'] + '_2'], info

    # Create a test downloader object
    ydl = gen_downloader()

    # And make sure it has no postprocessors
    assert len(ydl._pps) == 0

    # Add our PostProcessor
    ydl.add_post_processor(MyPP())

    # Test if its present in the list

# Generated at 2022-06-24 14:04:48.149229
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    """
    $ python -m youtube_dl.postprocessor.test
    """
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    pp = PostProcessor(ydl)
    pp.set_downloader(None)
    assert pp._downloader is None
    ydl2 = youtube_dl.YoutubeDL()
    pp.set_downloader(ydl2)
    assert pp._downloader == ydl2

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:04:53.196486
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from .common import FileDownloader
    a = FileDownloader()
    a.params['outtmpl'] = '%(id)s'

    pp = PostProcessor(a)
    info = {
        'id': '321'
    }
    (tmp_files, new_info) = pp.run(info)

    assert tmp_files == []
    assert new_info == info

# Generated at 2022-06-24 14:05:04.368683
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from .common import FileDownloader
    from .YoutubeDL import YoutubeDL

    class MyPP(PostProcessor):
        def __init__(self):
            PostProcessor.__init__(self)
            self.downloader = None

        def set_downloader(self, downloader):
            PostProcessor.set_downloader(self, downloader)
            if isinstance(downloader, FileDownloader):
                self.downloader = 'FileDownloader'
            elif isinstance(downloader, YoutubeDL):
                self.downloader = 'YoutubeDL'

    pp = MyPP()
    fd = FileDownloader({})
    ydl = YoutubeDL({})
    pp.set_downloader(fd)
    assert pp.downloader == 'FileDownloader'
    pp.set_downloader(ydl)


# Generated at 2022-06-24 14:05:10.167259
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError(
            'audio_conversion_failure', 'Input file', 'converter', 128, 128)
    except AudioConversionError as e:
        assert e.format_message() == 'audio_conversion_failure: Input file: converter: exit code 128, stderr output: 128'



# Generated at 2022-06-24 14:05:12.780645
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    pp = PostProcessor()
    dl = YoutubeDL()
    assert pp._downloader is None
    pp.set_downloader(dl)
    assert pp._downloader == dl

# Generated at 2022-06-24 14:05:20.445944
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    # Create a subclass of the PostProcessor class
    # TODO: Use inherit from the object class

    class TestPostProcessor(PostProcessor):

        def run(self, information):
            return [], information  # Keep file and do nothing
    # Create an instance of the downloader class
    test_downloader = object()
    # Create an instance of the TestPostProcessor class
    test_post_processor = TestPostProcessor(test_downloader)
    # Check that the method run returns the same result given the same input
    assert test_post_processor.run({}) == ([], {})

# Generated at 2022-06-24 14:05:24.186983
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Create downloader to mock it.
    class MockDownloader(object):
        def __init__(self):
            self.params = {
                'logger': 'mock_logger'
            }

        def report_warning(self, msg):
            print(msg)

    # Create instance of error class.
    err = PostProcessingError('error')
    # Create instance of class
    pp = PostProcessor(MockDownloader())
    # Call method
    pp.try_utime('filepath', 1, 2, 'errnote')

# Generated at 2022-06-24 14:05:25.795717
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    test_downloader = None
    test_PP = PostProcessor(test_downloader)
    assert test_PP._downloader == test_downloader

# Generated at 2022-06-24 14:05:28.056580
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    ydl = object()
    pp = PostProcessor(ydl)
    assert pp.run({}) == ([], {})



# Generated at 2022-06-24 14:05:31.637609
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():  # pylint: disable=W0613,R0201
    """Test the constructor of class AudioConversionError."""

    error = AudioConversionError("test message")  # Action
    assert error.cause == "test message"



# Generated at 2022-06-24 14:05:37.320819
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class TestPP(PostProcessor):
        def run(self, info):
            return [], info

    pp = TestPP()
    pp.set_downloader(None)
    assert pp.run({'a': 'b', 'filepath': 'c.d'}) == ([], {'a': 'b', 'filepath': 'c.d'})


_postprocessors = {}



# Generated at 2022-06-24 14:05:44.611147
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """ Tests postprocessor.PostProcessor.run """
    # Create a Mock downloader
    class MockDownloader():
        @staticmethod
        def report_warning(errnote):
            pass

        @staticmethod
        def to_screen(message):
            pass

    # Create a PostProcessor mock object
    pp = PostProcessor(MockDownloader)
    # Initialize it's variable "outputname" using the protected method "_match_entry()"
    pp.outputname = "outputname"

    # Run the PostProcessor
    pp.run("information")

# Generated at 2022-06-24 14:05:47.423699
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError(): # pylint: disable=missing-docstring
    AudioConversionError()
    try:
        raise AudioConversionError
    # pylint: disable=bare-except
    except:
        pass

# Generated at 2022-06-24 14:05:50.385141
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pp = PostProcessor(None)
    # We cannot check the error message here, because it depends on the system
    # language and local.
    try:
        pp.try_utime(None, 0, 0)
        assert False
    except PostProcessingError:
        pass

# Generated at 2022-06-24 14:06:00.989352
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    """
    Test method try_utime of PostProcessor without os.utime.
    """
    import sys
    import tempfile
    import os
    from .test_utils import config_tmpdir, FakeYDL

    if sys.platform == 'win32':
        return

    def fake_utime(param, atime, mtime):
        raise OSError

    def check_warning(dummy_message, dummy_category, dummy_filename, dummy_lineno, message, dummy_file=None, *args):
        assert message == 'Cannot update utime of file'

    orig_utime = os.utime
    os.utime = fake_utime
    orig_check_warning = FakeYDL.report_warning
    FakeYDL.report_warning = check_warning


# Generated at 2022-06-24 14:06:06.856129
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    import sys
    import nose.tools
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL

    downloader = FakeYDL()

    class MyTestPP(PostProcessor):
        _downloader = None

        def __init__(self, downloader=None):
            super(MyTestPP, self).__init__(downloader)

        def run(self, info):
            return [], info

    pp = MyTestPP()
    nose.tools.assert_equal(pp._downloader, None)
    pp.set_downloader(downloader)
    nose.tools.assert_equal(pp._downloader, downloader)

if __name__ == '__main__':
    test_PostProcessor_set_downloader()

# Generated at 2022-06-24 14:06:09.585727
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    assert str(AudioConversionError('sample.mp3', 'ogg')) == 'ffmpeg or avconv not found. Please install one.'


# Generated at 2022-06-24 14:06:12.790767
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('Some error message')
    except AudioConversionError as exception:
        assert str(exception) == 'Some error message'

# Generated at 2022-06-24 14:06:15.830331
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader

    downloader = FileDownloader()
    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return ['bar', info]

    tp = TestPostProcessor()
    assert tp._downloader is None
    tp.set_downloader(downloader)
    assert tp._downloader == downloader

# Generated at 2022-06-24 14:06:20.808956
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class MockDownloader(object):
        pass
    dummy_pp = PostProcessor()
    downloader = MockDownloader()
    dummy_pp.set_downloader(downloader)
    assert dummy_pp._downloader is downloader


# Generated at 2022-06-24 14:06:29.806904
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time
    import shutil
    import os
    import random

    import tempfile
    tmpdir = tempfile.mkdtemp()
    atime = time.time()
    mtime = time.time()
    # Let's create a file and try to update atime and mtime
    fname = os.path.join(tmpdir, 'file')
    f = open(fname, 'wb')
    f.write(bytes(bytearray(random.getrandbits(8) for _ in range(100))))
    f.close()
    pp = PostProcessor(None)
    pp.try_utime(fname, atime, mtime)
    shutil.rmtree(tmpdir)

if __name__ == '__main__':
    test_PostProcessor_try_utime()

# Generated at 2022-06-24 14:06:34.512777
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..compat import compat_os_name

    from . import postprocessor

    # Run a PostProcessor object
    pp = postprocessor.PostProcessor(None)
    pp_data = {}
    files_to_delete, pp_data = pp.run(pp_data)
    assert (files_to_delete, pp_data) == ([], {})

    # Try to open a file for writing on a read-only directory
    if compat_os_name != 'nt':
        os.mkdir('/test_youtube-dl/postprocessor')
        os.mkdir('/test_youtube-dl/postprocessor_test')
        os.utime('/test_youtube-dl/postprocessor', (6000, 6000))
        os.chmod('/test_youtube-dl/postprocessor', 0o400)

# Generated at 2022-06-24 14:06:46.904937
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    from ..downloader import FileDownloader
    from ..compat import compat_str
    from .xattrpp import XAttrMetadataPP
    from .execafterdownload import ExecAfterDownloadPP
    from .metadatafromtitle import MetadataFromTitlePP

    # Test default behavior of PostProcessor.run()
    pp = PostProcessor(None)
    information = {'filepath': 'myfile'}
    filepath, new_information = pp.run(information)
    assert filepath == []
    assert new_information == information

    # Test running of PostProcessors in a chain.
    fd = FileDownloader()
    fd.params['writedescription'] = True
    fd.params['writeinfojson'] = True
    metadata_pp = XAttrMetadataPP(fd)
    exeafterdownload_pp = ExecAfter

# Generated at 2022-06-24 14:06:54.477860
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class FakeDownloader:
        def __init__(self):
            self.warning_count = 0

        def report_warning(self, msg):
            self.warning_count += 1

    class FakePostProcessor(PostProcessor):

        def __init__(self):
            self.downloader = FakeDownloader()

    filepath = 'test'
    atime = 1543118388
    mtime = 1543118388

    pp = FakePostProcessor()
    pp.try_utime(path=filepath, atime=atime, mtime=mtime, errnote='Cannot update utime of file')
    assert pp.downloader.warning_count == 0

    error_filepath = 123

# Generated at 2022-06-24 14:07:00.890138
# Unit test for method run of class PostProcessor

# Generated at 2022-06-24 14:07:05.637410
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class TestPostProcessor(PostProcessor):
        def __init__(self, downloader=None):
            super(TestPostProcessor, self).__init__(downloader=downloader)
            self._downloader = downloader

        def run(self, information):
            return [], information

    pp = TestPostProcessor()
    pp.set_downloader('downloader')
    assert pp._downloader == 'downloader'

# Generated at 2022-06-24 14:07:06.478943
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    mytest = PostProcessor()
    assert isinstance(mytest, PostProcessor)

# Generated at 2022-06-24 14:07:15.909351
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # Prepare a temp directory
    import tempfile
    temp_dir = tempfile.mkdtemp(suffix='-YTDL-PP-UT')
    # Create temp file to use with the test
    file_path = os.path.join(temp_dir, 'temp')
    with open(file_path, 'w') as f_out:
        f_out.write('Temporary file for testing')
    # Load PostProcessor class
    from ..extractor import gen_extractors
    from ..downloader import gen_downloaders
    from ..postprocessor import gen_postprocessors
    gen_extractors()
    gen_downloaders()
    gen_postprocessors()
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    # Change atime and mtime of the file
    import time
    path_at

# Generated at 2022-06-24 14:07:19.925003
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp.__class__.__name__ == 'PostProcessor'
    assert pp.__class__.__module__ == 'youtube_dl.postprocessor'
    assert pp._downloader is None

# Generated at 2022-06-24 14:07:20.271269
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    pass

# Generated at 2022-06-24 14:07:22.931429
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..YoutubeDL import YoutubeDL
    p = PostProcessor(downloader=None)
    p.set_downloader(YoutubeDL({}))
    assert p._downloader is not None

# Generated at 2022-06-24 14:07:28.708445
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    """Test if PostProcessor works as intended."""
    class FileDeletionPP(PostProcessor):
        def run(self, information):
            return [information['filepath']], information
    class InfoTagPP(PostProcessor):
        def run(self, information):
            information.update({'key': 'value'})
            return [], information

    pp1 = FileDeletionPP()
    pp2 = InfoTagPP()
    pp1.set_downloader(pp2)

    result = pp1.run({'filepath': 'filepath', 'test': 'test'})

    assert result[0] == ['filepath'], 'File deletion postprocessor does not return the file path.'
    assert result[1] == {'key': 'value', 'test': 'test'}, 'Consecutive postprocessor do not work properly.'

# Generated at 2022-06-24 14:07:38.452571
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    try:
        from mock import patch
        from ..utils import DateRange
    except ImportError:
        raise # Skip test if the external 'mock' module is not available

    dummy_downloader = 'dummy downloader' # Must be an object

    pp = PostProcessor(dummy_downloader)

    os_utime_mock = patch.object(os, 'utime')
    report_warning_mock = patch.object(dummy_downloader, 'report_warning')
    DateRange_mock = patch.object(DateRange, '__init__', return_value=None)

    with os_utime_mock as mock:
        with report_warning_mock as mock2:
            with DateRange_mock as mock3:
                pp.try_utime('path', 'atime', 'mtime')

# Generated at 2022-06-24 14:07:42.132817
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        def __init__(self, downloader):
            PostProcessor.__init__(self, downloader)

    pp = TestPP(None)
    assert pp._downloader is None
    assert pp._configuration_args() == []

# Generated at 2022-06-24 14:07:44.726323
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    audio_conversion_error = AudioConversionError('test_AudioConversionError')
    assert audio_conversion_error.args[0] == 'test_AudioConversionError'

# Generated at 2022-06-24 14:07:52.077297
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    class Mock_PostProcessor():
        def __init__(self):
            self.errnote_called = False
            self._downloader = object()
            self._downloader.params = {}

        def _configuration_args(self, default=[]):
            return []

        def report_warning(self, errnote):
            self.errnote_called = True


# Generated at 2022-06-24 14:07:59.056381
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    class A(PostProcessor):
        def run(self, something):
            return [], something
    a = A()
    assert a._downloader is None
    class B(A):
        def run(self, something):
            return [], something
    b = B()
    assert b._downloader is None
    b.set_downloader({})
    assert b._downloader == {}
    assert a._downloader is None

# Generated at 2022-06-24 14:07:59.564152
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:08:10.922690
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.extractor.common import InfoExtractor
    from .youtube_dl.compat import urlopen
    import tempfile
    import os
    import shutil
    import time
    import stat

    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s', 'verbose': True})
    ydl.add_info_extractor(InfoExtractor('test_IE'))
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 14:08:13.548288
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    err = AudioConversionError('test')
    assert err.args == ('test',)
    assert str(err) == 'test'



# Generated at 2022-06-24 14:08:21.045344
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import time

    # Create temporary files
    import tempfile
    fd, fp = tempfile.mkstemp(prefix=b'ytdl_test_')
    os.close(fd)

# Generated at 2022-06-24 14:08:21.594337
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:08:24.244856
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    post_processor = PostProcessor()
    downloader = "downloader"
    post_processor.set_downloader(downloader)
    assert post_processor._downloader == downloader

# Generated at 2022-06-24 14:08:33.014799
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    import tempfile
    import os
    import shutil
    import sys
    from subprocess import Popen, PIPE
    class DummyDnld(object):
        def __init__(self):
            self.temp_name = tempfile.mkdtemp(prefix='youtube-dl-test_PostProcessor_try_utime')
        def report_warning(self, str):
            sys.stderr.write(str + '\n')
            sys.stderr.flush()
        def __del__(self):
            shutil.rmtree(self.temp_name)
    class DummyPP(PostProcessor):
        def __init__(self):
            self.set_downloader(DummyDnld())
    # File is writable

# Generated at 2022-06-24 14:08:34.409394
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    constructor_object = AudioConversionError()
    assert constructor_object is not None


# Generated at 2022-06-24 14:08:38.672738
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    pp = PostProcessor()
    assert (pp._downloader == None)
    pp.set_downloader(None)
    assert (pp._downloader == None)
    pp.set_downloader("test")
    assert (pp._downloader == None)

# Generated at 2022-06-24 14:08:41.668776
# Unit test for constructor of class AudioConversionError

# Generated at 2022-06-24 14:08:42.166728
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    pass

# Generated at 2022-06-24 14:08:49.407390
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    # Test the PostProcessor's method set_downloader(downloader)
    # by passing it a fake downloader object
    from ..extractor import YoutubeIE

    # Fake downloader object
    class downloader():
        def __init__(self, ie_key):
            self._ies = [ie_key]
        def to_stdout(self, msg):
            return 0

    fake_downloader = downloader(YoutubeIE.ie_key())

    # Test setting the downloader
    pp = PostProcessor(None)
    pp.set_downloader(fake_downloader)
    # Test that the downloader is not None
    assert pp._downloader is not None
    # Test that the correct downloader object is set in the PostProcessor
    assert isinstance(pp._downloader, downloader)

# Generated at 2022-06-24 14:08:51.401791
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError("some error")
    except AudioConversionError as e:
        assert str(e) == "some error"
        assert e.cause is None

# Generated at 2022-06-24 14:08:54.283419
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader import Downloader

    processor = PostProcessor()
    downloader = Downloader()
    processor.set_downloader(downloader)
    assert downloader == processor._downloader

# Generated at 2022-06-24 14:09:05.463462
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():

    class MockPostProcessor(PostProcessor):
            pass

    class MockDownloader():

        def __init__(self, module_path):
            self.params = {
                'download_archive': os.path.join(module_path, 'test.archive'),
                'restrictfilenames': True
            }

        @staticmethod
        def report_warning(errnote):
            pass

    class MockFaker():

        def __init__(self):
            self.fakes = {}
            self.fakes['os'] = self
            self.fakes['os.utime'] = self.utime

        @staticmethod
        def utime(path, times):
            # No-op: successfully do nothing
            pass

    import sys
    import os
    import tempfile
    import shutil

    # Mock out os.

# Generated at 2022-06-24 14:09:12.784343
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    import tempfile

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [], info

    url_prefix = 'http://localhost:'
    req = compat_urllib_request.Request(url_prefix + '%d/test' % os.getpid())

    ie = InfoExtractor()
    ie.add_info_extractor(lambda url: {
        'id': 'test',
        'ext': 'mkv',
        'url': url_prefix + '%d/test.mkv' % os.getpid(),
    })
    ie.extract(req.get_full_url())
    fd = FileDownload

# Generated at 2022-06-24 14:09:14.428492
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    test_error = AudioConversionError('Test')
    assert test_error.reason == 'Test'


# Generated at 2022-06-24 14:09:22.021515
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..downloader.common import FileDownloader
    from ..downloader.external import \
        FFmpegExtractAudioPP, FFmpegMergerPP, \
        FFmpegAudioFixPP, FFmpegMetadataPP, FFmpegEmbedSubtitlePP

    postprocessors = [
        FFmpegExtractAudioPP(),
        FFmpegMergerPP(),
        FFmpegAudioFixPP(),
        FFmpegMetadataPP(),
        FFmpegEmbedSubtitlePP(),
    ]

    # Test "set_downloader(downloader)"
    downloader = FileDownloader(params={})
    for pp in postprocessors:
        pp.set_downloader(downloader)
        assert pp._downloader is downloader

    # Test "set_downloader(downloader) raises error"

# Generated at 2022-06-24 14:09:32.519976
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    import unittest
    import sys
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            return [], info
    class TestPostProcessor(unittest.TestCase):
        def test_run(self):
            pp = DummyPostProcessor()
            info = {
                'id': 'testid',
                'title': 'testtitle',
                'filename': 'testfilename',
                'format': 'testformat',
                'ext': 'testext',
                'duration': '10'
            }
            path = 'testfilepath'
            delfilelist, updated_info = pp.run(info)
            self.assertIsInstance(delfilelist, (list, tuple), 'Invalid type for delfilelist in PostProcessor')

# Generated at 2022-06-24 14:09:37.045339
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
  from ..downloader.common import FileDownloader
  assert PostProcessor(downloader=None)._downloader is None
  assert PostProcessor(downloader=True)._downloader is True
  assert PostProcessor(downloader=FileDownloader())._downloader is not None

# Generated at 2022-06-24 14:09:44.587252
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    try:
        from collections import OrderedDict
    except ImportError:
        OrderedDict = dict  # NOQA

    try:
        import nose.core
    except ImportError:
        import nose  # NOQA

    class TestPostProcessor(PostProcessor):
        def run(self, information):
            information['a'] = 1
            information['b'] = 2
            return [], information

    tests = OrderedDict()

    def test_pp(self, expected_information, expected_files_to_delete):
        information = OrderedDict()
        files_to_delete = []
        pp = TestPostProcessor()
        pp.set_downloader(self)
        result = pp.run(information)
        files_to_delete.extend(result[0])

# Generated at 2022-06-24 14:09:46.195001
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    pp = PostProcessor()
    assert pp


# Generated at 2022-06-24 14:09:48.486660
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    try:
        raise AudioConversionError('test')
    except AudioConversionError as err:
        assert err.msg == 'test'
        assert not err.cause



# Generated at 2022-06-24 14:09:51.069854
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    message = 'test error message'
    audio_conversion_error = AudioConversionError(message)
    assert audio_conversion_error.message == message
    assert audio_conversion_error.code == 1



# Generated at 2022-06-24 14:09:59.007717
# Unit test for constructor of class AudioConversionError
def test_AudioConversionError():
    error = AudioConversionError('a', 'b', None, True)
    assert error.src == 'a'
    assert error.dst == 'b'
    assert error.live is True
    assert error.msg is None

    error = AudioConversionError('a', 'b', 'c', False)
    assert error.src == 'a'
    assert error.dst == 'b'
    assert error.live is False
    assert error.msg == 'c'

    error = AudioConversionError('a', 'b', 'c')
    assert error.src == 'a'
    assert error.dst == 'b'
    assert error.live is False
    assert error.msg == 'c'

# Generated at 2022-06-24 14:10:00.058745
# Unit test for method try_utime of class PostProcessor
def test_PostProcessor_try_utime():
    # TODO
    pass

# Generated at 2022-06-24 14:10:11.932167
# Unit test for method set_downloader of class PostProcessor
def test_PostProcessor_set_downloader():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..postprocessor import PostProcessor

    class TestPP(PostProcessor):
        def test(self):
            return self._downloader.params['username']

    ydl = Downloader()
    ydl.add_info_extractor(YoutubeIE())
    pp = TestPP()
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    ydl.add_post_processor(pp)
    pp.test()
    ydl.params['username'] = u'foobar'
    pp.set_downloader(ydl)
    if pp.test() != 'foobar':
        raise Exception('Postprocessors\'s method set_downloader failed.')
    else:
        print

# Generated at 2022-06-24 14:10:22.846719
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class DummyPostProcessor(PostProcessor):
        def run(self, info):
            info['title'] = 'DummyPostProcessor was run'
            return [], info

    class TestDownloader(object):
        def __init__(self):
            self.pp = DummyPostProcessor(downloader=self)
            self.result_title = 'result'

        def report_warning(self, msg):
            pass

    downloader = TestDownloader()


# Generated at 2022-06-24 14:10:26.029782
# Unit test for constructor of class PostProcessor
def test_PostProcessor():
    class TestPP(PostProcessor):
        _downloader = None

    pp = TestPP()
    assert pp is not None

if __name__ == '__main__':
    test_PostProcessor()

# Generated at 2022-06-24 14:10:35.877082
# Unit test for method run of class PostProcessor
def test_PostProcessor_run():
    class MockPostProcessor1(PostProcessor):
        def run(self, info):
            return [], dict(info, field1='afdsa', field2='fdsajkl')

    class MockPostProcessor2(PostProcessor):
        def run(self, info):
            return [], dict(info, field3='ewrew', field4='xcvxcv')

    class MockPostProcessor3(PostProcessor):
        def run(self, info):
            return [], dict(info, field5='dfgdfg', field6='qwert')

    class MockPostProcessor4(PostProcessor):
        def run(self, info):
            return [], dict(info, field7='ertert', field8='jhgjhg')
