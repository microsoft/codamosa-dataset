

# Generated at 2022-06-12 17:35:28.637535
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-12 17:35:38.104241
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # method test
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:44.030168
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie_url = ie._VALID_URL[0]
    ie_url_data = ie._match_id(ie_url)
    assert ie_url_data == '2404147'
    ie_url = ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie_url == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-12 17:35:48.369555
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'Heise'
    assert ie._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-12 17:35:58.642258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-12 17:36:06.182469
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    hie = HeiseIE()
    hie.url = url
    webpage = hie._download_webpage(url, 'test')
    hie._real_extract(url)

# Generated at 2022-06-12 17:36:08.853864
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:36:16.333674
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    regex_result = heiseie._search_regex(heiseie._VALID_URL, url, 'video id')
    assert regex_result == "2404147"

# Generated at 2022-06-12 17:36:18.533024
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-12 17:36:21.133719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE.__init__()
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-12 17:36:34.609421
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'heise:video'
    assert ie.IE_DESC == 'c\'t uplink und heise video'
    assert HeiseIE._VALID_URL == ie._VALID_URL
    assert HeiseIE._TESTS == ie._TESTS
    return

# Generated at 2022-06-12 17:36:42.685719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test for constructors of class HeiseIE. """

# Generated at 2022-06-12 17:36:43.923183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('Heise')



# Generated at 2022-06-12 17:36:49.667754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.extractor_key == "Heise"
    assert ie.info_dict["id"] == "1_kkrq94sm"
    assert ie.info_dict["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:36:51.440001
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-12 17:36:53.716491
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() != YoutubeIE.ie_key()
    assert HeiseIE.ie_key() != KalturaIE.ie_key()
    assert HeiseIE.ie_key() != 'youtube'



# Generated at 2022-06-12 17:36:55.883245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'


# Generated at 2022-06-12 17:37:03.314587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    fixture_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    assert ie.suitable(fixture_url)
    assert ie.ie_key() == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:11.483610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..test_utils import get_testdata_folder
    sample_test_data = get_testdata_folder()
    url = sample_test_data + 'kaltura_video.json'
    heise_ie = HeiseIE()
    print(heise_ie)
    assert heise_ie._match_id('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == '2403911'
    assert heise_ie._match_id('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == '2403911'

# Generated at 2022-06-12 17:37:15.877174
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'
    assert obj.ie_key() == 'Heise'
    assert obj.IE_NAME == 'Heise'
    assert obj.IE_NAME == 'Heise'
    assert obj.ie_key() == 'Heise'
    #assert obj._VALID_URL == r''
    assert obj.ie_key() == 'Heise'


# HeiseIE

# Generated at 2022-06-12 17:37:37.857021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import HeiseIE
    from . import BILDIE
    from . import KalturaIE
    from . import YoutubeIE
    assert HeiseIE is not None
    assert BILDIE is not None
    assert KalturaIE is not None
    assert YoutubeIE is not None

# Generated at 2022-06-12 17:37:39.428016
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # tests/test_heise.py
    assert HeiseIE

# Generated at 2022-06-12 17:37:44.997858
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:37:52.189203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # A Constructor of Unix time.
    #    def __init__(self, year, month=1, day=1, hour=0, minute=0, second=0,
    #                 microsecond=0):
    heiseie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:37:56.420021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# If a class has a constructor, the following code is needed in the test function.
	# Without it, the test still passes but the lines below are not executed.
	# To understand it, visit https://stackoverflow.com/a/12050625
    from .common import InfoExtractor
    InfoExtractor

# Generated at 2022-06-12 17:37:58.645052
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global heise
    heise = HeiseIE()
    print("HEISE TEST")
    print("---------------")

test_HeiseIE()

# Generated at 2022-06-12 17:38:03.351402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2017-7-DVD-3966364.html')
    assert ie.name == 'heise'

# Generated at 2022-06-12 17:38:10.802589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HEISE_URL = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heiseIE = HeiseIE()
    assert heiseIE is not None
    assert heiseIE._VALID_URL == HeiseIE._VALID_URL
    assert heiseIE.suitable(HEISE_URL) == []


# Generated at 2022-06-12 17:38:20.721101
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the constructor for class HeiseIE
    heise_extractor = HeiseIE()
    assert heise_extractor.extractor_key == "Heise"

    # Test for class HeiseIE for method _real_extract
    heise_extractor = HeiseIE()
    yt_urls = heise_extractor._real_extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert yt_urls["title"] == "NEU IM SEPTEMBER | Netflix"
    assert yt_urls["id"] == "6kmWbXleKW4"

    heise_extractor = HeiseIE()
    kaltura_

# Generated at 2022-06-12 17:38:28.414480
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Define a video URL to be passed to the constructor
    video_url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    # Define expected value
    expected_value = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

    # Create a new instance of HeiseIE
    ie = HeiseIE(video_url)

    # Check if title is the one expected
    assert ie.title == expected_value

# Generated at 2022-06-12 17:39:08.821423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('test')
    ie.test()

# Generated at 2022-06-12 17:39:12.650020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl.utils import SearchInfoExtractor
    from youtube_dl.compat import compat_str
    assert any(isinstance(ie, SearchInfoExtractor) and
               ie.SEARCH_KEY in compat_str(ie)
               for ie in InfoExtractor._ies.values())

# Generated at 2022-06-12 17:39:13.824239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass



# Generated at 2022-06-12 17:39:14.553299
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:15.074911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  return HeiseIE()

# Generated at 2022-06-12 17:39:25.625515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from .test_cases import TestCase
    except ImportError:
        from test_cases import TestCase  # NOQA

    class TestHeiseIE(TestCase):
        @staticmethod
        def run_test_for_class(test_instance):
            if test_instance.IE:
                test_instance.assertIsInstance(
                    HeiseIE(), test_instance.IE,
                    'Testing for "%s" failed' % test_instance.IE.__name__)
            else:
                test_instance.expect_failure(
                    'Testing for None failed',
                    exception_class=AssertionError)

    # Test basic constructor

# Generated at 2022-06-12 17:39:34.116464
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # tests for YouTube
    youtube_urls = {'https://www.youtube.com/watch?v=6kmWbXleKW4'
        'https://www.youtube.com/watch?v=AEuL7tYzvrI'
        'https://www.youtube.com/watch?v=eOmSDq3CLYY'
        'https://www.youtube.com/watch?v=1h7VHZoDDQA'
        'https://www.youtube.com/watch?v=EKnIS8q0q4w'
        'https://www.youtube.com/watch?v=DMgOs7yLmWQ'}
    for youtube_url in youtube_urls:
        youtube_ie = YoutubeIE(youtube_url)
        assert youtube_ie is not None
        youtube

# Generated at 2022-06-12 17:39:37.298417
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Make sure that all class is assigned to same IE class
    ie = InfoExtractor(
        {'extractors': ['heise.de']}
    )
    assert len(ie._ies) == 1
    assert list(ie._ies)[0] == HeiseIE

# Generated at 2022-06-12 17:39:38.070980
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
      assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-12 17:39:39.138626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test initialization of HeiseIE class
    HeiseIE()

# Generated at 2022-06-12 17:41:31.232774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/ausgabe/2016-30-Mit-32-Bit-Windows-10-aktuell-halten-3177027.html")
    assert ie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-12 17:41:31.932823
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()

# Generated at 2022-06-12 17:41:33.765356
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise.ie_key() == 'heise'


# Generated at 2022-06-12 17:41:34.197191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:41:36.479446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:41:39.528471
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '1_kkrq94sm'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE().match_url(url) == video_id

# Generated at 2022-06-12 17:41:43.090955
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:41:52.338212
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.title == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    assert ie.id == '1_kkrq94sm'
    assert ie.description == 'Welche Tastatur ist für wen am besten geeignet? Wie sicher ist Owncloud? Und wie kann man einen Peilsender untergebracht in einem USB-Stick nutzen?'
    assert ie.ext == 'mp4'


# Generated at 2022-06-12 17:41:58.663159
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _test_instance
    ie = _test_instance(HeiseIE)
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not ie.suitable('https://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:42:04.325502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    d = HeiseIE()
    # kaltura video
    assert d._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # kaltura video (heise up)
    assert d._real_extract('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    # youtube video
    assert d._real_extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    # heise video