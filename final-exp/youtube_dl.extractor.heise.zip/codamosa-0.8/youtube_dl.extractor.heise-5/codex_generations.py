

# Generated at 2022-06-12 17:35:27.276609
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:35:30.710593
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE based on YouTubeIE
    youtubeIE = HeiseIE._youtube_ie(None)
    assert youtubeIE.__name__ == 'YoutubeIE'

    # HeiseIE based on KalturaIE
    kalturaIE = HeiseIE._kaltura_ie(None)
    assert kalturaIE.__name__ == 'KalturaIE'

# Generated at 2022-06-12 17:35:32.471135
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ == '__main__':
        HeiseIE()._real_initialize()

# Generated at 2022-06-12 17:35:41.848718
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructor
    ie = HeiseIE()
    # Test various possibilities of preparing request
    assert ie._prepare_request("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html") == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-12 17:35:43.496593
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Test for _extract_url

# Generated at 2022-06-12 17:35:51.204346
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:52.120963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()



# Generated at 2022-06-12 17:35:55.821781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("url to the video")
    assert(ie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html")

# Generated at 2022-06-12 17:35:57.654477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:36:00.657285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:10.614081
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-12 17:36:20.415838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE().extract_info(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        download=False)
    assert info['id'] == '1_kkrq94sm'

# Generated at 2022-06-12 17:36:23.629550
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE, '_VALID_URL')
    assert HeiseIE._VALID_URL

    assert hasattr(HeiseIE, '_TESTS')
    assert len(HeiseIE._TESTS) > 0

# Generated at 2022-06-12 17:36:28.020222
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    # name of class
    assert inst._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:33.139914
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.WORKING == True
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    b = ie.extract(url)
    assert b.get('id') == '3959893'
    assert b.get('url') == '1_59mk80sf'
    assert b.get('title') == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert b.get('upload_date') == '20180202'

# Generated at 2022-06-12 17:36:36.706697
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, YoutubeIE)
    assert isinstance(ie, KalturaIE)

# Generated at 2022-06-12 17:36:40.377717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:41.877102
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())


# Generated at 2022-06-12 17:36:43.438451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor without any argument
    HeiseIE()


# Generated at 2022-06-12 17:36:51.429574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # local tests
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:10.445382
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'heise'
    assert obj.ie_name() == 'Heise'
    assert obj.ie_url() == 'https://www.heise.de/'

# Generated at 2022-06-12 17:37:11.403800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:37:17.827813
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return {
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'info_dict': {
            'id': '1_kkrq94sm',
            'ext': 'mp4',
            'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
            'timestamp': 1512734959,
            'upload_date': '20171208',
            'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
        },
        'params': {
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 17:37:27.486425
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # HeiseIE._VALID_URL matches
    match = ie._VALID_URL.match("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert match
    assert match.group("id") == "2404147"
    # HeiseIE._VALID_URL does not match
    assert ie._VALID_URL.match("http://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") is None

# Generated at 2022-06-12 17:37:35.575874
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:37:37.488830
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test whether a simple instantiation would work
    heise_ie = HeiseIE()
    # test whether __version__ is as expected
    assert heise_ie.__version__ == "0.1.7"

# Generated at 2022-06-12 17:37:44.830171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = "2404147"
    test_video_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test_webpage = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

    HeiseIE(test_webpage)

# Generated at 2022-06-12 17:37:46.318295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE._VALID_URL)

# Generated at 2022-06-12 17:37:54.317845
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Unit test for constructor of class HeiseIE")
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE(url)
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-12 17:38:05.601920
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    downloader = HeiseIE()

    assert downloader._VALID_URL == HeiseIE._VALID_URL

    assert HeiseIE.__name__ == 'HeiseIE'
    assert HeiseIE.ie_key() == 'Heise'
    assert HeiseIE.search_ie() == [HeiseIE.ie_key()]
    assert downloader._TESTS == HeiseIE._TESTS


# Generated at 2022-06-12 17:38:29.202419
# Unit test for constructor of class HeiseIE
def test_HeiseIE(): 
    h = HeiseIE()
    url = "https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html"
    h.url = url
    assert(h.url == url)

# Generated at 2022-06-12 17:38:36.577849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # 2016-12-Spiele
    url = 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    test_instance = HeiseIE()
    assert test_instance.suitable(url)
    assert test_instance.IE_NAME == 'heise'
    assert test_instance.IE_DESC == 'Heise'
    # drupal/7
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_instance = HeiseIE()
    assert test_instance.suitable(url)
    assert test_instance.IE_NAME == 'heise'

# Generated at 2022-06-12 17:38:40.717944
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heise_ie = HeiseIE()
    assert heise_ie.suitable(url) == True
    assert heise_ie._real_extract(url) == {'upload_date': '20170830'}

# Generated at 2022-06-12 17:38:41.921995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-12 17:38:45.041031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    match = HeiseIE._VALID_URL.match("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert match is not None, \
        "input url didn't match expected format"
    assert match.group('id') == '2404147'

# Generated at 2022-06-12 17:38:47.552719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:38:55.143978
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:38:59.753663
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:39:01.585004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable(ie._VALID_URL)

# Generated at 2022-06-12 17:39:03.039839
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie!=None

# Generated at 2022-06-12 17:39:40.137496
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:39:41.386025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.__class__.__name__ == 'HeiseIE'


# Generated at 2022-06-12 17:39:42.285200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None


# Generated at 2022-06-12 17:39:43.480468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-12 17:39:49.079011
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:50.357280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:51.772584
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'heise')



# Generated at 2022-06-12 17:39:59.690568
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'Heise')
    assert(ie.ie_name() == 'Heise')
    assert(ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    assert(not ie.suitable('https://video.studierendenwerk-berlin.de/einsplus/dw-tv-einsplus-kuchenstudio-stachelbeerkuchen-mit-mascarpone-schokoladensauce-und-pistazien__1485103223585.html'))

# Generated at 2022-06-12 17:40:00.411731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:40:06.665545
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '2404147'
    # Verify that both URLs are identified as the same video
    url1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-%s.html' % video_id
    url2 = 'http://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-%s.html' % video_id
    assertHeiseIE(url1, video_id) == assertHeiseIE(url2, video_id)

# Construct an instance of HeiseIE and return an extractor

# Generated at 2022-06-12 17:41:49.795909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_heise = HeiseIE()
    assert ie_heise
    # Check if _VALID_URL is a valid URL
    ie_heise._VALID_URL
    # Check if _TESTS is a list
    ie_heise._TESTS
    # Check if _TESTS is not empty
    assert ie_heise._TESTS

# Generated at 2022-06-12 17:41:50.934282
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'

test_HeiseIE()

# Generated at 2022-06-12 17:41:58.103496
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:41:58.712287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE != None)

# Generated at 2022-06-12 17:42:01.555067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == 'heise'
    assert x.ie_key() in globals()['InfoExtractor']._WORKING_IES



# Generated at 2022-06-12 17:42:02.858166
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise:video'
    assert HeiseIE.ie_key() != 'heise'



# Generated at 2022-06-12 17:42:09.025232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE
    test_pattern = r'https?://.*heise\.de/\d{2,}-(?P<id>\d+)\.html'

# Generated at 2022-06-12 17:42:18.993929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for the regex in constructor of class HeiseIE
    regex = HeiseIE._VALID_URL
    # Regular video
    assert HeiseIE._matches_url(regex, 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE._matches_url(regex, 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    # Video with 'newsticker'
    assert HeiseIE._mat

# Generated at 2022-06-12 17:42:26.427737
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:42:38.008054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'