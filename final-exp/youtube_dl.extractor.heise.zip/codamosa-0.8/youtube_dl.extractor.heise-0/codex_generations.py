

# Generated at 2022-06-12 17:35:30.317631
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE

# Generated at 2022-06-12 17:35:31.178017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:35:31.809647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:35:39.639984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    match = HeiseIE._VALID_URL.match("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert match
    ie = HeiseIE(None, None)
    assert ie._match_id(None) == None
    assert ie._extract_url(None) == None
    assert ie._real_extract(None) == None
    assert ie._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._extract_title(None) == None
   

# Generated at 2022-06-12 17:35:45.781506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # given
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # when
    hie = HeiseIE()
    # then
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-12 17:35:49.335968
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    name_of_class = 'HeiseIE'
    test_object = globals()[name_of_class]()
    assert isinstance(test_object, InfoExtractor)

# Generated at 2022-06-12 17:35:54.875830
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.info_extractors[0] == KalturaIE)
    assert(ie.info_extractors[1] == YoutubeIE)
    assert(ie._VALID_URL == r'^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')



# Generated at 2022-06-12 17:35:59.316076
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE()
    info = heise_ie.extract(url)
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:36:01.595374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-12 17:36:02.863485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE())

# Generated at 2022-06-12 17:36:16.037854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_utils import make_test_result

    test_result = make_test_result(HeiseIE)
    test_result.assertTrue(HeiseIE._VALID_URL)
    test_result.assertTrue(HeiseIE._TESTS)

# Generated at 2022-06-12 17:36:25.509471
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for course initialisation"""
    # Valid input
    # Test for initialisation of HeiseIE class
    HeiseIE("www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

    # Invalid input
    # Test for initialisation with no input parameters
    with pytest.raises(TypeError):
        HeiseIE()
    # Test for initialisation with invalid url
    with pytest.raises(ValueError):
        HeiseIE("http://www.heise.de/video/artikel/")
        HeiseIE("http://www.heise.de")

# Generated at 2022-06-12 17:36:35.532466
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:36:36.369689
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:36:39.209844
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..testcases import get_testcases

    for tc in get_testcases(HeiseIE._TESTS):
        HeiseIE()(tc['url'])

# Generated at 2022-06-12 17:36:40.478548
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:36:41.185270
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-12 17:36:47.496280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    obj = HeiseIE()
    actual = obj._real_extract(url)
    assert actual['id'] == '1_ntrmio2s'
    assert actual['description'] == 'md5:47e8ffb6c46d85c92c310a512d6db271'

# Generated at 2022-06-12 17:36:58.738875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Tests against the videos listed in _TESTS."""
    ie = HeiseIE()
    for entry in ie._TESTS:
        name, info = entry.get("name") or "about-us", entry.get("info")
        print("Searching for %s" % name)
        ie.extract(entry.get("url"))
        if info:
            assert_equals(ie.get("id"), info.get("id"))
            assert_equals(ie.get("title"), info.get("title"))
            assert_equals(ie.get("thumbnail"), info.get("thumbnail"))

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-12 17:36:59.388114
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   pass


# Generated at 2022-06-12 17:37:26.109860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    url_info = HeiseIE._match_id(url)
    assert url_info == '3959893', 'Test error: HeiseIE._match_id(%s)' % url
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    url_info = HeiseIE

# Generated at 2022-06-12 17:37:33.459528
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_chrome import test_chrome
    url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html"
    result = test_chrome(url)
    result = HeiseIE()._real_extract(url)
    # ---------------Test Video URL------------------------
    assert result['id'] == '1_kkrq94sm'
    # ---------------Test Title------------------------
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    # ---------------Test Video Upload Date------------------------
    assert result['upload_date'] == '20171208'
    # ---------------Test Video Description------------------------

# Generated at 2022-06-12 17:37:42.495550
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == 0

# Generated at 2022-06-12 17:37:45.119920
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h is not None


# Generated at 2022-06-12 17:37:46.985300
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(
        HeiseIE(),
        HeiseIE
    )


# Generated at 2022-06-12 17:37:48.322481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:37:49.825000
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:38:00.193200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == (
            'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
            '2404147')
    assert HeiseIE._TESTS[2]['info_dict']['id'] == '1_ntrmio2s'
    assert HeiseIE._TESTS[4]['info_dict']['id'] == '1_59mk80sf'
    assert HeiseIE._T

# Generated at 2022-06-12 17:38:00.959552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE != None

# Generated at 2022-06-12 17:38:03.157136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    assert HeiseIE

# Generated at 2022-06-12 17:38:47.964500
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:38:55.474588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert i.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not i.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html/')

# Generated at 2022-06-12 17:38:56.975006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

# Generated at 2022-06-12 17:39:07.121903
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_main import TestIE

# Generated at 2022-06-12 17:39:08.332225
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Verifies that the class HeiseIE can be constructed.
    """
    HeiseIE();


# Generated at 2022-06-12 17:39:12.221469
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract({"url": "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"})

# Generated at 2022-06-12 17:39:15.589682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract( HeiseIE._TESTS[0].get('url') )
    assert ie.result.get('formats')[0].get('format_note') == '1536p'

# Generated at 2022-06-12 17:39:26.173774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert ie.ie_key() == "Heise"
    assert HeiseIE.ie_key() == ie.ie_key()
    assert ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:39:29.672050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE._download_webpage('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
                              '1_kkrq94sm')

# Generated at 2022-06-12 17:39:30.883434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-12 17:41:10.026816
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Unit test to check that URL matches the regex and extract the id of the video

# Generated at 2022-06-12 17:41:14.751428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    # This is just a check that it works.
    # The test that is performed will return correct url of the video, but as video is
    # dynamic, it will change, so in order to have stable tests, there has to be
    # new one for each video, which is not possible, so just one sample test would have to do.
    assert ie._real_extract(ie._VALID_URL)[ie.__name__]['id'] == '1_kkrq94sm'

# Generated at 2022-06-12 17:41:16.173072
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE() 
    assert ie.name == 'Heise'
    assert ie.valid_urls == ['heise.de']

# Generated at 2022-06-12 17:41:18.757015
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_instance = HeiseIE()
    assert heise_instance is not None

# Generated at 2022-06-12 17:41:24.131717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.video_id == '1_kkrq94sm'

# Generated at 2022-06-12 17:41:24.787334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:41:25.809195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    raise NotImplementedError('TODO')

# Generated at 2022-06-12 17:41:26.659017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-12 17:41:27.266605
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:41:29.730933
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-12 17:44:55.712618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hIE = HeiseIE()
    assert hIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:44:57.750987
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.host() == 'heise.de'
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:45:02.442639
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise_extractor = heise._extract_m3u8_formats('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', 'example', 'mp4')
    assert heise_extractor[0].get('url') == 'http://cdnapi.kaltura.com/p/2238431/sp/223843100/playManifest/entryId/1_kkrq94sm/protocol/http/format/url/flavorParamIds/0'
    assert heise_extractor[0].get('ext') == 'mp4'

# Generated at 2022-06-12 17:45:03.545859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test __init__ of class HeiseIE
    HeiseIE()

# Generated at 2022-06-12 17:45:06.493676
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:45:07.872705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:45:09.066084
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE != None

# Generated at 2022-06-12 17:45:12.438153
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Testing HeiseIE")
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    print("Passed")


# Generated at 2022-06-12 17:45:16.012855
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.valid_url("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True
    assert h.valid_url("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html") == False

# Generated at 2022-06-12 17:45:20.290670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    infoExtractor = HeiseIE()
    infoExtractor._download_webpage = lambda url, video_id: ""
    infoExtractor._search_regex = lambda regex, page, name, default=None, group=None: ""
    infoExtractor._sort_formats = lambda formats: ""
    infoExtractor.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")