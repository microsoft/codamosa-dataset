

# Generated at 2022-06-12 17:35:29.817405
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:31.413095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_raises(NotImplementedError, HeiseIE, object())

# Generated at 2022-06-12 17:35:33.501460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(HeiseIE._VALID_URL) == True
    return # TODO: implement test_HeiseIE

# Generated at 2022-06-12 17:35:43.146166
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

	# Test 1:
	url = "https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
	test_IE = HeiseIE()
	test_IE.initialize()
	test_IE.extract(url)
	test_IE.destruct()

	# Test 2:
	url = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
	test_IE = HeiseIE()
	test_IE.initialize()
	test_IE.extract(url)
	test_IE.destruct()

	# Test 3

# Generated at 2022-06-12 17:35:43.831050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-12 17:35:44.697805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()

# Generated at 2022-06-12 17:35:46.486585
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

test_HeiseIE.unit_test = True
test_HeiseIE.test = ['test_class_HeiseIE']

# Generated at 2022-06-12 17:35:57.033929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert obj._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:59.702506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, "ie_key")
    assert hasattr(ie, "ie_key")
    assert hasattr(ie, "_VALID_URL")
    assert hasattr(ie, "extract")

# Generated at 2022-06-12 17:36:03.140428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    test_string = "simple test string"
    result = heise._search_regex(r'^\w+\s\w+$', test_string, 'regex_match_string')
    assert result == test_string



# Generated at 2022-06-12 17:36:23.821426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert len(ie._WORKING) > 0

# Generated at 2022-06-12 17:36:34.483968
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._download_webpage('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', '1_kkrq94sm')
    HeiseIE()._download_webpage('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html', '6kmWbXleKW4')

# Generated at 2022-06-12 17:36:41.855071
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from cStringIO import StringIO
    from lxml import etree
    from lxml.etree import XMLParser

# Generated at 2022-06-12 17:36:43.432442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check if the class can be initialized
    HeiseIE()

# Generated at 2022-06-12 17:36:51.429303
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert heise.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:36:56.324469
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _HeiseIE = HeiseIE()
    assert _HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-12 17:36:56.908003
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None


# Generated at 2022-06-12 17:37:06.236529
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    h = HeiseIE(u)
    assert h.url == u
    assert h.ie_key == 'heise'
    assert h.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert h.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert h.timestamp == '20171208'
    assert h.timestamp == 1512734959
    assert h.upload_date == '20171208'

# Generated at 2022-06-12 17:37:10.191591
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    match = KalturaIE.ie_key().match('kaltura:2238431:1_kkrq94sm')
    assert match is not None
    assert HeiseIE.suitable(match) is True
    match = YoutubeIE.ie_key().match('http://www.youtube.com/watch?v=6kmWbXleKW4')
    assert match is not None
    assert HeiseIE.suitable(match) is True

# Generated at 2022-06-12 17:37:11.014787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL

# Generated at 2022-06-12 17:37:30.356667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    create_instance(HeiseIE)



# Generated at 2022-06-12 17:37:37.598743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    assert(ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'))
    assert(ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'))

# Generated at 2022-06-12 17:37:38.106996
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:37:48.844968
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie


# Generated at 2022-06-12 17:37:50.289743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests whether the constructor can be called
    HeiseIE()

# Generated at 2022-06-12 17:38:01.157934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    eg_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:38:09.788657
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    url_parsed_dict = heiseie._real_extract(url)
    actual_video_id = url_parsed_dict['id']
    expected_video_id = '1_kkrq94sm'
    assert expected_video_id == actual_video_id

# Generated at 2022-06-12 17:38:14.481441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:38:23.722988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"
    heise_IE = HeiseIE()
    assert heise_IE._VALID_URL == HeiseIE._VALID_URL
    assert heise_IE._TESTS == HeiseIE._TESTS
    assert heise_IE.IE_NAME == 'heise'
    assert heise_IE.IE_DESC == 'heise video'
    assert heise_IE._WORKING == True
    assert heise_IE.extract_id == HeiseIE.extract_id
    assert heise_IE.extract_info == HeiseIE

# Generated at 2022-06-12 17:38:25.494104
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:39:08.733411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:39:18.874027
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    from ..utils import TestCase

    class MockHeiseIE(HeiseIE):
        """Mocked HeiseIE"""
        def __init__(self, url):
            MockHeiseIE.url = url

        def _real_extract(self, url):
            """Test method _real_extract"""
            # pylint: disable=no-self-use
            return {'url': self.url}

    # Test all types of urls accepted by HeiseIE
    url = 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    test = TestCase([('url', url, {'url': url})])
    # Test constructor
    assert MockHeiseIE(url)._type == 'url'

# Generated at 2022-06-12 17:39:19.393228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:25.204249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert HeiseIE.suitable(ie.suitable('https://www.heise.de/video/artikel/Der-Algorithmus-als-Gesellschaftsmodell-3955963.html'))

# Generated at 2022-06-12 17:39:32.976372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case_1 = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    test_case_2 = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:39:33.439631
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:41.150821
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:47.081058
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    heiseIE.extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:39:48.071621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE.ie._VALID_URL

# Generated at 2022-06-12 17:39:53.439331
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    info = ie.extract()
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:41:50.368072
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:41:53.303546
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        info_extractor = HeiseIE()
    except NameError:
        print("Unit test for constructor of class HeiseIE failed.")
        return -1

    return 0


# Generated at 2022-06-12 17:41:54.581496
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test constructor of class HeiseIE
    """
    ie = HeiseIE(None)


# Generated at 2022-06-12 17:41:55.484588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst.ie_key() == "Heise"

# Generated at 2022-06-12 17:41:57.822963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();
    assert ie.host == 'www.heise.de';
    assert ie.ie_key() == 'heise';


# Generated at 2022-06-12 17:42:00.420680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')
    assert ie.ie_key() == 'heise'
    assert ie.host() == 'http://www.heise.de/'

# Generated at 2022-06-12 17:42:06.694706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-12 17:42:08.675011
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor HeiseIE
    # Test that class HeiseIE can be initialized
    hie = HeiseIE()



# Generated at 2022-06-12 17:42:10.329431
# Unit test for constructor of class HeiseIE
def test_HeiseIE(): assert HeiseIE()

# Generated at 2022-06-12 17:42:10.821724
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()