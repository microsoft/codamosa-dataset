

# Generated at 2022-06-12 17:35:32.444410
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE([])
    assert obj.SUBS == []
    assert obj.params['extract_flat'] == 'in_playlist'

# Generated at 2022-06-12 17:35:34.384776
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        assert False, 'Failed to initialize HeiseIE'


# Generated at 2022-06-12 17:35:36.036426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test the constructor of HeiseIE"""
    


# Unit tests for methods of class HeiseIE

# Generated at 2022-06-12 17:35:37.847963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUFFIX == 'heise.de'

# Generated at 2022-06-12 17:35:41.653779
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE(None)
    # see https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py
    # the constructor calls back to YoutubeIE.__init__
    assert x.ie_key() == 'youtube'



# Generated at 2022-06-12 17:35:44.013177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    new_object = HeiseIE()
    assert isinstance(new_object, HeiseIE)
    assert isinstance(new_object, InfoExtractor)


# Generated at 2022-06-12 17:35:47.608338
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-12 17:35:49.464384
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE({"_downloader": {}})
    assert (isinstance(heise_ie, InfoExtractor))


# Generated at 2022-06-12 17:35:50.091248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:35:53.740085
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')


# Generated at 2022-06-12 17:36:12.291292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise online Video'

# Generated at 2022-06-12 17:36:14.727450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie == HeiseIE(None) == HeiseIE(None)

# Generated at 2022-06-12 17:36:25.560446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    result = ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert result != None
    assert result['id'] == '1_kkrq94sm'
    assert result['ext'] == 'mp4'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert result['timestamp'] == 1512734959
    assert result['upload_date'] == '20171208'
    assert result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-12 17:36:31.520259
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:36:32.068600
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-12 17:36:35.785751
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie is not None


# Generated at 2022-06-12 17:36:41.877176
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.info_dict['id'] == '1_kkrq94sm'

# Generated at 2022-06-12 17:36:45.103543
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Instantiate the class
    HeiseIE()
    # Verify that it is an instance of InfoExtractor
    from .common import InfoExtractor
    assert isinstance(HeiseIE(), InfoExtractor)
# end test_HeiseIE


# Generated at 2022-06-12 17:36:46.980896
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise_ie = HeiseIE(downloader=None)
    assert heise_ie is not None

# Generated at 2022-06-12 17:36:49.240685
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert HeiseIE._VALID_URL == i._VALID_URL

# Generated at 2022-06-12 17:37:31.478323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    expect_id = '1_kkrq94sm'
    assert ie._match_id(url) == expect_id
    assert ie.ie_key() == 'heise'
    assert ie.SUITABLE_GENERAL == 'heise'
    assert ie.SUITABLE_BROWSER == True

# Generated at 2022-06-12 17:37:34.128012
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KalturaIE)
    assert isinstance(ie, YoutubeIE)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:37:41.989087
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    page = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    obj = HeiseIE(page)
    assert obj != None
    assert obj.url != None
    assert obj.id != None
    assert obj.name != None
    assert obj.title != None
    assert obj.description != None
    assert obj.timestamp != None
    assert obj.ext != None
    assert obj.duration != None
    assert obj.formats != None
    assert obj.thumbnail != None
    assert obj.age_limit != None
    assert obj.view_count != None

# Generated at 2022-06-12 17:37:47.866886
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	class Test_HeiseIE(HeiseIE):
		def __init__(self):
			super(Test_HeiseIE, self).__init__()
			return ""

	test_heise_IE = Test_HeiseIE()
	assert isinstance(test_heise_IE, object)

# Generated at 2022-06-12 17:37:57.488509
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = '1_kkrq94sm'
    title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    expected_results = {
        'id': video_id,
        'url': video_url,
        'title': title,
        'description': description,
    }
    assert HeiseIE().result_for_url(video_url) == expected_results

# Generated at 2022-06-12 17:37:59.100426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    heise = HeiseIE()

# Generated at 2022-06-12 17:38:10.949614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Setup and test initialization
    hie = HeiseIE()
    assert hie is not None

    # Test title extraction
    assert hie.extract_title(
        'http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == \
        "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert hie.extract_title(
        'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == \
        'NEU IM SEPTEMBER | Netflix'


# Generated at 2022-06-12 17:38:13.086277
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-12 17:38:14.327290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj.name == 'heise'

# Generated at 2022-06-12 17:38:23.550743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.url == ie._VALID_URL
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.url == ie._VALID_URL

# Generated at 2022-06-12 17:39:42.814508
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisei = HeiseIE()

# Generated at 2022-06-12 17:39:46.342050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:48.073554
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test that HeiseIE has been instantiated
    ie = HeiseIE(None)
    # Test that the HeiseIE name attribute has been set
    assert ie.name == 'heise'

# Generated at 2022-06-12 17:39:48.839593
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    test.suite()

# Generated at 2022-06-12 17:39:52.766096
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()

# Generated at 2022-06-12 17:39:55.124618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test constructor does not raise any exception
    HeiseIE('http://heise.de')
    HeiseIE('http://heise.de/')

# Generated at 2022-06-12 17:39:59.791511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test HeiseIE constructor and possible attributes
    """
    heise_ie = HeiseIE('foo')
    assert heise_ie.info_extractor_key == 'Heise'
    assert heise_ie.info_extractor_type == 'generic'
    assert heise_ie.landing_page_regex == 'http://www\.heise\.de/video'
    assert heise_ie.video_id_regex == 'http://www\.heise\.de/video/artikel/'

# Generated at 2022-06-12 17:40:02.821608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:40:08.846711
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:40:13.598692
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_download import _TEST_CASES
    ie = HeiseIE()
    for (url_base, manifest, result) in _TEST_CASES:
        assert ie._match_id(url_base) == result[0]
        assert ie._match_id(manifest) == result[0]

# Generated at 2022-06-12 17:43:42.437190
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:43:43.273861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()


# Generated at 2022-06-12 17:43:44.484634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-12 17:43:45.495665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj

# Generated at 2022-06-12 17:43:46.208491
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:43:51.821443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    HeiseIE("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-12 17:43:55.009973
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    except:
        assert False, "Can't create an instance of HeiseIE"

# Generated at 2022-06-12 17:44:01.083556
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check that HeiseIE.__init__() overrides its parent class
    # InfoExtractor.__init__()
    heise_ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert(heise_ie.__class__.__base__ == InfoExtractor)

# Generated at 2022-06-12 17:44:06.727833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie.video_id == "1_kkrq94sm"

# Generated at 2022-06-12 17:44:08.716142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Instantiation test"""
    ie = HeiseIE()

