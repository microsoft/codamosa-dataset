

# Generated at 2022-06-12 17:35:30.064143
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:35:38.407138
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    youtube_url = 'https://www.youtube.com/watch?v=6kmWbXleKW4'
    kaltura_url = 'kaltura:2238431:1_4wf4k0gc_1_n0t2g2t9'
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    youtube_url_transparent = 'http://example.com/foo.mp4'
    ie = HeiseIE()

# Generated at 2022-06-12 17:35:44.191307
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for title extraction 1
    input_text = """
    <html>
    <meta property="og:title" content="title1">
    </html>
    """
    ie = HeiseIE()
    actual_value = ie.extract_title(input_text);
    expected_value = "title1"
    assert (actual_value == expected_value)

    # test for title extraction 2
    input_text = """
    <html>
    <title>title2</title>
    </html>
    """
    ie = HeiseIE()
    actual_value = ie.extract_title(input_text);
    expected_value = "title2"
    assert (actual_value == expected_value)

    # test for title extraction 3

# Generated at 2022-06-12 17:35:44.983249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE.suite()

# Generated at 2022-06-12 17:35:49.531751
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:35:52.874672
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/nummer/2017-18-PS4-Pro-und-Xbox-One-X-im-Test-3610760.html')
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:35:53.833092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:35:54.828569
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("")

# Generated at 2022-06-12 17:36:01.246862
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:36:04.251108
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'Heise'
    assert heise_ie.ie_key() in HeiseIE.ie_key()

# Generated at 2022-06-12 17:36:24.691558
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE should be the constructor of class HeiseIE
    assert_equal(HeiseIE.__name__, "HeiseIE")
    # Make sure the object is instance of InfoExtractor
    assert_true(issubclass(HeiseIE, InfoExtractor))


# Generated at 2022-06-12 17:36:29.672390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unittest for constructor of HeiseIE"""
    url = ('https://www.heise.de/video/artikel/'
           'nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    instance = HeiseIE(HeiseIE._create_get_info(url))
    assert instance._VALID_URL == (
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-12 17:36:32.705870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Test for constructor of class HeiseIE.
    '''
    heise_ie = HeiseIE(None)
    assert 'HeiseIE' in repr(heise_ie)


# Generated at 2022-06-12 17:36:37.210647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(id='https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html');
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:47.465803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url = url.rstrip('/')
    heise = HeiseIE(HeiseIE.ie_key())
    Video = heise.extract(url)
    # object Video is an object of class YoutubeVideo
    assert (Video.__class__.__name__ == 'YoutubeVideo')
    # test thumbnail:
    assert (Video.thumbnail() == 'https://img.youtube.com/vi/HPsPYzSgvh4/hqdefault.jpg')
    # test video title:

# Generated at 2022-06-12 17:36:49.961248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check whether the HeiseIE class is constructable
    ie = HeiseIE()

# Generated at 2022-06-12 17:36:52.213327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    cf = HeiseIE()
    assert cf.ie_key() == "heise"

# Generated at 2022-06-12 17:36:55.112124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.name == "Heise"

# Generated at 2022-06-12 17:37:04.727962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'
    assert HeiseIE.__doc__ == 'Heise.de video extractor'
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:06.897579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-12 17:37:29.294981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.IE_NAME == 'heise'
    assert obj.IE_DESC == 'heise online video'

# Generated at 2022-06-12 17:37:30.138150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    raise Exception("Unit test not implemented")

# Generated at 2022-06-12 17:37:33.851954
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'
    assert obj.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:36.611958
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.urls == ie.URLS
    assert ie.name == 'heise'

# Generated at 2022-06-12 17:37:44.113396
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:48.895432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

    assert ie.extract() is not None

# Generated at 2022-06-12 17:37:53.503463
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    match = HeiseIE._VALID_URL.match(url)
    assert HeiseIE._real_extract(HeiseIE(), url) is not None
    assert HeiseIE._real_extract(HeiseIE(), 'Not an URL') is None
    assert HeiseIE._real_extract(HeiseIE(), url, video_id=match.group('id')) is not None
    assert HeiseIE._real_extract(HeiseIE(), url, video_id='Not an ID') is None

# Generated at 2022-06-12 17:37:54.742667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None and HeiseIE is not ""

# Generated at 2022-06-12 17:37:56.259476
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise.extractor, HeiseIE)

# Generated at 2022-06-12 17:37:57.654393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().info() == {'id': 'heise', 'title': 'heise'}

# Generated at 2022-06-12 17:38:44.740856
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-12 17:38:47.211372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:38:50.640814
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.ie_key() == 'Heise'
    assert ie.SUCCESS == True

# Generated at 2022-06-12 17:38:52.165542
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE is not None


# Generated at 2022-06-12 17:38:53.656063
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:39:03.843569
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = {'url': 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'}
    hie = HeiseIE()
    assert hie._VALID_URL == HeiseIE._VALID_URL
    assert hie._TESTS == HeiseIE._TESTS
    assert hie._download_xml == HeiseIE._download_xml
    assert hie._real_extract == HeiseIE._real_extract
    assert hie._download_webpage == InfoExtractor._download_webpage

# Generated at 2022-06-12 17:39:05.592445
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:10.354845
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert test._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert test._TESTS[0]['url'] == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    assert test._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

# Generated at 2022-06-12 17:39:16.678446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html") == True
    

# Generated at 2022-06-12 17:39:27.098491
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:41:09.404583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:41:14.825670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from unittest import mock
    from youtube_dl.downloader import HttpFD
    from youtube_dl.utils import compat_str
    from youtube_dl.YoutubeDL import YoutubeDL

    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE({})

# Generated at 2022-06-12 17:41:20.544944
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test URL 1
    podcast = HeiseIE._make_kaltura_result('kaltura:2238431:1_kkrq94sm')
    assert podcast['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert podcast['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert podcast['timestamp'] == 1512734959
    assert podcast['upload_date'] == '20171208'
    # Test URL 2
    netflix = HeiseIE._make_kaltura_result('https://www.youtube.com/watch?v=6kmWbXleKW4')
    assert netflix['title'] == 'NEU IM SEPTEMBER | Netflix'

# Generated at 2022-06-12 17:41:22.275767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:41:24.456736
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    assert HeiseIE != None

# Generated at 2022-06-12 17:41:31.049658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.IE_NAME == 'Heise.de Video'
    assert ie.ie_key() == 'Heise'
    assert ie.thumbnail == 're:^https?://.*'
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:41:32.567107
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.extractor_key == 'heise'
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-12 17:41:33.047583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:41:35.480534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise.de'
    assert ie.thumbnail() is None
    assert isinstance(ie.working_as_of, int)

# Generated at 2022-06-12 17:41:35.960144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:45:18.344894
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_downloads import _test_downloads
    _test_downloads(HeiseIE)

# Generated at 2022-06-12 17:45:23.743681
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of HeiseIE class"""
    def test_HeiseIE_constructor(url, expected_class, expected_result):
        """Test constructor of HeiseIE class"""
        heise_instance = HeiseIE(url)
        assert(type(heise_instance) is expected_class)
        assert(heise_instance._VALID_URL is expected_result)

    test_HeiseIE_constructor("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html", type(InfoExtractor()), "http://(?:www\.)?heise.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html")
    test_