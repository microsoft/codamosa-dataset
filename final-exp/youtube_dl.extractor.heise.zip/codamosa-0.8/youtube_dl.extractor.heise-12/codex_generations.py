

# Generated at 2022-06-12 17:35:34.256867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for constructor of HeiseIE
    """
    obj = HeiseIE(HeiseIE.ie_key())
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    yt_urls = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

# Generated at 2022-06-12 17:35:43.965280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') is True
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') is True

# Generated at 2022-06-12 17:35:45.152134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    print(heiseie)

# Generated at 2022-06-12 17:35:52.841737
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Testing for only_matching
    ie = HeiseIE()

    # testing for real URL
    url = 'https://www.heise.de/ct/video/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._match_id(url) == '2404147'

    # testing for URL with no match
    url = 'https://www.heise.de/ct/video/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html#234'
    assert ie._match_id(url) == '2404147'

    # testing for URL with no match

# Generated at 2022-06-12 17:35:54.918870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.name == "heise"
    assert ie.ie_key() == "heise"

# Generated at 2022-06-12 17:35:55.514545
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:04.323991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    input_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseie = HeiseIE(input_url)
    assert heiseie != None
    assert heiseie.url == input_url
    assert heiseie.get_url() == input_url
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie.ie_key() == 'Heise'
    assert heiseie.valid() == True
    assert heiseie.extract() != None


# Generated at 2022-06-12 17:36:15.105230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:36:25.968474
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise_ie._TESTS[0]['info_dict']['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:36:35.909791
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = ('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-'
           'Tastaturen-Peilsender-Smartphone-2404147.html')
    heise = HeiseIE()
    info = heise._real_extract(url)
    assert info['id'] == '1_kkrq94sm'
    assert info['ext'] == 'mp4'
    assert info['title'] == ("Podcast: c't uplink 3.3 – Owncloud / Tastaturen "
                             "/ Peilsender Smartphone")
    assert info['timestamp'] == 1512734959
    assert info['upload_date'] == '20171208'

# Generated at 2022-06-12 17:37:01.046050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test cases for class HeiseIE"""

    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    ie = HeiseIE()
    assert ie.match_url(url) == True
    assert isinstance(ie.match_url(url), str) #match_url returns extracted video_id


# Generated at 2022-06-12 17:37:03.612296
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL


# Test for class HeiseIE methods

# Generated at 2022-06-12 17:37:11.726999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    expected_result = {
            'id': '1_ntrmio2s',
            'ext': 'mp4',
            'title': "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?",
            'description': 'md5:47e8ffb6c46d85c92c310a512d6db271',
            'timestamp': 1512470717,
            'upload_date': '20171205',
        }

    heise_ie = HeiseIE()
    actual_result = heise_ie

# Generated at 2022-06-12 17:37:21.906056
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def test_HeiseIE_for_url(url):
        heise_ie = HeiseIE(url)
        return heise_ie

    test_url1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_HeiseIE_for_url(test_url1)
    test_url2 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    test_HeiseIE_for_url(test_url2)

# Generated at 2022-06-12 17:37:25.861043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:37:33.256701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert a._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:42.316139
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key(url="http://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == "heise"
    assert HeiseIE.ie_key(url="http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html") == "youtube"

    # test constructor of InfoExtractor
    ie = IE([])

# Generated at 2022-06-12 17:37:43.137854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:37:48.689392
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE(url)

# Generated at 2022-06-12 17:37:50.120683
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:38:36.265010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    data = HeiseIE()
    assert data.info_extractors[0].ie_key() == 'Youtube'
    assert data.info_extractors[1].ie_key() == 'Kaltura'
    assert data.info_extractors[-1].ie_key() == 'Heise'

# Generated at 2022-06-12 17:38:37.375608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    return heiseIE

# Generated at 2022-06-12 17:38:38.653597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor of HeiseIE
    instance = HeiseIE(None)
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-12 17:38:39.695597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:38:42.985334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert HeiseIE._VALID_URL == ie._VALID_URL
    assert ie.__name__ == 'heise:heise'
    assert ie.ie_key() == 'heise'
    assert ie.server_url == 'heise'
    assert ie.host == 'heise'
    assert ie.data_format == 'xml'

# Generated at 2022-06-12 17:38:52.889867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'))
    print(ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    print(ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'))

# Generated at 2022-06-12 17:38:55.174625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:38:58.828179
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Constructor of class HeiseIE is called by YoutubeIE
# when "youtube" appears in the url

# Generated at 2022-06-12 17:39:03.261993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie is not None

# Generated at 2022-06-12 17:39:15.588932
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _make_extractors

    extractors = _make_extractors()


# Generated at 2022-06-12 17:41:02.579767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("")
    assert heiseIE.ie_key() == 'heise'

# Generated at 2022-06-12 17:41:04.472603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_kaltura import HEISE_TEST_URL
    HeiseIE._build_kaltura_result(HEISE_TEST_URL)

# Generated at 2022-06-12 17:41:11.331727
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    input_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    instance = HeiseIE(input_url)
    assert instance.url == input_url
    assert instance.video_id == '1_kkrq94sm'
    assert instance.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert instance.timestamp == 1512734959
    assert instance.upload_date == '20171208'
    assert instance.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-12 17:41:17.835550
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:41:18.877467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None) is not None

# Generated at 2022-06-12 17:41:30.787707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.constructor._download_webpage('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', "1_kkrq94sm")
    assert ie.constructor._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'

# Generated at 2022-06-12 17:41:36.296131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    # test case from heise.de
    ie_test_case = 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    metadata = ie.extract(ie_test_case)
    assert metadata['id'] == '3214137'
    assert metadata['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert len(metadata['formats']) > 0
    assert metadata['thumbnail'] is not None
    assert metadata['description'] is not None
    assert metadata['timestamp'] is not None

# Generated at 2022-06-12 17:41:38.679541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'Heise Video'
    assert ie.lang == 'de'

# Generated at 2022-06-12 17:41:39.260025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()

# Generated at 2022-06-12 17:41:50.245644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert ie.suitable("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    # not c't uplink