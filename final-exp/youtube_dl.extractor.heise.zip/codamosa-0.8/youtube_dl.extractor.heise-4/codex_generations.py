

# Generated at 2022-06-12 17:35:29.547790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key('test') == HeiseIE.suitable('test')

# Generated at 2022-06-12 17:35:33.549722
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert t

# Generated at 2022-06-12 17:35:43.232772
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:35:44.230561
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:35:45.344206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie


# Generated at 2022-06-12 17:35:52.980285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_downloader = InfoExtractor('test', 'HeiseIE', 'heise.de')
    url = unit_test_downloader.url_result('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    url.download()
    url.playlist_result(['1_ntrmio2s', '1_9uztjedf'])
    url.playlist_result(['https://www.youtube.com/watch?v=AZlFZZzJuj0'])

# Generated at 2022-06-12 17:35:59.614926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("heise.de", "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    HeiseIE("heise.de", "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-12 17:36:00.746393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseEscuela=HeiseIE()
	heiseEscuela
	assert True==True

# Generated at 2022-06-12 17:36:03.586367
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:36:04.335220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test HeiseIE constructor
    assert test_HeiseIE()

# Generated at 2022-06-12 17:36:28.516705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Instantiate an instance of the HeiseIE class
    # UAT url: http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html
    heise_ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    # Verify the properties of the instance of the HeiseIE class
    assert heise_ie.ie_key() == 'Heise'
    assert heise_ie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:36:31.966237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_suite import TestCase

    class HeiseTestCase(TestCase):
        def setUp(self):
            self.ie = HeiseIE()

    test_case = HeiseTestCase()
    test_case.run()

# Generated at 2022-06-12 17:36:32.540706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:40.488319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testfile = os.path.join(os.path.dirname(__file__), "test.html")
    fh = open(testfile, "r")
    data = fh.read()
    fh.close()
    heise = HeiseIE(data)
    assert heise._make_kaltura_result("test") == {
        '_type': 'url_transparent',
        'url': 'test',
        'ie_key': 'Kaltura',
        'title': None,
        'description': None
    }
    assert heise._extract_url(heise.webpage) == 'kaltura:2238431:51128832'


# Generated at 2022-06-12 17:36:42.030504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:36:46.430404
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heise.de")
    assert isinstance(ie, HeiseIE)
    assert isinstance(ie._VALID_URL, str)
    assert len(ie._TESTS) > 500
    assert isinstance(ie._download_webpage(ie._TESTS[0], "videotest"), str)

# Generated at 2022-06-12 17:36:50.385848
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert hasattr(heise, '_VALID_URL')
    assert type(heise._VALID_URL) == type(re.compile(''))
    assert hasattr(heise, '_TESTS')
    assert type(heise._TESTS) == list
    assert hasattr(heise, '_real_extract')

# Generated at 2022-06-12 17:36:51.799122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:56.625012
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.download('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:00.600576
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    HeiseIE(url)

# Generated at 2022-06-12 17:37:40.221503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-12 17:37:43.007994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.IE_NAME == 'heise'
    assert heise_ie.IE_DESC == 'heise online'
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:52.397066
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  heiseie = HeiseIE()
  heiseie._download_webpage(
    'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html', '1_ntrmio2s')
  heiseie._real_extract(
    'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:53.647809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:37:54.525582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.initialize()

# Generated at 2022-06-12 17:37:55.081936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:37:58.118008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    instance = HeiseIE(url)
    assert instance.url == url


# Generated at 2022-06-12 17:38:03.669131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    module = HeiseIE()
    assert hasattr(module, '_VALID_URL')
    assert hasattr(module, '_TESTS')
    assert hasattr(module, '_real_extract')

# Generated at 2022-06-12 17:38:10.256731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert i._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:38:16.767462
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    obj = HeiseIE()
    result = obj._real_extract(url)   
    print(result)

# Generated at 2022-06-12 17:39:33.629116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:35.186765
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.download = lambda *args, **kwargs: b'OK'


# Generated at 2022-06-12 17:39:36.735842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        test1 = True
    except:
        test1 = False
    assert test1

# Unit Test for method _real_extract of class HeiseIE

# Generated at 2022-06-12 17:39:43.656125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE({})

    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html'
    assert hie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert hie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert hie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:39:49.189687
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test_url_bis = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    test_url_ter = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    test_url_qu

# Generated at 2022-06-12 17:39:57.787288
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Running test cases for HeiseIE")
    heise = HeiseIE()
    heise._download_webpage = lambda *args, **kwargs: ''
    heise._extract_urls = lambda *args, **kwargs: {}
    heise._html_search_regex = lambda *args, **kwargs: {}
    heise._html_search_meta = lambda *args, **kwargs: ''
    heise._og_search_description = lambda *args, **kwargs: ''
    heise._og_search_thumbnail = lambda *args, **kwargs: ''
    heise._search_regex = lambda *args, **kwargs: ''
    # test case 1: Happy case of kaltura embed
    heise._download_xml = lambda *args, **kwargs: ''
    heise._sort_

# Generated at 2022-06-12 17:39:58.802281
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-12 17:39:59.955351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:40:06.530809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert (h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert (h._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert (h._TESTS[0]['info_dict']['id'] == '1_kkrq94sm')
    assert (h._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-12 17:40:11.310021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests that HeiseIE(self, *args, **kwargs) calls super(InfoExtractor, self).__init__(*args, **kwargs)
    # and that it uses the class name as the IE_NAME attribute
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'Heise'

# Generated at 2022-06-12 17:43:46.928883
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.host == 'heise.de'
    assert ie.hostname == 'heise'
    assert ie.video_id == '1_kkrq94sm'
    assert ie.url == 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:43:52.248085
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for class HeiseIE"""
    # Creation of correct object for heise.de
    heiseIE = HeiseIE({})
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:43:52.931047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('heise')

# Generated at 2022-06-12 17:44:04.330264
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    heise_url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"

    res = ie.extract(heise_url)
    assert res["title"] == "nachgehakt: c't uplink – Owncloud, Tastaturen & Peilsender Smartphone"

    res = ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:44:04.998309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert instance

# Generated at 2022-06-12 17:44:14.930567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    obj = test_HeiseIE
    obj.heise = HeiseIE()

    obj.url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    obj.result = {
        '_type': 'url_transparent',
        'url': 'https://www.youtube.com/watch?v=6kmWbXleKW4',
        'ie_key': 'Youtube',
        'id': '6kmWbXleKW4',
        'title': 'NEU IM SEPTEMBER | Netflix'
    }

# Generated at 2022-06-12 17:44:15.902558
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  ie = HeiseIE()
  assert ie is not None



# Generated at 2022-06-12 17:44:20.946009
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(None) is False
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is True
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') is True

# Generated at 2022-06-12 17:44:21.516515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-12 17:44:26.124702
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check the constructor of class HeiseIE
    x = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert x.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert x.id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
