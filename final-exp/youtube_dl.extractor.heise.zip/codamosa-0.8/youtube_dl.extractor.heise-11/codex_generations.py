

# Generated at 2022-06-12 17:35:27.782054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert type(ie) == HeiseIE

# Generated at 2022-06-12 17:35:28.533154
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-12 17:35:36.665503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-12 17:35:37.697978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    print (heise_ie)

# Generated at 2022-06-12 17:35:46.525549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie.suitable('url', 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('url', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('url', 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:35:57.032511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id = '1_ntrmio2s'

# Generated at 2022-06-12 17:35:57.732194
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hIE = HeiseIE()
    assert hIE != None

# Generated at 2022-06-12 17:36:05.555158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:08.356316
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    

# Generated at 2022-06-12 17:36:19.560485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:33.436129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[1]['md5'] == 'e403d2b43fea8e405e88e3f8623909f1'
    assert ie._TESTS[2]['info_dict']['id'] == '1_ntrmio2s'
    assert ie._TESTS[2]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:36:34.353518
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:36:41.002906
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests for constructor of class HeiseIE
    # Test case: valid url (1st test case from _TESTS)
    instance = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(instance, HeiseIE)
    # Test case: invalid url
    instance = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-240414.html')
    assert instance is None

# Generated at 2022-06-12 17:36:47.158993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the code for the constructor of class HeiseIE
    # Arguments:
    #   None

    # Example 1


    # Test the code for the constructor of class HeiseIE
    # Arguments:
    #   None

    # Example 1
    HEISE_IE=HeiseIE()
    # Example 2
    print("\n\n")
    HEISE_IE=HeiseIE()
    # Example 3
    print("\n\n")
    HEISE_IE=HeiseIE()

# Generated at 2022-06-12 17:36:47.743105
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:51.548948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == "heise"
    assert heise.ie_key(instance=True) == "heiseie"

# Generated at 2022-06-12 17:36:53.144675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:36:55.009232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE, type)

# Generated at 2022-06-12 17:36:57.878304
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() in ie.gen_extractors()


# Generated at 2022-06-12 17:37:00.077429
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._TESTS[0]['info_dict']['id'] == KalturaIE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-12 17:37:25.564872
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True)
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie.download(url)


# Generated at 2022-06-12 17:37:28.586581
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert(type(ie) == HeiseIE)

# Generated at 2022-06-12 17:37:34.162483
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE = HeiseIE(url)
    assert heiseIE.url == url
    assert heiseIE.id == "1_kkrq94sm"
    assert heiseIE.thumbnail != None
# Unit tests for some functions of class HeiseIE.

# Generated at 2022-06-12 17:37:35.694348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._download_webpage('', '')

# Generated at 2022-06-12 17:37:36.612992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert('Heise' == HeiseIE._VALID_URL)

# Generated at 2022-06-12 17:37:37.766329
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:37:45.059625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:37:50.035173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    return HeiseIE() \
        .get_urldata(test_url, {}) \
        .get('id')

# Generated at 2022-06-12 17:37:51.027637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-12 17:37:54.023993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert isinstance(heiseIE, HeiseIE)
    assert isinstance(heiseIE, InfoExtractor)


# Generated at 2022-06-12 17:38:45.124852
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    youtube_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'

# Generated at 2022-06-12 17:38:52.986842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    id = "1_kkrq94sm"
    ie = HeiseIE(url, id, "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-12 17:38:59.262445
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-12 17:39:08.078712
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    info_dict = {
        'id': '1_kkrq94sm',
        'ext': 'mp4',
        'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        'timestamp': 1512734959,
        'upload_date': '20171208',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
    }

    # Unit test for _real_extract()
    def real_extract(self, url):
        video_id = self._match_id(url)
        webpage = self._download_webpage(url, video_id)

        def extract_title(default=NO_DEFAULT):
            title = self._

# Generated at 2022-06-12 17:39:18.390417
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

# Generated at 2022-06-12 17:39:28.211455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'

# Generated at 2022-06-12 17:39:35.177554
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[0]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[1]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[2]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[3]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[4]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[5]['url'])
    assert HeiseIE._VALID_URL.search(HeiseIE._TESTS[6]['url'])
    assert He

# Generated at 2022-06-12 17:39:35.714793
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:39:42.846271
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:48.672220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:41:38.504372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test creating a new HeiseIE object
    """
    global class_instance
    class_instance = HeiseIE('http://www.heise.de')
    assert class_instance.url == 'http://www.heise.de'

# Unit tests for methods of class HeiseIE

# Generated at 2022-06-12 17:41:38.870487
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-12 17:41:42.746566
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    # Test default initialization
    HeiseIE()

# Generated at 2022-06-12 17:41:50.989419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HEISE_URL = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    expected_info_dict = {'id': '1_kkrq94sm', 'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone", 'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'}
    heise = HeiseIE()
    info_dict = heise.extract(HEISE_URL)
    assert info_dict.get('id') == expected_info_dict.get('id')
    assert info_dict.get('title') == expected_

# Generated at 2022-06-12 17:41:54.581655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE('http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    except NotImplementedError:
        pass


# Generated at 2022-06-12 17:41:55.579918
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()


# Generated at 2022-06-12 17:41:57.255837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None, None)
    assert ie is not None


# Generated at 2022-06-12 17:42:01.411480
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_constructor(self, url):
        IE = type(self).ie()
        assert IE.suitable(url)
        assert IE.working == True
        assert IE._VALID_URL == self._VALID_URL

    for _, test in HeiseIE._TESTS:
        yield _test_constructor, test

# Generated at 2022-06-12 17:42:06.762934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() != 'heise'
    assert ie.suitable("http://heise.de/ix/artikel/5/566/1.html")
    assert ie.suitable("http://www.heise.de/ix/artikel/5/566/1.html")
    assert not ie.suitable("https://www.heise.de/ix/artikel/5/566/1.html")
    assert not ie.suitable("http://www.heise.de/ix/artikel/6/685/1.html")

# Generated at 2022-06-12 17:42:11.551629
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # first call the constructor
    info = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    # and then check if the downloader has been constructed as expected
    assert info.downloader._default_search_limit == 10000