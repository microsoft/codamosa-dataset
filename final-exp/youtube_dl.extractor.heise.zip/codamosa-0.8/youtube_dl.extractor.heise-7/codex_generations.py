

# Generated at 2022-06-12 17:35:30.709188
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:34.217310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    # regex
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:35.556507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert isinstance(obj, HeiseIE)

# Generated at 2022-06-12 17:35:38.723785
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise.ie_name() == 'Heise'
    assert heise.ie_description() == 'Heise Video'

# Generated at 2022-06-12 17:35:39.795541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception:
        pass

# Generated at 2022-06-12 17:35:48.324425
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:35:58.558017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = [{
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'video_id': '1_kkrq94sm',
        'ext': 'mp4',
        'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        'timestamp': 1512734959,
        'upload_date': '20171208',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
    }]

    for tc in test_cases:
        ie = HeiseIE()

# Generated at 2022-06-12 17:35:59.130024
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-12 17:36:00.099634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:36:11.552289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case = [('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html',
                    'heise',
                    'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html',
                    'HeiseIE')]
    for cur_case in test_case:
        assert cur_case[0] == cur_case[1]._match_url(cur_case[1]._VALID_URL, cur_case[0])
        assert cur_case[2] == cur_case[1]._

# Generated at 2022-06-12 17:36:37.141062
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:47.432403
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE test
    heise_test = HeiseIE()._make_kaltura_result('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise_test['_type'] == 'url_transparent'
    assert heise_test['ie_key'] == 'Kaltura'
    assert heise_test['url'] == 'kaltura:2238431:1_kkrq94sm'
    assert heise_test['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:36:48.608070
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    res = HeiseIE()
    assert type(res) == HeiseIE

# Generated at 2022-06-12 17:37:00.363054
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:37:01.892635
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if the class HeiseIE initializes.
    test_obj = HeiseIE()



# Generated at 2022-06-12 17:37:10.247325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Example of json data for checking extractor

# Generated at 2022-06-12 17:37:18.870895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test class inheritance
    assert issubclass(HeiseIE,InfoExtractor)

    # Test instance creation
    test_obj = HeiseIE(HeiseIE._downloader, 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

    # Check attributes
    assert test_obj.ie_key() == 'heise'
    assert test_obj.ie_desc() == 'heise online'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:22.400981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()

    if isinstance(instance, HeiseIE):
        assert isinstance(instance, InfoExtractor)
    else:
        raise Exception('Cannot create instance of HeiseIE')

# Generated at 2022-06-12 17:37:24.025902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._TESTS[0]['url'] == HeiseIE._VALID_URL


# Generated at 2022-06-12 17:37:30.493126
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert heise.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:56.536486
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(downloader=None)
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise_ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-12 17:37:57.336519
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();

# Generated at 2022-06-12 17:38:00.155686
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    http_client = md5 = None
    heise = HeiseIE(http_client, md5)
    assert heise.http_client == http_client
    assert heise.md5 == md5


# Generated at 2022-06-12 17:38:04.380845
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("test")


# Generated at 2022-06-12 17:38:05.481492
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()

# Generated at 2022-06-12 17:38:10.651888
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not inst.suitable('http://www.imdb.com/title/tt0354766/')

# Generated at 2022-06-12 17:38:20.721543
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE()
    # Check if we recognize the given URL
    assert heise_ie._match_id(url)
    info_dict = heise_ie._real_extract(url)
    assert info_dict['id'] == '1_kkrq94sm'
    assert info_dict['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info_dict['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'


# Generated at 2022-06-12 17:38:21.815287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_instance = HeiseIE()
    assert unit_test_instance

# Generated at 2022-06-12 17:38:24.991859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE().extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:38:30.973202
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url="www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie=HeiseIE()
    assert repr(ie) == repr(HeiseIE)
    assert ie.suitable(video_url)
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise online video'
    assert ie.VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:39:10.689171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    siteObject = heiseIE.constructor
    assert isinstance(siteObject, HeiseIE)


# Generated at 2022-06-12 17:39:21.223703
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.url = 'https://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'
    html = '<div class="videoplayerjw"[^>]+data-container="([0-9]+)"'
    container_id = '123'
    assert ie._search_regex(html, ie.url, 'container ID') == container_id
    xpath = './/{http://rss.jwpcdn.com/}image'

# Generated at 2022-06-12 17:39:28.744665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    assert ie.url == url
    assert ie.video_id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'
    assert ie.title is None
    assert ie.http_headers is not None
    assert ie.kaltura_id is None
    assert ie.kaltura_playlist is None

# Generated at 2022-06-12 17:39:35.566039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    args = [None, 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html']
    heiseIE = HeiseIE(*args)
    assert(heiseIE.url == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert(heiseIE.ie_key() == 'heise')
    assert(heiseIE.video_id == '1_ntrmio2s')

# Generated at 2022-06-12 17:39:36.430454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert ie

# Generated at 2022-06-12 17:39:42.614923
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test on supported video
    heise_test = HeiseIE(HeiseIE._VALID_URL)
    assert heise_test._VALID_URL == HeiseIE._VALID_URL
    assert heise_test.IE_NAME == 'heise'
    TestInfoExtractor(HeiseIE(HeiseIE._VALID_URL)).test()

    # Test on non-supported video
    heise_test = HeiseIE('http://www.heise.de/newsticker/meldung/')
    with pytest.raises(ExtractorError) as excinfo:
        heise_test.extract()
    assert excinfo.value.args[0] == 'Invalid URL'

# Generated at 2022-06-12 17:39:45.278649
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # print(HeiseIE._TESTS)
    # print(HeiseIE._VALID_URL)
    # print(Heise.ie_key())
    # print(HeiseIE._download_webpage)

    HeiseIE()


# Generated at 2022-06-12 17:39:45.908407
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    o = HeiseIE()

# Generated at 2022-06-12 17:39:47.222508
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import gen_extractors_test
    gen_extractors_test(HeiseIE)

# Generated at 2022-06-12 17:39:47.911843
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:41:32.154458
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert t._id == '2404147'


# Generated at 2022-06-12 17:41:35.853577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_video = HeiseIE('heise', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    print(heise_video)
    assert heise_video.ie_key() == 'Heise'
    assert heise_video.ie_key() in globals()

# Generated at 2022-06-12 17:41:37.586873
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE('www.heise.de', {})
    print(h)
    return h

# Generated at 2022-06-12 17:41:43.611778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:41:44.992906
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()

# Generated at 2022-06-12 17:41:53.638334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("")
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:41:58.902216
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == \
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:42:03.524838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    ie = HeiseIE()
    ie.extract(url)

    assert ie.url_result is not None
    assert ie.url_result.url == '1_ntrmio2s'

# Generated at 2022-06-12 17:42:09.414320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:42:18.731528
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Altes-iPhone-gefunden-Auf-diese-Daten-sollten-Sie-vorher-nicht-vergessen-zuzugreifen-3876296.html') is False