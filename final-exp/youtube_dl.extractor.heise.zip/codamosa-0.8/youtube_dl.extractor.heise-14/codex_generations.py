

# Generated at 2022-06-12 17:35:38.136758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:35:39.346507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_obj = HeiseIE(HeiseIE.ie_key())

# Generated at 2022-06-12 17:35:41.013780
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'



# Generated at 2022-06-12 17:35:46.977622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(dummy_args)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, HeiseIE)
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert len(ie._TESTS)


# Generated at 2022-06-12 17:35:48.407278
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test for constructor of class HeiseIE
    assert HeiseIE

# Generated at 2022-06-12 17:35:49.845183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL()

# Generated at 2022-06-12 17:35:59.877087
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #valid Kaltura url
    webpage = r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE().suitable(webpage) is True

    #valid YouTube url
    webpage = r'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert HeiseIE().suitable(webpage) is True

    #invalid url
    webpage = r'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 17:36:01.159996
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    object_instance = HeiseIE()
    assert isinstance(object_instance, HeiseIE)


# Generated at 2022-06-12 17:36:01.658142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()
    assert video is not None

# Generated at 2022-06-12 17:36:03.760310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.ie_name == 'heise'
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:36:22.928939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'heise'
    assert ie.host() == 'heise.de'
    assert ie.description() is not None
    assert ie.description().startswith('Heise')
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is not None
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') is not None


# Generated at 2022-06-12 17:36:34.397387
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:36:37.416202
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise.ie_name() == 'Heise'
    assert heise.suitable(None)
    assert not heise.suitable('')

# Generated at 2022-06-12 17:36:47.941342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.check_urls(['http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'])
    assert not ie.check_urls(['https://www.heise.de/'])
    assert ie.check_urls(['http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'])

# Generated at 2022-06-12 17:36:54.284058
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Case 1
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise = HeiseIE(url)


# Generated at 2022-06-12 17:36:55.882047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise


# Generated at 2022-06-12 17:36:56.659826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._get_video_id() == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:36:57.930388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-12 17:36:58.710160
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()


# Generated at 2022-06-12 17:37:07.755213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = HeiseIE._VALID_URL
    exp_id = '3700244'
    exp_title = "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    exp_description = "md5:47e8ffb6c46d85c92c310a512d6db271"
    exp_timestamp = 1512470717
    exp_thumbnail = None
    exp_formats = None
    exp_upload_date = None
    exp_uploader = None
    exp_uploader_id = None
    exp_tags = None
    exp_duration = None
    exp_like_count = None
    exp_average_rating = None
    exp_dislike_count = None
    exp_comment_count = None

# Generated at 2022-06-12 17:37:27.094524
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')

# Generated at 2022-06-12 17:37:29.933770
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-12 17:37:31.525106
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of HeiseIE"""
    heise_ie = HeiseIE(InfoExtractor())

# Generated at 2022-06-12 17:37:37.307511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'heise')
    assert(ie.SUCCESS_TEST_URL == 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-12 17:37:38.095700
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-12 17:37:39.949147
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-12 17:37:43.627390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html','heise.de/video/')
    assert x.video_id == '6kmWbXleKW4'


# Generated at 2022-06-12 17:37:48.419332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    print(ie)

# Generated at 2022-06-12 17:37:51.370835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This test verifies that the HeiseIE() class can be constructed,
    # which causes it's _download_webpage() method to be automatically
    # registered with the downloader handler.
    HeiseIE()

# Generated at 2022-06-12 17:37:51.981092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:38:35.905886
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    # Check if working
    testVideo = ie.extract(_make_url('1_kkrq94sm'))
    assert testVideo['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-12 17:38:42.864265
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Unit test for constructor of class HeiseIE
    '''

    # Arrange
    URL = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    VIDEO_ID = '1_kkrq94sm'
    title = 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    timestamp = 1512734959
    upload_date = '20171208'

    # Act
    heise_ie = HeiseIE()
    heise_ie_result = heise

# Generated at 2022-06-12 17:38:44.630837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import YoutubeTestCase
    youtube_test_case = YoutubeTestCase()
    youtube_test_case.run(HeiseIE)

# Generated at 2022-06-12 17:38:45.091917
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-12 17:38:52.952367
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:38:58.674343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    heise = HeiseIE(url)
    assert heise.url == url

# Generated at 2022-06-12 17:38:59.853457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-12 17:39:03.349123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE(InfoExtractor())
    assert heiseIE.ie_key() == 'Heise'
    assert heiseIE.ie_key() in InfoExtractor.get_ie_keywords()

# Generated at 2022-06-12 17:39:15.667827
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    #testing HeiseIE constructor
    heiseIE = HeiseIE()

    #testing initial values of class variables
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:18.156406
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = InfoExtractor(HeiseIE.ie_key())
    assert isinstance(info_extractor, HeiseIE)

# Generated at 2022-06-12 17:41:03.758126
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-12 17:41:05.251054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, InfoExtractor)

# Generated at 2022-06-12 17:41:06.780358
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    ie = HeiseIE();

    # test if the constructor has created a valid object
    assert(ie is not None);

# Generated at 2022-06-12 17:41:09.854990
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract_info()
    assert ie.video_id == '1_kkrq94sm'

# Generated at 2022-06-12 17:41:11.973823
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:41:15.576066
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE()
    heiseIE._download_webpage = lambda url: "some html"
    assert heiseIE._real_extract(url)

# Generated at 2022-06-12 17:41:18.715118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('url_1')
    HeiseIE('url_2')

# Generated at 2022-06-12 17:41:19.108063
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:41:19.769747
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-12 17:41:21.406376
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-12 17:45:01.352428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:45:08.126885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert issubclass(HeiseIE, InfoExtractor)
    ie = HeiseIE("YouTube", "http://www.heise.de", [])
    assert ie.suitable("http://www.heise.de")
    assert ie.suitable("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")


# Generated at 2022-06-12 17:45:08.770179
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:45:10.678930
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE()._call_api(api_url='http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert result is not None

# Generated at 2022-06-12 17:45:12.459224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test a HeiseIE object
    test_obj = HeiseIE(None)
    assert isinstance(test_obj, HeiseIE)



# Generated at 2022-06-12 17:45:18.226350
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    result = ie.result
    assert(result['id'] == "1_kkrq94sm")
    assert(result['ext'] == 'mp4')
    assert(result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    assert(result['timestamp'] == 1512734959)
    assert(result['upload_date'] == '20171208')
    assert(result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20')