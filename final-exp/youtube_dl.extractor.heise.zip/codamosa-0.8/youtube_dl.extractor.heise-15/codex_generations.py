

# Generated at 2022-06-12 17:35:27.651348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:35:28.695782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE, type)



# Generated at 2022-06-12 17:35:32.445250
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_exporter import test_exporter
    test_exporter(HeiseIE, 'ct.de', '1_rd4c4o4x')

# Generated at 2022-06-12 17:35:34.379401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    heise_ie.extract(url=heise_ie._VALID_URL)

# Generated at 2022-06-12 17:35:35.327522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-12 17:35:35.928416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:35:44.455137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE(InfoExtractor)

# Generated at 2022-06-12 17:35:52.345671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.url == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    assert ie.video_id == 'nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244'

    # Unit test for function _real_extract

# Generated at 2022-06-12 17:36:00.045705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of class HeiseIE"""

    heise_ie_instance = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert isinstance(heise_ie_instance, HeiseIE)

    heise_ie_instance = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert isinstance(heise_ie_instance, HeiseIE)

# Generated at 2022-06-12 17:36:01.206083
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:36:11.020288
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert(instance._VALID_URL == HeiseIE._VALID_URL)

# Generated at 2022-06-12 17:36:21.440041
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert obj._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert obj._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert obj._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:36:23.033013
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(None)


# Generated at 2022-06-12 17:36:27.158745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise.de/video'
    assert ie.ie.__name__ == 'HeiseIE'

# Generated at 2022-06-12 17:36:33.920976
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.video_id_re() == _VALID_URL
    assert ie.video_id_re() == _VALID_URL
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:36:35.828123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, HeiseIE)
    assert isinstance(heise, InfoExtractor)

# Generated at 2022-06-12 17:36:47.057433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"
    ht = HeiseIE(url)
    assert ht is not None
    assert ht.ie is not None
    assert ht.ie.name == "Heise"
    assert ht.ie.ie_key() == "Heise"


if __name__ == '__main__':
    test_class = HeiseIE()

# Generated at 2022-06-12 17:36:48.265653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE.suite()

# Generated at 2022-06-12 17:36:50.486999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-12 17:37:01.609553
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .util import compat_urllib_parse_urlparse
    url = HeiseIE._VALID_URL
    url_data = compat_urllib_parse_urlparse(url)
    # Check if the id regex matches
    if bool(url_data.path.split('/')[-1].split('.')[0].split('-')[-1].isdigit()) is True:
        if bool(HeiseIE._VALID_URL == url) is True:
            print('_VALID_URL is the same as the url')
            print(url)
            print(HeiseIE._VALID_URL)
        else:
            print('_VALID_URL is not the same as the url')
            print(url)
            print(HeiseIE._VALID_URL)

# Generated at 2022-06-12 17:37:20.403029
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass # test passed

# Generated at 2022-06-12 17:37:28.622237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert "https://www.heise.de/ct/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html" in HeiseIE._build_url("nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-12 17:37:37.345741
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    video_id = '1_kkrq94sm'
    title = 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    timestamp = 1512734959
    upload_date = '20171208'

    class DummyHeiseIE(HeiseIE):
        """Dummy class for testing class HeiseIE without real (network) access."""

# Generated at 2022-06-12 17:37:38.484830
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # dict with instance members
    HeiseIE(InfoExtractor())._real_extract

# Generated at 2022-06-12 17:37:39.276122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance

# Generated at 2022-06-12 17:37:47.522567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    # helper function
    def gettitle():
        return ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')['title']

    # Test that the title is not None
    assert gettitle() is not None
    # Test that the fetched title is the same as the one in the webpage
    assert gettitle() == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-12 17:37:57.319498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    info_dict = {
        'id': '1_59mk80sf',
        'ext': 'mp4',
        'title': "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten",
        'description': 'md5:f50fe044d3371ec73a8f79fcebd74afc',
        'timestamp': 1517567237,
        'upload_date': '20180202',
    }

# Generated at 2022-06-12 17:38:00.121286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert KalturaIE.ie_key() == 'kaltura'
    assert YoutubeIE.ie_key() == 'Youtube'
    assert HeiseIE.ie_key() == 'Heise'

# Generated at 2022-06-12 17:38:01.510826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    tester = HeiseIE()

# Generated at 2022-06-12 17:38:07.220291
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie.IE_NAME == 'heise'
    assert heise_ie.IE_DESC == 'heise online'

# Generated at 2022-06-12 17:38:42.829972
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:38:52.743853
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')


# Generated at 2022-06-12 17:38:54.055704
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except: 
        assert False
    else: 
        assert True

# Generated at 2022-06-12 17:38:55.730669
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:39:06.586309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    search_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # search_url =
    # 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    # search_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    # search_url

# Generated at 2022-06-12 17:39:17.135921
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from io import StringIO
    from json import loads
    from docopt import docopt
    from utils import urljoin

    class FakeYDL():
        def __init__(self):
            self.params = dict()
            self.result = dict()

    class Options():
        def __init__(self):
            self.noplaylist = False


# Generated at 2022-06-12 17:39:18.835599
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_heise import test_HeiseIE
    test_HeiseIE()

# Generated at 2022-06-12 17:39:22.078701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heise", [])
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-12 17:39:23.543943
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that HeiseIE is instantiated correctly
    HeiseIE()

# Generated at 2022-06-12 17:39:27.447393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert ie.name == 'heise.de'

# Generated at 2022-06-12 17:40:27.680908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # input:
    #   instance of HeiseIE
    #   url to video
    heise_ie = HeiseIE('heise', {}, {}, {})
    heise_ie._entries = []
    # expected result:
    #   list of two instances of HeiseIE
    heise_ie._real_extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert len(heise_ie._entries) == 2

# test for KalturaIE._extract_url

# Generated at 2022-06-12 17:40:28.863952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_video = HeiseIE()

# Generated at 2022-06-12 17:40:34.085942
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .kaltura import KalturaIE, KalturaPlainIE
    from .youtube import YoutubeIE, YoutubePlaylistIE

    ie = HeiseIE(dummy_args())

    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() in IE_DESC

    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, YoutubeIE)
    assert isinstance(ie, YoutubePlaylistIE)
    assert isinstance(ie, KalturaIE)
    assert isinstance(ie, KalturaPlainIE)

# Generated at 2022-06-12 17:40:34.557447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-12 17:40:39.989334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test HeiseIE
    url_test_HeiseIE = 'https://www.heise.de/video/artikel/nachgehakt-' + \
            'Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    e_test_HeiseIE = HeiseIE()
    (result_test_HeiseIE,) = e_test_HeiseIE.extract(url_test_HeiseIE)
    assert result_test_HeiseIE['id'] == '1_ntrmio2s'
    assert result_test_HeiseIE['title'] == \
            "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"

# Generated at 2022-06-12 17:40:41.149502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    # For simplicity, just a few basic tests.
    HeiseIE()

# Generated at 2022-06-12 17:40:51.755684
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:40:54.820948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-12 17:40:59.574382
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    url = 'https://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    info_extractor._real_extract(url)
    assert info_extractor._match_id(url)
    assert info_extractor._VALID_URL

# Generated at 2022-06-12 17:41:01.298488
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:42:41.267906
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test requires an internet connection
    # Instantiating an HeiseIE object.
    heise_ie = HeiseIE()

    # Testing the constructor using an url.
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise_ie.suitable(test_url) == True
    assert heise_ie.IE_NAME == 'heise'

    # Testing the constructor using an invalid url.
    invalid_test_url = 'https://www.spiegel.de/video/'
    assert heise_ie.suitable(invalid_test_url) == False

# Generated at 2022-06-12 17:42:43.592584
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # simply check if HeiseIE can be instantiated by its construtor
    # ie = HeiseIE()
    ie = HeiseIE()
    ie = HeiseIE(HeiseIE.ie_key())

# Generated at 2022-06-12 17:42:44.421118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:42:47.666876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Test if constructor of HeiseIE class raises TypeError exception
    '''
    # Test for passing a wrong parameter to constructor
    with pytest.raises(TypeError):
        ie = HeiseIE('http://www.heise.de')

    # Test for passing valid data to constructor
    ie = HeiseIE({})
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-12 17:42:48.130342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:42:51.073519
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    videoUrl = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    m = heise_ie._match_id(videoUrl)
    assert m == '2404147'

# Generated at 2022-06-12 17:42:58.738475
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Creates object `ie` of class HeiseIE
    ie = HeiseIE()
    # Asserts if name of class HeiseIE is equal to `heise`
    assert ie.IE_NAME == 'heise'
    # Asserts if URL of site `heise` is equal to `http://www.heise.de`
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Asserts if first item of TESTS is equal to `kaltura embed`

# Generated at 2022-06-12 17:43:01.280877
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:43:03.947430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:43:05.894420
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    # check for the constructor of the class HeiseIE
    assert heise_ie != None