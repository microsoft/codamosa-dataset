

# Generated at 2022-06-12 17:35:29.279458
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=W0212
    # Invoking protected members of classes is OK in unit tests
    # I do it to test private members
    assert HeiseIE._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-12 17:35:38.136171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:39.764173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._download_webpage('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html', '')

# Generated at 2022-06-12 17:35:48.290417
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.host() == 'heise.de'
    assert ie.url_re == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.params == {'skip_download': True}
    assert ie.VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.RETURN_TYPES is None
    assert ie.BR_IE is None

# Generated at 2022-06-12 17:35:58.518677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_ie = HeiseIE()
    assert heise_ie.suitable(url)
    info_regex = lambda t: heise_ie._info_regex(t)
    assert info_regex('Dies ist ein Heise-Test') == ['Dies', 'ist', 'ein', 'Heise', 'Test']
    assert info_regex('Dies ist ein Heise-Test-123') == ['Dies', 'ist', 'ein', 'Heise', 'Test']

# Generated at 2022-06-12 17:36:08.357317
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'
    assert HeiseIE._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert HeiseIE._TESTS[1]['md5'] == 'e403d2b43fea8e405e88e3f8623909f1'
    assert HeiseIE._TESTS[1]['info_dict']['id'] == '6kmWbXleKW4'
    assert He

# Generated at 2022-06-12 17:36:10.750049
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import _TEST_OTHER_CASES
    assert isinstance(_TEST_OTHER_CASES[0], HeiseIE)

# Generated at 2022-06-12 17:36:14.128542
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(None)
    assert heise_ie
    # TODO: Add tests checking if this IExtractor class is working

# Generated at 2022-06-12 17:36:16.716917
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance.name == "heise"

    assert(instance.IE_NAME == instance.name)


# Generated at 2022-06-12 17:36:21.502789
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")


# Generated at 2022-06-12 17:36:32.141178
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Use this to have an easy way to test the class
    test_obj = HeiseIE()
    assert(test_obj is not None)

# Generated at 2022-06-12 17:36:34.522787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(object, HeiseIE.ie_key())
    assert heise is not None
test_HeiseIE.test = 'test_HeiseIE'

# Generated at 2022-06-12 17:36:41.630202
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def helper(url, expected_id, expected_title):
        ie = HeiseIE(Outlet('HeiseIE', 'heise', url))
        assert ie.video_id == expected_id
        assert ie.video_title == expected_title
    helper('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
           'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147',
           'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone')

# Generated at 2022-06-12 17:36:52.708651
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .. import YoutubeIE
    from .. import KalturaIE

# Generated at 2022-06-12 17:36:55.061499
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-12 17:36:55.632169
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:56.288057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:36:58.652577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test without content of webpage, because it's possible to do all the extractions without it
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:36:59.964650
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-12 17:37:08.824247
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    url = "https://www.heise.de/newsticker/meldung/Feuerwehr-Sprechfunk-wird-fuer-die-Daten-von-Morgen-abgeschaltet-3857698.html"
    webpage = ie._download_webpage(url)
    title = ie._html_search_meta(
        'title', webpage, default=None)
    description = ie._html_search_meta(
        'description', webpage, default=None)
    
    assert title == "Feuerwehr: Sprechfunk wird für die Daten von morgen abgeschaltet"

# Generated at 2022-06-12 17:37:28.428826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise Video'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-12 17:37:33.028633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()["HeiseIE"]
    instance = class_()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == "heise"
    assert(instance.IE_DESC == "heise online Video/Mediathek")
    assert(instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-12 17:37:34.443739
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-12 17:37:42.802883
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the constructor of class HeiseIE
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.heise import HeiseIE
    from youtube_dl.YoutubeDL import YoutubeDL

    # Test for any extractor (kaltura)
    heise_dl = YoutubeDL(YoutubeDL({'extractors': HeiseIE.ie_key()}))
    h1 = heise_dl.extract_info(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        download=False)
    assert h1
    assert h1['id'] == '1_kkrq94sm'

    # Test for any extract

# Generated at 2022-06-12 17:37:46.189466
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # tests the constructor of HeiseIE
    # currently it is not possible to test the HeiseIE class because of the missing webpage
    pass

# Generated at 2022-06-12 17:37:56.498455
# Unit test for constructor of class HeiseIE
def test_HeiseIE(): # pylint: disable=missing-docstring
    """Unit test for constructor of class HeiseIE

    Raising SystemExit on AssertionError as it is recommended in
    https://docs.python.org/2/library/unittest.html#unittest.TestCase.debug
    """

# Generated at 2022-06-12 17:38:00.777767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert obj.IE_NAME == 'heise'
    # assert obj.IE_DESC == 'Heise Video'

# Generated at 2022-06-12 17:38:01.897030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(HeiseIE._VALID_URL)


# Generated at 2022-06-12 17:38:02.647833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-12 17:38:05.020202
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Unit tests for class HeiseIE

# Generated at 2022-06-12 17:38:48.501165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    _ = HeiseIE()._real_extract(url)

# Generated at 2022-06-12 17:38:50.401542
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Test HeiseIE constructor.
    '''
    checker = [HeiseIE]
    assert checker != []
    checker[0]()

# Generated at 2022-06-12 17:38:55.042129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = ('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen'
           '-Peilsender-Smartphone-2404147.html')
    webpage = ie._download_webpage(url, '1_kkrq94sm')
    ie._real_extract(url)

# Generated at 2022-06-12 17:39:01.706706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Construct the class
    heise_ie = HeiseIE()
    # Check that the class isn't null
    assert heise_ie is not None
    # Check type
    assert isinstance(heise_ie, InfoExtractor)
    # Check name of InfoExtractor
    assert heise_ie.IE_NAME == 'heise'


# Generated at 2022-06-12 17:39:04.887594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'



# Generated at 2022-06-12 17:39:11.344775
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test = HeiseIE()
    test._download_webpage(test_url, 'test_id')

# Generated at 2022-06-12 17:39:15.427180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # Raise an exception if the constructor fails.
        # This exception will be caught in the utils unit test code
        HeiseIE()
        # If the above did not raise an exception,
        # it means that the constructor did not fail
        assert 1 == 2
    except:
        assert 1 == 1

# Generated at 2022-06-12 17:39:21.867485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Generate a HeiseIE object and ensure it calculates the correct video ID"""
    heise = HeiseIE()
    video_id = heise._match_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert video_id == '2404147'

# Generated at 2022-06-12 17:39:22.787471
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:39:24.172279
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:41:08.722472
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-12 17:41:11.484701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert  HeiseIE.ie_key() == 'heise'
    assert ie.SUCCESS == 'SUCCESS'

# Generated at 2022-06-12 17:41:14.201311
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    k = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    k.download()

# Generated at 2022-06-12 17:41:15.355627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    for test in HeiseIE._TESTS:
        f = HeiseIE()
        f.suite()

# Generated at 2022-06-12 17:41:20.980750
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with real classes
    real_kaltura_url = 'kaltura:2238431:1_oazcwduv'
    url_info = KalturaIE._build_url_result(real_kaltura_url)
    assert url_info['_type'] == 'url_transparent'
    assert url_info['url'] == real_kaltura_url
    assert url_info['ie_key'] == 'Kaltura'

    # Test with mocked classes
    class MockIE:
        def __init__(self):
            self.suitable = True
            self.working = True
    class MockIE2:
        def __init__(self):
            self.suitable = False
            self.working = False
    good_ie = MockIE()
    bad_ie = MockIE2()
   

# Generated at 2022-06-12 17:41:32.386309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Construct HeiseIE and test it.
    """
    i = HeiseIE()
    assert(i.test("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"))
    assert(i.test("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"))

# Generated at 2022-06-12 17:41:36.245723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from tests.test_utils import (
                            create_module_for_function
                            )

    module_for_HeiseIE = create_module_for_function(
                            HeiseIE,
                            dict(HeiseIE=HeiseIE)
                            )

    assert module_for_HeiseIE.HeiseIE.__doc__ is None
    assert len(module_for_HeiseIE.HeiseIE._TESTS) > 0

# Generated at 2022-06-12 17:41:39.642723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    assert ie.valid_url(url) == True

# Generated at 2022-06-12 17:41:50.309691
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE class
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    result = HeiseIE().extract(test_url)
    assert result['id'] == '1_kkrq94sm'
    assert result['ext'] == 'mp4'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert result['timestamp'] == 1512734959
    assert result['upload_date'] == '20171208'

# Generated at 2022-06-12 17:41:51.202694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._TESTS