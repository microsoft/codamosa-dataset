

# Generated at 2022-06-12 17:35:31.315678
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie == ie.__name__

# Generated at 2022-06-12 17:35:39.290006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.get_name() == "Heise"
    assert ie.get_description() == "Heise"
    assert ie.get_url_pattern() == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:44.169015
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    h = HeiseIE()
    assert h.suitable(url)
    assert h.extract(url)

# Generated at 2022-06-12 17:35:52.113834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = [
        {
            'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
            'id': '1_kkrq94sm',
            'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        }
    ]

    actual_test_case = test_cases[0]

    # Test extractor object creation
    ie = HeiseIE(actual_test_case['url'])

    assert ie._match_id(actual_test_case['url']) is not None
    assert ie.IE_NAME == 'Heise'
    assert ie.ie_key()

# Generated at 2022-06-12 17:35:58.160460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # path to video file with valid HeiseIE url
        test_file_path = './test/data/heise.mov'
        with open(test_file_path, 'rb') as test_file:
            heiseie = HeiseIE(test_file)
    except Exception as e:
        # if any exception raised, return False
        return False
    assert heiseie is not None
    return True

# Generated at 2022-06-12 17:36:05.856831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:11.440842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:21.645986
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    test_object = HeiseIE()
    result = test_object._real_extract(test_url)
    assert result['id'] == '2403911'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-12 17:36:33.699242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:34.609121
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-12 17:36:55.671939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Test constructor for class HeiseIE
	ie = HeiseIE()
	assert ie is not None
# test_HeiseIE() ######################################################

# Generated at 2022-06-12 17:36:56.685336
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._id == 'heise'

# Generated at 2022-06-12 17:36:58.242594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-12 17:37:02.824138
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:37:10.593681
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:37:12.066667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:37:13.083898
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test if HeiseIE is working."""
    HeiseIE()

# Generated at 2022-06-12 17:37:19.130613
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    response = requests.get('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    testsite = HeiseIE(response)
    assert testsite._match_id(response.url) == '1_kkrq94sm'

# Generated at 2022-06-12 17:37:19.992142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print()

# Generated at 2022-06-12 17:37:28.519515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	from . import _test_extractors
	yield "kaltura embed", _test_extractors.test_extractor, HeiseIE, "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
	yield "youtube embed", _test_extractors.test_extractor, HeiseIE, "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"

# Generated at 2022-06-12 17:37:46.278099
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE


# Generated at 2022-06-12 17:37:56.573500
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check if class constructor can be called
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    # check if instance is created
    assert ie != None
    # call to extract without an URL should raise an Exception
    raised = False
    try:
        ie.extract()
    except:
        raised = True
    assert raised
    # supply any URL to extract method of class HeiseIE
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-12 17:37:57.078023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE()

# Generated at 2022-06-12 17:38:00.778290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    page = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie.download(page)

# Generated at 2022-06-12 17:38:11.342234
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    assert a.suitable(a.IE_NAME) == True

    assert a.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True

    assert a.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True


# Generated at 2022-06-12 17:38:21.232810
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.set_downloader(FakeDownloader())

    # Playlist
    entries = ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert len(entries) == 1         # one entry
    assert entries[0]['url'] == 'http:example.com'
    assert entries[0]['id'] == '1_59mk80sf'
    assert entries[0]['title'] == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"

# Generated at 2022-06-12 17:38:25.647111
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # test HeiseIE.extract()
    heise_id = '3977523'
    url = 'https://www.heise.de/ct/ausgabe/2018-03-WLAN-3977523.html'
    result_dict = ie.extract(url)
    assert result_dict.get('id') == heise_id
    # test HeiseIE.suitable
    assert ie.suitable(url)

# Generated at 2022-06-12 17:38:31.128945
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:38:33.524120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:38:39.415556
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE()
    if heise_ie.suitable(url) and heise_ie.working():
        print("PASS")
    else:
        print("FAIL")

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-12 17:39:19.128413
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-12 17:39:28.849247
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()
    # Check for a valid instance
    assert isinstance(extractor, HeiseIE)
    # Check for a valid url
    assert extractor._match_id(
        "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    # Check for invalid urls
    assert not extractor._match_id(
        "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.xml")

# Generated at 2022-06-12 17:39:29.637055
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL

# Generated at 2022-06-12 17:39:30.265607
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:39:32.944919
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie is not None

# Generated at 2022-06-12 17:39:41.022555
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m1 = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    m2 = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    m3 = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-12 17:39:43.278216
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_info_extractor = HeiseIE()
    assert heise_info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:44.976928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL is not None
    assert HeiseIE._TESTS is not None


# Generated at 2022-06-12 17:39:46.868609
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == 'heise'
    assert HeiseIE().ie_key() == 'heise'
    assert HeiseIE().ie_key() == 'heise'

# Generated at 2022-06-12 17:39:52.662233
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    tmp = HeiseIE()
    assert tmp.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    # assert tmp.parse_page('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == '1_59mk80sf'
    assert tmp.get_entries('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == []

# Generated at 2022-06-12 17:41:43.577023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie)
    print(repr(ie))


# Generated at 2022-06-12 17:41:46.385202
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUFFIX  # pylint: disable=E1101
    assert ie._VALID_URL  # pylint: disable=W0212

# Generated at 2022-06-12 17:41:50.868648
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(yt_dl=None)
    heise_ie._download_webpage = lambda x: {}
    assert heise_ie._real_extract(
        "ct/ausgabe/2016-12-Spiele-3214137.html", "3214137") == {}

# Generated at 2022-06-12 17:41:57.155812
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    # Unit tests for method _real_extract
    assert ie._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-12 17:41:57.825552
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:41:58.384477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-12 17:42:05.829040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:42:06.442645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:42:07.333702
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit tests for HeiseIE"""
    HeiseIE(InfoExtractor())

# Generated at 2022-06-12 17:42:11.989279
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # URL of heise article which contains a video
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)
    assert (heiseIE.extractor_key() == 'HeiseIE')