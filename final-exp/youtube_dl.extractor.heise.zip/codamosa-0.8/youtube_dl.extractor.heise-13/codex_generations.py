

# Generated at 2022-06-12 17:35:31.272167
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    my_test = HeiseIE()
    assert my_test


# Generated at 2022-06-12 17:35:35.288060
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	video = HeiseIE()._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
	assertHeiseVideo(video , "1_kkrq94sm")


# Generated at 2022-06-12 17:35:44.872734
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_logging = {'level': 'ERROR'}
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE(test_logging)
    match = heiseie._VALID_URL.match(test_url)
    assert match
    assert match.group('id') == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'

# Generated at 2022-06-12 17:35:49.727174
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie

# Generated at 2022-06-12 17:35:50.641101
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-12 17:36:00.622136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for _VALID_URL
    print("test for _VALID_URL")
    assert HeiseIE._is_valid_url('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == True
    assert HeiseIE._is_valid_url('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html?wt_mc=rss.ho.beitrag.atom') == True

# Generated at 2022-06-12 17:36:03.197600
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:09.500631
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html?wt_mc=rss.ho.beitrag.atom'
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    expected_id = '1_59mk80sf'
    assert heise_ie._id_from_url(test_url) == expected_id

# Generated at 2022-06-12 17:36:11.645383
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-12 17:36:13.277834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:36:26.759136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:36:29.182443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == "Heise"
    assert obj.ie_name() == "Heise.de"

# Generated at 2022-06-12 17:36:38.033474
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    instance = class_()
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:36:39.067513
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-12 17:36:44.763409
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    e = HeiseIE()._real_extract(u)
    print(e)

# Tests for the class HeiseIE

# Generated at 2022-06-12 17:36:52.317399
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE._VALID_URL.match('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert HeiseIE._VALID_URL.match('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-12 17:37:00.191086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of HeiseIE"""
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.name == "heise"
    assert ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-12 17:37:06.471224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert test._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert test._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-12 17:37:13.435541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.suitable(None) is False
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom') is True

# Generated at 2022-06-12 17:37:15.053452
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   obj = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-12 17:37:33.525035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    infoExtractor = HeiseIE()
    assert infoExtractor.ie_key() == 'heise'

# Generated at 2022-06-12 17:37:42.538905
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # We will use the constructor of class HeiseIE to test HeiseIE class.
    # First, we need to import class HeiseIE.
    from ..jsinterp import JSInterpreter

    from .test_HeiseIE import HeiseIE as HeiseIE_test

    # Then, we construct an instance of class HeiseIE.
    heise_ie = HeiseIE_test(JSInterpreter())

    # Since module 'compat' is not imported in __init__.py, we need to import
    # it before using it.
    from ..compat import compat_str

    # We will test URL 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-12 17:37:49.524835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_class = HeiseIE(None, {})
    # list default values for class attributes
    for k in dir(test_class):
        if k.startswith("__"):
            continue
        if k not in ['params', '_downloader']:
            print(k, ":", test_class.__getattribute__(k))


# Test of HeiseIE to play the video from the url

# Generated at 2022-06-12 17:37:50.414663
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	y = HeiseIE(None)


# Generated at 2022-06-12 17:38:01.210024
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructor of class HeiseIE
    # Positive test case for video
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE = HeiseIE()
    result = heiseIE.suitable(url)
    assert result == True, "Test case failed " + url
    # Test for constructor of class HeiseIE
    # Positive test case for video
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heiseIE = HeiseIE()
    result = he

# Generated at 2022-06-12 17:38:11.560478
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    webpage = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heiseie._download_webpage(webpage, '1')
    heiseie._og_search_description(webpage, '1')
    heiseie._extract_urls(webpage)
    heiseie.playlist_from_matches(
        heiseie._extract_urls(webpage), '1', '2', ie=YoutubeIE.ie_key())

# Generated at 2022-06-12 17:38:14.481579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-12 17:38:18.660258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE()._real_extract(url)

# Generated at 2022-06-12 17:38:21.305626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    obj = ie.get_info('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert obj is not None

# Generated at 2022-06-12 17:38:24.640944
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE._download_xml = lambda *args, **kwargs: None
    HeiseIE()._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")


# Generated at 2022-06-12 17:39:16.410446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-12 17:39:18.118676
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    assert test_HeiseIE != None

# Generated at 2022-06-12 17:39:27.957938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url']=='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._TESTS[1]['md5']=='e403d2b43fea8e405e88e3f8623909f1'
    assert HeiseIE._TESTS[2]['info_dict']['id']=='1_ntrmio2s'
    assert Heise

# Generated at 2022-06-12 17:39:34.988332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html', "https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html", "https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-12 17:39:42.221693
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') is True

# Generated at 2022-06-12 17:39:43.550092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable(ie._VALID_URL)

# Generated at 2022-06-12 17:39:45.957622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert hasattr(heise, '_VALID_URL')
    assert hasattr(heise, '_TESTS')
    assert hasattr(heise, '_real_extract')

# Generated at 2022-06-12 17:39:46.989360
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # TODO: Add unit test for HeiseIE
    pass


# Generated at 2022-06-12 17:39:47.941802
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert isinstance(hie, HeiseIE)

# Generated at 2022-06-12 17:39:50.672121
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # test the constructor for Heise IE class loading
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:41:37.110021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    obj = HeiseIE()
    assert(obj._VALID_URL == "https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html")
    assert(obj._TESTS[0]['url'] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-12 17:41:37.960894
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie)

# Generated at 2022-06-12 17:41:47.574396
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Test for case for kaltura embed
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie = HeiseIE(url)
    assert ie._VALID_URL == '(?:https?://)?(?:www\\.)?heise\\.de/video/(?:[^/]+/)+[^/]+-([0-9]+)(?P<id>[0-9]+)\\.html'

    # Test for case of YouTube embed

# Generated at 2022-06-12 17:41:51.250318
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:41:52.706118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(HeiseIE.ie_key())

# Generated at 2022-06-12 17:41:54.215471
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        i = InfoExtractor.iencode('Heise')
    except:
        i = None
    assert i is not None

# Generated at 2022-06-12 17:41:58.846936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.extractor_key == 'Heise'
    assert ie.extractor_type == 'IE'
    assert ie.__class__.__name__ == 'HeiseIE'

# Generated at 2022-06-12 17:42:00.098119
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE.__new__(HeiseIE)

# Generated at 2022-06-12 17:42:04.618889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heap = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heap._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-12 17:42:06.658676
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE