

# Generated at 2022-06-12 17:35:28.891786
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-12 17:35:32.471172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.ie_key() == 'Heise'
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:35:38.073343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # To test for the HeiseIE class.
        # If it is successfully loaded, it would raise no error
        HeiseIE(None)
    except TypeError:
        import sys
        from .utils import ExtractorError

        # Get the version of Python
        python_version = sys.version_info

        if python_version.major == 2 and python_version.minor == 7:
            raise ExtractorError('HeiseIE is not available for Python 2.7')
        else:
            raise ExtractorError('HeiseIE is only available for Python 2.7')

# Generated at 2022-06-12 17:35:38.643368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-12 17:35:45.191978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert not ie.suitable('https://www.heise.de/tp/angebote/special/gutschein/')

# Generated at 2022-06-12 17:35:45.926291
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())._real_initialize()

# Generated at 2022-06-12 17:35:53.384546
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    videoURL = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    id = HeiseIE._match_id(videoURL)
    page = HeiseIE._download_webpage(videoURL, id)
    title = HeiseIE._html_search_meta(('fulltitle', 'title'), page, default=None)
    description = HeiseIE._og_search_description(page, default=None) or HeiseIE._html_search_meta('description', page)

# Generated at 2022-06-12 17:36:00.334215
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_video = HeiseIE()._extract_url('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert test_video['id'] == '1_kkrq94sm', 'Test id failed'
    assert test_video['title'] ==  "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone", 'Test title failed'

# Generated at 2022-06-12 17:36:02.668721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE(
        downloader=None
    )
    assert isinstance(instance, HeiseIE)


# Generated at 2022-06-12 17:36:06.549568
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    # Test with no args
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)
    # Test with URL argument
    ie = HeiseIE(url)
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-12 17:36:34.482456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie.ie_key() == 'heise'
    assert heiseie.ie_key() == heiseie.ie_key()
    assert heiseie.ie_key() == heiseie.ie_key()
    assert heiseie.ie_key() == heiseie.ie_key()
    assert heiseie.ie_key() == heiseie.ie_key()
    assert heiseie.ie_key() == heiseie.ie_key()
    assert heiseie.ie_key() == heiseie.ie_key()


# Generated at 2022-06-12 17:36:35.365619
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-12 17:36:43.923532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie.video_id == '1_kkrq94sm'
    assert ie.ie_key() == 'Kaltura'

# Generated at 2022-06-12 17:36:44.805218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-12 17:36:45.649142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE != None


# Generated at 2022-06-12 17:36:46.259111
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-12 17:36:48.048854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert "HeiseIE()" == ie.__repr__()

# Generated at 2022-06-12 17:36:52.752292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:36:56.323219
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit = HeiseIE()
    assert unit._VALID_URL == HeiseIE._VALID_URL
    assert unit._TESTS == HeiseIE._TESTS

# Generated at 2022-06-12 17:36:59.998823
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE() # just return a constructed instance, no real URL passed
    HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') # valid URL is passed

# Generated at 2022-06-12 17:37:24.851238
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with no constructor args
    heise = HeiseIE()
    assert heise is not None
    # Test with empty arg dict
    heise = HeiseIE(dict())
    assert heise is not None
    # Test with invalid value in arg dict
    test_args = dict()
    test_args['invalid_key'] = 'invalid_value'
    heise = HeiseIE(test_args)
    assert heise is not None

# Generated at 2022-06-12 17:37:32.242549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    import datetime
    heise_inst = HeiseIE(HeiseIE._create_get_url('url'))
    assert heise_inst._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:37:38.954423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create a new instance of HeiseIE
    ie = HeiseIE()
    # Check if HeiseIE implements the _real_extract() method
    assert hasattr(ie, '_real_extract')
    # Check if the regex defined in _VALID_URL matches given url
    assert ie._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:37:39.732902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-12 17:37:40.529762
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None).to_screen('Heise')

# Generated at 2022-06-12 17:37:47.058099
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:37:50.810532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'heise'
    assert obj.ie_name() == 'heise'
    assert obj.info_dict() == {'title': 'heise', 'age_limit': 0}

# Generated at 2022-06-12 17:37:51.382804
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})

# Generated at 2022-06-12 17:37:52.746289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Unit tests for class HeiseIE

# Generated at 2022-06-12 17:37:55.675032
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This tests if the constructor can be called.
    try:
        HeiseIE()
    except Exception as e:
        assert False, "Unexpected exception in HeiseIE constructor: " + repr(e)
    assert True

# Generated at 2022-06-12 17:38:45.483245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.__class__ == HeiseIE
    assert obj.ie_key() == 'heise'
    assert obj.ie_name() == 'heise'
    # test empty url
    assert obj._search_regex(r'(?P<id>[0-9]+)', '', 'id') is None

# Generated at 2022-06-12 17:38:48.822044
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    assert isinstance(ie, HeiseIE)



# Generated at 2022-06-12 17:38:50.190023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    if ie is not None:
        print("HeiseIE created")

# Generated at 2022-06-12 17:38:50.846650
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-12 17:38:57.384740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    _VALID_URL = r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-12 17:39:07.334524
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-12 17:39:11.415249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'



# Generated at 2022-06-12 17:39:22.079369
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'Heise'

# Generated at 2022-06-12 17:39:23.543805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:39:28.426355
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE()._match_id(url) == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'

# Generated at 2022-06-12 17:41:23.097668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create instance of HeiseIE
    ieu = HeiseIE()
    # Verify that url_result (return inside _real_extract(self, url))
    # is not empty
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    url_result = ieu._real_extract(url);
    assert url_result is not None
    # Verify that "formats" in url_result
    # is not empty
    formats_result = url_result['formats']
    assert len(formats_result) > 0
    # Verify that "formats" in url_result
    # is a list

# Generated at 2022-06-12 17:41:33.264461
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("1_ntrmio2s")
    assert ie.ie_key() == "Kaltura"
    assert ie.video_id == "1_ntrmio2s"
    assert ie.url == "https://vod.kaltura.com/ext/1_ntrmio2s"

# Generated at 2022-06-12 17:41:34.943025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_heise = HeiseIE()
    assert ie_heise is not None


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-12 17:41:37.778491
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.host() == 'heise'
    assert ie.description() == 'heise online'
    assert ie.working() is True


# Generated at 2022-06-12 17:41:38.574805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-12 17:41:49.492464
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from MediaSources import MediaSource
    from MediaSources import MediaSoup
    from MediaSources import YoutubeSource
    from MediaSources import KalturaSource

    # Test for Kaltura Videos
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    extractor = HeiseIE()
    kaltura_url = 'kaltura:2238431:1_kkrq94sm'
    source = extractor.make_media_source(test_url)
    assert isinstance(source, MediaSoup)
    assert len(source.sources) == 1
    assert isinstance(source.sources[0], KalturaSource)

# Generated at 2022-06-12 17:41:51.495914
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-12 17:41:53.370916
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.name == 'heise'



# Generated at 2022-06-12 17:41:58.674595
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-12 17:42:05.985401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    expect_kwargs = {
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'video_id': 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'ie': 'Heise',
        'num_threads': 1,
    }
    # test constructor
    heise_ie = HeiseIE(**expect_kwargs)
    assert heise_ie._VALID_URL == HeiseIE._VALID_URL
    assert heise_ie.ie == expect_kwargs['ie']