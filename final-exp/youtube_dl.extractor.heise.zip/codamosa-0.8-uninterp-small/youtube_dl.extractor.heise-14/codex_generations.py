

# Generated at 2022-06-26 12:00:16.433699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    heise_i_e_1 = HeiseIE(
    )


# Generated at 2022-06-26 12:00:17.825136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE


# Generated at 2022-06-26 12:00:29.696393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'

# Generated at 2022-06-26 12:00:34.775665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-26 12:00:35.933861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'
    assert HeiseIE.__doc__ == 'HeiseIE()'


# Generated at 2022-06-26 12:00:38.334085
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import unittest
    try:
        heise_i_e_0 = HeiseIE()
    except:
        assert False


# Generated at 2022-06-26 12:00:40.598186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-26 12:00:50.603904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert raise_exception(
        heise_i_e_0._download_webpage, 
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', 
        '1_kkrq94sm',
        'Podcast: c\'t uplink 3.3 \u2013 Owncloud / Tastaturen / Peilsender Smartphone', 
        's', 
        None)


# Generated at 2022-06-26 12:00:51.680558
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()

# Generated at 2022-06-26 12:00:55.502388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_i_e = HeiseIE()
    heise_i_e._download_webpage(url)
    heise_i_e._download_webpage(url, '3700244')
    heise_i_e._download_webpage(url, video_id='3700244')
    heise_i_e._download_webpage(url, video_id='3700244',
                                note='Downloading webpage')

# Generated at 2022-06-26 12:01:07.669078
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """

    heiseIE = HeiseIE()
    assert heiseIE is not None

# Generated at 2022-06-26 12:01:10.314094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #Test on a non-existing video
    test_video = "wrongURL"
    page = InfoExtractor.request_webpage(test_video,"Test Page")
    assert(page == None)

# Generated at 2022-06-26 12:01:20.771045
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.NAME == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)*([^/]+-)?(?P<id>[0-9]+)\.html'
    assert ie.IE_NAME == 'heise'
    assert ie.ie_key() == 'Heise'
    assert ie.age_limit == 0

# Generated at 2022-06-26 12:01:23.007456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj != None


# Generated at 2022-06-26 12:01:30.890802
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.SUFFIX == ""  # Check default suffix
    assert ie.host == "heise.de"
    assert ie._VALID_URL == \
        r'https?://(?:www\.)?heise\.de/(?P<id>[^/]+)(?:[^/]*)/(?P<display_id>[^/]+)-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:35.540237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert h

# Generated at 2022-06-26 12:01:38.655939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-26 12:01:45.883744
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    info = heiseIE._real_extract("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    print("%s" % info)

# Generated at 2022-06-26 12:01:56.320304
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    expect_video_info = {
        'id': '1_59mk80sf',
        'ext': 'mp4',
        'title': "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten",
        'description': 'md5:f50fe044d3371ec73a8f79fcebd74afc',
        'timestamp': 1517567237,
        'upload_date': '20180202',
    }

    video_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
   

# Generated at 2022-06-26 12:01:58.223065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == 'heise'

# Generated at 2022-06-26 12:02:16.642258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:02:20.566293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:02:21.400794
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-26 12:02:31.599067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    # heise url
    assert heise._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html', 'Wrong url is stored in _VALID_URL'
    # heise video_id
    assert heise.video_id == '3700244', 'Wrong id is stored in video_id'

# Generated at 2022-06-26 12:02:33.572653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-26 12:02:42.545180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import (
        determine_ext,
        int_or_none,
        NO_DEFAULT,
        parse_iso8601,
        smuggle_url,
        xpath_text,
    )

    _VALID_URL = r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:48.202965
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(InfoExtractor())
    assert isinstance(heise_ie, InfoExtractor)
    assert isinstance(heise_ie, HeiseIE)

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:02:51.153815
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        assert HeiseIE
    except:
        print("Error creating HeiseIE Class")
        print("Please make sure that HeiseIE class definition is updated in extractor folder as per the instructions given in README.md file")

# Generated at 2022-06-26 12:02:56.655123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.download('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:02:59.631997
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_downloader import FakeYDL
    ydl = FakeYDL()
    ie = HeiseIE(ydl)
    assert ie.ydl is ydl

# Generated at 2022-06-26 12:03:34.019075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:03:36.315409
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL == HeiseIE._VALID_URL)

# Generated at 2022-06-26 12:03:37.133719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:03:43.872525
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = HeiseIE()
    assert u.ie_key() == 'heise'
    assert u.ie_name() == 'heise'
    assert u.supported_domains == ['heise.de']
    assert u.regex == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert u.url_re == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert u.template_ids == ('id',)

# Generated at 2022-06-26 12:03:46.422130
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:03:54.905030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info = info_extractor._real_extract(url)
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info['thumbnail'] == 'https://cdnapisec.kaltura.com/p/2238431/sp/223843100/thumbnail/entry_id/1_kkrq94sm/width/640/height/360'
    assert info['timestamp']

# Generated at 2022-06-26 12:04:01.388706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This test case is disabled because it uses network
    # resources. You may enable it for local testing.
    return
    class DummyIE(HeiseIE):
        def _real_extract(self, url):
            pass

    DummyIE()._real_extract('http://example.org')

# Generated at 2022-06-26 12:04:03.206327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(None)
    assert heise_ie is not None

# Generated at 2022-06-26 12:04:13.049351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    conf_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert ie._match_id(conf_url) == '3814130'
    test_url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    assert ie._match_id(test_url) == '2403911'

# Generated at 2022-06-26 12:04:24.060742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.ie_key() == 'heise'
    with open('test/testdata/heise/test.html') as f:
        html = f.read()
        ie = HeiseIE(InfoExtractor())
        assert ie.get_id_from_url('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == '1_ntrmio2s'
        assert ie.get_extractor_from_html(html) == 'heise'

# Generated at 2022-06-26 12:05:56.701300
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()


# Generated at 2022-06-26 12:06:02.535292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Initialization test for the class HeiseIE
    """
    instance = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:04.705520
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-26 12:06:06.138089
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

# Generated at 2022-06-26 12:06:07.567616
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), InfoExtractor)

# Generated at 2022-06-26 12:06:12.077152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # test constructor
    def test_HeiseIE_constructor():
        instance = HeiseIE()

    test_HeiseIE_constructor()



# Generated at 2022-06-26 12:06:22.130897
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test1 = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert test1.get_url() == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

    test2 = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html#)')

# Generated at 2022-06-26 12:06:23.531138
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie.service_key, str), ie.service_key
    assert isinstance(ie.service_name, str), ie.service_name

# Generated at 2022-06-26 12:06:26.894176
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # assert HeiseIE.__init__()
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:06:35.214415
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	assert HeiseIE()._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:10:10.689383
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        print (__file__)
    except:
        print ('[!] Unit tests need to be run from inside referrer-tests/')

    print ('[*] Starting unit tests for HeiseIE')
    heise_ie = HeiseIE()

    # Test case:
    #   URL: http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    #   Result: MD5 hash of video title
    print ('[*] Testing for http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')