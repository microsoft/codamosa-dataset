

# Generated at 2022-06-26 12:00:17.342900
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e != None, "Test case failed to construct HeiseIE object"


# Generated at 2022-06-26 12:00:29.516525
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the presence of parameters
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:31.452527
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0() == HeiseIE()


# Generated at 2022-06-26 12:00:39.082994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    assert heise_i_e_0._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:39.657060
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE



# Generated at 2022-06-26 12:00:43.612365
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Assert that HeiseIE is initialised correctly and returns a HeiseIE object 
    ma_instance = HeiseIE()
    assert type(ma_instance) == HeiseIE

# Generated at 2022-06-26 12:00:45.658502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)


# Generated at 2022-06-26 12:00:47.370150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-26 12:00:51.641066
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_raises(RegexNotFoundError, HeiseIE,
                  'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:00:52.503484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0()

# Generated at 2022-06-26 12:01:12.610528
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie._TESTS[0]['info_dict']['id'] == "1_kkrq94sm"
    assert ie._TESTS[0]['info_dict']['ext'] == "mp4"


# note: also testing for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:23.923260
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:30.965144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'Heise'
    assert heise_ie.ie_key() in heise_ie.supported_ie

    assert( heise_ie._VALID_URL ==
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:01:32.314780
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-26 12:01:35.874859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseVideo = HeiseIE(InfoExtractor() )
    assert HeiseVideo.ie_key() == 'Heise'
    assert HeiseVideo.ie_name() == 'Heise'

# Generated at 2022-06-26 12:01:37.856134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE)



# Generated at 2022-06-26 12:01:39.355468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor test
    heise = HeiseIE(InfoExtractor())


# Generated at 2022-06-26 12:01:51.010535
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The url for heise video contains id Info for the video
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_ie = HeiseIE()
    # HeiseIE has its own method to get video ID from url
    video_id = heise_ie._match_id(url)
    # Extract info for the video
    info_dict = heise_ie.extract(url)
    # The id of the video should equal to the one extracted from url
    assert(info_dict['id'] == video_id)

# Generated at 2022-06-26 12:01:51.978158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    Test = HeiseIE
    Test.test(Test)

# Generated at 2022-06-26 12:01:52.742802
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _ = HeiseIE('test', 'test')

# Generated at 2022-06-26 12:02:18.110789
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    result = HeiseIE.suitable(url)
    print(result)


# Generated at 2022-06-26 12:02:18.842257
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:02:21.252632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.ie_key() == 'heise:video'

# Generated at 2022-06-26 12:02:23.572280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-26 12:02:27.759039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert HeiseIE._VALID_URL == ie._VALID_URL
    assert HeiseIE._TESTS == ie._TESTS

# Generated at 2022-06-26 12:02:35.306898
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE.VALID_URL
    assert HeiseIE._TESTS == HeiseIE.TEST
    # Check that the constructor works
    try:
        HeiseIE(None)
    except:
        pass
    else:
        raise AssertionError('Failed to raise expected exception')

# Generated at 2022-06-26 12:02:38.411720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # HeiseIE.__init__() doesn't take any arguments
    heise_IE = HeiseIE()
    assert heise_IE is not None

# Generated at 2022-06-26 12:02:51.762766
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:02:54.871774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-26 12:03:03.058296
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._real_initialize()
    assert ie.ie_key() == 'heise'
    assert ie.IE_NAME == 'heise.de'
    assert ie.BASE_URL == 'http://www.heise.de'
    assert ie.VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.BR_DESC == '{0} – heise online'.format(HeiseIE._search_regex(
        r'<title>(?P<title>[^<]+)</title>', ie.webpage, 'title', fatal=False))

# Generated at 2022-06-26 12:03:41.693033
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-26 12:03:44.642042
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'


# Generated at 2022-06-26 12:03:49.946256
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.startswith('(?:')
    assert info_extractor.endswith(':[0-9]+)')
    assert info_extractor.count('|') == 4

# Generated at 2022-06-26 12:03:55.585667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(ie.hostname() == 'www.heise.de')
    assert(ie.num_videos() == 1)
    assert(ie.video_id() == '1_kkrq94sm')
    assert(ie.has_video(ie.video_id()))
    assert(ie.video_title() == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")

# Generated at 2022-06-26 12:04:01.918496
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create a instance of HeiseIE
    # Success: No exception should be thrown and instance should be created
    try:
        heise_ie = HeiseIE()
    except Exception as e:
        assert False, 'Unable to create instance of HeiseIE'

# Unit test to check the _real_extract function of class HeiseIE

# Generated at 2022-06-26 12:04:03.478659
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL

# Generated at 2022-06-26 12:04:05.981494
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise=HeiseIE(None)
    assert heise is not None

# Generated at 2022-06-26 12:04:09.011485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    instance = class_()
    assert isinstance(class_, type)
    assert isinstance(instance, class_)

# Generated at 2022-06-26 12:04:15.071083
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie_instance = HeiseIE(url)
    title = ie_instance._html_search_meta(
        'title', ie_instance.webpage, default=None)
    kaltura_url = ie_instance._search_regex(
        r'<iframe[^>]+src="(https?://[^"]+)/media/kwidget/wid/1_kkrq94sm/uiconf_id/55121552/entry_id/1_kkrq94sm"',
        ie_instance.webpage, 'kaltura url', default=None)

# Generated at 2022-06-26 12:04:25.724668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # extract the JSON blob from one of the test pages
    with open('test/testdata/test_heise.txt') as tfile:
        json = tfile.read()
    heise = HeiseIE({})
    # extract the video ID from the HTML part
    # test/testdata/test_kaltura_player.html
    html = '''<div class="videoplayerjw" data-container="84" data-sequenz="3" id="KalturaDynamicPlayer_0_13s0s1s6">'''
    video_id = heise._search_regex(
        r'<div class="videoplayerjw"[^>]+data-container="([0-9]+)"',
        html, 'container ID')
    assert video_id == "84"
    sequenz_id = he

# Generated at 2022-06-26 12:06:09.638131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie=HeiseIE()
    heiseie._downloader.verbose=True
    title="c't-Mediathek: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    video_id="1_kkrq94sm"
    heiseie._download_xml_formats(title, video_id)

# Generated at 2022-06-26 12:06:21.327895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_constructor(url, expected_ie):
        ie = HeiseIE(url)
        assert ie.suitable(url)
        assert ie.ie_key() == expected_ie
    _test_constructor(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        KalturaIE.ie_key())
    _test_constructor(
        'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom',
        YoutubeIE.ie_key())

# Generated at 2022-06-26 12:06:27.219628
# Unit test for constructor of class HeiseIE
def test_HeiseIE():  # This test is just to see that no exception is raised.
    url = "https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html"
    ie = HeiseIE.from_url(url)
    ie.extract(url)

# Generated at 2022-06-26 12:06:34.763363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie == HeiseIE


# Generated at 2022-06-26 12:06:36.847251
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()
    assert t.SUCCESS

# Generated at 2022-06-26 12:06:38.330293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # constructor should not raise error
    assert HeiseIE(InfoExtractor())

# Generated at 2022-06-26 12:06:42.037521
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie,InfoExtractor)
    assert isinstance(ie,KalturaIE)
    assert isinstance(ie,YoutubeIE)

# Generated at 2022-06-26 12:06:52.120939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.ie_key() == 'Heise'
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-26 12:06:58.635909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie.__name__ == 'Heise'
    assert ie.ie_key() == 'Heise'
    assert ie.server_url == 'heise.de'

# Generated at 2022-06-26 12:07:05.048254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')