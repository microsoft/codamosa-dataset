

# Generated at 2022-06-26 12:00:15.601070
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:16.718028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    pass


# Generated at 2022-06-26 12:00:20.840004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as ex:
        print(ex)
        assert False


# Generated at 2022-06-26 12:00:25.856592
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE(
        examples=None,
        ie_key='Kaltura',
        ie_key_prefix='heise:',
        trainable=True,
        )


# Generated at 2022-06-26 12:00:34.185720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id = '1_ntrmio2s'
    assert HeiseIE._match_id(url) == video_id

# Generated at 2022-06-26 12:00:35.643674
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()


# Generated at 2022-06-26 12:00:41.798608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if (heise_i_e_0.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')):
        heise_i_e_0._real_extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:00:43.990670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:45.433301
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(isinstance(HeiseIE(), HeiseIE))

# Generated at 2022-06-26 12:00:52.937266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # url should be of this format: http://www.heise.de/ct/artikel/<id>.html
    # id is not necessarily a number
    url = ("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-"
           "Peilsender-Smartphone-2403911.html")
    heise_i_e_0 = HeiseIE()
    
    return

test_case_0()

# Generated at 2022-06-26 12:01:02.569393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None


# Generated at 2022-06-26 12:01:05.456300
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global heise_i_e_0
    assert(heise_i_e_0 is not None)

# Generated at 2022-06-26 12:01:08.554165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    # Unit test for foo in class HeiseIE
    heise_i_e.foo()

# Generated at 2022-06-26 12:01:21.904001
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0.name in ['heise', 'Heise']
    assert heise_i_e_0.description in ['heise Download: Video, Audio, Podcasts', 'Heise Download: Video, Audio, Podcasts']
    assert heise_i_e_0.ie_key() in ['heise', 'Heise']
    assert heise_i_e_0.ie_key() in ['heise', 'Heise']
    assert heise_i_e_0._VALID_URL in ['https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-[0-9]+.html']

# Generated at 2022-06-26 12:01:24.605677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:30.223059
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_i_e_0.ie_key() == 'HeiseIE'



# Generated at 2022-06-26 12:01:32.107895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()



# Generated at 2022-06-26 12:01:42.257716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url2 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    url3 = 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'

# Generated at 2022-06-26 12:01:44.469355
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:46.035081
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE)

# Generated at 2022-06-26 12:01:57.886352
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-([0-9]+)\.html'

# Generated at 2022-06-26 12:02:00.228892
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if HeiseIE class is constructed or not
    assert 'HeiseIE' in globals()

# Generated at 2022-06-26 12:02:02.231579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    print(heiseIE.SUFFIX)

# Generated at 2022-06-26 12:02:06.874031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:07.698436
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._TESTS

# Generated at 2022-06-26 12:02:09.728809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_obj = HeiseIE()
    assert unit_test_obj is not None

# Generated at 2022-06-26 12:02:21.489231
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
	#url = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
	#url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

	#url = "http://www.

# Generated at 2022-06-26 12:02:26.895441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == ('https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+'
		'[^/]+-(?P<id>[0-9]+)\\.html')

# Generated at 2022-06-26 12:02:32.146691
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-26 12:02:35.152048
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _test_cases
    _test_cases.run_unittest(HeiseIE)


# Generated at 2022-06-26 12:02:53.498887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(0)
    assert ie

# Generated at 2022-06-26 12:02:55.500634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE_instance = HeiseIE()

# Generated at 2022-06-26 12:02:56.856426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:02:58.761881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE != None


# Generated at 2022-06-26 12:03:11.994378
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    fetch_page = lambda URL, video_id: {
        'status_code': 200,
        'url': test_url,
        'content': '<div data-container="5577" data-sequenz="0" data-title="c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone" id="kaltura_player_1512429132" style="width:480px;height:270px;"></div>'
    }
    HeiseIE.fetch_page = fetch_page
    heise_ie = HeiseIE({})

# Generated at 2022-06-26 12:03:22.205146
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert not ie.suitable("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-26 12:03:32.499595
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    HeiseIE("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-26 12:03:33.730423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ies = HeiseIE()

# Generated at 2022-06-26 12:03:39.780358
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:03:41.255266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-26 12:04:17.389861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"
    assert hasattr(ie, '_TESTS')
    assert len(ie._TESTS) == 8

# Generated at 2022-06-26 12:04:26.322815
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Basic test to test HeiseIE with a media id.
    """
    ie = HeiseIE(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    video = ie.extract('1_kkrq94sm')
    assert video
    assert video['title'] ==  "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert video['id'] == '1_kkrq94sm'

# Generated at 2022-06-26 12:04:35.588017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:42.689264
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    aHeiseIE = HeiseIE();
    #assert aHeiseIE.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")


# Generated at 2022-06-26 12:04:48.989175
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE
    test_HeiseIE.__doc__ = ie.__doc__
    assert ie.__name__ == "HeiseIE"
    assert ie.ie_key() == "heise"
    assert ie.supported_domains == ["heise.de"]

# Generated at 2022-06-26 12:04:58.477589
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:05:00.109965
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-26 12:05:04.881045
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-26 12:05:17.040220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Creates an instance of HeiseIE with a mock in, puts it into the registry
    so that the unit test is able to retrieve it by name, and then executes the
    unit test on it."""

    # Create a dummy subclass of InfoExtractor
    class MockInfoExtractorSubclass(InfoExtractor):
        IE_NAME = 'mockie'

    # Put it into the registry
    InfoExtractor._registry[MockInfoExtractorSubclass.IE_NAME] = MockInfoExtractorSubclass

    # Create the expected HeiseIE instance
    heiseIE = HeiseIE()

    # Create the test Harvester instance and execute the test on it
    heiseIE.run_tests()


# Generated at 2022-06-26 12:05:17.793491
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:06:52.705713
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is not None
    assert HeiseIE._VALID_URL.match('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None

# Generated at 2022-06-26 12:06:59.752796
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test 1: Random url - should not be handled by this extractor
    url = "http://www.heise.de/broken-link.html"
    opts = {
        'usenetrc': False,
        'verbose': True,
        'skip_download': True,
    }
    return HeiseIE(opts).suitable(url)

# Test 2: Valid url - should be handled by this extractor

# Generated at 2022-06-26 12:07:03.957064
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert issubclass(HeiseIE, InfoExtractor)
    assert ie
# Unit test to check if object is an instance of InfoExtractor

# Generated at 2022-06-26 12:07:13.243245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # Test with an invalid url
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    Test = HeiseIE(url)
    assert Test.url == url
    assert Test.id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'
    assert Test._VALID_URL == HeiseIE._VALID_URL
   

# Generated at 2022-06-26 12:07:22.308482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    # Test successful initialization without fail
    assert heise_ie != None
    # Test if _VALID_URL matches
    assert heise_ie._match_id("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html") == '2403911'
    # Test if _VALID_URL does not match
    assert heise_ie._match_id("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911") is None

# Generated at 2022-06-26 12:07:32.577269
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# HeiseIE unit test
	info_dict = { 
		'id': '1_ntrmio2s',
		'ext': 'mp4',
		'title': "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?",
		'description': 'md5:47e8ffb6c46d85c92c310a512d6db271',
		'timestamp': 1512470717,
		'upload_date': '20171205',
	}
	url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
	assert info_dict == He

# Generated at 2022-06-26 12:07:34.050131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:07:36.232638
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i.ie_key() == 'heise'

# Generated at 2022-06-26 12:07:40.334057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:07:45.183373
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._real_extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')