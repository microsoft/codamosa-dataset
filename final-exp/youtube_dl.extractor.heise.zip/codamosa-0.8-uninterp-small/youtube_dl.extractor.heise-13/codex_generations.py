

# Generated at 2022-06-26 12:00:22.698852
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_i_e = HeiseIE()
    assert heise_i_e._real_extract(url)


# Generated at 2022-06-26 12:00:24.853355
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE()._downloader.params["format"] == "best")


# Generated at 2022-06-26 12:00:25.862912
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()

# Generated at 2022-06-26 12:00:26.842586
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_ = HeiseIE()

# Generated at 2022-06-26 12:00:29.338599
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()


# Generated at 2022-06-26 12:00:31.913310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0.__class__.__name__ == 'HeiseIE'


# Generated at 2022-06-26 12:00:34.703213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    assert heise_i_e_0 != None

# Generated at 2022-06-26 12:00:43.433087
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:54.793229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_equal(heise_i_e_0.name, 'heise:videosec')
    assert_equal(heise_i_e_0.num_entries, None)
    assert_equal(heise_i_e_0.headers, None)
    assert_equal(heise_i_e_0.max_bitrate, None)
    assert_equal(heise_i_e_0.fatal, False)
    assert_equal(heise_i_e_0.params, None)
    assert_equal(heise_i_e_0.obfuscated_player, False)
    assert_equal(heise_i_e_0.downloader, None)
    assert_equal(heise_i_e_0.recursive, None)

# Generated at 2022-06-26 12:00:55.694900
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_unit_test = HeiseIE()

# Generated at 2022-06-26 12:01:06.527966
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    if h is not None:
        pass

# Generated at 2022-06-26 12:01:11.719972
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    inst = HeiseIE()
    assert inst.suitable(url)
    id = inst._match_id(url)
    assert id == '2404147'
    assert inst._real_extract(url)

# Generated at 2022-06-26 12:01:23.598027
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor"""

# Generated at 2022-06-26 12:01:24.687018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:01:25.717676
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj.extractor_key == 'Heise'



# Generated at 2022-06-26 12:01:26.514974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _test_HeiseIE(HeiseIE)


# Generated at 2022-06-26 12:01:30.297695
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.VERSION == '1.1'

# Generated at 2022-06-26 12:01:32.176125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE("heise.de", None)
    assert ie is not None

# Generated at 2022-06-26 12:01:42.291901
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .abc import BaseIE
    from .abc import BaseIE2
    from .abc import BaseIE3
    from .abc import BaseIE4
    from .abc import BaseIE5
    from .abc import BaseIE6
    from .abc import BaseIE7
    from .abc import BaseIE8
    from .abc import BaseIE9
    from .abc import BaseIE10
    from .abc import BaseIE11
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import (
        determine_ext,
        int_or_none,
        NO_DEFAULT,
        parse_iso8601,
        smuggle_url,
        xpath_text,
    )

    # unittests in __main__ are not loaded when using from ..utils import
    # hence this test will not be executed

# Generated at 2022-06-26 12:01:53.259240
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    heise.extract("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-26 12:02:12.996960
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:02:15.742620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_test = HeiseIE()
    assert heise_test != None


# Generated at 2022-06-26 12:02:23.192099
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-26 12:02:25.346519
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    data = HeiseIE()
    assert data.ie_key() == 'heise'

# Generated at 2022-06-26 12:02:25.989322
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:02:33.883561
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    assert ie.suitable("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom") is False
    # Test if HeiseIE performs a call to the super class constructor of InfoExtractor
    assert ie.extractor_key is not None

# Generated at 2022-06-26 12:02:35.758535
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-26 12:02:38.600352
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.IE_NAME == 'heise.de'
    assert obj.IE_DESC == 'heise.de'

# Generated at 2022-06-26 12:02:40.357523
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:02:52.403015
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Note: The following two lines are to prevent the test from failing
    #       if no network is available. Some test scripts do not have mocks
    #       of the YoutubeIE class available.
    try:
        from .youtube import YoutubeIE
    except ImportError:
        YoutubeIE = None

    # Note: The following line is to prevent the test from failing
    #       if no network is available. Some test scripts do not have mocks
    #       of the KalturaIE class available.
    KalturaIE = None

    # The following line is to prevent the test from failing
    # if no network is available.
    extractor = HeiseIE(None)
    assert extractor is not None

    # The following line is to prevent the test from failing
    # if no network is available.
    extractor.working = False

# Generated at 2022-06-26 12:03:35.848961
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:03:36.577285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-26 12:03:38.994986
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('')
    assert obj
    return True

# Generated at 2022-06-26 12:03:43.588763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE(None)
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert h._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-26 12:03:54.069019
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    result = ie._real_extract(ie._TESTS[0]['url'])
    assert result['id'] == '1_kkrq94sm'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert result['timestamp'] == 1512734959
    assert result['upload_date'] == '20171208'
    assert result['_type'] == 'url_transparent'
    assert result['url'] == 'kaltura:2238431:1_kkrq94sm'
    assert result['ie_key'] == 'Kaltura'
   

# Generated at 2022-06-26 12:03:56.118859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-26 12:04:03.893038
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html', 'mp4')
    assert ie.name == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.title() == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"


# Generated at 2022-06-26 12:04:07.718907
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Exercise __init__()
    x = HeiseIE()
    # Assert that HeiseIE.extract is defined
    assert x.extract is not None

# Generated at 2022-06-26 12:04:11.547385
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-26 12:04:19.239196
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e=HeiseIE()
    e._real_extract ('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-26 12:05:52.010553
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  ie = HeiseIE()
  assert ie.ie_key() == 'heise'

# Generated at 2022-06-26 12:06:00.539078
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test 1
    result = HeiseIE().extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert result['id'] == '1_kkrq94sm'
    assert result['ext'] == 'mp4'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

    # Test 2
    result = HeiseIE().extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-26 12:06:08.007490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ydl_opts = {}
    # Initialize class HeiseIE
    ue = HeiseIE()
    # Call method _real_extract
    ue._real_extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html',ydl_opts)

# Generated at 2022-06-26 12:06:20.752063
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE(None)
    except TypeError as e:
        assert False, 'HeiseIE constructor raises TypeError: ' + str(e)

    heise_ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert heise_ie


# Generated at 2022-06-26 12:06:27.338540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Should not raise exception
    ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:06:40.483398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == "Heise"

    # Test if HeiseIE is able to detect Kaltura, Youtube and JWPlayer formats
    assert HeiseIE._extract_url(
        '<div class="videoplayerjw" data-preview="http://www.heise.de/video/preview/1_kkrq94sm/778x437.jpg" data-mediaid="1_kkrq94sm" data-duration="1352" data-start="0" data-container="3558" data-sequenz="3561" data-title="Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone">'
    ) == "kaltura:2238431:1_kkrq94sm"

    assert HeiseIE._extract_

# Generated at 2022-06-26 12:06:41.966588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, None)

# Generated at 2022-06-26 12:06:44.599422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def test():
        HeiseIE()
    assert test() is None, 'Unit test failed'


# Generated at 2022-06-26 12:06:53.055326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:07:00.415184
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test if this is a HeiseIE object
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.__class__ is HeiseIE
    # test the constructor of the IE
    ie = InfoExtractor('heise')
    # test if this is a HeiseIE object
    assert ie.__class__ is HeiseIE