

# Generated at 2022-06-26 12:00:27.399887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    heise_i_e = HeiseIE()

    assert heise_i_e._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:30.672573
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:00:32.131936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()

# Generated at 2022-06-26 12:00:33.777497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case_0()

# Generated at 2022-06-26 12:00:36.435255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert(heise_i_e)


# Generated at 2022-06-26 12:00:37.965182
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import HeiseIE
    assert(HeiseIE) == HeiseIE

# Generated at 2022-06-26 12:00:45.359548
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor

    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    assert ie._WORKING == ie.WORKING


# Generated at 2022-06-26 12:00:56.206792
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()
    # HeiseIE test with positive input

# Generated at 2022-06-26 12:00:57.840316
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0.url_result


# Generated at 2022-06-26 12:01:00.580230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()



# Generated at 2022-06-26 12:01:10.543781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

# Generated at 2022-06-26 12:01:17.403388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html');
    assert 'Heise' in info._WORKING

# Generated at 2022-06-26 12:01:19.470187
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    Test_HeiseIE = HeiseIE("heise.de")
    Test_HeiseIE.test()

# Generated at 2022-06-26 12:01:20.195608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:01:22.329655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create unit test stub for class HeiseIE
    assert 1 == 0

# Generated at 2022-06-26 12:01:25.036009
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUCCESS == "SUCCESS"

# Generated at 2022-06-26 12:01:26.443107
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as e:
        assert False, repr(e)
    assert True, 'This test never fails.'


# Generated at 2022-06-26 12:01:35.976157
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeIE as classYoutubeIE
    from .kaltura import KalturaIE as classKalturaIE

    heiseIE = HeiseIE()

    # Test for video YouTube
    video_url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    assert heiseIE._call_downloader(video_url) == classYoutubeIE(heiseIE)._call_downloader(video_url)

    # Test for video Kaltura

# Generated at 2022-06-26 12:01:37.897748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUCCESS

# Generated at 2022-06-26 12:01:41.821807
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create an object of class HeiseIE
    heiseIE_object = HeiseIE()
    assert isinstance(heiseIE_object, HeiseIE)

# Generated at 2022-06-26 12:01:59.842673
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-26 12:02:04.597813
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YouTubeIE
    from .npo import NPOIE
    ie = HeiseIE()
    assert ie.info_extractors[-1] == NPOIE
    assert ie.info_extractors[-2] == YouTubeIE

# Generated at 2022-06-26 12:02:06.246312
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE('www.heise.de')
    assert type(instance) is HeiseIE
    assert instance.domain == 'www.heise.de'

# Generated at 2022-06-26 12:02:07.181416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:02:17.940503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:02:19.349505
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()



# Generated at 2022-06-26 12:02:22.401929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_IE = HeiseIE()
    # Test if instance HeiseIE is created
    assert heise_IE is not None

# Generated at 2022-06-26 12:02:23.582462
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-26 12:02:30.181093
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.get_test() == None
    assert heiseIE.get_fullname() == None
    assert heiseIE.get_shortname() == None
    assert heiseIE.get_info() == None
    assert heiseIE.get_video_info() == None
    assert heiseIE.extract_video_id() == None
    assert heiseIE.get_source_info() == None

# Generated at 2022-06-26 12:02:37.368835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-26 12:03:12.858110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "tests_url_for_HeiseIE"
    heise_ie = HeiseIE(test_url)
    assert test_url == heise_ie.url_ie

# Generated at 2022-06-26 12:03:17.470099
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(True)
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    instance = HeiseIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:03:21.029337
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    #print(ie.extract(''))
    return ie

# Generated at 2022-06-26 12:03:30.474068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
                'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    print(m)

# Generated at 2022-06-26 12:03:32.211783
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert type(ie) == HeiseIE

# Generated at 2022-06-26 12:03:40.916807
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None, {}, False, None)
    assert not ie.is_suitable("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.is_suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-26 12:03:41.765943
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-26 12:03:52.033423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    video_id = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url = HeiseIE._extract_url(video_url)
    assert url == video_id

# Generated at 2022-06-26 12:04:04.508614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # For testing, set up a local version of the heise.de RSS feed
    import os
    import random
    from tempfile import mkdtemp
    from shutil import rmtree
    from .common import get_testdata_file
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, parse_qs
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed_path = urlparse(self.path)
            parsed_query = parse_qs(parsed_path.query)
            do_print("GET: %s?%s" % (parsed_path.path, parsed_path.query))

# Generated at 2022-06-26 12:04:13.817860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # without fatal error
    ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # unit test for constructor of class HeiseIE
    ie = HeiseIE()
    # without fatal error
    ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    # unit test for constructor of class HeiseIE
    ie = HeiseIE()
    # without fatal error

# Generated at 2022-06-26 12:05:48.921462
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:05:59.765689
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:06:01.515215
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-26 12:06:02.929580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != ''

# Generated at 2022-06-26 12:06:12.018758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(
            HeiseIE(downloader=None).suitable(
            'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'),
            bool)
    assert isinstance(
            HeiseIE(downloader=None).suitable(
            'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'),
            bool)

# Generated at 2022-06-26 12:06:21.871540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # 1. Download webpage
    webpage = r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    print(webpage)
    # 2. Instantiate an IE
    ies = [KalturaIE(), YoutubeIE(), HeiseIE()]
    print(ies)
    # 3. Extract video formats and subtitles
    print(InfoExtractor.extract(ies[2], webpage))
    # 4. Get the URLs of the video formats and subtitles
    print(InfoExtractor.get_info(ies[2], webpage))

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:06:32.717903
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:35.419924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == \
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:36.170239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-26 12:06:37.970380
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'


# Generated at 2022-06-26 12:10:10.938624
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'