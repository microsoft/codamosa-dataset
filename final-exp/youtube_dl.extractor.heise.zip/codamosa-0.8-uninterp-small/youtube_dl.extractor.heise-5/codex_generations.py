

# Generated at 2022-06-26 12:00:19.866140
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Case 1
    # The return value of method _real_extract
    # is a dictionary (ie. json object)
    # with the following keys: 
    # 	id
    # 	title
    # 	description
    # 	thumbnail
    # 	timestamp
    # 	formats
    from pprint import pprint as pp

    heise_i_e_1 = HeiseIE()
    url_1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_video_1 = heise_i_e_1._real_extract(url_1)
    pp(heise_video_1)

# Generated at 2022-06-26 12:00:20.986636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0() == None

#### Unit test for HeiseIE._real_extract() ####


# Generated at 2022-06-26 12:00:22.401269
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0() == None

# Generated at 2022-06-26 12:00:26.212706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("In function test_HeiseIE")
    test_case_0()
    print("Function test_HeiseIE Passed")

# Test extract, should succeed

# Generated at 2022-06-26 12:00:34.398401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e.__class__ == HeiseIE
    assert heise_i_e._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:36.435503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 'HeiseIE' in globals()


# Generated at 2022-06-26 12:00:36.994875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_equal(true, HeiseIE())

# Generated at 2022-06-26 12:00:39.832025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:41.227183
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:00:50.603632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0.get_url('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'


# Generated at 2022-06-26 12:01:00.509946
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()

# Generated at 2022-06-26 12:01:08.851730
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_ie = HeiseIE()
    video_id = heise_ie._match_id(url)
    webpage = heise_ie._download_webpage(url, video_id)

# Generated at 2022-06-26 12:01:22.086071
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-26 12:01:33.847772
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._match_id("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    heise._real_extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert heise._VALID_URL == "(?:https?://)?(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html"

# Generated at 2022-06-26 12:01:35.741608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie is not None

# Generated at 2022-06-26 12:01:37.133838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-26 12:01:42.740488
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    youtube_ie = YoutubeIE()
    kaltura_ie = KalturaIE()
    heise_ie = HeiseIE()

    assert YoutubeIE.ie_key() in heise_ie.ie_key_map
    assert KalturaIE.ie_key() in heise_ie.ie_key_map

    assert heise_ie.ie_key_map[YoutubeIE.ie_key()] is youtube_ie
    assert heise_ie.ie_key_map[KalturaIE.ie_key()] is kaltura_ie

# Generated at 2022-06-26 12:01:48.834269
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:02:00.339065
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:02:10.375672
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor test
    if not hasattr(HeiseIE, '_VALID_URL') or not HeiseIE._VALID_URL:
        return

    # Test youtube extractor
    ie = HeiseIE(YoutubeIE.ie_key())
    ie.extract('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

    # Test kaltura extractor
    ie = HeiseIE(KalturaIE.ie_key())

# Generated at 2022-06-26 12:02:28.833613
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'Heise'
    assert HeiseIE.__doc__ == 'heise.de extractor'

# Generated at 2022-06-26 12:02:31.507870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:02:41.224210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.NAME == "heise"
    assert ie.IE_NAME == "heise"

    ie = HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert ie.NAME == "heise"
    assert ie.IE_NAME == "heise"

# Generated at 2022-06-26 12:02:52.516029
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie.extract("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-26 12:02:56.720992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Make sure constructor can be called, and a heiseie object is returned
    heise_ie_instance = HeiseIE()
    assert isinstance(heise_ie_instance, HeiseIE)

# Generated at 2022-06-26 12:03:04.089957
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._TESTS[0]['url'] == url
    assert heise._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-26 12:03:05.538706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE=HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:03:14.439579
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:03:22.065238
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE._TESTS[0]['url']
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert HeiseIE._TESTS[1]['info_dict']['id'] == '6kmWbXleKW4'
    assert HeiseIE._TESTS[2]['info_dict']['id'] == '1_ntrmio2s'
    assert HeiseIE._TESTS[3]['info_dict']['id'] == '1_59mk80sf'

# Generated at 2022-06-26 12:03:28.279636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL ==  r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:11.413817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    kaltura_url = KalturaIE._extract_url(webpage)
    kaltura_id = self._search_regex(
        r'entry-id=(["\'])(?P<id>(?:(?!\1).)+)\1', webpage, 'kaltura id',
        default=None, group='id')
    print("test_HeiseIE:")
    print("kaltura_url =", kaltura_url)
    print("kaltura_id =", kaltura_id)



# Generated at 2022-06-26 12:04:18.911223
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE.report_download_page(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud' +
        '-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-26 12:04:21.045634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert HeiseIE(None).ie_key() == 'heise'

# Generated at 2022-06-26 12:04:24.054292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    heiseIE=HeiseIE()

# Generated at 2022-06-26 12:04:32.147401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  # Test when URL is valid.
  assert HeiseIE._VALID_URL.match('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
  # Test when URL is invalid.
  assert not HeiseIE._VALID_URL.match('https://www.amazon.de/')

# Generated at 2022-06-26 12:04:33.383020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-26 12:04:36.092766
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    
    assert heiseIE
    

# Used for testing

# Generated at 2022-06-26 12:04:40.001047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseIE = HeiseIE(None)
	assert heiseIE is not None


# Generated at 2022-06-26 12:04:48.463467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ix = HeiseIE(None)
    assert ix.SUCCESS_MSG == ('Downloaded c\'t video (id: {id}) and merged it'
                              ' with audio.')
    assert ix.FAILED_MSG == ('Downloading c\'t video (id: {id}) and merging it'
                             ' with audio failed!')
    assert ix.FAILED_MSG_SINGLE == ('Downloading c\'t video (id: {id}) failed!'
                                    ' Audio downloading is disabled, so no '
                                    'merging is possible.')
    assert ix.RETRY_MSG == ('Failed to download c\'t video (id: {id}), retrying'
                            ' ...')

# Generated at 2022-06-26 12:04:55.474934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE._VALID_URL(url)
    h = HeiseIE()
    video_id = h._match_id(url)
    assert h._download_webpage(url, video_id) is not None

# Generated at 2022-06-26 12:06:28.477474
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    HeiseIE._TESTS[0]
    test_HeiseIE._real_extract(HeiseIE._TESTS[0])
    
    

# Generated at 2022-06-26 12:06:33.028947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise = HeiseIE()
    result = heise._real_extract(url)

    assert(result['id'] == '1_kkrq94sm')

# Generated at 2022-06-26 12:06:34.595326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-26 12:06:46.095764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests whether the URL of an article with a video is properly constructed
    # and whether a call to the video works.
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heise = HeiseIE()
    video = heise.url_result(url)
    info = video.extract()
    assert info['id'] == '1_59mk80sf'
    assert info['title'] == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert info['timestamp'] == 1517567

# Generated at 2022-06-26 12:06:53.510149
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_video(url, test_data):
        ie = HeiseIE(params={'format': 'json'})
        result = ie.extract(url)
        for key, val in test_data.items():
            if key == 'formats':
                for format_key, format_val in val.items():
                    assert result['formats'][format_key] == format_val
            elif key == 'thumbnails':
                for format_key in val.items():
                    assert result['thumbnails'][format_key] == format_val
            else:
                assert result[key] == val


# Generated at 2022-06-26 12:06:56.362163
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-26 12:06:58.857418
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from . import HeiseIE
    except(ImportError):
        from . import heise
    print(HeiseIE)

# Generated at 2022-06-26 12:07:11.326840
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
	HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
	HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-26 12:07:16.522101
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_video = HeiseIE()
    assert heise_video._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:07:23.663118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for normal Heise video
    heise = HeiseIE('/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert (heise.name == 'Heise.de')
    assert (heise.ie_key() == 'heise')

    # Test for a Heise article with a video embedded
    heise2 = HeiseIE('/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html')
    assert (heise2.name == 'Heise.de')
    assert (heise2.ie_key() == 'heise')

    # Test for a Heise article without a video
   