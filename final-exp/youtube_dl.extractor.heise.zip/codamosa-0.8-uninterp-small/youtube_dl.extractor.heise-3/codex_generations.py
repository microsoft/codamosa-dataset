

# Generated at 2022-06-26 12:00:20.402872
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '1_kkrq94sm'
    title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    timestamp = 1512734959
    upload_date = '20171208'
    info_dict = {'id': video_id, 'ext': 'mp4', 'title': title, 'description': description, 'timestamp': timestamp, 'upload_date': upload_date}
    heise_i_e_1 = HeiseIE()

# Generated at 2022-06-26 12:00:30.212509
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_info_e_0 = {
        'id': '1_kkrq94sm',
        'ext': 'mp4',
        'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        'timestamp': 1512734959,
        'upload_date': '20171208',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
    }
    url_0 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-26 12:00:38.492987
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_equal(HeiseIE._VALID_URL, 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+.html')
    assert_equal(HeiseIE.__name__, 'HeiseIE')
    assert_equal(HeiseIE.ie_key(), 'Heise')
    assert_equal(HeiseIE.test(), HeiseIE._TESTS )

test_case_0()

# Generated at 2022-06-26 12:00:42.475907
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# test for assertEqual method of class HeiseIE

# Generated at 2022-06-26 12:00:44.590910
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0() == None


# Generated at 2022-06-26 12:00:55.462810
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_i_e_1 = HeiseIE() 
    print("INFO EXTRACTOR created successfully")
    res = heise_i_e_1._real_extract(url)
    print("\n TEST 1: extract fields from the info extractor") 
    print("VIDEO_ID: " + res["id"])
    print("TITLE: " + res["title"])
    print("DESCRIPTION: " + res["description"])
    print("TIMESTAMP: " + str(res["timestamp"]))
    print("FORMATS:")

# Generated at 2022-06-26 12:00:57.146782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()


# Generated at 2022-06-26 12:00:58.377572
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:11.275886
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    url_0 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    webpage = heise_i_e._download_webpage(url_0, None, '')
    res = heise_i_e._real_extract(url_0)
    assert 'entries' not in res
    assert res['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    assert res['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-26 12:01:13.231905
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0


# Generated at 2022-06-26 12:01:23.077781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE();
    return heise;

# Generated at 2022-06-26 12:01:23.659700
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:01:25.016094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-26 12:01:30.106825
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.__name__ == 'Heise'

# Generated at 2022-06-26 12:01:41.289521
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:52.881111
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE().result(HeiseIE()._VALID_URL)
    assert(result['id'] == '1_kkrq94sm')
    assert(result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    assert(int(result['timestamp']) == 1512734959)
    assert(result['upload_date'] == '20171208')
    assert(result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20')

# Generated at 2022-06-26 12:01:54.408206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    test_class_constructor(heise_ie)

# Generated at 2022-06-26 12:01:58.259725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:00.032766
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that you can construct an instance of the class.
    assert HeiseIE

# Generated at 2022-06-26 12:02:02.010145
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-26 12:02:29.470868
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test with a valid url
    ie = HeiseIE()
    ie.download('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

    # test with a invalid url
    ie.download('https://www.heise.de/video/artikel1/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:02:41.376755
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Sanity checks:
    import json
    # given a sample HeiseIE video,
    json_url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html?view=json"
    webpage = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    webpage_

# Generated at 2022-06-26 12:02:42.802311
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-26 12:02:44.821884
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor by passing arbitrary values
    HeiseIE(InfoExtractor)

# Generated at 2022-06-26 12:02:50.629298
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url, 'heise')
    assert ie.url == url
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-26 12:02:52.793587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-26 12:02:58.165531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS is not None

# Generated at 2022-06-26 12:03:04.509145
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.suitable('') == False
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heiseIE.suitable(url) == True
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    assert heiseIE.suitable(url) == True

# Generated at 2022-06-26 12:03:09.348203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Tests for function _real_extract of class HeiseIE

# Generated at 2022-06-26 12:03:12.412814
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:03:47.422950
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test constructor
    ie = HeiseIE(None)
    assert ie == HeiseIE


# Generated at 2022-06-26 12:03:50.864809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(**{'name':'heise'})
    assert heise.name == 'heise'
    assert heise.ie_key() == 'heise'

# Generated at 2022-06-26 12:03:51.756768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-26 12:03:53.393016
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()



# Generated at 2022-06-26 12:03:59.186739
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-26 12:04:11.348809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:04:24.305048
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case for url input
    url = 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'
    instance = HeiseIE(url)
    assert instance._match_id(url) == '2404251'

# Generated at 2022-06-26 12:04:30.154010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Dummy object for test
    heise = HeiseIE()
    heise.url = 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    heise._real_extract(heise.url)

# Generated at 2022-06-26 12:04:34.089407
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of HeiseIE should instantiate with an URL as parameter
    assert isinstance(HeiseIE(url="http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"),
                      HeiseIE)

# Generated at 2022-06-26 12:04:40.217654
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/ct/ausgabe/2017-12-Netzpolitik-3921912.html")
    assert "title" in ie.extract("1_wk8wfqb3")

# Generated at 2022-06-26 12:06:22.812325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # random article from the last days
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    video = HeiseIE._real_extract(url)

    assert video['id'] == '1_59mk80sf'
    assert video['formats'] == [{'format_note': '360p_mp4', 'format_id': 'mp4_360p_mp4', 'url': 'https://video-api.heise.de/video/1/59mk80sf/360p.mp4', 'height': 360}]

# Generated at 2022-06-26 12:06:28.442487
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(HeiseIE._VALID_URL)
    assert ie.__class__.__name__ == 'HeiseIE'
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie.IE_NAME == 'heise'
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-26 12:06:31.134955
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    pass

# Generated at 2022-06-26 12:06:41.248399
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie._VALID_URL == '(?:https?://)?(?:www\.)?heise\.de/(?:[^/]+/)+[0-9]+\.html'
    # Test accepted formats of constructor
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-26 12:06:42.810688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-26 12:06:52.442848
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:06:58.784460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise.suitable(url)
    heise.extract(url)

# Generated at 2022-06-26 12:07:01.595094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.IE_NAME == 'heise'

# Generated at 2022-06-26 12:07:07.762952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_inst = HeiseIE()
    assert(test_inst._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.(?:html)')

# Generated at 2022-06-26 12:07:14.343290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert(ie._VALID_URL ==
        'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html')