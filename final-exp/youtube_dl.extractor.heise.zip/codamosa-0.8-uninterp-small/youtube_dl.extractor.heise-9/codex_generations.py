

# Generated at 2022-06-26 12:00:16.656191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if no exception is thrown
    try:
        heise_i_e = HeiseIE()
    except Exception:
        print('Failed to instanstiate class HeiseIE')


# Generated at 2022-06-26 12:00:21.358493
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ct.common import InfoExtractor

    # Check if HeiseIE inherits from InfoExtractor
    assert issubclass(HeiseIE, InfoExtractor)


# Generated at 2022-06-26 12:00:28.112951
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with a video and an audio
    video_url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_i_e_0 = HeiseIE()
    result = heise_i_e_0.extract(video_url)

# Generated at 2022-06-26 12:00:40.523134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise_i_e_0.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:00:41.681761
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case 0
    heise_i_e_0 = HeiseIE()


# Generated at 2022-06-26 12:00:42.976457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(heise_i_e_0, HeiseIE)
    

# Generated at 2022-06-26 12:00:44.443738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0()



# Generated at 2022-06-26 12:00:46.850365
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()



# Generated at 2022-06-26 12:00:49.246861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL is not None
    assert HeiseIE._TESTS is not None

# Generated at 2022-06-26 12:00:49.948391
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-26 12:01:05.773422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE('www', 'heise')
    assert heiseie.ie_key() == 'Heise'
    assert heiseie.ie_key() == heiseie.name
    assert heiseie.name == 'Heise'
    assert heiseie.name == heiseie.ie_key()
    return heiseie

# Generated at 2022-06-26 12:01:08.376393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    constructor_test_helper(HeiseIE)

# Generated at 2022-06-26 12:01:14.876819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    globals()['HeiseIE']()._real_extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-26 12:01:17.053503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None).IE_NAME == 'Heise'

# Generated at 2022-06-26 12:01:22.659258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-26 12:01:24.221339
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-26 12:01:28.690929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor)._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE(InfoExtractor)._TESTS == HeiseIE._TESTS

# Generated at 2022-06-26 12:01:40.448114
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE(url=u)._test_extract()
    assert obj['id'] == '1_kkrq94sm'
    assert obj['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert obj['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert obj['timestamp'] == 1512734959
    assert obj['upload_date'] == '20171208'

# Generated at 2022-06-26 12:01:41.747792
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-26 12:01:47.293561
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:07.288339
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    assert(a.ie_key() == 'Heise')
    assert(a.ie_name() == 'Heise.de')

# Generated at 2022-06-26 12:02:20.432171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:02:25.734855
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE._TESTS[0]['url']
    assert HeiseIE._TESTS[0]['info_dict'] == HeiseIE._TESTS[1]['info_dict']

# Generated at 2022-06-26 12:02:27.226633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-26 12:02:30.345995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie is not None


# Generated at 2022-06-26 12:02:32.219932
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:02:38.521831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE(
        InfoExtractor(
            None
        )
    )
    template = '{0}_obj = {1}(InfoExtractor(None))'
    assert template.format(
        'test', 'HeiseIE'
    ) == str(test_obj)

# Generated at 2022-06-26 12:02:42.729087
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor and method _real_extract of class HeiseIE
    # by passing valid arguments in its constructor.
    heise = HeiseIE()

# Generated at 2022-06-26 12:02:44.183227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE({})


# Generated at 2022-06-26 12:02:46.298499
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert issubclass(HeiseIE, InfoExtractor)


# Generated at 2022-06-26 12:03:26.706395
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.set_downloader(FakeYDL({'simulate': True}))
    ie.download("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-26 12:03:29.645343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Successful construction
    ie = HeiseIE({})
    # Failed construction
    ie = HeiseIE({}, {'count': -1})

# Generated at 2022-06-26 12:03:34.293919
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Case 1
    test_url_1 = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    expected_video_id_1 = "1_ntrmio2s"
    assert HeiseIE._match_id(test_url_1) == expected_video_id_1

# Generated at 2022-06-26 12:03:35.438644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE({})._downloader, InfoExtractor)

# Generated at 2022-06-26 12:03:40.793541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]["url"] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-26 12:03:44.849285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    for url in HeiseIE._TESTS:
        tester = HeiseIE(url, {})
        assert tester is not None

# Generated at 2022-06-26 12:03:54.469392
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heise = HeiseIE(url)
    assert heise.extract_description() == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert heise.extract_id() == '1_59mk80sf'
    assert heise.extract_title() == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert heise.extract

# Generated at 2022-06-26 12:03:57.708025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert isinstance(heiseie, HeiseIE)

# Generated at 2022-06-26 12:04:06.795765
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    expected_id = '1_kkrq94sm'
    expected_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    expected_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    expected_uploader = None
    expected_timestamp = 1512734959
    expected_duration = None

    info = ie._real_extract(url)

    assert info['id'] == expected_id

# Generated at 2022-06-26 12:04:07.451666
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-26 12:05:27.355457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-26 12:05:36.022029
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    videoID = 3959893
    url = "http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    result = HeiseIE._real_extract(HeiseIE(), url)
    assert result["id"] == str(videoID)

# Generated at 2022-06-26 12:05:43.869227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test whether an instance of class HeiseIE can be initialized."""
    # method 'test_HeiseIE' of class 'HeiseIE'
    # This is the module '__main__' from '__main__.py'
    # Document: '<module>'
    # Location: (1, 0) - (1, 0)
    assert HeiseIE

# Generated at 2022-06-26 12:05:44.685286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:05:49.488770
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '2404147'
    assert HeiseIE._match_id('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == '3814130'

# Generated at 2022-06-26 12:05:51.818319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._download_webpage(NO_DEFAULT)

# Generated at 2022-06-26 12:05:53.091867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-26 12:05:59.768308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('http://www.heise.de/video/artikel/Live-mit-Toshiba-der-Notebook-ECO-Test-3098838.html')  
    assert (heise.url == 'http://www.heise.de/video/artikel/Live-mit-Toshiba-der-Notebook-ECO-Test-3098838.html')
assert (heise.video_id == '3098838')

from unittest import TestCase
from ..compat import compat_urlparse

from youtube_dl.utils import *



# Generated at 2022-06-26 12:06:02.690010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    obj = HeiseIE(url)
    return obj.get_extension()


# Generated at 2022-06-26 12:06:06.633007
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'

# Generated at 2022-06-26 12:09:13.141050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None, None)

# Generated at 2022-06-26 12:09:18.469403
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:09:24.134352
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    instance.get_entries()
    instance.playlist_from_matches([u'7-b5GCGvxo8', u'KsiDZd1vl9M', u'BbWYBk-ycsw'], u'KsiDZd1vl9M', u'Neuheiten - Messe HANNOVER MESSE 2017', ie='youtube')
    instance.playlist_from_matches([u'http://youtu.be/7-b5GCGvxo8', u'KsiDZd1vl9M', u'BbWYBk-ycsw'], u'KsiDZd1vl9M', u'Neuheiten - Messe HANNOVER MESSE 2017', ie='youtube')
    instance.playlist_

# Generated at 2022-06-26 12:09:25.488031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-26 12:09:26.772431
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h

# Generated at 2022-06-26 12:09:32.698501
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() in InfoExtractor.ie_key_map
    assert HeiseIE.ie_key() in InfoExtractor._ALL_CLASSES
    assert HeiseIE.suitable(HeiseIE._VALID_URL)



# Generated at 2022-06-26 12:09:43.101455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable(url='http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert not HeiseIE.suitable(url='http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-26 12:09:46.449290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = heise_ie._match_id(url)
    heise_ie._download_webpage(url, video_id)

# Generated at 2022-06-26 12:09:49.358419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE(name='heise', default_urls=url)

    assert(ie.name == 'heise')
    assert(ie.default_urls == url)

# Generated at 2022-06-26 12:09:51.071567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)