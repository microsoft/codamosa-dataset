

# Generated at 2022-06-26 12:00:15.791210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:16.889978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case_0()

# Workflow test for class HeiseI

# Generated at 2022-06-26 12:00:21.064094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    heise_i_e_1 = HeiseIE()


# Generated at 2022-06-26 12:00:29.808381
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_0 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url_1 = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    url_2 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'

# Generated at 2022-06-26 12:00:31.844086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(heise_i_e_0 != None)


# Generated at 2022-06-26 12:00:34.052054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()


# Generated at 2022-06-26 12:00:37.618656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Input parameters for constructor
    # Output: test for constructor

    # Class name should be HeiseIE
    assert HeiseIE.__name__ == 'HeiseIE'

# Generated at 2022-06-26 12:00:41.567952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e is not None


# Generated at 2022-06-26 12:00:43.764878
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert( isinstance( HeiseIE(), InfoExtractor ) )


# Generated at 2022-06-26 12:00:45.884656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:01.220808
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '1_kkrq94sm'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    assert heiseie._match_id(url) == video_id
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:11.342133
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    inst = HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    inst = HeiseIE("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-26 12:01:13.646934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()

# Generated at 2022-06-26 12:01:16.666594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.domain == 'heise.de'


# Generated at 2022-06-26 12:01:25.016463
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True
    assert HeiseIE.suitable("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html") == True

# Generated at 2022-06-26 12:01:35.810449
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	H = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
	assert H.url == u'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
	assert H.video_id == u'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'

# Generated at 2022-06-26 12:01:37.784618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Just a basic test to confirm that the file is not broken
    HeiseIE.test()

# Generated at 2022-06-26 12:01:38.654511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE
    assert HeiseIE()

# Generated at 2022-06-26 12:01:49.405622
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:51.694221
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-26 12:02:10.262753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _test_videos_info_extractor
    return _test_videos_info_extractor(HeiseIE)

# Generated at 2022-06-26 12:02:17.775074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print()
    print('HeiseIE Constructor')
    he = HeiseIE()
    data = {
        'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    }
    he.extract(data)
    print('Done ')

# Generated at 2022-06-26 12:02:30.472260
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert not ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert not ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie

# Generated at 2022-06-26 12:02:31.628724
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('').ie_key() == 'Heise'

# Generated at 2022-06-26 12:02:33.574806
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create a test instance of class HeiseIE
    Heise = HeiseIE()

# Generated at 2022-06-26 12:02:38.314243
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check instance creation
    ie = HeiseIE()
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie

# Generated at 2022-06-26 12:02:45.434265
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    k = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(k, HeiseIE) == True

# Generated at 2022-06-26 12:02:46.957745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:02:48.428760
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(downloader=None)

# Generated at 2022-06-26 12:02:55.639077
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _assert_run


# Generated at 2022-06-26 12:03:26.929339
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:03:31.028016
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    HeiseIE(url)


# Generated at 2022-06-26 12:03:42.295415
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    get_info = HeiseIE()._real_extract
    info_dict = get_info('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert info_dict['id'] == '1_59mk80sf'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"


# Generated at 2022-06-26 12:03:53.946203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    scraper = HeiseIE()
    assert scraper._VALID_URL  == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert scraper._TESTS[0]["info_dict"]["id"] == '1_kkrq94sm'
    assert scraper._TESTS[0]["info_dict"]["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert scraper._TESTS[0]["params"]["skip_download"] == True

# Generated at 2022-06-26 12:04:04.273584
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url_result == {'id': '1_kkrq94sm', 'ext': 'mp4', 'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone", 'timestamp': 1512734959, 'upload_date': '20171208', 'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'}

# Generated at 2022-06-26 12:04:06.258904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit = HeiseIE()
    assert unit.ie_key() == 'heise'

# Generated at 2022-06-26 12:04:07.661774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-26 12:04:09.556658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE()
    assert isinstance(result, HeiseIE)

# Generated at 2022-06-26 12:04:12.901328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This unit test is important because it tests whether the class HeiseIE has a constructor or not
    # (because it is not allowed to change the class name or constructor of class HeiseIE and
    # you should not inherit class HeiseIE for testing purposes)
    test_obj = HeiseIE('test')
    assert test_obj.ie_key() == 'Heise'

# Generated at 2022-06-26 12:04:22.800911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Das-Mathematik-Abenteuer-mit-mit-Liane-Faulder-und-dem-c-t-Magazin-3700253.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-26 12:05:46.333200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() is not None

# Generated at 2022-06-26 12:05:58.891019
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Running test for https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    actual_result = HeiseIE()._real_extract(test_url)

# Generated at 2022-06-26 12:06:08.137173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    meta_start_time = time.time()
    heise_page = "https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html"
    heise_page_extractor = HeiseIE()
    heise_page_extractor.extract(heise_page)
    meta_end_time = time.time()

# Generated at 2022-06-26 12:06:12.150093
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Constructor test"""
    heiseIE = HeiseIE()
    # Ensure that there are no errors in constructor
    assert heiseIE


# Generated at 2022-06-26 12:06:17.916137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-26 12:06:20.005883
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert "HeiseIE" == HeiseIE.ie_key()

# Generated at 2022-06-26 12:06:30.681562
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.video_id == '1_ntrmio2s'
    assert ie.video_title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    assert ie.video_description == 'md5:47e8ffb6c46d85c92c310a512d6db271'


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:06:32.970710
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    TestHeiseIE = HeiseIE(InfoExtractor)
    TestHeiseIE.ie_key()



# Generated at 2022-06-26 12:06:34.518370
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-26 12:06:39.633577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # There are two different constructors, we should be able to instantiate
    # both with no errors
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE(test_url)
    HeiseIE(test_url, expected_ie_result=None)

# Generated at 2022-06-26 12:09:50.531152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()

# Generated at 2022-06-26 12:09:59.042044
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor without arguments
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    # Constructor with one argument
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.ie_key() == 'Heise'

# Unit tests for _real_extract method of class HeiseIE

# Generated at 2022-06-26 12:10:00.752786
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    pass

# Generated at 2022-06-26 12:10:03.126764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('','')
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-26 12:10:09.940248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test valid URL
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # Test invalid URL
    assert not ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
