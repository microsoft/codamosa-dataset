

# Generated at 2022-06-26 12:00:16.577482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_0 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_case_0(url_0)


# Generated at 2022-06-26 12:00:19.269797
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:21.582155
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Call constructor of class HeiseIE
    heise_i_e = HeiseIE()

# Generated at 2022-06-26 12:00:23.658286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie_test_case_1 = HeiseIE()


# Generated at 2022-06-26 12:00:31.048694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    data_id = '1_ntrmio2s' # just for testing if the class was constructed
    heise_i_e = HeiseIE() # just declair an instance, no need to call it
    heise_i_e._download_webpage = lambda url, video_id: url # mock method
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    webpage = heise_i_e._download_webpage(url, data_id)
    assert webpage.endswith(url)



# Generated at 2022-06-26 12:00:37.662799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructor of class HeiseIE
    # Unit test for constructor of class HeiseIE
    # Test for constructor of class HeiseIE
    heise_i_e = HeiseIE()
    assert heise_i_e.ie_key() == 'heise'
    assert heise_i_e.ie_key() == 'heise'

# Generated at 2022-06-26 12:00:43.461672
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e
    assert heise_i_e == HeiseIE()
    assert isinstance(heise_i_e, InfoExtractor)

# Generated at 2022-06-26 12:00:45.581040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0


# Generated at 2022-06-26 12:00:46.789442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:00:48.297434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()

# Generated at 2022-06-26 12:00:58.588725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ = HeiseIE({})
    assert isinstance(heise_, InfoExtractor)

# Generated at 2022-06-26 12:01:11.309852
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:12.357010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:01:14.875075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass


# Generated at 2022-06-26 12:01:21.339734
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	#
	# test of constructor
	#
	# https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py
	# def __init__(self, ie_key, ie_name, ie_version=None, downloader=None):
	#
	# https://github.com/rg3/youtube-dl/blob/master/youtube_dl/YoutubeDL.py
	# def __init__(self):
	#
	# https://stackoverflow.com/questions/23176161/from-youtube-import-not-working
	#
	#from youtube_dl.extractor import common
	from youtube_dl import YoutubeDL
	from heise.heise import HeiseIE
	from heise.common import InfoExtractor

	from pprint import pprint

# Generated at 2022-06-26 12:01:29.089027
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url= 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    info= HeiseIE()._real_extract(url)
    assert info['id'] == '1_ntrmio2s'

# Generated at 2022-06-26 12:01:39.613306
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract(('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))

    ie.extract(('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'))

    ie.extract(('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'))

# Generated at 2022-06-26 12:01:42.717108
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    inst = HeiseIE()
    assert inst is not None

# Generated at 2022-06-26 12:01:44.767587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # used in HeiseIE's constructor
    assert HeiseIE._VALID_URL

# Generated at 2022-06-26 12:01:54.560725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert ie.suitable('https://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom') == True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == False
    assert ie

# Generated at 2022-06-26 12:02:20.008725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE().suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE().suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')


# Generated at 2022-06-26 12:02:26.517309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.IE_NAME == 'heise')
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:02:28.426210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise= HeiseIE({})
    assert heise._downloader

# Generated at 2022-06-26 12:02:38.975832
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({'__name__': 'test'})
    assert hasattr(ie, '_VALID_URL')

    ie._download_webpage = lambda *args: 'wrd_webpage'
    ie._html_search_regex = lambda *args: None
    ie._search_regex = lambda *args: None
    ie._og_search_thumbnail = lambda *args: None
    ie._html_search_meta = lambda *args: None
    ie._og_search_description = lambda *args: None

    ie.extract()

# Generated at 2022-06-26 12:02:43.236828
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() in extractor_defs

# Generated at 2022-06-26 12:02:48.886773
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE()(url)

# Generated at 2022-06-26 12:02:51.824877
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    HeiseIE(test_url)


# Generated at 2022-06-26 12:02:53.783072
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert True, "Test for presence of constructor for class HeiseIE"

# Generated at 2022-06-26 12:02:59.594039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    instance._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:03:12.444695
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    message = str(ie)
    assert ie.extractor.name == 'Heise'
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:03:53.223163
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id = '1_ntrmio2s'
    webpage = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2....'
    title = 'nachgehakt: Wie sichert das c\'t-Tool Restric\'tor Windows 10 ab?'
    description = 'md5:47e8ffb6c46d85c92c310a512d6db271'
    timestamp = 1512470717
    upload_

# Generated at 2022-06-26 12:03:56.501680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor call of HeiseIE class with out passing any argument.
    heise = HeiseIE()


# Generated at 2022-06-26 12:04:06.352951
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	import unittest
	class TestHeiseIE(unittest.TestCase):
		def setUp(self):
			self.ie = HeiseIE()
			self.heise_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
			self.heise_url_ID = '2404147'
			self.heise_url_expected_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
			self.heise_url_expected_date = '20171208'

# Generated at 2022-06-26 12:04:08.015700
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_key() in heise_ie.supported_ie

# Generated at 2022-06-26 12:04:14.811713
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert instance.entry_protocol == 'http'

    assert instance.args['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert instance.args['ie_key'] == 'Heise'
    assert instance.args['video_id'] == '2404147'
    assert instance.entry_protocol == 'http'

# Generated at 2022-06-26 12:04:23.790989
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(HeiseIE):
        IE_NAME = "test_heise"
        _VALID_URL = r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

    ie = TestHeiseIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:04:30.889863
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor)._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE(InfoExtractor)._TESTS == HeiseIE._TESTS
    assert HeiseIE(InfoExtractor).__name__ == 'HeiseIE'
    assert HeiseIE(InfoExtractor)._WORKING == True

# Generated at 2022-06-26 12:04:34.160981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.__name__ == 'heise'

# Generated at 2022-06-26 12:04:38.589636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Make test against a dummy object
    heise_dummy = HeiseIE()
    assert heise_dummy.ie_key() == 'heise'

# Generated at 2022-06-26 12:04:41.117870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:06:22.603036
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = [
        (True,  HeiseIE, 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'),
        (False, HeiseIE, 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'),
    ]

    for case_valid, case_class, case_url in test_cases:
        assert case_class(case_url)._VALID_URL == case_valid

# Generated at 2022-06-26 12:06:26.540005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # N.B.: The following testcase is not fully tested yet
    #       (simply check if the constructor doesn't fail)
    assert HeiseIE()



# Generated at 2022-06-26 12:06:32.265882
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(www\.)?heise\.de/(?P<id>[^/]+)/artikel/(?P<display_id>[^/]+)\.html'
    assert heiseIE._TEST == {
        'url': 'https://www.heise.de/ct/artikel/Entwickler-vor-dem-Kollaps-3909347.html',
        'only_matching': True,
    }

# Generated at 2022-06-26 12:06:41.755212
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    youtube_ie = YoutubeIE()
    kaltura_ie = KalturaIE()
    assert ie
    # Test for member variables
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:43.160610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()

# Generated at 2022-06-26 12:06:52.551020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:59.682123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        obj = HeiseIE(__name__)
        obj.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
        assert False
    except:
        assert True
    try:
        HeiseIE('__name__')
        assert False
    except:
        assert True

# Generated at 2022-06-26 12:07:02.002891
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance


# Generated at 2022-06-26 12:07:04.162993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUCCESS

# Generated at 2022-06-26 12:07:09.603810
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')