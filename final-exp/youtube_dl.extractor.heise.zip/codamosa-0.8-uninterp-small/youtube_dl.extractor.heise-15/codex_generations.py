

# Generated at 2022-06-26 12:00:14.973672
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:18.439348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    x = heise_i_e_0.test(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    )


# Generated at 2022-06-26 12:00:21.254210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # now execute all leftover unit tests
    import sys
    import unittest
    suite = unittest.defaultTestLoader.loadTestsFromModule(
        sys.modules[__name__],
        pattern='(?!test_case_0)^test_case_')
    unittest.TextTestRunner().run(suite())

# Generated at 2022-06-26 12:00:23.298854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:00:24.783330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()


# Generated at 2022-06-26 12:00:32.167487
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()
    heise_i_e_1 = HeiseIE("/data/files/test.json");

    # Test __init__
    assert heise_i_e_1.to_screen, heise_i_e_1.ie_key()
    assert heise_i_e_1.get_info(), heise_i_e_1.ie_key()
    assert heise_i_e_1.get_info(True), heise_i_e_1.ie_key()
    assert heise_i_e_1.get_info(True, ("/data/files/test.json")), heise_i_e_1.ie_key()
    assert heise_i_e_1.process_result(None, True), heise_

# Generated at 2022-06-26 12:00:42.112374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_0 = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    url_1 = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    url_2 = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"

# Generated at 2022-06-26 12:00:54.030047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert re.match(HeiseIE._VALID_URL, "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") != None

# Generated at 2022-06-26 12:00:55.002419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case_0()

# Generated at 2022-06-26 12:00:57.208247
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case_0()

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-26 12:01:08.639310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-26 12:01:10.543141
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:22.949758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:25.690451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:27.792197
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

    

# Generated at 2022-06-26 12:01:29.722573
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()


# Generated at 2022-06-26 12:01:31.629185
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:37.421924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    heise_i_e.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:01:38.458230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0 != None

# Generated at 2022-06-26 12:01:41.611947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-26 12:01:53.418651
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-26 12:01:54.407675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE({})

# Generated at 2022-06-26 12:01:57.036787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    ie = HeiseIE()
    # Currently no public API
    pass

# Generated at 2022-06-26 12:01:58.637527
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    g_instance = HeiseIE()
    assert g_instance.ie_key() == 'heise'

# Generated at 2022-06-26 12:01:59.403387
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:02:05.231831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    config = {}
    ie = HeiseIE(config=config)
    assert ie is not None
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:08.417342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:02:09.187744
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	pass

# Generated at 2022-06-26 12:02:15.595991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    d = HeiseIE(downloader=None)
    assert(d._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:02:23.154361
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-26 12:02:48.939971
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_ie = HeiseIE()
    assert heise_ie.suitable(url)
    assert heise_ie.IE_NAME == 'heise'

# Generated at 2022-06-26 12:02:52.106355
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    # Unit test of class HeiseIE
    assert test._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-26 12:02:54.656525
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor is not None


# Generated at 2022-06-26 12:03:01.599189
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = '1_kkrq94sm'
    heiseIE = HeiseIE()
    assert heiseIE._match_id(url) == video_id
    assert heiseIE._real_initialize() is None
    assert heiseIE._real_extract(url) is not None

# Generated at 2022-06-26 12:03:10.596503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test successful cases
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:03:13.819596
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.ie_key() == 'Heise'
    assert ie.host() == 'heise.de'
    assert ie.base_url() == 'http://www.heise.de'

# Generated at 2022-06-26 12:03:22.884043
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:03:29.446191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE is constructed
    test = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert test

# Generated at 2022-06-26 12:03:36.899007
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:03:37.994928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:04:24.982800
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:04:30.670782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert isinstance(i, InfoExtractor)
    assert isinstance(i, YoutubeIE)
    assert isinstance(i, KalturaIE)
    assert i.ie_key() in types_to_info_extractor.keys()

# Generated at 2022-06-26 12:04:36.762137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Sample unit test for HeiseIE constructor.
    Parameters:
        url                URL of the webpage to be scraped
        ua                 user-agent for the webpage request
    Returns:
        ID of the video.
    """
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
    heise = HeiseIE(url=url, ua=user_agent)

# Generated at 2022-06-26 12:04:39.651231
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'



# Generated at 2022-06-26 12:04:44.082279
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:53.134493
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heiseExtractor = HeiseIE()
    heiseExtractor._HeiseIE__real_extract(url)

# Generated at 2022-06-26 12:05:03.853122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert(ie.getTitle() == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    assert(ie.getId() == '1_kkrq94sm')
    assert(ie.getDescription() == "In der Folge c't uplink 3.3 haben wir ...")

# Generated at 2022-06-26 12:05:04.674992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise' or ie.name == 'heise:video'

# Generated at 2022-06-26 12:05:06.804341
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

test_HeiseIE()

# Generated at 2022-06-26 12:05:18.187054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:06:47.173897
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert(str(heiseIE) == 'class HeiseIE')

# Generated at 2022-06-26 12:06:48.598392
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = HeiseIE._VALID_URL
    e = HeiseIE._TESTS

# Generated at 2022-06-26 12:06:59.822640
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._html_search_regex('<div>foo</div>', '', None, 'foo')
    ie._html_search_meta('', '', None)
    ie._og_search_description('')
    ie._og_search_thumbnail('')
    ie._match_id('')
    ie._search_regex(None, '', '', 'foo')
    ie._download_webpage(None, None, None)
    ie._download_xml(None, None, None)
    ie.playlist_from_matches(None, None, None, None)
    ie._sort_formats(None)

# Generated at 2022-06-26 12:07:04.654629
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'
    assert isinstance(ie.get_testcases(), list)

# Generated at 2022-06-26 12:07:08.329971
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.ie_key() == 'heise'
    assert h.ie_name() == 'heise.de'

# Generated at 2022-06-26 12:07:10.326351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert not HeiseIE.suitable(
        'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-26 12:07:18.819614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Verify that there is a function for each entry in _TESTS
    for entry in HeiseIE._TESTS:
        assert (
            inspect.isfunction(
                getattr(
                    HeiseIE,
                    "test_" +
                    entry["url"].split(
                        "/")[-1].split(
                        ".")[0])))



# Generated at 2022-06-26 12:07:21.398871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    print (IE.IE_NAME)
    print (IE.IE_DESC)
    print (IE._VALID_URL)
    print (IE._TESTS)

# download a Heise video list through its webpage

# Generated at 2022-06-26 12:07:32.334213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:07:42.289257
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') is False
    assert ie