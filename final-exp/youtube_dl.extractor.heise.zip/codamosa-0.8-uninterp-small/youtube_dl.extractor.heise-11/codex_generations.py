

# Generated at 2022-06-26 12:00:19.864047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_i_e.extract(url)

# Generated at 2022-06-26 12:00:27.535534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor does not require any parameters
    # You may provide optional parameters for __init__()
    # e.g.
    heise_i_e_1 = HeiseIE(
        # optional_param_1=None,
        # optional_param_2=None,
        # optional_param_3=None,
        # optional_param_4=None,
    )
    assert heise_i_e_1 is not None


# Generated at 2022-06-26 12:00:29.669454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert callable(HeiseIE)



# Generated at 2022-06-26 12:00:30.541901
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert True

# Generated at 2022-06-26 12:00:31.376666
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-26 12:00:35.777738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.ie_key() == 'heise')
    assert(HeiseIE.ie_key() != 'Heise')
    assert(HeiseIE.ie_key() != 'kaltura')
    assert(HeiseIE.ie_key() != 'Kaltura')
    assert(HeiseIE.ie_key() != 'ELABORATE')


# Generated at 2022-06-26 12:00:37.877146
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE(smuggle_url)


# Generated at 2022-06-26 12:00:41.563389
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e is not None


# Generated at 2022-06-26 12:00:53.759253
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor
    heise_i_e = HeiseIE()
    # Check if attributes of class HeiseIE are 'InfoExtractor'
    assert heise_i_e._VALID_URL == InfoExtractor._VALID_URL
    assert heise_i_e._TESTS == InfoExtractor._TESTS
    assert heise_i_e.IE_NAME == InfoExtractor.IE_NAME
    assert heise_i_e.IE_DESC == InfoExtractor.IE_DESC
    assert heise_i_e.http_headers == InfoExtractor.http_headers
    assert heise_i_e.geo_verification_headers == InfoExtractor.geo_verification_headers
    assert heise_i_e._GEO_BYPASS == InfoExtractor._GEO_

# Generated at 2022-06-26 12:00:55.025330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_0 = HeiseIE()

# Generated at 2022-06-26 12:01:05.028267
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor)


# Generated at 2022-06-26 12:01:09.334372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:13.953786
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS


# Generated at 2022-06-26 12:01:21.536348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)*[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-26 12:01:33.847785
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-26 12:01:36.889321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE().run({
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'skip_download': True,
        'only_matching': True,
    })[0]

# Generated at 2022-06-26 12:01:43.064683
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key()
    assert ie.ie_key() == ie.extractor_key()
    assert isinstance(ie.description, basestring)
    assert ie.extractor_key() == ie.SUFFIX.split('__')[-1]
    assert isinstance(ie.name, basestring)
    assert ie.name
    assert isinstance(ie.supported_url_patterns, (tuple, list, set))
    assert bool(ie.supported_url_patterns)
    assert isinstance(ie.url_result_classes, dict)
    assert ie.url_result_classes

# Generated at 2022-06-26 12:01:45.798702
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == "heise"

# Generated at 2022-06-26 12:01:47.293791
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('Heise')

# Generated at 2022-06-26 12:01:50.145443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:02:08.847209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-26 12:02:19.543331
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ies = [
        HeiseIE.__base__,
        HeiseIE,
    ]
    for ie_cls in ies:
        ie = ie_cls()
        assert ie.extract_id("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html") == "3959893"

# end of test_HeiseIE



# Generated at 2022-06-26 12:02:25.347065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.name ==  "heise.de"

# Generated at 2022-06-26 12:02:26.824129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-26 12:02:30.791144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE().extract(url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert info['id'] == '1_kkrq94sm'

# Generated at 2022-06-26 12:02:41.636778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Initialize HeiseIE with video URL
    heise_ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise_ie.video_id == '1_kkrq94sm'
    assert heise_ie.video_url == 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

    # Check HeiseIE is able to get metadata from video URL
    metadata = heise_ie.extract_metadata()

# Generated at 2022-06-26 12:02:48.509407
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test when not passing optional arguments
    ie.url_result(ie._VALID_URL, ie.ie_key())
    # Test when passing optional arguments
    ie.url_result(ie._VALID_URL, ie.ie_key(), video_id=ie._match_id(ie._VALID_URL))

# Generated at 2022-06-26 12:02:49.476142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-26 12:02:52.934799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None, None)
    assert ie.BASE_URL == 'https://www.heise.de/'

# Generated at 2022-06-26 12:03:00.608158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.url == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    assert ie.video_id == '2403911'

# Generated at 2022-06-26 12:03:43.374969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import parse_media

    # Assert that HeiseIE.parse_media implementation is compatible with its
    # constructor.
    heise_ie = HeiseIE()

    def assert_result_equal(url):
        parsed = parse_media(url)
        parsed_from_constructor = heise_ie.parse_media(url)

        assert parsed == parsed_from_constructor

    # Test if constructor of HeiseIE with an URL of a video
    assert_result_equal(
        'http://www.heise.de/video/artikel/E-Scooter-und-Gear-VR-im-Test-3896942.html')

    # Test if constructor of HeiseIE with an URL of a non-video webpage

# Generated at 2022-06-26 12:03:54.021768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie_test = HeiseIE()

    assert(heiseie_test._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:03:56.049116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-26 12:03:58.729740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == ie.VALID_URL



# Generated at 2022-06-26 12:04:04.240009
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert obj._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-26 12:04:12.771978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance.suitable('https://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert instance.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not instance.suitable('https://www.heise.de/')

# Generated at 2022-06-26 12:04:21.754589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE()
    # example of a valid url
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    # extract the video id
    video_id = m._match_id(url)
    assert video_id == "2404147"

# Generated at 2022-06-26 12:04:27.635253
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:04:29.639366
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)


# Generated at 2022-06-26 12:04:34.120036
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for the constructor of the class HeiseIE
    """
    heise = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert heise is not None


# Generated at 2022-06-26 12:06:12.010675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-26 12:06:22.103925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone', 'md5:c934cbfb326c669c2bcabcbe3d3fcd20')
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    #assert ie._TESTS == [{'url': 'http://www.heise.de/video/artikel/Podcast-c-t-u

# Generated at 2022-06-26 12:06:22.942902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:06:33.132399
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.extract_url("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    heise.extract_url("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-26 12:06:40.084258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # When given an url, the constructor should create an HeiseIE object
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE_object = HeiseIE(url)
    # HeiseIE object created should be an instance of HeiseIE
    assert isinstance(heiseIE_object, HeiseIE)
    # HeiseIE object created should be an instance of InfoExtractor
    assert isinstance(heiseIE_object, InfoExtractor)

# Generated at 2022-06-26 12:06:42.105844
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception:
        pass

# Generated at 2022-06-26 12:06:43.586644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-26 12:06:47.401497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor.list_IE(HeiseIE)
    assert ie.name == 'Heise'
    assert ie.description == 'heise online video'

# Generated at 2022-06-26 12:06:48.727781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj



# Generated at 2022-06-26 12:06:50.379850
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
