

# Generated at 2022-06-26 12:00:18.410454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_i_e = HeiseIE(url)
    assert heise_i_e == heise_i_e_0



# Generated at 2022-06-26 12:00:21.139447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert heise_i_e_0(HeiseIE)

# Generated at 2022-06-26 12:00:22.172832
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()


# Generated at 2022-06-26 12:00:26.967349
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE()
    heiseIE.extract(url)

# Generated at 2022-06-26 12:00:37.226506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Input parameters initialization
    URL: str = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

    # Call to the method
    heise_ie = HeiseIE()

    # Call to _extract_urls
    assert heise_ie._extract_urls(URL) is None



# Generated at 2022-06-26 12:00:38.130580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0()

# Generated at 2022-06-26 12:00:52.225634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '2404147'
    assert heise_i_e._match_id('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == '3814130'

# Generated at 2022-06-26 12:00:53.605577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()



# Generated at 2022-06-26 12:00:56.305984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test: class HeiseIE
    test_case_0()

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-26 12:00:56.930787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-26 12:01:13.846889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') == {'id': '1_59mk80sf', 'ext': 'mp4', 'title': "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten", 'description': 'md5:f50fe044d3371ec73a8f79fcebd74afc', 'timestamp': 1517567237, 'upload_date': '20180202'}

# Generated at 2022-06-26 12:01:24.014760
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:29.912433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..extractor import Extractor
    extractor = Extractor()
    for ie in extractor.get_info_extractors():
        if ie.ie_key() == 'heise':
            extractor.remove_ie(ie)
            break
    heise_ie = HeiseIE()
    extractor.add_ie(heise_ie)

# Generated at 2022-06-26 12:01:32.383979
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Just use the default constructor of HeiseIE
    HeiseIE()
    return "OK"

# Generated at 2022-06-26 12:01:42.376566
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:01:43.424363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(None)
    obj._valid_url()
    obj._real_extract()

# Generated at 2022-06-26 12:01:50.751141
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_uri = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"

    test_object = HeiseIE( test_uri )
    assert( test_object._VALID_URL != None )
    assert( test_object._valid_url( test_uri, test_object._VALID_URL ) )


# Generated at 2022-06-26 12:01:51.692244
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor())

# Generated at 2022-06-26 12:01:54.082082
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert isinstance(IE, HeiseIE)


# Generated at 2022-06-26 12:01:55.863486
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('')

# Generated at 2022-06-26 12:02:20.537950
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    hie = HeiseIE()
    assert hie._match_id(url) == '3959893'
    assert hie._real_extract(url)['id'] == '3959893'

# Generated at 2022-06-26 12:02:28.535064
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_ie = HeiseIE(test_url)
    print("heise_ie constructed with url: %s." % heise_ie._url)

# Generated at 2022-06-26 12:02:31.226003
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-26 12:02:39.721440
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test empty input
    assert(ie._match_id(None) == None)
    # Test invalid input
    assert(ie._match_id('invalid URL') == None)
    # Test valid input
    assert(ie._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == "2404147")

# Generated at 2022-06-26 12:02:42.158909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-26 12:02:53.633478
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert not ie.suitable('https://www.heise.de/autos/')

# Generated at 2022-06-26 12:02:55.083766
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE(None)
    assert inst

# Generated at 2022-06-26 12:03:03.547445
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.__name__ == 'HeiseIE')
    assert(HeiseIE._VALID_URL.search('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html').groups() == ('2404147',))
    assert(HeiseIE._TESTS[0]['approx_video_id'] == '1_kkrq94sm')
    assert(HeiseIE._TESTS[-1]['approx_video_id'] == '1_59mk80sf')
    assert(HeiseIE._TESTS[2]['approx_video_id'] == '1_ntrmio2s')

# Generated at 2022-06-26 12:03:13.846814
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('http://heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-26 12:03:18.921688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE, InfoExtractor)
    assert isinstance(HeiseIE(None), HeiseIE)
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Unit tests for methods of class HeiseIE

# Generated at 2022-06-26 12:03:55.842753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:04:03.232871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert heiseie.url == "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"

# Generated at 2022-06-26 12:04:11.536879
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:04:16.195253
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    we_have_a_constructor = hasattr(HeiseIE, '__init__')
    assert we_have_a_constructor
    assert callable(getattr(HeiseIE, '__init__'))

# Generated at 2022-06-26 12:04:26.029862
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:26.867952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:04:35.774448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test url
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"

    # Test instantiation of class
    heise_ie = HeiseIE()

    # Test _VALID_URL
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

    # Test _real_extract() method
    info_dict = heise_ie._real_extract(url)
    assert info_dict['id'] == '1_ntrmio2s'
    assert info_dict

# Generated at 2022-06-26 12:04:46.619259
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Not-well-formed data for testing method _real_extract
    web_page_data = r"""
<html>
<head>
<title>The title</title>
</head>
<body>
<div class="videoplayerjw" data-player="ct-videoplayer-2"
    data-title="Title" data-container="9751" data-sequenz="475614">
    <div class="videoplayerjw_container_element"></div>
</div>
</body>
</html>"""


# Generated at 2022-06-26 12:04:54.755107
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert e._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:56.313938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert('HeiseIE' in globals())

# Generated at 2022-06-26 12:06:42.885698
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Download test video from c't Magazine
    test_url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    
    # Check if url is valid
    valid_url = HeiseIE._VALID_URL
    def check_valid_url(url):
        return re.match(r'(?i)^%s$' % valid_url, url)

    assert check_valid_url(test_url) is not None

    # Create instance of class with arguments
    heise_ie = HeiseIE(test_url)

    # Check if instance is created
    test_instance_creation = heise_ie.instance_created

    assert test_instance_creation == True



# Generated at 2022-06-26 12:06:52.469816
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Missing tests
    IE = HeiseIE()
    # assert IE.ie_key() == 'Heise'
    # This doesn't work, as the site returns 404 for this URL
    # assert IE._extract_url('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == 'kaltura:2238431:1_kkrq94sm'

# Generated at 2022-06-26 12:07:02.190921
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    TEMPLATE = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-26 12:07:03.814731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None, None)

# Generated at 2022-06-26 12:07:13.191595
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    print(ie.extract()['title'])
# http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
# https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html
# https://www.heise.de/ct/artikel/c-t-

# Generated at 2022-06-26 12:07:20.830618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert info_extractor.suitable("http://www.heise.de/ct/artikel/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html")

# Generated at 2022-06-26 12:07:32.135883
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_object = HeiseIE()
    assert test_object.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert test_object.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert not test_object.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-26 12:07:41.421879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE
    heise = HeiseIE()
    heiseIE = heise._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    title = heiseIE['title']
    # Assert if title of the video is equal to the expected title
    assert title == 'c\'t uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten'


# Generated at 2022-06-26 12:07:46.925526
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') is not None

# Generated at 2022-06-26 12:07:48.265319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor works
    ie = HeiseIE()