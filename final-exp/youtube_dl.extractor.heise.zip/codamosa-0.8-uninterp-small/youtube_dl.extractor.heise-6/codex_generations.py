

# Generated at 2022-06-26 12:00:16.754038
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert(heise is not None)

test_case_0()

# Generated at 2022-06-26 12:00:29.262970
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"
    assert HeiseIE._TESTS[0]["url"] == url
    assert HeiseIE._TESTS[0]["info_dict"]["id"] == "1_kkrq94sm"
    assert HeiseIE._TESTS[0]["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-26 12:00:39.867132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE,'_VALID_URL'), "No attribute '_VALID_URL' in HeiseIE"
    assert hasattr(HeiseIE,'_TESTS'), "No attribute '_TESTS' in HeiseIE"
    assert hasattr(HeiseIE,'_download_webpage'), "No attribute '_download_webpage' in HeiseIE"
    assert hasattr(HeiseIE,'_match_id'), "No attribute '_match_id' in HeiseIE"
    assert hasattr(HeiseIE,'_real_extract'), "No attribute '_real_extract' in HeiseIE"

# Unit tests for the video URL matching

# Generated at 2022-06-26 12:00:52.898867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:00:55.071249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    doc = test_case_0()

    assert isinstance(doc, HeiseIE)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 12:00:55.814003
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 1==1

# Generated at 2022-06-26 12:00:59.246580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.name == 'heise')
    assert(HeiseIE.description == 'heise online')
    assert(HeiseIE.__name__ == 'HeiseIE')

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-26 12:01:03.069527
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        heise_i_e_0 = HeiseIE()
        assert heise_i_e_0
    except Exception:
        assert False


# Generated at 2022-06-26 12:01:05.773274
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE(KalturaIE, YoutubeIE)


# Generated at 2022-06-26 12:01:06.402465
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()


# Generated at 2022-06-26 12:01:24.249809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    # tests for validate_url
    inst.validate_url('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    inst.validate_url('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    inst.validate_url('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    # tests for _real_extract()

# Generated at 2022-06-26 12:01:24.693538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-26 12:01:35.337841
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:01:40.040622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    assert ie._match_id(url) is not None

# Generated at 2022-06-26 12:01:52.220601
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert url.startswith('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert 'http' in url
    assert '://' in url
    assert 'www.heise.de' in url
    assert '.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' in url

# Generated at 2022-06-26 12:01:54.628272
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        HeiseIE(InfoExtractor())
    except Exception:
        assert False, 'Unit test for HeiseIE.__init__() failed!'


# Generated at 2022-06-26 12:02:07.479012
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ajax_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})


    #expected_results

# Generated at 2022-06-26 12:02:20.539332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    heiseIE = ie._get_info_extractor(url="http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    #For multiple inheritance, the method of the first class that appears in the list will be invoked
    #The first class of this example is "InfoExtractor"

# Generated at 2022-06-26 12:02:28.216470
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    assert ie.__class__ == HeiseIE

# Generated at 2022-06-26 12:02:29.618569
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-26 12:02:54.810379
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from unit_test_base import TestBase
    from youtube_dl.utils import merge_dicts
    from youtube_dl.extractor import (
        HeiseIE,
    )

    class Mock_YoutubeIE():
        def __init__(self, *args, **kwargs):
            pass
        def extract(self, *args, **kwargs):
            return "YoutubeIE's extract method was called."

    class Mock_YoutubeIE_playlist_from_matches(*Mock_YoutubeIE.__init__.__args__, **Mock_YoutubeIE.__init__.__kwargs__):
        def extract(self, *args, **kwargs):
            return "YoutubeIE_playlist_from_matches's extract method was called."


# Generated at 2022-06-26 12:02:55.649207
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:03:00.718314
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url='https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    res = HeiseIE()(url)
    assert res["id"]=="1_ntrmio2s"

# Generated at 2022-06-26 12:03:13.031004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS

# Generated at 2022-06-26 12:03:18.696137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test = HeiseIE.__dict__['suitable']("", url)
    assert test

# Generated at 2022-06-26 12:03:24.671228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-26 12:03:27.852871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # All of them must return an instance of class HeiseIE
    HeiseIE(InfoExtractor())._real_initialize()

# Generated at 2022-06-26 12:03:28.715433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:03:36.289680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert h.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert h.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:03:40.835861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:04:16.585928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    k = HeiseIE()


# Generated at 2022-06-26 12:04:22.166817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a=HeiseIE()
    assert len(a._TESTS)>0
    assert a._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:34.058327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.SUFFIX == '/video/artikel/'
    assert ie.IE_NAME == 'heise'
    assert ie.HOST == 'www.heise.de'
    assert ie.BASE_URL == 'http://www.heise.de'
    assert ie.RE_VIDEO_ID == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:04:43.906743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests loading a video, which is not working right now due to a bug in jwplayer5
    # heise_ie = HeiseIE(HeiseIE.ie_key())
    # info_dict = heise_ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # assert info_dict['id'] == '1_kkrq94sm'
    pass

# Generated at 2022-06-26 12:04:56.641798
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.name == 'heise.de'
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:05:06.275482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_class = HeiseIE
    # Instantiation of the class to be tested
    instance = test_class()
    # sample url for testing
    sample_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # check if the instantiation is working
    assert isinstance(instance, HeiseIE)
    # check if get_id function is working properly
    assert instance._match_id(sample_url) == "2404147"

# Generated at 2022-06-26 12:05:07.775043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL

# Generated at 2022-06-26 12:05:11.365067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    # TODO: Add assert here

# Generated at 2022-06-26 12:05:19.583854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class SubInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            pass

    # c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone
    hie = HeiseIE()
    assert hie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"
    assert hie.ie_key() == 'heise'
    assert hie.suitable(SubInfoExtractor(), 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert hie._match_id

# Generated at 2022-06-26 12:05:21.922005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUITABLE_GENERAL
    assert ie.IE_NAME

# Generated at 2022-06-26 12:06:44.301146
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()

# Generated at 2022-06-26 12:06:46.891358
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    # Just to get rid of error messages
    _ = heise.ie_key()

# Generated at 2022-06-26 12:06:49.075397
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test the class constructor HeiseIE
    """
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-26 12:07:00.949867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    # Test HeiseIE.
    assert hie.ie_key() == 'heise'
    assert hie.ie_name() == 'heise.de'

# Generated at 2022-06-26 12:07:08.014549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    inst.suitable('http://www.heise.de/ct/artikel/c-t-uplink-48-Tastaturen-Keylogger-Kryptowaehrungen-und-Bibliotheks-Apps-3066875.html')

# Generated at 2022-06-26 12:07:10.898837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

    # Unit test for instance of class HeiseIE

# Generated at 2022-06-26 12:07:14.259406
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-26 12:07:15.684682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    assert a

# Generated at 2022-06-26 12:07:18.232617
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	from . import extractor
	extractor.get_info_extractor(HeiseIE.ie_key())

# Generated at 2022-06-26 12:07:24.095743
# Unit test for constructor of class HeiseIE