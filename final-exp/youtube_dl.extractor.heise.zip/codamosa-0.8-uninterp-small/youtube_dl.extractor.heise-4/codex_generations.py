

# Generated at 2022-06-26 12:00:15.090390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert issubclass(HeiseIE, InfoExtractor)


# Generated at 2022-06-26 12:00:21.735338
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    expected_result = {
        '_type': 'url_transparent',
        'id': '1_kkrq94sm',
        'url': 'kaltura:2238431:1_kkrq94sm',
        'title': 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
        'ie_key': 'Kaltura'
    }

    heise_i_e_0 = HeiseIE()

# Generated at 2022-06-26 12:00:22.821497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()

# Generated at 2022-06-26 12:00:30.966075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE()
    heise_i_e_1.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    heise_i_e_1.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:00:41.652725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_data_0 = [{
        'url': 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html',
        'only_matching': True}]
    heise_i_e = HeiseIE()
    for unit_test_data in unit_test_data_0:
        assert heise_i_e._valid_url(unit_test_data['url'], unit_test_data['only_matching']) == True

# Generated at 2022-06-26 12:00:53.785579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e.ie_key() in [u'heise', u'kaltura'], "ie_key not found"
    assert heise_i_e._VALID_URL == u'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html', "_VALID_URL not found"

# Generated at 2022-06-26 12:01:01.281497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Argument url
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    instance = heise_i_e_0._real_extract(url=url)
    assert instance['id'] == '1_kkrq94sm', '_test_HeiseIE failed'
    assert instance['ext'] == 'mp4', '_test_HeiseIE failed'
    assert instance['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone", '_test_HeiseIE failed'
    assert instance['timestamp'] == 1512734959, '_test_HeiseIE failed'
    assert instance

# Generated at 2022-06-26 12:01:07.745941
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test type of `heise_i_e` object
    assert isinstance(heise_i_e_0, HeiseIE)

    # Test type of arguments of `test_case_0` function
    assert isinstance(heise_i_e_0, HeiseIE)


test_case_0()

# Generated at 2022-06-26 12:01:08.134432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:01:09.015251
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    

# Generated at 2022-06-26 12:01:18.065881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-26 12:01:25.514288
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:27.566955
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_raises(AttributeError, heise_i_e_0.__init__)

# Generated at 2022-06-26 12:01:29.112921
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert test_case_0() == True

# Generated at 2022-06-26 12:01:31.560921
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e_1 = HeiseIE(googletag=None)


# Generated at 2022-06-26 12:01:42.010758
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-26 12:01:43.753979
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE)


# Generated at 2022-06-26 12:01:50.934967
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_i_e = HeiseIE()
    assert heise_i_e.ie_key() == 'Heise'
    assert heise_i_e.ie_key() == HeiseIE.ie_key()
    assert heise_i_e.name == 'heise'
    assert heise_i_e.name == HeiseIE.ie_key()
    assert heise_i_e.description == 'heise.de'



# Generated at 2022-06-26 12:02:02.472505
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = '1_kkrq94sm'
    webpage = '''
    <div class="video_player" data-container="293" data-sequenz="5013" data-title="Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone" data-videoplayerid="0" data-videoplayertype="kaltura"></div>
    '''
    heise_i_e = HeiseIE()
    heise_i_e._download_webpage = lambda *args, **kwargs: webpage
    assert heise_

# Generated at 2022-06-26 12:02:11.193208
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == True
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-26 12:02:22.328658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None


# Generated at 2022-06-26 12:02:32.941735
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert heise._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:02:33.368273
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:02:39.397926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-26 12:02:45.933448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 'Heise' in HeiseIE.__name__
    assert 'Heise' in HeiseIE.__doc__
    extractor = HeiseIE()
    assert 'from' in extractor.__doc__
    assert 'heise' in extractor._VALID_URL

# Generated at 2022-06-26 12:02:48.499023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # expected is True because the link is valid and the function returns true if the link is valid
    expected = True
    # checks if the constructor returns True because we expect the link to be valid
    assert expected == ie._match_id(ie.url)

# Generated at 2022-06-26 12:02:49.756648
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie != None



# Generated at 2022-06-26 12:02:51.196000
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-26 12:02:53.368096
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('dummy')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:02:59.020268
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit = HeiseIE()
    assert unit._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert unit.ie_key() == 'heise'


# Generated at 2022-06-26 12:03:17.339621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	HEISE_IE = HeiseIE()
	assert HEISE_IE
	assert HEISE_IE._VALID_URL is not None
	assert HEISE_IE._TESTS is not None


# Generated at 2022-06-26 12:03:21.421128
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import re
    from .common import InfoExtractor
    from .kaltura import KalturaIE

    class MockInfoExtractor(InfoExtractor):
        pass

    # single youtube video
    youtube_url = 'ytsingle'
    video_id = 'ytid'
    video_title = 'yttitle'
    test = HeiseIE._real_extract(HeiseIE(), youtube_url)
    expected = {
        'id': video_id,
        'title': video_title,
        '_type': 'url_transparent',
        'ie_key': YoutubeIE.ie_key(),
        'url': youtube_url
    }
    assert(expected == test)

    # youtube playlist
    youtube_url = 'ytplaylist'
    video_id = 'ytid'

# Generated at 2022-06-26 12:03:23.739892
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-26 12:03:26.137878
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE();
    assert obj.ie_key() == 'heise'

# Generated at 2022-06-26 12:03:27.002206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-26 12:03:35.749085
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten
    # https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    ie = HeiseIE(url)

# Generated at 2022-06-26 12:03:40.117947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'Heise'
    assert heiseIE.ie_codec() == 'heise'
    assert heiseIE.get_host_and_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == ('www.heise.de', 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147')

# Generated at 2022-06-26 12:03:42.147186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE(None)
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-26 12:03:53.919872
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie.set_downloader(object())
    ie.download = object()
    ie._make_request = object()

    # tests for static functions
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

    # tests for constructor
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie.IE_DESC == 'Heise'

    # tests for _real_extract
    assert ie

# Generated at 2022-06-26 12:03:55.905790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # No exception should be raised
    HeiseIE()

# Generated at 2022-06-26 12:04:33.349295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE()
    ie.extract(url)
    assert ie



# Generated at 2022-06-26 12:04:35.429492
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj != None


# Generated at 2022-06-26 12:04:46.506238
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print ("Running unit test for class HeiseIE")

    video_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = '1_kkrq94sm'
    expected_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    expected_thumb = 're:http://cdn.heise.de/.*'
    expected_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    expected_upload_date = '20171208'
    expected_duration = 7


# Generated at 2022-06-26 12:04:53.587422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()
    _VALID_URL = r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert extractor._VALID_URL == _VALID_URL

# Generated at 2022-06-26 12:04:54.657613
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-26 12:05:06.992377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-26 12:05:08.121758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-26 12:05:14.001876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract(url='https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-26 12:05:20.408943
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    # Basic test to see whether __init__ works
    assert (HeiseIE() is not None)

    # Basic test to see whether __init__ works for a known input URL
    assert (HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None)

    # Basic test to see whether __init__ works for a non existing URL
    assert (HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-NOT-EXISTING.html') is not None)

    # Basic test

# Generated at 2022-06-26 12:05:29.386865
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj.ie_key == 'heise'
    assert test_obj.ie_name == 'heise'
    assert test_obj.access_token == None
    assert test_obj.secret_token == None
    assert test_obj.host == 'www.heise.de'
    assert test_obj.SUBMIT_LOGIN_FORM == False
    assert test_obj.AJAX_LOGIN == False
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == None
    assert test_obj.KALTURA_ACCOUNT_ID == None
    assert test_obj.KALTURA_UICONF_ID == None
    assert test_obj.KALTURA_PLAYLIST_ID == None
    assert test_obj.KALTURA_GENER

# Generated at 2022-06-26 12:06:51.531299
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _test_instance = HeiseIE()
    assert _test_instance is not None

# Generated at 2022-06-26 12:06:55.294903
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    object = HeiseIE()
    object_rt = HeiseIE.__name__
    expected_rt = 'HeiseIE'
    assert object_rt == expected_rt

# Generated at 2022-06-26 12:07:01.286767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE._VALID_URL == HeiseIE._TESTS[0]['url']
    assert HeiseIE._VALID_URL == HeiseIE(url)._VALID_URL
    assert HeiseIE._downloader == None
    assert HeiseIE._WORKING == True

# Generated at 2022-06-26 12:07:02.622183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-26 12:07:12.803826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-26 12:07:17.075066
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE("HeiseIE")
    # Test if class is a subclass of the correct class
    assert isinstance(heise_ie, InfoExtractor)


# Generated at 2022-06-26 12:07:20.770762
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie.NO_URL_FOUND == 'NO_URL_FOUND'

# Generated at 2022-06-26 12:07:24.058518
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    heise_ie = HeiseIE()



# Generated at 2022-06-26 12:07:25.961459
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst.ie_key() == 'Heise'

# Generated at 2022-06-26 12:07:32.290957
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert not heise.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
