

# Generated at 2022-06-24 12:26:41.827290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of HeiseIE does not throw an exception
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:26:45.954213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'Heise'
    assert ie.server_url() == 'www.heise.de'

# Generated at 2022-06-24 12:26:47.960709
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-24 12:26:49.550195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    
    ydl = YoutubeDL({})
    
    # id doesn't matter, constructor is not called with an url
    heise = HeiseIE(ydl)
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-24 12:26:50.797991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:26:59.599181
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_video_id = '1_kkrq94sm'
    test_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    test_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    test_timestamp = 1512734959
    test_upload_date = '20171208'


# Generated at 2022-06-24 12:27:09.844737
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    e = class_(123)
    assert e.video_id == 123
    assert class_.suitable(123)

# Generated at 2022-06-24 12:27:10.667694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:27:12.379707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test for constructor of class HeiseIE
    constructor_test_helper(HeiseIE)

# Generated at 2022-06-24 12:27:21.079776
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert not HeiseIE.suitable('https://www.heise.de/ct-artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert HeiseIE.suitable('https://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:27:27.868262
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_html_search_regex')
    assert hasattr(ie, '_search_regex')

# Generated at 2022-06-24 12:27:28.428993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:27:38.306621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == True

# Generated at 2022-06-24 12:27:39.268559
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:43.991011
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:27:45.272858
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:52.154370
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_info_dict = HeiseIE()._real_extract(url)
    assert test_info_dict['id'] == '1_kkrq94sm'
    assert test_info_dict['ext'] == 'mp4'
    assert test_info_dict['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert test_info_dict['upload_date'] == '20171208'

# Generated at 2022-06-24 12:27:52.544557
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:56.868411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    heiseie._real_extract(url)

# Generated at 2022-06-24 12:28:03.549811
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

    HeiseIE().suitable(url)

    #run test
    test_dict = HeiseIE()._real_extract(url)
    assert test_dict['id'] == u'1_kkrq94sm'

# Generated at 2022-06-24 12:28:05.581716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:15.839872
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.title() == 'heise'
    assert ie.description() == 'c\'t, iX, Technology Review, Mac & i, Make, Telepolis, Telepolis HD'
    assert ie.url_re.match('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') is not None
    assert ie.url_re.match('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') is not None

# Generated at 2022-06-24 12:28:17.555800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert test.NAME == "heise"
    assert test._VALID_URL

# Generated at 2022-06-24 12:28:18.554229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:28:20.399485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# test HeiseIE instance
	assert HeiseIE.ie_key() == "heise"



# Generated at 2022-06-24 12:28:27.348649
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.downloader = None
    ie.http = None
    ie.extractor = None
    ie.params = {}
    ie.cache = None
    ie.cache_path = ""
    ie.opener = None
    ie._player_defaults = {}
    ie.player = None

    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:28.720749
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:28:37.982240
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    heise = HeiseIE()
    heise._download_webpage = lambda x: 'huhu'
    kaltura_url = 'kaltura:2238431:1_bb8pknnw'

    # test Kaltura
    assert(heise._extract_kaltura(kaltura_url) ==
           {'_type': 'url_transparent',
            'ie_key': 'Kaltura',
            'url': 'kaltura:2238431:1_bb8pknnw',
            'title': 'huhu',
            'description': 'huhu'})

    # test YouTube

# Generated at 2022-06-24 12:28:41.098260
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Construct an instance of HeiseIE
    heise_ie = HeiseIE()

    # If the calling application provides command line arguments
    # then parse them
    if __name__ == "__main__":
        import sys
        heise_ie.main(sys.argv[1:])

# Generated at 2022-06-24 12:28:47.804933
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:28:58.796144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE("heise.de", "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"))
    assert(HeiseIE("heise.de", "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"))

# Generated at 2022-06-24 12:28:59.740394
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:29:00.395123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:05.058481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # For a test of real_extract() method, see
    # tests/test_extractor.py::TestHeisetvIE::test_real_extract()
    assert ie._call_exists('test_HeiseIE_run')

# Generated at 2022-06-24 12:29:08.792895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE(None)
    assert m._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:09.428190
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:29:21.120984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Tests for HeiseIE constructor"""
    # HeiseIE(FileDownloader)
    file_downloader = {
    }

    # HeiseIE(FileDownloader, compat_str)
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heiseie = HeiseIE(file_downloader, url)
    assert heiseie.suitable(url)
    assert heiseie.compat_str is not None

    # HeiseIE(FileDownloader, compat_str)
    heiseie = HeiseIE(file_downloader, 'test')

# Generated at 2022-06-24 12:29:22.564319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj is not None

# Generated at 2022-06-24 12:29:33.109022
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # run unit test
    # get youtube video id
    id = HeiseIE._extract_video_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # get kaltura video id

# Generated at 2022-06-24 12:29:35.775760
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("test if constructor of class HeiseIE is working in constructor")
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-24 12:29:38.177620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Invoke HeiseIE and test its constructor.
    obj = HeiseIE()


# Generated at 2022-06-24 12:29:39.602707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL

# Generated at 2022-06-24 12:29:48.724596
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert video.url == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    assert video.title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    assert video.description == 'md5:47e8ffb6c46d85c92c310a512d6db271'
    assert video.timestamp == 15124

# Generated at 2022-06-24 12:29:52.932198
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:02.603325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() in ie.source_key()
    assert ie.source_key() == 'Heise'
    assert ie.ie_key() in ie.extractor_key()
    assert ie.extractor_key() == 'HeiseIE'
    assert ie.extractor_key() in ie.downloader_key()
    assert ie.downloader_key() == 'Heise'
    assert ie.source_key() in ie.test_cases()
    assert ie.downloader_key() in ie.test_cases()
    assert ie.extractor_key() in ie.test_cases()
    assert ie.ie_key() in ie.test_cases()
    assert ie.name() == 'Heise'

# Generated at 2022-06-24 12:30:04.896892
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.__class__.__name__ == "HeiseIE"


# Unit test to judge whether the download of the video file is successful

# Generated at 2022-06-24 12:30:07.649226
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HEISE_VALID_URL
    assert ie._TESTS == HEISE_TESTS

# Generated at 2022-06-24 12:30:08.692372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('heise')

# Generated at 2022-06-24 12:30:18.729688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE()._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert result["id"] == "1_kkrq94sm"
    assert len(result["formats"]) > 0
    assert result["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:30:19.405507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:30:28.502197
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'HeiseIE'
    assert ie.IE_DESC == 'Heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Just test first test case
    TESTS = [HeiseIE._TESTS[0]]
    for test in TESTS:
        ie.params = {}
        url, options, expected_results = test
        ie.extract(url, options)
        # make sure there are no expected results specified (test IE)
        assert expected_results == None


# Generated at 2022-06-24 12:30:31.833001
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.__class__ == HeiseIE


# Generated at 2022-06-24 12:30:42.537457
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:30:45.152230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE instantiates HeiseIE(InfoExtractor)
    heise_ie = HeiseIE("HeiseIE(InfoExtractor)")
    assert issubclass(HeiseIE, InfoExtractor)

# Generated at 2022-06-24 12:30:48.702442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    # Assert the test cases from the class exist
    for test in ie._TESTS:
        assert test['url']
        assert test['info_dict']
        assert 'url' in test['info_dict']
        assert 'title' in test['info_dict']

# Generated at 2022-06-24 12:30:49.458027
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()

# Generated at 2022-06-24 12:30:50.567789
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.get_video_url()

# Generated at 2022-06-24 12:31:01.776200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=W0212
    for i in HeiseIE._downloader.info_extractors:
        if i.IE_NAME == HeiseIE.ie_key():
            heise_ie = i
            break
    else:
        return
    obj = heise_ie(
        # Unit test for the constructor of class HeiseIE.
        # it tests whether the passed url matches or not
        {'extractor': 'HeiseIE',
         'url': "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"})

# Generated at 2022-06-24 12:31:08.200254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testObject = HeiseIE('Heise')
    assert (testObject._VALID_URL ==
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert (testObject.ie_key() == 'Heise')
    assert (testObject._NETRC_MACHINE == 'heise')



# Generated at 2022-06-24 12:31:15.776994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor"""
    heise_ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise_ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert heise_ie.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert heise_ie.uploader_id == None
    assert heise_ie.uploader == None
    assert heise_ie.duration == None

    # test_HeiseIE2()
    heise_ie2 = HeiseIE

# Generated at 2022-06-24 12:31:24.989936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') is True

# Generated at 2022-06-24 12:31:25.802193
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    theIE = HeiseIE()

# Generated at 2022-06-24 12:31:28.272849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ieHeise = HeiseIE()
    assert ieHeise.ie_key() == 'heise'
    assert ieHeise.IE_NAME == 'heise.de'
    assert ieHeise.IE_DESC == 'heise online'

# Generated at 2022-06-24 12:31:33.973228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE with invalid package name
    heiseie = HeiseIE('heise_name')
    assert heiseie._VALID_URL is None
    # HeiseIE with valid package name
    heiseie = HeiseIE('heise')
    assert heiseie._VALID_URL is not None
    # HeiseIE with valid url
    url ='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    assert heiseie.suitable(url)

# Generated at 2022-06-24 12:31:38.201142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    # Issue #876: HeiseIE should not output an error message
    # when the wrong URL is given.
    #
    # Before changing HeiseIE, it was not possible for an instance of HeiseIE
    # to know whether it was created using the right URL.
    # This is a test for #876.
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:49.635026
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:00.615050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # IE for testing
    ie = HeiseIE()

    # some Youtube video
    url = 'https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert ie._match_id(url) == '3814130'
    assert ie._match_id('https://www.heise.de/developer/artikel/IVI-3-0-Bringt-Das-Browser-Fenster-Nach-Unter-Die-Haube-3812268.html') == '3812268'

# Generated at 2022-06-24 12:32:01.896215
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUCCESS == True

# Generated at 2022-06-24 12:32:04.995528
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-24 12:32:07.940928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:11.333120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL'), 'HeiseIE instance has no attribute "_VALID_URL"'
    assert hasattr(ie, '_TESTS'), 'HeiseIE instance has no attribute "_TESTS"'

# Generated at 2022-06-24 12:32:14.311721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:15.193637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:32:21.633079
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:33.614978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:34.528354
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-24 12:32:43.545817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert(h.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'))
    assert(h.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    assert(h.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'))

# Generated at 2022-06-24 12:32:54.268135
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # example based on https://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom
    # this is an example of a HeiseIE video
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True

    # this is another url of the same video

# Generated at 2022-06-24 12:32:55.223201
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:04.540837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test the constructor HeiseIE
    """
    if __name__ == '__main__':
        test_url = ('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
        test_url_2 = ('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:33:15.595017
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:18.492778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:20.086495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(None)
    assert isinstance(heise, HeiseIE)

# Generated at 2022-06-24 12:33:21.304764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.heise_id == None

# Generated at 2022-06-24 12:33:23.590048
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == "heise"

# Generated at 2022-06-24 12:33:25.150347
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE();
    assert heise_ie;

# Generated at 2022-06-24 12:33:33.737086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert ie._TES

# Generated at 2022-06-24 12:33:45.862976
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    ex = HeiseIE()

# Generated at 2022-06-24 12:33:50.473834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inf = HeiseIE.HeiseIE(None, None)
    assert inf.__class__.__name__ == "HeiseIE"
    assert inf.ie_key() == "Heise"
    assert inf.ie_key() != "heise"


# Generated at 2022-06-24 12:33:51.800381
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie != None

# Generated at 2022-06-24 12:33:52.266020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # No error should have been raised
    HeiseIE()

# Generated at 2022-06-24 12:34:01.439534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    attribs = {
        'class': 'videoplayerjw',
        'data-container': '4681',
        'data-sequenz': '3109',
        'data-title': 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone',
        'data-videoid': '1_kkrq94sm',
    }
    div_video_player = '<div {0}></div>'.format(
        ' '.join(['{0}="{1}"'.format(k, v)
                  for k, v in attribs.items()]))
    webpage = """
<html>
<body>
{div_video_player}
</body>
</html>
""".format(div_video_player=div_video_player)


# Generated at 2022-06-24 12:34:08.652157
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        input_url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
        heise_info_extractor = HeiseIE()
        if heise_info_extractor is not None:
            print("Unit test for constructor of class HeiseIE :FAILED")
        else:
            print("Unit test for constructor of class HeiseIE :SUCCESS")
    except Exception as e:
        print("Unit test for constructor of class HeiseIE :FAILED")


# Generated at 2022-06-24 12:34:13.171455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    obj = ie('url', 'md5', 'title', 'description')
    assert obj['_type'] == 'url_transparent'
    assert obj['url'] == 'url'
    assert obj['md5'] == 'md5'
    assert obj['title'] == 'title'
    assert obj['description'] == 'description'

# Generated at 2022-06-24 12:34:13.789776
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:16.680057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = list()
    test_cases.append((None, 1))
    test_cases.append((1, 1))
    for test_case,expect in test_cases:
        ret = HeiseIE(test_case)
        print('ret: %s' % ret)

# Generated at 2022-06-24 12:34:24.289722
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert_equal(extractor.get_url(), "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert_equal(extractor.get_id(), "1_kkrq94sm")


################################################################################
# Test HeiseIE.py
from numpy.testing import assert_equal
from numpy.testing import assert_raises
from numpy.testing import assert_
from numpy.testing import assert_array

# Generated at 2022-06-24 12:34:35.061211
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE._VALID_URL == HeiseIE._match_url(url)[0]
    assert HeiseIE._TEST_URL == None
    assert HeiseIE._TEST[0]['url'] == HeiseIE._TESTS[0]['url']
    assert HeiseIE._TEST[0]['md5'] == HeiseIE._TESTS[0]['md5']
    assert HeiseIE._TEST_TEMPLATE_URL == None
    assert HeiseIE._TESTS_TEMPLATE_URL == None
    assert HeiseIE._TESTS

# Generated at 2022-06-24 12:34:38.790468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert ie.get_IE() == "Heise"

# Generated at 2022-06-24 12:34:51.156653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

# Generated at 2022-06-24 12:34:52.804421
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _test_instances_args

    _test_instances_args(HeiseIE)

# Generated at 2022-06-24 12:34:54.733151
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    assert(HeiseIE.ie_key() == 'heise')
    assert(HeiseIE.ie_key() == 'heise')

# Generated at 2022-06-24 12:35:03.676008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:35:15.194220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import shutil
    import os
    # create class instance
    HeiseIE = HeiseIE()
    # test result of class method _match_id
    match = HeiseIE._match_id('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert isinstance(match, unicode)
    assert match == '3214137'
    # test result of class method _real_extract
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:35:15.790084
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-24 12:35:24.016152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'), dict)
    assert isinstance(ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'), dict)

# Generated at 2022-06-24 12:35:28.891599
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE()
    _ = heise_ie.extract(url)

# Generated at 2022-06-24 12:35:40.257109
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .unit.test_downloader import FakeYDL
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from .common import InfoExtractor
    e = InfoExtractor(FakeYDL(), {u'extractor': u'Heise', u'url': u'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'})
    assert e._get_info_extractor(e._VALID_URL) is e

# Generated at 2022-06-24 12:35:41.112208
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL is not None

# Generated at 2022-06-24 12:35:42.063794
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:42.745864
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:49.693512
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie and isinstance(ie, HeiseIE)
    assert ie.ie_key() == 'Heise'
    assert ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:35:52.479618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE({'extractor': 'heise'}, None, None)
    assert heise_ie.get_kaltura_id(None, None) is None

# Generated at 2022-06-24 12:35:53.755422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:35:57.930726
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == 'heise'
    assert heiseie.ie_name() == 'heise'
    assert heiseie.ie_version() == 1

# Generated at 2022-06-24 12:36:02.297598
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    yield (lambda x: ie.suitable(x) or False, 'test_heise_url_extraction')
    yield (lambda x: ie._get_info_extractor(x) or False, 'test_heise_url_specific_info_extraction')

# Generated at 2022-06-24 12:36:05.392504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE.IE_NAME == 'heise'

# Generated at 2022-06-24 12:36:05.933482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:36:07.382736
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    heiseie.suitable('http://www.heise.de/test')

# Generated at 2022-06-24 12:36:18.340040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # In this test, we assert that the html of a news article (without embed)
    # can be parsed, but that it does not contain any usable information

    # first, retrieve the html of the news article
    url = 'http://www.heise.de/security/artikel/OpenSSL-Bug-BIG-IP-schaltet-SSL-ab-beim-Zugriff-auf-Zieladressen-mit-31-Bit-IP-Adressen-2588593.html'
    webpage = (self._download_webpage(url))
    # then, initialize the HeiseIE class, which takes in the html as an argument
    ie = HeiseIE(webpage)
    # finally, test the 'extract' method
    ie.extract()
    # assert that the video_id is correctly parsed
    self

# Generated at 2022-06-24 12:36:19.465208
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:36:20.295117
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:36:21.644778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    print(heiseie)

# Generated at 2022-06-24 12:36:23.501127
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == "Heise"

# Generated at 2022-06-24 12:36:24.239041
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('www.heise.de', 'heise').assert_success()

# Generated at 2022-06-24 12:36:25.569242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie != None

# Generated at 2022-06-24 12:36:26.938150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        pass

# Generated at 2022-06-24 12:36:34.553949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('http://www.heise.de/ct/video/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')



# Generated at 2022-06-24 12:36:36.251250
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test for constructor of class HeiseIE"""
    heise = HeiseIE()

# Generated at 2022-06-24 12:36:38.195571
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_name() != "Unknown"
    assert ie.working == True

# Generated at 2022-06-24 12:36:42.045511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_constructor = getattr(HeiseIE, '__init__')
    def_signature = inspect.getargspec(class_constructor)
    # check default of parameter 'fatal' in deleting HeiseIE
    assert 'fatal' in def_signature.args
    assert def_signature.defaults[0] == True

