

# Generated at 2022-06-24 12:26:42.456114
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    assert e._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert e.IE_NAME == 'heise'
    assert e.IE_DESC == 'heise:'




# Generated at 2022-06-24 12:26:48.254867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.suitable( 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html' )
    assert not heiseie.suitable( 'https://www.heise.de/forum/heise-online/Webnews/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-nach-eigenen-Angaben/posting-3814130/show/' )

# Generated at 2022-06-24 12:26:49.545590
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:26:56.118335
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Testing HeiseIE"""
    url = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    HeiseIE._download_webpage = lambda x, y: '<html />'
    heiseie = HeiseIE({})
    assert(heiseie.suitable(url))

# Generated at 2022-06-24 12:27:05.960966
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl.downloader.common import FileDownloader

    ydl = FileDownloader()
    ydl.add_info_extractor(HeiseIE)
    ydl.add_info_extractor(KalturaIE)
    ydl.add_info_extractor(YoutubeIE)
    ydl.add_default_info_extractors()
    ydl.extract_info(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        download=False
    )

# Generated at 2022-06-24 12:27:08.599583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE('www.heise.de')
    print(heiseie.name)
    print(heiseie.ie_key())
    print(heiseie.domain)

# Generated at 2022-06-24 12:27:16.857285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    '''
    Test constructor of class HeiseIE
    '''
    heiseIE = HeiseIE()
    _url = heiseIE._real_extract(url)['url']
    assert _url == 'kaltura:2238431:1_kkrq94sm' 
    #assert heiseIE.__init__(url)
    
    
    

# Generated at 2022-06-24 12:27:18.819738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    tester = HeiseIE()
    test_dict = tester.test()

    assert(test_dict['test'] == 'test')

# Generated at 2022-06-24 12:27:23.251177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_name = HeiseIE.__name__
    # When adding an additional test in the test set,
    # please make sure it is also added in the constructor assertion below
    ie = HeiseIE(dict(extractors=['a', 'b', 'c', class_name], downloader=None))
    assert ie.IE_NAME == class_name
    assert ie.ie_key() == class_name
    assert ie.SUCCESS_REGEX == HeiseIE._VALID_URL
    assert ie.VIDEO_ID_REGEX == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:27:26.418010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that we have subclassed the basic InfoExtractor
    ie = HeiseIE(dummy_klass=InfoExtractor)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:27:30.983941
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    heise_ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html", True)

# Generated at 2022-06-24 12:27:31.953440
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__doc__ is not None

# Generated at 2022-06-24 12:27:33.718478
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert 'HeiseIE' in ie.__class__.__name__

# Generated at 2022-06-24 12:27:35.782060
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-24 12:27:36.378255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:27:43.368642
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None, None)

    assert isinstance(ie, HeiseIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, YoutubeIE)
    assert isinstance(ie, KalturaIE)
    assert isinstance(ie.constructor_spec, dict)
    assert ie.constructor_spec['ie_key'] == 'Heise'

    assert ie.constructor_spec['_VALID_URL'] == HeiseIE._VALID_URL
    assert ie.constructor_spec['_TESTS'] == HeiseIE._TESTS
    assert ie.constructor_spec['_EXTRA_TESTS'] == []
    assert ie.constructor_spec['_FORMATS'] == YoutubeIE._FORMATS

# Generated at 2022-06-24 12:27:49.402515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    _ = heise.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    _ = heise.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html?wt_mc=rss.ho.beitrag.atom')
    _ = heise.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:27:56.427961
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class HeiseIE_test(HeiseIE):
        pass

    try:
        HeiseIE_test('b', 'c')
    except TypeError as e:
        assert(str(e) == "__init__() takes exactly 3 arguments (2 given)")
    try:
        HeiseIE_test('b', 'c', 'd')
    except TypeError as e:
        assert(str(e) == "__init__() takes exactly 3 arguments (3 given)")

# Generated at 2022-06-24 12:27:57.465888
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # assert HeiseIE()
    assert True

# Generated at 2022-06-24 12:28:03.049454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_imports import HeiseIE
    filename = os.path.join(
        os.path.dirname(__file__),
        'test_data',
        '%s' % inspect.getframeinfo(inspect.currentframe()).function)
    if not os.path.exists(filename):
        os.mkdir(filename)
    _ = hei = HeiseIE(filename)

# Generated at 2022-06-24 12:28:10.140339
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('heise')
    assert obj.name == 'heise'
    assert obj.exports.get('playlist_from_matches') is None
    assert obj.exports.get('match_url') is not None
    assert obj.exports.get('video_info_from_url') is not None
    assert obj.exports.get('_real_extract') is not None
    assert obj.exports.get('_real_initialize') is not None
    assert obj.exports.get('_real_extract_from_url') is not None

# Generated at 2022-06-24 12:28:11.546742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-24 12:28:14.173671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test the construction of HeiseIE class"""
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:24.334123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert obj._TESTS is not None

# Generated at 2022-06-24 12:28:26.895603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ies = [HeiseIE]
    for ie in ies:
        ie(heise_instance=True)
        ie()

# Generated at 2022-06-24 12:28:27.801659
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE can be instantiated
    ie = HeiseIE()

# Generated at 2022-06-24 12:28:29.281035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Runs unit test for HeiseIE Constructor
    """
    HeiseIE()

# Generated at 2022-06-24 12:28:33.241308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE('www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert heiseie.N.get('classes') == 'HeiseIE'

# Generated at 2022-06-24 12:28:41.221255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Check for valid URL

# Generated at 2022-06-24 12:28:44.366782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_key() in heise_ie.supported_ie()

# Generated at 2022-06-24 12:28:45.488888
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.name == 'heise'

# Generated at 2022-06-24 12:28:53.701799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:04.964720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # I did not find a way to create a mock url object which is assigned to
    # heise_id.url. Because of this, I'm checking the url of the HeiseIE
    # object instead
    heise_id = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:29:06.468428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()

# Generated at 2022-06-24 12:29:16.864294
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:29:21.069591
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:22.879884
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None


# Generated at 2022-06-24 12:29:23.451927
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())


# Generated at 2022-06-24 12:29:24.339143
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:29:30.604825
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE(None)
    assert h.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert h.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert h.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:29:31.660403
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE.construct_type(HeiseIE.ie_key()))

# Generated at 2022-06-24 12:29:35.775922
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    import sys

    print(sys.version)
    print("Testing HeiseIE constructor")
    print("==============================================================")
    HeiseIE(sys.argv[1])
    print("==============================================================")


# Generated at 2022-06-24 12:29:37.181944
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:47.042910
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(
        'https://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ) == True
    assert HeiseIE.suitable(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    ) == True

# Generated at 2022-06-24 12:29:57.904771
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE(None)._TESTS == HeiseIE._TESTS
    assert 'youtube:' not in HeiseIE._TESTS[0]['info_dict'].get('id', '')
    assert 'kaltura:' in HeiseIE._TESTS[0]['info_dict'].get('id', '')
    assert 'youtube:' in HeiseIE._TESTS[1]['info_dict'].get('id', '')
    assert 'kaltura:' not in HeiseIE._TESTS[1]['info_dict'].get('id', '')
    assert 'youtube:' not in HeiseIE._TESTS[2]['info_dict'].get('id', '')

# Generated at 2022-06-24 12:29:58.485237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:06.795701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom') is True
    assert HeiseIE.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') is False

# Generated at 2022-06-24 12:30:16.388884
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert(heise_ie._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html')
    assert(heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:30:23.987046
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    ie = HeiseIE(url)
    assert ie._meta == 'Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert ie._id == '3814130'

# Generated at 2022-06-24 12:30:29.070715
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    
    # Make sure the regex matches
    # This will also assure that the program will execute at least this far
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:38.459427
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    world = HeiseIE()
    assert world._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:43.918777
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise.ie_key() == 'heise'
    assert heise.IE_DESC == 'heise'

# Generated at 2022-06-24 12:30:46.647076
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE();
    instance._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:30:52.199034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:31:03.360697
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert IE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert IE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert not IE.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:31:13.007120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:31:15.586485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    param = "video_id"
    klass = HeiseIE
    HeiseIE.__bases__ = (InfoExtractor,)
    instance = klass(param)
    print("*************test_HeiseIE()*********************")
    print("instance: ", instance)

# Generated at 2022-06-24 12:31:22.250328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    if heise_ie.suitable("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"):
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:31:30.898565
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:31:41.577151
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url2 = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    url3 = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"

# Generated at 2022-06-24 12:31:42.444970
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:45.793711
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() in ie.gen_extractors()

# Generated at 2022-06-24 12:31:48.096323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE(None)

    # constructor should ignore the parameters
    assert isinstance(test, HeiseIE)
    assert test._downloader is None

# Generated at 2022-06-24 12:31:48.882398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h is not None

# Generated at 2022-06-24 12:31:52.589374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:31:55.855290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    expected_pattern = r'^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html$'
    assert ie._VALID_URL == expected_pattern

# Generated at 2022-06-24 12:32:05.290929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.description == """\
heise+ von heise online. Das Tech-Magazin mit Liebe zum Detail.\
"""
    assert ie.suitable(u'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True
    assert ie.suitable(u'http://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is True

# Generated at 2022-06-24 12:32:06.119399
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:32:06.982937
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:32:09.044683
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-24 12:32:11.714926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_key() in heise_ie.SUFFIX

# Generated at 2022-06-24 12:32:13.316835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert type(heise) == HeiseIE

# Generated at 2022-06-24 12:32:19.824035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE constructer input arguments
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id = '3700244'

    # HeiseIE constructer output arguments
    heiseie = HeiseIE()
    heiseie_url = heiseie._VALID_URL
    heiseie_video_id = heiseie._TESTS[0]['info_dict']['id']

    # assert
    assert url == heiseie_url
    assert video_id == heiseie_video_id

# Generated at 2022-06-24 12:32:20.751055
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-24 12:32:22.287172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie


# Generated at 2022-06-24 12:32:25.899118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for class HeiseIE"""
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise:video'

# Generated at 2022-06-24 12:32:36.680459
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['id'] =='1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:32:42.969723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ydl = YoutubeDL(YoutubeDL.params)
    url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    HeiseIE(ydl = ydl)
    ie = ydl.extract_info(url, download = False)
    assert ie.get("id") == "heise:2404147"
    assert ie.get("ext") == "mp4"

# Generated at 2022-06-24 12:32:50.269295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract(url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract(url='http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:33:01.505652
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    metadata = ie._get_metadata('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert metadata['title'] == "c't uplink 3.3: Owncloud / Tastaturen / Peilsender Smartphone"
    assert metadata['description'] == 'md5:795c381057a4a6d62ca60a3f6e0777ad'
    assert metadata['thumbnail'] == 'http://cdn-ak.f.st-hatena.com/images/fotolife/h/hibiki_t/20171215/20171215013430_original.png'
    assert metadata['timestamp'] == 1513227965

# Generated at 2022-06-24 12:33:03.189780
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE();
    assert isinstance(hie, InfoExtractor)

# Generated at 2022-06-24 12:33:13.368713
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
  assert HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
  assert HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:33:22.241590
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not heise_ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert not heise_ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-11-1-Sicherheit-in-WLAN-und-Smart-Home-3551458.html')
    assert heise

# Generated at 2022-06-24 12:33:26.044979
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable("http://www.heise.de/video/artikel/c-t-uplink-6-2-TV-Stick-Louis-CK-und-Mac-Speicher-leeren-2555341.html")

# Generated at 2022-06-24 12:33:27.004214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:33:35.000861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from xml.etree import ElementTree
    from xml.dom import minidom
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:33:36.474682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == "heise"

# Generated at 2022-06-24 12:33:45.678765
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Check if it is a subclass of InfoExtractor
    assert issubclass(HeiseIE, InfoExtractor)
    # Superficial tests
    # HeiseIE should have been registered
    assert ie.ie_key() in InfoExtractor._ies
    # test whether the constructor is working
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:47.177670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:33:50.646620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise.de'
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:33:56.278772
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if HeiseIE raises an error if no video_id is found in the url
    # and check if video_id is used from match_id if video_id is not found in url
    url = 'http://www.heise.de/ct/artikel/New-Motif-Git-unter-Windows-und-Linux-3598637.html'
    ie = HeiseIE(url)
    assert ie.match_id == '3598637'

# Generated at 2022-06-24 12:33:57.206099
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:33:59.970298
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise'


# Generated at 2022-06-24 12:34:02.841235
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(dict())
    assert isinstance(ie, HeiseIE) and isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:05.103057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_desc() == 'heise.de'

# Generated at 2022-06-24 12:34:07.529515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == "Heise"
    assert x.ie_name() == "Heise"
    assert x.suitable(None)

# Generated at 2022-06-24 12:34:10.257588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create the class instance
    HeiseIE_instance = HeiseIE()
    # Call the constructor of InfoExtractor
    InfoExtractor.__init__(HeiseIE_instance)
    # Check the class name
    assert HeiseIE_instance._CLASS_NAME == "HeiseIE"

# Generated at 2022-06-24 12:34:20.284793
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:21.609321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import test_factory
    return test_factory(HeiseIE)

# Generated at 2022-06-24 12:34:24.660272
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    this_module = sys.modules[__name__]
    heise_ie = this_module.HeiseIE()
    # check HeiseIE instance
    assert isinstance(heise_ie, this_module.HeiseIE) is True


# Generated at 2022-06-24 12:34:25.807293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.name == 'heise.de'

# Generated at 2022-06-24 12:34:34.536343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert ie.suitable("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert not ie.suitable("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-24 12:34:37.215592
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test if HeiseIE constructor returns a HeiseIE object
    """
    ie = HeiseIE()
    assert ie.__class__.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:34:39.830655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:34:51.893947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert(heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:34:58.286748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Test the constructor of HeiseIE,
    which we use to check the types of the parameters.
    '''
    heise_video = HeiseIE()
    for attr, expected_type in heise_video._TESTS[0].items():
        attr_value = getattr(heise_video, attr, None)
        # for example:
        #   heise_video._downloader ==
        #   <youtube_dl.YoutubeDL object at 0x7f9dc17b6c10>
        assert isinstance(attr_value, expected_type)

# Generated at 2022-06-24 12:35:06.833232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:35:17.840548
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    instance.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    instance.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:35:19.718478
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_flag = False
    try:
        heise = HeiseIE()
        unit_test_flag = True
    except Exception:
        pass
    assert unit_test_flag, 'Unit Test for HeiseIE failed'


# Generated at 2022-06-24 12:35:22.135195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"
    # Test Video URL with constructor
    heiseIE = HeiseIE(url)

# Generated at 2022-06-24 12:35:26.732359
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title']

# Generated at 2022-06-24 12:35:27.444230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:35:37.423811
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.url == 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    assert ie.id == '3959893'

# Generated at 2022-06-24 12:35:45.954815
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:35:55.247600
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # youtube_url = 'https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    # heise_video = HeiseIE(youtube_url)
    # # heise_video.test()

    # kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # heise_video2 = HeiseIE(kaltura_url)
    # heise_video2.test()
    pass

# Generated at 2022-06-24 12:35:56.198763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:36:00.999366
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None

# Generated at 2022-06-24 12:36:04.090577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    print (ie.extract(ie.url))

# Generated at 2022-06-24 12:36:05.600843
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Constructor test"""
    heise_ie = HeiseIE()
    #print ("Constructor test")

# Generated at 2022-06-24 12:36:06.452646
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE != None


# Generated at 2022-06-24 12:36:08.190721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.ie_key() == 'heise'
    assert h.ie_name() == 'heise video'

# Generated at 2022-06-24 12:36:09.575931
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    heiseIE = ie._real_initialize()



# Generated at 2022-06-24 12:36:11.610637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:36:15.357582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    # Check for the test _VALID_URL
    url = heise._VALID_URL
    assert heise._match_id(url)


# Generated at 2022-06-24 12:36:19.156655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    HeiseIE()._real_extract(url)

# Generated at 2022-06-24 12:36:23.097731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:36:26.159412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:29.588591
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    assert url in ie.extract(url)

# Generated at 2022-06-24 12:36:40.179006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable(ie.ie_key(), 'https://www.heise.de/videout/feed?container=38075&sequenz=431905')
    ie.suitable(ie.ie_key(), 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.suitable(ie.ie_key(), 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')