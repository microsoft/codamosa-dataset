

# Generated at 2022-06-24 12:26:41.378423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == 'heise'

# Generated at 2022-06-24 12:26:47.381839
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.get_video_id() == '1_kkrq94sm'

# Generated at 2022-06-24 12:26:50.414028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert bool(HeiseIE._VALID_URL)
    assert bool(HeiseIE.IE_NAME)
    assert bool(HeiseIE.IE_DESC)

# Generated at 2022-06-24 12:26:51.213422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global ie
    ie = HeiseIE()

# Generated at 2022-06-24 12:26:53.496254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE.test(url)
    return

# Generated at 2022-06-24 12:26:54.641412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert(ie != None)
    assert(ie != "")

# Generated at 2022-06-24 12:27:05.697093
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisie = HeiseIE("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heisie.url == "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heisie.video_id == "Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heisie.ie_key() == "heise"


# Generated at 2022-06-24 12:27:13.035582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE(False)
    assert obj.suitable(test_url) == True

    obj = HeiseIE(True)
    assert obj.suitable(test_url) == True

    test_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert obj.suitable(test_url) == True

# Generated at 2022-06-24 12:27:14.032251
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Direct instantiation test case
    heiseie = HeiseIE()
    assert heiseie

# Generated at 2022-06-24 12:27:14.615430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:27:16.075144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    y = HeiseIE()
    assert(y.ie_key() == 'heise')
    assert(y.ie_name() == 'heise.de')

# Generated at 2022-06-24 12:27:17.961329
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'Heise Video'

# Generated at 2022-06-24 12:27:21.937887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-24 12:27:25.527754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.site_name == 'heise'


# Generated at 2022-06-24 12:27:30.691390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.__name__ == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.test()

# Generated at 2022-06-24 12:27:33.672636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None
    assert heise_ie.SUFFIX is not None
    #print 'SUFFIX: ' + heise_ie.SUFFIX

# Generated at 2022-06-24 12:27:35.365365
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    r = HeiseIE()
    obj = r.return_something()

# Generated at 2022-06-24 12:27:36.061340
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert test

# Generated at 2022-06-24 12:27:36.655410
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:37.709454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.hostname() == 'heise.de'

# Generated at 2022-06-24 12:27:44.443520
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Testing constructor of class HeiseIE"""
    from .heise import HeiseIE
    url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    h = HeiseIE()
    h.init()
    h._real_initialize(url)

# Generated at 2022-06-24 12:27:47.328514
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    s = HeiseIE()
    assert(s.get_name() == "heise")
    assert(s.ie_key() == "heise")
    assert(s.get_description() == "heise.de")

# Generated at 2022-06-24 12:27:48.543504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == 'heise'

# Generated at 2022-06-24 12:27:59.689055
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test _download_json method
    assert heise._download_json('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is None
    # Test _real_extract method of HeiseIE
   

# Generated at 2022-06-24 12:28:02.791255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.__class__ == tuple
    assert HeiseIE._TESTS.__class__ == list
    assert HeiseIE.__doc__ is not None



# Generated at 2022-06-24 12:28:03.668642
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:07.440907
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # No exception should be thrown
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:28:07.973911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:11.163330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # Search for existence of extractor
        assert HeiseIE() is not None
    except NameError:
        # Continue if name is not defined yet
        pass


# Generated at 2022-06-24 12:28:12.781567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("heise", "http://www.heise.de/artikel/") is not None

# Generated at 2022-06-24 12:28:22.899308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:27.608755
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    heiseie.extract(url)

# Generated at 2022-06-24 12:28:31.804330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..__main__ import HeiseIE
    # test object creation
    # use an invalid url for testing
    _wrong_url = "https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html"
    HeiseIE(_wrong_url)

# Generated at 2022-06-24 12:28:37.148594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    url = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    heiseIE = HeiseIE(url)
    assert heiseIE.url == url
    assert heiseIE._VALID_URL == HeiseIE._VALID_URL
    assert heiseIE.ie_key() == "Heise"

# Generated at 2022-06-24 12:28:44.744605
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)
    assert heiseIE.extractor_key == 'HeiseIE'
    assert heiseIE.playlist_type == None
    assert heiseIE.video_id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'
    assert heiseIE.url == url
    assert heiseIE.ie_key == 'HeiseIE'
    assert heiseIE.mobj.group(1) == '2404147'

# Generated at 2022-06-24 12:28:53.219945
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True
    assert inst.suitable("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html") == True
    assert inst.suitable("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html") == True

# Generated at 2022-06-24 12:29:04.458293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.title_key == 'fulltitle'
    assert ie.description_key == 'description'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:10.942656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

    # check if URL is valid
    heise_ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

    # check if URL is invalid
    assert not heise_ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:29:12.352573
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of class HeiseIE."""
    HeiseIE()


# Generated at 2022-06-24 12:29:23.915603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = [
        {
            'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
            'id': '2404147',
            'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
        },
    ]
    for test_case in test_cases:
        assert test_case['id'] == HeiseIE._match_id(test_case['url'])
        heiseIE = HeiseIE(url=test_case['url'])
        stream = heiseIE._real_extract(url=test_case['url'])
        assert stream['title'] == test

# Generated at 2022-06-24 12:29:30.379286
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:31.382150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # simple test to determine if the constructor has changed
    HeiseIE()

# Generated at 2022-06-24 12:29:35.425088
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE(None)
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:39.752887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/ausgabe/2017-4-Virenscanner-ProtonMail-und-Raspberry-Pi-3924167.html")
    assert ie.extract()["id"] == "3924167"

# Generated at 2022-06-24 12:29:46.283823
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS
    assert heise_ie.__name__ == 'Heise'
    assert heise_ie.IE_NAME == 'heise'
    assert heise_ie.ie_key() == 'Heise'



# Generated at 2022-06-24 12:29:48.948412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:51.973374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #HeiseIE('url','name',True) #need to implement a case for which an url and name are passed in as arguments
    hie = HeiseIE()

# Generated at 2022-06-24 12:30:01.985736
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:30:02.917256
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:30:03.813894
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:30:07.912501
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie.suitable('http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') is False

# Generated at 2022-06-24 12:30:12.456826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.__class__.__name__ == 'HeiseIE'


# Generated at 2022-06-24 12:30:13.078295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	pass

# Generated at 2022-06-24 12:30:14.834764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_heise = HeiseIE()
    assert ie_heise.ie_key() == 'Heise'

# Generated at 2022-06-24 12:30:16.562768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assertHeiseIEObject(ie)


# Generated at 2022-06-24 12:30:27.240621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for Kaltura
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    kaltura_match = HeiseIE._VALID_URL.match(kaltura_url)
    kaltura_ie = HeiseIE(kaltura_match)
    assert kaltura_ie.video_id == '1_kkrq94sm'

    # Test for YouTube
    youtube_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    youtube_match

# Generated at 2022-06-24 12:30:29.044262
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        heise_ie = HeiseIE()
    except Exception:
        raise AssertionError("Constructor of HeiseIE should be valid.")


# Generated at 2022-06-24 12:30:37.850175
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    TestHeiseIE = type('TestHeiseIE', (HeiseIE,), {})
    test_heise_ie = TestHeiseIE()

    assert test_heise_ie._VALID_URL == (
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert test_heise_ie.IE_NAME == 'heise'
    assert test_heise_ie.IE_DESC == 'heise'

# Generated at 2022-06-24 12:30:39.864741
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:30:42.451588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:30:50.468857
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:51.301743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    infoextractor = HeiseIE()

# Generated at 2022-06-24 12:30:52.604769
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-24 12:30:54.357037
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ != '__main__':
        return
    else:
        unittest.main()

# Generated at 2022-06-24 12:30:55.005945
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:56.475232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    Ha = HeiseIE()

# Generated at 2022-06-24 12:31:07.859319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:11.753217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_class = HeiseIE()
    # print(test_class.__class__.__bases__)
    assert test_class.__class__.__bases__[0].__name__ == 'InfoExtractor'
    assert test_class.__class__.__bases__[0].__bases__[0].__name__ == 'VideoInfoExtractor'



# Generated at 2022-06-24 12:31:12.405469
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'

# Generated at 2022-06-24 12:31:16.726634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    expected_result = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

    extractor_result = HeiseIE(expected_result, url)
    assert (extractor_result.title == expected_result)

# Generated at 2022-06-24 12:31:18.276694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:31:21.528690
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   ie=HeiseIE()
   if not ie:
      raise Exception('Failed to create class HeiseIE')
   else:
      print('test_HeiseIE: ok')

# Generated at 2022-06-24 12:31:30.351973
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(HeiseIE.ie_key())
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == 1
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == 1
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == 1

# Generated at 2022-06-24 12:31:40.533717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        _ = HeiseIE(None)
    except:
        assert False, 'An exception was raised during initialization'
    try:
        _ = HeiseIE(InfoExtractor())
    except:
        assert False, 'An exception was raised during initialization'
    try:
        _ = HeiseIE(InfoExtractor(), 'This is a pattern')
        assert False
    except NotImplementedError:
        pass
    try:
        _ = HeiseIE(InfoExtractor(), r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147\.html')
    except:
        assert False, 'An exception was raised during initialization'

# Generated at 2022-06-24 12:31:49.588858
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.url == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    assert ie.id == '1_ntrmio2s'
    assert ie.name == 'Heise'

# Generated at 2022-06-24 12:31:55.571988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    page = HeiseIE(url)
    assert page.url == url
    assert page.video_id == '3700244'
    assert page.title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"



# Generated at 2022-06-24 12:32:00.569348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #instance is created with class name and heiseie
    f = HeiseIE('heise','heise')
    assert f._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:01.504620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('HEISE') == HeiseIE

# Generated at 2022-06-24 12:32:07.590432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    return

# Generated at 2022-06-24 12:32:08.516728
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()

# Generated at 2022-06-24 12:32:09.796995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._build_url_result()



# Generated at 2022-06-24 12:32:18.082922
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:32:25.138940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.extract_info("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:32:26.661751
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.__name__ == "HeiseIE")


# Generated at 2022-06-24 12:32:34.189183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE("heisede", "http://heise.de/")
    # Test the attribute 'name' of class HeiseIE
    assert obj.name == 'heisede'
    # Test the attribute '_VALID_URL' of class HeiseIE
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:32:36.382246
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.constructor['_VALID_URL'].__doc__ == ie._VALID_URL

# Generated at 2022-06-24 12:32:45.208780
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Prevent "AttributeError: 'HeiseIE' object has no attribute '_TEST'"
    # in case there is no '_TEST' attribute in class HeiseIE
    try:
        getattr(HeiseIE, '_TEST')
    except AttributeError:
        HeiseIE._TEST = {}
    # Prevent "NameError: global name 'logger' is not defined"
    # in case there is no 'logger' attribute in class HeiseIE
    try:
        getattr(HeiseIE, 'logger')
    except NameError:
        HeiseIE.logger = object()
    # Prevent "AttributeError: 'HeiseIE' object has no attribute '_download_json'"
    # in case there is no '_download_json' attribute in class HeiseIE

# Generated at 2022-06-24 12:32:47.510061
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.server_url() == 'http://www.heise.de/'

# Generated at 2022-06-24 12:32:48.875344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE



# Generated at 2022-06-24 12:32:50.930503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for class HeiseIE"""
    info_extractor = HeiseIE()
    assert info_extractor.ie_key() == 'heise'

# Generated at 2022-06-24 12:33:02.054216
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import bytes_to_url
    from . import YoutubeDL
    from .extractor.common import InfoExtractor

    # Test case 1: check input params
    ydl = YoutubeDL({'dump_single_json': 1, 'skip_download': 1, 'simulate': 1})
    assert isinstance(ydl.params['dump_single_json'], bool)
    assert isinstance(ydl.params['skip_download'], bool)
    assert isinstance(ydl.params['simulate'], bool)

    # Test case 2: check input params
    ydl = YoutubeDL({'outtmpl': '%(height)s'})
    assert isinstance(ydl.params['outtmpl'], str)

    # Test case 3: check

# Generated at 2022-06-24 12:33:06.601812
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple unit test to exercise the constructor of class HeiseIE.
    The test is only done when running locally and not via Travis CI.
    """
    if __name__ != "__main__":
        return
    import sys
    import os
    import unittest

    def _get_next_unit_test_number():
        """
        Returns the next unit test number.
        """
        for n in range(1, sys.maxsize):
            if not os.path.exists(os.path.join("tests", "test%d" % n)):
                return n
        raise RuntimeError("could not find empty test directory")

    # set required environment variables for unit test
    os.environ["PYTHONPATH"] = os.getcwd()
    test_number = _get_next_unit_test_number

# Generated at 2022-06-24 12:33:07.315411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("heiseIE")

# Generated at 2022-06-24 12:33:18.169325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test cases for method _real_extract()

    # Case 1: Test an URL of a video embedding a Youtube video
    assert ie._real_extract(
        'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html').get(
        '_type') == 'url_transparent'
    # Case 2: Test an URL of a video embedding a Kaltura video

# Generated at 2022-06-24 12:33:24.609880
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    heise.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:33:27.003928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Create instance of HeiseIE
    heise_ie = HeiseIE()

    # Make sure HeiseIE's constructor is working
    assert isinstance(heise_ie, HeiseIE)

# Generated at 2022-06-24 12:33:29.358511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:33.121891
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test construction of HeiseIE class"""
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:33:45.412204
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    # pylint: disable=W0212
    instance = HeiseIE._build_video_result(
        {}, {})
    assert instance['extractor_key'] == "Heise"

    inst = HeiseIE(HeiseIE._build_downloader({}))
    assert inst.ie_key() == "Heise"
    assert inst.suitable(None) is False
    assert inst.suitable(HeiseIE._build_url_result({
        'url': 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    })) is True

# Generated at 2022-06-24 12:33:46.003509
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:33:47.222992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:54.016219
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # constructor
    x = HeiseIE()
    # video_id
    y = x._match_id('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert y == '2403911'
    y = x._match_id('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert y == '3214137'

# Generated at 2022-06-24 12:33:56.008849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:33:57.981791
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()["HeiseIE"]
    assert class_ is not None
    instance = class_()
    assert instance is not None

# Generated at 2022-06-24 12:34:02.476429
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    HeiseIE._download_webpage = lambda *args, **kwargs: ""
    assert ie._real_extract(url)

# Generated at 2022-06-24 12:34:03.024447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:34:09.834521
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #Main test
    result = HeiseIE()
    assert result.suitable("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html") == True
    #Test for unsuitable URL
    result = HeiseIE()
    assert result.suitable("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html") == True


# Generated at 2022-06-24 12:34:11.628889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:34:14.098229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE()._VALID_URL
    assert HeiseIE._TESTS == HeiseIE()._TESTS

# Generated at 2022-06-24 12:34:15.020460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:34:15.413065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:16.915567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-24 12:34:18.456518
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _init = HeiseIE._init()
    print(_init)

# Generated at 2022-06-24 12:34:19.686757
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-24 12:34:24.579720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(HeiseIE):
        IE_DESC = 'Test class'
        _VALID_URL = 'Invalid URL'

    info_extractor = TestHeiseIE()

    assert info_extractor.IE_NAME == 'heise.de'
    assert info_extractor.IE_DESC == 'Test class'
    assert info_extractor._VALID_URL == 'Invalid URL'

# Generated at 2022-06-24 12:34:31.480927
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    for test_url in heise_ie._TESTS:
        test_extract_result = heise_ie.extract(test_url)
        # Assertion 1: Extracting the heise video_id
        heise_video_id = heise_ie._match_id(test_url)
        assert heise_video_id is not None
        # Assertion 2: True if youtube video, False otherwise
        assert heise_ie._is_valid_url(test_url, heise_video_id)
        # Assertion 3: True if kaltura video, False otherwise
        assert heise_ie._is_valid_url(test_url, heise_video_id)
        # Assertion 4: Extracting the video title
        video_title = test

# Generated at 2022-06-24 12:34:36.930680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor of class HeiseIE have only one instance.
    # Because url_result is a class variable and will be shared by
    # the instances.
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise1 = HeiseIE()
    result1 = heise1._real_extract(url)
    heise2 = HeiseIE()
    result2 = heise2._real_extract(url)
    assert result1 == result2

# Generated at 2022-06-24 12:34:40.226416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == (r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:44.820141
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Assigning a string to HeiseIE object
    hie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    # Was the URL really saved?
    assert hie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-24 12:34:52.020723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')
    assert ie.__class__ is HeiseIE
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_xml')
    assert hasattr(ie, '_extract_description')

# Generated at 2022-06-24 12:34:58.408886
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl.extractor import gen_extractors_by_class
    from youtube_dl.utils import extract_attributes

    heise_extractor = gen_extractors_by_class(HeiseIE)[0]
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_extractor.suitable(url)
    heise_extractor.extract(url)



# Generated at 2022-06-24 12:35:06.926181
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for the HeiseIE extractor."""

# Generated at 2022-06-24 12:35:09.089441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('test_HeiseIE', './test_HeiseIE')

# Generated at 2022-06-24 12:35:12.948267
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:13.537848
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:14.837495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:35:17.042290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert(ie.ie_key() == 'heise')
    assert(ie.ie_name() == 'Heise')

# Generated at 2022-06-24 12:35:18.674012
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    constr = lambda: HeiseIE()
    assert_raises(TypeError, constr)



# Generated at 2022-06-24 12:35:20.835068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Just for testing the constructor of the class
    ie = HeiseIE(None)
    assert ie

# Generated at 2022-06-24 12:35:23.214062
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(InfoExtractor._calc_fields())
    # Unit test for constructor of class HeiseIE
    # ie = HeiseIE()
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:34.528249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_suite = [
        test_HeiseIE.Heise_Kaltura,
        test_HeiseIE.Heise_YouTube,
        test_HeiseIE.Heise_VideoHeise,
    ]
    #TODO: Uncomment this later
    """
    for case in test_suite:
        if case.__name__ == "Heise_VideoHeise":
            # This test is failing due to not availability of video on server
            continue
        print "Running unit test for case " + case.__name__
        curCase = case()
        curCase.setUp()
        curCase.test_Heise_Kaltura()
        curCase.tearDown()
        print "Successfully passed unit test for case " + case.__name__
    """


# Generated at 2022-06-24 12:35:35.121736
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:36.581125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 'HeiseIE' in globals()

# Generated at 2022-06-24 12:35:40.469018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    # HeiseIE must support _VALID_URLs.
    for url in ie._TESTS:
        assert ie._is_valid_url(url['url']), 'url %s should be valid' % (url['url'])



# Generated at 2022-06-24 12:35:45.147402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_class = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert test_class.ie_key() == "Heise"

# Generated at 2022-06-24 12:35:46.748287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert plugins.get_IE_codecs('HeiseIE') == HeiseIE.ie_key()

# Generated at 2022-06-24 12:35:52.382915
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Make sure that the HeiseIE extraction succeeds.
    """
    # If extractor fails this test, then the extractor itself is broken
    HeiseIE().extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:36:01.006446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-24 12:36:08.101034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie._download_webpage = lambda *args, **kwargs: 'test'
    ie._search_regex = lambda *args, **kwargs: 'test'
    ie._html_search_regex = lambda *args, **kwargs: 'test'
    ie._html_search_meta = lambda *args, **kwargs: 'test'
    ie._og_search_description = lambda *args, **kwargs: 'test'
    ie._og_search_thumbnail = lambda *args, **kwargs: 'test'

# Generated at 2022-06-24 12:36:09.465071
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:14.960184
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test the constructor of class HeiseIE"""
    heiseie = HeiseIE("heise.de", "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heiseie.name == "heise.de"
    assert heiseie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heiseie.ie_key() == "heise"


# Generated at 2022-06-24 12:36:15.519444
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert HeiseIE(InfoExtractor()).working

# Generated at 2022-06-24 12:36:19.505531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie.extract(url)

# Generated at 2022-06-24 12:36:20.151684
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:36:24.499427
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Ensure the old HeiseIE which doesn't support new features no longer exists
    assert not globals().get('HeiseIE')

    # Ensure new HeiseIE exists and is a subclass of InfoExtractor
    assert hasattr(InfoExtractor, '__bases__') and HeiseIE in InfoExtractor.__bases__

# Generated at 2022-06-24 12:36:25.478975
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:36:26.419364
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()

# Generated at 2022-06-24 12:36:31.233578
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:36:32.398985
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-24 12:36:37.091264
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:36:42.082650
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'heise'  # Test ie_key() function
    assert obj.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')['id'] == '1_kkrq94sm'  # Test extract() function