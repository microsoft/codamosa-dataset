

# Generated at 2022-06-24 12:26:43.273680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-24 12:26:47.934121
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE('www.heise.de/ct/video/test.html', {})
    assert x.ie_key() == 'Heise'
    assert x.ie_name() == 'Heise'
    assert x._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert 'None' in repr(x)
    return True

# Generated at 2022-06-24 12:26:50.321105
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # create instance of class HeiseIE
    Heise = HeiseIE()
    assert Heise

# Generated at 2022-06-24 12:26:59.417580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    try:
        ie.match_url('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
        assert(True)
    except:
        assert(False)
    try:
        ie.match_url('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-24 12:27:00.790821
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-24 12:27:01.809111
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, None)


# Generated at 2022-06-24 12:27:08.647412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:11.260149
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:20.327988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.ie_key() == 'Heise'
    assert ie.sub_ie[YoutubeIE.ie_key()].name == 'Youtube'
    assert ie.sub_ie[KalturaIE.ie_key()].name == 'Kaltura'

    # Test HeiseIE standard video
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:27:30.094152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'

    # test for function _real_extract()
    url_1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url_2 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'

# Generated at 2022-06-24 12:27:37.838946
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.findall("/") is not None
    assert HeiseIE._TESTS[0].get("url").find("heise") is not None
    assert HeiseIE._TESTS[1].get("url").find("heise") is not None
    assert HeiseIE._TESTS[2].get("url").find("heise") is not None
    assert HeiseIE._TESTS[3].get("url").find("heise") is not None
    assert HeiseIE._TESTS[4].get("url").find("heise") is not None

# Generated at 2022-06-24 12:27:41.021827
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'

# Generated at 2022-06-24 12:27:43.045619
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE(None)
    assert_equal(e.IE_NAME, 'heise')

# Generated at 2022-06-24 12:27:50.071225
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('c934cbfb326c669c2bcabcbe3d3fcd20')
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.id == '1_kkrq94sm'
    assert ie.ext == 'mp4'
    assert ie.timestamp == 1512734959
    assert ie.upload_date == '20171208'
    assert ie.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:28:00.586122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    url = 'https://www.heise.de/ct/ausgabe/2017-12-c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-3740276.html'

    # Test if the webpage is loaded correctly
    webpage_node = info_extractor._download_webpage(url, None)
    assert webpage_node == '<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body>\n'
    # Test if the correct title is extracted
    title = info_extractor._get_title(webpage_node)
    assert title == 'c\'t uplink: Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-24 12:28:02.527507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:28:03.429481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:28:04.379727
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:28:06.412825
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() is not None


# Generated at 2022-06-24 12:28:07.604643
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert(h is not None)

# Generated at 2022-06-24 12:28:18.039026
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL is HeiseIE._VALID_URL
    ie = HeiseIE(None)
    assert ie._TESTS is HeiseIE._TESTS
    ie = HeiseIE(None)
    ie._downloader.cache.remove('http://www.heise.de/videout/feed?container=24&sequenz=258')
    assert ie._downloader.cache.has_key('http://www.heise.de/videout/feed?container=24&sequenz=258') is False
    ie = HeiseIE(None)
    ie._downloader.cache.remove('http://www.heise.de/videout/feed?container=24&sequenz=258')

# Generated at 2022-06-24 12:28:18.688531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:19.265596
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:21.018511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL  # pylint: disable=protected-access

# Generated at 2022-06-24 12:28:31.045993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test to instantiate class HeiseIE with an url and make
    sure that it returns an object of class HeiseIE.
    """

    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    inst_object = HeiseIE(url)
    assert isinstance(inst_object, HeiseIE)

    url = 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'
    inst_object = HeiseIE(url)

# Generated at 2022-06-24 12:28:35.867594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    e = HeiseIE(u)
    assert(e)
    print('heise-OK')

# Generated at 2022-06-24 12:28:39.070286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?heise\.de/(?:[^/]+/)+(?P<id>[0-9]+)\.html'
    assert ie.NAME == 'heise'

# Generated at 2022-06-24 12:28:46.217938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    HeiseIE should be test since it has been broken for a long time.
    """
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    url2 = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    ie = HeiseIE()
    ie.extract(url)
    ie.extract(url2)

# Generated at 2022-06-24 12:28:49.878490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.SUFFIX == '.html'
    assert ie.VIDEO_URL_TEMPLATE.format('0') == 'http://www.heise.de/video/artikel/0.html'

# Generated at 2022-06-24 12:28:54.420150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Simple test for module Heise
    target = HeiseIE()
    assert (target.suitable("http://www.heise.de/newsticker/"
                            "meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
            == True)

# Generated at 2022-06-24 12:28:55.977728
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:28:57.568248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie = HeiseIE('test')

# Generated at 2022-06-24 12:28:59.609854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(None)
    # Just to get the instances of the HeiseIE class,
    # Nothing is to be done with it

# Generated at 2022-06-24 12:29:02.976552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == 'Heise'
    assert x.ie_name() == 'Heise'
    assert x.supported_extractors()['Kaltura']

# Generated at 2022-06-24 12:29:07.494468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:29:11.117333
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    construct_test(HeiseIE, {'url': 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'})

# Generated at 2022-06-24 12:29:19.693819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import heise
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    heise.HeiseIE()._real_initialize()
    heise.HeiseIE().suitable(url)
    heise.HeiseIE()._real_extract(url)
    pass


if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-24 12:29:25.153962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    id = '1_kkrq94sm'

    test_HeiseIE = HeiseIE(url)

    assert test_HeiseIE.url == url
    assert test_HeiseIE.id == id

# Generated at 2022-06-24 12:29:26.251298
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:29:27.253598
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

# Generated at 2022-06-24 12:29:30.414514
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-24 12:29:31.422463
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Checks for the instantiation of the class
    HeiseIE(None)

# Generated at 2022-06-24 12:29:42.394148
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _constructor(url):
        this_class = globals()[HeiseIE.__name__]
        return this_class(url)

    assert _constructor('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:43.174185
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    return h

# Generated at 2022-06-24 12:29:45.522667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h != None
    assert h.ie_key() != None

# Unit tests for method _real_extract of class HeiseIE

# Generated at 2022-06-24 12:29:51.309860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # The url has a number in it which will be used as the video id
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = ie._match_id(url)
    print("VIDEO_ID: " + video_id)
    # Will download the webpage and extract the video ID and then download the media
    webpage = ie._download_webpage(url, video_id)
    print("WEBPAGE: " + webpage)

# Generated at 2022-06-24 12:29:54.915580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL=='^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html$'

# Generated at 2022-06-24 12:30:00.872860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ == '__main__':
        url = 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'
        ie = HeiseIE(url)
        print("Ausgabe:")
        print(ie._VALID_URL)
        print("\nTest Ende")
    else:
        assert 0

# Generated at 2022-06-24 12:30:02.517645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test that the HeiseIE constructor works."""
    assert HeiseIE

# Generated at 2022-06-24 12:30:08.095306
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Basic test with a working video.
    """
    url = 'http://www.heise.de/ct/video/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    h = HeiseIE()
    assert h.suitable(url)
    assert h.IE_NAME == 'heise'
    assert h.IE_DESC == 'heise'

# Generated at 2022-06-24 12:30:10.813411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(IE, InfoExtractor)
    assert isinstance(IE, KalturaIE)
    assert isinstance(IE, YoutubeIE)

# Generated at 2022-06-24 12:30:11.398974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:30:14.290338
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Error case: no URL
    with pytest.raises(TypeError):
        HeiseIE()
    # No error case: url
    ie = HeiseIE(url='url')

# Generated at 2022-06-24 12:30:18.949217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	instance = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
	assert instance.__class__.__name__ == "HeiseIE"


# Generated at 2022-06-24 12:30:21.666299
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE() is working
    # Raises an exception if not.
    HeiseIE()

# Generated at 2022-06-24 12:30:30.562443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable( 'https://www.heise.de' )
    assert ie.suitable( 'http://www.heise.de/video' )
    assert ie.suitable( 'http://www.heise.de/photo' )
    assert ie.suitable( 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' )

# Generated at 2022-06-24 12:30:35.572260
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'heise')
    assert(ie.ie_name() == 'heise')
    assert(ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True)


# Generated at 2022-06-24 12:30:37.045415
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.downloader.cache.remove_old_entries(0)

# Generated at 2022-06-24 12:30:46.841662
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") is True
    assert HeiseIE.suitable(
        "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom") is True
    assert HeiseIE.suitable(
        "http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html") is True

# Generated at 2022-06-24 12:30:47.710468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:30:48.770082
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:30:56.376388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://video.heise.de/.../...-...html')
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')


# Generated at 2022-06-24 12:31:07.774393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    with open('./test/test_data/heise.txt', 'r') as f:
        webpage = f.read()
    entry_id = ie._find_entry_id_in_webpage(webpage)
    assert entry_id == '1_kkrq94sm'
    video_id = ie._find_video_id_in_webpage(webpage)
    assert video_id == '1_kkrq94sm'
    embed_url = ie._find_embed_url_in_webpage(webpage)

# Generated at 2022-06-24 12:31:15.433115
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:31:26.215166
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for exception for basic instantiation
    try:
        HeiseIE()
    except Exception:
        pass
    else:
        raise Exception("Expected exception for basic instantiation")

    # Test for exception for no URL
    try:
        HeiseIE(url=None)
    except Exception:
        pass
    else:
        raise Exception("Expected exception for no URL")

    # Test for instantiation of HeiseIE with valid URL
    h = HeiseIE(url="http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert isinstance(h, HeiseIE)

# Generated at 2022-06-24 12:31:29.583444
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.name == "Heise"
    assert(heiseie.extractor_key == 'heise')
    assert heiseie.ie_key() == 'heise'
    assert(heiseie.get_info("123") is None)

# Generated at 2022-06-24 12:31:31.110998
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # testing constructor
    assert HeiseIE.__name__ == "HeiseIE"

# Generated at 2022-06-24 12:31:41.851694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test for extractor HeiseIE
    #
    # If true, test passes
    # If false, test fails
    #
    # The order of arguments is:
    # 1. URL
    # 2. Expected plain title
    # 3. Expected description

    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    expected_title = "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    expected_description = "Wie sichert das c't-Tool Restric'tor Windows 10 ab?"

    extractor = HeiseIE()

    # Get the URL information

# Generated at 2022-06-24 12:31:52.778538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert obj.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    
    obj = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:31:59.757094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'heise'
    assert heiseIE.ie_name() == 'heise'
    assert heiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heiseIE.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:32:01.150918
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:32:07.812285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE.URL = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_HeiseIE.EXPECTED_TITLE = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    test_HeiseIE.EXPECTED_VIDEO_ID = '1_kkrq94sm'
    test_HeiseIE.EXPECTED_DESCRIPTION = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:32:10.154132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Run unit tests for class HeiseIE.
    '''
    ie = HeiseIE()
    assert ie is not None, "Couldn't instantiate HeiseIE"

# Generated at 2022-06-24 12:32:11.417227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:32:13.104829
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name in Ie.ie_map

# Generated at 2022-06-24 12:32:14.673503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE()

    # Test type of result
    assert isinstance(result, HeiseIE)

# Generated at 2022-06-24 12:32:19.356129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise = HeiseIE()
    data = heise._real_extract(url)
    assert data['title'] == 'NEU IM SEPTEMBER | Netflix'
    assert data['description'] == 'md5:2131f3c7525e540d5fd841de938bd452'

# Generated at 2022-06-24 12:32:30.924199
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html?wt_mc=rss.ho.beitrag.atom') == True
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == True

# Generated at 2022-06-24 12:32:35.585578
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_data = {
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    }
    HeiseIE.match(**test_data)(test_data)

# Generated at 2022-06-24 12:32:39.047532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:40.288803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUFFIX

# Generated at 2022-06-24 12:32:41.526338
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    #TODO: implement test
    assert True

# Generated at 2022-06-24 12:32:42.758185
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL

# Generated at 2022-06-24 12:32:50.133408
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert HeiseIE.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:33:01.360883
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:06.030356
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert isinstance(i.suitable(url), bool)
    assert "Heise" in i._real_extract(url)['title']
    assert i.suitable(url)

# Generated at 2022-06-24 12:33:09.885324
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:15.805310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test_id = '1_kkrq94sm'
    test_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    test_ext = 'mp4'

    HeiseIE_downloader = HeiseIE()

    # Test case: Download mp4 file

# Generated at 2022-06-24 12:33:23.464864
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie = HeiseIE()
    ie._download_webpage = lambda *args, **kwargs: "<html/>"

# Generated at 2022-06-24 12:33:29.056475
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test if the regex of the url works
    test_url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    match = ie._VALID_URL.match(test_url)
    assert match

# Generated at 2022-06-24 12:33:32.545829
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..utils import parse_duration
    h = HeiseIE(None)
    h._download_webpage = lambda id, url: {'title':'Test'}
    assert h._download_webpage('http://www.example.com/', None)['title'] == 'Test'


# Generated at 2022-06-24 12:33:34.125180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    print(heiseIE)


# Generated at 2022-06-24 12:33:34.582213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:33:36.493440
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # b/w: HeiseIE is not a downloadable extractor.
    assert HeiseIE.__name__ != 'HeiseIE'

    # b/w: HeiseIE requires to be initialized with an URL.
    HeiseIE(None)

# Generated at 2022-06-24 12:33:47.871833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:49.308694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

    assert ie.name

# Generated at 2022-06-24 12:33:50.554681
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._WORKING

# Generated at 2022-06-24 12:33:59.791712
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructors
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    url2 = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

    # Test for normal
    assert HeiseIE.suitable(url)
    assert He

# Generated at 2022-06-24 12:34:00.726914
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:34:01.297013
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:04.303951
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:34:05.525265
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Simulate empty test for constructor of class HeiseIE."""

# Generated at 2022-06-24 12:34:07.974005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # TypeError, AttributeError are raised with assertRaises as e.
    # NameError is raised as e.message.
    with pytest.raises(NameError):
        HeiseIE()

# Generated at 2022-06-24 12:34:11.169952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/artikel-URL.html')
    assert isinstance(ie, HeiseIE)
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:34:14.874398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:34:22.845675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == "https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html"

# Generated at 2022-06-24 12:34:33.386563
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[3]['url'] == 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    assert ie._TESTS[3]['info_dict']['id'] == '1_59mk80sf'
    assert ie._TESTS[3]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:34:35.195765
# Unit test for constructor of class HeiseIE
def test_HeiseIE(): # (self=<test.test_youtube.YoutubeIE testMethod=test_suitable>)
    """ Unit test for constructor of class HeiseIE """
    # pylint: disable=no-member
    obj = HeiseIE()

# Generated at 2022-06-24 12:34:41.279303
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:34:45.513242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test HeiseIE class constructor
    try:
        HeiseIE()
    except Exception as e:
        pass

    # test HeiseIE class is an instance of InfoExtractor
    from .common import InfoExtractor
    assert issubclass(HeiseIE, InfoExtractor) == 1

# Generated at 2022-06-24 12:34:50.475530
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that an object an be created
    heise_ie = HeiseIE()
    heise_ie.url_result('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:34:59.780257
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    )
    assert ie._VALID_URL(
        'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    )

# Generated at 2022-06-24 12:35:02.110618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        assert True
    except Exception as e:
        assert False, 'Failed to construct HeiseIE: %s' % e

# Generated at 2022-06-24 12:35:07.383352
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '2404147'

# Generated at 2022-06-24 12:35:13.942234
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.SUFFIX == '.html'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.domain == 'www.heise.de'
    assert HeiseIE.RE_VIDEO_VALID == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:22.670218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Construct an instance of HeiseIE
    ie = HeiseIE()
    # Assert that URLS are correctly matched
    assert ie.suitable("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert ie.suitable("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")
    assert ie.suitable("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")
    # These are

# Generated at 2022-06-24 12:35:34.788296
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor)

    # There should be no attribute '_test' in class HeiseIE
    assert '_test' not in ie.__dict__

    # There should be no attribute 'test' in class HeiseIE
    assert 'test' not in ie.__dict__

    # There should be no attribute '_download_webpage_impl' in class HeiseIE
    assert '_download_webpage_impl' not in ie.__dict__

    # There should be no attribute 'to_screen' in class HeiseIE
    assert 'to_screen' not in ie.__dict__

    # There should be no attribute '_downloader' in class HeiseIE
    assert '_downloader' not in ie.__dict__

    # There should be no attribute '_type' in class HeiseIE

# Generated at 2022-06-24 12:35:43.523241
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # url with kaltura embed
    url1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # url with youtube embed
    url2 = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    # Test for HeiseIE.extract() method
    if not ie.is_suitable(url1):
        _ = ie.extract(url1)

test_HeiseIE()

# Generated at 2022-06-24 12:35:44.259229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:45.324432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:35:48.612737
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    results = [HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')]
    assert results != None

# Generated at 2022-06-24 12:35:53.795344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE.suitable(url)
    assert HeiseIE.suitable(url.replace('video', 'video/artikel'))
    assert HeiseIE.suitable(url.replace('video', 'video/artikel/'))
    assert not HeiseIE.suitable(url.replace('video', 'video/artikel/jwplayer'))
    assert HeiseIE.suitable(url.replace('video', 'newsticker'))

# Generated at 2022-06-24 12:35:55.616680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:35:56.957564
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for constructor of class HeiseIE,
    """
    assert HeiseIE

# Generated at 2022-06-24 12:35:58.715504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case = HeiseIE()
    assert 'heise' in test_case._VALID_URL

# Generated at 2022-06-24 12:35:59.445701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-24 12:36:05.146579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    params = {
        'skip_download': True,
    }
    ie = HeiseIE()._real_extract(url)
    ie.get('url')
    ie.get('id')
    ie.get('title')
    ie.get('description')
    ie.get('thumbnail')
    ie.get('timestamp')
    ie.get('formats')

# Generated at 2022-06-24 12:36:05.627052
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:36:06.492442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-24 12:36:07.306632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("")
    assert ie == ie

# Generated at 2022-06-24 12:36:13.519885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #For test purposes, we create a copy of an heise webpage (needs to be saved locally)
    test_url = "file://" + os.path.dirname(os.path.abspath(__file__)) + "/test.html"
    #We extract the url from the webpage
    test_url_extracted = HeiseIE._extract_url(test_url)
    #We test if we get the same url we put in
    assert "1_ntrmio2s" in test_url_extracted
    #We test if we can download the video (we are not interested in the result, we just want to check if it works correctly)
    heise_ie = HeiseIE()
    heise_ie.extract(test_url_extracted)

# Generated at 2022-06-24 12:36:21.666849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_kaltura import _download_json
    from .test_youtube import _download_webpage

    video_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = '1_kkrq94sm'

    # Constructing HeiseIE from HeiseIE
    test = HeiseIE(HeiseIE(HeiseIE(video_url)))
    assert test.video_url == video_url
    assert test.video_id == video_id
    assert test.extract() == test.extract()
    assert test.extract() == HeiseIE(video_url).extract()


# Generated at 2022-06-24 12:36:22.771004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:36:25.890559
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'
    assert ie.SUPPORTED_IE_NAME == 'heise'

# Generated at 2022-06-24 12:36:32.727305
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:36:34.272254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import doctest
    return doctest.DocTestSuite(HeiseIE)

# Generated at 2022-06-24 12:36:35.344821
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()


# Generated at 2022-06-24 12:36:39.970860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.IE_NAME = 'heise'
    ie.IE_DESC = 'heise.de'
    ie.URL_MAIN = 'https://www.heise.de/'
    ie.VALID_URL = HeiseIE._VALID_URL
    ie.URL_SERVICE = None

# Generated at 2022-06-24 12:36:43.043822
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    assert(ie.url == url)