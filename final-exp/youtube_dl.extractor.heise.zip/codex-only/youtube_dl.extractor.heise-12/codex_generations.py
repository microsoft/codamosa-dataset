

# Generated at 2022-06-24 12:26:40.730001
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None) is not None

# Generated at 2022-06-24 12:26:45.252099
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test constructor of HeiseIE """
    _assert_no_exception(HeiseIE, "heise.de")


# Generated at 2022-06-24 12:26:55.997966
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = [
        # Test case 1
        # Test if HeiseIE can be constructed normally
        (HeiseIE, {}),

        # Test case 2
        # Check if KalturaIE inherited from HeiseIE 
        (KalturaIE, {
            'is_normal_case': True,
            'inherited': True,
            'inherited_from': HeiseIE
        }),

        # Test case 3
        # Check if YoutubeIE inherited from HeiseIE 
        (YoutubeIE, {
            'is_normal_case': True,
            'inherited': True,
            'inherited_from': HeiseIE
        })
    ]

    test_cases_results = []

# Generated at 2022-06-24 12:26:58.867435
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_Heise = HeiseIE()
    assert test_Heise._VALID_URL == HeiseIE._VALID_URL
    assert test_Heise._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:27:01.129015
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:27:06.993370
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'
    assert heise.suitable(heise.gen_extractors(), 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-24 12:27:12.181466
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    assert obj._match_id(url) == '2404147'
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:17.526739
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple test to prove existence of class HeiseIE
    """
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    HeiseIE()._real_extract(url)

# Generated at 2022-06-24 12:27:18.105532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:27:19.349147
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import HeiseIE

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:27:23.551957
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    instance = heise._match_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert instance == '2404147'

# Generated at 2022-06-24 12:27:24.493134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE

# Generated at 2022-06-24 12:27:32.449634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    from .kaltura import KalturaIE
    from ..utils import (
        determine_ext,
        int_or_none,
        NO_DEFAULT,
        parse_iso8601,
        smuggle_url,
        xpath_text,
    )
    assert 'Heise' == HeiseIE.__module__.split('.')[-1]
    assert InfoExtractor.__module__.split('.')[-1] == 'common'
    assert YoutubeIE.__module__.split('.')[-1] == 'youtube'
    assert KalturaIE.__module__.split('.')[-1] == 'kaltura'
    assert 'determine_ext' == determine_ext.__name__

# Generated at 2022-06-24 12:27:35.271539
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import sys
    try:
        HeiseIE(sys.argv[1])
    except BrokenPipeError:
        # unit test of constructor doesn't need to output anything
        pass

# Generated at 2022-06-24 12:27:37.958217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-24 12:27:39.669133
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        print("Test for constructor of HeiseIE failed")
        raise


# Generated at 2022-06-24 12:27:42.342678
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test of HeiseIE
    """
    info_extractor = HeiseIE(None)


# Generated at 2022-06-24 12:27:48.468654
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie

# Generated at 2022-06-24 12:27:50.500485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of class HeiseIE."""
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-24 12:27:52.476281
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, HeiseIE)

# Generated at 2022-06-24 12:27:56.381781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert isinstance(ie, HeiseIE), "HeiseIE object not created for URL"


# Generated at 2022-06-24 12:27:59.939134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:08.991075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    # Test ext
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test title

# Generated at 2022-06-24 12:28:19.467518
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:28:20.913783
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE() # pylint: disable=E1120

# Generated at 2022-06-24 12:28:22.170272
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie is not None

# Generated at 2022-06-24 12:28:22.905799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:23.279378
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:26.895957
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except TypeError as e:
        assert "__init__() takes at least 1 argument (0 given)"
    assert HeiseIE('http://www.heise.de/test/test.html')

# Generated at 2022-06-24 12:28:27.829591
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-24 12:28:37.426811
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:28:38.890719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE._TESTS[0]['url']

# Generated at 2022-06-24 12:28:46.307172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint:disable=W0212
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:48.437332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	x = HeiseIE(heiseIE)
	assert x.media_domain == 'media.heise.de'
	assert x.media_name  == 'heise'

# Generated at 2022-06-24 12:28:59.525192
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:01.039835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:05.923205
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert (HeiseIE()._VALID_URL == HeiseIE._VALID_URL)
    assert (HeiseIE()._TESTS == HeiseIE._TESTS)
    assert (HeiseIE().__name__ == HeiseIE.__name__)

# Generated at 2022-06-24 12:29:07.038901
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Checks the constructor HeiseIE
    heise = HeiseIE()
    heise._TEST = True
    heise.suite()

# Generated at 2022-06-24 12:29:10.473633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS
    assert HeiseIE().__name__ == HeiseIE.__name__
    return True

# Generated at 2022-06-24 12:29:13.553584
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisie = HeiseIE()
    assert heisie.IE_NAME == 'heise'
    assert heisie._VALID_URL == __name__.replace('test_', '')

# Generated at 2022-06-24 12:29:22.834736
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    from .heise import HeiseIE
    from .youtube import YoutubeIE
    from .kaltura import KalturaIE
    
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.page_url
    
    

# Generated at 2022-06-24 12:29:23.412091
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:29:34.221991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:44.853199
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._extract_url(None) == None
    assert HeiseIE._extract_url(123) == None
    assert HeiseIE._extract_url([]) == None
    assert HeiseIE._extract_url({}) == None
    assert HeiseIE._extract_url('') == None
    assert HeiseIE._extract_url('  ') == None
    assert HeiseIE._extract_url('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'
    assert HeiseIE._extract_url('asdasdas') == None

# Generated at 2022-06-24 12:29:45.903535
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:29:47.856430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL is not None
    assert heise._TESTS is not None

# Generated at 2022-06-24 12:29:58.866095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	from .heise import HeiseIE
	from .youtube import YoutubeIE
	from .kaltura import KalturaIE
	from .common import InfoExtractor
	import unittest
	from selenium import webdriver
	from selenium.webdriver.support.ui import WebDriverWait
	from selenium.webdriver.support import expected_conditions as EC
	from selenium.webdriver.common.by import By
	from selenium.common.exceptions import TimeoutException
	from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

	#create instance of class HeiseIE
	ie_mgr = InfoExtractor()
	ie_mgr.add_info_extractor(HeiseIE)
	ie_mgr.add_info_extractor(YoutubeIE)
	

# Generated at 2022-06-24 12:30:08.000664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE('HeiseIE')
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:18.246948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = {
        # kaltura embed
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        # YouTube embed
        'url': 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html',
    }
    ie = HeiseIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._download_webpage(test['url'], None)

# Generated at 2022-06-24 12:30:28.226929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__module__ == '__main__'
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert HeiseIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:30:32.296152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    example_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE(url=example_url)
    assert heise_ie._TESTS[0]['url'] == example_url

# Generated at 2022-06-24 12:30:38.843399
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_test_ie = HeiseIE()
    heise_test_ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    heise_test_ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:45.309037
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Arrange
    expected_id = "2404147"
    expected_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    expected_description = "Heise Video"
    expected_thumbnail = "https://img.heise.de/2404147.jpg"
    expected_timestamp = "2017-12-08T18:22:39+01:00"

    # Arrange
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE()

    # Act
    info = heise._real_extract(url)

    # Assert


# Generated at 2022-06-24 12:30:52.505995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:54.261470
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Create instance for class HeiseIE
    yt = HeiseIE()
    print(yt)


# Generated at 2022-06-24 12:30:56.129819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE() # just check that it doesn't raise an exception

# Generated at 2022-06-24 12:30:57.512889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i.ie_key() == 'Heise'

# Generated at 2022-06-24 12:30:58.697076
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-24 12:31:09.855272
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:31:12.453024
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:14.193513
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'



# Generated at 2022-06-24 12:31:15.281411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:31:16.985412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=protected-access
    heise = HeiseIE(None)
    assert heise._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:24.813969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    print(heise_ie)
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:31:25.830271
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE
    assert test_obj

# Generated at 2022-06-24 12:31:30.422879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    ie = HeiseIE('heise')
    assert ie.ie_key() == 'Heise'
    assert ie.video_id == 'heise'
    assert ie.title is None
    assert ie.url == 'heise'
    assert ie.thumbnail is None
    assert ie.description is None
    assert ie.extractor.ie_key() == 'Heise'

# Generated at 2022-06-24 12:31:37.894658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info = HeiseIE()._real_extract(url)
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info['thumbnail'] is not None

# Generated at 2022-06-24 12:31:42.032254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html','')
    assert(ie.ie_key() == 'heise:video')

# Generated at 2022-06-24 12:31:42.964095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-24 12:31:47.634876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor."""
    heiseie = HeiseIE()
    if heiseie is None:
        print("Unable to instantiate HeiseIE")
        assert False
    else:
        print("Successfully instantiated HeiseIE")
        assert True


# Generated at 2022-06-24 12:31:49.488347
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj is not None


# Generated at 2022-06-24 12:31:50.437466
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass
    # Test for constructor of class HeiseIE

# Generated at 2022-06-24 12:31:53.699572
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == 'heise'
    assert HeiseIE().ie_key() == 'Heise'

# Generated at 2022-06-24 12:32:03.572621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert_equal(heise_ie._VALID_URL,r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert_equal(heise_ie._TESTS[0]['url'], 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert_equal(heise_ie._TESTS[0]['info_dict']['id'], '1_kkrq94sm')

# Generated at 2022-06-24 12:32:05.105067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, HeiseIE)

# Generated at 2022-06-24 12:32:05.961552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-24 12:32:08.340834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    print(str(heise))
    assert heise.ie_key() == 'heise'
    assert heise.info_dict == {}

# Generated at 2022-06-24 12:32:12.789177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:14.993165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Basic
    HeiseIE(None)
    # Advanced
    HeiseIE(KalturaIE(None, {}))
    HeiseIE(YoutubeIE(None, {}))

# Generated at 2022-06-24 12:32:26.097723
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:36.839100
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:32:37.998102
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == "Heise"


# Generated at 2022-06-24 12:32:39.653746
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE(None)
    assert h is not None

# Generated at 2022-06-24 12:32:40.747599
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #Constructor is just a default method without any business logic
    assert(True)



# Generated at 2022-06-24 12:32:43.051865
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE has to satisfy this invariant:
    #   assert isinstance(self.ie, type(ie))
    # See https://github.com/rg3/youtube-dl/pull/12785
    HeiseIE(InfoExtractor()).to_screen()

# Generated at 2022-06-24 12:32:48.361547
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    try:
        assert ie.name
        assert ie.description
        assert ie.description != ie.name
        assert ie.extractor_key == "HeiseIE"
    except AttributeError:
        ie.name = ie.description = ie.extractor_key = ""
        assert (False,
                "{}\nTest for __init__() failed. Some attributes are empty."
                .format(ie.name))

# Generated at 2022-06-24 12:32:59.572556
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for constructor of class HeiseIE
    """

    from .common import InfoExtractor
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import (
        determine_ext,
        int_or_none,
        NO_DEFAULT,
        parse_iso8601,
        smuggle_url,
        xpath_text,
    )

    # Test for constructor with object
    if HeiseIE(InfoExtractor()):
        assert True
    else:
        assert False

    # Test for constructor with object
    if HeiseIE(KalturaIE()):
        assert True
    else:
        assert False

    # Test for constructor with object
    if HeiseIE(YoutubeIE()):
        assert True
    else:
        assert False

    # Test for

# Generated at 2022-06-24 12:33:02.641753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=protected-access
    heise_ie = HeiseIE()._build_ie('Heise', '')
    assert heise_ie.IE_NAME == 'Heise'

    # pylint: enable=protected-access

# Generated at 2022-06-24 12:33:09.268345
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # check if all the required attributes are set
    assert ie._WORKING == True
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._NETRC_MACHINE == 'heise'
    assert ie._TESTS
    assert ie._downloader

# Generated at 2022-06-24 12:33:19.312207
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:20.768344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE({})
    assert 'HeiseIE' in heise_ie.IE_NAME

# Generated at 2022-06-24 12:33:25.060842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.__class__ == HeiseIE

# Generated at 2022-06-24 12:33:26.001536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(None)

# Generated at 2022-06-24 12:33:29.180242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().get_info('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:34.509826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.url_result['_type'] == 'url_transparent'
    assert ie.url_result['ie_key'] == 'Kaltura'
    assert ie.url_result['url'] == 'kaltura:2238431:1_kkrq94sm'

# Generated at 2022-06-24 12:33:38.229224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == "Heise"
    assert ie.ie_key() == "Heise"
    assert ie.name == "Heise"
    assert ie.host == "heise.de"

# Generated at 2022-06-24 12:33:39.963391
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Test HeiseIE.suitable

# Generated at 2022-06-24 12:33:41.459305
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert not HeiseIE._TO_REMOVE is None

# Generated at 2022-06-24 12:33:42.692624
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseIE = HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:33:49.649812
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', '1_kkrq94sm')
    print("test case: ")
    print("url: ", ie.url)
    print("id: ", ie.id)
    print("timestamp: ", ie._timestamp)
    # print("c_t_uplink_url: ",ie._c_t_uplink_url)
    # print("_query: ", ie._query)


# Generated at 2022-06-24 12:33:51.662886
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, InfoExtractor)

# Generated at 2022-06-24 12:34:00.856564
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    id = '1_ntrmio2s'
    assert HeiseIE.suitable(url)
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE._VALID_URL == str('https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert HeiseIE._TESTS[0]['url'] == url
    assert HeiseIE._TESTS[0]['id'] == id

# Generated at 2022-06-24 12:34:02.434900
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise','Incompatible IE Key'

# Generated at 2022-06-24 12:34:10.421590
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    #urls = ['https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html',
    #'https://www.heise.de/tr/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html',
    #'https://www.heise.de/tr/artikel/Der-Vergleich-Windows-10-vs-Linux-vs-MacOS-vs-Android-vs

# Generated at 2022-06-24 12:34:12.145653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
     if __name__ == "__main__":
         test = HeiseIE()
         print(test)

# Generated at 2022-06-24 12:34:15.821210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:34:17.122481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if HeiseIE can be instantiated
    HeiseIE()

# Generated at 2022-06-24 12:34:19.686416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # assert the class name
    assert ie.__class__.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:34:22.045981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import assertHttpRequest
    assertHttpRequest(
        '%s?container=2175&sequenz=4' % (HeiseIE._VALID_URL[:7]),
        expected_data=r'<rss version="2.0" xmlns:jwplayer="http://rss.jwpcdn.com/">')

# Generated at 2022-06-24 12:34:23.356831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE(InfoExtractor())
    assert heiseIE

# Generated at 2022-06-24 12:34:24.807039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-24 12:34:29.812266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    assert test_HeiseIE._VALID_URL == HeiseIE._VALID_URL
    assert len(test_HeiseIE._TESTS) == len(HeiseIE._TESTS)
    assert test_HeiseIE.IE_NAME == HeiseIE.IE_NAME

# Generated at 2022-06-24 12:34:33.794522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() == ie.IE_NAME
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:34:39.878432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test example URL
    example_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    example_id = '1_kkrq94sm'
    example_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

    # Construct class object
    heise = HeiseIE()

    # Deal with videoID
    assert heise._match_id(
        example_url) == example_id or heise._match_url(example_url) == example_id

    # Download video
    heise.download(example_url)

    # Download video and get information
    info_dict = he

# Generated at 2022-06-24 12:34:51.936456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:52.847969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:34:54.068164
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

test_HeiseIE()

# Generated at 2022-06-24 12:34:57.425051
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == "heise"
    assert heise_ie.ie_key() == "www.heise.de"
    assert heise_ie.ie_key() == "heise.de"

# Generated at 2022-06-24 12:34:58.286275
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE == type(HeiseIE({}))

# Generated at 2022-06-24 12:35:00.115549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test inherited class
    from .common import InfoExtractor
    assert issubclass(HeiseIE, InfoExtractor)


# Generated at 2022-06-24 12:35:08.173650
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' )
    assert heise.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert heise.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:35:13.038541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    instance = class_("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:35:16.110074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') != None

# Generated at 2022-06-24 12:35:17.220887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:35:18.034503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('')
    assert obj != None

# Generated at 2022-06-24 12:35:21.315999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id  = '1_ntrmio2s'

    heiseIE = HeiseIE()
    video_data = heiseIE._real_extract(video_url)
    assert video_data['id'] == video_id

# Generated at 2022-06-24 12:35:22.221759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:35:29.028405
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_video_id = '1_kkrq94sm'

    HeiseIE(test_url) == test_video_id

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:35:30.727752
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = heiseIE.HeiseIE()
    assert instance.ie_key() == "heise"

# Generated at 2022-06-24 12:35:31.922991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:35:32.937922
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:35:34.788378
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-24 12:35:35.350291
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:43.394347
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('kaltura', 'heise.de')
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie.IE_NAME == 'kaltura:heise.de'
    assert ie.ie._VALID_URL == HeiseIE._VALID_URL
    assert ie.ie._TESTS == HeiseIE._TESTS
    assert ie.ie.IE_NAME == 'kaltura:heise.de'
    assert ie.ie.host() == 'heise.de'
    assert ie.ie.ie_key() == 'heise.de'

# Generated at 2022-06-24 12:35:49.976237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ht = HeiseIE()
    assert ht.suitable(u'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ht.suitable(u'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')



# Generated at 2022-06-24 12:35:54.668714
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:35:56.074833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()


# Generated at 2022-06-24 12:36:01.767277
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie.IE_NAME == 'heise'
    assert heise_ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:04.951800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html',{})._real_extract({})

# Generated at 2022-06-24 12:36:06.130074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() in ie.SUFFIX

# Generated at 2022-06-24 12:36:07.223538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:36:07.714233
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:36:18.656261
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE();

# Generated at 2022-06-24 12:36:20.884840
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    
    # create object of class HeiseIE
    obj = HeiseIE()
    # check if the object was created correctly
    assert obj != None

# Generated at 2022-06-24 12:36:30.036704
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:40.635833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # First constructor test HeiseIE()
    extractor = HeiseIE()
    # Test to see if the constructor obtains id of a video
    assert extractor._match_id(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-'
        '2404147.html') == '2404147', "The constructor does not obtain the id of a video"

    # Second constructor test HeiseIE(url)
    extractor = HeiseIE(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-'
        '2404147.html')
    #