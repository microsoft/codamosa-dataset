

# Generated at 2022-06-24 12:26:46.333252
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Function to test constructor of class HeiseIE. Passed test cases are
    url, id, title and description
    """
    # Test Case 1
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    video_id = '6kmWbXleKW4'
    title = 'NEU IM SEPTEMBER | Netflix'
    description = 'md5:2131f3c7525e540d5fd841de938bd452'
    test_dict = {
        'url': url,
        'id': video_id,
        'title': title,
        'description': description,
    }
    # Test Case 2

# Generated at 2022-06-24 12:26:47.530541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    d = HeiseIE()

    assert d is not 0



# Generated at 2022-06-24 12:26:49.409761
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:26:52.704859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructing an instance of this class should not raise an exception.
    """
    try:
        ie = HeiseIE()
    except Exception as e:
        raise AssertionError('HeiseIE raises exception %r' % e)

# Generated at 2022-06-24 12:27:00.809310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:05.647189
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    h = HeiseIE(url=url)
    assert h is not None

# Generated at 2022-06-24 12:27:08.648659
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'
    assert obj.ie_name() == 'heise.de'
    assert obj.ie_version()
    assert obj.supported_extensions() == ['mp4']

# Generated at 2022-06-24 12:27:10.928043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE()
    assert m.ie_key() == 'heise'

# Generated at 2022-06-24 12:27:13.018307
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE, 'ie_key')
    assert hasattr(HeiseIE, '_VALID_URL')

# Generated at 2022-06-24 12:27:20.075191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    module = HeiseIE()
    # Check URL matches
    assert( module._match_id('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == '2403911' )
    assert( module._match_id('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html', strict=True) == None )

# Generated at 2022-06-24 12:27:22.313716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(0)
    assert isinstance(ie, HeiseIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:27:23.692102
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE()
    assert type(class_) == HeiseIE

# Generated at 2022-06-24 12:27:27.637742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url="http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"
    heiseie = HeiseIE()
    heiseie.extract(url)

# Generated at 2022-06-24 12:27:37.635341
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor and all its functions"""
    heise_ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert heise_ie._VALID_URL == 'http://www\.heise\.de/video/artikel/[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:40.607160
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
# test_HeiseIE()

# Generated at 2022-06-24 12:27:42.246700
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import test_HeiseIE
    test_HeiseIE.runTest()

# Generated at 2022-06-24 12:27:51.138490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisie = HeiseIE()
    # Test the metadata extraction

# Generated at 2022-06-24 12:27:52.580159
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('Heise')

# Generated at 2022-06-24 12:27:53.930723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj is not None

# Generated at 2022-06-24 12:27:57.366401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:59.739239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise'

# Generated at 2022-06-24 12:28:02.483820
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(InfoExtractor())
    assert obj.ie_key() == 'Heise'
    assert obj.ie_name() == 'heise'

# Generated at 2022-06-24 12:28:10.315473
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:28:14.215609
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    heise_ie.package('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:28:18.378727
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:23.523531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE, '_VALID_URL')
    assert hasattr(HeiseIE, '_TESTS')
    assert hasattr(HeiseIE, '_download_webpage')
    assert hasattr(HeiseIE, '_match_id')
    assert hasattr(HeiseIE, '_real_extract')
    assert hasattr(HeiseIE, '_search_regex')

# Generated at 2022-06-24 12:28:33.572036
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:41.577041
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Instantiate HeiseIE class
	heise_ie = HeiseIE()

	# Test exctract function
	heise_ie._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

	# Test upload date
	upload_date = heise_ie._search_regex('\\d{8}', heise_ie.formats[0]['format_note'], 'upload date')
	date_object = datetime.strptime(upload_date, '%Y%m%d')

# Generated at 2022-06-24 12:28:49.312973
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("kaltura:2238431:1_kkrq94sm")
    assert ie.url == "https://cdnapisec.kaltura.com/p/2238431/sp/223843100/embedIframeJs/uiconf_id/29110792/partner_id/2238431?iframeembed=true&playerId=kaltura_player_1493153352&entry_id=1_kkrq94sm"
    assert ie.kaltura_video_id == "1_kkrq94sm"
    assert ie._KALTURA_HOSTNAME == "www.heise.de"

# Generated at 2022-06-24 12:28:53.479401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:28:54.553135
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE({})
test_HeiseIE()

# Generated at 2022-06-24 12:29:00.948758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert_equals(test._TESTS[0]['url'], 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert_equals(test._TESTS[0]['info_dict']['id'], '1_kkrq94sm')

# Generated at 2022-06-24 12:29:02.431953
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #TODO: Add unit test for HeiseIE
    pass

# Generated at 2022-06-24 12:29:05.105287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(downloader=None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:09.971611
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:11.598641
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check if the correct class name is HeiseIE
    assert HeiseIE.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:29:23.405421
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test case for invalid url
    invalid_url = 'https://www.heise.de/'
    heise_ie = HeiseIE(invalid_url)
    assert heise_ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:25.358819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    obj_ = HeiseIE()

# Generated at 2022-06-24 12:29:35.177283
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    youtube_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    extractor = HeiseIE()._real_extract(youtube_url)
    assert extractor['id'] == '6kmWbXleKW4'
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    extractor = HeiseIE()._real_extract(kaltura_url)
    assert extractor['id'] == '1_kkrq94sm', extractor['id']


# Generated at 2022-06-24 12:29:39.845657
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie == HeiseIE
    assert ie.type == 'kaltura'

# Generated at 2022-06-24 12:29:44.677911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert(HeiseIE.suitable(url))
    assert(HeiseIE._VALID_URL == HeiseIE.valid_url(url))

# Generated at 2022-06-24 12:29:47.343699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test class HeiseIE"""
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie = HeiseIE(url)
    assert ie.url == url

# Generated at 2022-06-24 12:29:58.214372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()
    assert t._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:05.185908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of HeiseIE"""

    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE(InfoExtractor())

    ie = heise._real_extract(url)

    # Test video_id
    assert(heise._match_id(url) == ie['id'])

    # Test title
    assert(ie['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")

    # Test description

# Generated at 2022-06-24 12:30:07.383180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor should create an instance of this class
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:30:10.721939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:12.038344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie


# Generated at 2022-06-24 12:30:17.533987
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    stream_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    ie.url = stream_url
    assert ie.youtube_id == ie.video_id == '1_kkrq94sm'

# Generated at 2022-06-24 12:30:27.129720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE

    Test with the unit test for HeiseIE._real_extract with test_HeiseIE()._TESTS
    """

    # Test with the test URLs from HeiseIE._TESTS
    _heise_tests = HeiseIE._TESTS

    assert len(_heise_tests) > 0

    # For every test in _heise_tests
    for _heise_test in _heise_tests:
        url_test = _heise_test['url']

        # Test with the test URL from HeiseIE._TESTS
        _heise_ie = HeiseIE(url_test)

        # Test for constructor
        assert type(_heise_ie) == HeiseIE

# Generated at 2022-06-24 12:30:29.280424
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'heise')
    assert(ie.video_id == 'heise')
    return

# Generated at 2022-06-24 12:30:33.057215
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:30:38.716307
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = (
        'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-'
        'Tastaturen-Peilsender-Smartphone-2404147.html'
    )
    ie = HeiseIE(test_url)
    assert ie == HeiseIE, 'should return itself'
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:48.199224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # for "Requests" library tests
    import requests
    session = requests.Session()

    # for "url_basename" function
    import os

    # 1. case
    ie_ = HeiseIE({})._downloader
    assert ie_ is not None

    # 2. case
    ie_ = HeiseIE({})
    assert ie_ is not None

    # 3. case (no arguments)
    ie_ = HeiseIE()
    assert ie_ is not None

    # get true name of IE
    name = ie_.IE_NAME

    # 4. case
    ie_ = globals()[name + 'IE']({}, session)
    assert ie_ is not None

    # get url of current test
    url = os.path.dirname(__file__)

    # 5. case
    ie_ = glob

# Generated at 2022-06-24 12:30:49.841746
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() in globals()

# Generated at 2022-06-24 12:30:53.186704
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # Check if HeiseIE constructor has created an instance of the HeiseIE class
    # and return it
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:31:03.982993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

    assert heise.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert heise.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert heise.suitable('http://www.heise.de/newsticker/meldung/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    assert not heise.suitable('https://www.heise.de')

# Generated at 2022-06-24 12:31:13.499885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:14.268252
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().IE_NAME == 'heise'

# Generated at 2022-06-24 12:31:19.591245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:31:23.595764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:24.590523
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-24 12:31:33.933043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert HeiseIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:31:37.349179
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .HeiseIE import HeiseIE
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise.ie_key() == 'heise'
    assert heise.ie_key() == 'heise.de'

# Generated at 2022-06-24 12:31:38.625091
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:31:43.161304
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:44.298881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    H = HeiseIE()

# Generated at 2022-06-24 12:31:48.520141
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Video from https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    ie = HeiseIE()
    obj = ie.extract(url)
    title = obj["title"]
    assert title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    formats = obj["formats"]
    assert len(formats) > 0
    duration = obj

# Generated at 2022-06-24 12:31:56.971246
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   ie = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
   info = ie._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
   assert info['id'] == '1_kkrq94sm'
   assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
   assert info['timestamp'] == 1512734959
   assert info['upload_date'] == '20171208'

# Generated at 2022-06-24 12:32:05.227557
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import unittest
    
    class TestHeiseIE(unittest.TestCase):

        instance = HeiseIE()

        def test_HeiseIE_accept(self):
            self.assertIsInstance(HeiseIE.accept(self), bool)

        def test_HeiseIE__real_extract(self):
            self.assertIsInstance(HeiseIE._real_extract(self), dict)

        def test_HeiseIE_suitable(self):
            self.assertIsInstance(HeiseIE.suitable(self), bool)

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-24 12:32:08.606106
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None).extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:32:11.629438
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, InfoExtractor)
    assert isinstance(heise_ie, YoutubeIE)
    assert isinstance(heise_ie, KalturaIE)

# Generated at 2022-06-24 12:32:15.542162
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.name == 'heise'
    assert heise.ie_key() == 'heise'
    assert heise.url_regex == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html'

# Generated at 2022-06-24 12:32:26.144484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # assert HeiseIE._TESTS[2]['url'] == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    # assert HeiseIE._TESTS[2]['info_dict']['id'] == '1_ntrmio2s'
    # assert HeiseIE._TESTS[2]['info_dict']['ext'] == 'mp4'
    # assert HeiseIE._TESTS[2

# Generated at 2022-06-24 12:32:36.208830
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_youtube import assertRegexpMatches
    from .test_kaltura import skip_if_kaltura_test_server_is_down
    try:
        i = HeiseIE()
        i.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    except ImportError as e:
        if ('kaltura' in e.args[0]):
            skip_if_kaltura_test_server_is_down()
        raise e

    assertRegexpMatches(i.IE_NAME, "heise")

# Generated at 2022-06-24 12:32:45.051507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    assert obj.suitable(url)
    assert obj.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert obj.extract('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:32:56.008205
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:00.486060
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.download("www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:33:02.143044
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert isinstance(test_obj, HeiseIE)


# Generated at 2022-06-24 12:33:06.110697
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._TESTS[-1] == {
        'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html',
        'only_matching': True,
    }

# Generated at 2022-06-24 12:33:12.325866
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:13.367968
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise

# Generated at 2022-06-24 12:33:15.408220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.name == 'Heise'

# Generated at 2022-06-24 12:33:16.038616
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:33:23.591149
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:31.564039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._html_search_regex = lambda x, y, tag_name, default=None: x
    heise._html_search_meta = lambda x, y, default=None: x
    heise._search_regex = lambda x, y, tag_name, default=None, group="id": x
    heise.extract({
        'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'only_matching': True,
    })

# Generated at 2022-06-24 12:33:32.250079
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:33:34.229034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.extractor_key == "HeiseIE"

# Generated at 2022-06-24 12:33:34.940648
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:33:38.278397
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test if a constructor of class HeiseIE is working
        """
    ie = HeiseIE()
    assert ie.SUFFIX == '.html'
    assert ie.IE_NAME == 'heise:heise'

# Generated at 2022-06-24 12:33:48.848228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.match_url('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'
    assert info_extractor.match_url('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == '6kmWbXleKW4'

# Generated at 2022-06-24 12:33:54.239117
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/newsticker/meldung/'
    heiseInstance = HeiseIE()
    assert(heiseInstance._VALID_URL == re.compile(r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-([0-9]+)\.html'))


# Generated at 2022-06-24 12:33:55.878043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    infoExtractor = HeiseIE()
    assert isinstance(infoExtractor, HeiseIE)

# Generated at 2022-06-24 12:34:01.115510
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE class is constructed by registering, see __init__ of YoutubeIE
    i = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert "class HeiseIE(InfoExtractor)" in repr(i)
    # print repr(i)

# Generated at 2022-06-24 12:34:08.726171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_download import Result
    from . import YoutubeIE
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    # YouTube

# Generated at 2022-06-24 12:34:10.212626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')
    

# Generated at 2022-06-24 12:34:12.661733
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'Heise'
    assert HeiseIE.ie_key() == 'Heise'

# Test video with kaltura embed

# Generated at 2022-06-24 12:34:13.634262
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_info_extractor(HeiseIE)

# Generated at 2022-06-24 12:34:23.648842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:34:29.516879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	dummy_url = 'http://www.heise.de/(some_weird_text)/artikel/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html'
	assert HeiseIE().suitable(dummy_url)
	assert HeiseIE()._real_extract(dummy_url) is not None


# Generated at 2022-06-24 12:34:31.103916
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise

# Generated at 2022-06-24 12:34:40.106167
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:45.773410
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(HeiseIE._VALID_URL)
    assert HeiseIE.ie_key() == 'Heise'
    assert HeiseIE.class_type() == 'HeiseIE'

    # Test for constructor
    assert HeiseIE(HeiseIE._VALID_URL) != None

# Generated at 2022-06-24 12:34:49.613645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:34:50.813758
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test = HeiseIE()

# Generated at 2022-06-24 12:34:54.430626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # No test available for this class

# Generated at 2022-06-24 12:34:56.047749
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-24 12:34:59.258061
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    object = HeiseIE()
    object._real_extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:35:05.417474
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.name == 'heise.de'
    assert ie.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:35:07.182931
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.name == 'heise'

# Generated at 2022-06-24 12:35:15.151686
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    imp = obj.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', {})
    assert imp is None, 'suitable for http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html should be None'

# Generated at 2022-06-24 12:35:16.721200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Successful instantiation of class HeiseIE
    try:
        assert(HeiseIE() is not None)
    except:
        raise AssertionError('Instantiation of HeiseIE() failed!')

# Generated at 2022-06-24 12:35:17.664451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:35:23.922803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Running test for HeiseIE instance")
    heise_ie_instance = HeiseIE()
    assert heise_ie_instance
    assert isinstance(heise_ie_instance, InfoExtractor)
    assert heise_ie_instance._WORKING == True
    assert heise_ie_instance._downloader is not None
    assert heise_ie_instance.ie_key() == 'heise'
    assert heise_ie_instance.working == True
    assert heise_ie_instance.server_location() == 'Frankfurt am Main, HE, Germany'
    assert heise_ie_instance.age_limit == 0

# Generated at 2022-06-24 12:35:27.153209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({"bulk_downloadable": False})
    assert ie

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:35:27.953725
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:35:29.709511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.video_id_re() == re.compile(HeiseIE._VALID_URL)


# Generated at 2022-06-24 12:35:40.948717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_ie = HeiseIE()
    ua = 'Mozilla/5.0 (X11; Linux x86_64; rv:71.0) Gecko/20100101 Firefox/71.0'
    expected_title = 'NEU IM SEPTEMBER | Netflix'
    heise_ie._download_webpage = lambda *args, **kwargs: '{}'

# Generated at 2022-06-24 12:35:42.253070
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # assert that HeiseIE can be constructed
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:50.814940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # First test for constructor of class YoutubeIE
    test_YoutubeIE = YoutubeIE()
    # Second test for constructor of class KalturaIE
    test_KalturaIE = KalturaIE()
    # Third test for constructor of class HeiseIE
    test_HeiseIE = HeiseIE()
    # Fourth test for the _valid_url() function in test_HeiseIE

# Generated at 2022-06-24 12:35:52.383685
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heise = HeiseIE()
	assert heise


# Generated at 2022-06-24 12:35:56.438613
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({"extractor": "HeiseIE",
                  "url": "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
                  })

# Generated at 2022-06-24 12:35:58.326437
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert isinstance(instance, HeiseIE)


# Generated at 2022-06-24 12:36:02.660669
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case 1
    ie1 = HeiseIE(context = "Unit test case 1")
    # Asserting the object creation
    assert ie1

    # Test case 2
    ie2 = HeiseIE(context = "Unit test case 2")
    # Asserting the object creation
    assert ie2


# Generated at 2022-06-24 12:36:03.953421
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert type(heise) == HeiseIE


# Generated at 2022-06-24 12:36:04.504066
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    WordpressIE()

# Generated at 2022-06-24 12:36:11.946376
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.ie_key() == 'heise')

    test_url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_result = HeiseIE().extract(test_url)
    assert(test_result['id'] == '1_kkrq94sm')
    assert(test_result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    assert(test_result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20')

# Generated at 2022-06-24 12:36:18.007314
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_key() == heise_ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:36:27.868778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:35.778191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key()=='heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:36:41.188849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.PROVIDER == "heise.de"
    assert ie.IE_DESC == "C't Magazin Videos and Podcasts"
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'