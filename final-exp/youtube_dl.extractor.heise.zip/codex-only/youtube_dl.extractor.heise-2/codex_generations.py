

# Generated at 2022-06-24 12:26:43.270150
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._constructor()

# Generated at 2022-06-24 12:26:43.839579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:26:45.009481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance.ie_key() == 'Heise'

# Generated at 2022-06-24 12:26:45.566303
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:26:46.475406
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()

# Generated at 2022-06-24 12:26:52.472773
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:00.716401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeIE
    from .kaltura import KalturaIE
    from .common import InfoExtractor
    from .utils import determine_ext
    import string
    import random

    heise_ie = HeiseIE()

    # Check if the class was loaded properly
    assert heise_ie.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'

    # Test for the IE constructor
    def get_heise_video(url):
        ie = InfoExtractor.for_url(url)
        return ie

    # Check if the class was loaded properly

# Generated at 2022-06-24 12:27:09.010234
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE().extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert info.get('id') == '1_kkrq94sm'
    assert info.get('title') == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info.get('description') == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:27:12.973235
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:15.090749
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from .test_HeiseIE import test_HeiseIE
        return test_HeiseIE()
    except ImportError:
        pass

# Generated at 2022-06-24 12:27:22.656908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.url == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    assert ie.video_id == '1_ntrmio2s'
    assert ie.title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"

# Generated at 2022-06-24 12:27:31.769540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().match('kaltura:2238431:1_h3wjnshn')
    assert HeiseIE().match('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert HeiseIE().match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:27:35.365565
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = GetIE()
    assert ie.ie_key() == 'Heise'
    assert ie.IE_NAME == 'Heise'
    assert ie.IE_DESC == 'Hetzner Online GmbH'


# Generated at 2022-06-24 12:27:35.818995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:39.321908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    ie.IE_NAME = 'heisee'
    assert ie.IE_NAME == 'heisee'
    ie.IE_NAME = 'Heise'
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:27:49.108049
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # requires access to heise.de
    ie = HeiseIE()
    video_id = '2404147'
    result = ie._real_extract(ie._VALID_URL % video_id)
    assert result['id'] == '1_kkrq94sm'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert result['thumbnail'] == 're:http://cdn1.heise.de/.*'
    assert result['timestamp'] == 1512734959
    assert len(result['formats']) == 4

# Generated at 2022-06-24 12:27:52.580767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    my_HeiseIE = HeiseIE()
    assert my_HeiseIE != None

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:27:53.368484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:27:54.412430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:27:55.824653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:28:00.240201
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ == '__main__':
        print(HeiseIE()._download_webpage('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html', '123'))

# Generated at 2022-06-24 12:28:05.041957
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    with open("heise_%s.html" % "1_kkrq94sm", 'rb') as file:
        webpage = file.read().decode("utf-8")
    heise = HeiseIE("", "", "", "")
    heise._extract_title(webpage)
    heise._extract_timestamp(webpage)
    heise._extract_id(webpage)

# Generated at 2022-06-24 12:28:06.536164
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE("url")
    assert obj.url == "url"

# Generated at 2022-06-24 12:28:11.337791
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	ie = HeiseIE(None)
	assert ie.get_title("") == ""
	assert ie.get_url("") == ""
	assert ie.get_size("") == 0
	assert ie.get_duration("") == 0
	assert ie.get_author("") == ""
	assert ie.get_views("") == 0

# Generated at 2022-06-24 12:28:12.613705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:28:15.843838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # Instantiation should fail because of missing arguments (url)
        heise = HeiseIE()
        assert(False)
    except:
        # test passed
        assert(True)

# Generated at 2022-06-24 12:28:16.293649
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE()

# Generated at 2022-06-24 12:28:21.622354
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:23.085164
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj is not None


# Generated at 2022-06-24 12:28:24.014978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, None)

# Generated at 2022-06-24 12:28:25.391467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(InfoExtractor)
    assert heise_ie

# Generated at 2022-06-24 12:28:26.798069
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    infoExtractor = HeiseIE()

# Generated at 2022-06-24 12:28:34.090940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    # The test for HeiseIE with heise.de/ct/ausgabe/2016-12-Spiele-3214137.html
    test_HeiseIE = HeiseIE()
    result = test_HeiseIE.extract(url)
    print(result)


# Generated at 2022-06-24 12:28:39.524289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test to check if url is a valid url for HeiseIE
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heise_ie = HeiseIE(url,"facebook")
    assert heise_ie.is_valid_url()
    # Test to check if constructor create a new instance of HeiseIE
    assert isinstance(heise_ie,HeiseIE)

# Generated at 2022-06-24 12:28:40.677425
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    print(ie)

# Generated at 2022-06-24 12:28:49.228363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise.de'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info = ie.extract(url)
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:29:00.078307
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import TestCase
    from .common import setUp
    from .common import tearDown
    from .common import result_has_format
    from .download_corpus import heise_corpus

    TestCase().assertEqual(
        HeiseIE._VALID_URL, 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    class ExtractorTest(TestCase):
        def setUp(self):
            self.extractor = HeiseIE()

        def test_corpus(self):
            for source_url, expected in heise_corpus.items():
                self.setUp()

# Generated at 2022-06-24 12:29:01.039178
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    return ie

# Generated at 2022-06-24 12:29:02.525481
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #pylint: disable=no-member
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:29:10.636987
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # url is mandatory
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-\
Peilsender-Smartphone-2403911.html'
    ie.url = url
    # video_id is mandatory
    video_id = '1_kkrq94sm'
    ie.video_id = video_id

    # test to get the info of the single video
    print(ie.extract())

# Generated at 2022-06-24 12:29:11.904668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == "HeiseIE"

# Generated at 2022-06-24 12:29:13.206113
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-24 12:29:17.674803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:29:22.326645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..test import get_testcases
    for (test_url, test_data) in get_testcases(__name__, 'HeiseIE'):
        ie = HeiseIE({})
        assert ie._extract_video_url(test_url) == test_data

# Generated at 2022-06-24 12:29:26.488774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'HeiseIE'
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')



# Generated at 2022-06-24 12:29:28.597005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-24 12:29:31.005445
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    assert e.IE_NAME == "heise"


# Generated at 2022-06-24 12:29:32.407974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(None)
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:29:35.294657
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.IE_NAME == 'heise.de'

# Generated at 2022-06-24 12:29:40.986597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    config = {
        'desc_xpath': '//sometag[@id="description..."]',
        'caption_class': 'someclass...',
    }
    assert HeiseIE()._VALID_URL == HeiseIE(config)._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE(config)._TESTS

# Generated at 2022-06-24 12:29:44.064801
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie.ie_key()
    assert ie.suitable
    assert ie.extract
    assert ie._real_extract

# Generated at 2022-06-24 12:29:46.022861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert (HeiseIE._VALID_URL ==
            HeiseIE.__bases__[0]._VALID_URL)

# Generated at 2022-06-24 12:29:47.042830
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    R = HeiseIE()
    assert R is not None

# Generated at 2022-06-24 12:29:48.151228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:29:57.031990
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    print('unit.class:', unit.__class__.__name__)
    print('unit.id:', unit.id)
    print('unit.url_basename:', unit.url_basename)
    print('unit.url_basename:', unit.url_basename)
    print('unit.ie_key:', unit.ie_key)

# Generated at 2022-06-24 12:30:06.542198
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:07.382271
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-24 12:30:08.215532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	assert HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:30:10.184332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:30:12.121775
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE._extract_info(HeiseIE(), HeiseIE._VALID_URL, 'id')
    assert info == {}

# Generated at 2022-06-24 12:30:15.020937
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == "heise"
    assert ie.ie_key() == "heise"
    assert HeiseIE.ie_key() == "heise"

# Generated at 2022-06-24 12:30:25.805800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    expected_result = HeiseIE()
    assert expected_result._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:28.940425
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:30.168521
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-24 12:30:33.546437
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    # Test for class variable
    assert ie.ie_key() == 'Heise'
    # Test for _VALID_URL variable
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test for ie()
    assert ie.ie('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == HeiseIE

# Generated at 2022-06-24 12:30:36.843310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:41.308885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() in ie.extractor_key_map
    assert ie.extractor_key_map[ie.ie_key()] is ie

# Generated at 2022-06-24 12:30:42.871376
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    assert type(a) == HeiseIE
#

# Generated at 2022-06-24 12:30:44.473671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 12:30:46.305230
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    assert class_ is not None
    instance = class_()
    assert instance is not None


# Generated at 2022-06-24 12:30:48.256039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _TestHeiseIE
    _TestHeiseIE.test_with_class(HeiseIE, 'heise.de', '1_kkrq94sm')

# Generated at 2022-06-24 12:30:51.064468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE(InfoExtractor())
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:02.651534
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:31:03.235440
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:31:04.155395
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    frm = HeiseIE()

# Generated at 2022-06-24 12:31:11.882014
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # struct: class HeiseIE(InfoExtractor)
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    # struct: assertEqual(a, b, msg=None)
    assertEqual(ie._VALID_URL, r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:31:17.608611
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    my_HeiseIE = HeiseIE()
    assert my_HeiseIE.suitable(url) == True
    assert my_HeiseIE.ie_key() == 'heise'
    assert my_HeiseIE._VALID_URL == my_HeiseIE.VALID_URL
    assert my_HeiseIE.extract(url) is not None


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:31:21.714995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:24.267594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    instance = ie.__class__.__name__
    assert instance == 'HeiseIE', 'Expected HeiseIE as instance, instead got ' + instance

# Generated at 2022-06-24 12:31:24.867996
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:31:32.579775
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Testing class HeiseIE"""
    _HeiseIE = HeiseIE()
    assert _HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html', "Test failed!"
    # URL should have no '?' or '&' or '#' or '=' or '+'
    assert _HeiseIE._VALID_URL.find("?") == -1, "Test failed!"
    assert _HeiseIE._VALID_URL.find("&") == -1, "Test failed!"
    assert _HeiseIE._VALID_URL.find("#") == -1, "Test failed!"

# Generated at 2022-06-24 12:31:35.702376
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE(None)
    assert heise_ie.suitable(url)
    assert heise_ie.extract(url)

# Generated at 2022-06-24 12:31:40.712984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() == 'Heise'
    assert ie.IE_NAME == 'heise'
    assert ie.IE_NAME == 'Heise'
    assert ie.IE_DESC == 'Heise'
    assert ie.ie_key() in globals()
    assert ie.ie_key() in locals()

# Generated at 2022-06-24 12:31:42.462258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Create instance of class HeiseIE
	HeiseIE()



# Generated at 2022-06-24 12:31:43.182420
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()




# Generated at 2022-06-24 12:31:44.339154
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:31:54.646033
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Loads the extractor dynamically
    ie = globals()['HeiseIE']()

    # Test if the extractor is able to extract the content

# Generated at 2022-06-24 12:31:57.832430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:06.444625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test URL that is used in _TESTS of HeiseIE
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_info_dict = {
        'id': '1_kkrq94sm',
        'ext': 'mp4',
        'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        'timestamp': 1512734959,
        'upload_date': '20171208',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
    }

    heise = Heise

# Generated at 2022-06-24 12:32:07.769194
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test constructor of class HeiseIE
    # provides test data
    HeiseIE()

# Generated at 2022-06-24 12:32:10.201442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor._VALID_URL == HeiseIE._VALID_URL
    assert info_extractor._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:32:12.699977
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    
    HeiseIE()._real_extract(url)

# Generated at 2022-06-24 12:32:15.542761
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert repr(ie) == 'HeiseIE'
    assert ie == HeiseIE

# Generated at 2022-06-24 12:32:17.057741
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.host == 'heise'

# Generated at 2022-06-24 12:32:18.281074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    print(i)

# Generated at 2022-06-24 12:32:21.866594
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  '''
  Test for constructor of class HeiseIE
  '''
  try:
    assert(HeiseIE(None))
  except AssertionError as e:
    print('test_HeiseIE of file heise.py failed with AssertionError: ' + str(e))

# Generated at 2022-06-24 12:32:33.703511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    video_id = '1_ntrmio2s'
    title = 'nachgehakt: Wie sichert das c\'t-Tool Restric\'tor Windows 10 ab?'
    description = 'md5:47e8ffb6c46d85c92c310a512d6db271'
    timestamp = 1512470717
    upload_date = '20171205'

# Generated at 2022-06-24 12:32:40.586022
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisie = HeiseIE()

# Generated at 2022-06-24 12:32:43.376645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert e.__class__.__name__ == 'HeiseIE'


# Generated at 2022-06-24 12:32:43.903895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:32:44.411846
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:32:55.164430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseIE = HeiseIE()

# Generated at 2022-06-24 12:32:55.807880
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:02.770356
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._is_valid_url("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert not HeiseIE._is_valid_url("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html",
                                     ie="Youtube")


# Generated at 2022-06-24 12:33:04.184402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:33:07.241173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    e = HeiseIE()
    assert e.ie_key() == 'heise'
    assert e.ie_name() == 'heise.de'

# Generated at 2022-06-24 12:33:10.013507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:12.353058
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    assert test_HeiseIE.required_keys == ['id']
    assert test_HeiseIE.required_keys == ['id']

# Generated at 2022-06-24 12:33:13.071633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:14.595287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("unit test")
    assert ie.name == "Heise"

# Generated at 2022-06-24 12:33:16.078753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        heiseIE = HeiseIE()
    except:
        assert False

# Generated at 2022-06-24 12:33:20.212443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    assert obj._match_id(url) == "1_kkrq94sm"

# Generated at 2022-06-24 12:33:23.760679
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:33:26.789176
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:33:28.049673
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	obj = HeiseIE()
	assert isinstance(obj, HeiseIE)

# Generated at 2022-06-24 12:33:31.246500
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Wenn die HeiseIE Klasse erstellt und die Methode extract() aufgerufen ist, muss das response Objekt das Attribut 'id' haben.
    assert(HeiseIE()._extract_info({'id':'1_kkrq94sm'}['id'])=='1_kkrq94sm')

# Generated at 2022-06-24 12:33:36.667320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test: Get the Website and call HeiseIE()
    test_webpage = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE()._real_extract(test_webpage) != None

# Generated at 2022-06-24 12:33:39.122018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().extract(HeiseIE._TESTS[0]['url']) != None

# Generated at 2022-06-24 12:33:47.275970
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h == HeiseIE()
    assert h == HeiseIE()
    assert h == HeiseIE()
    assert h == HeiseIE()
    assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()
    #assert h == HeiseIE()

# Generated at 2022-06-24 12:33:52.617783
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseIE.IE_NAME == 'heise'
    assert heiseIE.IE_DESC == 'heise.de'

# Generated at 2022-06-24 12:33:53.429293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE)

# Generated at 2022-06-24 12:33:56.497403
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:00.682567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() != 'kaltura'
    # Note: The json_ld is not a valid json_ld; the fields are not enclosed by quotation marks.
    assert ie.working == False

# Generated at 2022-06-24 12:34:06.164710
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:07.717396
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:34:08.751665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE == type(HeiseIE({}))

# Generated at 2022-06-24 12:34:09.576321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:34:10.310200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:34:11.261231
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:34:12.613332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        i = HeiseIE()
    except:
        assert False

# Generated at 2022-06-24 12:34:14.458127
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:34:15.061636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE()

# Generated at 2022-06-24 12:34:15.648468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE

# Generated at 2022-06-24 12:34:25.274565
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert not ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html', True)
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:34:31.417413
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    path = 'test_data/HeiseIE.json'
    with open(path, 'r') as f:
        content = f.read()

    data = json.loads(content)
    HeiseIE.__init__(data["url"])
    assert HeiseIE._VALID_URL == data['_VALID_URL']
    assert HeiseIE._TESTS == data['_TESTS']

# Generated at 2022-06-24 12:34:32.581885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    print(heiseie._VALID_URL)

# Generated at 2022-06-24 12:34:39.197433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info_dict = HeiseIE()._real_extract(video_url)
    assert info_dict.get('id') == '1_kkrq94sm'
    assert info_dict.get('title') == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info_dict.get('description') == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'


# Generated at 2022-06-24 12:34:51.291022
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import TestCase
    from nose.tools import assert_raises


# Generated at 2022-06-24 12:34:52.178833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:35:00.825461
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:03.962817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Try to create an instance of class Heise.
    # If creation was successful, the test case ends here.
    # If not, an AssertionError is raised.
    try:
        ied = HeiseIE()
    except AssertionError:
        raise AssertionError("Creation of HeiseIE failed.")
    return

# Generated at 2022-06-24 12:35:15.590104
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test to verify that HeiseIE() constructor works as expected by verifying that all fields are initialized correctly."""
    # Test that HeiseIE() constructor initializes all fields as expected
    expected_result = {
        "_VALID_URL": re.compile(r"https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html"),
        "IE_NAME": "heise",
        "IE_DESC": "Heise is a German Media Company",
        "BR_DESC_RENDER": re.compile(r"<br.*?>", re.DOTALL),
        "BR_DESC_ENDSWITH": re.compile(r"<br.*?>$", re.DOTALL),
    }
    heise_ie = Heise

# Generated at 2022-06-24 12:35:20.504025
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # resource is not available for testing
    assert HeiseIE(url='https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    pass


# Generated at 2022-06-24 12:35:21.305285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:35:32.649553
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:42.871795
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == (
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert HeiseIE._TESTS[0]['url'] == (
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-'
        '3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-24 12:35:43.631768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:45.631603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    # TODO: write unit test
    pass

# Generated at 2022-06-24 12:35:46.468342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseie = HeiseIE()

# Generated at 2022-06-24 12:35:53.150784
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.url == 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    assert ie.video_id == '2016-12-Spiele-3214137'
    assert len(ie.extractor._TESTS) == 4

# Generated at 2022-06-24 12:35:56.157072
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for the constructor of class HeiseIE."""
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:35:57.166110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('url')

# Generated at 2022-06-24 12:36:06.571999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:07.686278
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import HeiseIE
    heise = HeiseIE()


# Generated at 2022-06-24 12:36:13.117978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    file_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    # test case 1: type(file_url) == str and file_url contains "heise"
    assert ie._match_id(file_url), 'test case 1: file_url contains "heise"'
    # test case 2: type(file_url) == str and file_url doesn\'t contain "heise"
    assert not ie._match_id('https://youtube.com'), 'test case 2: file_url doesn\'t contain "heise"'
    # test case 3: type(file_url) != str

# Generated at 2022-06-24 12:36:18.446515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    heise_test = HeiseIE()
    print(heise_test.extract(url))
    print(heise_test._real_extract(url))

# Generated at 2022-06-24 12:36:19.230981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:36:20.122748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:36:29.519981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:39.793072
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # TODO: include test for non-Kaltura embeds
    info = HeiseIE()._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    # The xpath_text method is tested because it's a helper method which parses an XML-node.
    # If a tag is found in an entry, it is returned.
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:36:40.674247
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:36:43.732692
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # No error raised
    HeiseIE()._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')