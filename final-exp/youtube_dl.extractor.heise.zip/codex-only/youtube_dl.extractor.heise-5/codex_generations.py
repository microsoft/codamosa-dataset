

# Generated at 2022-06-24 12:26:46.508899
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert test.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert test.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not test.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:26:50.755499
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert heiseIE.playlist == []

# Generated at 2022-06-24 12:26:51.636353
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:27:00.162505
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    ie = HeiseIE()
    ie.url = url
    video_id = '1_ntrmio2s'
    webpage = ie._download_webpage(url, video_id)

# Generated at 2022-06-24 12:27:00.762074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:27:10.527303
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise online'
    assert ie.BRAND == 'heise'
    assert ie.BUILD_TEMPLATES_SUFFIX == 'heise.de'
    assert ie.TAB_URL_TEMPLATE == 'https://www.heise.de/artikel-suche/%s'
    assert ie.TOPIC_URL_TEMPLATE == 'https://www.heise.de/%s'
    assert ie.SEARCH_URL_TEMPLATE

# Generated at 2022-06-24 12:27:11.517978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:27:17.869836
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    id = heise_ie._match_id(url)
    if id is not None:
        assert id == '3700244'
        assert heise_ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:19.630596
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Instance of class HeiseIE
    ie = HeiseIE()
    # Check if it is instance of InfoExtractor
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 12:27:21.002465
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    print(heise_ie)



# Generated at 2022-06-24 12:27:24.183266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    try:
        ie.report_warning
    except Exception as e:
        raise Exception("HeiseIE constructor should have super of YoutubIE") from e

# Generated at 2022-06-24 12:27:32.283351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_video_url = "http://www.heise.de/newsticker/meldung/The-Pirate-Bay-Foerdert-neue-Verbreitung-von-Malware-2980503.html"
    test_heise_download_page = "http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    # check instance of class HeiseIE
    assert isinstance(HeiseIE(), HeiseIE)
    # check constructor of class HeiseIE
    assert HeiseIE(test_video_url), HeiseIE(test_video_url)
    # check that constructor of HeiseIE with invalid url raises ValueError

# Generated at 2022-06-24 12:27:33.672497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()  # should not raise an exception



# Generated at 2022-06-24 12:27:35.367904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(isinstance(ie,HeiseIE))

# Generated at 2022-06-24 12:27:36.325328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-24 12:27:38.228719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructor of class HeiseIE
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-24 12:27:41.435422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    # Instantiation of class HeiseIE
    instance = class_()
    # Check if the test_class attribute is initialized
    assert instance.test_class == None

# Generated at 2022-06-24 12:27:50.768721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    f = HeiseIE()
    assert(f._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert(f._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(f._TESTS[0]['info_dict']['id'] == '1_kkrq94sm')
    assert(f._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-24 12:27:54.907539
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:04.765309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
   

# Generated at 2022-06-24 12:28:08.454172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():  # noqa: D403
    ie = HeiseIE(None)
    assert isinstance(ie, HeiseIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, YoutubeIE)
    assert isinstance(ie, KalturaIE)

# Generated at 2022-06-24 12:28:09.477116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    return

# Generated at 2022-06-24 12:28:20.167552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'heise'
    assert ie.ie_key() == 'Heise'
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:21.421165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except TypeError:
        pass

# Generated at 2022-06-24 12:28:23.216533
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.IE_NAME == 'heise:video'

# Generated at 2022-06-24 12:28:25.668096
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    # test the constructor
    assert heise_ie
    # test the type
    assert type(heise_ie) is HeiseIE

# Generated at 2022-06-24 12:28:36.087622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test no. 1
    h1 = HeiseIE()
    assert h1._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test no. 2
    h2 = HeiseIE()
    assert h2._TESTS[0]['url'] == r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # Test no. 3
    h3 = HeiseIE()

# Generated at 2022-06-24 12:28:38.521712
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(HeiseIE):
        pass

    heise_ie = TestHeiseIE(TestHeiseIE.ie_key())
    assert heise_ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:39.101906
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:28:46.463289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:48.115231
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:52.130531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:28:53.053088
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-24 12:28:56.146620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    # check if HeiseIE is a subclass of InfoExtractor
    from .common import InfoExtractor
    assert(issubclass(HeiseIE, InfoExtractor))
    return h

# Generated at 2022-06-24 12:28:58.106544
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testObject = HeiseIE()
    assert testObject
    assert isinstance(testObject, HeiseIE)

# Generated at 2022-06-24 12:28:59.428193
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Given
    HeiseIE.__init__("HeiseIE")


# Generated at 2022-06-24 12:29:01.804669
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception:
        # If exception, just print out its name
        print(Exception)

# Generated at 2022-06-24 12:29:03.023143
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()



# Generated at 2022-06-24 12:29:14.442415
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL.search("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") is not None, "HeiseIE.VALID_URL regexp should match"
    assert heiseIE._VALID_URL.search("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html") is not None, "HeiseIE.VALID_URL regexp should match"

# Generated at 2022-06-24 12:29:15.939371
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test that the class HeiseIE can be constructed"""
    HeiseIE()

# Generated at 2022-06-24 12:29:26.445642
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Arrange
	expected_valid_id = '1_kkrq94sm'
	expected_valid_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
	expected_n_tests = 7 # Number of test cases in _TESTS
	expected_n_results = 3 # Number of results in _TESTS
	expected_n_formats = 1 # Expected number of formats

	# Act
	heise_ie = HeiseIE()
	actual_valid_id = heise_ie._VALID_URL
	actual_valid_url = heise_ie._TESTS[0]['url']

# Generated at 2022-06-24 12:29:35.051519
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE()
    assert heise._re.match(url)
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise.ie_key() == "heise"
    assert heise.ie_key() in IE_DESC
    assert heise.ie_key() in ie_list

# Generated at 2022-06-24 12:29:45.362445
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Youtube embed
    heise = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_info = InfoExtractor.InfoExtractor.extract(heise)
    assert heise_info.ie_key() == 'Youtube'
    assert heise_info.type() == 'video'
    assert heise_info.id() == '6kmWbXleKW4'
    assert heise_info.title() == 'NEU IM SEPTEMBER | Netflix'
    assert heise_info.description() == 'md5:2131f3c7525e540d5fd841de938bd452'
    assert heise_info.timestamp

# Generated at 2022-06-24 12:29:46.236241
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()


# Generated at 2022-06-24 12:29:52.500798
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    heise_ie = HeiseIE()

    # tests extracting the title
    test_title = heise_ie._extract_title(
        '<div class="videoplayerjw" data-id="1_kkrq94sm" data-title="Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"><span class="vjs-loading-spinner"></span></div>')

    assert (test_title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")

    # tests extracting the description

# Generated at 2022-06-24 12:29:55.595168
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as e:
        assert False, "Constructor of class HeiseIE failed with exception:"+e.message


# Generated at 2022-06-24 12:30:01.842079
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    hie = HeiseIE()
    hie._download_webpage = lambda x, y: open('test/testdata/heise.html', 'rb').read()
    assert (hie.suitable(url) is not False)



# Generated at 2022-06-24 12:30:03.129674
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # HEISETEST: Heise IE test
    heise = HeiseIE()

# Generated at 2022-06-24 12:30:04.375203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert(bool(heiseIE))

# Generated at 2022-06-24 12:30:07.927453
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = url_HeiseIE_0
    ie = HeiseIE(url, YoutubeIE)
    assert ie.source_url == url
    assert ie.ie.name == 'youtube'
    ie = HeiseIE(url, KalturaIE)
    assert ie.source_url == url
    assert ie.ie.name == 'kaltura'

# Generated at 2022-06-24 12:30:18.103699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE("http://www.heise.de" +
    		       "/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert(test.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert(test._VALID_URL == r'^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html$')

# Generated at 2022-06-24 12:30:19.038343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

# Generated at 2022-06-24 12:30:21.274034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    print(obj.SUFFIX)

# Generated at 2022-06-24 12:30:21.861791
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:30:22.493621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:30:27.306353
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print (HeiseIE._build_url_result("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"))



if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-24 12:30:28.626085
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == "Heise"

# Generated at 2022-06-24 12:30:32.027342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')


# Generated at 2022-06-24 12:30:40.410509
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''Unit test for class HeiseIE'''
    heiseie = HeiseIE()
    # Test URL
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

    # Test invalid URLs
    assert heiseie._real_extract('http://localhost/video/') is False
    assert heiseie._real_extract('http://localhost/video/artikel/') is False
    assert heiseie._real_extract('http://localhost/video/artikel/abcd-2404147.html') is False
    assert heiseie._real_extract('http://localhost/video/artikel/12345.html') is False

    # Test valid

# Generated at 2022-06-24 12:30:42.028989
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test constructor of HeiseIE """
    # No runtime exception
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:30:43.621719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if constructor of HeiseIE class is working.
    HeiseIE('heise.de')

# Generated at 2022-06-24 12:30:44.516925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie=HeiseIE()

# Generated at 2022-06-24 12:30:45.395685
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie)

# Generated at 2022-06-24 12:30:49.968027
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert(repr(heiseIE) == "<HeiseIE: http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html>")

# Generated at 2022-06-24 12:30:52.189790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test creation of a new HeiseIE object.
    test_object = HeiseIE()
    assert test_object is not None


# Generated at 2022-06-24 12:30:53.125187
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance

# Generated at 2022-06-24 12:30:58.051373
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    args = [
        'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ]
    assert HeiseIE(*args)
    assert HeiseIE(args)


# Generated at 2022-06-24 12:31:09.147535
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:13.781206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    args = ['https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html']
    ie = HeiseIE()

    ie.init_heuristik()
    ie.init_downloader(*args)
    ie.downloader.process_info(ie.info_extractor.extract(*args))
    print('\n')


# Generated at 2022-06-24 12:31:16.229806
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:24.639622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie.video_id == '2404147'

# Generated at 2022-06-24 12:31:27.973038
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # if we can't download, let's not worry about this
    try:
        heiseie = HeiseIE()
    # TODO: remove bare except
    except:
        heiseie = HeiseIE()
    heiseie.get_info_extractor_list()

# Generated at 2022-06-24 12:31:29.664402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:31:30.525517
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisei = HeiseIE()

# Generated at 2022-06-24 12:31:37.268162
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test parsing of url in constructor
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    instance = HeiseIE(url=url)
    assert instance.id == "1_kkrq94sm"
    assert instance.name == "HeiseIE"
    assert instance.url == url

# Generated at 2022-06-24 12:31:39.713502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE(None)._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:31:40.804871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

# Generated at 2022-06-24 12:31:51.917717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE()._extract_info_dict('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html', '', 'heise.de')
    assert info['id'] == '1_ntrmio2s'
    assert info['ext'] == 'mp4'
    assert info['title'] == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    assert info['description'] == 'md5:47e8ffb6c46d85c92c310a512d6db271'
    assert info['timestamp'] == 1512470717

# Generated at 2022-06-24 12:31:54.435979
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:32:00.208700
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL ==
           r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert(ie.ie_key() == 'heise')
    assert(ie.ie_name() == 'heise.de')


# Generated at 2022-06-24 12:32:05.497516
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE(url)
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    return


# Generated at 2022-06-24 12:32:06.690987
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == "HeiseIE"

# Generated at 2022-06-24 12:32:15.581859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:20.970232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE()
    result = heise_ie.suitable(url)
    assert(result == True)
# Test for method _real_extract for HeiseIE

# Generated at 2022-06-24 12:32:26.809275
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for constructor
    heise = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heise != None
    assert heise.media_id == '1_kkrq94sm'

# Generated at 2022-06-24 12:32:37.360837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # standard case
    ie = HeiseIE('url', 'id', 'title', 'description', 'thumbnail', 'timestamp',
                 'formats')
    assert ie.url == 'url'
    assert ie.id == 'id'
    assert ie.title == 'title'
    assert ie.description == 'description'
    assert ie.thumbnail == 'thumbnail'
    assert ie.timestamp == 'timestamp'
    assert ie.formats == 'formats'
    # without timestamp
    ie = HeiseIE('url', 'id', 'title', 'description', 'thumbnail', None,
                 'formats')
    assert ie.url == 'url'
    assert ie.id == 'id'
    assert ie.title == 'title'
    assert ie.description == 'description'

# Generated at 2022-06-24 12:32:41.010106
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:48.916778
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:50.223286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create mock HeiseIE
    heise = HeiseIE()
    assert heise

# Generated at 2022-06-24 12:32:55.694309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")

# Generated at 2022-06-24 12:33:00.532221
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL == r'https?:\/\/(?:www\.)?heise\.de\/(?:[^\/]+\/)+[^\/]+-(?P<id>[0-9]+)\.html')
    # assert(ie._TESTS == [{}]) # TODO: add tests


# Generated at 2022-06-24 12:33:11.101060
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    print(ie._VALID_URL)
    print(ie._TESTS)
    print(ie._match_id('https://www.heise.de/ct/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))

# Generated at 2022-06-24 12:33:12.004925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-24 12:33:21.367424
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    # Input parameters
    url = 'http://www.heise.de/newsticker/meldung/IE-Edge-und-Flash-laufen-auch-auf-Huawei-Tablets-und-Smartphones-3968269.html' # URL of article with embedded video

    # Expected output
    expected_id = '3968269' # ID of the article
    expected_title = None # Title of the Video
    expected_description = None # None, because this information isn't provided by this site

    # Instantiate object of class HeiseIE
    heise = HeiseIE()

    # Check whether ID of article is extracted correctly
    assert heise._match_id(url) == expected_id
    # Check whether title of article is extracted correctly
    assert heise._real

# Generated at 2022-06-24 12:33:22.465353
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:28.398615
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import filecmp
    from youtube_dl.utils import DownloadError
    from youtube_dl.options import OptionError
    # Test exceptions
    with unittest.TestCase() as t:
        t.assertRaises(DownloadError, HeiseIE._search_regex, None, '<div></div>', 'non_existent', None)
        t.assertRaises(DownloadError, HeiseIE._html_search_meta, 'foo', '<html></html>')
        t.assertRaises(DownloadError, HeiseIE._html_search_regex, 'foo', '<html></html>', 'non_existent', None)

# Generated at 2022-06-24 12:33:29.819753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie
    assert ie._VALID_URL
    assert ie._TESTS

# Test for _real_extract method of class HeiseIE

# Generated at 2022-06-24 12:33:31.993406
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heiseIE = HeiseIE(InfoExtractor())
    assert heiseIE.ie_name == 'Heise'

# Generated at 2022-06-24 12:33:36.077724
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:42.915555
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    example_input_1 = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    heiseie = HeiseIE()
    assert heiseie._match_id(example_input_1) == "3700244"
    

# Generated at 2022-06-24 12:33:50.837029
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeIE
    from .kaltura import KalturaIE
    from .common import InfoExtractor
    heise = HeiseIE()
    assert isinstance(heise, InfoExtractor)
    assert heise._WORKING == True
    heise._WORKING = False
    assert heise.ie_key() == 'heise'
    assert heise.ie_key() in heise._ies
    assert heise.suitable(
        'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:33:52.532422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == u'heise'
    assert obj.ie_name() == u'heise.de'
    assert obj.ie_version() is not None
    assert obj.__doc__ is not None

# Generated at 2022-06-24 12:33:52.908969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:33:56.379797
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    result = heiseIE._real_extract("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    assert result
    assert result['title'] == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert result['id'] == '1_59mk80sf'

# Generated at 2022-06-24 12:33:57.295858
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h=HeiseIE()

# Generated at 2022-06-24 12:33:58.861665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:34:02.955885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heise.extractor_key == "heise"

# Generated at 2022-06-24 12:34:05.230447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    j = HeiseIE._VALID_URL
    assert j == ie._VALID_URL, 'You broke the regex in your constructor!'

# Generated at 2022-06-24 12:34:10.853415
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(None)
    obj.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    obj.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    obj.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:34:13.925102
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert h.IE_NAME=='heise'
    assert h.INFO_TEMPLATE=='%s - %s'

# Generated at 2022-06-24 12:34:19.431768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:34:24.335321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Paragraph from heise.de, URL from above
    heise_testurl = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_test_ie = HeiseIE(heise_testurl)
    assert heise_test_ie is not None

# Generated at 2022-06-24 12:34:35.061064
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'Heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:37.937446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    assert e.ie_key() == 'Heise'
    assert e.ie_key() in e.gen_extractors()

# Generated at 2022-06-24 12:34:38.749615
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass


# Generated at 2022-06-24 12:34:51.111325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    test_exporter = HeiseIE()

    def test_extractor(url):
        return test_exporter.suitable(url) and test_exporter.extract(url)

    def get_testcases():

        testcases = {}
        for ie, results in test_exporter._TESTS.items():
            for result in results:
                testcases[result['url']] = result['info_dict']
        return testcases

    testcases = get_testcases()
    for url, info_dict in testcases.items():
        try:
            result = test_extractor(url)
        except Exception as e:
            print("[-] Error " + str(e) + " while testing URL '" + url + "'")
            assert False
        testcases[url]['id'] = result['id']

# Generated at 2022-06-24 12:34:54.866526
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert(heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

test_HeiseIE()

# Generated at 2022-06-24 12:35:03.805985
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:35:04.254158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE

# Generated at 2022-06-24 12:35:05.392964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:35:07.473309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise =  HeiseIE()
    assert heise.__class__.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:35:18.499965
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # imports are placed here to avoid module import in class definition
    import urllib.request
    import urllib.parse
    import urllib.error


# Generated at 2022-06-24 12:35:22.514427
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()
    assert extractor.IE_NAME == 'heise'
    assert extractor._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:27.538592
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert h._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert h._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert h._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:35:30.695876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The constructor of the HeiseIE class must be invoked with a
    # string indicating the name of the class, or else an exception is raised.
    HeiseIE(HeiseIE.ie_key())

# Generated at 2022-06-24 12:35:40.599755
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_test = HeiseIE()
    # Tests for function _real_extract()
    test_cases_extract = [
        # Non-matching cases
        { 'url': 'http://www.heise.de/download/heise-online-tv-3416225.html'},
        { 'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'},
    ]
    for case_extract in test_cases_extract:
        with pytest.raises(ExtractorError, match=r'did not match'):
            ie_test._real_extract(case_extract['url'])

# Generated at 2022-06-24 12:35:45.638947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    print(ie._VALID_URL)

# Generated at 2022-06-24 12:35:47.149938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie = HeiseIE()
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:48.743948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.IE_NAME == 'heise:heise'

# Generated at 2022-06-24 12:35:49.680971
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-24 12:35:58.777036
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Data and expected values taken from
    # https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    heise_test_url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_test_id = '1_kkrq94sm'

# Generated at 2022-06-24 12:35:59.236887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:36:01.230629
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests if it returns none if the URL is not supported
    heise = HeiseIE()
    assert heise.suitable('https://www.heise.de/foo') is False

# Generated at 2022-06-24 12:36:02.372967
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    return inst._VALID_URL

# Generated at 2022-06-24 12:36:09.250145
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE(None)

# Generated at 2022-06-24 12:36:12.449144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    print(ie.ie_key())

# Generated at 2022-06-24 12:36:13.504453
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:36:16.610835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract("") == ""
    assert ie.extract("") == ""
    assert ie.extract("") == ""

# Generated at 2022-06-24 12:36:27.024606
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:36:27.993878
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:36:38.758523
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  ie = HeiseIE()
  ie.extract(url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
  ie.extract(url='https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')