

# Generated at 2022-06-24 12:26:39.664645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x

# Generated at 2022-06-24 12:26:40.521044
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('www.heise.de')

# Generated at 2022-06-24 12:26:42.424905
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:26:47.652019
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # HeiseIE._VALID_URL is dynamic, so test its constructor
    assert ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:26:52.942712
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._real_extract(
        "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-24 12:27:00.951326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for constructor of class HeiseIE
    # Test for HeiseIE with kaltura embed
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(kaltura_url)
    assert ie.suitable(kaltura_url) is True
    # Test for HeiseIE with youtube embed
    youtube_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    ie = HeiseIE(youtube_url)
    assert ie.suitable

# Generated at 2022-06-24 12:27:07.509760
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for parsing its URL.
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    HeiseIE(extract_flat=True)._match_id(url)
    # Test for extracting its title.
    HeiseIE(extract_flat=True)._real_extract(url)

# Generated at 2022-06-24 12:27:08.494911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE constructor
    assert HeiseIE

# Generated at 2022-06-24 12:27:18.903214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # load testdata
    import os
    import json
    import time

    testdata_path = os.path.join(os.path.dirname(__file__), 'test', 'data')
    webpage = open(os.path.join(testdata_path, 'heise_test_url')).read(-1)

    print('Testing get_video_info of HeiseIE ...')

    # create a new instance of the class
    heise_ie_instance = HeiseIE()

# Generated at 2022-06-24 12:27:24.243592
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:27:32.308604
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_raises(RegexNotFoundError, HeiseIE, 'foo', 'http://www.heise.de/test-test')
    assert_raises(RegexNotFoundError, HeiseIE, 'foo', 'http://www.heise.de/test-test.html')
    assert_raises(RegexNotFoundError, HeiseIE, 'foo', 'http://www.heise.de/test-test-test-test-test-test-test.html')
    assert_raises(RegexNotFoundError, HeiseIE, 'foo', 'http://www.heise.de/test-test-test-test-test-test-test-test.html')

    assert_raises(RegexNotFoundError, HeiseIE, 'foo', 'https://www.heise.de/test-test')
   

# Generated at 2022-06-24 12:27:35.628213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Run a test to confirm existence of the class HeiseIE.
    """
    ie = HeiseIE('http://www.heise.de/')
    assert (ie is not None), 'Object creation failed.'
    assert (ie.name == 'Heise'), 'Name of the object is incorrect.'

# Generated at 2022-06-24 12:27:46.103385
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:49.741402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._WORKING == True


# Generated at 2022-06-24 12:28:00.633817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # single
    assert HeiseIE._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-24 12:28:03.920186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Tastatur-mit-Dreh-Display-auf-Kickstarter-2794424.html'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'Heise'
    assert ie.IE_DESC == 'heise online Video'

# Generated at 2022-06-24 12:28:10.223881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    result = heise_ie.extract(url)
    for key, value in result.items():
        print(key + ": " + str(value))



# Generated at 2022-06-24 12:28:16.498036
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Typical case, a video with a Kaltura embed
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    assert ie.source_url == url
    assert ie.url == 'kaltura:2238431:1_kkrq94sm'
    assert ie.ext == 'mp4'
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:28:17.861293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert IE.ie_key() == 'heise'

# Generated at 2022-06-24 12:28:18.854693
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE() != None)

# Generated at 2022-06-24 12:28:24.773467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from pytube import YouTube
    video = YouTube('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert video.filename == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    assert video.caption_tracks == []



# Generated at 2022-06-24 12:28:25.763327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance

# Generated at 2022-06-24 12:28:26.871589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Tests creation of HeiseIE object
    test_HeiseIE = HeiseIE()
    assert type(test_HeiseIE) == HeiseIE

# Generated at 2022-06-24 12:28:27.441826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:29.632635
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-24 12:28:30.537485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()


# Generated at 2022-06-24 12:28:31.691587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()


# Generated at 2022-06-24 12:28:39.873382
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._VALID_URL = HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:41.384298
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Just make sure HeiseIE can be constructed with the given things.
    HeiseIE(None)

# Generated at 2022-06-24 12:28:44.497949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_key() in heise_ie._WORKING_IE

# Generated at 2022-06-24 12:28:53.012347
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:04.220742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert len(ie._TESTS) == 8

# Generated at 2022-06-24 12:29:05.823107
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(demo_HeiseIE()) is not None



# Generated at 2022-06-24 12:29:09.824155
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie != None


# Generated at 2022-06-24 12:29:12.168393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:29:13.749940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:29:25.000547
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:27.014954
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de')
    assert ie.SUCCESS == 'OK'

# Generated at 2022-06-24 12:29:36.066035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE()._VALID_URL.match('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE()._VALID_URL.match('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')


# Generated at 2022-06-24 12:29:46.319604
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for one video
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE()
    name = heiseIE.IE_NAME
    ieVersion = heiseIE.ie._VERSION
    ieVersionRequired = heiseIE.ie.IE_DESC[name]['ie_version']
    ieVersionRequiredParse = heiseIE.ie._VERSION_REQUIRED
    ieVersionParse = heiseIE.ie._version
    url_valid = heiseIE._VALID_URL
    # Test on valid url

# Generated at 2022-06-24 12:29:56.688821
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test for class HeiseIE """
    # check if all public functions of HeiseIE are covered by at least
    # one test
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:30:01.608532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(ie.TITLE == ie.ie_key())
    assert(ie.ie._downloader.params['nocheckcertificate'] == '1')

# Generated at 2022-06-24 12:30:07.964334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url == ie._VALID_URL
    assert ie._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")["id"] == "1_kkrq94sm"

# Generated at 2022-06-24 12:30:09.088589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE(InfoExtractor)

# Generated at 2022-06-24 12:30:10.095441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    f = HeiseIE()
    assert f is not None

# Generated at 2022-06-24 12:30:14.835285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hIE = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert isinstance(hIE, HeiseIE)

# Generated at 2022-06-24 12:30:20.785132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.name == 'heise'
    assert ie.IE_NAME == 'heise'


# Generated at 2022-06-24 12:30:21.855788
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE()



# Generated at 2022-06-24 12:30:27.130095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    d1 = HeiseIE()
    #print(d1.__module__)
    #print(d1.__class__.__name__)
    assert (d1.__module__ == 'youtube_dl.extractor.heise')
    assert (d1.__class__.__name__ == 'HeiseIE')
    assert (d1.ie_key() == 'Heise')


## Unit tests for URL extraction

# Generated at 2022-06-24 12:30:28.191054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _ = HeiseIE(HeiseIE.ie_key())

# Generated at 2022-06-24 12:30:29.069669
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    test.suite()

# Generated at 2022-06-24 12:30:30.152668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:34.162043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    downloader = HeiseIE()
    downloader._download_webpage('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html','3959893')
    assert True == True

# Generated at 2022-06-24 12:30:39.819289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    test_url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    h._real_extract(test_url)

# Generated at 2022-06-24 12:30:43.115916
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for the constructor
    test_instance = HeiseIE('http://some_url')
    assert(isinstance(test_instance, HeiseIE))
    assert(isinstance(test_instance, InfoExtractor))


# Generated at 2022-06-24 12:30:50.981363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    hexie = HeiseIE()
    hexie.set_helper(HeiseIE)
    match = hexie._real_extract(url)
    assert(match['id'] == '1_kkrq94sm')
    assert(match['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    assert(match['timestamp'] == 1512734959)
    assert(match['upload_date'] == '20171208')

# Generated at 2022-06-24 12:30:52.356094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:58.562540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        e = HeiseIE()
        print('e = ', e)
    except:
        print('Error 1')
        raise

    with pytest.raises(Exception):
        HeiseIE('https://heise.de/')

    with pytest.raises(Exception):
        HeiseIE('https://heise.de/', 'Kaltura id')

    HeiseIE('https://heise.de/', 'only_matching')

# Generated at 2022-06-24 12:31:09.734002
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == (
        r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    )

# Generated at 2022-06-24 12:31:16.812699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_HeiseIE(test_number, url, expected_id):
        info_extractor = HeiseIE()
        match = info_extractor._VALID_URL.match(url)
        assert match, "Could not extract _VALID_URL from input url: %s" % url
        # Simulate the behaviour of the real _real_extract function
        video_id = info_extractor._match_id(url)
        assert video_id == expected_id, "video_id for test %d is wrong" % test_number
        return True

    fail_count = 0
    test_number = 0

    # Test 1: c't uplink 3.3
    test_number += 1

# Generated at 2022-06-24 12:31:27.585773
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.extract('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is None

# Generated at 2022-06-24 12:31:34.362322
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_downloads import opts
    from .test_downloads import _make_result


# Generated at 2022-06-24 12:31:44.526911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == True
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-24 12:31:46.089080
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test.
    """
    assert callable(HeiseIE)
    ie = HeiseIE(None)
    assert ie.suitable("") == False


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:31:49.906545
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, HeiseIE)
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'heise'
    assert ie.website_slug == 'heise'


# Generated at 2022-06-24 12:31:58.788722
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:06.702781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:32:10.154132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:18.138904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/Nachgehakt-Was-tut-die-c-t-App-alles-im-Hintergrund-3700244.html'
    _HeiseIE = HeiseIE(url)
    assert _HeiseIE.url == 'https://www.heise.de/video/artikel/Nachgehakt-Was-tut-die-c-t-App-alles-im-Hintergrund-3700244.html'
    assert _HeiseIE.video_id == '3700244'
    assert _HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:20.575431
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == (HeiseIE._VALID_URL)
    assert ie._TESTS == (HeiseIE._TESTS)

# Generated at 2022-06-24 12:32:21.151280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:32:21.828626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:32:33.703719
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if not HeiseIE._WORKING:
        raise ValueError('The heise extractor is broken.')
    ie = HeiseIE()
    ie._download_webpage = lambda x: {'content': '<html/><html/>'}
    ie._search_regex = lambda x,y: '1'
    ie._download_xml = lambda x: '<xml/>'
    res = ie._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert res['id'] == '1'
    assert res['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-24 12:32:37.836720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

    # Test the constructor
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:32:39.192763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE, type)

# Generated at 2022-06-24 12:32:40.080159
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global HeiseIE
    ie = HeiseIE()

# Generated at 2022-06-24 12:32:43.979269
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:32:54.853040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None
    assert HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') is not None
    assert HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') is not None
    assert Heise

# Generated at 2022-06-24 12:33:04.343873
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_ie = HeiseIE()
    assert heise_ie._match_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'
    assert heise_ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:33:04.888347
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:33:06.938647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_inst = HeiseIE()
    assert ie_inst.ie_key() == 'heise'

# Generated at 2022-06-24 12:33:09.037239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-24 12:33:09.630258
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:16.720491
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.txt')



# Generated at 2022-06-24 12:33:18.798662
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/', {})
    assert ie.website == 'Heise'

# Generated at 2022-06-24 12:33:19.661840
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:22.772952
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .__main__ import HeiseIE
    assert HeiseIE.__name__ == 'HeiseIE'
    assert HeiseIE.__doc__ is not None

# Unit test function for class HeiseIE

# Generated at 2022-06-24 12:33:32.070637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Returns true if HeiseIE object is created without any exceptions"""
    
    url_test = 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    heise_IE = HeiseIE()
    
    assert heise_IE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_IE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise_IE._T

# Generated at 2022-06-24 12:33:34.076733
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE=InfoExtractor()
    assert isinstance(IE.get_info_extractor("HeiseIE"), HeiseIE)

# Generated at 2022-06-24 12:33:35.540654
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    loader = HeiseIE()
    assert loader.__class__ is HeiseIE

# Generated at 2022-06-24 12:33:47.218229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:56.852422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    youtube_url = 'https://www.youtube.com/watch?v=6kmWbXleKW4'
    heise_video = HeiseIE(youtube_url, 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

    assert heise_video.yt_urls[0] == youtube_url
    assert heise_video.id == '6kmWbXleKW4'
    assert heise_video.title == 'NEU IM SEPTEMBER | Netflix'
    assert heise_video.description == 'md5:2131f3c7525e540d5fd841de938bd452'

# Generated at 2022-06-24 12:33:57.637745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:34:03.321872
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert(ie.__class__.__name__=='HeiseIE')
    assert(ie.IE_DESC=='heise.de')
    assert(ie._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert(ie._TESTS[3]['only_matching']==True)

# Generated at 2022-06-24 12:34:09.872582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:10.812898
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        pass

# Generated at 2022-06-24 12:34:20.837332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # create an object of class HeiseIE
    test = HeiseIE()

    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_video_id = '1_kkrq94sm'
    test_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    test_timestamp = 1512734959
    test_upload_date = '20171208'
    test_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

    # check the HeiseIE specific fields
    assert test._VALID_URL

# Generated at 2022-06-24 12:34:21.434068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:22.103691
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:24.337291
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    HeiseIE(url)

# Generated at 2022-06-24 12:34:35.060447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:37.978125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert isinstance(obj, HeiseIE)

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-24 12:34:40.689380
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:34:45.970657
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test for HeiseIE constructors """
    kwargs = {
        'url': "https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html",
        'video_id': '3214137',
    }
    assert HeiseIE.suitable(kwargs['url']) is True
    heise_ie = HeiseIE(**kwargs)
    assert heise_ie.video_id == kwargs['video_id']
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:48.992746
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL.startswith('http://www.heise.de/')

# Generated at 2022-06-24 12:34:53.553295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '3700244'
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    assert url == HeiseIE._VALID_URL % video_id

# Generated at 2022-06-24 12:35:02.315171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert(heise.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'))
    assert(heise.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'))
    assert(heise.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'))

# Generated at 2022-06-24 12:35:03.154761
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:35:06.497224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    assert HeiseIE
    # without arguments
    assert HeiseIE()
    # with argument
    assert HeiseIE('http://www.heise.de')
    # with some keyword arguments
    assert HeiseIE(url='http://www.heise.de')

# Generated at 2022-06-24 12:35:14.033817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
        heiseIE = HeiseIE(url)
        assert heiseIE.url == url
    except Exception as e:
        print(str(e))
        assert False
    print('test passed ...')

# Generated at 2022-06-24 12:35:16.162368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # clear history in InfoExtractor
    ie._downloader = None
    ie.IE_NAME = 'Heise'
    assert(ie.ie_key() == 'Heise')
    assert(ie.IE_NAME == 'Heise')
    assert(ie.working == True)

# Generated at 2022-06-24 12:35:20.383126
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:35:31.249624
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE, InfoExtractor)

test_video_id = '1_kkrq94sm'
test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
test_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
test_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
test_timestamp = 1512734959
test_upload_date = '20171208'

# Generated at 2022-06-24 12:35:34.204658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # self.assertIsInstance(ie, YoutubeIE)
    # or:
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 12:35:34.749006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()


# Generated at 2022-06-24 12:35:35.454308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:35:39.497929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    heise_ie = HeiseIE({'test_arg': 'test_arg_value'})
    assert heise_ie._downloader == {'test_arg': 'test_arg_value'}

# Generated at 2022-06-24 12:35:42.738052
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.test(test_HeiseIE.__name__, test_HeiseIE._TESTS,
            test_HeiseIE.__doc__, __file__)

# Generated at 2022-06-24 12:35:51.045093
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    heise_ie = HeiseIE(config={})
    heise_ie = HeiseIE(config={'downloader/http_chunk_size': '23'})
    heise_ie = HeiseIE(config={'fallback_urls': False})
    heise_ie = HeiseIE(config={'fallback_urls': True})
    heise_ie = HeiseIE(params={'noplaylist': True})
    heise_ie = HeiseIE(params={'noplaylist': False})
    heise_ie = HeiseIE(params={'nocheckcertificate': True})
    heise_ie = HeiseIE(params={'nocheckcertificate': False})

# Generated at 2022-06-24 12:35:51.625759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:55.946294
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    except Exception as ex:
        raise Exception('Unable to init object: {0}'.format(ex))

# Generated at 2022-06-24 12:35:57.396959
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL
    assert HeiseIE._TESTS

# Generated at 2022-06-24 12:35:58.758356
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:36:01.018689
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	ie = HeiseIE()
	assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:08.300065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE("HeiseIE", "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html", {}, None)
    assert info_extractor.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert info_extractor.name == "HeiseIE"
    assert info_extractor.downloader is None
    assert info_extractor.params == {}

# Generated at 2022-06-24 12:36:17.891318
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_name = HeiseIE.__name__
    # check if the class is defined
    obj1 = globals().get(class_name)
    if obj1 is None:
        assert False, 'could not find class named: %s' % class_name

    # check inheritance
    obj2 = eval('kaltura.KalturaIE')
    assert issubclass(obj1, obj2)
    obj2 = eval('youtube.YoutubeIE')
    assert issubclass(obj1, obj2)
    obj2 = eval('info_extractor.InfoExtractor')
    assert issubclass(obj1, obj2)
    return



# Generated at 2022-06-24 12:36:27.820497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie is not None
    info = ie._real_extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") is True

# Generated at 2022-06-24 12:36:32.846034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heiseIE.ie_key() == 'Heise'
    assert heiseIE.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:42.529715
# Unit test for constructor of class HeiseIE