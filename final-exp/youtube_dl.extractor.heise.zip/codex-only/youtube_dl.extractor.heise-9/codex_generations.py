

# Generated at 2022-06-24 12:26:53.108267
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:26:55.959538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  ie = HeiseIE(None)
  assert ie.IE_NAME == "heise"
  assert ie.IE_DESC == "heise.de"

# Generated at 2022-06-24 12:26:58.322536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test without a constructor
    HeiseIE()
    assert HeiseIE.ie_key() == "Heise"
    assert HeiseIE.ie_key_short() == "Heise"

# Generated at 2022-06-24 12:26:59.943993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:27:10.096428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE = HeiseIE(url=url)
    assert heiseIE.valid_url == True
    assert heiseIE.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heiseIE.valid_url == True
    assert hasattr(heiseIE, '_VALID_URL') == True
    assert heiseIE.id == '1_kkrq94sm'
    assert heiseIE.title

# Generated at 2022-06-24 12:27:10.875391
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:27:20.011626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.(?:de|de/(?:[^/]+/)+[^/]+)-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:29.800480
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE instance has all fields as expected
    heiseie = HeiseIE()
    assert isinstance(heiseie, InfoExtractor)
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie._NETRC_MACHINE == "heise"

# Generated at 2022-06-24 12:27:31.813488
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test requires the websites being actually up
    # assert HeiseIE().extract(sample_url)
    return

# Generated at 2022-06-24 12:27:33.194026
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:35.598213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE(None)
    except TypeError:
        pass
    except Exception:
        assert False, 'Unexpected exception raised when running HeiseIE class instance'

# Generated at 2022-06-24 12:27:36.551201
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:27:37.138843
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:42.550831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.video_id_re == r'(?P<id>\d+)'
    assert ie.ie_key() == ie.extractor_key()
    assert ie.extractor_key() == 'Heise'

# Generated at 2022-06-24 12:27:48.077332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()._extract_url(url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert heise == ["1_59mk80sf"], "Constructor of class HeiseIE failed"

# Generated at 2022-06-24 12:27:50.698498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check HeiseIE constructor signature
    # noinspection PyUnresolvedReferences
    from youtube_dl.extractor.heise import HeiseIE
    assert HeiseIE.__init__.__code__.co_varnames == ('self', 'url')

# Generated at 2022-06-24 12:27:58.436817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE, 'ie_key')
    assert HeiseIE.ie_key() == 'heise'
    assert hasattr(HeiseIE, '_VALID_URL')
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert hasattr(HeiseIE, '_TESTS')
    assert isinstance(HeiseIE._TESTS, list)

# Generated at 2022-06-24 12:27:59.285011
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor()).ie_key() == 'heise'

# Generated at 2022-06-24 12:27:59.954786
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:08.991174
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:13.122541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable(heise._VALID_URL)
    assert heise.IE_NAME == 'heise'
    assert heise.IE_DESC == 'heise.de'
    assert heise.ie._WORKING

# Generated at 2022-06-24 12:28:23.216846
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for abstract class for Heise IE
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # test for abstract class for Heise IE
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    # test for Heise IE
    ie = HeiseIE()

# Generated at 2022-06-24 12:28:28.262801
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("url")
    # test if has class attributes
    assert ie.IE_NAME == ie.__class__.IE_NAME
    assert ie.IE_DESC == ie.__class__.IE_DESC
    assert ie._VALID_URL == ie.__class__._VALID_URL
    assert ie._TESTS == ie.__class__._TESTS

# Generated at 2022-06-24 12:28:36.567499
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # First test for empty input
    assert HeiseIE('', {}) is not None

    # Second test for invalid input
    test_dict = {'url': 'http://www.heise.de/'}
    assert HeiseIE('http://www.heise.de/', test_dict) is None

    # Third test for valid input
    test_dict = {'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'}
    assert HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html', test_dict)

# Generated at 2022-06-24 12:28:38.453670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.set_downloader(None)
    ie.set_downloader(ie.get_downloader()(ie.get_downloader()))

# Generated at 2022-06-24 12:28:39.988994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("HeiseIE")

# Test case for function _make_kaltura_result

# Generated at 2022-06-24 12:28:47.000988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_name == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() in IE_NAME_TO_CLASS.keys()
    assert ie.webpage_url_regex() == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.video_id_regex() == ie.webpage_url_regex()
    assert ie.embed_webpage_url_regex() == None
    assert ie.embed_url_regex() == None

# Generated at 2022-06-24 12:28:57.789367
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE(object).extract_info(
        'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert result['id'] == '1_59mk80sf'
    assert result['title'] == 'c\'t uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten'
    assert result['description'] == 'md5:f50fe044d3371ec73a8f79fcebd74afc'
    assert result['thumbnail'] is not None
    assert result['timestamp'] == 1517567237

# Generated at 2022-06-24 12:29:00.387513
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        instance = HeiseIE()
    except Exception as ex:
        assert False, 'failed to create instance of HeiseIE'
        print(type(ex))

# Generated at 2022-06-24 12:29:01.343997
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # TODO
    return

# Generated at 2022-06-24 12:29:05.479213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test that HeiseIE instance is constucted properly
    test_inst = HeiseIE()

    # Test that test_inst is instance of HeiseIE
    assert isinstance(test_inst, HeiseIE)

# Generated at 2022-06-24 12:29:16.137804
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    name = 'Heise'
    ie = HeiseIE(name)
    assert ie.name == name
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:17.934842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    with pytest.raises(TypeError):
        HeiseIE()

# Generated at 2022-06-24 12:29:21.364374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  """constructor of a class"""
  heise_extractor = HeiseIE()
  assert heise_extractor.ie_key() == 'heise'


# Generated at 2022-06-24 12:29:22.000131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""

    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:29:23.320914
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == "Heise"

# Generated at 2022-06-24 12:29:24.880028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.name == "heise"


# Generated at 2022-06-24 12:29:26.629023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, InfoExtractor)

# Generated at 2022-06-24 12:29:31.245323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == "heise"
    assert ie.IE_DESC == "heise.de, heise Medien"
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:32.014175
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:29:35.512374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE), 'Constructor returns not an instance of HeiseIE'

# Generated at 2022-06-24 12:29:39.845359
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   heise = HeiseIE()
   assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:29:41.873870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heiseIE is not None, "Constructor of class HeiseIE failed"


# Generated at 2022-06-24 12:29:45.333716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info=HeiseIE().extract_info('http://www.heise.de')
    assert info['id'] == 'http://www.heise.de'
    assert info['title'] == 'http://www.heise.de'
    assert info['description'] == 'http://www.heise.de'
    assert info['thumbnail'] == 'http://www.heise.de'
    assert info['timestamp'] == 'http://www.heise.de'
    assert info['formats'] == 'http://www.heise.de'

# Generated at 2022-06-24 12:29:45.906769
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:51.334482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True
    assert info_extractor.suitable("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html") == True


# Generated at 2022-06-24 12:29:54.517994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE({})
    assert obj._VALID_URL == HeiseIE._VALID_URL
    assert obj._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:29:55.170476
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:01.636896
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    class MockHeiseIE(HeiseIE):
        def _real_extract(self, url):
            # This method makes sure that the test only succeeds when
            # real is called from the constructor
            raise NotImplementedError

    heiseie = MockHeiseIE("http://www.heise.de/")
    heiseie.extract("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-24 12:30:02.565693
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.constructor()

# Generated at 2022-06-24 12:30:07.573010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()._make_kaltura_result("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert test['_type'] == "url_transparent" and test['ie_key'] == "Kaltura" and test['url'] == "kaltura:1_kkrq94sm"

# Generated at 2022-06-24 12:30:13.164013
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	data = HeiseIE().extract("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
	assert 'title' in data
	assert 'id' in data
	assert 'formats' in data

# Generated at 2022-06-24 12:30:14.560633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:15.168875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:16.519180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert type(obj) == HeiseIE

# Generated at 2022-06-24 12:30:17.873417
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert not obj is None

# Generated at 2022-06-24 12:30:19.249710
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == "HeiseIE"


# Generated at 2022-06-24 12:30:28.900291
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.url == "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:31.052858
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise'

# Generated at 2022-06-24 12:30:32.331183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:32.928112
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:30:38.765209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.valid_url("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert not heiseIE.valid_url("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-24 12:30:43.821017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE(url)
    html = ie.extract(url, 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert html['id'] == '1_kkrq94sm'

# Generated at 2022-06-24 12:30:46.101879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    heiseie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:30:47.036623
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  from .common import test_IE;
  test_IE(HeiseIE)()

# Generated at 2022-06-24 12:30:48.528013
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj.ie_key() == 'Heise'

# Generated at 2022-06-24 12:30:49.012895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:49.500618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:30:50.304407
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create object for unit test
    HeiseIE()

# Generated at 2022-06-24 12:30:51.886186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i.ie_key() == 'heise'

# Generated at 2022-06-24 12:30:52.821209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor"""
    assert HeiseIE

# Generated at 2022-06-24 12:30:56.618324
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS
    assert HeiseIE().__name__ == HeiseIE.__name__

# Generated at 2022-06-24 12:30:57.963475
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-24 12:31:00.572689
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .static_test import test_static_suite
    test_static_suite(HeiseIE, HeiseIE._TESTS)

# Generated at 2022-06-24 12:31:11.155221
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    #assert heise._VALID_URL == '^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:13.714909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert ie._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:14.484450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:31:19.735340
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print('# Unit test for class HeiseIE')
    # Extraction from a c't uplink podcast (Kaltura embed)
    print('test_HeiseIE: Kaltura embed')

    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_video = HeiseIE()
    assert(heise_video != None)
    assert(heise_video.suitable(url) == True)
    assert(heise_video.IE_NAME == 'heise')
    assert(heise_video.IE_DESC == 'heise.de')

    filename = heise_video.extract(url)
    assert(filename != None)

# Generated at 2022-06-24 12:31:21.940330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert isinstance(h, InfoExtractor)


# Generated at 2022-06-24 12:31:30.100500
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert obj.getId() == "1_kkrq94sm"
    assert obj.getDescription() == "Auch diesmal gab es eine Menge Feedback zu unseren Themen. Besonders heftig diskutiert wurde der Artikel über die Zukunft des Internets. Ein Leser ist sicher: Das Internet wird auch in Zukunft die Freiheit der Bürger sichern. Wir haben uns für unseren Podcast mit..."

# Generated at 2022-06-24 12:31:35.100682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # TODO: implement _TESTS

# Generated at 2022-06-24 12:31:36.951482
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:38.454222
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.set_downloader(None)
    assert ie._downloader == None
    ie.downloader = None
    assert ie._downloader == None

# Generated at 2022-06-24 12:31:39.488732
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(test_HeiseIE)

# Generated at 2022-06-24 12:31:40.578695
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-24 12:31:41.622153
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    print (inst)

# Generated at 2022-06-24 12:31:52.551195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._VALID_URL = r'http://www\.heise\.de/(?P<id>[^\?]+)'

# Generated at 2022-06-24 12:31:59.590537
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_utils import _sort_formats

# Generated at 2022-06-24 12:32:03.376497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()  # Should not raise
    assert ie.ie_key() == 'Heise'
    assert ie.ie_codec() == 'Heise'
    assert ie.codec_desc() == 'Video'
    assert ie.plugin_version() == '0.0.1'

# Generated at 2022-06-24 12:32:04.552390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..test import get_testcases
    return get_testcases(__name__)

# Generated at 2022-06-24 12:32:05.757794
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test that HeiseIE can be constructed.
    """
    assert HeiseIE

# Generated at 2022-06-24 12:32:11.246813
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' # NOQA
    heise = HeiseIE()
    heise._real_initialize()
    heise.suitable(url)
    heise.url_result(url)
    heise._real_extract(url)

# Generated at 2022-06-24 12:32:12.873309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check that the class is in fact constructed
    ie = HeiseIE(None)
    assert ie



# Generated at 2022-06-24 12:32:17.513706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('http://www.heise.de/ct/ausgabe/2014-13-Spiele-2250231.html')
    assert not HeiseIE.suitable('http://www.heise.de/ct/aktuell/')

# Generated at 2022-06-24 12:32:22.343703
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Step 1: Testing the constructor of class HeiseIE"""
    heise_ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heise_ie != None


# Generated at 2022-06-24 12:32:29.000214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test constructor of class HeiseIE.
    """
    #Check for class existence
    ie = HeiseIE(None)
    #Check whether it implements the list of attributes of its class
    assert ie.IE_NAME == 'Heise'
    assert ie.IE_DESC == 'Heise'
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:32:30.766363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.desc = "desc"

# Generated at 2022-06-24 12:32:39.366927
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:32:40.399316
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.get_name() == 'heise'

# Generated at 2022-06-24 12:32:48.472170
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:59.664698
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    direct_url = "http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html"
    video_id = "3214137"
    title = "c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    description = "Podcast: c't uplink, Folge 3.3 – Owncloud, Tastaturen und Peilsender Smartphone"
    upload_date = "20171208"
    extractor = HeiseIE(direct_url)
    ie_info = extractor.extract(direct_url)
    assert ie_info['id'] == video_id
    assert ie_info['title'] == title
    assert ie_info['description'] == description
    assert ie_info['upload_date'] == upload_date

# Generated at 2022-06-24 12:33:00.262178
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h is not None

# Generated at 2022-06-24 12:33:00.652503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:33:02.007320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert isinstance(test_obj, HeiseIE)

# Generated at 2022-06-24 12:33:07.066623
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # You need to provide the following args to test the constructor of this class
    # since it is an abstract class.
    #
    # WARNING: You need to provide a youtube video id!!!!!
    # This test is not valid for now. 
    print('\nbegin test for HeiseIE constructor:')
    print('TODO: current HeiseIE is an abstract class, '
          'test for constructor of an abstract class is not valid.\n')
    print('finish testing!\n')



# Generated at 2022-06-24 12:33:09.889031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("www.heise.de")
    assert ie.url_re == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:33:10.551232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert "HeiseIE" == HeiseIE.ie_key()

# Generated at 2022-06-24 12:33:11.445181
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # unit test for constructor
    x = HeiseIE()

# Generated at 2022-06-24 12:33:12.619221
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE(None)
    assert isinstance(heise_ie, HeiseIE)

# Generated at 2022-06-24 12:33:14.884585
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    for url, test in HeiseIE._TESTS:
        content = HeiseIE().get_content_for_test(url)
        assert content == test

# Generated at 2022-06-24 12:33:15.985919
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), InfoExtractor)

# Generated at 2022-06-24 12:33:18.492874
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if the parameter url is required
    with pytest.raises(TypeError):
        HeiseIE()

# Unit tests for method extract() of class HeiseIE

# Generated at 2022-06-24 12:33:28.337390
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:34.583120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Class HeiseIE constructor unit test"""
    heiseie = HeiseIE()
    assert(heiseie.ie_key() == 'heise')
    assert(heiseie.supported_extractors() == [
        HeiseIE.ie_key(),
        YoutubeIE.ie_key(),
        KalturaIE.ie_key()])
    assert(heiseie._VALID_URL == HeiseIE._VALID_URL)

# Generated at 2022-06-24 12:33:46.466964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # Python 3
        from unittest import mock
    except ImportError:
        # Python 2
        import mock
    with mock.patch('youtube_dl.utils.sanitize_open',
                    mock.mock_open(read_data='{"foo": "bar"}')) as m:
        ydl = YoutubeDL({})
        with ydl:
            ie = HeiseIE(ydl)
            ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:33:56.277962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:57.063861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	HeiseIE()

# Generated at 2022-06-24 12:34:06.060062
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test of class HeiseIE.
    """
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE()
    assert heiseIE == HeiseIE
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseIE.__name__ == 'Heise'
    assert heiseIE.ie_key() == 'heise'
    assert heiseIE.url_result(url, 'Heise')
    assert heiseIE

# Generated at 2022-06-24 12:34:11.584451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from .test_downloads import TestDownloads
        from .kaltura import KalturaIE

        TestDownloads.__test__ = False # Force no test for TestDownloads

        KalturaIE.__test__ = True # Force test for KalturaIE
        TestDownloads.test_KalturaIE()

        TestDownloads.__test__ = True # Force test for TestDownloads
        TestDownloads.test_HeiseIE()

        TestDownloads.__test__ = False
    except ImportError:
        print('Unable to test HeiseIE, please check it manually')

# Generated at 2022-06-24 12:34:21.609330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert(ie.SUCCESS == 0)
    assert(ie.FAILED == 1)
    assert(ie.IGNORE == -1)

    assert(ie.IE_NAME == 'heise')
    assert(ie.IE_DESC == 'heise')

    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:34:25.470375
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    expected_ie_key = 'Heise'
    expected_ie_desc = 'Video website of a german publisher'
    expected_ie = [
        {
            'ie_key': expected_ie_key,
            'ie_desc': expected_ie_desc,
            'ie_module_cn': 'HeiseIE',
            'ie_module_name': 'HeiseIE',
            'ie_module_path': 'heise.py'
        }
    ]
    assert expected_ie == ie._ies


# Generated at 2022-06-24 12:34:32.417638
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is not None
    assert HeiseIE._VALID_URL('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None

# Generated at 2022-06-24 12:34:36.113768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:34:39.618166
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    heiseie.set_downloader(None)
    heiseie._downloader = None
    print(heiseie.test())
    assert heiseie.test() == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:34:43.575008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('','')
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-24 12:34:45.252028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None,{})._real_extract('')

# Generated at 2022-06-24 12:34:48.380351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = heiseie.HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'


# Generated at 2022-06-24 12:34:50.073844
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:34:52.068065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE.suitable(HeiseIE._VALID_URL))

# Generated at 2022-06-24 12:34:55.387522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'



# Generated at 2022-06-24 12:35:02.361361
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test class HeiseIE."""
    # Enter valid URLs for your unit tests

# Generated at 2022-06-24 12:35:04.138790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    # test if constructor worked properly
    assert heise is not None

# Generated at 2022-06-24 12:35:15.849212
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:35:20.737852
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == "heise"
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.IE_DESC == 'heise online'

# Generated at 2022-06-24 12:35:26.801854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.number_of_tests() == 6
    assert ie.REQUIRE_TITLE == "Podcast: "
    assert ie.REQUIRE_DESCRIPTION == "md5:c934cbfb326c669c2bcabcbe3d3fcd20"
    assert ie.BAD_EMBED_REGEXES == [
        r'<embed\b[^>]+\btype=["\']application/x-shockwave-flash["\'][^>]*>',
        r'<p\b[^>]+\bclass=["\']error[^>]*>',
        r'<iframe\b[^>]+\byoutube',
    ]

# Generated at 2022-06-24 12:35:27.190559
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:35:30.938542
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert i.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:35:41.655604
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUFFIX == 'heise.de'
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise Video'
    assert ie.ie_key() == 'heise'
    assert ie.VERSION == '0.3'
    assert ie.VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)?(?P<id>[0-9]+)\.html'
    assert ie.webpage_url_regex == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)?(?P<id>[0-9]+)\.html'
    assert isinstance(ie.video_id_regex, type(re.compile('')))

# Generated at 2022-06-24 12:35:45.631282
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:53.284252
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert isinstance(ie, HeiseIE)
    assert ie.url == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    assert ie.video_id == "2403911"

# Generated at 2022-06-24 12:36:04.096004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    HeiseIE._VALID_URL, HeiseIE._TESTS
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert len(ie._TESTS) == 7
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['md5'] == '46b9c3b3aa76c7a24d18ebcc7f2a2dbf'


# Generated at 2022-06-24 12:36:10.663861
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""


# Generated at 2022-06-24 12:36:14.031618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:21.913218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    # test for private method _extract_title()
    assert ie._extract_title('<title>Die Title</title>', '123') == 'Die Title'

    # test for private method _extract_id()
    assert ie._extract_id('<a href="http://www.heise.de/123.html">Link</a>') == '123'
    assert ie._extract_id('<a href="http://www.heise.de/video/artikel/123.html">Link</a>') == '123'
    assert ie._extract_id('<a href="http://www.heise.de/video/artikel/123-1234.html">Link</a>') == '123-1234'

# Generated at 2022-06-24 12:36:30.752736
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:36:32.306282
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Unit test class for constructor of HeiseIE

# Generated at 2022-06-24 12:36:39.601633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_Heise = HeiseIE()
    assert ie_Heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie_Heise._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:36:41.759574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    ie.ie_key()  # TODO Remove this line when dropping Python 2 support
    ie._real_initialize()
