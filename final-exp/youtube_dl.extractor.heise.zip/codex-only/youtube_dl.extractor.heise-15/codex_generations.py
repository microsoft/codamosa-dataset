

# Generated at 2022-06-24 12:26:47.306131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL is not None
    assert HeiseIE._TESTS is not None
    assert len(HeiseIE._TESTS) > 0
    test1 = HeiseIE._TESTS[0]
    assert test1['url'] is not None
    assert test1['info_dict'] is not None


# Generated at 2022-06-24 12:26:57.723925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_utility.assertEquals(
        HeiseIE.ie_key('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'),
        'heise'
    )
    unit_test_utility.assertEquals(
        HeiseIE.ie_key('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'),
        'heise'
    )

# Generated at 2022-06-24 12:27:06.047582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # url = url of video
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    # url is url of video
    assert ie.suitable(url)
    assert ie.extract(url)
    # url is not url of video
    assert not ie.suitable("http://heise.de")

# Generated at 2022-06-24 12:27:07.344485
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE
    assert heiseIE


# Generated at 2022-06-24 12:27:10.703808
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.ie_key() == 'heise:2404147'

# Generated at 2022-06-24 12:27:16.210169
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(HeiseIE):
        def _download_webpage(self, *args, **kwargs):
            return '<html>'

    ie = TestHeiseIE()
    assert ie.suitable(ie.IE_NAME, 'https://www.heise.de/foo/bar-123.html')
    assert not ie.suitable(ie.IE_NAME, 'https://www.heise.de/foo/')

# Generated at 2022-06-24 12:27:19.699960
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.server_url() == 'www.heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?P<id>[^\s<]+\.html)'
    assert ie._TESTS

# Generated at 2022-06-24 12:27:24.752173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for template
    post_data = {'test': 'foo'}
    url = 'http://example.com/'
    heise_ie = HeiseIE(post_data)
    assert heise_ie._download_webpage(url)
    heise_ie = HeiseIE(post_data)
    assert heise_ie._download_xml(url)



# Generated at 2022-06-24 12:27:34.575451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test all constructors of the class HeiseIE
    url = HeiseIE._VALID_URL

    # Test with all the class variables
    ie = HeiseIE(url)
    assert ie.url == url
    assert ie.video_id == ie._match_id(url)
    assert ie.title == ie._html_search_meta(
        ('fulltitle', 'title'), ie.webpage, default=None)
    assert ie.description == ie._og_search_description(
        ie.webpage, default=None) or ie._html_search_meta(
        'description', ie.webpage)
    assert ie.webpage == ie._download_webpage(url, ie.video_id)

# Generated at 2022-06-24 12:27:44.532739
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:27:47.121545
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie is not None
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:27:48.372278
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE != None

# Generated at 2022-06-24 12:27:52.583949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie=HeiseIE()
    assert heise_ie


# Unit test method for heise_ie.extract
# Note: We need to do an end to end test of the extract method since it involves integration with
#       other class methods

# Generated at 2022-06-24 12:27:59.212685
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    test_ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert test_ie.name == 'heise'
    assert test_ie.title == 'NEU IM SEPTEMBER | Netflix'
    assert test_ie.description == "Abonnieren Sie hier unseren Netflix-Newsletter, um keine Neuigkeiten zu verpassen:\n\nhttp://nflx.it/29qBUt7"
    assert test_ie.duration == 14
    assert test_ie.timestamp == 1504110400

# Generated at 2022-06-24 12:28:08.540774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:09.923074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(InfoExtractor)
    assert heiseie

# Generated at 2022-06-24 12:28:13.665738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.IE_NAME == 'heise'
    assert heise.IE_DESC == 'heise video'

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:28:23.791444
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def test_for_url(url):
        heise_ie = HeiseIE()
        assert(heise_ie.suitable(url))

    test_for_url('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    test_for_url('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:28:24.383566
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-24 12:28:25.763426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-24 12:28:36.160056
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:28:40.471637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None,'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE(None,'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:28:50.101777
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

    # Test regular expression
    assert ie.regex.match('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.regex.match('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:28:51.593774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:28:58.200726
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert t.url.startswith("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:29:02.048984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:29:13.456530
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__=="__main__":
        print("Test Class HeiseIE")
    url="http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    info=HeiseIE.extract_url(url)
    assert info["id"] == "1_kkrq94sm"
    assert info["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info["upload_date"] == "20171208"

# Generated at 2022-06-24 12:29:24.797755
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:26.965881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(None)
    assert isinstance(heise, HeiseIE)

# Generated at 2022-06-24 12:29:33.246146
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of class HeiseIE"""
    heise = HeiseIE()
    assert(heise.count_video_id == 0)
    assert(heise.count_video_content == 0)
    assert(heise.count_video_url == 0)
    assert(heise.count_video_title == 0)

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:29:39.654233
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = video = HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    assert video.__class__.__name__ == 'HeiseIE'


# Generated at 2022-06-24 12:29:41.617173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # HeiseIE()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 12:29:42.924817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:29:46.277865
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise video'
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:29:48.663636
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('Heise', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:29:49.982948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE
    YoutubeIE
    KalturaIE

# Generated at 2022-06-24 12:29:51.685984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie is not None

# Generated at 2022-06-24 12:29:54.470754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE(None)

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:30:03.250240
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:07.295086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise', HeiseIE, 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.type == 'video'
    assert ie.id == '1_kkrq94sm'

# Generated at 2022-06-24 12:30:17.294108
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:17.928498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:22.477434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)._extract_url('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:30:24.941178
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if constructor does not raise exception
    # for any provided url
    ie = HeiseIE(HeiseIE._VALID_URL)
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:30:34.136871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor).suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    HeiseIE(InfoExtractor).suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    HeiseIE(InfoExtractor).suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:30:44.941562
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test suite for the constructor of class HeiseIE """


# Generated at 2022-06-24 12:30:45.639812
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()

# Generated at 2022-06-24 12:30:53.772500
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:31:04.896470
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE(None)

    except TypeError as e:
        print('test_HeiseIE: TypeError expected')

    else:
        print('test_HeiseIE: TypeError not raised')

    # Unit test for parse of URL
    try:
        HeiseIE.match_url('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

    except RegexNotFoundError as e:
        print('test_HeiseIE.match_url: RegexNotFoundError expected')

    else:
        print('test_HeiseIE.match_url: RegexNotFoundError not raised')

    # Unit test for _

# Generated at 2022-06-24 12:31:09.972887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Initialize and use the class HeiseIE."""
    ie = HeiseIE(None)
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')



# Generated at 2022-06-24 12:31:17.146935
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert heise_ie._TESTS[0]['info_dict']['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert heise_ie._TESTS[0]['info_dict']['timestamp'] == 1512734959

# Generated at 2022-06-24 12:31:21.945134
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:31:22.657664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie != None

# Generated at 2022-06-24 12:31:23.249959
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:31:25.871991
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:31:36.078799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]["url"] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE._TESTS[0]["md5"] == "4190b70fffdd24c6e1971b6c4f6d9e9f"

# Generated at 2022-06-24 12:31:37.308567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:31:38.580543
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:49.950924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.url_result.get('url').startswith('kaltura:')
    assert ie.url_result.get('id') == '1_kkrq94sm'
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.url_result.get('url') == 'https://www.youtube.com/watch?v=6kmWbXleKW4'
   

# Generated at 2022-06-24 12:32:01.102901
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert ie.url == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert ie.video_id == '6kmWbXleKW4'
    assert ie.title == 'NEU IM SEPTEMBER | Netflix'
    assert ie.description == 'md5:2131f3c7525e540d5fd841de938bd452'
    assert ie.timestamp == 1504042400
    assert ie.upload

# Generated at 2022-06-24 12:32:03.686977
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	IE = HeiseIE("Heise")
	print("HeiseIE.__init__(HeiseIE) = " + str(IE))
	assert IE.__dict__ == {'name': 'Heise'}

# Generated at 2022-06-24 12:32:11.158722
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.match(r'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.extract(r'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:32:12.937157
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # initializes default binaries
    dl = downloader.Downloader()

    # tests that there is a constructor
    assert HeiseIE(dl) is not None



# Generated at 2022-06-24 12:32:20.231548
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') is not None
    assert ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') is not None

# Generated at 2022-06-24 12:32:21.494145
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:32:24.470177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:32:30.176598
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor of class HeiseIE
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# UnitTests for HeiseIE

# Generated at 2022-06-24 12:32:33.142130
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__doc__ is not None, "No docstring defined"
    # Ensure constructor is not defined
    with pytest.raises(AttributeError):
        HeiseIE()

# Generated at 2022-06-24 12:32:40.337092
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:41.224942
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    globals()['HeiseIE']()

# Generated at 2022-06-24 12:32:49.071213
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:50.357797
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:32:54.320169
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/ausgabe/2016-3-Security-Interview-2759678.html'
    heise = HeiseIE()
    heise.suitable(url)

# Generated at 2022-06-24 12:32:55.640661
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:32:56.659229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:33:02.810925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:33:13.499132
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:22.331495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:26.133337
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())._real_extract(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:33.158165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
        from youtube_dl.utils import SearchInfoExtractor
        import sys
        import os
        import pytest
        sys.path.insert(0, os.getcwd())
        path = os.path.abspath(__file__)
        cwd = path.split('test_Heise')[0]
        sys.path.insert(0, cwd)
        # test HeiseIE constructor (no exception)
        HeiseIE()
        # test extractor
        with pytest.raises(SearchInfoExtractor):
            HeiseIE().extract_info('https://www.heise.de/ct/artikel/')

# Generated at 2022-06-24 12:33:35.232214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:33:47.018659
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test video from RSS feed
    video_id = '3948963'
    url = 'http://www.heise.de/video/artikel/%s.html' % video_id
    heise_ie = HeiseIE(url)
    assert heise_ie.video_id == '3948963'
    assert heise_ie.video_url == url
    assert heise_ie.video_title is None
    assert heise_ie.video_description is None
    assert heise_ie.video_thumbnail is None
    assert heise_ie.video_timestamp is None
    assert heise_ie.video_formats == []
    assert heise_ie.get_video_formats == None
    assert heise_ie.get_video_id == None

# Generated at 2022-06-24 12:33:47.578209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:33:57.206186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['md5'] == 'b7d0ddac6dbf7a2f79a025c46374fea0'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie

# Generated at 2022-06-24 12:34:06.197998
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_constructor(url, ie_downloader):
        video_id = HeiseIE._match_id(url)
        webpage = ie_downloader._download_webpage(url, video_id)

        def extract_title(default=NO_DEFAULT):
            title = ie_downloader._html_search_meta(
                ('fulltitle', 'title'), webpage, default=None)
            return title

        title = extract_title()

        container_id = ie_downloader._search_regex(
            r'<div class="videoplayerjw"[^>]+data-container="([0-9]+)"',
            webpage, 'container ID')


# Generated at 2022-06-24 12:34:08.008089
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert repr(HeiseIE)


# Generated at 2022-06-24 12:34:10.847283
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor test
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() in ie.extractors

# Generated at 2022-06-24 12:34:12.192667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(InfoExtractor()), HeiseIE)



# Generated at 2022-06-24 12:34:22.287195
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:34:23.373379
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import heise
    assert heise.HeiseIE

# Generated at 2022-06-24 12:34:26.734073
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    try:
        ie.extract(False)
        raise Exception('Expected Exception was not thrown')
    except:
        pass

# Generated at 2022-06-24 12:34:36.734932
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    json = {"title": "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"}

# Generated at 2022-06-24 12:34:41.834654
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case of HeiseIE
    heise_test_case = HeiseIE(
        HeiseIE._VALID_URL, HeiseIE._download_webpage)

    # Check attribute `_VALID_URL`
    assert heise_test_case._VALID_URL == HeiseIE._VALID_URL

    # Check attribute `_download_webpage`
    assert heise_test_case._download_webpage == HeiseIE._download_webpage


# Generated at 2022-06-24 12:34:46.224234
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:34:47.963190
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), HeiseIE)

# Generated at 2022-06-24 12:34:56.956239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    yt_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    yt_url_id = YoutubeIE._extract_id(yt_url)
    assert(yt_url_id == '6kmWbXleKW4')
    kaltura_url = ('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    kaltura_url_id = KalturaIE._extract_url(kaltura_url)

# Generated at 2022-06-24 12:35:00.950647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.url == "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"

# Generated at 2022-06-24 12:35:02.177641
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The constructor is tested by extraction of real video
    # so no specific unit test needed
    pass

# Generated at 2022-06-24 12:35:09.465691
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE instance
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:12.585341
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # This assert is necessary to avoid this test fail in function "detect_ie_conflicts"
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:35:16.648648
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if '_match_id' method of HeiseIE class is working correctly
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    expected_id = '3814130'
    instance_of_HeiseIE = HeiseIE(url)
    result = instance_of_HeiseIE._match_id(url)
    assert result == expected_id, "The match_id method should give '{0}' instead of '{1}'!".format(expected_id, result)


# Generated at 2022-06-24 12:35:18.452126
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m_instance = HeiseIE()
    assert m_instance.ie_key() == 'heise'
    assert m_instance.ie_name() == 'Heise'
    assert m_instance.ie_version() == __version__

# Generated at 2022-06-24 12:35:29.428627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    e.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    e.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    e.suitable('http://www.heise.de/ct/artikel/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html')

# Generated at 2022-06-24 12:35:33.535235
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.download('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:35:43.524023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # method __init__ of class HeiseIE
    test_obj = HeiseIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:48.097455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    example = 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom'
    downloader = HeiseIE(url=example)
    assert isinstance(downloader, HeiseIE)


# Generated at 2022-06-24 12:35:51.437899
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import sys
    if sys.version_info[0]>=3:
        assert issubclass(HeiseIE, YoutubeIE)
    else:
        assert HeiseIE is not None

# Generated at 2022-06-24 12:35:53.628552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heise = HeiseIE()
	assert heise.extractor.IE_DESC == u'Heise'


# Generated at 2022-06-24 12:35:56.238610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None and isinstance(HeiseIE, type)

# Generated at 2022-06-24 12:36:05.804513
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html"
    assert ie._TESTS[0]['url'] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:36:06.822794
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie.VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:36:10.375115
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import json
    with open('tests/heise/data') as data_file:    
        data = json.load(data_file)
        heiseIE = HeiseIE(data)
        info_dicts = heiseIE._real_extract(data['url'])
        for key in info_dicts:
            print(key + ': ' + str(info_dicts[key]))

# Generated at 2022-06-24 12:36:11.823266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None


# Generated at 2022-06-24 12:36:16.983667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE = HeiseIE(url)
    heiseIE._get_video(url)

# Generated at 2022-06-24 12:36:18.596734
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:36:23.955785
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert instance._TESTS[1]['md5'] == 'e403d2b43fea8e405e88e3f8623909f1'

# Generated at 2022-06-24 12:36:31.844816
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = "2404251"
    title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    description = 'c\'t - Heise Online: Partnertest: Sicherheitsprogramme - Heise Online'
    timestamp = 1512734959
    url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie = HeiseIE()
    assert classmethod(ie.suitable).__func__(ie, url)

# Generated at 2022-06-24 12:36:32.803271
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()

# Generated at 2022-06-24 12:36:36.251043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:36:44.207028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE

    assert (
        HeiseIE._build_url_result(
            'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
        .get('url') == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')