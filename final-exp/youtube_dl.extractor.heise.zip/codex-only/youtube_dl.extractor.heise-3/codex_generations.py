

# Generated at 2022-06-24 12:26:42.132174
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html').test()

# Generated at 2022-06-24 12:26:43.018821
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:26:45.573841
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-24 12:26:46.640383
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()



# Generated at 2022-06-24 12:26:51.567580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert (ie.get_info('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')['id'] == '1_ntrmio2s')
    assert (ie.get_info('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')['id'] == '1_kkrq94sm')

# Generated at 2022-06-24 12:26:52.415301
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:26:56.277377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Instantiation
    HeiseIE()

    # Constructor
    obj = HeiseIE(None)

    # Callback method
    _real_extract(obj, obj.url)

    # Static methods
    _extract_urls()

# Generated at 2022-06-24 12:26:57.293820
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:27:08.774010
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:27:09.885047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:15.310941
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    result = ie._extract_url(url)

# Generated at 2022-06-24 12:27:16.128263
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	assert(HeiseIE.ie_key() == 'heise')

# Generated at 2022-06-24 12:27:22.871420
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    # extract the video information
    video = ie.extract()
    # check if the video has the expected title
    assert(video.get('title') == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone")
    # check if the video has the expected id
    assert(video.get('id') == "1_kkrq94sm")

# Generated at 2022-06-24 12:27:30.162633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise_info_extractor = HeiseIE(url)
    assert heise_info_extractor.url == url
    assert heise_info_extractor.title == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    assert heise_info_extractor.id == '1_ntrmio2s'

# Generated at 2022-06-24 12:27:39.706451
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:43.528902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:46.437191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == 'heise'
    assert heiseie.ie_key() in HeiseIE.ie_key_map()

# Generated at 2022-06-24 12:27:50.092930
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	import sys
	import os
	sys.path.insert(0, os.path.relpath(
		os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))
	from youtube_dl.utils import parse_duration
	from youtube_dl.YoutubeDL import YoutubeDL
	
	heise_ie = YoutubeDL().get_info_extractor('heise')
	assert isinstance(heise_ie, HeiseIE)

# Generated at 2022-06-24 12:27:50.687753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:27:53.103882
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.ie_key() == 'heise'

# Generated at 2022-06-24 12:28:03.429874
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:28:08.453879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    ie = HeiseIE()
    ie._download_webpage = lambda *args, **kwargs: object()
    assert ie._real_extract(url)

# Generated at 2022-06-24 12:28:13.708753
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie.extract(url)
    print('Extract succeeded for', ie.__name__)

# Generated at 2022-06-24 12:28:23.835838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_downloader import FakeYDL
    from .extractors.kaltura import KalturaIE
    from .extractors.youtube import YoutubeIE
    from .aes import (aes_cbc_decrypt, aes_cbc_encrypt, aes_decrypt_text)

    test_obj = HeiseIE()
    test_obj._downloader = FakeYDL(params={})

    # Test id extraction

# Generated at 2022-06-24 12:28:24.821358
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _test_class_constructor(HeiseIE)

# Generated at 2022-06-24 12:28:29.325974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None, 'http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie

# Generated at 2022-06-24 12:28:31.190738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:28:32.730318
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, InfoExtractor)

# Generated at 2022-06-24 12:28:34.181300
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Test to run all Unit tests of class HeiseIE

# Generated at 2022-06-24 12:28:35.604010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:28:36.418333
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # init HeiseIE
    a = HeiseIE()

# Generated at 2022-06-24 12:28:40.218875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .__main__ import main
    from .common import test_main_function

    test_main_function(main, [
        '-v', '--write-pages',
        '--portal', 'heise',
        '--username', 'test@example.com',
        '--password', 'test_password',
        '--video-id', '2187993',
        '--location', 'Potsdam'
    ])

# Generated at 2022-06-24 12:28:41.725511
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	ie = HeiseIE()
	assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:28:49.482424
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # basic test
    heise = HeiseIE()
    assert heise.extractor_key == 'heise'
    assert heise.ie_key() == 'Heise'

    # test url resolving
    url = heise._resolve_url(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # this should be handled by KalturaIE
    assert heise._match_id(url) == None
    # TODO: add test case for youtube and custom xml api

# Generated at 2022-06-24 12:28:53.179591
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:29:02.376074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    ie.extract('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:29:04.219345
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:29:09.996095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_name() == 'heise.de'

# Generated at 2022-06-24 12:29:18.501363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.video_id == '2403911'
    assert ie.url == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    if __name__ == '__main__':
        print('Unit test successful!')

# Generated at 2022-06-24 12:29:27.660589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # This test case is used to test the constructor of class HeiseIE
    # Some attributes of the class HeiseIE that can be tested:
    #   _VALID_URL
    #   IE_NAME
    #   _TESTS
    #   _GEO_COUNTRIES
    #   _GEO_BYPASS
    #   IE_DESC
    #   _WORKING
    # In this test case, the target is to test whether the attribute _VALID_URL
    # can extract the correct values from the given url and then combine the
    # attribute IE_NAME with the extracted values to form

# Generated at 2022-06-24 12:29:36.176313
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert (ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert (ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert (ie._TESTS[0]['info_dict']['upload_date'] == '20171208')

# Generated at 2022-06-24 12:29:44.241220
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	#test url
	url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
	#init class
	heiseExtractor = HeiseIE()
	#test if url is valid
	assert heiseExtractor.suitable(url)
	#extract video
	test = heiseExtractor.extract(url)
	#assert if video is extracted
	assert test.get('id') == '1_kkrq94sm'



# Generated at 2022-06-24 12:29:51.545532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import YoutubeIE
    from . import KalturaIE
    # For testing, construct instance of HeiseIE class
    ie = HeiseIE(
        YoutubeIE,
        KalturaIE
    )
    # For testing, obtain heise video ID
    video_id = ie._match_id(ie._TESTS[0]['url'])
    # For testing, obtain heise video url
    url = ie._VALID_URL % video_id
    # For testing, obtain heise webpage
    webpage = ie._download_webpage(url, video_id)
    # For testing, obtain heise video title
    title = ie._html_search_meta(('fulltitle', 'title'), webpage)
    # For testing, obtain heise video description
    description = ie._html_search_meta('description', webpage)
    #

# Generated at 2022-06-24 12:29:53.520666
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InstanceTest

    ie = InstanceTest(HeiseIE)
    ie.run()

# Generated at 2022-06-24 12:29:58.700467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    video_id = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_info = ie.extract(video_id)
    print(video_info)

# Generated at 2022-06-24 12:30:00.229803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'



# Generated at 2022-06-24 12:30:05.105668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()
    video.url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert video.video_id == '1_kkrq94sm'

# Generated at 2022-06-24 12:30:07.265245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj
    assert obj.__class__.__name__ == 'HeiseIE'

# Generated at 2022-06-24 12:30:08.063095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:30:11.125144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:30:14.384416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:24.557199
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

    yt_urls = heiseie._extract_youtube(
        '<iframe width="560" height="315"'
        ' src="https://www.youtube.com/embed/vX2WulF8jJg" frameborder="0"'
        ' allow="autoplay; encrypted-media" allowfullscreen></iframe>')
    assert len(yt_urls) == 1
    assert yt_urls[0] == 'https://youtube.com/watch?v=vX2WulF8jJg'

    assert heiseie._extract_youtube(
        '<iframe width="560" height="315" src="http://example.com" ></iframe>') == []


# Generated at 2022-06-24 12:30:27.478484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _test_instances as _test_instances
    heise_test_instances = _test_instances(HeiseIE)
    assert heise_test_instances

# Generated at 2022-06-24 12:30:36.364837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    A unit test for HeiseIE
    """
    # Two valid URLs for Heise's site

# Generated at 2022-06-24 12:30:39.728419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as e:
        print("Test failed: ", e)
        return False
    return True


# Generated at 2022-06-24 12:30:41.646932
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:30:44.941571
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test,
    """
    _ = HeiseIE(InfoExtractor())
    if __name__ == '__main__':
        test_func = lambda: test_HeiseIE()
        for test in [test_func]:
            test()

# Generated at 2022-06-24 12:30:47.332393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    ie.extract_links("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-24 12:30:48.003265
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:30:49.005209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-24 12:30:51.171385
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == "Heise"
    assert ie.ie_name() == "Heise"
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:02.737305
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    heise.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:31:04.761450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL('https://www.heise.de/?-2211219.html') == '2211219'

# Generated at 2022-06-24 12:31:14.098824
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE._VALID_URL = 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+(?P<id>[0-9]+)\.html'
    heiseIE._download = lambda _: '{}'

# Generated at 2022-06-24 12:31:19.557310
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:31:27.346556
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert hasattr(heise_ie, '_VALID_URL')
    assert isinstance(heise_ie._VALID_URL, HeiseIE._VALID_URL.__class__)

    assert hasattr(heise_ie, '_TESTS')
    assert isinstance(heise_ie._TESTS, HeiseIE._TESTS.__class__)

    assert hasattr(heise_ie, '_real_extract')
    assert isinstance(heise_ie._real_extract, HeiseIE._real_extract.__class__)

# Generated at 2022-06-24 12:31:27.813839
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:31:32.212429
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE().extract_info(HeiseIE()._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html').groupdict())
    # import json
    # print(json.dumps(info, indent=4))
    assert info['_type'] != 'url_transparent'

# Generated at 2022-06-24 12:31:33.603740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE1 = HeiseIE()
    heiseIE2 = HeiseIE()
    assert heiseIE1 == heiseIE2

# Generated at 2022-06-24 12:31:37.389329
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert a is not None
    pass

# Generated at 2022-06-24 12:31:48.715116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'
    assert ie.supported_extensions() == []
    assert ie.can_extract_url(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:31:50.831387
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _ = HeiseIE("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-24 12:31:53.919661
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:31:55.599568
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.ie_key() == 'heise')


# Generated at 2022-06-24 12:31:59.759364
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE(url)

# Generated at 2022-06-24 12:32:04.611195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:05.483548
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit = HeiseIE()

# Generated at 2022-06-24 12:32:06.318281
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    q = HeiseIE()

# Generated at 2022-06-24 12:32:15.232295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.is_suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.is_suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.is_suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:32:16.725104
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-24 12:32:18.616948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE_inst = HeiseIE(None)
    assert isinstance(HeiseIE_inst, InfoExtractor)


# Generated at 2022-06-24 12:32:25.848805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    HeiseIE('http://www.heise.de/ct/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:32:31.396334
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-24 12:32:38.230515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_html_search_meta')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_og_search_description')
    assert hasattr(ie, '_og_search_thumbnail')


# Generated at 2022-06-24 12:32:42.801541
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testurl = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise = HeiseIE()
    assert heise._match_id(testurl) == '3700244'

# Generated at 2022-06-24 12:32:52.374948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    m = HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    m = HeiseIE("http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    m = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    return

# Generated at 2022-06-24 12:32:54.163079
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None


# Generated at 2022-06-24 12:32:55.910657
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(HeiseIE._VALID_URL)

# Generated at 2022-06-24 12:32:57.745449
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.IE_NAME == "heise"

# Generated at 2022-06-24 12:33:01.711936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE(HeiseIE._build_url_result(url))

# Generated at 2022-06-24 12:33:09.000314
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE().info_extract('http://www.heise.de/video/artikel/Buchvorstellung-von-Alle-anderen-sind-schon-da-3627985.html')
    assert info
    info = HeiseIE().info_extract('http://www.heise.de/video/artikel/Gefahr-durch-gehackte-Handys-und-Smartphone-Ortung-3895852.html')
    assert info
    info = HeiseIE().info_extract('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert info

# Generated at 2022-06-24 12:33:10.141117
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'Heise'

# Generated at 2022-06-24 12:33:19.827888
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test class HeiseIE"""

# Generated at 2022-06-24 12:33:20.652526
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-24 12:33:21.462313
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE({}) != None

# Generated at 2022-06-24 12:33:26.045090
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Just testing if the constructor for this class works
    # This is done by not providing it with any input
    # And expecting it to raise an error because of that
    try:
        ie = HeiseIE()
        ie.extract()
    except:
        pass
    else:
        assert False

# Generated at 2022-06-24 12:33:32.493531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._download_webpage = lambda *args, **kwargs: None
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'Heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:35.779362
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        heiseie = HeiseIE()
        print("Created object of HeiseIE.")
    except:
        raise AssertionError("Unable to create object of HeiseIE.")



# Generated at 2022-06-24 12:33:43.637902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == "heise"
    assert ie.ie_key() == "heise"
    assert ie.homepage == "http://heise.de"
    assert ie.hostname == "heise.de"
    assert ie.description == (
        "heise online - IT-News, Nachrichten und Hintergründe zu "
        "Computer, Telekommunikation, Software und mehr - heise online")

# Generated at 2022-06-24 12:33:51.074688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    expected_result = (
        {
            'id': '1_kkrq94sm',
            'ext': 'mp4',
            'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
            'timestamp': 1512734959,
            'upload_date': '20171208',
            'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
        },
        {
            'skip_download': True,
        })


# Generated at 2022-06-24 12:33:53.836958
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.VALID_URL == HeiseIE._VALID_URL
    assert ie.IE_NAME == "Heise"
    assert ie.TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:33:57.600227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    globals()['KalturaIE'] = type('KalturaIE', (object,), {})
    globals()['YoutubeIE'] = type('YoutubeIE', (object,), {})
    heise_ie = HeiseIE({})
    assert heise_ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:33:58.861682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert repr(ie) == '<HeiseIE>'

# Generated at 2022-06-24 12:34:07.742254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    self = HeiseIE()
    self.suite = 'c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten'
    self.content_id = 3959893
    self.content_id_str = str(self.content_id)
    self.url = url

# Generated at 2022-06-24 12:34:13.125351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.hostname == "heise.de"
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html'
    assert hie.IE_DESC == "heise.de"
    assert hie.title == "HeiseIE"

# Generated at 2022-06-24 12:34:23.184428
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    video_id = test_HeiseIE._match_id(url)
    webpage = test_HeiseIE._download_webpage(url, video_id)
    title = test_HeiseIE._html_search_meta(('fulltitle', 'title'), webpage, default=None)
    description = test_HeiseIE._og_search_description(webpage, default=None) or test_HeiseIE._html_search_meta('description', webpage)
    kaltura_url

# Generated at 2022-06-24 12:34:23.982880
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE.test()

# Generated at 2022-06-24 12:34:26.687742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()
    assert(video._VALID_URL == HeiseIE._VALID_URL)

# Generated at 2022-06-24 12:34:27.964155
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()
    assert t.extract != None

# Generated at 2022-06-24 12:34:29.263008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:31.596575
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, HeiseIE)


# Generated at 2022-06-24 12:34:32.503130
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()


# Generated at 2022-06-24 12:34:38.055366
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Existence of the class should be proved by an object
    instance = HeiseIE()
    # Proving methods of class
    instance.extract({"_type": "url", "url": "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"})

# Generated at 2022-06-24 12:34:41.455707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Construct an instance of HeiseIE
    ie = HeiseIE()

    # Test whether it is instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:42.742074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:34:44.240904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE(None)
    assert isinstance(h, HeiseIE)

# Generated at 2022-06-24 12:34:49.470242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test to assert HeiseIE constructor
    # Only checks if the constructor of HeiseIE succeeds, not the functionality
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:34:58.976235
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:04.857959
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(
        HeiseIE._VALID_URL, {
            'validate_cert': 'false',
            'format': 'bestvideo',
            'proxy': 'http://192.168.1.1:8000',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        }
    )

# Generated at 2022-06-24 12:35:06.858255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# make sure HeiseIE can be initialized
	heise_ie = HeiseIE()

# Generated at 2022-06-24 12:35:08.327752
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	heiseIE = HeiseIE()
	assert heiseIE.extract("") == None

# Generated at 2022-06-24 12:35:10.417225
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:35:11.840337
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE('heise'), InfoExtractor)

# Generated at 2022-06-24 12:35:13.171896
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise != None


# Generated at 2022-06-24 12:35:20.581748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    # test valid url
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'  # noqa
    # test invalid url
    assert heiseie._VALID_URL != 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'  # noqa



# Generated at 2022-06-24 12:35:28.149124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test empty constructor
    try:
        heiseIE = HeiseIE('url')
    except:
        pass

    # Test parameter url
    url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    heiseIE = HeiseIE(url)
    assert(heiseIE._real_extract(url)['id'] == '1_ntrmio2s')

# Generated at 2022-06-24 12:35:33.708699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Two examples of test urls, one for kaltura embed, and the other for youtube embed
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:35:43.070394
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    ie.extract("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-24 12:35:45.713121
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE().IE_NAME == HeiseIE.IE_NAME

# Generated at 2022-06-24 12:35:48.612464
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:35:50.599793
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    return ie

# Generated at 2022-06-24 12:35:51.706759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    sut = HeiseIE()

# Generated at 2022-06-24 12:35:52.835110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:35:53.422993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:36:02.055397
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    instance = class_('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert instance.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert instance.name == 'HeiseIE'

# Generated at 2022-06-24 12:36:10.041214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Check if HeiseIE can be created.
    """
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import NO_DEFAULT
    instance = HeiseIE()
    assert instance
    assert instance._VALID_URL
    assert instance._TESTS
    assert instance._download_webpage
    assert instance._html_search_meta
    assert instance._html_search_regex
    assert instance._match_id == HeiseIE._match_id
    assert instance._og_search_description
    assert instance._og_search_thumbnail
    assert instance._real_extract == HeiseIE._real_extract
    assert instance._search_regex
    assert instance._sort_formats
    assert instance._type
    assert instance.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:19.844860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:36:29.275460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:36:32.802084
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:38.719717
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    inst = class_()
    assert inst.__name__ == 'Heise'
    assert inst.ie_key() == 'Heise'
    assert inst.server_encoding == 'iso-8859-15'
    assert inst.host() == 'www.heise.de'
    assert inst.description == 'Heise-Videobereich'
    assert inst.age_limit == 0

# Generated at 2022-06-24 12:36:45.338762
# Unit test for constructor of class HeiseIE