

# Generated at 2022-06-24 12:26:46.076404
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.name == 'Heise'
    assert ie.IE_NAME == 'heise'
    assert ie._VIDEO_RE == ie._VALID_URL


# Generated at 2022-06-24 12:26:49.367484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    instance = HeiseIE()
    assert instance.ie_key() == "Heise"
    assert instance.ie_name() == "Heise"

# Generated at 2022-06-24 12:26:50.471200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, InfoExtractor)

# Generated at 2022-06-24 12:26:57.365763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

    # Test regular expression
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

    # Test parse_url
    assert heise_ie._parse_url("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == "1_kkrq94sm"

# Generated at 2022-06-24 12:27:08.852963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Stub test case to allow the travis-ci server to test the
    HeiseIE constructor.
    """
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:27:14.510765
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = {
        'kaltura_url': 'kaltura:2238431:1_n0n2c2lw',
        'yt_urls': ['https://www.youtube.com/watch?v=y8Jp1j01EeY'],
    }
    heiseie = HeiseIE(None, x)
    print(heiseie)

# Generated at 2022-06-24 12:27:22.326770
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_heise = HeiseIE()
    assert ie_heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html', "Test _VALID_URL"
    assert ie_heise._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', "Test _TESTS(first item)"
    assert ie_heise._TESTS[0]['info_dict']['id'] == '1_kkrq94sm', "Test _TESTS(id of first item)"
   

# Generated at 2022-06-24 12:27:26.318632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    item = HeiseIE({})
    assert item.ie_key() == 'Heise'
    assert item.test() is False
    assert item.working() is False


# Generated at 2022-06-24 12:27:36.780503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Init object
    try:
        heiseie_object = HeiseIE();
    except:
        print('Init Object of HeiseIE failed!')
        exit(-1)

    # Test 1
    # Check if the URL is suitable for the class
    # by using _VALID_URL
    def _valid_url(url):
        return heiseie_object._VALID_URL.match(url)
    
    test_URL = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_result = _valid_url(test_URL)
    if test_result is not None:
        print('Test 1 passed!')
    else:
        print

# Generated at 2022-06-24 12:27:43.223356
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:27:51.713877
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor
    import unittest

    class TestHeiseIE(unittest.TestCase):
        """Unit test class for HeiseIE"""

        def setUp(self):
            self.ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')


# Generated at 2022-06-24 12:27:52.592806
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:03.050426
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    # Test URLs
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:28:06.616486
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for class HeiseIE
    HEISE_INSTANCE = HeiseIE()
    if HEISE_INSTANCE == None:
        print('HEISE_INSTANCE already exists')
    else:
        print('HEISE_INSTANCE created')

# Generated at 2022-06-24 12:28:07.806598
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    get_test = HeiseIE()
    assert get_test._TESTS

# Generated at 2022-06-24 12:28:18.249006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert HeiseIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:28:18.819225
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:21.670470
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("url")
    # test argument for class constructor
    assert ie.url == "url"
    # test for inherited methods
    assert ie.suitable("url")
    assert ie.extract("url")

# Generated at 2022-06-24 12:28:28.507145
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:28:36.404677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not ie.suitable('https://www.heise.de/telepolis/rss/news-atom.xml')

# Generated at 2022-06-24 12:28:44.323197
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL.match('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heiseIE._VALID_URL.match('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:28:49.800787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    test_class = HeiseIE(test_url)
    assert test_class.url == test_url
    assert test_class.module_name == 'Heise'

# Generated at 2022-06-24 12:28:52.845248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'Heise'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:28:58.747939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple test for HeiseIE IE
    """
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url_s = smuggle_url(url, {'source_url': url})
    HeiseIE().suitable(url_s)

# Generated at 2022-06-24 12:28:59.844495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    ie_obj = HeiseIE()

# Generated at 2022-06-24 12:29:00.808889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE


# Generated at 2022-06-24 12:29:02.279199
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
        ie = HeiseIE(None)
        assert ie is not None

# Generated at 2022-06-24 12:29:08.550545
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    class_ = HeiseIE
    try:
        class_(url)
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:29:12.734779
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom")

# Generated at 2022-06-24 12:29:13.362823
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:15.383302
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ex = HeiseIE()
    # Test url1 is not None
    assert ex is not None

# Generated at 2022-06-24 12:29:20.043262
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:21.121726
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:26.148656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=no-value-for-parameter

    # Check constructor of HeiseIE
    instance = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert isinstance(instance, InfoExtractor)
#
# Unit tests for HeiseIE

# Generated at 2022-06-24 12:29:26.733665
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:35.917581
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    heiseie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    heiseie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    heiseie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    # Should return False for URLs of different host

# Generated at 2022-06-24 12:29:37.336560
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()


# Generated at 2022-06-24 12:29:47.209248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case for title
    webpage_1 = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    webpage_2 = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    webpage_3 = "http://www.heise.de/video/artikel/c-t-uplink-1-8-Xiaomi-Redmi-6-3-Pro-4GB-RAM-64GB-ROM-Kamera-und-Preis-3789452.html"
    webpage

# Generated at 2022-06-24 12:29:48.260974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'

# Generated at 2022-06-24 12:29:49.062890
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor)

# Generated at 2022-06-24 12:29:55.850881
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable(ie.get_info_extractor(url=''))
    assert ie.suitable(ie.get_info_extractor(url='heise:'))
    assert ie.suitable(ie.get_info_extractor(url='https://heise.de'))



# Generated at 2022-06-24 12:29:57.666871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-24 12:30:00.369002
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._TEST_URL
    assert ie._TEST_TITLE
    assert ie._TEST_DESC

# Generated at 2022-06-24 12:30:02.835019
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import expected
    url = expected.URL
    m = expected.META
    HeiseIE(url, m)

# Generated at 2022-06-24 12:30:06.357730
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:30:07.949737
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:30:09.087112
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-24 12:30:16.116217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # Check if instance was created
    assert(ie != None)
    # Check if URL was correctly set
    assert(ie.url == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:30:26.849653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    desc_id = '1_ntrmio2s'
    desc_url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    desc_title = "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    desc_description = 'md5:47e8ffb6c46d85c92c310a512d6db271'
    desc_timestamp = 1512470717
    desc_upload_date = '20171205'

    ie = HeiseIE()
    ie._download_webpage(desc_url, desc_id)

# Generated at 2022-06-24 12:30:35.704614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Instantiate an object
	video = HeiseIE()

	# Make url
	url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

	assert video.suitable(url) == True, 'Heise url: ' + url + ' is not suitable'
	assert video.working() == True, 'Heise is not working'

	assert isinstance(video.extract(url), dict), 'Extract is not working'

	url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
	

# Generated at 2022-06-24 12:30:45.875018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test SZ_STORY_PAGE_URL_PATTERN
    ie_instance = HeiseIE(None)

    # c't uplink
    assert ie_instance._valid_url('http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', None)

    # c't uplink from Podcasts
    assert ie_instance._valid_url('http://www.heise.de/ct/ausgabe/2017-12-Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404149.html', None)

    # c't uplink from Videos

# Generated at 2022-06-24 12:30:52.670215
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass
    """
    # short testing of creation and functionality of the HeiseIE
    class TestHeiseIE(HeiseIE):
        def __init__(self, *args, **kwargs):
            super(TestHeiseIE, self).__init__(*args, **kwargs)

        def _real_extract(self, *args, **kwargs):
            pass

        def _download_json(self, *args, **kwargs):
            return '{"status": "ok"}'

    t_heise = TestHeiseIE(params=dict())
    assert t_heise._download_json('http://www.heise.de')['status'] == 'ok'
    """

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:30:54.018524
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:31:05.456194
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE methods
    heise_ie = HeiseIE()
    assert heise_ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert heise_ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert heise_ie.suitable('http://heise.de/-3214137')
    assert heise_ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:31:08.949732
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html').download() # noqa

# Generated at 2022-06-24 12:31:12.862209
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(HeiseIE):
        def _real_initialize(self):
            assert self._downloader is not None

        def _download_webpage(self, url, video_id):
            assert self._downloader is not None
            return 'dummy'
    ie = TestHeiseIE()
    ie._real_initialize()

# Generated at 2022-06-24 12:31:13.918614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie != None

# Generated at 2022-06-24 12:31:17.042191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie._match_id(url) == "2404147"

# Generated at 2022-06-24 12:31:18.418312
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-24 12:31:23.999132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    assert(test.get_url() == None)
    assert(test.get_title() == None)
    assert(test.get_description() == None)
    assert(test.get_thumbnail() == None)
    assert(test.get_upload_date() == None)
    assert(test.get_duration() == None)

# Generated at 2022-06-24 12:31:24.597708
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:31:32.397293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    _HEISE_URL_TEST = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    _HEISE_URL_TEST1 = 'https://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    TestHeise = HeiseIE()
    assert TestHeise._match_id(_HEISE_URL_TEST) == '3700244'

# Generated at 2022-06-24 12:31:37.145990
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') and HeiseIE.IE_NAME == 'heise' and HeiseIE.IE_DESC == 'heise online Video'

# Generated at 2022-06-24 12:31:40.032964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'
    assert ie._TESTS[0]['info_dict']['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'

# Generated at 2022-06-24 12:31:46.612333
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.suitable("http://www.heise.de/radio/podcast/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

test_HeiseIE()


# Generated at 2022-06-24 12:31:55.718492
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    v = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert v.video_id == '1_kkrq94sm'
    assert v.video_url == 'https://cdnapisec.kaltura.com/p/2238431/sp/223843100/embedIframeJs/uiconf_id/36217212/partner_id/2238431?iframeembed=true&playerId=kaltura_player_1512735020&entry_id=1_kkrq94sm&flashvars[streamerType]=auto'

# Generated at 2022-06-24 12:32:05.197457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_url2 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    heise = HeiseIE()
    assert heise._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._TESTS[0]['url'] == test_url


# Generated at 2022-06-24 12:32:14.110419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    # HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # HeiseIE('http://www.heise

# Generated at 2022-06-24 12:32:14.913512
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()
    assert video

# Generated at 2022-06-24 12:32:23.559122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert HeiseIE().extract('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # Test exception throwing
    raise Exception('Not implemented')

# Generated at 2022-06-24 12:32:34.697603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Correct input
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)
    assert heiseIE.getUrl() == "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heiseIE.validUrl() == True
    assert heiseIE.getVideoID() == "2404147"

    # Wrong input

# Generated at 2022-06-24 12:32:43.625183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract_video_url(url='http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    ie.extract_video_url(url='http://www.heise.de/ct/ausgabe/2016-10-Heise-Zeitschriften-Verlag-GmbH--Co-KG-3191937.html')
    ie.extract_video_url(url='http://www.heise.de/video/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.extract_video_url

# Generated at 2022-06-24 12:32:46.213094
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_object = HeiseIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:46.705116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:32:48.664457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        # Check class constructor
        ie = HeiseIE()
    except:
        # When no class constructor
        assert False


test_HeiseIE()

# Generated at 2022-06-24 12:32:55.957113
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    print(test_HeiseIE.name)
    print(test_HeiseIE.description)
    print(test_HeiseIE.supported_extensions)
    print(test_HeiseIE.IE_NAME)
    print(test_HeiseIE.IE_DESC)
    print(test_HeiseIE.ie_key())

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:32:58.966976
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:33:00.143975
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception as ex:
        assert False, "Unexpected exception happened: " + ex.message

# Generated at 2022-06-24 12:33:00.752343
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()



# Generated at 2022-06-24 12:33:11.359242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("") == False
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True
    assert ie.suitable("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html") == True

# Generated at 2022-06-24 12:33:20.855211
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.IE_NAME == 'heise'
    assert hasattr(heise, '_VALID_URL')
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert hasattr(heise, '_TEST')

# Generated at 2022-06-24 12:33:30.926296
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Instantiate the class
    ie = HeiseIE()
    # Check the class name
    assert ie.IE_NAME == "heise"
    # Check that the regexes match
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Check the video id extraction
    assert ie._match_id("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html") == "3700244"

# Generated at 2022-06-24 12:33:32.433903
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie)

# Generated at 2022-06-24 12:33:44.612619
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # URL with missing <div data-type='kaltura'>
    url = 'https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert HeiseIE(url) is not None

    # URL having <div data-type='kaltura'>
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE(url) is not None

    # URL with missing <div data-type='kaltura'> and <div data-type='youtube'>

# Generated at 2022-06-24 12:33:46.629517
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i.ie_key() == 'Heise'
    assert i.ie_name() == 'Heise'

# Generated at 2022-06-24 12:33:53.072972
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_youtube_dl import YoutubeDL
    YoutubeDL.params['quiet'] = True
    video = HeiseIE()._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert video['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:33:53.848612
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()

# Generated at 2022-06-24 12:33:54.632048
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE, "Test not implemented."

# Generated at 2022-06-24 12:33:55.804999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)  # Assert that the constructor does not raise an exception

# Generated at 2022-06-24 12:33:56.715289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extract = InfoExtractor(HeiseIE)

# Generated at 2022-06-24 12:34:05.732749
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    # test for umlauts
    assert ie.title == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    # test for multiple formats
    assert ie.extract_info('c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.extract

# Generated at 2022-06-24 12:34:06.683939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == 'heise'

# Generated at 2022-06-24 12:34:16.990081
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-24 12:34:18.385267
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'

# Generated at 2022-06-24 12:34:19.593978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    test

# Generated at 2022-06-24 12:34:21.289434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('HeiseIE', 'heise.de') == HeiseIE



# Generated at 2022-06-24 12:34:25.313020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE('heise.de')
    assert hasattr(heise_ie, '_valid_url')
    assert heise_ie._VALID_URL == heise_ie._valid_url
    assert hasattr(heise_ie, 'ie_key')
    assert heise_ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:34:28.220677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

    ie = HeiseIE(None)
    assert ie.SUFFIX == 'heise.de'

# Generated at 2022-06-24 12:34:38.329034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:40.730963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:42.870994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() is 'heise'
    assert heise.ie_name() == 'Heise'
    assert heise.ie_description() == 'Heise'

# Generated at 2022-06-24 12:34:48.530067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
        from scrapy.http import Request
        url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
        h = HeiseIE()
        req = Request(url)
        h._real_extract(req)

# Generated at 2022-06-24 12:34:52.530713
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:34:55.875326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie != None


# Generated at 2022-06-24 12:34:56.621092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()


# Generated at 2022-06-24 12:35:03.310519
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE.url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE.extract()
    heiseIE.url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heiseIE.extract()

# Generated at 2022-06-24 12:35:05.248115
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:11.132738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:20.422723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.ie_key() == 'heise'
    assert 'heise.de' in heiseie.hosts()
    assert heiseie.matches('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heiseie.matches('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:35:22.108538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the constructor of class HeiseIE
    assert( HeiseIE.ie_key() == 'heise' )



# Generated at 2022-06-24 12:35:22.607462
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:23.958004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:27.855735
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE("")
    h.extract("http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html")

# Generated at 2022-06-24 12:35:33.493254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test class constructor"""
    obj = HeiseIE(None)
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert obj._API_BASE_URL == 'http://www.heise.de/videout/feed'


# Generated at 2022-06-24 12:35:38.756224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if exception has been raised
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    HeiseIE(url=url)

# Generated at 2022-06-24 12:35:47.806688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test for constructor of class HeiseIE
    # https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    # Test if the url is valid
    assert HeiseIE.suitable(url)
    # Test the constructor
    ie = HeiseIE(url)
    # Test the method for extracting the URL
    assert ie.extract()

# Generated at 2022-06-24 12:35:49.880573
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert isinstance(i, HeiseIE)

# Generated at 2022-06-24 12:35:53.713013
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'
    assert HeiseIE.__doc__ == 'Heise.de'
    assert HeiseIE.IE_NAME == 'heise'
    assert HeiseIE.IE_DESC == 'heise.de'

# Generated at 2022-06-24 12:35:55.945788
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:36:03.198803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # HeiseIE is a subclass of InfoExtractor
    assert(isinstance(ie, InfoExtractor))
    # HeiseIE.is_enabled() returns True
    assert(ie.is_enabled())
    # Assert that all the keys of HeiseIE.IE_DESC are defined
    HEISE_KEYS = [
        'id', 'ext', 'title', 'timestamp', 'upload_date', 'description',
        '_type', 'url', 'ie_key', 'playlist', 'display_id', 'age_limit']
    # Call keys() to get a list of keys of IE_DESC
    assert(not set(HeiseIE.IE_DESC['extract'].keys()) ^ set(HEISE_KEYS))

# Generated at 2022-06-24 12:36:08.236133
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    :return: None
    """
    if __name__ == '__main__':
        print("Testing constructor of class HeiseIE")
        url = "http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom"
        HeiseIE(url)


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:36:18.995008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # dummy vars
    kaltura_url = 'kaltura:2238431:1_kkrq94sm'
    webpage = ''
    video_id = '1_kkrq94sm'
    description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    timestamp = 1512734959
    title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:36:23.495682
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:36:24.972648
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # the HeiseIE class requires an instance of InfoExtractor
    InfoExtractor()

# Generated at 2022-06-24 12:36:25.718705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:36:36.062549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import FileDownloader
    from . import YoutubeDL
    from .extractor.kaltura import KalturaIE
    from .utils import get_cachedir
    import os

    dl = YoutubeDL({'outtmpl': '%(id)s', 'format': 'bestvideo+bestaudio',
                'cachedir': get_cachedir()})
    dl.add_info_extractor(KalturaIE)

    ie = HeiseIE(dl)
    # Kaltura embed
    res = ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert res['id'] == '1_kkrq94sm'

# Generated at 2022-06-24 12:36:37.257261
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie

# Generated at 2022-06-24 12:36:38.670062
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test for constructor of class HeiseIE """
    return HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:36:43.327455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Run a constructor test to check if the HeiseIE object is constructed properly.
    """
    url = "http://www.heise.de/video/artikel/" \
          "Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE()
    result = heise.suitable(url)
    assert result

