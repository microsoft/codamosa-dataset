

# Generated at 2022-06-24 12:26:39.433563
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        heise_ie = HeiseIE()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-24 12:26:46.474489
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_correct_input = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_wrong_input = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.pdf'
    heise = HeiseIE()
    assert heise.suitable(test_correct_input)
    assert not heise.suitable(test_wrong_input)

# Generated at 2022-06-24 12:26:48.274446
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL')
    ie = HeiseIE(False)

# Generated at 2022-06-24 12:26:50.941543
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None


# Generated at 2022-06-24 12:26:59.688769
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable(ie.ie_key())
    assert HeiseIE.suitable(ie.ie_key())
    assert ie.suitable(HeiseIE.ie_key())
    assert HeiseIE.suitable(HeiseIE.ie_key())
    assert ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') != None
    assert ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') != None

# Generated at 2022-06-24 12:27:09.879683
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    inst = HeiseIE()
    assert inst.ie_key() == 'heise'
    assert inst.ie_key(url='http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == 'heise'
    assert inst.ie_key(url='http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom') == 'heise'

# Generated at 2022-06-24 12:27:15.155118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:27:20.926962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    info_extractor._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert 1,2 == 3

# Generated at 2022-06-24 12:27:21.842167
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:27:30.958916
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.parameters == {}
    assert ie.ttl == None
    assert ie.max_downloads == None
    assert ie.params == {}
    assert ie.extractor == None
    assert ie.cached_template == None
    assert ie.params_to_signature == None
    assert ie.params_to_string == None
    assert ie.format == None
    assert ie.merge_result_headers == None
    assert ie.display_id == None
    assert ie.resume_download == None
    assert ie.continuedl == None
    assert ie.simulate == None
    assert ie.age_limit == None
    assert ie.auth_required == None
    assert ie.geo_restricted == None
    assert ie.playlist_title == None
    assert ie.playlist

# Generated at 2022-06-24 12:27:40.148610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_name = "HeiseIE"
    if globals()[class_name].__module__ is None.__class__.__name__:
        globals()[class_name].__module__ = "test"
    globals()[class_name] = type(
        globals()[class_name].__name__,
        (globals()[class_name],),
        dict(
            __module__="test",
            _VALID_URL=HeiseIE._VALID_URL,
            _TESTS=HeiseIE._TESTS,
        )
    )
    # heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html

# Generated at 2022-06-24 12:27:49.924641
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Testing constructor of class HeiseIE...")
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie.extract("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:27:50.899156
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test that the constructor works
    HeiseIE()

# Generated at 2022-06-24 12:27:55.677763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj_1 = HeiseIE()
    test_obj_2 = HeiseIE(test_obj_1)
    test_obj_3 = HeiseIE(test_obj_1, downloader=None)
    assert test_obj_2._downloader is test_obj_3._downloader


# Generated at 2022-06-24 12:28:05.322218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_inst = HeiseIE()
    entry_inst = heise_inst._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert entry_inst['id'] == '1_kkrq94sm'
    assert entry_inst['title']=="Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert entry_inst['timestamp']==1512734959
    assert entry_inst['upload_date']=='20171208'

# Generated at 2022-06-24 12:28:06.903627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, HeiseIE)

# Generated at 2022-06-24 12:28:07.765310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:28:18.206120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_url(url, expected_id, expected_type):
        ie = HeiseIE(url, {'skip_download': True})
        info = ie.extract()
        assert info['id'] == expected_id
        assert info['_type'] == expected_type
    # Kaltura videos
    _test_url(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-'
        'Tastaturen-Peilsender-Smartphone-2404147.html', '1_kkrq94sm', 'url')

# Generated at 2022-06-24 12:28:23.293255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert IE.ie_key() == 'heise'
    assert IE.ie_name() == 'heise'
    assert IE.supported_extractors() == ['heise']
    assert IE.supported_ie() == ['heise']
    assert IE.supported_ie_full() == ['heise']
    assert IE.supported_ie_only() == ['HeiseIE']
    assert IE.supported_ie_key() == ['heise']
    assert IE.supported_ie_key_map() == {'heise': 'HeiseIE'}
    assert IE.supported_ie_key_v() == [('heise', 'HeiseIE')]

# Generated at 2022-06-24 12:28:33.368551
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	
	# check if constructor of class HeiseIE works
	with pytest.raises(TypeError):
		HeiseIE(None, test_HeiseIE)
	
	# check if url and id of clip are extracted correctly
	url="https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
	id="3959893"
	instance=HeiseIE(url, id)
	assert instance.url == url
	assert instance._id == id
	
	# check if container_id and sequenz_id are extracted correctly
	# check if format of video is mp4

# Generated at 2022-06-24 12:28:36.038385
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with HeiseIE._TESTS
    heise_ie = HeiseIE()
    for url in [test['url'] for test in HeiseIE._TESTS]:
        heise_ie.extract(url)

# Generated at 2022-06-24 12:28:37.247380
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()



# Generated at 2022-06-24 12:28:41.870876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-24 12:28:50.536382
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)

    assert heiseIE is not None
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:52.587039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-24 12:28:53.907574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE
    assert heise_ie is not None

# Generated at 2022-06-24 12:28:55.838203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE class exists
    heiseIE = HeiseIE()
    assert heiseIE != None

# Generated at 2022-06-24 12:28:57.009622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_heise_class = HeiseIE()

# Generated at 2022-06-24 12:28:57.968940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:28:58.928076
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE


# end

# Generated at 2022-06-24 12:29:00.808295
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Because it uses class variable in code
    HeiseIE._VALID_URL = HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:01.900252
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    harry = HeiseIE

# Generated at 2022-06-24 12:29:10.087188
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie is not None
    assert ie.getUrl() == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' 


# Generated at 2022-06-24 12:29:10.686378
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:22.475073
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert HeiseIE('http://www.heise.de/ct/ausgabe/2017-13-E3-und-die-Spiele-2580128.html')

# Generated at 2022-06-24 12:29:29.556504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE constructor
    test_1 = HeiseIE()
    assert isinstance(test_1, HeiseIE)
    # Test HeiseIE constructor with video_id
    test_2 = HeiseIE(HeiseIE._VALID_URL)
    assert isinstance(test_2, HeiseIE)
    # Test HeiseIE constructor with expected, video_id
    test_3 = HeiseIE(HeiseIE._VALID_URL)
    assert isinstance(test_3, HeiseIE)
    # Test HeiseIE constructor with expected, video_id, download, note
    test_4 = HeiseIE(HeiseIE._VALID_URL)
    assert isinstance(test_4, HeiseIE)
    # Test HeiseIE constructor with expected, video_id, download, note,
    # expected_status

# Generated at 2022-06-24 12:29:32.935962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert(str(type(heise_ie)) == "<class 'youtube_dl.extractor.heise.HeiseIE'>")

# Generated at 2022-06-24 12:29:39.052374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    assert 'netflixdach' in HeiseIE._build_url_result('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html', '6kmWbXleKW4')

# Generated at 2022-06-24 12:29:42.174633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Can't test actual content extraction here, without creating test videos on the server.
    # Only checking the class constructor can be called properly
    heise = HeiseIE()

    assert heise is not None

# Generated at 2022-06-24 12:29:50.348457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:29:51.007225
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:52.050026
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:29:54.765908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == "heise"
    assert obj.ie_name() == "Heise"

# Generated at 2022-06-24 12:30:03.430772
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    heise.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:30:03.848939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:30:05.151805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE.VALID_URL
    assert HeiseIE._TESTS == HeiseIE.TESTS

# Generated at 2022-06-24 12:30:15.210782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._TESTS['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise._TESTS['md5'] == 'e403d2b43fea8e405e88e3f8623909f1'
    assert heise._TESTS['info_dict']['id'] == '6kmWbXleKW4'
    assert heise._T

# Generated at 2022-06-24 12:30:25.963102
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=invalid-name
    HeiseIE._VALID_URL = 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:27.791891
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/...'
    assert ie._VALID_URL == url

# Generated at 2022-06-24 12:30:28.984667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if the class constructor works
    HeiseIE(None)



# Generated at 2022-06-24 12:30:30.551495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    HeiseIE(None)

# Generated at 2022-06-24 12:30:36.762475
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor

    InfoExtractor.constructor = HeiseIE
    b = InfoExtractor("", "")
    b.url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    b.params = {'skip_download': True}
    b.download = lambda **k: None
    b.ie_key = "HeiseIE"
    b.extract()

# Generated at 2022-06-24 12:30:43.712564
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(None)
    obj = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    obj = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    obj = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-24 12:30:49.493327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')._real_extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:30:50.294628
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.constructor()

# Generated at 2022-06-24 12:30:51.541740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'


# Generated at 2022-06-24 12:30:52.648177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test in here that HeiseIE is created
    pass

# Generated at 2022-06-24 12:30:53.584563
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:00.523871
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testcase = {
        'url': 'http://www.heise.de/ct/artikel/Spiele-3214137.html',
    }
    instance = HeiseIE()
    result =  instance.result(testcase)

# Generated at 2022-06-24 12:31:07.294759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t=HeiseIE()
    assert('Heise' in t.IE_NAME)
    assert('heise.de' in t.VALID_URL)
    assert(t.IE_NAME=='Heise')
    assert(t.VALID_URL=='https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:31:09.247142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise.de'

# Generated at 2022-06-24 12:31:10.529231
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-24 12:31:17.516313
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x
    assert x.ie_key() == 'heise'
    assert x.name == 'heise'
    assert x.description == 'Video from heise'
    assert x._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert x._TESTS
    # Test: return KalturaIE when 'kaltura' is found in embed URL
    assert x._extract_embed_url('kaltura:123') == {'_type': 'url_transparent', 'url': 'kaltura:123', 'ie_key': 'kaltura'}

# Generated at 2022-06-24 12:31:27.895159
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie

# Generated at 2022-06-24 12:31:36.421715
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import unittest
    import re

    class TestHeiseIE(unittest.TestCase):
        def test_regular_url(self):
            obj = HeiseIE(HeiseIE._VALID_URL)

        def test_url_id_after_slash(self):
            obj = HeiseIE(HeiseIE._VALID_URL)

            m = re.match(obj._VALID_URL, HeiseIE._VALID_URL)
            self.assertEqual(obj._match_id(HeiseIE._VALID_URL), m.group('id'))

    unittest.main()

# Generated at 2022-06-24 12:31:36.868197
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:31:39.497411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(0xFF)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.ie_key() == "Heise"
    assert ie.host() == "www.heise.de"

# Generated at 2022-06-24 12:31:40.579203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE != None

# Generated at 2022-06-24 12:31:41.566992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE == InfoExtractor.registry.get('heise'))

# Generated at 2022-06-24 12:31:47.434068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    instance = ie.get_info_extractor("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-24 12:31:48.484448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()



# Generated at 2022-06-24 12:31:53.193756
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Success
    assert ie._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '2404147'
    # Failure
    assert ie._match_id('http://www.google.com') is None

# Generated at 2022-06-24 12:31:56.640123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.get_info('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-24 12:32:04.968514
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	obj = HeiseIE("youtube:6kmWbXleKW4")
	# check the types of the returned arguments
	assert isinstance(obj.url, str)
	assert isinstance(obj.video_id, str)
	assert isinstance(obj._downloader, YoutubeIE)
	# test the values returned
	assert obj.url == "https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
	assert obj.video_id == "9d904f79-a3a3-3d38-b8c8-21140d3c6bc5"

# Generated at 2022-06-24 12:32:06.118292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:32:13.380621
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.video_id == '1_kkrq94sm'
    assert ie.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert len(ie.video_data) > 0


# Generated at 2022-06-24 12:32:17.627223
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'Heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:22.091978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:32:25.343986
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for YoutubeIE"""
    from ..utils import CacheBackendTest

    with CacheBackendTest():
        assert HeiseIE._download_xml(None, None, query={})

# Generated at 2022-06-24 12:32:26.054262
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE()

# Generated at 2022-06-24 12:32:37.209673
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:32:43.861887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.VIDEO_URL == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    with pytest.raises(AttributeError):
        ie.prefer_free_formats


# Generated at 2022-06-24 12:32:45.094424
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()

# Generated at 2022-06-24 12:32:48.611760
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:32:57.494740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '2404147'
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-{}'.format(video_id)
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.get_id_from_url(url) == video_id

# Generated at 2022-06-24 12:32:58.955532
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:33:03.322788
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert ie.video_id == '6kmWbXleKW4'
    assert ie.regex.search(ie.video_id)
    assert ie.video_title == 'NEU IM SEPTEMBER | Netflix'

# Generated at 2022-06-24 12:33:05.114080
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heiseIE = HeiseIE()
    assert heiseIE is not None

# Generated at 2022-06-24 12:33:06.547067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 'kaltura' == HeiseIE.ie_key()

# Generated at 2022-06-24 12:33:12.259003
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Only the basic attributes shall be tested here, more tests
    # can be found in test_suite.py.
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise.de'
    assert ie.IE_DESC == 'heise.de, the web portal of the German IT and technology magazine c\'t.'
    assert ie.webpage_only_contains_embed

# Generated at 2022-06-24 12:33:13.669631
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)


# Generated at 2022-06-24 12:33:15.358963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.ie_key() == 'Heise'

# Generated at 2022-06-24 12:33:23.235687
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test_video_id(input_url):
        expected_video_id = input_url.split('-')[-1].split('.')[0]
        actual_video_id =  HeiseIE._match_id(input_url)
        assert expected_video_id == actual_video_id

    _test_video_id('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    _test_video_id('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-24 12:33:24.792423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE("test")
    assert True

# Generated at 2022-06-24 12:33:30.799077
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244-2.html')
    assert t._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert t._TESTS is not None

# Generated at 2022-06-24 12:33:31.976890
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:33:44.208372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'
    assert heise.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == '6kmWbXleKW4'

# Generated at 2022-06-24 12:33:49.650125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise._match_id(url) == '2404147'

# Generated at 2022-06-24 12:33:57.729084
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # heise-video
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._match_id(url).strip() is not None

    # heise-newsticker
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert HeiseIE._match_id(url).strip() is not None

# Generated at 2022-06-24 12:34:04.596752
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(HeiseIE.ie_key())
    assert isinstance(ie.kaltura_ie, KalturaIE)
    assert isinstance(ie.youtube_ie, YoutubeIE)
    # https://www.youtube.com/watch?v=9XGD8WJq3qM
    youtube_url = 'https://www.youtube.com/watch?v=9XGD8WJq3qM'
    assert HeiseIE.suitable(youtube_url)
    assert ie.suitable(youtube_url)


# Generated at 2022-06-24 12:34:05.154710
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:34:06.023552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:34:09.015908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #
    # check constructor
    #
    assert HeiseIE is not None


# Generated at 2022-06-24 12:34:13.032439
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that the HeiseIE constructor throws no exceptions
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")



# Generated at 2022-06-24 12:34:14.872697
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance.VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:34:19.599964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    HeiseIE().suitable(url)
    HeiseIE()._real_extract(url)

# Generated at 2022-06-24 12:34:25.098853
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(
        # Retrieve mp4 file metadata
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    )
    assert ie.name == 'heise.de'
    assert ie._extract_url() == 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    # Test if heise video file metadata was retrieved.
    # If video file metadata is stored in video_url
    # it can be retrieved by heiseie._extract_url()


# Generated at 2022-06-24 12:34:35.658312
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    ie = HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:34:38.023534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:34:42.137110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heise_ie.is_suitable("url") == True
    assert heise_ie.ie_key() == "Heise"



# Generated at 2022-06-24 12:34:42.943141
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:34:45.773320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    kaltura_ie = HeiseIE()
    print(kaltura_ie)

    youtube_ie = HeiseIE()
    print(youtube_ie)

# Generated at 2022-06-24 12:34:46.917597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-24 12:34:48.226528
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()

# Generated at 2022-06-24 12:34:57.147912
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Load the webpage http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    webpage = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert webpage
    # Create a HeiseIE object
    Heise = HeiseIE()
    # check if url is valid
    assert Heise.suitable(webpage)
    # extract the videos from the webpage
    videos = Heise.extract(webpage)
    # check the length of result
    assert len(videos) == 1

# Generated at 2022-06-24 12:34:59.930549
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor(HeiseIE.ie_key())
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:35:00.824851
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-24 12:35:02.047731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE({})
    assert obj.ie_key() == 'Heise'
    assert obj.working == True

# Generated at 2022-06-24 12:35:03.845001
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE("")
    assert isinstance(a,HeiseIE)

# Generated at 2022-06-24 12:35:08.058030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert type(ie) == HeiseIE

# Generated at 2022-06-24 12:35:09.407628
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:11.408156
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()

# Testing the regex of HeiseIE

# Generated at 2022-06-24 12:35:14.212732
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    See https://github.com/rg3/youtube-dl/issues/1819 for a discussion.
    This test is for checking if HeiseIE is constructed properly.
    """
    HeiseIE(YoutubeIE)

# Generated at 2022-06-24 12:35:15.150124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE())


# Generated at 2022-06-24 12:35:16.641948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:35:20.619949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
     # see explanation in the HeiseIE class local variable _TESTS
     for test in HeiseIE._TESTS:
         if test.get('only_matching', False):  # only testing if it matches the given regular expression
             continue
         result = HeiseIE().result_from_url(test['url'])
         assert result

# Generated at 2022-06-24 12:35:24.883456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:26.530365
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:35:29.080854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Tests for no exception on type error,
	# and all attributes are initialized properly
	obj = HeiseIE()
	assert obj.ie_key() == 'Heise'

# Generated at 2022-06-24 12:35:29.865012
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:41.057354
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS

    url = ie._TESTS[0]['url']
    webpage = ie._download_webpage(url)
    kaltura_url = ie._search_regex(r'(?:<div class="kalturavideo">.+?<script [^>]+?data-player-id="([^"]+)"|<div class="videoplayerjw"[^>]+data-player-id="([^"]+)">)', webpage, 'kaltura url', default=None)
    if kaltura_url:
        assert kaltura

# Generated at 2022-06-24 12:35:47.527993
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.get_real_url() == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-24 12:35:48.483058
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-24 12:35:58.424052
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Initialize the class HeiseIE
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:01.765768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    assert HeiseIE()._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'

# Generated at 2022-06-24 12:36:03.899682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() in ie.supported_ie_keys()

# Generated at 2022-06-24 12:36:09.095533
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..utils import TestHeiseIE
    class_name = 'HeiseIE'
    # Can not test, url is not fixed
    # Can not test, url is not fixed
    # Can not test, url is not fixed
    # Can not test, url is not fixed
    # Can not test, url is not fixed
    # Can not test, url is not fixed

    TestHeiseIE(class_name).run()

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:36:12.449115
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Unit test for constructor of class HeiseIE")
    ie = HeiseIE()
    assert ie is not None



# Generated at 2022-06-24 12:36:17.696564
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie= HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.extractor == HeiseIE

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:36:18.837962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_object = HeiseIE()

# Generated at 2022-06-24 12:36:21.010497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import test_utils
    test_utils.InsecureTestCase(HeiseIE).run_test(HeiseIE._TESTS)

# Generated at 2022-06-24 12:36:30.133404
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:30.973279
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:36:35.046785
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:36:36.346580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-24 12:36:41.940284
# Unit test for constructor of class HeiseIE
def test_HeiseIE(): 
    print('\n', HeiseIE._VALID_URL)
    # Video on c't uplink
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heise = HeiseIE()
    heise.extract(url)