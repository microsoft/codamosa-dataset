

# Generated at 2022-06-24 12:26:47.964567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class A(HeiseIE):
        pass
    A('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    A('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    A('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:26:49.900674
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie.IE_NAME == HeiseIE.IE_NAME

# Generated at 2022-06-24 12:26:59.138844
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .YouTubePlaylistIE import YouTubePlaylistIE
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from .common import InfoExtractor

    ###############
    # Normal cases
    ###############

    # URL of test case
    # Check if a given URL is an instance of HeiseIE
    assert isinstance(InfoExtractor()._get_info_extractor(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ), HeiseIE)


# Generated at 2022-06-24 12:27:00.101490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:01.228851
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-24 12:27:03.483168
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(None)
    # Test for type of instance
    assert isinstance(obj, HeiseIE)

# Generated at 2022-06-24 12:27:05.916911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.get_suitable_extractors # check HeiseIE is a IE


# Generated at 2022-06-24 12:27:07.165579
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL ==HeiseIE._VALID_URL

# Generated at 2022-06-24 12:27:13.787949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Heise has to be tested with a working internet connection,
    because it uses other extractors. The tests at the end are only
    url tests.
    """


# Generated at 2022-06-24 12:27:15.414266
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # pylint: disable=protected-access
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:27:24.361328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert HeiseIE

# Generated at 2022-06-24 12:27:27.932759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract(
        r'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie

# Generated at 2022-06-24 12:27:28.469583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:30.086860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'


# Generated at 2022-06-24 12:27:33.656363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '3946472'
    webpage = "http://www.heise.de/video/artikel/" + video_id + ".html";
    expected_output = {
        'id': video_id,
        'url': webpage,
        'title': 'Sicherheitsforscher analysieren über 350 Sprachassistenten und stellen fest: keiner hört so richtig zu.'
    }
    assert HeiseIE(None)._extract_video(webpage) == expected_output

# Generated at 2022-06-24 12:27:34.245739
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:36.641745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance._VALID_URL is not None
    assert instance._TESTS is not None


# Generated at 2022-06-24 12:27:47.666075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == "https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html"

# Generated at 2022-06-24 12:27:48.868477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h != None

# Generated at 2022-06-24 12:27:58.849936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    youtube_url = 'https://www.youtube.com/watch?v=6kmWbXleKW4'
    youtube_url_with_redirect = 'https://www.youtube.com/watch?v=6kmWbXleKW4&redirect=true'
    heise_url_with_youtube_url_redirect = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    ie = HeiseIE(heise_url_with_youtube_url_redirect)
    assert ie.url == youtube_url_with_redirect, ie.url

# Generated at 2022-06-24 12:28:08.322368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.url_result.url == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie.url_result.id == '1_kkrq94sm'
    assert ie.url_result.ext == 'mp4'
    assert ie.url_result.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.url

# Generated at 2022-06-24 12:28:09.348253
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None


# Generated at 2022-06-24 12:28:13.794104
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)._real_initialize()
    HeiseIE(None)._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:28:14.685557
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-24 12:28:24.918541
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:28:30.108021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', 'www.heise.de')
    assert ie._VIDEO_ID == '1_kkrq94sm'


# Generated at 2022-06-24 12:28:33.483212
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test HeiseIE
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE(None)._TESTS[0] == HeiseIE._TESTS[0]

# Generated at 2022-06-24 12:28:35.672201
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("www.test.com")
    assert heiseIE.name == "Heise"

# Generated at 2022-06-24 12:28:36.167438
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:28:40.324191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().get_playlist_id('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') == '3959893'

# Generated at 2022-06-24 12:28:45.514035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # check inheritance
    assert isinstance(ie, InfoExtractor)
    # check type of _VALID_URL and _TEST
    assert isinstance(ie._VALID_URL, type(re.compile('')))
    assert isinstance(ie._TESTS, list)
    # check _cert
    assert ie._cert == 'HX9o05jKpFm+l3cJh+xLso5JZ2Y='
    # check _TIMEOUT
    assert ie._TIMEOUT == 5

# Generated at 2022-06-24 12:28:46.473794
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    me = HeiseIE()
    print(me)

# Generated at 2022-06-24 12:28:57.469487
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    # Test extracting basic video URL
    assert e.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not e.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert not e.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-24 12:28:58.421020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE())

# Generated at 2022-06-24 12:29:04.705008
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # pylint: disable=protected-access
    # Class HeiseIE should be initialized with "new HeiseIE()"
    ie = HeiseIE()
    # HeiseIE should require re=True
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:29:07.348675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('www.heise.de')
    assert(heise.ie_key() == 'heise')

# Generated at 2022-06-24 12:29:07.987498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:29:15.531213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("www.heise.de","http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    # Test if constructor creates the expected object
    assert True == (ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-24 12:29:21.017205
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Testing class HeiseIE")
    try:
        heise_ie = HeiseIE()
        print("Successfully instantiated HeiseIE")
    except:
        print("Failed to instantiate HeiseIE")


if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:29:21.752809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-24 12:29:26.532930
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    try:
        # the test should pass, because the class has the required methods
        assert hasattr(ie, '_real_extract') and callable(ie._real_extract)
        ie._real_extract(None)
    except Exception as e:
        print("FAILED test_HeiseIE, because of exception {0}".format(e))
    else:
        print("SUCCESS test_HeiseIE")

# Generated at 2022-06-24 12:29:35.813773
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:29:37.636854
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().constructor == HeiseIE



# Generated at 2022-06-24 12:29:44.938437
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    meta_info = {
        'md5': '2c85a58a6f4d6c80ff4bb5986a2cff6c',
        'size': '994516'
    }

    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ie = HeiseIE()
    ie.download(url)
    ie.extract(url)



# Generated at 2022-06-24 12:29:54.179506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise_ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-24 12:29:54.827372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:30:03.459339
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:30:06.784287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case = HeiseIE()
    test_case._real_extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:16.389707
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:30:21.275779
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test constructor of class HeiseIE"""
    try:
        iExtractor = HeiseIE("var")
    except Exception as e:
        print("test_HeiseIE: Assertion test case failed.")
        print(str(e))
        assert False


# Generated at 2022-06-24 12:30:22.216497
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import heise
    heise.HeiseIE()

# Generated at 2022-06-24 12:30:26.754056
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for HeiseIE, an IE for heise.de video website
    """
    heise = HeiseIE()
    assert heise._VALID_URL == re.compile(r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:30:32.070836
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.name == 'heise'
    assert ie.video_id == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147'


# Generated at 2022-06-24 12:30:36.164206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-24 12:30:43.312847
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

    # Test a valid URL
    info = h.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert info['id'] == '1_kkrq94sm'
    assert info['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

    # Test a not-supported URL

# Generated at 2022-06-24 12:30:46.497662
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS

# Generated at 2022-06-24 12:30:49.346580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    check = HeiseIE()
    check._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:30:56.799966
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import inspect
    import json
    import os
    assert 'c-t' in inspect.getmodule(HeiseIE).__name__
    path = os.path.join(os.path.dirname(__file__), 'test_data', 'ct', 'heise.json')
    with open(path, "r") as f:
        test_cases = json.load(f)
    for test_case in test_cases:
        heise_ie = HeiseIE(downloader=None)
        assert heise_ie._real_extract(**test_case)

# Generated at 2022-06-24 12:30:58.380969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie


# Generated at 2022-06-24 12:31:09.574467
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:31:16.002913
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info=HeiseIE()._real_extract(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert info['id'] == '1_ntrmio2s'
    assert info['title'] == "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?"
    assert info['description'] == 'md5:47e8ffb6c46d85c92c310a512d6db271'
    assert info['timestamp'] == 1512470717

# Generated at 2022-06-24 12:31:20.756814
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'Heise'
    assert ie.server_site_name() == 'Heise'

# Generated at 2022-06-24 12:31:22.467238
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heiseIE = HeiseIE()
    assert heiseIE != None

# Generated at 2022-06-24 12:31:31.057938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie._match_id('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == '3214137'
    assert ie._real_extract('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')['title'] == 'c\'t uplink 17.11: Test: Gaming-Mäuse, Retro-Konsolen, nützliche Tools, Windo- und Linux-Spiele'

# Generated at 2022-06-24 12:31:33.191447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE(), InfoExtractor)

# Generated at 2022-06-24 12:31:37.018582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    dl = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert dl.suitable(url)

# Generated at 2022-06-24 12:31:37.662494
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-24 12:31:38.243177
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:31:38.907977
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:31:50.261237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:51.211955
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:32:02.748584
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # For HEISE site newsticker/meldung
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heise_ie = HeiseIE(url)
    assert heise_ie.url == url
    assert heise_ie.id == 3814130
    assert heise_ie.type == "heise_newsticker"
    # For HEISE site video/artikel/
    url = "http://www.heise.de/video/artikel/c-t-uplink-28-4-Netzneutralitaet-Das-Flip-Flop-des-White-House-3924649.html"
    heise_

# Generated at 2022-06-24 12:32:04.052564
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-24 12:32:05.030643
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL

# Generated at 2022-06-24 12:32:13.935432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:20.510033
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:32:21.867005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    res = HeiseIE()
    assert res.ie_key() == "heise"

# Generated at 2022-06-24 12:32:24.677826
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()
    HeiseIE(InfoExtractor)
    HeiseIE(InfoExtractor(), InfoExtractor)
    InfoExtractor().suitable()

# Generated at 2022-06-24 12:32:28.283933
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:30.663911
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'

# Generated at 2022-06-24 12:32:39.342389
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert ('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-'
            'Tastaturen-Peilsender-Smartphone-2404147.html') == (
               HeiseIE._VALID_URL)

# Generated at 2022-06-24 12:32:42.631507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME.lower().replace(' ', '_') == ie.ie_key().lower().replace(' ', '_')
    assert ie.ie_key() == 'heise'
    assert ie.IE_NAME == 'Heise'

# Generated at 2022-06-24 12:32:52.544430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Object creation
    obj = HeiseIE()
    # Check _VALID_URLs
    _VALID_URLs = obj._VALID_URL
    for _VALID_URL in _VALID_URLs:
        assert _VALID_URL.match("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    for _VALID_URL in _VALID_URLs:
        assert _VALID_URL.match("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-24 12:32:55.428927
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.constructor_name() == 'HeiseIE'
    assert ie.constructor_key() == 'heise'

# Generated at 2022-06-24 12:33:02.138167
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert HeiseIE._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:33:03.662984
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    instance = class_()
    assert instance.SUCCESS

# Generated at 2022-06-24 12:33:04.500943
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()

# Generated at 2022-06-24 12:33:05.612414
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:33:07.285664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Test class HeiseIE is created
    assert HeiseIE is not None

# Generated at 2022-06-24 12:33:13.670461
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    r = HeiseIE()
    assert r.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not r.suitable('https://www.heise.de/')


# Generated at 2022-06-24 12:33:22.449327
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:33:27.919171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    instance = ie.get_info_extractor(
        'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-24 12:33:34.409382
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = HeiseIE._match_id(url)
    video_url = HeiseIE._download_webpage(url, video_id)
    title = ('Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / '
             'Peilsender Smartphone')
    description = None
    HeiseIE._real_extract(video_url, video_id, title, description)

# Generated at 2022-06-24 12:33:36.230743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:33:37.973007
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..utils import make_extractor
    return make_extractor(HeiseIE)

# Generated at 2022-06-24 12:33:43.277885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert (ie.ie_key() == 'Heise')

# Generated at 2022-06-24 12:33:50.982925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor"""
    # Test if HeiseIE raises ValueError when there is no url
    def constructor_without_url():
        HeiseIE("")

    # Test if HeiseIE raises ValueError when there is no id
    def constructor_without_id():
        HeiseIE("https://www.heise.de/ct/")
        HeiseIE("https://www.heise.de/ct/")

    # Test if HeiseIE does not raise when the id is valid

# Generated at 2022-06-24 12:33:57.528092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test construction of HeiseIE
    # Subclass of InfoExtractor
    # Methods
    #   _real_initialize()
    #   _real_extract()
    # Attributes
    #   IE_NAME
    #   IE_DESC
    #   _VALID_URL

    # Construct an instance of HeiseIE
    ie = HeiseIE()

    # Test the inherited methods and attributes of InfoExtractor
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise online'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:03.449172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import _tests_common
    from .constants import _ALLOWED_DRM_MAP
    from .extractor import gen_extractors

    (_, ie_key) = gen_extractors({
        'HeiseIE': (HeiseIE, HeiseIE._VALID_URL)
    })[0]
    ie = ie_key(default_drm_scheme=_ALLOWED_DRM_MAP)
    _tests_common.do_test_extraction(ie, 'HeiseIE')

# Generated at 2022-06-24 12:34:06.209667
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    test.to_screen('title')
    test.to_screen('description')
    test.to_screen('thumbnail')
    test.to_screen('timestamp')
    test.to_screen('formats')

# Generated at 2022-06-24 12:34:16.945947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    fetch_page_test_results = [
        {"status_code": 200, 
         "content": "<div id='test_page'></div>"},
        {"status_code": 200, 
         "content": "<html><head><title>page title</title></head><body><div id='test_page'></div></body></html>"},
        {"status_code": 200, 
         "content": "<html><head><title>page title</title></head><body><div id='test_page'>test_page_content</div></body></html>"},
        {"status_code": 200, 
         "content": "<div id='test_page'>test_page_content</div>"},
        {"status_code": 200, 
         "content": "<p>page content</p>"}
    ]
    fetch_page_

# Generated at 2022-06-24 12:34:17.596218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE

# Generated at 2022-06-24 12:34:21.110280
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import doctest
    doctest.DocFileSuite(
        '../docs/build/doctrees/heiseie.rst',
        optionflags=doctest.REPORT_ONLY_FIRST_FAILURE
    )

# Generated at 2022-06-24 12:34:27.687328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    print(ie._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'))

# Generated at 2022-06-24 12:34:28.994107
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    module = HeiseIE()
    assert isinstance(module, HeiseIE)

# Generated at 2022-06-24 12:34:37.420954
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._downloader = None
    heise.download = lambda *a, **k: None
    heise.to_screen = lambda *a, **k: None
    heise.report_warning = lambda *a, **k: None
    heise.report_error = lambda *a, **k: None
    heise.try_get = lambda *a, **k: None
    heise._download_webpage = lambda *a, **k: None
    heise._extract_rss = lambda *a, **k: None
    heise._real_extract("heise.de")

# Generated at 2022-06-24 12:34:38.594714
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert "Heise" in x._VALID_URL

# Generated at 2022-06-24 12:34:41.612960
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    wanted_class = HeiseIE
    module_name = wanted_class.__module__
    wanted_class_name = wanted_class.__name__
    assert module_name == "youtube_dl.extractor.heise"
    assert wanted_class_name == "HeiseIE"

# Generated at 2022-06-24 12:34:45.459286
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:47.678021
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-24 12:34:49.517232
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_obj = HeiseIE(HeiseIE._downloader)
    assert unit_test_obj is not None

# Generated at 2022-06-24 12:34:59.016136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    # Call constructor method and check if the link is valid
    heise._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # Call constructor method and check if the link is valid
    heise._real_extract('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # Call constructor method and check if the link is valid

# Generated at 2022-06-24 12:34:59.545269
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:05.685975
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert ie.name == "heise"
    assert ie.url == "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"

# Generated at 2022-06-24 12:35:16.998754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for static method HeiseIE._extract_url
    assert HeiseIE._extract_url('www.heise.de/video/sequenz-1-1/clip-1.flv') == 'http://www.heise.de/video/sequenz-1-1/clip-1.flv'
    assert HeiseIE._extract_url('www.heise.de/video/sequenz-1-1/clip-1.mp4') == 'http://www.heise.de/video/sequenz-1-1/clip-1.mp4'

# Generated at 2022-06-24 12:35:24.761095
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl import youtube_dl
    from youtube_dl.downloader.http import HttpFD
    from unittest.mock import Mock
    from io import BytesIO

# Generated at 2022-06-24 12:35:27.604660
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'
    assert ie.supported_extensions() == ['mp4']

# Generated at 2022-06-24 12:35:34.484964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:35:34.884982
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:35.436243
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:35:37.540204
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:35:46.059797
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Check whether constructor of HeiseIE works as expected
    """
    from os import sys, path
    _script_dir = path.dirname(path.abspath(__file__))
    _script_dir = path.dirname(path.dirname(_script_dir))
    _script_dir = path.dirname(path.dirname(_script_dir))
    sys.path.append(_script_dir)
    from youtube_dl.YoutubeDL import create_std_options
    (params, info) = create_std_options(_script_dir)
    params.update({'verbose': True, 'forcejson': True, 'simulate': False, 'debug_printtraffic':False})

# Generated at 2022-06-24 12:35:47.636351
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert isinstance(heiseIE, InfoExtractor)

# Generated at 2022-06-24 12:35:53.996838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heiseie = HeiseIE()
    assert heiseie.suitable(test_url)
    assert heiseie.extract(test_url)["title"] == 'NEU IM SEPTEMBER | Netflix'

# Generated at 2022-06-24 12:35:55.168790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert len(ie._TESTS) > 100

# Generated at 2022-06-24 12:35:56.438592
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:36:06.009119
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Constructor test
    '''
    ie = HeiseIE()
    # self.assertEqual(ie.ie_key(), 'Heise')
    # self.assertEqual(
    #     ie.ie_key(),
    #     'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    # )
    # self.assertEqual(
    #     ie.ie_key(),
    #     'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'

# Generated at 2022-06-24 12:36:10.561800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert(IE.ie_key() == "Heise")
    assert(IE.ie_key() == 'Heise')
    assert(IE.suitable("https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"))
    assert(not IE.suitable("https://www.youtube.com/watch?v=IXXstfp_X2E"))

# Generated at 2022-06-24 12:36:13.548495
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:36:21.690348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:36:26.804676
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:36:28.167210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL[0] == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:36:32.115598
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for constructor of HeiseIE"""
    heise_ie = HeiseIE()
    assert heise_ie is not None
    assert heise_ie.ie_key() == 'heise'
    assert heise_ie.ie_name() == 'Heise'

# Generated at 2022-06-24 12:36:39.432731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    webpage = ie.urlopen(url)
    assert webpage is not None
    assert ie.get_id() == '1_jr1r0xlj'
    assert ie.get_title() == "c't uplink 3.3: Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-24 12:36:42.183779
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'