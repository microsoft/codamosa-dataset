

# Generated at 2022-06-24 12:26:46.369240
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = "1_kkrq94sm"
    title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    description = "md5:c934cbfb326c669c2bcabcbe3d3fcd20"
    upload_date = "20171120"
    timestamp = 1512734959
    height = 360
    heiseie = HeiseIE()

    assert heiseie.suitable(url)

    info_dict = heiseie._real_extract(url)

# Generated at 2022-06-24 12:26:50.333533
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor("HeiseIE") # Create the InfoExtractor object
    assert ie == InfoExtractor.infoExtractorFor("HeiseIE") == HeiseIE # Check that it is the right one
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") # Check that it can be called by its name


# Generated at 2022-06-24 12:26:56.320459
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:26:57.365698
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('heise')
    heise.get_info()

# Generated at 2022-06-24 12:26:58.687917
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:27:00.985339
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:27:10.703627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   ie = InfoExtractor()
   ie.add_info_extractor( HeiseIE )

   assert ie.suitable( 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
   assert ie.suitable( 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:27:16.211494
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE
    # test _VALID_URL
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # test _TESTS
    assert len(heiseIE._TESTS) == 6


# Generated at 2022-06-24 12:27:24.492944
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # A heise page with a kaltura embed
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise_ie = HeiseIE()
    result_dict = heise_ie.extract(url)

    # A heise page with a youtube embed
    url = "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heise_ie = HeiseIE()
    result_dict = heise_ie.extract(url)

# Generated at 2022-06-24 12:27:25.455587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:27:25.996187
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:27:29.444759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        assert False, "Test HeiseIE constructor: Testcase failed"
    except AssertionError as e:
        print(e)
        print("Test HeiseIE constructor: Testcase passed")


# Generated at 2022-06-24 12:27:34.428183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '5597386'
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    HeiseIE(url)
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-24 12:27:34.978348
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-24 12:27:44.041438
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-24 12:27:47.818960
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.url_result == 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-24 12:27:49.030033
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE can be constructed
    heise = HeiseIE()

# Generated at 2022-06-24 12:27:54.163936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE(url)
    heise_ie.extract()

# Generated at 2022-06-24 12:27:56.819613
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check the constructor was called with the expected arguments
    # and that an object with the expected type was returned
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:28:06.802404
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:28:13.035138
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with url from unit test of _real_extract
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    instance = HeiseIE(url)

# Generated at 2022-06-24 12:28:14.599035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.NAME == 'heise'


# Generated at 2022-06-24 12:28:17.292341
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    info_dict = ie.extract('')
    assert info_dict.get('filename')

# Generated at 2022-06-24 12:28:27.347373
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test case for testing constructor of class HeiseIE """

# Generated at 2022-06-24 12:28:30.237472
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL
    assert heise_ie._TEST

# Generated at 2022-06-24 12:28:31.169125
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-24 12:28:32.317504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-24 12:28:40.306186
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    base_url = 'https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    url_prefix = 'https://www.heise.de'
    
    # Instantiate HeiseIE class
    heise_ie = HeiseIE(url_prefix)
    
    # Check _VALID_URL
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    
    # Check _TESTS

# Generated at 2022-06-24 12:28:42.915966
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-24 12:28:44.541910
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:28:53.047611
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for video used by ct uplink
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    # test for iframe used by ct uplink
    test_url2 = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    # test for youtube used by ct uplink

# Generated at 2022-06-24 12:28:54.817670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE = get_ie()
    assert HeiseIE.ie_key() == 'Heise'

# Generated at 2022-06-24 12:29:02.050408
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_Heise = HeiseIE()
    assert ie_Heise.ie_key() == 'heise'
    assert ie_Heise.ie_name() == 'heise'
    assert ie_Heise.supported_ie() == ('kaltura', 'youtube')
    assert ie_Heise.suitable() == True
    assert ie_Heise.ie_obj().get_info_extractor()[0] == KalturaIE
    assert ie_Heise.ie_obj().get_info_extractor()[1] == YoutubeIE

# Generated at 2022-06-24 12:29:05.676137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_obj = HeiseIE(1)
    assert ie_obj.ie_key() == 'Heise'
    assert ie_obj.ie_name() == 'heise'

# Generated at 2022-06-24 12:29:16.351679
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_youtube_dl import YoutubeDL
    from .test_kaltura import KalturaIE_test
    from .test_youtube import YoutubeIE_test

    # test for method _real_extract
    def _real_extract_test(self, *args):
        return self._real_extract(*args)

    test_video_id = '1_kkrq94sm'
    test_title_1 = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    test_description_1 = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'

# Generated at 2022-06-24 12:29:18.140228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:19.491321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-24 12:29:27.859799
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Test URL for heise.de
	url = 'https://www.heise.de/mobil/meldung/nachgehakt-Wozu-dient-die-Anzeige-aktueller-Standort-im-Browser-3816221.html'
	ie = HeiseIE(url)
	print(ie.url)
	assert ie.url == url

	# Test URL for heise.de
	url = 'https://www.heise.de/ct/ftp/fotolink/p200/p20030521-1-1.pdf'
	ie = HeiseIE(url)
	print(ie._download_webpage(url))
	assert ie._download_webpage(url) == b'ERROR: Unsupported URL for HeiseIE'


# Generated at 2022-06-24 12:29:31.126217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.__name__ == 'heise:heise'
    assert hie.ie_key() == 'heise'

# Generated at 2022-06-24 12:29:42.086503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable(None)
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/c-t-uplink-22-4-Kinnara-Raspberry-Pi-3-Grill-Alternative-und-Drone-Einsteigertool-3793016.html')
    assert not HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:29:43.307058
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:29:44.632442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-24 12:29:46.529270
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert(IE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-24 12:29:50.376005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'heise:video'
    assert ie.name() == 'heise:video'

# Generated at 2022-06-24 12:30:00.537346
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:30:01.753522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-24 12:30:03.045454
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE."""
    assert HeiseIE

# Generated at 2022-06-24 12:30:05.318507
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'
    assert heise.ie_key() == HeiseIE.ie_key()



# Generated at 2022-06-24 12:30:12.038385
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert heiseIE.url == "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"

# Generated at 2022-06-24 12:30:13.515477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    # check if heise.de domain is present in the regex
    assert ie._VALID_URL.split('://')[1].split('/')[0] == 'www.heise.de'

# Generated at 2022-06-24 12:30:24.472434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Test 1: Valid URL
	url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
	test_one = HeiseIE()._match_id(url)
	assert test_one == "3700244" # Test if the function find the video id
	
	# Test 2: Invalid URL
	url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.txt"
	test_two = HeiseIE()._match_id(url)
	assert test_two == False #

# Generated at 2022-06-24 12:30:27.158773
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie is not None
    assert ie.INVALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:30.109635
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:31.808825
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	test_obj = HeiseIE()

test_obj = HeiseIE()

# Generated at 2022-06-24 12:30:40.237031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:41.604633
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert isinstance(HeiseIE._VIDEO_URL, type(re.compile('')))

# Generated at 2022-06-24 12:30:42.493516
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-24 12:30:43.412776
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h

# Generated at 2022-06-24 12:30:44.644590
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()
    HeiseIE({'test': 'test'})

# Generated at 2022-06-24 12:30:48.849010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Container id is the second parameter and sequenz id is the third parameter
    # which are both required to construct the URL.
    ie = HeiseIE(None, '12345', '12345')
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:30:50.225228
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor())._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:30:55.545183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-24 12:30:59.432284
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')._VALID_URL

# Generated at 2022-06-24 12:31:00.861829
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:31:11.348767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)
    assert heiseIE.url == url
    assert heiseIE.video_id == "1_kkrq94sm"
    assert heiseIE.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert heiseIE.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert heiseIE.upload_date == '20171208'
    assert heiseIE.timestamp == 1512734959

# Generated at 2022-06-24 12:31:12.489237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Smoke test
    assert HeiseIE(HeiseIE._VALID_URL)

# Generated at 2022-06-24 12:31:13.012401
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-24 12:31:14.779680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:31:25.787742
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:28.598546
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:35.543953
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    dummy_class = 'dummy_class'
    dummy_url = 'dummy_url'
    dummy_video_id = 'dummy_video_id'
    test_HeiseIE = HeiseIE(
        dummy_class, dummy_url, dummy_video_id)
    expected_video_id = 'dummy_video_id'
    assert test_HeiseIE._match_id(dummy_url) == expected_video_id

# Generated at 2022-06-24 12:31:37.353661
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Testing HeiseIE")
    assert HeiseIE._VALID_URL == HeiseIE.valid_urls[0][1]
    assert HeiseIE.valid_urls[0][0] == 'example'

# Generated at 2022-06-24 12:31:39.177645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:31:40.980934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This will call constructor of HeiseIE and make sure that it does not throw any exceptions 
    HeiseIE()

# Generated at 2022-06-24 12:31:52.078682
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class TestHeiseIE(object):
        def __init__(self, url, title, description, timestamp, upload_date, formats, duration, expected_count):
            self.result = HeiseIE()._real_extract(url)

        def assert_equal(self, count):
            assert len(self.result['formats']) == count, "Assert failed"


# Generated at 2022-06-24 12:31:59.116814
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # First create an instance of HeiseIE
    ie = HeiseIE()
    # Then test whether the instance can execute code.
    ie._real_extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:32:02.961214
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """test HeiseIE constructor"""
    instance = HeiseIE()
    instance.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')


# Generated at 2022-06-24 12:32:05.442850
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS

# Generated at 2022-06-24 12:32:09.134523
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert (ie._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html')
    assert (ie._WORKING == True)

# Generated at 2022-06-24 12:32:10.415324
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-24 12:32:12.009562
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(repr(ie._download_webpage))

# Generated at 2022-06-24 12:32:19.655264
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert test_obj.__class__.__name__ == 'HeiseIE'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:21.772703
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    test_ie = HeiseIE({})
    test_ie.to_screen('test')

# Generated at 2022-06-24 12:32:26.763129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-24 12:32:37.371908
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import unittest
    from . import *
    from .common import InfoExtractor
    from .heise import HeiseIE
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import unescapeHTML

    class HeiseIETest(unittest.TestCase):
        def test_generatetests(self, test_data):
            self.__class__.__name__ = test_data['test_name']
            url = test_data['url']
            expected = test_data['test']
            _ = globals()[expected['test_id']]
            IEClass = globals()[expected['test_ie']]

            info_dict = globals()[expected['test_info_dict_generator']](
                expected, IEClass, url)
            info_dict

# Generated at 2022-06-24 12:32:40.037808
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(8, "Heise", [], {})
    assert ie.site == "Heise"
    assert ie.name == "Heise"

# Generated at 2022-06-24 12:32:48.166207
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:32:49.185254
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_IE = HeiseIE()

# Generated at 2022-06-24 12:32:54.628355
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test instantiation
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)
    # test HeiseIE._call_api
    heise_ie = HeiseIE()
    heise_ie._call_api('http://www.heise.de/tp/artikel/38/38781/1.html', '38781')

# Generated at 2022-06-24 12:32:55.540974
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return

# Generated at 2022-06-24 12:32:57.001435
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    module = 'HeiseIE'
    globals()[module]()

# Generated at 2022-06-24 12:32:59.571895
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE('http://url.com')
    assert isinstance(heise_ie, HeiseIE)

test_HeiseIE()

# Generated at 2022-06-24 12:33:00.167444
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global HeiseIE
    HeiseIE()

# Generated at 2022-06-24 12:33:05.899924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not h.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-24 12:33:17.026653
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.HeiseIE import HeiseIE
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    assert ydl.extract_info(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        download=False)


# Generated at 2022-06-24 12:33:24.088042
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._real_extract(
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie._real_extract(
        "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    ie._real_extract(
        "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
   

# Generated at 2022-06-24 12:33:26.872716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:33:33.238978
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    VideoIE = HeiseIE(url)
    assert VideoIE.url == url
    assert VideoIE.video_id == '1_59mk80sf'
    assert VideoIE.title == "c't uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten"
    assert VideoIE.description == 'md5:f50fe044d3371ec73a8f79fcebd74afc'

# Generated at 2022-06-24 12:33:45.500926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert instance._VALID_URL == r'^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html$'

# Generated at 2022-06-24 12:33:51.781885
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # set up helper instances
    heiseIE = InfoExtractor()
    url = "http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    heiseIE = HeiseIE(heiseIE)
    # assert attribute existence
    assert hasattr(heiseIE, '_VALID_URL')
    assert isinstance(heiseIE._VALID_URL, str)
    assert hasattr(heiseIE, '_TESTS')
    assert isinstance(heiseIE._TESTS, list)
    # assert URL and test existence
    assert heiseIE._VALID_URL == HeiseIE._VALID_URL
    assert heiseIE._TESTS

# Generated at 2022-06-24 12:33:58.796733
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info_dict = {
            'id': '1_kkrq94sm',
            'ext': 'mp4',
            'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
            'timestamp': 1512734959,
            'upload_date': '20171208',
            'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
    }
    heise_ie = HeiseIE()

# Generated at 2022-06-24 12:34:07.704567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from sys import version_info
    from urlparse import urlparse
    from urlparse import urlunparse
    from urlparse import parse_qs
    from urlparse import parse_qsl
    from types import FunctionType as function
    from types import MethodType as method
    if version_info[0:2] == (2, 6):
        from unittest2 import TestCase
    else:
        from unittest import TestCase
    if version_info[0] == 2:
        from StringIO import StringIO as stringIO
    else:
        from io import StringIO as stringIO
    from itertools import izip
    from mock import patch
    from json import loads
    from json import dumps
    from os.path import exists
    from os import remove
    from shutil import copyfileobj
    from shutil import copyfile
   

# Generated at 2022-06-24 12:34:17.693981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    path = os.path.dirname(os.path.abspath(__file__))
    # Get the webpage which would be normally served by the url
    with open(os.path.join(path, 'test_data', 'heise.html')) as f:
        webpage = f.read()
    # Extract all information from url
    ie = HeiseIE()
    stream_dict = ie._real_extract(
        r'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html',
        webpage)
    # Check if the information has been extracted

# Generated at 2022-06-24 12:34:23.009040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    he = HeiseIE()
    assert he.ie_key() == 'heise'
    assert he.ie_name() == 'Heise'
    assert he.supported_extractors() == [u'info']
    assert he.url_result('kaltura:2238431:1_kkrq94sm') == 'kaltura:2238431:1_kkrq94sm'

# Generated at 2022-06-24 12:34:27.584034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.suitable(hie._VALID_URL)
    assert not hie.suitable("https://www.heise.de")
    assert hie._TESTS[0] == hie.extract(hie._TESTS[0]['url'])

# Generated at 2022-06-24 12:34:28.865321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie is not None

# Generated at 2022-06-24 12:34:38.864661
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-24 12:34:44.345056
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.url_name == 'HeiseIE'

# Generated at 2022-06-24 12:34:45.887913
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-24 12:34:55.113790
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'
    assert ie.http_headers()["User-Agent"] == "curl/7.52.1"
    assert ie.working == True
    assert ie.is_extractable == True
    assert ie.is_suitable(None) == False
    assert ie.is_suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == True

# Generated at 2022-06-24 12:35:02.362596
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:35:04.842057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._match_id("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:35:16.552176
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert x._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert x._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert x._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:35:24.469326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie.extract("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-24 12:35:28.233820
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor test
    heise_test_test = HeiseIE()
    # Check if it is the correct class
    assert heise_test_test.__class__ == HeiseIE, 'Not the correct class'

# Unit tests for extractor methods of class HeiseIE

# Generated at 2022-06-24 12:35:33.787955
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-24 12:35:38.284306
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Test with a Heise video page url.
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE().working_instance(url)
    assert ie.name == 'heise'

    # Test with a Heise newsticker page url.
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    ie = HeiseIE().working_instance(url)
    assert ie.name == 'heise'

    # Test with a Heise ct page url.


# Generated at 2022-06-24 12:35:40.722536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'
    assert ie.url_name == 'Heise'

# Generated at 2022-06-24 12:35:42.339506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    xxx = HeiseIE._VALID_URL
    assert xxx

# Generated at 2022-06-24 12:35:49.946593
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_for_test = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    # test - create instance of class
    test_instance = HeiseIE(url_for_test)
    # test - check key of ie_key class attribute
    test_key_exists = hasattr(test_instance, '_VALID_URL')
    # test - check key of ie_key class attribute
    # test - check key of _NETRC_MACHINE class attribute
    assert test_key_exists == True


# Generated at 2022-06-24 12:35:52.363067
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE is constructed as expected
    assert HeiseIE._VALID_URL is not None
    assert HeiseIE._TESTS is not None

# Generated at 2022-06-24 12:35:53.628240
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'

# Generated at 2022-06-24 12:35:58.583698
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie.IE_NAME == 'Heise'
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-24 12:36:05.145395
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'Heise'
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['info_dict']['id'] == ie._TESTS[1]['info_dict']['id']
    assert ie._TESTS[0]['info_dict']['ext'] == ie._TESTS[1]['info_dict']['ext']

# Generated at 2022-06-24 12:36:06.332659
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-24 12:36:09.757292
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
	info = ie.extract()

test_HeiseIE()

# Generated at 2022-06-24 12:36:14.802620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test constructor
    # url = None
    url = 'https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    ie = HeiseIE(url)
    print(ie._real_extract(url))
# end of test_HeiseIE()

# Generated at 2022-06-24 12:36:19.844627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    e = HeiseIE()
    e.suitable('https://www.heise.de/artikel/c-t-uplink-8-4-WebM-GStreamer-Kodi-Plasma-5-3397486.html')
    e.suitable('https://www.heise.de/newsticker/meldung/c-t-uplink-8-4-WebM-GStreamer-Kodi-Plasma-5-3397489.html')

# Generated at 2022-06-24 12:36:29.272891
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(None)
    assert obj.ie_key() == 'Heise'
    assert obj.ie_name() == 'heise'
    assert obj.suitable(None) is False
    assert obj.suitable(dict(url='http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')) is True
    assert obj.suitable(dict(url='http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')) is True

# Generated at 2022-06-24 12:36:39.885318
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'