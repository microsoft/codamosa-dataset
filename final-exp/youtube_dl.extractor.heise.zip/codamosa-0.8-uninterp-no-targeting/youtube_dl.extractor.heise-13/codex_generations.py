

# Generated at 2022-06-22 07:37:12.648928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'


# Generated at 2022-06-22 07:37:14.511527
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_HeiseIE = HeiseIE()
    print('Unit test for HeiseIE.py done.')

# Generated at 2022-06-22 07:37:23.783245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert isinstance(ie, HeiseIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie._KALTURA_OBJECT_CLASS, type(KalturaIE._KALTURA_OBJECT_CLASS))
    assert isinstance(ie._YOUTUBE_IE, type(YoutubeIE._YOUTUBE_IE))
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie._TESTS == HeiseIE._TESTS
    assert ie._RATING_REGEXES == InfoExtractor._RATING_REGEXES
    assert ie.__name__ == 'HeiseIE'
    assert ie.ie_key() == 'Heise'
    test = ie._download_webpage('url', 'id')
    assert test

# Generated at 2022-06-22 07:37:25.611383
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-22 07:37:36.445743
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:37:38.574443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE.ie_key()[0]

# Generated at 2022-06-22 07:37:40.944208
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-22 07:37:42.149037
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('')



# Generated at 2022-06-22 07:37:45.692680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:53.997331
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_for_test = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url_for_test_extract = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # Test constructor
    heiseie = HeiseIE(url_for_test, {})
    # Test extract
    heiseie.extract(url_for_test_extract)

# Generated at 2022-06-22 07:38:12.405034
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(None)
    assert isinstance(heise, InfoExtractor)

# Generated at 2022-06-22 07:38:24.274874
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    assert(ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'))
    assert(ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'))

# Generated at 2022-06-22 07:38:33.084888
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')


# Generated at 2022-06-22 07:38:37.784652
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Cover case when a format is not found
    assert HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html") is not None

# Generated at 2022-06-22 07:38:48.033050
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    ydl = YoutubeDL({})

    expected_ie = 'HeiseIE'
    expected_result = {
        'id': '1_kkrq94sm',
        'ext': 'mp4',
        'title': "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone",
        'timestamp': 1512734959,
        'upload_date': '20171208',
        'description': 'md5:c934cbfb326c669c2bcabcbe3d3fcd20',
        'thumbnail': 're:^https?://.+',
        'formats': 'mincount:1',
    }


# Generated at 2022-06-22 07:38:49.576216
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert type(ie) == HeiseIE

# Generated at 2022-06-22 07:38:59.319831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.name == 'heise'
    assert ie.url == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    assert ie.id == 'ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911'
    assert ie.version == '0.0'
    assert ie.age_limit == 0

# Generated at 2022-06-22 07:39:00.933574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-22 07:39:08.945557
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('test', 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

    assert ie.video_id == '2403911'
    assert ie.url == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

# Generated at 2022-06-22 07:39:15.706757
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test of type check constructor
    obj_HeiseIE = HeiseIE(HeiseIE._VALID_URL)
    # Test of __init__() and _download_webpage() of class InfoExtractor
    InfoExtractor.__init__(obj_HeiseIE, HeiseIE._VALID_URL)
    webpage = obj_HeiseIE._download_webpage(obj_HeiseIE._VALID_URL, None)
    
# test_HeiseIE()

# Generated at 2022-06-22 07:39:33.687688
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE())

# Generated at 2022-06-22 07:39:34.802362
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-22 07:39:36.447873
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:39:37.905433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:39:48.558368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE()._build_info_model(HeiseIE()._get_info(url='http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html', video_id='http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'))
    assert info['title'] == 'NEU IM SEPTEMBER | Netflix'

# Generated at 2022-06-22 07:39:49.639887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(InfoExtractor())
    assert ie.name == 'heise'

# Generated at 2022-06-22 07:39:50.872096
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass


# Generated at 2022-06-22 07:39:55.940472
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

	assert HeiseIE._extract_urls(
		"https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-22 07:39:57.425323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseObj = HeiseIE()


# Generated at 2022-06-22 07:40:02.783439
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE()
    heise_ie._real_extract(url)

# Generated at 2022-06-22 07:40:22.387625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:40:25.804224
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    h = HeiseIE()
    h.extract(u)

# Generated at 2022-06-22 07:40:27.111146
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:30.817023
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    global HeiseIE
    try:
        HeiseIE
    except NameError:
        HeiseIE = None
    if HeiseIE is None:
        from . import heise
        HeiseIE = heise.HeiseIE

    assert HeiseIE

# Generated at 2022-06-22 07:40:36.786043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert "HeiseIE" in ie.__class__.__name__
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:40.757603
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:41.651271
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:40:53.076490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert info_extractor.IE_NAME == 'heise'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:54.519804
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heisie = HeiseIE()
    assert heisie

# Generated at 2022-06-22 07:40:59.352388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for the __init__ and _real_extract methods of class HeiseIE
    """
    heise_ie_instance = HeiseIE()
    heise_ie_instance._real_extract("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-22 07:41:51.440084
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE()._get_info_extractor(
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert result.ie_key() == 'Heise'
    assert result.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-22 07:42:02.614812
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL.match("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._VALID_URL.match("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-22 07:42:12.986585
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    youtube_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    heise_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'

# Generated at 2022-06-22 07:42:22.564156
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.set_cookie()
    ie.set_request()
    ie.set_response()
    ie.get_response_info()
    ie.set_video_id()
    ie.set_video_id_re()
    ie.set_formats()
    ie.set_format_id()
    ie.set_format_id_re()
    ie.set_upload_date()
    ie.set_timestamp()
    ie.set_url()
    ie.set_url_result()
    ie.set_image()
    ie.set_filename()
    ie.set_title()
    ie.set_description()
    ie.set_thumbnail()
    ie.set_age_limit()
    ie.set_is_live()
    ie.set_license

# Generated at 2022-06-22 07:42:23.541136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case = HeiseIE()

# Generated at 2022-06-22 07:42:35.913075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # YouTube embed
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    webpage = ie._download_webpage(url, '1')
    ie._extract_youtube(webpage, '1')

    # Kaltura embed
    url = 'https://www.heise.de/video/artikel/c-t-uplink-21-1-CES-2018-mit-Staubsaugerrobotern-und-LED-Technik-3973629.html'
    webpage = ie._download_webpage(url, '2')

# Generated at 2022-06-22 07:42:38.703864
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert "heise" in ie.IE_NAME

# Generated at 2022-06-22 07:42:41.492655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:42:44.412112
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ == "__main__":
        HeiseIE()

# Generated at 2022-06-22 07:42:45.505113
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    t = HeiseIE()
    assert t.IE_NAME == "Heise"

# Generated at 2022-06-22 07:44:25.511746
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test that static class correctly captures properties of a video
    # so that these properties can be used by a VideoPlayer
    # Currently only test case for Kaltura source
    assert HeiseIE._VALID_URL
    assert HeiseIE._TESTS

    # test that class can download the webpage
    webpage = HeiseIE._download_webpage('http://heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html', '3814130')
    assert isinstance(webpage, str)

    # test that class can extract the video id

# Generated at 2022-06-22 07:44:34.497043
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    obj_test_url = obj._VALID_URL.match(test_url)
    assert obj_test_url, "The match function should return a valid non-empty result, but the result is empty."
 #   assert obj_test_url.group('id'), "test_url should contain non-empty video ID, but video ID is empty."

# Generated at 2022-06-22 07:44:40.446057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    # assert heiseie._VALID_URL == ur'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:44:44.984393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'




# Generated at 2022-06-22 07:44:46.982255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'

# Generated at 2022-06-22 07:44:51.108200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    result = test_obj.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert result == True

# Generated at 2022-06-22 07:44:53.888192
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:44:54.394540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE({})

# Generated at 2022-06-22 07:45:00.134856
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert hasattr(HeiseIE, '_VALID_URL')
    assert hasattr(HeiseIE, '_TESTS')
    assert hasattr(HeiseIE, '_NETRC_MACHINE')
    assert not hasattr(HeiseIE, '_LOGIN_URL')
    assert not hasattr(HeiseIE, 'IE_NAME')
    assert not hasattr(HeiseIE, '_TEMPLATE_URL')
    assert not hasattr(HeiseIE, '_TEST')

# Generated at 2022-06-22 07:45:04.594118
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    instance = HeiseIE()
    assert type(instance) is HeiseIE
