

# Generated at 2022-06-22 07:37:21.026999
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SITENAME == 'heise.de'
    assert ie.LANGUAGE == 'de'
    assert ie.url_to_id('http://www.heise.de/tr/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '2403911'

# Generated at 2022-06-22 07:37:21.905534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:37:24.071378
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE()
    assert test_obj



# Generated at 2022-06-22 07:37:28.094632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    with open("test_data/test.html", 'r') as f:
        webpage = f.read()
    pre_test_heise = HeiseIE("", webpage)
    assert type(pre_test_heise) == HeiseIE

# Generated at 2022-06-22 07:37:35.951402
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.get_id()
    assert ie.get_title()
    assert ie.get_description()
    assert ie.get_thumbnail()
    assert ie.get_timestamp()
    assert ie.get_duration()
    assert ie.get_keywords()
    assert ie.get_formats()

# Generated at 2022-06-22 07:37:40.159248
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert(heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-22 07:37:41.769645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE();

# Generated at 2022-06-22 07:37:42.829555
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h != None

# Generated at 2022-06-22 07:37:47.102191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor test
    ie = HeiseIE()
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:37:53.918319
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    ie = HeiseIE()
    title = ie._real_extract(url)['title']
    assert(title == 'c\'t uplink 20.8: Staubsaugerroboter Xiaomi Vacuum 2, AR-Brille Meta 2 und Android rooten')

# Generated at 2022-06-22 07:38:12.189912
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-22 07:38:14.447617
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-22 07:38:25.542081
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    extractor = HeiseIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:37.526774
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url_test, options_test, expected_test = (
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html',
        {'skip_download': True},
        {
            'id': '1_ntrmio2s',
            'ext': 'mp4',
            'title': "nachgehakt: Wie sichert das c't-Tool Restric'tor Windows 10 ab?",
            'description': 'md5:47e8ffb6c46d85c92c310a512d6db271',
            'timestamp': 1512470717,
            'upload_date': '20171205'
        }
    )


# Generated at 2022-06-22 07:38:47.828979
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from datetime import datetime
    from pytz import timezone
    from time import time


# Generated at 2022-06-22 07:38:59.612333
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test case one
    # Input:
    #       url = https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html
    # Expected output:
    #       success with info_dict
    test_input_one = {'url': 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'}
    heiseie = HeiseIE(InfoExtractor(YDL(), test_input_one))
    heiseie.extract()

# Generated at 2022-06-22 07:39:10.667342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test = HeiseIE(InfoExtractor())
    assert unit_test._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert unit_test._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert unit_test._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'

# Generated at 2022-06-22 07:39:13.806902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == 'Heise'
    assert type(x.ie_key()) == str



# Generated at 2022-06-22 07:39:25.454597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test double checking if HeiseIE is working and if the first
    # two tests are not broken.
    heise_ie = HeiseIE()
    heise_ie._download_webpage = lambda url, video_id: None
    heise_url = 'https://www.heise.de/video/artikel/c-t-uplink-21-1-YubiKey-5-und-5c-Webbrowser-mit-Gecko-Onboard-Handyschleuder-und-M4-Maeuse-4050857.html'

# Generated at 2022-06-22 07:39:27.398783
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    temp = HeiseIE()
    assert 'HeiseIE' == temp.extractor_key

# Generated at 2022-06-22 07:39:46.815320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_HeiseIE import HeiseIETest
    test_instance = HeiseIETest(HeiseIE)
    test_instance.run()


# Generated at 2022-06-22 07:39:55.190601
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:39:59.425666
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:09.625447
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test for constructor of HeiseIE class.
    """
    # When no IE key is given, but a regex for it, the key should be
    # determined from the regex
    klass = type(
        'MyHeiseIE', (InfoExtractor,),
        {'_VALID_URL': r'http://www\.heise\.de/foo/(?P<id>\d+).html',
         '_TEST': {
             'url': 'http://www.heise.de/foo/1234.html',
             'info_dict': {'id': '1234'},
         }})
    assert klass.ie_key() == 'Heise'

    # When an IE key is given, it should be used without further checks

# Generated at 2022-06-22 07:40:18.829363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heiseie.name == 'heise.de'
    assert heiseie.urls == ['http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html']

# Generated at 2022-06-22 07:40:19.730233
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("HeiseIE")

# Generated at 2022-06-22 07:40:20.936705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None


# Generated at 2022-06-22 07:40:22.383391
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE().ie_key() == 'heise')

# Generated at 2022-06-22 07:40:23.740137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-22 07:40:25.884164
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """test constructor of HeiseIE"""
    return HeiseIE("test", "test")

# Generated at 2022-06-22 07:41:03.123935
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE



# Generated at 2022-06-22 07:41:13.253018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html?wt_mc=rss.ext.ho.beitrag.atom')

# Generated at 2022-06-22 07:41:23.329290
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_utils import get_testcases
    from .test_utils import get_expected

    testcases = get_testcases(HeiseIE)

    for testcase in testcases:
        for url in testcase.urls:
            ie = HeiseIE(url)
            expected = get_expected(ie, testcase)
            ie.extract()

            assert ie.title == expected.title
            assert ie.thumbnail == expected.thumbnail
            assert ie.description == expected.description
            assert ie.duration == expected.duration
            assert ie.timestamp == expected.timestamp
            assert ie.webpage_url == expected.webpage_url
            assert ie.view_count == 0
            assert ie.age_limit == 0

            format_id, expect_url = next(iteritems(expected.formats))
            format

# Generated at 2022-06-22 07:41:30.693930
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:41:41.109806
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # these URLs are the links to other websites
    # check if the constructor can handle the exceptions
    url1 = 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    url2 = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE(url1)
    if ie.suitable(url1):
        # Get the title of the page
        print("Title: " + ie.get_title())
        # Get the description of the page
        print("Description: " + ie.get_description())

# Generated at 2022-06-22 07:41:51.490913
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:41:56.966035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    ie = HeiseIE()
    ie.extract(url)
    assert ie.video_id == '3814130'

# Generated at 2022-06-22 07:41:58.046129
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:42:02.809427
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.constructor('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:42:06.708250
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'heise.de'
    assert ie.ie_key() == 'heise'



# Generated at 2022-06-22 07:43:41.917745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    exists = HeiseIE() is not None
    assert(exists)


# Generated at 2022-06-22 07:43:46.796075
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_obj = InfoExtractor.implemented_constructors['heise'](None)
    assert ie_obj.IE_NAME == 'heise'
    assert ie_obj.ie_key() == 'heise'
    assert ie_obj.http_headers['User-Agent']
    assert ie_obj.md5 is not None

# Generated at 2022-06-22 07:43:52.518953
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseID = "3700244"
    heiseURL = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    heiseIE = HeiseIE()
    heiseIE._valid_url(heiseURL, heiseID)

# Generated at 2022-06-22 07:44:03.679061
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    instance = HeiseIE()


# Generated at 2022-06-22 07:44:06.784251
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Unit test for class HeiseIE")
    heise_url = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    HeiseIE(heise_url)


# Generated at 2022-06-22 07:44:14.577268
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeIE
    from .kaltura import KalturaIE
    from .common import InfoExtractor
    from .youtube import YoutubePlaylistIE
    ie = HeiseIE()
    ie.ie_key()
    ie.ie_key() == InfoExtractor.ie_key()
    ie.ie_key() == YoutubeIE.ie_key()
    ie.ie_key() == YoutubePlaylistIE.ie_key()
    ie.ie_key() == KalturaIE.ie_key()

# Generated at 2022-06-22 07:44:24.529249
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(Downloader())
    assert heiseie._VALID_URL=='https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie._TESTS[0]['url']=='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heiseie._TESTS[0]['info_dict']['id']=='1_kkrq94sm'
    assert heiseie._TESTS[0]['info_dict']['ext']=='mp4'
    assert heiseie._

# Generated at 2022-06-22 07:44:33.399341
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE("/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert instance._VALID_URL ==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:44:43.334323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == "heise"
    assert ie.IE_NAME == "heise"
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:44:48.107536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE()
    ie.extract(url)
