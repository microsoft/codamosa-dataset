

# Generated at 2022-06-22 07:37:21.171274
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Not a real test but useful for debugging
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info_dict = HeiseIE()._extract(url)
    assert (int_or_none(info_dict['id']) == 2404147)
    assert info_dict['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert (int_or_none(info_dict['timestamp']) == 1512734959)
    assert info_dict['upload_date'] == '20171208'



# Generated at 2022-06-22 07:37:33.059973
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.search('http://www.heise.de/newsticker/meldung/Die-verflixte-neun-Hochwasser-sorgt-fuer-Probleme-im-Osten-3799866.html').group('id') == '3799866'
    assert HeiseIE._VALID_URL.search('http://www.heise.de/ct/ausgabe/2017-04-Das-Tastatur-Quartett-3877732.html').group('id') == '3877732'
    assert HeiseIE._VALID_URL.search('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html').group

# Generated at 2022-06-22 07:37:37.720634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor()
    ie.register(HeiseIE)
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:37:46.995928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:58.057161
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	assert HeiseIE._TESTS[0]["url"] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
	assert HeiseIE._TESTS[0]["info_dict"]["id"] == "1_kkrq94sm"
	assert HeiseIE._TESTS[0]["info_dict"]["timestamp"] == 1512734959
	
	assert HeiseIE._TESTS[1]["url"] == "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
	

# Generated at 2022-06-22 07:38:02.634241
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE();
    # Test if the HeiseIE constructor succeeded by checking if it's class member _VALID_URL has been set
    if heise._VALID_URL == None:
        raise Exception('HeiseIE: constructor failed')

# Generated at 2022-06-22 07:38:07.700948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(None)
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    

# Generated at 2022-06-22 07:38:13.085912
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html", {})

# Generated at 2022-06-22 07:38:17.346735
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Only to test the constructor
    ie = HeiseIE('heise')
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() == 'Heise'

# Generated at 2022-06-22 07:38:18.809375
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:38:38.424740
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with valid input
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

    # Test with invalid input
    import pytest
    with pytest.raises(RegexNotFoundError):
        HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893')



# Generated at 2022-06-22 07:38:48.140439
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    video_id = heiseie._match_id(url)
    webpage = heiseie._download_webpage(url, video_id)

    # Constructor of class InfoExtractor (parent of class HeiseIE)
    ie = InfoExtractor()
    ie_result = ie._real_extract(url)
    assert ie_result['id'] == video_id

    # Constructor of class HeiseIE
    heiseie_result = heiseie._real_extract(url)
    assert heiseie_result['id'] == video_id


# Generated at 2022-06-22 07:38:48.779670
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:38:54.550625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:39:00.465436
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE._download_webpage = lambda *args, **kargs: None
    IE._real_extract(url)

# Generated at 2022-06-22 07:39:02.869828
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.getName() == 'heise'

# Generated at 2022-06-22 07:39:08.005154
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    test_url = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    filename = ie.extract(test_url)
    print("Filename of the video: " + filename)

# Generated at 2022-06-22 07:39:09.371030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test HeiseIE constructor
    visit = HeiseIE()



# Generated at 2022-06-22 07:39:18.061599
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    #This video has no description, but it does have a title
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    #This video has a description and a title
    url2 = 'http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    #This video is a YouTube video, so it should have a description and a title

# Generated at 2022-06-22 07:39:22.451057
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:39:50.735760
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
# Unit testing 'extract_title' from class HeiseIE

# Generated at 2022-06-22 07:39:52.845838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-22 07:39:53.887531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h is not None

# Generated at 2022-06-22 07:39:54.933922
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()


# Generated at 2022-06-22 07:39:58.851002
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'
    assert heise.ie_key() == 'Heise'
    assert heise.ie_key() == 'HeiseIE'

# Generated at 2022-06-22 07:39:59.610646
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:04.896893
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() == 'Heise'
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:13.222664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    ie = HeiseIE()

    assert_equal(ie._build_url('http://www.heise.de/ct/video/mpeg2-bzw-h-264-5377460.html', '5377460'),
                 'http://www.heise.de/ct/video/mpeg2-bzw-h-264-5377460.html')

    assert_equal(ie._build_url('http://www.heise.de/ct/video/mpeg2-bzw-h-264-5377460.html', '5377460', '/videos/'),
                 'http://www.heise.de/ct/video/mpeg2-bzw-h-264-5377460.html')


# Generated at 2022-06-22 07:40:17.901350
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heise.de", "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:40:20.577671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise.IE_NAME == 'Heise'

# Generated at 2022-06-22 07:41:07.607069
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # HeiseIE._VALID_URL matches
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.suitable("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert ie.suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-22 07:41:11.876327
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

    assert (HeiseIE(None)._TESTS[0]['url'] == HeiseIE._TESTS[0]['url'])

# Generated at 2022-06-22 07:41:13.722988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:41:15.560972
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-22 07:41:17.345028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert True


# Generated at 2022-06-22 07:41:18.759175
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:41:19.400990
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-22 07:41:20.437106
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-22 07:41:21.490656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-22 07:41:32.407748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # parameters for HeiseIE using the constructor.
    _VALID_URL = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    _TESTS = {InfoExtractor._download_json_handle:'heise', InfoExtractor._match_id:'heise'}
    heise_new = HeiseIE(_VALID_URL, _TESTS)
    # As heise_new is a HeiseIE object, all properties obtained from the constructor
    # can be accessed using the dot notation
    print('heise_new.url:', heise_new.url)
    print('heise_new.expected_results:', heise_new.expected_results)


# Generated at 2022-06-22 07:42:57.075246
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-22 07:42:58.200144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:43:03.373218
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE().extract_entries(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:43:14.792997
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:43:18.020842
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise online'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 07:43:25.654030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE
    assert not heiseIE.suitable('http://localhost:8888/test/html')
    assert not heiseIE.suitable('wrongurl')
    assert heiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:43:27.320273
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL, HeiseIE

# Generated at 2022-06-22 07:43:37.066853
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.params['ie_key'] == 'Heise'
    assert ie.name == 'Heise'
    assert ie.description == 'Video portal of the c\'t and iX magazine'
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == False

# Generated at 2022-06-22 07:43:38.786524
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == 'HeiseIE'

# Generated at 2022-06-22 07:43:42.580963
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    # Instantiate a class
    obj = class_(None)
    # Test its methods
    assert obj.suitable(None) == False
    assert obj.extract(None) == False