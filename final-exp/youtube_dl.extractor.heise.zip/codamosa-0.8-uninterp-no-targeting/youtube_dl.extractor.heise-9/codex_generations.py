

# Generated at 2022-06-22 07:37:17.021588
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    expected_id = '1_kkrq94sm'
    assert ie.ID == expected_id


# Generated at 2022-06-22 07:37:17.587063
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:37:28.039293
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:29.113489
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:37:40.939374
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()
    assert video.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert video.suitable('https://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert video.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-22 07:37:45.385277
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple test for class HeiseIE
    """
    HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-22 07:37:49.148294
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test constructor of HeiseIE class
    """
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    expected = HeiseIE(url)
    assert expected == HeiseIE(url)



# Generated at 2022-06-22 07:37:51.218720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie != None

# Generated at 2022-06-22 07:37:52.718040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('')
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:38:03.285136
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import sys
    import os.path
    from .youtube import YouTubeIE
    from .common import InfoExtractor

    # Call the constructor of InfoExtractor
    ie = InfoExtractor()
    if ie.extractor_key == 'youtube':
        print('InfoExtractor constructor test: Pass')
    else:
        print('InfoExtractor constructor test: Fail')

    # Call the constructor of YouTubeIE
    yt = YouTubeIE()
    if yt.extractor_key == 'youtube':
        print('YouTubeIE constructor test: Pass')
    else:
        print('YouTubeIE constructor test: Fail')

    # Call the constructor of HeiseIE
    he = HeiseIE()
    if he.extractor_key == 'heise':
        print('HeiseIE constructor test: Pass')

# Generated at 2022-06-22 07:38:21.212646
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:38:32.398514
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i=HeiseIE()
    assert i._real_extract(
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert i._real_extract(
        "http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-22 07:38:37.232574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._match_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:38:41.095605
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE
    assert HeiseIE.__name__
    assert HeiseIE.__module__
    assert HeiseIE.IE_NAME
    assert HeiseIE.IE_DESC
    assert HeiseIE._VALID_URL
    assert HeiseIE._TESTS

# Generated at 2022-06-22 07:38:51.161638
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert HeiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert HeiseIE._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-22 07:38:59.391413
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_download import _TEST_CASES
    ie = HeiseIE()
    for test_url, expected_result in _TEST_CASES:
        url = ie.url_result(test_url)['url']
        assert url == expected_result
    ie.url_result('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')



# Generated at 2022-06-22 07:39:09.828475
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test youtube video
    yt_url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    test_HeiseIE = HeiseIE()
    yt_result = test_HeiseIE._real_extract(yt_url)

# Generated at 2022-06-22 07:39:16.766835
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Function to run tests of HeiseIE"""
    # We can't use unit test assertRaisesRegex because it is not available
    # on older python versions
    success = False
    msg = ""
    try:
        ct = HeiseIE()
        ct._get_available_subtitles()
    except NotImplementedError as e:
        msg = str(e)
    if msg == "Subtitle is not implemented for HeiseIE":
        success = True

    assert success, "NotImplementedError not thrown for HeiseIE"

# Generated at 2022-06-22 07:39:22.594841
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.__class__ == HeiseIE


# Generated at 2022-06-22 07:39:23.084745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:39:50.304770
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import inspect
    from youtube_dl import YoutubeDL
    """
    Get a class instance from an object
    """
    def _get_class_instance(obj, class_instance):
        args = inspect.getargspec(class_instance.__init__)[0]
        args.pop(0)
        f = lambda self: None
        f.__name__ = obj.__name__
        temp_class = type(obj.__name__, (class_instance,), {'__init__': f})
        return temp_class(*args)

    ydl = YoutubeDL({'format': 'ALL'})

# Generated at 2022-06-22 07:40:00.322928
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert ie.VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"
    assert ie._TESTS[0]['url'] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-22 07:40:02.976152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Constructor testing"""
    # Without API key
    assert HeiseIE()._AUTH_HOST == "https://login.heise.de"

# Generated at 2022-06-22 07:40:04.972898
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.url = ''
    assert ie

# Generated at 2022-06-22 07:40:13.247748
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:40:19.421455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = HeiseIE()
    urls = [
        (r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',)
    ]
    for url in urls:
        u.url_result(url)

# Generated at 2022-06-22 07:40:23.655171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.host() == 'heise.de'
    assert ie.description == 'Heise video website'
    assert ie._VALID_URL == HeiseIE.VALID_URL
    assert ie._TESTS == HeiseIE.TESTS

# Generated at 2022-06-22 07:40:29.059759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructing an object
    heise = HeiseIE()

    # Getting the class name of the object
    print('Class of the object: ', type(heise).__name__)
    # Checks if the object is an instance of the class InfoExtractor
    assert isinstance(heise, InfoExtractor)

# Generated at 2022-06-22 07:40:29.607841
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:37.201964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

# Generated at 2022-06-22 07:41:22.066137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie_instance = HeiseIE()
    assert heise_ie_instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-22 07:41:26.881517
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Tests if the constructor of HeiseIE works properly"""
    # Constructor of InfoExtractor class
    info_extractor = InfoExtractor(HeiseIE._VALID_URL)
    # Type of info_extractor is HeiseIE
    assert isinstance(info_extractor,HeiseIE)

# Generated at 2022-06-22 07:41:28.950860
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    heiseie.extract_info(HeiseIE._VALID_URL)

# Generated at 2022-06-22 07:41:29.769014
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	test = HeiseIE()

# Generated at 2022-06-22 07:41:36.281731
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for HeiseIE()"""
    heiseIE = HeiseIE()
    heiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Test for extractor HeiseIE

# Generated at 2022-06-22 07:41:48.121430
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/video/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:41:48.811778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:41:50.428492
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:41:53.346630
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    instance = hie(HeiseIE._VALID_URL)
    assert(instance.video_id == "2404147")

# Generated at 2022-06-22 07:41:58.675239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heiseIE = HeiseIE()
    heiseIE.extract(url)

# Generated at 2022-06-22 07:43:31.143148
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:43:32.907767
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE(None)
    assert x.ie_key() == 'Heise'

# Generated at 2022-06-22 07:43:35.462643
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    instance = class_()
    assert instance.ie_key() == 'heise'
    assert class_.ie_key() == 'heise'



# Generated at 2022-06-22 07:43:40.993421
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    IE.extract(url)
    return IE

# Generated at 2022-06-22 07:43:44.615416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:43:45.735386
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:43:54.161551
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    HeiseIE('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-22 07:43:54.788629
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:43:56.273805
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test for HeiseIE
    x = HeiseIE()
    print (x)

# Generated at 2022-06-22 07:44:00.628906
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'