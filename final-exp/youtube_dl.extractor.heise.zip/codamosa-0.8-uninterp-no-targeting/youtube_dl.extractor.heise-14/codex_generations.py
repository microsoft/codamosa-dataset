

# Generated at 2022-06-22 07:37:15.293525
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # json_ld key '@context' is not defined in HeiseIE()
    HeiseIE(url)

# Generated at 2022-06-22 07:37:24.346242
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    instance.downloader = type('Downloader', (object,), {
        'to_screen': lambda self, message: None,
        'report_warning': lambda self, message: None,
        'report_error': lambda self, message: None,
        'params': {'nooverwrites': True},
    })()
    instance._download_webpage = lambda x, y: None
    instance._sort_formats = lambda x: 0
    instance._download_xml = lambda x, y, z: None
    instance._search_regex = lambda x, y, z, w, v=None: None
    instance._html_search_regex = lambda x, y, z, w=None: None
    instance._og_search_description = lambda x, y=None: None
    instance.ie_

# Generated at 2022-06-22 07:37:28.360967
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:37:40.148940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:37:41.779801
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.ie_key() == 'heise'

# Generated at 2022-06-22 07:37:48.819902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    ie.extract('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-22 07:37:52.073176
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    attrs = ('_real_initialize', '_real_extract')
    instance = HeiseIE()
    assert all(hasattr(instance, attr) for attr in attrs)

# Generated at 2022-06-22 07:37:53.598206
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    VideoIE.test_video_ie(HeiseIE, ['heise'])

# Generated at 2022-06-22 07:37:54.710709
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()

# Generated at 2022-06-22 07:37:58.636527
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:38:21.991530
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if class HeiseIE can be instantiated
    HeiseIE()
    # Test if the class can be instantiated with a empty url
    HeiseIE(url='')
    # Test if the class can be instantiated with a url
    HeiseIE(url='https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:38:33.411112
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/video/artikel/Neues-von-Microsoft-Windows-10-Oktober-2018-Update-laut-Bericht-swift-3959243.html')
    assert ie.suitable('https://www.heise.de/video/artikel/Internet-of-Things-Sicherheit-Raspberry-Pi-und-Windows-10-fuer-Embedded-Systems-3814190.html')

# Generated at 2022-06-22 07:38:38.107580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, YoutubeIE)
    assert ie.__name__ == 'heise'
    assert getattr(ie, "IE_NAME", None) == 'heise'

# Generated at 2022-06-22 07:38:48.345229
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.findall('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')[0] == '2403911'
    assert HeiseIE._VALID_URL.findall('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html')[0] == '2404251'
    assert HeiseIE._VALID_URL.findall('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')[0] == '3214137'

# Generated at 2022-06-22 07:38:53.938924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    expected_result = True
    result = (heise.suitable({'ext': 'mp4'}))
    assert result == expected_result

    heise = HeiseIE()
    expected_result = False
    result = (heise.suitable({'ext': 'mp4'}) == expected_result)
    assert result == expected_result

# Generated at 2022-06-22 07:38:58.857943
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test empty constructor
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == HeiseIE._VALID_URL
    assert heiseIE.__name__ == 'Heise'
    assert heiseIE.ie_key() == 'Heise'
    assert heiseIE.test()

# Generated at 2022-06-22 07:39:03.792817
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    TestHeiseIE = HeiseIE()
    assert TestHeiseIE._VALID_URL == HeiseIE._VALID_URL
    assert TestHeiseIE._TESTS == HeiseIE._TESTS
    assert TestHeiseIE.IE_NAME == HeiseIE.IE_NAME
    assert TestHeiseIE.IE_DESC == HeiseIE.IE_DESC
    assert TestHeiseIE._VALID_URL == HeiseIE._VALID_URL



# Generated at 2022-06-22 07:39:08.450132
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert str(ie) == '<HeiseIE https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html>'

# Generated at 2022-06-22 07:39:10.132834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:39:18.405046
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # rtmp streams don't work behind proxies -> make sure we have none set
    import os
    rtmp_envvars = ('RTMP_CONNECTION', 'RTMP_SWFVFY', 'RTMP_SWFURL',
                    'RTMP_APP', 'RTMP_PLAYPATH',)
    rtmp_envvar_backup = {}
    for rtmp_envvar in rtmp_envvars:
        if rtmp_envvar in os.environ:
            rtmp_envvar_backup[rtmp_envvar] = os.environ[rtmp_envvar]
        os.environ.pop(rtmp_envvar, None)
    # actually test extraction
    ie = HeiseIE()

# Generated at 2022-06-22 07:39:54.934404
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == isinstance(ie._VALID_URL, str)


# Generated at 2022-06-22 07:40:06.542556
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:40:13.921061
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HEISE parser
    ie = HeiseIE()
    ie._download_webpage = lambda x, y: None
    ie._html_search_regex = lambda x, y: '47e8ffb6c46d85c92c310a512d6db271'
    ie._search_regex = lambda x, y, z: '1_59mk80sf'
    ie._download_xml = lambda x, y, z: None
    ie._og_search_description = lambda x: None
    ie._html_search_meta = lambda x: None
    ie._og_search_thumbnail = lambda x: None
    ie._search_regex = lambda x, y, z: None
    ie._og_search_title = lambda x: None

# Generated at 2022-06-22 07:40:15.970939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    d = HeiseIE()
    assert d.name == 'heise'
    assert d.ie_key() == 'Heise'

# Generated at 2022-06-22 07:40:19.636692
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-22 07:40:23.523818
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie.extract(url)

# Generated at 2022-06-22 07:40:24.441789
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:27.918859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE._TESTS == HeiseIE._TESTS


# Generated at 2022-06-22 07:40:29.533441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:40:32.962610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:41:19.072256
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-22 07:41:30.062147
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:41:33.272893
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-22 07:41:39.885255
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  # HeiseIE('<url>')
  assert HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:41:44.937330
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:41:57.020783
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    input_str = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    obj1 = HeiseIE(FakeYDL())
    result = obj1.suitable(input_str)
    assert result is True
    obj2 = HeiseIE(FakeYDL())
    result = obj2.suitable(
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert result is True
    obj3 = HeiseIE(FakeYDL())

# Generated at 2022-06-22 07:42:01.592175
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'
    assert ie.SUBTITLE_EXT == '.vtt'

# Generated at 2022-06-22 07:42:12.123336
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print(HeiseIE._construct_url(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'))
    print(HeiseIE._construct_url(
        'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'))

# Generated at 2022-06-22 07:42:21.941514
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'Heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:42:27.946412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert hie.__name__ == 'Heise'
    assert hie.ie_key() == 'heise'

# Generated at 2022-06-22 07:44:11.195521
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ''' Test HeiseIE.__init__() '''

# Generated at 2022-06-22 07:44:11.809314
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:44:14.625326
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_video = HeiseIE()
    assert heise_video is not None

# Generated at 2022-06-22 07:44:15.920116
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('HeiseIE')

# Generated at 2022-06-22 07:44:19.435108
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:44:24.402411
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video = HeiseIE()

    # test for valid URL
    assert video.suitable(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    # test for invalid URL
    assert not video.suitable('http://www.heise.de/')

# Generated at 2022-06-22 07:44:28.912017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    ie = HeiseIE()
    ie.get_info(url)

# Generated at 2022-06-22 07:44:31.630344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ This function removes the HeiseIE class to cover all lines of code. """
    heiseIE = HeiseIE.HeiseIE(InfoExtractor())
    assert heiseIE

# Generated at 2022-06-22 07:44:33.913625
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        h = HeiseIE()
    except Exception as e:
        print('test_HeiseIE failed: ' + str(e))
        raise

# Generated at 2022-06-22 07:44:34.929536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())