

# Generated at 2022-06-22 07:37:11.988380
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE.bonus.test_HeiseIE()

test_HeiseIE()

# Generated at 2022-06-22 07:37:13.441040
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-22 07:37:14.416435
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:37:23.712884
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:24.830944
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-22 07:37:27.088547
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:37:29.005275
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie.name == 'heise'

# Generated at 2022-06-22 07:37:30.068628
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    int_or_none('1')

# Generated at 2022-06-22 07:37:41.452030
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	t1 = HeiseIE('https://www.heise.de/ct/artikel/Bild-Unter-der-Haube-der-GameCube-152431.html')
	t2 = HeiseIE('https://www.heise.de/ct/artikel/Bild-Unter-der-Haube-der-GameCube-152431.html')
	t3 = HeiseIE('https://www.heise.de/ct/artikel/Bild-Unter-der-Haube-der-GameCube-152431.html')
	assert (t1._VALID_URL == t2._VALID_URL == t3._VALID_URL)
	assert (t1.name == t2.name == t3.name)

# Generated at 2022-06-22 07:37:42.993601
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h


# Generated at 2022-06-22 07:38:02.633416
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructing an instance of HeiseIE should not result in an exception
    """
    ie = HeiseIE("")
    pass

# Generated at 2022-06-22 07:38:04.801601
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # HeiseIE is tested in test_downloader
    pass

# Generated at 2022-06-22 07:38:07.138323
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie.ie_key() == 'heise'

# Generated at 2022-06-22 07:38:09.493832
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for HeiseIE.__init__."""
    heise = HeiseIE()
    assert heise is not None


# Generated at 2022-06-22 07:38:21.629189
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie.ie_key() == 'heise'
    assert ie.video_id == '1'
    assert ie._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'

# Generated at 2022-06-22 07:38:22.723456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:38:25.993061
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The constructor of class InfoExtractor
    ie = InfoExtractor(None, {}, True)

    # The constructor of class HeiseIE
    ie.HeiseIE(None, {}, True)


# Generated at 2022-06-22 07:38:26.656930
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:38:27.184204
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:38:35.783367
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heisede", "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    assert(ie.API_BASE == "http://www.heise.de")
    assert(isinstance(ie.ie_key(), str))
    assert(isinstance(ie.ie_name(), str))

# Generated at 2022-06-22 07:38:56.055239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert(HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert(HeiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert(HeiseIE._TESTS[1]['url'] == 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:38:58.204508
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # parse HeiseIE
    # constructor of HeiseIE
    assert(HeiseIE)
    return


# Generated at 2022-06-22 07:39:02.210026
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-22 07:39:07.732690
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Container and sequenz are defined in the first video article
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    result = HeiseIE().url_result(url)
    assert result.video_id == '1_kkrq94sm'

# Generated at 2022-06-22 07:39:10.229350
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE_instance = HeiseIE()
    assert heiseIE_instance.ie_key() == 'heise'

# Generated at 2022-06-22 07:39:13.389310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.constructor_test('Heise')
    
if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-22 07:39:16.754766
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # result = ie.extract(url)
    # print(result)
    assert ie.suitable(url)

# Generated at 2022-06-22 07:39:18.661819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL



# Generated at 2022-06-22 07:39:22.201395
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testobj = HeiseIE()
    assert testobj.extractor_key == 'HeiseIE'
    assert testobj.video_id_pattern == r'(?P<id>[0-9]+)'

# Generated at 2022-06-22 07:39:25.878448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	# Test initialization and checking of HeiseIE object
	# This test checks if object is instance of InfoExtractor and it's
	# inheritor in tree
	assert isinstance(HeiseIE(''), InfoExtractor)
	assert isinstance(HeiseIE(''), KalturaIE)
	assert isinstance(HeiseIE(''), YoutubeIE)

# Generated at 2022-06-22 07:39:59.413632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract()

# Generated at 2022-06-22 07:40:00.989605
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie)


# Generated at 2022-06-22 07:40:11.497994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:40:16.469909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:40:17.274459
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:25.665849
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(downloader=None)
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert not ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:40:35.547800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert obj._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert obj._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert obj._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:40:46.872804
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import re
    assert re.match(HeiseIE._VALID_URL, "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert re.match(HeiseIE._VALID_URL, "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")    
    assert re.match(HeiseIE._VALID_URL, "http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-22 07:40:57.337042
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of the info extractor
    heise_ie = HeiseIE()

    # Test case 1: URL with kaltura embed
    url_test_1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    info_dict_test_1 = heise_ie._real_extract(url_test_1)

    assert info_dict_test_1['id'] == '1_kkrq94sm'
    assert info_dict_test_1['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert info_dict_test_1['timestamp'] == 15127

# Generated at 2022-06-22 07:40:57.706377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:10.072173
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # An instance of HeiseIE
    assert isinstance(
        HeiseIE(InfoExtractor()), InfoExtractor)

# Generated at 2022-06-22 07:42:11.963471
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-22 07:42:15.700520
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check that HeiseIE can be instantiated
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-22 07:42:16.248803
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:17.412608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE is not None

# Generated at 2022-06-22 07:42:18.525337
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('video')
    HeiseIE('article')

# Generated at 2022-06-22 07:42:19.055824
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:25.191506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = {
        'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html',
        'info_dict': {'id': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'},
        'playlist_count': 16,
    }

    test_p = {
        'url': 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html',
        'only_matching': True,
    }


# Generated at 2022-06-22 07:42:27.598994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert type(ie) == HeiseIE

# Generated at 2022-06-22 07:42:28.611331
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('url')

# Generated at 2022-06-22 07:45:50.532634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    assert hie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:45:52.580432
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._V

# Generated at 2022-06-22 07:46:01.825819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()

# Generated at 2022-06-22 07:46:04.731166
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:46:15.318216
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_key() == ie.extract_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert '1_kkrq94sm' == ie.extract_id('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:46:17.115723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    H = HeiseIE()
    H.suite()

# Generated at 2022-06-22 07:46:19.102144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert isinstance(obj, HeiseIE)


# Generated at 2022-06-22 07:46:27.989806
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test of constructor of class HeiseIE
    # Create object of class HeiseIE
    test_heise_ie = HeiseIE("heise.de")
    # Test if _VALID_URL is set in constructor
    assert test_heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test if _TESTS is set in constructor
    assert test_heise_ie._TESTS

# Generated at 2022-06-22 07:46:31.966187
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Required parameters
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    ie = HeiseIE({})
    assert ie.suitable(url)

# Generated at 2022-06-22 07:46:37.961346
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'
    a = HeiseIE()
    a._real_initialize()
    a._real_extract(url)