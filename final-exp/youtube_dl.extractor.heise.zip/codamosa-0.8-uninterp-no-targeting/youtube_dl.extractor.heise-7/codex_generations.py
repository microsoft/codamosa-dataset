

# Generated at 2022-06-22 07:37:15.388308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie.__class__, 'ie_key')
    assert ie.__class__.ie_key() == 'heise'
    assert ie.__class__.ie_key() in ie.extractor_ids()
    assert not hasattr(ie.__class__, 'ie_name') or ie.__class__.ie_name() == 'heise'

# Generated at 2022-06-22 07:37:24.406405
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:36.054565
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-22 07:37:37.122031
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise is not None

# Generated at 2022-06-22 07:37:46.594046
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:57.741992
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise:video'
    assert ie.extract_id('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == 'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-22 07:38:07.638055
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:17.110172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:23.377671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_ie = HeiseIE( url, 'Video')
    assert heise_ie.module_name == 'Heise'

# Generated at 2022-06-22 07:38:24.450005
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE == type(HeiseIE({}))

# Generated at 2022-06-22 07:38:43.770297
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE.VALID_URL

# Generated at 2022-06-22 07:38:47.898574
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:38:49.427344
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    raise RuntimeError("Unit test not implemented")


# Generated at 2022-06-22 07:38:51.529583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    assert class_ is not None



# Generated at 2022-06-22 07:38:56.286354
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-22 07:39:08.306687
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .. import ydl
    ydl_opts = {
        'usenetrc': False,
        'username': 'test',
        'password': 'test',
        'quiet': True,
    }
    assert HeiseIE._download_webpage(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        '2404147').decode('utf-8') != ''

# Generated at 2022-06-22 07:39:13.569929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE._download_webpage("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html","1_kkrq94sm")

# Generated at 2022-06-22 07:39:25.210110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:37.441668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') == True

# Generated at 2022-06-22 07:39:44.367461
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert ie.suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-22 07:40:02.567994
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    HeiseIE._real_extract(instance, '')

# Generated at 2022-06-22 07:40:06.683071
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:07.689524
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()



# Generated at 2022-06-22 07:40:08.317694
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:40:14.650450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._real_initialize(url='http://heise.de/test')
    assert ie.SUCCESS == ie._request_webpage(
        'http://heise.de/test', None, 'Downloading webpage')
    assert ie.report_warning == ie._request_webpage(
        'http://heise.de/test', None, 'Downloading webpage',
        expected_status=(403, 404))
    assert ie.report_warning == ie._request_webpage(
        'http://heise.de/test', None, 'Downloading webpage',
        fatal=False)
    assert ie.report_warning == ie._request_webpage(
        'http://heise.de/test', None, 'Downloading webpage',
        fatal=False, expected_status=[403, 404])

# Generated at 2022-06-22 07:40:25.051832
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:40:28.072704
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE(None, {'_type': 'url'})
    assert instance.ie_key() == 'Heise'

# Generated at 2022-06-22 07:40:34.035080
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None).get_host_and_id() == (None, None)
    assert HeiseIE('').get_host_and_id() == (None, None)
    url = 'http://www.heise.de/tp/artikel/2/2898/1.html'
    assert HeiseIE(url).get_host_and_id() == ('www.heise.de', '2/2898/1')

# Generated at 2022-06-22 07:40:36.664131
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Check that it can be instantiated
    heise_ie = HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:40:42.377800
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ieInstance = HeiseIE()
    assert ieInstance.IE_NAME == 'heise'
    assert ieInstance.IE_DESC == 'Heise'
    assert ieInstance._VALID_URL == HeiseIE._VALID_URL
    assert ieInstance._TESTS == HeiseIE._TESTS
    assert ieInstance.ie_key() == 'heise'

# Generated at 2022-06-22 07:41:29.715419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_class = HeiseIE('HeiseIE', 'http://www.heise.de', {}, {}, {}, {})
    assert test_class.name == 'HeiseIE'
    assert test_class.base_url == 'http://www.heise.de'
    assert test_class.EXTENSIONS == ['mp4']

# Generated at 2022-06-22 07:41:31.538434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:41:41.986819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE(None, None, None)
    if heiseIE.VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html':
        assert True
    else:
        assert False

# Generated at 2022-06-22 07:41:45.089183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE.VALID_URL

# Generated at 2022-06-22 07:41:48.804567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    HeiseIE(url)

# Generated at 2022-06-22 07:41:50.013836
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:41:51.157140
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)

# Generated at 2022-06-22 07:41:52.260702
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()


# Generated at 2022-06-22 07:42:03.512859
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise

    heise_video_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html' # noqa
    heise_video_id = '1_kkrq94sm' # noqa
    heise_video_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone" # noqa
    heise_video_timestamp = 1512734959 # noqa
    heise_video_upload_date = '20171208' # noqa

# Generated at 2022-06-22 07:42:04.795110
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:43:45.487029
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test is working on the HeiseIE constructor
    # created by module name using parse_url
    # if the class name is changed, this test will fail.
    ie = InfoExtractor._create_ie('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')
    assert isinstance(ie, HeiseIE) # Check that the constructor was created

# Generated at 2022-06-22 07:43:49.964553
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE({})
    assert not x._LOGIN_URL
    assert not x._LOGIN_REQUIRED
    assert x._SEARCH_KEY
    assert x._BASE_URL
    assert not x._NETRC_MACHINE
    assert not x._VALID_URLs

# Generated at 2022-06-22 07:43:51.040630
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x is not None

# Generated at 2022-06-22 07:43:52.468654
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE({})
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-22 07:43:55.080409
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    print(hie)

if __name__ == '__main__':
    test_HeiseIE()

# End of HeiseIE

# Generated at 2022-06-22 07:43:57.339105
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # check class variables
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-22 07:44:00.913848
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE(InfoExtractor)  # pylint: disable=abstract-class-instantiated
    assert IE.name == HeiseIE.ie_key()

# Generated at 2022-06-22 07:44:02.967172
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseVideo = HeiseIE(None)
    assert heiseVideo is not None
    assert type(heiseVideo) == HeiseIE

# Generated at 2022-06-22 07:44:04.418894
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:44:05.116504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie