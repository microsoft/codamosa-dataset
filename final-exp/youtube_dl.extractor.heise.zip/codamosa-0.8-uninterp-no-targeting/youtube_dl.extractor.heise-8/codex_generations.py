

# Generated at 2022-06-22 07:37:10.443455
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        assert HeiseIE()
    except:
        print("Test failed")


# Generated at 2022-06-22 07:37:11.407726
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:37:12.846390
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:37:20.469372
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html', 'passed password')


# Generated at 2022-06-22 07:37:21.484082
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    with pytest.raises(Exception):
        heiseIE = HeiseIE()

# Generated at 2022-06-22 07:37:23.062047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({}, {},"")
    # Check for NullPointerException

# Generated at 2022-06-22 07:37:30.820638
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.is_gone('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    heise.is_gone('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:37:36.502754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        status = "Success"
    except ImportError as e:
        if "Couldn't find a parser" in str(e):
            status = "Module not available"
        else:
            status = "Failure"
    print("Execution Status: %s" % status)

if __name__ == "__main__":
    test_HeiseIE()

# Generated at 2022-06-22 07:37:39.517727
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-22 07:37:40.352768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:38:03.074971
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_IE_ = HeiseIE()
    assert heise_IE_._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise_IE_._LANG == 'de'

# Generated at 2022-06-22 07:38:14.472020
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = url2 = url3 = url4 = url5 = url6 = url7 = url8 = None
    url1 = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url2 = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    url3 = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
   

# Generated at 2022-06-22 07:38:18.657059
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie is not None


# Generated at 2022-06-22 07:38:20.586832
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-22 07:38:31.978438
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'heise'
    assert obj.ie_name() == 'heise.de'
    assert obj.suitable(url='http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert obj.suitable(url='http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-22 07:38:35.234391
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('www.heise.de', test = True)
    print(ie)
    return

# Generated at 2022-06-22 07:38:36.324393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test = HeiseIE()

# Generated at 2022-06-22 07:38:37.548191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("heise.de")
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:38:38.029195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    heiseIE

# Generated at 2022-06-22 07:38:42.945044
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extract(url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-22 07:39:21.127405
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        input = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
        ie = HeiseIE(input)
        assert ie != None
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-22 07:39:21.743727
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:39:29.006024
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")._VALID_URL == r"https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-22 07:39:33.973409
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    # check attributes were initialised correctly
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:43.788587
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.name == 'Heise'
    assert ie.host == 'heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:55.293610
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert not ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html?wt_mc=rss.ho.beitrag.atom')


# Generated at 2022-06-22 07:40:07.356312
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:40:12.565450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Arguments used by HeiseIE
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    ie = HeiseIE()
    ie.extract(url)

# Generated at 2022-06-22 07:40:23.714516
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:40:35.098853
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _test(url_type):
        if url_type == 'VIDEO_URL':
            url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
        else:
            url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
        video_id = HeiseIE._match_id(url)
        webpage = HeiseIE._download_webpage(url, video_id)

# Generated at 2022-06-22 07:41:25.431441
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.urls == [
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html",
        "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html",
    ]

# Generated at 2022-06-22 07:41:29.910247
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    instance = HeiseIE(IE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 07:41:31.339047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    o = HeiseIE()
    assert o.ie_key() == 'heise'

# Generated at 2022-06-22 07:41:41.987073
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._extract_url("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html") == (
        "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html",
        {"id": "2404147"}
    )

# Generated at 2022-06-22 07:41:47.306595
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

    assert(heise.get_id() == 'heise')
    assert(heise.get_description() == 'Heise.de news and videos')
    assert(heise.get_ie_key() == 'heise')
    assert(heise.get_name() == 'Heise')

# Generated at 2022-06-22 07:41:59.306929
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # Check that right instance is constructed
    assert isinstance(ie, HeiseIE)
    # Check that constructor does not raise any exceptions
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # Check that right instance is constructed
    assert isinstance(ie, HeiseIE)
    # Check that constructor does not raise any exceptions

# Generated at 2022-06-22 07:42:00.350153
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise=HeiseIE()

# Generated at 2022-06-22 07:42:02.180158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'


# Generated at 2022-06-22 07:42:02.736213
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:04.698583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-22 07:43:42.732624
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    HeiseIE()._real_extract(url)

# Generated at 2022-06-22 07:43:43.439506
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:43:45.102185
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj is not None


# Generated at 2022-06-22 07:43:45.743364
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:43:47.681484
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

    assert HeiseIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-22 07:43:50.072721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_HeiseIE import TestHeiseIE
    TestHeiseIE()

test_HeiseIE()

# Generated at 2022-06-22 07:43:54.699501
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    assert HeiseIE().suitable(video_url)

# Generated at 2022-06-22 07:43:56.178995
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    y = HeiseIE()
    y = HeiseIE(dict())

# Generated at 2022-06-22 07:44:07.586761
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    # Test cases with URLs of class HeiseIE
    ie.match_heise_url("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    ie.match_heise_url("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")

# Generated at 2022-06-22 07:44:19.140964
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    # heiseie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    # heiseie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    # heiseie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-root