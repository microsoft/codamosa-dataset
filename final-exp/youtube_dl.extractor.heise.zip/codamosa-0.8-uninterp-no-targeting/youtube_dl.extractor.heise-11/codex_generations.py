

# Generated at 2022-06-22 07:37:10.889159
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.update_video_url("")

# Generated at 2022-06-22 07:37:15.332388
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._VALID_URL == "http://www.heise.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-22 07:37:24.375875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test with embed from YouTube
    heise = HeiseIE("https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html")
    assert heise.ie_key() == YouTubeIE.ie_key()
    # Test with Kaltura video
    heise = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert heise.ie_key() == KalturaIE.ie_key()
    # Test with Heise video

# Generated at 2022-06-22 07:37:25.139864
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE is not None

# Generated at 2022-06-22 07:37:27.987018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-22 07:37:33.052156
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # constructor checks for "new" in URL
    with pytest.raises(RegexNotFoundError):
        HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")


# Generated at 2022-06-22 07:37:37.204940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    filename = './test/data/Heise.json'
    with open(filename) as data_file:
        for test in json.load(data_file):
            response = HeiseIE().extract(test)
            print(response)
test_HeiseIE()

# Generated at 2022-06-22 07:37:45.108064
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')

# Generated at 2022-06-22 07:37:52.481525
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    # Test for constructor with invalid url
    try:
        ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.invalid")
        assert(False)
    except RegexNotFoundError:
        assert(True)

# Generated at 2022-06-22 07:37:58.604721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from .test_youtube_dl.test_youtube_dl import YoutubeDL
        from .test_youtube_dl.test_youtube_dl import FakeYDL
    except (ImportError, AttributeError):
        return
    ydl = FakeYDL()
    assert isinstance(ydl, YoutubeDL)
    i = HeiseIE()
    assert isinstance(i, InfoExtractor)

# Generated at 2022-06-22 07:38:14.472138
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.get_url() == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie.get_extractor_key() == "HeiseIE"

# Generated at 2022-06-22 07:38:16.685838
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KalturaIE)
    assert isinstance(ie, YoutubeIE)

# Generated at 2022-06-22 07:38:19.742677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html'
    id = '1_ntrmio2s'
    assert HeiseIE._match_id(url) == id
    assert HeiseIE._match_id(id) == id

# Generated at 2022-06-22 07:38:20.949477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-22 07:38:22.454981
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-22 07:38:23.535180
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, None);

# Generated at 2022-06-22 07:38:25.449477
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE(downloader=None)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 07:38:30.348179
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL.match('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-22 07:38:34.794827
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Unit test for constructor of class HeiseIE
    heise_info = HeiseIE()
    assert heise_info
    print("HeiseIE is initialized.") # test is passed.

if __name__ == '__main__':
    test_HeiseIE()

# Generated at 2022-06-22 07:38:36.322948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:38:54.370257
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()


# Generated at 2022-06-22 07:38:55.915263
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()
    YoutubeIE()
    KalturaIE()

# Generated at 2022-06-22 07:39:00.599655
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    '''
    Unit test for the constructor of class HeiseIE.
    '''
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseIE = HeiseIE(url)
    assert heiseIE.url == url

# Generated at 2022-06-22 07:39:09.787668
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    testing_instances = [
        # normal cases
        {'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'},
        {'url': 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'}
    ]
    assert_instances(class_, testing_instances)

# Generated at 2022-06-22 07:39:15.509112
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'Heise'
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseIE._TESTS

# Generated at 2022-06-22 07:39:17.218407
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:39:17.883120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:39:20.778371
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'

# Generated at 2022-06-22 07:39:21.314746
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:39:22.201054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HIE = HeiseIE()

# Generated at 2022-06-22 07:39:59.529108
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    #Tests constructor HeiseIE

    #With invalid values
    assert HeiseIE(None, None) == None

    #With valid values
    assert HeiseIE(InfoExtractor._WORKING_URL_RE, None)

# Generated at 2022-06-22 07:40:10.620937
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for the constructor
    ie = HeiseIE('HeiseIE', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', 'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html','1_ntrmio2s','nachgehakt: Wie sichert das c&#x27;t-Tool Restric&#x27;tor Windows 10 ab?','md5:47e8ffb6c46d85c92c310a512d6db271')
    # Check for video

# Generated at 2022-06-22 07:40:16.117155
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie_instance = HeiseIE()
    assert heise_ie_instance.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == True

# Generated at 2022-06-22 07:40:17.266359
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert_raises(TypeError, HeiseIE)

# Generated at 2022-06-22 07:40:19.920612
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')


# Generated at 2022-06-22 07:40:20.951194
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
   ie = HeiseIE()

# Generated at 2022-06-22 07:40:23.259664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)
    assert ie._VALID_URL == HeiseIE._VALID_URL


# Generated at 2022-06-22 07:40:28.180162
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE({})
    assert ie._VALID_URL==r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:40:37.869647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()

# Generated at 2022-06-22 07:40:47.919391
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:42:03.429386
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:42:05.775223
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_result = HeiseIE()
    assert(test_result == HeiseIE)


# Generated at 2022-06-22 07:42:06.791837
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:15.200891
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie._VALID_URL=='https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\\.html'

# Generated at 2022-06-22 07:42:17.634714
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(True)
    assert ie.ie_key() == "Heise"
    assert ie.ie_name() == "Heise"

test_HeiseIE()

# Generated at 2022-06-22 07:42:21.284634
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert obj.__class__.__name__ == 'HeiseIE'
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-22 07:42:22.203538
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(request=None)

# Generated at 2022-06-22 07:42:23.179191
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_case = HeiseIE()

# Generated at 2022-06-22 07:42:23.767394
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:35.812647
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple unit test for function constructor of class HeiseIE
    """
    #Get parameters
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    #Call the constructor
    heise_ie = HeiseIE()
    #Test the extraction
    heise_ie.extract(url)
    #Check if url attribute exists
    if not hasattr(heise_ie, "url"):
        raise AssertionError("Expected url attribute does not exist")
    if not heise_ie.url:
        raise AssertionError("Expected url attribute is equal to %s" % url)

# Generated at 2022-06-22 07:45:52.637400
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:45:57.188124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    req_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    properties = HeiseIE._match_id(req_url)
    assert properties == "2404147"

# Generated at 2022-06-22 07:46:04.966831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    regex_id = r'^[0-9]{1,}$'
    regex_title = r'^(.){1,}$'
    regex_url = r'^https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+.html'
    ie = HeiseIE()
    ie_result = ie.extract(url)
    assert ie_result['_type'] == 'url_transparent'
    assert ie_result['id'] is not None
    assert ie_result['title'] is not None

# Generated at 2022-06-22 07:46:10.167771
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()
    hie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-22 07:46:15.407869
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE()
    assert i.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not i.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:46:17.114522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:46:19.843766
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_var = HeiseIE('url', {'source_url': 'url'})
    # class_var.suitable('url')
    assert class_var.ie_key() == 'heise'

# Generated at 2022-06-22 07:46:22.928968
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    Test = HeiseIE([], {})
    assert Test

# Generated at 2022-06-22 07:46:28.491073
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Arrange
    ie = HeiseIE()

    # Assert
    assert ie is not None
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'Heise'
    assert ie.http_headers() is None
    assert ie.working_as_of() is None
    assert ie.version() == '0.0.1'



# Generated at 2022-06-22 07:46:35.243874
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert ie.id == "1_kkrq94sm"
    assert ie.ext == "mp4"
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.timestamp == 1512734959