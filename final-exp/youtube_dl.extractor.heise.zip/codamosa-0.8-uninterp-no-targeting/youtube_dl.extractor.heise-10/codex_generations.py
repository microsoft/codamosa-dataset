

# Generated at 2022-06-22 07:37:18.304738
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor without an URL should fail
    try:
        HeiseIE()
        raise AssertionError("Constructor without an URL should fail")
    except TypeError:
        pass

    # Constructor with a correct URL should succeed
    try:
        HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    except TypeError:
        raise AssertionError("Constructor with a correct URL should succeed")

# Generated at 2022-06-22 07:37:21.515183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == HeiseIE._VALID_URL
    assert ie.__name__ == 'Heise'
    assert ie.ie_key() == 'Heise'
    assert ie.test() is False

# Generated at 2022-06-22 07:37:23.439211
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:37:24.604325
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    hie = HeiseIE()

# Generated at 2022-06-22 07:37:27.298275
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL(HeiseIE._TESTS[0]['url'])
    assert ie

# Generated at 2022-06-22 07:37:29.895167
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    constructor = HeiseIE.__init__
    assert constructor.__doc__ is not None

# Generated at 2022-06-22 07:37:39.746268
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().ie_key() == 'heise'

    # Unit test for method _real_extract of class HeiseIE
    heise_url = 'http://www.heise.de/video/artikel/' \
                'Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

    heise_id = HeiseIE()._real_extract(heise_url)['id']
    assert heise_id == '1_kkrq94sm'

    # Test if the correct  extractor is called
    heise_result = HeiseIE()._real_extract(heise_url)

    assert heise_result['_type'] == 'url_transparent'

    # Test if the constructor of enemy

# Generated at 2022-06-22 07:37:46.863238
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    kaltura_url = 'kaltura:2238431:1_kkrq94sm'
    # noinspection PyTypeChecker
    heise_ie = HeiseIE(url, kaltura_url)
    heise_ie.test_result()

# Generated at 2022-06-22 07:37:54.336071
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    # Test _real_extract()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    webpage = ie._download_webpage(url, '1_kkrq94sm')
    k

# Generated at 2022-06-22 07:37:57.897677
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:08.809423
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'Heise'



# Generated at 2022-06-22 07:38:09.449502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-22 07:38:12.911237
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_download import MockCache
    ie = HeiseIE(MockCache)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KalturaIE)
    assert isinstance(ie, YoutubeIE)
    return True

# Generated at 2022-06-22 07:38:20.620627
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test for constructor of class HeiseIE."""
    path = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE(path)
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:26.846498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Unit test for constructor of class HeiseIE """
    from .test_utils import construct_test
    construct_test(HeiseIE, [
        ("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html", {}),
    ])

# Generated at 2022-06-22 07:38:28.277074
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'

# Generated at 2022-06-22 07:38:36.592014
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import assert_equal, GeneratorTestCase

    module = sys.modules[__name__]
    class_name = module.__name__[0].upper() + module.__name__[1:]
    class_ = getattr(module, class_name)

    with GeneratorTestCase(class_) as test_case:
        for url in set(test_case.test_urls):
            yield (test_case.run, class_, url)


if __name__ == '__main__':
    sys.exit(test_main())

# Generated at 2022-06-22 07:38:46.782948
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of the HeiseIE class
    ie = HeiseIE()

    # Following matching groups are expected with the unit test 
    # The test URL is: http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    expected_id = '1_kkrq94sm'
    expected_ie_key = 'Kaltura'
    expected_title = "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    expected_description = 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    expected_upload_date = '20171208'
    expected_thumbnail

# Generated at 2022-06-22 07:38:47.419065
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-22 07:38:48.771154
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise != None

# Generated at 2022-06-22 07:38:58.525755
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE("heise")

# Generated at 2022-06-22 07:39:00.781268
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .travis import TravisTest
    TravisTest(HeiseIE, needs_network=True)

# Generated at 2022-06-22 07:39:11.545179
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test.test_media_info import create_media

    media_info = create_media(1547852400, 'https://www.heise.de/video/artikel/Facebook-nach-Datenleak-Wir-haben-ein-Problem-mit-unserer-App-3980851.html', 'c\'t uplink 18.1: Facebook nach Datenleak / Gefahren durch ungültige Zertifikate')

    assert media_info.title == 'c\'t uplink 18.1: Facebook nach Datenleak / Gefahren durch ungültige Zertifikate'
    assert media_info.date == '20190118'
    assert media_info.site == 'heise'
    assert media_info.cover.startswith

# Generated at 2022-06-22 07:39:15.620844
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of class HeiseIE is tested by calling _real_extract() method
    # of class HeiseIE which is implemented by calling constructor of class
    # HeiseIE
    HeiseIE()._real_extract('')

# Generated at 2022-06-22 07:39:20.515087
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.de_ie_key() == 'heise'

# Generated at 2022-06-22 07:39:22.165320
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()
    assert info_extractor.ie_key() == "Heise"

# Generated at 2022-06-22 07:39:28.698357
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    hie = HeiseIE()
    assert hie._VALID_URL == "https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html"

# Generated at 2022-06-22 07:39:29.377068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE

# Generated at 2022-06-22 07:39:39.838171
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = "2404147"
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    constructor = HeiseIE(None)._constructor
    o = constructor(url)
    assert o._extract_m3u8_formats
    assert o.ie_key() == 'Heise'
    assert o.ie_name() == 'heise'
    assert o._VALID_URL == HeiseIE._VALID_URL
    assert o._TESTS == HeiseIE._TESTS
    assert o.expected_results == HeiseIE.expected_results

# Generated at 2022-06-22 07:39:42.466019
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Simple test for constructors
    heiseIE = HeiseIE()
    assert heiseIE is not None

# Generated at 2022-06-22 07:40:09.377578
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert not ie.suitable('https://www.heise.de/thema/https')
    assert not ie.suitable('https://www.heise.de/thema/https')


# Generated at 2022-06-22 07:40:13.253300
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = InfoExtractor.infoExtractor(HeiseIE.ie_key())
    assert ie.ie_key() == 'Heise'
    assert ie.ie_key() == HeiseIE.ie_key()


# Generated at 2022-06-22 07:40:19.052189
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.__name__ == 'heise'
    assert ie.ie_key() == 'heise'

# Generated at 2022-06-22 07:40:26.317305
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:27.222887
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-22 07:40:30.512419
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie_object = HeiseIE()
    assert heise_ie_object.ie_key() == 'heise'
    assert heise_ie_object.ie_name() == 'Heise'

# Generated at 2022-06-22 07:40:31.980311
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	x = HeiseIE(None)
	assert isinstance(x,HeiseIE)

# Generated at 2022-06-22 07:40:33.866288
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-22 07:40:39.855706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import HeiseIE
    # HeiseIE is a module that contains an InfoExtractor class (HeiseIE),
    # so we should be able to construct an instance of it
    assert HeiseIE is not None
    # The class will be initialised once by youtube-dl
    HeiseIE = None

# Generated at 2022-06-22 07:40:49.028985
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def test_construct_heise_ie(url):
        ie = HeiseIE(url)
        assert ie is not None


# Generated at 2022-06-22 07:41:33.798310
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-22 07:41:38.617028
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie.ie_key() == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.VIDEO_URL_TEMPLATE == 'http://www.heise.de/video/artikel/{id}.html'

# Generated at 2022-06-22 07:41:39.672183
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:41:51.636566
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    i = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert i._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:41:53.214681
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instance = HeiseIE()
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-22 07:41:54.554022
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:42:03.880474
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:42:05.498468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:42:07.179178
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None, None)

# Generated at 2022-06-22 07:42:08.299422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    return HeiseIE({})

# Generated at 2022-06-22 07:43:46.844162
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE("https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")._real_extract("https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html") #pylint: disable=protected-access
    assert info["id"] == "3214137"
    assert info["title"] == "c't 2016, Heft 12"

# Generated at 2022-06-22 07:43:51.293563
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test for an XML parsing error.
    # This URL returns garbage content but it's not enough to trigger
    # an HTTP error warning.
    ie = InfoExtractor(HeiseIE, 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.ie_key() == 'heise'
    return

# Generated at 2022-06-22 07:43:52.715745
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:43:58.084608
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test cases
    url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # Instantiate instance
    i = HeiseIE(url)
    # Checks
    assert i.get_url() == url

# Generated at 2022-06-22 07:44:09.012850
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.ie_key() == 'heise'
    ie = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    # NOTE:  assertEqual is an unordered comparison.
    assert ie.SUFFIX == '.html'
    assert ie.VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-[0-9]+\.html'

# Generated at 2022-06-22 07:44:14.364707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'heise'
    assert heise.ie_name() == 'heise.de'
    assert heise.ie_urls() == ['heise.de']
    assert heise.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:44:14.978713
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:44:16.835582
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    # Tests running of constructor of HeiseIE
    HeiseIE()

# Generated at 2022-06-22 07:44:17.490782
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-22 07:44:20.699457
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise'
    assert ie.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
    assert HeiseIE.ie_key() == 'heise'
