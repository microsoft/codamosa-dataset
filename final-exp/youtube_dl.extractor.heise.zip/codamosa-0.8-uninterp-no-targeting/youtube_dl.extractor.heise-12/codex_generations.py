

# Generated at 2022-06-22 07:37:20.467188
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    'Test constructor of class HeiseIE'
    #without passing any argument
    assert HeiseIE()

    #with passing a single argument
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

    #with passing two arguments
    assert HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html', '1_kkrq94sm')

# Generated at 2022-06-22 07:37:25.559749
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")
    

# Generated at 2022-06-22 07:37:27.509235
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor of HeiseIE should not raise an exception
    ie = HeiseIE(None)
    assert ie is not None

# Generated at 2022-06-22 07:37:29.496970
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test constructor of class
    instance = HeiseIE(InfoExtractor())
    assert isinstance(instance, HeiseIE)

# Generated at 2022-06-22 07:37:36.111358
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # No unit test extraction for now
    # url = "https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html"
    # test_data = ie._download_webpage(url, 4169439)
    # assert test_data !=None

# Generated at 2022-06-22 07:37:41.197316
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-22 07:37:47.244889
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .heise import HeiseIE
    ie = HeiseIE()
    assert ie.__name__ == 'Heise.de'
    assert ie.ie_key() == 'heise'
    assert ie.host() == 'heise.de'
    assert ie.base_url() == 'http://www.heise.de/'
    assert ie.description() == 'Heise.de'


# Test class HeiseIE

# Generated at 2022-06-22 07:37:50.294308
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.BASE_URL == "http://www.heise.de"
    assert ie.IE_NAME == "heise"


# Generated at 2022-06-22 07:37:56.868940
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone" == ie._extract_title()

# Generated at 2022-06-22 07:37:58.684530
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-22 07:38:18.443522
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie
    return ie

# Generated at 2022-06-22 07:38:19.819732
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().IE_DESC == 'Heise'

# Generated at 2022-06-22 07:38:27.108201
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test whether it raises an exception on a webpage with no video
    webpage = 'http://www.heise.de/newsticker/meldung/Logitech-Bluetooth-Multi-Device-Keyboard-K480-Erste-Tastatur-fuer-Computer-und-Smartphones-2333131.html'
    ie._download_webpage = lambda *args, **kwargs: webpage
    assert_raises(ExtractorError, ie.suitable, webpage)

# Generated at 2022-06-22 07:38:32.100926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL == HeiseIE._VALID_URL)
    assert(ie.IE_NAME == HeiseIE.IE_NAME)
    assert(ie.ie_key() == HeiseIE.ie_key())

# Generated at 2022-06-22 07:38:33.414133
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE({})

# Generated at 2022-06-22 07:38:37.681418
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    ie = HeiseIE()
    assert ie.name == "heise"
    assert ie.ie_key() == "heise"
    assert ie.description() == "All about digital life"

# Generated at 2022-06-22 07:38:39.998716
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # try to test the constructor of a class HeiseIE
    heise_ie = HeiseIE()
    assert heise_ie != None


# Generated at 2022-06-22 07:38:41.000466
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-22 07:38:42.729644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert_equal(ie.ie_key(), 'Heise')

# Generated at 2022-06-22 07:38:43.674972
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie.NAME == 'heise')

# Generated at 2022-06-22 07:39:19.541245
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:39:21.782902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise.de'

# Generated at 2022-06-22 07:39:22.785632
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()

# Generated at 2022-06-22 07:39:35.389937
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert not ie.suitable("https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html")

# Generated at 2022-06-22 07:39:38.931504
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")

# Generated at 2022-06-22 07:39:48.550223
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.format == "mp4"
    assert ie.timestamp == 1512734959
    assert ie.upload_date == "20171208"
    assert ie.description == "md5:c934cbfb326c669c2bcabcbe3d3fcd20"


# Generated at 2022-06-22 07:40:00.311988
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.extractor_key == 'heise'
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:40:03.330450
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE.ie_key() == 'heise'
    assert heiseIE.ie_name() == 'heise'

# Generated at 2022-06-22 07:40:11.326487
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	m = HeiseIE("HeiseIE","https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
	assert m.name == "HeiseIE"
	assert m._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'


# Generated at 2022-06-22 07:40:16.564554
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().extract({'url': 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'}) is not None

# Generated at 2022-06-22 07:41:48.909896
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:42:00.845743
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:42:02.408972
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:42:03.591707
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie.name == 'heise'

# Generated at 2022-06-22 07:42:10.027567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test import *

    if not os.path.exists('test.mp4'):
        pytest.skip('test.mp4 not found')

    assert os.path.exists('test.mp4')

    url = urljoin('file:', 'test.mp4')
    ie = HeiseIE(url)

    assert ie.url == url
    assert ie.media_id == 'test'

# Generated at 2022-06-22 07:42:17.126675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
#   Unit test for constructor of class HeiseIE

    from youtube_dl.compat import compat_str

    ie = HeiseIE()

# Generated at 2022-06-22 07:42:23.992720
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
	assert HeiseIE().suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
	assert HeiseIE().suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-22 07:42:27.451004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    # test when class is imported
    heise.register_ie(HeiseIE.ie_key())

# Generated at 2022-06-22 07:42:30.049787
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert isinstance(heise_ie, HeiseIE)
    assert isinstance(heise_ie, InfoExtractor)

# Generated at 2022-06-22 07:42:34.553210
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  assert HeiseIE(None)._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:46:08.795926
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_for_constructor(HeiseIE)

# Generated at 2022-06-22 07:46:17.605410
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    url = 'https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heise_page = HeiseIE()._real_extract(url)
    assert heise_page['id'] == '1_kkrq94sm'
    assert heise_page['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

    # https://www.heise.de/tr/art

# Generated at 2022-06-22 07:46:19.879283
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        print("Could not instantiate HeiseIE")
        raise

# Generated at 2022-06-22 07:46:26.720833
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    obj = HeiseIE()
    assert obj.ie_key() == 'heise'
    assert obj.ie_name() == 'Heise'
    assert obj.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')


# Generated at 2022-06-22 07:46:30.503035
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    obj = HeiseIE(url)
    assert obj.IE_NAME == "Heise"

# Generated at 2022-06-22 07:46:33.119239
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print("Test for class HeiseIE")
    # Init HeiseIE
    # Check if returned dict is instance of InfoExtractor
    ie = HeiseIE() # type: InfoExtractor
    print("%s" % ie)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:46:42.188721
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """ Test case for HeiseIE constructor """

    # Test without any parameters
    instance = HeiseIE()
    # Test with empty parameters
    instance = HeiseIE(None)
    # Test with video URL
    instance = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') # pylint: disable=line-too-long
    # Test with video_id
    instance = HeiseIE(video_id='123456')

# Generated at 2022-06-22 07:46:43.546456
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:46:44.985612
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE(InfoExtractor())
    return

# Generated at 2022-06-22 07:46:48.734936
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The first argument is the URL to be used in the test.
    # The second argument is a list of expected InfoExtractor keywords.
    # The third argument is a list of expected InfoExtractor i.e. classes
    ie = HeiseIE("http://heise.de/")
    assert ie.ie_key() == "Heise"