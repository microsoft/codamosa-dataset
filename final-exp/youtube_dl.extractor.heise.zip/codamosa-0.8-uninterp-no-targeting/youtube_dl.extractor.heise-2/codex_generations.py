

# Generated at 2022-06-22 07:37:17.427139
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Unit test for constructor of class HeiseIE
    """
    url = "http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html"
    heise = HeiseIE()
    heise.extract(url)

# Generated at 2022-06-22 07:37:18.628764
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Create an instance of class HeiseIE
    _ = HeiseIE('heise')

# Generated at 2022-06-22 07:37:29.116089
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:30.655470
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Constructor function of HeiseIE()
    # HeiseIE()
    pass

# Generated at 2022-06-22 07:37:33.934802
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    try:
        assert ie.ie_key() == 'heise'
        assert ie.ie_name() == 'Heise'
        assert ie.SUCCESS == True
    except AssertionError:
        print('Failure')

# Generated at 2022-06-22 07:37:35.028128
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('Heise')

# Generated at 2022-06-22 07:37:46.395705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == (r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    assert heise._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heise._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert heise._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:37:46.800568
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:37:48.456618
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.IE_NAME # should not raise an exception

# Generated at 2022-06-22 07:37:50.024879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    ie = HeiseIE()

    assert isinstance(ie._VALID_URL, str)
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:37:59.944831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    "Constructor of class HeiseIE"
    heise = HeiseIE()

# Generated at 2022-06-22 07:38:04.138257
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:38:14.847200
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_inst = HeiseIE()
    assert test_inst._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:16.097980
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:38:16.737768
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

# Generated at 2022-06-22 07:38:19.068321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    print('test_HeiseIE: constructor')
    heise = HeiseIE()
    assert heise.movie_info == {}


# Generated at 2022-06-22 07:38:23.274939
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.name == 'Heise'

# Generated at 2022-06-22 07:38:31.127111
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    loader = HeiseIE()
    assert loader._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert loader._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'

# Generated at 2022-06-22 07:38:32.344251
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie=HeiseIE()
    assert ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:38:38.920434
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    v = "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"
    h = HeiseIE()
    data = h.extract(v)

# Generated at 2022-06-22 07:38:55.546377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL is HeiseIE._VALID_URL

# Generated at 2022-06-22 07:39:02.355368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    video_id = heise_ie._match_id('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert video_id == '3959893'
    assert heise_ie.IE_NAME == 'heise'

# Generated at 2022-06-22 07:39:13.859278
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:39:16.204765
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-22 07:39:22.459723
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HEISE_URL = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    ie = HeiseIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?heise\\.de/(?:[^/]+/)+[^/]+-([0-9]+)\\.html'

# Generated at 2022-06-22 07:39:27.197092
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test to construct class HeiseIE
    heise_ie = HeiseIE()
    # Test to get video id
    video_id = heise_ie._match_id('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert video_id == '3959893'

# Generated at 2022-06-22 07:39:38.576581
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert ie.extract_info('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')


# Generated at 2022-06-22 07:39:40.802515
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Constructor test
    """
    obj = HeiseIE()
    assert obj is not None

# Generated at 2022-06-22 07:39:41.867268
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(None)._real_initialize()

# Generated at 2022-06-22 07:39:46.025938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:18.818536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:40:24.206658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_video = HeiseIE().extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone" == test_video['title']

# Generated at 2022-06-22 07:40:33.060661
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Test with valid URL
    test_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test_result = ie._real_extract(test_url)
    assert test_result["id"] == "1_kkrq94sm"
    assert test_result["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-22 07:40:33.865309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    res = HeiseIE()

# Generated at 2022-06-22 07:40:35.479946
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_HeiseIE = HeiseIE()

# Generated at 2022-06-22 07:40:36.664498
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:40:39.045671
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE({})
    assert ie

# Generated at 2022-06-22 07:40:50.956714
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert HeiseIE.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert not HeiseIE.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:40:52.013051
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:40:55.436876
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.__name__ == 'Heise'
    assert ie.ie_key() == 'Heise'
    assert ie.host == 'www.heise.de'

# Generated at 2022-06-22 07:42:11.769778
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:42:13.010490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Initialize our HeiseIE object
    HeiseIE()

# Generated at 2022-06-22 07:42:17.646018
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise._VALID_URL = HeiseIE._VALID_URL
    heise._TEST = HeiseIE._TESTS[0]
    heise.suite()

# Generated at 2022-06-22 07:42:18.110285
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:22.283276
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie)
    assert ie.METHOD == "GET"
    assert ie.NAME == "Heise"


# Generated at 2022-06-22 07:42:34.830687
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert 'HeiseIE' in globals()
    assert isinstance(HeiseIE, type)
    assert issubclass(HeiseIE, InfoExtractor)
    assert hasattr(HeiseIE, '_VALID_URL')
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert hasattr(HeiseIE, '_TEST')
    assert callable(HeiseIE._TEST)
    assert hasattr(HeiseIE, 'IE_NAME')
    assert HeiseIE.IE_NAME == 'Heise'
    assert hasattr(HeiseIE, '_NETRC_MACHINE')

# Generated at 2022-06-22 07:42:35.386934
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:42:46.615468
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")
    assert(ie.url == 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert(ie.id == '2403911')    # id is an attribute of InfoExtractor
    assert(ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-22 07:42:51.311867
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL.match('http://www.heise.de/tp/artikel/46/46112/1.html') is not None

# Generated at 2022-06-22 07:42:53.135276
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE constructor
    heise_ie = HeiseIE({})
    assert isinstance(heise_ie, HeiseIE)

# Generated at 2022-06-22 07:46:11.278626
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE.__name__ == "HeiseIE"

# Generated at 2022-06-22 07:46:14.225194
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    els = HeiseIE(None)
    assert els.ie_key() == 'heise'
    assert els.ie_name() == 'heise.de'
    assert els._VALID_URL is not None

# Generated at 2022-06-22 07:46:16.241705
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test = HeiseIE()
    test == HeiseIE
    return test

# Generated at 2022-06-22 07:46:24.378412
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HEISEIE = HeiseIE()
    assert HEISEIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:46:25.245155
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:46:29.340875
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    The only purpose of this test is to make sure that the class constructor
    is still present.
    """
    try:
        HeiseIE()
    except Exception as e:
        assert False, 'HeiseIE class constructor raises exception: %s' % str(e)

# Generated at 2022-06-22 07:46:32.645706
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()
    valid_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert extractor._match_id(valid_url) == '2404147'

# Generated at 2022-06-22 07:46:34.821357
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie_obj = HeiseIE()
    assert isinstance(ie_obj, InfoExtractor)

# Generated at 2022-06-22 07:46:45.808819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise.ie_key() == 'Heise'
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:46:55.636017
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test constructor of class HeiseIE.
    """
    print("\n" + "-" * 50, end='\n\n')
    print("Test constructor of class HeiseIE.")
    ie = HeiseIE()
    ie = HeiseIE("heise", "heise De")
    ie = HeiseIE("heise", "heise De", "heise")
    ie = HeiseIE("heise", "heise De", "heise", "heise")
    ie = HeiseIE("heise", "heise De", "heise", "heise", "heise")
    ie = HeiseIE("heise", "heise De", "heise", "heise", "heise", "heise")