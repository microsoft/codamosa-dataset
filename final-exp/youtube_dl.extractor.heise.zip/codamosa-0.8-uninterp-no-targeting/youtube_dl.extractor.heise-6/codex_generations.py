

# Generated at 2022-06-22 07:37:11.316563
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    print (h)

# Generated at 2022-06-22 07:37:18.094105
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'
    assert HeiseIE()._extract_urls(url,
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:37:19.004079
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-22 07:37:20.711287
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    heise = HeiseIE()
    heise.file_to_mem()

# Generated at 2022-06-22 07:37:27.242010
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    with open("test_data/heise.html", "r") as f:
        webpage = f.read()
    heise = HeiseIE()
    heise.extract("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html", webpage)

# Generated at 2022-06-22 07:37:28.737711
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(InfoExtractor()).IE_NAME == 'heise'

# Generated at 2022-06-22 07:37:29.801531
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()
    assert h is not None

# Generated at 2022-06-22 07:37:31.761165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ht = HeiseIE([])
    assert len(ht.__dict__) > 0

# Generated at 2022-06-22 07:37:32.452680
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:37:34.452490
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    o = HeiseIE()
    print(o.get_supported_ie_keys())

# Generated at 2022-06-22 07:38:02.947970
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable(None)
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') is True
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html') is True

# Generated at 2022-06-22 07:38:14.388448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == True
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html') == True

# Generated at 2022-06-22 07:38:16.460158
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.name == 'heise-video'

# Generated at 2022-06-22 07:38:28.865398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.SUFFIX == 'heise.de'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:40.687853
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html'

    heise_ie = HeiseIE()

    # Test if the constructor of class HeiseIE can extract the video ID
    assert heise_ie._match_id(url) == '2403911'

    # Test if the constructor of class HeiseIE can extract the video title
    # todo: perhaps there is a better way to ensure that the video title is correct

# Generated at 2022-06-22 07:38:50.671383
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Embed test
    # Unit test for construction of class HeiseIE
    # with embed format
    youtube_url = "https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html"
    heise = HeiseIE(youtube_url)
    assert heise
    assert heise.url == youtube_url
    assert heise.suitable(youtube_url)

    # Non-embed test
    kaltura_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

# Generated at 2022-06-22 07:38:54.551039
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Simple unit test for constructor of class HeiseIE
    """
    expected_output = HeiseIE('http://www.heise.de/')
    assert expected_output.url == 'http://www.heise.de/'

# Generated at 2022-06-22 07:38:59.667915
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # The constructor of HeiseIE
    test_object = HeiseIE()

    # The expected result
    assert test_object._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:06.606195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    for url in ['http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html']:
        # resetting the class to ensure it's at the beginning of cache directory
        global YoutubeIE
        YoutubeIE = type(YoutubeIE)
        heise_ie = HeiseIE()

        try:
            heise_ie.suitable(url)
        except Exception:
            import traceback
            traceback.print_exc()
            pass

# Generated at 2022-06-22 07:39:10.093203
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(isinstance(ie, KalturaIE) or isinstance(ie, YoutubeIE) or isinstance(ie, HeiseIE))

# Generated at 2022-06-22 07:39:47.477363
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Setup
    heiseIE = HeiseIE()
    assert heiseIE

    # Tear down

# Generated at 2022-06-22 07:39:49.736047
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
        assert False
    except TypeError as e:
        assert 'Cannot create a Meta class from' in str(e)

# Generated at 2022-06-22 07:39:59.338393
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:04.623006
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == "heise"
    assert ie.suitable(ie.ie_key())
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:40:16.212879
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    if __name__ == '__main__':
        # Get URL of a video in the 'test_suite' folder
        test_video_url = "https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"

        # Initialize the HeiseIE
        heiseIE = HeiseIE(downloader=None)

        # Call _real_extract() method of HeiseIE
        # The result should contain these fields.

# Generated at 2022-06-22 07:40:18.774277
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-22 07:40:24.586503
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import (
        BpBaseIE,
        BpGroupIE,
        CdaIE,
        CzateriaIE,
        DaumIe,
        DbcIE,
        DIE,
    )
    heise_ie = HeiseIE(BpBaseIE)(BpGroupIE)(CdaIE)(CzateriaIE)(DaumIe)(DbcIE)(DIE)
    assert heise_ie

# Generated at 2022-06-22 07:40:26.803601
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE('heise')
    assert heise is not None

# Generated at 2022-06-22 07:40:36.798309
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert ie.suitable('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')

# Generated at 2022-06-22 07:40:47.635289
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # explicitly call to avoid registering as a downloader
    ie.download = lambda *args, **kwargs: 'dummy'
    assert ie.name == 'heise'
    assert ie.suitable('http://www.heise.de/ct/videos')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:41:33.902763
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE(None)

# Generated at 2022-06-22 07:41:35.068759
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.working()

# Generated at 2022-06-22 07:41:46.744124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # heise.de
    # http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html
    # http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html
    result = HeiseIE()._real_extract(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:41:48.705093
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE('url')
    except Exception as e:
        assert(False)
    assert(True)

# Generated at 2022-06-22 07:41:50.272735
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie != None

# Generated at 2022-06-22 07:41:52.260660
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeBaseInfoExtractor

    assert issubclass(HeiseIE, YoutubeBaseInfoExtractor)

# Generated at 2022-06-22 07:41:55.440321
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    This is a test to confirm that the constructor of class HeiseIE is working
    properly.
    """
    heise_ie = HeiseIE()
    assert heise_ie.ie_key() == "heise"
    assert heise_ie.ie_key() == "Heise"

# Generated at 2022-06-22 07:41:59.148711
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('heise')
    assert ie.NAME == 'heise'
    assert ie.IE_NAME == 'heise'
    assert ie.SUFFIX == 'video'
    assert ie.IE_DESC == 'heise'

# Generated at 2022-06-22 07:42:00.609675
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE()
    # TODO: Add proper unit test
    pass

# Generated at 2022-06-22 07:42:05.389801
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Workaround to make sure that the regex in the constructor will be called
    # Note: module level regexes are only called in the constructor if a
    # an instance of the class is created.
    heise_ie = HeiseIE()


# Generated at 2022-06-22 07:43:51.156998
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html') == True
    # assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html?wt_mc=rss.ho.beitrag.atom') == True
    assert ie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == False

# Generated at 2022-06-22 07:43:53.020583
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except Exception:
        assert 0, 'Unit test failed to initialize class HeiseIE'

# Generated at 2022-06-22 07:43:55.632953
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        from . import TestVideoIE
    except ImportError:
        from test.test_video_dl import TestVideoIE

    TestVideoIE.test_constructor(HeiseIE)

# Generated at 2022-06-22 07:43:57.637699
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test class HeiseIE"""
    expected_value = HeiseIE(InfoExtractor())._VALID_URL
    returned_value = HeiseIE._VALID_URL
    assert(expected_value == returned_value)

# Generated at 2022-06-22 07:43:59.182357
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie

# Generated at 2022-06-22 07:44:01.358577
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # heise.de
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:44:11.658227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from ..utils import unwrap
    from .common import exec_command

    _, err = exec_command(['youtube-dl', '-e', 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'])
    assert 'NEU IM SEPTEMBER | Netflix' in unwrap(err)

    _, err = exec_command(['youtube-dl', '-e', 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'])
    assert 'Podcast: c\'t uplink 3.3' in unwrap(err)

# Generated at 2022-06-22 07:44:23.229904
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = HeiseIE
    # heise.de:
    assert (class_._VALID_URL ==
            r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')
    webPageUrl = r'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert class_.suitable(webPageUrl)
    assert class_.IE_NAME == 'heise'
    assert class_.IE_DESC == 'heise.de'
    ie = class_(create_test_instance=True)
    assert ie.extract(webPageUrl)
    #

# Generated at 2022-06-22 07:44:25.894664
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test the constructor of this class
    assert HeiseIE.ie_key() is not None

# Generated at 2022-06-22 07:44:30.932897
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()

    assert heiseie.get_host() == "heise.de"
    assert heiseie.get_host_corresponding_url_pattern() == HeiseIE._VALID_URL
    assert heiseie.get_host_name() == "heise.de"