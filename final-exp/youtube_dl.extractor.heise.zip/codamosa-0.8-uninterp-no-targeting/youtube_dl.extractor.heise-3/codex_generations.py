

# Generated at 2022-06-22 07:37:10.889142
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    instancia = HeiseIE()
    assert instancia

# Generated at 2022-06-22 07:37:15.823614
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('HeiseIE', 'https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert ie.description is None
    assert ie.title is None
    assert ie.thumbnail is None
    assert ie.duration is None

# Generated at 2022-06-22 07:37:18.232174
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TESTS == HeiseIE._TESTS

# Generated at 2022-06-22 07:37:20.921139
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:26.212219
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:37:33.700144
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    test = HeiseIE(url)
    assert(test.url == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")

# Generated at 2022-06-22 07:37:36.003003
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    u = HeiseIE()
    assert hasattr(u, '_VALID_URL')
    assert hasattr(u, '_TESTS')

# Generated at 2022-06-22 07:37:47.342513
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testInfoExtractor = InfoExtractor(HeiseIE)
    assert testInfoExtractor.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert testInfoExtractor.suitable('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')

# Generated at 2022-06-22 07:37:48.259751
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE() is not None

# Generated at 2022-06-22 07:37:49.521637
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)

# Generated at 2022-06-22 07:38:07.595448
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(InfoExtractor())

# Generated at 2022-06-22 07:38:09.907181
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie
    assert ie.extractor_key == 'heise'
    assert ie.name == 'heise'

# Generated at 2022-06-22 07:38:13.272398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_slug() == 'heise'

# Generated at 2022-06-22 07:38:14.804122
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info_extractor = HeiseIE()

# Generated at 2022-06-22 07:38:16.051792
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()

# Generated at 2022-06-22 07:38:26.657117
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from . import ungetcachedpage

    def getcachedpage(url, *args, **kwargs):
        if url.endswith('rss.xml'):
            return HEISE_RSS_XML
        return ungetcachedpage(url, *args, **kwargs)

    ie = HeiseIE(
        downloader=FakeDownloader(getcachedpage=getcachedpage))
    title = (
        'c t uplink 20 8 Staubsaugerroboter Xiaomi Vacuum 2 AR Brille Meta 2 und Android rooten')

# Generated at 2022-06-22 07:38:31.481332
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    config = {
        'extractors': {
            'youtube': {
                'IE_NAME': 'Youtube',
                'ie': 'Youtube',
                'x': 1,
            },
        },
    }
    ie = HeiseIE(config)
    assert ie.IE_NAME == 'Heise'

# Generated at 2022-06-22 07:38:41.397442
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    id = ie._match_id("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert id == "Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147"



# Generated at 2022-06-22 07:38:42.729560
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    class_()

# Generated at 2022-06-22 07:38:46.210990
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:39:11.851922
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().IE_NAME == "heise"
    assert HeiseIE().ie_key() == "heise"
    assert HeiseIE()._VALID_URL == HeiseIE._VALID_URL
    assert HeiseIE()._TEST == HeiseIE._TEST

# Generated at 2022-06-22 07:39:19.114501
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .common import InfoExtractor
    from .heise import HeiseIE
    from .kaltura import KalturaIE
    from .youtube import YoutubeIE
    from ..utils import (
        determine_ext,
        int_or_none,
        NO_DEFAULT,
        parse_iso8601,
        smuggle_url,
        xpath_text,
    )
    heise_ie = HeiseIE()
    assert isinstance(heise_ie,InfoExtractor)
    assert heise_ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:22.523241
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    extractor = HeiseIE()
    assert extractor.IE_NAME == "heise"
    assert extractor.IE_DESC == "heise online video"

# Unit test verifying the crawler works as expected on a video with a Kaltura embed

# Generated at 2022-06-22 07:39:23.313589
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().IE_NAME == 'heise'

# Generated at 2022-06-22 07:39:36.045135
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    kaltura_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    url = kaltura_url
    url = HeiseIE._VALID_URL.match(url).groupdict()
    url = url['id']
    heise_kaltura = HeiseIE()
    result = heise_kaltura._real_extract(kaltura_url)

    assert result['id'] == url
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-22 07:39:37.586870
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
  # Only test that no exception is raised
  test_HeiseIE.heise = HeiseIE()

# Generated at 2022-06-22 07:39:38.045536
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:39:48.948580
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:40:00.772377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    info = HeiseIE()._real_extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert info['title'] == 'Podcast: c\'t uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone'
    assert info['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert info['upload_date'] == '20171208'
    assert info['timestamp'] == 1512734959
    assert info['id'] == '1_kkrq94sm'

# Generated at 2022-06-22 07:40:03.891077
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test the constructor of class HeiseIE.
    """
    assert isinstance(
        HeiseIE(),
        HeiseIE
    )



# Generated at 2022-06-22 07:40:43.741246
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_dict = {
        'url': 'https://www.heise.de/ct/artikel/c-t-uplink-20-7-Raspberry-Pi-3-Smartphone-Hacking-und-Gefahren-beim-Schreddern-3922723.html',
        'only_matching': True,
    }
    heise_instance = HeiseIE()
    heise_instance.suitable(test_dict)
    heise_instance.extract(test_dict)

# Generated at 2022-06-22 07:40:54.274570
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.suitable("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie.ie_key() == 'heise'
    assert ie.suitable("http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html")

# Generated at 2022-06-22 07:41:04.121551
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.name == 'Heise'
    assert ie.video_id == '2404147'
    assert ie.url_id == '1_kkrq94sm'
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert ie.timestamp == 1512734959
    assert ie.upload_date == '20171208'
    assert ie.formats

# Generated at 2022-06-22 07:41:14.130827
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    testcases = [
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html',
        'https://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html',
        'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html',
    ]

# Generated at 2022-06-22 07:41:15.561260
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie)

# Generated at 2022-06-22 07:41:17.998217
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() in ie.supported_ie
    assert ie.SUCCEEDED == 0

# Generated at 2022-06-22 07:41:29.000056
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseIE._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert heiseIE._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert heiseIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert heiseIE._TES

# Generated at 2022-06-22 07:41:33.085054
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # An example of a video
    url = 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html'

    return HeiseIE()._real_extract(url)

# Generated at 2022-06-22 07:41:43.491834
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # The first item from the list of entries in _TESTS
    test_entry = ie._TESTS[0]

    # Test if the id of the video is extracted correctly
    video_id = ie._match_id(test_entry['url'])
    assert(video_id == test_entry['info_dict']['id'])

    # Test if the title of the video is extracted correctly
    title = ie._html_search_meta(('fulltitle', 'title'), ie._download_webpage(test_entry['url'], video_id), default=None)
    assert(title == test_entry['info_dict']['title'])

    # Test if the id of the video is extracted correctly

# Generated at 2022-06-22 07:41:44.613444
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-22 07:43:09.814925
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')

# Generated at 2022-06-22 07:43:13.166606
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE();
    assert heiseIE._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:43:24.153862
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    def _filter_kaltura_result(result):
        return result.copy() if result and result.get('_type') == 'url' else None
    kaltura_url = KalturaIE._extract_url(
        '<html><head></head><body><div class="videoplayerjw" data-player="kaltura" data-nodemodule="videoplayerjw" data-embedtype="dynamic" data-kalturapartnerid="2238431" data-flashvars="{&quot;playlist&quot;:[{&quot;entryid&quot;&quot;1_kkrq94sm&quot;}]}"</div></body></html>')
    kaltura_url = _filter_kaltura_result(kaltura_url)


# Generated at 2022-06-22 07:43:25.422635
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    assert heiseIE == HeiseIE()

# Generated at 2022-06-22 07:43:37.529342
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    a = HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert a.info_extractor.IE_NAME == 'Heise'
    assert a.info_extractor.IE_DESC == 'heise.de'
    assert a.info_extractor._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:43:39.124068
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie is not NO_DEFAULT

# Generated at 2022-06-22 07:43:50.219601
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    result = ie._real_extract(url)
    assert result['id'] == '1_kkrq94sm'
    assert result['title'] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert result['description'] == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert result['timestamp'] == 1512734959

# Generated at 2022-06-22 07:43:53.257443
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import unittest

    class HeiseIETestCase(unittest.TestCase):
        def setUp(self):
            self.heiseIE = HeiseIE()

    unittest.main()

# Generated at 2022-06-22 07:43:53.897620
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-22 07:43:55.764919
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_obj = HeiseIE(None)
    assert test_obj is not None


# Generated at 2022-06-22 07:45:35.408120
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_object = HeiseIE()


# Generated at 2022-06-22 07:45:38.290123
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:45:50.440433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .test_kaltura import KalturaIE_test
    from .test_youtube import YoutubeIE_test

    youtube_test_cases = YoutubeIE_test()['test_cases']

# Generated at 2022-06-22 07:45:52.101641
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:45:53.851152
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    assert ie.ie_name() == 'heise'

# Generated at 2022-06-22 07:45:55.573554
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE().IE_NAME == 'heise:video'

# Generated at 2022-06-22 07:46:03.997877
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-22 07:46:15.191735
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:46:18.192294
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # test if this constructor can be called
    HeiseIE()

# Generated at 2022-06-22 07:46:30.116644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    item = heise.get_info(url="https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html", download=None)
    assert(item is not None)
    heise = HeiseIE(download=True)