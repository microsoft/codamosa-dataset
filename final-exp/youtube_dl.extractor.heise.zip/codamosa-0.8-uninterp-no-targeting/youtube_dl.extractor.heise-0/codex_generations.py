

# Generated at 2022-06-22 07:37:14.461600
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()._real_extract('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-10-CES-Highlights-Millimeterwellen-Satelliten-und-Technik-2494377.html')
    except:
        pass

# Generated at 2022-06-22 07:37:18.320219
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    heise.extract(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
test_HeiseIE()

# Generated at 2022-06-22 07:37:28.842795
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie._VALID_URL.search('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    assert heise_ie._VALID_URL.search('http://www.heise.de/newsticker/meldung/c-t-uplink-Owncloud-Tastaturen-Peilsender-Smartphone-2404251.html?wt_mc=rss.ho.beitrag.atom')
    assert heise_ie._VALID_URL.search('http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html') == None

# Generated at 2022-06-22 07:37:30.417606
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:37:40.236831
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

    assert(heiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html')

# Generated at 2022-06-22 07:37:49.938551
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # First test HeiseIE functions called by constructor
    # mostly to check coverage
    HeiseIE.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    HeiseIE.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    HeiseIE.suitable('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:38:00.560064
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    IE = HeiseIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:12.406049
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    module = 'heise'
    classname = 'HeiseIE'
    # filename of testcase or testcases
    testcase_file = './test/testcases/%s/%s.txt' % (module, classname)

    testcase_list = []
    testcases = open(testcase_file, 'r').readlines()
    for line in testcases:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        testcase_list.append(line)

    total_num = len(testcase_list)
    passed_num = 0

    for i, testcase in enumerate(testcase_list):
        url, id = testcase.split()[:2]
        ie = HeiseIE(extract_flat=True)

# Generated at 2022-06-22 07:38:17.396546
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_cases = ['http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html']
    for url in test_cases:
        assert HeiseIE(url)

# Generated at 2022-06-22 07:38:24.146377
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE("http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:38:45.343622
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test HeiseIE constructor
    heise_ie = HeiseIE()
    # assert that HeiseIE constructed successfully
    assert heise_ie is not None

# Generated at 2022-06-22 07:38:51.294996
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.title == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"
    assert ie.description == 'md5:c934cbfb326c669c2bcabcbe3d3fcd20'
    assert ie.timestamp == 1512734959
    assert ie.upload_date == '20171208'

# Generated at 2022-06-22 07:38:52.562962
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()

# Generated at 2022-06-22 07:38:54.042781
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise != None

# Generated at 2022-06-22 07:39:00.939422
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'
    heise = HeiseIE()
    assert 'Heise' == heise._real_extract(test_url)["title"]

# Generated at 2022-06-22 07:39:05.178640
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.IE_NAME == 'heise'
    assert ie.IE_DESC == 'heise.de, heise video'
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:39:06.205651
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    h = HeiseIE()

# Generated at 2022-06-22 07:39:10.911086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    a = ie.extract('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    print(a)
    #assert a.get('id') == '1_kkrq94sm'

# Generated at 2022-06-22 07:39:12.249392
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    wert = HeiseIE(wert)
    assert wert.test()


# Generated at 2022-06-22 07:39:13.749693
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print(ie)

# Generated at 2022-06-22 07:39:57.685589
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:40:02.997644
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert ie._VALID_URL == HeiseIE._VALID_URL

# Generated at 2022-06-22 07:40:09.211306
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    class_ = globals()['HeiseIE']
    instance = class_()
    assert isinstance(instance, InfoExtractor)
    assert hasattr(instance, '_VALID_URL')
    assert hasattr(instance, '_TESTS')
    assert hasattr(instance, 'IE_NAME')
    assert hasattr(instance, '_is_initialized')
    assert hasattr(instance, '_downloader')
    assert instance._is_initialized == False
    assert instance._downloader == None

# Generated at 2022-06-22 07:40:10.419184
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:40:19.497329
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # Typical video on Heise.de
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    # Method parse() should return a dictionary with key 'id' and 'ext'
    info_dict = ie.extract(url)
    assert info_dict.get('id')  # key 'id' should exist
    assert info_dict.get('ext')  # key 'ext' should exist

# Generated at 2022-06-22 07:40:26.572685
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie.ie_name == 'heise'
    assert ie.ie_key() == 'heise'
    assert ie.host == 'www.heise.de'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://bcove.me/%s'

# Generated at 2022-06-22 07:40:27.707902
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie =  HeiseIE()

# Generated at 2022-06-22 07:40:33.696687
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # testing for constructor with valid url
    assert HeiseIE("http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

    # testing for constructor with invalid url
    try:
        HeiseIE("http://www.youtube.com/watch?v=BaW_jenozKc")
    except:
        pass
    else:
        raise Exception("HeiseIE accepts youtube url instead of raising error")

# Generated at 2022-06-22 07:40:36.577882
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE('http://www.heise.de/video/artikel/nachgehakt-Wie-sichert-das-c-t-Tool-Restric-tor-Windows-10-ab-3700244.html')
    assert isinstance(ie._download_webpage, staticmethod)

# Generated at 2022-06-22 07:40:37.926328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:41:59.529294
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:42:08.056301
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE(HeiseIE._downloader)._download_webpage(
        HeiseIE._VALID_URL, '1_kkrq94sm')
    HeiseIE(HeiseIE._downloader)._download_webpage(
        HeiseIE._VALID_URL, '1_ntrmio2s')
    HeiseIE(HeiseIE._downloader)._download_webpage(
        HeiseIE._VALID_URL, '1_59mk80sf')
    HeiseIE(HeiseIE._downloader)._download_webpage(
        HeiseIE._VALID_URL, '3700244')

# Generated at 2022-06-22 07:42:15.837709
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:42:18.783004
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """
    Test constructor of HeiseIE class
    """
    heiseIE = HeiseIE()
    assert heiseIE._VALID_URL == 'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:42:21.353819
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL

# Generated at 2022-06-22 07:42:23.043715
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert isinstance(heise, HeiseIE)

# Generated at 2022-06-22 07:42:23.972597
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    unit_test_class = HeiseIE()

# Generated at 2022-06-22 07:42:36.209460
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test initializing of class HeiseIE with url
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert HeiseIE(url)._match_id(url) is not None

    # Test initializing of class HeiseIE with id
    video_id = "2404147"
    assert HeiseIE(video_id)._match_id(url) == video_id

    # Test initializing of class HeiseIE with url having and without trailing slash

# Generated at 2022-06-22 07:42:46.955537
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    sample_url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    ins = HeiseIE()
    match_object = ins._VALID_URL.match(sample_url)
    assert match_object
    assert ins._real_extract(sample_url)

    # sample_url2 = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    # ins = HeiseIE()
    # match_object = ins._VALID_URL.match(sample_url2)
    # assert match

# Generated at 2022-06-22 07:42:50.953376
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    HeiseIE.ie_key() # should not fail


# Generated at 2022-06-22 07:44:26.128502
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE._VALID_URL
    assert HeiseIE._TESTS

# Generated at 2022-06-22 07:44:37.429852
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(edu.Internet())
    assert isinstance(heiseie, HeiseIE)
    assert heiseie.name == "Heise"
    assert heiseie.ie_key() == 'Heise'
    assert heiseie.host == "heise.de"
    assert heiseie.age_limit == 0
    assert heiseie.test_cases[0]['url'] == "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    assert heiseie.test_cases[0]['md5'] == "2d13f68a822064a95521674c7a4e4a56"
    assert heise

# Generated at 2022-06-22 07:44:38.412718
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:44:45.107124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heiseie == HeiseIE

# Generated at 2022-06-22 07:44:46.705938
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # This only run constructor, nothing else
    HeiseIE()

# Generated at 2022-06-22 07:44:48.312754
# Unit test for constructor of class HeiseIE
def test_HeiseIE():

    # Check object instantiation
    hie = HeiseIE()

# Generated at 2022-06-22 07:44:57.540982
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    ie._VALID_URL = r'heise.de/(artikel|video|ct)/.*'

# Generated at 2022-06-22 07:45:05.918969
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    x = HeiseIE()
    assert x.url_to_videoid('http://www.heise.de/ct/artikel/Spiele-1-3216662.html') == 'Spiele-1-3216662'
    assert x.url_to_videoid('http://www.heise.de/ct/artikel/Spiele-1-3216662.html?wt_mc=rss.ho.beitrag.atom') == 'Spiele-1-3216662'
    assert x.url_to_videoid('http://www.heise.de/newsticker/meldung/Spiele-1-3216662.html?wt_mc=rss.ho.beitrag.atom') == 'Spiele-1-3216662'
    assert x.url_to_videoid

# Generated at 2022-06-22 07:45:09.718328
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE

# Generated at 2022-06-22 07:45:16.995809
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert heiseie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')
    assert heiseie.suitable('https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html')