

# Generated at 2022-06-22 07:37:21.278379
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'

# Generated at 2022-06-22 07:37:23.016551
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Unit test for constructor of class HeiseIE"""
    HeiseIE()

# Generated at 2022-06-22 07:37:32.440780
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE("https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html")
    assert heiseie.url == "https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html"

# Generated at 2022-06-22 07:37:38.749227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    print (ie.ie_key())
    print (ie.extract('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html'))

# Generated at 2022-06-22 07:37:40.564949
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, HeiseIE)

# Generated at 2022-06-22 07:37:42.160453
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    result = HeiseIE().result()
    assert len(result) == 0

# Generated at 2022-06-22 07:37:45.182473
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None
    ie.extract('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:37:46.297989
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:37:51.834762
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Returns True if constructor of HeiseIE class is working. Otherwise return False."""

    success = True

    try:
        # Create new object with example URL
        HeiseIE('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    except:
        success = False

    return success

# Generated at 2022-06-22 07:37:53.353368
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # Test if HeiseIE can be instantiated
    HeiseIE()

# Generated at 2022-06-22 07:38:19.354227
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # valid URL
    test_url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    test_obj = HeiseIE(url=test_url)
    # valid URL, but not a video
    test_url = 'http://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html'
    test_obj = HeiseIE(url=test_url)

# Generated at 2022-06-22 07:38:20.400195
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:38:31.834435
# Unit test for constructor of class HeiseIE

# Generated at 2022-06-22 07:38:43.008086
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable('https://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:38:43.935394
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie is not None

# Generated at 2022-06-22 07:38:49.421165
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.suitable(None) is False
    assert ie.suitable('') is False
    assert ie.suitable("http://video.heise.de/anything") is False
    assert ie.suitable("https://www.heise.de/ct/ausgabe/2016-12-Spiele-3214137.html")

# Generated at 2022-06-22 07:38:57.808656
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseIE = HeiseIE()
    # Test URL from Heise
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    result = heiseIE._real_extract(url)

    # Test if any element of result is empty
    assert(result['url'])
    assert(result['id'])
    assert(result['title'])
    assert(result['ext'])

# Generated at 2022-06-22 07:39:05.184868
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = "http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html"
    heise = HeiseIE()
    result = heise.extract(url)
    assert result["title"] == "Podcast: c't uplink 3.3 – Owncloud / Tastaturen / Peilsender Smartphone"

# Generated at 2022-06-22 07:39:11.960398
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE('https://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')
    HeiseIE('http://www.heise.de/ct/artikel/c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2403911.html')

# Generated at 2022-06-22 07:39:13.662137
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()

# Generated at 2022-06-22 07:39:49.735976
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE({})
    assert 'heise' in heiseie._WORKING_IE_NAME

# Generated at 2022-06-22 07:39:51.304773
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        HeiseIE()
    except:
        assert False

# Generated at 2022-06-22 07:40:03.164924
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url = 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    heiseie = HeiseIE()
    heiseie.match_url(url)
    heiseie._download_webpage(url, 'heise_podcast')
    heiseie._search_regex(r'<div[^>]+class="videoplayerjw"[^>]+data-title="([^"]+)"', 'webpage','title')
    heiseie._html_search_regex(r'<h1[^>]+\bclass=["\']article_page_title[^>]+>(.+?)<', 'webpage', 'title')
    heiseie

# Generated at 2022-06-22 07:40:13.388189
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    # test class
    assert ie.ie_key() == "heise"
    # test constructor
    assert ie.suitable('http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html')

# Generated at 2022-06-22 07:40:14.761072
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie = HeiseIE()
    assert heise_ie

# Generated at 2022-06-22 07:40:16.381909
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE()
    assert heiseie.__class__ == HeiseIE


# Generated at 2022-06-22 07:40:16.994839
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    pass

# Generated at 2022-06-22 07:40:25.612534
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    video_id = '3959893'
    url = 'https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-%s.html'%video_id
    print(url)
    heise_ie = HeiseIE()
    #test function parse_iso8601
    print(parse_iso8601('20180202'))
    #test function determine_ext

# Generated at 2022-06-22 07:40:35.438642
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # check exception for bad URL
    from .common import ExtractorError
    try:
        HeiseIE("http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html").get_info("_")
    except ExtractorError as e:
        assert str(e) == "Unsupported URL 'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html': This video is no c't uplink, please report this issue on https://github.com/rg3/youtube-dl/issues"

# Generated at 2022-06-22 07:40:46.757567
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    try:
        import kaltura
        kaltura  # silence pyflakes
    except ImportError:
        kaltura = None

    # Without kaltura module - would raise an error if using KalturaIE
    heise = HeiseIE()
    assert heise.ie_key() == 'ct'
    assert heise.ie_key() == heise.ie_key(HeiseIE._VALID_URL)

    if kaltura is not None:
        # With kaltura module - could use KalturaIE if not set to False explicitly
        heise = HeiseIE(use_kaltura=False)
        assert heise.ie_key() == 'cctv'
        assert heise.ie_key() == heise.ie_key(HeiseIE._VALID_URL)

# Generated at 2022-06-22 07:41:41.937540
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'heise'
    assert ie.ie_name() == 'heise.de'
    assert ie.suitable('https://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html')
    assert ie.suitable('https://www.heise.de/ct/artikel/c-t-uplink-20-8-Staubsaugerroboter-Xiaomi-Vacuum-2-AR-Brille-Meta-2-und-Android-rooten-3959893.html')

# Generated at 2022-06-22 07:41:44.185403
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:41:45.766945
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_test = HeiseIE().test()
    assert heise_test is not None

# Generated at 2022-06-22 07:41:48.650976
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    
    try:
        assert(HeiseIE.ie_key())
    except (AssertionError, TypeError) as e:
        raise Exception(e)


# Generated at 2022-06-22 07:42:00.514552
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert ie._TESTS[0]['url'] == 'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    assert ie._TESTS[0]['info_dict']['id'] == '1_kkrq94sm'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:42:11.071947
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert ie.ie_key() == 'Heise'
    # This video has a kaltura embed
    assert ie._extract_url(
        'http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html') == '1_kkrq94sm'
    # This video has a youtube embed
    assert ie._extract_url(
        'http://www.heise.de/newsticker/meldung/Netflix-In-20-Jahren-vom-Videoverleih-zum-TV-Revolutionaer-3814130.html') == '6kmWbXleKW4'
    # This video has a jw player

# Generated at 2022-06-22 07:42:15.730645
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    test_object = HeiseIE()
    assert test_object.ie_key() == 'heise'
    assert test_object.ie_name() == 'heise'

# Generated at 2022-06-22 07:42:17.226273
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test HeiseIE constructor"""
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:42:24.046555
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    import sys
    import unittest
    try:
        # Python 3
        from urllib.parse import parse_qs
    except ImportError:
        # Python 2
        from urlparse import parse_qs

    class TestHeiseIE(unittest.TestCase):
        def test_HeiseIE(self):
            def assertDictContainsSubset(subset, dictionary):
                self.assertDictContainsSubset(subset, dictionary, msg=None)

            class MockInfoExtractor(InfoExtractor):
                def __init__(self, *args, **kargs):
                    try:
                        self.requested_urls = [args[1]] # url
                    except IndexError:
                        self.requested_urls = []


# Generated at 2022-06-22 07:42:33.360433
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise = HeiseIE()
    assert heise._VALID_URL == r'https?://(?:www\.)?heise\.de/(?:[^/]+/)+[^/]+-(?P<id>[0-9]+)\.html'
    assert heise.__name__ == 'Heise'
    assert heise.IE_NAME == 'heise'
    assert heise.ie_key() == 'Heise'
    assert heise.supported_extensions == {'mp4'}

# Generated at 2022-06-22 07:44:07.737701
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:44:09.886537
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    """Test creation of HeiseIE object."""
    test_HeiseIE_obj = HeiseIE()
    assert test_HeiseIE_obj

# Generated at 2022-06-22 07:44:11.281683
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heiseie = HeiseIE(None)
    assert heiseie

# Generated at 2022-06-22 07:44:15.266098
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    # this test is intended to test the constructor of HeiseIE
    # when the class is imported
    ie = HeiseIE(None)
    assert ie is not None

# Generated at 2022-06-22 07:44:16.737168
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    ie = HeiseIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:44:17.430124
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    HeiseIE()

# Generated at 2022-06-22 07:44:19.287331
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    from .youtube import YoutubeIE
    HeiseIE.test_video_youtube(YoutubeIE)

# Generated at 2022-06-22 07:44:20.005658
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    assert HeiseIE()

# Generated at 2022-06-22 07:44:21.361575
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    heise_ie=HeiseIE()
    assert(heise_ie)

# Generated at 2022-06-22 07:44:26.949199
# Unit test for constructor of class HeiseIE
def test_HeiseIE():
    url='http://www.heise.de/video/artikel/Podcast-c-t-uplink-3-3-Owncloud-Tastaturen-Peilsender-Smartphone-2404147.html'
    obj = HeiseIE()
    obj.suitable(url)
    print(obj.extract(url))