

# Generated at 2022-06-24 04:20:19.526574
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    import inspect
    import os
    import subprocess
    import sys
    import tempfile

    from unittest.mock import Mock, patch
    import pytest

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    show_code_in_traceback = False

    output_list = []
    temp_dir = None
    test_failing = False

    def epilog(exc_type, exc_value, tb):
        global test_failing
        test_failing = True
        output = "".join(output_list)
        if show_code_in_traceback:
            traceback.print_exception(exc_type, exc_value, tb)
        else:
            sys.stderr.write("{}\n".format(output))


# Generated at 2022-06-24 04:20:21.115293
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    ...


# Generated at 2022-06-24 04:20:30.366111
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    print("test_RouteMixin_get")
    # Unit test for method get of class RouteMixin
    print("get")

    # test for passing an invalid method
    try:
        @app.get('/', methods=['POST'])
        def handler():
            return True
    except ValueError as e:
        if str(e) == "Invalid method 'POST' passed to get(): only GET is allowed":
            print("passed first test")
        else:
            print(str(e))
            raise e
    else:
        raise Exception("Failed first test")

    # test for passing a valid method
    @app.get('/', methods=['GET'])
    def handler():
        return True
    if handler:
        print("passed second test")

    # test for not passing a method

# Generated at 2022-06-24 04:20:32.302483
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test')
    app.router.add_route('get', '/', app.async_handler(lambda : None))


# Generated at 2022-06-24 04:20:39.673528
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    """
    test patch method
    """
    # 1
    @app.patch("/users/<user_id:int>")
    async def handler(request, user_id):
        return text("I patched a user")
    # 2
    assert app.router.routes_names["_handler"] == [handler]
    assert app.router.routes_names["text"] == [handler]
    assert app.router.routes_names["text-response"] == [handler]
    # 3
    @app.patch(
        "/users/<user_id:int>", name="_handler", strict_slashes=True
    )
    async def handler(request, user_id):
        return text("I patched a user")
    # 4

# Generated at 2022-06-24 04:20:50.001902
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router, RouteExists
    from sanic.constants import HTTP_METHODS

    def handler(request):
        return HTTPResponse(body="OK")

    sanic_app = Sanic('test_RouteMixin_put')
    sanic_app.put('/')(handler)

    @sanic_app.route('/test/<param>', methods=['PUT'])
    async def handler_test(request, param):
        return HTTPResponse(body="OK")

    uri = "/"
    uri_test = "/test/<param>"

    router = Router()


# Generated at 2022-06-24 04:21:05.470453
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic('test_RouteMixin_route')

# Generated at 2022-06-24 04:21:10.343848
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """
    Test case for method add_route of class RouteMixin
    """
    r = App("TestApp")
    assert r.route("/test/", methods=["GET"])(r.add_route) is None


# Generated at 2022-06-24 04:21:20.193244
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from unittest.mock import patch
    from sanic import Sanic
    from sanic.router import Route

    app = Sanic('sanic-test')
    uri = "uri"
    host = "host"
    subprotocols = "subprotocols"
    strict_slashes = "strict_slashes"
    version = "version"
    name = "name"
    class testClass():
        def __init__(self):
            pass

        async def handler(self, request):
            pass
        def __call__(self):
            pass
    with patch('sanic.router.RouteMixin.websocket') as mock_websocket:
        mock_websocket.return_value = testClass

# Generated at 2022-06-24 04:21:21.471252
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    my_route = RouteMixin('/', Route, Route)
    assert isinstance(my_route, RouteMixin)

# Generated at 2022-06-24 04:21:29.754430
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    router = RouteMixin()

    class ClassB:
        pass

    class ClassA:
        def __init__(self, host=None, strict_slashes=None, **kwargs):
            self.sanic_router = router
            self.host = host
            self.strict_slashes = strict_slashes
            self.kwargs = kwargs

        @router.route(uri='/', methods=['get'], version=1, name='test', apply=True)
        async def handler(request):
            return HTTPResponse(text="OK")

        async def async_handler(self, request):
            if self.kwargs.get('res'):
                return self.kwargs.get('res')

            return HTTPResponse(text="OK")


# Generated at 2022-06-24 04:21:43.048438
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import Route, RouteExists
    from sanic.response import json
    from sanic import Sanic
    from sanic.request import Request
    from sanic.exceptions import RequestTimeout, RequestURITooLarge, ContentRangeError
    from sanic.wrappers import RequestParameters
    from json import loads
    import re
    import os.path as path
    import sys
    if 'sanic.app' not in sys.modules:
        sys.modules['sanic.app'] = Sanic('sanic')
    app = Sanic('sanic')
    app.config.REQUEST_MAX_SIZE = 10
    app.config.REQUEST_TIMEOUT = 10
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 60
    app.config.RE

# Generated at 2022-06-24 04:21:50.074951
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    rm = RouteMixin()
    rm._generate_name = MagicMock(return_value="mock_name")
    rm.websocket = MagicMock(return_value=MagicMock())
    handler = MagicMock()
    host = MagicMock()
    uri = MagicMock()
    strict_slashes = MagicMock()
    subprotocols = MagicMock()
    version = MagicMock()
    name = MagicMock()
    # when
    result = rm.add_websocket_route(handler, uri, host, strict_slashes, subprotocols, version, name)
    # then
    assert result == rm.websocket.return_value

# Generated at 2022-06-24 04:21:57.288931
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    app = Sanic('test_RouteMixin_options')
    options(uri='/', host=None, strict_slashes=False, name=None, version=None,
            apply=True)(app.async_add)
    options(uri='/', host=None, strict_slashes=False, name=None, version=None,
            apply=True)(app.async_sub)
    options(uri='/', host=None, strict_slashes=False, name=None, version=None,
            apply=True)(app.handle_request)



# Generated at 2022-06-24 04:22:06.722530
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():

    # create instance of class RouteMixin and create instance variable router
    route_mixin = RouteMixin()
    route_mixin.router = Router()

    # create decorator put by method put of class RouteMixin and create instance variable routes
    put = route_mixin.put("test", strict_slashes=True)

    @put
    async def handler(request):
        pass

    # get value of variable routes
    result = route_mixin.routes
    expected = [("PUT", "test", True, "sansio", None, None, None)]

    # assert result equals expected
    assert result == expected


# Generated at 2022-06-24 04:22:16.955302
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    router = RouteMixin()
    result = router.static(
        uri="/",
        file_or_directory="Some directory or file path",
        pattern=r"/?.+",
        use_modified_since=True,
        use_content_range=True,
        stream_large_files=True,
        name="static",
        host=None,
        strict_slashes=None,
        content_type="Content type",
    )
    # result = router.static(
    #     uri=r"/",
    #     file_or_directory="Some directory or file path",
    #     pattern=r"/?.+",
    #     use_modified_since=True,
    #     use_content_range=True,
    #     stream_large_files=True,
    #     name="static

# Generated at 2022-06-24 04:22:18.861752
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    with pytest.raises(ValueError):
        RouteMixin(websocket=None)


# Generated at 2022-06-24 04:22:28.114464
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.router import Route
    from sanic.request import Request
    
    _test_route = Route("", host=None, methods=None, handler=None, strict_slashes=None, version=0, name=None, static=False, websocket=False, stream=False, expect_handler=None, schema="", patterns=None, router=None, middlewares=None, subprotocols=None)

    _test_request = Request("", "", "", "", "")

    assert RouteMixin.patch(_test_route, _test_request) == None


# Generated at 2022-06-24 04:22:38.860153
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    class _Mock(RouteMixin):
        name = None
        ignore_route_names_extension = False
        routes = None
        _future_statics = None
        strict_slashes = None
        host = None
        headers = None
        version = None
        _after_server_start = None
        _before_server_stop = None
        error_handler = None
        error_handler_spec = None
        websocket_exceptions = None
        exceptions = None
        middleware = None
        existing_app = None
        _static_router = None
        ssl = None
        debug = None
        request_class = None
        is_request_stream = None
        response_class = None
        is_response_stream = None
        loop = None
        config = None
        protocol = None
        worker = None

# Generated at 2022-06-24 04:22:44.844317
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    request = Request("/", None, None, None, None, None, None)
    rm = RouteMixin()
    rm.patch("/", None, None, None, None, (None,))
    route = Route('/', None, None, None, None)
    result = route.handle_request(request)
    assert result == None

# Generated at 2022-06-24 04:22:45.394444
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass

# Generated at 2022-06-24 04:22:47.008198
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # create a instance of RouteMixin class
    obj = RouteMixin()
    return True

# Generated at 2022-06-24 04:22:55.938941
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    a=RouteMixin()
    assert a.options("/")==[]
    assert a.options("/a")==[]
    b=Route("/","GET",None)
    a.add_route(b)
    assert a.options("/")==['GET']
    assert a.options("/a")==[]
    a.add_route(Route("/a","POST",None))
    assert a.options("/")==['GET']
    assert a.options("/a")==['GET','POST']
    c=Route("/","GET",None)
    a.add_route(c)
    assert a.options("/")==['GET']
    assert a.options("/a")==['GET','POST']
    a.add_route(Route("/a","HEAD",None))

# Generated at 2022-06-24 04:22:57.374755
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    assert RouteMixin().route() is None

# Generated at 2022-06-24 04:23:04.465366
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic()
    route_mixin = RouteMixin()
    # using the RouteMixin to call the method delete
    route_mixin.delete("/users/<id:int>")
    assert(route_mixin.routes[0].name == "delete.users.id.int")
    assert(route_mixin.routes[0].uri == "/users/<id:int>")
    assert(route_mixin.routes[0].methods == ["DELETE"])

# Generated at 2022-06-24 04:23:08.825772
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    
    app = Sanic(__name__)

    # Add route to a class
    class Class:
        def __init__(self):
            pass
        
        def method(self):
            pass
    app.add_websocket_route(Class().method, '/')

# Generated at 2022-06-24 04:23:11.874214
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
  route_mixin = RouteMixin()
  route_mixin._delete('uri', ['methods'], 'host', 'strict_slashes', 'name', 'version', 'apply')

# Generated at 2022-06-24 04:23:16.147865
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    assert RouteMixin().get('/index1') == RouteMixin().route('/index1').get()
    
    

# Generated at 2022-06-24 04:23:18.785815
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    with pytest.raises(Exception) as error:
        r = RouteMixin()
        r._get()
    assert str(error.value) == "Not implemented"


# Generated at 2022-06-24 04:23:30.440971
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic.app import Sanic
    from sanic.router import Route

    def handler(request, ws):
        pass

    app = Sanic('test_RouteMixin_add_websocket_route')
    app.router.add_websocket_route(handler, '/test')
    assert isinstance(app.router.routes_all['test.handler'], Route)
    assert app.router.routes_all['test.handler'] == app.router.routes_all['test.handler']._route_string
    assert app.router.routes_all['test.handler'] == app.router.routes['test.handler']._route_string
    


# Generated at 2022-06-24 04:23:33.267908
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case1.
    print("\nTest case1.")

    # Test case2.
    print("\nTest case2.")


# Generated at 2022-06-24 04:23:45.251774
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.response import json
    from sanic.router import Route, Url
    from sanic.handlers import ErrorHandler
    from sanic.exceptions import InvalidUsage

    class MyRouter(RouteMixin):
        def __init__(self):
            self._route_table = []
            
            # unit test for class Route
            self.route(uri='/route_params/<param1>/<regex("[0-9a-zA-Z]{1,6}"):param2>/<param3>',
               methods=['GET'],
               strict_slashes=True,
               host='myhost:8080',
               version=2,
               name='route_name',
               apply=True,
               uri_as_is=False,
               websocket=True)(json)
            

# Generated at 2022-06-24 04:23:51.471457
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    assert RouteMixin(app=None, router=None, name='test').route(
        uri='/test', methods=None, host=None, strict_slashes=None, version=None,
        name='test', apply=True, subprotocols=None, websocket=False
        ) == (route(uri='/test', methods=None, host=None, strict_slashes=None, version=None,
        name='test', apply=True, subprotocols=None, websocket=False))

# Generated at 2022-06-24 04:24:00.475596
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic import response
    from sanic.router import RouteExists

    app = Sanic('test_RouteMixin_route')
    app.route("/", methods=['GET'])(lambda request: response.text("OK"))
    app.route("/", methods=['POST'])(lambda request: response.text("OK"))
    app.route("/", methods=['GET', 'POST'])(lambda request: response.text("OK"))
    #If the following is uncommented, the code will fail as expected
    #app.route("/foo/bar", methods=['GET'])(lambda request: response.text("OK"))
    #app.route("/foo/bar", methods=['POST'])(lambda request: response.text("OK"))
    #app.route("/foo/bar", methods=['GET

# Generated at 2022-06-24 04:24:07.378667
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # Initialize the test class
    routeMixin = RouteMixin()

    # Case 1
    # Test description: The head method makes a head request

    # This is the expected result
    expected_result = None

    # Call the test function
    actual_result = routeMixin.head(url, **kwargs)

    # Assertion
    assert actual_result == expected_result

# Generated at 2022-06-24 04:24:15.585263
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    def __init__(self):
        pass
    def method(self):
        pass
    rm = RouteMixin()
    rm.route = MagicMock(return_value=(1,2))
    rm.delete('/uri', name='name', host='localhost',strict_slashes=True, subprotocols='subprotocols')(rm.method)
    rm.route.assert_called_with('/uri','POST', host='localhost',strict_slashes=True,name='name', subprotocols='subprotocols')
    rm.delete('/uri', name='name', host='localhost',strict_slashes=True, subprotocols='subprotocols')(rm.method)

# Generated at 2022-06-24 04:24:22.673080
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    print('\r\n')

    # create class A
    @RouteMixin.route('/a/')
    def A(request):
        print('A')
        return text('A')

    # create class B
    @RouteMixin.route('/b/')
    async def B(request):
        print('B')
        return text('B')

    # create class C
    @RouteMixin.route('/c/')
    async def C(request):
        print('C')
        return text('C')

    # create class D
    @RouteMixin.route('/d/')
    def D(request):
        print('D')
        return text('D')

    # create class E
    @RouteMixin.route('/e/')
    async def E(request):
        print('E')

# Generated at 2022-06-24 04:24:32.485985
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    import sys
    import os
    import types

    app = Sanic('test_RouteMixin_add_route')
    # 1. add_route: func route(self, uri, host=None, methods=None,
    # strict_slashes=None, version=None, name=None, apply=True, **options):
    # 2. route, _ = self.route(uri=uri, host=host, methods=methods,
    # strict_slashes=strict_slashes, version=version, name=name, apply=apply,
    # **options):
    # 2.1. route = Route(uri=uri, host=host, methods=methods,
    # strict_slashes=strict_slashes, version=version, name=name,
    # **options)
    #

# Generated at 2022-06-24 04:24:37.387954
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    if not hasattr(RouteMixin, 'post'):
        from sanic.router import RouteMixin
        app = Sanic('Sanic')
        app.blueprint(app)
        app.static('/static', './examples/static', name='static')
        def handler():
            return text('OK')
        RouteMixin.post(app, '/test_post', handler, name='test')
        app.router._apply_blueprint(app)


# Generated at 2022-06-24 04:24:49.684211
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    # Sanic(__name__)
    sanic_app_1 = Sanic('sanic.app.Sanic')
    
    # Sanic()
    # sanic_app_1 = Sanic()
    
    def test_function():
        pass
    # setup
    # Action
    # sanic_app_1.add_websocket_route(test_function, "/test_function_1")
    sanic_app_1.add_websocket_route(test_function, "/test_function_1", host="localhost")
    sanic_app_1.add_websocket_route(test_function, "/test_function_1", host="127.0.0.1")

# Generated at 2022-06-24 04:24:51.063704
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    r = RouteMixin()
    r.head(uri="")


# Generated at 2022-06-24 04:24:51.968184
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    pass # TODO


# Generated at 2022-06-24 04:25:00.704863
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic import Sanic
    from sanic.response import html
    from sanic.router import Route
    from pysaeg.router import Response

    app = Sanic("test_sanic_options")
    route = Route("/test", app, [], None, None)
    @app.options("/test/", methods=["GET", "POST", "PATCH", "OPTIONS"])
    def test_route1(request):
        return Response(body="route1", status=200)

    @app.options("/test/", methods=["POST", "PUT", "GET", "PATCH", "OPTIONS"])
    def test_route2(request):
        return Response(body="route2", status=200)


# Generated at 2022-06-24 04:25:08.066724
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from urllib.parse import urlparse, parse_qs
    import io
    import sys
    import unittest

    url = 'http://127.0.0.1:8000/favicon.ico'
    req = Request.from_url(url)

    app = Sanic(name='test_RouteMixin_static')
    route = RouteMixin(app)
    file_or_directory = '/home/app/app/static/favicon.ico'
    uri = '/'
    pattern = '/?.+'
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = '_static_static'
    host

# Generated at 2022-06-24 04:25:13.314269
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.router import Route
    from sanic.websocket import WebSocketProtocol
    
    app = Sanic(__name__)
    
    ##############
    # GET Route
    ##############
    @app.route("/", methods=["GET"])
    def handler(request):
        return json({ "test": True })
    
    assert len(app.router.routes_all["GET"]) == 1
    assert isinstance(app.router.routes_all["GET"][0], Route)
    
    
    
    ##############
    # HEAD Route
    ##############

# Generated at 2022-06-24 04:25:22.860671
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # dummy function
    def handler():
        pass
    # basic method call without parameters
    mixin = RouteMixin(None)
    mixin.add_route(handler, "/foo")
    # basic method call with parameters
    mixin.add_route(handler, "/foo", methods=["GET", "POST"], host="0.0.0.0", strict_slashes=False, version=1, name="foo", apply=True)
    # basic method call with parameters
    mixin.add_route(handler, "/foo", methods=["GET", "POST"], host="0.0.0.0", strict_slashes=False, version=1, name="foo", apply=True)

# Generated at 2022-06-24 04:25:25.167048
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # error
    with pytest.raises(Exception) as e:
        route_mixin = RouteMixin()
        route_mixin.head("")


# Generated at 2022-06-24 04:25:27.473159
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement a unit test for RouteMixin.add_route
    #       if possible
    assert False



# Generated at 2022-06-24 04:25:32.982864
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    a = Sanic("RouteMixin_post")
    a.post("/")
    assert a.router.routes_names["_post_/"]
    assert a.router.routes_all[0].uri == "/"


# Generated at 2022-06-24 04:25:33.877226
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
  assert True


# Generated at 2022-06-24 04:25:35.029598
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass


# Generated at 2022-06-24 04:25:42.522129
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """
    Test the private method add_route of the class RouteMixin
    """

    test_route = RouteMixin()
    assert test_route._routes == {}

    temp = test_route.add_route(None, None)
    assert temp[0] == {}
    assert isinstance(temp[1], partial)

    temp = test_route.add_route(None, None, None)
    assert temp[0] == {}
    assert isinstance(temp[1], partial)


# Generated at 2022-06-24 04:25:47.893693
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    import unittest
    class RouteMixin_Test(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_RouteMixin_websocket(self):
            pass

    unittest.main()


# Generated at 2022-06-24 04:25:53.929527
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.exceptions import InvalidUsage
    from sanic.route_common import HTTP_METHODS
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.app import Sanic

    app = Sanic("test_route")

    class SimpleView(HTTPMethodView):
        def get(self, request):
            pass

        def post(self, request):
            pass

    # Both uri and methods are None, so attributeError should be caught
    assert app.route(uri=None, methods=None) == RouteMixin.route
    # Both uri and methods are string, so uri should be string and methods should be list
    assert app.route(uri="string", methods="GET") == RouteMixin.route
    # Both uri and methods are lists, so

# Generated at 2022-06-24 04:25:59.886440
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    request = Request(
        'GET', "http://localhost:8888/1/2/3",
        headers={})
    response = StreamHTTPResponse(body=b"123")
    assert request.url == "http://localhost:8888/1/2/3"
    assert response.body == b"123"


# Generated at 2022-06-24 04:26:07.079551
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    """
    Test add_websocket_route
    """
    m = RouteMixin()
    def handler(*args, **kwargs):
        """
        Handler of the route
        """
        pass
    m.add_websocket_route(handler, uri='/uri', host='127.0.0.1', strict_slashes=False, subprotocols=None, version=None, name='name')
    print(m.websocket_routes)
# add_websocket_route
test_RouteMixin_add_websocket_route()

# Generated at 2022-06-24 04:26:15.380497
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    app = Sanic(__name__)
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_TIMEOUT = 10
    app.config.RESPONSE_TIMEOUT = 15
    app.config.KEEP_ALIVE = True

    @app.get("/", strict_slashes=True)
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "OK"

    request, response = app.test_client.get("")
    assert response.status == 200
    assert response.text == "OK"


# Generated at 2022-06-24 04:26:22.175890
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    uri = '/uri'
    host = 'host'
    host_result = '127.0.0.1'
    strict_slashes = True
    strict_slashes_result = True
    subprotocols = None
    version = '1'
    name = 'name'
    name_result = 'name'
    apply = True
    apply_result = True
    obj = RouteMixin()
    # Call the method
    handler = {}
    actualresult = obj.add_websocket_route(handler, uri, host, strict_slashes, subprotocols, version, name, apply)
    # Check the result
    assert actualresult == handler

# Generated at 2022-06-24 04:26:23.167855
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    pass



# Generated at 2022-06-24 04:26:30.607818
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic("sanic")
    router = RouteMixin(app, name="test_route")
    router.route("/", methods=["GET"], name="simple_route")
    assert str(router.routes[0]) == "Route(/ -> handler, host=None, methods=('GET'))"
    router.route("/", methods=["PUT"])
    assert str(router.routes[1]) == "Route(/ -> handler, host=None, methods=('PUT'))"
    router.route("/", methods=["POST", "DELETE"])
    assert str(router.routes[2]) == "Route(/ -> handler, host=None, methods=('POST', 'DELETE'))"
    router.route("/", methods=["PUT"])
    assert str

# Generated at 2022-06-24 04:26:36.659873
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Pass: @static(uri, file_or_directory)
    # Fail: @static()
    try:
        @static(uri, file_or_directory)
        def self():
            pass
    except Exception as e:
        raise

    try:
        @static()
        def self():
            pass
    except TypeError:
        pass



# Generated at 2022-06-24 04:26:39.472566
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    route = Route('HEAD', '', '')
    assert route.methods == ['HEAD']
    assert route.group == ''
    assert route.uri == ''


# Generated at 2022-06-24 04:26:43.513253
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():  
    with pytest.raises(Exception) as e_info:
        RouteMixin.delete()


# Generated at 2022-06-24 04:26:51.103507
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    import pytest
    from sanic.response import json
    from sanic.utils import sanic_endpoint_test

    class TestRouteMixin(RouteMixin):
        pass

    @TestRouteMixin.route("/route")
    async def handler(request):
        return json({"test": True})

    request, response = sanic_endpoint_test(TestRouteMixin.application)
    assert response.json.get("test")



# Generated at 2022-06-24 04:27:03.357602
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.router import Route

    from tests.router import test_server

    app = Sanic('test_RouteMixin_patch')
    routeMixin = RouteMixin()

    @app.patch('/patch')
    async def patch_handler(request):
        return text('I am a PATCH request')

    assert routeMixin.routes == []
    assert len(app.router.routes_all) == 1

    assert isinstance(app.router.routes_all[0], Route)
    assert app.router.routes_all[0].name == 'patch_handler'
    assert app.router.routes_all[0].uri == '/patch'
    assert app.router.routes_all[0].methods == ['PATCH']


# Generated at 2022-06-24 04:27:08.955789
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import Route

    class RouteMixin(object):
        '''
        Test for RouteMixin class
        '''

        def __init__(self, uri=None, host=None, methods=None,
                     strict_slashes=None, version=None, name=None,
                     subprotocols=None, websocket=False, static=False,
                     version_constraint=None):
            self.uri = uri
            self.host = host
            self.methods = methods
            self.strict_slashes = strict_slashes
            self.version = version
            self.name = name
            self.subprotocols = subprotocols
            self.websocket = websocket
            self.static = static
            self.version_constraint = version_constraint
           

# Generated at 2022-06-24 04:27:11.437061
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    router = RouteMixin()
    assert router.routes == []


# Generated at 2022-06-24 04:27:24.392346
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.response import text
    from sanic.router import Route
    from datetime import datetime
    from io import StringIO
    from sanic.config import Config
    from sanic.app import Sanic
    #
    # Create a dummy "app" for the method.
    #
    config = Config()
    app = Sanic("sanic-server", config)
    app.name = "sanic-server"
    app.config = config
    app.websocket_max_message_size = None
    app.websocket_max_queue = None
    app.websocket_read_limit = None
    app.websocket_write_limit = None
    app.websocket_ping_interval = None
    app.websocket_close_timeout = 10
    app.websocket_

# Generated at 2022-06-24 04:27:26.934051
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    route_mixin = RouteMixin()
    assert route_mixin.get('/') == route_mixin.route()('get')


# Generated at 2022-06-24 04:27:35.817753
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic(__name__)

    @app.get("/", strict_slashes=True)
    async def home(request):
        # FIXME: return the correct HTTP response headers
        return HTTPResponse("Sanic here!")

    @app.get("/ping")
    async def test(request):
        return response.text("Pong!")

    @app.get("/echo/<thing>")
    async def echo(request, thing):
        return response.text("Say hello to my little friend: %s" % thing)

    @app.get("/files/<file_id:int>")
    async def file(request, file_id):
        # FIXME: return the correct HTTP response headers
        return HTTPResponse("File:%s\n" % file_id)


# Generated at 2022-06-24 04:27:45.526982
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # Test for RouteMixin.patch
    # Patch is a concrete method of class RouteMixin
    # We test if the patch method is defined
    assert inspect.ismethod(RouteMixin.patch)
    # Test that a patch is added to the router
    x = RouteMixin()
    @x.patch('/foo')
    def  h():
        pass
    assert x._routes['/foo']

    # Test for RouteMixin.patch
    # We test if the patch method is defined
    assert inspect.ismethod(RouteMixin.patch)
    # Test that a patch is added to the router
    x = RouteMixin()
    @x.patch('/foo')
    def  h():
        pass
    assert x._routes['/foo']

    # Test that a patch is added to the router


# Generated at 2022-06-24 04:27:53.262649
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic("test_RouteMixin_delete")

    @app.delete("test_RouteMixin_delete")
    async def handler(request):
        return text("OK")

    # assert isinstance(app.router.routes_names, dict)
    # assert app.router.routes_names.get(
    #     "test_RouteMixin_delete", None) == "test_RouteMixin_delete"

    request, response = app.test_client.delete("test_RouteMixin_delete")

    assert response.text == "OK"



# Generated at 2022-06-24 04:28:02.787130
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_client = TestClient(app=Sanic())
    route_mixin = RouteMixin()

    with pytest.raises(ValueError):
        @route_mixin.route("/test", methods=None)
        def test_route_1(request):
            return text("TEST")

    with pytest.raises(ValueError):
        @route_mixin.route("/test", methods=["GET", "POST", "PUT"])
        def test_route_2(request):
            return text("TEST")

    with pytest.raises(ValueError):
        @route_mixin.route("/test", methods=["GET", "POST", "PUT", "HEAD"])
        def test_route_3(request):
            return text("TEST")

# Generated at 2022-06-24 04:28:10.544312
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    '''
    Test if RouteMixin.patch(self, uri, host=None, strict_slashes=None,
            stream=False, version=None, name=None,
            apply=True, **options) works
    '''

    @asynctest.patch('sanic.router.RouteMixin.route')
    def test(mock_route):
        '''
        Test for RouteMixin.patch(self, uri, host=None, strict_slashes=None,
            stream=False, version=None, name=None,
            apply=True, **options)
        '''

        # Define args
        uri = 'uri_of_uri'
        host = 'host_of_host'
        strict_slashes = True
        stream = True
        version = 1

# Generated at 2022-06-24 04:28:11.233952
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    pass


# Generated at 2022-06-24 04:28:17.468607
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    instance = RouteMixin()
    host = None
    uri = "/"
    strict_slashes = None
    version = None
    name = None
    apply = True
    ret_value = instance.put(host=host,uri=uri,strict_slashes=strict_slashes,version=version,name=name,apply=apply)
    return ret_value


# Generated at 2022-06-24 04:28:21.820033
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # Test with Method not supported
    request, response = Sanic('test_RouteMixin_patch').test_client.put('/')
    assert response.status == 405
    # Test with Method supported
    request, response = Sanic('test_RouteMixin_patch').test_client.patch('/')
    assert response.status == 404
    

# Generated at 2022-06-24 04:28:28.743066
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    r = RouteMixin()
    assert isinstance(r, RouteMixin)
    assert r.name == None
    assert r.strict_slashes == None
    assert r.version == None
    assert r.host == None
    assert r.route_register == None
    assert r.url_for_func == None
    assert r.router == None
    assert r.versioned_router == False


# Generated at 2022-06-24 04:28:36.278978
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    app = Sanic(env='test')
    r = RouteMixin(app)
    uri='/api/v1'
    version='v1'
    name='v1_api'
    routes = r.get(uri=uri, version=version, name=name)
    assert type(routes) is tuple
    assert len(routes) == 2
    assert type(routes[0]) is list
    assert len(routes[0]) == 1
    assert type(routes[0][0]) is Route


# Generated at 2022-06-24 04:28:37.074674
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass

# Generated at 2022-06-24 04:28:47.984306
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    '''
    This method tests the functionality of
    the method head of class RouteMixin
    '''
    rm = RouteMixin()
    test_str = "/"
    test_args = ()
    test_kwargs = {}
    test_options = {}
    test_host = None
    test_name = "null"
    test_methods = ["HEAD"]
    test_strict_slashes = None
    test_apply = False
    test_result_expected = (Route(uri=test_str, args=test_args, kwargs=test_kwargs, options=test_options, host=test_host, name=test_name, methods=test_methods, strict_slashes=test_strict_slashes), None)

# Generated at 2022-06-24 04:29:00.443067
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    app = Sanic(__name__)

    def s(a, b, c, d, e, f, g, h, i, j, k, l, m, o, p, q, r, s, t, u, v, w, x, y, z, aa, ab, ac, ad, ae, af, ag, ah, ai, aj, ak, al, am, an, ao, ap, aq, ar, as_, at, au, av, aw, ax, ay, az, ba, bb, bc, bd, be, bf, bg, bh, bi, bj, bk, bl, bm, bn, bo, bp, bq, br, bs, bt, bu, bv):
        pass


# Generated at 2022-06-24 04:29:12.064441
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    method_name = 'route'
    from yandextank.plugins.Autostop.plugin import AutostopPlugin
    from yandextank.plugins.Phantom import Plugin
    from yandextank.plugins.DataUploader.plugin import DataUploaderPlugin
    from yandextank.plugins.ConsoleOnline.console import ConsolePlugin
    from yandextank.plugins.Telegraf.plugin import TelegrafPlugin
    from yandextank.plugins.Monitoring.plugin import MonitoringPlugin
    from yandextank.plugins.ConsoleOnline.console import ConsolePlugin
    from yandextank.plugins.ConsoleScreener.plugin import ConsoleScreenerPlugin
    from yandextank.plugins.ConsoleScreen.plugin import ConsoleScreenPlugin
    from yandextank.plugins.Blazemeter.plugin import BlazemeterPlugin

# Generated at 2022-06-24 04:29:21.744632
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("app")
    app.router.add_route("/post/<name:[a-zA-Z0-9]+>/<age:[a-zA-Z0-9]+>", "GET", None)
    app.router.add_route("/post/<name:[a-zA-Z0-9]+>", "GET", None)
    app.router.add_route("/post/<name:[a-zA-Z0-9]+>", "POST", None)
    app.router.add_route("/post/<name:[a-zA-Z0-9]+>", "PUT", None)
    app.router.add_route("/post/<name:[a-zA-Z0-9]+>", "DELETE", None)

# Generated at 2022-06-24 04:29:33.007385
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    route_mixin = RouteMixin()  # instance of RouteMixin

    # mock the parameters
    uri = None
    name = None
    host = None
    strict_slashes = None
    version = None
    stream = None
    include_in_schema = None
    apply = None
    scheme = None
    catch_all_404s = None
    output = None
    
    # call the method

# Generated at 2022-06-24 04:29:35.724851
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    '''
    Unit test function for RouteMixin class websocket method
    '''
    route_mixin_obj = RouteMixin()
    route_mixin_obj.websocket('/hello')



# Generated at 2022-06-24 04:29:41.867247
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    server = Sanic('test_RouteMixin_route')
    @server.route('/test')
    def handler(request):
        return text('OK')
    request, response = server.test_client.get('/test')
    assert response.text == 'OK'

# Generated at 2022-06-24 04:29:54.072839
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """Test for method RouteMixin: route"""
    method = RouteMixin()

    method_list = [
        "GET",
        "POST",
        "PUT",
        "DELETE",
        "PATCH",
        "HEAD",
        "OPTIONS",
        "LINK",
        "UNLINK"
    ]
    
    method_object = method.route(uri="/home", host="127.0.0.1",methods=method_list, strict_slashes=True, version=1, name="name", apply=True)
    assert method_object[0][0]._uri == "/home"
    assert method_object[0][0]._methods == method_list


# Generated at 2022-06-24 04:30:02.165393
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from .router import Route
    from .response import HTTPResponse
    from .exceptions import InvalidUsage
    from .websocket import WebSocketProtocol
    from .websocket import WebSocketProtocol13
    from .websocket import WebSocketProtocolHybi13
    from .websocket import WebSocketProtocolHybi08
    from .websocket import WebSocketProtocol76
    from .websocket import WebSocketProtocol75

    def test_route():
        """
        test_route
        
        :return: 
        """
    
    def test_route_websocket():
        """
        test_route_websocket
        
        :return: 
        """
    


# Generated at 2022-06-24 04:30:11.408130
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    gr = RouteMixin()
    routes = gr.options(
        uri='/', host=None, strict_slashes=None, version=None, name=None,
        apply=True
    )

# Generated at 2022-06-24 04:30:21.113538
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Post by RouteMixin
    # Post with empty route
    class dummyRouteMixin(RouteMixin):
        def post(self):
            pass
    dummyRouteMixin.post()

    # Post with a route
    class postRoute(RouteMixin):
        def post(self, request):
            pass
    postRoute.post(1)

    # Post with multiple routes
    class postRoute(RouteMixin):
        def post(self, request, response):
            pass
    postRoute.post(1,2)

    # Post with multiple routes
    class postRoute(RouteMixin):
        def post(self, request, response, url_param):
            pass
    postRoute.post(1, 2, 3)