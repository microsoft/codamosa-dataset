

# Generated at 2022-06-24 04:20:18.938898
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # args
    sanic_app = Sanic("sanic-router")
    sanic_app.config.KEEP_ALIVE_TIMEOUT = None
    sanic_app.config.REQUEST_TIMEOUT = None

    uri = "/test/static"
    file_or_directory = os.path.dirname(sanic_router.__file__)
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True

    # /////////// Before //////////////
    # Before

# Generated at 2022-06-24 04:20:25.934125
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    import uvicorn
    import asyncio
    from sanic.websocket import WebSocketProtocol
    try:
        from websockets.protocol import WebSocketCommonProtocol
    except ImportError:
        pass

    print("\n\nRunning Test: RouteMixin_add_websocket_route")

    async def handler(request, ws):
        while True:
            data = await ws.recv()
            print("Received: " + data)
            await asyncio.sleep(1)
            await ws.send("Pong: " + data)

    app = Sanic("test_app")
    app.add_websocket_route(
        handler,
        "/test",
        subprotocols=("test3.2", "test3.1"),
    )

    protocol = WebSocketProtocol

# Generated at 2022-06-24 04:20:34.165513
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    import pytest
    from sanic import Sanic
    from sanic.router import Route
    from sanic.websocket import WebSocketProtocol

    app = Sanic('test_RouteMixin_add_websocket_route')
    route_mixin = RouteMixin(app)

    class MyWebsocket(WebSocketProtocol):
        def __init__(self, *args, **kwargs):
            super(MyWebsocket, self).__init__(*args, **kwargs)
            self.routes = []
    
    async def websocket_handler(*args, **kwargs):
        return MyWebsocket(*args, **kwargs)
    
    route_mixin.add_websocket_route(websocket_handler, '/ws')
    

# Generated at 2022-06-24 04:20:34.957702
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    RouteMixin()


# Generated at 2022-06-24 04:20:40.131161
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():           
    obj = Sanic('test_RouteMixin_options')
    obj.route(uri='/', methods=['GET', 'POST'])
    assert obj.routes[0].uri == '/'
    assert obj.routes[0].methods == frozenset(['GET', 'POST'])
    assert obj.routes[0].handler == None


# Generated at 2022-06-24 04:20:47.143947
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    class RouteMixin(object):
        def put(self, *args, **kwargs):
            return self.route(*args, **kwargs)
        def route(self, uri, methods, name, host, strict_slashes, version, apply, **kwargs):
            return (1, lambda x : x)

    rm = RouteMixin()
    r, f = rm.put("uri", methods="methods", name="name", host="host", strict_slashes="strict_slashes", version="version", apply="apply")
    assert r == 1
    assert f(1) == 1

# Generated at 2022-06-24 04:20:55.001345
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    from sanic.router import Route
    from sanic.router import RouteExists

    mixin = RouteMixin()
    route = Route('/', methods=['GET'], host=None, strict_slashes=None, version=None, name='delete')
    mixin._routes.append(route)
    mixin.delete(route)
    assert len(mixin._routes) == 0

    with pytest.raises(RouteExists):
        route = Route('/', methods=['GET'], host=None, strict_slashes=None, version=None, name='delete')
        mixin.delete(route)

# Generated at 2022-06-24 04:21:04.172063
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_RouteMixin_post')
    rm = RouteMixin(app.router)
    test_path = '/'
    test_uri = '/'
    test_handler = text('test')
    @rm.post(test_uri)
    async def test_handler2(request):
        return text('await test_handler2')

    result = test_handler
    result2 = app.exception_handler.default(app.exception_handler, request,
                                            test_handler2)
    assert result == result2



# Generated at 2022-06-24 04:21:11.141830
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    """
    Test method websocket of class RouteMixin.
    """

    # Test with optional arguments
    async def handler():
        pass

    # Test with optional arguments
    async def handler():
        pass

    app = Sanic(__name__)

    # Test with optional arguments # TODO: StrictSlashes
    app.add_websocket_route(handler, "/", subprotocols=None, name="name")

    # Test with required arguments
    app.add_websocket_route(handler, "/")

    # Test with required arguments # TODO: StrictSlashes
    app.add_websocket_route(handler, "/")

    # Test with required arguments
    app.websocket('/')(handler)

    # Test with required arguments # TODO: StrictSlashes

# Generated at 2022-06-24 04:21:20.707134
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse,text
    app = Sanic('test_RouteMixin_add_route')
    response = HTTPResponse()
    route = Route(None,None,None,None,None)

    def test1_handler(request: Request, *args, **kwargs):
        return response
    async def test2_handler(request: Request, *args, **kwargs):
        return response
    @app.route("/test", methods=['GET'])
    def test3_handler(request: Request, *args, **kwargs):
        return response


# Generated at 2022-06-24 04:21:24.499811
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    # Get instance of RouteMixin
    rm = RouteMixin()
    # Call method add_websocket_route
    res = rm.add_websocket_route('test_websocket', '/testroute')
    # Assert type of returned value
    assert isinstance(res, decorator) == True


# Generated at 2022-06-24 04:21:28.897216
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()

    @route_mixin.get("/")
    def h1(request):
        print("h1")
        return "h1"
    
    h1_h2 = route_mixin.add_route(h1, "/2")

    assert h1_h2 is h1
    assert route_mixin._routes["/2"]


# Generated at 2022-06-24 04:21:31.378838
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    app = RouteMixin()
    r = Route()
    app.add_route(r)


# Generated at 2022-06-24 04:21:36.488397
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    class FakeSanic:
        del route
        del patch
        del socketio
        del add_route

    inst = RouteMixin(FakeSanic())
    resp = inst.patch(uri='/', handler='handler')
    # print(resp)
    assert resp == None

# Generated at 2022-06-24 04:21:48.488358
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    with patch("sanic.router.Route") as mock_route:
        from sanic.router import Route
        from sanic.router import RouteExists
        mock_route.side_effect = [Route(uri="/user", method="GET"), RouteExists()]
        routes = []
        routes.append(Route(uri="/user", method="GET"))
        routes.append(Route(uri="/user", method="POST"))
        # mock uri
        uri = "/user"
        # mock host
        host = "localhost"
        # mock version
        version = 1
        # mock name
        name = "test"
        # mock apply
        apply = True
        # mock strict_slashes
        strict_slashes = True
        # mock subprotocols
        subprotocols = None
        # mock websocket


# Generated at 2022-06-24 04:21:56.533048
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    router = Router()
    curr_num_routes = len(router.routes_all)
    assert router.routes_all == []
    uri = '/'
    handler = None
    router.add_route(handler=handler, uri=uri)
    assert len(router.routes_all) == curr_num_routes + 1
    assert router.routes_all[curr_num_routes].uri == uri
    assert router.routes_all[curr_num_routes].handler == handler
    
    

# Generated at 2022-06-24 04:22:06.940456
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():

    def test_handler():
        pass

    class TestRouteMixin:

        def put(self):
            pass

    class TestRouteMixinWithoutPut:

        def get(self):
            pass

    router = RouteMixin()

    # Affected branch 1
    test_handler_wrapper = router.put("/1/", name="name")(test_handler)
    assert isinstance(test_handler_wrapper, FunctionType)
    assert test_handler_wrapper.__name__ == 'test_handler'
    assert test_handler_wrapper.__doc__ == 'test doc'

    # Affected branch 2
    test_handler_wrapper = router.put("/1/", name="name")(test_handler)
    assert isinstance(test_handler_wrapper, FunctionType)

# Generated at 2022-06-24 04:22:12.371221
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    result = RouteMixin().add_websocket_route(handler=None, 
                                              uri='/', 
                                              host=None, 
                                              strict_slashes=False, 
                                              subprotocols=None, 
                                              version=None, 
                                              name=None)
    assert result is not None


# Generated at 2022-06-24 04:22:22.955720
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    
    # Method #1
    @ClassBasedRouterMixin.options("/")
    def handler(request):
        pass
    h = handler
    assert h.__name__ == "handler"

    # Method #2
    @ClassBasedRouterMixin.options("/", host="example.com")
    def handler(request):
        pass
    h = handler
    assert h.__name__ == "handler"

    # Method #3
    @ClassBasedRouterMixin.options("/", methods=["POST"])
    def handler(request):
        pass
    h = handler
    assert h.__name__ == "handler"

    # Method #4
    @ClassBasedRouterMixin.options("/", host="example.com", methods=["POST"])
    def handler(request):
        pass
    h

# Generated at 2022-06-24 04:22:24.117601
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    pass


# Generated at 2022-06-24 04:22:28.147128
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    class MockApp(RouteMixin):
        def __init__(self):
            super().__init__()
            self.router = MockRouter()

    with pytest.raises(TypeError):
        MockApp()


# Generated at 2022-06-24 04:22:37.390175
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Input
    uri = '/test_post'
    host = None
    strict_slashes = None
    stream = False
    version = None
    name = None
    methods = None
    layout = None
    routines = None
    body = None
    # Expected output
    expected = None
    # ________________________________________________________
    # Generate output
    # ________________________________________________________
    class Testpost(RouteMixin):
        def __init__(self):
            self.app = Sanic('app')
        @post(uri, host, strict_slashes, stream, version, name, methods, layout,
              routines, body)
        def f():
            pass
    # ________________________________________________________
    # Test
    # ________________________________________________________
    test_post = Testpost()
    assert test_post.f == expected

# Generated at 2022-06-24 04:22:38.372455
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    assert False


# Generated at 2022-06-24 04:22:43.301980
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    """
    Unit test for the constructor of class RouteMixin.
    """
    # should not raise Exception
    RouteMixin()
    # should not raise Exception
    RouteMixin(name='test')


# Generated at 2022-06-24 04:22:54.003932
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import collect_routes
    from sanic.router import sanitize_url
    from sanic.router import Router
    from sanic.router import RuleTemplate
    from sanic.router import StaticRoute
    from sanic.router import URLSpec
    from sanic.router import UrlTemplate
    from sanic.router import compile_route_pattern
    from sanic.router import get_parameter_name_from_match
    from sanic.router import get_route_name_from_handler
    from sanic.router import merge_rules
    from sanic.router import prepare_regex_pattern
    from sanic.router import register_route

# Generated at 2022-06-24 04:22:57.581598
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    uri = "/test"
    name = "test"
    function = lambda x: 1
    router = RouteMixin()
    assert router.delete(uri,name)(function) == function

# Generated at 2022-06-24 04:22:58.322725
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass

# Generated at 2022-06-24 04:23:03.177105
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    class Test(object):
        pass
    obj = RouteMixin()
    obj.name = "test"
    uri = "/Users/test"
    strict_slashes = None
    return_value = obj.delete(uri, strict_slashes)
    assert return_value == (obj._route, Test)


# Generated at 2022-06-24 04:23:08.425715
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    sanic_obj = Sanic('sanic-test')
    obj = RouteMixin(sanic_obj)
    obj._register_static()


if __name__ == "__main__":
    test_RouteMixin()

# Generated at 2022-06-24 04:23:18.595070
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.websocket import WebSocketProtocol
    route = RouteMixin()
    arg1 = "/static"
    arg2 = "/"
    arg3 = ".*"
    arg4 = True
    arg5 = False
    arg6 = False
    arg7 = "static"
    arg8 = None
    arg9 = None
    arg10 = "test_RouteMixin_static"
    expected_result = Route(arg1, arg2, None, arg3, arg4, arg5, arg6, arg7, 
    arg8, arg9, "GET", WebSocketProtocol(None), None, None, True, arg10)

# Generated at 2022-06-24 04:23:31.054011
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.response import text
    from sanic import Sanic
    from io import BytesIO
    app = Sanic("test_RouteMixin_static")


    async def test_static_view(request):
        return text("Testing static")

    app.static("/static", "./static")

    handler, _ = app.router.get(
        "/static/favicon.ico", strict_slashes=False)
    assert handler.handler_args["file_or_directory"] == "./static"

    @app.route("/test_static")
    async def test_static(request):
        return text("Testing static")

    @app.route("/test_static_with_name")
    async def test_static_with_name(request):
        return text("Testing static with name")


# Generated at 2022-06-24 04:23:43.096070
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    r = coroutine_return_value()
    r.set_coroutine_return_value(None)
    @asynctest
    async def mock_websocket_request(request, ws):
        return r.coroutine_return_value

    @asynctest
    async def mock_coroutine():
        pass

    @asynctest
    async def mock_get(request):
        return r.coroutine_return_value

    test_app = Sanic('test_RouteMixin_websocket')
    test_app.route('mock_websocket_request', '/mock_websocket_request', websocket=True)(mock_websocket_request)
    test_app.route('mock_coroutine', '/mock_coroutine')(mock_coroutine)
    test_

# Generated at 2022-06-24 04:23:51.824221
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test parameter 'handler' of type <class 'function'>
    def hello():
        pass
    # Test parameter 'uri' of type <class 'str'>
    uri = "/test"
    # Test parameter 'methods' of type <class 'NoneType'>
    methods = None
    # Test parameter 'host' of type <class 'NoneType'>
    host = None
    # Test parameter 'strict_slashes' of type <class 'NoneType'>
    strict_slashes = None
    # Test parameter 'version' of type <class 'NoneType'>
    version = None
    # Test parameter 'name' of type <class 'NoneType'>
    name = None

    test_obj = RouteMixin()
    test_obj.add_route(hello, uri, methods, host, strict_slashes, version, name)


# Generated at 2022-06-24 04:23:52.991824
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket(): 
    # Tests for websocket
    pass

# Generated at 2022-06-24 04:23:54.670880
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    pass




# Generated at 2022-06-24 04:24:05.894418
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    mixin = RouteMixin()
    uri = 'testing_uri'
    host = 'testing_host'
    strict_slashes = None
    version = 1
    name = 'testing_name'
    apply = True
    return_value_expected = {
        'route': [Route(uri='testing_uri',
                        methods=['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
                        host='testing_host',
                        strict_slashes=None,
                        version=1,
                        name='testing_name',
                        static=False,
                        websocket=False,
                        stream=False,
                        status_code=None)],
        'fn' : None
    }

# Generated at 2022-06-24 04:24:10.390149
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # Arrange
    # Act
    res = RouteMixin().websocket(
        uri=None,
        host=None,
        strict_slashes=None,
        subprotocols=None,
        version=None,
        name=None,
        apply=True,
    )

    # Assert
    assert res == (None, None)


# Generated at 2022-06-24 04:24:16.709647
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    app = Sanic(__name__)
    app.route('/')(lambda request: 'OK')

    assert app.url_for('test_RouteMixin_route.<locals>.handler') == '/'
    assert app.url_for('test_RouteMixin_route.<locals>.handler', _external=True) == 'http://127.0.0.1:8000/'

# Generated at 2022-06-24 04:24:27.832210
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    class Test:
        def test_basic(self):
            app = Sanic(__name__)
            route, handler = app.get("/")(lambda req: 'test')
            assert isinstance(route, Route)
            assert route.rule == "/"

        def test_hosts(self):
            app = Sanic(__name__)
            for host in HOSTS.values():
                app = Sanic(__name__)
                route, handler = app.get("/", host=host)(lambda req: 'test')
                assert isinstance(route, Route)
                assert route.host == host

        def test_strict_slashes(self):
            app = Sanic(__name__)
            route, handler = app.get("/", strict_slashes=True)(
                lambda req: 'test'
            )

# Generated at 2022-06-24 04:24:30.828368
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("route_mixin_test")
    app.route("/websocket")(websocket)
    assert len(app.websocket_routes) == 1

# Generated at 2022-06-24 04:24:40.108944
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.router import Route
    from sanic.router import RouteExists

    @websocket("/22")
    async def handler2(request):
        return "OK"
    
    test = RouteMixin()
    test._register_route = mock.Mock()
    test._register_route.return_value = Route(
        uri="",
        host=None,
        methods=None,
        handler=handler2,
        name="handler2",
        version=None,
        strict_slashes=None,
        websocket=True,
        stream=False,
        subprotocols=None
    )
    test._register_websocket_route = mock.Mock()

# Generated at 2022-06-24 04:24:40.962669
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass


# Generated at 2022-06-24 04:24:45.402740
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from .router import _Route
    route = _Route(None, None, None, None)
    route.head()

# Generated at 2022-06-24 04:24:48.218902
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    Sanic('test_RouteMixin_get')
    with pytest.raises(TypeError):
        Sanic.get()


# Generated at 2022-06-24 04:24:52.776788
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # This is a dummy method test. The route class is a blueprint object,
    # and has a lot of dependencies, so we do not want to test this in unit
    # test.
    # In fact, this method is just an adaptor for route function, so real
    # test for this method is in test_router.
    pass

# Generated at 2022-06-24 04:24:57.356372
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    import os
    import json
    import requests
    import multiprocessing as mp
    from sanic import Sanic, response
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol

    app = Sanic()

    @app.websocket('/test_add_websocket_route')
    async def test_add_websocket_route(request, ws):
        while True:
            data = "pong"
            print('Sending: ' + data)
            await ws.send(data)
            data = await ws.recv()
            print('Received: ' + data)
            if data == 'close':
                break


# Generated at 2022-06-24 04:25:03.459305
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    @MethodView.decorator()
    class TestView(MethodView):
        def get(self, request):
            pass

        def post(self, request):
            pass

    app = Sanic(__name__)
    view = TestView.as_view()
    app.add_route(view, uri='/')

# Generated at 2022-06-24 04:25:12.634616
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    router = Router()
    @router.head('/')
    async def hello(request):
        return response.text('Hello!')
    assert isinstance(router._routes_all, ChainMap)
    assert isinstance(router._routes_head, dict)
    assert isinstance(router._routes_head['/'], list)
    assert callable(router._routes_head['/'][0]['handler'])
    assert router._routes_head['/'][0]['hosts'] == '*'


# Generated at 2022-06-24 04:25:18.890568
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    with pytest.raises(PassedParameterIsNotCallable):
        route_mixin_instance = RouteMixin()
        route_mixin_instance.delete("delete")
        route_mixin_instance.delete(3)
        route_mixin_instance.delete([])
        route_mixin_instance.delete({})
        route_mixin_instance.delete(None)


# Generated at 2022-06-24 04:25:21.452007
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    assert True 

# Generated at 2022-06-24 04:25:31.562614
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    # Test the function of route decorator with options parameter
    with Sanic('test_app') as app:
        @app.websocket('/feed')
        async def feed(request, ws):
            while True:
                data = 'hello!'
                print('Sending: ' + data)
                await ws.send(data)
                data = await ws.recv()
                print('Received: ' + data)
            return ws

        @app.route('/', methods=['GET', 'HEAD'])
        async def test(request):
            return response.text('OK')

        @app.route('/0', methods=['GET'], strict_slashes=True)
        async def test1(request):
            return response.text('OK')


# Generated at 2022-06-24 04:25:40.142023
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    logger.info("Start route tests...")
    
    app = Sanic('test')
    
    @app.route('/test',host='testhost',strict_slashes=True)
    def handler(request):
        return text('OK')
    
    @app.route('/test')
    def handler(request):
        return text('OK')
    
    @app.route('/',host='testhost',strict_slashes=True)
    def handler(request):
        return text('OK')
    
    routes = app.routes_all
    
    assert routes[0].uri == '/test'
    assert routes[0].host == 'testhost'
    assert routes[0].strict_slashes == True
    assert routes[0].methods == ['GET']
    

# Generated at 2022-06-24 04:25:48.013064
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # Initialization
    router = RouteMixin()
    uri = "/"
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None

    # Execution
    function, routes = router.route(
        uri,
        host,
        methods,
        strict_slashes,
        version,
        name,
    )

    # Assertion
    assert function is None
    assert routes is None



# Generated at 2022-06-24 04:25:54.880655
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from unittest.mock import Mock

    # Setup app environment
    app = Sanic(__name__)
    app_router = Mock()
    app_router.add = Mock()
    app.router = app_router
    app.add_route = Mock()

    # Setup RouteMixin environment
    route_mixin_obj = RouteMixin()

    # Test route method with version
    version = Mock()
    route_mixin_obj.route(uri='/path', version=version)(Mock(return_value=Mock()))

    # Test route method with name
    url_for = Mock()

# Generated at 2022-06-24 04:26:06.252678
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    from sanic.router import Route
    from sanic.exceptions import InvalidUsage, NotFound
    from sanic.response import json as sanic_json
    from sanic import exceptions
    from sanic_openapi import doc
    from jinja2 import TemplateNotFound, Template

    import warnings
    import httpx

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        # Cause all warnings to always be triggered.
        _ = RouteMixin()
        assert len(w) == 0
        _ = RouteMixin(exceptions.InvalidUsage)
        assert len(w) == 0
        _ = RouteMixin(exceptions.InvalidUsage, exceptions.NotFound)
        assert len(w) == 0

# Generated at 2022-06-24 04:26:16.000935
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from . import route_mixin
    from . import sanic
    from . import exceptions

    #from sanic.router import Route
    #from sanic.server import serve
    #from sanic.response import text
    #from sanic.log import logger
    #from collections import namedtuple

    app = sanic.Sanic('test_RouteMixin_websocket')

    # method websocket
    HOST = '127.0.0.1'
    PORT = 8001
    URI = '/test'
    #route = Route(app, None, None, None, None, None, None, None, None)
    #route_mixin.RouteMixin().websocket(
    #    route.websocket(
    #        URI,
    #        host=HOST,
    #        strict_slashes

# Generated at 2022-06-24 04:26:27.058263
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    app = Sanic("test_RouteMixin_post")
    mix = RouteMixin(app, strict_slashes=True)
    class websocket:
        def __init__(self):
            self.name = "websocket"
        def __call__(self, *args, **kwargs):
            return self
    websocket = websocket()
    def route(self, uri, host, strict_slashes, methods, version, name, apply, subprotocols, websocket):
        return None, None
    mix.route = route
    mix.websocket = websocket
    mix.post("/", "http://localhost", True, 2, "name", True)
    print("passed test_RouteMixin_post")



# Generated at 2022-06-24 04:26:36.367865
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    server = RouteMixin
    fake_handler = 'fake'
    fake_uri = 'fake'
    fake_host = 'fake'
    fake_strict_slashes = 'fake'
    fake_version = 'fake'
    fake_strict_slashes = 'fake'
    fake_name = 'fake'
    fake_subprotocols = 'fake'
    fake_websocket = 'fake'
    fake_apply = 'fake'
    assert server.route(handler, fake_uri, fake_methods, fake_host, fake_strict_slashes, fake_version, fake_name, fake_apply, fake_subprotocols, fake_websocket) == (route, fake_handler)

# Generated at 2022-06-24 04:26:43.982957
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    import sys
    import asyncio

    @staticmethod
    def fake_coroutine(*args, **kwargs):
        return RouteMixin.delete()

    RouteMixin.delete = fake_coroutine

    test_instance = RouteMixin()

    coro = test_instance.delete()
    try:
        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(coro)
    except:
        print("Exception when calling RouteMixin.delete:")
        print(sys.exc_info()[0])

    assert result is None


# Generated at 2022-06-24 04:26:55.181353
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    app = Sanic('test_RouteMixin_static')
    # 当前目录为 test/unittest
    app.static('/static','../../examples/static/hell.txt', name='static')
    assert isinstance(app.router.routes_all['static'], sanic.router.Route)
    assert app.router.routes_all['static'].uri == '/static/<__file_uri__:path>'
    assert app.router.routes_all['static'].name == 'static'

    with pytest.raises(ValueError) as excinfo:
        app.static('/static', 123, name='123')
    assert f"Invalid file path string" in str(excinfo.value)

# Generated at 2022-06-24 04:27:06.855014
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    import unittest
    from unittest.mock import Mock
    from sanic.router import Route
    from sanic.router import RouteExpects

    class TestCase(unittest.TestCase):

        def setUp(self):
            # mock app
            self.app = Mock()
            self.app.static_folder = Mock(return_value='/')
            self.app.router = Mock()
            self.app.blueprints = {}
            RouteMixin.host = 'host'
            RouteMixin.name = 'name'
            RouteMixin.blueprint = Mock()

        def test_add_route(self):
            # mock route, handler
            route = Mock()
            handler = Mock()

            # mock route.copy
            route_copy = Mock()

# Generated at 2022-06-24 04:27:11.235982
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # Method get is not implemented 
    pass

# Generated at 2022-06-24 04:27:24.227614
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("sanic-test")

    @app.websocket("/test")
    async def handler(request, ws):
        pass

    routes = [
        Route(
            handler,
            uri="/test",
            methods=set(),
            host=None,
            strict_slashes=None,
            version=None,
            name="handler",
            websocket=True,
            stream=False,
            subprotocols=None,
            compiled_pattern=re.compile(
                "^/(?:(?P<token>[a-zA-Z0-9_.-]{64}))$"
            ),
        )
    ]

    assert app.router._routes_names["GET"] == {}
    assert app.router._routes_all == {}


# Generated at 2022-06-24 04:27:33.956576
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic import Sanic
    app = Sanic("options_test")  # type: Sanic
    app.config.from_object(CONFIG, silent=True)

    all_test_methods = []
    for route_method in [app.route, app.get, app.post, app.put, app.patch, app.delete, app.head, app.options]:
        def test_method(route_method):
            @route_method("/uri", methods=["GET", "POST"], name="name", host="host", strict_slashes=True, version=1, apply=True)
            def test_handler(request):
                pass
        all_test_methods.append(test_method)

    for test_method in all_test_methods:
        test_method(test_method)


# Generated at 2022-06-24 04:27:35.375097
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    pass


# Generated at 2022-06-24 04:27:40.780716
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.route import Route
    
    app = Sanic("test_RouteMixin_static")
    
    # Pass

    @app.route("/")
    def handler(request):
        return HTTPResponse(b"OK")

    app.static('/static', 'static/path')

    @app.listener('after_server_start')
    def async_after_server_start(app, loop):
        pass
    
    @app.listener('after_server_stop')
    def async_after_server_stop(app, loop):
        pass
    

# Generated at 2022-06-24 04:27:51.581286
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    def ws_handler(request):
        # import sys
        # sys.path.append('/Users/baiweili/PycharmProjects/Sanic-Server/sanic/router')
        # from route_mixin import RouteMixin
        # mixin = RouteMixin()
        # routes = mixin.websocket('uri',host='host',strict_slashes='strict_slashes',
        #                    version='version',name='name',apply='apply')
        # routes = routes(request)
        return request

    RouteMixin.websocket = websocket
    RouteMixin.websocket('uri', host='host', strict_slashes='strict_slashes',
                         version='version', name='name', apply='apply')

# Generated at 2022-06-24 04:27:59.614151
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():

    uri = '<path:path>'
    host = '192.168.60.4'
    strict_slashes = 'False'
    version = 3
    name = 'register_route_put'
    apply = 'True'
 
    router = RouteMixin()
    handler = router.put(uri, host, strict_slashes, version, name, apply)
    
    assert handler == 'uri' and 'host' and 'strict_slashes' and 'version' and 'name' and 'apply'
TestRunner().run(test_RouteMixin_put.__doc__)


# Generated at 2022-06-24 04:28:01.818242
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    import pytest

    with pytest.raises(AssertionError):
        RouteMixin().websocket()


# Generated at 2022-06-24 04:28:10.497783
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import Route
    from sanic.exceptions import MethodNotSupported

    router = RouteMixin()
    router.options('/hello', [1,2,3,4], True, None,None,None,None,False)

    assert len(router.routes) == 1

    assert router.routes[0].methods == ['OPTIONS']
    assert router.routes[0].uri == '/hello'
    assert router.routes[0].host == [1,2,3,4]
    assert router.routes[0].strict_slashes == True
    assert router.routes[0].version == None
    assert router.routes[0].name == None
    assert router.routes[0].websocket == None

    # Test exception raising


# Generated at 2022-06-24 04:28:11.541471
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-24 04:28:18.781281
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    host = 'sparkle.abc.com'
    uri = '/'
    strict_slashes = True
    methods = ['GET']
    version = '1.0'
    name = 'function_name'
    apply = True
    routes, decorated_function = RouteMixin().route(uri, host, methods, strict_slashes, version, name, apply)
    assert isinstance(decorated_function, functools.partial)
    assert isinstance(routes, list)
    assert routes[0].name == name

# Generated at 2022-06-24 04:28:23.854091
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    route_mixin = RouteMixin()
    route_mixin.route = MagicMock()
    route_mixin.get(uri="/", host=None, strict_slashes=None, version=None, name=None, apply=True)
    route_mixin.route.assert_called_once_with(uri="/", host=None, strict_slashes=None, methods=["GET"], version=None, name=None, apply=True, websocket=False)


# Generated at 2022-06-24 04:28:24.590836
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass

# Generated at 2022-06-24 04:28:27.041341
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    mixin = RouteMixin()
    options = mixin.options
    options('uri', name='name', version=1)

# Generated at 2022-06-24 04:28:30.551045
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    router = Router()
    router.route("/url/", methods=["GET"], name="test")
    assert (router.routes_names["test"].uri=="/url/")



# Generated at 2022-06-24 04:28:40.224732
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    def dummy_function():
        pass
    RouteMixin = RouteMixin()
    RouteMixin.head = dummy_function
    RouteMixin.strict_slashes = True
    RouteMixin.route_class = Route
    RouteMixin.host = None
    RouteMixin.name = "Sanic"
    RouteMixin.route_class = Route
    RouteMixin.subdomain_matching = False
    RouteMixin.subdomain = "www"
    RouteMixin.strict_slashes = False
    RouteMixin.route_class = Route
    RouteMixin.subdomain_matching = False
    RouteMixin.subdomain = "www"
    RouteMixin.name = "Sanic"
    RouteMixin.strict_slashes = False
    RouteMixin.route_class = Route
    Route

# Generated at 2022-06-24 04:28:50.342302
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    # Imports
    from werkzeug.test import create_environ
    from werkzeug.wrappers import BaseResponse
    import json
    import re

    # Mocks
    class MockSanic:
        name = 'sanic_server'
        host = '127.0.0.1'
        port = 8080
        debug = False

        def register_route(self, route):
            self.route = route

    class MockRequest:
        app = MockSanic()
        path = None
        url = None
        method = None
        protocol = None
        headers = None

        def __init__(self, path, method, headers, content_type='text/html'):
            self.path = path
            self.method = method
            self.url = path
            self.protocol = 'http'
           

# Generated at 2022-06-24 04:28:51.644069
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    a=RouteMixin()
    assert a is not None

# Generated at 2022-06-24 04:28:53.229603
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    a = RouteMixin()
    assert a != None


# Generated at 2022-06-24 04:29:03.717304
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic import Sanic

    class RouteMixinTest(object):
        pass

    s = Sanic("sanic-server")
    r = RouteMixinTest()
    r.name = "route_mixin_test"
    r.blueprint = None
    r.strict_slashes = None
    r.add_route = Sanic.add_route
    r.error_handler = Sanic.error_handler

    @r.route("/foo/bar")
    def foo(request):
        return response.text("foo")

    # Check: that the returned routes has been registered by Sanic
    assert isinstance(s.router.routes_names["route_mixin_test.foo"], Route)

# Generated at 2022-06-24 04:29:14.803196
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse, StreamingHTTPResponse
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler
    from sanic.router import Route, ContentRangeHandler

# Generated at 2022-06-24 04:29:16.734910
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    sanic = Sanic('test_RouteMixin_route')
    sanic.route()


# Generated at 2022-06-24 04:29:23.861476
# Unit test for method patch of class RouteMixin

# Generated at 2022-06-24 04:29:31.922799
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    _, route_mixin.route = route_mixin.route(methods=['GET'])
    @route_mixin.route(uri='/test_RouteMixin_route', methods=['GET'], version=1, name='test_RouteMixin_route')
    async def test_RouteMixin_route_route(request):
        pass
    assert(inspect.getsource(test_RouteMixin_route_route) == inspect.getsource(route_mixin.route))


# Generated at 2022-06-24 04:29:33.965462
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass

# Generated at 2022-06-24 04:29:42.094076
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # URLS
    urls = {
        "URL_TEMPLATE": "https://www.example.com/hi/<url>",
        "URL_INVALID": "https://www.example.com/hi/<url>/<nothing>",
    }
    # RouteMixin
    routemixin = RouteMixin()

    ########################
    # WHEN calling route AND
    #      route name AND
    #      request method AND
    #      host AND
    #      strict_slashes AND
    #      version AND
    #      methods AND
    #      static AND
    #      apply is True AND
    #      websocket is True AND
    #      subprotocols is non empty list AND
    #      apply is True
    ########################

# Generated at 2022-06-24 04:29:55.161761
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic import router
    import re

    @router.delete('/')
    async def handler(request):
        return HTTPResponse(text='OK')

    app = Sanic('test_delete')
    app.blueprint(router)

    request, response = app.test_client.delete('/')
    put_route = router._routes['delete'][0]

    assert put_route.methods == ['DELETE']
    assert put_route.uri == '/'
    assert put_route.strict_slashes is True
    assert put_route.host is None
    assert put_route.name == 'handler'
    assert put_route.version is None


# Generated at 2022-06-24 04:30:03.713549
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    uri = '/foo/bar'
    handler = None
    strict_slashes = True
    name = None
    host = None
    version = None
    apply = None
    subprotocols = None
    websocket = None
    default = None
    stream = None
    raw = None
    route_method = 'DELETE'
    router = Router()
    router.add_route = MagicMock(return_value = None)
    router.route(uri = uri, handler = handler, route_method = route_method, strict_slashes = strict_slashes, name = name, version = version, host = host, apply = apply, subprotocols = subprotocols, websocket = websocket, default = default, stream = stream, raw = raw)
    assert router.add_route.call_count == 1



# Generated at 2022-06-24 04:30:05.983094
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    pass_method = RouteMixin()
    assert pass_method.post is not None
    

# Generated at 2022-06-24 04:30:07.626441
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    obj = RouteMixin()
    assert obj is not None


# Generated at 2022-06-24 04:30:19.165120
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    class FakeRouteMixin:
        strict_slashes = False
        name = 'test'
        _future_statics = None
        add_route = None
        _apply_route = None
        _register_route = None
        _router = None
        _static = None
        static = None
        #Add your code here
        @websocket('/', strict_slashes=False, version=1, name='name_websocket', apply=True)
        def websocket(self, uri=None, host=None, strict_slashes=None, version=None, name=None, subprotocols=None, apply=None):
            return self, uri, host, 'strick_slashes', 1, 'name_websocket', 'subprotocols', False
        pass


    route_Mixin = Fake