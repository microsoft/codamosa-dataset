

# Generated at 2022-06-26 03:51:09.909100
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    class Request:
        def __init__(self, method, url_info):
            self.method = method
            self.url_info = url_info
        
        def __repr__(self):
            return repr((self.method, self.url_info))

    class Response:
        def __init__(self, status, headers, body):
            self.status = status
            self.headers = headers
            self.body = body

        def __repr__(self):
            return repr((self.status, self.headers, self.body))

    def handler_0(request):
        assert type(request) == Request
        assert request.method == "GET"
        assert request.url_info == "/"

# Generated at 2022-06-26 03:51:10.589438
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert RouteMixin.add_route


# Generated at 2022-06-26 03:51:17.907602
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # case 0
    route_mixin_0 = RouteMixin()
    case_0_uri = "/users/"
    case_0_methods = ["PUT"]
    case_0_host = None
    case_0_strict_slashes = None
    case_0_version = None
    case_0_name = None
    case_0_apply = True
    case_0_static = False
    case_0_trailing_slash = True
    case_0_can_stream_body = False
    case_0_stream_large_bodies = False
    case_0_register_as_coroutine = False
    case_0_status_code = None

# Generated at 2022-06-26 03:51:27.721075
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = '0'
    host_0 = '0'
    methods_0 = '0'
    strict_slashes_0 = '0'
    version_0 = '0'
    name_0 = '0'
    route_0, route_1 = route_mixin_0.route(uri_0, host_0, methods_0, strict_slashes_0, version_0, name_0)
    assert route_0.uri_template == '/<uri>'


# Generated at 2022-06-26 03:51:42.395213
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Custom example unit test
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(
        uri="[A-Za-z0-9]{2}/<surgeon_id:[A-Za-z0-9]{2,3}>/surgery_history/<date>",
        methods=["POST", "ValueError"],
        version=1,
        host="localhost",
        name="add_route_0",
        strict_slashes=True,
    )
    route_mixin_1 = RouteMixin()

# Generated at 2022-06-26 03:51:48.878435
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case #0 route
    test_case_0()

    # Test case #1 RouteMixin.route
    class RouteMixin_route(RouteMixin):
        # Assertion: methods: List[str]
        # Assertion: uri
        # Assertion: strict_slashes: Optional[bool]
        def route(self, uri: str, host: Optional[str] = None, methods: List[
            str] = None, strict_slashes: Optional[bool] = None, version: Optional[int] = None, name:
            Optional[str] = None, apply: bool = True, subprotocols=None,
            websocket=False):

            return None

    route_mixin_1 = RouteMixin_route()

    host = "http://localhost:8000"
    uri = "/"

# Generated at 2022-06-26 03:51:54.476789
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    handler = lambda : None
    uri = 'test_uri_string'
    methods = ['GET', 'POST']
    version = 1
    host = 'test_host_string'
    strict_slashes = False
    stream = True
    register = True
    name = 'test_name_string'

    routeMixin_0 = RouteMixin()
    routes, fn = routeMixin_0.route(uri, methods, host, strict_slashes, version, stream, register, name) 
    return fn


# Generated at 2022-06-26 03:52:05.948369
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    import unittest
    import shutil
    import asyncio

    async def handler0(request: Request):
        pass

    class Static():
        def __init__(self, file_or_directory, uri, pattern, use_modified_since, \
            use_content_range, stream_large_files, name, host, strict_slashes, \
            content_type):
            self.file_or_directory = file_or_directory
            self.uri = uri
            self.pattern = pattern
            self.use_modified_since = use_modified_since
            self.use_content_range = use_content_range
            self.stream_large_files = stream_large_files
            self.name = name
            self.host = host

# Generated at 2022-06-26 03:52:08.504274
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app_0 = Sanic("test_RouteMixin_add_route")
    route_mixin_0 = RouteMixin()
    def handler_0():
        return None
    
    route_mixin_0.add_route(handler_0, "/", methods=["GET"], version=1)


# Generated at 2022-06-26 03:52:18.881739
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test')
    uri = "test"
    methods = ["GET"]
    handler = app.request_handler
    host = "127.0.0.1"
    version = 1
    name = None
    strict_slashes = True
    stream = True
    apply = True
    inject_host = True
    inject_port = True
    uri_params = {}
    route_mixin_1 = RouteMixin()
    # Test with host
    result_1 = route_mixin_1.add_route(uri, methods, handler, host, version,
                                   name, strict_slashes, stream, apply,
                                   inject_host, inject_port, uri_params)
    assert isinstance(result_1, Route)
    assert result_1.uri == uri
    assert result_

# Generated at 2022-06-26 03:52:37.954754
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.router import Route
    app = Sanic(__name__)
    router = Router(app=app, name='sanic.app.router.Router')
    route_mixin = RouteMixin(router=router)
    # test case 1
    result1 = route_mixin.add_route(uri=None, methods=[], endpoint=None, host=None, strict_slashes=None, version=None, name=None, stream=False, websocket=False)
    assert result1 == None


# Generated at 2022-06-26 03:52:45.261195
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    # Assign parameters for the method
    uri = "uri"
    # Assign variables for the method
    returns_0 = None
    # Call the method
    returns_0 = route_mixin_0.route(uri)
    # Verify if the method works as expected
    assert returns_0 is None


# Generated at 2022-06-26 03:52:58.786254
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    file_or_directory = r"/home/kirill/MyWork/Research/sanic_mock/sanic/static/"
    uri = r"/static"
    pattern = None
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = None
    host = r"10.4.4.20"
    strict_slashes = None
    content_type = None
    apply = True
    RouteMixin_0 = RouteMixin()
    RouteMixin_0.static(file_or_directory, uri, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)


# Generated at 2022-06-26 03:53:12.389088
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    #Creation of an object of class Sanic
    sanic_0 = Sanic()
    sanic_0.config.REQUEST_MAX_SIZE = 1073741824
    #Creation of an object of class RouteMixin as a member of sanic_0
    sanic_0.router = RouteMixin()
    sanic_0.trim_request_class = False
    sanic_0.exception_handler = None
    sanic_0.before_start = []
    sanic_0.after_start = []
    sanic_0.before_stop = []
    sanic_0.after_stop = []
    sanic_0.before_start_funcs = []
    sanic_0.after_start_funcs = []
    sanic_0.before_stop_funcs = []
   

# Generated at 2022-06-26 03:53:19.852733
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    method, uri, host = 'POST', '', None
    routes = route_mixin_0.route(
        method=method, uri=uri, host=host
    )
    assert(routes[0].methods == {'POST'})
    assert(routes[0].uri == uri)
    assert(routes[0].host == host)


# Generated at 2022-06-26 03:53:32.551914
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for function sub
    print(sub('[;\\"\\.]', '', '"a; b. c\\"'))

    # Test for function join
    print(path.join('abc', '123'))

    # Test for function decode_uri
    print(unquote('abc+def%20hij'))

    # Test for class FutureStatic
    static_0 = FutureStatic(
        '/static',
        file_or_directory='.',
        pattern=r'/[.]*',
        use_modified_since=1,
        use_content_range=1,
        stream_large_files=1,
        name='static',
        host='*',
        strict_slashes=0,
        content_type='text/plain'
    )

    # Test for function route

# Generated at 2022-06-26 03:53:44.997278
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # test case 1
    route_mixin_1 = RouteMixin()
    @route_mixin_1.add_route('/', 'GET', host='0.0.0.0', strict_slashes=False, stream=True)
    def hello_world():
        """
        TEST CASE 1
        """
        return
    print(route_mixin_1.routes)

    # test case 2
    route_mixin_2 = RouteMixin()
    @route_mixin_2.add_route('/', 'GET', host='0.0.0.0', strict_slashes=False, stream=True)
    class Hello(object):
        """
        TEST CASE 2
        """
        def __init__(self):
            return
        def __call__(self, request):
            return
       

# Generated at 2022-06-26 03:53:51.697316
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    mock_methods_0 = Mock(spec=[])
    mock_methods_0.get.return_value = True
    mock_methods_0.delete.return_value = False
    mock_methods_0.put.return_value = True
    mock_methods_0.get.return_value = True
    mock_methods_0.post.return_value = True
    def mock_handler_0(request):
        return True
    
    # Test line 791

# Generated at 2022-06-26 03:53:59.966517
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Change method and parameters here
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(
        handler = None,
        uri = "/",
        host = None,
        methods = None,
        strict_slashes = None,
        version = None,
        name = None
    )



# Generated at 2022-06-26 03:54:06.634564
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # instantiate class object
    route_mixin = RouteMixin()
    # create a handler
    @route_mixin.route('/test1')
    def test_handler():
        pass

    route_mixin.add_route(test_handler, uri='/test1')
    # assert that route is registered
    assert len(route_mixin.routes) == 1
    # assert that filter is registered
    assert len(route_mixin.filter) == 1


# Generated at 2022-06-26 03:54:25.033381
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    assert isinstance(route_mixin_0.route, types.FunctionType)
    assert route_mixin_0.route.__qualname__ == "RouteMixin.route"


# Generated at 2022-06-26 03:54:33.210270
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    global file_or_directory_0
    file_or_directory_0 = "."
    global uri_0
    uri_0 = "/"
    global pattern_0
    pattern_0 = r"/?.+"
    global use_modified_since_0
    use_modified_since_0 = True
    global use_content_range_0
    use_content_range_0 = False
    global stream_large_files_0
    stream_large_files_0 = False
    global name_0
    name_0 = "static"
    global host_0
    host_0 = None
    global strict_slashes_0
    strict_slashes_0 = None
    global content_type_0
    content_type_0 = None
    global apply

# Generated at 2022-06-26 03:54:34.929418
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # case 0
    test_case_0()


# Generated at 2022-06-26 03:54:44.352813
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test')
    routes: List[Route] = []
    mixin = RouteMixin()
    mixin.app = app
    mixin.routes = routes
    func = lambda x,y : x+y
    app.add_route = lambda self, uri, host, methods, strict_slashes, version, name :func
    mixin.add_route('/home/',['GET','POST'])
    assert func('/home/','GET') == '/home/GET'
    assert func('/home/','POST') == '/home/POST'


# Generated at 2022-06-26 03:54:51.364732
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    methods = None
    uri = None
    host = None
    strict_slashes = None
    version = None
    name = None
    result_0 = route_mixin_0.route(methods=methods, uri=uri, host=host, strict_slashes=strict_slashes, version=version, name=name)
    assert "function" == type(result_0).__name__
    assert result_0.__name__ == "_decorator"
    
    
    
    

# Generated at 2022-06-26 03:54:59.413442
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # test case 0
    route_mixin_0 = RouteMixin()
    # assert len(list(route_mixin_0.routes.keys())) == 0
    route_mixin_0.add_route('/', 'GET', 'test_handler_0', 'test_name_0')
    assert len(list(route_mixin_0.routes.keys())) == 1


# Generated at 2022-06-26 03:55:04.372005
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(handler_0, uri_0)


# Generated at 2022-06-26 03:55:07.948694
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    # Call method route
    route_mixin_0.route()


# Generated at 2022-06-26 03:55:15.275126
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.response import html
    from unittest.mock import call

    def expected_HTTPResponse_1():
        return html("Hello")

    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(
        methods=None,
        uri="",
        host=None,
        version=None,
        name=None,
        strict_slashes=None,
        apply=None,
        stream=None,
        websocket=None,
    )(expected_HTTPResponse_1)
    # AssertionError: Expected call: add_route(methods=None, uri="", host=None, version=None, name=None, strict_slashes=None, apply=None, stream=None, websocket=None)(<function expected_HT

# Generated at 2022-06-26 03:55:25.680963
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    host = '127.0.0.1'
    strict_slashes = True

    headers = {'Host': host}
    data = 'Hello, world!'
    url = '/post'

    app = Sanic('test_RouteMixin_route')
    route_mixin_0 = RouteMixin()
    @route_mixin_0.route('/post', methods=('POST', ))
    def handler_post(request):
        return HTTPResponse(text='OK')

    request, response = app.test_client.post(url, data=data, headers=headers)

    assert response.text == 'OK'


# Generated at 2022-06-26 03:55:50.502445
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    request_handler_1 = RequestHandler()
    uri_1 = "/"
    host_1 = "host"
    methods_1 = ["methods"]
    strict_slashes_1 = True
    version_1 = "version"
    name_1 = "name"
    route_mixin_1.add_route(request_handler_1, uri_1, host_1, methods_1, strict_slashes_1, version_1, name_1)


# Generated at 2022-06-26 03:55:58.901913
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def add_route_handler(request):
        pass
    route_mixin_0.add_route(add_route_handler, '/users/{id}', 'get')
    assert route_mixin_0._routes[0].uri == '/users/{id}'


# Generated at 2022-06-26 03:56:11.701822
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # create a request
    request = Request(
        "POST",
        "/user/david.yonehara/",
        headers={
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 Gecko/20100101 Firefox/61.0",
        },
        body=b'{ "name": "David Yonehara", "age": 32, "email": "david.yonehara@example.com" }',
        version="1.0",
        protocol="HTTP/1.1",
        content_type=None,
        app=None,
        loop=None,
    )
    # create a route instance
    route_1 = RouteMixin()
    route_2 = RouteMixin()
    # create a test case:

# Generated at 2022-06-26 03:56:25.015751
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()

    @route_mixin_1.route("/test1", methods=["GET", "POST"])
    def handler(request):
        pass

    @route_mixin_1.route("/test2", methods=["GET", "POST"], host="www")
    def handler(request):
        pass

    @route_mixin_1.route("/test3", methods=["GET", "POST"], host="www", version=1)
    def handler(request):
        pass

    @route_mixin_1.route("/test4", methods=["GET", "POST"], strict_slashes=True)
    def handler(request):
        pass


# Generated at 2022-06-26 03:56:32.019971
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    app = Sanic()

    async def handler(request):
        return response.text('OK')

    app.add_route(handler, '/', 'GET')
    # use add_route
    sanic_request, sanic_response = app.test_client.get('/', route=True)
    assert sanic_response.text == 'OK'

    # use @app.route
    app.route('/', 'GET')(handler)
    sanic_request, sanic_response = app.test_client.get('/', route=True)
    assert sanic_response.text == 'OK'

    # use @app.post
    app.post('/', 'POST')(handler)
    sanic_request, sanic_response = app.test_client.post('/', route=True)
    assert sanic_

# Generated at 2022-06-26 03:56:44.000149
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    method_info_0 = route_mixin_0.route(uri='uri_0', host='host_0', methods='methods_0', strict_slashes='strict_slashes_0', version='version_0', name='name_0', apply='apply_0', websocket='websocket_0', subprotocols='subprotocols_0')
    method_info_1 = route_mixin_0.route(uri='uri_1', host='host_1', methods='methods_1', strict_slashes='strict_slashes_1', version='version_1', name='name_1', apply='apply_1', websocket='websocket_1', subprotocols='subprotocols_1')
    method_info_2 = route_mix

# Generated at 2022-06-26 03:56:47.852491
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route("test_case_0", "test_case_2", "test_case_5", "test_case_8")


# Generated at 2022-06-26 03:56:59.645235
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    async def async_handler_0(a, b, c):
        pass
    async def async_handler_1(a, b):
        pass
    route_mixin_0 = RouteMixin()
    route_mixin_0.methods = ['GET']
    route_mixin_0.pattern = re.compile('')
    route_mixin_0.host = None
    route_mixin_0.strict_slashes = None
    route_mixin_0.version = None
    route_mixin_0.name = None
    route_mixin_0.websocket = None
    route_mixin_0.stream = None
    route_mixin_0.handler_func = async_handler_0
    route_mixin_0.path = ''
    route_mixin_0.register

# Generated at 2022-06-26 03:57:10.889611
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()

    uri_2 = '/'
    host_2 = None
    methods_2 = None
    strict_slashes_2 = True
    version_2 = None
    name_2 = None
    handler_2 = None
    apply_2 = True

    method_return_2 = route_mixin_1.route(uri_2, host_2, methods_2,
                                          strict_slashes_2, version_2,
                                          name_2, apply_2)

    assert method_return_2[0] is not None, 'None'
    assert method_return_2[1] is not None, 'None'


# Generated at 2022-06-26 03:57:20.396093
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # print()

    # test_case = 0
    # test_case_0()

    print()

    app = Sanic()
    app.route("/", methods=["GET"])(lambda _: 0)

    @app.route("/")
    async def handler(request):
        return response.text("OK")

    assert len(app.router.routes_names) == 2
    assert "/" in app.router.routes_names
    assert "<lambda>-0" in app.router.routes_names

    print()


# Generated at 2022-06-26 03:57:53.599528
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    uri = "uri"
    file_or_directory = ["./TestDir/test_folder/test_file_0.txt", "./TestDir/test_folder/test_file_1.txt", "./TestDir/test_folder/test_file_2.txt", "./TestDir/test_folder/test_file_3.txt", "./TestDir/test_folder/test_file_4.txt", "./TestDir/test_folder/test_file_5.txt", "./TestDir/test_folder/test_file_6.txt", "./TestDir/test_folder/test_file_7.txt", "./TestDir/test_folder/test_file_8.txt", "./TestDir/test_folder/test_file_9.txt"]

# Generated at 2022-06-26 03:57:55.357283
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()

if __name__ == "__main__":
    test_RouteMixin_add_route()

# Generated at 2022-06-26 03:57:58.256525
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Call target function with each test case
    route_mixin_0 = RouteMixin()
    route_mixin_0.static("/static/swagger.json", "path/to/swagger.json")
    # TODO
    return True


# Generated at 2022-06-26 03:58:11.120241
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    expected_output_0 = 123
    handler_0 = (lambda request: expected_output_0)
    uri_0 = "/foo/"
    methods_0 = ["GET", "HEAD", "POST", "DELETE", "PUT", "OPTIONS", "PATCH", "TRACE"]
    host_0 = "0.0.0.0"
    strict_slashes_0 = False
    version_0 = 3
    name_0 = "foo"
    route = route_mixin_0.add_route(handler_0, uri_0, methods_0, host_0, strict_slashes_0, version_0, name_0)
    request = Request('GET', '/foo/')
    actual_output = route.handler(request)
    assert actual

# Generated at 2022-06-26 03:58:18.755148
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()

    # args for func route
    uri_1 = None
    host_1 = None
    methods_1 = None
    strict_slashes_1 = None
    version_1 = None
    name_1 = None
    apply_1 = None
    subprotocols_1 = None
    websocket_1 = None

    # test case for method route of class RouteMixin
    route_mixin_1_route_1 = route_mixin_1.route(uri_1, host_1, methods_1, strict_slashes_1, version_1, name_1, apply_1, subprotocols_1, websocket_1)
    # test case for method route of class RouteMixin
    route_mixin_1_route_2 = route_mixin_

# Generated at 2022-06-26 03:58:29.142486
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 0
    route_mixin_0 = RouteMixin()
    def method_0(self, uri, host, methods, strict_slashes, version, name, 
                 apply, subprotocols, websocket):
        if apply is True:
            if type(websocket) is bool:
                if websocket is False:
                    return None
                else:
                    return None
            else:
                return None
        else:
            return None
    decorated_method = route_mixin_0.route(uri=None, host=None, methods=None, 
                                           strict_slashes=None, version=None, 
                                           name=None, apply=True, 
                                           subprotocols=None, 
                                           websocket=True)
    assert decorated_method.__name__

# Generated at 2022-06-26 03:58:36.457059
# Unit test for method static of class RouteMixin

# Generated at 2022-06-26 03:58:38.621305
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(None, None)


# Generated at 2022-06-26 03:58:44.082808
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Init
    route_mixin = RouteMixin()
    args = (None, )
    args_list = []
    func_0 = lambda request : request
    args_list.append(args)
    args_list.append(args)
    handlers = []
    handlers.append(('func_0', func_0))
    handlers.append(('func_0', func_0))
    # Call function
    route_mixin.add_route(*args, **kwargs)
    # Get attributes
    # Check
    assert route_mixin._route_executor.handle == func_0
    assert route_mixin.handlers == handlers
    assert route_mixin.args_list == args_list


# Generated at 2022-06-26 03:58:55.131999
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    uri = "static"
    file_or_directory = "static"
    pattern = "static"
    use_modified_since = True
    use_content_range = True
    stream_large_files = True
    name = "static"
    host = "static"
    strict_slashes = "static"
    content_type = "static"
    apply = True
    route_mixin_0.static(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)

# Test of the method generate_name

# Generated at 2022-06-26 03:59:30.625858
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Setup
    _test_route_mixin = RouteMixin()
    _test_method = 'get'
    _test_uri = '/testuri'
    _test_handler = 'test_handler'
    _test_host = None
    _test_strict_slashes = None
    _test_stream = False
    _test_version = None
    _test_name = None
    _test_subdomain = None
    _test_dependency = None
    _result = None

    # Invoke

# Generated at 2022-06-26 03:59:32.907202
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()


# Generated at 2022-06-26 03:59:43.462079
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # host = "0.0.0.0"
    # uri = "http://0.0.0.0:8888/goto/hello?a=1&b=2"
    # methods = ["GET"]
    # strict_slashes = True
    # version = 1
    # name = "hello"
    # apply = True
    # route_mixin_0.add_route(host = host, uri = uri, methods = methods, strict_slashes = strict_slashes, version = version, name = name, apply = apply)

    # host = "0.0.0.0"
    # uri = "http://0.0.0.0:8888/goto/hello?a=1&b=2"
    # methods = ["

# Generated at 2022-06-26 03:59:57.092865
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    @route_mixin_0.get('/')
    async def handler(request):
        return response.html('')

    route = route_mixin_0._routes[0]
    assert_equal(route.methods, ["GET"])
    assert_equal(route.uri, "/")
    assert_equal(route.strict_slashes, False)
    assert_equal(route.host, None)
    assert_equal(route.version, None)
    assert_equal(route.name, None)
    assert_equal(route.websocket, False)
    assert_equal(route.stream, False)
    assert_equal(route.static, False)
    assert_equal(route.expect_handler, None)
    assert_equal(route.expect_ct_preload, False)



# Generated at 2022-06-26 04:00:06.039963
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('get', 'test_add_route')
    route_mixin_0.add_route('post', 'test_add_route')
    route_mixin_0.add_route('put', 'test_add_route')
    route_mixin_0.add_route('patch', 'test_add_route')
    route_mixin_0.add_route('options', 'test_add_route')
    route_mixin_0.add_route('head', 'test_add_route')
    route_mixin_0.add_route('trace', 'test_add_route')
    route_mixin_0.add_route('delete', 'test_add_route')
    route_mixin_0.add_

# Generated at 2022-06-26 04:00:16.077072
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    '''Test add_route method of the RouteMixin class'''
    route_mixin_0 = RouteMixin()

    if __debug__:
        route_mixin_0._app = Application()
        route_mixin_0.strict_slashes = None

    uri_0 = '/users/<username>'
    methods_0 = [
        'POST',
        'GET',
        'DELETE',
        'HEAD',
        'PUT'
    ]
    handler_0 = lambda *args:None
    host_0 = None
    strict_slashes_0 = None
    version_0 = None
    name_0 = 'users.username'

# Generated at 2022-06-26 04:00:26.814883
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    #
    # Create a new app instance which will be used for testing
    #
    app = Sanic("RouteMixin_add_route")
    #
    #
    #
    #
    #
    #
    # test case 1
    #
    #
    #
    #
    #
    #
    api_path = '/api/v1/test'
    handler = lambda request: HTTPResponse(body=b"OK")
    
    app.add_route(handler, api_path, methods=['GET'])
    
    assert app.router.routes_all['GET'][0].uri == api_path
    #
    #
    #
    #
    #
    #
    # test case 2
    #
    #
    #
    #
    #
    #

# Generated at 2022-06-26 04:00:34.240922
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    uri = str()
    handler = None
    methods = [object]
    host = str()
    strict_slashes = bool()
    version = int()
    name = str()
    route_mixin.add_route(uri, handler, methods, host, strict_slashes, version, name)
