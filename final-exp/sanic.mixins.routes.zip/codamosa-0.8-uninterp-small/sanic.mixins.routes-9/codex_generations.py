

# Generated at 2022-06-26 03:51:13.042206
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class_0 = RouteMixin()
    # root path should not be a regular expression
    assert_raises(TypeError, class_0.add_route, "/([new]+)")
    # host_pattern should be a regular expression
    assert_raises(TypeError, class_0.add_route, "/new", host_pattern="new")
    # Make sure not passing in both host and host_pattern results in a ValueError
    assert_raises(ValueError, class_0.add_route, "/new", host="new")
    # Make sure passing in host when host_pattern is None results in a ValueError
    assert_raises(ValueError, class_0.add_route, "/new", host="new", host_pattern=None)
    # Make sure passing in host_pattern when host is None results in a ValueError
    assert_

# Generated at 2022-06-26 03:51:21.168046
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    method_route_0 = RouteMixin()
    dict_0 = dict()
    dict_0['method'] = 'PUT'
    dict_1 = dict()
    dict_1['method'] = 'POST'
    dict_2 = dict()
    dict_2['name'] = 'get'
    dict_2['method'] = 'POST'
    dict_3 = dict()
    dict_3['name'] = 'get'
    dict_4 = dict()
    dict_4['name'] = '_default'
    dict_4['method'] = 'POST'
    dict_5 = dict()
    dict_5['name'] = 'get'
    dict_6 = dict()
    dict_6['name'] = 'get'
    dict_6['method'] = 'OPTIONS'
    dict_7 = dict()


# Generated at 2022-06-26 03:51:31.405738
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_var_1 = '%'
    str_var_2 = 'bH/'
    str_var_3 = '%o\tXN+'
    int_var_4 = 0
    str_var_5 = 'bH/'
    str_var_6 = '%o\tXN+'
    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_0.add_route(str_var_1, str_var_2, int_var_4, str_var_5)
    route_mixin_0.add_route(str_var_6)
    route_mixin_0.add_route()
    route_mixin_0.add_route(route_mixin_1)

# Unit test

# Generated at 2022-06-26 03:51:36.172744
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '%o\tXN+'
    route_mixin_0 = RouteMixin()
    test_case_0()


# Generated at 2022-06-26 03:51:46.663399
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '\nX\x11'
    str_1 = '\x11\n'
    module_0 = ModuleType('socketserver')
    setattr(module_0, 'RequestHandlerClass', BaseHTTPRequestHandler)
    module_0.RequestHandlerClass = BaseHTTPRequestHandler
    module_0.RequestHandlerClass.version_string = '\x11'
    event_loop_0 = new_event_loop()
    event_loop_0.run_until_complete(route_mixin_0.add_route((module_0.RequestHandlerClass.version_string, str_0), strict_slashes=True))
    event_loop_0.close()


# Generated at 2022-06-26 03:51:56.661645
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Initialize test case
    route_mixin_0 = RouteMixin()

    # Test with following arguments:
    #   uri - '"5W8bWS/L'
    #   methods - 'S"N'
    #   strict_slashes - '*\"dW'
    #   version - 'YJ=C'
    #   name - '&y9'
    #   apply - '+'
    #   websocket - '"j'
    #   stream - '7'
    #   strict_slashes - '"'
    #   subprotocols - 'O'
    #   url_prefix - 'XO$e'
    #   strict_slashes - 'H'
    #   name - 'r'
    #   subprotocols - '#<'
    #   apply -

# Generated at 2022-06-26 03:51:58.218610
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    test_0 = route_mixin_0.add_route('/', str_0)
    print(test_0)


# Generated at 2022-06-26 03:52:01.581377
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('', str_0)


# Generated at 2022-06-26 03:52:05.886958
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '%o\tXN+'
    route_mixin_0 = RouteMixin()
    method_0 = route_mixin_0.add_route
    method_0(str_0, '%o\tXN+')

if __name__ == '__main__':
    test_case_0()
    test_RouteMixin_add_route()

# %%

# Generated at 2022-06-26 03:52:11.413569
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '%o\tXN+'
    str_1 = 'm\x7f\x1c8\x0f`'
    str_2 = ':s'
    str_3 = '^'
    str_4 = '\x7f\x1c8\x0f`m'
    str_5 = '%'
    route_mixin_0 = RouteMixin()
    # Test case for attribute uri
    assert route_mixin_0.uri != str_5
    # Test case for attribute apply
    assert route_mixin_0.apply
    # Test case for attribute strict_slashes
    assert route_mixin_0.strict_slashes
    # Test case for attribute host
    assert route_mixin_0.host != str_2
    # Test case for

# Generated at 2022-06-26 03:52:35.722053
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for no param
    route_mixin_1 = RouteMixin()
    def func_a():
        pass

    decorator_a = route_mixin_1.route('/a')(func_a)
    assert decorator_a == func_a

    # Test for full param
    route_mixin_2 = RouteMixin()
    def func_b():
        pass

    decorator_b = route_mixin_2.route(
        host='127.0.0.1',
        uri='/path/to/func',
        methods=['GET', 'POST'],
        strict_slashes=True,
        version=1.1,
        name='func_name',
        apply=True,
    )(func_b)
    assert decorator_b == func_b


# Generated at 2022-06-26 03:52:37.979740
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO Need to be tested
    return


# Generated at 2022-06-26 03:52:49.444625
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()

    # check if an error occurs when calling method static with argument file_or_directory of value 1
    try:
        route_mixin_1.static("uri_0", 1)
    except ValueError:
        print("Successfully caught error.")
    else:
        print("Did not catch error.")

    # check if an error occurs when calling method static with argument file_or_directory of value True
    try:
        route_mixin_1.static("uri_1", True)
    except ValueError:
        print("Successfully caught error.")
    else:
        print("Did not catch error.")

    # check if an error occurs when calling method static with argument file_or_directory of value "str"

# Generated at 2022-06-26 03:52:53.734587
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    routes_0 = route_mixin_0.add_route(
        '"GET',
        "*hello?@world/"
    )


# Generated at 2022-06-26 03:52:58.472092
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(
        handler = '',
        uri = '',
        host = '',
        methods = [],
        strict_slashes = True,
        version = 1,
        name = '',
    )


# Generated at 2022-06-26 03:53:08.692491
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    # Test case 0
    route_mixin_1 = RouteMixin()
    @route_mixin_1.add_route('/test', methods=["GET"])
    def test_route():
        return 1

    assert route_mixin_1.routes[0].handler == test_route
    assert route_mixin_1.routes[0].uri == '/test'
    assert route_mixin_1.routes[0].methods == ["GET"]


# Generated at 2022-06-26 03:53:18.131344
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.app = "app"
    route_mixin_0.app.router = "router"
    route_mixin_0.app.router.add = "add"
    route_mixin_0.add_route(handler="handler", uri="uri")
    assert isinstance(route_mixin_0, RouteMixin)


# Generated at 2022-06-26 03:53:22.985346
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('/0/')
    assert (True)


# Generated at 2022-06-26 03:53:28.629954
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    import os
    import sys
    cur_abs_path = os.path.abspath(__file__)
    cur_dir_name = os.path.dirname(cur_abs_path)
    cur_dir_abs_path = os.path.abspath(os.path.join(cur_dir_name, '..'))
    sys.path.append(cur_dir_abs_path)
    import sanic
    from sanic.response import text

    route_mixin = RouteMixin()
    app = sanic.Sanic(__name__)
    route_mixin.static(app, "/sensor/static", os.path.join(cur_dir_abs_path, 'test'))

# Generated at 2022-06-26 03:53:42.737891
# Unit test for method route of class RouteMixin

# Generated at 2022-06-26 03:54:08.513085
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def handler_func(request):
        return request
    def handler_func_2(request):
        return request

    # Test 0
    route_mixin_0 = RouteMixin()
    uri = '/'
    host = None
    methods_ = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    result_0 = route_mixin_0.add_route(handler_func, uri=uri, host=host, methods=methods_, strict_slashes=strict_slashes, version=version, name=name, apply=apply)
    
    # Test 1
    route_mixin_1 = RouteMixin()
    uri = '/'
    host = None
    methods_ = None
    strict_slashes = None
    version = 1
    name

# Generated at 2022-06-26 03:54:15.715567
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    lambda_handler = lambda request: "Hello"
    route_0 = route_mixin_0.add_route(lambda_handler, uri='/', host=None,
                                      strict_slashes=None,
                                      name='sanic.route.lambda_handler',
                                      version=None)


# Generated at 2022-06-26 03:54:25.792849
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    mixed_route_0_0 = route_mixin_0.route(
        uri="",
        host=None,
        methods=None,
        strict_slashes=None,
        version=None,
        name=None,
        apply=True,
        subprotocols=None,
        websocket=False
    )
    print("mixed_route_0_0: ", mixed_route_0_0)



# Generated at 2022-06-26 03:54:31.374747
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def a():
        print("backend handler")

    mixin_obj = RouteMixin()
    mixin_obj.add_route("/", a, methods=["GET"], version=1, strict_slashes=True)
    return


# Generated at 2022-06-26 03:54:44.575837
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    @route_mixin_1.add_route("/", methods=["GET", "HEAD"])
    def handler_0():
        pass

    # TODO: the name argument is necessary, and is not optional.
    # You cannot pass None as the name in python.
    @route_mixin_1.add_route("/", methods=["GET", "HEAD"], name="name_0")
    def handler_1():
        pass

    @route_mixin_1.add_route("/", methods=["GET", "HEAD"])
    async def handler_2():
        pass

    @route_mixin_1.add_route("/", methods=["GET", "HEAD"])
    async def handler_3():
        pass


# Generated at 2022-06-26 03:54:47.599017
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(uri='/', methods=['GET'], name='sanic_root_route')


# Generated at 2022-06-26 03:54:55.998401
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route("__uri__", methods="__methods__", host="__host__", name="__name__", pattern="__pattern__", strict_slashes="__strict_slashes__", stream="__stream__", version="__version__")


# Generated at 2022-06-26 03:55:01.320966
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()

    route_mixin_0.static("/test", "test_file", pattern=r"/?.+", use_modified_since=True, use_content_range=False, stream_large_files=False, name=None, host=None, strict_slashes=None, content_type=None, apply=True)


# Generated at 2022-06-26 03:55:11.692312
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    st = FutureStatic(uri='/static/<file>', file_or_directory=b'/Users/zeeshan/Library/Containers/com.docker.docker/Data/docker.qcow2', pattern=r'/?.+', use_modified_since=True, use_content_range=False, stream_large_files=False, name='static', host=None, strict_slashes=None, content_type=None)
    route_mixin_0._register_static(st)

test_case_0()
test_RouteMixin_static()

# Generated at 2022-06-26 03:55:24.686358
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = 'uri_0'
    host_0 = 'host_0'
    methods_0 = 'methods_0'
    strict_slashes_0 = 'strict_slashes_0'
    version_0 = 'version_0'
    name_0 = 'name_0'
    apply_0 = 'apply_0'
    route_mixin_0.route(uri=uri_0, host=host_0, methods=methods_0, strict_slashes=strict_slashes_0, version=version_0, name=name_0, apply=apply_0)


# Generated at 2022-06-26 03:55:50.471119
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    logger.debug(
        "Testing Method: static of class RouteMixin..."
    )
    route_mixin = RouteMixin()

    file_or_directory = '/Users/wanyudong/Desktop/Sanic/examples/static'
    uri = '/static'
    route_mixin.static(
        uri,
        file_or_directory,
    )

    file_or_directory = '/Users/wanyudong/Desktop/Sanic/examples/static'
    uri = '/static'
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    route_mix

# Generated at 2022-06-26 03:56:05.697406
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Invoke function RouteMixin's add_route method
    route_mixin_1 = RouteMixin()
    uri = "ws://127.0.0.1:5000/websockets"
    method = "GET"
    handler = "handler"
    uri_for_handler = "uri_for_handler"
    host = ""
    strict_slashes = True
    version = "version"
    name = "name"
    route_0 = route_mixin_1.add_route(uri=uri,
                                      handler=handler,
                                      methods=method,
                                      uri_for_handler=uri_for_handler,
                                      host=host,
                                      strict_slashes=strict_slashes,
                                      version=version,
                                      name=name)


# Generated at 2022-06-26 03:56:18.448976
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.router import RouteExists

    uri = '/<name>'
    host = None
    methods = None # ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH']
    strict_slashes = None # False
    version = None # 1
    name = None # None
    apply = True # True

    route_mixin_obj = RouteMixin()

    print("Test 1")
    # Test values, that are not acceptable
    uri = None
    methods = ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH']
    handler = text("test")

# Generated at 2022-06-26 03:56:20.401980
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # case 0
    test_case_0()

    # No exception raised
    assert(True)


# Generated at 2022-06-26 03:56:24.992966
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    handler_1 = partial(print, "Hello, world!", end="\n")
    uri_1 = "/"
    host_1 = None
    strict_slashes_1 = None
    version_1 = None
    methods_1 = ["GET", "POST"]
    name_1 = None
    route_1, route_handler_1 = route_mixin_1.route(uri=uri_1,
        host=host_1,
        strict_slashes=strict_slashes_1,
        methods=methods_1,
        version=version_1,
        name=name_1)(handler_1)
    
    # Test if method add_route of class RouteMixin is called

# Generated at 2022-06-26 03:56:29.540908
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with 0 arguments
    route_mixin_0 = RouteMixin()
    handler = None

    with pytest.raises(TypeError):
        route_mixin_0.add_route(
            handler, uri=None, host=None, methods=None,
            strict_slashes=None, version=None, name=None
        )


# Generated at 2022-06-26 03:56:42.420607
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    root = Root()
    root._router = Router()
    root._router.routes = []

    root.add_route(
        handler=partial(
            root._request_handler,
            root._error_handler,
            root.default_error_handler,
            app=root,
        ),
        uri="/",
        host="127.0.0.1",
        methods=["GET"],
        strict_slashes=False,
        version="3.0",
        name="root",
    )

# Generated at 2022-06-26 03:56:56.192603
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    
    route_mixin_0 = RouteMixin()
    handler_0 = None
    uri_0 = "test"
    methods_0 = [
        "test",
        "test",
        "test",
        "test"
    ]
    version_0 = 1
    strict_slashes_0 = True
    name_0 = "test"
    host_0 = "test"
    register_0 = True
    route_mixin_0.add_route(
        handler_0,
        uri_0,
        methods=methods_0,
        version=version_0,
        strict_slashes=strict_slashes_0,
        name=name_0,
        host=host_0,
        register=register_0
    )
    route_mixin_0.add_route

# Generated at 2022-06-26 03:56:59.525937
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0_instance = RouteMixin()

    @route_mixin_0_instance.route("/index.html")
    async def handler(request):
        return text("Hello, world!")


# Generated at 2022-06-26 03:57:03.651748
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    uri = '/account'
    host = 'www.example.com'
    methods = ['GET','POST']
    strict_slashes = None
    version = '0.0.1'
    name = 'account'
    apply = True
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(uri, host, methods, strict_slashes, version, name, apply)


# Generated at 2022-06-26 03:57:28.587175
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a RouteMixin object
    route_mixin = RouteMixin()
    # Create the wrapped handler
    def handler(request):
        return web.json_response({'message': 'hello, world!'})

    # Create the route
    api_url = '/'
    api_method = 'get'
    route_mixin.add_route(handler, api_url, api_method)


# Generated at 2022-06-26 03:57:35.682488
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    func_0 = lambda: 0
    result_0 = route_mixin_0.route(uri='/', name='')(func_0)
    assert result_0 == func_0

if __name__ == "__main__":
    test_RouteMixin_route()

# Generated at 2022-06-26 03:57:44.322967
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """
    A helper method to register a function as a HTTP route and apply
    decorators to it.

    :param uri: path of the URL
    :param methods: List of acceptable HTTP methods, if not provided
                    it will be set to ["GET"].
    :param host: Host IP or FQDN details
    :param strict_slashes: If the API endpoint needs to terminate
                           with a "/" or not
    :param version: Version number in integer that will be prefixed to
                    the URL
    :param name: A unique name assigned to the URL so that it can
                 be used with :func:`url_for`
    :return: decorated function
    """

# Generated at 2022-06-26 03:57:52.870466
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('/test.html', route_mixin_0.test_handler)
    print(route_mixin_0.router.routes_all)
    assert (route_mixin_0.router.routes_all[0].uri == '/test.html')
    assert (route_mixin_0.router.routes_all[0].handler == route_mixin_0.test_handler)

# Generated at 2022-06-26 03:58:00.422679
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create an object of class RouteMixin
    route_mixin_1 = RouteMixin()

    # Create an object of class Route
    route = Route(
        "route_0",
        "GET",
        "route_0",
        "http",
        0,
        True,
        None,
        None,
        None,
        None,
    )

    # Add route to route_mixin_1
    new_route = route_mixin_1.add_route(
        route.method,
        route.uri,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        route.strict_slashes,
        None,
        None,
        None,
        None,
    )

    # Check if the two routes are the same


# Generated at 2022-06-26 03:58:13.699317
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 0
    route_mixin_0 = RouteMixin()
    handler_0 = ""
    uri_0 = "www.google.com"
    methods_0 = []
    host_0 = None
    strict_slashes_0 = None
    version_0 = None
    name_0 = None

# Generated at 2022-06-26 03:58:20.239130
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1=RouteMixin()
    path_1=None
    methods_1=None
    host_1=None
    strict_slashes_1=None
    version_1=None
    name_1=None
    route_mixin_1.add_route(path_1,methods_1,host_1,strict_slashes_1,version_1,name_1)


# Generated at 2022-06-26 03:58:30.084597
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()
    uri_5 = ""
    file_or_directory_0 = None
    pattern_0 = None
    use_modified_since_0 = None
    use_content_range_0 = None
    stream_large_files_0 = None
    name_0 = None
    host_0 = None
    strict_slashes_0 = None
    content_type_0 = None
    apply_0 = None

# Generated at 2022-06-26 03:58:37.048772
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    def test_case_1():
        route_mixin_1.route(
            uri='/',
            host=None,
            methods=None,
            strict_slashes=None,
            version=None,
            name=None,
            apply=True,
            websocket=False,
        )

    def test_case_2():
        route_mixin_1.route(
            uri='/',
            host=None,
            methods=None,
            strict_slashes=True,
            version=None,
            name=None,
            apply=True,
            websocket=False,
        )


# Generated at 2022-06-26 03:58:39.548870
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: Write unit test to test method route of class RouteMixin
    assert False


# Generated at 2022-06-26 03:59:30.741969
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    request = Request({})
    class handler_0:
        def __init__(self):
            self.request = request
        def route_handler_0(self):
            pass
    try:
        route_mixin_0.add_route(handler_0.route_handler_0, '/', None, None, None, None)
    except TypeError as e:
        assert str(e) != 'the four arguments must be of type str'


# Generated at 2022-06-26 03:59:35.066921
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 0
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri = "/", methods = ["GET", "HEAD"], name = "index")


# Generated at 2022-06-26 03:59:41.166408
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test')
    a = "a"
    b = "b"
    method = "POST"
    uri = "/"
    host = None
    strict_slashes = None
    version = None
    name = None
    route_mixin = RouteMixin(app)
    route_mixin.add_route(a, b, method, uri, host, strict_slashes, version, name)

# Generated at 2022-06-26 03:59:47.825131
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Create mock object to record call arguments
    instance     = Mock()
    instance_uri = Mock()
    instance_file_or_directory = Mock()
    instance_pattern = Mock()
    instance_use_modified_since = Mock()
    instance_use_content_range = Mock()
    instance_stream_large_files = Mock()
    instance_name = Mock()
    instance_host = Mock()
    instance_strict_slashes = Mock()
    instance_content_type = Mock()
    # Create mock object for method to test
    instance.static = route_mixin.RouteMixin.static
    # Perform test

# Generated at 2022-06-26 03:59:53.924143
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler_0(request, **kwargs):
        return HTTPResponse()
    
    assert route_mixin_0.add_route(handler=handler_0, uri='/', strict_slashes=True) == handler_0


# Generated at 2022-06-26 04:00:04.707368
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = lambda request: "return"
    request_0 = Request("GET", "/")
    default_name_0 = route_mixin_0._generate_name(handler_0)
    uri_0 = "/"
    methods_0 = ["GET"]
    strict_slashes_0 = True
    class_0 = route_mixin_0.add_route(handler_0, uri_0, methods_0, strict_slashes_0)
    assert(issubclass(class_0, Route))
    assert(class_0._strict_slashes == strict_slashes_0)
    assert(class_0._uri == uri_0)
    assert(class_0._methods == methods_0)

# Generated at 2022-06-26 04:00:08.305693
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """ Unit test for method add_route of class RouteMixin
    """
    print("method: add_route")
    # Test Case 0
    print("Test Case 0")
    test_case_0()


# Generated at 2022-06-26 04:00:13.362723
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    r0 = RouteMixin()
    r0.add_route(
        "GET",
        "/",
        callable,
        host=None,
        strict_slashes=None,
        stream=False,
        version=None,
        name=None
    )


# Generated at 2022-06-26 04:00:24.195682
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 0
    method_name = "test_RouteMixin_add_route"
    logger.info(f"Start test case: {method_name}")

    route_mixin_0 = RouteMixin()
    handler_0 = lambda x: print(x) # noqa
    uri_0 = "_"
    methods_0 = None
    host_0 = "_"
    strict_slashes_0 = None
    version_0 = 1
    name_0 = None
    route_mixin_0.add_route(handler_0, uri_0, methods_0, host_0, strict_slashes_0, version_0, name_0)

    logger.info(f"End test case: {method_name}")


# Generated at 2022-06-26 04:00:25.475282
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass
