

# Generated at 2022-06-26 03:51:21.248481
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    route_mixin_0 = RouteMixin()
    # case 0: test for decorator @route
    # case 0.0: test for static route
    @route_mixin_0.route('/')
    def handler(request):
        return json({'Hello': 'World'})
    print('Test route: '+str(handler))
    ret = route_mixin_0._routes['GET'][0]
    print('_routes[GET][0]: '+str(ret))
    # case 0.1: test for dynamic route
    @route_mixin_0.route('/user/<name>')
    def handler(request, name):
        return json({'hello': name})
    print('Test route: '+str(handler))

# Generated at 2022-06-26 03:51:31.483394
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # declare and create RouteMixin object
    route_mixin_1 = RouteMixin()
    # declare and create a handler
    def handler_routes_1(request):
        if request.method == 'POST':
            return json({"received": True, "message": request.json})
        else:
            return text("Hello")

    # declare and create a route
    route_1 = route_mixin_1.add_route(handler_routes_1, uri='/test', methods=['GET', 'POST'], host='172.16.0.1')
    # test that the uri is correctly set
    assert route_1.uri == '/test'
    # test that the method is correctly set
    assert route_1.methods == ['GET', 'POST']
    # test that the host is correctly set


# Generated at 2022-06-26 03:51:36.925401
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    class_0 = Sanic()
    route_mixin_0.add_route(class_0, '/', None)


# Generated at 2022-06-26 03:51:47.380627
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    app_0 = Sanic('sanic')
    handler_0 = print
    uri_0 = "/"
    methods_0 = ["GET", "POST"]
    strict_slashes_0 = False
    host_0 = "0.0.0.0"
    version_0 = 1
    name_0 = "test_RouteMixin_add_route"
    status_0 = None
    stream_0 = False
    route_0 = route_mixin_0.add_route(handler_0, uri_0, methods_0, strict_slashes_0, host_0, version_0, name_0, status_0, stream_0)

# Generated at 2022-06-26 03:51:56.887230
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    mock_uri = "mock_uri"
    mock_methods = "mock_methods"
    mock_host = "mock_host"
    mock_strict_slashes = "mock_strict_slashes"
    mock_name = "mock_name"
    mock_version = "mock_version"
    mock2_uri = "mock2_uri"
    mock2_methods = "mock2_methods"
    mock2_host = "mock2_host"
    mock2_strict_slashes = "mock2_strict_slashes"
    mock2_name = "mock2_name"
    mock2_version = "mock2_version"
    mock3_uri = "mock3_uri"

# Generated at 2022-06-26 03:52:05.947635
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Mockroute object
    route_0 = Route('/', None, None)

    # Mockup the RouteMixin object
    route_mixin_0 = RouteMixin()

    # Test case #1
    try:
        route_mixin_0.add_route(route_0)
        code = 0
    except Exception as e:
        print(e)
        code = 1
    assert code == 0

    # Test case #2
    try:
        route_mixin_0.add_route(route_0)
        code = 0
    except Exception as e:
        print(e)
        code = 1
    assert code == 0


# Generated at 2022-06-26 03:52:15.857915
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    uri = "signin/<username>"
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = None
    handler = None
    result_route_mixin_0 = RouteMixin()
    route_mixin_0 = RouteMixin()
    result_route_mixin_0.add_route(uri, host, methods, strict_slashes, version, name, apply, handler)
    if (result_route_mixin_0 != route_mixin_0):
        raise RuntimeError("test_RouteMixin_add_route failed")


# Generated at 2022-06-26 03:52:25.239224
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    # Testing route with default args
    route_mixin.route()

    # Test route with only uri
    route_mixin.route(uri='/url')

    # Test route with uri, method and strict_slashes
    route_mixin.route(uri='/url', methods=['POST'], strict_slashes=True)

    # Test route with uri, method, strict_slashes, version and name
    route_mixin.route(uri='/url', methods=['POST'], strict_slashes=True, version=1, name='route')


    # Test route with handler
    def handler(request):
        return


# Generated at 2022-06-26 03:52:36.945698
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic("test_strict_slashes")
    route_mixin_0 = RouteMixin(app)
    # First call of route
    # Case 1:
    uri_0 = "testing/<parameter>/<parameter_1>" # uri_0 -> "testing/<parameter>/<parameter_1>"
    methods_0 = ["GET", "HEAD"] # methods_0 -> ["GET", "HEAD"]
    strict_slashes_0 = True # strict_slashes_0 -> True
    name_0 = "route_mixin" # name_0 -> "route_mixin"
    @route_mixin_0.route(uri_0, methods_0, name_0, strict_slashes_0)
    async def handler(request):
        pass

# Generated at 2022-06-26 03:52:41.813091
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Init Mixin
    route_mixin_0 = RouteMixin()
    # Call method
    route_mixin_0.route(uri='/', methods=[], websocket=True)(lambda : "")


# Generated at 2022-06-26 03:52:56.579088
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_1 = route_mixin_1.add_route('/foo', lambda request : 'a')

    return route_1


# Generated at 2022-06-26 03:53:02.844824
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    # test for add_route with decorator
    @route_mixin_0.add_route
    def test_handler(request):
        pass


# Generated at 2022-06-26 03:53:19.703601
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    # Arrange
    route_mixin_1 = RouteMixin()

    # Act
    route_mixin_1.add_route('a', 'b', 'c')

    # Assert
    assert route_mixin_1 is not None

    # Arrange
    route_mixin_2 = RouteMixin()
    handler_2 = 3

    # Act
    route_mixin_2.add_route('a', 'b', 'c', handler=handler_2)

    # Assert
    assert route_mixin_2 is not None

    # Arrange
    route_mixin_3 = RouteMixin()

    # Act
    route_mixin_3.add_route('a', 'b', 'c', methods='d')

    # Assert
    assert route_mixin_3 is not None

    #

# Generated at 2022-06-26 03:53:26.093690
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    handler_0 = object()
    route_0 = route_mixin_0.route("/", methods=None, version=None, name=None, apply=None, strict_slashes=None, websocket=None, host=None, subprotocols=None)(handler_0)
    route_mixin_0.add_route(route_0, uri="/", methods=None, version=None, name=None, host=None, strict_slashes=None, subprotocols=None)
    route_1 = route_mixin_0.route("/", methods=None, version=None, name=None, apply=None, strict_slashes=None, websocket=None, host=None, subprotocols=None)(route_0)
    route_mixin_0

# Generated at 2022-06-26 03:53:29.498753
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(None, None)


# Generated at 2022-06-26 03:53:43.459027
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # test case 0
    route_mixin_0 = RouteMixin()
    route_mixin_0.static(uri="/",file_or_directory="./app/static/css/main.css",content_type="application/json",pattern=r"/a+")
    routes_0 = Route(uri="/",methods=["GET","HEAD"],strict_slashes=False,websocket=False,static=True,host=None,name="_static_.css",version=1)
    assert route_mixin_0._register_static(route_mixin_0._future_statics.pop()) == routes_0
    return

if __name__ == "__main__":
    test_case_0()
    test_RouteMixin_static()

# Generated at 2022-06-26 03:53:44.360761
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-26 03:53:45.187918
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_case_0()


# Generated at 2022-06-26 03:53:50.314693
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    handler = None
    uri = "/test/uri"
    methods = None
    host = None
    strict_slashes = None
    name = None
    version = None
    stream = None
    route_mixin_0 = RouteMixin()
    route = route_mixin_0.add_route(handler, uri, host, strict_slashes, name, version, stream)

# Entry point of the python script
if __name__ == "__main__":
    test_case_0()
    test_RouteMixin_add_route()

# Generated at 2022-06-26 03:53:57.441805
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()
    route_mixin_1.static(uri = '/', file_or_directory = '/home/gx/apitest', pattern = r"/?.+", use_modified_since = True, use_content_range = False, stream_large_files = False, name = 'asd', host = None, strict_slashes = None, content_type = None, apply = True)

# Generated at 2022-06-26 03:54:13.188297
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = 'uri'
    host = 'host'
    methods = ['method']
    strict_slashes = True
    version = 1
    name = 'name'
    apply = True
    subprotocols = 'subprotocols'
    handler = 'handler'
    route_mixin_0.route(uri, host, methods, strict_slashes, version, name, apply, subprotocols)(handler)


# Generated at 2022-06-26 03:54:19.225425
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for add_route
    route_mixin_1 = RouteMixin()
    d = dict(a = 1, b = 2)
    handler = lambda request, a, b, **kwargs : None

# Generated at 2022-06-26 03:54:26.926138
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()

    def handle_0(request, response, **kwargs):
        pass
    uri_0 = '/test'
    host_0 = '0.0.0.0'
    methods_0 = ['get', 'post']

    route_mixin_0.route(uri_0, host_0, methods_0)(handle_0)


# Generated at 2022-06-26 03:54:39.083614
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    uri = str()
    host = str()
    methods = None
    strict_slashes = None
    version = None
    name = str()
    handler = str()
    uri_2 = route_mixin_0.add_route(handler, uri, host, methods, strict_slashes, version, name)
    assert type(uri_2) == tp.Tuple
    assert len(uri_2) == 2
    assert type(uri_2[0]) == tp.List
    assert type(uri_2[1]) == tp.Any


# Generated at 2022-06-26 03:54:50.968656
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class App0(RouteMixin):
        def __init__(self):
            self.blueprints = set()
            self.host = None
            self.port = 8000
            self.error_handler = {}
            self.websocket_path = '/'
            self.version = 1
            self.auto_reload = False
            self.static_url_path = None
            self.static_folder = None
            self.static_hash_cache = False
            self.protocol = 'http'
            self.request_class = Request
            self.request_handler_class: RequestHandler = RequestHandler
            self.response_class = HTTPResponse
            self.route_middlewares = []
            self.rules = defaultdict(list)
            self.exception_handler = None
            self.default_exception_handler

# Generated at 2022-06-26 03:54:52.699439
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # 1
    pass


# Generated at 2022-06-26 03:55:03.395064
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    # The purpose of this test case is to verify RouteMixin.route.
    def _route_decorator_0(func):
        return func
    
    class _route_handler_0():
        pass
    _route_handler_0.name = "route_handler_0.name"

    class _route_handler_1():
        pass

    class _route_handler_2():
        pass

    # Test for normal operation
    def test_RouteMixin_route_0():
        # Instantiation and method invocation
        route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:55:07.651854
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    coro_0 =  asyncio.Coroutine

test_RouteMixin_add_route()


# Generated at 2022-06-26 03:55:11.616617
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route("/", 1)
    print(route_mixin_1.routes)
    assert route_mixin_1.routes[0].uri == "/"


# Generated at 2022-06-26 03:55:16.544165
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    views_0 = lambda request, name=None: 'sanic.response'
    route_mixin_0.route('/users/<id>', strict_slashes=False)(views_0)


# Generated at 2022-06-26 03:55:33.164414
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for case 1
    route_mixin_1 = RouteMixin()
    handler_1 = object()
    uri_1 = str()
    method_1 = list()
    host_1 = str()
    strict_slashes_1 = False
    version_1 = 1
    name_1 = str()
    expect_result_1 = Route(uri_1, handler_1, method_1, host_1, strict_slashes_1, version_1, name_1)
    output_route_mixin_1 = route_mixin_1.add_route(uri=uri_1, handler=handler_1, method=method_1, host=host_1, strict_slashes=strict_slashes_1, version=version_1, name=name_1)
    assert output_route_mixin_

# Generated at 2022-06-26 03:55:41.227799
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    # print(route_mixin_0.router.routes_all.items())
    #print(route_mixin_0.router.routes_all.items())
    #print(route_mixin_0.router.routes_all.items())
    #print(route_mixin_0.router.routes_all.items())

    method_0 = types.FunctionType(
        globals()["test_route_0"],
        globals()
    )
    #print(method_0)
    # print(method_0)
    # print(method_0)
    # print(method_0)
    # print(method_0)
    # print(method_0)
    #print(method_0)



# Generated at 2022-06-26 03:55:46.325725
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.name = "kwds"
    arg = route_mixin_0.route(uri="foo", host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True, websocket=True, subprotocols=None)
    assert(route_mixin_0.name == "kwds")


# Generated at 2022-06-26 03:56:01.128934
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:56:13.164287
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    request_handler_0 = RequestHandler(
        RequestHandler._default_handler,
        RequestHandler._default_handler
    )
    uri_0 = "/"
    uri_1 = ""
    uri_2 = "/home"
    uri_3 = "/home/"
    uri_4 = "home"
    uri_5 = "home/"
    uri_6 = "home/app"
    uri_7 = "home/app/"
    uri_8 = "/home/app"
    uri_9 = "/home/app/"
    uri_10 = "/home/app/hello"
    uri_11 = "/home/app/hello/"
    uri_12 = "home/app/hello"

# Generated at 2022-06-26 03:56:25.268597
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    uri_1 = 'https://github.com/'
    host_1 = '0.0.0.0'
    methods_1 = 'GET'
    strict_slashes_1 = False
    version_1 = None
    name_1 = 'test_case_1'
    apply_1 = True
    subprotocols_1 = None
    websocket_1 = False
    route, funct = route_mixin_1.route(uri_1, host_1, methods_1, strict_slashes_1, version_1, name_1, apply_1, subprotocols_1, websocket_1)


# Generated at 2022-06-26 03:56:37.352298
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    assert route_mixin_0.route("test_string_0", "test_string_1", "test_string_2", True, 3, "test_string_4", True, "test_string_6", "test_string_7", 5, True, "test_string_9")("test_function_0") == (3)
    assert route_mixin_0.route("test_string_0", "test_string_1", "test_string_2", True, 3, "test_string_4")("test_function_1") == (3)

# Generated at 2022-06-26 03:56:46.331014
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    def handler(request):
        return response.text("Hello World", 200)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route(handler, uri="/", strict_slashes=True)
    route_mixin_1.add_route

# Generated at 2022-06-26 03:56:58.490748
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    request_handler_0 = RequestHandler()
    view_function_0 = ViewFunction()
    request_handler_0.request = request_handler_0.request = request = Request()
    response_0 = route_mixin_0.add_route(request_handler_0, request, view_function_0)
    response_1 = route_mixin_0.add_route(request_handler_0, request, view_function_0)
    assert response_0.is_streamed == False
    assert response_1.is_streamed == False
    assert response_0.status_code == response_1.status_code
    assert response_0.status_code == 500
    assert response_0.body == b''
    assert response_1.body == b''

#

# Generated at 2022-06-26 03:57:00.223323
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    c = RouteMixin()
    c.add_route('/', 'h')


# Generated at 2022-06-26 03:57:20.545291
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
    Test whether route method can work properly
    """

    #create a instance of class Router
    route_mixin = RouteMixin()
    #test whether this method can work properly
    @route_mixin.route('/test',methods=['GET','POST'],strict_slashes=True)
    async def test_case(request):
        return 'Test successful'
    print('test_case_1')


# Generated at 2022-06-26 03:57:26.801250
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler = EchoHandler()
    route_mixin_0.add_route(handler, uri='/')
    assert route_mixin_0.routes[0].name == 'echo_handler'
    assert route_mixin_0.routes[0].handlers[0] == handler


# Generated at 2022-06-26 03:57:29.326141
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    def handler_0(request, *args, **kwargs):
        return 'OK'

    handler_0.__name__ = 'handler_0'
    route_0 = route_mixin_0.add_route('/', handler_0)



# Generated at 2022-06-26 03:57:35.468440
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri=None, host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True, subprotocols=None, websocket=False)


# Generated at 2022-06-26 03:57:43.001002
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Sanic injects manually a route_mixin to the Application object.
    # It serves the purpose of decoupling the implementation of the routes
    # from the Application object, so that other class could extend the
    # functionality of Sanic and still be able to add routes to the server.
    #
    # However, as we're rewriting sanic, we don't need this separation.
    # Thus, I'm commenting out this test case.
    # route_mixin_1 = RouteMixin()
    # route_mixin_1.static(uri='/static/', file_or_directory='./static_files/')
    return


# Generated at 2022-06-26 03:57:50.156948
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route('/competitions/<competition_id:int>', methods=['GET'], strict_slashes=False, version=None, host=None, name=None, apply=False)


# Generated at 2022-06-26 03:57:58.975774
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from functools import partial
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse

    # build a mock handler
    def handler_mock(request):
        return HTTPResponse(b"OK")

    route_mixin_1 = RouteMixin()
    route_mixin_1.error_handler.add(InvalidUsage, handler_mock)

    routes, _ = route_mixin_1.route('/test/', methods=None, strict_slashes=None, version=None, name=None,
    apply=True, status_code=None, stream=False, websocket=False)(handler_mock)

# Generated at 2022-06-26 03:58:02.703952
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    @route_mixin.add_route
    def my_route(req):
        pass

    @route_mixin.add_route("/my_route/")
    def my_route(req):
        pass


# Generated at 2022-06-26 03:58:11.699457
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_1 = object()
    uri_2 = 'share'
    methods_3 = ['GET']
    host_4 = 'stark'
    strict_slashes_5 = True
    version_6 = 1
    name_7 = 'name'
    route_mixin_0.add_route(handler_1,uri_2,methods_3,host_4,strict_slashes_5,version_6,name_7)


# Generated at 2022-06-26 03:58:14.679782
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    assert route_mixin_0.add_route(None, None, None, None, None) == None


# Generated at 2022-06-26 03:58:32.318872
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    @route_mixin_0.route('/')
    def handler(request):
        return text('OK')


# Generated at 2022-06-26 03:58:35.907354
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    assert route_mixin_0.add_route("/test_url/", None, None, None, None) == None

# Generated at 2022-06-26 03:58:38.115740
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('GET', '', '/')


# Generated at 2022-06-26 03:58:49.649214
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(sanic.request, uri="", )
    route_mixin_0.add_route(sanic.request, uri="", methods=["GET", "POST",], )
    route_mixin_0.add_route(sanic.request, uri="", methods=["GET", "POST",], strict_slashes=False, )
    route_mixin_0.add_route(sanic.request, uri="", methods=["GET", "POST",], strict_slashes=False, name="", )
    route_mixin_0.add_route(sanic.request, uri="", methods=["GET", "POST",], strict_slashes=False, name="", version=2, )
    route_mix

# Generated at 2022-06-26 03:58:57.452824
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    @get("/", host="www.sanic.com")
    async def handler():
        return Response("Hello world!")
    handler_0 = handler.__wrapped__
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(handler_0, "/", methods=["HEAD", "GET"], host="www.sanic.com", strict_slashes=True)
    assert route_mixin_0._routes[0].uri == "/"
    assert route_mixin_0._routes[0].host == "www.sanic.com"


# Generated at 2022-06-26 03:59:04.523032
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # method route
    route_mixin_0 = RouteMixin()
    uri = ""
    methods = None
    strict_slashes = None
    host = None
    version = None
    name = None
    apply = None
    return_value = route_mixin_0.route(uri, methods, strict_slashes, host, version, name, apply)
    print(return_value)


# Generated at 2022-06-26 03:59:08.327972
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    def handler():
        pass
    route_mixin_0.route("/test", methods=["GET", "HEAD"], version=1)(handler)


# Generated at 2022-06-26 03:59:10.182767
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    try:
        method = RouteMixin.route
        method = partial(RouteMixin.route, route_mixin_0)
        del method
    except:
        assert False
    assert True

# Generated at 2022-06-26 03:59:19.091694
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1: test add a route with method GET
    app_0 = Sanic('test_case_1')
    route_mixin_0 = RouteMixin()
    app_0.add_route = Mock()
    async def handler_0(request):
        return HTTPResponse(body=b'abc')

    route_mixin_0.add_route(app_0, handler_0, '/test', 'GET',
                            host=None,
                            uri_template=None,
                            strict_slashes=False,
                            stream=False,
                            version=None,
                            name='test',
                            methods=['POST'])

# Generated at 2022-06-26 03:59:20.336203
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case0
    route_mixin_0 = RouteMixin()



# Generated at 2022-06-26 03:59:43.232004
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    sanic_0 = Sanic('sanic_0')
    handler_0 = HTTPHandler()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_RouteMixin_add_websocket_route()
    test_RouteMixin_add_static()
    route_mixin_0.add_route(handler_0,'/index.htm',methods=['GET'],name='index',host=None,strict_slashes=None,version=None,apply=True,websocket=False)

# Generated at 2022-06-26 03:59:56.359297
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create instance of class RouteMixin
    route_mixin_0 = RouteMixin()
    # Bind method add_route with instance
    method_add_route = MethodType(RouteMixin.add_route, route_mixin_0)
    # Call method add_route

# Generated at 2022-06-26 04:00:05.711263
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def foo(request):
        print('Hi')
    def bar(request):
        print('World')

    router_0 = RouteMixin()
    router_0.add_route(foo, uri='/foo', methods=['GET'])
    actual_result_0 = router_0.routes_all[0]
    expect_result_0 = (foo, 'GET', frozenset({'GET'}), False, False, '', '', '/foo', '_sanic_route_0')
    assert expect_result_0 == actual_result_0
    router_0.add_route(bar, uri='/bar', methods=['GET'])
    actual_result_1 = router_0.routes_all[1]

# Generated at 2022-06-26 04:00:10.564346
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(handler=None, uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None)


# Generated at 2022-06-26 04:00:23.276152
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic(__name__)

    
    @app.route('/test')
    async def test(request):
        return 'test'

    # pass
    # route_mixin_0 = RouteMixin()
    # route_mixin_0.add_route(test, '/test')
    # assert(route_mixin_0.route_list[0].uri == '/test')
    # assert(route_mixin_0.route_list[0].handler == test)
    # print('passed test case 1')

    # fail: 1. pass in none handler
    # try:
    #     route_mixin_0 = RouteMixin()
    #     route_mixin_0.add_route(None, '/test')
    #     assert(1 == 0)
    # except AssertionError:

# Generated at 2022-06-26 04:00:28.366406
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app_0 = Sanic('sanic')
    result_0 = RouteMixin.route(
        app_0.router,
        uri='/',
        host=None,
        methods=None,
        strict_slashes=None,
        version=None,
        name=None,
        apply=True,
        subprotocols=None,
        websocket=False,
        handler=None,
    )


# Generated at 2022-06-26 04:00:35.270704
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Success
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('1', '2', 3)

    # Failure
    route_mixin_1 = RouteMixin()
    try:
        route_mixin_1.add_route('1')
    except TypeError:
        pass

    # Failure
    try:
        route_mixin_1.add_route('1', '2')
    except TypeError:
        pass
