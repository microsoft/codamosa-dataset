

# Generated at 2022-06-26 03:51:13.089265
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Initialize a RouteMixin object
    str_0 = 'Response Timeout'
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    # Call method add_route of object route_mixin_0
    str_1 = 'POST'
    str_2 = '/test_RouteMixin_add_route'
    str_3 = 'Response Timeout'
    dict_1 = {}
    str_4 = 'Response Timeout'
    dict_2 = {}
    route_mixin_1 = RouteMixin(**dict_2)
    route_mixin_1.route(uri=str_2, methods=str_1, name=str_4, **dict_1)
    # Test successful execution
    assert True



# Generated at 2022-06-26 03:51:14.844168
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    router_0 = RouteMixin()
    router_0.route('/index', 'GET', name='index')


# Generated at 2022-06-26 03:51:27.013224
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    set_0 = {''}
    method_0 = 'post'
    dict_1 = {"get" : 'get' , "post" : 'post'}
    tuple_0 = ('' , '')
    routes_0 = route_mixin_0.route(uri = '', methods = set_0, strict_slashes = False, version = 1, name = '', host = '', apply = True, )(dict_1.get(method_0))
    if (routes_0[0].methods == set_0):
        assert False

# Generated at 2022-06-26 03:51:32.434535
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'Response Timeout'
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)


# Generated at 2022-06-26 03:51:39.398741
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_1 = 'Response Timeout'
    dict_1 = {
        'version': 892456,
        'methods_0': [
            'GET',
            'HEAD',
            'POST',
            'OPTIONS',
            'PUT',
            'DELETE',
            'CONNECT',
            'TRACE',
            'PATCH',
            'LINK',
            'UNLINK'],
        'version_0': 892456,
        'methods': [
            'GET',
            'HEAD',
            'POST',
            'OPTIONS',
            'PUT',
            'DELETE',
            'CONNECT',
            'TRACE',
            'PATCH',
            'LINK',
            'UNLINK']}
    int_0 = 7360
    route_mixin

# Generated at 2022-06-26 03:51:54.083070
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    str_0 = 'Response Timeout'
    str_1 = 'path='
    str_2 = 'relative_url='
    str_3 = '.'
    str_4 = '.'
    str_5 = '.'
    str_6 = '.'
    str_7 = '.'
    str_8 = '.'
    str_9 = '.'
    str_10 = '.'
    str_11 = '.'
    str_12 = '.'
    str_13 = '.'
    str_14 = '.'
    str_15 = 'Invalid URL'
    str_16 = 'File not found'

# Generated at 2022-06-26 03:52:05.791747
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-26 03:52:17.071744
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class Response:
        pass
    class Request:
        pass
    class Sanic:
        pass
    class wrapped_function:
        pass
    dict_0 = {}
    class request:
        pass
    request_0 = request()
    request_0.__module__ = 'module_0'
    str_0 = 'module_0'
    request_0.__module__ = str_0
    dict_1 = {}
    dict_1['request'] = request_0
    dict_2 = {}
    dict_2['sanic'] = dict_1
    dict_3 = {}
    dict_3['tracker'] = dict_2
    dict_0['args'] = dict_3
    dict_0['function'] = wrapped_function
    dict_0['options'] = dict_0
    dict_0['uri']

# Generated at 2022-06-26 03:52:19.511834
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def method_0():
        # Invoke method 1
        print('Invoke method 1')
        return
    # Invoke method 1
    method_0()
    # Invoke method 2
    print('Invoke method 2')
    return


# Generated at 2022-06-26 03:52:28.261340
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'Response Timeout'
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    url_0 = '/user/<username>'
    route_mixin_0.add_route(url_0, 'GET')


# Generated at 2022-06-26 03:52:51.250144
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    try:
        assert False
        # assert test_case_0() == 'Success'
    except AssertionError:
        print('AssertionError raised')
    else:
        print('Success')



# Generated at 2022-06-26 03:52:59.521143
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
    Test method route of class RouteMixin
    """
    # Create an instance of the RouteMixin class
    route_mixin_0 = RouteMixin()

    # Create an instance of the Sanic class
    sanic_0 = Sanic('sanic_0')

    # Create an instance of the Signal class
    signal_0 = Signal()

    # Create an instance of the Type class
    type_0 = Type('unicode_0', 0, 0)

    # Create an instance of the Type class
    type_1 = Type('unicode_0', 0, 0)

    # Create an instance of the Type class
    type_2 = Type('unicode_0', 0, 0)

    # Create an instance of the Type class
    type_3 = Type('unicode_0', 0, 0)

    # Create an instance of

# Generated at 2022-06-26 03:53:03.245111
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = 'Invoke method 0'
    var_0 = print(str_0)


# Generated at 2022-06-26 03:53:06.815962
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-26 03:53:20.483897
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    # Create an instance of RouteMixin
    route_mixin_0 = RouteMixin()
    assert isinstance(route_mixin_0, RouteMixin)

    # Create a mock object for the handler
    handler_0 = Mock()

    # Call add_route on the mock object
    route_mixin_0.add_route(handler_0, 'uri_0')

    # Call the mock_calls function on the mock handler object
    # This returns a list of mock calls made to the mock handler object
    mock_calls_0 = handler_0.mock_calls

    # Check the length of the list of mock calls
    # The length should be 3. The reason for this is as follows:
    # 1. call of the sanic_main.route method on the mock object
    # 2. call of the sanic_main

# Generated at 2022-06-26 03:53:23.448623
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    # Your code here
    route_mixin.add_route()


# Generated at 2022-06-26 03:53:25.448904
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = 'Invoke method 1'
    var_0 = print(str_0)
    str_1 = 'Invoke method 2'
    var_1 = print(str_1)


# Generated at 2022-06-26 03:53:30.799317
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """
    Unit test for method add_route of class RouteMixin
    """
    # Create a new instance of class RouteMixin
    obj_0 = RouteMixin()
    # Call the method add_route of class RouteMixin
    obj_0.add_route('0')
    test_case_0()


# Generated at 2022-06-26 03:53:41.793414
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    routeMixin = RouteMixin()
    handler = "hello"
    uri = "/"
    methods = None
    host = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    var_0 = routeMixin.route(handler=handler, uri=uri, host=host, methods=methods, strict_slashes=strict_slashes, version=version, name=name, apply=apply)
    str_0 = 'Invoke method 2'
    print(str_0)


# Generated at 2022-06-26 03:53:47.141446
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Instantiate
    obj_0 = RouteMixin()
    # TODO: Test this out some more
    assert obj_0 is not None


# Generated at 2022-06-26 03:54:08.778098
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)

    # Test error 1
    # Test TypeError raised
    try:
        route_mixin_0.add_route()
    except TypeError:
        pass
    else:
        raise AssertionError()

    # Test error 2
    # Test TypeError raised
    try:
        route_mixin_0.add_route(None)
    except TypeError:
        pass
    else:
        raise AssertionError()

    # Test error 3
    # Test TypeError raised
    try:
        route_mixin_0.add_route(None, None)
    except TypeError:
        pass
    else:
        raise AssertionError()

    # Test error 4
    # Test TypeError raised

# Generated at 2022-06-26 03:54:19.493420
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {'name': '__main__.Sanic'}
    route_mixin_0 = RouteMixin(**dict_0)
    dict_1 = {}
    route_mixin_1 = RouteMixin(**dict_1)
    dict_2 = {'host': '0.0.0.0', 'port': '8000', 'debug': False}
    sanic_0 = Sanic(**dict_2)
    sanic_0.blueprint(route_mixin_1)
    dict_3 = {'host': '10.21.136.225', 'port': '8000', 'debug': True}
    sanic_1 = Sanic(**dict_3)
    sanic_1.blueprint(route_mixin_0)

# Generated at 2022-06-26 03:54:27.775395
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    handler = Handler()
    uri = 'URITEST'
    method = 'GET'
    host = 'URLTEST'
    strict_slashes = True
    version = 0
    name = 'NAMETEST'
    route_mixin_0.add_route(handler, uri, method, host, strict_slashes, version, name)


# Generated at 2022-06-26 03:54:35.275352
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    # TODO: What should be the expected value ??
    expected_value = None
    # When
    actual_value = route_mixin_0.route
    # Then
    assert actual_value == expected_value


# Generated at 2022-06-26 03:54:46.973870
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {
        'resolver': DefaultResolver(),
        'strict_slashes': None,
        'name': None,
        'host': None,
        'version': None,
    }
    route_mixin_0 = RouteMixin(**dict_0)
    def func_0():
        return None
    dict_1 = {
        'methods': None,
        'uri': '',
        'apply': True,
        'websocket': False,
        'subprotocols': None,
        'strict_slashes': None,
        'name': None,
        'host': None,
    }
    tuple_0 = route_mixin_0.route(**dict_1)(func_0)
    if __name__ == '__main__':
        test_case_0

# Generated at 2022-06-26 03:54:57.938258
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {
        "host": "",
        "methods": [],
        "name": "",
        "strict_slashes": "",
        "subdomain": "",
        "uri": "",
        "version": 0,
    }
    route_mixin_0 = RouteMixin(**dict_0)

    function_0 = function(function_0)
    route_mixin_0.add_route(function_0)



# Generated at 2022-06-26 03:55:04.775696
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    route_mixin_0.add_route(None, None)
    # This method takes at least 2 arguments (4 given)
    # TypeError: add_route() takes at least 2 arguments (4 given)
    route_mixin_0.add_route(None, None, None, None)
    # This method takes at least 2 arguments (5 given)
    # TypeError: add_route() takes at least 2 arguments (5 given)
    route_mixin_0.add_route(None, None, None, None, None)
    # This method takes at least 2 arguments (6 given)
    # TypeError: add_route() takes at least 2 arguments (6 given)

# Generated at 2022-06-26 03:55:07.800933
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)


# Generated at 2022-06-26 03:55:11.063516
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    handler = getattr(route_mixin_0, "add_route")
    handler()


# Generated at 2022-06-26 03:55:25.824618
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    dict_0 = {}
    dict_1 = {}
    dict_1['uri'] = "/static"
    dict_1['file_or_directory'] = "static"
    dict_1['pattern'] = r"/?.+"
    dict_1['use_modified_since'] = True
    dict_1['use_content_range'] = False
    dict_1['stream_large_files'] = False
    dict_1['name'] = "static"
    dict_1['host'] = None
    dict_1['strict_slashes'] = None
    dict_1['content_type'] = None
    dict_1['apply'] = True
    dict_2 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    route_mixin_1 = RouteMixin(**dict_0)

# Generated at 2022-06-26 03:56:13.865617
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    method_list = []
    host_list = []
    strict_slashes_list = []
    version_list = []
    name_list = []
    apply_list = []
    for method in method_list:
        for host in host_list:
            for strict_slashes in strict_slashes_list:
                for version in version_list:
                    for name in name_list:
                        for apply in apply_list:
                            route_mixin_0 = RouteMixin(**dict_0)
                            dict_0.update({"method": method})
                            dict_0.update({"host": host})
                            dict_0.update({"strict_slashes": strict_slashes})
                            dict_0.update({"version": version})
                            dict_0

# Generated at 2022-06-26 03:56:27.065333
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    uri_0 = None
    host_0 = None
    methods_0 = None
    strict_slashes_0 = None
    version_0 = None
    name_0 = None
    apply_0 = None
    subprotocols_0 = None
    websocket_0 = None
    int_0 = route_mixin_0.route(uri=uri_0, host=host_0, methods=methods_0, strict_slashes=strict_slashes_0, version=version_0, name=name_0, apply=apply_0, subprotocols=subprotocols_0, websocket=websocket_0)
    assert int_0 is None


# Generated at 2022-06-26 03:56:31.250713
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case for method RouteMixin.add_route
    r = RouteMixin()
    r.add_route(uri = '/', host = None, methods = ['GET'], strict_slashes = None, version = None, name = None, apply = True)

# Generated at 2022-06-26 03:56:39.246277
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_1 = {}
    route_mixin_1 = RouteMixin(**dict_1)
    dict_3 = {}
    route_mixin_3 = RouteMixin(**dict_3)
    dict_4 = {}
    route_mixin_4 = RouteMixin(**dict_4)
    dict_5 = {}
    route_mixin_5 = RouteMixin(**dict_5)


# Generated at 2022-06-26 03:56:41.329847
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)


# Generated at 2022-06-26 03:56:47.994153
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    dict_1 = {}
    class_0 = route_mixin_0.route("uri_0", **dict_1)
    class_0 = partial(class_0)
    class_0("host_0")
    class_0("host_0", "strict_slashes_0")
    class_0("host_0", "strict_slashes_0", "version_0")
    class_0("host_0", "strict_slashes_0", "version_0", "name_0")
    class_0("host_0", "strict_slashes_0", "version_0", "name_0", False)

# Generated at 2022-06-26 03:56:56.759913
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)

    # Check if it is an instance of expected class
    assert (isinstance(route_mixin_0.add_route("/test/route"), types.FunctionType))
    # Check if it raises on an exception
    import exceptions
    try:
        route_mixin_0.add_route()
    except exceptions.ValueError as exc0:
        pass
    else:
        assert False, "Should be an Exception"


# Generated at 2022-06-26 03:56:59.606627
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    list_0 = ['foo']
    route_mixin_0.route(methods=list_0)


# Generated at 2022-06-26 03:57:02.921546
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app_0 = Sanic('test')
    str_literal_0 = ''
    route_mixin_0 = RouteMixin(app_0)
    def handler_0(request):
        pass

    route_mixin_0.add_route(str_literal_0, handler_0)


# Generated at 2022-06-26 03:57:07.864996
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    route_mixin_0.add_route(None, None, None, None, None, None, None)


# Generated at 2022-06-26 03:58:37.047784
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {'router': Router(registry={})}
    dict_0['router'].routes = {}
    route_mixin_0 = RouteMixin(**dict_0)
    str_0 = 'GET'
    str_1 = 'uri'
    dict_1 = {}
    dict_2 = {}
    dict_2['uri'] = str_1
    dict_2['methods'] = [str_0]
    dict_2['strict_slashes'] = False
    dict_2['host'] = None
    dict_2['name'] = None
    dict_2['version'] = None
    dict_2['apply'] = True
    dict_2['websocket'] = False
    dict_2['subprotocols'] = None
    route_0 = route_mixin_

# Generated at 2022-06-26 03:58:38.536626
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 03:58:40.600429
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()

if __name__ == '__main__':
    test_RouteMixin_add_route()

# Generated at 2022-06-26 03:58:45.447497
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    dict_1 = {}
    @route_mixin_0.route(**dict_1)
    def route_0( **dict_2):
        print(__name__)



# Generated at 2022-06-26 03:58:49.534286
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
   dict_0 = {}
   route_mixin_0 = RouteMixin(**dict_0)
   route_0 = route_mixin_0.route(**dict_0)



# Generated at 2022-06-26 03:58:58.739250
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_RouteMixin_route.counter += 1
    dict_0 = {'strict_slashes': True, 'name': 'sanic.router.Route_'+str(test_RouteMixin_route.counter), 'version': 1, 'uri': '/xyz'}
    route_mixin_0 = RouteMixin(**dict_0)
    dict_1 = {'strict_slashes': True, 'name': str(test_RouteMixin_route.counter), 'version': 1, 'uri': '/xyz'}
    route_0 = route_mixin_0.route(**dict_1)
    dict_2 = {'strict_slashes': True, 'name': None, 'version': 1, 'uri': '/xyz'}

# Generated at 2022-06-26 03:59:04.478205
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    dict_0 = {}
    uri_0 = ""
    handler_0 = None
    route_mixin_0 = RouteMixin(**dict_0)
    route_0 = Route(**dict_0)
    assert route_mixin_0.add_route(
        uri_0,
        handler_0,
    ) == route_0


# Generated at 2022-06-26 03:59:15.260603
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    from sanic.router import Route
    
    mock_route_0 = Route(**{})
    mock_route_1 = Route(**{})
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)

    # Test branch 1
    with pytest.raises(ValueError):
        route_mixin_0.add_route('uri_0', 'handler_0', methods = ["get"])

    # Test branch 2
    with pytest.raises(ValueError):
        route_mixin_0.add_route('uri_0', 'handler_0', host = "host_0")

    # Test branch 3

# Generated at 2022-06-26 03:59:18.794910
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Instantiate RouteMixin object
    mem_0 = RouteMixin()
    # Call method add_route
    mem_0.add_route(uri="/foo", handler=None, methods=None, host=None,
        strict_slashes=None, version=None, name=None)


# Generated at 2022-06-26 03:59:30.742682
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    dict_0 = {}
    route_mixin_0 = RouteMixin(**dict_0)
    function_0 = lambda :None
    function_1 = lambda :None
    function_2 = lambda :None
    function_3 = lambda :None
    function_4 = lambda :None
    routes_1 = route_mixin_0.route(uri = "9OgIy", host = "GjYuL", methods = None, strict_slashes = None, version = None, name = "8yvFu", apply = True, subprotocols = None, websocket = True)