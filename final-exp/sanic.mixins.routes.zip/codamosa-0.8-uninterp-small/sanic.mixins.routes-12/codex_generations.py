

# Generated at 2022-06-26 03:50:58.955720
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_1 = 'c(c \x0c7TM4'
    str_2 = 'c(c \x0c7TM4'
    str_3 = 'c(c \x0c7TM4'
    float_2 = -2449.39
    str_4 = 'c(c \x0c7TM4'
    str_5 = 'c(c \x0c7TM4'
    str_6 = 'c(c \x0c7TM4'
    route_mixin_1 = RouteMixin()
    var_1 = route_mixin_1.route(str_1, str_2, str_3, float_2, str_4, str_5, str_6)


# Generated at 2022-06-26 03:51:02.535971
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'M:'.encode('utf-8')
    int_0 = -1968427005
    var_0 = route_mixin_0.add_route(str_0, int_0, False, False)


# Generated at 2022-06-26 03:51:12.924518
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    str_0 = 'c(c \x0c7TM4'
    str_1 = 'c(c \x0c7TM4'
    bool_0 = False
    bool_1 = True
    long_0 = -26053
    str_2 = 'c(c \x0c7TM4'
    bool_2 = True
    bool_3 = False
    route_mixin_0 = RouteMixin()
    route_mixin_0.static(str_0, str_2, str_0, str_1, bool_3, str_1, str_1, bool_0, bool_2)


# Generated at 2022-06-26 03:51:17.350245
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    func_0 = lambda : None
    str_0 = 'L\xd6\x9f\x8b\xcd'
    str_1 = 'L\xd6\x9f\x8b\xcd'
    assert route_mixin_0.add_route(func_0, str_0, str_1) == ()



# Generated at 2022-06-26 03:51:20.024776
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'c(c \x0c7TM4'
    float_0 = -2449.39
    route_mixin_0 = RouteMixin()
    var_0 = route_mixin_0.add_route(str_0, float_0, str_0)


# Generated at 2022-06-26 03:51:21.951560
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    pass


# Generated at 2022-06-26 03:51:28.229672
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '^!Xh\x1c'
    float_0 = -1893.816
    str_1 = '7^*\x1a'
    int_0 = route_mixin_0.add_route(str_0, float_0, str_1)
    print(int_0)


# Generated at 2022-06-26 03:51:35.783176
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '"2+'
    float_0 = -1110.31
    float_1 = float_0
    route_mixin_0 = RouteMixin()
    var_1 = route_mixin_0.route(str_0, float_0, float_1)


# Generated at 2022-06-26 03:51:37.840433
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # WARNING: This test case not yet created
    assert True
    # Init arguments
    
    # Init Parameter
    
    # Call method
    # WARNING: This method not yet tested


# Generated at 2022-06-26 03:51:40.691024
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'c(c \x0c7TM4'
    float_0 = -2449.39
    route_mixin_0 = RouteMixin()
    var_0 = route_mixin_0.head(str_0, float_0, str_0)
    return var_0


# Generated at 2022-06-26 03:52:04.411341
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    assert isinstance(var_0[0], list)
    assert isinstance(var_0[1], function)


# Generated at 2022-06-26 03:52:16.478446
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    str_0 = '=Ü\x05\x16\x01\x0c\x02\x11\x0b\x0c\x1e+\x1c\x05\x0e'
    str_1 = '\x13\x17\x1c\x1a\x1e\x1d\x08\x0f\x04\x06\x02\x1a\x1f\x0f\x06\x1f\x0b\x15\x12\x1e!\x0e\x14\x02'

# Generated at 2022-06-26 03:52:22.915631
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '9òÛd'
    str_1 = '\x02Æ\x1a\x1f'
    str_2 = 'í'
    var_0 = route_mixin_0.add_route(str_0, str_1, str_2)


# Generated at 2022-06-26 03:52:28.796502
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = str_0
    str_2 = str_1
    var_0 = route_mixin_0.add_route(str_0, str_1, str_2)


# Generated at 2022-06-26 03:52:36.037512
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = 'LÖ\x9f\x8bÍ'
    str_2 = 'LÖ\x9f\x8bÍ'
    route_mixin_0.route(str_0, str_1, str_2)

# testcase for testing add_route

# Generated at 2022-06-26 03:52:48.322284
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    routes = {}
    route_mixin_0 = RouteMixin()
    str_0 = '$Ý\x10\x18\x1a\x9c\x08\x10\x18\x1a\x9c\x08'
    var_0 = route_mixin_0.route(str_0, str_0, str_0, str_0, str_0)
    routes[0] = (var_0, str_0)
    str_1 = ')>\x02\x0b'
    var_1 = route_mixin_0.route(str_1, str_1, str_1, str_1, str_1)
    routes[1] = (var_1, str_1)

# Generated at 2022-06-26 03:52:51.250035
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with arguments test_1.txt, test_2.txt and test_3.txt
    test_case_0()

# Generated at 2022-06-26 03:53:00.927175
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


test_case_0()

str_0 = 'LÖ\x9f\x8bÍ'
int_0 = 0
int_1 = 1
float_0 = 1.0
route_mixin_0 = RouteMixin()
route_mixin_0.add_route(str_0, str_0, str_0)
route_mixin_1 = RouteMixin()
route_mixin_1.add_route(str_0, str_0, str_0)

# Generated at 2022-06-26 03:53:08.523153
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert "{}{}{}".format("LÖ\x9f\x8bÍ", "LÖ\x9f\x8bÍ", "LÖ\x9f\x8bÍ") == "{}{}{}".format("LÖ\x9f\x8bÍ", "LÖ\x9f\x8bÍ", "LÖ\x9f\x8bÍ")


# Generated at 2022-06-26 03:53:14.971895
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("\n\n== Test case for testing add_route of class RouteMixin ==")
    route_mixin_1 = RouteMixin()
    print("\n\n== Test case 0 ==")
    test_case_0()


# Generated at 2022-06-26 03:53:37.888795
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    str = 'LÖ\x9f\x8bÍ'
    var = route_mixin.add_route(str, str, str)
    print(var)


# Generated at 2022-06-26 03:53:38.822221
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()


# Generated at 2022-06-26 03:53:42.133150
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    int_0 = random.randint(0, 25)
    str_0 = 'hÀùÿÆzZ'
    # Call route
    route_mixin_0.route(bool(int_0), str_0)


# Generated at 2022-06-26 03:53:50.301941
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # String Assignments
    str_0 = 'LÖ\x9f\x8bÍ'
    route_mixin_0 = RouteMixin()
    route_mixin_0.static(str_0, str_0, str_0, True, True, True, str_0, str_0, True)


# Generated at 2022-06-26 03:53:54.128865
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    route_mixin_0.static('\x19\x0b\x1d', '\x19\x0b\x1d')

if __name__ == '__main__':
    test_RouteMixin_static()

# Generated at 2022-06-26 03:54:02.870583
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    int_0 = 1000
    var_0 = route_mixin_0.route(str_0, str_0, str_0, int_0, str_0)
    print(var_0)


# Generated at 2022-06-26 03:54:06.687623
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    # Create an instance of RouteMixin
    route_mixin_0 = RouteMixin()
    # Fetch the route with the endpoint of 'LÖ\x9f\x8bÍ'
    route_0 = route_mixin_0.router.get('LÖ\x9f\x8bÍ')


# Generated at 2022-06-26 03:54:14.716497
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'P'
    str_1 = ':'
    str_2 = 'v5'
    str_3 = 'P'
    str_4 = ':'
    str_5 = ':v5'
    str_6 = 'P'
    str_7 = ':'
    str_8 = ':v5'
    var_0 = route_mixin_0.add_route(str_0, str_1, str_2)
    route_mixin_0 = RouteMixin()
    var_1 = route_mixin_0.add_route(str_3, str_4, str_5)
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:54:23.195527
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    str_1 = 'LÖ\x9f\x8bÍ'
    var_1 = route_mixin_1.add_route(str_1, str_1, str_1)
    assert isinstance(var_1, [].__class__)


# Generated at 2022-06-26 03:54:32.588140
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    print(route_mixin_0)
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = None

# Generated at 2022-06-26 03:55:02.989027
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    args_0 = [str_0]
    args_1 = [str_0, str_0]
    kwargs_0 = {str_0:str_0, str_1:str_0}
    return_value_0 = route_mixin_0.route(*args_0, **kwargs_0)
    def func_0():
        return None
    args_2 = []
    kwargs_1 = {str_0:bool_0}
    return_value_1 = func_0(*args_2, **kwargs_1)
    str_2 = str_0
    return_value_2 = route_mixin_0.add_route(str_2, return_value_1, str_0)
    str_3 = str_0


# Generated at 2022-06-26 03:55:13.829661
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'r\x0b\x1f5\n\x14\x07\x11\x1c\x1c\x1d\x17g\x0f\x1bj\x0b\x04\x1b\x1b\x1c\x0f\x14\x07\x1f\x0c\x0e\x17\x05\x0e'
    str_1 = '3\x12H\x1cW\x10\x0f'
    str_2 = 'w\x1c\x0c\x06'
    str_3 = '\x0b\x0dm\x14\r\x1d\x0f\x1c\\\x0b'

# Generated at 2022-06-26 03:55:23.634589
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0._compile_rules = Mock(return_value=None)

    # Should work
    route_mixin_0.add_route('/test', '/test')

    # Should work
    route_mixin_0.add_route('/test1', 'test2', 'test3')

    # Should work
    route_mixin_0.add_route('/test4', 'test5', 'test6', 'test7')

    # Should work
    route_mixin_0.add_route('/test8', 'test9', 'test10', 'test11', 'test12')

    # Should work

# Generated at 2022-06-26 03:55:38.274653
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '\x10\xfe\xaeo\x9c%ZB\x1e\x8c'
    file_path_0 = "C:\\Files\\File.txt"
    path_0 = path.normpath(file_path_0)
    route_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    route_0.methods = ['\x10\xfe\xaeo\x9c%ZB\x1e\x8c']

# Generated at 2022-06-26 03:55:46.903799
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    method_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    assert method_0 is not None



# Generated at 2022-06-26 03:56:02.177767
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = 'c'
    str_2 = '13'
    str_3 = '4'
    str_4 = '1\x016'
    str_5 = '0'
    str_6 = '8'
    str_7 = '3'
    str_8 = '6'
    str_9 = '13'
    str_10 = '4'
    str_11 = '1\x016'
    str_12 = '0'
    str_13 = '8'
    str_14 = '3'
    str_15 = '6'
    str_16 = '13'
    str_17 = '4'

# Generated at 2022-06-26 03:56:04.025174
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route()


# Generated at 2022-06-26 03:56:16.590526
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # str_0 = 'LÖ\x9f\x8bÍ'
    # str_1 = 'LÖ\x9f\x8bÍ'
    # str_2 = 'LÖ\x9f\x8bÍ'
    str_0 = 'str_0'
    str_1 = 'str_1'
    str_2 = 'str_2'
    var_0 = route_mixin_0.add_route(str_0, str_1, str_2)
    assert isinstance(var_0, HTTPRoute)
    assert var_0.uri == str_0
    assert var_0.host == str_1
    assert var_0.strict_slashes == str_2


# Generated at 2022-06-26 03:56:22.197897
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = '\x80\xa1\xad\xfe\xb9'
    boolean_0 = True
    route_mixin_0 = RouteMixin()
    route_mixin_0.static(str_0, str_1)



# Generated at 2022-06-26 03:56:31.238278
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:56:57.902396
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    str_0 = 'G\t\x8c\x15\x90\t'
    str_1 = '#\x15\x10\x06\x15\x15\x01\x04\x1e\x1c'
    test_case_0()
    route_mixin_0.static(str_0, str_0, str_0, str_1, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-26 03:57:09.347073
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create instance of class RouteMixin
    route_mixin_0 = RouteMixin()
    route_mixin_0.strict_slashes = False
    # Assign value to variable str_1
    str_1 = '"Y*9}F\\E\x9e\x9b'
    # Assign value to variable str_0
    str_0 = '7\x9c\x9eVÝ\x9c\x8dÝ'
    # Invoke method add_route of class RouteMixin
    var_0 = route_mixin_0.add_route(
        str_0,
        str_1,
        "iÈÞ\x9c\x8dÝ"
    )

# Generated at 2022-06-26 03:57:13.939060
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 03:57:27.198725
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def route(request, name='test_route_0'):
        return name

    route_mixin = RouteMixin()
    route_mixin.add_route('/test_route_0', name='test_route_0', methods=['GET'])
    assert route_mixin.routes is not None
    assert route_mixin.routes['GET']['/test_route_0'] is not None
    assert '<Route GET: /test_route_0 -> route' in str(route_mixin.routes['GET']['/test_route_0'])

# def test_RouteMixin_add_route_1():
#     route_mixin = RouteMixin()
#
#     @route_mixin.route('/test_route_1', methods=['GET'])
#     def

# Generated at 2022-06-26 03:57:34.769006
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    assert var_0.uri == str_0
    assert var_0.name == str_0


# Generated at 2022-06-26 03:57:39.102657
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route('', '', '', name='', methods='', version='', host='', strict_slashes='', apply='')
    # No Exception thrown
    

# Generated at 2022-06-26 03:57:45.933592
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '!t'
    str_1 = '?'
    str_2 = '/'
    str_3 = '\x103\x04\x85\x7f\x11\x94\r\n\r\r\x85\x7f;\x1d'
    str_4 = '\x1aW\x8bv\x94\n\x19\x1f\x92\x1e\x1c'
    str_5 = '\n'
    str_6 = '\x14\x7f\x12\x0b\x06\x9f\x1c\x1a\x1e'

# Generated at 2022-06-26 03:57:52.733360
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = '\x81\x9c\xbe\xbe\xf5\xa3\x10\x15\xf6Z\x7f'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 03:57:55.777248
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert callable(RouteMixin.add_route), "add_route method is not callable"
    assert isinstance(RouteMixin.add_route(RouteMixin()), tuple), "add_route does not return a tuple"


# Generated at 2022-06-26 03:58:00.096858
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'z\t'
    str_1 = '2\x9f;\n'
    var_0 = route_mixin_0.add_route(str_0, str_1)
    return (var_0)


# Generated at 2022-06-26 03:58:31.317497
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 03:58:36.089720
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 03:58:40.380735
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'LÖ\x9f\x8bÍ'
    route_mixin_0 = RouteMixin()
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    if (var_0 == 0):
        raise RuntimeError


# Generated at 2022-06-26 03:58:46.430265
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    str_0 = ""
    str_1 = ""
    str_2 = "LÖ\x9f\x8bÍ"
    bool_0 = True
    int_0 = 0
    route_mixin_0.static(str_2, str_0, str_1, bool_0, int_0)


# Generated at 2022-06-26 03:58:57.452581
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Setup
    route_mixin_0 = RouteMixin()
    # Exercise
    str_0 = 'Í\x9c\xef—\x04'
    str_1 = 'ª\x1fÃë\x04'
    str_2 = '\x97Ë\x8a\x1fû¿¿'
    var_0 = route_mixin_0.route(str_0, str_1, str_2) # 0
    assert_equal((var_0, var_0, var_0), ('LÖ\x9f\x8bÍ', 'LÖ\x9f\x8bÍ', 'LÖ\x9f\x8bÍ'))
    str_3 = '\xffa\x8b\x89\xff'
    str_

# Generated at 2022-06-26 03:59:10.205638
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = 'LÖ\x9f\x8bÍ'
    str_2 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_1, str_2)

# Generated at 2022-06-26 03:59:19.155562
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Setup
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = 'Y\xff\xa5\xabpdÓ'
    str_2 = 'm\xbb\xd7r\xcf\xa2Gw'
    str_3 = '\x9d\xa9\x8c\xe3\x87\xa1\x96\xb3\xda\x07'

    # Invocation
    var_0 = route_mixin_0.route(
        str_0, str_1, str_2, str_3, str_3, str_3, str_3, str_3,
        str_3, str_3)

    # Type Checking

# Generated at 2022-06-26 03:59:29.261657
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'ÚÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    str_1 = 'J\x9c¯'
    var_0 = route_mixin_0.add_route(str_1, str_0, str_0)
    str_2 = 'ÚÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_2, str_0, str_0)


# Generated at 2022-06-26 03:59:30.562623
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()


# Generated at 2022-06-26 03:59:31.698474
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()

# Generated at 2022-06-26 03:59:57.399291
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    str_1 = 'LÖ\x9f\x8bÍ'
    str_2 = '\x8a\x0cå'
    str_3 = 'Ý\x13'
    var_1 = route_mixin_1.add_route(str_1, str_2, str_3)


# Generated at 2022-06-26 04:00:00.685478
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    var_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    var_1 = var_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 04:00:04.550783
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = "\x0b\xde\xb9\xef\xdd\xe0\x1f\x857"
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)


# Generated at 2022-06-26 04:00:15.084149
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    str_0 = 'WÐ\x98\xfd\x0f'
    str_1 = 'ÐÝ\x9a\x8a4'
    str_2 = 'AÜ\x88\xdb\xeb'
    str_3 = 'Ö£\x9fÞ\x0c'
    str_4 = '\x16\x97\x9c\x8fj'
    str_5 = '\x10\xadn\x18{'
    var_0 = route_mixin_0.static(str_0, str_1, str_2, True, False, False, str_3, str_4, str_5, str_1)


# Generated at 2022-06-26 04:00:23.585127
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    str_0 = 'LÖ\x9f\x8bÍ'
    str_1 = 'q'
    var_0 = route_mixin_0.route(str_0, str_1, str_1)
    str_2 = 'RÖ\x9ciÍ'
    str_3 = 'q'
    str_4 = 'Ö\x9ciÍ'
    var_1 = route_mixin_0.route(str_2, str_3, str_4)


# Generated at 2022-06-26 04:00:30.692146
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin(
        http_helper_class=HTTPHelper,
        name="application",
        url_prefix="/application",
        strict_slashes=None,
        version=0
    )
    route_mixin_0.url_for = _url_for
    str_0 = 'LÖ\x9f\x8bÍ'
    var_0 = route_mixin_0.add_route(str_0, str_0, str_0)
    var_3 = route_mixin_0.version
    str_3 = 'LÖ\x9f\x8bÍ'
    var_1 = route_mixin_0.add_route(str_0, str_3, str_0, var_3)
    var_4 = route_mixin_