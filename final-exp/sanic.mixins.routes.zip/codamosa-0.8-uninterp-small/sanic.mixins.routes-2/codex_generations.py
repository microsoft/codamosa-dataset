

# Generated at 2022-06-26 03:51:09.908588
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    int_0 = -1862
    class_0 = User()
    string_0 = "User"
    def_0 = route_mixin_0.add_route(class_0, string_0)


# Generated at 2022-06-26 03:51:12.922584
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    int_0 = -1862


# Generated at 2022-06-26 03:51:20.670327
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0: str = 'uri'
    methods_0: List[str] = []
    strict_slashes_0: bool = True
    version_0: Optional[int] = -1862
    name_0: Optional[str] = 'name'
    host_0: Optional[str] = 'host'
    apply_0: bool = True
    routes_0, decorated_function_0 = route_mixin_0.route(
        uri=uri_0,
        methods=methods_0,
        strict_slashes=strict_slashes_0,
        version=version_0,
        name=name_0,
        host=host_0,
        apply=apply_0
    )



# Generated at 2022-06-26 03:51:27.534036
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    coroutine_0 = route_mixin_0.route(uri='lrt/<user>', strict_slashes=False, methods=['GET', 'POST'])
    coroutine_1 = route_mixin_0.route(uri='lrt/<user>', strict_slashes=False, methods=['GET', 'POST'])


# Generated at 2022-06-26 03:51:42.354963
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    str_0 = "JStI"
    str_1 = "4b:j7"
    str_2 = "f\"S5"
    str_3 = "k-=h"
    str_4 = "p)t"
    int_0 = 7740
    str_5 = "G"
    str_6 = "["
    str_7 = "Kj]T@"
    str_8 = "9_Z=3"
    str_9 = "`^8a"
    str_10 = "v</>"
    str_11 = "o"
    str_12 = "G"
    str_13 = "e"
    str_14 = "S"
    str_15 = "E"
    str_16 = "E"

# Generated at 2022-06-26 03:51:52.971302
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Instantiates a RouteMixin object
    route_mixin_0 = RouteMixin()
    # Setup arguments for method add_route of class RouteMixin
    uri_1 = "i;m`hqqp./98t_5`e@#"
    # Instantiates a WebSocket object
    web_socket_0 = WebSocket(uri_1, 100)
    # Calls method add_route of class RouteMixin
    route_mixin_0.add_route(web_socket_0, "*.vg`7-u1+2:_%c")


# Generated at 2022-06-26 03:52:00.991208
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    print("Testing RouteMixin.add_route")
    print("\tInitializing RouteMixin")
    route_mixin_0 = RouteMixin()
    int_0 = -1862
    print("\tAdding route")
    route_mixin_0.add_route(None, int_0)


# Generated at 2022-06-26 03:52:14.723311
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    int_0 = -1862
    dict_0 = dict()
    dict_0['host'] = None
    dict_0['methods'] = None
    dict_0['uri'] = '/test'
    dict_0['strict_slashes'] = None
    dict_0['name'] = None
    dict_0['version'] = None
    dict_0['static'] = False
    dict_0['websocket'] = False
    dict_0['apply'] = True
    dict_0['handler'] = None
    dict_0['route'] = None
    dict_0['_route'] = Route('', 0, 1, None, None, '', '', int_0, None, None, None, None, '', '', None, None)
    dict_0['route_info'] = dict_0['_route']


# Generated at 2022-06-26 03:52:21.790369
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    int_0 = -1862
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = None
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = True
    route_mixin_0.strict_slashes = False
    route_mixin_0.strict_slashes = False
   

# Generated at 2022-06-26 03:52:24.545489
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    print("\n* Testing route of class RouteMixin ...")
    route_mixin_0 = RouteMixin()
    int_0 = -1862
    def f(*args):
        return 0
    route_mixin_0.route(methods=(), uri=())


# Generated at 2022-06-26 03:52:48.768846
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler_0(request_0, name_0=None, ):
        var_0 = None
        var_0 = request_0
        var_1 = None
        var_1 = name_0
        return var_0, var_1
    route_mixin_0.add_route(handler_0, uri_0=lit49_, host_0=lit50_, name_0=lit51_)
    var_2 = None
    var_5 = None
    var_3 = None
    var_3 = route_mixin_0
    var_4 = None
    var_4 = route_mixin_0.routes
    var_5 = var_4[0]
    var_2 = var_5.methods
    assert var_

# Generated at 2022-06-26 03:52:57.082995
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.strict_slashes = True
    method_route = route_mixin_0.route
    route_mixin_0.strict_slashes = False
    routes, decorated_function = method_route("test", "test", "test", "test", "test", "test", "test", "test", "test", "test")
    assert routes == []


# Generated at 2022-06-26 03:53:06.152874
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    request_handler_0 = lambda request: None
    result = route_mixin_0.add_route(request_handler_0, '/testroute1')
    request_handler_1 = lambda request: None
    result = route_mixin_0.add_route(request_handler_1, '/testroute2')


# Generated at 2022-06-26 03:53:13.957308
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    def _handler_0():
        pass
    route_mixin_1.add_route(
        handler=_handler_0,
        uri='',
        host=None,
        methods=None,
        strict_slashes=None,
        version=None,
        name=None,
    )


# Generated at 2022-06-26 03:53:23.269593
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_app")
    route_mixin_1 = RouteMixin()
    # add path '/'
    async def async_test(request):
        return text("ok")
    route_mixin_1.add_route(async_test, uri="/")
    uri_rule_0 = route_mixin_1.rules[0]
    assert uri_rule_0.uri == "/"
    assert uri_rule_0.method in ['GET', 'HEAD']
    assert uri_rule_0.strict_slashes == False
    assert uri_rule_0.host == None
    assert uri_rule_0.version == None
    assert uri_rule_0.name == None
    assert uri_rule_0.handler == async_test
    assert uri_rule

# Generated at 2022-06-26 03:53:25.506470
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    print(route_mixin_1.add_route(handler = test_case_0,
                                   uri = '/',
                                   methods = ['GET']))


# Generated at 2022-06-26 03:53:27.980603
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_1 = Route('GET', '<request:Request>', '/example', 'example')
    route_mixin_0.add_route('GET', '/example', 'example')
    #TODO: assertEqual(expected, observed, 'Assertion Error')


# Generated at 2022-06-26 03:53:39.943027
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    uri = "/"
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    handler = None
    route_0 = route_mixin_1.add_route(uri, host, strict_slashes, version, name, handler)
    assert isinstance(route_0, tuple)
    assert len(route_0) == 2
    assert isinstance(route_0[0], list)
    assert len(route_0[0]) == 1
    assert isinstance(route_0[1], unittest.mock.MagicMock)


# Generated at 2022-06-26 03:53:48.005642
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0._routes = route_mixin_0._routes.copy()
    route_mixin_0._routes["GET"] = route_mixin_0.router.routes_names["GET"]
    route_mixin_0._routes["HEAD"] = route_mixin_0.router.routes_names["HEAD"]
    route_mixin_0._routes["OPTIONS"] = route_mixin_0.router.routes_names["OPTIONS"]
    route_mixin_0._routes["POST"] = route_mixin_0.router.routes_names["POST"]
    route_mixin_0._routes["PUT"] = route_mixin_

# Generated at 2022-06-26 03:53:57.669700
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    # Initialize the class object
    route_mixin_0 = RouteMixin()

    # Mocks for methods
    def mock_method0(self, request, *args, **kwargs):
        # body
        pass
        return mock_method0

    route_mixin_0.register_route = Mock(return_value=[])

    with patch("sanic.router.Route.__init__", return_value=None) as mock_init:
        try:
            # Call method in a try-except block to catch ValueError
            route_mixin_0.route(uri=object(),methods=object(),strict_slashes=object(),host=object(),version=object(),name=object(),apply=object())
        except ValueError as e:
            assert "is not callable" in str(e)


# Generated at 2022-06-26 03:54:15.701441
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    uri = "static"
    file_or_directory = "tmp/foo.txt"
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = "127.0.0.1"
    strict_slashes = None
    content_type = None
    apply = True
    obj = RouteMixin()
    obj.static(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)


# Generated at 2022-06-26 03:54:23.189001
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = lambda request, name: None
    route_mixin_0.add_route(handler_0, uri='', host=None, strict_slashes=None, methods=None, version=None, name='', name_prefix='')


# Generated at 2022-06-26 03:54:29.306420
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler_function_0(request):
        var = request.args.get("key")
        _ = request.args.get("key2", int)
        return response.json({"key": var})
    route_mixin_0.add_route(handler_function_0, "/test", methods=["POST"])


# Generated at 2022-06-26 03:54:39.366423
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    req_uri = "http://localhost:8000"
    uri = "/"
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    handler = ""
    route_mixin_1 = RouteMixin()

    route_mixin_1.add_route(
        uri,
        host,
        methods,
        strict_slashes,
        version,
        name,
        apply,
        handler,
    )



# Generated at 2022-06-26 03:54:45.609900
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler(request, *args, **kwargs):
        pass
    distance = route_mixin_0.add_route(handler, "/b/<t>", methods=["GET"], version=1, name="test_name")


# Generated at 2022-06-26 03:54:52.733037
# Unit test for method route of class RouteMixin

# Generated at 2022-06-26 03:54:59.111413
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler(obj):
        return True

    route_mixin_0.add_route(handler)
    print("[+] RouteMixin ---> test_case_0: test_add_route:", handler.__module__)



# Generated at 2022-06-26 03:55:10.300868
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(
        "/test/<url_param>/<url_param2>/",
        [
            "GET",
            "POST",
            "PUT",
            "DELETE",
            "OPTIONS",
            "HEAD"
        ],
        test_add_route_0,
        'example.com',
        False,
        None,
        'test_name',
        None,
        True
    )


# Generated at 2022-06-26 03:55:15.162411
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test default parameter
    route_mixin_1 = RouteMixin()
    route_mixin_1.route()


# Generated at 2022-06-26 03:55:27.160522
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("test_RouteMixin_add_route() started.")
    app = Sanic(__name__)
    r = RouteMixin()
    async def handler_0(req):
        print("handler_0")
    async def handler_1(req):
        print("handler_1")
    @app.route('/uri_add', methods=["GET", "HEAD"])
    def test_add_route_0():
        print("test_add_route_0")
    @app.route('/uri_addreq', methods=["POST"])
    async def test_add_route_1(req):
        print("test_add_route_1")
    #r.add_route(handler_0, uri='/uri_0', methods=["GET", "HEAD"], host='127.0.0.1', strict

# Generated at 2022-06-26 03:55:39.094953
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_add_route = RouteMixin()


# Generated at 2022-06-26 03:55:43.733535
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    uri = "index.html"
    file_or_directory = "index.html"
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "_static_"
    host = "127.0.0.1"
    strict_slashes = None
    content_type = None
    apply = True

# Generated at 2022-06-26 03:55:52.709641
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()

    def handler_1():
        return None

    uri_1 = '/'
    methods_1 = ["GET", "HEAD", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"]
    host_1 = None
    strict_slashes_1 = None
    stream_1 = False
    version_1 = None
    name_1 = None
    prefix_1 = None


# Generated at 2022-06-26 03:55:54.891853
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
      route_mixin_0 = RouteMixin()
      route = route_mixin_0.static(uri='/static/<path>',
                                   file_or_directory='/home/fang/files')
      assert route.route_path == '/static/<path>'


# Generated at 2022-06-26 03:56:08.219565
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for invalid type of arg0
    arg0 = None
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None
    arg9 = None
    arg10 = None
    arg11 = None
    arg12 = None
    try:
        RouteMixin.route(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"

    # Test for invalid type of arg1
    arg0 = str
    arg1 = None
    arg2 = None
    arg3 = None
    arg

# Generated at 2022-06-26 03:56:15.423246
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    try:
        test_case_1_handler = test_case_1
        route_mixin_1 = RouteMixin()
        route_mixin_1.add_route(route_mixin_1.handler, "/test-case-1", "GET")
    except Exception as e:
        print("Test case for add_route of class RouteMixin:")
        print("Exception raised: ", type(e))
        print("No exception is expected")


# Generated at 2022-06-26 03:56:26.390387
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = lambda request: None
    uri_0 = "https://example.org/5v5z5/6"
    host_0 = "http://localhost"
    methods_0 = None
    strict_slashes_0 = None
    name_0 = None
    version_0 = None
    apply_0 = True
    route_0 = route_mixin_0.add_route(handler_0, uri_0, host_0, methods_0, strict_slashes_0, name_0, version_0, apply_0)


# Generated at 2022-06-26 03:56:28.731100
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    @route_mixin.route('/')
    def test(request):
        return "hello"


# Generated at 2022-06-26 03:56:41.905382
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """
    Add the route to the router

    :param uri: path of the URL
    :param host: Host IP or FQDN details
    :param methods: HTTP methods that should be allowed for the URL
    :param strict_slashes: If the API endpoint needs to terminate
                           with a "/" or not
    :param version: API version in the form of float, int or str
    :param name: A unique name assigned to the URL so that it can
                 be used with :func:`url_for`
    :param apply: If the route must be applied to the router
    :param websocket: If the route is a websocket route
    :return: tuple of routes, decorated function
    """
    route_mixin = RouteMixin()

# Generated at 2022-06-26 03:56:56.135688
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():

    # Simple test for all the following parameters
    file_or_directory = "test path"
    uri = "test uri"
    pattern = "test_pattern"
    use_modified_since = True
    use_content_range = False
    stream_large_files = True
    name = "test name"
    host = "test host"
    strict_slashes = True
    content_type = "test type"

    # Create a instance of class RouteMixin
    route_mixin_0 = RouteMixin()

    # Call the method static of class RouteMixin

# Generated at 2022-06-26 03:57:21.115430
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    print("----- test_RouteMixin_static -----")
    route_mixin_0 = RouteMixin()
    # uri = '/static/<file:path>'
    uri = '/static/<file:path>'
    file_or_directory = '../sanic/route_mixin_static'
    pattern = r'/?.+'
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = 'static'
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    route_mixin_0.static(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)


# Generated at 2022-06-26 03:57:31.913432
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()

    route = route_mixin_0.add_route(route_mixin_0.async_asgi, route_mixin_1.strict_slashes)
    route = route_mixin_1.add_route(route_mixin_1.async_asgi, route_mixin_2.strict_slashes)
    route = route_mixin_2.add_route(route_mixin_2.async_asgi, route_mixin_0.strict_slashes)


# Generated at 2022-06-26 03:57:36.274577
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    with pytest.raises(AssertionError):
        route_mixin_0.add_route()


# Generated at 2022-06-26 03:57:44.675446
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0 = PartialRoute('/wiki/<page_name>', 'head', True, 'sanic/11.0.0', 'wiki', True)
    route_1 = route_mixin_0.route(uri='/wiki/<page_name>', host='head', strict_slashes=True, version='sanic/11.0.0', name='wiki', apply=True)
    assert route_0.uri == route_1.uri
    assert route_0.host == route_1.host
    assert route_0.strict_slashes == route_1.strict_slashes
    assert route_0.version == route_1.version
    assert route_0.name == route_1.name
    assert route_0.apply == route_1.apply



# Generated at 2022-06-26 03:57:54.227708
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """Verify correct operation of method RouteMixin.add_route"""

    route_mixin_0 = RouteMixin()
    app_0 = Sanic("sanic_0")

    @app_0.route("/user", methods=["GET"], version=1)
    async def handler_0(request):
        return text("OK")

    response_0 = route_mixin_0.add_route(app_0, handler_0, uri="/user",
                                         host=None, strict_slashes=None,
                                         version=1, name=None)

    assert response_0 is None


# Generated at 2022-06-26 03:57:57.804991
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # call the method, must raise an error
    try:
        route_mixin_0.add_route()
        raise Exception("Must raise an error")
    except Exception as e:
        assert(str(e) == "Not enough arguments, missing 'handler'")



# Generated at 2022-06-26 03:58:11.069767
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    def handler_0(request):
        return response.text('This route is a test')
    # create a new route
    route_0 = route_mixin_0.add_route(
        uri='test',
        name='test',
        handler=handler_0,
    )
    route_mixin_0.add_route(
        uri='test',
        name='test',
        handler=handler_0,
        methods=['GET'],
    )
    route_mixin_0.add_route(
        uri='test',
        name='test',
        handler=handler_0,
        methods=['POST', 'GET'],
    )

# Generated at 2022-06-26 03:58:19.599408
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()

    # Args:
    #     uri: path of the URL
    #     host: Host IP or FQDN details
    #     methods: List of valid HTTP methods
    #     strict_slashes: If the API endpoint needs to terminate
    #                     with a "/" or not
    #     version: Version of the service
    #     name: A unique name assigned to the URL so that it can
    #           be used with :func:`url_for`
    #     apply: Whether to apply routes to the router
    #     websocket : If the route is for a websocket
    #     subprotocols: List of valid subprotocols
    #     stream: If the route is for a stream
    #     websocket_max_size: Max size of websocket messages
    uri = None

# Generated at 2022-06-26 03:58:29.642960
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    # Test 1
    def foo_handler(request, *args, **kwargs):
        print("foo_handler")
        return "OK"
    route_mixin_0.route("/foo/", methods=["GET"])(foo_handler)
    print(route_mixin_0.routes_all)

    # Test 2
    def handler_websocket(ws, *args, **kwargs):
        print("ws_handler")

    route_mixin_0.add_websocket_route(
        handler_websocket,
        "/foo/",
        host=None,
        strict_slashes=None,
        subprotocols=None,
        version=None,
        name="ws_handler",
    )

# Generated at 2022-06-26 03:58:38.622471
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    def handler_1(request, id_):
        pass
    assert hasattr(route_mixin_1, "add_route")
    def test_1():
        route_mixin_1.add_route(handler_1, "/test_path/<id_>")
    assert raises(TypeError, test_1)
    def test_2():
        route_mixin_1.add_route(handler_1, "/test_path/<id_>", versions=[1])
    assert raises(TypeError, test_2)


# Generated at 2022-06-26 03:58:52.593308
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Positive
    route_mixin_0 = RouteMixin()
    route_mixin_0.route("uri", host="host", version="version", name="name")


# Generated at 2022-06-26 03:59:00.049890
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    method_route_0 = RouteMixin()
    uri_0 = '/'
    host_0 = 'localhost'
    strict_slashes_0 = True
    methods_0 = ['GET', 'POST']
    version_0 = 1
    name_0 = 'route'
    apply_0 = True
    version_1 = 1
    name_1 = 'route'
    apply_1 = False
    # Call method on object with arguments
    ret_0, ret_1 = method_route_0.route(uri_0, host_0, strict_slashes_0, methods_0,
                  version_0, name_0, apply_0, version_1, name_1, apply_1)
    assert ret_0 == None
    assert ret_1 == None
    pass



# Generated at 2022-06-26 03:59:05.532652
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route('/', 'index', 'GET', index)
    route_mixin_1.add_websocket_route(websocket_handler, '/ws', 'GET')
    route_mixin_1.route('/', 'index', 'GET', index, host='localhost')


# Generated at 2022-06-26 03:59:10.698269
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():  
    # initialize the RouteMixin object
    route_mixin_0 = RouteMixin()
    # invoke the add_route method with the required parameters
    route_mixin_0.add_route('/', None, ['GET'], '0.0.0.0', 1)


# Generated at 2022-06-26 03:59:19.215321
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.name = "_sanic_.__name__"
    route_mixin_0.strict_slashes = None
    route_mixin_0.version = 0
    handler_0 = None
    uri_0 = "./"
    host_0 = None
    strict_slashes_0 = False
    version_0 = None
    name_0 = "_sanic_.__name__.add_route"
    methods_0 = ["TRACE", "GET", "HEAD"]
    route_mixin_0.add_route(handler_0, uri_0, host_0, strict_slashes_0, version_0, name_0, methods_0)


# Generated at 2022-06-26 03:59:24.392307
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    def handler_1(request, *args, **kwargs):
        pass
    route_mixin_1.add_route(handler_1, uri="dummy_uri", methods=None, strict_slashes=None, version=None, name=None)
    

# Generated at 2022-06-26 03:59:37.224702
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Create a test object of class RouteMixin
    route_mixin_0 = RouteMixin()
    # Call method route of the object with different arguments
    route_0 = route_mixin_0.route("/test_0/")
    route_1 = route_mixin_0.route("/test_1/", methods=['GET'])
    route_2 = route_mixin_0.route("/test_2/", methods=['GET'], version=1)
    route_3 = route_mixin_0.route("/test_3/", methods=['GET'], version=1, name="test")
    route_4 = route_mixin_0.route("/test_4/", methods=['GET'], version=1, name="test", apply=False)
    route_5 = route_mixin

# Generated at 2022-06-26 03:59:44.065507
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    req_handler = object()
    uri = "uri"
    host = "host"
    name = "name"
    route_mixin_0 = RouteMixin()
    # Return the function wrapped by this decorator, which is add_route
    # argument: None
    ret_val_0 = route_mixin_0.add_route(req_handler=req_handler, uri=uri, host=host, name=name)
    assert callable(ret_val_0)
    assert ret_val_0 is route_mixin_0.add_route


# Generated at 2022-06-26 03:59:57.494466
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # create a class instance
    route_mixin_0 = RouteMixin()
    # create a class instance of class
    request = sanic.request.Request()
    # create a class instance of class Route
    route = sanic.router.Route()
    # create a class instance of class Route
    route_0 = sanic.router.Route()
    route_0.version = None
    route_0.host = '*'
    route_0.static = True
    route_0.name = None
    route_0.uri = '/*'
    route_0.methods = ['GET', 'HEAD', 'OPTIONS']
    route_0.websocket = False

# Generated at 2022-06-26 04:00:05.631781
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Inject mock data for testing
    import tempfile
    import pathlib
    with tempfile.TemporaryDirectory() as tmpdirname:
        route_mixin_0 = RouteMixin()
        route_mixin_0.static(
            uri="",
            file_or_directory=pathlib.Path(tmpdirname) / "test_file_0.txt",
            pattern=r"/?.+",
            use_modified_since=True,
            use_content_range=False,
            stream_large_files=False,
            name="static",
            host=None,
            strict_slashes=None,
            content_type=None,
            apply=True,
        )
