

# Generated at 2022-06-26 03:51:20.603411
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    list_0 = None
    route_mixin_0 = RouteMixin(*list_0)

    # mock the args for method add_route
    args_mock = Mock()
    args_mock.uri = '/'
    args_mock.methods = [METHOD_GET]
    args_mock.host = '127.0.0.1'
    args_mock.version = None
    args_mock.name = '_sanic_route_handler_wrapper_'
    args_mock.strict_slashes = None
    args_mock.stream = False

    # mock the kwargs for method add_route
    kwargs_mock = Mock()
    kwargs_mock.handler = route_mixin_0.route
    kwargs_mock.apply = True
   

# Generated at 2022-06-26 03:51:30.882261
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from core.interface import Sanic
    sanic_0 = Sanic()
    map_0 = None
    list_0 = ['', utf8_encode(''), '', utf8_encode(''), None, False, '', False, '[', None, '[', utf8_encode(''), None, None, None, None, False, False, '', '', None, None, None, None]
    __method_0 = MethodType(route, sanic_0, Sanic)
    try:
        __return_value_0 = __method_0(*list_0)
    except:
        __return_value_0 = False
        raise
    assert __return_value_0 == 5, "Incorrect return value for method route of class RouteMixin"


# Generated at 2022-06-26 03:51:43.925336
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def handler(request):
        pass

    route_mixin_0 = RouteMixin()
    uri_0 = '/resource'
    methods_0 = None
    host_0 = None
    strict_slashes_0 = None
    version_0 = None
    name_0 = 'add_route'
    route_mixin_0.add_route(uri_0, methods_0, host_0, strict_slashes_0, version_0, name_0)
    uri_1 = '/resource/123'
    methods_1 = None
    host_1 = None
    strict_slashes_1 = None
    version_1 = None
    name_1 = 'add_route'

# Generated at 2022-06-26 03:51:55.786927
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.uri = r('uri')
    route_mixin_0.methods = list()
    route_mixin_0.name = r('name')
    route_mixin_0.host = r('host')
    route_mixin_0.strict_slashes = r('strict_slashes')
    route_mixin_0.version = r('version')
    route_mixin_0.suffix = r('suffix')
    route_mixin_0.websocket = r('websocket')
    route_mixin_0.stream = r('stream')
    route_mixin_0.static = r('static')
    route_mixin_0.apply = r('apply')

# Generated at 2022-06-26 03:51:57.377638
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()


# Generated at 2022-06-26 03:52:06.069040
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    list_0 = None
    route_mixin_0 = RouteMixin(*list_0)
    handler_0 = None
    uri_0 = None
    host_0 = ""
    method_list_0 = None
    strict_slashes_0 = None
    name_0 = ""
    route_0 = route_mixin_0.add_route(handler_0, uri_0, host_0, method_list_0, strict_slashes_0, name_0)
    assert isinstance(route_0, Route)


# Generated at 2022-06-26 03:52:14.063054
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("Testing RouteMixin.add_route")
    print("# Testing with valid and invalid input")
    try:
        route_mixin_0 = RouteMixin()
        route_mixin_0.add_route(handler=None, uri="", host="", strict_slashes=True, version=None)
    except InvalidUsage:
        pass
    except:
        traceback.print_exc()


# Generated at 2022-06-26 03:52:21.273235
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app_0 = App.__new__(App)
    app_0.app_middlewares = list()
    app_0.registered_middleware = list()
    app_0.worker_ctx = None
    app_0.on_startup = list()
    app_0.on_cleanup = list()
    app_0.on_shutdown = []
    app_0.with_cookie_domain = False
    app_0.cookie_domain = None
    app_0.blueprints = []
    app_0.request_middleware = []
    app_0.response_middleware = []
    app_0.error_handler = dict()
    app_0.exception_handler = {}
    app_0.router = Router()
    app_0.request_class = Request

# Generated at 2022-06-26 03:52:21.940258
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert False, "Test not implemented"


# Generated at 2022-06-26 03:52:25.736067
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    list_0 = [
        None,
        "",
        "",
        "",
        None,
        None,
        "",
        None,
        None,
        None,
    ]
    route_mixin_0 = RouteMixin(*list_0)
    handler_0 = route_mixin_0.add_route("", "", "", "", None, None, "", None, None, None)
    assert_equal(handler_0, None)


# Generated at 2022-06-26 03:52:49.999719
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    print(RouteMixin.route.__qualname__)

    uri = '/test'
    host = 'localhost'
    strict_slashes = True
    methods = ['GET', 'POST', 'PUT']
    version = 1
    name = 'test_case'
    apply = True
    route = RouteMixin().route(uri=uri, host=host, strict_slashes=strict_slashes, methods=methods, version=version, name=name, apply=apply)
    print('[+]', len(route.__quantifiers__), route.__quantifiers__)
    # for quantifier in route.__quantifiers__:
    #     print('\t', quantifier)
    #     print('\t', type(quantifier))
    #     print('\t', quant

# Generated at 2022-06-26 03:52:54.992544
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.route('/sanic/<name>/')


# Generated at 2022-06-26 03:53:02.568979
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # First test case
    str_0 = '5U6Wx#Lr'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    def handler_0(request, name):
        str_1 = 'R'
        str_0 = 'DY78'
        if str_0 == 'DY78':
            def _handler_0():
                return 5
            return _handler_0
        list_0 = [5, 6, 7]
        set_0.clear()
        set_0.add(str_0)
        int_0 = len(set_0)
        str_0 = str_0 + str(int_0)
        set_0.remove(str_1)
        if 'DY78' and str_0:
            return 5

# Generated at 2022-06-26 03:53:10.345854
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '['
    list_0 = []
    list_1 = []
    list_2 = []
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri='[',methods=list_0,name='[',version=list_2,apply=list_1,websocket=list_0,host=list_1,strict_slashes=list_0,subprotocols=list_1)


# Generated at 2022-06-26 03:53:20.334634
# Unit test for method route of class RouteMixin

# Generated at 2022-06-26 03:53:32.739544
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # 'App'
    # ['GET', '/', <function test_RouteMixin_add_route.<locals>.<lambda> at 0x102566b90>, {}]
    # set()
    # 'sanic.app'
    # 'App'
    str_0 = 'App'
    int_0 = 0
    def_0 = 'def'
    str_1 = '/'
    str_2 = 'GET'
    str_3 = str_2
    str_4 = 'App'
    str_5 = str_4
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:53:35.277607
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '*'
    slashes = False
    flag_0 = True
    test_0 = RouteMixin.route('/', '\'E($)W):', slashes=True, apply=True, optional_str=str_0, optional_bool=flag_0)

# Generated at 2022-06-26 03:53:46.063692
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    # line_0:
    # 51 |     def static(
    # 52 |         self,
    # 53 |         uri,
    # 54 |         file_or_directory: Union[str, bytes, PurePath],
    # uri = '8l#1GTjCWx'
    # file_or_directory = set()
    # pattern = r"/?.+"
    # use_modified_since = True
    # use_content_range = False
    # stream_large_files = False
    # name = "static"
    # host = None
    # strict_slashes = None
    # content_type = None
    # apply = True
    # line

# Generated at 2022-06-26 03:53:50.379163
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    str_0 = './static'
    PurePath_0 = PurePath(str_0)
    str_1 = '.*\.(htm|html|css|js|png|jpg|jpeg|ttf)$'
    str_2 = 'static'
    route_mixin_0 = RouteMixin()
    route_mixin_0.static(str_0, PurePath_0, str_1, True, False, False, str_2)


# Generated at 2022-06-26 03:54:01.478561
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.route('', '', '', '', '', '', '', True)
    route_mixin_0.route('', '', [], '', '', '', '', True)
    route_mixin_0.route('', '', '', '', '', '', '', True)
    route_mixin_0.route('', '', '', '', '', '', '', True)


# Generated at 2022-06-26 03:54:19.180431
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '8l#1GTjCWx'
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(handler, uri = str_0, host = None, methods = None, strict_slashes = None, version = None, name = None)


# Generated at 2022-06-26 03:54:30.961300
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.method_map = {'GET': 'get', 'HEAD': 'head', 'POST': 'post', 'PUT': 'put', 'DELETE': 'delete', 'OPTIONS': 'options', 'PATCH': 'patch', 'TRACE': 'trace'}
    route_mixin_0.name = 'name_0'

# Generated at 2022-06-26 03:54:42.940387
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'twl4w4%4'
    set_0 = set()
    route_mixin_0 = RouteMixin()

    # Test with values that should reveal vulnerabilities
    class Test_0:
        def __init__(self):
            __name__ = "BdNbBp&qH"
            
    route_mixin_0.add_route(handler = Test_0(), uri = "7w.c*ofu5", host = "j5ATV7z&9", strict_slashes = "pZJN4B4C#", version = "W8CvJn0YX", name = "6&Jm8d.Dm")

    # Test with values that should not reveal vulnerabilities

# Generated at 2022-06-26 03:54:47.429334
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route( 0 )
    print(route_0)

if __name__ == '__main__':
    test_case_0()
    # test_RouteMixin_route()

# Generated at 2022-06-26 03:54:49.249018
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_case_0()


# Generated at 2022-06-26 03:54:57.591632
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = ''
    str_1 = ''
    set_0 = set()
    RouteMixin_instance = RouteMixin()

    RouteMixin_instance.route(uri=str_0)
    RouteMixin_instance.route(methods=set_0, uri=str_1)

    assert True


# Generated at 2022-06-26 03:55:11.351016
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    print('Testing method RouteMixin.route of class RouteMixin')
    int_0 = 1
    str_0 = '#l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    set_0.add(route_mixin_0._RouteMixin__default_expect_handler)
    set_0.add(route_mixin_0._RouteMixin__default_stream_handler)
    set_0.add(route_mixin_0._RouteMixin__websocket_handler)
    set_0.add(route_mixin_0._RouteMixin__options_handler)
    set_0.add(route_mixin_0._RouteMixin__error_handler_factory)

# Generated at 2022-06-26 03:55:25.891627
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '3q+mK0?w&'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    str_1 = '@Jc%(.+Fz'
    dict_0 = dict()
    set_1 = set()
    int_0 = 120
    int_1 = -140
    list_0 = list()
    route_mixin_0.route(9, -3, uri=str_1, name=str_0, host=str_1, version=int_0)
    route_mixin_0.route(83, -7, strict_slashes=False, host=str_0, version=int_1)

# Generated at 2022-06-26 03:55:29.017896
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass


# Generated at 2022-06-26 03:55:37.638050
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = 'lN2S'
    str_1 = 'Uzgp'
    str_2 = 'M8'
    set_0 = set()
    set_0.add(str_0)
    set_0.add(str_1)
    set_0.add(str_2)
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri=str_0, name=str_2, apply=True, methods=set_0)


# Generated at 2022-06-26 03:56:15.025824
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    method_0 = 'GET'
    uri_0 = '/'
    handler_0 = 'lt'
    route_0 = route_mixin_0.add_route(method_0, uri_0, handler_0)
    print('route_0.uri: %s' % (route_0.uri))
    print('route_0.handler: %s' % (route_0.handler))

test_RouteMixin_add_route()


# Generated at 2022-06-26 03:56:27.868585
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    str_0 = '8l#1GTjCWx'
    set_0 = {str_0}
    str_2 = '\\#8lTDnhSV;<5Plx'
    set_1 = {str_0, str_2}
    set_2 = {str_0, str_2}
    route_mixin_0 = RouteMixin()
    route_mixin_0.blueprints = set()
    route_mixin_0.blueprints = {str_0}
    route_mixin_0.strict_slashes = None
    str_1 = '|=[\\'
    set_3 = {str_0, str_1}
    str_3 = 't|[x\\v|8t'
    route_mixin_0._future_statics = set()
   

# Generated at 2022-06-26 03:56:40.092698
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()

    def handler_0(request_0):
        return

    route_mixin_0.add_route(uri='/Kj#iV7ixB', handler=handler_0)

    def handler_0(request_0):
        return

    route_mixin_0.add_route(
        uri='/Kj#iV7ixB',
        handler=handler_0,
        host='MgZ3&8',
        strict_slashes=False,
        version=2,
        name='Xg=I6%atZ')


# Generated at 2022-06-26 03:56:42.763453
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '3q@N8;x`$'
    set_0 = set()
    route_mixin_0 = RouteMixin()


# Generated at 2022-06-26 03:56:46.026942
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route()


# Generated at 2022-06-26 03:56:58.167667
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route('#', 'async_route', 'GET', '###', '34545454545', '3bc#3')
    route_mixin_1.add_route('p6UwA6', '_route', '9sQ2$D#R*', 'test_controller', '0Zjb$1#A', '###')
    route_mixin_0.add_route('1YkpcpE', 'async_route', '###', '####', '####', '2s9hRmfM')

# Generated at 2022-06-26 03:57:04.437811
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '#@'
    str_1 = '8_)dFh.<'
    str_2 = 'T9nji%'
    future_route_0 = FutureRoute(str_0, str_1, str_2)
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route(future_route_0=future_route_0)
    return route_0


# Generated at 2022-06-26 03:57:18.462081
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'G3NC'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    int_0 = 1
    str_1 = 'Cc%RgN'
    str_2 = '5'
    str_3 = 'l5'
    str_4 = 'tg'
    str_5 = 'g7'
    str_6 = '9'
    str_7 = '4'
    str_8 = 'Dz1w'
    str_9 = 'lR$^'
    int_1 = 4
    str_10 = 'E#('
    str_11 = 'u'
    str_12 = 'H'
    float_0 = 3.2
    str_13 = '62s'
    str_14 = 'D'
    str_

# Generated at 2022-06-26 03:57:21.170491
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = 'lzF6[oK]^/8l'
    route_mixin_0 = RouteMixin()


# Generated at 2022-06-26 03:57:35.023670
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('q3?lD1:6H[', 'T', '/^M?z=rP', 'Z\x18Z\x18Z\x18Z\x18Z\x18Z\x18')
    route_mixin_0.add_route('d_Jv_8Wb', 'BW&', '+`sX^p;,', 'Z\x18Z\x18Z\x18Z\x18Z\x18Z\x18')

# Generated at 2022-06-26 03:58:40.835019
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print('Running test method RouteMixin.add_route')
    # Create an instance of RouteMixin
    route_mixin_0 = RouteMixin()
    ____ = Wrapped(route_mixin_0._generate_name)
    ____()(None)

    print('Testing RouteMixin.add_route')
    # Run add_route method with parameter uri
    route_mixin_0.add_route(uri=___)
    # Run add_route method with parameter methods
    route_mixin_0.add_route(methods=___)
    # Run add_route method with parameter strict_slashes
    route_mixin_0.add_route(strict_slashes=___)
    # Run add_route method with parameter version
    route_mixin_0.add_route(version=___)

# Generated at 2022-06-26 03:58:53.292065
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # str 0
    str_0 = 'h\x7fbn'
    # int 0
    int_0 = 1
    # str 1
    str_1 = 'Jk\x7f'
    # str 2
    str_2 = '6\x7f\x1cX'
    # str 3
    str_3 = 'J\x7f\x1cV7\x1c\x7f'
    # str 4
    str_4 = 'P"\x7f'
    # str 5
    str_5 = '6X\x1c\x7f'
    # str 6
    str_6 = '"V7\x1c\x7f'
    # str 7

# Generated at 2022-06-26 03:58:59.365897
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_1 = 'h!r$yaZg-k'
    str_2 = 'h!r$yaZg-k'
    str_3 = 'S!E8!vJ1YX'
    class_0 = RouteMixin
    route_mixin_0 = RouteMixin()
    output = route_mixin_0.route(uri=str_1, methods=str_2, host=str_3, version=1)
    assert output
    output = route_mixin_0.route(uri=str_1, methods=str_2, host=str_3, version=1)
    assert output


# Generated at 2022-06-26 03:59:02.994141
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(object, object, object, object, object, object, object, object, object, object, object)

# Generated at 2022-06-26 03:59:10.291332
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    set_0 = set()
    RouteMixin_0 = RouteMixin()
    RouteMixin_0.str_0 = '8l#1GTjCWx'
    RouteMixin_0.set_0 = set()
    RouteMixin_0.route(RouteMixin_0.str_0, RouteMixin_0.set_0, RouteMixin_0.name, False, RouteMixin_0.strict_slashes)


# Generated at 2022-06-26 03:59:11.351579
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()


# Generated at 2022-06-26 03:59:15.339887
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-26 03:59:25.953138
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(
        uri='/users/me/profile',
        methods=['GET', 'POST'],
        name='profile',
        host=None,
        strict_slashes=None,
        version=None,
        apply=False,
        websocket=False,
        stream=False,
    )

# Generated at 2022-06-26 03:59:38.569358
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from mockingjay import Mockingjay
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    file_or_directory = "Test"
    uri = "Test"
    pattern = "Test"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "Test"
    host = None
    strict_slashes = True
    content_type = None
    apply = True

    route_mixin_0 = RouteMixin()
    assert isinstance(route_mixin_0, RouteMixin)


# Generated at 2022-06-26 03:59:46.434583
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    str_0 = '8l#1GTjCWx'
    set_0 = set()
    route_mixin_0 = RouteMixin()
    # As var10 is not a variable, we can call route with no return value
    route_mixin_0.route()

if __name__ == "__main__":
    # Unit test for method add_route of class RouteMixin
    test_RouteMixin_add_route()

    # Unit test for method websocket of class RouteMixin
    test_RouteMixin_websocket()

    # Unit test for method add_websocket_route of class RouteMixin
    test_RouteMixin_add_websocket_route()

    # Unit test for method static of class RouteMixin
    test_RouteMixin_static()

    # Unit test for method _generate