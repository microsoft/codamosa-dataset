

# Generated at 2022-06-26 03:51:12.923303
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    param_0 = '/'
    param_1 = None
    param_2 = ['GET']
    param_3 = None
    param_4 = None
    param_5 = None
    param_6 = None
    param_7 = True
    param_8 = None
    param_9 = None
    param_10 = False
    param_11 = True
    param_12 = True
    param_13 = True
    param_14 = True
    param_15 = False
    param_16 = None

# Generated at 2022-06-26 03:51:15.236418
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler=print, uri="/", name="index", host="", strict_slashes=False)



# Generated at 2022-06-26 03:51:27.055145
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create the object of class
    route_mixin_1 = RouteMixin()
    # Call the method
    function_handler = route_mixin_1.add_route(uri='/', host=None, strict_slashes=True, version=None, 
    name=None, methods=['GET'], 
    handler=None, strict_slashes=True, apply=True, stream=False)

    # Check the return value

    # Check the type
    assert(type(function_handler) == type)
    # Check the function name
    assert(function_handler.__name__ == 'function_handler')
    # Check the function source code
    assert(function_handler.__code__.co_name == 'function_handler')
    # Check the function's first argument

# Generated at 2022-06-26 03:51:38.086735
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()
    assert route_mixin_1.static(uri='/favicon.ico', file_or_directory=None, pattern='/[^/]*', use_modified_since=True, use_content_range=False, stream_large_files=False, name='static', host=None, strict_slashes=None, content_type=None, apply=True)


# Generated at 2022-06-26 03:51:47.823618
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case with all parameters
    route_mixin_1 = RouteMixin()
    routes, decorated_func_handler = route_mixin_1.route(
            uri='/foo',
            methods=[],
            host=None,
            strict_slashes=False,
            version=1,
            name="foo",
            apply=False,
            websocket=True,
            stream=False,
            static=False,
            # subprotocols=None
    )
    assert routes
    assert decorated_func_handler


# Generated at 2022-06-26 03:51:52.387341
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    method_0 = route_mixin_0.route
    assert method_0(uri='/api/v1/user', methods=["GET"], strict_slashes=None)


# Generated at 2022-06-26 03:52:05.443229
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route = Mock()
    mock_route_1 = Mock()
    route_mixin_0.route.return_value = mock_route_1, Mock()
    mock_request_handler_2 = Mock()
    mock_uri_3 = Mock()
    mock_methods_4 = Mock()
    mock_host_5 = Mock()
    mock_strict_slashes_6 = Mock()
    mock_stream_7 = Mock()
    mock_name_8 = Mock()
    mock_version_9 = Mock()
    mock_expect_continue_10 = Mock()
    mock_apply_11 = Mock()
    mock_catch_all_12 = Mock()
    mock_register_13 = Mock()
    mock_status_14 = Mock

# Generated at 2022-06-26 03:52:16.918211
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.url_for = Mock()
    route_mixin_1.add_route = Mock()

    def handler_0(request, a=None, b=None, c=None):
        pass

    route_0 = route_mixin_1.route(
        uri='/abc/<a>/<b>/<c>',
        host='host',
        methods=['methods'],
        strict_slashes='strict_slashes',
        version='version',
        name='name',
        apply='apply',
        subprotocols=['subprotocols'],
        websocket='websocket',
        apply=False,
    )(handler_0)

    response_0 = route_0[1]()
   

# Generated at 2022-06-26 03:52:19.689243
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    def acc_0_handler(request): pass

    # Test Case 0:
    # Test when uri is not a path but a string
    route_mixin.add_route(acc_0_handler, "/acc_0")


# Generated at 2022-06-26 03:52:35.757333
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    method_0 = route_mixin_0.route
    args_0 = ('uri', 'methods', 'strict_slashes', 'version', 'name', 'apply', 'static')
    kwargs_0 = {'version': 0, 'apply': True, 'name': 'name', 'methods': 'methods', 'strict_slashes': 'strict_slashes'}
    attr_values_0 = (method_0, args_0, kwargs_0)
    RouteMixin_add_route = RouteMixin.add_route
    args_1 = (route_mixin_0, 'handler', 'uri', 'methods', 'strict_slashes', 'version', 'name')

# Generated at 2022-06-26 03:52:59.314060
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    #construct an instance of Sanic
    sanic_obj = Sanic()

    #construct an instance of RouteMixin
    route_mixin_obj = RouteMixin()

    #case with default arguments
    assert(route_mixin_obj.add_route(sanic_obj, '/route_1') == 'route 1')

    #case with host not None, method PUT and strict_slashes is True
    assert(route_mixin_obj.add_route(sanic_obj, '/route_2', host='127.0.0.1', methods="PUT", strict_slashes=True) == 'route 2')

    #case with host not None, method DELETE and strict_slashes is False

# Generated at 2022-06-26 03:53:12.562368
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    func_0 = lambda x: x
    result_0 = route_mixin_0.route("/test_path")(func_0)
    func_1 = lambda x: x
    result_1 = route_mixin_0.route("/test_path", methods=["GET", "POST", "DELETE"])(func_1)
    func_2 = lambda x: x
    result_2 = route_mixin_0.route("/test_path", methods=["GET", "POST", "DELETE"], strict_slashes=True)(func_2)
    func_3 = lambda x: x

# Generated at 2022-06-26 03:53:22.786812
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_2 = RouteMixin()
    request_handler_1 = wraps(route_mixin_2.add_route)
    route_mixin_2.add_route(
        request_handler_1,
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
        'dd',
    )
    try:
        route_mixin_2.add_route(
            request_handler_1,
        )
    except TypeError:
        pass
    route_mixin_2.add_route(
        request_handler_1,
        'dd',
    )

# Generated at 2022-06-26 03:53:29.800624
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("[+] test_RouteMixin_add_route")
    print("Already tested in current file")
    #route_mixin_0 = RouteMixin()
    #assert(route_mixin_0.add_route(methods_for_tests, uri_for_tests, handler_for_test) == None)


# Generated at 2022-06-26 03:53:43.910586
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    with pytest.raises(TypeError):
        route_mixin_1.add_route()
    with pytest.raises(TypeError):
        route_mixin_1.add_route(uri='/home')
    with pytest.raises(TypeError):
        route_mixin_1.add_route(uri='/home', host=None)
    with pytest.raises(TypeError):
        route_mixin_1.add_route(uri='/home', host=None, name=None)
    with pytest.raises(TypeError):
        route_mixin_1.add_route(uri='/home', host=None, name=None, methods=None)
    with pytest.raises(TypeError):
        route_mixin

# Generated at 2022-06-26 03:53:55.656099
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    uri_0 = 'xV?jB&%'
    host_0 = 'zd.j(`S'
    methods_0 = ['A', 'd', '+']
    strict_slashes_0 = True
    version_0 = 686160
    name_0 = 'xT38|)'
    handler_0 = object()
    route_mixin_0.add_route(
        uri=uri_0,
        methods=methods_0,
        host=host_0,
        strict_slashes=strict_slashes_0,
        version=version_0,
        name=name_0,
    )(handler_0)

# Generated at 2022-06-26 03:54:07.165295
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.handlers import async_handler_wrapper

    route_mixin_0 = RouteMixin()
    assert(route_mixin_0.routes == [])
    assert(route_mixin_0._future_routes == set())
    assert(len(route_mixin_0._future_routes) == 0)

    @route_mixin_0.route('/')
    def handler(request):
        pass

    route_0 = next(iter(route_mixin_0._future_routes))
    assert(route_0.uri == '/')
    assert(route_0.methods == ['GET'])
    assert(route_0.host == None)
    assert(route_0.strict_slashes is None)

# Generated at 2022-06-26 03:54:18.955348
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def handler_0(request):
        return response_0

    handler_0.name = "handler_0"

    response_0 = HTTPResponse()
    response_0.status_code = 200
    response_0.url_for = partial(url_for, _external=True)
    response_0.cookies.update({})
    response_0.app = Mock()
    response_0.app.send = Mock()
    response_0.app.websocket_handlers = {}
    response_0.app.before_start = None
    response_0.app.before_websocket_handshake = None
    response_0.app.after_websocket_handshake = None
    response_0.app.before_request = None
    response_0.app.after_request = None
    response

# Generated at 2022-06-26 03:54:30.862770
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    import tempfile
    import shutil
    import pathlib
    
    route_mixin_0 = RouteMixin()
    temp_dir = tempfile.mkdtemp()
    a_file = pathlib.Path(temp_dir) / 'a_file.txt'
    a_file.write_text('Hello')
    uri = '/'
    file_or_directory = a_file
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True

# Generated at 2022-06-26 03:54:44.311320
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("Test: test_RouteMixin_add_route")

# Generated at 2022-06-26 03:55:14.988813
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print('\n=======Unit test for method add_route of class RouteMixin')

    route_mixin_1 = RouteMixin()

    # Unit test with static routing config

    # Unit test with invalid uri
    def handler_1(request):
        pass

    uri = "test_uri"
    host = 'test_host'
    strict_slashes = True
    methods = 'test_methods'
    version = 1
    name = 'test_name'

    # with pytest.raises(ValueError):
    #     route_mixin_1.add_route(handler_1, uri, host, strict_slashes, methods, version, name)

    # Unit test with normal uri
    def handler_2(request):
        pass

    uri = "/test_uri"

# Generated at 2022-06-26 03:55:16.439826
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass

# Generated at 2022-06-26 03:55:27.452110
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("Start test method add_route...")
    host = "www.liuzhen.com"
    uri = "liuzhen"
    strict_slashes = False
    version = 1
    name = None
    apply = True
    methods = ["GET"]
    _handler = "test_handler_0"
    expect_route = sanic.router.Route(
        uri=uri,
        host=host,
        methods=methods,
        strict_slashes=strict_slashes,
        version=version,
        name=name,
        apply=apply,
        handler=_handler,
    )
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:55:35.488526
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    uri = '/home'
    handler = route_mixin_1.route(uri = '/home')(route_mixin_1.index)
    assert handler.__name__ == "index"
    route_mixin_1.add_route(handler = route_mixin_1.index, uri = '/home')


# Generated at 2022-06-26 03:55:43.806080
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    # TODO
    #assert route_mixin.add_route("/test_uri[0-9]/", None, None, None, None, None, None, None) == None
    assert True


# Generated at 2022-06-26 03:55:47.509085
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
    method route of class RouteMixin
    """
    route_mixin = RouteMixin()
    assert route_mixin.route(1, 2, 3)


# Generated at 2022-06-26 03:56:02.720837
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    route_mixin_1 = RouteMixin(strict_slashes=True)
    handler_1 = partial(echo, b"Hello")
    routes_1 = route_mixin_1.add_route(handler_1, uri="/foo_bar")
    assert routes_1
    # Test case 2
    route_mixin_2 = RouteMixin(strict_slashes=False)
    handler_2 = partial(echo, b"Hello")
    routes_2 = route_mixin_2.add_route(handler_2, uri="/foo_bar")
    assert routes_2
    # Test case 3
    route_mixin_3 = RouteMixin(strict_slashes=True, version=None)
    handler_3 = partial(echo, b"Hello")
    routes_3

# Generated at 2022-06-26 03:56:09.544384
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: need to finish
    # test case 1
    route_mixin_1 = RouteMixin()
    route_mixin_1.strict_slashes = True
    route_mixin_1_callback = lambda request: "route_mixin_1_callback"
    route = route_mixin_1.add_route(route_mixin_1_callback, "/index", methods=["get"])
    print(route)

# Generated at 2022-06-26 03:56:22.082275
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app_0 = RouteMixin()
    def handler_0(request, name, id):
        return
    app_0.add_route(handler_0, '', host='', strict_slashes='', version='', name='',
        uri='http://<name>/api/blog/<id>')
    app_0.add_route(handler_0, '', host='', strict_slashes='', version='', name='',
        uri='/api/blog/<id>')
    app_0.add_route(handler_0, '', host='', strict_slashes='', version='', name='',
        uri='/api/blog/<id>/')

# Generated at 2022-06-26 03:56:24.670778
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    assert False



# Generated at 2022-06-26 03:56:46.525701
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    import pathlib

    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()
    route_mixin_3 = RouteMixin()
    route_mixin_4 = RouteMixin()
    route_mixin_5 = RouteMixin()
    route_mixin_6 = RouteMixin()
    route_mixin_7 = RouteMixin()
    route_mixin_8 = RouteMixin()
    route_mixin_9 = RouteMixin()
    route_mixin_10 = RouteMixin()
    route_mixin_11 = RouteMixin()
    route_mixin_12 = RouteMixin()
    route_mixin_13 = RouteMixin()
    route_mixin_14 = RouteMixin()

# Generated at 2022-06-26 03:56:59.038881
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    import asyncio

    class MyView(HTTPMethodView):

        async def get(self, request):
            return await self.post(request)

        async def post(self, request):
            return HTTPResponse(text="Hello world!", status=200)

    request = Request.blank("/")
    uri = "uri"
    host = "host"
    strict_slashes = True
    version = 1
    name = "name"
    apply = True

    # test normal pattern
    route_mixin_0 = RouteMixin()

# Generated at 2022-06-26 03:57:01.945763
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri="/user/<id>", methods=["GET"], strict_slashes=None, version=1, name=None)


# Generated at 2022-06-26 03:57:15.684455
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("start test_case_1_1")
    route_mixin_1_1 = RouteMixin()
    @route_mixin_1_1.add_route("/", host='localhost:8081')
    def handler_1_1(request):
        return text('OK')
    print("end test_case_1_1")

    print("start test_case_1_2")
    route_mixin_1_2 = RouteMixin()
    @route_mixin_1_2.add_route("/", host='localhost:8081', methods=["POST"])
    def handler_1_2(request):
        return text('OK')
    print("end test_case_1_2")

    print("start test_case_1_3")
    route_mixin_1_3 = RouteMix

# Generated at 2022-06-26 03:57:24.397579
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # mock up an instance
    route_mixin_1 = RouteMixin()
    
    # mock up a method handler
    handler_0 = mock.Mock()
    # mock up a url
    url_0 = "/test"
    # method
    methods_0 = ["GET", "POST"]
    
    # call the method route of RouteMixin
    route_0 = route_mixin_1.route(
        uri=url_0, methods=methods_0, apply=False)(handler_0)
    
    # check if route is registered
    assert len(route_mixin_1.routes) == 1
    # check if route is of type Route
    assert isinstance(route_mixin_1.routes[0], Route)
    # check if url is correct
    assert route_mixin_

# Generated at 2022-06-26 03:57:37.324900
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # No assertions. Just examples
    route_mixin_0.add_route('/', 'get', 'index')
    route_mixin_0.add_route('/login', 'post', 'login')
    route_mixin_0.add_route('/logout', 'get', 'logout')
    route_mixin_0.add_route('/user/<id>', 'delete', 'delete_user')
    route_mixin_0.add_route('/user/<id>', 'put', 'update_user')
    route_mixin_0.add_route('/user/<id:int>', 'put', 'update_user')

# Generated at 2022-06-26 03:57:45.253521
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1, also test case 0
    route_mixin_0 = RouteMixin()
    test_case_0()

    # Test case 2
    route_mixin_1 = RouteMixin(None, None, None, None, None, None, None, None, None, False, False)
    route_mixin_1.add_route("1", "2", 3, 4, 5, 6, 7, 8, 9, False, False)

    # Test case 3
    def test_handler(request):
        pass
    test_handler.__name__ = "test_handler"
    route_mixin_2 = RouteMixin(None, None, None, None, None, None, None, None, None, False, False)

# Generated at 2022-06-26 03:57:49.622548
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route()
    route_0.method()


# Generated at 2022-06-26 03:57:56.429206
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('abc', 'abc')
    route_mixin_0.add_route('abc', 'abc', host='abc', strict_slashes='abc', version='abc', name='abc', apply='abc', methods='abc')
    route_mixin_0.add_route('abc', 'abc', host='abc', strict_slashes='abc', version='abc', name='abc', apply='abc', methods='abc', uri='abc')


# Generated at 2022-06-26 03:57:58.995433
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.route()



# Generated at 2022-06-26 03:58:12.696648
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: add some test code
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route()


# Generated at 2022-06-26 03:58:15.216335
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    global_route_mixin_instance = global_app.app.router
    global_route_mixin_instance.add_route("/", lambda request: "OK")


# Generated at 2022-06-26 03:58:20.115103
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    with async_test_server(_handler_default) as client:
        resp = client.get("/test/")
        assert resp.status == 200
        assert resp.text == "default handler"


# Generated at 2022-06-26 03:58:29.977044
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = "static"
    host = None
    methods = ['GET', 'HEAD']
    strict_slashes = None
    version = 0
    name = "static"
    apply = True
    method = 'GET'
    expected_output = [
        Route(
            uri,
             host,
             methods,
             strict_slashes,
             version,
             name,
             static=None,
             websocket=None,
             strict_slashes=None,
             host=None,
             stream=None
        )
    ]
    assert route_mixin_0.route(
        uri,
        host,
        methods,
        strict_slashes,
        version,
        name,
        apply
    )(lambda r: None) == expected

# Generated at 2022-06-26 03:58:34.328695
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    global expected_routes
    route_mixin_0 = RouteMixin()
    routes_0 = route_mixin_0.route(uri='/', methods=None, host=None, strict_slashes=None, version=None, name=None, apply=True)
    routes_0_0 = routes_0(handler=None)
    foobar_0 = uri_0


# Generated at 2022-06-26 03:58:44.727774
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_route = RouteMixin()

    route_mixin_route.strict_slashes = True
    arg0 = None
    arg1 = "http://127.0.0.1:8000/test_case"
    arg2 = ["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"]
    arg3 = False
    arg4 = 1
    arg5 = None
    arg6 = True
    arg7 = False
    arg8 = None
    arg9 = None
    arg10 = None
    arg11 = False
    arg12 = []
    arg13 = False
    arg14 = None
    arg15 = True
    arg16 = ["utf-8"]

# Generated at 2022-06-26 03:58:53.087610
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic()
    route_mixin_0 = RouteMixin()

    @route_mixin_0.add_route("/", name="foo")
    async def get_handler(request):
        return text("I am foo")

    # Check that a route is created for the route handler
    assert len(route_mixin_0.route_handlers) == 1

    # Check that the route handler is added to the router
    assert app.router.has_route(get_handler)


# Generated at 2022-06-26 03:58:56.755339
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO
    mock_handler = mock.Mock()
    route_mixin_0 = RouteMixin()
    uri = "yphwv"
    route_mixin_0.add_route(uri=uri, handler=mock_handler)


# Generated at 2022-06-26 03:59:02.054044
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.add_route("GET", "/users/<name_1>/<age_1>", "handler", name_1="name_1", age_1="age_1")


# Generated at 2022-06-26 03:59:09.761991
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    method = "GET"
    uri = "/index"
    func = "test"
    args = {
        "method": method,
        "uri": uri,
        "func": func
    }
    # Wrong type for request handler
    exception_thrown = False
    try:
        route_mixin.add_route(args)
    except Exception:
        exception_thrown = True
    assert exception_thrown


# Generated at 2022-06-26 03:59:39.554992
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri: str = "hello"
    host: Optional[str] = "127.0.0.1"
    methods: Optional[List[str]] = ["hello"]
    strict_slashes: Optional[bool] = False
    version: Optional[int] = 5
    name: Optional[str] = "hello"
    apply: bool = True
    subprotocols: Optional[List[str]] = ["hello"]
    websocket: Optional[bool] = False
    exception_0 = None
    value_0 = None
    try:
        value_0 = route_mixin_0.route(uri, host, methods, strict_slashes, version, name, apply, subprotocols, websocket)
    except Exception as exception_0:
        pass

# Unit test

# Generated at 2022-06-26 03:59:42.425153
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.route("/heatmap/data", methods=["GET", "HEAD"])("route_mixin_1.route")


# Generated at 2022-06-26 03:59:45.282022
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler = 'test_handler', uri = 'test_uri', host = 'test_host', strict_slashes = None, version = 1, name = 'test_name')


# Generated at 2022-06-26 03:59:53.133821
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = None
    methods_0 = None
    host_0 = None
    strict_slashes_0 = None
    version_0 = None
    name_0 = None
    result = route_mixin_0.route(uri_0, methods_0, host_0, strict_slashes_0, version_0, name_0)


# Generated at 2022-06-26 03:59:55.508606
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    @route_mixin_1.add_route('/', methods=['GET'], host='127.0.0.1', strict_slashes=None, version=None, name=None, )
    def handler_1():
        return 'Hello world!'


# Generated at 2022-06-26 03:59:58.864438
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(None, "/url/path/", None, None)


# Generated at 2022-06-26 04:00:11.786660
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    logger.info("Start test_RouteMixin_route")

    app_0 = Sanic('test_app_0')
    test_func_0 = lambda : 42
    # AssertionError: Failed to invoke decorated function.
    with pytest.raises(AssertionError, match="Failed to invoke decorated function."):
        route_mixin_0 = RouteMixin()
        route_mixin_0.route('/test_uri_0', methods=['GET'], name='test_name_0', host='test_host_0', strict_slashes=True, version=1, apply=False, catch_all=True, uri_part=None, name_prefix=None, websocket=False, stream=False, static=False, default_content_type=None)(test_func_0)

# Generated at 2022-06-26 04:00:24.171543
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # This test is Invalid because of not initialize RouteMixin
    try:
        route_mixin_0 = RouteMixin()
        route_mixin_0.route()
    except Exception as e:
        print("Failed {}".format(e))

    # This test is Invalid because of not initialize RouteMixin
    try:
        route_mixin_0 = RouteMixin()
        route_mixin_0.route(
            uri='/',
            host=None,
            methods=['GET'],
            strict_slashes=False,
            version=1,
            name=None,
            apply=True,
            subprotocols=None,
            websocket=False,
        )
    except Exception as e:
        print("Failed {}".format(e))

    # This test is Invalid because of not initialize

# Generated at 2022-06-26 04:00:26.109137
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()


# Generated at 2022-06-26 04:00:34.095049
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = str()
    methods = set()
    host = str()
    strict_slashes = bool()
    version = int()
    name = str()
    apply = bool()
    _, routes_0 = route_mixin_0.route(uri, methods, host, strict_slashes, version, name, apply)
