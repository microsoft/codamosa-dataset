

# Generated at 2022-06-26 03:50:59.992308
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    # Test 1
    method_1 = route_mixin_1.route(
        uri='/users/<id>',
        strict_slashes=False,
        methods=['GET', 'OPTION'],
        name='get_user_by_id',
        host='sanic.com'
    )
    method_1_handler_0 = method_1(lambda request, id, *args, **kwargs: None)
    route_1_1 = method_1_handler_0
    # Test 2

# Generated at 2022-06-26 03:51:05.172508
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # 1
    route_mixin_0.add_route(None, "/test", None, None, False, False, None)
    # 2
    route_mixin_0.add_route(None, "/test", None, None, True, False, None)
    # 3
    route_mixin_0.add_route(None, "/test", None, None, False, True, None)


# Generated at 2022-06-26 03:51:17.912682
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():

    route_mixin = RouteMixin()

    # Test with no parameter
    route_mixin.static()
    # Test with wrong parameter
    route_mixin.static(1)
    # Test with wrong parameter
    route_mixin.static(1, "two")
    # Test with wrong parameter
    route_mixin.static("one", 1)
    # Test with wrong parameter
    route_mixin.static("one", "two", "three")
    # Test with wrong parameter
    route_mixin.static("one", "two", "three", "four")
    # Test with wrong parameter
    route_mixin.static("one", "two", "three", "four", 1)
    route_mixin.static("one", "two", "three", "four", True, 1)

# Generated at 2022-06-26 03:51:28.583158
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TestSanicCoreApp_route_0
    sanic_app_0 = Sanic('sanic_app_0')
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route('/users/0', strict_slashes=True)('Test_sanic_core.test_handler_0')
    # TestSanicCoreApp_route_1
    sanic_app_1 = Sanic('sanic_app_1')
    route_mixin_1 = RouteMixin()
    route_1 = route_mixin_1.route('/users/0', strict_slashes=True)('Test_sanic_core.test_handler_0')
    # TestSanicCoreApp_route_2

# Generated at 2022-06-26 03:51:42.985317
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Case 0: 
    #    input: uri = '/hi', methods=None, name='/hi', host=None, 
    #     strict_slashes=False, version=None, apply=True, websocket=False, 
    #     stream=False, subprotocols=None
    #    output: (<class 'tuple'>: [], <class 'function'>)
    route_mixin_0 = RouteMixin()
    uri =  '/hi'
    version = None
    methods=None
    name= '/hi'
    host=None
    strict_slashes=False
    apply=True
    return route_mixin_0.route(uri, methods, name, host, strict_slashes, version, apply, websocket=False, stream=False, subprotocols=None)

# Unit test

# Generated at 2022-06-26 03:51:55.444411
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    uri = "test uri"
    file_or_directory = "test file_or_directory"
    
    pattern = "test pattern"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "test name"
    host = None
    strict_slashes = None
    content_type = None
    apply = True

    route_mixin_1 = RouteMixin()
    route_mixin_1.static(uri, file_or_directory, pattern, use_modified_since,
                use_content_range, stream_large_files, name, host, strict_slashes,
                content_type, apply)

if __name__ == '__main__':
    test_case_0()
    test_RouteMixin_static()

# Generated at 2022-06-26 03:52:06.316963
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # create an object of class RouteMixin
    route_mixin_0 = RouteMixin()
    # The first parameter is a callable function or the instance of a class that can handle the request
    handler = my_handler_0
    # The second parameter is the URL path that will be mapped to the handler
    uri = 'sometext/<file_uri:path>/sometext'
    # The third parameter is the [host: Optional[str]] = None
    host = None
    # The fourth parameter is the [strict_slashes: Optional[bool]] = None
    strict_slashes = None
    # The fifth parameter is the [name: Optional[str]] = None
    name = None
    # The sixth parameter is the [version: Optional[int]] = None
    version = None

    route_mixin_0.add_

# Generated at 2022-06-26 03:52:17.956717
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # arrange
    route_mixin_1 = RouteMixin()
    uri_1 = '/'
    handler_1 = MagicMock(__name__='handler_1')
    methods_1 = ['GET', 'PUT']
    host_1 = 'localhost'
    strict_slashes_1 = True
    version_1 = 1
    name_1 = 'test_name'

    # act
    actual_route_1, actual_handler_1 = route_mixin_1.add_route(
        handler=handler_1,
        uri=uri_1,
        methods=methods_1,
        host=host_1,
        strict_slashes=strict_slashes_1,
        version=version_1,
        name=name_1,
        apply=True
    )

    # assert


# Generated at 2022-06-26 03:52:22.219695
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app_0 = Sanic()
    route_mixin_0 = RouteMixin()

    # Test function with 'host' as argument
    @route_mixin_0.add_route('/', host='127.0.0.1')
    def test_function_0(request):
        print("Hello Sanic!!")
        return text("Hello Sanic!!")

    app_0.add_route(test_function_0, url_0, methods=['GET'], host='127.0.0.1')


# Generated at 2022-06-26 03:52:24.989828
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    @route_mixin_0.add_route('/', host=None, strict_slashes=False, version=None, name='main')
    async def func(request):
        return text('hello world')

    assert isinstance(func, Callable)


# Generated at 2022-06-26 03:52:45.303568
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    uri = None
    methods = None
    handler = None
    host = None
    strict_slashes = None
    stream = None
    version = None
    name = None
    apply = True
    websocket = False
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri, methods, handler, host, strict_slashes, stream, version, name, apply, websocket)


# Generated at 2022-06-26 03:52:59.058452
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    import asyncio # noqa
    import unittest # noqa
    from sanic.router import Route # noqa
    from functools import partial # noqa
    from sanic.log import error_logger # noqa
    from sanic.response import HTTPResponse, empty # noqa
    from sanic.views import CompositionView # noqa

    # 1. None handler case
    # 1.1 None handler with name
    try:
        route = route_mixin_0.add_route('/', None, name='test_name')
        ret_ok = False
    except AttributeError:
        ret_ok = True
    print('ret_ok: {}'.format(ret_ok))
    assert ret_ok is True

    # 1.2 None handler without name

# Generated at 2022-06-26 03:53:12.445390
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()
    uri = "uri"
    file_or_directory = "file_or_directory"
    pattern = "*.png"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = "localhost"
    strict_slashes = True
    content_type = "image/png"
    result = route_mixin_1.static(uri, 
                                  file_or_directory, 
                                  pattern, 
                                  use_modified_since, 
                                  use_content_range, 
                                  stream_large_files, 
                                  name, 
                                  host,
                                  strict_slashes,
                                  content_type)

# Generated at 2022-06-26 03:53:16.194263
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    uri = ""
    handler_0 = lambda x: None
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = ""
    route_mixin_1.add_route(uri=uri, handler=handler_0, host=host, methods=methods, strict_slashes=strict_slashes, version=version, name=name)


# Generated at 2022-06-26 03:53:30.130653
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    run_async = False
    route_mixin_0 = RouteMixin()
    file_or_directory = "__file_or_directory_1"
    uri = "/static/a"
    pattern = ".*"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "__name_1"
    host = "__host_1"
    strict_slashes = False
    content_type = "__content_type_1"
    route_mixin_0.static(file_or_directory, uri, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type)


# Generated at 2022-06-26 03:53:33.647581
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route()

# Generated at 2022-06-26 03:53:42.460371
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app_0 = Sanic('app_0')
    cf_0 = lambda x, y: x + y
    route_mixin_0 = RouteMixin()
    response_0 = route_mixin_0.add_route(app=app_0, uri='0.0.0.0', host='0.0.0.0', method='GET', handler=cf_0, name='cf_0')
    print(response_0)
    # True


# Generated at 2022-06-26 03:53:45.390508
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()


# Generated at 2022-06-26 03:53:54.616303
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # -----------------------------------------------------------------------------
    # Create a route and register it with the app
    # -----------------------------------------------------------------------------
    # Create a Sanic() object
    sanic_0 = Sanic()

    # Add a self.route() method decorated function to the list of functions to be
    # registered as routes
    # TODO: Need to work on this
    # route_mixin_0 = RouteMixin()
    # route_mixin_0.add_route(handler=None, uri='/', host=None, methods=None,
    # strict_slashes=False, version=None, name=None)



# Generated at 2022-06-26 03:54:06.967606
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()
    route_mixin_3 = RouteMixin()
    route_mixin_4 = RouteMixin()
    route_mixin_5 = RouteMixin()
    route_mixin_6 = RouteMixin()
    route_mixin_7 = RouteMixin()
    route_mixin_8 = RouteMixin()
    route_mixin_9 = RouteMixin()
    route_mixin_10 = RouteMixin()
    route_mixin_11 = RouteMixin()
    route_mixin_12 = RouteMixin()
    route_mixin_13 = RouteMixin()
    route_mixin_14 = RouteMixin()
    route_mixin_15 = RouteMixin()
    route_mix

# Generated at 2022-06-26 03:54:33.609360
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case where arguments are correct.
    try:
        route_mixin_1 = RouteMixin()
        route_mixin_1.add_route("route_uri_example_1", "route_handler_example_1")
    except Exception as e:
        assert False, "Unable to add route: " + str(e)

    # Test case where arguments are incorrect.
    try:
        route_mixin_2 = RouteMixin()
        route_mixin_2.add_route(None, None)
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-26 03:54:41.564802
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = object()
    def handler_1(request, uri):
        return request, uri
    uri_0 = str()
    strict_slashes_0 = None
    methods_0 = None
    host_0 = str()
    version_0 = None
    name_0 = str()
    register_to_base_url_0 = bool()
    stream_0 = None


# Generated at 2022-06-26 03:54:45.950379
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin(name = "name")
    def test_function():
        pass
    route_mixin.route("test_uri")(test_function)


# Generated at 2022-06-26 03:54:47.745002
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('/', 0)


# Generated at 2022-06-26 03:54:52.038406
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert hasattr(RouteMixin, "add_route")
    route_mixin_0 = RouteMixin()


# Generated at 2022-06-26 03:55:03.213985
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def test_body_0():
        test_app_0 = Sanic()
        route_mixin_0 = RouteMixin()
        handler_0 = test_app_0.get('/')
        uri_0 = '/'
        host_0 = None
        strict_slashes_0 = None
        version_0 = '0.0.0'
        name_0 = None
        # Test the add_route functionality
        route = route_mixin_0.add_route(handler_0, uri_0, host_0, strict_slashes_0, version_0, name_0)
        assert route.handler == handler_0
        assert route.uri == uri_0
        assert route.host == host_0
        assert route.strict_slashes == strict_slashes_0

# Generated at 2022-06-26 03:55:12.227773
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    uri = "uri_0"
    handler = "handler_0"
    method = "GET"
    host = "host_0"
    strict_slashes = "strict_slashes_0"
    version = "version_0"
    name = "name_0"
    route_mixin_0.add_route(uri, handler, method, host, strict_slashes, version, name)


# Generated at 2022-06-26 03:55:25.956891
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    #@TODO: fix
    import types
    route_mixin_1 = RouteMixin()

    # Input Parameters
    uri = '''/$route<id:\d+>/$route<action:\d+>/$route<name:(.*?)>/$route<age:(.*?)>'''
    host = '''www.baidu.com'''
    methods = ['''GET''']
    strict_slashes = False
    version = 1
    name = '''test_name'''
    handler = "test_handler"
    uri_prefix = '''www.baidu.com'''

    # Placeholder for return value
    handler_0 = None

    # Invoke method

# Generated at 2022-06-26 03:55:34.955861
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    print("------test_RouteMixin_route------")
    route_mixin = RouteMixin()
    # test_case_0()

    # TODO: Need to make this unit test more powerful

    # Test case 1
    uri = '/'
    method = 'GET'
    handler_0 = RouteMixin._static_request_handler
    # Test method RouteMixin.route of class RouteMixin
    # Test case 1
    # TODO: Need to add more test case
    print('Test case 1:')
    print('uri = %s, method = %s' % (uri, method))
    route, func = route_mixin.route(uri, method)
    assert(func == handler_0)



# Generated at 2022-06-26 03:55:39.001744
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route('/url_0/', endpoint_0)


# Generated at 2022-06-26 03:55:53.094640
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # @add_route(uri, name)


# Generated at 2022-06-26 03:55:58.160346
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler="some_handler", uri="/some/uri", host="some_host", strict_slashes=1, version=1, name="some_name")


# Generated at 2022-06-26 03:56:10.890035
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for 'add_route' method of RouteMixin
    # Create test objects for RouteMixin
    route_mixin_0 = RouteMixin()
    handler_0 = TestHandler()
    uri_0 = '/test'
    methods_0 = ['GET']
    host_0 = None
    version_0 = 1
    name_0 = 'test'
    # Must call the method under test
    result_0 = route_mixin_0.add_route(handler=handler_0, uri=uri_0, host=host_0, methods=methods_0, version=version_0, name=name_0)
    # Check the result
    assert result_0.is_coroutine, "Invalid result"
    # Check the result of 'add_route' method of RouteMixin

# Generated at 2022-06-26 03:56:19.421931
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    # {}
    expected = ({
        'uri': '',
        'methods': None,
        'host': None,
        'strict_slashes': None,
        'version': None,
        'name': None,
        'apply': True,
        'subprotocols': None,
        'websocket': False,
        'static': False,
    }, None)
    actual = route_mixin_0.route()
    assert actual == expected


# Generated at 2022-06-26 03:56:21.042354
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass



# Generated at 2022-06-26 03:56:30.687534
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    # Test 1 - Test with defaults
    try:
        route_mixin_0.static(uri="", file_or_directory="", name="")
    except ValueError as err1:
        print("Test 1 - Test with defaults")
        print("Test Failed")
        print("Error message: {}".format(err1))
    else:
        print("Test 1 - Test with defaults")
        print("Test Passed")
    # Test 2 - Test with empty string
    try:
        route_mixin_0.static(uri="", file_or_directory="", name="")
    except ValueError as err2:
        print("Test 2 - Test with empty string")
        print("Test Failed")
        print("Error message: {}".format(err2))
    else:
        print

# Generated at 2022-06-26 03:56:41.682342
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    # Set value for variable uri
    uri = 'test_value'
    # Set value for variable host
    host = 'test_value'
    # Set value for variable methods
    methods = ['test_value']
    # Set value for variable strict_slashes
    strict_slashes = False
    # Set value for variable version
    version = 0
    # Set value for variable name
    name = 'test_value'
    # Call method add_route to do the test
    res = route_mixin.add_route(uri, host, methods, strict_slashes, version, name)
    assert res


# Generated at 2022-06-26 03:56:48.169320
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    @route_mixin_1.add_route('/')
    async def handler(request):
        return 'hello world'
    assert isinstance(route_mixin_1._routes[0].uri, str)
    assert route_mixin_1._routes[0].uri == '/'
    assert isinstance(route_mixin_1._routes[0].handler, types.FunctionType)
    assert route_mixin_1._routes[0].handler.__name__ == 'handler'
    assert route_mixin_1._routes[0].handler.__qualname__ == 'handler'
    assert isinstance(route_mixin_1._routes[0].name, str)
    assert route_mixin_1._routes

# Generated at 2022-06-26 03:56:55.133012
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    uri = 'test'
    methods = None
    handler = None
    strict_slashes = None
    host = None
    register = False
    stream = False
    version = None
    name = None
    route_0 = route_mixin.route(uri, methods, handler, strict_slashes, host, register, stream, version, name)


# Generated at 2022-06-26 03:57:02.177758
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()

    @route_mixin_1.add_route("/test_1", methods=["GET"], host="test", strict_slashes=True, version=1, name="test_1")
    async def test_1(request):
        pass

    @route_mixin_2.add_route("/test_2", methods=["GET"], host="test", strict_slashes=True, version=1, name="test_2")
    def test_2(request):
        pass



# Generated at 2022-06-26 03:57:23.745865
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = "/"
    host = "127.0.0.1"
    methods = "GET"
    strict_slashes = False
    version = None
    name = None
    apply = True
    subprotocols = None
    websocket = False
    res = route_mixin_0.route(uri, host, methods, strict_slashes, version, name, apply,
                              subprotocols, websocket)


# Generated at 2022-06-26 03:57:35.519390
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(handler="abc", uri="/path/to/handler/", host="127.0.0.1",
                            version=1, name="route_name")
    route_mixin_0.add_route(handler="abc", uri="/path/to/handler/", host="127.0.0.1",
                            version=1, name="route_name")
    route_mixin_0.add_route(handler="abc", uri="/path/to/handler/", host="127.0.0.1",
                            version=1, name="route_name", strict_slashes=True)


# Generated at 2022-06-26 03:57:41.938786
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    handler = None
    uri = 'abc'
    host = None
    methods_list = None
    strict_slashes = None
    version = None
    name = None
    route_derive_mixin_1 = route_mixin_1.add_route(
        handler,
        uri,
        host,
        methods_list,
        strict_slashes,
        version,
        name
    )


# Generated at 2022-06-26 03:57:52.691340
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Build args
    uri = ""
    methods = ""
    host = ""
    strict_slashes = ""
    version = ""
    name = ""
    apply = ""
    websocket = ""
    subprotocols = ""

    # Instantiate the object
    route_mixin_1 = RouteMixin()

    # Call the method
    # TODO: Replace the following code with your test.
    try:
        route_mixin_1.route(uri, methods, host, strict_slashes, version, name, apply, websocket, subprotocols)
    except:
        pass


# Generated at 2022-06-26 03:58:00.320400
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    async def test_handler_0(request: Request) -> HTTPResponse:
        return HTTPResponse(b'{"test": "response"}')
    uri_0 = "/test-uri"
    host_0 = "127.0.0.1"
    strict_slashes_0 = False
    version_0 = None
    name_0 = "test-name"
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(test_handler_0, uri_0, host_0, strict_slashes_0, version_0, name_0)

# Generated at 2022-06-26 03:58:13.645713
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    #  This is the original method
    #  def route(
    #      self,
    #      uri,
    #      methods=frozenset({"GET"}),
    #      host: Optional[str] = None,
    #      strict_slashes: Optional[bool] = None,
    #      version: Optional[int] = None,
    #      name: Optional[str] = None,
    #      apply: bool = True,
    #      **options
    #  ):
    #
    #      Apply decorator on a function.
    #
    #      :param uri: path of the URL
    #      :param methods: list of methods this route responds to
    #      :param host: Host IP or FQDN details
    #      :param strict

# Generated at 2022-06-26 03:58:18.714049
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    req = HTTPRequest()

    req.headers["method"] = "POST"
    req.headers['Content-Type'] = 'application/json'
    req.body = {"name": 'test', "password": '123456'}

    print(req.headers)
    print(req.body)


# Generated at 2022-06-26 03:58:20.838120
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.route("get", "/")


# Generated at 2022-06-26 03:58:28.041005
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def get(self, request, *args, **kwargs):
        return request, args, kwargs

    route_mixin_0.add_route("/api/v2/users/<user_id>/", get, methods=("GET",),
                            version=2, strict_slashes=True, host="www.example.com")
    return

# Case for testing of method add_route of class RouteMixin

# Generated at 2022-06-26 03:58:35.462197
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = str()
    methods_0 = [str()]
    host_0 = str()
    strict_slashes_0 = bool()
    version_0 = int()
    name_0 = str()
    apply_0 = bool()
    router_0, decorated_0 = route_mixin_0.route(
        uri=uri_0,
        methods=methods_0,
        host=host_0,
        strict_slashes=strict_slashes_0,
        version=version_0,
        name=name_0,
        apply=apply_0
    )
    assert router_0
    assert decorated_0


# Generated at 2022-06-26 03:58:57.515384
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # 1. Arrange
    route_mixin_0 = RouteMixin()
    uri_0 = "/test_uri"
    file_or_directory_0 = "test_file.txt"
    pattern_0 = r"/?.+"
    use_modified_since_0 = True
    use_content_range_0 = False
    stream_large_files_0 = False
    name_0 = "test_name"
    host_0 = None
    strict_slashes_0 = None
    content_type_0 = None
    apply_0 = True

# Generated at 2022-06-26 03:59:10.253688
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    route_mixin_0.static("uri_0", "file_or_directory_0", pattern="pattern_0", use_modified_since=True, use_content_range=True, stream_large_files=True, name="name_0", host="host_0", strict_slashes=True, content_type="content_type_0", apply=True)
    route_mixin_1 = RouteMixin()
    route_mixin_1.static("uri_1", "file_or_directory_1", pattern="pattern_1", use_modified_since=True, use_content_range=True, stream_large_files=True, name="name_1", host="host_1", strict_slashes=True, content_type="content_type_1", apply=True)

# Generated at 2022-06-26 03:59:11.635022
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    uri = 'home'
    handler = 'home_handler'
    route_mixin = RouteMixin()
    route_mixin.add_route(handler, uri)


# Generated at 2022-06-26 03:59:16.022825
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri="<test_uri>", host=None, strict_slashes="<test_strict_slashes>", version=None, name="<test_name>", apply=True, subprotocols=None, websocket=None)


# Generated at 2022-06-26 03:59:23.713729
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    method_0 = RouteMixin.add_route.__name__
    (handler_0, uri_0, methods_0, host_0, strict_slashes_0, version_0,
        name_0) = (None, '/', None, None, None, None, None)
    route_mixin_1.add_route(handler_0, uri_0, methods_0, host_0,
                            strict_slashes_0, version_0, name_0)


# Generated at 2022-06-26 03:59:29.831202
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.router = Router()

    class Handler_0:
        def __call__(self, request, *args, **kwargs):
            return HTTPResponse('Hellow Sanic!')

    route_mixin_1.add_route(Handler_0(), '/')



# Generated at 2022-06-26 03:59:41.574279
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = "test_uri"
    methods_0 = [ "test_methods" ]
    host_0 = ""
    strict_slashes_0 = False
    version_0 = 1
    name_0 = "test_name"
    apply_0 = False
    websocket_0 = False
    subprotocols_0 = [ "test_subprotocols" ]
    # Call method route of class RouteMixin

# Generated at 2022-06-26 03:59:52.388206
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler_0():
        pass
    uri_0 = URI("//LHJ@n@z?E[X+Nv")
    host_0 = Host("JQ]?8wv")
    methods_0 = None
    strict_slashes_0 = False
    version_0 = None
    name_0 = "U_K"
    apply_0 = False
    assert route_mixin_0.add_route(handler_0, uri_0, host_0, methods_0, strict_slashes_0, version_0, name_0, apply_0) == (None, handler_0)


# Generated at 2022-06-26 04:00:00.245094
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    async def handler():
        pass
    uri = "/v0/abc"
    host = "127.0.0.1"
    methods = ["GET"]
    strict_slashes = True
    version = 0
    name = None
    apply = True
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler, uri, host, methods, strict_slashes, version, name)


# Generated at 2022-06-26 04:00:07.081130
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    handler_a_0 = "async def handler_a_0(request: Type[Request], **kwargs):\n    return await request.app.render_template(\"template_a_0.html\", request=request, **kwargs)\n"
    handler_a_1 = "async def handler_a_1(request: Type[Request], **kwargs):\n    return await request.app.render_template(\"template_a_0.html\", request=request, **kwargs)\n"

    # Test case with assertions