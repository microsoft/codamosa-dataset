

# Generated at 2022-06-26 03:51:09.908892
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    route = route_mixin.route('/')
    assert(route)


# Generated at 2022-06-26 03:51:16.290615
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def foo_handler(request):
        return "foo"
    route = route_mixin_0.add_route(foo_handler, uri="/foo", method="get")
    route.handler = foo_handler
    with capture_logging(None) as log_buffer:
        route.handler(request=None)
        assert log_buffer.getvalue() == "foo\nfoo\n"
    route.methods = set(['get'])
    route.method = "GET"
    route.name = "foo_handler"
    route.strict_slashes = False
    route.host = None
    route.uri = "/foo"
    route.parameter_order = tuple()
    with capture_logging(None) as log_buffer:
        route.handler

# Generated at 2022-06-26 03:51:22.077974
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    with pytest.raises(TypeError):
        route_mixin_1.add_route(None, None, None)


# Generated at 2022-06-26 03:51:31.938567
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = lambda request, name: len(request)
    path_0 = ""
    host_0 = ""
    methods_0 = []
    strict_slashes_0 = True
    version_0 = 0
    name_0 = ""
    routes_0, decorated_0 = route_mixin_0.add_route(handler_0, path_0, host_0, methods_0, strict_slashes_0, version_0, name_0)
    print(routes_0)
    print(decorated_0)
    def test_case_0(route_mixin_0):
        route_mixin_0.route(2, 4)
        return 1

# Generated at 2022-06-26 03:51:34.207226
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    route = route_mixin_0.add_route("/test_route", "GET")


# Generated at 2022-06-26 03:51:40.586701
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_app_0")
    route_mixin_1 = RouteMixin(app)
    # test case 1
    def hello(request):
        return response.text("hello world")
    route_mixin_1.add_route(hello, "/", "GET")
    # test case 2
    def test(request):
        return response.text("test")
    route_mixin_1.add_route(test, "/test", "GET")
    # test case 3
    def hello(request):
        return response.text("hello world")
    route_mixin_1.add_route(hello, "/test1", "GET")
    # test case 4
    def hello(request):
        return response.text("hello world")

# Generated at 2022-06-26 03:51:54.304092
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route_param_class = Route

    class fake_methods:
        def __init__(self):
            self.GET = 'GET'
            self.POST = 'POST'
            self.PUT = 'PUT'
            self.PATCH = 'PATCH'
            self.DELETE = 'DELETE'
            self.OPTIONS = 'OPTIONS'
            self.HEAD = 'HEAD'
            self.ANY = 'ANY'
    fake_methods_0 = fake_methods()

    class fake_handler:
        def __init__(self):
            pass
    fake_handler_0 = fake_handler()
    fake_handler_1 = fake_handler()
    fake_handler_2 = fake_handler()
    fake

# Generated at 2022-06-26 03:52:05.886049
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # State of the RouteMixin
    print(f"route_mixin_0.route_middleware: {route_mixin_0.route_middleware}")
    print(f"route_mixin_0.middleware: {route_mixin_0.middleware}")
    print(f"route_mixin_0.strict_slashes: {route_mixin_0.strict_slashes}")
    print(f"route_mixin_0.requests_versions: {route_mixin_0.requests_versions}")
    print(f"route_mixin_0.errors: {route_mixin_0.errors}")

# Generated at 2022-06-26 03:52:10.004215
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    request = Request("GET", "/")
    handler = lambda request: "Ok"
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri="/", methods=["GET"])(handler)(request)

    try:
        route_mixin_0.route(uri="/a/b/c", methods=["GET"])(handler)(request)
    except:
        pass

    route_mixin_0.route(uri="/a/b/c", methods=["GET"], strict_slashes=False)(handler)(request)


# Generated at 2022-06-26 03:52:15.829413
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Arrange
    # Create instance of RouteMixin
    route_mixin_0 = RouteMixin()

    # Act
    # Invoke method add_route of RouteMixin
    try:
        route_mixin_0.add_route(uri = '/', methods = [], host = "0.0.0.0", strict_slashes = True, version = 1, name = "", stream = True, status = 200, headers = {}, apply = True)
    except Exception as e:
        result = str(e)[0:16]
        print("add_route " + result)
    else:
        print("add_route PASSED")


# Generated at 2022-06-26 03:52:36.402999
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.version = 1
    route_mixin_0.name = "algorithm"
    route_mixin_0.strict_slashes = None
    handler_0 = lambda : None
    uri_0 = "/algorithm"
    method_0 = None
    host_0 = None
    strict_slashes_0 = None
    name_0 = None
    version_0 = None
    route_mixin_0.add_route(handler_0, uri_0, method_0, host_0, strict_slashes_0, name_0, version_0)




# Generated at 2022-06-26 03:52:48.549729
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Instance of class RouteMixin for test
    route_mixin_1 = RouteMixin()
    #
    # Test for normal input
    file_or_directory = "test_files/hypercorn.py"
    uri = "/file_path"
    name = "my_file"
    pattern = "/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    host = "127.0.0.1"
    strict_slashes = False
    content_type = None
    #
    # Function calls

# Generated at 2022-06-26 03:52:52.197800
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_1 = route_mixin_1.add_route('/', None)


# Generated at 2022-06-26 03:53:01.687157
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from functools import wraps
    from .async_dispatcher import StaticFileHandler
    from .constants import DEFAULT_HTTP_CONTENT_TYPE
    from .route import Route
    from .server import serve
    from .static import guess_type
    from .exceptions import InvalidUsage
    from .streams import FlowControlStreamReader, StreamingHTTPResponse
    from .static import StaticFileHandler
    from .helpers import create_environ
    from .static import stream_file_handler

    async def function_0(request):
        pass

    async def function_1(request):
        pass

    class class_0:
        def __init__(self):
            pass

        async def function_0(self, request):
            pass

    class_0_0 = class_0()


# Generated at 2022-06-26 03:53:12.176272
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_0 = RouteMixin()
    def test_func():
        pass
    version = 0
    def test_func2():
        pass
    version = 0
    test_0.route(uri = '/', host = None, methods = ['GET'], strict_slashes = None, version = version, name = None, apply = True, subprotocols = None, websocket = False)(test_func)
    test_0.route(uri = '/test_0', host = None, methods = ['GET'], strict_slashes = None, version = version, name = None, apply = True, subprotocols = None, websocket = False)(test_func2)


# Generated at 2022-06-26 03:53:18.766346
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()

    @route_mixin_0.route('/user/<name>')
    def testfun_0(request,name):
        return 'test'

    route_mixin_0.add_route(testfun_0, '/user/<name>')


# Generated at 2022-06-26 03:53:28.342268
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    uri_0 = "/"
    host_0 = None
    methods_0 = ["GET"]
    strict_slashes_0 = None
    version_0 = None
    name_0 = None
    output_0 = route_mixin_0.add_route(uri_0, host_0, methods_0, strict_slashes_0, version_0, name_0)


# Generated at 2022-06-26 03:53:42.350362
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = "/hello1"
    host = 'localhost1'
    methods = ['GET']
    strict_slashes = True
    version = 1
    name = 'hello1'
    apply = True
    subprotocols = None
    websocket = True
    decorated_function = ()
    (routes, decorated_function) = route_mixin_0.route(uri, host, methods, strict_slashes, version, name, apply, subprotocols, websocket)
    print('-------------------------------')
    print('<output of test_RouteMixin_route>')
    print('-------------------------------')
    print(routes)
    print('\n')
    print(decorated_function)
    print('\n')
    print('-------------------------------')


# Generated at 2022-06-26 03:53:53.097914
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of class RouteMixin
    route_mixin_0 = RouteMixin()

    # Execute method add_route of the object route_mixin_0
    instance_method_0 = route_mixin_0.add_route(uri='/', host=None, strict_slashes=None, methods=None, version=None, name=None)
    # Assert the output of method 'add_route' equal to expected output
    assert not isinstance(instance_method_0, type(None))


# Generated at 2022-06-26 03:54:01.638759
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route("/users/<id>", "get", "/users/<id>", ["GET"], True, None, None, None, "/users/<id>", False, False, False, False, None, None, None, None)


# Generated at 2022-06-26 03:54:29.581050
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = 'foo'
    uri_0 = 'foo'
    methods_0 = ['GET', 'HEAD']
    host_0 = 'foo'
    strict_slashes_0 = True
    version_0 = 'foo'
    name_0 = 'foo'
    route_0 = route_mixin_0.add_route(handler_0,uri_0,methods_0,host_0,strict_slashes_0,version_0,name_0)
    assert isinstance(route_0, tuple)


# Generated at 2022-06-26 03:54:32.757713
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    add_route_handler = '''def handler(request):
    return text('OK')'''
    route_mixin_1.add_route(add_route_handler, uri='/hello')
    return route_mixin_1.router.routes_names


# Generated at 2022-06-26 03:54:37.205303
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    uri_1 = "/"
    methods_1 = [ "GET", "HEAD" ]
    handler_1 = None
    route_mixin_1.route(uri=uri_1, methods=methods_1)(handler_1)



# Generated at 2022-06-26 03:54:47.862992
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.is_DEBUG = False
    route_mixin_0.strict_slashes = None
    route_mixin_0.name = 'sanic.root'
    route_mixin_0.host = None
    route_mixin_0.methods = ['GET']
    route_mixin_0.uri = '/test'
    route_mixin_0.version = 1
    route_mixin_0.strict_slashes = False
    route_mixin_0.name = 'test'
    route_mixin_0.apply = True
    route_mixin_0.websocket = False
    route_mixin_0.stream = False
    route_mixin_0.static = False
    route_mixin_

# Generated at 2022-06-26 03:54:51.049957
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Simple test of inherited private method _add_route
    route_mixin_1 = RouteMixin()
    route_mixin_1._add_route(None, None)


# Generated at 2022-06-26 03:55:02.870180
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from .request import Request
    from .response import HTTPResponse

    route_mixin_0 = RouteMixin()
    # routes, handler = route_mixin_0.route(uri=uri_0, host=host_0, methods=methods_0, strict_slashes=strict_slashes_0, version=version_0, name=name_0, apply=apply_0)
    route_mixin_1 = RouteMixin()
    routes_1, handler_1 = route_mixin_1.route(uri=uri_1, host=host_1, methods=methods_1, strict_slashes=strict_slashes_1, version=version_1, name=name_1, apply=apply_1)

# Generated at 2022-06-26 03:55:12.085651
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    service = MagicMock()
    service.version = 0
    route_mixin_0.service = service
    handler = MagicMock()
    uri = "4:"
    host = None
    methods = ["GET", "HEAD"]
    strict_slashes = None
    version = None
    name = "urllib.request.pathname2url"
    route_mixin_0.add_route(handler, uri, host, strict_slashes, methods, version, name)


# Generated at 2022-06-26 03:55:19.091938
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # no argurments
    route_mixin_1 = RouteMixin()
    # test_case_1
    route_mixin_1 = RouteMixin()
    route_mixin_1.route()


# Generated at 2022-06-26 03:55:26.083639
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri = '1'
    methods = '2'
    host = '3'
    strict_slashes = True
    version = 4
    name = '5'
    apply = True
    subprotocols = '6'
    websocket = True
    deco = lambda x: x
    ret = route_mixin_0.route(uri, methods, host, strict_slashes, version, name, apply, subprotocols, websocket, deco)


# Generated at 2022-06-26 03:55:28.479401
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # This is an example.
    # assert route_mixin.add_route(url) == another_result

    test_case_0()

# Generated at 2022-06-26 03:55:49.437538
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_1 = RouteMixin()

    # normal case
    try:
        route_mixin_1.static("/", "/usr/local/")
        print("test case 1 : normal case")
    except Exception:
        print("test case 1 : exception")

    # abnormal case 1 : route_mixin_1.static("/", ["/usr/local/"])
    try:
        route_mixin_1.static("/", ["/usr/local/"])
        print("test case 2 : abnormal case 1")
    except Exception:
        print("test case 2 : exception")


if __name__ == "__main__":
    test_case_0()
    test_RouteMixin_static()

# Generated at 2022-06-26 03:55:54.381795
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route("/work/<workId>")


# Generated at 2022-06-26 03:55:58.112388
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler = request_handler_0, uri = '/api/user')


# Generated at 2022-06-26 03:56:09.174452
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    handler_0 = lambda x : print(x)
    uri_0 = '/'
    methods_0 = ['GET']
    name_0 = 'test'
    host_0 = 'localhost'
    strict_slashes_0 = True
    version_0 = 1
    expect_ret_0 = None
    ret_0 = route_mixin_1.add_route(
        handler_0,
        uri_0,
        methods_0,
        name_0,
        host_0,
        strict_slashes_0,
        version_0)
    assert ret_0 == expect_ret_0


# Generated at 2022-06-26 03:56:21.821887
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    file_or_directory = "."
    uri = "/static"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name="static"
    host=None
    strict_slashes=None
    content_type=None
    apply=True
    route_mixin_0 = RouteMixin()
    file_or_directory_cp = file_or_directory
    uri_cp = uri
    use_modified_since_cp = use_modified_since
    use_content_range_cp = use_content_range
    stream_large_files_cp = stream_large_files
    name_cp = name
    host_cp = host
    strict_slashes_cp = strict_slashes
    content_type_cp = content_type
    apply_

# Generated at 2022-06-26 03:56:26.021093
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    handler = route_mixin_0.route
    # TODO: implement the test
    assert False

# test_RouteMixin

# Generated at 2022-06-26 03:56:35.973263
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()


# Generated at 2022-06-26 03:56:44.096874
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Prepare mock data
    uri = 'some string'

    host = 'some string'
    methods = None
    strict_slashes = True
    version = 1
    name = 'some string'
    apply = True
    websocket = True
    subprotocols = 'some string'

    # Invoke method
    try:
        result = route_mixin_0.route(uri, host, methods, strict_slashes, version, name, apply, websocket, subprotocols)
    except Exception as e:
        print(e)
    else:
        pass


# Generated at 2022-06-26 03:56:46.558481
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route("/example", "example")


# Generated at 2022-06-26 03:56:58.296008
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test Case 1 - When all the values are passed and checks if it is able to return
    # the correct route

    uri = "/index"
    host = "global"
    strict_slashes = False
    name = "index"

    route_mixin_0 = RouteMixin()
    test_function_0 = lambda: test_function_0()
    route, _ = route_mixin_0.route(
        uri=uri,
        host=host,
        strict_slashes=strict_slashes,
        name=name,
    )(test_function_0)

    assert route.uri == uri
    assert route.host == host
    assert route.strict_slashes == strict_slashes
    assert route.name == name


# Generated at 2022-06-26 03:57:30.002943
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    uri = ""
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = "test_name"
    apply = True
    subprotocols = None
    websocket = True
    route_mixin_1 = RouteMixin()
    route_mixin_1.route(uri, host, methods, strict_slashes, version, name, apply, subprotocols, websocket)
    assert route_mixin_1 is not None


# Generated at 2022-06-26 03:57:30.767787
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    main()


# Generated at 2022-06-26 03:57:41.072314
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test data
    route_mixin_0 = RouteMixin()
    uri = "test string"
    methods = ["test string"]
    version = 1
    name = "test string"
    host = "test string"
    strict_slashes = True
    apply = True

    # Call method
    result = route_mixin_0.route(
        uri,
        methods,
        version,
        name,
        host,
        strict_slashes,
        apply,
    )

    assert isinstance(result, tuple)
    assert isinstance(result[0], list)
    assert isinstance(result[1], functools.partial)



# Generated at 2022-06-26 03:57:45.763938
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Case 0
    app = Sanic(__name__)
    @app.route("/")
    def handler(request):
        return text("Hey!")
    assert app.static("/static", "./static") # exception


# Generated at 2022-06-26 03:57:53.678269
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def test_handler_0(request, *args, **kwargs):
        return HTTPResponse(body=str(request.url))
    test_route_0 = route_mixin_0.add_route(
        uri="/test",
        host=None,
        strict_slashes=None,
        version=None,
        name=None,
        apply=True,
    )(test_handler_0)
    print(test_route_0)


# Generated at 2022-06-26 03:58:00.667438
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    route = route_mixin.route(uri="uri",
                              methods=["methods"], host="host",
                              strict_slashes=True,
                              version=1, name="name", apply=False,
                              static=True)
    def test_func(request):
        return "test_func"

    test_func_decorated = route(test_func)
    test_func_decorated(request="request")
    # Expect: test_func_decorated = route_mixin.route(uri="uri", method="methods", host="host",
    #                      strict_slashes=True, version=1, name="name", apply=False, static=True)(test_func)


# Generated at 2022-06-26 03:58:12.475864
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # The definition of the function is as follows:
    # def add_route(self, uri, methods, handler, host=None,
    # strict_slashes=None, version=None, name=None):
    # test 0
    uri = '/hello/'
    methods = None
    handler = None
    host = None
    strict_slashes = None
    version = None
    name = None
    try:
        route_mixin_0.add_route(uri, methods, handler, host,\
        strict_slashes, version, name)
    except:
        pass


# Generated at 2022-06-26 03:58:19.112517
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler=None, uri=None, host=None, strict_slashes=None, name=None, version=None)
    with pytest.raises(TypeError):
        route_mixin_1.add_route(handler=None, uri=None, host=None, strict_slashes=None, name=None, version=None)
    with pytest.raises(TypeError):
        route_mixin_1.add_route(handler=None, uri=None, host=None, strict_slashes=None, name=None, version=None)


# Generated at 2022-06-26 03:58:27.568261
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    version_0 = 1
    endpoint_0 = "example_endpoint"
    uri_0 = "example_uri"
    version_1 = 1
    endpoint_1 = "example_endpoint"
    uri_1 = "example_uri"
    assert isinstance(route_mixin_0.route(version=version_0, endpoint=endpoint_0, uri=uri_0, version=version_1, endpoint=endpoint_1, uri=uri_1), tuple)


# Generated at 2022-06-26 03:58:34.698280
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()

    # Testing for TypeError
    # File "/Users/raghav/Desktop/GitHub/sanic/sanic/router.py", line 823, in route
    # TypeError: <lambda>() takes 0 positional arguments but 1 was given
    try:
        route_mixin_0.route(uri = "/test_route", methods = ["GET", "POST"], name = "test_route_case_0", apply = True)(lambda : None)
    except TypeError:
        print("Method route test case 0 passed")
    else:
        print("Method route test case 0 failed")


# Generated at 2022-06-26 03:59:45.638559
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # [int, int]
    if __name__ == "__main__":
        route_mixin_0 = RouteMixin()
        add_route_method_0 = route_mixin_0.add_route
        uri_0 = "7"
        handler_0 = "8"
        handler_0 = handler_0
        uri_0 = uri_0
        handler_0 = handler_0
        host_0 = "9"
        host_0 = host_0
        handler_0 = handler_0
        handler_0 = handler_0
        handler_0 = handler_0
        strict_slashes_0 = "0"
        strict_slashes_0 = strict_slashes_0
        strict_slashes_0 = strict_slashes_0
        version_0 = "1"
        version

# Generated at 2022-06-26 03:59:52.095525
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    class TestClass_0():
        pass

    assert route_mixin_1.add_route(handler=TestClass_0(), uri="/", host=None, strict_slashes=None, method=None, version=None, name=None) is TestClass_0()


# Generated at 2022-06-26 04:00:03.684348
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    def handler_0(request, *args, **kwargs):
        return request
    routes_0 = route_mixin_0.add_route(handler_0, "uri_0", name="name_0")
    routes_1 = route_mixin_0.add_route(handler_0, "uri_1", name="name_1")
    assert isinstance(routes_0, list)
    assert isinstance(routes_1, list)
    route_0 = routes_0[0]
    route_1 = routes_1[0]
    # AssertionError: AssertionError('assert_route_has_expected_attributes')
    assert_route_has_expected_attributes(route_0)
    assert_route_has_expected_

# Generated at 2022-06-26 04:00:07.138097
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # initialize a router
    router = Router()
    router.add_route("/", handler, methods=["GET"], version=1)
    assert router.routes[0].uri == "/"



# Generated at 2022-06-26 04:00:13.640260
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    route_mixin_0 = RouteMixin()

    def add_route_handler(request):
        pass

    route_mixin_0.add_route(
        add_route_handler,
        uri="/test",
        methods=["GET"],
        host=None,
        strict_slashes=False,
        version=1,
        name="test",
    )


# Generated at 2022-06-26 04:00:19.817714
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    handler = lambda request, name: 'add_route test'
    route_mixin_1.add_route(handler, uri='/index', methods=['GET'], name='index')


# Generated at 2022-06-26 04:00:28.542445
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    method = route_mixin_0.route
    uri = "/"
    handler=test_case_0
    default1 = None
    middleware=test_case_0
    version=0
    name = "root"
    host = None
    strict_slashes=None
    methods = ["GET", "HEAD"]
    return_value = method(uri=uri, handler=handler, default=default1, middleware=middleware, version=version, name=name, host=host, strict_slashes=strict_slashes, methods=methods)
    assert return_value[0] == route
    assert return_value[1] == handler


# Generated at 2022-06-26 04:00:30.832648
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route('/')


# Generated at 2022-06-26 04:00:37.018248
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    app_0 = Sanic()
    uri_0 = "ayvIH"
    handler_0 = lambda : 0
    method_0 = "head"
    host_0 = "AyHxI"
    strict_slashes_0 = True
    version_0 = 8
    name_0 = "wVuLx"
    route_mixin_0.add_route(app_0, uri_0, handler_0, method_0, host_0, strict_slashes_0, version_0, name_0)
