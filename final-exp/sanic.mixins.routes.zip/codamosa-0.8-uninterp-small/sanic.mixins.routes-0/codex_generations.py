

# Generated at 2022-06-26 03:51:16.036028
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    with pytest.raises(TypeError, match="unexpected keyword argument 'empty_route'"):
        RouteMixin().add_route('/test_case_0', empty_route=Route.from_string('/test_case_0'))

################################################################################


# Generated at 2022-06-26 03:51:26.969590
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0, _ = route_mixin_0.route(uri = "/{name}", methods = None, strict_slashes = None, version = None, name = None, apply = True, websocket = False)(lambda name: None)
    route_1, _ = route_mixin_0.route(uri = ['/'], methods = None, strict_slashes = None, version = None, name = None, apply = True, websocket = False)(lambda: None)
    route_2, _ = route_mixin_0.route(uri = '/', methods = None, strict_slashes = None, version = None, name = None, apply = True, websocket = False)(lambda: None)

# Generated at 2022-06-26 03:51:34.666094
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = "J'Kf)MlZ[! M9n>YN"
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route("POST", "/open", None, True, [], [])


# Generated at 2022-06-26 03:51:46.557790
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = "`0(:6h]W8D.U6|gU6" # str_0 -> str
    route_mixin_0 = RouteMixin() # route_mixin_0 -> object
    method_0 = lambda x: None # method_0 -> function
    uri_arg_0 = "/ex/user/login" # uri_arg_0 -> str
    version_arg_0 = 2 # version_arg_0 -> int
    name_arg_0 = None # name_arg_0 -> NoneType
    route_0 = route_mixin_0.add_route(method_0, uri_arg_0, version_arg_0, name_arg_0) # route_0 -> object
    None_1 = route_mixin_0.register_route(route_0) # None_1

# Generated at 2022-06-26 03:51:56.607942
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # initialize parameters
    uri = "mzpy9D>g`qz@jv1:W.h^B*|w3#,&+xO=bT*G9h)Ls"
    methods = ["POST", "PUT"]
    url = "http://127.0.0.1:8000"
    version = 0
    name = "myFirstRoute"
    strict_slashes = False
    static = True
    host = "127.0.0.1"
    subprotocols = None
    websocket = True
    route_mixin_0 = RouteMixin()
    assert route_mixin_0.route(uri, methods, url, version, name, strict_slashes, static, host, subprotocols, websocket) == False


# Generated at 2022-06-26 03:52:01.837262
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = 'PV7`i{fz]V/'
    methods_1 = ['']
    host_0 = '@3q4>_?=1'
    strict_slashes_0 = '`]9.{fg<@'
    version_1 = ['1']
    name_1 = ''
    apply_0 = '6I43Q6^#'
    websocket_0 = '~;oa\x7f.z'
    # test that we get a Coroutine when the function is decorated by route

# Generated at 2022-06-26 03:52:09.758592
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = "J'Kf)MlZ[! M9n>YN"
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route(uri=str_0, handler=test_case_0, host=str_0, methods=None, name=str_0, strict_slashes=None, version=None)


# Generated at 2022-06-26 03:52:20.298793
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = "^Iq3'aV@1LFw>TLs7"
    route_mixin_0 = RouteMixin()
    route_mixin_0.add_route("Lz'Q2h>|87PjnwkPX", "U!qa6#M[FpBm0=40,")
    try:
        route_mixin_0.add_route("d2+![&%4!d:AF?#w", "N.F&+83.Nv`9J`W8M")
    except ValueError:
        passed = 0
    else:
        passed = 1
    assert (passed == 1)


# Generated at 2022-06-26 03:52:23.975984
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Init an object of class RouteMixin
    route_mixin_0 = RouteMixin()
    str_0 = "uV<O]@6pAq6.>J6 q"
    # Call method static of the object
    route_mixin_0.static(uri=str_0)


# Generated at 2022-06-26 03:52:28.947704
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    str_0 = "EXBhI"
    route_0 = Route()
    routes_0 = None
    route_mixin_0 = RouteMixin()
    routes_0 = route_mixin_0.add_route("J'Kf)MlZ[! M9n>YN", route_0)


# Generated at 2022-06-26 03:52:45.686998
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route('/post', methods=['POST'])
    route_mixin_0.route('/post', methods=['PUT'])



# Generated at 2022-06-26 03:52:58.169179
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()

    uri = "/"
    strict_slashes = False
    version = 0
    name = 'static'
    host = "localhost"
    methods = ["GET", "HEAD"]
    route, func = route_mixin.route(uri=uri, strict_slashes=strict_slashes,
                                version=version, name=name, apply=False,
                                host=host, methods=methods)
    assert route.is_static()
    assert route.strict_slashes == strict_slashes
    assert func.__name__ == "test_RouteMixin_route_wrapper"

test_RouteMixin_route()


# Generated at 2022-06-26 03:53:12.174823
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Sanic instance
    app_0 = Sanic()

    # Method instance
    handler_0 = partial(partial, app_0, strict_slashes=None, host=None, apply=True)
    handler_1 = app_0.route(uri=None, host=None, strict_slashes=None, methods=None, version=None, name=None, apply=True, websocket=True)
    handler_2 = app_0.add_route(uri='/', handler=None)

    # Argument values
    uri = '/'
    handler = None
    methods = ['GET']

    # Call method CALL_TARGET
    handler_2(uri=uri, handler=handler, methods=methods)

    # Output
    # app_0.router
    # app_0.router.routes_all


# Generated at 2022-06-26 03:53:15.526772
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.route(uri='/<path>',
                        host='<host>',
                        methods='<methods>',
                        strict_slashes='<strict_slashes>',
                        version='<version>',
                        name='<name>',
                        apply='<apply>',
                        websocket='<websocket>')


# Generated at 2022-06-26 03:53:23.953372
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    app = Sanic(__name__)

    @route_mixin.route( "uri=''", host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True, websocket=False)
    def case0(request):
        return request

    @route_mixin.websocket( "uri=''", host=None, strict_slashes=None, subprotocols=None, version=None, name=None)
    def case1(request):
        return request

    route_mixin.add_route( case0, uri='', host=None, methods=None, strict_slashes=None, version=None, name=None)


# Generated at 2022-06-26 03:53:30.760477
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin_0 = RouteMixin()
    route_mixin_0.static('/static', 'static/folder', 'static_handler', use_modified_since=True, use_content_range=False, stream_large_files=False, name='static', host=None, strict_slashes=None, content_type=None, apply=True)


# Generated at 2022-06-26 03:53:44.292357
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin = RouteMixin()
    uri = '/app/static'
    file_or_directory = '/tmp/test'
    pattern = r'/?.+'
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    route_mixin.static(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)


if __name__ == '__main__':

    logging.getLogger().setLevel(logging.DEBUG)
    # test_case_0()

    test_RouteMixin_

# Generated at 2022-06-26 03:53:49.579898
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()

    uri = str()
    methods = None
    handler = lambda x : x
    host = str()
    strict_slashes = bool()
    version = int()
    name = str()
    apply = bool()
    stream = bool()
    websocket = bool()
    expect_result = (list(), handler)
    actual_result_0 = route_mixin_0.route(uri, methods, handler, host, strict_slashes, version, name, apply, stream, websocket)
    assert actual_result_0==expect_result


# Generated at 2022-06-26 03:53:57.313074
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    print("route_mixin_0 = RouteMixin()")
    def handler_0(request, a_0, b_0, c_0=None):
        return HTTPResponse()

    print("route_mixin_0.add_route(handler_0, uri='/test/', methods=None, host=None, strict_slashes=None, version=None, name=None)")
    route_mixin_0.add_route(handler_0, uri='/test/', methods=None, host=None, strict_slashes=None, version=None, name=None)


# Generated at 2022-06-26 03:54:03.392578
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():    
    route_mixin = RouteMixin()
    route_mixin.add_route(handler = None, uri = '/api/test', methods = ['POST'], host = None, strict_slashes = False, version = None, name = None)


# Generated at 2022-06-26 03:54:22.539711
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route("/", "get", kwargs={"host": "127.0.0.1"})(lambda x: x)
    # print("\n", route_mixin_1)


# Generated at 2022-06-26 03:54:31.812976
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    route_mixin_1 = RouteMixin()
    handler1 = lambda request: "done"

    response = route_mixin_1.add_route(
        handler1, uri="/", host=None, strict_slashes=None, methods=["GET"], stream=None,
        version=None, name=None
    )

    # Test case 2
    route_mixin_2 = RouteMixin()
    handler2 = lambda request: "done"

    response = route_mixin_2.add_route(
        handler2, uri="/", host=None, strict_slashes=None, methods=["GET"], stream=None,
        version=None, name="test_case_2"
    )


# Generated at 2022-06-26 03:54:44.771344
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    apps = [
        {
            "name": "foobar",
            "uri": "foobar",
            "host": "localhost",
            "methods": "GET",
            "strict_slashes": False,
            "version": 2,
            "name": "test",
            "apply": True,
            "subprotocols": None,
            "websocket": False,
        },
        {
            "name": "foobar",
            "uri": "foobar",
            "host": "localhost",
            "methods": "GET",
            "version": 2,
            "name": "test",
            "apply": True,
            "subprotocols": None,
            "websocket": False,
        },
    ]
    # We can use the same handler, since this is merely registering the route

# Generated at 2022-06-26 03:54:51.740814
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # case 0
    route_mixin_0 = RouteMixin()

    uri_0 = '/'
    host_0 = '127.0.0.1'
    methods_0 = ['GET']
    strict_slashes_0 = True
    version_0 = 4
    name_0 = "route"
    apply_0 = True

    result_0 = route_mixin_0.add_route(uri_0, host_0, methods_0, strict_slashes_0, version_0, name_0, apply_0)
    assert result_0.__class__.__name__ == 'route'

    # case 1
    route_mixin_1 = RouteMixin()

    uri_1 = '/'
    host_1 = '127.0.0.1'

# Generated at 2022-06-26 03:55:03.103513
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()
    route_mixin_3 = RouteMixin()
    route_mixin_4 = RouteMixin()
    res = route_mixin_0.route(uri=1, methods=1, host=1, strict_slashes=1, version=1, name=1)
    # print("res:{}".format(res))
    assert res[0] == [], "expected: [], actual: " + str(res)
    res = route_mixin_1.route(uri="test", methods=1, host=1, strict_slashes=1, version=1, name=1)

# Generated at 2022-06-26 03:55:17.133725
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    url_for_ = url_for = route_mixin_1.url_for
    # if the value of the parameter route_name_or_id is not of type str, then an exception should be thrown
    route_name_or_id = None
    try:
        route_mixin_1.add_route(url_for_, route_name_or_id)
        assert False
    except Exception as ex:
        assert True
    # if the value of the parameter url_for_ is not of type str, then an exception should be thrown
    url_for_ = None
    try:
        route_mixin_1.add_route(url_for_, route_name_or_id)
        assert False
    except Exception as ex:
        assert True

# Unit

# Generated at 2022-06-26 03:55:23.023974
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.route(uri="/hello/", methods=None, strict_slashes=None,
                        name=None, host=None, subprotocols=None, version=None,
                        websocket=False, apply=True)


# Generated at 2022-06-26 03:55:28.049491
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route("/", handler)


# Generated at 2022-06-26 03:55:39.311459
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_0 = route_mixin_0.route("path")
    route_1 = route_mixin_0.route("path", host="host")
    route_2 = route_mixin_0.route("path", host="host", strict_slashes=False)
    route_3 = route_mixin_0.route("path", host="host", strict_slashes=False, methods=["method"])
    route_4 = route_mixin_0.route("path", host="host", strict_slashes=False, methods=["method"], version=0)
    route_5 = route_mixin_0.route("path", host="host", strict_slashes=False, methods=["method"], version=0, name="name")
    route_6 = route_mix

# Generated at 2022-06-26 03:55:51.758521
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def method_handler(request):
        return "OK"

    def handler_0(request):
        return "OK"

    uri_0 = "uri_0"
    host_0 = "host_0"
    strict_slashes_0 = True
    version_0 = 0
    name_0 = "name_0"
    methods_0 = ["method_0"]
    route_mixin_0 = RouteMixin()
    # create a new RouteMixin instance
    # which provides methods to handle routes

# Generated at 2022-06-26 03:56:12.840265
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    _handler = lambda x,y:'foo'
    route_0 = route_mixin_1.add_route("", _handler)
    assert(route_0.uri == "")
    assert(route_0.handler is _handler)


# Generated at 2022-06-26 03:56:21.316244
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a test route
    route_mixin_1 = RouteMixin()
    # Create a test handler
    test_handler_1 = lambda request: HTTPResponse("test_handler_1")

    # Test function add_route
    route, _ = route_mixin_1.add_route("/test_handler_1", "GET", test_handler_1)
    assert route.uri == "/test_handler_1"
    assert route.methods == ["GET"]


# Generated at 2022-06-26 03:56:30.831818
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route = MagicMock()
    route_mixin_0.route.return_value = (1, 2)

    host_0 = 'szs6s0'
    uri_0 = '4l4joc'
    methods_0 = (1, '6ao0o')
    strict_slashes_0 = 0.9691326692397311
    version_0 = '5r5m'
    name_0 = '8wv7'
    apply_0 = 'ug9'
    mock_0 = MagicMock(return_value=None)
    with patch('sanic.router.RouteMixin.add_route', new=mock_0):
        ret_0 = route_mixin_0.add_

# Generated at 2022-06-26 03:56:43.211355
# Unit test for method route of class RouteMixin

# Generated at 2022-06-26 03:56:52.687067
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    app_0 = Sanic("test")
    route_mixin_0 = RouteMixin()
    from sanic.router import Route
    route_mixin_0.router = Route(app_0, host=None)
    route_mixin_0.route("GET", "/", strict_slashes=True)(test2)
    assert route_mixin_0.router.routes_names["test2"] == "/"
    assert "GET" in route_mixin_0.router.routes


# Generated at 2022-06-26 03:57:02.690349
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    print("\n")
    print(route_mixin_1.add_route.__doc__)
    test_route_1 = route_mixin_1.add_route("/test1_route", None, host=None,
                                           strict_slashes=False,
                                           version=None, name="test1")
    print("\n")
    test_route_2 = route_mixin_1.add_route("/test2_route", None, host=None,
                                           strict_slashes=False,
                                           version=None, name="test2")
    print("\n")

# Generated at 2022-06-26 03:57:13.038232
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    response_0 = route_mixin_0.add_route(
        handler=dict(), uri='/routemixin/', methods=None, host=None, strict_slashes=None, version=None, name=None,
        stream=False)
    assert response_0 == route_mixin_0.route(
        uri='/routemixin/', methods=None, host=None, strict_slashes=None, version=None, name=None, apply=True,
        stream=False)


# Generated at 2022-06-26 03:57:24.413405
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0 = ''
    host_0 = ''
    methods_0 = ['GET']
    strict_slashes_0 = True
    version_0 = 0
    name_0 = 'test_name'
    apply_0 = True
    kwargs_0 = {}
    route_mixin_0.route(uri=uri_0, host=host_0, methods=methods_0, strict_slashes=strict_slashes_0, version=version_0, name=name_0, apply=apply_0, **kwargs_0)


# Generated at 2022-06-26 03:57:27.719194
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    tracer.start_span(name='test_RouteMixin_add_route')

    # Call method add_route of RouteMixin
    route_mixin_0.add_route(uri=None, methods=None, host=None, strict_slashes=None, version=None, name=None)


# Generated at 2022-06-26 03:57:40.690943
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()

    #case 1:
    # Unit test for method route of class RouteMixin when uri = "/"
    uri_0 = "/"

    # Unit test for method route of class RouteMixin when apply = True
    apply_0 = True

    # Unit test for method route of class RouteMixin when strict_slashes = None
    strict_slashes_0 = None

    # Unit test for method route of class RouteMixin when name = "home"
    name_0 = "home"

    # Unit test for method route of class RouteMixin when host = None
    host_0 = None

    # Unit test for method route of class RouteMixin when methods = None
    methods_0 = None

    # Unit test for method route of class RouteMixin when version = None

# Generated at 2022-06-26 03:57:58.194311
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    uri_1 = '/a-resource'
    handler_1 = lambda: None
    method_1 = 'POST'
    route_mixin_1.add_route(uri_1, handler_1, methods=method_1)
    assert isinstance(route_mixin_1, RouteMixin)
    assert route_mixin_1.routes[0].uri == uri_1
    assert route_mixin_1.routes[0].handler == handler_1
    assert route_mixin_1.routes[0].methods == [method_1]


# Generated at 2022-06-26 03:58:11.116519
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    try:
        route_mixin_0 = RouteMixin()
        assert(route_mixin_0 != None)
        assert(isinstance(route_mixin_0, RouteMixin))
    except AssertionError:
        print('AssertionError raised in RouteMixin.__init__ testcase')
        return

    try:
        # testcase 1
        methods_0 = None
        route_mixin_0.route(uri='/users/<id:int>', methods=methods_0)
        assert(True)
    except Exception:
        print('Exception raised in RouteMixin.route testcase 1')
        return
    print('testcase 1 passed')


# Generated at 2022-06-26 03:58:18.712894
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    uri_0    = '/test/<param>'
    method_0 = 'GET'
    version_0 = 1.0
    route_0  = route_mixin_0.route(uri=uri_0, methods=method_0, version=version_0)
    assert route_0.uri == uri_0
    assert not route_0.subdomain
    assert route_0.methods == [method_0]
    assert route_0.version == version_0
    assert not route_0.host
    assert not route_0.strict_slashes
    assert not route_0.name
    assert route_0.is_dynamic
    assert route_0.route_func == route_mixin_0.route_func

# Generated at 2022-06-26 03:58:29.080756
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    global route_mixin_0, route_mixin_1, route_mixin_2, handler_0, handler_1, handler_2, handler_3
    # TODO:
    route_mixin_0 = RouteMixin()
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()
    def handler_0(request):
        assert request.args == {"greeting": "hello"}
        return HTTPResponse(200)
    def handler_1(request):
        assert request.args == {"greeting": "hello"}
        return HTTPResponse(200)
    def handler_2(request):
        return HTTPResponse(200)
    def handler_3(request):
        return HTTPResponse(200)

# Generated at 2022-06-26 03:58:36.432524
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
    Unit test for method "route" of class RouteMixin
    """
    route_mixin_1 = RouteMixin()
    # Case 1
    # If a handler is a function that does not exist, then
    # the call to "route" fails.
    try:
        route_mixin_1.route(handler=non_existing_function)
    except NameError as e:
        print(e)

    # Case 2
    # If a handler is a function that exists and has no parameters, then
    # the call to "route" succeeds.
    route_mixin_1.route(handler=func_1)

    # Case 3
    # If a handler is a function that exists and has parameters with default values, then
    # the call to "route" succeed.

# Generated at 2022-06-26 03:58:38.777930
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route()


# Generated at 2022-06-26 03:58:44.477719
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_1 = RouteMixin()
    uri_1 = "/list/<param>"
    host_1 = None
    strict_slashes_1 = None
    methods_1 = ["POST"]
    version_1 = 1
    name_1 = None
    apply_1 = True
    cors_1 = None
    stream_1 = False
    static_1 = False
    websocket_1 = False
    subprotocols_1 = None

# Generated at 2022-06-26 03:58:56.361172
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin = RouteMixin()
    uri = "abc"
    static_file = PurePath("/tmp/")
    pattern = "abc"
    use_modified_since = True
    use_content_range = True
    stream_large_files = True
    name = "def"
    host = "ghi"
    strict_slashes = True
    content_type = "jkl"
    route_mixin.static(uri, static_file, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type)

# Generated at 2022-06-26 03:58:59.411045
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()
    route_mixin_0.route(uri="/", methods="GET")


# Generated at 2022-06-26 03:59:04.294273
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_1.add_route(handler=None, uri='/', host='a', methods=['GET'], 
            strict_slashes=None, version=None, name='abc', stream=True)


# Generated at 2022-06-26 03:59:19.933299
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    route_mixin_2 = RouteMixin()
    route_mixin_3 = RouteMixin()
    route_mixin_1.add_route("hello")

    if len(route_mixin_1.routes) != 1:
        raise ValueError("RouteMixin.add_route returns wrong result")



# Generated at 2022-06-26 03:59:26.321419
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin = RouteMixin()
    route_mixin.route(
        uri="",
        methods=None,
        host=None,
        strict_slashes=None,
        version=None,
        name=None,
        static=False,
        stream=None,
        apply=True,
        websocket=False,
        subprotocols=None,
    )


# Generated at 2022-06-26 03:59:37.486617
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_add_route_0 = RouteMixin()
    route_mixin_add_route_0.add_route(route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0, route_mixin_add_route_0)


# Generated at 2022-06-26 03:59:43.385121
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_1 = RouteMixin()
    def _handler_1(req):
        return ('return value of _handler_1')
    route_mixin_1.add_route(_handler_1, '/test_route_1', methods=None, host=None, 
                    strict_slashes=False, stream=False, version=None, name=None)
    # assert (route_mixin_1.routes!=None)


# Generated at 2022-06-26 03:59:53.085180
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
	route_mixin_0 = RouteMixin()
	route_mixin_0.route(uri = '/', methods = None, version = None, strict_slashes = True, name = 'index', apply = True, websocket = False, host = None)
	route_mixin_0.add_route(handler = None, uri = '/trends', host = None, methods = None, strict_slashes = None, version = None, name = 'trends')


if __name__ == "__main__":
	test_case_0()

# Generated at 2022-06-26 04:00:00.879015
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # setup
    route_mixin = RouteMixin()
    uri = '/'
    handler = ""
    host = ""
    strict_slashes = ""
    version = ""
    name = ""
    methods = ""
    expect = ""
    
    # exercise
    route_mixin.add_route(uri, handler, host, strict_slashes, version, name, methods)
    
    # verify
    assert "" == expect
    
    # cleanup - none
    

# Generated at 2022-06-26 04:00:05.761015
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    handler_0 = partial(sanic.request, "GET", uri="/foo", strict_slashes=None, version=None)
    uri = "foo"
    host = None
    strict_slashes = None
    version = None
    name = None

    results = route_mixin_0.add_route(handler_0, uri, host, strict_slashes, version, name)
    assert results != None


# Generated at 2022-06-26 04:00:11.744700
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route_mixin_0 = RouteMixin()

    def handler_0(request, *args, **kwargs):
        return request

    try:
        route_mixin_0.route("/", strict_slashes=None)(handler_0)

        assert False
    except TypeError:
        assert True


# Generated at 2022-06-26 04:00:22.074681
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    endpoint_0 = 'handler'
    uri_0 = '/post'
    host_0 = '0.0.0.0'
    methods_0 = ['GET', 'POST']
    host_1 = None
    strict_slashes_0 = True
    version_0 = 1
    name_0 = 'post'
    route_mixin_0.add_route(endpoint_0, uri_0, host_0, methods_0, host_1, strict_slashes_0, version_0, name_0)


# Generated at 2022-06-26 04:00:30.139388
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin_0 = RouteMixin()
    # test case 1:
    route_mixin_0.add_route( "", "", "", "", "", "")
    # test case 2:
    route_mixin_0.add_route( "", "", "", "", "", "")
    # test case 3:
    route_mixin_0.add_route( "", "", "", "", "", "")
    # test case 4:
    route_mixin_0.add_route( "", "", "", "", "", "")
    # test case 5:
    route_mixin_0.add_route( "", "", "", "", "", "")
    # test case 6: