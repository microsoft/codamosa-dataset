

# Generated at 2022-06-21 23:26:14.901784
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic("test_RouteMixin")
    app.blueprint(Blueprint("test_RouteMixin"))
    app._route_class = lambda *args, **kwargs: app._router.add(*args, **kwargs)
    app.route("/")(lambda _: _)
    app.route("/", methods=["GET", "POST"])(lambda _: _)
    app.route("/post", methods=["POST"])(lambda _: _)
    app.get("/get")(lambda _: _)
    app.head("/head", strict_slashes=True)(lambda _: _)
    app.options("/options")(lambda _: _)
    app.patch("/patch")(lambda _: _)

# Generated at 2022-06-21 23:26:24.992819
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.request import Request
    options = RouteMixin().options
    r1 = Route(None, None, None, None, '/', 'GET', None, None)
    r2 = Route(None, None, None, None, '/', 'GET', None, None)
    r3 = Route(None, None, None, None, '/', 'GET', None, None)
    r4 = Route(None, None, None, None, '/', 'GET', None, None)
    r5 = Route(None, None, None, None, '/', 'GET', None, None)
    r6 = Route(None, None, None, None, '/test_r6', 'GET', None, None)

# Generated at 2022-06-21 23:26:36.815519
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    app = Sanic('test_RouteMixin_head')
    class RouteMixinMock():
        def __init__(self, app):
            self.app = app
            self.routes = []
            self.version = 1
            self.strict_slashes = True
            self.websocket_enabled = False
    route_mixin = RouteMixinMock(app)
    @route_mixin.head("/")
    def handler1(request): pass
    @route_mixin.head("/", strict_slashes = False)
    def handler2(request): pass
    @route_mixin.head("/", version = 2)
    def handler3(request): pass
    @route_mixin.head("/", name = 'test_head')
    def handler4(request): pass

# Generated at 2022-06-21 23:26:40.432086
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Set up object
    obj1 = RouteMixin()
    # Assign values to instance attributes of object
    obj1.strict_slashes = True

    # Call method post of class RouteMixin
    obj1.post(
        uri=uri,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        version=version,
        name=name,
        apply=apply,
    )


# Generated at 2022-06-21 23:26:43.815288
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Create a variable of the class RouteMixin with name route_mixin_instance
    route_mixin_instance = RouteMixin()
    # Try if the route_mixin_instance is a instance of RouteMixin
    assert isinstance(route_mixin_instance, RouteMixin)
    # Try if the method post of the class RouteMixin is callable
    # (if the method exists)
    assert callable(route_mixin_instance.post)


# Generated at 2022-06-21 23:26:48.215981
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic import Sanic


    app = Sanic()

    with pytest.raises(Exception):
        app.post()

# Generated at 2022-06-21 23:26:52.812647
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    with pytest.raises(AttributeError):
        async def test(request):
            return text("Hello, world")
        RouteMixin.add_route(test, '/', methods='OPTIONS')

# Generated at 2022-06-21 23:27:00.477203
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    d = {}
    d['url'] = "string"
    d['endpoint'] = "string"
    d['route'] = "string"
    d['strict_slashes'] = False
    d['host'] = "string"
    d['methods'] = "string"
    d['status'] = "string"
    d['stream'] = False
    d['version'] = 1
    d['websocket'] = False
    d['name'] = "string"
    d['static'] = False
    d['apply'] = False
    d['uri_template'] = "string"
    d['formatter'] = {}
    d['args'] = "string"
    r = Route(**d)
    assert r.delete() == None


# Generated at 2022-06-21 23:27:06.547855
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    router = Router()
    uri = "/get"
    method = "GET"
    handler = router.get(uri)
    assert router._routes[method][0].uri == uri
    assert router._routes[method][0].handler is handler
    assert router._routes[method][0].method == method


# Generated at 2022-06-21 23:27:11.650753
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    r = RouteMixin()

    @r.websocket('/join', name='join', strict_slashes=False)
    async def join(request, ws):
        pass

    assert isinstance(r.add_websocket_route(join, '/join', strict_slashes=False), join)
    
    


# Generated at 2022-06-21 23:27:29.541066
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    app = Sanic('test')

    @app.route('/')
    def handler(request):
        return text('OK')


    @app.websocket('/feed')
    async def feed(request, ws):
        while True:
            data = 'hello!'
            print('Sending: ' + data)
            await ws.send(data)
            data = await ws.recv()
            print('Received: ' + data)


    app.run(debug=True)


# Generated at 2022-06-21 23:27:34.334834
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    hoge = RouteMixin()
    class Hogehoge:
        pass
    hogehoge = Hogehoge
    def hoge_handler(request, name):
        pass
    hoge_handler = hoge_handler
    hoge.post(uri="uri", methods=["methods"], host="host", strict_slashes=True, version=1, name="name", apply=True, subprotocols=["subprotocols"], websocket=True)(hoge_handler)
    hoge.add_websocket_route(handler=hogehoge, uri="uri", host="host", strict_slashes=True, subprotocols=["subprotocols"], version=1, name="name")

# Generated at 2022-06-21 23:27:38.057953
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    routeMixin = RouterMixin()
    # Test case 1
    assert callable(routeMixin.get) == True
    # Test case 2
    assert callable(routeMixin.get("uri")) == True
    # Test case 3
    assert callable(routeMixin.get("uri", version=1)) == True
    # Test case 4
    assert callable(routeMixin.get("uri", version=1, strict_slashes=True)) == True
    # Test case 5
    assert callable(routeMixin.get("uri", version=1, strict_slashes=True, name="name")) == True



# Generated at 2022-06-21 23:27:44.573482
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    test = RouteMixin()
    test.register_route()
    test.register_listener()
    test.register_middleware()
    test.register_exception()
    test.route()
    test.listener()
    test.middleware()
    test.exception()
    test.websocket()
    test.websocket()
    test.add_websocket_route()
    test.add_websocket_route()
    test.static()
    test.static()
    test.static()
    test._generate_name()
    test._static_request_handler()
    test._register_static()


if __name__ == "__main__":
    test_RouteMixin()

# Generated at 2022-06-21 23:27:57.302805
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_RouteMixin_websocket")
    uri = "/test_RouteMixin_websocket/"
    strict_slashes = None
    version = None
    name = app.name + ".test_RouteMixin_websocket"
    subprotocols = None
    apply = True

    @app.websocket(uri, strict_slashes, version, name)
    async def test(request, ws):
        pass

    # check return value
    assert test.__name__ == "test"
    assert type(test) == Route
    assert test.uri == uri
    assert test.host == None
    assert test.methods == [WebSocketProtocol]
    assert test.strict_slashes == strict_slashes


# Generated at 2022-06-21 23:28:10.087977
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.response import HTTPResponse

    app = Sanic()
    @app.route('/')
    def handler(request):
        return HTTPResponse(text='OK')
    assert handler.__name__ == 'handler'
    app_route = app.router._routes['GET'][0]
    assert len(app.router._routes['GET']) == 1
    assert app.router._routes['GET'][0].uri == '/'
    assert len(app.router._routes['HEAD']) == 1
    assert app.router._routes['HEAD'][0].uri == '/'
    handler = app._run_route('GET', '/')
    assert handler.__name__ == 'handler'

# Generated at 2022-06-21 23:28:16.080694
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    route_mixin = RouteMixin()
    # Test that the the method options of class RouteMixin is working properly
    def get_handler(request):
        return
    assert route_mixin.options('hello', host='localhost')(get_handler)


# Generated at 2022-06-21 23:28:16.880397
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    pass


# Generated at 2022-06-21 23:28:26.961460
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    print("Testing put")
    test_router = Router()
    uri = "/"
    handler = None
    host = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    test_router.put(uri=uri, host=host, strict_slashes=strict_slashes, version=version, name=name, apply=apply)
    assert True


# Generated at 2022-06-21 23:28:34.640627
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    """
    Test method websocket of class RouteMixin
    """
    # No parameters test case
    router = RouterMixin()
    component = router.websocket()
    assert component

    # One parameter test case
    component = router.websocket(None)
    assert component


# Generated at 2022-06-21 23:28:51.720567
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    class A:
        def __init__(self):
            self.a = 1

        def websocket(self, x: str, y: int) -> int:
            pass

    a = A()

    @a.websocket("/test", name="test", host="localhost")
    def handler(request, x: str, y: int):
        return 3

    assert a.a == 1
    assert handler(None, "a", 1) == 3
    
    

# Generated at 2022-06-21 23:29:02.320246
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    def test_RouteMixin_delete_0():
        """
        If a route is not found, delete() should return None
        """
        class _FakeRoute:
            def __init__(self):
                pass
        r = _FakeRoute()
        self = api.RouteMixin()
        url = 'test url'
        self.routes = {'test': r}
        assert self.delete(url) == None

    def test_RouteMixin_delete_1():
        """
        If a route is found, delete() should delete the route from `routes`
        and return a tuple containing the route and its name
        """
        class _FakeRoute:
            def __init__(self):
                self.name = 'test name'
        r = _FakeRoute()
        self = api.RouteMixin()
       

# Generated at 2022-06-21 23:29:14.353445
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from .router import Route

    def handler():
        pass

    uri = '/uri'
    host = 'host'
    strict_slashes = False
    stream = None
    version = 'version'
    name = 'name'
    apply = True

    mixin = RouteMixin()
    result = mixin.put(uri, host, strict_slashes, stream, version, name, apply)

    assert hasattr(result, "routes")
    assert isinstance(result.routes, list)
    assert isinstance(result.routes[0], Route)
    assert result.routes[0].uri == uri
    assert result.routes[0].host == host
    assert result.routes[0].strict_slashes == strict_slashes

# Generated at 2022-06-21 23:29:26.537657
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    request = Request("GET", "/test_route", Host("localhost", 8080),
                      Version(1, 1), EmptyContent(), EmptyHeader(), EmptyHeader(), EmptyBody())
    # None
    app = RouteMixin()
    uri, methods, strict_slashes, version, name, apply, static = None, None, None, None, None, None, None
    _method = app.route(uri, methods, strict_slashes, version, name, apply, static)
    assert not _method
    # empty
    app = RouteMixin()
    uri, methods, strict_slashes, version, name, apply, static = (), (), (), (), (), (), ()
    _method = app.route(uri, methods, strict_slashes, version, name, apply, static)
    assert not _method
    # valid
    app = RouteMixin()

# Generated at 2022-06-21 23:29:29.659550
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # Create parameter
    uri = 'api/get'
    # Create instance of class RouteMixin
    route_mixin = RouteMixin()
    # Call method get and return result
    return route_mixin.get(uri=uri)

# Generated at 2022-06-21 23:29:31.517784
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    pass

# Generated at 2022-06-21 23:29:43.000550
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # Ensure that the test name is composed of the class name and the method
    # being tested.
    assert str(inspect.stack()[0][3]) == 'test_'+class_name+'_'+inspect.stack()[0][3]


# Generated at 2022-06-21 23:29:50.815396
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    status = Status.OK
    response_headers = [("content-type", "text/plain")]
    response_content = b"text"
    out = route_mixin.post("/post", name="post")(
        partial(
            function_handler,
            status=status,
            response_headers=response_headers,
            response_content=response_content,
        )
    )
    assert status == out.status
    assert response_headers == out.response_headers
    assert response_content == out.response_content


# Generated at 2022-06-21 23:29:52.169499
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    route_mixin = RouteMixin()

    assert isinstance(route_mixin, RouteMixin)


# Generated at 2022-06-21 23:29:58.102977
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic, response
    from sanic.exceptions import MethodNotSupported
    
    app = Sanic(__name__)

    @app.route("/", methods=["GET","POST"])
    def test1(request):
        return response.text("OK")
    
    app.test_client.get("/")
    
    assert list(app.url_map._rules_by_endpoint.keys()) == ["test1"]

# Generated at 2022-06-21 23:30:14.850552
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    import warnings
    warnings.warn = lambda *args, **kwargs: None # ignore all warnings
    app = Sanic('test_RouteMixin_delete')
    results = []
    @app.delete('/')
    async def test(request):
        return text('OK')
    app.run(port=None)
    assert results[0] == 'OK'


# Generated at 2022-06-21 23:30:18.520131
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    b = RouteMixin()
    b.route("/test")


# Generated at 2022-06-21 23:30:24.555029
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    app = Sanic("test_RouteMixin_options")
    options = app.options("/test", name="test")

    assert options.rule == "/test"
    assert options.name == "test"
    assert options.host is None
    assert options.strict_slashes is None
    assert options.version is None


# Generated at 2022-06-21 23:30:35.701069
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    with Sanic('test_RouteMixin_add_route') as app:
        app.config.KEEP_ALIVE = False
        app.config.REQUEST_TIMEOUT = 30
        app.config.RESPONSE_TIMEOUT = 30

        @app.route('/test_RouteMixin_add_route')
        async def handler(request):
            return response.text('OK')

        request, response = app.test_client.get('/test_RouteMixin_add_route')
        assert response.text == 'OK'


# Generated at 2022-06-21 23:30:46.176888
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    main = Blueprint("main")
    main.add_route(handler, "/", methods=["GET"])
    async def handler(request):
        return response.text("I am a get method")
    request, response = get_test_context("/", method="GET")
    message = response.body
    expected_output = b"I am a get method"
    assert message == expected_output
    expected_output = ["main"]
    assert request.blueprint_name in expected_output
    assert request.blueprint_name in expected_output


# Generated at 2022-06-21 23:31:00.265410
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.router import Route
    from sanic.router import RouteExists as RouteExists
    from sanic.router import RouteDoesNotExist as RouteDoesNotExist
    from sanic.router import RouteReset as RouteReset

    from sanic.router import Router as Router
    from sanic.router import RouteExists as RouteExists
    from sanic.router import RouteReset as RouteReset
    def test_get():
        pass
    def test_post():
        pass

    @asyncio.coroutine
    def handler(*args, **kwargs):
        pass


# Generated at 2022-06-21 23:31:03.375128
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint.create("Test_websocket")

    
    blueprint.websocket(
        uri = "/",
        host = None,
        strict_slashes = None,
        subprotocols = None,
        version = None,
        name = "middle",
        apply = True,
    )
    
    # assert blueprint.router.routes[0].name == "middle"
    

# Generated at 2022-06-21 23:31:10.138696
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # Static directory test
    sanic_app = Sanic("sanic-test")
    router = Router()
    prefix = ""
    version = 1
    router._apply_static = lambda x: x
    router.static("/static", "./", version=version, name="static_test")
    assert "static_test-1" in router.url_map._rules_by_endpoint



# Generated at 2022-06-21 23:31:21.847209
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    @app.route('/')
    def hello_world():
        return text('Hello world!')

    @app.middleware('request')
    async def print_on_request(request):
        print('I print on request!')

    @app.middleware('response')
    async def print_on_response(request, response):
        print('I print on response!')

    @app.exception(InvalidUsage)
    def handle_invalid_usage(request, exception):
        return text("You did it wrong!", status=404)

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    @app.get('/')
    async def handler(request):
        raise NotFound


# Generated at 2022-06-21 23:31:24.879318
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    assert RouteMixin(__name__)


# Generated at 2022-06-21 23:31:38.859303
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    try:
        server = Sanic('test')
        route = RouteMixin()
        route.get(None, None)
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-21 23:31:45.456519
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from inspect import signature
    from .views import SynchronousView
    app = Sanic(__name__)
    class MyView(SynchronousView):
        methods=['POST']
        url='/'

        def post(self, request):
            return 'ok'
    view = MyView.as_view()
    app.add_route(view.get_method(), '/', view)
    #Test ArgumentError
    try:
        view()
    except ArgumentError:
        pass
    #Test ArgumentError
    try:
        view(app)
    except ArgumentError:
        pass

    assert len(signature(view.get_method()).parameters) == 2
    assert view(app) == 'ok'
    #Test request

# Generated at 2022-06-21 23:31:46.571500
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-21 23:31:51.218144
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    @sanic.blueprints.Blueprint.listener("before_register")
    def stub_before_register_route_mixin(bp, app):
        bp.route(bp.name, bp.name)(lambda req: "ok")


# Generated at 2022-06-21 23:31:56.934219
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    names = [['route'], ['route_static'], ['static_route'], ['static_static']]

    for name in names:
        mixin = RouteMixin(name=name)
        assert isinstance(mixin, RouteMixin)

# Generated at 2022-06-21 23:31:59.429183
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    routeMixin = RouteMixin()
    options = routeMixin.options()
    assert(options["strictSlash"] == True)
    options = routeMixin.options(strictSlash=False)
    assert(options["strictSlash"] == False)


# Generated at 2022-06-21 23:32:04.757874
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    expected_result1=[Route(uri='/', methods=[{'PUT'}], strict_slashes=False, host=None, version=None, name=None, handler=None, websocket=False, static=False), HTTPResponse(body=b'OK', status=200, headers={}, content_type='text/html; charset=utf-8')]

    expected_result2=[Route(uri='/', methods=[{'PUT'}], strict_slashes=False, host=None, version=None, name=None, handler=None, websocket=False, static=False), HTTPResponse(body=b'OK', status=200, headers={}, content_type='text/html; charset=utf-8')]


# Generated at 2022-06-21 23:32:07.102137
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_RouteMixin_head')
    RouteMixin(app).head('foo')(text('OK'))

    request, response = app.test_client.head('/foo')

    assert response.text == 'OK'
    assert response.status == 200



# Generated at 2022-06-21 23:32:18.820256
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # create a instance of the class RouteMixin
    mixin = RouteMixin()
    # create a instance of the class RequestParameters
    request_parameters = RequestParameters()
    # create a instance of the class UrlParameters
    url_parameters = UrlParameters(None, None)

    # test route() method under the condition that uri is a str
    # set the default value
    uri = "/testMixin/testMixin"
    pattern = r"/testMixin/\w*"
    methods = ["GET", "POST"]
    strict_slashes = True
    host = "127.0.0.1"
    origin = "127.0.0.1"
    version = 1
    blueprint = None
    strict_slashes = True
    name = "/testMixin/testMixin"
    status_

# Generated at 2022-06-21 23:32:28.000808
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Create instance of RouteMixin
    test_instance = RouteMixin()

    # Assert that there are no static routes yet
    assert len(test_instance._static_routes) == 0

    # Assert that there are no future static routes yet
    assert len(test_instance._future_statics) == 0

    # Add a static route

# Generated at 2022-06-21 23:33:03.026943
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    import sanic_route

    # Test for the route method of class RouteMixin
    async def test():
        r = sanic_route.RouteMixin()
        r.strict_slashes = False
        rt, h = r.route("/test", version=1)(lambda x: 1)
        rt2, h2 = r.route("/test2", version=2)(lambda x: 2)
        r.add_route(rt)
        r.add_route(rt2)
        hh = r.head("/test")(h)
        r.add_route(hh)
        # Test for the head method of class RouteMixin
        hhh = r.head("/test2")(h)
        r.add_route(hhh)

# Generated at 2022-06-21 23:33:06.652703
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    options = RouteMixin.options()
    assert isinstance(options, List[Route])
    assert len(options)==1
    assert options[0].uri == '__routes__'


# Generated at 2022-06-21 23:33:11.756172
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic('test_RouteMixin_delete')
    test_route = Route(app, "/", True)
    try:
        assert not test_route.delete()
        raise
    except TypeError:
        return

# Generated at 2022-06-21 23:33:20.151386
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic.response import json

    app = Sanic("test")

    # =======================
    # 1. post() 
    # =======================
    # 1.1
    @app.post("/")
    async def handler(request):
        return json("OK")
    assert hasattr(handler, "_route")

    # 1.2
    @app.post("/post/")
    async def handler(request):
        return json("OK")
    assert hasattr(handler, "_route")

    # 1.3
    @app.post("/post/sub/")
    async def handler(request):
        return json("OK")
    assert hasattr(handler, "_route")

    # 1.4

# Generated at 2022-06-21 23:33:31.187929
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    import logging
    logging.getLogger().setLevel(logging.DEBUG)
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from service.main import app
    from service.main import static

    from unittest import TestCase, main
    from IPython import embed
    from loguru import logger
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteParameters
    from sanic.router import build_url

    from sanic.router import RouterMixin
    from sanic.router import RouteMixin


# Generated at 2022-06-21 23:33:41.688119
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    uri = "test_route_mixin_head"
    version = "test_route_mixin_head"
    name = "test_route_mixin_head"
    strict_slashes = "test_route_mixin_head"
    host = "test_route_mixin_head"
    apply = "test_route_mixin_head"

    @head(uri=uri, version=version, name=name, strict_slashes=strict_slashes, host=host, apply=apply)
    def handler_test_route_mixin_head():
        return "test_route_mixin_head"

    assert handler_test_route_mixin_head() == "test_route_mixin_head"

# Generated at 2022-06-21 23:33:53.016311
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic("test_RouteMixin_delete")
    mixin = RouteMixin()
    mixin.sanic = app
    # Case:1
    res = mixin.delete("/test")(lambda: "test")
    obj = app.router.routes_all["DELETE"][-1]
    assert obj.uri=="/test"

    # Case:2
    mixin.delete("/test/<param>/<param2>")(lambda: "test")
    obj = app.router.routes_all["DELETE"][-1]
    assert obj.uri=="/test/<param>/<param2>"

    # Case:3
    mixin.add_delete_route("/test/<param>/<param2>", lambda: "test")
   

# Generated at 2022-06-21 23:34:00.125214
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    with pytest.raises(ValueError):
        RouteMixin.options(['options'])
    
    with pytest.raises(ValueError):
        RouteMixin.options(1, handler=None)

    @RouteMixin.options(1)
    def ok():
        pass

    @RouteMixin.options(1, name='test_options')
    def ok2():
        pass

    @RouteMixin.options(1, version=1, name='test_options')
    def ok2():
        pass

    @RouteMixin.options(1, strict_slashes=1, name='test_options')
    def ok2():
        pass

    @RouteMixin.options(1, host='1', name='test_options')
    def ok2():
        pass


# Generated at 2022-06-21 23:34:05.300822
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    server = app.Sanic(__name__)
    server.static(uri='/', file_or_directory='/')
    assert ('/' in server.routes_names['static']) == True


# Generated at 2022-06-21 23:34:13.091041
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    uri = 'index'
    host = 'localhost'
    methods = ['POST']
    strict_slashes = True
    version = None
    name = None
    apply = True
    function = None
    websocket = False
    RouteMixin_test = RouteMixin()
    RouteMixin_test.route(uri, host, methods, strict_slashes, version, name, apply, websocket)


# Generated at 2022-06-21 23:35:07.175002
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    pass


# Generated at 2022-06-21 23:35:12.134424
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # Testing class RouteMixin
    # method get
    if isinstance(self, self.__class__):
        self.route(uri='/', methods=['GET'])
    assert True == True # TODO: implement your test here


# Generated at 2022-06-21 23:35:19.089485
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    """
    Unit test for method static of class RouteMixin
    """
    def _test_route_mixin_static_file_or_directory_str():
        """
        Test for file_or_directory is a str
        """
        route_mixin = RouteMixin()
        file_or_directory = "dummy_path"
        uri = "dummy_uri"
        pattern = ".*"
        use_modified_since = True
        use_content_range = False
        stream_large_files = False
        name = "dummy_name"

# Generated at 2022-06-21 23:35:28.098189
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.router import Route
    
    router = RouteMixin()
    
    #case 1
    uri = "a"
    strict_slashes = True
    version = 1
    name = "_a"
    host = "127.0.0.1"
    subprotocols = None
    apply = True
    
    router.head(
        uri = uri, 
        host = host, 
        strict_slashes = strict_slashes, 
        subprotocols = subprotocols, 
        version = version, 
        name = name, 
        apply = apply, 
    )
    
