

# Generated at 2022-06-21 23:26:02.315603
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    """Unit test for method static of class RouteMixin."""
    
    # Arrange
    r = RouteMixin()
    uri = '/test'
    file_or_directory = './test'
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    
    # Act

# Generated at 2022-06-21 23:26:11.899259
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.app import Sanic
    app = Sanic("test_RouteMixin_put")
    routes = app.put("/", host="example.com", version=2, name="test_put")
    assert routes[0].uri == "/"
    assert routes[0].name == "test_put"
    assert routes[0].version == 2
    assert "example.com" in routes[0].hosts
    assert routes[0].handler is None
    assert routes[0].static is False
    assert routes[0].strict_slashes is None
    assert routes[0].host is None
    assert routes[0].methods[0] == "PUT"


# Generated at 2022-06-21 23:26:19.971555
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    # initialize an instance
    sanic_ins = Sanic(__name__)

    # call the method
    ret = sanic_ins.delete('/a/path', version=1)
    # verify
    assert ret == ('/a/path', ['DELETE'], 1, None, True, False)

# Generated at 2022-06-21 23:26:20.932449
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass

# Generated at 2022-06-21 23:26:23.766511
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    route = RouteMixin()
    route.put()


# Generated at 2022-06-21 23:26:31.016028
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic(__name__)
    route = Route('/')
    route.delete = delete
    res = route.delete(
        '/',
        strict_slashes=None,
        version=None,
        host=None,
        name=None,
        stream=False,
        version_kwarg=None,
        apply=True,
    )
    assert res == (route, delete)

# Generated at 2022-06-21 23:26:44.334066
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # RouteMixin.route(self, uri, host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True):

    # Arguments initialization
    uri = ROUTE_CONF['uri']
    host = ROUTE_CONF['host']
    strict_slashes = ROUTE_CONF['strict_slashes']
    version = ROUTE_CONF['version']
    name = ROUTE_CONF['name']
    apply = ROUTE_CONF['apply']
    methods = ROUTE_CONF['methods']


    # create an instance of the class
    route = RouteMixin()

    # execute method route

# Generated at 2022-06-21 23:26:57.743869
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    import json
    import asyncio
    import aiohttp
    import sanic

    app = sanic.Sanic()

    @app.websocket('/feed')
    async def feed(request, ws):
        while True:
            data = 'hello!'
            print('Sending: ' + data)
            await ws.send(data)
            data = await ws.recv()
            print('Received: ' + data)
        
    async def test_client(app, loop):
        async with aiohttp.ClientSession() as session:
            async with session.ws_connect(
                    'http://localhost:5000/feed') as ws:
                
                await ws.send_json({'test': 'test'})
                data = await ws.recv()

# Generated at 2022-06-21 23:27:09.013412
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.response import stream, file
    from sanic.request import RequestParameters

    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol, WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed, WebSocketConnection
    from sanic.websocket import ConnectionClosed, ConnectionAlreadyClosed

    from sanic_openapi import doc
    from sanic_openapi import openapi_blueprint
    from sanic_openapi import swagger_blueprint

    import time
    import os

    import asyncio
    import json
    import tempfile
    import base64

# Generated at 2022-06-21 23:27:19.279923
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # test GET
    response = client.get(route_param_path, params={'name': 'laurent'}, headers=headers)
    assert response.status == 200
    assert response.json == {'name': 'laurent'}

    # test GET with default parameter
    response = client.get(route_param_path, params={'name': 'laurent'}, headers=headers)
    assert response.status == 200
    assert response.json == {'name': 'laurent'}

    # test bad request
    response = client.get(route_param_path, headers=headers)
    assert response.status == 400
    assert response.json == {'name': ['Missing data for required field.']}

    # test invalid request

# Generated at 2022-06-21 23:27:41.769992
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    uri_ws = '/test_add_websocket_route'

    # Test the basic calls
    app = Sanic('test_add_websocket_route')
    app.add_websocket_route('test1', uri_ws)
    app.add_websocket_route('test2', uri_ws, host='test')

    assert app.websocket_handlers['test1'][0].uri == uri_ws
    assert app.websocket_handlers['test2'][0].uri == uri_ws
    assert app.websocket_handlers['test2'][0].host == 'test'

    # Test the decorator
    @app.websocket(uri_ws)
    def websocket_handler1(request, ws):
        pass


# Generated at 2022-06-21 23:27:55.708475
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteExists

    from sanic.router import Version

# Generated at 2022-06-21 23:28:09.497936
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    from sanic import Sanic
    from sanic.response import json
    from sanic.router import Route
    
    sanic_app = Sanic()
    
    @sanic_app.listener('before_server_start')
    async def ensure_static(sanic_app, loop):
        await sanic_app.static('/static', 'tests/static', name='static')
        await sanic_app.get('/get', name='get')
    
    @sanic_app.route('/client/<param>')
    async def client_handler(request, param):
        return json({'msg': 'Client!', 'param': param})
        
    @sanic_app.route('/plain')
    async def plain_handler(request):
        return json({'msg': 'Hello!'})
    


# Generated at 2022-06-21 23:28:13.644155
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    route_mixin = RouteMixin()
    assert len(route_mixin.routes) == 0
    assert len(route_mixin.websocket_routes) == 0

# Generated at 2022-06-21 23:28:19.618143
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    # Clean state
    cache.clear()
    # create state
    route = Route(
        "GET",
        "/",
        None,
        strict_slashes=None,
        host=None,
        version=None,
        name=None,
        stream=False,
        websocket=False,
        static=None,
        expect_handler=None,
        payload_compression_method=None,
        request_class=None,
        responses=None,
        status_code=200,
        complete_yield=None,
        post_handler=None,
    )

# Generated at 2022-06-21 23:28:30.485014
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # case 1
    r = RouteMixin()
    route_result = r.route(uri="uri", methods=None, version=None, name=None, host=None, strict_slashes=None, apply=None)
    assert type(route_result) is tuple
    # case 2
    r = RouteMixin()
    host = Host("ip", "port")
    r.hosts = {"name": host}
    r.hosts_len = len(r.hosts)
    r.hosts_list = [host]
    r.rules_by_endpoint = {"endpoint": {}}
    r.routes = {"routes"}
    r.url_map = Map()
    r.strict_slashes = None
    methods = ["POST"]

# Generated at 2022-06-21 23:28:40.673616
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from unittest.mock import MagicMock, patch
    app = Sanic("test_RouteMixin_websocket")
    mock_route = MagicMock()

    with patch(
        "sanic.router.Route", return_value=mock_route, autospec=True
    ) as mock_Route:
        route = app.websocket("/")
        assert route == mock_route
        mock_Route.assert_called_with(
            "/",
            host=None,
            methods=None,
            strict_slashes=None,
            version=None,
            name=None,
            subprotocols=None,
            apply=True,
            websocket=True,
        )


# Generated at 2022-06-21 23:28:49.482514
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    url_string = "/"
    # Create an object RouteMixin
    result = RouteMixin()
    # Execute method websocket
    result.websocket(
        uri=url_string,
        host=None,
        strict_slashes=None,
        subprotocols=None,
        version=None,
        name=None,
    )
    # Check the name of the function used in websocket
    assert result.route.func_name == "route"

# Generated at 2022-06-21 23:28:52.230912
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
        pass


# Generated at 2022-06-21 23:29:02.040185
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # No input
    app = Sanic(__name__)
    app.route(uri='/hello')(lambda request, name: text('hello'))
    client = app.test_client

    request, response = client.post('/hello')
    assert response.status == 405
    assert response.text == 'Method PATCH Not Allowed'

    # All input
    app = Sanic(__name__)
    app.route(uri='/hello', methods=['POST', 'GET', 'PUT', 'PATCH'])(lambda request, name: text('hello'))
    client = app.test_client

    request, response = client.post('/hello')
    assert response.status == 405
    assert response.text == 'Method PATCH Not Allowed'

# Generated at 2022-06-21 23:29:22.074988
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    def test_route_add_route_put():
        from sanic.router import Route
        import inspect
        from sanic.router import Router
        from types import FunctionType
        from types import MethodType
        route_obj = RouteMixin()
        route_obj_instance = Router()
        method = inspect.getfullargspec(route_obj.put).args[0]
        if len(inspect.getfullargspec(route_obj_instance.put).args) == 1:
            raise Exception(
                "It looks like you are using Python < 3.6. "
                "This test can only be run with Python 3.6 or newer"
            )
        def handler():
            pass

# Generated at 2022-06-21 23:29:24.340636
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    
    #create a greeter
    greeter = GreeterRouteMixin()
    #create route
    @greeter.get("/test/<nr:int>")
    async def _handler(request,nr):
      
     assert await greeter._get(request,nr) == "/test/1"

# Generated at 2022-06-21 23:29:36.256188
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    class Application:
        def __init__(self, **kwargs):
            self.config = kwargs
    app=Application()
    app.config['REQUEST_MAX_SIZE']=100000
    app.config['REQUEST_BUFFER_QUEUE_SIZE']=100
    app.config['REQUEST_TIMEOUT']=60
    app.config['KEEP_ALIVE']=True
    app.config['KEEP_ALIVE_TIMEOUT']=5
    app.config['RESPONSE_TIMEOUT']=60
    app.config['WEBSOCKET_MAX_SIZE']=2 ** 20
    app.config['WEBSOCKET_MAX_QUEUE']=32
    app.config['WEBSOCKET_READ_LIMIT']=2 ** 16

# Generated at 2022-06-21 23:29:40.268801
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    # route_mixin = RouteMixin()
    # result = route_mixin.delete(uri='foo', host=None, strict_slashes=None, version=None, name=None, apply=True)
    pass


# Generated at 2022-06-21 23:29:49.987051
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    """
    Test method websocket of class RouteMixin
    """
    
    routes = RouteMixin().websocket('/todo', subprotocols=['todo'])
    assert routes.handler_class.handler == 'todo'
    assert routes.websocket == True
    assert routes.methods == []
    assert routes.host is None
    assert routes.uri == '/todo'
    assert routes.name == 'websocket'
    assert routes.strict_slashes is None
    assert routes.version is None
    assert routes.can_reuse_a_handler is False
    assert routes.handler.__name__ == 'todo'



# Generated at 2022-06-21 23:29:56.805157
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic.exceptions import InvalidUsage
    from sanic.router import Route
    from sanic.server import HttpProtocol
    from sanic.handlers import ErrorHandler
    from sanic.server import serve

    class TestRouter(Router, RouteMixin):
        def __init__(self):
            super().__init__()

    test_router = TestRouter()

    @test_router.websocket("/")
    async def test_websocket(request, ws):
        pass

    assert isinstance(test_router.routes[0], Route)
    assert test_router.routes[0].name == "test_websocket"
    assert test_router.routes[0].uri == "/"

# Generated at 2022-06-21 23:30:02.960524
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic import Sanic
    app = Sanic()
    @app.patch("/")
    def handler():
        pass
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].methods == {'PATCH'}


# Generated at 2022-06-21 23:30:15.787864
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    host = None
    strict_slashes = None
    version = None
    name = None
    uri = 'test_uri'
    apply = True
    subprotocols = ()

    r = RouteMixin(None)
    ret = r.websocket(uri, host, strict_slashes, version, name, apply, subprotocols)
    assert isinstance(ret, tuple) and len(ret) == 2 and \
        isinstance(ret[0], list) and len(ret[0]) == 0 and \
        callable(ret[1]) and ret[1].__closure__

    r = RouteMixin(None)
    ret = r.websocket()

# Generated at 2022-06-21 23:30:24.298884
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    my_app = MyApp(__name__)
    assert isinstance(my_app, MyApp)
    assert isinstance(my_app, Sanic)
    assert isinstance(my_app, RouteMixin)
    assert hasattr(my_app, 'name')
    assert hasattr(my_app, 'strict_slashes')
    assert hasattr(my_app, '_future_middlewares')
    assert hasattr(my_app, '_future_statics')
    assert hasattr(my_app, '_middlewares')
    assert hasattr(my_app, '_middleware_order')
    assert hasattr(my_app, '_blueprints')
    assert hasattr(my_app, '_blueprints_order')
    assert hasattr(my_app, '_router')
   

# Generated at 2022-06-21 23:30:38.201784
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():

    @patch("sanic.response.HTTPResponse")
    @patch("sanic.router.Route.get_info")
    @patch("sanic.router.Route.get_params")
    @patch("sanic.router.sanic")
    def _test(
        self,
        m_sanic,
        mock_get_info: MagicMock,
        mock_get_params: MagicMock,
        mock_HTTPResponse,
    ):

        m_sanic.create_endpoint = MagicMock()
        m_sanic.on_request = MagicMock()

        handler = MagicMock()
        instance = MagicMock()
        instance.get_info = MagicMock(return_value=1)
        request = MagicMock()
        kwargs = MagicMock

# Generated at 2022-06-21 23:31:06.533406
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    assert True


# Generated at 2022-06-21 23:31:09.553876
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    print("Start test_RouteMixin_websocket")
    
    
    print("End test_RouteMixin_websocket")

# Generated at 2022-06-21 23:31:19.581017
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic("test_route_mixin")

    @app.route("/")
    def handler(request):
        pass

    assert isinstance(app.router, RouteMixin)
    assert hasattr(app.router, "route")
    assert hasattr(app.router, "add_route")
    assert hasattr(app.router, "websocket")
    assert hasattr(app.router, "add_websocket_route")
    assert hasattr(app.router, "static")

if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-21 23:31:27.591802
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    request = Request(
        transport=None,
        message=None,
        protocol=None,
        writer=None,
        task_id=None,
        server=None,
        task=None,
        uri=None,
        preload_content=None,
    )
    app = Sanic(__name__)
    router_mixin = RouteMixin(app)
    router_mixin.put(uri='/test/', strict_slashes=True, version=1\
    , name='module_method', apply=True)

    expected_result = [
        Route(
            app,
            "/test",
            module_method,
            strict_slashes=True,
            hosts=[],
            methods=["PUT"],
            version=1,
            name="module_method",
        )
    ]



# Generated at 2022-06-21 23:31:39.772815
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    try:
        app = Sanic("test_RouteMixin_get")
        uri = '/'
        host = '127.0.0.1'
        strict_slashes = True
        version = 1
        name = None 
        routes = app.route(uri=uri, host=host, strict_slashes=strict_slashes, version=version, name=name)
        assert len(app.routes) == 0
        assert len(routes) == 2
        assert len(routes[1]) == 0
    except Exception as e:
        pytest.fail(f"Exception raised when testing RouteMixin get: {e}")


# Generated at 2022-06-21 23:31:51.865552
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    print("Start test for method add_route of class RouteMixin")
    app = Sanic(name='test_route_mixin_add_route')
    path = '/test/route/mixin/add_route'
    async def handler(request):
        return json({"test": "test_route_mixin_add_route"})
    app.add_route(handler, path, methods=['GET'])
    _, response = app.test_client.get(path)
    assert response.json == {"test": "test_route_mixin_add_route"}
    print("End test for method add_route of class RouteMixin")


# Generated at 2022-06-21 23:32:01.116395
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    # setup
    router = RouteMixin()
    # assert
    assert router.options

# Generated at 2022-06-21 23:32:05.830494
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    @RouteMixin
    class Service:
        pass

    s = Service()
    assert isinstance(s.router, Router)


# Generated at 2022-06-21 23:32:12.429732
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    r = RouteMixin()
    decorator = r.post('test_uri2', host=None, strict_slashes=None, version=None, name=None)
    r1 = decorator(test_RouteMixin_post)
    assert r1.routes[0].uri == 'test_uri2'
    
    

# Generated at 2022-06-21 23:32:25.862051
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    """"""
    uri = "/"
    host = "127.0.0.1"
    strict_slashes=True
    version = 1
    name = "name"
    decorators = "decorators"
    handler = "handler"
    apply = True
    # this method is tested in test_RouteMixin_route
    router = RouteMixin()
    route = router.patch(uri, host=host, strict_slashes=strict_slashes, version=version, name=name, apply=apply)
    assert route
    assert uri in router.routes_all
    assert host in router.routes_all[uri]
    assert strict_slashes in router.routes_all[uri][host]

# Generated at 2022-06-21 23:33:31.793991
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    app = Sanic("test_RouteMixin_websocket")
    RouteMixin.websocket(
        uri="/",
        host=None,
        strict_slashes=None,
        subprotocols=None,
        version=None,
        name=None,
        apply=True,
    )

# Generated at 2022-06-21 23:33:42.469589
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # Input
    uri="/"
    host="127.0.0.1"
    strict_slashes=None
    name=None
    version=None
    methods="POST"
    apply=True
    # Expected
    Exp_method = "PATCH"
    # Real
    route_mixin = RouteMixin()
    @route_mixin.patch(
        uri=uri,
        host=host,
        name=name,
        methods=methods,
        strict_slashes=strict_slashes,
        version=version,
        apply=apply,
    )
    def test():
        return "test patch"
    real_method = route_mixin._registered_routes[0].methods
    # Test
    assert real_method == Exp_method

# Generated at 2022-06-21 23:33:49.246774
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # the websocket function of RouteMixin should return the correct result according to the input
    #   @websocket('/feed')
    #   async def feed(request):
    #       return redirect("/")
    # -> return a decorator to decorate the request handlers
    from sanic.handlers import ErrorHandler
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    result = RouteMixin.websocket('/feed')(ErrorHandler)
    assert isinstance(result, type(HTTPResponse))
    assert isinstance(result, WebSocketProtocol)


# Generated at 2022-06-21 23:34:00.134875
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    print('\n\nRunning unittest for the method options of class RouteMixin')

    class App(RouteMixin):
        def __init__(self, *args, **kwargs):
            self.routes = []
            super().__init__(*args, **kwargs)

    app = App()
    route = app.options('test', 'test', 'test')(lambda *a, **b: None)
    assert route.methods == {'OPTIONS'}


# Generated at 2022-06-21 23:34:09.338687
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # Create app instance
    app = Sanic(__name__)
    # Register a websocket route to test
    @app.websocket('/')
    async def test(request, ws):
        pass
    # The route should be registered
    assert app.is_websocket_route(None, '/')
    assert not app.is_websocket_route(None, '/hello')
    
    

# Generated at 2022-06-21 23:34:11.787996
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    try:
        pass
    except:
        assert False

# Generated at 2022-06-21 23:34:14.135291
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    router = RouteMixin('/base')
    assert isinstance(router, RouteMixin)
    

# Generated at 2022-06-21 23:34:26.867869
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    print("==================== test_RouteMixin_websocket ====================")
    debug = True
    app = Sanic("test_RouteMixin_websocket")
    @app.websocket("/feed")
    async def feed(request, ws):
        while True:
            data = "Hello!"
            print('Sending: ' + data)
            await ws.send(data)
            data = await ws.recv()
            print('Received: ' + data)

# Generated at 2022-06-21 23:34:36.221892
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    @app.route("/")
    @app.websocket("/test_websocket")
    async def handler(request, ws):
        pass

    @app.middleware
    async def handler_mw(request):
        pass

    @app.exception(BaseException)
    async def handler_exception(request, exception):
        pass

    @app.listener("before_server_start")
    async def listener(app, loop):
        pass

    @app.listener("after_server_start")
    async def listener(app, loop):
        pass

    @app.listener("before_server_stop")
    async def listener(app, loop):
        pass

    @app.listener("after_server_stop")
    async def listener(app, loop):
        pass


# Generated at 2022-06-21 23:34:49.433456
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic()
    Sanic.add_websocket_route = RouteMixin.add_websocket_route
    # Case 1
    @app.websocket('/echo')
    async def echo(request, ws):
        while True:
            data = await ws.recv()
            await ws.send(data)
    assert app.websocket_routes[0].uri == '/echo'
    assert app.websocket_routes[0].handler == echo
    assert app.websocket_routes[0].host == None
    assert app.websocket_routes[0].strict_slashes == None
    assert app.websocket_routes[0].subprotocols == None
    assert app.websocket_routes[0].version