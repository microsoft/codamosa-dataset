

# Generated at 2022-06-21 23:25:58.839475
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse

    def handler(request):
        return HTTPResponse()

    mixin = RouteMixin()
    uri = '/test/'
    method = "GET"
    host = None
    strict_slashes = None
    version = 1
    name = 'test'
    apply = True
    websocket = False
    output = mixin.route(uri, host, method, strict_slashes, version, name, apply, websocket)

    assert type(output[0]) == Route


# Generated at 2022-06-21 23:26:08.086136
# Unit test for constructor of class RouteMixin
def test_RouteMixin():

    routes = RouteMixin(
        name = 'Entertainment',
        host = '123.123.123.123',
        subprotocols = ['a'],
        strict_slashes = True
    )

    # Test name
    assert routes.name == 'Entertainment', "Test name"

    # Test host
    assert routes.host == '123.123.123.123', "Test host"

    # Test subprotocols
    assert routes.subprotocols == ['a'], "Test subprotocol"

    # Test strict_slashes
    assert routes.strict_slashes == True, "Test strict_slashes"


# Generated at 2022-06-21 23:26:09.445368
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    r = RouteMixin()
    assert r.head()


# Generated at 2022-06-21 23:26:17.395247
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    """
    Unit test for method static of class RouteMixin
    """
    route = RouteMixin()
    file_or_directory = "./"
    uri = "/"
    pattern = r"^/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = '__sanic_static__'
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    static = FutureStatic(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type)

    # test static

# Generated at 2022-06-21 23:26:31.298866
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists

    app = Sanic(__name__)
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters
    # TODO: add testing of route's parameters

# Generated at 2022-06-21 23:26:34.882270
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: implement this test
    pass



# Generated at 2022-06-21 23:26:43.000629
# Unit test for method put of class RouteMixin

# Generated at 2022-06-21 23:26:51.517224
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    with AsyncClient() as client:
        with Sanic('test_RouteMixin_delete') as app:
            @app.delete('/', strict_slashes=True)
            async def handler(request):
                return text('OK')

            request, response = client.delete('/')
            assert response.text == 'OK'


# Generated at 2022-06-21 23:26:59.237610
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Test for RouteMixin
    assert RouteMixin().__dict__.get("strict_slashes") == None
    assert RouteMixin().__dict__.get("host") == None
    assert RouteMixin().__dict__.get("version") == None
    assert RouteMixin().__dict__.get("name") == None
    assert RouteMixin().__dict__.get("changes") == None
    assert RouteMixin().__dict__.get("route_depth") == 0
    assert RouteMixin().__dict__.get("url_args") == None
    assert RouteMixin().__dict__.get("blueprint_url_args") == None


# Generated at 2022-06-21 23:27:10.133011
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin')
    _request = RequestParameters(
        host='127.0.0.1',
        port=8000,
        scheme=None,
        transport=None,
        remote_addr='127.0.0.1',
        debug=False,
        root_path=None)


# Generated at 2022-06-21 23:27:30.760825
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    app = Sanic('test_RouteMixin_websocket')

    # Test version defualt
    @app.websocket('/create')
    async def create(request, ws):
        pass

    assert app.router.routes_all['create'][0].version == 0

    # Test version is zero
    @app.websocket('/create', version=0)
    async def create(request, ws):
        pass

    assert app.router.routes_all['create'][0].version == 0

    # Test version is one
    @app.websocket('/create', version=1)
    async def create(request, ws):
        pass

    assert app.router.routes_all['create'][0].version == 1

    # Test version is more than one

# Generated at 2022-06-21 23:27:33.804777
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class Foo(RouteMixin):
        def route(self, uri, host, methods, strict_slashes, version, name, apply, **kwargs):
            return uri
    f = Foo()
    f.name = "foo"
    result = f.route("bar", "baz", "qux", "quux", "quuz", "quuux", True)
    assert result == "bar"

# Generated at 2022-06-21 23:27:43.127162
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class TestRouteMixin(RouteMixin):
        def __init__(self, reverse_list):
            self.reverse_list = reverse_list
            self.strict_slashes = False
            self.websocket_timeout = None
            self.websocket_max_size = None
            self.websocket_max_queue = None
            self.websocket_read_limit = None
            self.websocket_write_limit = None
            self.request_timeout = 60
            self.keep_alive = True
            self.response_timeout = 60

        def reverse_url(self, name, *args):
            self.reverse_list.append((name, args))
            return name

    reverse_list = list()
    test_route_mixin = TestRouteMixin(reverse_list=reverse_list)

# Generated at 2022-06-21 23:27:44.570593
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    assert RouteMixin


# Generated at 2022-06-21 23:27:47.493414
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass


# Generated at 2022-06-21 23:27:57.648633
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    @options("/test")
    async def handler(request):
        return response.text("OK")

    app = Sanic("test_route_mixin_options")
    try:
        app.add_route(handler, "/test", methods=["OPTIONS"])
    except AssertionError as e:
        assert str(e) == "handler already added"
    else:
        raise
    finally:
        app.stop()
        loop = app.loop
        tasks = asyncio.all_tasks(loop=loop)
        for task in tasks:
            task.cancel()
        loop.run_until_complete(
            asyncio.gather(*tasks, return_exceptions=True)
        )
        loop.close()



# Generated at 2022-06-21 23:28:10.199611
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    r = RouteMixin()
    r.route(uri=None, host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True)
    r.add_route(handler=None, host=None, uri=None, methods=None, strict_slashes=None, version=None, name=None)
    r.websocket(uri=None, host=None, strict_slashes=None, subprotocols=None, version=None, name=None, apply=True)
    r.add_websocket_route(handler=None, host=None, uri=None, strict_slashes=None, subprotocols=None, version=None, name=None)

# Generated at 2022-06-21 23:28:20.847761
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    router_path = "sanic.router.RouteMixin"
    with patch(router_path + "._generate_name") as mock_generate:
        mock_func = Mock(return_value=Mock())
        router = RouteMixin()

        host = "127.0.0.1"
        uri = "/"
        strict_slashes = True
        subprotocols = "chat"
        version = 1
        name = "name"

        # Case 1
        result1 = router.add_websocket_route(
            mock_func, host=host, uri=uri, strict_slashes=strict_slashes,
            subprotocols=subprotocols, version=version, name=None)
        mock_generate.assert_called_once_with(mock_func)


# Generated at 2022-06-21 23:28:27.868868
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    with pytest.raises(TypeError) as execinfo:
        RouteMixin().get()
    assert str(execinfo.value) == "get() missing 1 required positional argument: 'uri'"
    with pytest.raises(TypeError) as execinfo:
        RouteMixin().get(uri='/')
    assert str(execinfo.value) == "get() missing 1 required positional argument: 'handler'"


# Generated at 2022-06-21 23:28:30.116288
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    pass

# Generated at 2022-06-21 23:28:45.006541
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    print('Function: test of RouteMixin.get')

# Generated at 2022-06-21 23:28:58.784699
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    def f1():
        pass

    def f2():
        pass

    def f3():
        pass

    @functools.wraps(f1)
    def f4():
        pass

    @functools.wraps(f1)
    def f5():
        pass

    @functools.wraps(f1)
    def f6():
        pass

    @functools.wraps(f1)
    def f7():
        pass

    @functools.wraps(f7)
    def f8():
        pass

    @functools.wraps(f1)
    def f9():
        pass

    @functools.wraps(f1)
    def f10():
        pass


# Generated at 2022-06-21 23:29:05.933423
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    assert RouteMixin().route("uri", methods=None)
    assert RouteMixin().route("uri", methods=None, name=None)
    assert RouteMixin().route("uri", methods=None, version=None)
    assert RouteMixin().route("uri", methods=None, host=None)
    assert RouteMixin().route("uri", methods=None, strict_slashes=None)
    assert RouteMixin().route("uri", methods=None, stream=None)
    assert RouteMixin().route("uri", methods=None, websocket=None)
    assert RouteMixin().route("uri", methods=None, apply=None)



# Generated at 2022-06-21 23:29:10.565778
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic.router import Route

    class RouteMixin():
        def post(self):
            pass

    route_mixin: RouteMixin = RouteMixin()

    route: Route = route_mixin.post()

# Generated at 2022-06-21 23:29:25.247332
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    _sanic_app=App()
    _route_mixin=RouteMixin(app=_sanic_app)
    def f(a: int, b: float) -> str: pass
    _f=partial(f)
    _app=App()
    _app.route=lambda uri, host=None, methods=None, strict_slashes=True, version=1, name=None, apply=True: (uri, host, methods, strict_slashes, version, name, apply)
    _app.router=_route_mixin
    _route, _f=_route_mixin.websocket(uri="uri", host="host", strict_slashes="strict_slashes", subprotocols="subprotocols", version="version", name="name")(f)
    result = _route, _f


# Generated at 2022-06-21 23:29:31.434555
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import RouteMixin
    from sanic.websocket import WebSocketProtocol

    _tm = RouteMixin()

    # unit test for '_get_route_middlewares' method
    assert _tm._get_route_middlewares() == _tm._middlewares

    # unit test for 'middleware' method
    assert _tm.middleware(lambda x: x) == _tm._middlewares
    assert _tm._get_route_middlewares() == _tm._middlewares

    # unit test for 'static' method
    # file_path = "./"
    # url = "/"
    # url_prefix = ""
    # pattern = "^.*$"
    # strict_slashes = False
    # name = ""
    # host = None
    # content_type = None

# Generated at 2022-06-21 23:29:39.899542
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    route_mixin = RouteMixin()
    # Test case 1: arg: None
    try:
        route_mixin.delete( None )
        assert False
    except ValueError:
        assert True
    # Test case 2: arg: ""
    try:
        route_mixin.delete( "" )
        assert False
    except ValueError:
        assert True
    # Test case 3: arg: "api/"
    try:
        route_mixin.delete( "api/" )
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 23:29:41.149214
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    route_mixin = RouteMixin()
    assert route_mixin.websocket(uri=None)



# Generated at 2022-06-21 23:29:52.084936
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.exceptions import FileNotFound
    from sanic.response import HTTPResponse

    async def async_mock_handler(*args, **kwargs):
        return "OK"

    mock_handler = Mock(side_effect=async_mock_handler)

    # Base case
    app = Sanic("test_RouteMixin_options")
    app.route = RouteMixin.route(app)
    app.add_route = app.route
    app.route(uri="/test_RouteMixin_options", methods=None)(mock_handler)
    request, response = app.test_client.get("/test_RouteMixin_options")

    assert response.status == 200
    assert response.text == "OK"
    assert request.url == "http://testclient/test_RouteMixin_options"

# Generated at 2022-06-21 23:29:55.334290
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    response = RouteMixin.post()
    assert response.__class__ is post
    

# Generated at 2022-06-21 23:30:19.256502
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("myserver")
    router = RouteMixin()
    app.route = router.route
    app.add_websocket_route = router.add_websocket_route
    app.websocket = router.websocket
    app.host = "testhost"
    app.strict_slashes = None
    app.name = "myserver"

    @app.websocket("/test", strict_slashes = True)
    def test(request):
        pass

    assert router.routes_all == {routes.WebSocketRoute({'uri': '/test', 'strict_slashes': True, 'host': 'testhost', 'name': 'myserver.test', 'subprotocols': []}, test, websocket=True)}

# Generated at 2022-06-21 23:30:28.166867
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # Test with no parameters
    Input = {
        "uri": None,
        "strict_slashes": None,
        "version": None,
        "name": None,
    }
    Output = {
        "uri": None,
        "strict_slashes": None,
        "version": None,
        "name": None,
    }
    assert RouteMixin.head(Input) == Output
    # Test with all possible parameters
    Input = {
        "uri": "url",
        "strict_slashes": True,
        "version": 1,
        "name": "name",
    }
    Output = {
        "uri": "url",
        "strict_slashes": True,
        "version": 1,
        "name": "name",
    }
    assert RouteMixin.head

# Generated at 2022-06-21 23:30:39.728577
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    # Setup
    uri = "www.example.com"
    host = "127.0.0.1"
    strict_slashes = True
    subprotocols = None
    version = 1
    name = "name"
    class Handler():
        def __init__(self, websocket):
            self.websocket = websocket
        def __call__(self):
            return "HANDLER"
    handler = Handler

    # Exercise
    class RouteMixinTest(RouteMixin):
        def __init__(self):
            return
    
    route_mixin_test = RouteMixinTest()
    ret = route_mixin_test.add_websocket_route(handler,uri,host,strict_slashes,subprotocols,version,name)

    # Verify

# Generated at 2022-06-21 23:30:43.994326
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    print("Testing RouteMixin.static")
    test_RouteMixin = RouteMixin()
    uri = "/"
    file_or_directory = ""
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True
    result = test_RouteMixin.static(uri, file_or_directory, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type, apply)
    print('Expect: None')
    print('Actual:', result)

# Generated at 2022-06-21 23:30:46.789015
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    r = RouteMixin()

    @r.put("/")
    def handler():
        return True

    assert r.router.routes_names['put'] == [None]



# Generated at 2022-06-21 23:30:48.247566
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass



# Generated at 2022-06-21 23:31:01.684542
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.router import Route
    from sanic.request import Request
    app = MagicMock()
    app.router = Mock()
    app.router.add.return_value = route = MagicMock()
    mixin = RouteMixin()
    @mixin.head('/', host='127.0.0.1', strict_slashes=None, version=None, name=None, apply=True)
    def bla(request: Request):
        return 'bla'
    assert (repr(mixin) == "<RouteMixin>")
    assert (repr(route) == repr(mixin.head('/', host='127.0.0.1', strict_slashes=None, version=None, name=None, apply=True)(bla)))

# Generated at 2022-06-21 23:31:05.772177
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic("route_test")
    @app.route("/route_test")
    def route_test(request):
        assert request
        return text("OK")

# Generated at 2022-06-21 23:31:14.768655
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # A method for patching the test scenario
    def test_patch():
        route = router.Route('/', host=None, methods=None, strict_slashes=True,
                             version=None, name=None, static=None,
                             stream=False, websocket=False)
        return route
    # Method to test the patching of route
    def patch_test(self):
        route.methods = ['PATCH']
        return route

    # Create an instance of class RouteMixin
    route_mixing = RouteMixin()
    # Patching the Route with testers method
    patch_test(route_mixing)
    # Testing the patched route with the original
    assert test_patch().methods == route.methods


# Generated at 2022-06-21 23:31:23.362916
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    @ok
    async def test():
        router = Router()
        @router.get('/test')
        async def _test(request):
            return
        assert not router.has_get('/test')
        router._apply_routes()
        assert router.has_get('/test')
        router.reset()
        assert not router.has_get('/test')
        router._apply_routes()
        assert router.has_get('/test')
    # if __name__ == '__main__':
    #     test()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()


# Generated at 2022-06-21 23:31:55.504715
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    @patch("sanic.response.text")
    def test_patch_decorator_basic_usage(mock_text):
        @RouteMixin.patch("/test/<param>")
        async def handler(request, param):
            return text("I am a get response")

        assert handler.__name__ == "handler"
        assert handler.__module__ == __name__

        route, output = RouteMixin.route(uri="/test/<param>", methods=["PATCH"])(
            handler
        )

        assert route == RouteMixin.route(uri="/test/<param>", methods=["PATCH"])

        assert output == handler
        assert output.__name__ == "handler"
        assert output.__module__ == __name__


# Generated at 2022-06-21 23:31:57.581875
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    data = '{"name":"kiwi"}'
    data = json.loads(data)
    assert data['name'] == "kiwi"

# Generated at 2022-06-21 23:32:01.479481
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic()
    rm = RouteMixin()

    @rm.route("/")
    def hello(request):
        return json({"hello": "world"})

    assert rm.routes


# Generated at 2022-06-21 23:32:03.588836
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    RouteMixin().patch()


# Generated at 2022-06-21 23:32:12.124073
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    def func():
      pass

    routes = RouteMixin()
    result = routes.route(uri='/uri', methods='None', strict_slashes='None',
         version='None', name='None', apply='False', websocket='True')(func)


# Generated at 2022-06-21 23:32:24.982943
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    route_mixin = RouteMixin()
    route_mixin.router = Router()
    route_mixin.name = "sanic"
    route_mixin.blueprint = None
    route_mixin.strict_slashes = None
    route_mixin.host = None
    route_mixin.prefix = None
    # TODO: Add assert here
    route_mixin.get("/", methods=["GET"], strict_slashes=None, version=None, name="test", apply=True)
    # TODO: Add assert here
    route_mixin.get("/", methods=["GET"], strict_slashes=None, version=None, name="test", apply=False)


# Generated at 2022-06-21 23:32:31.974223
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    route_mixin = RouteMixin()

# Generated at 2022-06-21 23:32:33.457662
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    assert False

# Generated at 2022-06-21 23:32:47.008084
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    class Mock(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def __call__(self, *args, **kwargs):
            return Mock(**kwargs)

    mock_sanic = Mock()
    mock_request = Mock(__class__=Mock)
    mock_response = Mock()
    mock_request.__class__.__name__ = 'MockRequest'
    mock_response.__class__.__name__ = 'MockResponse'
    mock_route = Mock()
    mock_route.__class__.__name__ = 'MockRoute'
    mock_uri = Mock()
    mock_uri.__class__.__name__ = 'MockUri'

# Generated at 2022-06-21 23:32:54.655878
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("Sanic")

    async def handler(request):
        return text("OK")

    app.add_websocket_route(handler, "/test")
    assert app.is_request_stream
    assert app.websocket_routes[0].name == "__main__.handler"
    assert app.websocket_routes[0].uri == "/test"



# Generated at 2022-06-21 23:33:49.311461
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic('test_app')
    mixin = RouteMixin(app, "test_app")
    assert mixin is not None
    assert mixin._app is not None
    assert mixin.name == "test_app"


# Generated at 2022-06-21 23:33:51.477482
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    pass
    

# Generated at 2022-06-21 23:34:02.730426
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route, Router
    from sanic.request import Request
    from sanic.response import HTTPResponse

    router = Router()
    route, _ = router.route(uri='test')(lambda request, i1, i2: HTTPResponse(body='test'))
    req = Request('GET', '/test/23/abc', headers={}, version=None,
        match_info=MatchInfo(['23', 'abc'], {}), app=MagicMock(), loop=MagicMock(), protocol=MagicMock(), transport=MagicMock())
    assert(route.handler(req) == HTTPResponse(body='test'))
    assert(len(route.parameters) == 2)
#test_RouteMixin_route()


# Generated at 2022-06-21 23:34:15.211365
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # default parameters
    def handler():
        pass
    RouteMixin_instance = RouteMixin()
    RouteMixin_instance.add_route(handler, uri="/", methods=["GET"])
    assert RouteMixin_instance.get_request_handler(uri="/", method="GET") == handler

    # all parameters
    route = RouteMixin_instance.add_route(handler, uri="/b", methods=["POST"],
                                          host="127.0.0.1",
                                          strict_slashes=False,
                                          version=0,
                                          stream=True, name="name_a")
    assert route.uri == "/b"
    assert route.methods == ["POST"]
    assert route.host == "127.0.0.1"
    assert route.strict_slashes == False

# Generated at 2022-06-21 23:34:24.261130
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    test_obj = RouteMixin()
    with pytest.raises(NotImplementedError):
        test_obj.options(uri=str(), host=str(), methods=str(), 
                         version=int(), strict_slashes=bool(),
                         name=str(), apply=bool(), 
                         stream=bool(), 
                         websocket=bool(),
                         handler=str(), 
                         stream_large_files=bool(), 
                         subprotocols=str(),
                         run_async=bool())

# Generated at 2022-06-21 23:34:26.376840
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # create instance of class RouteMixin
    route_mixin = RouteMixin()
    # return None
    assert route_mixin.head() is None

# Generated at 2022-06-21 23:34:32.232357
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    # test decorate syntax
    @RouteMixin.options('uri')
    def foo():
        pass
    assert foo.route.uri == 'uri'
    assert foo.route.methods == ['OPTIONS']

    # test function syntax
    @RouteMixin
    def bar():
        pass
    bar.options('uri')
    assert bar.route.uri == 'uri'
    assert bar.route.methods == ['OPTIONS']

# Generated at 2022-06-21 23:34:34.914737
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    router = Router()
    @router.patch("/test")
    def test_function(request):
        return text("test")
    assert router.routes[0].uri == "/test"
    assert router.routes[0].methods == ["PATCH"]

# Generated at 2022-06-21 23:34:47.466584
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    post_uri = "test_uri"
    post_methods = "test_methods"
    post_host = "test_host"
    post_strict_slashes = False
    post_version = 1
    post_name = "test_name"
    post_apply = True
    
    routeMixin = RouteMixin()
    method_return = routeMixin.post(
        uri=post_uri,
        methods=post_methods,
        host=post_host,
        strict_slashes=post_strict_slashes,
        version=post_version,
        name=post_name,
        apply=post_apply,
    )
    

# Generated at 2022-06-21 23:34:57.578796
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route

    class Sanic:
        routes = []
        strict_slashes = True

        def route(self, *args, **kwargs):
            def wrapper(handler):
                self.routes.append(Route(*args, **kwargs, handler=handler))
                return handler

            return wrapper

        def add_route(self, route):
            self.routes.append(route)

    app = Sanic()
    RouteMixin().mixin_in(app)

    app.static(
        uri="/static", file_or_directory="static", name="static", strict_slashes=True
    )
    app.static(uri="/static1", file_or_directory="static", name="static1")