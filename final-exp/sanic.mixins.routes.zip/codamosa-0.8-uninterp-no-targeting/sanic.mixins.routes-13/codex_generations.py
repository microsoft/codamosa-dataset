

# Generated at 2022-06-21 23:26:10.700475
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    '''Test post method, part of class RouteMixin.'''
    # setup
    global app
    app = Sanic('test_RouteMixin')
    # run
    route = app.route('/test', methods=['POST'], strict_slashes=True,
                      version=1)(lambda req: req)
    # test
    assert route.methods == ['POST']
    assert route.strict_slashes == True
    assert route.version == 1

# Generated at 2022-06-21 23:26:18.198380
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    """
    This test is to test the all properties and methods of RouteMixin
    """
    # Test route
    r = sanic.router.Route("GET", "/home", "home", None, None)
    r.host = "host"
    r.strict_slashes = True
    r.uri = "uri"
    r.pattern = "pattern"
    r.handler = None
    r.websocket = True
    r.name = "name"
    r.host_matching = False
    r.host_matching_strict_slashes = False
    r.host_matching_attribute_name = "host_matching_attribute_name"
    r.host_matching_pattern = "host_matching_pattern"
    r.host_matching_exact = False
    r.static

# Generated at 2022-06-21 23:26:24.837304
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    app = Sanic("test_RouteMixin_put")
    router = Router()
    router.put("/", host=None, methods=None, version=None, strict_slashes=None, name=None,
        stream=True, apply=True)
    assert router.routes
    assert router.routes_all
    assert router.routes_all_strict_slashes
    assert router.handlers
    assert router.default_subdomain
    assert router.host_matching
    assert router.middlewares
    assert router.name
    assert router.strict_slashes


# Generated at 2022-06-21 23:26:28.148036
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    m = RouteMixin()
    m.register_route(handler='handler', uri='/', methods=None, name='name')



# Generated at 2022-06-21 23:26:35.353985
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic import Sanic
    from sanic_restful import Api

    app = Sanic(__name__)
    api = Api(app)

    @api.put('/users/<id>')
    async def update(request, id):
        return text('OK')

    uri = '/users/10'
    request = Request.fake_request('PUT', uri)

    route = api.router._routes_all['PUT'][0]
    match_info = route.matcher.match(request.url, request.method)
    route = route.resolve_handler(match_info)

    assert route.uri == '/users/<id>'
    assert route.handler_args == ['id']
    assert route.handler_kwargs == {}

# Generated at 2022-06-21 23:26:45.185383
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from unittest.mock import MagicMock, patch, call

    routes = []

    def mock_route(
        uri, methods, version=None, host=None, name=None, apply=False, strict_slashes=None
    ):
        routes.append(
            Route(
                uri,
                MagicMock(),
                methods=methods,
                version=version,
                host=host,
                strict_slashes=strict_slashes
            )
        )

        def runner(url):
            return url

        return runner


# Generated at 2022-06-21 23:26:50.956040
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic import Sanic
    app = Sanic()
    assert RouteMixin.options(app) == []
    RouteMixin.options(app, "OK")
    assert RouteMixin.options(app) == ["OK"]


# Generated at 2022-06-21 23:26:51.850717
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    pass



# Generated at 2022-06-21 23:27:00.280808
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Case: register a root to serve files from. The input can either be a
    # file or a directory. This method will enable an easy and simple way
    # to setup the :class:`Route` necessary to serve the static files.
    with pytest.raises(ValueError):
        RouteMixin().static(
            uri = "",
            file_or_directory = {},
            pattern = r"/?.+",
            use_modified_since = True,
            use_content_range = False,
            stream_large_files = False,
            name = "static",
            host = None,
            strict_slashes = None,
            content_type = None,
            apply = True
        )

# Generated at 2022-06-21 23:27:04.214472
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    # Initializate
    try:
        routeMixin = RouteMixin()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-21 23:27:25.219992
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    s = Sanic("test_RouteMixin_delete")
    res = s.delete()
    assert res == 'DELETE'


# Generated at 2022-06-21 23:27:31.616696
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    app = Sanic('test_RouteMixin_static')
    test_route_mixin = RouteMixin(app, 'Group', '1.0')
    test_route_mixin.static(uri='/static', file_or_directory='/static', pattern=r"/?.+", use_modified_since=True, use_content_range=False, stream_large_files=False, name="static", host='Host', strict_slashes=None, content_type='Content Type', apply=True)
    return


# Generated at 2022-06-21 23:27:33.419750
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    app = Sanic("sanic-server")
    # test for successful to execute add_websocket_route
    app.add_websocket_route('/websocket', 'websocket-handler')

# Generated at 2022-06-21 23:27:42.783511
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.app import Sanic

    app = Sanic()
    class test_RouteMixin_RouteMixin():

        def __init__(self):

            self.name = u'test_RouteMixin_sanic.app'
            self.router = app.router
            self.strict_slashes = None
            self._future_statics = set()
            self._future_handlers = set()
            self.config = app.config

        def register_blueprint(self, blueprint, version=None, host=None):
            return app.register_blueprint(blueprint, version=None, host=None)


# Generated at 2022-06-21 23:27:49.915435
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    router = Router()
    router.patch(
        uri='/',
        host=None,
        strict_slashes=None,
        version=None,
        name=None,
        stream=False,
        apply=True
        )
    assert True


# Generated at 2022-06-21 23:27:58.513915
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    class RouteMixin:
        def __init__(self):
            # The name of the blueprint.
            self.name = "Llama"
            # A map of {URL pattern: :class:`Route` instance}
            self._routes = {}
            # List of URL Mapping rules
            self._rules = []
            # A map of {URL name: :class:`Route` instance}
            self._named_rules = {}
            # A list of :class:`Route` instances in their order of registration
            self._ordered_rules = []
            # A list of :class:`Route` instances that have been built
            self._built_rules = []
            # A map of {URL: :class:`Route` instance}
            self._strict_slashes = None
            # A map of {URL: :class:`

# Generated at 2022-06-21 23:28:00.589965
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():

        
        obj = RouteMixin()
        param = 'uri'
        ret = obj.put(param=param)
        assert ret.uri == param



# Generated at 2022-06-21 23:28:05.035299
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    assert RouteMixin(strict_slashes=True).put('path', 'host', 'strict_slashes', 'version', 'name', False)(False)


# Generated at 2022-06-21 23:28:19.250252
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # mock request
    request = Mock()
    # mock app
    app = Mock()

    # initialize RouteMixin class
    r = RouteMixin(app)
    # initialize Route
    route = r.route(uri='/',methods=None,strict_slashes=True)(request)

    # test if attribute 'app' has same value of mock instance 'app'
    assert r.app == app

    # test if attribute 'routes' is a list
    assert isinstance(r.routes,list)

    # test if attribute 'strict_slashes' is a bool value True
    assert isinstance(r.strict_slashes,bool)
    assert r.strict_slashes

    # test if attribute 'host' is a str and a empty string
    assert isinstance(r.host,str)
   

# Generated at 2022-06-21 23:28:19.895363
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass


# Generated at 2022-06-21 23:28:48.297408
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    router = sanic.router.RouteMixin()
    uri = "url"
    json_data = {"key": "value"}
    response = HTTPResponse(json=json_data, status=200)
    method = "get"
    host = "localhost"
    strict_slashes = True
    version = 1
    name = "name"
    apply = True
    expect = response
    result = router.route(method=method, uri=uri, host=host, strict_slashes=strict_slashes, version=version, name=name, apply=apply)(router.dummy_handler)
    assert type(result[0]) == sanic.router.Route
    assert result[1](response) == expect

# Generated at 2022-06-21 23:29:01.347233
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    
    app = Sanic(__name__)

    @app.route('/')
    async def test(request):
        return text('OK')

    routes = app.router.routes_all
    assert len(routes) == 1
    assert routes[0] == Route('test', '/', ['GET'], test, None, 'GET', 
    None, None, True, None, False, 'sre_constants.error: unknown')
    
    app.static('/static/', 'static')
    routes = app.router.routes_all
    assert len(routes) == 2

# Generated at 2022-06-21 23:29:11.159460
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic import Sanic
    from sanic.response import  json, text

    app = Sanic('test_RouteMixin_head')
    RouteMixin.init_app(app, {})

    @app.route('/', methods=['GET','POST','HEAD','OPTIONS'])
    async def test(request):
        return json({'test':True})

    request, response = app.test_client.head('/')

    assert response.status == 200
    assert response.text == ''


# Generated at 2022-06-21 23:29:20.718942
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Server()
    assert app.router is not None
    assert app.static is not None
    assert app._middlewares is list
    #assert app._error_handlers is list
    #assert app._listeners is dict
    assert app._http_exception_handlers is dict

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 23:29:23.891173
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    mixin = RouteMixin()

    assert mixin.routes == []
    assert mixin.error_handler_definitions == {}
    assert mixin.blueprint == None



# Generated at 2022-06-21 23:29:28.813172
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    # set up the context
    handler = None
    uri = "/"
    host = None
    strict_slashes = None
    subprotocols = None
    version = None
    name = "main-page"
    # test the function
    result = RouteMixin().add_websocket_route(handler, uri, host, strict_slashes, subprotocols, version, name)
    print(str(result))

if __name__ == "__main__":
    test_RouteMixin_add_websocket_route()

# Generated at 2022-06-21 23:29:41.180380
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.request import Request as SanicRequest
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.router import Route
    app = application.Sanic("route_mixin_test")
    # Testing patch method without a request
    route = RouteMixin(app)
    result = route.patch(uri=None,host=None,methods=None,name=None)
    assert result
    # Testing patch method with a request
    request = SanicRequest(uri=None,method=None,headers=None,body=b"",transport=None,protocol=None,ip=None)
    route = RouteMixin(app)

# Generated at 2022-06-21 23:29:52.122692
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.router import Route
    from unittest.mock import Mock

    instance = RouteMixin()
    function = Mock()
    function.__dict__ = {
        "name": "name",
        "__name__": "name",
        "__qualname__": "name",
    }

    @functools.wraps(function)
    def _arguments_handler(request, uri, *args, **kwargs):
        function(*args, **kwargs)

    ## testing cases
    # case 1
    routes, decorate = instance.websocket(
        uri='path',
        host=None,
        subprotocols=None,
        version=2,
        name='name',
    )

    assert isinstance(routes, list)

# Generated at 2022-06-21 23:30:04.411992
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.constants import HTTP_METHODS
    from sanic.router import Route
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

    host = "0.0.0.0"
    port = 8000
    host_info = "http://0.0.0.0:8000"

    router = Router()
    app = Sanic(__name__, router=router)

    handler_mapping_size = 0
    for method in HTTP_METHODS:
        handler_mapping_size += len(getattr(Router, method))
    assert handler_mapping_size == 0

    # add route

# Generated at 2022-06-21 23:30:15.908777
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.app import Sanic
    app = Sanic(__name__)
    for _ in range(3):
        @app.route('/')
        async def handler(request):
            return request.app.name
    assert len(app.router.routes_all) == 3
    for _ in range(3):
        @app.route('/', methods=['GET', 'POST'])
        async def handler(request):
            return request.app.name
    assert len(app.router.routes_all) == 6
    # with strict_slashes
    for _ in range(3):
        @app.route('/', strict_slashes=True)
        async def handler(request):
            return request.app.name

# Generated at 2022-06-21 23:30:57.663346
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    x=RouteMixin()

# Generated at 2022-06-21 23:31:10.828850
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    'post should return a route that has its method set to "POST"'
    #Procedure
    # 1. create a RouteMixin
    # 2. call post
    # 3. check the return value
    # 4. repeat steps 2 and 3 with verb "GET"
    # 5. repeat steps 2 and 3 with verb "PUT"
    # 6. repeat steps 2 and 3 with verb "PATCH"
    # 7. repeat steps 2 and 3 with verb "DELETE"
    # 8. repeat steps 2 and 3 with verb "OPTIONS"
    class Sanic(RouteMixin):
        pass
    sanic = Sanic()
    route = sanic.post("uri")

    assert(route.method == "POST")
    route = sanic.get("uri")
    assert(route.method == "GET")
    route = sanic

# Generated at 2022-06-21 23:31:22.156333
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    import ddt
    from sanic.response import text

    @ddt.ddt
    class RouteMixinTest(unittest.TestCase):
        def setUp(self):
            self.app = Sanic('test_route_method')
            self.route_mixin = RouteMixin(self.app)

        @ddt.file_data(path.join(dirname(__file__), 'test_data/route_data.json'))
        def test_route_args(self, value):
            value['app_name'] = self.app.name
            response = text('OK')
            name = value['name']
            if name == 'test1':
                actual = self.route_mixin.route(uri=value['uri'])\
                    (response)

# Generated at 2022-06-21 23:31:29.615943
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.config import Config
    from sanic.constants import LOGGING
    from sanic.log import create_logger
    from sanic.exceptions import AddRouteError

    app = Sanic("Sanic-Web")
    app.config.LOGO = None
    app.config.KEEP_ALIVE = False
    app.config.WEBSOCKET_KEEP_ALIVE_TIMEOUT = 0
    app.config.REQUEST_TIMEOUT = 0
    app.config.RESPONSE_TIMEOUT = 0
    app.config.KEEP_ALIVE_TIMEOUT = 0
    app.config.WEBSOCKET_MAX_SIZE = None
    app.config.WEBSOCKET_MAX_QUEUE = None
    app

# Generated at 2022-06-21 23:31:31.743022
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    instance = RouteMixin()
    assert instance.head is None

# Generated at 2022-06-21 23:31:43.354815
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    router = RouteMixin()
    @router.get('/hello')
    async def hello(request):
        return response.text('hello world')
    assert list(router.routes_names.keys())[0] == 'hello'
    assert router.routes_names['hello'] == hello
    assert router.routes_names['hello'].__name__ == 'hello'
    assert router.routes['hello'].name == 'hello'
    assert router.routes['hello'].methods == ['GET', 'HEAD']
    assert type(router.routes['hello'].uri) is sanic.routing.Path
    assert router.routes['hello'].uri.strict_slashes == True
    assert router.routes['hello'].uri.name == 'hello'


# Generated at 2022-06-21 23:31:51.680710
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic("sanic-style-test")
    app.delete("/delete_test/", callback=delete_callback)

    request, response = app.test_client.delete("/delete_test/")
    assert response.status == 200
    assert response.json == {
        "args": {},
        "cookies": {},
        "data": b"",
        "files": {},
        "form": {},
        "json": None,
    }


# Generated at 2022-06-21 23:31:57.567964
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    class MyRouteMixin(RouteMixin):

        def __init__(self, name):
            super().__init__(name)

    mixin = MyRouteMixin('myroutermixin')
    assert mixin.name == 'myroutermixin'


# Generated at 2022-06-21 23:32:01.978559
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    loop = asyncio.get_event_loop()
    loop.create_task(start_server())
    sanic = Sanic('sanic-server')
    delete = RouteMixin.delete
    await delete(self,uri,host,strict_slashes,version,name,apply)

# Generated at 2022-06-21 23:32:13.263582
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    app = Sanic(__name__)

    async def test_handler(request):
        pass

    # def test_handler(request):
    #     return text("I am a get request")

    request, response = app.test_client.get("/")

    assert response.status == 404
    app.add_route(test_handler, "/", methods=["GET"])
    request, response = app.test_client.get("/")
    assert response.status == 200
    content = response.text
    # assert content == "I am a get request"


# Generated at 2022-06-21 23:32:56.489541
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass


# Generated at 2022-06-21 23:32:58.623106
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    route = RouteMixin()
    assert route != None
    

# Generated at 2022-06-21 23:33:10.241865
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    app = Sanic("sanic-server")
    assert isinstance(app, Sanic)

    class RouteMixin:
        def post(self, uri, host=None, strict_slashes=None, version=None, name=None, apply=True):
            return self.route(
                uri=uri,
                host=host,
                methods=["POST"],
                strict_slashes=strict_slashes,
                version=version,
                name=name,
                apply=apply,
            )


# Generated at 2022-06-21 23:33:21.716759
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset

    app = Sanic("test_websocket")
    router = app.router
    route_mixin = RouteMixin()
    uri = "static/uri"
    host = "static/host"
    strict_slashes = "static/strict_slashes"
    subprotocols = "static/subprotocols"
    version = "static/version"
    name = "static/name"
    websocket = "static/websocket"
    apply = "static/apply"

# Generated at 2022-06-21 23:33:24.493665
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
  try:
    router1 = Router()
  except TypeError:
    pass


# Generated at 2022-06-21 23:33:33.468698
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    from sanic.router import Route
    from unittest import mock

    route_mixin = RouteMixin()
    route_mixin.route = mock.Mock(return_value=Route)

    uri = "test uri"
    host = "test host"
    methods = "test methods"
    strict_slashes = "test strict_slashes"
    version = "test version"
    name = "test name"
    route_mixin.delete(
        uri=uri,
        host=host,
        strict_slashes=strict_slashes,
        version=version,
        name=name,
    )


# Generated at 2022-06-21 23:33:43.129678
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic.constants import WEBSOCKET_UPGRADE
    from sanic.constants import HTTP_METHODS
    from sanic.websocket import WebSocketProtocol

    class TestRouteMixin(RouteMixin):
        pass

    route_mixin = TestRouteMixin()
    websocket_handler = lambda x: x + 1
    route_mixin.add_websocket_route(
        websocket_handler,
        uri='/websocket/',
        host=None,
        strict_slashes=None,
        subprotocols=None,
        version=None,
        name=None,
    )

# Generated at 2022-06-21 23:33:46.006898
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    websocket = Mock()
    response = websocket(host="host")

    assert(response == websocket)

# Generated at 2022-06-21 23:33:50.779377
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    # Initialize the test client
    app = Sanic('test_app')

    @app.delete('/')
    async def test(request):
        return text('OK')

    request, response = app.test_client.delete('/')

    assert response.text == 'OK'

# Generated at 2022-06-21 23:34:02.710225
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():

    def tester(**kwargs):
        
        return None

    params = {
        "uri": "/test",
        "host": None,
        "version": None,
        "strict_slashes": None,
        "name": None,
        "apply": True,
    }

    uri = params["uri"]
    host = params["host"]
    version = params["version"]
    strict_slashes = params["strict_slashes"]
    name = params["name"]
    apply = params["apply"]
    kwargs = {}
    kwargs.update({
        "host": host,
        "version": version,
        "strict_slashes": strict_slashes,
        "name": name,
        "apply": apply,
    })
    expected = tester(**kwargs)

   