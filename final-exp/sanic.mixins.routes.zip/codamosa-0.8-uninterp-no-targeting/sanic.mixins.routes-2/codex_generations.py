

# Generated at 2022-06-21 23:25:45.816875
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
  assert 1==1
RouteMixin.head = head

# Generated at 2022-06-21 23:25:50.227273
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    router = Router()
    router.delete("/delete", lambda r: HTTPResponse())
    assert router.routes_names.get("/delete") == "delete"
    assert router.routes[0][2]["methods"] == ["DELETE"]
    assert router.routes[0][2]["uri"] == "/delete"
    assert isinstance(router.routes[0][2]["handler"], FunctionType)


# Generated at 2022-06-21 23:25:56.016472
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    config_for_all_routes = {
        'strict_slashes': False,
        'host': None,
        'uri_prefix': '/api/v1'
    }
    mixin = RouteMixin(**config_for_all_routes)
    assert mixin


# Generated at 2022-06-21 23:26:04.187413
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    router = Route.RouteMixin()
    uri = "path/to/service"
    version = 1
    # Test for sanic.router.Route
    assert type(router.add_route(uri, version=version)) is Route
    # Test for TypeError by passing different type of function handler
    try:
        router.add_route(uri, version=version)(1234)
    except TypeError:
        pass
    else:
        assert False, "Test failed"
    # Test for TypeError by passing method of class
    try:
        class TestClass:
            def method(self):
                return
        router.add_route(uri, version=version)(TestClass.method)
    except TypeError:
        pass
    else:
        assert False, "Test failed"


# Generated at 2022-06-21 23:26:13.269814
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    data = []
    def method(request, *args, **kwargs):
        data.append(request)
    app = Sanic(__name__)
    instance = RouteMixin(app)
    instance.delete('/test_url/test_route', host=None, strict_slashes=None, version=None, name=None)(method)
    request = Request()
    req = Mock(return_value=request)
    instance.app.request = req
    instance.app.config.KEEP_ALIVE = False
    instance.app.config.KEEP_ALIVE_TIMEOUT = 5
    result = instance.dispatch_request(request, {}, {}, {}, {})
    assert result == method
    assert data[0] == request
    assert instance.app.request == req

# Generated at 2022-06-21 23:26:14.293699
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    pass

# Generated at 2022-06-21 23:26:22.342596
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.response import text
    from sanic.router import Route
    
    
    def one(request):
        return text("OK")


    route = Route("/", one, host=None, methods=("PATCH",), version=None, name=None, strict_slashes=None, websocket=None, stream=None, static=None, path_params_factory=None, alias=None)
    assert route.methods == ['PATCH', 'PATCH']
    
    

# Generated at 2022-06-21 23:26:27.574389
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    route = RouteMixin()
    assert route.head._name.startswith("head_")
    assert type(route.head._name) is str
    assert "head_" in route.head._name
    

# Generated at 2022-06-21 23:26:34.321946
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    @asyncio.coroutine
    def handler(*args, **kwargs):
        return True

    try:
        route = Route()
        result = route.route(
            uri="/",
            methods=None,
            host=None,
            strict_slashes=None,
            version=None,
            name=None,
            apply=True,
            subprotocols=None,
            websocket=False
        )(handler)
        print("test_RouteMixin_route: ", result)
    except Exception as e:
        print("test_RouteMixin_route: ", e)
        return False
    return True


# Generated at 2022-06-21 23:26:41.866395
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    app = Sanic('test')
    with pytest.raises(TypeError):
        app.put('/', '/')
    with pytest.raises(TypeError):
        app.put('/')
    with pytest.raises(TypeError):
        app.put()
    with pytest.raises(ValueError):
        app.put('/', methods=2)


# Generated at 2022-06-21 23:27:08.630043
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    pass

# Generated at 2022-06-21 23:27:16.650477
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from unittest.mock import Mock, call, patch
    from sanic.exceptions import InvalidUsage
    from sanic.constants import DEFAULT_SUBPROTOCOLS
    from sanic.router import Route, RouteExists
    from sanic.request import RequestParameters
    from sanic.websocket import WebSocketProtocol
    from sanic.response import HTTPResponse

    request_mock = Mock()
    request_mock.app = Mock()
    request_mock.app.config = {
        "REQUEST_MAX_SIZE": 100,
        "REQUEST_TIMEOUT": 60
    }
    request_mock.app.request_class = RequestParameters
    request_mock.app.websocket_protocol_class = WebSocketProtocol

    router_mock = Mock()


# Generated at 2022-06-21 23:27:20.553133
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    @RouteMixin.route('/')
    def func1(request):
        return text('Hello world!')
    pass



# Generated at 2022-06-21 23:27:31.581577
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    print("\n# Test RouteMixin class")
    app = Sanic("route_test")
    # test_RouteMixin_route_1
    print("\n## test_RouteMixin_route_1")
    # simplified version
    async def handler(request, name=None):
        pass

    @app.route("/route_test_route_1", methods=["GET", "POST"])
    @app.route("/route_test_route_2", methods=["PUT", "DELETE"], name="route_2")
    async def handler(request, name=None):
        pass

    assert len(app.router.routes_names["GET"]) == 1
    assert app.router.routes_all[0][1].name == "handler"
    assert app.router.routes

# Generated at 2022-06-21 23:27:32.294630
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    pass


# Generated at 2022-06-21 23:27:38.880600
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    class Router(RouteMixin):
        def __init__(self): # noqa: E301
            super().__init__()

            self.strict_slashes = True
            self.version = 1
            self.name = "MyApp"
            self.route = None
            self.url_for = None
            self.websocket = None

    router = Router()
    assert router.strict_slashes is True
    assert router.version == 1
    assert router.name == "MyApp"



# Generated at 2022-06-21 23:27:49.713862
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # create a new app
    app = Sanic(__name__)

    # test if the app is an object of class Sanic
    assert type(app) == Sanic

    # test if the message property is created
    assert app.message == ""

    # test if the uri_pattern property is created
    assert app.uri_pattern == ""

    # test if the routes property is created
    assert app.routes == []

    # test if the route_host property is created
    assert app.route_host == ""

    # test if the route_strict_slashes property is created
    assert app.route_strict_slashes == None

    # test if the route_version property is created
    assert app.route_version == None

    # test if the route_methods property is created

# Generated at 2022-06-21 23:27:52.482072
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    uri = ""
    host = "amazonaws.com"
    methods = "<class 'NoneType'>"
    strict_slashes = "<class 'NoneType'>"
    version = "<class 'NoneType'>"
    name = "test_name"
    apply = True
    obj = RouteMixin()
    #obj.post(uri,host,methods,strict_slashes,version,name,apply)
    assert True


# Generated at 2022-06-21 23:28:01.529375
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    app = Sanic("test_RouteMixin_get")
    test_route = "/test"
    test_strict_slashes = None
    test_host = None
    test_version = None
    test_name = None
    test_websocket = False
    test_stream = False
    test_strict_slashes = None
    test_apply = True
    test_methods = ["GET"]
    test_uri = "/test"
    test_handler = lambda x: x
    def test_handler(x: None) -> None: 
        pass

# Generated at 2022-06-21 23:28:11.860667
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    with pytest.raises(ValueError, match=r"version must be provided."):
        RouteMixin().put(uri="bla")
    with pytest.raises(ValueError, match=r"version must be provided."):
        RouteMixin().put("bla")
    with pytest.raises(ValueError, match=r"version must be provided."):
        RouteMixin().put(version="bla",uri="bla")
    with pytest.raises(ValueError, match=r"version must be provided."):
        RouteMixin().put(uri="bla",version=None)
    with pytest.raises(ValueError, match=r"handler must be provided."):
        RouteMixin().put(uri="bla",version="bla")

# Generated at 2022-06-21 23:28:42.374987
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # static route
    with pytest.raises(TypeError):
        RouteMixin.post()


# Generated at 2022-06-21 23:28:52.502715
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic.request import Request
    from sanic.router import Route

    class MockRoute(Route):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, uri="", **kwargs)

    def handler(*args, **kwargs):
        return "OK"

    def handler_async(*args, **kwargs):
        return "OK"

    app = Sanic(__name__)

    assert isinstance(
        app.post("/", host="testhost", strict_slashes=False, version=123)(
            handler
        ),
        MockRoute,
    )

# Generated at 2022-06-21 23:28:57.346679
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    with Sanic("test_options") as app:
        @app.route("/")
        def handler(request):
            return text("OK")
        response = app.test_client.options("/")
        assert response.status == 200


# Generated at 2022-06-21 23:29:06.271710
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    import pytest
    from sanic import Sanic
    from sanic.response import HTTPResponse
    
    app = Sanic(__name__)
    uri = r'/post_test/user/<id:[0-9]+>'
    k = Sanic('test').blueprint(uri)
    assert k is not None
    assert hasattr(k, 'post')
    assert callable(k.post)
    
    @k.post(uri, host='example.com')
    async def handler(request, id):
        return HTTPResponse(status=200)
    
    assert handler is not None
    assert callable(handler)
    
    request, response = app.test_client.get('/post_test/user/1')
    assert response.status == 404
    
    request, response

# Generated at 2022-06-21 23:29:11.473714
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():

    routes, RouteMixin = RouteMixin.get(uri=None, host=None, methods=["GET"], strict_slashes=None, version=None, name=None, apply=True)
    assert routes == []
    assert RouteMixin.strict_slashes == None


# Generated at 2022-06-21 23:29:15.921296
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    import doctest
    from . import sanic
    doctest.run_docstring_examples(sanic.RouteMixin.add_websocket_route, globals())

# Generated at 2022-06-21 23:29:22.713159
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    #
    r = RouteMixin()
    #
    @r.put('/test/')
    #
    def handler(request):
        log.info('Got request to /test/')
        return text('OK')
    #
    tester = app.test_client(r)
    #
    assert tester.put('/test/').status == 200


# Generated at 2022-06-21 23:29:34.105183
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    from sanic_openapi import doc, doc_attr
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse, json
    import sanic.routing
    import sanic.exceptions
    import sanic.helpers
    import sanic.utils
    import sanic.__main__
    import sanic.response
    import sanic.websocket
    import sanic.blueprints
    import sanic.server
    import sanic.app
    import sanic.log
    import sanic.views
    import sanic.exceptions
    import sanic.handlers
    import sanic.signals
    import sanic.constants
    import sanic.router
    import sanic.config
    import sanic.response
    import sanic.request


# Generated at 2022-06-21 23:29:39.813260
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic('test')

    @app.delete('/')
    def handler(request):
        pass

    uri = '/'
    request = Request.get(uri, protocol='http')

    routes = list(app._router.routes_all.get(request.method))
    assert len(routes) == 1

    route = routes[0]
    assert isinstance(route, Route)
    assert route.handler == handler
    assert route.methods == ['DELETE']
    assert isinstance(route.uris, re._pattern_type)
    assert route.strict_slashes == True
    assert route.host == None
    assert route.version == None
    assert route.name == None
    assert route.static == False
    assert route.websocket == False

# Generated at 2022-06-21 23:29:51.014152
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    route_mixin = RouteMixin()
    app = Sanic('test_RouteMixin_route')
    
    # prepare mock for method 'handle_request'
    with patch.object(route_mixin, 'handle_request') as mock_handle_request:
        route_mixin.route('/test', methods=['GET', 'POST'], version=1)(lambda request: None)
        mock_handle_request.assert_called_once_with(
            uri='/test',
            methods=['GET', 'POST'],
            host=None,
            strict_slashes=None,
            version=1,
            name=None,
            stream=False,
            websocket=False,
            static=False,
            apply=True,
            subprotocols=None
        )

# Generated at 2022-06-21 23:30:21.545741
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic import Sanic
    from sanic.router import Route

    app = Sanic()
    mixin = RouteMixin(app)

    @app.route("/")
    async def return_foo(request):
        return text(request.method)

    @app.websocket("/")
    async def return_foo(request, ws):
        return text(request.method)

    assert len(app.router.routes_names.keys()) == 2
    assert set(app.router.routes_names.keys()) == {"return_foo", ""}
    assert isinstance(app.router.routes_all[0], Route)
    assert isinstance(app.router.routes_all[1], Route)

# Generated at 2022-06-21 23:30:27.326694
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # initialization
    global_config["router"] = Router()
    class A(RouteMixin):
        def __init__(self):
            self.name = "A"
            self.strict_slashes = "A"
        def _generate_name(self, *objects):
            return "B"
        def _apply_static(self,static):
            return "C"
        async def _static_request_handler(self,file_or_directory,use_modified_since,use_content_range,stream_large_files,request,content_type=None,__file_uri__=None):
            return "D"
        def _register_static(self,static):
            return "E"
    a = A()

    # start test

# Generated at 2022-06-21 23:30:30.038001
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    route = RouteMixin()
    class test():
        
        async def test(self, request, ws):
            pass
    class mws():
        def __init__(self):
            self.ms = test()
        def __call__(self, *args, **kwargs):
            return self.ms

    route.add_websocket_route(mws(), uri='ws', host=None)

# Generated at 2022-06-21 23:30:39.397409
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Route

    app = Sanic("test_RouteMixin_head")
    test_route = Route(app, ["HEAD"], "/test", "test", fakes.test_handler)
    fake_request = Request(app.create_server_request("test"), app)
    fake_request.method = "HEAD"
    fake_request.path = "/test"
    response = test_route.handler(fake_request)

    assert response.status == 200
    assert response.text == ""
    assert response._body == b""

# Generated at 2022-06-21 23:30:45.632066
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    class RouteMixinTest(RouteMixin):
        def __init__(self):
            super().__init__()

    route_mixin = RouteMixinTest()    
    
    request, resp = route_mixin.opts(request=None)

    assert resp.status == 200


# Generated at 2022-06-21 23:30:59.921725
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    import pytest
    from .server import Sanic

    app = Sanic("test_app")
    # Test for the method route in class RouteMixin
    @app.route("/test1")
    def handle_request(request):
        return text("OK")

    request, response = app.test_client.get("/test1")
    assert response.status == 200

    @app.route("/test2", methods=['GET', 'POST'])
    def handle_request(request):
        return text("OK")


    request, response = app.test_client.options("/test2")

    assert response.text == "GET, POST"
    assert response.headers["Allow"] == "GET, POST"
    assert response.headers["Content-Length"] == "0"

    # Test for adding route

# Generated at 2022-06-21 23:31:07.486438
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic(__name__)
    route, handler_1 = app.route(uri='/', methods=None,
    strict_slashes=None, version=None, name=None)
    @route
    async def handler_3(request):
        return text('OK')
        
    assert handler_1.name=='handler_3'

# Generated at 2022-06-21 23:31:20.658092
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.router import Route, RouteExists
    from sanic.app import Sanic

    uri = "/"
    methods = ["GET", "HEAD"]
    handler = ""
    name = "test_route"
    host = None
    strict_slashes = True
    stream = False
    version = None
    route_methods = ["GET", "HEAD"]
    version = None
    status_code = 200
    # -----
    route = Route(uri, methods, handler, name, host, strict_slashes, stream, version, route_methods, version, status_code)
    from unittest.mock import Mock
    sanic = Sanic(__name__)
    sanic_app = Mock(spec=sanic)
    sanic_app.url_for = Mock()

# Generated at 2022-06-21 23:31:24.234871
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    routeMixin = RouteMixin()
    assert isinstance(routeMixin, RouteMixin)

# Generated at 2022-06-21 23:31:31.533024
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    app = Sanic('test_RouteMixin_patch')
    request_ctx_var = RequestContextVar()
    request_ctx_var.set({
        "base_url": "",
        "app": app,
        "request": Request(app),
        "transport": None,
        "protocol": None
    })
    # SUT
    app.route_patch(uri='/test')
    assert app.router.routes_all['test.patch'].methods == ['PATCH']



# Generated at 2022-06-21 23:32:14.565272
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    pass



# Generated at 2022-06-21 23:32:16.009597
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass
    

# Generated at 2022-06-21 23:32:17.471556
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    test_obj = RouteMixin()

# Generated at 2022-06-21 23:32:27.421619
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
	class Router_Mock:
		def add_route(self, uri, handler, methods, host, strict_slashes, version, name, stream, apply, **kwargs):
			return
	class Sanic_Mock:
		def __init__(self):
			self.router = Router_Mock()
			self.name = "sanic_mock"

	route_mixin = RouteMixin(Sanic_Mock())
	@route_mixin.put('uri', 'handler', 'methods', 'host', 'strict_slashes', 'version', 'name', 'stream', 'apply', '**kwargs')
	def decorated(request):
		return
	decorated(None)


# Generated at 2022-06-21 23:32:36.181187
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from run import app

    # Test 1 - create a RouteMixin instance
    RouteMixin_instance = RouteMixin()

    # Test 2 - add a websocket route
    RouteMixin_instance.add_websocket_route(lambda ws: None, uri='/')

    assert len(app.router.routes_names) == 1
    assert '/' in app.router.routes_names
    assert app.router.routes_names['/'] == 'static'

test_RouteMixin_add_websocket_route()

# Generated at 2022-06-21 23:32:48.089153
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.response import text
    from sanic.router import Route

    # Create a fake app
    app = Sanic("sanic-router-test")
    
    # Create a fake method to use inside the test
    async def handler(request):
        return text("OK")

    # Apply the fake method to the fake app
    app.put("/test_put")(handler)

    # Assert the output has one route
    assert len(app.router.routes_all['PUT']) == 1

    # Extract the route
    route = app.router.routes_all['PUT'][0]

    # Assert its type is "Route"
    assert isinstance(route, Route)

    # Assert its URL is "/test_put"
    assert route.uri == "/test_put"

   

# Generated at 2022-06-21 23:32:53.281422
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    class TestRouterMixin(RouterMixin):
        def __init__(self, name: str = None, strict_slashes: bool = None):
            super().__init__()

    return TestRouterMixin


# Generated at 2022-06-21 23:32:55.045253
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    mixin = RouteMixin()
    assert "RouteMixin" == mixin.__class__.__name__

# Generated at 2022-06-21 23:33:08.559605
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    import asyncio
    
    class Bogus:
        pass
    their_websocket = [
            'get', 'post', 'delete', 'put', 'patch', 'head', 'options']
    
    def check_web_support(Web):
        supported_methods = []
        for i in dir(Web):
            if i in their_websocket:
                supported_methods.append(i)
        return supported_methods
    
    class TestRouteMixin(RouteMixin):
    
        def websocket(self, uri, host=None, strict_slashes=None,
                      subprotocols=None, version=None, name=None,
                      apply=True):
            return super().websocket(uri, host, strict_slashes, subprotocols,
                                     version, name, apply)

# Generated at 2022-06-21 23:33:13.367173
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    class _RouteMixin(RouteMixin):
      pass
    self = _RouteMixin()
    uri = "a"
    host = None
    strict_slashes = None
    subprotocols = None
    version = None
    name = "user"
    apply = True
    assert self.websocket(uri, host, strict_slashes, subprotocols, version, name, apply)
    uri = "b"
    host = "a"
    strict_slashes = True
    subprotocols = "a"
    version = 1
    name = "user"
    apply = True
    assert self.websocket(uri, host, strict_slashes, subprotocols, version, name, apply)
    uri = "c"
    host = "a"

# Generated at 2022-06-21 23:34:14.101141
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    
    """
        Unit test for class RouteMixin method delete:
            1) create a method and a object of class RouteMixin
            2) call the method delete on this object
            3) assert the result of this method call
    """
    def create_app():
        app = Sanic('test_app')
        @app.route('/route_mixin_delete')
        def root(request):
            return text('Test for method delete of class RouteMixin')
        return app
    apps = {'delete':create_app()}
    for key, value in apps.items():
        value.router = Router(value)
        value.router.add(request_handler=value.handle_request,
                                    uri='/route_mixin_delete',
                                    methods=['GET'])
        value.route = value

# Generated at 2022-06-21 23:34:22.702456
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    app = Sanic('test')
    # Testing raise exception when a function is not passed
    with pytest.raises(ValueError):
        app.head('/test')

    # Testing raise exception when a function is passed
    # but the function doesn't have a __name__ attribute
    @app.head('/test')
    def example():
        pass



# Generated at 2022-06-21 23:34:27.134049
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    r = RouteMixin()
    assert r.post(routes=routes) == None

# Generated at 2022-06-21 23:34:32.562729
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # Test Arguments
    uri = "/"
    strict_slashes = None
    version = None
    name = None
    apply = True

    # Test Variables
    expected_return = None

    # Method Under Test
    route_mixin = RouteMixin()
    return_value = route_mixin.head(uri, strict_slashes, version, name, apply)

    assert return_value == expected_return



# Generated at 2022-06-21 23:34:39.174182
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route = RouteMixin()
    route.static(uri = '', file_or_directory = '.', pattern = r'/?.+', use_modified_since = True, use_content_range = False, stream_large_files = False, name = 'static', host = None, strict_slashes = None, content_type = None, apply = True)
    print(route._static_request_handler())


# Generated at 2022-06-21 23:34:42.369631
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    with pytest.raises(Exception) as exec:
        method_patch()
    assert "raise NotImplementedError" in str(exec.value)



# Generated at 2022-06-21 23:34:44.320102
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # for now, we do not test this method
    pass
# class Router

# Generated at 2022-06-21 23:34:47.607950
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    router = RouteMixin("name",  strict_slashes=False, version=1)
    router.options("/api/<string:param>")



# Generated at 2022-06-21 23:34:48.032969
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass

# Generated at 2022-06-21 23:34:57.672376
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route

    app = Sanic("test_RouteMixin_add_route")

    #  register_route(self, uri, handler, methods, host=None, strict_slashes=None, version=None, name=None):
    @app.route("/", methods=["PATCH"])
    def handler(request):
        assert request is not None

    @app.websocket("/")
    async def handler_socket(request, ws):
        assert request is not None

    assert type(app.router.routes_all[0]) == Route
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].method == "PATCH"
    assert app.rou