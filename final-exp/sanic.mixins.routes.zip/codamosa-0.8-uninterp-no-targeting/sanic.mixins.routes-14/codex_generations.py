

# Generated at 2022-06-21 23:26:08.099427
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic import Sanic
    app = Sanic()
    r = RouteMixin(app)
    r.add_websocket_route(lambda a,b: 0, "uri", "host", "strict_slashes", "subprotocols", "version", "name")

# Generated at 2022-06-21 23:26:16.522053
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    r = RouteMixin()
    handler = lambda x: print('handler')
    uri = '/test'
    host = '127.0.0.1'
    methods = 'GET'
    strict_slashes = True
    version = 1
    name = 'test'
    route = r.add_route(handler, uri, host=host, methods=methods, strict_slashes=strict_slashes, version=version, name=name)
    assert route.uri == '/test'
    assert route.host == '127.0.0.1'
    assert route.methods == ('GET',)
    assert route.strict_slashes == True
    assert route.version == 1
    assert route.name == 'test'
    assert route.routes == set()
    assert route.handlers == [handler]

# Generated at 2022-06-21 23:26:19.787013
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    app1 = Sanic('test_RouteMixin_head')
    app2 = Sanic('test_RouteMixin_head')
    # test different internal and external function
    wrapped_app1 = RouteMixin().head('/test1')(app1)
    wrapped_app2 = RouteMixin().head('/test1', name='test_name')(app2)
    assert wrapped_app1.name != wrapped_app2.name

# Generated at 2022-06-21 23:26:32.818582
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    raw_route_mixin = RouteMixin()
    uri = "hello/"
    handler = None
    host = None
    strict_slashes = None
    methods = "GET, PUT"
    version = None
    name = None
    stream = False
    verify_ssl = False
    ssl = None
    endpoint = None

    raw_route, _ = raw_route_mixin.route(
        uri,
        handler,
        host,
        methods,
        strict_slashes,
        version,
        name,
        stream,
        verify_ssl,
        ssl,
        endpoint,
    )
    route_mixin = RouteMixin()

# Generated at 2022-06-21 23:26:34.675228
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
  # test code
  pass

# Generated at 2022-06-21 23:26:44.989981
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from typing import Union
    from sanic import Sanic

    class TestClass(RouteMixin):
        pass

    test_obj = TestClass()

    url = 'test_1'
    handler = 'test__1'
    methods = 'test_3'
    host = 'test_4'
    strict_slashes = 'test_5'
    version = 'test_6'
    name = 'test_7'
    status = 'test_8'
    stream = 'test_9'
    timeout = 'test_10'
    expose_traceback = 'test_11'


    # test with only the required params
    test_obj.add_route(url,handler)

    # test with all the params

# Generated at 2022-06-21 23:26:57.855775
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.response import text
    from sanic.router import Route
    from sanic.websocket import WebSocketProtocol

    # RouteMixin
    from sanic.router import RouteMixin

    # initialize

    # RouteMixin
    class TestMixin(RouteMixin):
        def __init__(self):
            self.strict_slashes = True
            self.host = None
            self.name = 'route_mixin'
            self.started = False
            self.blueprints_enabled = False

    route_mixin = TestMixin()

    # route
    uri = '/'
    host = None
    methods = ('GET',)
    strict_slashes = True
    version = None
    name = None
    apply = True
    stream = False
    websocket = False
    static

# Generated at 2022-06-21 23:27:04.675184
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # arrange
    class SubRouter(RouteMixin):
        pass

    sub_router = SubRouter()
    assert sub_router.name == "sanic_router"

    class MyRouter(RouteMixin):
        pass

    my_router = MyRouter(name="myrouter")
    assert my_router.name == "myrouter"


# Generated at 2022-06-21 23:27:05.879212
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass


# Generated at 2022-06-21 23:27:06.606968
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    assert True

# Generated at 2022-06-21 23:27:16.841870
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
  pass

# Generated at 2022-06-21 23:27:30.032901
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.router import Route

    def test1(): pass

    route_mixin = RouteMixin()
    route_mixin.route = Mock(return_value=Route)
    route_mixin.websocket(uri="/testuri",
                        host="127.0.0.1",
                        subprotocols=["test1"],
                        version=1,
                        name="test1")(test1)

    # Verify calls
    route_mixin.route.assert_called_with(uri="/testuri",
                                        host="127.0.0.1",
                                        strict_slashes=None,
                                        methods=None,
                                        version=1,
                                        name="test1",
                                        apply=True,
                                        subprotocols=["test1"],
                                        websocket=True)



# Generated at 2022-06-21 23:27:33.642278
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Setup
    app = MagicMock()
    app_route = MagicMock()
    app_route.route = MagicMock(return_value=app_route)
    app.route = MagicMock(return_value=app_route)

    router = RouterMixin()
    router.app = app

    # Exercise
    routes = router.post("uri")

    # Verify
    assert routes == [app_route]
    app.route.assert_called_with("POST", "uri")


# Generated at 2022-06-21 23:27:38.137661
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic.blueprints import Blueprint

    bp = Blueprint(__name__)

    @bp.patch('/patch')
    def patch_func(request):
        return response.text('I am a PATCH')

    # Unit test for method post of class RouteMixin

# Generated at 2022-06-21 23:27:41.066248
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    app = Sanic('test_RouteMixin_get')
    with pytest.raises(TypeError):
        app.get()
    with pytest.raises(TypeError):
        app.get(uri='/test')
    with pytest.raises(TypeError):
        @app.get(uri='/test')
        async def handler():
            pass


# Generated at 2022-06-21 23:27:51.077084
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    route, _ = RouteMixin.route(uri='/test', methods=['GET', 'POST'], strict_slashes=None, version=None, name=None, apply=True)(partial(lambda: 0))
    assert route.uri == '/test'
    assert route.methods == {'HEAD', 'GET', 'POST'}
    assert route.strict_slashes == False
    assert route.version == None 
    assert route.name == None
    assert route.apply == True
    assert route.websocket == False


# Generated at 2022-06-21 23:27:58.514609
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    router = RouterMixin("test", None)
    method = HTTP_METHODS.index("POST")
    def test_function(test_arg):
        return test_arg
    # test route method
    route = router.route(uri="/test", methods=[method])(test_function)
    assert route[0].uri == "/test"
    assert route[1](None) == None
    assert route[0].methods == [method]

    # test post method
    route = router.post("/test2")(test_function)
    assert route[0].uri == "/test2"
    assert route[1](None) == None
    assert HTTP_METHODS[route[0].methods[0]] == "POST"


# Generated at 2022-06-21 23:28:00.812068
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    A = RouteMixin
    assert 0


# Generated at 2022-06-21 23:28:04.812904
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    new_RouteMixin = RouteMixin()
    assert isinstance(new_RouteMixin, RouteMixin)


# Generated at 2022-06-21 23:28:16.620393
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    try:
        route = RouteMixin()
        route_uri = "http://192.168.1.1"
        route_host = "http://192.168.1.2"
        route_strict_slashes = False
        route_name = 'route name'
        route_method = 'GET'
        route_version = 1
        route.route(route_uri, route_host, route_strict_slashes, route_method, route_version, route_name)
    except Exception as e:
        assert(isinstance(e, TypeError))


# Generated at 2022-06-21 23:28:40.210614
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    class TestRouter(RouteMixin):
        def __init__(self):
            self.websockets = [('/', 'test_websocket')]

        def test_websocket(self, request):
            print(request)
            return 'test entry'
    
    router = TestRouter()
    request = 'test_request'
    result = router.test_websocket(request)
    assert result == 'test entry'


# Generated at 2022-06-21 23:28:51.607307
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    input_method = 'PUT'
    input_uri = '/uri'
    input_host = 'host.com'
    input_strict_slashes = False
    input_version = 'version'
    input_version2 = None
    input_name = 'name'
    input_name2 = None
    input_apply = True

    r = RouteMixin.put(
        input_uri,
        host=input_host,
        strict_slashes=input_strict_slashes,
        version=input_version,
        name=input_name,
        apply=input_apply
    )

    assert r.methods == [input_method]
    assert r.uri == input_uri
    assert r.host == input_host
    assert r.strict_slashes == input_strict_slashes

# Generated at 2022-06-21 23:28:53.301439
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.response import text
    routeMixin = RouteMixin()
    app = Sanic()
    test = routeMixin.head('/')(text('I am a beautiful butterfly'))
    print(app.router)


# Generated at 2022-06-21 23:29:02.737580
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Check the return type
    router = RouteMixin()
    result = router.route('/', methods=['GET'], host="", strict_slashes=False, version=1, name="name", apply=True)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], list)
    assert len(result[0]) == 1
    assert isinstance(result[1], FunctionType)
    # Check the value of return
    route, func = result
    assert isinstance(route[0], Route)
    assert route[0].uri == "/"
    assert route[0].methods == ['GET']
    assert route[0].name == 'name'
    assert route[0].host == ""
    assert route[0].verify_host == None

# Generated at 2022-06-21 23:29:13.306772
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    client = Sanic(__name__)
    sanic_test_client = SanicTestClient(client)
    html = b"<b>Hello world!</b>"
    sanic_test_client.post("/")
    assert (sanic_test_client.response.status == 405)

    client.post("/")(lambda request: response.text(html))

    sanic_test_client.post(url="/", json={"data": "text"})
    assert (sanic_test_client.response.status == 200)
    assert (sanic_test_client.response.text == html)



# Generated at 2022-06-21 23:29:26.097799
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    
    # Test default functionality
    class TestRouteMixin:
        method = "PATCH"
        host = "127.0.0.1"
        version = 1
        strict_slashes = True
        subprotocols = ["ws", "wss"]
    route_mixin = RouteMixin()
    result = route_mixin.patch(
        uri="/",
        host=TestRouteMixin.host,
        strict_slashes=TestRouteMixin.strict_slashes,
        subprotocols=TestRouteMixin.subprotocols,
        version=TestRouteMixin.version,
    )
    assert result
    # Test default functionality
    class TestRouteMixin:
        uri = "/"
        host = "127.0.0.1"
        version = 1
        strict_sl

# Generated at 2022-06-21 23:29:29.430525
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    r = RouteMixin()
    app = Sanic("test_RouteMixin")
    r.add_head_route(
        uri=".*",
        host=None,
        strict_slashes=None,
        name=None,
        version=None,
        apply=True,
    )(app.handle_request)


# Generated at 2022-06-21 23:29:41.794382
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    app = Sanic('test_RouteMixin_post')
    app.route_register = RouteRegister()
    uri = 'test_uri'
    host = 'test_host'
    strict_slashes = True
    name = 'test_name'
    version = 1


    with pytest.raises(TypeError):
        app.post(uri, host, strict_slashes, name, version)
    with pytest.raises(TypeError):
        app.post(uri, host, strict_slashes, name)
    with pytest.raises(TypeError):
        app.post(uri, host, strict_slashes)
    with pytest.raises(TypeError):
        app.post(uri, host)
    with pytest.raises(TypeError):
        app.post(uri, version)


# Generated at 2022-06-21 23:29:47.288812
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # Test for the function put of class RouteMixin
    # Create an instance of class RouteMixin
    router = RouteMixin()
    # Test for the function put of class RouteMixin
    @router.put("/put/")
    async def test(request):
        return text("put")


# Generated at 2022-06-21 23:29:55.341550
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_RouteMixin_patch')

    @app.route('/patch')
    def handler(request):
        return text('OK')

    request, response = app.test_client.patch('/patch')

    assert response.status == 200

    @app.route('/patch_1', methods=['GET', 'PATCH'])
    def handler_1(request):
        return text('OK_1')

    request, response = app.test_client.patch('/patch_1')
    assert response.status == 200

    @app.route('/patch_2', methods=['get', 'patch'])
    def handler_2(request):
        return text('OK_2')

    request, response = app.test_client.patch

# Generated at 2022-06-21 23:30:40.027378
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    mimetype = None
    app = Sanic('test_RouteMixin_static')
    rp = app.url_for('static', filename='static/styles/default.css')
    assert rp == '/static/styles/default.css'
    rp = app.url_for('static', filename='favicon.ico')
    assert rp == '/static/favicon.ico'
    rp = app.url_for('static', filename='styles/default.css')
    assert rp == '/static/styles/default.css'
    rp = app.url_for('static', filename='../styles/default.css')
    assert rp == '/static/styles/default.css'
    rp = app.url_for('static', filename='../../styles/default.css')

# Generated at 2022-06-21 23:30:45.889493
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route

    mixin = RouteMixin()
    assert isinstance(
        mixin.route(uri='/', methods=['GET'], version=1, name='test_route'),
        (Route,)).description == "RouteMixin.route() should return instance of Route"
    

# Generated at 2022-06-21 23:30:47.720973
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # add your implementation here
    pass




# Generated at 2022-06-21 23:30:53.969854
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    """Unit test for method delete of class RouteMixin"""

    router = Router()

    assert router.routes == []

    router.delete(None, None, None, None, None)

    assert router.routes == []


# Generated at 2022-06-21 23:31:05.625397
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.response import json
    def wrap_post(resp):
        if resp.status_code == 200 and resp.content_type == 'text/html':
            resp.content_type = 'application/json'
            resp.body = json({'test': resp.body.decode('utf-8')})

        return resp
    
    app = Sanic()
    app.static(
        '/test_static',
        '/my_static_folder',
        strict_slashes=False,
        name='test_static',
        host='aaa.com',
        content_type='text/html',
    )
    app.register_middleware(wrap_post, 'response')

    request, response = app.test_client.get('/test_static', host='aaa.com')
   

# Generated at 2022-06-21 23:31:13.377974
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    r = RouteMixin()
    assert isinstance(r._routes, list)
    assert len(r._routes) == 0
    assert r.blueprints is None
    assert r.middlewares is None
    assert isinstance(r._future_statics, set)
    assert len(r._future_statics) == 0
    # TODO: add tests
    # assert r.host == None
    # assert r.name == None
    # assert isinstance(r.strict_slashes, bool)
    # assert isinstance(r.url_prefix, str)
    # assert r.version == None
    r.add_route(None,None,None,None,None,None)
    # test for assertion
    # r.add_route(None)

# Generated at 2022-06-21 23:31:23.581741
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.router import Route, add_route

    app = MagicMock()
    app.name = 'app'
    app.strict_slashes = True

    router = MagicMock()
    router.app = app
    router.routes_names = {}
    router._host_matching = True

    mixin = RouteMixin()
    mixin.router = router
    mixin.name = 'mixin'

    func_one = MagicMock()
    func_one.__name__ = 'func_one'
    func_one.__qualname__ = 'func_one'

    func_two = MagicMock()
    func_two.__name__ = 'func_two'
    func_two.__qualname__ = 'func_two'

    mixin_websocket = mixin

# Generated at 2022-06-21 23:31:30.571406
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Inject RouteMixin
    robot = Robot()
    r = robot._convert_func_to_route(
        add_static,
        "/static",
        "./static",
        "./static",
        "./static",
        "./static",
        "./static",
        "./static",
        "./static",
        "./static",
    )
    assert len(r) == 1
    assert r[0].uri == "/static"
    assert r[0].rule == r"\\?.+"
    assert r[0].use_modified_since == "./static"
    assert r[0].name == "./static"

    # Test with no args
    r = robot._convert_func_to_route(add_static)
    assert len(r) == 1

# Generated at 2022-06-21 23:31:42.895222
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    import json
    import pathlib
    import tempfile
    import warnings
    import functools
    import asyncio
    import sys
    import time
    import ssl
    import types
    import uuid
    import asyncio
    import traceback
    import argparse
    import inspect
    import socket
    import logging
    import logging.config
    import inspect
    import types
    import socketserver
    import http.server
    import base64
    import mimetypes
    import subprocess
    import multiprocessing
    import traceback
    from collections import deque
    from multiprocessing.pool import ThreadPool
    from multiprocessing.util import Finalize
    from datetime import datetime
    from functools import partial
    from urllib.parse import parse_qs, unquote, urlparse

# Generated at 2022-06-21 23:31:45.889066
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    ccc = RouteMixin()
    assert True == ccc.websocket(None, None, None, None, None, None)(None)


# Generated at 2022-06-21 23:32:27.531786
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # Instantiation of class RouteMixin
    class RouteMixin():
        def put(self, uri, host=None, strict_slashes=None, version=None, name=None,\
                apply=True):
            pass
    route = RouteMixin()

    # Case 1: Test the function put when parameters are in the right type
    # Expected:
    #     assert True
    uri = '/'
    host = '127.0.0.1'
    strict_slashes = True 
    version = 1
    name = 'name'
    result = route.put(uri, host, strict_slashes, version, name)
    assert isinstance(result, tuple)


# Generated at 2022-06-21 23:32:37.625171
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    rm = RouteMixin()
    uri = "/"
    host = None
    strict_slashes = None
    subprotocols = None
    version = '1.0'
    name = "static"
    handler = '''
    def hello_world(request):
    return response.text('Hello world!')
    '''
    rm.add_websocket_route(handler,uri,host,strict_slashes,subprotocols,version,name)
    assert rm.uri == uri
    assert rm.host == host
    assert rm.strict_slashes == strict_slashes
    assert rm.subprotocols == subprotocols
    assert rm.version == version
    assert rm.name == name
    assert rm.handler == handler


# Generated at 2022-06-21 23:32:46.435720
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic import Sanic
    app = Sanic()
    #kwargs = {
    #    'uri': '/path/10/',
    #    'host': '10.1.1.1',
    #    'version': 5,
    #    'name': 'Hello',
    #    'apply': True
    #}
    #expected_result = ({}, <function <lambda> at 0x10f79a8c8>)
    #result = app.post()
    #assert result == expected_result
    return


# Generated at 2022-06-21 23:32:52.833805
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    sanic = Sanic('test_RouteMixin_delete')

    @sanic.delete('/')
    async def test(request):
        return text('OK')

    request, response = sanic.create_test_request(method='DELETE')
    assert response.text == 'OK'



# Generated at 2022-06-21 23:32:55.800493
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    route_mixin.add_route(handler=None, uri=None, host=None, strict_slashes=None, methods=None, version=None, name=None)


# Generated at 2022-06-21 23:32:57.474903
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass


# Generated at 2022-06-21 23:33:02.176091
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    """
    Test case for method put of class RouteMixin
    """
    test_RouteMixin = RouteMixin()
    test_RouteMixin.put()


# Generated at 2022-06-21 23:33:11.870594
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    # Create a new sanic app server
    app = Sanic("test_RouteMixin_head")

    # Ready to test, create a new instance of RouteMixin
    routeMixin = RouteMixin()

    # Test when method is None (the default value)
    routeMixin.head("/")
    # No need to check the result, it just won't crash

    # Test when method is not None
    routeMixin.head("/", methods=["GET"])

    # Test when app is None (the default value)
    routeMixin.head("/", app=None)
    # No need to check the result, it just won't crash

    # Test when app is not None
    routeMixin.head("/", app=app)

    # Test when version is None (the default value)

# Generated at 2022-06-21 23:33:20.213109
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    from sanic.router import RouteMixin
    from sanic.router import Route

    class TestRouteMixin(RouteMixin):

        name = "TestRouteMixin"

        def __init__(self):
            super().__init__()
            self._routes = []
            self._route_cache = {}
            self._reversed_routes = []
            self._static_routes = {}
            self._middlewares = []
            self._middleware_stack = Chain()
            self._error_handler = {}
            self._exception_handler = {}
            self._host_middleware_stack = {DEFAULT_HTTP_HOST: Chain()}
            self.strict_slashes = None
            self._websocket_tasks = []
            self._future_statics = set()



# Generated at 2022-06-21 23:33:21.306467
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass

# Generated at 2022-06-21 23:33:55.336538
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    pass
 

# Generated at 2022-06-21 23:34:00.621657
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class MyTest(RouteMixin):
        def __init__(self):
            self.name = "sanic"
    r = MyTest()
    r1 = r.add_route(lambda request: "foo","/foo")
    assert r1.name == "sanic.foo"


# Generated at 2022-06-21 23:34:14.352788
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic import Blueprint

    test_app = Sanic("test_RouteMixin_websocket")
    test_bp = Blueprint("test_RouteMixin_websocket")

    @test_app.websocket("/")
    async def handler(request):
        pass

    @test_bp.websocket("/")
    async def handler(request):
        pass

    # ensure state is reset
    test_app.websocket_routes = []
    test_bp.websocket_routes = []

    # test app top level route
    assert len(test_app.websocket_routes) == 0
    assert len(test_app.routes) == 0

# Generated at 2022-06-21 23:34:18.892076
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    # Synthesize a fake RouteMixin, Route
    class fake_RouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.host = '*'
            self.url_prefix = "/"
            self.name = 'app'
            self.strict_slashes = True
            self.version = 1
            self.default_return_value = True


# Generated at 2022-06-21 23:34:28.534006
# Unit test for method options of class RouteMixin

# Generated at 2022-06-21 23:34:39.938790
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    class Route_Mixin_w_Websocket(Route_Mixin):
        def __init__(self, name=None, host=None, strict_slashes=None):
            super(Route_Mixin_w_Websocket, self).__init__(name, host, strict_slashes)
            self.websocket_enabled = True
            self.websocket = self.add_websocket_route
    #     
    #                       passing = passing + 1
    # 
    #     def _static_request_handler(self, file_or_directory, use_modified_since, use_content_range, stream_large_files, request, content_type=None, __file_uri__=None):
    #         """ 
    #         Function to handle the route using statics
    #         :param file_or_

# Generated at 2022-06-21 23:34:40.688563
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    pass

# Generated at 2022-06-21 23:34:41.614013
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass

# Generated at 2022-06-21 23:34:53.600871
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.exceptions import ContentRangeError, HeaderNotFound, InvalidUsage
    from sanic.response import HTTPResponse, file, file_stream, json
    from sanic.server import HttpProtocol, HttpProtocolSanic
    from sanic.router import Route, RouteExists, RouteExistsError, RouteParameter
    from sanic.websocket import WebSocketProtocol, WebSocketProtocolSanic
    from sanic.testing import HOST, PORT
    from werkzeug.routing import Rule, Submount, Subdomain, BuildError
    import unittest


# Generated at 2022-06-21 23:34:59.519981
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    app = Sanic()
    app_router = app.router
    app_router.head('/')
    assert app_router.routes[0].method == 'HEAD'

