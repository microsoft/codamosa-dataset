

# Generated at 2022-06-21 23:25:50.669796
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    assert True


# Generated at 2022-06-21 23:26:02.177374
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic('test_RouteMixin_delete')
    route_mixin = RouteMixin(app)

    with pytest.raises(InvalidUsage) as excinfo:
        @route_mixin.delete("/test")
        @websocket("/ws")
        async def handler(request):
            pass

    assert excinfo.value.__str__() == "Using the same URL for both HTTP and " \
                                      "WebSocket is not allowed: /test"

    @route_mixin.delete("/test")
    async def handler(request):
        pass

    assert handler.__name__ == 'test_RouteMixin_delete.handler'
    assert handler.__name__ in app.routes['DELETE']
    assert len(app.routes['DELETE']) == 1


# Generated at 2022-06-21 23:26:10.826919
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    def handler(request):
        return text("should not see this text")
    routes = RouteMixin(name="").route(uri="", handler=handler)
    assert routes[0].uri == ""
    assert routes[0].methods == ["GET"]

    routes = RouteMixin(name="").route(uri="", methods=["GET", "POST"])
    assert routes[0].uri == ""
    assert routes[0].methods == ["GET", "POST"]
    # Unit test for method add_route of class RouteMixin

# Generated at 2022-06-21 23:26:11.817707
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    RouteMixin


# Generated at 2022-06-21 23:26:13.797819
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    test_RouteMixin = RouteMixin()
    assert test_RouteMixin.get('/') is not None

# Generated at 2022-06-21 23:26:24.616501
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from .route import Route

    # implement example
    from .sanic import Sanic
    from .router import RouterDefaultsMixin

    class Sanic(RouteMixin, RouterDefaultsMixin, Sanic):
        pass
    s = Sanic(__name__)

    @s.route('patch')
    def test(request):
        return "OK"

    paths = [
        ('patch', 'test_patch', 'GET', '/patch'),
        ('patch', 'test_patch', 'HEAD', '/patch'),
        ('patch', 'test_patch', 'PUT', '/patch'),
        ('patch', 'test_patch', 'OPTIONS', '/patch'),
        ('patch', 'test_patch', 'PATCH', '/patch')
    ]
    # must have one route with method PATCH

# Generated at 2022-06-21 23:26:33.488910
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Setup
    r = RouteMixin()
    app = App()
    app.router.add_route(handler=None, uri='/', host=None, methods=None, strict_slashes=False, version=None, name=None)
    # Test
    assert r.add_route(app, handler=None, uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None) == None
    assert r.add_route(app, handler=None, uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None) == None
    # Teardown

# Generated at 2022-06-21 23:26:44.640521
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from functools import partialmethod
    from sanic import Sanic

    # Create a mock Sanic object for testing
    sanic_app = Mock()
    sanic_app.name = 'sanic_app'
    sanic_app.default_host = '127.0.0.1:8000'
    sanic_app.strict_slashes = True

    # Attach a explicit router to the application
    router = Router()
    router.add(Route(uri='/', methods=['GET', 'HEAD'], handler=Mock()), host='127.0.0.1:8000')
    router.add(Route(uri='/api', methods=['GET', 'HEAD'], handler=Mock()), host='127.0.0.1:8000')
    sanic_app

# Generated at 2022-06-21 23:26:53.084198
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    '''
    [sanic.router.RouteMixin] Test method websocket of class RouteMixin
    '''
    # Test normal case
    a = RouteMixin()
    a.websocket("/foo/", name="test_websocket", host="test", strict_slashes=None, version=None, apply=True, subprotocols=None)

# Generated at 2022-06-21 23:27:00.201604
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    r = RouteMixin()
    static = r.static("uri", "file", "pattern", True, False, True, "name", "host", "strict_slashes", "content_type")
    assert static.uri == "uri"
    assert static.file_or_directory == "file"
    assert static.pattern == "pattern"
    assert static.use_modified_since == True
    assert static.use_content_range == False
    assert static.stream_large_files == True
    assert static.name == "name"
    assert static.host == "host"
    assert static.strict_slashes == "strict_slashes"
    assert static.content_type == "content_type"


# Generated at 2022-06-21 23:27:18.637831
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.handlers import ErrorHandler
    from sanic import SanicException
    app = Sanic("test_RouteMixin_put")


    @app.put("/")
    def handler(request):
        return json({"test": True})


    request, response = app.test_client.put("/")

    assert response.json == {"test": True}



# Generated at 2022-06-21 23:27:30.637289
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    request = Request("url", "args", "body", "json")
    request.parsed_json = {"name":"username"}
    
    dispatcher = Dispatcher()
    request_handler = RequestHandler(dispatcher)
    def test_function(request, name):
        return name
    
    response = test_function(request, "username")
    assert response == "username"

    post_function = request_handler.route(uri="/post/", methods=["POST"])(test_function)
    response = post_function(request, "username")
    assert response.status == 200
    assert response.text == "username"
    
    dispatcher.add_route(request_handler.post(uri="/post/", host="10.20.30.40"), test_function)
    response = post_function(request, "username")


# Generated at 2022-06-21 23:27:39.883953
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    from sanic import Sanic
    sanic = Sanic('test_RouteMixin_delete')
    sanic.methods = ('GET', 'POST', 'PUT', 'DELETE')
    sanic.strict_slashes = False
    sanic.host='127.0.0.1'
    sanic.port=8000
    sanic.url_prefix=''
    sanic.uri_prefix=''
    sanic.blueprint_prefix=''
    sanic.request=None
    sanic.server=None
    sanic.blueprints=[]
    sanic.handlers=[]
    sanic.middlewares=[]
    sanic.error_handler=None
    sanic.websocket_enabled=True
    sanic.websocket_host='127.0.0.1'
    san

# Generated at 2022-06-21 23:27:41.446567
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def test_func():
        pass

    router_instance = Router()
    assert router_instance.add_route == router_instance.route, "Test failure"


# Generated at 2022-06-21 23:27:55.321749
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # Test with invalid parameters
    with pytest.raises(ValueError):
        assert not RouteMixin.patch(uri=None, name=None, host=None, strict_slashes=None, version=None, name=None, apply=True)
    with pytest.raises(ValueError):
        assert not RouteMixin.patch(uri="", name=None, host=None, strict_slashes=None, version=None, name=None, apply=True)
    with pytest.raises(ValueError):
        assert not RouteMixin.patch(uri=1, name=None, host=None, strict_slashes=None, version=None, name=None, apply=True)

# Generated at 2022-06-21 23:28:09.349688
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic import Sanic
    from sanic.response import json
    from sanic.router import RouteExists
    from sanic.testing import SanicTestClient
    app = Sanic(name='test_RouteMixin_head')
    test_route_exception1 = RouteExists('test_route_exception1')
    try:
        @app.head('/test_head')
        async def test_head(request):
            return json({'test': 123})
    except RouteExists as e:
        assert test_route_exception1.__str__() == e.__str__()
    client = SanicTestClient(app)
    request, response = client.head('/test_head')
    assert request.path == '/test_head'
    assert response.status == 200



# Generated at 2022-06-21 23:28:10.425764
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass

# Generated at 2022-06-21 23:28:20.358871
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    request = Mock()
    handler = Mock()
    mixin = RouteMixin()
    mixin.route = Mock(return_value=(route, handler))
    mixin.post(
        uri='/',
        host=None,
        strict_slashes=None,
        version=None,
        name=None,
        apply=True,
    )
    mixin.route.assert_called_once_with(
        uri='/',
        host=None,
        methods=['POST'],
        strict_slashes=None,
        version=None,
        name=None,
        apply=True,
        static=False,
        websocket=False,
    )


# Generated at 2022-06-21 23:28:30.752800
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic('test')
    # app attribute is type <class 'sanic.app.Sanic'>
    assert_equal(type(app), Sanic)
    test_uri = '/'
    test_host = None
    test_methods = ['GET']
    test_strict_slashes = False
    test_version = 1
    test_name = 'test'
    test_apply = True
    test_static = None
    test_websocket = False
    test_stream = False

# Generated at 2022-06-21 23:28:35.589300
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    print('test_RouteMixin_delete')
    def deleter():
        pass
    route_mixin = RouteMixin()

# Generated at 2022-06-21 23:29:11.692690
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    r = RouteMixin()
    file_or_directory = 'foo'
    uri = 'bar'
    pattern = 'baz'
    use_modified_since = True
    use_content_range = True
    stream_large_files = True
    name = 'lux'
    host = 'ho'
    strict_slashes = False
    content_type = '2'
    r.static(file_or_directory, uri, pattern, use_modified_since, use_content_range, stream_large_files, name, host, strict_slashes, content_type)


# Generated at 2022-06-21 23:29:13.459372
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass



# Generated at 2022-06-21 23:29:26.167206
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    # sets up a test application to apply methods to methods
    class app(RouteMixin):
        def __init__(self):
            pass
    app.blueprint=None
    app.name='application'
    # the following sets up a simple class with a method named a and definition of b
    class c:
        def a(self):
            pass
        def b(self):
            pass
    c.b.__name__='b'
    c.name='myclass'
    c.__name__='myclass'
    # the following sets up a simple decorator, which raises an exception
    def dec(f):
        raise UnmockedError
    # test app.route
    app.route('/', host='localhost', name='route')(dec)
    assert isinstance(app._route._uri,str)

# Generated at 2022-06-21 23:29:28.678037
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # check if returns correct values
    sanic = Sanic()
    sanic = RouteMixin.add_route(sanic, url='/')
    assert sanic is not None


# Generated at 2022-06-21 23:29:31.310259
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    """
        Test for method static of class RouteMixed
    """
    pass

# Generated at 2022-06-21 23:29:42.735220
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
        Create the object o of class RouteMixin with default parameters
        and test the route method for default case
    """
    o = RouteMixin()
    host = "localhost"
    uri = "/foo/bar"
    methods = ["GET", "POST","PUT", "OPTIONS"]
    strict_slashes = False
    version = 1
    name = "Foo"
    route, _ = o.route(
        uri = uri,
        host = host,
        strict_slashes = strict_slashes,
        methods = methods,
        version = version,
        name = name
    )(print)

# Generated at 2022-06-21 23:29:49.188350
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    sanic = Sanic('test_RouteMixin_put')
    sanic_route = RouteMixin(sanic, 'RouteMixin_put')
    @sanic_route.put(id, name = 'TestFunction')
    def test_function(id):
        raise Exception("Exception from TestFunction")
    result = test_function(id)
    assert result == Exception("Exception from TestFunction")


# Generated at 2022-06-21 23:29:53.951107
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():

    # Initialize the class
    route = RouteMixin("name")

    # Test without params
    result = route.get("/")
    assert result

    # Test with params
    result = route.get("/", host="host")
    assert result

    # Test with invalid params
    try:
        route.get("/", non_valid_param="value")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 23:30:02.915877
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Start
    print('test_RouteMixin')
    print('test_RouteMixin => Start')
    #print('test_RouteMixin => Start => Create Route_Mixin Instance')
    #print('test_RouteMixin => Start => Create Route_Mixin Instance => Done')
    #print('test_RouteMixin => Start => Create Route_Mixin Instance => Get')
    #print('test_RouteMixin => Start => Create Route_Mixin Instance => Get => Done')
    # End
    return None


# Generated at 2022-06-21 23:30:13.580396
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic()
    routeMixin = RouteMixin(app)
    assert routeMixin.app == app
    assert routeMixin.blueprints == []
    assert routeMixin.host == "127.0.0.1"
    assert routeMixin.name == "Sanic"
    assert routeMixin.strict_slashes == False
    assert routeMixin.uri_template == None
    assert routeMixin.version == 1
    assert routeMixin._future_statics == set()
    assert routeMixin.router == app.router

# Generated at 2022-06-21 23:30:59.653528
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic.response import text
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('my_blueprint')

    @blueprint.route('/user', methods=['POST'])
    def handler(request):
        return text('OK')

    app.blueprint(blueprint)

    request, response = app.test_client.post('/user')
    assert request.path == '/user'
    assert response.text == 'OK'


# Generated at 2022-06-21 23:31:11.232694
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    app = Sanic(__name__)
    root = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.dirname(__file__))))
    app.static('/static_dir', root + '/assets')
    app.static('/static_file', root + '/tests/fixtures/static_file.txt')
    app.static('/static_bytes', b'1234')
    app.static('/static_path', Path(root + '/tests/fixtures/static_path.txt'))
    app.static('/static_invalid', datetime.now())
    with pytest.raises(ValueError):
        app.static('/static_invalid', datetime.now())



# Generated at 2022-06-21 23:31:16.999539
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Create instance of class RouteMixin
    route_mixin = RouteMixin()

    assert route_mixin.post is not None
    assert callable(route_mixin.post)
    assert route_mixin.post.__name__ == "post"


# Generated at 2022-06-21 23:31:21.167710
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
        @get('/get')
        def handler(request):
                pass

        app = Sanic(__name__)
        # route = app.router.get(handler, uri='/get', methods=['GET'])
        route = Route(handler, uri='/get', methods=['GET'],
                    host=None,
                    strict_slashes=None,
                    version=None,
                    name=None,
                    stream=False,
                    websocket=False,
                    statics=None,
                    static=False,
                    apply=True,
                    handler=handler)
        assert check_route(route)


# Generated at 2022-06-21 23:31:24.163533
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    assert callable(RouteMixin.static)

# Generated at 2022-06-21 23:31:34.286610
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class App1(RouteMixin):
        pass

    app = App1()
    uri = "test"
    methods = ["get"]
    host = "test"
    strict_slashes = True
    version = 0
    name = "test"
    apply = True
    websocket = True
    route, _ = app.route(
        uri=uri,
        methods=methods,
        host=host,
        strict_slashes=strict_slashes,
        version=version,
        name=name,
        apply=apply,
        websocket=websocket
    )
    assert route.uri == uri
    assert route.methods == methods
    assert route.host == host
    assert route.strict_slashes == strict_slashes
    assert route.version == version
    assert route.name

# Generated at 2022-06-21 23:31:41.032890
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic("test_RouteMixin_route")
    test_route = app.route("/test_route", methods=["GET", "POST"], version=1)(lambda x: x)
    assert test_route.uri == "/test_route"
    assert test_route.methods == ["GET", "POST"]
    assert test_route.version == 1


# Generated at 2022-06-21 23:31:47.085305
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    instance = RouteMixin()
    params = {}
    # No exception should be thrown here
    try:
        result = instance.websocket(**params)
    except:
        assert False
    assert result is not None

# Generated at 2022-06-21 23:31:54.063017
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    test_obj = RouteMixin()
    uri = None
    host = None
    strict_slashes = None
    version = None
    name = None
    apply = None
    _route, _ = test_obj.head(uri=uri, host=host, strict_slashes=strict_slashes, version=version, name=name, apply=apply)
    assert _route.methods == {'HEAD'}
    assert _route.strict_slashes == strict_slashes
    assert _route.version == version
    assert _route.name == name
    assert _route.apply == apply


# Generated at 2022-06-21 23:32:03.657219
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

	def test_function():
		return True

	app = Sanic('sanic-test-route-methods')

	app.route( '/route' )( test_function )
	assert app.is_request_stream is None
	assert len(app.router.routes_all['GET']) == 1

	app.route( '/route', methods = ['POST'] )( test_function )
	assert len(app.router.routes_all['GET']) == 1
	assert len(app.router.routes_all['POST']) == 1

	app.route( '/route', methods = ['PUT'] )( test_function )
	assert len(app.router.routes_all['GET']) == 1

# Generated at 2022-06-21 23:33:20.739391
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    pass


# Generated at 2022-06-21 23:33:30.211225
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    class x(object):
        def __init__(self):
            pass
    x = x()
    x.websocket = MagicMock()
    x.add_websocket_route = MagicMock()
    x.static = MagicMock()
    x._future_statics = MagicMock()
    x.coroutine = MagicMock()
    x.host = MagicMock()
    x._register_static = MagicMock()
    x._apply_static = MagicMock()
    x.route = MagicMock()
    x.strict_slashes = MagicMock()
    x._generate_name = MagicMock()
    x.name = MagicMock()
    x.request_middleware = MagicMock()
    x.response_middleware = MagicMock()
    x.blueprints

# Generated at 2022-06-21 23:33:31.806684
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-21 23:33:34.378141
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    """
    1.
    """

    # setup env
    router = RouteMixin()

    # 1.
    @router.add_websocket_route("/index")
    async def index(request, ws):
        pass



# Generated at 2022-06-21 23:33:40.394504
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # test case 1
    uri = "uri"
    host = None
    strict_slashes = None
    version = None
    name = None
    return_value = None
    params = (1, 2)

    with pytest.raises(TypeError):
        return_value = RouteMixin.put(uri, host, strict_slashes, version, name, *params)


# Generated at 2022-06-21 23:33:52.584782
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    from sanic.router import Route
    routeMixin = RouteMixin()
    routeMixin.blueprint = Blueprint("test_routeMixin",url_prefix="/test_routeMixin")
    routeMixin.blueprint.register(application)
    routeMixin.delete("/delete")(routeMixin.routeMixin_delete_handler)
    assert ("/delete", "<function RouteMixin.routeMixin_delete_handler at 0x000002865C4442F0>") in application.router.routes_all[("DELETE", "test_routeMixin")], "Delete method of class RouteMixin is not working properly"

# Generated at 2022-06-21 23:33:55.445479
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # test path of class method, which could not be executed
    pass

# Generated at 2022-06-21 23:34:02.407945
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Given
    route_mixin = RouteMixin()
    uri_path = "/"
    method = "GET"
    handler = "mock"
    # When
    route_mixin.add_route(uri_path, method, handler)
    # Then
    assert route_mixin.routes[0].uri == uri_path
    assert route_mixin.routes[0].methods == [method]
    assert route_mixin.routes[0].handler == handler


# Generated at 2022-06-21 23:34:15.068239
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    _schematics_structure = ["RouteMixin"]
    _method_class = "Route"
    _router = RouteMixin
    _method = "route"
    _schema = RouteMixin.route
    _models = {"_models": {}}
    _method_name = "route"
    _signature = inspect.signature(_schema)
    _handler = _router.route
    _routes = _router.routes
    _default = []
    _args = ["uri", "methods", "host", "strict_slashes", "version", "name", "websocket"]

# Generated at 2022-06-21 23:34:26.984903
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    import asyncio
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    app = App()
    @app.route("/")
    async def index(request):
        return text("OK")
    WS_PORT = 8888
    loop = asyncio.get_event_loop()
    server = loop.run_until_complete(
        loop.create_server(app.async_run, port=WS_PORT))
    t = threading.Thread(target=loop.run_forever)
    t.start()
    asyncio.sleep(0.1)
    client = Client("http://127.0.0.1:{}".format(WS_PORT))
    try:
        client.get("/")
    except:
        pass

# Generated at 2022-06-21 23:35:25.707209
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic(name="test_RouteMixin_add_route")
    app.add_route(handler=lambda x: x, uri="/test")
    assert len(app.router.routes_all) == 1



# Generated at 2022-06-21 23:35:29.592784
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    uri = '/hello'
    host = None
    methods = ['HEAD']
    strict_slashes = None
    version = 1
    name = 'hello'
    route = RouteMixin.route(uri, host, methods, strict_slashes, version, name)
    assert route.uri == '/hello'
    assert route.methods == ['HEAD']
    assert route.version == 1
    assert route.name == 'hello'