

# Generated at 2022-06-21 23:25:53.359402
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    from sanic.router import Route, RouteExists
    from sanic.request import Request
    # Create a RouteMixin object:
        # self.routes = set()
        # self.routes_all = {}
        # self.routes_strict_slashes = {}
        # self.routes_strict_slashes_all = {}

    # Create a Route object
    # uri=None, host=None, methods=None, handler=None,
    # strict_slashes=None, name=None, websocket=False, stream=False,
    # version=None, parameters=None, register_all=False,
    # register_strict_slashes=False, register_websocket=False
    route=Route()


    # add_route(self, route, apply=True)


# Generated at 2022-06-21 23:26:03.198387
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    # Given a RouteMixin
    route_mixin = RouteMixin()
    # When I want to add a websocket route
    handler = "test_handler"
    uri = "test_uri"
    subprotocols = ["test_subprotocols"]
    name = "test_name"
    host = "test_host"
    strict_slashes = True
    version = 1
    
    route_mixin.add_websocket_route(handler, uri=uri, host=host, strict_slashes=strict_slashes, subprotocols=subprotocols, version=version, name=name)
    
    # Then I assert the result
    assert isinstance(route_mixin, RouteMixin)

# Generated at 2022-06-21 23:26:13.560808
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    app = Sanic('test-sanic')

# Generated at 2022-06-21 23:26:24.529572
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    router = RouteMixin()
    class MockHandler(object):
        def __call__(self):
            pass
    handler = MockHandler()
    subprotocols = ['foo', 'bar']
    with pytest.raises(ValueError) as e:
        router.add_websocket_route(
            handler, uri='/', host='localhost', strict_slashes=True,
            subprotocols=subprotocols
        )

    assert str(e.value) == "Use only one method to define subprotocols"

    with pytest.raises(ValueError) as e:
        router.add_websocket_route(
            handler, uri='/', host='localhost', strict_slashes=True,
            subprotocols='x'
        )


# Generated at 2022-06-21 23:26:31.723419
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Test RouteMixin.__init__()
    router = RouteMixin()
    assert router.router == RouteTable()
    assert router.websockets == set()
    assert router.strict_slashes == True
    assert router.name == None
    assert router.blueprints == set()
    assert router._future_statics == set()
    assert router._converters == {}
    assert router.resources == set()


# Generated at 2022-06-21 23:26:37.880499
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    app = Sanic(__name__)
    instance_RouteMixin = app.router.route
    assert instance_RouteMixin.__self__.__class__.__name__ == "RouteMixin"


# Generated at 2022-06-21 23:26:39.887023
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
  route_mixin = RouteMixin()
  assert route_mixin.head("/",name="test",host=None,strict_slashes=None,version=None,name="test",apply=True) == (route,_handler)

# Generated at 2022-06-21 23:26:45.215338
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    # Initialize a Sanic application
    app = Sanic('RouteMixin')
    # Configuration
    app.config.from_object(__name__)
    app.config["REQUEST_TIMEOUT"] = 60
    app.config["KEEP_ALIVE"] = False
    app.config["RESPONSE_TIMEOUT"] = 60
    app.config["WEBSOCKET_MAX_SIZE"] = 2 ** 20  # 1 MiB
    app.config["WEBSOCKET_MAX_QUEUE"] = 32
    app.config["WEBSOCKET_READ_LIMIT"] = 2 ** 16
    app.config["WEBSOCKET_WRITE_LIMIT"] = 2 ** 16

# Generated at 2022-06-21 23:26:49.883666
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Test Router not defined
    try:
        class TestRouteMixin(RouteMixin):
            pass
        assert False
    except Exception as e:
        assert True

    # Test Router defined
    class TestRouteMixin(RouteMixin):
        def __init__(self, router):
            self.route_list = router.routes_all

    obj = TestRouteMixin(router=BaseRouter())

# Generated at 2022-06-21 23:26:56.482969
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    routeMixin_1 = RouteMixin()
    assert isinstance(routeMixin_1._statics, set)
    assert isinstance(routeMixin_1._future_statics, set)
    assert isinstance(routeMixin_1._middlewares, list)
    assert isinstance(routeMixin_1._host_middlewares, dict)
    assert isinstance(routeMixin_1._error_handler, dict)

# Generated at 2022-06-21 23:27:08.848346
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
  pass

# Generated at 2022-06-21 23:27:10.723671
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    app=sanic.Sanic()
    # set the context
    # successfully call the method
    # test with different inputs
    pass


# Generated at 2022-06-21 23:27:16.516501
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    # string,string,bool,None,str -> list(Route)


    # string,string,None,None,str -> list(Route)


    # string,None,bool,None,str -> list(Route)


    # string,None,None,None,str -> list(Route)


    pass


# Generated at 2022-06-21 23:27:25.928933
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    def func(): pass
    
    routeMixin = RouteMixin()
    routeMixin.route = MagicMock(return_value=(func,func))
    routeMixin.static('/', 'home')
    routeMixin.route.assert_called_once_with('/', methods=None, version=None,
        strict_slashes=None, name=None, host=None, apply=True, subprotocols=None,
        websocket=False)


# Generated at 2022-06-21 23:27:31.397304
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class DummyRouteMixin(object):
        pass
    class Dummy(object):
        
        def __init__(self):
            self.name = ""
            self.strict_slashes = False
            self.request_timeout = 60.0
            self.websocket_timeout = 60.0
            self.keep_alive_timeout = 5.0
            self.response_class = None
            self.host = None
            self.default_factory = None
            self.error_handler = None
            self.router = None
            self.blueprints = None
            self.url_for = None
            self.exception = None
            self.loop = None
            self.config = None
            self.before_start = None
            self.after_start = None
            self.before_stop = None
           

# Generated at 2022-06-21 23:27:33.331711
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
  url = "/a"
  alias = 'b'
  app = Sanic()
  assert app.add_route(url, alias) == True


# Generated at 2022-06-21 23:27:40.081330
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
  # tests that the function static runs properly
    async def foo():
        pass
    with Sanic('test') as app:
        app.route('/')(foo)
        app.static('static', get_app_dir(app))
        assert app.static_dir == get_app_dir(app)
        assert app.static_url_path == 'static'
    assert app.static_dir == get_app_dir(app)
    assert app.static_url_path == 'static'

# Generated at 2022-06-21 23:27:40.656377
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass

# Generated at 2022-06-21 23:27:54.223730
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    R = RouteMixin()
    # Test if _register_static returns the correct result
    file_or_directory = "test_file"
    uri = "/"
    pattern = r'/?.+'
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    static = FutureStatic(
        uri,
        file_or_directory,
        pattern,
        use_modified_since,
        use_content_range,
        stream_large_files,
        name,
        host,
        strict_slashes
    )
    res = R._register_static(static)
    assert res.uri == "/"
    assert res.name == "static"
    # Test if _

# Generated at 2022-06-21 23:28:03.716316
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():

    # Variables
    # None

    # Setup
    app = Sanic()
    app.route('/')(lambda request: None)
    router = app.router

    # Exercise
    router.patch('/')(lambda request: None)

    # Verify
    assert router.routes_all['PATCH'][0]['uri'] == '/'
    # Cleanup
    # None



# Generated at 2022-06-21 23:28:14.618399
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    pass
    

# Generated at 2022-06-21 23:28:16.335414
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # Test for method add_route of class RouteMixin
    assert False, "Test for method add_route of class RouteMixin"


# Generated at 2022-06-21 23:28:29.859524
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from sanic.websocket import WebSocketProtocol

    loop = Mock()
    mixin = RouteMixin(loop=loop)
    mock_uri = "mock_uri"
    mock_host = "mock_host"
    mock_strict_slashes = True
    mock_subprotocols_list = []
    mock_version = 4
    mock_name = "mock_name"
    mock_apply = True
    mock_websocket = True


# Generated at 2022-06-21 23:28:39.046166
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    config = Config(
            DEBUG=True,
            HOST='0.0.0.0',
            PORT=8888,
            RETRY_AFTER=3,
            KEEP_ALIVE=False,
            REQUEST_TIMEOUT=60,
            RESPONSE_TIMEOUT=60,
            LOGO=None)
    sanic_app = Sanic(name='sanic', debug=config.DEBUG)
    route_mixin = RouteMixin(app=sanic_app)
    print(route_mixin)

# RouteMixin constructor test case

# Generated at 2022-06-21 23:28:51.273065
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    class CustomHTTPResponse(HTTPResponse):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.content_type = "application/json"


# Generated at 2022-06-21 23:28:53.320143
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass


# Generated at 2022-06-21 23:29:05.515396
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():

    from sanic import Sanic
    from sanic.router import Route
    from sanic.app import UrlForHandler
    from sanic.response import HTTPResponse
    import asyncio
    import binascii

    # Function URlForWrapper_run
    # Arguments: self, *args
    # Return value: None

    @asyncio.coroutine
    def URlForWrapper_run(self, *args):
        return

    # Function request_handler
    # Arguments: request, *args, **kwargs
    # Return value: HTTPResponse

    def request_handler(request, *args, **kwargs):
        return HTTPResponse()

    # Function url_for
    # Arguments: self
    # Return value: URlForWrapper


# Generated at 2022-06-21 23:29:15.343749
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    """test_RouteMixin_delete"""

    from sanic.blueprints import Blueprint
    from sanic.router import Route, RouteExists

    blue = Blueprint(name="test_blueprint")
    with pytest.raises(RouteExists):
        blue.delete(uri="/")(lambda x: x)
    with pytest.raises(RouteExists):
        blue.delete(uri="/")(lambda x: x)

    @blue.delete(uri="/")
    def test():
        """test"""

        return 1

    @blue.delete(uri="/test")
    def test1():
        """test1"""

        return 1

    @blue.delete(uri="/test1")
    def test2():
        """test2"""

        return 1


# Generated at 2022-06-21 23:29:22.258541
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Test 1: standard initialization
    from sanic import Sanic
    app = Sanic(__name__)

    # Test 2: with version=1 and which is an int
    app2 = Sanic(__name__, version=1)

    # Test 3: with version="1.0" and which is a str
    app3 = Sanic(__name__, version="1.0")

    # Test 4, 5 and 6: with host=None, 0.0.0.0, "example.com"
    app4 = Sanic(__name__, host=None)
    app5 = Sanic(__name__, host="0.0.0.0")
    app6 = Sanic(__name__, host="example.com")

    # Test 7, 8, 9 and 10 with strict_slashes=None, True, False

# Generated at 2022-06-21 23:29:24.773832
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    """Unit test for method patch of class RouteMixin"""
    TestRouteMixin = RouteMixin()
    TestRouteMixin.patch('/')

# Generated at 2022-06-21 23:29:47.106677
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    from .router import RouteMixin
    from .route import Route
    from . import RouteExists
    from .router import RouteExists
    from .router import Route
    # init a Route and RouteMixin
    route = Route('GET', '/example', 'example_handler')
    routeMixin = RouteMixin()
    # init a RouteDict with a route inside
    routeDict = {'route': route}
    # assert if we retreived the same route
    assert routeMixin.get(routeDict, 'route') is route
    assert routeMixin.get(routeDict, 'a') is None
    # try to retrive a route that doesnt exists
    try:
        routeMixin.get(routeDict, 'a', fail_silently=False)
    except RouteExists:
        assert True

# Generated at 2022-06-21 23:29:49.672653
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    router = RouteMixin()
    assert router.put(path="/test")(handler=None) == (handler, None, None, None)
        


# Generated at 2022-06-21 23:29:53.695855
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    _app = Application(__name__)
    routeTable = RouteMixin(_app)
    assert routeTable.app == _app
    assert not routeTable.routes
    assert not routeTable._future_routes
    assert not routeTable._future_statics
    assert not routeTable._future_websockets
    assert routeTable.strict_slashes is False


# Generated at 2022-06-21 23:30:02.143007
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    def _test_route(self, uri, host, methods, strict_slashes, version, name, **kwargs):
        return ("route1", Route)
    
    RouteMixin.route = _test_route
    app = Sanic(__name__)
    routes = app.route(uri="t", host=None, strict_slashes=None, methods=None, version=None, name=None, apply=True)
    assert routes == ("route1", Route)


# Generated at 2022-06-21 23:30:14.923108
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    # Arrange
    route_mixin = RouteMixin()
    route_mixin.id = "id"
    route_mixin.host = "host"
    route_mixin.port = "port"
    route_mixin.name ="name"
    uri = "uri"
    host = "host"
    strict_slashes = None
    version = "version"
    name ="name"
    apply = True
  
    # Act
    actual = route_mixin.post(uri, host, strict_slashes, version, name, apply)
    expected = route_mixin.route(uri, host, strict_slashes, version, name, apply)
   
    # Assert
    assert actual == expected


# Generated at 2022-06-21 23:30:20.870307
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    routeMixin = RouteMixin("nameMixin")
    route = routeMixin.delete("uri")
    route.apply = False
    x = routeMixin.add_route(route)
    pass

# Generated at 2022-06-21 23:30:22.458757
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    _test_RouteMixin_route(False)
    _test_RouteMixin_route(True)


# Generated at 2022-06-21 23:30:23.276699
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    r = RouteMixin()


# Generated at 2022-06-21 23:30:24.855135
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    """
    unit test function: test_RouteMixin_add_websocket_route
    """
    pass


# Generated at 2022-06-21 23:30:38.496515
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from pathlib import PurePath
    from .shims import Sanic
    router = RouteMixin()
    router.name = 'router'
    # Case 1:
    #<editor-fold desc="Case 1:">
    app = Sanic('test_sanic')
    app.router.strict_slashes = None
    app.config.KEEP_ALIVE = True
    app.config.KEEP_ALIVE_TIMEOUT = 5

    @app.route("/")
    def handler(request):
        return response.text("OK")

    # TODO: I feel like we should at least make a good effort here.
    # TODO: Modified-since is nice, but we should also look into etags,
    # TODO: expires, and caching

# Generated at 2022-06-21 23:31:02.668348
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    with pytest.raises(Exception) as excinfo:
        route = RouteMixin.route()
        assert 'not implemented' in str(excinfo.value)


# Generated at 2022-06-21 23:31:06.828269
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():

    with pytest.raises(ValueError):
        app = Sanic('test_RouteMixin_delete')
        app.delete('test_RouteMixin_delete')

# Generated at 2022-06-21 23:31:16.005224
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # init 
    create_init()
    init()
    init_route()

    # test
    # it is a normal case
    Sanic('test_app').add_route(partial(view), '/', methods=['GET'])
    if len(app.router.routes_all['GET']) == 1 and len(app.router.routes_all['POST']) == 1 and len(app.router.routes_all['PUT']) == 1:
        assert True
    else:
        assert False
    # it is a exception case
    Sanic('test_app').add_route(view, '/', methods=['GET'])

# Generated at 2022-06-21 23:31:24.923831
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic.response import text

    async def handler(request, ws):
        await ws.send("hello")

    route = RouteMixin().add_websocket_route(handler, "/ws")
    assert route.name == "websocket"
    assert "websocket" in route.methods
    assert route.uri == "/ws"
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.scheme == None
    assert route.subprotocols == None
    assert route.name == None
    assert route.websocket == True
    assert route.static == False
    assert len(route.middleware) == 0
    assert route.stream is None
    assert route.handler.__name__ == "handler"
    assert route.handler

# Generated at 2022-06-21 23:31:28.304292
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    from sanic.request import Request

    # Uri is a string

    # Uri is set
    app = sanic.Sanic("Sanic")
    mixin = RouteMixin(app)
    uri = "/"
    request = Request("GET", uri)
    assert mixin.post("/", request)


# Generated at 2022-06-21 23:31:29.273460
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass


# Generated at 2022-06-21 23:31:38.613005
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # normal
    app = Sanic("sanic")
    # name is not string
    try:
        app = Sanic()
    except TypeError:
        pass
    # name is empty
    try:
        app = Sanic("")
    except ValueError:
        pass
    # config is not dictionary
    try:
        app = Sanic("sanic", config=True)
    except TypeError:
        pass


# Generated at 2022-06-21 23:31:45.398571
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    from asyncio import ensure_future, Event
    from sanic import Sanic
    from sanic import response

    class TestRouteMixin(RouteMixin):
        
        def __init__(self, app):
            self.app = app
            self._routes = []
            self._websockets = []
            self._future_statics = set([])
            self._static_routes = set([])
            self._host_routes = {}
            self.host = None
            self.strict_slashes = None
            self.name = app.name
            self.serve_static = False
            self.static_url_path = "/static"
            
    app = Sanic("sanic")
    app.config.KEEP_ALIVE_TIMEOUT = 15

# Generated at 2022-06-21 23:31:53.373366
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    # Create a class RouteMixin
    mixin = RouteMixin()
    # Raise exception
    with pytest.raises(NotImplementedError):
        # Get attribute 'app'
        mixin.app
    # Raise exception
    with pytest.raises(NotImplementedError):
        # Set attribute 'app'
        mixin.app = 5
    # Raise exception
    with pytest.raises(NotImplementedError):
        # Get attribute 'name'
        mixin.name
    # Raise exception
    with pytest.raises(NotImplementedError):
        # Set attribute 'name'
        mixin.name = 5
    # Raise exception
    with pytest.raises(NotImplementedError):
        # Get attribute 'host'
        mixin.host
    # Raise exception

# Generated at 2022-06-21 23:31:53.923865
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    pass

# Generated at 2022-06-21 23:32:26.353944
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    from sanic.router import Route, RouteExists
    from sanic.constants import ROUTE_STATIC, ROUTE_WEBSOCKET, ROUTE_REGEX
    from sanic import Sanic

    # test case 1
    sanic_app = Sanic("test_app_01")
    route_mixin = RouteMixin(sanic_app)

    uri = "/test"
    host = "localhost"
    strict_slashes = None
    methods = ["get","list"]
    version = 1
    name = "test_name"
    apply = True

    # test for existing routes

# Generated at 2022-06-21 23:32:35.183272
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    def test_func():
        pass
    app = Sanic('test_RouteMixin_patch')
    result = app.patch(pattern='/', strict_slashes=False, stream=False, name='test_func')(test_func)
    assert result.name == 'test.test_func' and result.uri == '/' and result.strict_slashes == False
    assert result.route.methods == ['PATCH'] and result.route.get_info()['uri'] == '/'

# Generated at 2022-06-21 23:32:41.507258
# Unit test for method add_websocket_route of class RouteMixin
def test_RouteMixin_add_websocket_route():
    from sanic.router import Route
    mixin = RouteMixin()
    mixin.add_websocket_route(lambda x: x, "/")
    assert isinstance(mixin._routes[0], Route)

# Generated at 2022-06-21 23:32:46.434043
# Unit test for constructor of class RouteMixin
def test_RouteMixin():
    app = Sanic(__name__)
    @app.route('/')
    def index(request):
        return json({"hello": "world"})
    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {"hello": "world"}


# Generated at 2022-06-21 23:32:55.169310
# Unit test for method post of class RouteMixin
def test_RouteMixin_post():
    route_mixin = RouteMixin()
    route_mixin.add_route = mock.Mock()

    route_mixin.post(uri='uri', host='host', strict_slashes='strict_slashes', version='version', name='name', apply='apply')
    route_mixin.add_route.assert_called_once_with(uri='uri', host='host', method='POST', strict_slashes='strict_slashes', version='version', name='name', apply='apply')


# Generated at 2022-06-21 23:33:03.186370
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Testing class Sanic
    sanic = _module_import('sanic.app').Sanic(__name__)
    sanic.RouteMixin.static(
      'static', 
      '/home/static'
    )
    # TODO: assert something


if __name__ == '__main__':
    test_RouteMixin()

# Generated at 2022-06-21 23:33:08.825888
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    from .sanic import Sanic
    app = Sanic("test_RouteMixin_patch")
  
    @app.patch("/test", version=1)
    async def handler(request):
        return text("OK")
  
    request, response = app.test_client.patch("/test")
    assert response.text == 'OK'
from sanic.response import HTTPResponse

from .router import Route

# Generated at 2022-06-21 23:33:17.982484
# Unit test for method delete of class RouteMixin
def test_RouteMixin_delete():
    app = Sanic('test_RouteMixin_delete')

    # CASE1: uri is not str
    try:
        @app.delete(101)
        def test(request):
            pass
    except TypeError:
        pass

    # CASE2: uri is None
    try:
        @app.delete(None)
        def test(request):
            pass
    except TypeError:
        pass
    
    # CASE3: route is str
    try:
        @app.delete('/test_route')
        def test(request):
            return True
    
        request, response = app.test_client.delete('/test_route')
        assert response.status == 200
    except TypeError:
        raise


# Generated at 2022-06-21 23:33:21.620666
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    # Init a RouteMixin object for testing
    route_mixin = RouteMixin()
    # Call the put method of class RouteMixin
    route_mixin.put()

# Generated at 2022-06-21 23:33:26.873187
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    route_mixin = RouteMixin()
    routes, handler = route_mixin.get(uri = '/', host=None, strict_slashes=None, version=None, name=None)
    assert len(routes) == 1


# Generated at 2022-06-21 23:33:47.922498
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    pass


# Generated at 2022-06-21 23:33:49.509921
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # TODO: write unit test for RouteMixin
    pass



# Generated at 2022-06-21 23:34:02.441607
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():   
    route_mixin = RouteMixin()
    def _handler1():
        return True
    def _handler2():
        return True
    def _handler3():
        return True
    def _handler4():
        return True
    route_mixin.route('/',host='127.0.0.1',methods=['GET'],strict_slashes=None) (_handler1)
    route_mixin.route('/',host='127.0.0.1',methods=['GET'],strict_slashes=None) (_handler2)
    route_mixin.route('/',host='127.0.0.1',methods=['GET'],strict_slashes=None) (_handler3)

# Generated at 2022-06-21 23:34:15.098611
# Unit test for method websocket of class RouteMixin
def test_RouteMixin_websocket():
    """Unit test for RouteMixin.websocket"""

    # Arguments
    uri: str = "/"
    host: Optional[str] = None
    strict_slashes: Optional[bool] = None
    subprotocols=None
    version: Optional[int] = None
    name: Optional[str] = None
    apply: bool = True
    
    
    route_mixin = RouteMixin()

    with pytest.raises(ValueError) as excinfo:
        route_mixin.websocket(
            uri=uri,
            host=host,
            strict_slashes=strict_slashes,
            subprotocols=subprotocols,
            version=version,
            name=name,
            apply=apply
        )

    # Exception message

# Generated at 2022-06-21 23:34:27.021072
# Unit test for method put of class RouteMixin
def test_RouteMixin_put():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.server import HOST, PORT, WORKERS
    from sanic.websocket import WebSocketProtocol
    import pytest

    @pytest.fixture
    def app():
        app = Sanic("test_RouteMixin_put")

        @app.route("/")
        async def handler(request):
            return HTTPResponse(b"OK")

        @app.websocket("/")
        async def handler(request, ws):
            return HTTPResponse(b"OK")

        return app

    @pytest.fixture
    def request():
        request = Request.fake_request()
        request.trans

# Generated at 2022-06-21 23:34:30.115432
# Unit test for method patch of class RouteMixin
def test_RouteMixin_patch():
    # No arguments
    router = RouteMixin()
    assert router

    # One argument
    router = RouteMixin("test_value")
    assert router

# Generated at 2022-06-21 23:34:35.414410
# Unit test for method head of class RouteMixin
def test_RouteMixin_head():
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import MethodNotSupported

    app = Sanic('test_RouteMixin_head')

    @app.route('/')
    def handler(request):
        return text('OK')

    with pytest.raises(MethodNotSupported, match=r"Method HEAD not supported for URL /"):
        assert Route.test(app, 'HEAD', '/')


# Generated at 2022-06-21 23:34:37.244365
# Unit test for method get of class RouteMixin
def test_RouteMixin_get():
    print('hello world')



# Generated at 2022-06-21 23:34:42.523855
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    app = Sanic()
    assert app.router.route('/testroute', methods=['GET'])(lambda: None)
    assert app.router.route('/testroute', methods=['GET','POST'])(lambda: None)
    assert app.router.route('/testroute', methods=None)(lambda: None)


# Generated at 2022-06-21 23:34:44.019283
# Unit test for method options of class RouteMixin
def test_RouteMixin_options():
    check_MethodMixin(RouteMixin)