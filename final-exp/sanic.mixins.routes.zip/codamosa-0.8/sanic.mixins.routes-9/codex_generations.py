

# Generated at 2022-06-12 09:12:10.224413
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route, HttpMethod

    host = "http://aa.com"
    uri = "/api/user"
    methods = ["GET"]
    strict_slashes = True
    version = 1
    name = "name"
    expected_route = Route(
        uri=uri,
        methods=set(methods),
        host=host,
        strict_slashes=strict_slashes,
        version=version,
        name=name,
        websocket=False,
        stream=False,
    )

    class RouteMixin:
        def route(self, **kwargs):
            # TODO: implement RouteMixin.route
            pass

    route_mixin = RouteMixin()

# Generated at 2022-06-12 09:12:19.712838
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic import response
    from sanic.router import Route
    from sanic.response import text
    from sanic.testing import HOST, PORT
    from sanic_routes.routes.route_mixin import RouteMixin

    def test_route_returns_decorated_function():
        class Server(RouteMixin, Sanic):
            pass

        server = Server(name="test")
        route, decorated_function = server.route("/")(text)
        assert route.handler == decorated_function
        assert route.uri == "/"
        assert route.version == None
        assert route.strict_slashes == None
        assert route.methods == ["GET"]
        assert route.name == "test.text"
        assert route.host == None

# Generated at 2022-06-12 09:12:21.308261
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # assert False # TODO: implement your test here
    pass


# Generated at 2022-06-12 09:12:31.785423
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.exceptions import abort
    from sanic.handlers import ErrorHandler
    from sanic.router import Router
    from sanic.server import BaseHttpProtocol
    from sanic.response import HTTPResponse, text
    from sanic.request import RequestParameters
    from sanic.testing import create_test_server, create_test_client, HOST, PORT, _request_handler
    async def _param_handler(request):
        if request.args['foo'][0] == 'bar':
            return text('OK')
        else:
            abort(400)
    async def _post_handler(request):
        return text('OK')
    async def _put_handler(request):
        return text('OK')
    async def _patch_handler(request):
        return text('OK')

# Generated at 2022-06-12 09:12:36.350479
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    route_mixin = RouteMixin(name = "sanic")
    file_or_directory = "tests/static/"
    uri = "/static"
    route_mixin.static(uri, file_or_directory)
    assert route_mixin._static_request_handler



# Generated at 2022-06-12 09:12:43.845120
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.request import Request as SanicRequest
    from sanic.websocket import WebSocketProtocol as SanicWebSocketProtocol
    from sanic.handlers import ErrorHandler as SanicErrorHandler
    from sanic.response import HTTPResponse as SanicHTTPResponse
    from sanic.response import stream as SanicStream
    from sanic.response import file as SanicFile
    from sanic.response import file_stream as SanicFileStream
    from sanic.response import text as SanicText
    from sanic.response import json as SanicJSON
    from sanic.response import html as SanicHTML
    from sanic.response import redirect as SanicRedirect
    from sanic.response import redirect as SanicRedirect
    from sanic.response import stream_

# Generated at 2022-06-12 09:12:45.343325
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass



# Generated at 2022-06-12 09:12:56.586409
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    sanic_object = Sanic('sanic_object')
    host_value = '0.0.0.0'
    uri_value = '/'
    file_or_directory_value = '/Users/lwang/PycharmProjects/sanic-jwt/examples/static'
    pattern_value = r"/?.+"
    use_modified_since_value = True
    use_content_range_value = False
    stream_large_files_value = False
    name_value = 'static'
    host_value = host_value
    strict_slashes_value = None
    content_type_value = None
    apply_value = True
    print_value = None
    # print(sanic_

# Generated at 2022-06-12 09:13:03.703513
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin(Sanic("Test_Add_Route"))
    # Valid test
    try:
        route_mixin.add_route("/", lambda req: "Hello world", methods=["GET"])
    except Exception:
        raise AssertionError("Valid test case")
    # Invalid test: if uri is empty
    try:
        route_mixin.add_route("", lambda req: "Hello world", methods=["GET"])
    except TypeError:
        pass
    else:
        raise AssertionError("Invalid test case")



# Generated at 2022-06-12 09:13:08.449216
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Set up
    test_app = Sanic('test_app')
    test_app.route('/')(lambda request: HTTPResponse())
    # Assertion
    assert test_app.routes['GET'][0].name == 'test_app.test_app'

test_RouteMixin_add_route()


# Generated at 2022-06-12 09:13:23.020260
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass


# Generated at 2022-06-12 09:13:28.535169
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class Router(RouteMixin):
        def __init__(self):
            self.routes = []
            self.host = '127.0.0.1'

    router = Router()
    route = Route('/')
    router.add_route(route)
    assert router.routes == [route]



# Generated at 2022-06-12 09:13:39.807169
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    import requests
    import json

    class TestRouter:
        pass

    router = TestRouter()
    router.add_route(uri=None, host=None, method=None, handler=None, name=None,
                     strict_slashes=None, stream=None, version=None,
                     apply=True, websocket=None, subprotocols=None)
    router.options(uri=None, host=None, strict_slashes=None, stream=None,
                   name=None, version=None, apply=True, websocket=None,
                   subprotocols=None)
    router.delete(uri=None, host=None, strict_slashes=None, stream=None,
                  name=None, version=None, apply=True, websocket=None,
                  subprotocols=None)
    router.put

# Generated at 2022-06-12 09:13:47.424020
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    # test_RouteMixin_route_instance of class RouteMixin
    test_RouteMixin_route_instance = RouteMixin()

    # Variables
    uri = "/"
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = None
    websocket = None
    subprotocols = None

    # test body
    decorated_function = test_RouteMixin_route_instance.route(
        uri,
        host,
        methods,
        strict_slashes,
        version,
        name,
        apply,
        websocket,
        subprotocols,
    )



# Generated at 2022-06-12 09:13:55.411533
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
  print("test_RouteMixin_add_route")
  obj = RouteMixin()
  handler = lambda x:x
  uri = "/users"
  methods = ["GET", "POST", "PUT", "DELETE"]
  host = "127.0.0.1"
  strict_slashes = True
  version = 1
  name = "myview"
  expect_result = True
  actual_result = obj.add_route(handler, uri, methods, host, strict_slashes, version, name)
  assert actual_result == expect_result


# Generated at 2022-06-12 09:14:02.305229
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test')

    def handler(request):
        return HTTPResponse(text="Hello")

    app.add_route(handler, uri='/test', host=None)

    assert app.router.routes_all[0].name == "test_handler"
    assert app.router.routes_all[0].uri == '/test'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].endpoint is handler


# Generated at 2022-06-12 09:14:02.890302
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-12 09:14:05.779433
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Testing class RouteMixin
    cls, expected_result, actual_result = RouteMixin, "handler", "handler"
    assert actual_result == expected_result 


# Generated at 2022-06-12 09:14:11.720696
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():  
    router = Router()

    @router.route('/test_route', methods=['GET', 'POST'], host='fake_host', strict_slashes=False, version=1, name='test_route',
                  apply=True)
    def test_route():
        pass

    assert router.routes_names['test_route'] == test_route


# Generated at 2022-06-12 09:14:19.715722
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic(__name__)

    @app.add_route('/', host='localhost.localdomain', methods=None,
                   strict_slashes=False, version=None, name=None,
                   handler=None, websocket=False, stream=False, apply=True)
    async def handler(request):
        return text('OK')


    assert(app.routes[0].name == 'test_RouteMixin_add_route.<locals>.handler')
    assert(app.routes[0].version is None)
    assert(app.routes[0].uri == '/')
    assert(app.routes[0].strict_slashes == False)
    assert(app.routes[0].endpoint_name == 'handler')

# Generated at 2022-06-12 09:14:51.635734
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    @app.route("/")
    async def root(request):
        return json({"hello": "world"})

    assert root.__name__ == 'root'
    assert root.__code__.co_argcount == 1
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'root'
    assert app.router.routes_all[0].handler == root


# Generated at 2022-06-12 09:15:03.299863
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    """ Testing add_route
    """
    # Test input data
    @app.route("/hi")
    def hi(request):
        return "hi"

    @app.websocket("/echo")
    async def echo(request, ws):
        while True:
            msg = await ws.recv()
            await ws.send(msg)

    # Tested method
    router.add_route(hi)
    router.add_route(echo)

    # Test assertion
    assert(len(router.routes) == 2)
    assert(router.routes[1].uri == "/echo")
    assert(router.routes[0].uri == "/hi")
    assert(router.routes[1].handler == echo)

# Generated at 2022-06-12 09:15:06.561635
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    uri = ""
    host=None
    methods=None
    strict_slashes=None
    version=None
    name=None
    apply=True
    _method_route(uri, host, methods, strict_slashes, version, name, apply)

# Generated at 2022-06-12 09:15:11.692866
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    with pytest.raises(TypeError):
        RouteMixin().add_route(uri=123, host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True)
    with pytest.raises(TypeError):
        RouteMixin().add_route(uri='abc', host=123, methods=None, strict_slashes=None, version=None, name=None, apply=True)
    with pytest.raises(TypeError):
        RouteMixin().add_route(uri='abc', host='def', methods=123, strict_slashes=None, version=None, name=None, apply=True)

# Generated at 2022-06-12 09:15:14.871178
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    mixin = RouteMixin()
    routes = mixin.route(uri="www.baidu.com",methods=["GET"],strict_slashes=False)(print)
    assert len(routes) == 1

# Generated at 2022-06-12 09:15:21.517562
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route

    r = RouteMixin()
#     r.route(uri='/',methods=['GET'],name=None,version=None,strict_slashes=None,host=None)
#     r.route(uri='/',methods=['GET'],name=None,version=None,strict_slashes=None,host=None,apply=False)
    
    
#     assert True


# Generated at 2022-06-12 09:15:27.948747
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route

    app = Sanic()
    app.config.REQUEST_MAX_SIZE = 2**32

    route = RouteMixin().add_route("/", {})
    assert isinstance(route, Route)
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None



# Generated at 2022-06-12 09:15:28.979378
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-12 09:15:37.964958
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    router = RouteMixin()
    assert len(router.routes) == 0
    router.add_route('/', handler, methods=['GET','POST'], host='example.com', strict_slashes=True, stream=True, version=1)
    assert len(router.routes) == 1
    assert router.routes[0].uri == '/'
    assert router.routes[0].host == 'example.com'
    assert router.routes[0].methods == {'GET','POST'}
    assert router.routes[0].strict_slashes == True
    assert router.routes[0].stream == True
    assert router.routes[0].version == 1
    assert router.routes[0].handler == handler

# Generated at 2022-06-12 09:15:42.417225
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """Method route of class RouteMixin"""
    # noinspection PyUnusedLocal
    @RouteMixin.route("/", host="localhost", methods=["GET", "POST"], version=1)
    def handler(request):
        pass

    assert True # TODO: implement your test here


# Generated at 2022-06-12 09:16:42.378670
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # create a class called RouteMixin for testing
    class RouteMixin:
        def __init__(self):
            self.routes = []
            self.strict_slashes = False
            self.host = None
            self.version = None
            self.name = "sanic"

        def route(self, uri, host=None, strict_slashes=None, name=None):
            routes = []
            def decorator(func):
                host = host if host is not None else self.host
                strict_slashes = (
                    strict_slashes
                    if strict_slashes is not None
                    else self.strict_slashes
                )
                name = name if name is not None else self._generate_name(func)

# Generated at 2022-06-12 09:16:51.817096
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():    
    class Test:
        @staticmethod
        def test_func(*args, **kwargs):
            print(f'args: {args}, kwargs: {kwargs}')
            return 'Test'

    obj = RouteMixin()
    obj._get_route_name = MagicMock(return_value='test_name')
    obj.make_handler = MagicMock(side_effect=Test.test_func)

    _handler = obj.route(
        uri='/test_route',
        methods=['GET', 'HEAD'],
        version=3,
        name='test_name',
        host='127.0.0.1',
        strict_slashes=False,
        stream=True,
        apply=True
    )(Test.test_func)

    # print(_handler.__closure__)


# Generated at 2022-06-12 09:16:52.923023
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    assert True


# Generated at 2022-06-12 09:16:59.583034
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class Test(RouteMixin):
        def __init__(self):
            self._future_statics = set()
            self.uri = None

        def url_for(self, view_name, **kwargs):
            print(kwargs)

    app = Test()
    app.route(uri='/', methods=None, name='route_0', apply=True, strict_slashes=None, version=None)
    #with pytest.raises(Exception) as ex:
    #    app.route(uri='/', methods=['GET'], name='route_0', apply=True, strict_slashes=None, version=None)
    assert len(app.uri) == 0
    #app.add_websocket_route(app, uri='/', host=None, strict_slashes=None, version=None

# Generated at 2022-06-12 09:17:06.773676
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():

    @app.route("/route_mixin_static_handler", methods=['GET', 'POST'])
    async def route_mixin_static_handler(request):
        return response.text('')

    assert app.router.url_for('route_mixin_static_handler', _external=True) == '/route_mixin_static_handler'
    assert isinstance(app.router.add_static('/route_mixin_static_handler', 'https://www.baidu.com/'), list)
    assert app.router.route_for('route_mixin_static_handler', '/static/route_mixin_static_handler') is None
    assert app.router.add_static is RouteMixin.static
    assert app.router._apply_static is RouteMixin._apply_static

# Generated at 2022-06-12 09:17:12.505598
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from .sanic import Sanic
    from .router import Route
    app = Sanic("name")
    app.__class__.name = "name"
    uri = "/"
    methods = ["GET"]
    strict_slashes = None
    version = None
    name = "name"
    apply = True
    route, _ = route(uri=uri, methods=methods, strict_slashes=strict_slashes, apply=apply, version=version, name=name)(lambda : "a")
    assert route.uri == "/"


# Generated at 2022-06-12 09:17:21.441487
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    mixin = RouteMixin()
    mixin.server = MyServer()
    mixin.server.error_handler = lambda request, exception: text(str(exception))
    mixin.server.exception_handler = lambda request, exception: text(str(exception))
    mixin.server.middleware = []

    @mixin.add_route(uri='/index')
    async def index(request):
        return text('首页')

    @mixin.add_route(uri='/news/<news_id>', methods=['GET'])
    async def news_handler(request, news_id):
        return text(news_id)

    @mixin.add_route(uri='/login', methods=['POST', 'GET'])
    async def login_handler(request):
        return text

# Generated at 2022-06-12 09:17:27.796803
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():


    try:
        RouteMixin.route(None, None, None, None, None)
    except TypeError as e:
        assert type(e) == TypeError

    try:
        RouteMixin.route(True, None, None, None, None)
    except TypeError as e:
        assert type(e) == TypeError

    try:
        RouteMixin.route([], None, None, None, None)
    except TypeError as e:
        assert type(e) == TypeError

    try:
        RouteMixin.route(1, None, None, None, None)
    except TypeError as e:
        assert type(e) == TypeError

    try:
        RouteMixin.route("a", None, None, None, None)
    except TypeError as e:
        assert type(e) == TypeError

# Generated at 2022-06-12 09:17:29.217596
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    myobj = RouteMixin()
    # not testable
    pass


# Generated at 2022-06-12 09:17:32.595212
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    app = Sanic(__name__)

    async def handler(request):
        pass

    app.route('/test')(handler)

    assert app.router.routes_all["GET"][0].uri == "test"

# Generated at 2022-06-12 09:18:34.965236
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.websocket import ConnectionClosed
    from sanic.server import HttpProtocol
    from sanic.response import BaseHTTPResponse
    from sanic.router import RouteExists, RouteExists

    from unittest.mock import Mock, patch
    from io import BytesIO

    router = Mock()
    route_mixin = RouteMixin()
    route_mixin.router = router

    #---------------------------------------------------------------------------
    # CHECK Path URL
    #---------------------------------------------------------------------------
    # test: route_mixin.route()
    # set uri to None
    uri = None
    methods = [
        "GET",
        "POST",
        "PUT"
    ]
    host = "127.0.0.1"
    strict_slashes=False
    version=1

# Generated at 2022-06-12 09:18:42.110681
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Arrange
    with patch("sanic.router.Route.handlers", new_callable=PropertyMock) as mock_handler:
        mock_route = Mock()
        mock_route.methods = []
        mock_route.uri_template = "/test/route"
        mock_handler.return_value = [mock_route]
        mock_app = Mock()
        mock_app.error_handler = {}
        mock_app.websocket_max_size = 1024
        mock_app.websocket_max_queue = 100
        mock_app.websocket_read_limit = 2 ** 16
        mock_app.websocket_write_limit = 2 ** 16
        mock_app.route_list = ["test"]

        # Act
        test_subject = RouteMixin(mock_app)


# Generated at 2022-06-12 09:18:49.426502
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    
    import asyncio
    @asyncio.coroutine
    def mock_loop():
        pass
    
    @asyncio.coroutine
    def mock_run_forever():
        yield from mock_loop()
    
    @asyncio.coroutine
    def mock_start_server(server_coro, host, port):
        return (server_coro, host, port)
    
    class Mock_router_route():
        
        def __init__(self):
            pass
        
        def add(self):
            pass
        
    @asyncio.coroutine
    def mock_router_register(route):
        return route

    class Mock_Router():
        
        def __init__(self):
            self.route = Mock_router_route()

# Generated at 2022-06-12 09:18:54.384488
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = RouteMixin()
    @app.add_route('/', method='GET', strict_slashes=False)
    def test_1():
        pass
    assert app.routes[0].uri == '/'
    assert app.routes[0].strict_slashes == False


# Generated at 2022-06-12 09:18:58.957615
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    '''
    Unit test for method route of class RouteMixin
    '''
    router = RouteMixin()
    @router.route('/')
    async def index(request):
        return 'Hello'
    # Now assume the function didn't crash - it passed the test
    assert True

# Generated at 2022-06-12 09:19:01.070257
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    async def handler(request):
        pass
    _self = RouteMixin()
    _self.add_route(handler, None)

# Generated at 2022-06-12 09:19:10.180047
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    def _test(endpoint, http_methods, handler, host, strict_slashes, **options):
        methods = http_methods or ["GET"]
        uri = endpoint
        for method in methods:
            handler_func = handler
            if isinstance(endpoint, tuple):
                uri, handler_func = endpoint

            route, _ = router.route(
                uri,
                methods=[method],
                name=options.get("name"),
                host=host,
                strict_slashes=strict_slashes,
                **options
            )(handler_func)

            return route

    test_router = RouteMixin(name="test")
    test_router.add_route(endpoint="/a", handler="b")


# Generated at 2022-06-12 09:19:16.363851
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from typing import Union
    import pytest
    from sanic import Sanic
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic import Sanic
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage

    app = Sanic(__name__)


# Generated at 2022-06-12 09:19:25.121378
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.server import Sanic
    from sanic.router import Route, RouteExists, Router
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    import types

    router = Router()
    Sanic.__dict__['router'] = router
    Sanic.__dict__['is_request_stream'] = False
    app = Sanic('test_RouteMixin_add_route')
    app.__dict__['_route_list'] = []
    app.__dict__['_route_websocket_list'] = []
    app.__dict__['_error_handlers'] = {}
    app.__dict__['exception_handlers'] = {}
    app.__dict__['_before_server_start'] = []

# Generated at 2022-06-12 09:19:30.426178
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    uri = "/"
    host = "127.0.0.1"
    strict_slashes = True
    version = "v1.0"
    name = "test1"
    version_kwargs = {"version": version}
    apply = True
    websocket = True
    routes, decorated_function = RouteMixin().route(uri, host, None, strict_slashes, version, name, apply, websocket)
    if routes[0].uri == "/":
        print("success")
    else:
        print("fail")


# Generated at 2022-06-12 09:21:20.053845
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    x = RouteMixin()
    x.add_route("/", "/", ["GET"], "t", "t", "t")
    assert True


# Generated at 2022-06-12 09:21:24.307818
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():

    try:
        mixin = RouteMixin()
        mixin.add_route("/foo/bar", lambda request: "Hello", methods=["GET"])

    except Exception as e:
        print("Exception raised: " + str(e))
        raise AssertionError("The test case is failed")


# Generated at 2022-06-12 09:21:30.156428
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestClass:
        pass
    uri = '/users/'
    methods = ['GET', 'POST', 'PATCH', 'DELETE']
    Test = TestClass()
    RouteMixin.add_route(Test, uri=uri, methods=methods)
    assert Test.uri == uri
    assert Test.methods == methods

# test for method add_websocket_route of class RouteMixin

# Generated at 2022-06-12 09:21:35.633721
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    app = MagicMock()
    route = RouteMixin(app)
    route.static('url','file_or_directory', pattern='pattern', use_modified_since=True, use_content_range=False, stream_large_files=False, name='static', host=None, strict_slashes=None, content_type=None, apply=True)
    assert type(route.routes) == list
    assert type(route.routes[0]) == Route
