

# Generated at 2022-06-12 09:11:59.422483
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    route_mixin = RouteMixin()
    route_mixin.add_route()


# Generated at 2022-06-12 09:12:01.142477
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    r = RouteMixin()
    r.add_route()

# Generated at 2022-06-12 09:12:10.223400
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    import asyncio
    from sanic import Sanic
    from sanic.response import text
    from sanic_router import RouteMixin
    from sanic_router.route import Route
    from sanic_router.websocket import WebSocketRoute
    from sanic.request import Request

    class Handler(RouteMixin):
        def __init__(self):
            self.handlers = []

        def add_route(self, handler, uri, methods, host, strict_slashes, version, name,
                apply, websocket, stream):
            self.handlers.append(handler)

    class App(Sanic):
        def __init__(self):
            super().__init__(name='App')

    app = App()
    handler = Handler()


# Generated at 2022-06-12 09:12:17.825343
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
	data = {'a': 1, 'b': 2}
	r = RouteMixin()
	uri = '/foo'
	methods = None
	strict_slashes = None
	version = None
	name = None
	apply = True
	subprotocols = None
	websocket = False
	def decorated_function(data):
		return data
		
	return_value = r.route(uri, methods, strict_slashes, version, name, apply, subprotocols, websocket)
	assert return_value(decorated_function)(data) == data


# Generated at 2022-06-12 09:12:24.613692
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    router = Router()

    @app.route('/')
    def handler(request):
        return response.text('I am home page')

    router.add_route(handler.__get__(None, app), uri = '/')
    #self.assertEqual(handler.__get__(None, app), router.routes_all[0].handler)
    assert handler.__get__(None, app), router.routes_all[0].handler


# Generated at 2022-06-12 09:12:34.406917
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class A: pass
    a = A()
    a.route = RouteMixin.route
    a.uri_for = RouteMixin.uri_for

    @a.route('/')
    def handler1(request):
        return text('OK')

    @a.route('/2')
    def handler2(request):
        return text('OK')

    _, handler = a.route('/3')(handler2)
    assert handler is handler2
    _, handler = a.route('/4', methods=['GET', 'POST'])(handler2)
    assert handler is handler2
    _, handler = a.route('/5', host='example.com')(handler2)
    assert handler is handler2
    _, handler = a.route('/6', version=1)(handler2)
    assert handler is handler2

# Generated at 2022-06-12 09:12:42.728009
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test the exceptions of the method route
    # 1. When the methods are not specified, it should throw exception
    @app.route("/")
    def test():
        pass

    with pytest.raises(ValueError):
        app.route("/", methods=None, name=None, host=None, strict_slashes=None)(
            test
        )

    # 2. When the uri is not specified, it should throw exception
    @app.route("/")
    def test():
        pass

    with pytest.raises(ValueError):
        app.route(uri=None, methods=["GET"], name=None, host=None, strict_slashes=None)(
            test
        )

    # 3. When the strict_slashes is not specified but app.strict_slashes is not None, it should throw exception

# Generated at 2022-06-12 09:12:54.503562
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    from sanic.router import Route

    route = Route(
        uri='/',
        methods=['GET', 'POST'],
        host='127.0.0.1',
        stream=False,
        version=None,
        name='name',
        strict_slashes=False,
        websocket=False,
        )
    assert route.uri == '/',    \
        'uri attribute of class Route is wrong'
    assert route.methods == ['GET', 'POST'],    \
        'methods attribute of class Route is wrong'
    assert route.host == '127.0.0.1',    \
        'host attribute of class Route is wrong'
    assert route.stream == False,    \
        'stream attribute of class Route is wrong'

# Generated at 2022-06-12 09:13:04.066535
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from app import RouteMixin
    from app import UrlDispatcher
    from app import HttpProtocol
    from app import WebSocketProtocol
    from app import Blueprint

    method = "GET"
    uri = None
    host = None
    version = None
    strict_slashes = None
    stream = None
    methods = ["POST", "PUT", "GET", "OPTIONS", "HEAD", "DELETE"]
    name = None
    blueprint = None
    subprotocols = None
    expect = ["POST", "PUT", "GET", "OPTIONS", "HEAD", "DELETE"]
    instance = RouteMixin()
    instance.websocket_enabled = False
    instance.router = UrlDispatcher(HttpProtocol, WebSocketProtocol)
    instance.blueprint = blueprint
    instance

# Generated at 2022-06-12 09:13:11.878538
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # check route finction in RouteMixin
    # Initilize a server
    app = Sanic("test_RouteMixin_route")
    app.config.REQUEST_MAX_SIZE = 10  # this number is very small
    
    # Set a route to the server
    @app.route('/', methods=['GET'])
    async def test(request):
        return text('OK')
    
    # Set a client and server
    request, response = app.test_client.get('/')
    
    # Check the response of the route
    assert response.text == 'OK'

# Generated at 2022-06-12 09:13:39.404698
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    scheme='http'
    port=5000
    uri='/'
    host=None
    methods=['GET']
    handler=None
    strict_slashes=None
    stream=False
    version=None
    name=None
    add_route=RouteMixin._router_add_route
    route, handler=add_route(scheme=scheme,port=port,uri=uri,host=host,
                              methods=methods,handler=handler,strict_slashes=strict_slashes,stream=stream,
                              version=version,name=name)
    assert(route.uri==uri)
    assert(route.is_static()==True)
    assert(route.host==host)
    assert(route.methods==methods)
    assert(route.handler==handler)

# Generated at 2022-06-12 09:13:42.653186
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Write test cases
    router = RouteMixin()
    assert router.add_route(None, None, None) != None, "register a route to serve all the requests to the specified handler"


# Generated at 2022-06-12 09:13:43.953468
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # dummy class
    class A:
        pass

    a = A()
    b = RouteMixin()
    b.add_route(a)



# Generated at 2022-06-12 09:13:45.553805
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    instance = RouteMixin()
    assert type(instance.route()) is tuple


# Generated at 2022-06-12 09:13:46.641364
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement
    pass


# Generated at 2022-06-12 09:13:47.243058
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    pass

# Generated at 2022-06-12 09:13:57.915739
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    app = Sanic('test_RouteMixin_add_route')
    app.config.KEEP_ALIVE_TIMEOUT = 10
    app.config.REQUEST_MAX_SIZE = 100000000
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    route = app.add_route
    # Check the type of return value
    return_value = route(lambda r: HTTPResponse(),"/test",methods=['GET'])
    assert(isinstance(return_value, tuple) and len(return_value) == 2)
    assert(isinstance(return_value[0], list) and len(return_value[0]) == 1)
    assert(isinstance(return_value[0][0], Route))


# Generated at 2022-06-12 09:14:08.733235
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestClass:
        def __init__(self):
            self.router = Router()
        def add_route(self, handler, uri,methods=None, host=None, strict_slashes=None,
             version=None, name=None):
            return self.router.add(uri, handler, methods=None, host=None, strict_slashes=None,
             version=None, name=None)
    
    test = TestClass()
    def handler1(req):
        return "hello"
    test.add_route(handler1, '/')
    assert(test.router.routes[0].name == "handler1")
    assert(test.router.routes[0].uri == '/')

# Generated at 2022-06-12 09:14:10.715499
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    # 1.Test
    @app.listener("before_server_stop")
    async def stop(app, loop):
        app.is_started = False


# Generated at 2022-06-12 09:14:19.083355
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test")
    mixin = RouteMixin(app)
    handler = lambda request: text("OK")
    route, handler = mixin.route(uri="/")(handler)
    assert route.uri == "/"
    assert route.host == None
    assert route.strict_slashes == None
    assert route.methods == ["GET"]
    assert route.name == "test.lambda.<locals>.<lambda>"
    assert route.static == False
    assert route.version == None
    assert route.stream == None
    assert route.websocket == False
    assert route.handler == handler
    assert route.schema == None
    assert route.subprotocols == None
    assert route.blueprint == None
    assert route.dependency == None
    assert route.middlewares == None

# Generated at 2022-06-12 09:14:42.648421
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    app = Sanic(__name__, strict_slashes=True)
    app.static("/assets", "./assets", name="static")
    app.blueprint(bp)
    # app.run()
    assert app.is_request_stream is False
    assert app.error_handler is None
    assert app.before_server_start is None
    assert app.before_server_stop is None
    assert app.before_request is None
    assert app.after_request is None
    assert app.request_timeout is None
    assert app.keep_alive_timeout is 2
    assert app.response_timeout is 60
    assert app.websocket_timeout is None
    assert app.websocket_max_size is 2 ** 20
    assert app.websocket_max_queue is 32
    assert app.websocket

# Generated at 2022-06-12 09:14:46.723591
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_RouteMixin_route')

    @app.route('/')
    async def test(request):
        return text('OK')

    request, response = app.test_client.get('/')

    assert response.text == 'OK'



# Generated at 2022-06-12 09:14:48.429969
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test route method
    # Test with all valid inputs

    # Test with all invalid inputs
    assert True



# Generated at 2022-06-12 09:14:51.080484
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    router = Router()
    route, _ = router.route(uri='/')(print)
    assert hasattr(route, 'name')
    assert not route.static
    assert not route.websocket
    assert type(route) == Route


# Generated at 2022-06-12 09:14:53.543615
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    try:
        router = RouteMixin()
        handler = lambda x: x
        router.add_route(handler, uri="/test")
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 09:15:05.463566
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.name = ""
            self.strict_slashes = False
            self.url_prefix = ""
            self.version = None
            self.error_handler = None
            self.websocket_timeout = 10
            self.exception_handler = None
            self.request_middleware = None
            self.response_middleware = None
            self.host = None
            self._future_routes = set(())
            self._future_statics = set(())
            self._reversed_routes = {}
            self._routes = {}
            self.is_request_stream = False
            self.is_websocket_route = False
            self.is_static_route = False

# Generated at 2022-06-12 09:15:12.777953
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    
    blueprint = Blueprint("bp", url_prefix='/bp')
    blueprint.add_route(handler, '/', host='xyz.com')
    blueprint.add_route(handler, '/', host='xyz.com', methods='get')
    blueprint.add_route(handler, '/', host='xyz.com', methods=['get'])
    blueprint.add_route(handler, '/', host='xyz.com', methods=['get', 'post'])
    blueprint.add_route(handler, '/', host='xyz.com', methods='get', name='')
    blueprint.add_route(handler, '/', host='xyz.com', methods=['get'], name='')
    blueprint.add_route(handler, '/', host='xyz.com', methods=['get', 'post'], name='')

# Generated at 2022-06-12 09:15:23.326230
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class mock_Route:
        """
        mock class for Route
        """
        def __init__(self):
            self.uris = []
            self.hosts = []
            self.version = 0

        def add_uri(self, uri):
            self.uris.append(uri)

        def add_host(self, host):
            self.hosts.append(host)

        def set_version(self, version):
            self.version = version
    
    class mock_Handler:
        """
        mock class for _Handler
        """
        def __init__(self):
            pass
    
    # Test case 1
    # uri: Test case uri
    # host: Test case host
    # version: Test case version
    # expected: add_uri, add_host and set_version will be

# Generated at 2022-06-12 09:15:33.220997
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    thistest = unittest.TestCase('__init__')
    request = Request("/route", "GET")
    app = Sanic("test_RouteMixin_route")
    expected_result = {
        "uri": "/route",
        "methods": ["GET"],
        "strict_slashes": None,
        "version": None,
        "name": "test_function_name",
        "host": None,
        "apply": True,
        "static": False,
        "is_stream": False,
        "websocket": False,
        "expected_exceptions": None,
        "route": app.route
    }
    result = RouteMixin.route(uri="/route", methods=["GET"], name="test_function_name")(app.route)

# Generated at 2022-06-12 09:15:42.066184
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    @functools.lru_cache()
    def _generate_name(name: Optional[str]) -> str:
        return "post-id"
    @functools.lru_cache()
    def _generate_handler(*args, **kwargs) -> tuple:
        return (
            'coroutine',
            functools.partial(
                _generate_handler,
                *args,
                **kwargs,
            ),
        )

    class RouteMixin:
        name = 'test'
        strict_slashes = False
        _lru_cache_generate_handler = _generate_handler
        _lru_cache_generate_name = _generate_name
        def __init__(self):
            self._routes = {}

# Generated at 2022-06-12 09:16:35.504899
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    async def handler(request):
        return 1

    sanic_app = Sanic('test')
    route = RouteMixin.add_route(sanic_app, handler, '/', None, None, None, None)
    assert route == [
        Route(
            uri='/',
            handler=handler,
            name='',
            static=False,
            host=None,
            methods=frozenset({'GET'}),
            version=None,
            strict_slashes=None,
        )
    ]

# Generated at 2022-06-12 09:16:37.631301
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    rm = RouteMixin()
    a = rm.route(uri='/')
    assert a is not None


# Generated at 2022-06-12 09:16:47.076088
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    _app = Sanic('test')
    _app.config.KEEP_ALIVE = False
    _app.config.REQUEST_MAX_SIZE = 104857600
    _app.config.REQUEST_TIMEOUT = 60
    _app.config.RESPONSE_TIMEOUT = 60

    
    # app.config.KEEP_ALIVE: None
    # app.config.REQUEST_MAX_SIZE: 100000000
    # app.config.REQUEST_TIMEOUT: 60
    # app.config.RESPONSE_TIMEOUT: 60

    class TestClass:
        @_app.route('/test', methods=['GET'])
        async def test(request, *args, **kwargs):
            return text('OK')

# Generated at 2022-06-12 09:16:53.893237
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO:
    #   test with arguments
    print("[RouteMixin] Testing add_route...")
    app = Sanic()
    route = RouteMixin(app)
    uri = "/"
    methods = ["GET", "POST", "PUT", "DELETE"]
    # url_for = "test"
    handler = "test"
    version = 1
    name = "test_route"
    assert(route.add_route(handler, uri, methods, None, None, version, name) == "test")
    print("[RouteMixin] add_route OK")


# Generated at 2022-06-12 09:17:03.172023
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    _test_ = RouteMixin()
    #_test_.add_route(handler=None,method="",uri="",host=None,strict_slashes=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None)
    # test with sample data
    _test_.add_route(handler=None,method="",uri="",host=None,strict_slashes=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None,name=None,version=None,sandbox=None)
    

# Generated at 2022-06-12 09:17:11.609698
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Params for static
    uri = "/static"
    file_or_directory = "static"
    pattern = r"/?.+"
    use_modified_since = True
    use_content_range = False
    stream_large_files = False
    name = "static"
    host = None
    strict_slashes = None
    content_type = None
    apply = True

    # Create RouteMixin Object
    RouteMixin_Obj = RouteMixin()

    # Test
    RouteMixin_Obj.static(
        uri,
        file_or_directory,
        pattern,
        use_modified_since,
        use_content_range,
        stream_large_files,
        name,
        host,
        strict_slashes,
        content_type,
        apply
    )
    pass

# Generated at 2022-06-12 09:17:20.915584
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    """
        :param uri: URI path for the Route
        :param methods: list of str with method names for the Route
        :param host: Host IP or FQDN details
        :param strict_slashes: If the API endpoint needs to terminate
                               with a "/" or not
        :param version: version of the API to be used
        :param name: A unique name assigned to the URL so that it can
                     be used with :func:`url_for`
        :param apply: Apply the routes to the router
        :param stream: Should the response to this route be streamed
        :param expect_handler: expected handler
        :return: Nothing
    """

    _uri = "home"
    _methods = ["GET", "HEAD"]
    _host = "home"
    _strict_slashes = False
    _version = 2

# Generated at 2022-06-12 09:17:30.734386
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():

    # 1st Test
    router = RouterMixin()
    assert router.route('/url') == ('/url',None,None,{'args':()},None,None,None,None,None,None,None,None,None,None)

    # 2nd Test
    router = RouterMixin()
    assert router.route(uri='/url', methods=['GET']) == ('/url',None,None,{'args':()},None,'GET',None,None,None,None,None,None,None,None)

    # 3rd Test
    router = RouterMixin()
    assert router.route(uri='/url', methods=['GET'], version=2) == ('/url',None,None,{'args':()},None,'GET',2,None,None,None,None,None,None,None)

    #

# Generated at 2022-06-12 09:17:31.638631
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass


# Generated at 2022-06-12 09:17:40.464775
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    route=RouteMixin()
    app=APP(__name__)
    @route.route('/')
    async def f(request):
        return response.text('Hello World')
    # test sanic_route(app, f)
    #test app.http_middleware
    #test app.websocket_middleware
    #test app.exception_handler
    #test app.listeners
    #test app.before_server_start
    #test app.after_server_start
    #test app.before_server_stop
    #test app.after_server_stop
    #test app.before_server_start_cb
    #test app.after_server_start_cb
    #test app.before_server_stop_cb
    #test app.after_server_stop_cb
    #test app.

# Generated at 2022-06-12 09:18:20.596667
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request

    routes = Mock()
    router = RouteMixin(name="", router=routes)

    result = router.route(
        uri="/test/endpoint",
        methods=["POST", "GET"],
        host="",
        strict_slashes=False,
        version=None,
        name="",
        apply=True,
        subprotocols=None,
        websocket=False,
    )

    # Check if router.route() is a function or not
    assert callable(result)

    # Check if it adds a new Route object to the routes list
    assert len(routes.routes) == 1

    # Check if it returns a tuple of routes, decorated function
    assert isinstance(result(), tuple)

# Generated at 2022-06-12 09:18:31.722879
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import json, text
    from sanic.views import CompositionView
    from sanic.handlers import ErrorHandler
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.blueprints import Blueprint

    uri = "/test_route/"
    methods = ["GET", "POST"]
    strict_slashes = True
    host = None
    version = "1.0"
    name = "test_route"
    version = "1.0"
    apply = True
    allow_websocket = True
    websocket = False
    static = False

# Generated at 2022-06-12 09:18:35.442638
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test_router = RouterMixin()
    uri = "/"
    methods = None
    strict_slashes = None
    version = None
    name = "index"
    apply = True
    test_router.route(uri, methods, strict_slashes, version, name, apply)
    assert(True)


# Generated at 2022-06-12 09:18:36.678056
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    test = RouteMixin()
    test.route()

# Generated at 2022-06-12 09:18:45.178385
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    import unittest
    import copy
    import sys
    import os
    import json
    import asyncio
    import tempfile

    from sanic import Sanic
    from sanic.response import html, text, json as json_response
    from sanic.blueprints import Blueprint
    from sanic.router import Route, BlueprintSetupState
    from sanic.request import Request
    from sanic.exceptions import URLBuildError, NotFound
    from sanic.views import HTTPMethodView, CompositionView
    from sanic.handlers import ErrorHandler

    class RouteTest(unittest.TestCase):
        def setUp(self):
            self.app = Sanic("test_route")

        def test_string_route(self):
            async def handler(request, test):
                return text(test)


# Generated at 2022-06-12 09:18:56.769262
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    @add_route(uri="/")
    async def handler(request):
        return "hello"
    
    l = RouteMixin()
    l.add_route(handler, uri="/")
    l.add_route(handler, uri="/ben")
    l.add_route(handler, uri="/sanic")
    assert l.has_route(uri="/") == True
    assert l.has_route(uri="/ben") == True
    assert l.has_route(uri="/sanic") == True
    assert l.has_route(uri="/sanic1") == False
    
    l.add_route(handler, uri="/sanic", methods=["GET"])
    l.add_route

# Generated at 2022-06-12 09:19:06.910486
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test without arguments
    try:
        obj_RouteMixin = RouteMixin()
        obj_RouteMixin.add_route()
    except:
        pass
    else:
        raise Exception("Expected error not thrown")

    # Test with invalid argument(s) type
    try:
        obj_RouteMixin = RouteMixin()
        obj_RouteMixin.add_route(
            uri=None,
            handler=None,
            host=None,
            methods=None,
            strict_slashes=None,
            version=None,
            name=None,
            stream=None
        )
    except:
        pass
    else:
        raise Exception("Expected error not thrown")

    # Test with invalid argument(s) value

# Generated at 2022-06-12 09:19:13.404273
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    try:
        import sanic
    except:
        class sanic:
            class Sanic:
                pass
    class TestRouteMixin:
        pass
    T = TestRouteMixin()
    T.Sanic = sanic.Sanic()
    T.route = RouteMixin.route
    # test for no return
    try:
        with pytest.raises(TypeError):
            for test_type in [
                [],
                {},
                -1,
                0,
                1,
                True,
                False,
                None,
                float("nan"),
                float("inf"),
                float("-inf"),
            ]:
                try:
                    T.route(uri=test_type)
                except TypeError:
                    pass
    except Exception as e:
        print(e)

# Generated at 2022-06-12 09:19:22.924614
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # get service information
    service_info = get_service_information("app_io_sanic_route_mixin.py")
    # set a temporary file path
    tmp_file_path = get_temp_file_path()
    # initialize the router
    router = service_info.service_access_point.router
    # test method route
    router.route(uri="/user/<user_id>", methods=["GET"], version=1)(
        mock_function_handler)
    # test method route
    router.route(uri="/user/<user_id>", methods=["GET"], strict_slashes=False, version=1)(
        mock_function_handler)
    # test method route

# Generated at 2022-06-12 09:19:29.301886
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-12 09:20:26.858113
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    pass

# Generated at 2022-06-12 09:20:32.625843
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.response import text

    app = Sanic('test_RouteMixin_add_route')

    @app.route('/')
    async def index(request):
        return text('Hello!')

    # build the handlers and register it to the app
    request, response = app.add_route(index, '/', ['GET'])

    test_client = app.test_client
    request, response = test_client.get('/')
    assert response.text == 'Hello!'


# Generated at 2022-06-12 09:20:37.745526
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route, FutureStatic
    from sanic.server import serve
    from unittest.mock import Mock

    app = Sanic("test_RouteMixin")

    route_mixin = app.router
    route_mixin.static("/python", "sanic/static")
    # check instance of FutureStatic
    assert isinstance(route_mixin._future_statics.pop(), FutureStatic)


# Generated at 2022-06-12 09:20:43.704586
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class test_RouteMixin(RouteMixin):
    # def add_route(self, uri, handler, methods=None, host=None, version=None,
    #               strict_slashes=None, name=None, stream=False,
    #               provide_automatic_options=None,
    #               apply=True, **kwargs):
        pass
    handler = test_RouteMixin()
    handler.add_route(host="host", uri="uri", version = "version",
    strict_slashes = "slashes", name = "name",stream="stream",
    provide_automatic_options="automatic_options", apply="apply")

# Generated at 2022-06-12 09:20:46.729314
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    router = Router()
    test_route = 'http://localhost:5000/'
    @router.route('/')
    async def handler_func(request):
        return response.html('<p>Hi!</p>')
    assert router.routes[0].uri == test_route


# Generated at 2022-06-12 09:20:54.524298
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.testing import HOST, PORT
    from sanic.router import Route
    from sanic.response import json
    from sanic.constants import HTTP_METHODS
    from sanic.websocket import WebSocketProtocol

    class RouteMixin(Route):
        def __init__(self, *args, **kwargs):
            pass

    class RouteMixin_Test(RouteMixin):
        pass

    app = Sanic('test_RouteMixin_add_route')
    RouteMixin_Test.bind(app)
    @app.route('/')
    async def handler(request):
        return json({'test': True})


# Generated at 2022-06-12 09:20:59.249079
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class Router:
        pass

    r = RouteMixin(Router)
    r.add_route("url", "handler", "GET", None, None, None, True)
    assert r.routes == [mock.call(uri="url", methods=["GET"], host=None)]

# Generated at 2022-06-12 09:21:04.857286
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    class TestClass(Sanic):
        pass
    test_instance = TestClass()
    class TestClass2(RouteMixin):
        def __init__(self):
            self.instance = test_instance
    test_class = TestClass2()
    result = test_class.add_route(
        handler=ignore_handler,
        uri=ignore_uri,
        methods=ignore_methods,
        host=ignore_host,
        strict_slashes=ignore_strict_slashes,
        version=ignore_version,
        name=ignore_name,
    )
    # assert result == None
    assert result == ignore_handler



# Generated at 2022-06-12 09:21:15.701837
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route, RouteExists

    app = Sanic(__name__)
    app.config.KEEP_ALIVE = False

    ok = RouteMixin(app)
    mock = RouteMixin(app)
    def handler(request):
        return "ok"

    # should return routes which contains in routes field of mock
    route = mock.route("/", methods=["GET"])(handler)
    mock.routes.append(route)
    assert mock.route("/")(handler) == mock.routes

    # should raise RouteExists when try add duplicated url
    with pytest.raises(RouteExists):
        route_1 = mock.route("/", methods=["GET"])(handler)

# Generated at 2022-06-12 09:21:25.098434
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.response import text

    app = Sanic()
    # add_route function used
    @app.add_route("/", host="test.com")
    def handler(request):
        return text("OK")

    # add_route function succeed       
    assert app.router.routes_all[0].uri == '/'             
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].host == "test.com"
    assert len(app.router.routes_all[0].methods) == 1
    assert app.router.routes_all[0].methods[0] == 'GET'

    # add_route function failed      