

# Generated at 2022-06-18 05:41:51.070082
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with valid input
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].stream == False

# Generated at 2022-06-18 05:41:57.844413
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:42:09.334154
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import InternalServerError
    from sanic.exceptions import NotImplemented

# Generated at 2022-06-18 05:42:15.229566
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    route_mixin = RouteMixin(app)
    route_mixin.add_route(handler=None, uri=None, host=None, strict_slashes=None, version=None, name=None)
    assert True


# Generated at 2022-06-18 05:42:25.413462
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Route
    route_1 = Route()
    # Create a mock object of class Route
    route_2 = Route()
    # Create a mock object of class Route
    route_3 = Route()
    # Create a mock object of class Route
    route_4 = Route()
    # Create a mock object of class Route
    route_5 = Route()
    # Create a mock object of class Route
    route_6 = Route()
    # Create a mock object of class Route
    route_7 = Route()
    # Create a mock object of class Route
    route_8 = Route()
    # Create a mock object of class Route
    route_9 = Route

# Generated at 2022-06-18 05:42:37.889732
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import URLBuildError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage

# Generated at 2022-06-18 05:42:44.881004
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import json
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import stream_file
    from sanic.response import raw
    from sanic.response import jsonp
   

# Generated at 2022-06-18 05:42:55.061863
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:43:07.439970
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:43:15.397007
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    route = RouteMixin.add_route(app, '/', 'GET', 'test_RouteMixin_add_route')
    assert route.uri == '/'
    assert route.methods == ['GET']
    assert route.name == 'test_RouteMixin_add_route'
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.stream == None
    assert route.websocket == None
    assert route.static == None
    assert route.handler == None
    assert route.uri_template == None
    assert route.uri_template_args == None
    assert route.uri_template_kwargs == None
    assert route.uri_template_regex == None

# Generated at 2022-06-18 05:43:39.165038
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Sanic
    app = Sanic()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of Handler
    handler = Handler()
    # Create a new instance of RequestParameters
    request_parameters = RequestParameters()
    # Create a new instance of RouteParameters
    route_parameters = RouteParameters()
    # Create a new instance of RouteParameters
    route_parameters_1 = RouteParameters()
    # Create a new instance of RouteParameters
    route_parameters_2 = RouteParameters()
    # Create a new instance of RouteParameters
    route_parameters_3 = RouteParameters()
    # Create a new instance of RouteParameters
    route_parameters_4 = RouteParameters()
    #

# Generated at 2022-06-18 05:43:48.324127
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteRes

# Generated at 2022-06-18 05:43:59.462132
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_route_mixin = RouteMixin()
    # We will create a mock object for class Route
    mock_route = Route()
    # We will create a mock object for class Sanic
    mock_sanic = Sanic()
    # We will create a mock object for class Request
    mock_request = Request()
    # We will create a mock object for class Response
    mock_response = Response()
    # We will create a mock object for class HTTPResponse
    mock_http_response = HTTPResponse()
    # We will create a mock object for class StreamingHTTPResponse
    mock_streaming_http_response = StreamingHTTPResponse()
    # We will create a mock object for class

# Generated at 2022-06-18 05:44:05.351410
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock app
    app = Mock()
    # Create a mock router
    router = Mock()
    # Create a mock route
    route = Mock()
    # Create a mock handler
    handler = Mock()
    # Create a mock uri
    uri = Mock()
    # Create a mock methods
    methods = Mock()
    # Create a mock host
    host = Mock()
    # Create a mock strict_slashes
    strict_slashes = Mock()
    # Create a mock version
    version = Mock()
    # Create a mock name
    name = Mock()
    # Create a mock apply
    apply = Mock()
    # Create a mock subprotocols
    subprotocols = Mock()
    # Create a mock websocket
    websocket = Mock()
    # Create a mock route_list

# Generated at 2022-06-18 05:44:15.107310
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError

# Generated at 2022-06-18 05:44:26.604301
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Create a mock object of class RouteMixin
    mock_RouteMixin = RouteMixin()
    # Create a mock object of class Route
    mock_Route = Route()
    # Assign the mock object of class Route to mock_RouteMixin.route
    mock_RouteMixin.route = mock_Route
    # Create a mock object of class Sanic
    mock_Sanic = Sanic()
    # Create a mock object of class Request
    mock_Request = Request()
    # Create a mock object of class HTTPResponse
    mock_HTTPResponse = HTTPResponse()
    # Assign the mock object of class HTTPResponse to mock_Sanic.response_class
    mock_Sanic.response_class = mock_HTTPResponse
    # Create a mock object of class Route
    mock_Route

# Generated at 2022-06-18 05:44:30.753543
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:39.850223
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    app = Sanic("test_RouteMixin_static")
    app.static("/", "./")
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].name == "static"
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].static == True
    assert app.router.routes_all[0].websocket == False
    assert app.router.routes_all[0].methods == ["GET", "HEAD"]

# Generated at 2022-06-18 05:44:42.145745
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test with default args
    # TODO: Test with default args
    # Test with all args
    # TODO: Test with all args
    pass


# Generated at 2022-06-18 05:44:52.431058
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default parameters
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == 'test_RouteMixin_add_route.handler'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].methods == ['GET']
    assert app.router.rout

# Generated at 2022-06-18 05:45:24.966010
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import Route
    from sanic.router import Router
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist


# Generated at 2022-06-18 05:45:35.114489
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:44.004045
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    class RouteMixin:
        def add_route(self, handler, uri, methods=None, host=None, strict_slashes=None, version=None, name=None):
            route = Route(handler, uri, methods, host, strict_slashes, version, name)
            self.routes.append(route)
            return route, handler

    mixin = RouteMixin()
    mixin.add_route(MyView.as_view(), '/')

# Generated at 2022-06-18 05:45:54.677558
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin works
    # Input:
    #   uri = "/test"
    #   methods = ["GET", "POST"]
    #   strict_slashes = True
    #   version = 1
    #   name = "test"
    #   apply = True
    #   static = False
    #   websocket = False
    #   stream = False
    #   subprotocols = None
    #   host = None
    #   Expect:
    #   route = Route(uri, methods, strict_slashes, version, name, apply, static, websocket, stream, subprotocols, host)
    #   return route, handler
    uri = "/test"
    methods = ["GET", "POST"]
    strict_slashes = True

# Generated at 2022-06-18 05:46:05.452334
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].version == None

# Generated at 2022-06-18 05:46:17.762893
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import RouterResetWarning

# Generated at 2022-06-18 05:46:29.329549
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:46:40.278957
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # without any error
    # Expected result:
    # The method route of class RouteMixin can be called
    # without any error
    # Actual result:
    # The method route of class RouteMixin can be called
    # without any error
    app = Sanic('test_RouteMixin_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert app.is_request_stream is False
    assert app.error_handler is None
    assert app.before_server_start is None
    assert app.before_server_stop is None
    assert app.before_startup is None
    assert app.after_startup is None
    assert app.before_shutdown is None
   

# Generated at 2022-06-18 05:46:49.897230
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    app = Sanic("test_RouteMixin_route")
    app.route("/test_RouteMixin_route/", methods=["GET", "POST"])(lambda x: x)
    assert app.router.routes_all["GET"][0].uri == "/test_RouteMixin_route/"
    assert app.router.routes_all["POST"][0].uri == "/test_RouteMixin_route/"
    assert app.router.routes_all["GET"][0].name == "test_RouteMixin_route.test_RouteMixin_route"
    assert app.router.routes_all["POST"][0].name == "test_RouteMixin_route.test_RouteMixin_route"
    assert app.router.routes_all

# Generated at 2022-06-18 05:46:57.806812
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Handler
    handler = Handler()
    # Create a new instance of Route
    route = Route(
        uri='/',
        methods=['GET'],
        host=None,
        strict_slashes=None,
        version=None,
        name=None,
        handler=handler,
        websocket=False,
        stream=False,
        static=False,
        expect_handler=None,
        payload_compression_method=None,
        register=True,
        cors=None,
        expect_compression=None,
        status_code=None,
        compress_response=None,
        version_constraint=None,
        subprotocols=None,
    )
   

# Generated at 2022-06-18 05:47:45.792524
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: implement test
    pass


# Generated at 2022-06-18 05:47:56.898818
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_RouteMixin_route')

    @app.route('/')
    def handler(request):
        return text('OK')

    @app.route('/1')
    async def handler1(request):
        return text('OK')

    @app.route('/2')
    def handler2(request):
        return text('OK')

    @app.route('/3')
    async def handler3(request):
        return text('OK')

    @app.route('/4')
    def handler4(request):
        return text('OK')


# Generated at 2022-06-18 05:48:01.026495
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestRouteMixin(RouteMixin):
        pass
    route_mixin = TestRouteMixin()
    route_mixin.add_route(handler=None, uri=None, host=None, strict_slashes=None, version=None, name=None)


# Generated at 2022-06-18 05:48:02.674072
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: add test
    pass


# Generated at 2022-06-18 05:48:09.150617
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Route
    route = Route()
    # Call method add_route of RouteMixin
    route_mixin.add_route(route)
    # Assert that the route is added to the routes of RouteMixin
    assert route in route_mixin.routes


# Generated at 2022-06-18 05:48:17.261506
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists

# Generated at 2022-06-18 05:48:21.195585
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'


# Generated at 2022-06-18 05:48:32.176744
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_route_mixin = RouteMixin()
    # We will create a mock object for class Route
    mock_route = Route()
    # We will create a mock object for class Sanic
    mock_sanic = Sanic()
    # We will create a mock object for class Request
    mock_request = Request()
    # We will create a mock object for class HTTPResponse
    mock_http_response = HTTPResponse()
    # We will create a mock object for class HTTPResponse
    mock_http_response_1 = HTTPResponse()
    # We will create a mock object for class HTTPResponse
    mock_http_response_2 = HTTPResponse()
   

# Generated at 2022-06-18 05:48:40.357460
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:48:47.828634
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import Router
    from sanic.router import Route

# Generated at 2022-06-18 05:50:42.584321
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   handler = 'handler'
    #   methods = ['GET', 'POST']
    #   host = '127.0.0.1'
    #   strict_slashes = False
    #   version = 1
    #   name = 'name'
    #   apply = True
    #   stream = False
    #   websocket = False
    #   subprotocols = None
    #   expect = [Route(uri='/', methods=['GET', 'POST'], handler='handler', host='127.0.0.1', strict_slashes=False, version=1, name='name', stream=False, websocket=False, subprotocols=None)]
    uri = '/'
    handler = 'handler'

# Generated at 2022-06-18 05:50:53.776885
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:50:59.970434
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError

# Generated at 2022-06-18 05:51:01.420741
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-18 05:51:08.419548
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
   

# Generated at 2022-06-18 05:51:19.812618
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import HandlerDoesNotExist
    from sanic.router import HandlerExists
    from sanic.router import Route
    from sanic.router import Router
    from sanic.router import UrlForError
    from sanic.router import UrlFor
    from sanic.router import UrlForStatic