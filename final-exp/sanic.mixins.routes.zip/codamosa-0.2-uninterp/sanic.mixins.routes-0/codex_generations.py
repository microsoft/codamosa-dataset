

# Generated at 2022-06-18 05:41:54.873673
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnectionClosed


# Generated at 2022-06-18 05:42:06.957130
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.response import json
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouterException
    from sanic.router import RouterMatchInfo
    from sanic.router import RouterMatchNotFound
    from sanic.router import RouterMatchType
    from sanic.router import RouterMatchWebSocket
    from sanic.router import RouterMatchWebSocketDisconnect
    from sanic.router import RouterMatchWebSocketError
    from sanic.router import RouterMatchWebSocketTimeout
    from sanic.router import RouterMatchWebSocketUpgrade
    from sanic.router import RouterMatchWebSocketUpgradeError
    from sanic.router import RouterMatchWebSocketUpgrade

# Generated at 2022-06-18 05:42:13.086474
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Create a mock object of class RouteMixin
    mock_route_mixin = RouteMixin()

    # Create a mock object of class Route
    mock_route = Route()

    # Create a mock object of class Route
    mock_route_1 = Route()

    # Create a mock object of class Route
    mock_route_2 = Route()

    # Create a mock object of class Route
    mock_route_3 = Route()

    # Create a mock object of class Route
    mock_route_4 = Route()

    # Create a mock object of class Route
    mock_route_5 = Route()

    # Create a mock object of class Route
    mock_route_6 = Route()

    # Create a mock object of class Route
    mock_route_7 = Route()

    # Create a mock object of class Route
    mock_route_8

# Generated at 2022-06-18 05:42:24.044544
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import Route
    from sanic.router import Router
    from sanic.router import RouteExists
    from sanic.router import RouteReset


# Generated at 2022-06-18 05:42:26.597174
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Test for method static of class RouteMixin
    # TODO: to be implemented
    pass


# Generated at 2022-06-18 05:42:37.974749
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:42:44.972452
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router

    router = Router()
    router.route("/", methods=["GET"])(lambda x: x)
    router.route("/", methods=["POST"])(lambda x: x)
    router.route("/", methods=["PUT"])(lambda x: x)
    router.route("/", methods=["DELETE"])(lambda x: x)
    router.route("/", methods=["OPTIONS"])(lambda x: x)
    router

# Generated at 2022-06-18 05:42:55.215954
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.app import Sanic
    from sanic.router import RouteExists

    app = Sanic("test_RouteMixin_add_route")
    route = Route("/test", host=None, methods=["GET"], handler=text("test"))
    app.add_route(route)
    assert route in app.router.routes_all

    route = Route("/test", host=None, methods=["GET"], handler=text("test"))
    with pytest.raises(RouteExists):
        app.add_route(route)


# Generated at 2022-06-18 05:43:07.651827
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of HTTPMethodView
    http_method_view = HTTPMethodView()
    # Create a new instance of HTTPMethodView
    http_method_view2 = HTTPMethodView()
    # Create a new instance of HTTPMethodView
    http_method_view3 = HTTPMethodView()
    # Create a new instance of HTTPMethodView
    http_method_view4 = HTTPMethodView()
    # Create a new instance of HTTPMethodView
    http_method_view5 = HTTPM

# Generated at 2022-06-18 05:43:15.555731
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    app = Sanic('test_RouteMixin_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.routes

# Generated at 2022-06-18 05:43:39.473033
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake


# Generated at 2022-06-18 05:43:48.593448
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with a simple function
    def test_function():
        pass
    # Test with a class
    class TestClass:
        def __init__(self):
            pass
        def test_method(self):
            pass
    # Test with a class with a __call__ method
    class TestClass2:
        def __init__(self):
            pass
        def __call__(self):
            pass
    # Test with a class with a __call__ method
    class TestClass3:
        def __init__(self):
            pass
        def __call__(self):
            pass
    # Test with a class with a __call__ method
    class TestClass4:
        def __init__(self):
            pass
        def __call__(self):
            pass
    # Test with a class with a __call__ method

# Generated at 2022-06-18 05:43:59.464281
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ServerError
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout

# Generated at 2022-06-18 05:44:11.338425
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = None
            self.name = "test"

    test_route_mixin = TestRouteMixin()

    @test_route_mixin.route("/test")
    def test_route():
        return "test"

    assert isinstance(test_route_mixin.routes[0], Route)
    assert test_route_mixin.routes[0].uri == "/test"
    assert test_route_mixin.routes[0].name == "test.test_route"


# Generated at 2022-06-18 05:44:22.689855
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # successfully
    # Input:
    #   uri = '/'
    #   host = None
    #   methods = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   apply = True
    #   subprotocols = None
    #   websocket = False
    #   static = False
    #   stream = False
    #   expect = True
    # Output:
    #   assertEqual(result, expect)
    uri = '/'
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    subprotocols = None
    websocket = False
    static = False

# Generated at 2022-06-18 05:44:33.435579
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:41.719846
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed

# Generated at 2022-06-18 05:44:51.884011
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import StaticRoute
    from sanic.router import StaticRouteWarning
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouteWarning

# Generated at 2022-06-18 05:44:59.593597
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:05.269925
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:27.903072
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Route
    route1 = Route()
    # Create a mock object of class Route
    route2 = Route()
    # Create a mock object of class Route
    route3 = Route()
    # Create a mock object of class Route
    route4 = Route()
    # Create a mock object of class Route
    route5 = Route()
    # Create a mock object of class Route
    route6 = Route()
    # Create a mock object of class Route
    route7 = Route()
    # Create a mock object of class Route
    route8 = Route()
    # Create a mock object of class Route
    route9 = Route()
    # Create a mock object of

# Generated at 2022-06-18 05:45:38.505482
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidHeader
    from sanic.exceptions import UnsupportedVersion


# Generated at 2022-06-18 05:45:45.700642
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We create a mock object for class RouteMixin
    route_mixin_mock = RouteMixin()
    # We create a mock object for class Route
    route_mock = Route()
    # We mock the method add_route of class RouteMixin
    route_mixin_mock.add_route = MagicMock(return_value=route_mock)
    # We call the method add_route of class RouteMixin
    route_mixin_mock.add_route("/", "GET")
    # We check that the method add_route of class RouteMixin has been called
    assert route_mixin_mock.add_route.called
    # We check that the method add_route of class RouteMixin has been called with the right parameters
    route_mix

# Generated at 2022-06-18 05:45:53.263722
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    test_route = RouteMixin(app)
    test_route.add_route('/', 'GET', 'test_RouteMixin_add_route')
    assert test_route.routes[0].uri == '/'
    assert test_route.routes[0].methods == ['GET']
    assert test_route.routes[0].name == 'test_RouteMixin_add_route'


# Generated at 2022-06-18 05:46:04.310618
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_RouteMixin = Mock(spec=RouteMixin)
    # Define return value of method add_route of class RouteMixin
    mock_RouteMixin.add_route.return_value = None
    # Call method add_route of class RouteMixin
    RouteMixin.add_route(mock_RouteMixin, 'uri', 'handler', 'methods', 'host', 'strict_slashes', 'version', 'name', 'apply', 'stream', 'static')
    # Now, we verify that method add_route of class RouteMixin has been called
    mock_RouteMixin.add_route.assert_called()


# Generated at 2022-06-18 05:46:15.992258
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Initialize the class
    app = Sanic(__name__)
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin
    # Test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:23.981893
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    app = Sanic("test_RouteMixin_add_route")
    @app.route("/")
    async def handler(request):
        return text("OK")
    assert len(app.router.routes_all) == 1
    route = app.router.routes_all[0]
    assert isinstance(route, Route)
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.name == "handler"
    assert route.host == None
    assert route.strict_slashes == None
    assert route.stream is False
    assert route.websocket is False
    assert route.static is False
    assert route.version is None

# Generated at 2022-06-18 05:46:32.890556
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default values
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda r: HTTPResponse(), '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].websocket == False
    assert app.router.routes_

# Generated at 2022-06-18 05:46:42.317640
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   handler = 'test'
    #   methods = ['GET']
    #   host = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   apply = True
    #   stream = False
    #   websocket = False
    #   static = False
    #   expect = None
    # Output:
    #   routes = [<sanic.router.Route object at 0x7f9b8b8c6c50>]
    uri = '/'
    handler = 'test'
    methods = ['GET']
    host = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    stream = False

# Generated at 2022-06-18 05:46:50.996570
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Create a new instance of class RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of class Route
    route = Route()
    # Assign function route to variable routes
    routes = route_mixin.route(uri="", methods=None, strict_slashes=None, version=None, name=None, apply=True, websocket=False)
    # Assert that routes is an instance of class Route
    assert isinstance(routes, Route)


# Generated at 2022-06-18 05:47:29.918499
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    import pytest
    import asyncio
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosedError

# Generated at 2022-06-18 05:47:40.783970
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import SanicRoute
    from sanic.router import SanicRouteError
    from sanic.router import SanicRouteWarning
    from sanic.router import UrlForError
    from sanic.router import UrlForWarning

# Generated at 2022-06-18 05:47:52.699558
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Test for method static of class RouteMixin
    # We create a RouteMixin object
    route_mixin = RouteMixin()
    # We create a FutureStatic object
    future_static = FutureStatic(
        uri='/',
        file_or_directory='/',
        pattern=r"/?.+",
        use_modified_since=True,
        use_content_range=False,
        stream_large_files=False,
        name="static",
        host=None,
        strict_slashes=None,
        content_type=None,
    )
    # We add the FutureStatic object to the list of future statics
    route_mixin._future_statics.add(future_static)
    # We call the method _apply_static
    route_mixin._apply_static(future_static)

# Generated at 2022-06-18 05:48:01.064961
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:48:12.097977
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   handler = None
    #   methods = ['GET']
    #   host = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   stream = False
    #   apply = True
    #   websocket = False
    #   expect = None
    # Output:
    #   return_value = None
    uri = '/'
    handler = None
    methods = ['GET']
    host = None
    strict_slashes = None
    version = None
    name = None
    stream = False
    apply = True
    websocket = False
    return_value = None

# Generated at 2022-06-18 05:48:23.787632
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived

# Generated at 2022-06-18 05:48:34.330514
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.response import StreamingHTTPResponse
    from sanic.utils import guess_type, DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import ContentRangeError
    from sanic.response import ContentRangeHandler
    from sanic.response import file, file_stream
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
    from sanic.router import Route
   

# Generated at 2022-06-18 05:48:44.076478
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:48:50.389412
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _Route
    from sanic.router import _VersionedRoute
    from sanic.router import _VersionedRouteExists
    from sanic.router import _VersionedRouteReset
   

# Generated at 2022-06-18 05:48:56.416777
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:49:50.479495
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Route

# Generated at 2022-06-18 05:50:02.992673
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default values
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test')
    assert app.router.routes_all['test'][0].uri == '/test'
    assert app.router.routes_all['test'][0].methods == ['GET']
    assert app.router.routes_all['test'][0].host == None
    assert app.router.routes_all['test'][0].strict_slashes == None
    assert app.router.routes_all['test'][0].version == None
    assert app.router.routes_all['test'][0].name == 'test'
    assert app.router.routes_all['test'][0].static

# Generated at 2022-06-18 05:50:13.436692
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound


# Generated at 2022-06-18 05:50:21.349308
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketPayloadTooBig
    from sanic.websocket import WebSocketConnectionClosed

# Generated at 2022-06-18 05:50:33.075743
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = "/test"
    #   handler = "test"
    #   methods = ["GET"]
    #   host = "127.0.0.1"
    #   strict_slashes = True
    #   version = 1
    #   name = "test"
    #   apply = True
    #   websocket = False
    #   stream = False
    #   expect = [Route(uri='/test', methods=['GET'], host='127.0.0.1', strict_slashes=True, version=1, name='test', handler='test', websocket=False, stream=False)]
    uri = "/test"
    handler = "test"
    methods = ["GET"]
    host = "127.0.0.1"
    strict_sl

# Generated at 2022-06-18 05:50:42.480616
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Request
    request = Request(b'GET', '/', [], b'', '1.1', '1.1')
    # Create a new instance of HTTPResponse
    http_response = HTTPResponse(body=b'', status=200)
    # Create a new instance of Route
    route = Route(uri='/', methods=['GET'], handler=http_response, name='test')
    # Create a new instance of Sanic
    sanic = Sanic(__name__)
    # Create a new instance of Router
    router = Router(sanic)
    # Create a new instance of Route

# Generated at 2022-06-18 05:50:53.661223
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # create a new instance of Route
    route = Route()
    # create a new instance of Sanic
    sanic = Sanic()
    # create a new instance of Request
    request = Request()
    # create a new instance of HTTPResponse
    http_response = HTTPResponse()
    # create a new instance of Response
    response = Response()
    # create a new instance of StreamResponse
    stream_response = StreamResponse()
    # create a new instance of WebSocketProtocol
    web_socket_protocol = WebSocketProtocol()
    # create a new instance of WebSocketCommonProtocol
    web_socket_common_protocol = WebSocketCommonProtocol()
    # create a new instance of WebSocket
    web_socket

# Generated at 2022-06-18 05:51:04.685625
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuild

# Generated at 2022-06-18 05:51:15.479525
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.response import HTTPResponse, StreamingHTTPResponse
    from sanic.router import Route
    from sanic.utils import sanic_endpoint_test
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.static import add_static
    from sanic.constants import HTTP_METHODS
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.constants import CONTENT_RANGE_HEADER
    from sanic.constants import CONTENT_RANGE

# Generated at 2022-06-18 05:51:25.848903
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset