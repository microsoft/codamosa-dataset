

# Generated at 2022-06-18 05:42:14.226367
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableDefined
    from sanic.router import RouteTableUndefined
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import add_route
    from sanic.router import get_route
    from sanic.router import has_static
    from sanic.router import has_websocket
    from sanic.router import is_dynamic
    from sanic.router import is_static

# Generated at 2022-06-18 05:42:17.204939
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-18 05:42:26.552471
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:42:37.933032
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default value
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test_RouteMixin_add_route', methods=['GET'])
    assert app.router.routes_all['GET'][0].uri == '/test_RouteMixin_add_route'
    assert app.router.routes_all['GET'][0].name == 'test_RouteMixin_add_route'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None

# Generated at 2022-06-18 05:42:44.942404
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotEx

# Generated at 2022-06-18 05:42:55.179050
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:43:07.611977
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:43:12.009508
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    class MyView2(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")


# Generated at 2022-06-18 05:43:18.706565
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:43:25.030557
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocketEventType
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:43:48.593600
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    app = Sanic("test_RouteMixin_add_route")
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.WEBSOCKET_MAX_SIZE = 2 ** 20
    app.config.WEBSOCKET_MAX_QUEUE = 32
    app.config.WEBSOCKET_READ_LIMIT = 2 ** 16
    app.config.WEBSOCKET_WRITE_LIMIT = 2 ** 16
    app.config.REQUEST_MAX_SIZE = 2 ** 20
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST

# Generated at 2022-06-18 05:43:53.930286
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:44:05.572251
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 30
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.WEBSOCKET_MAX_SIZE = 2 ** 20
    app.config.WEBSOCKET_MAX_QUEUE = 32
    app.config.WEBSOCKET_READ_LIMIT = 2 ** 16
    app.config.WEBSOCKET_WRITE_LIMIT = 2 ** 16
    app.config.REQUEST_MAX_SIZE = 2 ** 20
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60


# Generated at 2022-06-18 05:44:15.255751
# Unit test for method static of class RouteMixin

# Generated at 2022-06-18 05:44:22.873355
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_RouteMixin = MagicMock(spec=RouteMixin)
    # Define return value of method add_route.
    mock_RouteMixin.add_route.return_value = "add_route"
    # Assert return value.
    assert mock_RouteMixin.add_route() == "add_route"


# Generated at 2022-06-18 05:44:27.035317
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text

    app = Sanic("test_RouteMixin_add_route")
    app.add_route(text("hello"), "/")
    assert len(app.router.routes_all) == 1
    assert isinstance(app.router.routes_all[0], Route)
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].methods == ["GET"]
    assert app.router.routes_all[0].handler == text("hello")
    assert app.router.routes_all[0].name is None
    assert app.router.routes_all[0].host is None


# Generated at 2022-06-18 05:44:37.294822
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default value
    app = Sanic(__name__)
    app.add_route(lambda x: x, uri='/')
    assert len(app.router.routes_all) == 1
    # Test with custom value
    app = Sanic(__name__)
    app.add_route(lambda x: x, uri='/', methods=['GET'])
    assert len(app.router.routes_all) == 1
    # Test with custom value
    app = Sanic(__name__)
    app.add_route(lambda x: x, uri='/', methods=['GET'], host='127.0.0.1')
    assert len(app.router.routes_all) == 1
    # Test with custom value

# Generated at 2022-06-18 05:44:44.202429
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:54.683534
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].version == None
    assert app.router.routes_all[0].static == False
    assert app.router.routes_all[0].we

# Generated at 2022-06-18 05:45:00.462328
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # We create a mock object for class RouteMixin
    mock_RouteMixin = Mock(spec=RouteMixin)
    # We create a mock object for class Route
    mock_Route = Mock(spec=Route)
    # We set the attribute route of mock_RouteMixin as mock_Route
    mock_RouteMixin.route = mock_Route
    # We set the attribute routes of mock_RouteMixin as []
    mock_RouteMixin.routes = []
    # We set the attribute _future_routes of mock_RouteMixin as set()
    mock_RouteMixin._future_routes = set()
    # We set the attribute _future_statics of mock_RouteMixin as set()
    mock_RouteMixin._future_statics = set()
   

# Generated at 2022-06-18 05:45:28.175368
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert app.router.routes_all['GET'][0].uri == '/'
    assert app.router.routes_all['GET'][0].name == 'handler'
    assert app.router.routes_all['GET'][0].handler == handler
    assert app.router.routes_all['GET'][0].strict_slashes == True
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].version == None

# Generated at 2022-06-18 05:45:38.777938
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:45.875067
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for add_route method of class RouteMixin
    # Arrange
    app = Sanic('test_RouteMixin_add_route')
    app.config.REQUEST_MAX_SIZE = 10
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_MAX_MEMORY_SIZE = 0
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 15
    app.config.ERROR_HANDLER = None
    app.config.REQUEST_HANDLER = None
    app.config.RESPONSE_HANDLER = None
    app.config.WEBSOCKET_MAX_SIZE

# Generated at 2022-06-18 05:45:50.903143
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    class MyRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.name = "test"

        def add_route(self, uri, handler, *args, **kwargs):
            self.routes.append(Route(uri, handler, *args, **kwargs))

    route_mixin = MyRouteMixin()
    route_mixin.add_route("/", MyView.as_view())
    assert len(route_mixin.routes) == 1
   

# Generated at 2022-06-18 05:45:58.784340
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:46:05.821718
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Create a mock sanic app
    app = Sanic('test_RouteMixin_route')
    # Create a mock request context
    request_context = RouteMixin()
    # Assert that the mock sanic app is a sanic app
    assert isinstance(app, Sanic)
    # Assert that the mock request context is a RouteMixin
    assert isinstance(request_context, RouteMixin)
    # Assert that the mock sanic app has a router
    assert hasattr(app, 'router')
    # Assert that the mock sanic app has a router that is a Router
    assert isinstance(app.router, Router)
    # Create a mock uri
    uri = '/test_RouteMixin_route'
    # Create a mock handler
    handler = app.get(uri)
    # Assert that

# Generated at 2022-06-18 05:46:18.340662
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Router
    from sanic.router import Route
    from sanic.router import RouteReset
    from sanic.router import RouteTableDef
    from sanic.router import RouteTableDef
    from sanic.router import RouteTableDef
    from sanic.router import RouteTableDef
    from sanic.router import RouteTableDef

# Generated at 2022-06-18 05:46:29.561201
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:46:40.305094
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionWarning
    from sanic.router import add_route
    from sanic.router import add_static
    from sanic.router import add_websocket
    from sanic.router import compile_route
    from sanic.router import compile_static
    from sanic.router import compile_webs

# Generated at 2022-06-18 05:46:50.711234
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test_RouteMixin_add_route/<param>', methods=['GET'])
    assert app.router.routes_names['test_RouteMixin_add_route.test_RouteMixin_add_route'] == '/test_RouteMixin_add_route/<param>'
    assert app.router.routes[0].uri == '/test_RouteMixin_add_route/<param>'
    assert app.router.routes[0].methods == ['GET']
    assert app.router.routes[0].handler == app.router.routes[0]._handler

# Generated at 2022-06-18 05:47:18.228309
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:47:29.358139
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:47:40.755560
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object for the class Sanic
    mock_sanic = MagicMock()
    # Create a mock object for the class Route
    mock_route = MagicMock()
    # Create a mock object for the class Route
    mock_route2 = MagicMock()
    # Create a mock object for the class Route
    mock_route3 = MagicMock()
    # Create a mock object for the class Route
    mock_route4 = MagicMock()
    # Create a mock object for the class Route
    mock_route5 = MagicMock()
    # Create a mock object for the class Route
    mock_route6 = MagicMock()
    # Create a mock object for the class Route
    mock_route7 = MagicMock()
    # Create a mock object for the class Route
    mock_route8 = MagicMock()
   

# Generated at 2022-06-18 05:47:46.751959
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import _get_version_info
    from sanic.router import _is_version_included
    from sanic.router import _is_version_included_in_list
    from sanic.router import _is_version_included_in_tuple
    from sanic.router import _is_version_included_in_version_info
    from sanic.router import _is_version_

# Generated at 2022-06-18 05:47:57.672807
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    mock_RouteMixin = RouteMixin()
    # Create a mock object of class Route
    mock_Route = Route()
    # Create a mock object of class Route
    mock_Route_1 = Route()
    # Create a mock object of class Route
    mock_Route_2 = Route()
    # Create a mock object of class Route
    mock_Route_3 = Route()
    # Create a mock object of class Route
    mock_Route_4 = Route()
    # Create a mock object of class Route
    mock_Route_5 = Route()
    # Create a mock object of class Route
    mock_Route_6 = Route()
    # Create a mock object of class Route
    mock_Route_7 = Route()
    # Create a mock object of class Route

# Generated at 2022-06-18 05:48:09.488433
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We create a mock object for the class Sanic
    mock_sanic = MagicMock()
    # We create a mock object for the class Route
    mock_route = MagicMock()
    # We create a mock object for the class Route
    mock_route2 = MagicMock()
    # We create a mock object for the class Route
    mock_route3 = MagicMock()
    # We create a mock object for the class Route
    mock_route4 = MagicMock()
    # We create a mock object for the class Route
    mock_route5 = MagicMock()
    # We create a mock object for the class Route
    mock_route6 = MagicMock()
    # We create a mock object for the class Route
    mock_route7 = MagicMock()
   

# Generated at 2022-06-18 05:48:19.327380
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import InvalidHeader
    from sanic.exceptions import InvalidContentType

# Generated at 2022-06-18 05:48:21.629236
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: Implement unit test for method route of class RouteMixin
    pass


# Generated at 2022-06-18 05:48:32.550878
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    app = Sanic("test_RouteMixin_add_route")
    app.add_route(text("hello"), "/")
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].handler == text
    assert app.router.routes_all[0].methods == ["GET"]
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.routes_all[0].name == None


# Generated at 2022-06-18 05:48:40.636157
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 05:49:07.980971
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import ServerError
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import Request

# Generated at 2022-06-18 05:49:18.144395
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:27.534706
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = None
            self.name = "test"
            self.host = None
            self.websocket_max_size = None
            self.websocket_max_queue = None
            self.websocket_read_limit = None
            self.websocket_write_limit = None
            self.websocket_ping_timeout = None
            self.websocket_ping_interval = None
            self.websocket_max_http_size = None
            self.websocket_compression = None
            self.websocket_compression_options = None
            self.websocket_subprotocols = None
            self.websocket_max

# Generated at 2022-06-18 05:49:32.648854
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic('test_RouteMixin_route')
    route_mixin = RouteMixin(app)
    @route_mixin.route('/test_RouteMixin_route', methods=['GET'])
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/test_RouteMixin_route')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:49:44.172463
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin
    # and test the method route
    app = Sanic('test_RouteMixin_route')
    # Create a request context for the request
    request_context = app.request_context()
    request_context.push()

# Generated at 2022-06-18 05:49:52.682772
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol
    app = Sanic("test_RouteMixin_add_route")
    route = Route("/test", host=None, methods=None, handler=text("test"),
                  strict_slashes=None, version=None, name=None,
                  websocket=False, stream=False, static=False,
                  expect_handler=None,
                  )
    request = Request("GET", "/test",
                      headers={"host": "127.0.0.1:8000"},
                      version="1.1",
                      )
    app.add_route(route, request)

# Generated at 2022-06-18 05:50:04.315572
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionInfoError
    from sanic.router import VersionInfoWarning
    from sanic.router import VersionNotFound
    from sanic.router import VersionNotFoundError
    from sanic.router import VersionNotFoundWarning

# Generated at 2022-06-18 05:50:14.474519
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:50:22.164057
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import StaticRoute
    from sanic.router import StaticRouteWarning
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouteWarning
    from sanic.router import VersionedRouter


# Generated at 2022-06-18 05:50:28.008524
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeHandler
    from sanic.exceptions import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import guess_type
    from sanic.exceptions import file
    from sanic.exceptions import file_stream
    from sanic.exceptions import stat_async
    from sanic.exceptions import FutureStatic
    from sanic.exceptions import wraps
    from sanic.exceptions import partial
    from sanic.exceptions import path
    from sanic.exceptions import sub
   

# Generated at 2022-06-18 05:51:08.437945
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class Test(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = None
            self.name = "test"
    test = Test()
    test.add_route(None, "/", None, None, None, None, None, None, None, None)
    assert test.routes == []


# Generated at 2022-06-18 05:51:19.811226
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   host = None
    #   methods = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   apply = True
    #   websocket = False
    #   static = False
    #   stream = False
    #   expect = None
    # Output:
    #   routes = <sanic.router.Route object at 0x7f9b8c0c4e48>
    #   decorated_function = <function RouteMixin.route.<locals>.decorator at 0x7f9b8c0c4ea0>
    uri = '/'
    host = None
    methods = None
    strict_slashes = None
    version = None

# Generated at 2022-06-18 05:51:28.525903
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new RouteMixin object
    route_mixin = RouteMixin()
    # Create a new Sanic object
    app = Sanic()
    # Create a new Route object
    route = Route()
    # Create a new Route object
    route2 = Route()
    # Create a new Route object
    route3 = Route()
    # Create a new Route object
    route4 = Route()
    # Create a new Route object
    route5 = Route()
    # Create a new Route object
    route6 = Route()
    # Create a new Route object
    route7 = Route()
    # Create a new Route object
    route8 = Route()
    # Create a new Route object
    route9 = Route()
    # Create a new Route object
    route10 = Route()
    # Create a new Route object
    route11 = Route