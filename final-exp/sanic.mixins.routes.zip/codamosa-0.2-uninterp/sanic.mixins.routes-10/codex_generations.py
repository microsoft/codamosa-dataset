

# Generated at 2022-06-18 05:42:01.215259
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:42:12.723090
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Sanic
    sanic = Sanic()
    # Create a mock object of class Sanic
    sanic_1 = Sanic()
    # Create a mock object of class Sanic
    sanic_2 = Sanic()
    # Create a mock object of class Sanic
    sanic_3 = Sanic()
    # Create a mock object of class Sanic
    sanic_4 = Sanic()
    # Create a mock object of class Sanic
    sanic_5 = Sanic()
    # Create a mock object of class Sanic
    sanic_6 = Sanic()
    # Create a mock object of class Sanic
    sanic_

# Generated at 2022-06-18 05:42:18.974547
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import URLBuildError
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import HTTPException
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNot

# Generated at 2022-06-18 05:42:27.613216
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Sanic
    sanic = Sanic()
    # Create a mock object of class Route
    route_1 = Route()
    # Create a mock object of class Route
    route_2 = Route()
    # Create a mock object of class Route
    route_3 = Route()
    # Create a mock object of class Route
    route_4 = Route()
    # Create a mock object of class Route
    route_5 = Route()
    # Create a mock object of class Route
    route_6 = Route()
    # Create a mock object of class Route
    route_7 = Route()
    # Create a mock object of class Route

# Generated at 2022-06-18 05:42:38.469362
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of class RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of class Route
    route = Route()
    # Create a new instance of class Sanic
    sanic = Sanic()
    # Create a new instance of class Request
    request = Request()
    # Create a new instance of class HTTPResponse
    http_response = HTTPResponse()
    # Create a new instance of class HTTPResponse
    http_response_1 = HTTPResponse()
    # Create a new instance of class HTTPResponse
    http_response_2 = HTTPResponse()
    # Create a new instance of class HTTPResponse
    http_response_3 = HTTPResponse()
    # Create a new instance of class HTTPResponse
   

# Generated at 2022-06-18 05:42:45.531723
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   methods = ['GET']
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   apply = True
    #   static = False
    #   websocket = False
    #   host = None
    #   Expect:
    #   routes = [<sanic.router.Route object at 0x7f8a9a9a6b38>]
    #   decorated_function = <function RouteMixin_route.<locals>.decorator at 0x7f8a9a9a6bf8>
    @RouteMixin.route('/', methods=['GET'])
    def RouteMixin_route():
        pass
    # Test case 2
    # Input:
    #  

# Generated at 2022-06-18 05:42:56.363809
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of class RouteMixin
    route_mixin = RouteMixin()

    # Create a new instance of class Route
    route = Route()

    # Create a new instance of class Sanic
    sanic = Sanic()

    # Create a new instance of class Request
    request = Request()

    # Create a new instance of class HTTPResponse
    http_response = HTTPResponse()

    # Create a new instance of class WebSocketProtocol
    web_socket_protocol = WebSocketProtocol()

    # Create a new instance of class FutureStatic
    future_static = FutureStatic()

    # Create a new instance of class ContentRangeHandler
    content_range_handler = ContentRangeHandler()

    # Create a new instance of class HeaderNotFound
    header_not_found = HeaderNotFound()

    # Create a

# Generated at 2022-06-18 05:43:07.991573
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketPayloadTooBig
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketHandshakeError
    from sanic.websocket import WebSocketReader

# Generated at 2022-06-18 05:43:15.769071
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:43:21.666582
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for route with default values
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test')
    assert app.router.routes_names['test'] == '/test'
    assert app.router.routes[0].uri == '/test'
    assert app.router.routes[0].name == 'test'
    assert app.router.routes[0].host == None
    assert app.router.routes[0].strict_slashes == None
    assert app.router.routes[0].methods == ['GET']
    assert app.router.routes[0].version == None
    assert app.router.routes[0].stream == False
    assert app.router.routes

# Generated at 2022-06-18 05:43:43.419881
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 05:43:51.252449
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.views import CompositionView

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []

        def add_route(self, uri, handler, methods=None, host=None,
                      strict_slashes=None, version=None, name=None,
                      stream=False, websocket=False, static=False):
            self.routes.append(Route(uri, handler, methods, host,
                                     strict_slashes, version, name,
                                     stream, websocket, static))

    test_route_mixin = TestRouteMixin()
    test_route_mixin.add_route("/", CompositionView())
    assert len(test_route_mixin.routes) == 1
   

# Generated at 2022-06-18 05:44:01.473937
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Given
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = None
            self.name = "test"

    # When
    route_mixin = TestRouteMixin()
    route_mixin.add_route(
        uri="/",
        methods=["GET"],
        host="testhost",
        strict_slashes=True,
        version=1,
        name="testname",
    )

    # Then
    assert len(route_mixin.routes) == 1
    assert route_mixin.routes[0].uri == "/"
    assert route_mixin.routes[0].methods == ["GET"]
   

# Generated at 2022-06-18 05:44:13.204584
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import ServiceUnavailable
    from sanic.exceptions import QuotaExceeded
    from sanic.exceptions import Invalid

# Generated at 2022-06-18 05:44:14.165064
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # TODO: implement
    pass


# Generated at 2022-06-18 05:44:26.201819
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with valid input
    app = Sanic("test_sanic")
    app.add_route(lambda x: x, uri="/test/", methods=["GET"])
    assert app.router.routes_names["test_sanic.test"] == "/test/"
    assert app.router.routes["GET"][0].uri == "/test/"
    assert app.router.routes["GET"][0].name == "test_sanic.test"
    assert app.router.routes["GET"][0].strict_slashes == False
    assert app.router.routes["GET"][0].host == None
    assert app.router.routes["GET"][0].version == None
    assert app.router.routes["GET"][0].static

# Generated at 2022-06-18 05:44:36.710289
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:44:43.858515
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:54.350735
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:45:00.095948
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
   

# Generated at 2022-06-18 05:45:56.138530
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionCl

# Generated at 2022-06-18 05:46:06.450029
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:46:18.656771
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:29.861104
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ServerError
    from sanic.exceptions import Invalid

# Generated at 2022-06-18 05:46:32.605534
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    app.add_route(lambda r: "OK", "/", methods=["GET"])
    request, response = app.test_client.get("/")
    assert response.text == "OK"


# Generated at 2022-06-18 05:46:42.074471
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default arguments
    app = Sanic(__name__)
    app.add_route(lambda x: x, '/')
    assert app.router.routes_all['GET'][0].uri == '/'

# Generated at 2022-06-18 05:46:53.590528
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class Sanic
    app = Sanic('test_app')
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route('test_route')
    # Create a mock object of class Handler
    handler = Handler()
    # Create a mock object of class Request
    request = Request('test_request')
    # Create a mock object of class HTTPResponse
    response = HTTPResponse()
    # Create a mock object of class Route
    route_1 = Route('test_route_1')
    # Create a mock object of class Route
    route_2 = Route('test_route_2')
    # Create a mock object of class Route
    route_3 = Route('test_route_3')
    #

# Generated at 2022-06-18 05:47:00.272010
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBuffer
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import HTTPException
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound

# Generated at 2022-06-18 05:47:08.317508
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_route_name_from_handler
    from sanic.router import _get_route_name_from_uri

# Generated at 2022-06-18 05:47:19.540006
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:47:56.501083
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:48:08.033785
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:48:16.579538
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.response import StreamingHTTPResponse
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import ContentRangeHandler
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import file

# Generated at 2022-06-18 05:48:26.711261
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock Sanic app
    app = Sanic("test_RouteMixin_add_route")
    # Create a mock request
    request = Request.fake_request()
    # Create a mock handler
    handler = lambda request: "OK"
    # Create a mock route
    route = Route("/", "GET", handler, host=None, strict_slashes=None, version=None, name=None)
    # Create a mock router
    router = Router()
    # Create a mock RouteMixin
    route_mixin = RouteMixin()
    # Add the mock route to the mock router
    route_mixin.add_route(route, router)
    # Check if the route is added to the router
    assert router.routes[0] == route


# Generated at 2022-06-18 05:48:36.725045
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:48:46.044283
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset


# Generated at 2022-06-18 05:48:47.077431
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: write unit test
    pass


# Generated at 2022-06-18 05:48:53.121634
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExistsError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError

# Generated at 2022-06-18 05:48:58.933177
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import InvalidRangeType
    from sanic.exceptions import InvalidRangeValue
    from sanic.exceptions import InvalidRangeFormat

# Generated at 2022-06-18 05:49:10.035739
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:43.448838
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:52.165729
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:50:03.792299
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import StaticRouteExists
    from sanic.router import StaticRouteReset
    from sanic.router import StaticRouteResetError

# Generated at 2022-06-18 05:50:13.958253
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    app = Sanic(__name__)
    app.add_route(app.async_handler(lambda request: "OK"), '/')
    assert app.router.routes_names['/'][0].uri == '/'
    assert app.router.routes_names['/'][0].name == '<lambda>'
    assert app.router.routes_names['/'][0].methods == ['GET']
    assert app.router.routes_names['/'][0].host == None
    assert app.router.routes_names['/'][0].strict_slashes == None
    assert app.router.routes_names['/'][0].version == None

# Generated at 2022-06-18 05:50:24.542850
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage

    class TestHTTPMethodView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(b"OK")

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = False
            self.name = "test"


# Generated at 2022-06-18 05:50:35.891775
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import CompositionView

    app = Sanic("test_RouteMixin_add_route")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.route("/", methods=["POST"])
    async def handler2(request):
        return text("OK")

    @app.route("/", methods=["POST", "GET"])
    async def handler3(request):
        return text("OK")

    @app.route("/", methods=["POST", "GET", "PUT"])
    async def handler4(request):
        return text("OK")


# Generated at 2022-06-18 05:50:43.931848
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import Route

# Generated at 2022-06-18 05:50:56.064890
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.app import Sanic
    app = Sanic('test_RouteMixin_route')
    # Test with default parameters
    route = app.route('/test')(lambda r: r)
    assert route.uri == '/test'
    assert route.methods == ['GET']
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.name == None
    assert route.static == False
    assert route.websocket == False
    assert route.stream == False
    assert route.apply == True
    assert route.subprotocols == None
    # Test with all parameters

# Generated at 2022-06-18 05:51:05.582779
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import ServiceUnavailable
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import InvalidHeader
    from sanic.exceptions import InvalidContentType


# Generated at 2022-06-18 05:51:06.811068
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: write unit test
    pass
