

# Generated at 2022-06-18 05:42:10.995629
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default parameters
    # Define a empty class
    class Test:
        pass
    # Create an object of Test
    test = Test()
    # Create a RouteMixin object
    route_mixin = RouteMixin()
    # Create a mock object of Sanic
    sanic = MagicMock()
    # Set the attribute app of route_mixin
    route_mixin.app = sanic
    # Set the attribute router of route_mixin
    route_mixin.router = Router()
    # Set the attribute name of route_mixin
    route_mixin.name = 'test'
    # Set the attribute strict_slashes of route_mixin
    route_mixin.strict_slashes = False
    # Set the attribute version of route_mixin
    route_mixin.version = 1
   

# Generated at 2022-06-18 05:42:22.410332
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test with default value
    app = Sanic('test_RouteMixin_route')
    @app.route('/')
    async def handler(request):
        return text('OK')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.routes

# Generated at 2022-06-18 05:42:29.205833
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:42:39.422668
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:42:50.199021
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import CompositionView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:43:02.635132
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteRes

# Generated at 2022-06-18 05:43:11.786585
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketCommonError
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:43:15.739110
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Arrange
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Act
    # Call method add_route of class RouteMixin
    route_mixin.add_route(handler=None, uri=None, host=None, strict_slashes=None, version=None, name=None)
    # Assert
    # No assertion.

# Generated at 2022-06-18 05:43:21.638769
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView

    app = Sanic("test_RouteMixin_add_route")

    class SimpleView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    @app.route("/")
    async def handler(request):
        return json({"hello": "world"})

    # Test add_route with handler
    route = app.add_route(handler, uri="/", methods=["GET"])
    assert isinstance(route, Route)
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.handler == handler

    # Test add_route with view


# Generated at 2022-06-18 05:43:31.153508
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import PayloadExpected
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import HTTPVersionNotSupported
    from sanic.exceptions import VariantAlsoNegotiates

# Generated at 2022-06-18 05:43:48.697887
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Route
    route = Route()
    # Assign the return value of method add_route of class RouteMixin to variable routes
    routes = route_mixin.add_route(route)
    # Assert that routes is equal to [route]
    assert routes == [route]


# Generated at 2022-06-18 05:43:59.508132
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:11.384388
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/test'
    #   handler = 'test'
    #   methods = ['GET']
    #   host = '127.0.0.1'
    #   strict_slashes = False
    #   version = 1
    #   name = 'test'
    #   apply = True
    #   stream = False
    #   websocket = False
    #   static = False
    #   expect = None
    # Output:
    #   routes = None
    #   decorated_function = None
    uri = '/test'
    handler = 'test'
    methods = ['GET']
    host = '127.0.0.1'
    strict_slashes = False
    version = 1
    name = 'test'
    apply = True
    stream

# Generated at 2022-06-18 05:44:22.737153
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:33.482281
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:44:37.779937
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = "/test"
    #   handler = None
    #   host = None
    #   methods = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   apply = True
    #   stream = False
    #   websocket = False
    #   subprotocols = None
    #   expect = None
    # Output:
    #   routes = None
    #   decorated_function = None
    uri = "/test"
    handler = None
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    stream = False
    websocket = False
    subprotocols = None
    expect = None
    routes,

# Generated at 2022-06-18 05:44:44.395612
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:44:54.720875
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_RouteMixin_add_route')
    # Test 1:
    # Test with a function as handler
    @app.route('/')
    async def handler(request):
        return text('OK')
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].host == None

# Generated at 2022-06-18 05:45:00.567619
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default parameters
    router = RouteMixin()

# Generated at 2022-06-18 05:45:07.620200
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:45:55.040203
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case data
    uri = '/'
    handler = 'handler'
    methods = ['GET']
    host = '127.0.0.1'
    strict_slashes = True
    version = 1
    name = 'name'
    apply = True
    # Perform the test
    result = RouteMixin.add_route(uri, handler, methods, host, strict_slashes, version, name, apply)
    # Verify the results
    assert True # TODO: implement your test here


# Generated at 2022-06-18 05:46:05.669418
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # Arrange
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import VersionedRouterWarning
    from sanic.router import VersionedRouter

# Generated at 2022-06-18 05:46:18.087602
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Request
    request = Request()
    # Create a mock object of class HTTPResponse
    http_response = HTTPResponse()
    # Create a mock object of class Sanic
    sanic = Sanic()
    # Create a mock object of class Sanic
    sanic_1 = Sanic()
    # Create a mock object of class Sanic
    sanic_2 = Sanic()
    # Create a mock object of class Sanic
    sanic_3 = Sanic()
    # Create a mock object of class Sanic
    sanic_4 = Sanic()
    # Create a mock object of class Sanic
    sanic_

# Generated at 2022-06-18 05:46:19.256763
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: implement test
    pass


# Generated at 2022-06-18 05:46:26.123926
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeHandler
    from sanic.exceptions import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import guess_type
    from sanic.exceptions import FutureStatic
    from sanic.exceptions import HTTPResponse
    from sanic.exceptions import StreamingHTTPResponse
    from sanic.exceptions import file
    from sanic.exceptions import file_stream
    from sanic.exceptions import stat_async

# Generated at 2022-06-18 05:46:33.803937
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeHandler
    from sanic.exceptions import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import guess_type
    from sanic.exceptions import stat_async
    from sanic.exceptions import file
    from sanic.exceptions import file_stream
    from sanic.exceptions import error_logger
    from sanic.exceptions import FutureStatic
    from sanic.exceptions import sub
   

# Generated at 2022-06-18 05:46:36.212298
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement test
    pass


# Generated at 2022-06-18 05:46:43.890178
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionClosedPolicyViolation
    from sanic.websocket import WebSocketConnectionClosedTooLarge

# Generated at 2022-06-18 05:46:54.795029
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import ConnectionClosed

# Generated at 2022-06-18 05:47:02.631295
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    def handler(request):
        return text('OK')
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].methods == {'GET'}
    assert app.router.routes_all[0].strict_slashes == True
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].version == None

# Generated at 2022-06-18 05:47:32.597837
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    app.config.REQUEST_MAX_SIZE = 100
    app.config.REQUEST_TIMEOUT = 10
    app.config.RESPONSE_TIMEOUT = 15
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 15
    app.config.ERROR_HANDLER = app.error_handler
    app.config.WEBSOCKET_MAX_SIZE = 2 ** 20
    app.config.WEBSOCKET_MAX

# Generated at 2022-06-18 05:47:35.961631
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # Arrange
    # Act
    # Assert
    assert True == True

# Generated at 2022-06-18 05:47:43.854346
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.response import HTTPResponse
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists

    class TestHTTPMethodView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.url_for_paths = {}
            self.error_handler = {}
           

# Generated at 2022-06-18 05:47:56.292206
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import RouteExistsWarning
    from sanic.router import RouteExistsError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetError
    from sanic.router import RouteWarning
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import RouteExists

# Generated at 2022-06-18 05:48:07.937401
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import VersionedRouteTable
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_route_version
    from sanic.router import _get_version_from_name

# Generated at 2022-06-18 05:48:08.667226
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-18 05:48:16.960451
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test 1
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test1', methods=['GET'])
    assert len(app.router.routes_all['GET']) == 1
    assert app.router.routes_all['GET'][0].uri == '/test1'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all

# Generated at 2022-06-18 05:48:27.273816
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent

# Generated at 2022-06-18 05:48:37.140131
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse


# Generated at 2022-06-18 05:48:43.912469
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:49:44.303359
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:52.738833
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect

# Generated at 2022-06-18 05:50:04.368361
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:50:10.739911
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic('test_RouteMixin_add_route')

    @app.route('/')
    async def handler(request):
        return text('OK')

    @app.route('/1')
    async def handler1(request):
        return text('OK')

    @app.route('/2')
    async def handler2(request):
        return text('OK')

    @app.route('/3')
    async def handler3(request):
        return text('OK')

    @app.route('/4')
    async def handler4(request):
        return text('OK')


# Generated at 2022-06-18 05:50:19.234583
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.views import HTTPMethodView
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
   

# Generated at 2022-06-18 05:50:32.091244
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Test with valid parameters
    # Expected result:
    #     route is added to the router
    #     return the route object
    app = Sanic("test_app")
    router = RouteMixin(app)
    route = router.add_route("/", "GET", "handler")
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.handler == "handler"

    # Test case 2
    # Test with invalid parameters
    # Expected result:
    #     raise ValueError
    app = Sanic("test_app")
    router = RouteMixin(app)
    with pytest.raises(ValueError):
        router.add_route("/", "GET", "handler", "invalid_parameter")


# Generated at 2022-06-18 05:50:40.757913
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived

# Generated at 2022-06-18 05:50:51.651504
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.utils import guess_type, DEFAULT_HTTP_CONTENT_TYPE
    from sanic.static import ContentRangeHandler, ContentRangeError
    from sanic.response import file, file_stream
    from sanic.router import Route
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.utils import guess_type, DEFAULT_HTTP_CONTENT_TYPE
    from sanic.static import ContentRangeHandler, ContentRangeError
    from sanic.response import file, file_stream
    from sanic.router import Route
    from sanic.exceptions import InvalidUsage, FileNotFound

# Generated at 2022-06-18 05:51:02.757205
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:51:11.987828
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocketEventType
    from sanic.websocket import WebSocketEventType