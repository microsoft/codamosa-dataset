

# Generated at 2022-06-18 05:41:43.226469
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement test
    pass


# Generated at 2022-06-18 05:41:52.193899
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.websocket_routes = []
            self.middleware = []
            self.error_handler = {}
            self.static_routes = []
            self.host = None
            self.error_handler = {}
            self.exception_handler = {}
            self.request_middleware = []
            self.response_middleware = []
            self.blue

# Generated at 2022-06-18 05:41:55.684665
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    app = Sanic('test_RouteMixin_route')
    mixin = RouteMixin(app)
    @mixin.route('/test_RouteMixin_route')
    async def handler(request):
        return text('OK')
    request, response = app.test_client.get('/test_RouteMixin_route')
    assert response.text == 'OK'


# Generated at 2022-06-18 05:42:07.710960
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.app import Sanic
    from sanic.router import RouteExists

    app = Sanic("test_RouteMixin_add_route")
    app.config.REQUEST_MAX_SIZE = 10
    app.config.REQUEST_TIMEOUT = 10
    app.config.RESPONSE_TIMEOUT = 10
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 10
    app.config.RESPONSE_TIMEOUT = 10

# Generated at 2022-06-18 05:42:19.756069
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 05:42:21.482825
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: implement test
    pass


# Generated at 2022-06-18 05:42:28.908473
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:42:39.229519
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import Router

# Generated at 2022-06-18 05:42:46.273455
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:42:58.693955
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Sanic
    sanic = Sanic()
    # Create a mock object of class Request
    request = Request()
    # Create a mock object of class HTTPResponse
    http_response = HTTPResponse()
    # Create a mock object of class Handler
    handler = Handler()
    # Create a mock object of class Blueprint
    blueprint = Blueprint()
    # Create a mock object of class Blueprint
    blueprint2 = Blueprint()
    # Create a mock object of class Blueprint
    blueprint3 = Blueprint()
    # Create a mock object of class Blueprint
    blueprint4 = Blueprint()
    # Create a mock object of class Blueprint
    blueprint5 = Blueprint()

# Generated at 2022-06-18 05:43:29.418054
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Test the static method of class RouteMixin
    # Create a RouteMixin object
    route_mixin = RouteMixin()
    # Test the static method
    route_mixin.static(
        uri="/",
        file_or_directory="./",
        pattern=r"/?.+",
        use_modified_since=True,
        use_content_range=False,
        stream_large_files=False,
        name="static",
        host=None,
        strict_slashes=None,
        content_type=None,
        apply=True,
    )
    # Test the static method with invalid file path

# Generated at 2022-06-18 05:43:41.050721
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import Router
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Router
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Router

# Generated at 2022-06-18 05:43:49.680352
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of RequestParameters
    request_parameters = RequestParameters()
    # Create a new instance of Request
    request = Request()
    # Create a new instance of Response
    response = Response()
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Sanic
    sanic_1 = Sanic()
    # Create a new instance of Sanic
    sanic_2 = Sanic()
    # Create a new instance of Sanic
    sanic_3 = Sanic()
    # Create a new instance of Sanic
    sanic_4 = Sanic()
    # Create a new instance of Sanic
    sanic_

# Generated at 2022-06-18 05:43:54.311343
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test with default parameters
    test_route = RouteMixin()
    assert test_route.route()
    # Test with all parameters
    assert test_route.route(uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True, websocket=False)


# Generated at 2022-06-18 05:44:06.017837
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import PayloadTooLarge

# Generated at 2022-06-18 05:44:15.545495
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:44:27.023725
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import HTTPException
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidRangeType
    from sanic.exceptions import InvalidRangeValue

# Generated at 2022-06-18 05:44:37.251738
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route, RouteExists
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage

    class TestView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.name = "test"
            self.strict_slashes = True

    # test route
    route_mixin = TestRouteMixin()
    route_mixin.route("/test", methods=["GET"])(text("OK"))
    assert len(route_mixin.routes) == 1

# Generated at 2022-06-18 05:44:38.511563
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: implement test
    pass


# Generated at 2022-06-18 05:44:44.806577
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ServerError

# Generated at 2022-06-18 05:45:07.946955
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with valid parameters
    app = Sanic('test_sanic')
    app.add_route(lambda x: x, '/test', methods=['GET'])
    assert len(app.router.routes_all) == 1
    assert len(app.router.routes_all[0].handlers) == 1
    assert app.router.routes_all[0].uri == '/test'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].strict_slashes is None
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].version == None

# Generated at 2022-06-18 05:45:18.707819
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 05:45:29.176412
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a new object of class Route
    route = Route()
    # Create a new object of class Route
    route2 = Route()
    # Create a new object of class Route
    route3 = Route()
    # Create a new object of class Route
    route4 = Route()
    # Create a new object of class Route
    route5 = Route()
    # Create a new object of class Route
    route6 = Route()
    # Create a new object of class Route
    route7 = Route()
    # Create a new object of class Route
    route8 = Route()
    # Create a new object of class Route
    route9 = Route()
    # Create a new object of class Route
    route10 = Route()
    # Create a new object of

# Generated at 2022-06-18 05:45:39.760823
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:52.159508
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Request
    request = Request()
    # Create a new instance of HTTPResponse
    response = HTTPResponse()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of Sanic
    app = Sanic()
    # Create a new instance of Sanic
    app2 = Sanic()
    # Create a new instance of Sanic
    app3 = Sanic()
    # Create a new instance of Sanic
    app4 = Sanic()
    # Create a new instance of Sanic
    app5 = Sanic()
    # Create a new instance of Sanic
    app6 = Sanic()
    # Create a new instance of Sanic
    app7 = Sanic()

# Generated at 2022-06-18 05:46:00.898201
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    test_route = RouteMixin(app)
    test_route.add_route(handler=app.add_task, uri='/', methods=['GET'])
    assert test_route.routes[0].uri == '/'
    assert test_route.routes[0].methods == ['GET']
    assert test_route.routes[0].handler == app.add_task


# Generated at 2022-06-18 05:46:08.485056
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.utils import guess_type, DEFAULT_HTTP_CONTENT_TYPE
    from sanic.handlers import ContentRangeHandler
    from sanic.exceptions import ContentRangeError
    from sanic.response import file, file_stream
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.utils import guess_type, DEFAULT_HTTP_CONTENT_TYPE
    from sanic.handlers import ContentRangeHandler

# Generated at 2022-06-18 05:46:19.395603
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:46:26.207910
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:33.830607
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosedError
    from sanic.websocket import ConnectionClosedOK
    from sanic.websocket import ConnectionClosedAbnormal
    from sanic.websocket import ConnectionClosedNoStatusReceived
    from sanic.websocket import ConnectionClosedInvalidFramePayloadData
    from sanic.websocket import ConnectionClosedPolicyViolation
    from sanic.websocket import ConnectionClosedMessageTooBig
    from sanic.websocket import ConnectionClosedMandatoryExtension

# Generated at 2022-06-18 05:47:17.008658
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketReady
    from sanic.websocket import WebSocketMessage
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:47:28.300475
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure

# Generated at 2022-06-18 05:47:34.536771
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import VersionedRouteTable
    from sanic.router import VersionedRouter
    from sanic.router import get_parameter_name_from_match
    from sanic.router import get_route_parameter_names
    from sanic.router import get_route_parameters
    from sanic.router import get_route_parameters_from_match
    from sanic.router import get_route

# Generated at 2022-06-18 05:47:43.592455
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import InvalidUsage

# Generated at 2022-06-18 05:47:55.988979
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    route_mixin = RouteMixin()
    route_mixin.init_app(app)
    route_mixin.add_route(handler=None, uri="/", host=None, strict_slashes=None, methods=None, version=None, name=None)
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == "/"
    assert app.router.routes_all[0].methods == ["GET"]
    assert app.router.routes_all[0].version == None
    assert app.router.routes_all[0].name == None
    assert app.router.routes_all[0].strict_

# Generated at 2022-06-18 05:48:07.846233
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import InvalidUsage
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import file_stream
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import raw
    from sanic.response import jsonp
    from sanic.response import stream_file_stream

# Generated at 2022-06-18 05:48:16.438001
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of class RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of class Route
    route = Route()
    # Create a new instance of class Route
    route2 = Route()
    # Create a new instance of class Route
    route3 = Route()
    # Create a new instance of class Route
    route4 = Route()
    # Create a new instance of class Route
    route5 = Route()
    # Create a new instance of class Route
    route6 = Route()
    # Create a new instance of class Route
    route7 = Route()
    # Create a new instance of class Route
    route8 = Route()
    # Create a new instance of class Route
    route9 = Route()
    # Create a new instance of class Route
    route10 = Route()
    # Create a new instance of

# Generated at 2022-06-18 05:48:27.003734
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    app = Sanic("test_RouteMixin_add_route")
    # Act
    @app.route("/")
    async def handler(request):
        return text("OK")
    # Assert
    assert app.router.routes_all["GET"][0].uri == "/"
    assert app.router.routes_all["GET"][0].name == "handler"
    assert app.router.routes_all["GET"][0].handler == handler
    assert app.router.routes_all["GET"][0].strict_slashes is None
    assert app.router.routes_all["GET"][0].host is None

# Generated at 2022-06-18 05:48:28.732510
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # TODO: write unit test
    pass


# Generated at 2022-06-18 05:48:37.774252
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:14.581132
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:25.028550
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:49:34.295864
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # successfully
    # Input:
    #   uri: '/'
    #   host: None
    #   methods: None
    #   strict_slashes: None
    #   version: None
    #   name: None
    #   apply: True
    #   websocket: False
    #   subprotocols: None
    #   stream: False
    #   static: False
    #   expect: True
    # Output:
    #   assert: True
    uri = '/'
    host = None
    methods = None
    strict_slashes = None
    version = None
    name = None
    apply = True
    websocket = False
    subprotocols = None
    stream = False
    static = False

# Generated at 2022-06-18 05:49:46.803178
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:57.862560
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import RequestURITooLarge

# Generated at 2022-06-18 05:50:08.688496
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:50:14.822677
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'

# Generated at 2022-06-18 05:50:22.449852
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    app = Sanic("test_RouteMixin_add_route")
    # Act
    route = app.add_route("/", lambda r: HTTPResponse())
    # Assert
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.name == None

# Generated at 2022-06-18 05:50:33.367012
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of Handler
    handler = Handler()
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Request
    request = Request()
    # Create a new instance of Response
    response = Response()
    # Create a new instance of HTTPResponse
    http_response = HTTPResponse()
    # Create a new instance of StreamingHTTPResponse
    streaming_http_response = StreamingHTTPResponse()
    # Create a new instance of FileNotFound
    file_not_found = FileNotFound()
    # Create a new instance of InvalidUsage
    invalid_usage = InvalidUsage()
    # Create

# Generated at 2022-06-18 05:50:42.941383
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import VersionNotFound
    from sanic.router import VersionedRouteTable
    from sanic.router import VersionedRouter
    from sanic.router import _get_version_from_path
    from sanic.router import _get_version_from_url
    from sanic.router import _get_version_from_url_string
    from sanic.router import _get_version_from_url