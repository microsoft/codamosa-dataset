

# Generated at 2022-06-18 05:42:01.966495
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.blueprints import Blueprint
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteRes

# Generated at 2022-06-18 05:42:13.825866
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBody
    from sanic.views import StreamBuffer
    from sanic.views import Stream
    from sanic.views import HTTPMethodViewType
    from sanic.views import CompositionViewType
    from sanic.views import HTTPMethodViewType
    from sanic.views import StreamBodyType
    from sanic.views import StreamBufferType
    from sanic.views import StreamType
    from sanic.views import HTTPMethodViewType
    from sanic.views import CompositionViewType
    from sanic.views import HTTPMethod

# Generated at 2022-06-18 05:42:24.618154
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:42:30.569357
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import Router
    from sanic.router import Route
    from sanic.router import STATIC_ROUTE
    from sanic.router import WEBSOCKET_ROUTE
    from sanic.router import PLAIN_ROUTE

# Generated at 2022-06-18 05:42:40.603889
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.static import FutureStatic
    from sanic.router import Route
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:42:43.494964
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-18 05:42:53.632816
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:42:56.533564
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    app = Sanic()
    app.add_route(lambda x: x, '/', methods=['GET'])
    assert app.router.routes_names['/']['GET'] == '<lambda>'


# Generated at 2022-06-18 05:43:01.869967
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # Test for method static of class RouteMixin
    # We will create a Sanic app and test the method static
    app = Sanic('test_RouteMixin_static')
    # We will create a file and a directory to test the method static
    # We will create a file
    f = open('test_RouteMixin_static.txt', 'w')
    f.write('test_RouteMixin_static')
    f.close()
    # We will create a directory
    os.mkdir('test_RouteMixin_static_dir')
    # We will create a file in the directory
    f = open('test_RouteMixin_static_dir/test_RouteMixin_static.txt', 'w')
    f.write('test_RouteMixin_static')
    f.close()
    # We will test the method static with

# Generated at 2022-06-18 05:43:06.092658
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.name = "test_route_mixin"
            self.strict_slashes = None
            self.routes = []
            self._future_statics = set()
            self._future_middlewares = []
            self._future_exceptions = []
            self._future_listeners = []
            self._future_middleware_order = []
            self._future_middleware_order_index = 0
            self._future_middleware_order_index_map = {}
            self._future_middleware_order_index_map_reverse = {}
            self._future_middleware_order_index_map_reverse_index = 0
            self._future_middleware_order_index_map_reverse_index_map = {}


# Generated at 2022-06-18 05:43:22.412570
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBodyView
    from sanic.views import StreamBufferView
    from sanic.views import StreamFileView
    from sanic.views import StreamFileWrapperView
    from sanic.views import StreamHTTPResponseView
    from sanic.views import StreamJSONView
    from sanic.views import StreamTextView
    from sanic.views import StreamWebsocketView
    from sanic.views import TemplateView
    from sanic.views import TextView
    from sanic.views import WebsocketView


# Generated at 2022-06-18 05:43:29.115310
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with no arguments
    assert RouteMixin().add_route() == None
    # Test with valid arguments
    assert RouteMixin().add_route(uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True) == None
    # Test with invalid arguments
    assert RouteMixin().add_route(uri='/', host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True) == None


# Generated at 2022-06-18 05:43:40.606014
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNot

# Generated at 2022-06-18 05:43:49.401647
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 05:43:59.761929
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketDisconnect
   

# Generated at 2022-06-18 05:44:11.612054
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/'
    #   handler = 'test'
    #   methods = ['GET']
    #   host = '127.0.0.1'
    #   strict_slashes = False
    #   version = 1
    #   name = 'test'
    #   apply = True
    #   websocket = False
    #   stream = False
    #   expect = True
    #   actual = True
    # Output:
    #   expect == actual
    uri = '/'
    handler = 'test'
    methods = ['GET']
    host = '127.0.0.1'
    strict_slashes = False
    version = 1
    name = 'test'
    apply = True
    websocket = False
    stream = False
    expect

# Generated at 2022-06-18 05:44:23.098974
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:33.837795
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableUndefError
    from sanic.router import RouteTableDef
    from sanic.router import RouteTableUndef
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import RouterTable

# Generated at 2022-06-18 05:44:35.881281
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-18 05:44:43.345042
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterResetError
    from sanic.router import RouterResetWarning
    from sanic.router import RouterWarning
    from sanic.router import SanicRouteWarning

# Generated at 2022-06-18 05:45:08.073875
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
    from sanic.views import StreamBuffer
   

# Generated at 2022-06-18 05:45:18.959317
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:45:29.420991
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:39.965390
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:45:52.472960
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import StaticRouteExists
    from sanic.router import StaticRouteReset
    from sanic.router import StaticRouteResetError
    from sanic.router import StaticRouteTable
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouteExists
    from sanic.router import VersionedRouteReset
    from sanic.router import VersionedRouteResetError
    from sanic.router import VersionedRouteTable


# Generated at 2022-06-18 05:46:04.475275
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   handler = None
    #   uri = None
    #   methods = None
    #   host = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   stream = None
    #   apply = True
    #   websocket = False
    #   expect = None
    # Output:
    #   expect = None
    handler = None
    uri = None
    methods = None
    host = None
    strict_slashes = None
    version = None
    name = None
    stream = None
    apply = True
    websocket = False
    expect = None

# Generated at 2022-06-18 05:46:16.224270
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionInfoError
    from sanic.router import VersionInfoWarning
    from sanic.router import VersionInfoReset
    from sanic.router import VersionInfoResetError
    from sanic.router import VersionInfo

# Generated at 2022-06-18 05:46:29.117202
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default parameters
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == 'test'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].methods == ['GET']
    assert app.router.routes_all['GET'][0].handler

# Generated at 2022-06-18 05:46:40.283046
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import UrlBuildError
    from sanic.router import UrlBuildErrorContext
    from sanic.router import UrlBuildErrorContextMissingParameter
    from sanic.router import UrlBuildErrorContextParameterValue
    from sanic.router import UrlBuildErrorContextParameterType
    from sanic.router import UrlBuildErrorContextParameterUnknown

# Generated at 2022-06-18 05:46:50.723543
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouterException
    from sanic.router import RouterMatch
    from sanic.router import RouterMatchInfo
    from sanic.router import RouterMatchNotFound
    from sanic.router import RouterMatchNotHttp
    from sanic.router import RouterMatchWebSocket
    from sanic.router import RouterMatchWebSocketUpgrade
    from sanic.router import RouterMatchWebSocketUpgradeRequired
    from sanic.router import RouterMatchWebSocketUpgradeRequired
    from sanic.router import RouterMatchWebSocketUpgradeRequired
    from sanic.router import RouterMatchWebSocketUpgradeRequired

# Generated at 2022-06-18 05:47:12.042765
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:47:24.051670
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:47:31.971785
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    app = Sanic('test_RouteMixin_route')
    @app.route('/')
    async def handler(request):
        return text('OK')
    assert isinstance(app.router.routes_all[0], Route)
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].strict_slashes is None

# Generated at 2022-06-18 05:47:33.190586
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: implement test
    pass


# Generated at 2022-06-18 05:47:42.863206
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.request import RequestParameters
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketConnection
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:47:55.460375
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:48:02.321143
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Sanic
    app = Sanic()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of RequestParameters
    request_parameters = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters_1 = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters_2 = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters_3 = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters_4 = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters_5 = RequestParameters()
    # Create a new instance of RequestParameters
    request_parameters

# Generated at 2022-06-18 05:48:13.005854
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import Web

# Generated at 2022-06-18 05:48:24.720689
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Route
    route_1 = Route()
    # Create a mock object of class Route
    route_2 = Route()
    # Create a mock object of class Route
    route_3 = Route()
    # Create a mock object of class Route
    route_4 = Route()
    # Create a mock object of class Route
    route_5 = Route()
    # Create a mock object of class Route
    route_6 = Route()
    # Create a mock object of class Route
    route_7 = Route()
    # Create a mock object of class Route
    route_8 = Route()
    # Create a mock object of class Route
    route_9 = Route

# Generated at 2022-06-18 05:48:35.197282
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.response import json
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:49:17.342036
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import InternalServerError

# Generated at 2022-06-18 05:49:26.914412
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetSuccess
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetError
    from sanic.router import RouteResetSuccess
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:49:34.854141
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterMatchError
    from sanic.router import RouterMatchNotFound
    from sanic.router import RouterMatchNotFoundError
    from sanic.router import RouterMatchTypeError
    from sanic.router import RouterMatchValueError
    from sanic.router import RouterMatchWarning
    from sanic.router import RouterMatchWarningError
    from sanic.router import RouterMatchWarningNotFound
    from sanic.router import RouterMatchWarningNotFoundError

# Generated at 2022-06-18 05:49:47.416672
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteRes

# Generated at 2022-06-18 05:49:58.917291
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:50:10.427656
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist

# Generated at 2022-06-18 05:50:18.972935
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError

# Generated at 2022-06-18 05:50:31.753084
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import Web

# Generated at 2022-06-18 05:50:41.298464
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.request import RequestParameters
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteReset
    from sanic.router import RouteExists

# Generated at 2022-06-18 05:50:52.281611
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.exceptions import InvalidUsage
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:51:25.950074
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    app.config.REQUEST_MAX_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_MAX_MEMORY_SIZE = 0
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 15
    app.config.ERROR_LOGGER = False
    app.config.ACCESS_LOG = False

# Generated at 2022-06-18 05:51:31.818897
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon