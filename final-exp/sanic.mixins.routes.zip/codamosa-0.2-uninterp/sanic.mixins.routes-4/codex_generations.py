

# Generated at 2022-06-18 05:41:50.991056
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:41:57.789585
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import UrlExists
    from sanic.router import UrlReset
    from sanic.router import UrlPrefixExists
    from sanic.router import UrlPrefixReset
    from sanic.router import UrlPrefixVersionExists
    from sanic.router import UrlPrefixVersionReset
    from sanic.router import VersionExists
    from sanic.router import VersionReset
    from sanic.router import VersionHostExists
    from sanic.router import VersionHostReset
    from sanic.router import VersionHostMethodExists

# Generated at 2022-06-18 05:42:09.249293
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionNotFound
    from sanic.router import VersionedRouteTable
    from sanic.router import _get_version_from_request
    from sanic.router import _get_version_from_url
    from sanic.router import _get_version_info
    from sanic.router import _get_

# Generated at 2022-06-18 05:42:16.297439
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default arguments
    @RouteMixin.add_route("/")
    def handler(request):
        pass

    # Test with all arguments
    @RouteMixin.add_route("/", methods=["GET"], host="localhost", strict_slashes=True, version=1, name="name", apply=True)
    def handler(request):
        pass


# Generated at 2022-06-18 05:42:25.950518
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteResetWarning

# Generated at 2022-06-18 05:42:37.888698
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import URLTooLong
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import InvalidHeader
    from sanic.exceptions import InvalidProxyHeader

# Generated at 2022-06-18 05:42:44.881245
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    routeMixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Handler
    handler = Handler()
    # Create a mock object of class Sanic
    sanic = Sanic()
    # Create a mock object of class Request
    request = Request()
    # Create a mock object of class HTTPResponse
    httpResponse = HTTPResponse()
    # Create a mock object of class Response
    response = Response()
    # Create a mock object of class StreamResponse
    streamResponse = StreamResponse()
    # Create a mock object of class WebSocketProtocol
    webSocketProtocol = WebSocketProtocol()
    # Create a mock object of class WebSocketCommonProtocol
    webSocketCommonProtocol = WebSocketCommonProt

# Generated at 2022-06-18 05:42:55.133734
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:43:07.568914
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import PayloadExpected
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import URIT

# Generated at 2022-06-18 05:43:15.494083
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin()
    # Create a mock object of class Route
    route = Route()
    # Create a mock object of class Route
    route2 = Route()
    # Create a mock object of class Route
    route3 = Route()
    # Create a mock object of class Route
    route4 = Route()
    # Create a mock object of class Route
    route5 = Route()
    # Create a mock object of class Route
    route6 = Route()
    # Create a mock object of class Route
    route7 = Route()
    # Create a mock object of class Route
    route8 = Route()
    # Create a mock object of class Route
    route9 = Route()
    # Create a mock object of class Route
    route10 = Route()
    # Create a mock object of

# Generated at 2022-06-18 05:43:45.394826
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default values
    router = RouteMixin()
    route = router.add_route('/', 'GET', 'test_handler')
    assert route.uri == '/'
    assert route.methods == ['GET']
    assert route.name == 'test_handler'
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.stream == False
    assert route.websocket == False
    assert route.static == False
    assert route.handler == 'test_handler'
    assert route.apply == True
    assert route.subprotocols == None
    assert route.pattern == None
    assert route.use_modified_since == True
    assert route.use_content_range == False
    assert route.stream_large_files == False
    assert route

# Generated at 2022-06-18 05:43:56.384008
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:44:08.092909
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock Sanic app
    app = Sanic("test_RouteMixin_add_route")
    # Create a mock request
    request = Request.fake_request("GET", "/")
    # Create a mock response
    response = HTTPResponse()
    # Create a mock handler
    async def handler(request):
        return response
    # Create a mock route
    route = Route("/", host=None, methods=["GET"], handler=handler,
                  strict_slashes=None, version=None, name=None,
                  stream=False, websocket=False, static=False,
                  expect_handler=None,
                  )
    # Create a mock router
    router = Router()
    # Create a mock RouteMixin
    routemixin = RouteMixin()
    # Add the route to the router
    routem

# Generated at 2022-06-18 05:44:16.880588
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    app.add_route(lambda x: x, uri="/test")
    assert app.is_request_stream is False
    assert app.is_websocket_route is False
    assert app.is_static_route is False
    assert app.is_stream_route is False
    assert app.is_websocket is False
    assert app.is_websocket_response is False
    assert app.is_websocket_request is False
    assert app.is_websocket_handler is False
    assert app.is_websocket_exception is False
    assert app.is_coroutine is False
    assert app.is_coroutine_route is False
    assert app.is_coroutine_exception is False
    assert app.is_middle

# Generated at 2022-06-18 05:44:18.435173
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: add test cases
    pass


# Generated at 2022-06-18 05:44:30.022581
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    app = Sanic()
    app.static('/static', './static')
    assert app.router.routes_all['GET'][0].uri == '/static/<__file_uri__:path>'
    assert app.router.routes_all['GET'][0].name == '_static_static'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].static == True
    assert app.router.routes_all['GET'][0].websocket == False

# Generated at 2022-06-18 05:44:39.697275
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import PayloadExpected
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import TooManyRequests
    from sanic.exceptions import RequestURITooLarge

# Generated at 2022-06-18 05:44:49.883564
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:44:58.083052
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.utils import guess_type
    from sanic.utils import ContentRangeHandler
    from sanic.utils import stat_async
    from sanic.utils import file
    from sanic.utils import file_stream
    from sanic.utils import sub
    from sanic.utils import unquote
    from sanic.utils import strftime
    from sanic.utils import gmtime
    from sanic.utils import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.utils import FutureStatic


# Generated at 2022-06-18 05:45:05.325303
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetFull
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError

# Generated at 2022-06-18 05:45:28.676727
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import Router
    from sanic.router import RouterException
    from sanic.router import RouterMatch
    from sanic.router import RouterMatchInfo
    from sanic.router import RouterMatchNotFound
    from sanic.router import RouterMatchWebSocket
    from sanic.router import RouterMatchWebSocketDisconnect
    from sanic.router import RouterMatchWebSocketError
    from sanic.router import RouterMatchWebSocketTimeout
    from sanic.router import RouterMatchWebSocketUpgrade
    from sanic.router import RouterMatchWebSocketUpgradeError
    from sanic.router import RouterMatchWebSocketUpgradeTimeout
    from sanic.router import RouterMatchWebSocketUpgradeWebSocket

# Generated at 2022-06-18 05:45:39.255561
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketState
    from sanic.websocket import Web

# Generated at 2022-06-18 05:45:51.273373
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:56.022460
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_RouteMixin = mock.Mock(spec=RouteMixin)
    # Define return value of method add_route of class RouteMixin
    mock_RouteMixin.add_route.return_value = None
    # Check the return value of method add_route of class RouteMixin
    assert mock_RouteMixin.add_route() == None


# Generated at 2022-06-18 05:46:06.357730
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic import Sanic
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import ConnectionClosed

# Generated at 2022-06-18 05:46:18.656937
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import RouterResetWarning
    from sanic.router import RouterWarning

# Generated at 2022-06-18 05:46:29.849278
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import TooManyRequests
    from sanic.exceptions import PayloadExpected
   

# Generated at 2022-06-18 05:46:38.137117
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import UrlExists
    from sanic.router import UrlReset
    from sanic.router import UrlResetError
    from sanic.router import UrlResetWarning
    from sanic.router import UrlWarning
    from sanic.router import VersionExists
    from sanic.router import VersionReset

# Generated at 2022-06-18 05:46:45.087517
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a RouteMixin object
    route_mixin = RouteMixin()

    # Create a handler function
    def handler(request):
        return text('OK')

    # Create a route
    route = route_mixin.add_route(handler, '/')

    # Check if the route is a Route object
    assert isinstance(route, Route)

    # Check if the route has the correct handler
    assert route.handler == handler

    # Check if the route has the correct uri
    assert route.uri == '/'

    # Check if the route has the correct methods
    assert route.methods == ['GET']

    # Check if the route has the correct host
    assert route.host == None

    # Check if the route has the correct strict_slashes
    assert route.strict_slashes == None

    # Check if the route has

# Generated at 2022-06-18 05:46:55.319293
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import ContentRangeError, FileNotFound, InvalidUsage
    from sanic.utils import guess_type, stat_async
    from sanic.static import ContentRangeHandler
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.response import file, file_stream
    from sanic.router import Route
    from sanic.exceptions import InvalidUsage
    from sanic.utils import sanic_endpoint_test
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.router import Route

# Generated at 2022-06-18 05:47:19.368693
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class Sanic
    app = MagicMock(spec=Sanic)
    # Create a mock object of class RouteMixin
    route_mixin = RouteMixin(app)
    # Create a mock object of class Route
    route = MagicMock(spec=Route)
    # Create a mock object of class Handler
    handler = MagicMock(spec=Handler)
    # Create a mock object of class RequestParameters
    request_parameters = MagicMock(spec=RequestParameters)
    # Create a mock object of class Route
    route_1 = MagicMock(spec=Route)
    # Create a mock object of class Handler
    handler_1 = MagicMock(spec=Handler)
    # Create a mock object of class RequestParameters
    request_parameters_1 = MagicMock(spec=RequestParameters)
    #

# Generated at 2022-06-18 05:47:30.245233
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterWarning
    from sanic.router import VersionWarning
    from sanic.router import Warning
    from sanic.router import WarningRegistry
    from sanic.router import _get_route_name
    from sanic.router import _get_route_version
    from sanic.router import _get_route_version_name
    from sanic.router import _get_

# Generated at 2022-06-18 05:47:35.967187
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol


# Generated at 2022-06-18 05:47:43.882139
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists

    class MockRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.websocket_routes = []
            self.static_routes = []
            self.host = None
            self.strict_slashes = None
            self.name = 'sanic'

    mock_route_mixin = MockRouteMixin()

    # Test for method add_route with method GET

# Generated at 2022-06-18 05:47:56.334430
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionInfoError
    from sanic.router import VersionInfoWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_version
    from sanic.router import _

# Generated at 2022-06-18 05:48:07.987865
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import file_stream
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream_file
   

# Generated at 2022-06-18 05:48:16.540047
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:48:27.052705
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:48:36.974782
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage

# Generated at 2022-06-18 05:48:46.205211
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildError
    from sanic.router import Route

# Generated at 2022-06-18 05:49:08.576490
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of class RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of class Route
    route = Route()
    # Create a new instance of class Request
    request = Request()
    # Create a new instance of class HTTPResponse
    http_response = HTTPResponse()
    # Create a new instance of class Sanic
    sanic = Sanic()
    # Create a new instance of class Sanic
    sanic_1 = Sanic()
    # Create a new instance of class Sanic
    sanic_2 = Sanic()
    # Create a new instance of class Sanic
    sanic_3 = Sanic()
    # Create a new instance of class Sanic
    sanic_4 = Sanic()
    # Create a new instance of class Sanic
    sanic_

# Generated at 2022-06-18 05:49:18.687681
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin and test the method route
    # Create an instance of RouteMixin
    route_mixin = RouteMixin()
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin and test the method route
    # Create an instance of RouteMixin
    route_mixin = RouteMixin()
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin and test the method route
    # Create an instance of RouteMixin
    route_mixin = RouteMixin()
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin and test the method route
    # Create an instance of RouteMixin
    route_mixin = RouteMixin()

# Generated at 2022-06-18 05:49:27.865249
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:35.253760
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import InvalidRangeType
    from sanic.exceptions import InvalidRangeValue
    from sanic.exceptions import InvalidRangeFormat
    from sanic.exceptions import InvalidRangeUnits
    from sanic.exceptions import InvalidRange

# Generated at 2022-06-18 05:49:43.900915
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case data
    uri = 'test'
    handler = 'test'
    methods = 'test'
    host = 'test'
    strict_slashes = 'test'
    version = 'test'
    name = 'test'
    apply = 'test'
    # Perform the test
    result = RouteMixin.add_route(uri, handler, methods, host, strict_slashes, version, name, apply)
    # Verify the results
    assert result is None


# Generated at 2022-06-18 05:49:52.540736
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound

    class TestView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = False
            self.name = "test"


# Generated at 2022-06-18 05:50:04.185610
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteNotFound
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteNotFound
    from sanic.router import Route
    from sanic.router import Route

# Generated at 2022-06-18 05:50:14.316619
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteNotFound
    from sanic.router import RouteExpectationFailed
    from sanic.router import RouteNotAllowed
    from sanic.router import RouteMethodNotAllowed
    from sanic.router import RouteHandlerNotFound
    from sanic.router import RouteHandlerNotCallable
    from sanic.router import RouteHandlerNotCor

# Generated at 2022-06-18 05:50:22.039126
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteBuildError
    from sanic.router import RouteBuildWarning
    from sanic.router import RouteBuildResult
    from sanic.router import RouteBuildSuccess
    from sanic.router import RouteBuildFailure

# Generated at 2022-06-18 05:50:33.158920
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import RequestURITooLarge
    from sanic.exceptions import HTTPVersionNotSupported


# Generated at 2022-06-18 05:51:06.521771
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import StreamBuffer
    from sanic.views import StreamBufferEmpty
    from sanic.views import StreamBufferFull
    from sanic.views import StreamBufferNoMoreData
    from sanic.views import StreamBufferTooBig
    from sanic.views import StreamBufferTooSmall
    from sanic.views import StreamBufferWrongType
    from sanic.views import StreamEmpty
    from sanic.views import StreamFull
    from sanic.views import StreamNoMoreData
    from sanic.views import StreamTooBig
    from sanic.views import Stream

# Generated at 2022-06-18 05:51:17.676558
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:51:21.813084
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:51:29.649010
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with no parameter
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].methods == ['GET']