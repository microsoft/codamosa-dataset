

# Generated at 2022-06-18 05:42:15.748902
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.constants import HTTP_STATUS_CODES
    from sanic.constants import WEBSOCKET_METHODS
    from sanic.constants import WEBSOCKET_STATUS_CODES
    from sanic.constants import REQUEST_

# Generated at 2022-06-18 05:42:25.629485
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    router = RouteMixin()
    router.add_route(MyView.as_view(), '/')
    assert router.routes[0].uri == '/'
    assert router.routes[0].methods == ['GET', 'POST']
    assert router.routes[0].handler == MyView.as_view()
    assert router.routes[0].name == 'myview'
    assert router.routes[0].host == None

# Generated at 2022-06-18 05:42:37.844244
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # with correct parameters
    # Expected result: the method route can be called
    # with correct parameters
    # Actual result: the method route can be called
    # with correct parameters
    assert RouteMixin.route(uri='/', methods=None, version=None, name=None,
                            strict_slashes=None, host=None, apply=True,
                            websocket=False, stream=False, static=False)

    # Test case 2
    # Test if the method route of class RouteMixin can be called
    # with incorrect parameters
    # Expected result: the method route can be called
    # with incorrect parameters
    # Actual result: the method route can be called
    # with incorrect parameters

# Generated at 2022-06-18 05:42:44.847990
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import UrlForError
    from sanic.router import UrlForStaticError
    from sanic.router import UrlForViewError
    from sanic.router import UrlForViewNotFound
    from sanic.router import UrlForViewNotRegistered
    from sanic.router import UrlForViewRegistered
    from sanic.router import UrlForViewRegisteredWithHost

# Generated at 2022-06-18 05:42:55.061221
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteSyntaxError
    from sanic.router import StaticRoute
    from sanic.router import StaticRouteExists
    from sanic.router import StaticRouteDoesNotExist
    from sanic.router import StaticRouteReset
    from sanic.router import StaticRouteResetError
    from sanic.router import StaticRouteSyntaxError
    from sanic.router import RouteExists
    from sanic.router import RouteDoes

# Generated at 2022-06-18 05:43:07.484392
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists

    app = Sanic("test_RouteMixin_static")
    router = app.router
    router.static("/static", "./static")
    assert router.routes_all == [
        Route(
            uri="/static/<__file_uri__:path>",
            host=None,
            methods={"GET", "HEAD"},
            handler=router._static_request_handler,
            name="static",
            strict_slashes=None,
            stream=False,
            version=None,
            websocket=False,
            static=True,
        )
    ]

# Generated at 2022-06-18 05:43:15.462590
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNot

# Generated at 2022-06-18 05:43:21.369832
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:43:30.707715
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import UrlForError
    from sanic.router import UrlForWarning

# Generated at 2022-06-18 05:43:42.186783
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:44:10.961498
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    print("Test case 1")
    app = Sanic(__name__)
    app.route('/')(lambda request: HTTPResponse())
    assert app.router.routes_all['GET'][0].uri == '/'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].methods == ['GET']
    assert app.router.routes_all

# Generated at 2022-06-18 05:44:18.291773
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    async def handler(request):
        return text('OK')
    assert len(app.router.routes_all) == 1
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.r

# Generated at 2022-06-18 05:44:29.818332
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:44:39.578245
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Route
    route = Route()
    # Create a new instance of Handler
    handler = Handler()
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Request
    request = Request()
    # Create a new instance of Response
    response = Response()
    # Create a new instance of Blueprint
    blueprint = Blueprint()
    # Create a new instance of Blueprint
    blueprint_1 = Blueprint()
    # Create a new instance of Blueprint
    blueprint_2 = Blueprint()
    # Create a new instance of Blueprint
    blueprint_3 = Blueprint()
    # Create a new instance of Blueprint
    blueprint_4 = Blueprint()
    # Create a new instance of Blueprint
    blueprint_5 = Blueprint()

# Generated at 2022-06-18 05:44:49.667344
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:44:57.888781
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:45:05.163131
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a RouteMixin object
    route_mixin = RouteMixin()
    # Create a function
    def test_function():
        pass
    # Create a route
    route = route_mixin.add_route(test_function, uri='/test_route')
    # Assert that the route is a Route object
    assert isinstance(route, Route)
    # Assert that the route has the correct uri
    assert route.uri == '/test_route'
    # Assert that the route has the correct handler
    assert route.handler == test_function
    # Assert that the route has the correct name
    assert route.name == 'test_function'
    # Assert that the route has the correct methods
    assert route.methods == ['GET']
    # Assert that the route has the correct version

# Generated at 2022-06-18 05:45:12.903508
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:24.865137
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.strict_slashes = None
            self.name = "TestRouteMixin"

        def route(self, uri, host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True, **options):
            def decorator(handler):
                return self.routes, handler
            return decorator

    test_route_mixin = TestRouteMixin()
    assert test_route_mixin.add_route("/", "test_handler") == ("test_handler",)
    assert test_route_mixin.add_route("/", "test_handler", methods=["GET"]) == ("test_handler",)
    assert test_route_mix

# Generated at 2022-06-18 05:45:34.984257
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouter
    from sanic.router import _get_route_name
    from sanic.router import _get_route_name_for_handler
    from sanic.router import _get_route_name_for_static
    from sanic.router import _get_route_name_for_websocket

# Generated at 2022-06-18 05:45:58.864251
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic(__name__)
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.WEBSOCKET_MAX_SIZE = 2 ** 20
    app.config.WEBSOCKET_MAX_QUEUE = 32
    app.config.WEBSOCKET_READ_LIMIT = 2 ** 16
    app.config.WEBSOCKET_WRITE_LIMIT = 2 ** 16
    app.config.REQUEST_MAX_SIZE = 2 ** 20
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.RES

# Generated at 2022-06-18 05:46:05.927716
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:18.371877
# Unit test for method static of class RouteMixin

# Generated at 2022-06-18 05:46:29.561965
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:40.305481
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_route_name_from_handler
    from sanic.router import _get_route_name_from_handler_string


# Generated at 2022-06-18 05:46:43.751046
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test with no parameters
    with pytest.raises(TypeError):
        RouteMixin().route()

    # Test with invalid parameters
    with pytest.raises(TypeError):
        RouteMixin().route(uri=None)

    # Test with valid parameters
    assert RouteMixin().route(uri='/')[0] == []


# Generated at 2022-06-18 05:46:54.715707
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.response import text
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import FileStream
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import file_stream


# Generated at 2022-06-18 05:47:02.568356
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:47:09.467876
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = "/"
    #   handler = None
    #   methods = ["GET"]
    #   host = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   stream = False
    #   apply = True
    #   websocket = False
    #   expect = None
    #   actual = None
    # Output:
    #   expect = None
    #   actual = None
    uri = "/"
    handler = None
    methods = ["GET"]
    host = None
    strict_slashes = None
    version = None
    name = None
    stream = False
    apply = True
    websocket = False
    expect = None
    actual = None
    assert expect == actual

    # Test

# Generated at 2022-06-18 05:47:21.335860
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:47:49.402390
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic

# Generated at 2022-06-18 05:47:55.867499
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new RouteMixin object
    route_mixin = RouteMixin()
    # Create a new Route object
    route = Route()
    # Add the route to the route_mixin
    route_mixin.add_route(route)
    # Check if the route is in the routes list
    assert route in route_mixin.routes


# Generated at 2022-06-18 05:48:07.845363
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import file_stream
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import json
    from sanic.response import jsonp
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream_file
    from sanic.response import raw
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 05:48:13.249473
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.app import Sanic
    app = Sanic()
    app.add_route(text('OK'), '/')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].handler == text
    assert app.router.routes_all[0].name == 'text'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version

# Generated at 2022-06-18 05:48:21.618160
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin
    # and test if the method route works properly.
    # Create an instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a function to be decorated
    def handler():
        pass
    # Decorate the function
    decorated_handler = route_mixin.route(uri='/test')(handler)
    # Test if the function is decorated
    assert decorated_handler.__name__ == 'handler'

# Generated at 2022-06-18 05:48:32.550595
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_RouteMixin_add_route")

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    @app.websocket("/feed")
    async def feed(request, ws):
        while True:
            data = "hello!"
            print("Sending: %s" % data)
            await ws.send(data)
            data = await ws.recv()

# Generated at 2022-06-18 05:48:42.785042
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:48:49.455492
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test with default parameters
    @app.route('/')
    def handler(request):
        return text('OK')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].static == False
    assert app.router.routes_all[0].websocket == False
    assert app.rou

# Generated at 2022-06-18 05:48:53.302301
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_RouteMixin = mock.Mock(spec=RouteMixin)
    # Define return value of method add_route of class RouteMixin
    mock_RouteMixin.add_route.return_value = None
    # Compare the return value from the mock object
    assert mock_RouteMixin.add_route() == None


# Generated at 2022-06-18 05:48:59.165751
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import FileNotFound, InvalidUsage, ContentRangeError
    from sanic.handlers import ContentRangeHandler
    from sanic.response import StreamingHTTPResponse
    from sanic.utils import guess_type
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.router import Route
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import FileNotFound, InvalidUsage, ContentRangeError
    from sanic.handlers import ContentRangeHandler
    from sanic.response import StreamingHTTPResponse

# Generated at 2022-06-18 05:49:25.069527
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteRemoved
    from sanic.router import RouteRemovedWarning
    from sanic.router import RouteWarning
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouteWarning
    from sanic.router import VersionWarning
    from sanic.router import Warning
    from sanic.router import _default_route_name
    from sanic.router import _get_route_name
    from sanic.router import _get_route_version

# Generated at 2022-06-18 05:49:34.284567
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterMatchError
    from sanic.router import RouterMatch
    from sanic.router import RouterMatchInfo
    from sanic.router import RouterMatchInfoError
    from sanic.router import RouterMatchInfoKeyError
    from sanic.router import RouterMatchInfoKey

# Generated at 2022-06-18 05:49:46.758530
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # successfully
    # Input:
    #   uri = 'test'
    #   host = 'test'
    #   methods = 'test'
    #   strict_slashes = 'test'
    #   version = 'test'
    #   name = 'test'
    #   apply = 'test'
    #   websocket = 'test'
    #   stream = 'test'
    #   subprotocols = 'test'
    #   static = 'test'
    #   expect = None
    # Output:
    #   assert_equal(expect, actual)
    uri = 'test'
    host = 'test'
    methods = 'test'
    strict_slashes = 'test'

# Generated at 2022-06-18 05:49:57.689606
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.websocket_routes = []
            self.host = None
            self.strict_slashes = None
            self.name = "test"

    route_mixin = TestRouteMixin()
    route_mixin.add_route(text, uri="/", methods=["GET"])
    assert isinstance(route_mixin.routes[0], Route)

# Generated at 2022-06-18 05:50:08.502476
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableDefExists
    from sanic.router import RouteTableDefReset
    from sanic.router import RouteTableDefResetError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableExists
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterExists
    from sanic.router import RouterReset

# Generated at 2022-06-18 05:50:17.840735
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default values
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda r: HTTPResponse(), '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].version == None
    assert app.router.routes_all['GET'][0].websocket == False
    assert app.router.routes_

# Generated at 2022-06-18 05:50:30.716585
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketPayloadTooBig
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketHand

# Generated at 2022-06-18 05:50:32.426809
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement unit test for method add_route of class RouteMixin
    pass


# Generated at 2022-06-18 05:50:33.791700
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: Implement
    pass


# Generated at 2022-06-18 05:50:43.942436
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:51:06.869100
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge

# Generated at 2022-06-18 05:51:18.650685
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:51:27.701014
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import VersionedRouteTable
    from sanic.router import VersionedRouter
    from sanic.router import _check_route_name
    from sanic.router import _check_route_name_collision
    from sanic.router import _get_route_name
    from sanic.router import _get_route_name_from_handler
    from sanic.router import _get_route_name