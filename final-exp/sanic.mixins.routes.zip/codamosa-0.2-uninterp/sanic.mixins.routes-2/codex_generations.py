

# Generated at 2022-06-18 05:41:55.607825
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import VersionInfo
    from sanic.router import VersionedRouteTable
    from sanic.router import _get_version_from_name
    from sanic.router import _get_version_from_uri
    from sanic.router import _get_version_from_uri_and_name
    from sanic.router import _get_version_info
    from sanic.router import _get_version_info_from_name

# Generated at 2022-06-18 05:42:07.710304
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState

# Generated at 2022-06-18 05:42:14.225872
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    import asyncio
    from sanic import Sanic
    from sanic.response import json

    app = Sanic('test_RouteMixin_add_route')

    @app.route('/')
    async def test(request):
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.json == {'test': True}


# Generated at 2022-06-18 05:42:24.929218
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:42:34.095668
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route

    app = Sanic()
    app.router = RouteMixin(app)
    app.router.route(uri='/', methods=['GET'], host=None, strict_slashes=None, version=None, name=None, apply=True, static=False, websocket=False)(lambda request: None)
    assert isinstance(app.router.routes[0], Route)


# Generated at 2022-06-18 05:42:42.585169
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # We will create a mock object for class RouteMixin
    mock_RouteMixin = Mock(spec=RouteMixin)
    # Define return value of method add_route of class RouteMixin
    mock_RouteMixin.add_route.return_value = None
    # Call method add_route of class RouteMixin
    RouteMixin.add_route(mock_RouteMixin, "uri", "handler")
    # Now, we verify that method add_route of class RouteMixin has been called
    assert mock_RouteMixin.add_route.called


# Generated at 2022-06-18 05:42:52.800905
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import TooManyRequests
    from sanic.exceptions import HTTPException
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound

# Generated at 2022-06-18 05:42:53.808732
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # TODO: write unit test for method add_route of class RouteMixin
    pass


# Generated at 2022-06-18 05:43:00.128221
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError

# Generated at 2022-06-18 05:43:10.144297
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:43:31.727598
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import RouteExistsWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import RouteExistsWarning
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning


# Generated at 2022-06-18 05:43:43.114397
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new RouteMixin object
    route_mixin = RouteMixin()
    # Create a new Request object
    request = Request()
    # Create a new HTTPResponse object
    response = HTTPResponse()
    # Create a new Route object
    route = Route()
    # Create a new Route object
    route_1 = Route()
    # Create a new Route object
    route_2 = Route()
    # Create a new Route object
    route_3 = Route()
    # Create a new Route object
    route_4 = Route()
    # Create a new Route object
    route_5 = Route()
    # Create a new Route object
    route_6 = Route()
    # Create a new Route object
    route_7 = Route()
    # Create a new Route object
    route_8 = Route()


# Generated at 2022-06-18 05:43:51.035113
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   handler: function
    #   uri: str
    #   host: str
    #   methods: list
    #   strict_slashes: bool
    #   version: int
    #   name: str
    #   apply: bool
    #   websocket: bool
    #   stream: bool
    #   subprotocols: list
    #   static: bool
    # Expected output:
    #   route: Route
    #   decorated_function: function
    handler = lambda: None
    uri = '/'
    host = '127.0.0.1'
    methods = ['GET']
    strict_slashes = True
    version = 1
    name = 'test'
    apply = True
    websocket = False
    stream = False
    subprot

# Generated at 2022-06-18 05:44:01.296559
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import InvalidUsage

    app = Sanic(__name__)
    app.add_route(text("Hello world"), uri="/", methods=["GET"])
    assert app.router.routes_all["/"][0].uri == "/"
    assert app.router.routes_all["/"][0].methods == ["GET"]
    assert app.router.routes_all["/"][0].handler == text
    assert app.router.routes_all["/"][0].name == "test_RouteMixin_add_route.<locals>.<lambda>"

# Generated at 2022-06-18 05:44:13.041710
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.response import text
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableRegisterError
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import UrlForError
    from sanic.router import UrlFor

# Generated at 2022-06-18 05:44:25.006939
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:44:27.436426
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with valid parameters
    # Test with invalid parameters
    # Test with missing parameters
    # Test with extra parameters
    pass


# Generated at 2022-06-18 05:44:37.612426
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Initialize a RouteMixin object
    route_mixin = RouteMixin()
    # Initialize a Sanic object
    app = Sanic()
    # Initialize a Request object

# Generated at 2022-06-18 05:44:44.378067
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda r: HTTPResponse(), '/test')
    assert app.router.routes_all['GET'][0].uri == '/test'
    assert app.router.routes_all['GET'][0].name == '<lambda>'

# Generated at 2022-06-18 05:44:54.720947
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:45:13.937789
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # without any error
    app = Sanic("test_RouteMixin_route")
    app.route("/", methods=["GET"])(lambda request: "OK")
    assert app.is_request_stream is False
    assert app.error_handler is None
    assert app.request_middleware is None
    assert app.response_middleware is None
    assert app.websocket_max_size is None
    assert app.websocket_max_queue is None
    assert app.websocket_read_limit is None
    assert app.websocket_write_limit is None
    assert app.websocket_ping_interval is None
    assert app.websocket_ping_timeout is None
    assert app.websocket

# Generated at 2022-06-18 05:45:26.008117
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import add_route
    from sanic.router import get
    from sanic.router import post
    from sanic.router import put
    from sanic.router import patch
    from sanic.router import options
    from sanic.router import head
    from sanic.router import delete
    from sanic.router import websocket

# Generated at 2022-06-18 05:45:36.507902
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test route with no parameters
    # Expected result:
    #   route = Route(uri='/', methods=['GET'], host=None, strict_slashes=None,
    #                 version=None, name=None, static=False, websocket=False,
    #                 stream=False, status_code=None, stream_large_files=False,
    #                 subprotocols=None)
    #   return [route], <function test_RouteMixin_route.<locals>.<lambda> at 0x7f0a3b3e4b70>
    route_mixin = RouteMixin()
    route, func = route_mixin.route()(lambda: None)
    assert isinstance(route, Route)
    assert route.uri == '/'

# Generated at 2022-06-18 05:45:44.545297
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketCommonDisconnect
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 05:45:55.008550
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:46:05.632648
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.name = "test"
            self.strict_slashes = None
            self.routes = []
            self.websocket_routes = []
            self.static_routes = []
            self.middleware = []
            self.error_handler = {}
            self.blueprints = []
            self.request_middleware = []
            self.response_middleware = []
            self.before_start = []
            self.after_start = []
            self.before_stop = []
            self.after_stop = []
            self.before_server_start = []
            self.after_server_start = []
            self.before_server_stop = []
            self.after_server_stop = []


# Generated at 2022-06-18 05:46:17.989908
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_route_version
    from sanic.router import _get_route_version_name

# Generated at 2022-06-18 05:46:29.489008
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge

# Generated at 2022-06-18 05:46:37.818611
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:46:44.889431
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Setup
    app = Sanic(__name__)
    # Test
    @app.route('/')
    def handler(request):
        return text('OK')
    # Verify
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].methods == ['GET', 'HEAD']
    assert app.router.routes_all[0].handler == handler
    assert app.router.routes_all[0].name == 'handler'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all

# Generated at 2022-06-18 05:47:20.099329
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_version
    from sanic.router import _is_coroutine_function
    from sanic.router import _is_

# Generated at 2022-06-18 05:47:30.726973
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import CompositionView
    from sanic.websocket import WebSocketProtocol
    from sanic.router import RouteExists

    class TestRouteMixin(RouteMixin):
        def __init__(self):
            self.routes = []
            self.name = "test"
            self.strict_slashes = False

        def add_route(self, route: Route):
            self.routes.append(route)

    test_route_mixin = TestRouteMixin()
    test_route_mixin.add_route(Route("/", "GET", text("OK")))
    assert test_route_mixin.routes[0].uri == "/"

# Generated at 2022-06-18 05:47:40.846728
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import TooManyRequests
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidHeader


# Generated at 2022-06-18 05:47:52.734488
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:48:03.193536
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNo

# Generated at 2022-06-18 05:48:13.646607
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidHeader
   

# Generated at 2022-06-18 05:48:24.762192
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:48:35.196748
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeHandler
    from sanic.exceptions import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import guess_type
    from sanic.exceptions import FutureStatic
    from sanic.exceptions import stat_async
    from sanic.exceptions import file_stream
    from sanic.exceptions import file
    from sanic.exceptions import wraps
    from sanic.exceptions import partial
    from sanic.exceptions import path

# Generated at 2022-06-18 05:48:44.436428
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for method route of class RouteMixin
    # We will create an instance of RouteMixin
    # and test if the method route works properly
    # by comparing the output of the method with
    # the expected output
    # Create an instance of RouteMixin
    route_mixin_instance = RouteMixin()
    # Create a function to be used as a handler
    def handler_func():
        return "handler_func"
    # Create a list of methods to be used as a parameter
    methods = ["GET", "POST"]
    # Create a list of versions to be used as a parameter
    versions = [1, 2]
    # Create a string to be used as a parameter
    name = "name"
    # Create a boolean to be used as a parameter
    strict_slashes = True
    # Create a boolean to be used as a parameter

# Generated at 2022-06-18 05:48:50.655018
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import ConnectionClosed

# Generated at 2022-06-18 05:49:24.988487
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketCommonState
   

# Generated at 2022-06-18 05:49:34.252662
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    app = Sanic("test_RouteMixin_add_route")
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 1
    app.config.REQUEST_TIMEOUT = 1
    app.config.RESPONSE_TIMEOUT = 1
    app.config.WEBSOCKET_MAX_SIZE = 1
    app.config.WEBSOCKET_MAX_QUEUE = 1
    app.config.WEBSOCKET_READ_LIMIT = 1
    app.config.WEBSOCKET_WRITE_LIMIT = 1
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 1
    app.config.REQUEST_MAX_SIZE = 1

# Generated at 2022-06-18 05:49:46.712770
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTable
    from sanic.router import Router
    from sanic.router import StaticRoute
    from sanic.router import UrlExists
    from sanic.router import UrlReset
    from sanic.router import UrlResetError
    from sanic.router import UrlTable
    from sanic.router import UrlTableError
    from sanic.router import UrlTableReset
    from sanic.router import UrlTableResetError
    from sanic.router import VersionedRoute
    from sanic.router import VersionedRouteExists


# Generated at 2022-06-18 05:49:57.553479
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:50:08.306338
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteRemoved
    from sanic.router import RouteRemovedError
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteRemoved
    from sanic.router import RouteRemovedError
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteRemoved
    from sanic.router import RouteRemovedError
    from sanic.router import RouteExists
    from sanic.router import Route

# Generated at 2022-06-18 05:50:17.731030
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import RouterResetWarning

# Generated at 2022-06-18 05:50:30.629362
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.server import HttpProtocol
    from sanic.response import text
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.server import serve
    from sanic.testing import SanicTestClient
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import MethodNotSupported

# Generated at 2022-06-18 05:50:35.922511
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new RouteMixin object
    route_mixin = RouteMixin()
    # Create a new Route object
    route = Route()
    # Add the route to the route_mixin
    route_mixin.add_route(route)
    # Check if the route is in the route_mixin
    assert route in route_mixin.routes


# Generated at 2022-06-18 05:50:41.576969
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test for method add_route of class RouteMixin
    # Arrange
    app = Sanic('test_RouteMixin_add_route')
    # Act
    app.add_route(handler=app.handle_request, uri='/test_RouteMixin_add_route', methods=['GET'])
    # Assert
    assert app.router.routes_names['/test_RouteMixin_add_route'] == 'test_RouteMixin_add_route'


# Generated at 2022-06-18 05:50:52.729553
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.response import json
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import TooManyRequests
    from sanic.exceptions import HTTPException
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL