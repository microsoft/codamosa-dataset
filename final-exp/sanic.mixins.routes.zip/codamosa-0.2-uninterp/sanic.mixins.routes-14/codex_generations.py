

# Generated at 2022-06-18 05:42:01.214804
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test with valid input
    # Expected result:
    #   return a tuple of routes, decorated function
    #   routes is a list of routes
    #   decorated function is a function
    @RouteMixin.route('/')
    def handler(request):
        return text('OK')
    assert isinstance(handler, function)
    assert isinstance(handler.__route__, list)
    assert isinstance(handler.__route__[0], Route)
    assert handler.__route__[0].uri == '/'
    assert handler.__route__[0].methods == ['GET']
    assert handler.__route__[0].host == None
    assert handler.__route__[0].strict_slashes == None
    assert handler.__route__[0].version == None
    assert handler.__

# Generated at 2022-06-18 05:42:12.723189
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteNotExists
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteNotExists
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteNotExists
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteNotExists
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteNotExists

# Generated at 2022-06-18 05:42:23.947906
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
    from sanic.router import RouteResetError
   

# Generated at 2022-06-18 05:42:30.432874
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a new instance of RouteMixin
    route_mixin = RouteMixin()
    # Create a new instance of Request
    request = Request(b'GET', '/')
    # Create a new instance of HTTPResponse
    response = HTTPResponse()
    # Create a new instance of Route
    route = Route(request, response)
    # Create a new instance of Sanic
    sanic = Sanic()
    # Create a new instance of Sanic
    sanic_1 = Sanic()
    # Create a new instance of Sanic
    sanic_2 = Sanic()
    # Create a new instance of Sanic
    sanic_3 = Sanic()
    # Create a new instance of Sanic
    sanic_4 = Sanic()
    # Create a new instance of Sanic

# Generated at 2022-06-18 05:42:40.491076
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:42:51.318862
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage, FileNotFound
    from sanic.handlers import ContentRangeHandler
    from sanic.handlers import ContentRangeError
    from sanic.handlers import file, file_stream
    from sanic.handlers import stat_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.constants import HTTP_METHODS
    from sanic.constants import HTTP_STATUS_CODES
    from sanic.constants import RE_PATH
    from sanic.constants import RE_URL
    from sanic.constants import RE_URL_WITH_PARAMS
    from sanic.constants import RE_URL

# Generated at 2022-06-18 05:42:54.592789
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(lambda x: x, '/test')
    assert app.router.routes_all[0].uri == '/test'


# Generated at 2022-06-18 05:43:01.008158
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNot

# Generated at 2022-06-18 05:43:10.819159
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteExistsError
    from sanic.router import RouteDoesNotExistError
    from sanic.router import RouteResetError
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:43:17.747788
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:43:42.775312
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import FileStream
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import HTTPResponse
   

# Generated at 2022-06-18 05:43:54.512652
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test case 1
    # Input:
    #   uri = '/test'
    #   handler = 'test'
    #   methods = ['GET']
    #   host = None
    #   strict_slashes = None
    #   version = None
    #   name = None
    #   stream = False
    #   apply = True
    #   websocket = False
    #   expect = None
    # Output:
    #   routes = [<sanic.router.Route object at 0x7f8c3a3c7f60>]
    uri = '/test'
    handler = 'test'
    methods = ['GET']
    host = None
    strict_slashes = None
    version = None
    name = None
    stream = False
    apply = True
    websocket = False

# Generated at 2022-06-18 05:44:06.235101
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists

# Generated at 2022-06-18 05:44:15.688015
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionInfo
    from sanic.router import VersionInfoError
    from sanic.router import VersionInfoWarning
    from sanic.router import _get_handler_name
    from sanic.router import _get_handler_name_from_func

# Generated at 2022-06-18 05:44:27.224898
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteSyntaxError
    from sanic.router import Router
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterResetError
    from sanic.router import VersionedRouterReset
    from sanic.router import VersionedRouterExists
    from sanic.router import VersionedRouterSyntaxError
    from sanic.router import VersionedRouterSyntax
    from sanic.router import VersionedRouterExists
    from sanic.router import Versioned

# Generated at 2022-06-18 05:44:37.456457
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteTableDefError
    from sanic.router import RouteTableError
    from sanic.router import RouteTableFull
    from sanic.router import RouteTableReset
    from sanic.router import RouteTableResetError
    from sanic.router import RouteTableResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterReset
    from sanic.router import RouterResetError
    from sanic.router import RouterResetWarning

# Generated at 2022-06-18 05:44:44.292507
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeHandler
    from sanic.exceptions import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.exceptions import guess_type
    from sanic.exceptions import stat_async
    from sanic.exceptions import file
    from sanic.exceptions import file_stream
    from sanic.exceptions import FutureStatic
    from sanic.exceptions import error_logger
    from sanic.exceptions import sub

# Generated at 2022-06-18 05:44:54.720588
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import StaticRoute
    from sanic.router import UrlMappingExists
    from sanic.router import UrlMappingReset
    from sanic.router import UrlMappingResetError
    from sanic.router import UrlMappingResetWarning
    from sanic.router import UrlMappingWarning
    from sanic.router import Ur

# Generated at 2022-06-18 05:45:00.507053
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.app import Sanic
    app = Sanic()
    app.add_route(text("Hello World!"), '/')
    assert app.router.routes_all[0].uri == '/'
    assert app.router.routes_all[0].handler == text("Hello World!")
    assert app.router.routes_all[0].methods == ['GET']
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].version == None
    assert app.router.routes_all[0].name == None
   

# Generated at 2022-06-18 05:45:07.564360
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import PayloadExpected
    from sanic.exceptions import RequestEntityTooLarge
    from sanic.exceptions import URIT

# Generated at 2022-06-18 05:45:31.266195
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic.app import Sanic
    app = Sanic('test_RouteMixin_static')
    app.static('/test', 'test')
    assert app.router.routes_all[0].uri == '/test/<__file_uri__:path>'
    assert app.router.routes_all[0].name == 'static'
    assert app.router.routes_all[0].host == None
    assert app.router.routes_all[0].strict_slashes == None
    assert app.router.routes_all[0].static == True
    assert app.router.routes_all[0].websocket == False
    assert app.router.routes_all[0].stream == False
    assert app.router.rout

# Generated at 2022-06-18 05:45:32.677258
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: write unit test
    pass


# Generated at 2022-06-18 05:45:41.222794
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test for route method of class RouteMixin
    # Arrange
    uri = '/'
    host = '127.0.0.1'
    methods = ['GET', 'HEAD']
    strict_slashes = False
    version = 1
    name = 'test'
    apply = True
    subprotocols = ['test']
    websocket = True
    # Act
    route = RouteMixin.route(uri, host, methods, strict_slashes, version, name, apply, subprotocols, websocket)
    # Assert
    assert route == (uri, host, methods, strict_slashes, version, name, apply, subprotocols, websocket)


# Generated at 2022-06-18 05:45:52.902635
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a Sanic app
    app = Sanic('test_RouteMixin_add_route')
    # Create a RouteMixin object
    route_mixin = RouteMixin()
    # Create a Sanic app object
    route_mixin.app = app
    # Create a route
    route = Route('/test', host=None, methods=None, strict_slashes=None, version=None, name=None, apply=True)
    # Create a handler
    handler = app.async_route(['GET'], '/test')(lambda request: text('OK'))
    # Add the route to the route_mixin
    route_mixin.add_route(route, handler)
    # Check if the route is added to the route_mixin
    assert route_mixin.routes == [route]
    # Check

# Generated at 2022-06-18 05:46:04.514844
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 05:46:09.806187
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:46:20.278895
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import NotFound
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK

# Generated at 2022-06-18 05:46:26.853450
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterMatchError
    from sanic.router import RouterMatchInfo
    from sanic.router import RouterMatchInfoError
    from sanic.router import RouterMatchInfoNotFound
    from sanic.router import RouterMatchInfoNotFoundError
    from sanic.router import RouterMatchInfoNotFoundError
    from sanic.router import RouterMatchInfoNotFoundError
    from sanic.router import RouterMatchInfoNotFoundError
    from sanic.router import RouterMatchInfoNotFoundError
    from sanic.router import RouterMatchInfoNotFoundError

# Generated at 2022-06-18 05:46:34.236351
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:46:35.690977
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # TODO: write unit test
    pass


# Generated at 2022-06-18 05:46:57.715633
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import VersionedRouter
    from sanic.router import VersionedRouterError
    from sanic.router import VersionedRouterWarning
    from sanic.router import _get_route_name
    from sanic.router import _get_route_name_and_host
    from sanic.router import _get_route_name_and_host_and_

# Generated at 2022-06-18 05:47:05.565444
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteReset
    from sanic.router import Route
    from sanic.router import Router
    from sanic.router import RouteExists
   

# Generated at 2022-06-18 05:47:15.582175
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketPayloadTooBig
    from sanic.websocket import WebSocketConnectionClosed

# Generated at 2022-06-18 05:47:27.136726
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import CompositionView
    from sanic.views import HTTPMethod

# Generated at 2022-06-18 05:47:31.656701
# Unit test for method route of class RouteMixin

# Generated at 2022-06-18 05:47:41.548034
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:47:53.503525
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with default value
    app = Sanic('test_RouteMixin_add_route')
    app.add_route(handler, '/test_RouteMixin_add_route', methods=['GET'])
    assert app.router.routes_all['GET'][0].uri == '/test_RouteMixin_add_route'
    assert app.router.routes_all['GET'][0].name == 'test_RouteMixin_add_route'
    assert app.router.routes_all['GET'][0].strict_slashes == None
    assert app.router.routes_all['GET'][0].host == None
    assert app.router.routes_all['GET'][0].version == None

# Generated at 2022-06-18 05:48:01.532806
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteResetError
    from sanic.router import RouteResetWarning
    from sanic.router import RouteTable
    from sanic.router import RouteTableError
    from sanic.router import RouteTableWarning
    from sanic.router import Router
    from sanic.router import RouterError
    from sanic.router import RouterWarning
    from sanic.router import SanicRoute
    from sanic.router import SanicRouteError
    from sanic.router import SanicRouteWarning
    from sanic.router import UrlForError
    from sanic.router import UrlForWarning

# Generated at 2022-06-18 05:48:12.416473
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic("test_RouteMixin_add_route")
    route = app.add_route("/", lambda x: x)
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.host == None
    assert route.strict_slashes == None
    assert route.version == None
    assert route.name == None
    assert route.websocket == False
    assert route.stream == False
    assert route.static == False

# Generated at 2022-06-18 05:48:24.250208
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent

# Generated at 2022-06-18 05:48:46.235998
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Test with a valid route
    app = Sanic('test_RouteMixin_add_route')
    @app.route('/')
    async def handler(request):
        return text('OK')
    assert app.router.routes_all['GET'][0].uri == '/'
    assert app.router.routes_all['GET'][0].name == 'handler'
    assert app.router.routes_all['GET'][0].handler == handler
    assert app.router.routes_all['GET'][0].strict_slashes is None
    assert app.router.routes_all['GET'][0].host is None
    assert app.router.routes_all['GET'][0].version is None
    assert app.router.routes_

# Generated at 2022-06-18 05:48:49.327768
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    app = Sanic('test_RouteMixin_add_route')
    request, response = app.test_client.get('/')
    assert response.status == 404
    @app.route('/')
    def handler(request):
        return response
    request, response = app.test_client.get('/')
    assert response.status == 200


# Generated at 2022-06-18 05:48:55.366221
# Unit test for method add_route of class RouteMixin

# Generated at 2022-06-18 05:49:02.794508
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import StreamBuffer
    from sanic.views import StreamBody
    from sanic.views import StreamFile
    from sanic.views import StreamFileWrapper
    from sanic.views import StreamHTTPResponse
    from sanic.views import StreamText
    from sanic.views import StreamUploadedFile
    from sanic.views import StreamUploadedFiles
    from sanic.views import StreamUploadedMultiDict
    from sanic.views import StreamUploadedMultiDicts
    from sanic.views import StreamUploadedSingleDict
   

# Generated at 2022-06-18 05:49:14.156168
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketReader


# Generated at 2022-06-18 05:49:16.082261
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    # TODO: write unit test for method static of class RouteMixin
    pass


# Generated at 2022-06-18 05:49:26.172365
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import InvalidRangeType
    from sanic.exceptions import InvalidRangeValue
    from sanic.exceptions import InvalidRangeFormat
    from sanic.exceptions import InvalidRange
    from sanic.exceptions import RangeNotSatisfiable
    from sanic.exceptions import InvalidRangeUnit
    from sanic.exceptions import InvalidRangeNoSuffix
    from sanic.exceptions import InvalidRangeInvalidByteRange
    from sanic.exceptions import InvalidRangeInvalidSuffix

# Generated at 2022-06-18 05:49:34.547244
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset

# Generated at 2022-06-18 05:49:47.060351
# Unit test for method static of class RouteMixin
def test_RouteMixin_static():
    from sanic import Sanic
    from sanic.router import Route
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ContentRangeError
    from sanic.exceptions import HeaderNotFound
    from sanic.response import StreamingHTTPResponse
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import guess_type
    from sanic.response import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.response import ContentRangeHandler
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteDoesNotExist


# Generated at 2022-06-18 05:49:58.198296
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
   

# Generated at 2022-06-18 05:50:19.340384
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:50:32.217553
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import NotFound
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ServerError
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge

# Generated at 2022-06-18 05:50:41.769269
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import RouteReset
    from sanic.router import Route

# Generated at 2022-06-18 05:50:52.899178
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.router import RouteExists
    from sanic.router import RouteDoesNotExist

    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMixin
    # test for method route of class RouteMix

# Generated at 2022-06-18 05:51:03.974640
# Unit test for method add_route of class RouteMixin
def test_RouteMixin_add_route():
    # Create a mock object of class Sanic
    app = Sanic(__name__)
    # Create a mock object of class RouteMixin
    router = RouteMixin(app)
    # Create a mock object of class Route

# Generated at 2022-06-18 05:51:14.213548
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    from sanic.router import Route
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNotExist
    from sanic.router import RouteExists
    from sanic.router import RouteReset
    from sanic.router import Router
    from sanic.router import RouteDoesNot

# Generated at 2022-06-18 05:51:25.113249
# Unit test for method route of class RouteMixin
def test_RouteMixin_route():
    # Test case 1
    # Test if the method route of class RouteMixin can be called
    # without any error
    app = Sanic(__name__)
    app.route('/')(lambda request: HTTPResponse())
    # Test case 2
    # Test if the method route of class RouteMixin can be called
    # without any error
    app = Sanic(__name__)
    app.route('/', methods=['GET'])(lambda request: HTTPResponse())
    # Test case 3
    # Test if the method route of class RouteMixin can be called
    # without any error
    app = Sanic(__name__)
    app.route('/', methods=['GET'], host='127.0.0.1')(lambda request: HTTPResponse())
    # Test case 4
   