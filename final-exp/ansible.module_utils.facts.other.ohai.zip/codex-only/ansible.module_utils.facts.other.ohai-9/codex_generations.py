

# Generated at 2022-06-23 00:16:47.088869
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Test function collect of OhaiFactCollector class
    pass

# Generated at 2022-06-23 00:16:57.717225
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils._text import to_bytes
    fact_collector = OhaiFactCollector()
    class test_module():
        def find_executable(module, executable):
            return executable
        def get_bin_path(module, executable):
            return executable
        def run_command(module, ohai_path):
            return 0, '{"test": "answer"}', ''
    module = test_module()
    expected_result = to_bytes("""{
    "test": "answer"
}
""")
    result = fact_collector.get_ohai_output(module)
    assert result == expected_result

# Generated at 2022-06-23 00:17:02.227188
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_path = "/usr/bin/ohai"
    rc, out, err = run_command(ohai_path)
    print(rc, out, err)

    if rc != 0:
        return None


# Generated at 2022-06-23 00:17:04.749886
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai = OhaiFactCollector()
    assert isinstance(ohai, OhaiFactCollector)
    assert isinstance(ohai, BaseFactCollector)


# Generated at 2022-06-23 00:17:06.503920
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    obj = OhaiFactCollector()
    assert obj.name == 'ohai'
    assert obj.collect() == {}


# Generated at 2022-06-23 00:17:15.893511
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Mock the module class
    module = MockModule()

    # Instantiate an instance of the fact class
    fact = OhaiFactCollector()

    # Build fact data dict and fact_list from fact class collect method
    fact_data = fact.collect(module=module)

    assert ('test_data' in fact_data)
    assert ('test_data2' in fact_data['test_data'])
    assert (fact_data['test_data']['test_data2'] == \
        'test_data2_value')

    assert ('test_data3' in fact_data)
    assert (fact_data['test_data3'] == 'test_data3_value')



# Generated at 2022-06-23 00:17:26.689348
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import tempfile

    # A class that mocks the BaseFactCollector methods for the sole purpose of testing run_ohai
    class MockOhaiFactCollector(OhaiFactCollector):
        name = 'mock_ohai'
        _fact_ids = set()

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='ohai',
                                            prefix='ohai_')
            super(MockOhaiFactCollector, self).__init__(collectors=collectors,
                                                        namespace=namespace)

        def find_ohai(self, module):
            return '/bin/true'

        def run_command(self, command):
            return 0, b'{"foo":"bar"}', b''

    # A class that mocks the 'get

# Generated at 2022-06-23 00:17:35.667216
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class Module(object):
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc


# Generated at 2022-06-23 00:17:44.711798
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'
    assert o.collectors == []
    assert 'ohai_' == o.namespace.prefix

    # Test an OhaiFactCollector()'s "collect" method
    def run_ohai(self, module, ohai_path,):
        rc, out, err = (0, '{"hello": "world"}', '')
        return rc, out, err

    o.run_ohai = run_ohai
    fake_module = FakeModule()
    facts = o.collect(module=fake_module)
    assert facts == {'hello': 'world'}



# Generated at 2022-06-23 00:17:56.003635
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    test_module = AnsibleModule(argument_spec={})
    test_ohai_path = "/usr/bin/ohai"
    test_output = '{"foo": "bar"}'

    # Mock the ohai run_command
    test_module.run_command = Mock(return_value=(0, test_output, "") )

    test_OhaiFactCollector = OhaiFactCollector(collectors=[], namespace=PrefixFactNamespace(namespace_name='ohai', prefix='ohai_'))

    # Call the ohai run_command
    rc, out, err = test_OhaiFactCollector.run_ohai(test_module, test_ohai_path)

    # Assert that the run_command was invoked

# Generated at 2022-06-23 00:18:04.932479
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    class MockAnsibleModule(object):
        def __init__(self):
            self._tmp = '/tmp/'
            self._return = {}
            self._ansible_tmp = '/tmp/'
            self._ansible_moduledir = './'

        def get_bin_path(self, path, raise_errors=True):
            return '/usr/bin/' + path

        def run_command(self, cmd):
            return 0, '{"a": "b"}', ''

    class MockFactCollector(object):
        def __init__(self):
            self.namespace = PrefixFactNamespace(namespace_name='ohai',
                                                 prefix='ohai_')

    ohai_fc = OhaiFactCollector()

# Generated at 2022-06-23 00:18:07.029907
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_collector = OhaiFactCollector()
    assert (ohai_collector.name == 'ohai')
    assert (ohai_collector._fact_ids == set())

# Generated at 2022-06-23 00:18:15.842205
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.utils import ModuleFinder
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors

    module = ModuleFinder.find_default_ansible_module('setup', mod_type='core')
    facts_collector = FactsCollector(module=module,
                                     collector_classes=default_collectors)
    ohai_facts = facts_collector.collect_facts()
    assert 'ohai' in ohai_facts

# Generated at 2022-06-23 00:18:17.146175
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    assert True


# Generated at 2022-06-23 00:18:28.096648
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    def mock_run_command(path):
        class DummyReturn:
            pass
        dret = DummyReturn()
        dret.returncode = 0
        dret.stdout = "{\"foo\": \"bar\"}"
        dret.stderr = ""
        return dret

    def mock_get_bin_path(filename):
        if filename == 'ohai':
            return '/path/to/ohai'
        return None

    class OhaiModule:
        def get_bin_path(self, a):
            return mock_get_bin_path(a)

        def run_command(self, a):
            return mock_run_command(a)

    class DummyFacts:
        def __init__(self):
            self.ohai = {}

        def get(self, a):
            return self

# Generated at 2022-06-23 00:18:33.470626
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Create an OhaiFactCollector with a mocked module
    class MockModule(object):
        def get_bin_path(self, name):
            if name == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None

    collector = OhaiFactCollector(None, None)
    ohai_path = collector.find_ohai(MockModule())
    assert ohai_path == '/usr/bin/ohai'


# Generated at 2022-06-23 00:18:35.759629
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'
    assert o._fact_ids == set()

# Generated at 2022-06-23 00:18:47.960442
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import sys
    import os
    import tempfile
    import mock
    import contextlib
    import StringIO

    dAll = {
        'stdout': """{
            "system": "linux"
        }""",
        'stderr': '',
        'rc': 0,
    }

    def run_command(cmd, *args, **kwargs):
        return (dAll['rc'], dAll['stdout'], dAll['stderr'])

    @contextlib.contextmanager
    def guard_cwd(path=None):
        old_cwd = os.getcwd()
        if path is not None:
            os.chdir(path)
        yield
        os.chdir(old_cwd)


# Generated at 2022-06-23 00:18:56.820542
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    """ validate run_ohai function of OhaiFactCollector """
    class FauxModule(object):
        def get_bin_path(self, arg):
            return "/bin/ohai"

        def run_command(self, arg):
            if arg != "/bin/ohai":
                raise Exception("Exception")
            return 0, '{"key": "value"}', ""

    module = FauxModule()

    fact_collector = OhaiFactCollector()
    rc, out, err = fact_collector.run_ohai(module, "/bin/ohai")
    assert rc == 0
    assert out == '{"key": "value"}'
    assert err == ""

# Generated at 2022-06-23 00:18:57.654976
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    assert OhaiFactCollector().name == 'ohai'

# Generated at 2022-06-23 00:18:58.872532
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    pass


# Generated at 2022-06-23 00:19:01.993350
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    m = AnsibleModule(argument_spec={})
    oc = OhaiFactCollector()
    oc.run_ohai(m, '/usr/bin/ohai')


# Generated at 2022-06-23 00:19:04.280928
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_facts = OhaiFactCollector(namespace='ohai')
    assert ohai_facts.name == 'ohai'

# Generated at 2022-06-23 00:19:14.656279
# Unit test for method collect of class OhaiFactCollector

# Generated at 2022-06-23 00:19:21.823272
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector as facts_collector
    import ansible.module_utils.facts.utils as facts_utils
    import ansible.module_utils.facts.namespace as facts_namespace
    import ansible.module_utils.basic as module_utils

    # Create a mock AnsibleModule
    mock_ansible_module = module_utils.AnsibleModule(argument_spec={})

    # Create a subclass of AnsibleModule for testing purposes
    class MockAnsibleModule(mock_ansible_module.__class__):
        def __init__(self, *args, **kwargs):
            super(MockAnsibleModule, self).__init__(*args, **kwargs)
            self.real_params = self.params


# Generated at 2022-06-23 00:19:32.671564
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''Unit test for method run_ohai of class OhaiFactCollector.'''
    from ansible.module_utils.facts import OhaiFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        '''A fake AnsibleModule used for unit test.'''
        def __init__(self):
            self.params = {}

        def get_bin_path(self, bin_path):
            return '/bin/ohai'


# Generated at 2022-06-23 00:19:39.639174
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.subcollectors.insert(0, OhaiFactCollector())
    module = ModuleMock('notimportant')
    ohai_collector = OhaiFactCollector(namespace=ansible_collector.namespace)
    ohai_output = ohai_collector.get_ohai_output(module)
    assert ohai_output is not None

# Generated at 2022-06-23 00:19:44.663580
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    collector = OhaiFactCollector()
    # The method collect of the collector is used by the AnsibleModule.collect_facts method
    # in the module. The AnsibleModule class is not available in the test, so
    # pass a test class as an argument instead.
    results = collector.collect(module=None)
    assert results == {}

# Generated at 2022-06-23 00:19:55.984002
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.ohai

    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.args = []

        def get_bin_path(self, param):
            # case 1
            if param == 'ohai' and self.params['ohai_path'] == 'ohai_pth':
                return 'ohai_pth'
            # case 2
            elif param == 'ohai' and self.params['ohai_path'] == 'not_ohai_pth':
                return ''

            # case 3

# Generated at 2022-06-23 00:19:58.265518
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'
    assert o._fact_ids == set()

# Generated at 2022-06-23 00:20:06.676511
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    '''
    Test for the OhaiFactCollector method find_ohai
    '''

    # Empty module object
    module = {}

    # Empty get_bin_path
    def get_bin_path(self, path):
        return None

    # Add get_bin_path to module
    module['get_bin_path'] = get_bin_path

    # Initialize an instance of OhaiFactCollector
    ohai_fact_collector = OhaiFactCollector()

    # Initialize the expected output
    expected_output = None

    # Call method find_ohai of class OhaiFactCollector with module
    actual_output = ohai_fact_collector.find_ohai(module)

    # Assert expected output and actual output are equal
    assert expected_output == actual_output


# Generated at 2022-06-23 00:20:10.657132
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    ohai_fact_collector = OhaiFactCollector()
    ohai_output = ohai_fact_collector.get_ohai_output(ansible.module_utils.facts.collector.BaseFactCollector)
    assert(ohai_output is not None)

# Generated at 2022-06-23 00:20:22.286635
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # This test checks if run_ohai function returns a non-zero RC without
    # clobbering the output.
    # Steps:
    #       1. run_ohai with a path which doesn't exist.
    #       2. Verify RC is non-zero.
    #       3. Verify the output is empty.
    class TestModule:
        def __init__(self):
            self.stdout = ''
            self.stderr = ''
            self.rc = 0

        def get_bin_path(self, _):
            return '/foo/bar/baz'

        def run_command(self, path):
            self.stdout = ''
            self.stderr = 'ohai: command not found'
            self.rc = 127
            return self.rc, self.stdout, self.stderr



# Generated at 2022-06-23 00:20:29.940598
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
   from ansible.module_utils.facts.collector.ohai import OhaiFactCollector

   from ansible.module_utils.basic import AnsibleModule

   from ansible.module_utils.facts.namespace import PrefixFactNamespace

   module = AnsibleModule()
   fact_collector = OhaiFactCollector()

   expected = {'platform_version': '19.04', 'platform': 'ubuntu', 'os': 'linux', 'hostname': 'test', 'ipaddress': '127.0.0.1', 'kernel': 'linux'}

   actual = fact_collector.get_ohai_output(module)
   actual = json.loads(actual)

   assert expected == actual

# Generated at 2022-06-23 00:20:33.212409
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_path = '/usr/bin/ohai'
    ohai_output_mock = '{ "platform": "mock_platform" }'

    OhaiFactCollector._find_ohai = lambda s, x: ohai_path
    OhaiFactCollector._run_ohai = lambda s, x, y: (0, ohai_output_mock, '')

    m = MockModule()
    o = OhaiFactCollector()

    assert o.get_ohai_output(m) == ohai_output_mock



# Generated at 2022-06-23 00:20:43.104931
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.basic
    from ansible.module_utils.facts.collector.constants import ModuleDeprecationWarning
    from ansible.module_utils.facts import get_collector_class

    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModuleMock
    FactCollector = get_collector_class(['OhaiFactCollector', 'FacterFactCollector'])
    warnings.simplefilter('error', ModuleDeprecationWarning)
    mock_module = ansible.module_utils.basic.AnsibleModuleMock('setup', '', {})
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.get_ohai_output(mock_module)

# Generated at 2022-06-23 00:20:50.234085
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    kwargs = dict(
        module = dict(
            get_bin_path = dict(
                return_value = 'ohai_path'
            ),
            run_command = dict(
                return_value = (0, '{"foo": "bar"}', '')
            )
        )
    )
    ohai_facts = CollectionFacts(**kwargs).get_facts()
    assert(ohai_facts['foo'] == 'bar')



# Generated at 2022-06-23 00:21:00.107671
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # If class OhaiFactCollector is instantiated with a module,
    # calls to module.get_bin_path and module.run_command work.
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/path/ohai'

        def run_command(self, *args, **kwargs):
            return 0, '{}', None

    ohai_fact_collector = OhaiFactCollector(module=MockModule())

    assert ohai_fact_collector.get_ohai_output(ohai_fact_collector.module) == '{}'

    # If no module is provided, None is returned.
    ohai_fact_collector = OhaiFactCollector()


# Generated at 2022-06-23 00:21:06.400298
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from io import BytesIO

    class FakeModule(object):
        def get_bin_path(self, prog, opts=None, required=False):
            assert prog == 'ohai'
            return '/bin/ohai'

        def run_command(self, cmd, check_rc=True):
            assert cmd == ['/bin/ohai']
            return 0, 'fake_ohai_output', None

    module = FakeModule()

    collector = OhaiFactCollector()
    facts = collector.collect(module=module)
    assert facts == collector.collect(module=module)


# Generated at 2022-06-23 00:21:10.472143
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai = OhaiFactCollector()
    assert ohai.name == 'ohai'
    assert ohai._fact_ids == set()
    assert OhaiFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:21:12.484977
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai = OhaiFactCollector()

    assert ohai.find_ohai(ohai)


# Generated at 2022-06-23 00:21:17.472000
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import os
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content
    from ansible.module_utils._text import to_bytes

    content = '{"languages":{"ruby":{"target_vendor":"unknown","target_version":"2.4.3","target_cpu":"x86_64-darwin16","host_vendor":"apple","host_version":"2.4.3","host_cpu":"x86_64-darwin17"}}}'
    dummy_out = '/tmp/out'
    dummy_rc = 0
    if os.path.exists(dummy_out):
        os.remove(dummy_out)


# Generated at 2022-06-23 00:21:26.045600
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    """Tests simple get_ohai_output of OhaiFactCollector
    """

    class module_test:
        def get_bin_path(self, ohai):
            return "./ohai"

        def run_command(self, ohai_path):
            return ohai_path

    obj = OhaiFactCollector()

    expected_out = "./ohai"

    out = obj.get_ohai_output(module_test())

    print("Expected output: %s" % expected_out)
    print("Actual output: %s" % out)

    assert out == expected_out

# Generated at 2022-06-23 00:21:26.934683
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 00:21:34.885617
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import timeout

    # Create instance of OhaiFactCollector
    ohai_collector = get_collector_instance('OhaiFactCollector')
    # Create, configure, run and get output of Module(s)
    ohai_output = get_file_content(
        '.travis/mock_data/',
        'ohai_output.json',
        timeout(10, 1)
    )
    # Compare it to the mocked Ohai output
    assert ohai_collector.run_ohai(
        None, None
    ) == (0, ohai_output, '')

# Generated at 2022-06-23 00:21:43.409180
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    class _module:
        def get_bin_path(self, path):
            return "fakepath/ohai"

        def run_command(self, cmd):
            return 0, '{"foo":"bar"}', ''

    ohai_path = _module()
    module = _module()
    ohai = OhaiFactCollector(collectors=[ohai_path])
    rc, out, err = ohai.run_ohai(module, ohai_path)
    assert rc == 0
    assert out == '{"foo":"bar"}'
    assert err == ''



# Generated at 2022-06-23 00:21:44.036879
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    assert OhaiFactCollector()

# Generated at 2022-06-23 00:21:47.184927
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    '''Test the constructor of class OhaiFactCollector'''
    ohai = OhaiFactCollector()
    assert ohai.name == 'ohai'
    assert hasattr(ohai, '_fact_ids')
    assert hasattr(ohai, '_module')
    assert hasattr(ohai, '_namespace')
    assert ohai._namespace.name == 'ohai'
    assert ohai._namespace.prefix == 'ohai_'


# Generated at 2022-06-23 00:21:53.945984
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    fc = FactCollector(
        [OhaiFactCollector()],
    )

    f = fc.collect(
        module=MockModule()
    )

    assert isinstance(f, dict)
    assert 'ohai' in f
    assert 'ohai_version' in f['ohai']
    assert 'ohai_kernel' in f['ohai']


# Mock class used in the unit test of OhaiFactCollector

# Generated at 2022-06-23 00:22:05.194708
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    params = {}
    params['ansible_module_mock'] = OhaiFactCollector(module=None, params=params)

# Generated at 2022-06-23 00:22:13.316012
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector

    # Stubbing command execution
    def run_command(self, cmd):
        return 0, '{"test_ohai_json": true}', ''

    ansible.module_utils.facts.collector.AnsibleModule.run_command = run_command

    # Testing the result of get_ohai_output method
    ofc = OhaiFactCollector()
    assert 'test_ohai_json' in ofc.get_ohai_output(ansible.module_utils.facts.collector.AnsibleModule())

# Generated at 2022-06-23 00:22:20.600625
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # mock module
    class MockModule(object):
        def get_bin_path(self, bin_name):
            return "/usr/bin/ohai"

        def run_command(self, cmd):
            return 0, "{\"foo\": \"bar\"}", ""

    mock_module = MockModule()

    ohai_collector = OhaiFactCollector()
    collected_facts = ohai_collector.collect(mock_module)

    assert collected_facts == {'ohai_foo': 'bar'}

# Generated at 2022-06-23 00:22:22.830526
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    assert OhaiFactCollector(collectors=None,
                             namespace=None) is not None


# Generated at 2022-06-23 00:22:31.320391
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts. ohai_collector import OhaiFactCollector, test_OhaiFactCollector_run_ohai
    import oa_test
    test_module, test_commands = oa_test.setup_testclass(OhaiFactCollector)
    test_object = OhaiFactCollector(namespace=PrefixFactNamespace(namespace_name='test', prefix='test'))

    oa_test.run_testmethod(test_object, test_module, test_commands, 'run_ohai')

# Generated at 2022-06-23 00:22:42.521326
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic

    mock_module = basic.AnsibleModule(
        argument_spec=dict())

    mock_module.run_command = lambda *a, **kwargs: (0, '{}', '')
    mock_module.get_bin_path = lambda *a, **kwargs: '/usr/bin/ohai'

    ohai_fact_collector = OhaiFactCollector()

    rc, out, err = ohai_fact_collector.run_ohai(mock_module, '/usr/bin/ohai')
    assert rc == 0
    assert out == '{}'
    assert err == ''


# Generated at 2022-06-23 00:22:52.913637
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    OHAI_PATH = "ansible.module_utils.ohai.fake_ohai"

# Generated at 2022-06-23 00:22:59.652331
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    """
    Test if the find_ohai() method returns the correct path to
    ohai when it's available.
    """
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})

    ohai_fact_collector = OhaiFactCollector()
    ohai_path = ohai_fact_collector.find_ohai(test_module)

    assert ohai_path == "/usr/bin/ohai"

# Generated at 2022-06-23 00:23:02.516148
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    '''Test class OhaiFactCollector'''
    OhaiFactCollector()
    OhaiFactCollector(namespace='ohai')
    OhaiFactCollector(collectors=None, namespace='ohai')

# Generated at 2022-06-23 00:23:10.298894
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module_mock = ModuleMock()
    ohai_collector = OhaiFactCollector()
    test_rc = 0
    test_out = '{"kernel": {"name": "Darwin"}, "languages": {"golang": {"target_cpu": "x86_64", "target_os": "darwin"}}}'
    test_err = ''
    rc, out, err = ohai_collector.run_ohai(module_mock, '/usr/bin/ohai')

    assert rc == test_rc
    assert out == test_out
    assert err == test_err


# Generated at 2022-06-23 00:23:15.132636
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai_fact_collector = OhaiFactCollector()
    collected_facts = ohai_fact_collector.collect(module)
    assert collected_facts == {'kernel': {'name': 'Linux', 'machine': 'x86_64'}}


# Generated at 2022-06-23 00:23:25.152224
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    collectors = [OhaiFactCollector()]

    module = AnsibleModule(argument_spec=dict(),
                           supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value=None)
    module.run_command = MagicMock(side_effect=Exception("Should not be called"))
    fact_collector = Facts(module=module,
                           collectors=collectors)
    fact_collector.collect(module=module)

    module.get_bin_path.assert_called_once_with('ohai')
    assert not module.run_command.called

    module.get_bin_path.reset_mock()
    module.get_bin_path.return_value = '/usr/bin/ohai'
    module.run_command.side_effect = None

# Generated at 2022-06-23 00:23:34.890324
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    facts = {
        'ohai_os': {
            'name': 'Ubuntu'
        },
        'ohai_memory': {
            'total': '3904MB',
            'free': '3049MB'
        }
    }

    class MockModule(object):

        def __init__(self):
            self.params = {'module_setup': True}

        def _executable_exists(self, executable):
            if executable == 'ohai':
                return True
            else:
                return False

        def get_bin_path(self, executable_name):
            if executable_name == 'ohai':
                return '/usr/local/bin/ohai'


# Generated at 2022-06-23 00:23:46.090373
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import sys
    from ansible.module_utils.facts.collector import FactsCollector
    fact_collector = FactsCollector()

    # No such module of the module
    ohai_collector = OhaiFactCollector()
    result = ohai_collector.get_ohai_output(None)
    assert result is None

    # No ohai command in module path
    ohai_collector = OhaiFactCollector()
    result = ohai_collector.get_ohai_output(fact_collector)
    assert result is None

    # ohai command run successfully
    def mock_get_bin_path(self, name):
        return name


# Generated at 2022-06-23 00:23:48.215588
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai = OhaiFactCollector()
    assert ohai.name == 'ohai'


# Generated at 2022-06-23 00:23:59.638425
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # case 1: ohai_path is a working file name, in this case it will return 0,
    # the output of command ohai and no errors
    ohai_path = 'test/test_ohai_file'
    # module is the mock value of module
    module = {
        'get_bin_path': lambda *arg, **kwargs: ohai_path,
        'run_command': lambda *arg, **kwargs: (0, '{"os":"Linux"}', '')}
    # initialize the object
    collector = OhaiFactCollector()
    # run the method
    rc, out, err = collector.run_ohai(module, ohai_path)
    # check if rc is expected
    assert rc == 0
    # check if out is expected
    assert out == '{"os":"Linux"}'
    # err is

# Generated at 2022-06-23 00:24:05.622929
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    collectors = None
    namespace = None
    ohai_facts = OhaiFactCollector(collectors=collectors, namespace=namespace)
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/ohai'
    ohai_path = ohai_facts.find_ohai(module)
    assert ohai_path == '/usr/bin/ohai'


# Generated at 2022-06-23 00:24:15.595833
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():

    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.collector.ohai import test_OhaiFactCollector_find_ohai

    class TestAnsibleModule:

        # fake AnsibleModule that has a .get_bin_path method
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/' + name

    c = OhaiFactCollector()
    assert c.find_ohai(TestAnsibleModule()) == '/usr/bin/ohai'



# Generated at 2022-06-23 00:24:25.884968
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    fc = ansible.module_utils.facts.collector.BaseFactCollector(
        collectors=None,
        namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(
            namespace_name='ohai',
            prefix='ohai_')
        )
    fc._module = ansible.module_utils.facts.TestModule(
        **{}
    )
    assert( isinstance(fc.get_ohai_output(), str) )


# Generated at 2022-06-23 00:24:27.862622
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'

# Generated at 2022-06-23 00:24:39.226163
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    try:
        # test default ohai path
        oc = OhaiFactCollector()
        assert oc.find_ohai(None) == "/usr/bin/ohai"

        # test ohai path in facter paths
        os.environ['PATH'] = tmpdir + ":" + os.environ['PATH']
        shutil.copy("/usr/bin/ohai", tmpdir + "/ohai")

        oc = OhaiFactCollector()
        assert oc.find_ohai(None) == tmpdir + "/ohai"
    finally:
        os.remove(tmpdir + "/ohai")
        os.rmdir(tmpdir)


# Generated at 2022-06-23 00:24:45.323531
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # Unit test for class OhaiFactCollector
    # Method find_ohai
    # Return an empty dictionary since ohai is not present in PATH
    ohai_path = OhaiFactCollector.find_ohai(Facts.collectors['ohai'],
                                            module)
    assert ohai_path is None



# Generated at 2022-06-23 00:24:47.378038
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ''' Unit test for method find_ohai of class OhaiFactCollector '''
    pass


# Generated at 2022-06-23 00:24:58.105063
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.collector as module_collector
    import ansible.module_utils.facts.utils as module_utils

    ohai_fact_collector = OhaiFactCollector()

    # Mock the file path of ohai
    mocked_module = module_utils.ModuleStub(
        path='/home/ansible/.ansible/plugins/module_utils/ohai',
        bin_ansible_callbacks=True,
        bin_path="/home/ansible/.ansible/plugins/module_utils/ohai",
    )

    result_ohai_path = ohai_fact_collector.find_ohai(mocked_module)
    assert result_ohai_path == '/home/ansible/.ansible/plugins/module_utils/ohai'

    # Mock the file path of oh

# Generated at 2022-06-23 00:24:59.822085
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o_fac = OhaiFactCollector()
    assert o_fac.name =="ohai"

# Generated at 2022-06-23 00:25:08.933466
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_path = 'tests/unit/module_utils/facts/fixtures/ohai'

    # Check that a fake ohai path is detected
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: ohai_path
    collector = OhaiFactCollector()
    assert collector.find_ohai(module) == ohai_path

    # Check that not finding ohai is detected
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: None
    collector = OhaiFactCollector()
    assert collector.find_ohai(module) is None



# Generated at 2022-06-23 00:25:20.422783
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    """
    Check the facts that OhaiFactCollector.collect() returns are non-zero.
    """
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock

    src_facts = {'dummy_fact': 'dummy_fact_value'}
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/ohai'
    module.run_command.return_value = (0, '{"fqdn": "example.com", "ohai_time": 0.003947033958435059}', '')
    ohai_fact_collector = OhaiFactCollector(module=module)
    collected_facts = ohai_fact_collector.collect(module, src_facts)

# Generated at 2022-06-23 00:25:28.079274
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class args_mock:
        def __init__(self):
            self.no_log = True

    class module_mock:
        def __init__(self):
            self.run_command = lambda x: (0, '/usr/bin/ohai', None)
            self.get_bin_path = lambda x: '/usr/bin/ohai'
    module_mock_instance = module_mock()

    ofc = OhaiFactCollector()
    assert ofc.find_ohai(module_mock_instance) == '/usr/bin/ohai'

# Generated at 2022-06-23 00:25:38.540672
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import os
    import json

    def get_bin_path(self, name):
        return name

    def run_command(self, name):
        if name == 'ohai':
            return 0, ohai_json, ''
        elif name == 'ohai_no_data':
            return 0, '', ''

    class TestAnsibleModule:
        def __init__(self, params=None):
            pass

        def get_bin_path(self, name):
            return name

        def run_command(self, name):
            if name == 'ohai':
                return 0, ohai

# Generated at 2022-06-23 00:25:46.927003
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    """Test whether collect method returns correct data.
    """
    # initialize class instance
    test_collector = OhaiFactCollector()

    # mock module and its functions
    module = ansible.module_utils.facts.__dict__['AnsibleModule']
    mock_module = ansible.module_utils.facts.AnsibleModule(argument_spec=dict())

    get_bin_path_patch = Mock(return_value='/usr/bin/ohai')
    run_command_patch = Mock(return_value=(0, '{"platform": "mac_os_x", "platform_version": "10.14.5", "os": "darwin"}', None))

    mock_module.get_bin_path = get_bin_path_patch
    mock_module.run_command = run_command_patch

    # execute

# Generated at 2022-06-23 00:25:57.318976
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class Module(object):
        def __init__(self):
            self.get_bin_path_calls = 0

        def get_bin_path(self, name, required=False):
            self.get_bin_path_calls += 1
            if name == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None

    class FakeFactsDict(dict):
        def __init__(self):
            pass

        def add_ohai_fact(self, name, value):
            pass

    test_module = Module()
    test_facts = FakeFactsDict()
    ohai_facts = OhaiFactCollector()
    test_facts.update(ohai_facts.collect(test_module))

    assert ohai_facts.find_ohai(test_module)

# Generated at 2022-06-23 00:26:04.381946
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    ohai_fact_collector_obj = OhaiFactCollector([], {})
    module.run_command = lambda _: (0,
                                    '/usr/bin/ohai',
                                    '')
    rc = ohai_fact_collector_obj.find_ohai(module)
    assert rc == '/usr/bin/ohai'


# Generated at 2022-06-23 00:26:06.685842
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohaiFactCollector = OhaiFactCollector()
    assert ohaiFactCollector != None


# Generated at 2022-06-23 00:26:17.584453
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # Test run_ohai() when command returns non zero exit status
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts import ansible_collector
    facts = ansible_collector.get_all_facts(module_utils.AnsibleModuleMock({}), 'all')
    ohai_output = facts['ohai']
    assert isinstance(ohai_output, (dict,))
    ok = False
    for key in ohai_output:
        if 'platform' in key:
            ok = True
            break
    assert ok

if __name__ == '__main__':
    # Unit test for class OhaiFactCollector
    test

# Generated at 2022-06-23 00:26:24.147212
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    def run_ohai_stub(path):
        print(json.dumps({'test_ohai': 'test'}))
    ohai = OhaiFactCollector()
    module = dict(run_command=run_ohai_stub)
    rc, out, err = ohai.run_ohai(module, None)
    assert rc == 0
    assert err == ''
    assert out == "{'test_ohai': 'test'}"

# Generated at 2022-06-23 00:26:27.381209
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    module = None
    fact_collector = OhaiFactCollector(module)
    assert fact_collector.module == module
    assert fact_collector.name == 'ohai'
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-23 00:26:28.690804
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    assert OhaiFactCollector().find_ohai

# Generated at 2022-06-23 00:26:39.771572
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector

    # This is a possible output of the command 'ohai'
    test_ohai_output = '{"test_ohai_output": "test_ohai_output"}'

    # This is a test Collector instance
    test_collector = OhaiFactCollector()

    # This is a test Facts object that has test_collector as a collector and
    # is used to provide the base methods (fetch_file, get_bin_path and run_command)
    test_facts = Facts(collectors=[test_collector])

    # This is a test Python module object and is used to provide the test_collector with
    # the needed methods (fetch_file, get_bin_path and

# Generated at 2022-06-23 00:26:50.043313
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import FactsCollector

    tests = [
        '{"foo": {"bar": "baz"}}',
        '{"foo": {"bar": ["baz", {"qux": 1}]}}',
    ]

    def run_ohai(module, ohai_path,):
        rc = 0
        out = tests[run_ohai.counter]
        run_ohai.counter += 1
        err = ''
        return rc, to_bytes(out), to_bytes(err)
    run_ohai.counter = 0

    def find_ohai(module):
        return 'ohai_path'

    module = {}
    module['get_bin_path'] = find_ohai