

# Generated at 2022-06-23 00:16:52.993575
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    for fact_class in get_collector_instance(all_collector_classes=False):
        if isinstance(fact_class, OhaiFactCollector):
            ohaiFactCollector = fact_class
    module = MagicMock()
    ohaiFactCollector.find_ohai(module)


# Generated at 2022-06-23 00:16:57.967518
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.system.ohai

    # FIXME: check if ohai is available for testing
    test_ohai = ansible.module_utils.facts.system.ohai.OhaiFactCollector()
    module = None
    ohai_output = test_ohai.get_ohai_output(module)
    assert ohai_output is not None

# Generated at 2022-06-23 00:17:08.331227
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Create a FakeModule
    class FakeModule:
        def __init__(self, ohai_bin_path):
            self.ohai_bin_path = ohai_bin_path

        def run_command(self, ohai_path):
            if ohai_path != self.ohai_bin_path:
                return (1, "", "")
            return (0, "Ohai Data Here", "")

        def get_bin_path(self, name, opt_dirs=None):
            return self.ohai_bin_path

    # Create a FakeModule
    class FakeModuleNoOhai:
        def run_command(self, ohai_path):
            return (1, "", "")

        def get_bin_path(self, name, opt_dirs=None):
            return None

    # Create

# Generated at 2022-06-23 00:17:09.652866
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    test_collector = OhaiFactCollector()
    assert test_collector.name == 'ohai'

# Generated at 2022-06-23 00:17:13.881823
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module = None
    ohai_path = '/usr/bin/ohai'
    ofc = OhaiFactCollector()
    ofc.run_ohai(module, ohai_path)


# Generated at 2022-06-23 00:17:24.506946
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # ohai is not available in travis ci
    if "TRAVIS" in os.environ:
        return

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, module):
            return "/bin/ohai"

        def run_command(self, cmd):
            if cmd == "/bin/ohai":
                rc = 0
                out = '{"role": "standalone", "hostname": "hostname", "foo": "bar"}'
                err = ""
                return rc, out, err
            return -1, '', 'Invalid command'
    
    module = MockModule()

    fact_collector = OhaiFactCollector()
    collected_facts = fact_collector.collect(module=module)


# Generated at 2022-06-23 00:17:31.511259
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    collector = OhaiFactCollector()
    class MockModule(object):
        def get_bin_path(self, cmd):
            return '/bin/ohai'
        def run_command(self, cmd):
            return 0, '{"hello": "world"}', ''

    ohai_facts = collector.collect(module=MockModule())
    assert ohai_facts == {'ohai_hello': 'world'}


# Generated at 2022-06-23 00:17:38.219120
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class TestModule(object):
        @staticmethod
        def get_bin_path(command, required=False, opt_dirs=[]):
            if command == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None

    module = TestModule()
    ofc = OhaiFactCollector()
    assert ofc.find_ohai(module) == '/usr/bin/ohai'



# Generated at 2022-06-23 00:17:46.546306
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import sys
    import os.path
    import imp
    import collections

    path_to_collectors = os.path.dirname(os.path.abspath(__file__))
    mod_path = os.path.join(path_to_collectors, '../../module_utils/facts/collector.py')
    mod_name = 'ansible.module_utils.facts.collector'
    collectors = imp.load_source(mod_name, mod_path)

    class MockModule:
        def __init__(self):
            self.params = {}
            self.called_by_ansible = True

        def get_bin_path(self, executable):
            executable_path = os.path.join(path_to_collectors, 'ohai-execute')

# Generated at 2022-06-23 00:17:57.652244
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    test_collector = OhaiFactCollector()

    ohai_path = "/usr/bin/ohai"
    fake_module = type('FakeModule', (), {'get_bin_path': lambda test_collector, bin_path: ohai_path})()
    found_path = test_collector.find_ohai(fake_module)

    # Verify expected path is returned
    assert(found_path == ohai_path)

    # Test case where ohai is not present
    non_ohai_path = "/usr/bin/nonexistent"

# Generated at 2022-06-23 00:18:03.974340
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    ohai_ns = PrefixFactNamespace(namespace_name='ohai', prefix='ohai_')
    ofc = OhaiFactCollector(namespace=ohai_ns)
    assert ofc.start() is True

    facts_collector = FactsCollector()
    facts_collector.collectors.append(ofc)

    facts = facts_collector.collect()
    assert facts == {'ohai': {'ohai_kernel': {'modules': []}}}

# Generated at 2022-06-23 00:18:10.626862
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import mock
    import __builtin__
    module = mock.Mock(return_value=True)
    module.get_bin_path.return_value = "/path/to/ohai"

    ohai_fact_collector = OhaiFactCollector()
    ohai_path = ohai_fact_collector.find_ohai(module)

    assert ohai_path == module.get_bin_path.return_value


# Generated at 2022-06-23 00:18:19.621890
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_OhaiFactCollector_collect_output = [
        {
            'languages': {
                'ura': {
                    'version': '0.9.0'
                },
                'python': {
                    'version': '2.6.8'
                }
            },
            'platform': 'ubuntu',
            'platform_version': '10.04'
        }
    ]

    class AnsibleModuleMock(object):

        def __init__(self, ohai_output=None, ohai_rc=0):
            self.ohai_output = ohai_output
            self.ohai_rc = ohai_rc

        def get_bin_path(self, bin_path):
            return '/bin/ohai'

        def run_command(self, command):
            return self.ohai_

# Generated at 2022-06-23 00:18:30.855531
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    class temp(object):
        def __init__(self):
            self.rc = 0
            self.out = '{"ohai_key": "ohai_val"}'
            self.err = ''

        def run_command(self, ohai_path):
            return self.rc, self.out, self.err

        def get_bin_path(self, command):
            return '/usr/bin/ohai'

    import ansible
    from ansible.module_utils.facts import collector

    module = temp()
    ohai = OhaiFactCollector()
    rc, out, err = ohai.run_ohai(module, '/usr/bin/ohai')

# Generated at 2022-06-23 00:18:31.487268
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    assert OhaiFactCollector()

# Generated at 2022-06-23 00:18:43.102718
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ''' Test for method get_ohai_output.
    '''
    from ansible.module_utils.facts.utils.runcommand import RunCommand
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.collector import FactsCollector

    rc = RunCommand()
    ohai_collector = OhaiFactCollector()

    # Testing when ohai_path is None
    ohai_output = ohai_collector.get_ohai_output(rc)
    assert ohai_output is None

    # Testing when ohai_path is not None

# Generated at 2022-06-23 00:18:46.404555
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    module = FakeModule("ansible")
    collector = OhaiFactCollector()

    ohai_path = collector.find_ohai(module)
    assert ohai_path is None


# Generated at 2022-06-23 00:18:57.148841
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import os
    import sys
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    mock_module = ansible_collector._MockModule()
    mock_module.run_command = _mock_run_command

    # test no ohai available
    collector = OhaiFactCollector(collectors=None, namespace=None)
    ohai_facts = collector.get_ohai_output(mock_module)
    assert ohai_facts is None

    # test ohai available but in a different path
    mock_module.run_command._ohai

# Generated at 2022-06-23 00:18:58.012983
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    oh = OhaiFactCollector()
    assert oh

# Generated at 2022-06-23 00:19:06.485633
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import sys
    class MockModule(object):
        def get_bin_path(self, arg):
            if arg == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None
        def run_command(self, arg):
            return 0, "", ""
    mock_module = MockModule()
    collector = OhaiFactCollector()
    ohai_facts = None
    try:
        ohai_facts = collector.get_ohai_output(mock_module)
    except Exception:
        pass
    assert ohai_facts is not None


# Generated at 2022-06-23 00:19:16.400115
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils._text import to_bytes
    ohai_collector = OhaiFactCollector(namespace=PrefixFactNamespace(namespace_name='ohai', prefix='ohai_'))

    class MockModule:
        def get_bin_path(self, binary):
            return '/usr/bin/{0}'.format(binary)

        def run_command(self, command):
            return 0, '{ "platform": "Linux" }', ''

    ohai_collector.collect(module=MockModule())
    facts = get_collector_facts(namespaces=[ohai_collector.namespace])


# Generated at 2022-06-23 00:19:22.733404
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    class ModuleMock(object):

        def __init__(self):
                self.bin_path = '/opt/chef/bin'

        def get_bin_path(self, path):
                return "%s/%s" % (self.bin_path, path)

        def run_command(self, command):
                return self.returncode, self.out, self.err

    class AnsibleModuleMock(object):

        def __init__(self):
                self.module = ModuleMock()

        def get_bin_path(self, path):
                return self.module.get_bin_path(path)

        def run_command(self, command):
                return self.module.run_command(command)

    m = AnsibleModuleMock()

    collector = OhaiFactCollector()

    # check ohai

# Generated at 2022-06-23 00:19:27.491189
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    from ansible.module_utils.facts import collector

    t_collector = collector.get_collector('ohai')
    assert isinstance(t_collector, OhaiFactCollector)
    assert t_collector.name == 'ohai'
    assert len(t_collector._fact_ids) == 0

# Generated at 2022-06-23 00:19:36.505164
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.ohai
    module=ansible.module_utils.facts.ohai
    module.get_bin_path = lambda x: "/usr/bin/ohai"
    module.run_command = lambda x: (0, "[\"test_data\"]", "")
    ohaiFactCollector = OhaiFactCollector()
    ohai_path = "/usr/bin/ohai"
    rc, out, err=ohaiFactCollector.run_ohai(module, ohai_path)
    assert rc == 0
    assert out == "[\"test_data\"]"
    assert err == ""


# Generated at 2022-06-23 00:19:47.225159
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    class ModuleMock(object):

        def __init__(self):
            self.bin_path = "/some/path/bin/"

        def get_bin_path(self, item):
            sq = (item,)
            if item == "ohai":
                return self.bin_path + 'ohai'

        def run_command(self, command):
            if command == '/some/path/bin/ohai':
                return 0, '{"a": "b"}', ''
            else:
                return 0, '', ''

    module = ModuleMock()

    ohai_fact_collector = OhaiFactCollector()

    ohai_output = ohai_fact_collector.get_ohai_output(module)

    assert ohai_output is not None

# Generated at 2022-06-23 00:19:57.213710
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    test_module = {'get_bin_path': lambda x: '/usr/bin/ohai',
                   'run_command': lambda x: (0, '{"ohai": 1}', '')}
    collector = OhaiFactCollector()

    assert collector.collect(module=test_module) == {'ohai': 1}

    test_module['get_bin_path'] = lambda x: None

    assert collector.collect(module=test_module) == {}

    test_module['get_bin_path'] = lambda x: '/usr/bin/ohai'
    test_module['run_command'] = lambda x: (1, '', '')

    assert collector.collect(module=test_module) == {}

# Generated at 2022-06-23 00:20:03.863257
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    AnsibleModule_mock = type('AnsibleModule', (object,),
                              {'exit_json': lambda x, y: None,
                               'get_bin_path': lambda x: '/usr/bin/ohai',
                               'run_command': lambda x: (0, '{"fact1": "value1"}', '')})

    test_object = OhaiFactCollector({}, namespace='ohai')

    result = test_object.get_ohai_output(AnsibleModule_mock())
    assert result == '{"fact1": "value1"}'

# Generated at 2022-06-23 00:20:10.121384
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.facts import ModuleWrapper
    import os
    import json

    m = ModuleWrapper()
    # Get absolute path to file ohai_facts_collector_test.json
    path_to_file = os.path.abspath(__file__)
    # Remove file from path
    path = path_to_file.split('ansible/module_utils/facts/ohai/ohai_facts_collector_test.py')[0]
    # Add path to json file
    path += ('ansible/module_utils/facts/ohai/ohai_facts_collector_test.json')
    # Open json file
    data = open(path, 'r')
    # Load json file
    data = json.load(data)
    # Close file
    data.close()



# Generated at 2022-06-23 00:20:21.405768
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import os
    import tempfile
    import filecmp
    import subprocess

    os_family = os.name
    test_file_dir = os.path.dirname(__file__)
    test_file_dir = test_file_dir + '/../../../' if os_family == 'posix' else test_file_dir + '\\'

    ohai_fact_collector = OhaiFactCollector()
    test_module = AnsibleModule(argument_spec = dict())
    test_module.run_command = mock_module_run_command
    test_module.get_bin_path = mock_module_get_bin_path

    # When
    #   ansible_tmpdir is set in env
    #   and, ohai is available
    # Then
    #   ohai result should be written in ansible_

# Generated at 2022-06-23 00:20:23.419852
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    collector = OhaiFactCollector()
    assert isinstance(collector, OhaiFactCollector)

# Generated at 2022-06-23 00:20:30.025106
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.utils.module_docs_fragments
    import ansible.module_utils.basic
    import ansible.module_utils.facts

    ohai_fact = OhaiFactCollector()
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    out = ohai_fact.get_ohai_output(module)

    print(out)


if __name__ == '__main__':
    test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-23 00:20:39.962548
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import Facts

    f = Facts()
    f.populate()

    mod = f.module_facts['module']

    c = OhaiFactCollector()
    ohai_path = c.find_ohai(mod)

    rc, out, err = c.run_ohai(mod, ohai_path)
    assert rc == 0
    assert len(out) > 0
    assert len(err) == 0

    c = OhaiFactCollector()

    assert c.get_ohai_output(mod) is not None

    c = OhaiFactCollector()
    ohai_facts = c.collect(module=mod)

    assert len(ohai_facts) > 0

# Generated at 2022-06-23 00:20:43.424321
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    # Construct a OhaiFactCollector
    ohai_collector = OhaiFactCollector(namespace='ohai')
    assert ohai_collector.name == 'ohai'



# Generated at 2022-06-23 00:20:45.232444
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_collector = OhaiFactCollector()
    assert ohai_collector is not None


# Generated at 2022-06-23 00:20:54.451205
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector
    import os
    import tempfile

    ohai_path = os.getenv('OHAI_PATH') or '/usr/bin/ohai'
    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    collector = ansible.module_utils.facts.collector.OhaiFactCollector()
    rc, out, err = collector.run_ohai(module, ohai_path)
    assert rc == 0
    assert out
    assert err == ''

    # NOTE: the test will fail if ohai_path is not available
    # This should not be the case for most users
    # If you encounter problems, set your own ohai

# Generated at 2022-06-23 00:21:04.084279
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    ohai_facts = OhaiFactCollector()

    # Mock the module
    class MockRunCommand():
        def __init__(self):
            self.ohai_path = "/usr/bin/ohai"

        def run_command(self, ohai_path):
            return 0, '{}', ''

    class MockModule():
        def __init__(self):
            self.ohai_path = "/usr/bin/ohai"
            self.run_command = MockRunCommand().run_command

# Generated at 2022-06-23 00:21:08.337265
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    # Create an instance of class OhaiFactCollector
    ohai_fact_collector = OhaiFactCollector()
    # Assert that name of the instance is `ohai`
    assert ohai_fact_collector.name == 'ohai'

# Generated at 2022-06-23 00:21:17.806000
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module = AnsibleModuleStub()
    collector = OhaiFactCollector()
    ohai_path = collector.find_ohai(module)
    if not ohai_path:
        return ("ohai_path is empty", None)

    rc, out, err = collector.run_ohai(module, ohai_path)
    if rc != 0:
        return ("Error running ohai: %s" % str(err), None)

    try:
        ohai_facts = json.loads(out)
    except Exception:
        return ("Error running ohai: %s" % str(err), None)

    return (None, ohai_facts)



# Generated at 2022-06-23 00:21:28.405025
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import set_collection_filter
    from ansible.module_utils.facts import FactCollector

    set_collection_filter(['ohai'])

    ohai_facts = {
        'ohai': {
            'os': 'linux',
            'hostname': 'myhostname',
            'network': {
                'default_interface': 'eth0',
                'interfaces': {
                    'eth0': [
                        'fe:54:00:7c:5d:59',
                        '10.0.0.6'
                    ]
                }
            },
            'platform_family': 'rhel',
            'platform_version': '7.4.1708'
        }
    }


# Generated at 2022-06-23 00:21:36.259812
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    o = OhaiFactCollector()
    test_cases = [
    # test_collector, args, output, error
        [1, 'find_ohai', {'rc': 0, 'out': to_bytes('/usr/bin/ohai')}, '', {}],
        [2, 'run_ohai', {'rc': 0, 'out': to_bytes('{"test": "ohai", "message": "ohai_output_2"}')}, '', {}],
    ]
    for test_case in test_cases:
        test_id = test_case[0]
       

# Generated at 2022-06-23 00:21:45.741943
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.ohai
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.common

    ohai_collector = ansible.module_utils.facts.collectors.ohai.OhaiFactCollector()
    tmp = ansible.module_utils.facts.collector.Facts()
    tmp.populate()
    tmp.add_collector(ohai_collector)

    ohai_output = tmp.collector.ohai.get_ohai_output(tmp)

    assert ohai_output is not None



# Generated at 2022-06-23 00:21:47.930328
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    factClass = OhaiFactCollector()
    assert factClass.name == "ohai"


# Generated at 2022-06-23 00:21:58.813747
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.system.ohai import OhaiFactCollector
    from ansible.module_utils._text import to_text
    # Initialize a module
    module = AnsibleModuleMock()
    # Initialize a collector object
    oc = OhaiFactCollector()

    # Test case where ohai executable is found
    ohai_path = oc.find_ohai(module=module)

    # Expect Ohai executable path is returned
    assert ohai_path == '/usr/bin/ohai'

    # Test case where ohai executable is not found
    # Initialize a module
    module = AnsibleModuleMock(run_command_return=dict(rc=1))
    # Initialize a collector object
    oc = OhaiFactCollector()

    # No ohai path should be returned


# Generated at 2022-06-23 00:22:09.558955
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.ohai as ohai
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    ohai_path = '/usr/bin/ohai'
    # Test the method find_ohai for class OhaiFactCollector.
    class TestOhaiFactCollector(BaseFactCollector):
        class TestModule:
            def get_bin_path(self, program):
                return ohai_path
        # Get the ohai_path value.
        ohai_path = TestOhaiFactCollector().find_ohai(TestModule())
        if ohai_path != '/usr/bin/ohai':
            return False
    return True


# Generated at 2022-06-23 00:22:11.580495
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    '''Unit test of method find_ohai of class OhaiFactCollector.'''
    pass

# Generated at 2022-06-23 00:22:13.412461
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    assert isinstance(OhaiFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 00:22:24.546405
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    # tests = [
    #     {
    #         'input': """{
    #   "block device": [
    #     {
    #       "sda": {
    #         "model": "VBOX HARDDISK",
    #         "removable": "0",
    #         "size": "1073741312",
    #         "vendor": "ATA"
    #       }
    #     }
    #   ],
    #   "bmi": {
    #     "bmi_value": 22.5,
    #     "height_m": 1.77,
    #     "ideal_bmi_range_higher": 24.

# Generated at 2022-06-23 00:22:35.650600
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    #
    # Setup test
    #
    m = MockModule()
    m.get_bin_path = MockGetBinPath()
    from ansible.module_utils.facts import collector

    class MockCollector:
        def __init__(self):
            self.name = "some_collector"

        def collect(self, module=None, collected_facts=None):
            return {'collected_facts': "some"}

    cf = collector.BaseFactCollector(collectors=[MockCollector()])
    f = OhaiFactCollector(collectors=[cf], namespace="some_namespace")

    #
    # Setup results
    #
    expected_ohai_path = "/usr/bin/ohai"
    expected_ohai_path_macos = "/usr/local/bin/ohai"

    #

# Generated at 2022-06-23 00:22:46.208993
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import json
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False) as ohai_fifo:
        ohai_fifo.write(b'{"ansible_ohai_test": "ohai"}')

        ohai_fifo.flush()
        ohai_fifo.close()
        module = DummyModule(ohai_path=ohai_fifo.name)
        ohai_collector = OhaiFactCollector()
        rc, out, err = ohai_collector.run_ohai(module, ohai_fifo.name)
        assert rc == 0
        assert out == '{"ansible_ohai_test": "ohai"}'
        assert err == ''
        module.cleanup()


# Generated at 2022-06-23 00:22:49.116123
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    test_collector = OhaiFactCollector(collectors=None, namespace=None)
    assert isinstance(test_collector, OhaiFactCollector)


# Generated at 2022-06-23 00:22:51.925345
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    collected_facts = ohai_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert collected_facts is not None

# Generated at 2022-06-23 00:22:53.210424
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    oc = OhaiFactCollector()
    assert oc.name == 'ohai'

# Generated at 2022-06-23 00:23:00.797701
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    test_module = ansible.module_utils.facts.collector.TestAnsibleModule()
    fact_collector = OhaiFactCollector(module=test_module)
    expected = {'platform': 'xenial'}
    fact_collector.run_ohai = lambda module, ohai_path: (0, json.dumps(expected), '')
    fact_collector.find_ohai = lambda module: True
    facts = fact_collector.collect(module=test_module)
    assert facts == expected

# Generated at 2022-06-23 00:23:11.725034
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''
    This test is written in an way to make it run with python unit test library and
    and also with nosetest.py library.
    If we run `python test_OhaiFactCollector.py -v` in this dir of tests, it will
    run with python unit test and also if we run `nosetests` in lib dir, where this
    file is present, it will run with nosetest.
    '''
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-23 00:23:22.093038
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class AnsibleModuleMock(basic.AnsibleModule):
        def __init__(self):
            super(AnsibleModuleMock, self).__init__()

        def get_bin_path(self, app, opt_dirs=None, required=False):
            return '/usr/bin/' + app

        def run_command(self, cmd, check_rc=True):
            return 0, '{"os":"Linux"}', ''

    module = AnsibleModuleMock()

    fact_collector = collector.get_collector(
        'ohai',
        module=module
    )

    ohai_facts = fact_collector.collect()

    assert isinstance(ohai_facts, dict)
    assert oh

# Generated at 2022-06-23 00:23:23.040928
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    pass


# Generated at 2022-06-23 00:23:33.006961
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.os

    import logging
    # Create a safe logger instance so that collect_file_facts can be unit tested
    # without spamming the logging system
    logger = logging.getLogger('ansible.module_utils.facts')
    logging_handler = logging.StreamHandler()
    logger.addHandler(logging_handler)
    logging_handler.setFormatter(logging.Formatter('%(asctime)s %(name)s:%(lineno)d %(levelname)s: %(message)s'))

    module = ansible.module_utils.facts.os.BaseFileFacts(
        path='',
        logger=logger
    )

    # FIXME: find_ohai should be mocked too.


# Generated at 2022-06-23 00:23:37.207453
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    if module.get_bin_path('ohai'):
        ohai_collector = OhaiFactCollector()
        assert ohai_collector.name == 'ohai'
        assert isinstance(ohai_collector._fact_ids, set)


# Generated at 2022-06-23 00:23:48.454994
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestOhaiFactCollector(BaseFactCollector):
        '''Test subclass of Facts for including information gathered from Ohai.'''
        name = 'test'
        _fact_ids = set()

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='test',
                                            prefix='test_')
            super(TestOhaiFactCollector, self).__init__(collectors=collectors,
                                                        namespace=namespace)

        def find_ohai(self, module):
            return '/usr/bin/ohai'


# Generated at 2022-06-23 00:23:59.870615
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Tests with shell=False
    mock_module = MockModule()
    mock_module.params['shell'] = False
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = "/usr/bin/ohai"
    ohai_fact_col = OhaiFactCollector()
    ohai_path = ohai_fact_col.find_ohai(mock_module)
    assert ohai_path == '/usr/bin/ohai'
    mock_module.get_bin_path.assert_called_once_with('ohai')
    mock_module.run_command.assert_not_called()

    mock_module.reset_mock()

    # Tests with shell=True
    mock_module.params['shell'] = True


# Generated at 2022-06-23 00:24:10.674081
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import Facts
    facts = Facts()

    # For this test we want to mock the actual 'ohai' command and provide a specific output for the test.
    # We also want to set executable bit on the file we mock as ohai command so it is actually executable by the
    # mocked module.run_command.
    import os
    import tempfile
    import atexit
    import shutil
    tempdir = tempfile.mkdtemp()
    tempohai = tempfile.NamedTemporaryFile(delete=False, dir=tempdir)
    tempohai.write('{ "ohai": "fact" }')
    tempohai.close()
    os.system('chmod +x ' + tempohai.name)
    assert os.path.exists(tempohai.name)

    # Create

# Generated at 2022-06-23 00:24:13.709554
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.find_ohai('fake_module') == 'ohai_path'

# Generated at 2022-06-23 00:24:25.885109
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.storage
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.cache
    import ansible.module_utils.urls
    import ansible.module_utils.sensors
    import ansible.module_utils.cpuinfo
    import ansible.module_utils.cpuinfo
    import ansible.module_utils.cpuinfo
    import ansible.module_utils.distribution
    import ansible.module_utils.facts.log
    import ansible.module_utils.facts.namespace

# Generated at 2022-06-23 00:24:28.547570
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_facts = OhaiFactCollector()
    print(ohai_facts.name)
    print(ohai_facts.namespace.namespace_name)
    print(ohai_facts.namespace.prefix)

# Generated at 2022-06-23 00:24:39.979151
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_path = "ohai"

    # FIXME: find a better way to mock ansible module
    import ansible.module_utils.basic
    class ModuleStub:
        class RunCommandResult:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

            def __call__(self):
                return self.rc, self.stdout, self.stderr

        def __init__(self):
            self.run_command_result = self.RunCommandResult(rc=0,
                                                            out='''{
                                                                   "os": "MacOS",
                                                                   "version": "10.11.1"
                                                                 }''',
                                                            err='')



# Generated at 2022-06-23 00:24:51.067719
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.sys_info import ModuleStub
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    ohai_fact_collector = OhaiFactCollector()

    module = ModuleStub()
    module.run_command = lambda x: (0, '{"platform":"ubuntu","platform_version":"12.04","languages":{"ruby":{"version":"1.8.7"},"python":[null,null,"2.7.3","default 2.7.3"],"python3":[null,null,"3.2.3","3.2.3"]},"platform_family":"debian"}', '')

    distro_collector = DistributionFactCollector(collectors=[ohai_fact_collector])
    distro_collector.collect(module=module)


# Generated at 2022-06-23 00:24:57.700716
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    collector = OhaiFactCollector()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/usr/bin/ohai'
    facts = collector.collect(module=module)
    assert facts == {}

# Generated at 2022-06-23 00:25:08.701709
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import os
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            if binary == 'ohai':
                return '/ohai_daemon'

        def run_command(self, cmd):
            raise NotImplementedError

    def test_run_ohai():
        raise NotImplementedError

    # construct ohai output
    ohaif = tempfile.NamedTemporaryFile()
    ohaif.write('{"ohai":"is"}\n')
    ohaif.flush()

    # write ohai_output stub path
    open(os.path.expanduser('~/.ohai_output'), 'w').write(ohaif.name)

    # write ohai_path stub
    tmp

# Generated at 2022-06-23 00:25:20.186967
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import os
    import tempfile
    from ansible.module_utils.facts import ansible_local

    # Setup file system
    tmpdir = tempfile.mkdtemp()
    # tmpdir = '/tmp'
    for path in ('/bin', '/sbin', '/usr/bin', '/usr/sbin'):
        os.makedirs(tmpdir + path)
    os.makedirs(tmpdir + '/usr/local/bin')
    ohai_exe = os.path.join(tmpdir + '/usr/local/bin', 'ohai')
    with open(ohai_exe, 'w') as f:
        f.write('#!/bin/sh\n')
    os.chmod(ohai_exe, 0o755)

    # Get fact collector
    fact_collector = ansible_local.collect

# Generated at 2022-06-23 00:25:30.821354
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.basic import AnsibleModule
    import os
    import json

    def run_command(self, cmd):
        cmd_frag = cmd.split()[1:]
        if cmd_frag[0] == 'os':
            cmd_frag.remove('os')
        if cmd_frag[0] == 'c':
            cmd_frag.remove('c')
        if cmd_frag[0] == 'cpu':
            cmd_frag.remove('cpu')
        if cmd_frag[0] == 'block_device':
            cmd_frag.remove('block_device')
        return 0, json.dumps({'cmd': cmd_frag}), ''


# Generated at 2022-06-23 00:25:37.713167
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact = {}

    class MockModule(object):
        def __init__(self, ohai_path):
            self.ohai_path = ohai_path

        def get_bin_path(self, bin_name):
            return self.ohai_path

        def run_command(self, command):
            return (0, 'data', None)

    module = MockModule("/fake/path")
    assert ohai_fact_collector.get_ohai_output(module)

# Generated at 2022-06-23 00:25:48.576303
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collectors.ohai import OhaiFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    # Create a namespace to store the collected facts
    namespace = PrefixFactNamespace(namespace_name='ohai', prefix='ohai_')
    # Create an instance of OhaiFactCollector
    ohaiFactCollector = OhaiFactCollector(namespace=namespace)
    # Create and populate an instance of AnsibleModule
    import ansible.module_utils.facts.ansible_module
    from ansible.module_utils.facts import ansible_module
    ansible_module.AnsibleModule = ansible.module_utils.facts.ansible_module.AnsibleModule

# Generated at 2022-06-23 00:25:58.320319
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    '''Method collect should return a dictionary of facts from ohai.'''
    from ansible.module_utils.facts import ModuleBase
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    class Module(ModuleBase):
        '''A dummy module class.'''

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg):
            fact = {'kernel': {'machine': 'x86_64', 'os': 'Darwin', 'name': 'Darwin', 'release': '13.3.0'}}
            output = json.dumps(fact)
            return 0, output, ''

    module = Module()

# Generated at 2022-06-23 00:26:09.448014
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.ohai.collector import OhaiFactCollector
    from ansible.module_utils.facts import ModuleDepFacts

    # Test missing ohai fact
    module_dep_facts = ModuleDepFacts(module=None)
    ohai_facts_collector = OhaiFactCollector(module_dep_facts)
    assert ohai_facts_collector.find_ohai(module_dep_facts.module) is None

    # Test for ohai fact
    module_dep_facts = ModuleDepFacts(module=None)
    module_dep_facts.module.params = {'gather_ohai_facts': True}
    ohai_facts_collector = OhaiFactCollector(module_dep_facts)
    ohai_path = ohai_facts_collector.find_

# Generated at 2022-06-23 00:26:15.482026
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector(namespace='ohai')
    assert ohai_fact_collector.name == 'ohai'
    assert isinstance(ohai_fact_collector._namespace,
                      PrefixFactNamespace)
    assert ohai_fact_collector._namespace.namespace_name == 'ohai'
    assert ohai_fact_collector._namespace.prefix == 'ohai_'

# Generated at 2022-06-23 00:26:18.109544
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import shutil
    import tempfile
    import os

    test_path = tempfile.mkdtemp()
    test_file = os.pat

# Generated at 2022-06-23 00:26:29.500692
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ## Mock module
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.get_bin_path = Mock(return_value='/usr/bin/ohai')

# Generated at 2022-06-23 00:26:40.528505
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    module = MockModule()
    # empty ohai dict is returned when ohai is not found
    ohai_fact = OhaiFactCollector([],
                                  namespace=PrefixFactNamespace(namespace_name='ohai',
                                                                prefix='ohai_'))
    module.bin_path = lambda x: None
    assert ohai_fact.get_ohai_output(module) == {}
    # empty ohai dict is returned when ohai is found but it fails
    module.bin_path = lambda x: '/'

# Generated at 2022-06-23 00:26:50.343733
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts import ansible_version
    from ansible.module_utils import basic
    import sys

    fake_ansible_version = ansible_version.AnsibleVersion('2.7.0')
    fake_module_tmpdir = '/tmp'
    fake_module_name = 'fake_module'
    fake_module_path = '/tmp/fake_module'
    fake_module_args = {
        'ansible_facts': {},
        'ansible_version': fake_ansible_version,
        'module_name': fake_module_name,
        'module_path': fake_module_path,
        'module_tmpdir': fake_module_tmpdir,
    }
    fake_ansible_collections