

# Generated at 2022-06-24 23:11:18.356667
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class MockModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, **args):
            pass

        def get_bin_path(self, bin_name):
            return "foo"

        def run_command(self, cmd):
            return 0, "output", "err"

    module = MockModule()
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output(module)


# Generated at 2022-06-24 23:11:20.092683
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = MockModule()



# Generated at 2022-06-24 23:11:23.479848
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_facts_0 = ohai_fact_collector_0.collect()
    assert ('cpu' in ohai_facts_0)


# Generated at 2022-06-24 23:11:29.010383
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    # TODO: Add test
    return True


# Generated at 2022-06-24 23:11:35.114579
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    def run_ohai(self, module, ohai_path,):
        rc = 0

# Generated at 2022-06-24 23:11:36.322649
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    assert True, "No tests written"


# Generated at 2022-06-24 23:11:45.720167
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    class MockModule(object):

        def __init__(self):
            self.rc = 0
            self.out = ''
            self.err = ''
            self.run_command_return_value = (self.rc, self.out, self.err)

        def get_bin_path(self, binaryname, required=False):
            ohai_path = '/usr/bin/ohai'
            return ohai_path

        def run_command(self, cmd, check_rc=True, close_fds=True):
            return self.run_command_return_value

    ohai_fact_collector_0 = OhaiFactCollector()
    mock_module_0 = MockModule()
    mock_module_0.run_command_return_value = (0, '{"id":"test"}', '')
    ohai

# Generated at 2022-06-24 23:11:48.571925
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output = lambda module: [None, "/bin/ohai"]
    assert ohai_fact_collector_0.find_ohai() == "/bin/ohai"


# Generated at 2022-06-24 23:11:55.081131
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    test_ohai_fact_collector = OhaiFactCollector()
    test_ohai_path = test_ohai_fact_collector.find_ohai(test_ohai_fact_collector)
    assert test_ohai_path == '/usr/bin/ohai'


# Generated at 2022-06-24 23:12:00.429268
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    module = FakeModule(
        bin_path={"ohai": "/usr/bin/ohai"},
        run_command=FakeRunCommand(
            stdout=b'{"ipaddress":"10.0.0.1"}'
        )
    )

    ohai_output = ohai_fact_collector.get_ohai_output(module)
    assert ohai_output == '{"ipaddress": "10.0.0.1"}'



# Generated at 2022-06-24 23:12:05.974904
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    """Test collect function of class OhaiFactCollector"""
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect()
    assert len(ohai_facts) > 0

# Generated at 2022-06-24 23:12:07.157079
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    # test with no module argument
    ohai_fact_collector_0.collect()



# Generated at 2022-06-24 23:12:12.081180
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # ohai_fact_collector_1 is instance of class OhaiFactCollector
    ohai_fact_collector_1 = OhaiFactCollector()

    # Attempt to retrieve ohai output
    ohai_output = ohai_fact_collector_1.get_ohai_output(None)

    # ohai_output should be empty
    assert not ohai_output


# Generated at 2022-06-24 23:12:22.971366
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    ohai_fact_collector = OhaiFactCollector()

    class Module():
        def __init__(self):
            pass
        def run_command(self, arg):
            return
        def get_bin_path(self, arg):
            return

    run_command_real = Module.run_command
    def run_command_fake(self, arg):
        return 0, '{"hello": "world"}', None

    Module.run_command = run_command_fake

    get_bin_path_real = Module.get_bin_path
    def get_bin_path_fake(self, arg):
        return 'ohai_path'

    Module.get_bin_path = get_bin_path_fake

    module = Module()

    ohai_output = ohai_fact_collector.get_ohai_

# Generated at 2022-06-24 23:12:28.856938
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = MockModule()
    # Mock function call, returns None
    ohai_fact_collector_0.find_ohai = Mock()
    ohai_fact_collector_0.find_ohai.return_value = None
    result = ohai_fact_collector_0.get_ohai_output(module_0)
    assert result is None


# Generated at 2022-06-24 23:12:33.741347
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.ohai as ohai

    class MyModule:
        def __init__(self):
            self.class_var = ""

        def get_bin_path(self, *args, **kwargs):
            return "/bin/"

        def run_command(self, *args, **kwargs):
            return 0, '{}', ''

    class AnsibleModule:
        def __init__(self):
            self.params = {}

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}
            self.my_module = MyModule()

    fact_collector_0 = ohai.OhaiFactCollector()

    ansible_module_0 = AnsibleModule()
    result_0 = fact_collector_0.get_ohai_output

# Generated at 2022-06-24 23:12:41.377286
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    ohai_fact_collector_0.run_ohai = lambda module, ohai_path: (0, '\n{\"os\":\"linux\"}\n', '')
    ohai_fact_collector_0.find_ohai = lambda module: 'ohai'
    assert ohai_fact_collector_0.collect(module) == {'os': 'linux'}



# Generated at 2022-06-24 23:12:44.718161
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collectors = []
    ansible_collector.collectors.append(OhaiFactCollector())
    facts = ansible_collector.get_facts(None)
    assert facts['ohai'] is None


# Generated at 2022-06-24 23:12:52.606357
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    class Test_Module():
        def get_bin_path(self, arg):
            return '/usr/bin/ohai'

        def run_command(self, arg):
            return 0

    test_module = Test_Module()
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.run_ohai(test_module, '/usr/bin/ohai')


# Generated at 2022-06-24 23:13:02.117249
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class TestAnsibleModule:
        def __init__(self):
            pass

        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, ohai_path):
            # FIXME: this is less than ideal for testing, what's a better way?
            with open("tests/units/module_utils/facts/test_ohai_facts.json", "r") as ohai_test_output:
                return (0, ohai_test_output.read(), 'test stderr')

    mm = TestAnsibleModule()
    assert ohai_fact_collector_0.find_ohai(mm) == '/usr/bin/ohai'

    out = ohai_fact

# Generated at 2022-06-24 23:13:07.698234
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


# Generated at 2022-06-24 23:13:13.996803
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    print("Class OhaiFactCollector, method collect")

    # Fixture OhaiFactCollector
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0 is not None

    # No module input, assert empty dict
    result = ohai_fact_collector_0.collect()
    assert result == {}

from ansible.module_utils.facts.namespace import PrefixFactNamespace
from ansible.module_utils.facts.collector import BaseFactCollector

from ansible.module_utils.facts.amzn import (AmznMeminfoFactCollector,
                                             Amzn2FactCollector)
from ansible.module_utils.facts.aix import AixDefaultFactCollector

# Generated at 2022-06-24 23:13:19.802893
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    #
    # Test no module param
    #
    assert ohai_fact_collector_0.collect() == {}

    #
    # Test a None module param
    #
    assert ohai_fact_collector_0.collect(module=None) == {}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-24 23:13:27.888977
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

# Generated at 2022-06-24 23:13:37.710154
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    test_cases = [
        {
            'name': 'Setup for this test suite',
            'in': {
                'module': None
            },
            'out': {},
        },
        {
            'name': 'Test case 0',
            'in': {
                'module' : {
                    'run_command': lambda x: (0, '{}', '')
                }
            },
            'out': {},
        },
    ]

    def run_test(test_case):
        ohai_fact_collector = OhaiFactCollector()
        actual = ohai_fact_collector.get_ohai_output(test_case['in']['module'])
        if test_case['out']:
            assert actual == test_case['out']['expected']

# Generated at 2022-06-24 23:13:40.994641
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.find_ohai(self) == ohai_path


# Generated at 2022-06-24 23:13:48.252439
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

    class fake_module:
        def get_bin_path(self, arg_0):
            return '/bin/ohai'


# Generated at 2022-06-24 23:13:53.781779
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModuleMock(params={'filter':"line.split()[0]",'gather_subset':[]})
    ohai_fact_collector_0.run_ohai(module_0, '/usr/bin/ohai')



# Generated at 2022-06-24 23:14:03.891119
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Mock Module object - actual invokation will not happen
    class MockModule():
        def __init__(self):
            self.path = '/path'

        def get_bin_path(self, cmd):
            if cmd == 'ohai':
                return '/bin/ohai'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/bin/ohai':
                return 0, '{"mock":"ohai"}', ''
            else:
                return 1, '', ''

    ohai_fact_collector_1 = OhaiFactCollector()
    module_1 = MockModule()
    ohai_fact_collector_1.get_ohai_output(module=module_1)

# Generated at 2022-06-24 23:14:08.983183
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    collected_facts_0 = {}
    class MockModule:
        def get_bin_path(self, path): return path
        def run_command(self, ohai_path): return 0, '{}', ''
    ohai_fact_collector_0.get_ohai_output(MockModule())


# Generated at 2022-06-24 23:14:19.165693
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class DummyModule:
        def get_bin_path(self, arg0):
            return 'bin_path'

        def run_command(self, arg0):
            return 0, 'out', 'err'

    ohai_output_0 = ohai_fact_collector_0.get_ohai_output(DummyModule())
    assert ohai_output_0 is not None


# Generated at 2022-06-24 23:14:26.384849
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class Module(object):
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def get_bin_path(self, ohai_command):
            return ohai_command

        def run_command(self, ohai_path):
            return self.run_command_result

    class TestOhaiFactCollector(OhaiFactCollector):
        def run_ohai(self, module, ohai_path):
            return module.run_command(ohai_path)

    module_0 = Module((0, '{}', None))
    ohai_fact_collector_0 = TestOhaiFactCollector()
    assert ohai_fact_collector_0.get_ohai_output(module_0) == '{}'

# Unit test

# Generated at 2022-06-24 23:14:27.323556
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    OhaiFactCollector.collect()


# Generated at 2022-06-24 23:14:29.143520
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    fixture = OhaiFactCollector()
    fixture.run_ohai(None, "/usr/bin/ohai")


# Generated at 2022-06-24 23:14:32.044890
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    # test_case_0
    ohai_fact_collector_0 = OhaiFactCollector()
    if ohai_fact_collector_0 != ohai_fact_collector_0.collect():
        raise AssertionError('ohai_fact_collector_0 did not equal ohai_fact_collector_0.collect()')



# Generated at 2022-06-24 23:14:40.148127
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    class FakeModule(object):

        def get_bin_path(self, name, opt_dirs=None):
            return '/bin/ohai'

        def run_command(self, command):
            out = '{"irssi_v": "1.0.3", "bundler_v": "1.9.3", "system": "x86_64-darwin14.0.0", "chef_v": "12.0.0", "git_v": "1.9.1", "ruby_v": "2.0.0"}'
            return 0, out, ''

    fake_module = FakeModule()
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_output = ohai_fact_collector_0.get_ohai_output(fake_module)



# Generated at 2022-06-24 23:14:45.581267
# Unit test for method get_ohai_output of class OhaiFactCollector

# Generated at 2022-06-24 23:14:54.736253
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # test for when ohai is not present
    module = type(
        'Module',
        (object,),
        {
            'run_command': lambda self, ohai_path: (1, None, 'ohai not found'),
            'get_bin_path': lambda self, ohai_path: None
        }
    )
    ohai_fact_collector = OhaiFactCollector()
    ohai_path = ohai_fact_collector.find_ohai(module())
    assert ohai_path == None
    # test for when ohai is present

# Generated at 2022-06-24 23:14:56.892657
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    assert ohai_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:15:04.782077
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    # call collect with module = ansible_module_0
    ansible_module_0 = AnsibleModule(argument_spec={})
    ansible_module_0.params['path'] = '/bin'
    ansible_module_0.params['http_port'] = 8080
    ansible_module_0.params['https_port'] = 8443
    ansible_module_0.params['vault_password_file'] = 'vault_password_file'
    ansible_module_0.params['forks'] = 5
    ansible_module_0.params['remote_user'] = 'remote_user'
    ansible_module_0.params['private_key_file'] = 'private_key_file'
    ansible_module_0

# Generated at 2022-06-24 23:15:25.334071
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()

    # Create a mock module
    class Module(object):
        def __init__(self):
            self.called_bin_paths = []

        def get_bin_path(self, arg):
            self.called_bin_paths.append(arg)

        def run_command(self, arg):
            self.called_bin_paths.append(arg)

    module = Module()

    # Test case when ohai is not installed
    module.called_bin_paths = []
    actual_result = ohai_fact_collector.collect(module=module, collected_facts=None)
    expected_result = {}
    assert expected_result == actual_result
    assert ['ohai'] == module.called_bin_paths

# Generated at 2022-06-24 23:15:27.678686
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert(ohai_fact_collector_0.collect() == {})

# Generated at 2022-06-24 23:15:38.429316
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.plugins.ohai
    from ansible.module_utils.facts.plugins.ohai import OhaiFactCollector
    import ansible.module_utils.facts.utils
    from ansible.module_utils.facts.utils import AnsibleCollector
    import re

    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output(module=None)


# Generated at 2022-06-24 23:15:40.010017
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.collect()

# Generated at 2022-06-24 23:15:47.191096
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_facts = {}

# Generated at 2022-06-24 23:15:50.701351
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output()

# Generated at 2022-06-24 23:15:53.616877
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_2 = OhaiFactCollector()
    result = ohai_fact_collector_2.collect()
    assert not result


# Generated at 2022-06-24 23:16:04.606824
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_fact_collector_2 = OhaiFactCollector()
    assert ohai_fact_collector_1.collect() == ohai_fact_collector_0.collect()
    ohai_fact_collector_3 = OhaiFactCollector()
    assert ohai_fact_collector_3.collect() == ohai_fact_collector_2.collect()
    assert ohai_fact_collector_2.collect() == ohai_fact_collector_1.collect()
    assert ohai_fact_collector_1.collect() == ohai_fact_collector_0.collect()

# Generated at 2022-06-24 23:16:07.272116
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()

    # Testing for required params
    try:
        ohai_fact_collector_0.run_ohai()
    except TypeError:
        pass


# Generated at 2022-06-24 23:16:11.623252
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


# Generated at 2022-06-24 23:16:43.683843
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    class module_0:
        def __init__(self):
            self.name = 'module_0'
        def get_bin_path(self, arg_0):
            return 'bin/path'
        def run_command(self, arg_0):
            class mock_run_command:
                def __init__(self):
                    self.name = 'mock_run_command'
                def __getitem__(self, item):
                    return 'mock_run_command'[item]
            return mock_run_command()
    ohai_path_0 = 'bin'+'/'+'path'

# Generated at 2022-06-24 23:16:45.448193
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.collect()

# Generated at 2022-06-24 23:16:53.017387
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Check with no ohai
    class Module(object):
        def get_bin_path(self, binary):
            return None
    ohai_fact_collector_1 = OhaiFactCollector()
    assert ohai_fact_collector_1.find_ohai(Module()) is None

    # Check with valid ohai
    class Module(object):
        def get_bin_path(self, binary):
            return 'foo'
    ohai_fact_collector_2 = OhaiFactCollector()
    assert ohai_fact_collector_2.find_ohai(Module()) is 'foo'


# Generated at 2022-06-24 23:16:54.524478
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    assert(OhaiFactCollector.get_ohai_output(None) is None)

# Generated at 2022-06-24 23:17:02.741483
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()
    module_name = "None"
    class T:
        def get_bin_path(self, name):
            if name == 'ohai':
                return "/usr/bin/ohai"
            else:
                return None
        def run_command(self, ohai_path):
            return 0, json.dumps({"ipaddress": "127.0.0.1"}), "None"
    module = T()
    out = ohai_fact_collector_1.get_ohai_output(module)
    assert out == json.dumps({"ipaddress": "127.0.0.1"})


# Generated at 2022-06-24 23:17:11.446923
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    """ Unit test to test method 'collect' of Class 'OhaiFactCollector' """

    ohai_fact_collector_collect_0 = OhaiFactCollector()

    ansible_module_mock_0 = MockAnsibleModule()
    ansible_module_mock_0.get_bin_path_mock.return_value = "/usr/bin/ohai"

    os_exists_mock_0 = MockOSExists()
    os_exists_mock_0.exists_mock.return_value = True

    ansible_module_mock_0.run_command_mock.return_value = [ 0, "[\"ubuntu\", \"lsb\"]", None]


# Generated at 2022-06-24 23:17:11.990150
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    pass

# Generated at 2022-06-24 23:17:14.211589
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:17:24.381428
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible_collections.ansible.community.plugins.module_utils.facts.test.test_ohai_fact_collector
    import ansible_collections.ansible.community.plugins.module_utils.facts.test.mock_module

    test_module_0 = ansible_collections.ansible.community.plugins.module_utils.facts.test.mock_module.MockModule()

    test_module_0.run_command = ansible_collections.ansible.community.plugins.module_utils.facts.test.test_ohai_fact_collector.run_command_mock

    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:17:26.402692
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert isinstance(ohai_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:18:18.749506
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Mock class module.
    class MockModule:
        def get_bin_path(self, path):
            return "/usr/bin/foo"

    mock_module_0 = MockModule()
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.find_ohai(mock_module_0) == "/usr/bin/foo"


# Generated at 2022-06-24 23:18:27.879985
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err
            def run_command(self, ohai_path):
                return self.rc, self.out, self.err

# Generated at 2022-06-24 23:18:33.527919
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_path = '/bin/ohai'
    ohai_output = '{"a": [1,2, "b"]}'
    module = AnsibleModuleMock(bin_path=ohai_path, ohai_output=ohai_output)
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.get_ohai_output(module) == ohai_output


# Generated at 2022-06-24 23:18:42.975332
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

    class MockModule(object):
        def get_bin_path(self, path):
            return None

        def run_command(self, cmd):
            return 1, '', ''

    mock_module_0 = MockModule()
    actual_result_0 = ohai_fact_collector_0.get_ohai_output(mock_module_0)

    assert actual_result_0 == None

    class MockModule(object):
        def get_bin_path(self, path):
            return 'ohai_path'

        def run_command(self, cmd):
            return 1, '', ''

    mock_module_1 = MockModule()

# Generated at 2022-06-24 23:18:49.888139
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    class MockModule:

        def run_command(self, ohai_path):
            return 0, '{"ohai_fact_0": "ohai_value_0"}', ''

        def get_bin_path(self, ohai):
            return 'ohai_in_path'

    mock_module_0 = MockModule()

    ohai_fact_collector_0 = OhaiFactCollector()
    collected_facts = ohai_fact_collector_0.collect(module=mock_module_0)

    assert collected_facts['ohai_fact_0'] == 'ohai_value_0'


# Generated at 2022-06-24 23:18:55.037093
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class MockModule():
        def get_bin_path(self, path):
            return 'bin/ohai'
        def run_command(self, command):
            return 0, '', ''
    module = MockModule()
    ohai_output = ohai_fact_collector_0.get_ohai_output(module)
    assert ohai_output is not None, 'Expected None, got %s for ohai_output' % ohai_output


# Generated at 2022-06-24 23:18:56.885697
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    '''Unit test for method find_ohai of class OhaiFactCollector.'''
    pass


# Generated at 2022-06-24 23:19:02.371041
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.system.distribution as distribution
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.get_ohai_output({}) == None


# Generated at 2022-06-24 23:19:06.150784
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    try:
        ohai_fact_collector_0 = OhaiFactCollector()
        test_module_0 = MagicMock()
        setattr(test_module_0, 'get_bin_path', lambda x: None)
        assert ohai_fact_collector_0.find_ohai(test_module_0) is None
    except Exception:
        assert False


# Generated at 2022-06-24 23:19:13.797036
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    class mock_run_command:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, *args, **kwargs):
            return (self.rc, self.out, self.err)

    class mock_get_bin_path:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def __call__(self, *args, **kwargs):
            return self.bin_path

    module = type('module', (object,), {
        'run_command': mock_run_command(0, '{"name": "ansible"}', None),
        'get_bin_path': mock_get_bin_path('ohai')
    })

   

# Generated at 2022-06-24 23:21:09.782011
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_path = [
        '/fake/bin/ohai'
    ]
    ohai_output = '''
    {
        "fake_ohai_fact1": "fake_ohai_fact1_value",
        "fake_ohai_fact2": "fake_ohai_fact2_value",
        "fake_ohai_fact3": "fake_ohai_fact3_value"
    }
    '''
    expected_ohai_facts = dict(
        fake_ohai_fact1='fake_ohai_fact1_value',
        fake_ohai_fact2='fake_ohai_fact2_value',
        fake_ohai_fact3='fake_ohai_fact3_value',
    )

    # Create a MockModule to use for testing.
    test_module = MockModule