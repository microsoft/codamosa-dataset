

# Generated at 2022-06-24 23:11:11.900813
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    bool_0 = False
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)



# Generated at 2022-06-24 23:11:22.253207
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    str_0 = 'test_ohai'
    str_1 = 'test_ohai'
    class_0 = type('', (), {})
    class_0.get_bin_path = test_OhaiFactCollector_get_ohai_output_0
    class_0.run_command = test_OhaiFactCollector_get_ohai_output_1
    ohai_fact_collector_0.get_ohai_output(class_0)
    str_2 = 'test_ohai'
    str_3 = 'test_ohai'
    class_1 = type('', (), {})
    class_1.get_bin_path = test_OhaiFactCollector_get_ohai_output_2
    class_1

# Generated at 2022-06-24 23:11:26.070265
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    collect_method_0 = getattr(OhaiFactCollector, 'get_ohai_output')

    # Call method
    collect_method_0(bool_0)


# Generated at 2022-06-24 23:11:35.973865
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    ansible_module_0 = MockAnsibleModule()
    ansible_module_0.run_command = MockRunCommand()
    ansible_module_0.get_bin_path = MockGetBinPath()
    bool_1 = True
    if bool_1:
        ohai_fact_collector_0.get_ohai_output = MockGetOhaiOutput()
    else:
        ohai_fact_collector_0.get_ohai_output = MockGetOhaiOutput()
    bool_1 = True
    if bool_1:
        ohai_fact_collector_0.get_ohai_output = MockGetOhaiOutput()
    else:
        ohai_fact_

# Generated at 2022-06-24 23:11:42.520496
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.basic import AnsibleModule
    bool_0 = False
    contributed_0 = [None]
    ohai_fact_collector_0 = OhaiFactCollector(contributed_0)
    ansible_module_0 = AnsibleModule(bool_0, bool_0)
    test_method_ohai_fact_collector_0 = ohai_fact_collector_0.get_ohai_output(ansible_module_0)

# Generated at 2022-06-24 23:11:49.874571
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    ansible_module_0 = AnsibleModuleMock()
    string_0 = 'ohai_path'
    rc_0, out_0, err_0 = ohai_fact_collector_0.run_ohai(ansible_module_0, string_0)
    int_0 = 0
    assert rc_0 == int_0


# Generated at 2022-06-24 23:11:54.817076
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector(True)

    # Pass
    pass


# Generated at 2022-06-24 23:11:58.810952
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # ohai_fact_collector_1 contains an OhaiFactCollector instance
    ohai_fact_collector_1 = OhaiFactCollector()

    # ohai_fact_collector_1.collect contains a method
    assert hasattr(ohai_fact_collector_1.collect, '__call__')


# Generated at 2022-06-24 23:12:01.034228
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


if __name__ == '__main__':
    test_case_0()
    test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-24 23:12:02.622646
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


# Generated at 2022-06-24 23:12:07.225999
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    Module_0 = ohai_fact_collector_0.get_ohai_output()

# Generated at 2022-06-24 23:12:08.417499
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # FIXME: no test coverage
    pass


# Generated at 2022-06-24 23:12:09.477864
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    pass


# Generated at 2022-06-24 23:12:13.574896
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Set up mock
    class MockModule(object):

        def get_bin_path(self, arg):
            if arg == 'ohai':
                return '/usr/bin/ohai'

        def run_command(self, arg):
            if arg == '/usr/bin/ohai':
                return (0, '{"kernel": {"name": "Linux", "machine": "x86_64"}}', '')

    mock_module = MockModule()

    # Test
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.run_ohai = lambda arg, arg1: (0, '{"kernel": {"name": "Linux", "machine": "x86_64"}}', '')

# Generated at 2022-06-24 23:12:23.876395
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    int_0 = 3
    bool_1 = True
    module_mock_0 = ohai_fact_collector_0.get__ModuleMock(int_0, bool_1)
    bool_2 = False
    int_1 = 2
    module_mock_1 = ohai_fact_collector_0.get__ModuleMock(int_1, bool_2)
    bool_3 = True
    int_2 = 3
    module_mock_2 = ohai_fact_collector_0.get__ModuleMock(int_2, bool_3)
    class_0 = ansible_module_mock_instance_0.run_command

# Generated at 2022-06-24 23:12:26.970207
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    base_fact_collector_0 = BaseFactCollector()
    list_0 = []
    collected_facts_0 = {}
    collected_facts_0 = ohai_fact_collector_0.collect(list_0, collected_facts_0)


# Generated at 2022-06-24 23:12:32.267723
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Ohai is expected to be in the PATH of the system.
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.find_ohai()


# Generated at 2022-06-24 23:12:33.746386
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # FIXME: I don't know how to test it currently
    pass



# Generated at 2022-06-24 23:12:40.902275
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class_0 = OhaiFactCollector()
    set_0 = set() # FIXME: set of Hashable
    vars_0 = vars()
    import ansible.module_utils.facts.collector
    module_0 = ansible.module_utils.facts.collector.BaseFactCollector()
    assert class_0.get_ohai_output(module_0) == None


# Generated at 2022-06-24 23:12:45.184283
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # FIXME: This fails in Azure: ohai_path is None.
    test_class = OhaiFactCollector()
    test_method = test_class.get_ohai_output
    retval = test_method()

if __name__ == '__main__':
    test_case_0()
    test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-24 23:12:53.933633
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Test with invalid module
    module = None
    ohai_fact_collector_0 = OhaiFactCollector()
    bool_0 = ohai_fact_collector_0.has_plugin('setup')
    if bool_0:
        ohai_output_0 = ohai_fact_collector_0.get_ohai_output(module)
        assert ohai_output_0 == None


# Generated at 2022-06-24 23:12:56.451201
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Case 0:
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    ohai_fact_collector_1 = ohai_fact_collector_0.collect()



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:12:59.065998
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    bool_0 = True
    bool_1 = bool_0
    ohai_fact_collector_0.get_ohai_output(bool_1)



# Generated at 2022-06-24 23:13:00.462235
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)


# Generated at 2022-06-24 23:13:02.323213
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.get_ohai_output()


# Generated at 2022-06-24 23:13:05.840960
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

# Generated at 2022-06-24 23:13:10.781850
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    argument_0 = 'foobar'
    ohai_fact_collector_0 = OhaiFactCollector(argument_0)

    from ansible.module_utils.facts import ansible_local
    ansible_local.AnsibleModule.get_bin_path = lambda *args, **kwargs: 'bin_path'

    assert ohai_fact_collector_0.find_ohai(ansible_local.AnsibleModule) == 'bin_path'



# Generated at 2022-06-24 23:13:21.343997
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    import ansible.module_utils.facts.collector as collector_0
    import ansible.module_utils.facts.namespace as namespace_0
    import ansible.module_utils.facts.utils as utils_0
    # FIXME: this is a horrible hack.  We need a method of testing modules
    # that don't actually want to talk to the network, or at least being
    # able to control that
    import ansible.module_utils.facts.network.base as base_0
    base_0.FACT_CACHE = None
    import ansible.module_utils.facts.network.default as default_0
    import ansible.module_utils.facts.network.linux as linux_0
    import ansible.module_utils.facts.network.windows as windows_0

    # set up objects required for the module


# Generated at 2022-06-24 23:13:26.941075
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Test default args.
    # setUp one variable.
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    # setUp one variable.
    str_0 = 'module'
    # setUp one variable.
    function_0 = hasattr
    # setUp one variable.
    str_1 = 'get_bin_path'
    # Call method
    result = ohai_fact_collector_0.find_ohai(str_0)
    assert result


# Generated at 2022-06-24 23:13:33.246779
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts']['ohai'] = dict()
    dict_0['ansible_facts']['ohai']['ohai_disk'] = dict()
    dict_0['ansible_facts']['ohai']['ohai_mem'] = dict()
    dict_0['ansible_facts']['ohai']['ohai_cpu'] = dict()
    dict_0['ansible_facts']['ohai']['ohai_network'] = dict()
    dict_0['ansible_facts']['ohai']['ohai_dmi'] = dict

# Generated at 2022-06-24 23:13:41.624693
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    pass


# Generated at 2022-06-24 23:13:48.450232
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module_0 = object()
    str_0 = ohai_fact_collector_0.find_ohai(module_0)
    test_str_0 = 'ansible_ohai_find_ohai'
    assert str_0 == test_str_0



# Generated at 2022-06-24 23:13:52.547553
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    # FIXME: How to test this, or even mock it?


# Generated at 2022-06-24 23:13:55.846378
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:14:00.406818
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_1 = True
    ohai_fact_collector_1 = OhaiFactCollector(bool_1)
    assert ohai_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:14:03.335517
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    bool_0 = False
    # Initialize a OhaiFactCollector
    ohai_fact_collector = OhaiFactCollector(bool_0)
    # Initialize a AnsibleModule
    ansible_module = None
    ohai_path = ''
    # Return a tuple with rc, out, err
    rc, out, err = ohai_fact_collector.run_ohai(ansible_module, ohai_path)
    assert rc == 0


# Generated at 2022-06-24 23:14:04.300065
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    test_case_0()



# Generated at 2022-06-24 23:14:05.620143
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # No parameters, so nothing to test
    return True


# Generated at 2022-06-24 23:14:15.536990
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    ansible_module_0 = AnsibleModule(bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0,
                                     bool_0)

# Generated at 2022-06-24 23:14:23.049823
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    try:
        ansible_module_0 = AnsibleModule(ohai_fact_collector_0)
    except:
        bool_1 = False
        assert bool_1
    ohai_fact_collector_0.get_ohai_output(ansible_module_0)



# Generated at 2022-06-24 23:14:46.567264
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = MockModule()
    ohai_path = ohai_fact_collector_0.find_ohai(module_0)

    if not ohai_path:
        return

    rc, out, err = ohai_fact_collector_0.run_ohai(module_0, ohai_path)
    if rc != 0:
        return

    ohai_fact_collector_0.get_ohai_output(module_0)


# Generated at 2022-06-24 23:14:50.200659
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)


# Generated at 2022-06-24 23:14:53.267900
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module = None
    ohai_fact_collector_0.get_ohai_output(module)

# Generated at 2022-06-24 23:14:55.426687
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    return ohai_fact_collector_0.get_ohai_output()


# Generated at 2022-06-24 23:15:03.665424
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path_0 = 'ohai_path'
    module_1 = 'module'
    module_0 = module_1
    ohai_fact_collector_0._ohai_fact_collector__run_ohai(module_0, ohai_path_0)
    module_2 = 'module'
    ohai_fact_collector_0._ohai_fact_collector__run_ohai(module_2, ohai_path_0)
    module_3 = 'module'
    ohai_fact_collector_0._ohai_fact_collector__run_ohai(module_3, ohai_path_0)
    module_4 = 'module'
    ohai_fact_collector_0._ohai

# Generated at 2022-06-24 23:15:09.243822
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    bool_1 = True
    ohai_fact_collector_1 = OhaiFactCollector(bool_1)
    module_1 = mock.Mock()
    ohai_path_1 = 'dummy'
    return_value_1 = (0, 'dummy', 'dummy')
    module_1.run_command.return_value = return_value_1
    return_value_2 = ohai_fact_collector_1.run_ohai(module_1,
                                                    ohai_path_1)
    assert return_value_2 == return_value_1
    return_value_1 = module_1.run_command.assert_called_with(ohai_path_1)


# Generated at 2022-06-24 23:15:18.887633
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module_0 = MagicMock(return_value=False)
    module_0._name = '_name'
    module_0._name = '_name'
    module_0._name = '_name'
    module_0.run_command = MagicMock(return_value=[0, 'stdout', 'stderr'])
    module_0.run_command = MagicMock(side_effect=TestException(IOError, IOError('IO Error')))
    module_0.run_command = MagicMock(return_value=[1, 'stdout', 'stderr'])

# Generated at 2022-06-24 23:15:26.307136
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    int_0 = 0
    bool_1 = False
    module_0 = AnsibleModule(argument_spec=module_arg_spec, supports_check_mode=bool_1)
    module_0.params = dict()
    ohai_fact_collector_0.find_ohai(module_0)


# Generated at 2022-06-24 23:15:28.397586
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    collected_facts = {}
    # Unit test stub
    try:
        collected_facts = ohai_fact_collector_0.collect()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:15:30.418109
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # no arg test
    test_case_0()


if __name__ == "__main__":
    test_OhaiFactCollector_collect()

# Generated at 2022-06-24 23:16:08.492203
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module_0 = ohai_fact_collector_0
    module_0 = ohai_fact_collector_0
    map_0 = ohai_fact_collector_0.collect(module_0)
    assert map_0['ohai_os'] == 'Linux'


# Generated at 2022-06-24 23:16:16.656795
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec={})
    ohai_path_0 = '/usr/bin/ohai'
    from ansible.module_utils._text import to_text

    rc_0, out_0, err_0 = ohai_fact_collector_0.run_ohai(ansible_module_0, ohai_path_0)
    assert rc_0 == 0
    assert to_text(out_0) == '{}'
    assert to_text(err_0) == ''


# Generated at 2022-06-24 23:16:22.035196
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Test case 0
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path_0 = ohai_fact_collector_0.find_ohai('ansible')
    if ohai_path_0:
        ohai_fact_collector_0.run_ohai('ansible', ohai_path_0, )


# Generated at 2022-06-24 23:16:23.746832
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # FIXME: Add tests for method OhaiFactCollector.get_ohai_output()
    assert True == True


# Generated at 2022-06-24 23:16:25.421724
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)



# Generated at 2022-06-24 23:16:28.835557
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector(None)
    ansible_module_0 = AnsibleModule()
    ohai_fact_collector_1.get_ohai_output(ansible_module_0)


# Generated at 2022-06-24 23:16:33.376248
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Initialize a class instance
    ohai_fact_collector_0 = OhaiFactCollector()

    # Call the method
    # FIXME: get rid of the values in the test
    # FIXME: get rid of all the None/''/[] and fail the test with an exception
    value_0 = ohai_fact_collector_0.collect(module=None)

    assert((value_0 == {}))


# Generated at 2022-06-24 23:16:35.831842
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    try:
        ohai_fact_collector_collect_None = OhaiFactCollector().collect()
        print(ohai_fact_collector_collect_None)
    except Exception:
        print("Exception")


# Generated at 2022-06-24 23:16:39.293033
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)


# Generated at 2022-06-24 23:16:46.011538
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    bool_0 = True
    bool_1 = False
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    ohai_fact_collector_1 = OhaiFactCollector(bool_1)
    assert ohai_fact_collector_0.run_ohai() == ohai_fact_collector_1.run_ohai()


# Generated at 2022-06-24 23:18:17.251870
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''
    Test method "run_ohai" of class OhaiFactCollector
    '''
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    bool_0 = True
    module_0 = AnsibleFakeModule(bool_0)
    str_0 = 'ohai'
    str_1 = ''
    rc_0, out_0, err_0 = ohai_fact_collector_0.run_ohai(module_0, str_0, str_1)


# Generated at 2022-06-24 23:18:20.718549
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    # FIXME
    module = None
    ohai_facts = ohai_fact_collector_0.get_ohai_output(module)


# Generated at 2022-06-24 23:18:23.938968
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    bool_0 = True
    bool_1 = bool_0
    bool_2 = bool_1
    ohai_fact_collector_0 = OhaiFactCollector(bool_2)
    module_0 = None
    ohai_path_0 = None
    rc_0, out_0, err_0 = ohai_fact_collector_0.run_ohai(module_0, ohai_path_0)


# Generated at 2022-06-24 23:18:32.453231
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class Module:
    # FIXME: this is just a stub
        def get_bin_path(self, args, executable=None, required=False, opt_dirs=[]):
            return "/bin/ls"
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', expand_user_and_vars=False, stdin=None):
            return (1, "", "")
    module_0 = Module()
    out_

# Generated at 2022-06-24 23:18:41.540055
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module_0 = getattr(module_0, 'module_0', Any())
    ohai_path_0 = ohai_fact_collector_0.find_ohai(module_0)
    # Calling the method without arguments
    int_0, str_0, str_1 = ohai_fact_collector_0.run_ohai(module_0, ohai_path_0)

    # TEST
    assert int_0 == 0

    # TEST
    assert str_0 == 'ohai_data'



# Generated at 2022-06-24 23:18:43.639029
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass



# Generated at 2022-06-24 23:18:46.305503
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    module_0 = object()
    out = ohai_fact_collector_0.get_ohai_output(module_0)
    return out


# Generated at 2022-06-24 23:18:50.241546
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    collector = OhaiFactCollector(collectors=None, namespace=None)

    # Run the code to be tested
    result = collector.find_ohai(ansible_module='ansible_module')

    # Check the result
    assert result == 'ohai'


# Generated at 2022-06-24 23:18:54.831776
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class MockModule:
        def get_bin_path(self, arg_0):
            mock_get_bin_path = MockModule()
            return mock_get_bin_path

    bool_0 = True
    ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    result_0 = ohai_fact_collector_0.find_ohai(MockModule())
    assert result_0 is not None



# Generated at 2022-06-24 23:18:57.772629
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    bool_0 = True
    # FIXME: Remove the try/except, this should never be raised
    try:
        ohai_fact_collector_0 = OhaiFactCollector(bool_0)
    except TypeError:
        pass
    except NameError:
        pass
