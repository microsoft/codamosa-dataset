

# Generated at 2022-06-24 23:11:13.521633
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ansible_module_for_ohai = AnsibleModule(argument_spec=dict())
    ohai_fact_collector = OhaiFactCollector()
    out = ohai_fact_collector.run_ohai(ansible_module_for_ohai, "ohai")
    assert out != None

# Generated at 2022-06-24 23:11:16.618427
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.get_ohai_output() == None


# Generated at 2022-06-24 23:11:21.567491
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    print('run_ohai: ' + str(ohai_fact_collector_0.run_ohai()))


# Generated at 2022-06-24 23:11:23.745559
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.collect()


# Generated at 2022-06-24 23:11:34.160277
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    class Module:
        def get_bin_path(self, bin_path):
            return '/bin/ohai'

        def run_command(self, ohai_path):
            return 0, """
                       {"platform": "centos",
                        "platform_version": "7",
                        "platform_family": "rhel",
                        "platform_release": "7.0.1406"}
                      """, ''
    ohai_fact_collector_get_ohai_output = ohai_fact_collector.get_ohai_output(Module())

# Generated at 2022-06-24 23:11:34.713947
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    a = OhaiFactCollector()


# Generated at 2022-06-24 23:11:37.785797
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    ohai_output = ohai_fact_collector.get_ohai_output(None)
    assert ohai_output is None


# Generated at 2022-06-24 23:11:46.232046
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    # Mock the module object used
    ohai_fact_collector_1 = OhaiFactCollector()

    from ansible.module_utils.facts.collector.ohai import module
    ohai_fact_collector_1.module = module
    ohai_fact_collector_1.module.run_command = run_command
    ohai_fact_collector_1.module.run_command.return_value = (0, '{"foo": "bar"}', None)
    ohai_fact_collector_1.find_ohai = find_ohai
    ohai_fact_collector_1.find_ohai.return_value = "ohai"

    results = ohai_fact_collector_1.get_ohai_output(ohai_fact_collector_1.module)


# Generated at 2022-06-24 23:11:54.570719
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    '''
    Json output from Ohai
    '''

# Generated at 2022-06-24 23:11:59.479610
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModule(
        argument_spec=dict(
            ansible_facts=dict()
            )
        )
    # AnsibleModule.get_bin_path stub
    def get_bin_path_0(*p_args, **kwargs):
        return 'ohai_path'
    module_0.get_bin_path = get_bin_path_0
    # AnsibleModule.run_command stub
    def run_command_0(*p_args, **kwargs):
        return 'rc', 'out', 'err'
    module_0.run_command = run_command_0

    result_0 = ohai_fact_collector_0.get_ohai_output(module_0)

# Generated at 2022-06-24 23:12:10.860557
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector = OhaiFactCollector()

    module = None
    ohai_path = '/tmp/ohai_test1'
    rc, out, err = ohai_fact_collector.run_ohai(module, ohai_path)
    assert rc == -1
    assert out == ''
    assert err == ''

    module = None
    ohai_path = '/tmp/ohai_test2'
    rc, out, err = ohai_fact_collector.run_ohai(module, ohai_path)
    assert rc == -1
    assert out == ''
    assert err == ''

    module = None
    ohai_path = '/tmp/ohai_test3'

# Generated at 2022-06-24 23:12:14.992521
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    module = AnsibleFakeModule()
    ohai_fact_collector_0.run_ohai = AnsibleFakeMethod()
    ohai_fact_collector_0.run_ohai.return_value = (0, "Ohai Facts Here", "")
    data = ohai_fact_collector_0.collect(module)
    assert data == {}

test_case_0()

# Generated at 2022-06-24 23:12:18.825383
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.get_ohai_output = lambda x: None
    facts = ohai_fact_collector.collect()
    assert isinstance(facts, dict)


# Generated at 2022-06-24 23:12:20.789917
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_obj = OhaiFactCollector()
    # FIXME: Write unit test for this method
    pass

# Generated at 2022-06-24 23:12:28.522954
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Declare and initialize the object under test
    ohai_fact_collector_1 = OhaiFactCollector()
    # assign a mock values for the following attributes
    # ohai_fact_collector_1.get_ohai_output = 'ohai_output'
    expected_output = 'ohai_output'
    # call the method get_ohai_output
    actual_output = ohai_fact_collector_1.get_ohai_output('module')
    # compare the actual output with the expected output
    assert actual_output == expected_output


# Generated at 2022-06-24 23:12:31.773743
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_output_1 = ohai_fact_collector_1.get_ohai_output(None)

    assert(ohai_output_1 is None)


# Generated at 2022-06-24 23:12:32.679762
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:12:34.952934
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_facts = ohai_fact_collector_1.collect()
    assert ohai_facts is not None

# Generated at 2022-06-24 23:12:44.297662
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    class ModuleStub():
        def get_bin_path(self,  name):
            return 'ohai'

        def run_command(self, cmd):
            if 'ohai' in cmd:
                return 0, json.dumps({'foo': 'bar'}), None
            else:
                return -1, None, None

    module_stub = ModuleStub()

    class CollectedFactsStub():
        pass

    collected_facts_stub = CollectedFactsStub()

    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.collect(module=module_stub,
                                         collected_facts=collected_facts_stub) == {'foo': 'bar'}

# Generated at 2022-06-24 23:12:55.154569
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_1 = MockModule()

# Generated at 2022-06-24 23:13:03.863473
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_fact_collector_1.collect = lambda x: json.loads('{"test": "test_value"}')

    expected = json.loads('{"test": "test_value"}')
    actual = ohai_fact_collector_1.get_ohai_output(None)

    assert expected == actual



# Generated at 2022-06-24 23:13:13.097954
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    class Parameters():
        def __init__(self):
            self.ohai_path = True
        def get_bin_path(self, *args, **kwargs):
            if self.ohai_path:
                return '/usr/bin/ohai'
            else:
                return None
        def run_command(self, *args, **kwargs):
            return 0, 'ohai_output', ''
    parameters = Parameters()
    ohai_fact_collector._module = parameters
    ohai_fact_collector.get_ohai_output()
    parameters.ohai_path = False
    ohai_fact_collector.get_ohai_output()


# Generated at 2022-06-24 23:13:15.972079
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = MockModule()
    rc, out = ohai_fact_collector_0.get_ohai_output(module_0)
    assert rc == 0
    assert out == "ohai output"


# Generated at 2022-06-24 23:13:21.958762
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    result = ohai_fact_collector_0.collect()
    assert isinstance(result, dict)
    result2 = ohai_fact_collector_0.collect()
    assert result == result2


# Generated at 2022-06-24 23:13:23.701227
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    ohai_fact_collector_collect = OhaiFactCollector()
    ohai_fact_collector_collect.collect()

# Generated at 2022-06-24 23:13:24.228252
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    pass

# Generated at 2022-06-24 23:13:25.358310
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:13:28.028896
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_mock = OhaiModuleMock()
    ohai_fact_collector_0.collect(module=module_mock)


# Generated at 2022-06-24 23:13:33.578329
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    param_1 = None          # (type: dict)

    collected_facts_0 = ohai_fact_collector_0.collect(collected_facts=param_1)
    collectd_collector_0 = CollectdFactCollector()
    collected_facts_1 = collectd_collector_0.collect()
    assert type(collected_facts_0) is dict, "Returned value '%s' is not of class 'dict'" % type(collected_facts_0)
    assert type(collected_facts_1) is dict, "Returned value '%s' is not of class 'dict'" % type(collected_facts_1)


# Generated at 2022-06-24 23:13:36.485599
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path = ohai_fact_collector_0.find_ohai(None)
    print(ohai_path)


# Generated at 2022-06-24 23:13:47.993210
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_get_ohai_output = OhaiFactCollector()
    def mock_get_bin_path(self, arg):
        return '/bin/ansible'
    ohai_fact_collector_get_ohai_output.get_bin_path = mock_get_bin_path
    def mock_run_command(self, arg):
        return 0, "fact1: value1", ''
    ohai_fact_collector_get_ohai_output.run_ohai = mock_run_command
    def mock_ohai_output(self):
        return {'fact1': 'value1'}
    ohai_fact_collector_get_ohai_output.get_ohai_output = mock_ohai_output


# Generated at 2022-06-24 23:13:58.741710
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    # Test if the return value is not None
    assert ohai_fact_collector_0.collect() is not None
    # Test if number of keys of return value is 10
    assert len(ohai_fact_collector_0.collect()) == 10
    # Test if a key of return value is 'languages'
    assert 'languages' in ohai_fact_collector_0.collect()
    # Test if a key of return value is 'current_user'
    assert 'current_user' in ohai_fact_collector_0.collect()
    # Test if a key of return value is 'fqdn'
    assert 'fqdn' in ohai_fact_collector_0.collect()
    # Test if a key of return value is '

# Generated at 2022-06-24 23:14:08.831320
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class TestModule(object):
        def __init__(self):
            self.path = '/usr/bin'

        def get_bin_path(self, binary):
            if binary == 'ohai':
                return self.path

        def run_command(self, binary):
            if binary == '/usr/bin/ohai':
                return 0, '{\"foo\": \"bar\"}', ''
            else:
                return 1, '', ''

    test_module_0 = TestModule()
    ohai_fact_collector_0 = OhaiFactCollector()

    rc, out, err = ohai_fact_collector_0.run_ohai(test_module_0, '/usr/bin/ohai')
    assert rc == 0
    assert out == '{\"foo\": \"bar\"}'

# Generated at 2022-06-24 23:14:17.239409
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # test case 0
    ohai_fact_collector_0 = OhaiFactCollector()
    actual_result_0 = ohai_fact_collector_0.collect()
    expected_result_0 = {}
    assert actual_result_0 == expected_result_0


if __name__ == '__main__':
    module = AnsibleModule(
        argument_spec=dict(),
    )
    # unit tests
    test_case_0()
    test_OhaiFactCollector_collect()

    # exit
    module.exit_json(**{'ohai': ohai_fact_collector_0.collect()})

# Generated at 2022-06-24 23:14:20.651589
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_facts_dict_1 = ohai_fact_collector_1.collect()
    assert type(ohai_facts_dict_1) is dict
    assert 'ohai_platform' in ohai_facts_dict_1

# Generated at 2022-06-24 23:14:27.452557
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_1 = OhaiFactCollector()
    class module0(object):
        def get_bin_path(self, bin_path, required=False):
            return 'test/test_ohai'
        def run_command(self, cmd, tmp_path, remote_tmp, connection,
                        executable, sudo_user=None, sudoable=False,
                        check_rc=True, close_fds=True, executable_exists_check=True):
            return 0, '{"foo":"bar"}', ''

    ohai_fact_collector_1._module = module0()
    rc, out, err = ohai_fact_collector_1.run_ohai(module0(),
                                                  'test/test_ohai')
    assert rc == 0

# Generated at 2022-06-24 23:14:35.048433
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    # Stub for module.get_bin_path
    def get_bin_path(arg_0):
        if arg_0 == 'ohai':
            return '/opt/local/bin/ohai'
    # Stub for module.run_command
    def run_command(arg_0):
        if arg_0 == '/opt/local/bin/ohai':
            return (0, json.dumps({'ansible_facts': {'ohai_fact_collector': 'succeeded'}}, ensure_ascii=False), None)
    ohai_fact_collector_0._module.get_bin_path = get_bin_path
    ohai_fact_collector_0._module.run_command = run_command
    # Inv

# Generated at 2022-06-24 23:14:37.491233
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path = ohai_fact_collector_0.find_ohai()
    assert ohai_path is not None


# Generated at 2022-06-24 23:14:44.183797
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.internal_proxy import FactInternalProxy

    module_0 = FactInternalProxy()
    ohai_fact_collector_0 = OhaiFactCollector()
    ansible_facts_0 = ohai_fact_collector_0.collect(module=module_0)

    assert not ansible_facts_0


# Generated at 2022-06-24 23:14:46.097520
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModule(argument_spec={})
    ohai_fact_collector_0.get_ohai_output(module_0)


# Generated at 2022-06-24 23:15:01.055399
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module_mock = Mock()
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output(module_mock)
    ohai_fact_collector_0.collect(module_mock, set())

if __name__ == '__main__':
    from unittest import mock
    Mock = mock.Mock
    test_OhaiFactCollector_collect()
    test_case_0()

# Generated at 2022-06-24 23:15:07.156718
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

    # create instance of module.
    class DummyModule:
        def __init__(self):
            self.bin_path_cache = {}
        def get_bin_path(self, binary):
            return self.bin_path_cache[binary]
        def run_command(self, binary):
            return None, None, None
    module_0 = DummyModule()

    # assign values to the module.bin_path_cache dictionary.
    module_0.bin_path_cache = {'ohai': 'ohai_bin'}

    # create instance of ohai that returns 'ohai_bin' for get_bin_path and 'output_0', 0, '' for run_command.

# Generated at 2022-06-24 23:15:17.145728
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class MockModule(object):
        def __init__(self, get_bin_path_value, run_command_value):
            self.get_bin_path_value = get_bin_path_value
            self.run_command_value = run_command_value
            self.run_command_call_count = 0
        def get_bin_path(self, arg_1, *args, **kwargs):
            return self.get_bin_path_value
        def run_command(self, *args, **kwargs):
            self.run_command_call_count += 1
            return self.run_command_value

# Generated at 2022-06-24 23:15:22.367470
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()

    # Test with module = None
    assert ohai_fact_collector_0.collect() == {}

    # Test with module = None
    assert ohai_fact_collector_0.collect(collected_facts={}) == {}


# Generated at 2022-06-24 23:15:28.377240
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module0 = AnsibleModule()
    ohai_fact_collector0 = OhaiFactCollector()
    ohai_fact_collector0.find_ohai = lambda x: "/path/to/ohai"
    ohai_fact_collector0.run_ohai = lambda x, y: (0, '{"cpu":{"0":"cpu0","1":"cpu1"},"disk":{"xvda":{"size":"30G"}},"kernel":"Linux"}', '')
    assert ohai_fact_collector0.get_ohai_output(module0) == '{"cpu":{"0":"cpu0","1":"cpu1"},"disk":{"xvda":{"size":"30G"}},"kernel":"Linux"}'


# Generated at 2022-06-24 23:15:31.067885
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''
    Unit test for method run_ohai of class OhaiFactCollector
    '''
    ohai_fact_collector_obj = OhaiFactCollector()
    try:
        ohai_fact_collector_obj.run_ohai(None, 'ohai_path')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:15:36.143454
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    '''Unit test for method collect of class OhaiFactCollector'''
    ohai_fact_collector_0 = OhaiFactCollector()
    result_0 = ohai_fact_collector_0.collect()
    assert result_0 == {}


# Generated at 2022-06-24 23:15:42.525148
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    test_case_name = 'test_OhaiFactCollector_get_ohai_output'
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_output_1 = ohai_fact_collector_1.get_ohai_output(None)
    assert ohai_output_1 is None, 'Failed test %s' % test_case_name

# Generated at 2022-06-24 23:15:48.223125
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = None
    assert ohai_fact_collector_0.get_ohai_output(module_0) is None


# Generated at 2022-06-24 23:15:49.314894
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.collect()


# Generated at 2022-06-24 23:16:17.468306
# Unit test for method collect of class OhaiFactCollector

# Generated at 2022-06-24 23:16:20.906989
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    fact_collector_0 = OhaiFactCollector()
    mod_0 = MockModule()

    ret_0 = fact_collector_0.find_ohai(mod_0)

    assert ret_0 == 'ohai'



# Generated at 2022-06-24 23:16:23.278523
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    output = ohai_fact_collector_0.collect()
    assert output is not None

# Generated at 2022-06-24 23:16:27.156263
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    test_OhaiFactCollector = OhaiFactCollector()
    module = None
    ohai_path = "path_to_ohai"
    rc = test_OhaiFactCollector.run_ohai(module, ohai_path)
    assert rc == (0, b'{"name": "value"}', b'')

# Generated at 2022-06-24 23:16:35.477745
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class FakeModule:
        def get_bin_path(self, bin_path):
            return '/opt/bin'
        def run_command(self, ohai_path):
            return 0, '{ "kernel": { "architecture": "amd64" } }', 'error'
    fake_module_0 = FakeModule()
    assert ohai_fact_collector_0.get_ohai_output(fake_module_0) == '{ "kernel": { "architecture": "amd64" } }'

# Generated at 2022-06-24 23:16:43.589788
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Mock AnsibleModule
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec = dict()
        )

    # Mock AnsibleModule.get_bin_path
    import os
    m.get_bin_path = lambda x: os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/find_ohai')

    ohai_fact_collector_0 = OhaiFactCollector()

    # substitute return value of mocked function
    ohai_path = ohai_fact_collector_0.find_ohai(m)

    assert ohai_path is not None
    assert ohai_path == 'find_ohai_return'


# Generated at 2022-06-24 23:16:44.757617
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    pass

# Generated at 2022-06-24 23:16:53.684797
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModule(argument_spec={})
    module_0.params['path'] = '/bin:/usr/bin:/usr/local/bin'
    assert ohai_fact_collector_0.find_ohai(module_0) is None
    module_0.params['path'] = '/bin:/usr/bin:/usr/local/bin:/usr/local/bin/ohai'
    assert ohai_fact_collector_0.find_ohai(module_0) is None
    module_0.params['path'] = '/bin:/usr/bin:/usr/local/bin:/usr/local/bin/ohai:/usr/bin/ohai'
    assert ohai_fact_collector_0.find_ohai(module_0)

# Generated at 2022-06-24 23:17:00.191808
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector = OhaiFactCollector()
    ohai_path = '/usr/bin/ohai'
    module = FakeModule()
    module.get_bin_path.return_value = '/usr/bin/ohai'

    rc, out, err = ohai_fact_collector.run_ohai(module, ohai_path)



# Generated at 2022-06-24 23:17:01.916801
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert isinstance(ohai_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:17:49.933841
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import *
    from ansible.module_utils.facts.collector import *
    from ansible.module_utils.facts.namespace import *

    class Module(object):

        def get_bin_path(self, command):
            return '/usr/bin/ohai'

        def run_command(self, command):
            return (0, '{ "foo": "bar" }', '')

    module = Module()
    ohai_fact_collector_0 = OhaiFactCollector(collectors=None, namespace=None)

    try:
        ohai_fact_collector_0.get_ohai_output(module=module)
    except Exception as e:
        assert False



# Generated at 2022-06-24 23:17:52.003485
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_path_result = find_ohai()
    assert ohai_path_result == 'ohai'


# Generated at 2022-06-24 23:17:56.902924
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.find_ohai('ohai') == '/usr/bin/ohai'


# Generated at 2022-06-24 23:18:01.271061
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    pass


# Generated at 2022-06-24 23:18:02.554567
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:18:08.149074
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModule({})
    item_dict_0 = {}
    assert ohai_fact_collector_0.collect(module=module_0, collected_facts=item_dict_0) == {}

    ohai_fact_collector_1 = OhaiFactCollector()
    module_1 = AnsibleModule({})
    item_dict_1 = {}
    assert ohai_fact_collector_1.collect(module=module_1, collected_facts=item_dict_1) == {}


# Generated at 2022-06-24 23:18:09.495467
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # FIXME: mock module, use it to test find_ohai
    pass


# Generated at 2022-06-24 23:18:14.795484
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    test_module_1 = None
    test_collected_facts_1 = None
    test_ohai_facts_1 = ohai_fact_collector_0.collect(module=test_module_1, collected_facts=test_collected_facts_1)

# Generated at 2022-06-24 23:18:18.234377
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()

    ohai_fact_collector.collect()


# Generated at 2022-06-24 23:18:21.708072
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            bin_path = 'ohai'
            return bin_path

        def run_command(self, command_args):
            pass

    mock_module_0 = MockModule()
    ohai_fact_collector_0 = OhaiFactCollector()

    ohai_fact_collector_0.get_ohai_output(mock_module_0)



# Generated at 2022-06-24 23:20:06.202455
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    o = OhaiFactCollector()
    o.find_ohai()


# Generated at 2022-06-24 23:20:12.601720
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class module_mock:
        def __init__(self):
            self.params = {
                'ansible_facts': {
                    'ohai_output': 'ohai_output',
                },
            }
        def get_bin_path(self, path):
            return '/path/to/ohai'
        def run_command(self, path):
            if path == '/path/to/ohai':
                return 0, 'ohai_output', ''
            return 0, '', ''
    ohai_fact_collector_0.module = module_mock()
    assert ohai_fact_collector_0.get_ohai_output() == 'ohai_output'


# Generated at 2022-06-24 23:20:17.003165
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path = ohai_fact_collector_0.find_ohai()

# Generated at 2022-06-24 23:20:26.127503
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # In this test case, we are mocking the ansible module object. The mock object
    # contains the method 'get_bin_path'. This method will return a string that is not null.
    # The expected result of the following test case is: ohai_output is not None
    ohai_fact_collector = OhaiFactCollector()
    ohai_path = 'not_empty'
    rc, out, err = ohai_fact_collector.run_ohai(ohai_path, 'module')
    ohai_output = ohai_fact_collector.get_ohai_output('module')
    assert ohai_output is not None

    # In this test case, we are mocking the ansible module object. The mock object
    # contains the method 'get_bin_path'. This method will return a string that is empty.
   

# Generated at 2022-06-24 23:20:33.526952
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    ohai_fact_collector_10 = OhaiFactCollector()

    module_11 = {
        'get_bin_path': lambda: None,
        'run_command': lambda: (0, '{}', None),
    }

    result_12 = ohai_fact_collector_10.get_ohai_output(module_11)

    assert result_12 == None

    ohai_fact_collector_13 = OhaiFactCollector()

    module_14 = {
        'get_bin_path': lambda: None,
    }

    result_15 = ohai_fact_collector_13.get_ohai_output(module_14)

    assert result_15 == None

    ohai_fact_collector_16 = OhaiFactCollector()


# Generated at 2022-06-24 23:20:40.747001
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()

    class MockModule(object):
        def run_command(self, ohai_path):
            return 0, '{"some":"value"}', ''

        def get_bin_path(self, command):
            return command

    assert ohai_fact_collector.get_ohai_output(MockModule()) == "{\"some\":\"value\"}", "get_ohai_output should return JSON data with ohai fact values"


# Generated at 2022-06-24 23:20:44.298992
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()


# Generated at 2022-06-24 23:20:49.175573
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    collected_facts = {
        'facter': {
            'virtual': 'xenu',
        },
    }
    module_mock = {
        'run_command': lambda ohai_path: (0, '{ "virtual": "xenu" }', ''),
        'get_bin_path': lambda ohai_path: None,
    }
    ohai_fact_collector_0.collect(module=module_mock, collected_facts=collected_facts)


# Generated at 2022-06-24 23:20:58.921142
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    try:
        src = '''
            import ansible.module_utils.facts.ohai.ohai as ohai
            ohai_fact_collector = ohai.OhaiFactCollector()
            result = ohai_fact_collector.find_ohai(module)
            '''
        results = run_ansible_module(src, {'module': {'get_bin_path': lambda path: '/bin/ohai'}})
        assert results['result'] == '/bin/ohai'
    except ImportError:
        throw_skip_exception()


# Generated at 2022-06-24 23:21:00.426245
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    test_module = 'test_module'
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.run_ohai(test_module, 
        ohai_fact_collector.find_ohai(test_module))[0] == 0