

# Generated at 2022-06-24 23:11:06.887405
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.collect()

# Generated at 2022-06-24 23:11:17.744733
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()

    # We need to setup a mock module, but cannot import one, so we'll
    # use an arbitrary class that has a few methods we'll need
    class MockModule:
        def get_bin_path(self, arg):
            return 'ohai_bin_path'
        def run_command(self, arg):
            return 0, 'ohai_output', 'stderr'

    module_1 = MockModule()

    result_1 = ohai_fact_collector_1.get_ohai_output(module_1)

    assert result_1 == 'ohai_output'


# Generated at 2022-06-24 23:11:26.846526
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ohai_fact_collector_0 = OhaiFactCollector(collectors=None, namespace=None)
    ohai_fact_collector_0.run_ohai()
    # Test for successful initialization of the object.
    assert isinstance(ohai_fact_collector_0, OhaiFactCollector)
    # Test for successful initialization of the parent object.
    assert isinstance(ohai_fact_collector_0, BaseFactCollector)
    # Test for successful initialization of the parent's parent object.
    assert isinstance(ohai_fact_collector_0, PrefixFactNamespace)


# Generated at 2022-06-24 23:11:28.282852
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.find_ohai(None)


# Generated at 2022-06-24 23:11:29.405528
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()

# Generated at 2022-06-24 23:11:33.064163
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class FakeModule:
        def get_bin_path(self, binary_name):
            return '/usr/bin/ohai'
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_path_0 = ohai_fact_collector_0.find_ohai(FakeModule())
    assert ohai_path_0 == '/usr/bin/ohai'


# Generated at 2022-06-24 23:11:41.054745
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class Mock(object):
        def run_command(self, ohai_path):
            return 0, '{\"platform\": \"ubuntu\", \"version\": \"16.04\"}', ''
        def get_bin_path(self, ohai):
            return 'which ohai'
    mock_module = Mock()
    rc, out, err = ohai_fact_collector_0.run_ohai(mock_module, 'ohai')
    assert rc == 0
    return


# Generated at 2022-06-24 23:11:46.818891
# Unit test for method run_ohai of class OhaiFactCollector

# Generated at 2022-06-24 23:11:54.926328
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()

    # Collect facts from dummy data
    collected_facts = {'ohai': {'item': '0'}}
    ohai_fact_collector.collect(collected_facts=collected_facts)

    # Collect facts calling ohai
    import ansible.module_utils.facts.system.ohai as ohai_mock_module
    ohai_path = None

    def mock_get_bin_path(binary):
        global ohai_path
        if binary == 'ohai':
            ohai_path = True
            return True
        return None

    ohai_mock_module.get_bin_path = mock_get_bin_path

    def mock_run_command(binary):
        global ohai_path
        assert ohai_path
       

# Generated at 2022-06-24 23:12:00.040747
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()
    class MockModule:
        def get_bin_path(self, bin_path):
            return 'OhaiPath'
        def run_command(self, ohai_path):
            return 0, 'OhaiOut', 'OhaiOut'
    module_0 = MockModule()
    assert ohai_fact_collector_1.get_ohai_output(module_0) == 'OhaiOut'

# Generated at 2022-06-24 23:12:13.458467
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()

    class AnsibleModuleFake(object):
        def get_bin_path(self, *args, **kwargs):
            return '/bin/ls'

        def run_command(self, *args, **kwargs):
            return 0, 'Test output', 'Test error'

    am = AnsibleModuleFake()
    result = ohai_fact_collector_0.get_ohai_output(am)

    assert result == 'Test output'

    class AnsibleModuleFake2(object):
        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return 0, 'Test output', 'Test error'

    am2 = AnsibleModuleFake2()
    result

# Generated at 2022-06-24 23:12:23.756311
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    fake_module_0 = object()
    ohai_fact_collector_0 = OhaiFactCollector()

    def run_command_side_effect(args, check_rc=False):
        if args == ['ohai']:
            return 0, 'fake_out_0', 'fake_err_0'
        else:
            return 0, 'fake_out_1', 'fake_err_1'

    fake_module_0.run_command = fake_module_0.run_command = run_command_side_effect

    def get_bin_path_side_effect(executable):
        if executable == 'ohai':
            return 'ohai'
        else:
            return None

    fake_module_0.get_bin_path = get_bin_path_side_effect

    result_0 = ohai_

# Generated at 2022-06-24 23:12:25.214518
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    assert ohai_fact_collector_0.find_ohai(module)



# Generated at 2022-06-24 23:12:31.035552
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_mock_0 = Mock()
    module_mock_0.get_bin_path.return_value = '/bin/ohai'
    return_value_0 = ohai_fact_collector_0.find_ohai(module=module_mock_0)
    assert return_value_0 == '/bin/ohai'


# Generated at 2022-06-24 23:12:33.661935
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Testing a method from a class is out of the scope of this project. So, this
    # stub is never supposed to be tested.
    pass


# Generated at 2022-06-24 23:12:40.625161
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    def mock_get_bin_path(bin_name):
        return bin_name
    ohai_fact_collector_0.find_ohai = mock_get_bin_path
    ohai_fact_collector_0.find_ohai('bake')



# Generated at 2022-06-24 23:12:48.379977
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    class MockModule(object):
        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
            return 0, json.dumps({ 'os': 'Darwin', 'kernel': {'version': '16.7.0'}, 'platform': 'mac_os_x' }), None

        def get_bin_path(self, arg, opt_dirs=[]):
            return "/usr/bin/ohai"

    ohai_fact_collector_0 = OhaiFactCollector()
    var_0 = ohai_fact_collector_0.get_ohai_output(MockModule())
    assert var_0

# Generated at 2022-06-24 23:12:53.039240
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_0 = AnsibleModule(argument_spec=dict())
    ohai_path = '/usr/bin/ohai'
    rc, out, err = ohai_fact_collector_0.run_ohai(module_0, ohai_path)
    assert (out is not None)


# Generated at 2022-06-24 23:12:56.793063
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_result = ohai_fact_collector_1.run_ohai(None, "")


# Generated at 2022-06-24 23:13:05.763608
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a OhaiFactCollector object
    ohai_fact_collector_0 = OhaiFactCollector()

    # Create a module_utils.basic.AnsibleModule object to test collect method
    # passing a argument_spec dict containing a dict of dicts
    module_args = dict(
        argument_spec=dict(
            foo=dict(default=dict(bar='bar_default_value')),
        )
    )
    basic_AnsibleModule_0 = AnsibleModule(**module_args)

    # Calling collect method of class OhaiFactCollector with basic_AnsibleModule_0 object as argument
    ohai_fact_collector_0.collect(basic_AnsibleModule_0)

# Generated at 2022-06-24 23:13:15.275111
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    ohai_fact_collector = OhaiFactCollector(module)
    ohai_fact_collector.collect()

# Generated at 2022-06-24 23:13:20.457956
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    fact_collector = OhaiFactCollector()
    ohai_output = fact_collector.get_ohai_output(None)
    assert ohai_output is None

# Generated at 2022-06-24 23:13:29.767602
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    # mock ohai's output
    class OhaiOutput(object):
        def __init__(self, ohai_output):
            self.ohai_output = ohai_output
        def read(self):
            return self.ohai_output
    # mock open and return the mocked ohai's output
    def mocked_open(filename, mode):
        if filename == '/tmp/ohai.json':
            return OhaiOutput('{"key": "value"}')
        else:
            return open(filename, mode)
    # mock find_ohai and return the location of ohai.json file
    def mocked_find_ohai(self, module):
        # ohai's json file is generated under /tmp directory
        return '/tmp/ohai.json'


# Generated at 2022-06-24 23:13:31.135566
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:13:39.280693
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = AnsibleModuleMock(path=[module_utils_path])
    ohai_fact_collector = OhaiFactCollector()

    ohai_fact_collector.find_ohai = MagicMock(return_value=None)
    output = ohai_fact_collector.get_ohai_output(module)
    assert output is None

    ohai_fact_collector.find_ohai = MagicMock(return_value='ohai_bin')
    ohai_fact_collector.run_ohai = MagicMock(return_value=(1, '', ''))
    output = ohai_fact_collector.get_ohai_output(module)
    assert output is None

    ohai_fact_collector.find_ohai = MagicMock(return_value='ohai_bin')
   

# Generated at 2022-06-24 23:13:46.288345
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
  collector = OhaiFactCollector()
  class Module0(object):
    def __init__(self):
        self._bin_path = {}
    def get_bin_path(self, name):
        return self._bin_path[name]
    def run_command(self, path):
        return 0, "{}", ""
  module0 = Module0()
  module0._bin_path['ohai'] = 'ohai'
  rc0, out0, err0 = collector.run_ohai(module0, 'ohai', )
  assert rc0 == 0
  assert out0 == "{}"
  assert err0 == ""

# Generated at 2022-06-24 23:13:51.564425
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.get_ohai_output('module_utils/ohai_facts.py')


if __name__ == '__main__':
    test_case_0()
    test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-24 23:13:54.183937
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    try:
        ohai_fact_collector_1 = OhaiFactCollector()
        ohai_fact_collector_1.find_ohai()
    except Exception:
        pass


# Generated at 2022-06-24 23:13:58.826266
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    assert isinstance(ohai_fact_collector_1.collect(), dict)


# Generated at 2022-06-24 23:14:08.935588
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class AnsibleModuleFake:
        def get_bin_path(self, name):
            return '/this/path/does/not/exist'
        def run_command(self, command):
            return 1, 'bad_ohai_output', 'stderr'

    f = OhaiFactCollector()
    assert f.get_ohai_output(AnsibleModuleFake()) is None

    class AnsibleModuleFake:
        def get_bin_path(self, name):
            return '/this/path/does/not/exist'
        def run_command(self, command):
            return 0, '{"a":"b","c":"d"}', ''

    f = OhaiFactCollector()
    result = f.get_ohai_output(AnsibleModuleFake())

# Generated at 2022-06-24 23:14:18.356789
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:14:21.044708
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector0 = OhaiFactCollector()

    # FIXME: Test here
    assert False, "Test not implemented"



# Generated at 2022-06-24 23:14:25.149082
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    fact_collector = OhaiFactCollector()
    fact_collector.collect()

# Generated at 2022-06-24 23:14:26.920858
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.collect()

# Generated at 2022-06-24 23:14:29.386484
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_1 = OhaiFactCollector()
    assert(ohai_fact_collector_1.get_ohai_output(1) == None)


# Generated at 2022-06-24 23:14:30.316780
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()

# Generated at 2022-06-24 23:14:40.058204
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class ModuleMock(object):
        def get_bin_path(self, *args, **kwargs):
            return 'testbinpath'

        def run_command(self, *args, **kwargs):
            return 0, 'testoutput', 'testerror'

    module = ModuleMock()
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_fact_collector_1.find_ohai = lambda *args, **kwargs: 'testbinpath'
    ohai_fact_collector_1.run_ohai = lambda *args, **kwargs: (0, 'testoutput', 'testerror')

    output_1 = ohai_fact_collector_1.get_ohai_output(module)

    assert isinstance(output_1, str)

# Generated at 2022-06-24 23:14:42.569420
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    module = None
    known_ohai_facts = ohai_fact_collector_1.collect(module=module)
    assert(known_ohai_facts == {})


# Generated at 2022-06-24 23:14:44.845360
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:14:52.409042
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_output = ohai_fact_collector_0.get_ohai_output(module=module)
    assert ohai_output is None


# Generated at 2022-06-24 23:15:18.963000
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    module_mock_exit = False
    class Module(object):
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 1, [], []

        def get_bin_path(self, *args, **kwargs):
            return 'ohai'

        def exit_json(self, *args, **kwargs):
            global module_mock_exit
            module_mock_exit = True
            pass

        def fail_json(self, *args, **kwargs):
            global module_mock_exit
            module_mock_exit = True
            pass


    args = {
        'path': ['ohai'],
    }
   

# Generated at 2022-06-24 23:15:23.028882
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.collect()


# Generated at 2022-06-24 23:15:27.779200
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class ModuleUtil:
        def get_bin_path(arg):
            return 'test_ohai_bin_path'

    ohai_fact_collector_1 = OhaiFactCollector()

    result_1 = ohai_fact_collector_1.find_ohai(ModuleUtil)
    if result_1 != 'test_ohai_bin_path':
        assert False



# Generated at 2022-06-24 23:15:36.483040
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector = OhaiFactCollector()
    class module:
        def get_bin_path(self, str1):
            return "./ansible/module_utils/facts/bin/ohai"

        def run_command(self, ohai_path):
            return 0, "test_output", "test_error"
    assert (0, "test_output", "test_error") == ohai_fact_collector.run_ohai(module(), ohai_fact_collector.find_ohai(module()))


# Generated at 2022-06-24 23:15:39.833248
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:15:44.283585
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class module:
        def get_bin_path(self, name):
            return '/bin/'+name

        def run_command(self,command):
            return 0,'{"test": "output"}',''

    ohai_fact_collector_1 = OhaiFactCollector()
    assert ohai_fact_collector_1.get_ohai_output(module()) == '{"test": "output"}'

# Generated at 2022-06-24 23:15:50.217672
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    # FIXME: test next line
    ohai_fact_collector_0.get_ohai_output()


# Generated at 2022-06-24 23:15:55.700417
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Test for OhaiFactCollector with no argument
    fact_collector = OhaiFactCollector()
    assert fact_collector.collect() == {}

    # Test for OhaiFactCollector with arguments
    fact_collector = OhaiFactCollector(collectors=None, namespace=None)
    assert fact_collector.collect() == {}

    fact_collector = OhaiFactCollector(collectors=None, namespace='')
    assert fact_collector.collect() == {}

# Generated at 2022-06-24 23:16:04.803830
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class Module(object):
        def __init__(self):
            self._bin_path = None
        def get_bin_path(self, ohai):
            self._bin_path = ohai
            return ohai_fact_collector_0.find_ohai(self)
        def run_command(self, ohai_path):
            rc = 0
            out = '{"platform":"ubuntu","platform_version":"14.04","kernel_version":"3.13.0-37-generic"}'
            err = ''
            return rc, out, err
    module_0 = Module()
    ohai_path = ohai_fact_collector_0.find_ohai(module_0)

# Generated at 2022-06-24 23:16:06.849768
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    assert ohai_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:16:48.869099
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    import ansible_mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import to_text
    from ansible.module_utils.facts import utils
    class FakeModule(object):
        def __init__(self):
             self.params = None
             self.check_mode = False
             self.debug = False
             self.logger = None
             self.warnings = []
             self.deprecations = []
             self.fail_json = None
             self.exit_json = None
             self._common_args = {}
             self._socket_path = None
             self._ansible_socket

# Generated at 2022-06-24 23:16:54.108622
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:17:00.516980
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    ohai_fact_collector_0 = OhaiFactCollector()
    ansible.module_utils.facts.collector.ModuleStub = ModuleStub
    ohai_fact_collector_0.get_ohai_output( ModuleStub )
    print("test_case_1 - Passed")


# Generated at 2022-06-24 23:17:10.500434
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector

    ohai_fact_collector_0 = OhaiFactCollector()

    # Stub for ansible.module_utils.facts.collector.BaseFactCollector.get_module
    def get_module_stub():
        pass

    ohai_fact_collector_0.get_module = get_module_stub
    ohai_fact_collector_0.get_ohai_output = get_ohai_output_stub
    ohai_fact_collector_0.run_ohai = run_ohai_stub
    ohai_fact_collector_0.find_ohai = find_ohai_stub

    ohai_fact_collector_0.collect()

# Stub for method get_ohai_output of class OhaiFactCollect

# Generated at 2022-06-24 23:17:14.116092
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_1 = OhaiFactCollector()
    ohai_fact_collector_1.collect()

# ========
#  Tests
# ========


# Generated at 2022-06-24 23:17:18.221741
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    class MockModule():
        def get_bin_path(self, arg):
            return '/usr/bin/ohai'
        def run_command(self, arg):
            return 0, '', ''
    mock_module = MockModule()
    assert ohai_fact_collector_0.get_ohai_output(mock_module) is None

# Generated at 2022-06-24 23:17:22.551830
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.get_ohai_output()


# Generated at 2022-06-24 23:17:27.383280
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    pending_tasks = {
        'task1': 'task1',
        'task2': 'task2',
    }
    expected = {
        'task1': 'task1',
        'task2': 'task2',
    }
    ohai_fact_collector_collect = OhaiFactCollector.collect(pending_tasks)
    assert ohai_fact_collector_collect == expected

# Generated at 2022-06-24 23:17:37.382821
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Create a module that has no ohai_path set
    import ansible.module_utils.basic
    module_0 = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # Create an OhaiFactCollector, with no collectors
    ohai_fact_collector_0 = OhaiFactCollector()
    # Verify running get_ohai_output, of the OhaiFactCollector, on the basic
    # AnsibleModule returns None.
    assert ohai_fact_collector_0.get_ohai_output(module_0) is None


# Unit tests for method collect of class OhaiFactCollector

# Generated at 2022-06-24 23:17:38.620875
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()


# Generated at 2022-06-24 23:19:16.870382
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert ohai_fact_collector_0.get_ohai_output() == {'ohai_0': {}}
    ohai_fact_collector_1 = OhaiFactCollector({'ohai_0': OhaiFactCollector})
    assert ohai_fact_collector_1.get_ohai_output() == {'ohai_0': {'ohai_0': {}}}
    ohai_fact_collector_2 = OhaiFactCollector({'ohai_0.collector': OhaiFactCollector})
    assert ohai_fact_collector_2.get_ohai_output() == {'ohai_0.collector': {'ohai_0.collector': {}}}


# Generated at 2022-06-24 23:19:21.628913
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    pass


# Generated at 2022-06-24 23:19:23.883131
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    print('Invoking test_OhaiFactCollector_run_ohai()')
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_fact_collector_0.run_ohai(module=None, ohai_path=None)


# Generated at 2022-06-24 23:19:32.232706
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_output_str = '{}'
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return 'ohai'

        def run_command(self, cmd):
            return 0, ohai_output_str, ''

    fake_module_0 = FakeModule()
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_output_0 = ohai_fact_collector_0.get_ohai_output(module=fake_module_0)
    assert ohai_output_0 == ohai_output_str


# Generated at 2022-06-24 23:19:37.741854
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    o = OhaiFactCollector()
    o.find_ohai = lambda x: None
    assert o.get_ohai_output(None) == None

    o.find_ohai = lambda x: 'ohai'
    o.run_ohai = lambda x, y: (0, '{"a": "b"}', '')
    assert o.get_ohai_output(None) == '{"a": "b"}'
    assert o.get_ohai_output(None) == '{"a": "b"}'
    assert o.get_ohai_output(None) == '{"a": "b"}'


if __name__ == '__main__':
    test_case_0()
    test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-24 23:19:39.466313
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


# Generated at 2022-06-24 23:19:46.885798
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # Instantiate
    ohai_fact_collector_1 = OhaiFactCollector()

    # Mock Module instantiation
    module = AnsibleModule(argument_spec=dict())

    # Test with a path of 'ohai'
    ohai_path = ohai_fact_collector_1.find_ohai(module)
    assert ohai_path != None

    # Test with a path of '/bin/ohai'
    ohai_path = ohai_fact_collector_1.find_ohai(module)
    assert ohai_path == '/bin/ohai'


# Generated at 2022-06-24 23:19:48.688713
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector_0 = OhaiFactCollector()
    ohai_facts_0 = ohai_fact_collector_0.collect()

# Generated at 2022-06-24 23:19:57.893645
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.test_module_utils_facts import (
        fake_module_0,
        fake_module_1,
    )
    ohai_fact_collector_0 = OhaiFactCollector()
    try:
        ohai_fact_collector_0.get_ohai_output(module=fake_module_0)
    except AssertionError:
        pass
    else:
        assert False
    try:
        ohai_fact_collector_0.get_ohai_output(module=fake_module_1)
    except AssertionError:
        pass
    else:
        assert False


# Generated at 2022-06-24 23:19:58.620475
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_fact_collector_0 = OhaiFactCollector()
    assert False