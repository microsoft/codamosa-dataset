

# Generated at 2022-06-17 01:14:13.389935
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.network.interface
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts

# Generated at 2022-06-17 01:14:24.346540
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content_string
    from ansible.module_utils.facts.utils import get_file_content_bytes
   

# Generated at 2022-06-17 01:14:35.701617
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.ohai.collector import OhaiFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDist

# Generated at 2022-06-17 01:14:47.082944
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_is_link
    from ansible.module_utils.facts.utils import get_file_is_directory
    from ansible.module_utils.facts.utils import get_file_is_file

# Generated at 2022-06-17 01:14:59.061722
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai.collector import OhaiFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.ohai import OhaiDistributionFactCollector

    # Create a mock module
    module = MockModule()

    # Create a mock BaseFactCollector
    base_fact_collector = BaseFactCollector()

    # Create a mock DistributionFactCollector
    distribution_fact_collector = DistributionFactCollector()

    # Create a mock OhaiDistributionFactCollector
   

# Generated at 2022-06-17 01:15:12.767333
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:15:23.423367
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:26.038291
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = None
    collected_facts = None
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect(module, collected_facts)
    assert isinstance(ohai_facts, dict)

# Generated at 2022-06-17 01:15:34.937539
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    facts = Facts(collectors=[OhaiFactCollector])
    facts.populate()
    assert 'ohai' in facts.data
    assert isinstance(facts.data['ohai'], dict)
    assert 'ohai_kernel' in facts.data
    assert isinstance(facts.data['ohai_kernel'], dict)
    assert 'ohai_kernel_name' in facts.data
    assert isinstance(facts.data['ohai_kernel_name'], str)

# Generated at 2022-06-17 01:15:44.736814
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subclasses
    from ansible.module_utils.facts.collector import list_fact_subclass_names
    from ansible.module_utils.facts.collector import list_fact_subclass_namespaces
    from ansible.module_utils.facts.collector import list_fact_subclass_namespace_names

# Generated at 2022-06-17 01:15:52.173901
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect(module=module)
    assert ohai_facts == {'ohai_platform': 'linux', 'ohai_platform_version': '2.6.32-431.3.1.el6.x86_64'}


# Generated at 2022-06-17 01:16:03.904235
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:12.227754
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subclasses
    from ansible.module_utils.facts.collector import list_fact_subclass_names
    from ansible.module_utils.facts.collector import list_fact_subclass_namespaces
    from ansible.module_utils.facts.collector import list_fact_subclass_namespace_names

# Generated at 2022-06-17 01:16:18.947027
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:16:31.186083
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:42.935996
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:16:48.823919
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, binary):
            return self.bin_path

        def run_command(self, command):
            return (0, '{"foo": "bar"}', '')

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def get(self, key, default=None):
            return self.facts.get(key, default)

    module = MockModule(bin_path='/usr/bin/ohai')
    facts = MockFacts

# Generated at 2022-06-17 01:16:59.750882
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCacheEntry
    from ansible.module_utils.facts.namespace import NamespaceFactCacheEntryKey
    from ansible.module_utils.facts.namespace import NamespaceFactCacheEntryValue

# Generated at 2022-06-17 01:17:12.996209
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:17:25.374373
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, app, required=False, opt_dirs=[]):
            return '/usr/bin/ohai'



# Generated at 2022-06-17 01:17:38.550266
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_all_collectors
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name

# Generated at 2022-06-17 01:17:48.356485
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceFactKeyError
    from ansible.module_utils.facts.namespace import NamespaceFactNotFound
    from ansible.module_utils.facts.namespace import NamespaceFactKeyNotFound
    from ansible.module_utils.facts.namespace import NamespaceFactKeyNotUnique

# Generated at 2022-06-17 01:17:54.090290
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:18:03.701424
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

        def run_command(self, command):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()


# Generated at 2022-06-17 01:18:14.881923
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:18:25.025376
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.system.mounts import MountFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.fips import FipsFactCollector

# Generated at 2022-06-17 01:18:34.700890
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector import TestModuleCollector
    from ansible.module_utils.facts.collector import TestModuleCollector2
    from ansible.module_utils.facts.collector import TestModuleCollector3

    test_module = TestModule()
    test_module_collector = TestModuleCollector(module=test_module)
    test_module_collector2 = TestModuleCollector2(module=test_module)
    test_module_collector3 = TestModuleCollector3(module=test_module)


# Generated at 2022-06-17 01:18:42.281000
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.local
    import ansible.module_utils.facts.network.neighbors
    import ansible.module_utils.facts.hardware.cpu
    import ansible.module_utils.facts.hard

# Generated at 2022-06-17 01:18:53.577976
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_fact_ids

# Generated at 2022-06-17 01:19:04.679939
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts.network.defaults

# Generated at 2022-06-17 01:19:24.077922
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_is_link
    from ansible.module_utils.facts.utils import get_file_is_directory
    from ansible.module_utils.facts.utils import get_file_is_fifo

# Generated at 2022-06-17 01:19:31.984430
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactList
    from ansible.module_utils.facts.namespace import NamespaceFactDict
    from ansible.module_utils.facts.namespace import NamespaceFactString
    from ansible.module_utils.facts.namespace import NamespaceFactBool

# Generated at 2022-06-17 01:19:40.872489
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:19:53.430155
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()


# Generated at 2022-06-17 01:20:05.552372
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail

# Generated at 2022-06-17 01:20:14.036589
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    module = MockModule()
    ohai_collector = get_collector_instance(BaseFactCollector,
                                            'ohai',
                                            namespace=PrefixFactNamespace(namespace_name='ohai',
                                                                          prefix='ohai_'))

# Generated at 2022-06-17 01:20:24.306057
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector

# Generated at 2022-06-17 01:20:25.845101
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = None
    collected_facts = None
    ohai_facts = OhaiFactCollector().collect(module, collected_facts)
    assert isinstance(ohai_facts, dict)

# Generated at 2022-06-17 01:20:30.731714
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai_collector = OhaiFactCollector()
    ohai_facts = ohai_collector.collect(module=module)
    assert ohai_facts == {'ohai_test': 'ohai_test_value'}


# Generated at 2022-06-17 01:20:37.681726
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, binary):
            if binary == 'ohai':
                return self.bin_path
            return None

    class FakeFactCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()

       

# Generated at 2022-06-17 01:21:06.163543
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def get_bin_path(self, executable):
            return '/usr/bin/ohai'

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='mock',
                                            prefix='mock_')

# Generated at 2022-06-17 01:21:15.684459
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceManager
    from ansible.module_utils.facts.namespace import NamespaceManagerError

    class TestModule(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-17 01:21:25.619508
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.default_ipv4
    import ansible.module_utils

# Generated at 2022-06-17 01:21:33.461336
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/ohai'

    class FakeCollector(BaseFactCollector):
        name = 'fake'

    fake_module = FakeModule()
    fake_collector = FakeCollector(namespace=PrefixFactNamespace(namespace_name='fake', prefix='fake_'))
    ohai_collector = get_collector_instance(fake_collector, 'ohai')


# Generated at 2022-06-17 01:21:42.204336
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_file
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_path

# Generated at 2022-06-17 01:21:53.332248
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule:
        def get_bin_path(self, name):
            if name == 'ohai':
                return '/usr/bin/ohai'
            return None

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.namespace = namespace

    class MockPrefixFactNamespace(PrefixFactNamespace):
        def __init__(self, namespace_name=None, prefix=None):
            self.names

# Generated at 2022-06-17 01:22:04.036109
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceTypeError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:22:12.375296
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.debian import DebianDistributionFactCollector
    from ansible.module_utils.facts.system.distribution.redhat import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution.suse import SuseDistributionFactCollector

# Generated at 2022-06-17 01:22:22.895213
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:22:34.042989
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6

# Generated at 2022-06-17 01:23:33.469041
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, binary, required=False):
            if binary == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None

    fake_module = FakeModule()

# Generated at 2022-06-17 01:23:40.399794
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:23:49.546755
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    '''Unit test for method collect of class OhaiFactCollector'''
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCollector
    from ansible.module_utils.facts.namespace import MockFactNamespace

    module = MockModule()
    module.run_command = MockCollector.run_command

    ohai_fact_collector = OhaiFactCollector(namespace=MockFactNamespace())
    ohai_facts = ohai_fact_collector.collect(module=module)
    assert ohai_facts is not None
    assert isinstance(ohai_facts, dict)
    assert ohai_facts['ohai_platform'] == 'ubuntu'

# Generated at 2022-06-17 01:23:59.786682
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_exists
    from ansible.module_utils.facts.utils import get_file_is_directory
    from ansible.module_utils.facts.utils import get_file_is_file
    from ansible.module_utils.facts.utils import get_file_is_link
    from ansible.module_utils.facts.utils import get_file_md5
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-17 01:24:09.483535
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_facts = OhaiFactCollector().collect()
    assert isinstance(ohai_facts, dict)
    assert 'ohai_platform' in ohai_facts
    assert 'ohai_platform_version' in ohai_facts
    assert 'ohai_fqdn' in ohai_facts
    assert 'ohai_hostname' in ohai_facts
    assert 'ohai_domain' in ohai_facts
    assert 'ohai_ipaddress' in ohai_facts
    assert 'ohai_macaddress' in ohai_facts
    assert 'ohai_network' in ohai_facts
    assert 'ohai_network_eth0' in ohai_facts
    assert 'ohai_network_eth0_ip' in ohai_facts
    assert 'ohai_network_eth0_ip6' in oh