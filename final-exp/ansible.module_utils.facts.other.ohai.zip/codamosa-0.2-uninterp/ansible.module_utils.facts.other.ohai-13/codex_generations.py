

# Generated at 2022-06-17 01:14:12.314405
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_types
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_subset
    from ansible.module_utils.facts.collector import get_fact_subsets

# Generated at 2022-06-17 01:14:22.035583
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_fact_ids

# Generated at 2022-06-17 01:14:31.350962
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_distribution
    from ansible.module_utils.facts.collector import get_collector_for_os_family

    # Test that the OhaiFactCollector is registered
    assert 'ohai' in get_collector_names()

    # Test that the OhaiFactCollector is returned by get_collector_for_type

# Generated at 2022-06-17 01:14:43.315111
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/usr/bin/ohai'


# Generated at 2022-06-17 01:14:52.267192
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:15:02.165009
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='fake',
                                            prefix='fake_')

# Generated at 2022-06-17 01:15:11.117074
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.ohai
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network

# Generated at 2022-06-17 01:15:21.524465
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import get_network_collector_instance

# Generated at 2022-06-17 01:15:27.786864
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:40.355632
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:15:50.330168
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:16:01.361394
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = None
            self.params['fact_caching'] = 'jsonfile'

# Generated at 2022-06-17 01:16:10.751252
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, '{"foo": "bar"}', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/ohai')

    # Create a mock fact collector
    fact_collector = MockFactCollector()

    # Create an instance of OhaiFactCollector
    ohai_fact_collector = OhaiFactCollector(collectors=[fact_collector])

    # Call method collect of OhaiFactCollector
    ohai_facts = ohai_fact_collector.collect(module=module)

    # Assert that ohai_facts is equal to {"foo": "bar"}
    assert ohai_facts == {"foo": "bar"}


# Generated at 2022-06-17 01:16:20.365474
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:16:25.510904
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_collector = get_collector_instance('ohai')
    assert ohai_collector.get_ohai_output(None) is None

# Generated at 2022-06-17 01:16:34.956160
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import get_namespace_instance
    from ansible.module_utils.facts.namespace import get_namespace_prefix
    from ansible.module_utils.facts.namespace import get_namespace_name
    from ansible.module_utils.facts.namespace import get_names

# Generated at 2022-06-17 01:16:36.460939
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # FIXME: implement
    pass

# Generated at 2022-06-17 01:16:46.688738
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, executable, required=False):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    module = MockModule()
    ohai_collector = get_collector_instance(BaseFactCollector, 'ohai')
    ohai_output = ohai_collector.get_oh

# Generated at 2022-06-17 01:16:58.791899
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6

# Generated at 2022-06-17 01:17:12.544144
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts_collectors
    from ansible.module_utils.facts.collector import list_system_collectors
    from ansible.module_utils.facts.collector import list_virtual_collectors

# Generated at 2022-06-17 01:17:26.531195
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts.network.defaults

# Generated at 2022-06-17 01:17:35.035499
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            return {}


# Generated at 2022-06-17 01:17:42.783634
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceManager
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import NamespaceKeyErrorDetailItem
    from ansible.module_utils.facts.namespace import NamespaceKeyErrorDetailItemList
   

# Generated at 2022-06-17 01:17:51.621187
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, binary):
            return self.bin_path + '/' + binary

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(Collector):
        def __init__(self):
            self.namespace = FactNamespace(namespace_name='foo')


# Generated at 2022-06-17 01:17:59.478349
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:13.410513
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:18:24.499359
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode

# Generated at 2022-06-17 01:18:34.291229
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode

# Generated at 2022-06-17 01:18:45.356126
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable, required=False):
            return '/usr/bin/ohai'

        def run_command(self, cmd, check_rc=True):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:18:54.230162
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:19:12.016324
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class MockFactsCollector(FactsCollector):
        def __init__(self):
            self.collectors

# Generated at 2022-06-17 01:19:22.853594
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/usr/bin/ohai'


# Generated at 2022-06-17 01:19:32.572608
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get a list of all the collectors
    collectors = list_collectors()

    # Get a list of the names of all the collectors
    collector_names = get_collector_names()

    # Get an instance of the OhaiFactCollector
    ohai_fact_collector = get_collector_instance('ohai')

    # Get the ohai output
    ohai_output = ohai_fact_collector.get_ohai_output(module=None)

    # Check that the ohai output is a string
    assert isinstance(ohai_output, str)

   

# Generated at 2022-06-17 01:19:41.187778
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_file
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_path

# Generated at 2022-06-17 01:19:52.583930
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    module = ModuleFacts()
    module.get_bin_path = lambda x: '/usr/bin/ohai'
    ohai_fact_collector = OhaiFactCollector(namespace=PrefixFactNamespace(namespace_name='ohai', prefix='ohai_'))
    assert ohai_fact_collector.find_ohai(module) == '/usr/bin/ohai'


# Generated at 2022-06-17 01:20:00.072621
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subsets
    from ansible.module_utils.facts.collector import list_fact_subset_names
    from ansible.module_utils.facts.collector import list_fact_subset_classes
    from ansible.module_utils.facts.collector import list_collection_order

# Generated at 2022-06-17 01:20:13.266741
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subsets
    from ansible.module_utils.facts.collector import list_fact_subset_names
    from ansible.module_utils.facts.collector import list_fact_subset_plugins
    from ansible.module_utils.facts.collector import list_fact_subset_plugin_names

# Generated at 2022-06-17 01:20:23.702301
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    # Create a mock module
    module = MockModule()

    # Create a mock ohai output
    ohai_output = '{"foo": "bar"}'

    # Create a mock ohai path
    ohai_path = '/bin/ohai'

    # Create a mock ohai rc
    ohai_rc = 0

    # Create a mock

# Generated at 2022-06-17 01:20:32.574935
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, *args, **kwargs):
            return '/usr/bin/ohai'

        def run_command(self, arg, *args, **kwargs):
            return 0

# Generated at 2022-06-17 01:20:41.018693
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    test_module = TestModule()
    test_collector = get_collector_instance(BaseFactCollector)
    test_collector.namespace = PrefixFactNamespace(namespace_name='ohai',
                                                   prefix='ohai_')
    test_collector.collectors = []

# Generated at 2022-06-17 01:21:12.091775
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailType
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailKey

# Generated at 2022-06-17 01:21:20.948461
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.openvz

# Generated at 2022-06-17 01:21:31.970135
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_classes_for_namespace
    from ansible.module_utils.facts.collector import get_collector_class_for_namespace
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:21:39.033310
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_is_link
    from ansible.module_utils.facts.utils import get_file_is_directory
    from ansible.module_utils.facts.utils import get_file_is_file

# Generated at 2022-06-17 01:21:48.951455
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:21:59.357431
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import list_cacheable_facts

# Generated at 2022-06-17 01:22:11.251230
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCacheModule
    from ansible.module_utils.facts.namespace import NamespaceFactCacheFile
    from ansible.module_utils.facts.namespace import NamespaceFactCacheMemory
    from ansible.module_utils.facts.namespace import NamespaceFactCacheNone

# Generated at 2022-06-17 01:22:22.793717
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:22:28.685659
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    fake_module = ansible_collector.get_fake_module()

    # Create a fake ohai binary
    fake_ohai_bin = '/tmp/fake_ohai'
    fake_ohai_content = '#!/bin/sh\necho "fake ohai"'
    get_file_content(fake_ohai_bin, fake_ohai_content)

    # Create a fake ohai fact collector
    fake_ohai_fact_collector = OhaiFactCollector()

    # Test the find_ohai method

# Generated at 2022-06-17 01:22:35.779281
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:23:35.449938
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:23:41.825651
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists
    from ansible.module_utils.facts.utils import get_file_lines_if_exists
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount

# Generated at 2022-06-17 01:23:49.881855
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, arg):
            return '/bin/ohai'

        def run_command(self, arg):
            self.run_command_calls.append(arg)
            return self.run_command_results.pop(0)

    # Create a mock module
    module = MockModule()

    # Create a mock ohai output

# Generated at 2022-06-17 01:24:00.034334
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device