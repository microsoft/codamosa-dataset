

# Generated at 2022-06-17 01:14:12.991905
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_name
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_class_by_name_or_class
    from ansible.module_utils.facts.collector import get

# Generated at 2022-06-17 01:14:22.621805
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_namespace
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-17 01:14:31.994019
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.default_ipv4
    import ansible.module_utils.facts.network.default_ipv6
    import ansible.module_utils.facts.network.local
    import ansible.module_

# Generated at 2022-06-17 01:14:43.678773
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_bytes

    # Create a mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'


# Generated at 2022-06-17 01:14:52.410388
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/ohai'

        def run_command(self, arg):
            return 0, '{"foo": "bar"}', ''

    # Create a mock module
    module = MockModule()

    # Create a OhaiFactCollector object
    ohai_fact_collector = OhaiFactCollector()

    # Get the ohai output
    ohai_output = ohai_fact_collector.get_ohai_output(module)

    # Assert that the ohai output is not None
    assert ohai_output is not None

    # Assert that the ohai output is a string
    assert isinstance(ohai_output, str)

    # Assert that the ohai output is a valid json

# Generated at 2022-06-17 01:15:01.844321
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:15:11.020731
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the OhaiFactCollector class is available
    assert 'ohai' in get_collector_names()

    # Test that the OhaiFactCollector class is available
    assert 'OhaiFactCollector' in list_collectors()

    # Test that the OhaiFactCollector class can be instantiated
    ohai_collector = get_collector_instance('ohai')
    assert isinstance(ohai_collector, OhaiFactCollector)

    # Test that the OhaiFactCollector class can be instantiated
    ohai_collector = get_collector

# Generated at 2022-06-17 01:15:21.437513
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_collector = get_collector_instance('ohai')
    assert ohai_collector.find_ohai('/bin/ohai') == '/bin/ohai'
    assert ohai_collector.find_ohai('/usr/bin/ohai') == '/usr/bin/ohai'
    assert ohai_collector.find_ohai('/usr/sbin/ohai') == '/usr/sbin/ohai'
    assert ohai_collector.find_ohai('/usr/local/bin/ohai') == '/usr/local/bin/ohai'

# Generated at 2022-06-17 01:15:27.766343
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collection
    import ansible.module_utils.facts.other
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.command_line
    import ansible.module_utils.facts.parsers
    import ansible.module_utils.facts.parsers.system
    import ansible

# Generated at 2022-06-17 01:15:40.315367
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_file
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_path

# Generated at 2022-06-17 01:15:50.310223
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyError

# Generated at 2022-06-17 01:16:01.354930
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, path):
            return '/usr/bin/ohai'

        def run_command(self, command):
            return 0, '{"foo": "bar"}', ''

    # Create a mock module
    module = MockModule()

    # Create a mock collected_facts
    collected_facts = {}

    # Create an instance of OhaiFactCollector
    ohai_fact_collector = OhaiFactCollector()

    # Call method collect of OhaiFactCollector
    ohai_facts = ohai_fact_collector.collect(module=module,
                                             collected_facts=collected_facts)

    # Assert that ohai_facts is not empty
    assert ohai_facts
    # Assert that ohai_facts is a

# Generated at 2022-06-17 01:16:12.873875
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:16:20.598159
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts

# Generated at 2022-06-17 01:16:32.929643
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class FakeModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/' + name

    class FakeCollector(BaseFactCollector):
        name = 'fake'

    class FakeNamespace(BaseFactNamespace):
        name = 'fake'

    class FakeFactNamespace(FactNamespace):
        name = 'fake'

    module = FakeModule()
    collector = get_collect

# Generated at 2022-06-17 01:16:45.479345
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceValueError
    from ansible.module_utils.facts.namespace import NamespaceAttributeError
    from ansible.module_utils.facts.namespace import NamespaceKeyTypeError
    from ansible.module_utils.facts.namespace import NamespaceValueTypeError

    # Test with no module
   

# Generated at 2022-06-17 01:16:57.800581
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_fact_namespace_class

# Generated at 2022-06-17 01:17:11.863449
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import NetBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SunOSDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import AIXDistributionFactCollector

# Generated at 2022-06-17 01:17:17.446581
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution_version
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os_version
   

# Generated at 2022-06-17 01:17:26.664438
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class MockModule(object):
        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockNamespace(BaseFactNamespace):
        name = 'mock'

        def get_facts(self, collected_facts=None):
            return {}

    ohai_collector = get

# Generated at 2022-06-17 01:17:39.006083
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class TestModule(object):
        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, binary):
            return self.bin_path

        def run_command(self, command):
            return 0, '{"test": "test"}', ''

    class TestCollector(BaseFactCollector):
        name = 'test'


# Generated at 2022-06-17 01:17:50.925535
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:59.413765
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts.network.defaults
    import ansible.module_utils.facts.network.fqdn

# Generated at 2022-06-17 01:18:13.410841
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:18:24.524834
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

    class MockModule(object):
        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, executable, required=False):
            return self.bin_path

        def run_command(self, executable):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:18:31.235400
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:18:40.813419
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:52.130996
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

        def run_command(self, binary):
            return 0, '{"foo": "bar"}', ''

    module = MockModule()

# Generated at 2022-06-17 01:19:00.747840
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.posix import PosixFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

# Generated at 2022-06-17 01:19:11.006977
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_type_name
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_name
    from ansible.module_utils.facts.collector import get_collectors_for_type_names
    from ansible.module_utils.facts.collector import get_collectors_for_types

# Generated at 2022-06-17 01:19:29.547220
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a Facts instance
    facts = Facts()

    # Create an OhaiFactCollector instance
    ohai_collector = get_collector_instance('ohai')

    # Create a module
    class Module(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['ohai']

        def get_bin_path(self, executable):
            return '/usr/bin/ohai'

        def run_command(self, executable):
            return 0, '{"foo": "bar"}', ''

    module = Module()

    # Run the collect method

# Generated at 2022-06-17 01:19:37.901467
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace_manager

    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'ohai']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = None
            self.params['fact_caching'] = 'jsonfile'
            self.params['fact_caching_connection'] = None
            self.params['fact_caching_timeout'] = 3600

# Generated at 2022-06-17 01:19:43.501242
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail

# Generated at 2022-06-17 01:19:55.085462
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:20:06.934697
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_instance

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/bin/ohai'

        def run_command(self, arg):
            return 0, '{"foo": "bar"}', ''

    module = MockModule()
    ohai_fact_collector = get_collector_instance(OhaiFactCollector)

# Generated at 2022-06-17 01:20:13.377451
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get a list of all the available collectors
    collectors = list_collectors()

    # Get a list of the names of all the available collectors
    collector_names = get_collector_names()

    # Get an instance of the OhaiFactCollector
    ohai_collector = get_collector_instance('ohai')

    # Get a list of the names of all the available collectors
    collector_names = get_collector_names()

    # Get an instance of the OhaiFactCollector
    ohai_collector = get_collector_instance('ohai')

    #

# Generated at 2022-06-17 01:20:23.804127
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.other
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils

# Generated at 2022-06-17 01:20:32.657828
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactSource
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCacheEntry

# Generated at 2022-06-17 01:20:41.093142
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time

# Generated at 2022-06-17 01:20:53.064480
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/ohai'

        def run_command(self, cmd, check_rc=True):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}


# Generated at 2022-06-17 01:21:22.120054
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_namespace
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-17 01:21:30.137542
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:21:39.400353
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines

    # Create a mock module
    class MockModule(object):
        def __init__(self, ohai_path, ohai_output):
            self.ohai_path = ohai_path
            self.ohai_output = ohai_output
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, binary):
            return self.ohai_path

        def run_command(self, cmd):
            return 0, self.ohai_output, ''

    # Create a mock module with no ohai

# Generated at 2022-06-17 01:21:49.690856
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_subset_collectors
    from ansible.module_utils.facts.collector import list_legacy_collectors

# Generated at 2022-06-17 01:22:01.134279
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCache

# Generated at 2022-06-17 01:22:11.378115
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:22:21.971321
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Create a module object
    class Module:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = None
            self.params['fact_caching'] = 'jsonfile'
            self.params['fact_caching_connection'] = None
            self.params['fact_caching_timeout'] = 3600

# Generated at 2022-06-17 01:22:28.199887
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:22:35.533457
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:22:45.574805
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.hardware.cpu
    import ansible.module_utils.facts.hardware.dmi
    import ansible.module_utils.facts.hardware.main_board
    import ansible.module_utils.facts.hardware

# Generated at 2022-06-17 01:23:40.107864
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class FakeModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/ohai'

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='fake',
                                            prefix='fake_')

# Generated at 2022-06-17 01:23:49.515603
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type_path
    from ansible.module_utils.facts.collector import get_collectors_for_type_path_namespace

# Generated at 2022-06-17 01:23:59.754454
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   