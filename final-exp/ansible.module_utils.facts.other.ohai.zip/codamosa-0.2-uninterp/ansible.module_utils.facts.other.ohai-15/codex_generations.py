

# Generated at 2022-06-17 01:14:13.902830
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts_collectors
    from ansible.module_utils.facts.collector import list_legacy_collectors
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:14:24.851740
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts_collectors
    from ansible.module_utils.facts.collector import list_legacy_collectors
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:14:35.737060
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail

# Generated at 2022-06-17 01:14:47.130664
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists
    from ansible.module_utils.facts.utils import get_file_content_as_lines
    from ansible.module_utils.facts.utils import get_file_content_as_json
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_reserved
    from ansible.module_utils.facts.utils import get_mount_size_available

# Generated at 2022-06-17 01:14:59.192752
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 01:15:12.832800
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_names_for_platform
    from ansible.module_utils.facts.collector import get_collector_names_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_names_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_names_for_

# Generated at 2022-06-17 01:15:23.424094
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_names_from_namespace
    from ansible.module_utils.facts.collector import get_collector_class_names_from_collectors
    from ansible.module_utils.facts.collector import get_collector_class_names_from_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names_from_collector

# Generated at 2022-06-17 01:15:34.567879
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailKey
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailValue

# Generated at 2022-06-17 01:15:45.229900
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceValueError
    from ansible.module_utils.facts.namespace import NamespaceTypeError

# Generated at 2022-06-17 01:15:55.340857
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_is_directory
    from ansible.module_utils.facts.utils import get_file_is_file
    from ansible.module_utils.facts.utils import get_file_is_link

# Generated at 2022-06-17 01:16:10.031915
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.local
    import ansible.module_utils.facts.network.neighbors

# Generated at 2022-06-17 01:16:20.340584
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

        def run_command(self, command):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='mock',
                                            prefix='mock_')
           

# Generated at 2022-06-17 01:16:32.705310
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.ohai
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.file_system
    import ansible.module_utils.facts.collectors.identity
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.config_

# Generated at 2022-06-17 01:16:45.176742
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, required=False):
            return self.bin_path


# Generated at 2022-06-17 01:16:57.452486
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a dummy module
    class DummyModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['verbosity'] = 0
            self.params['show_custom_facts'] = True

# Generated at 2022-06-17 01:17:07.955037
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}


# Generated at 2022-06-17 01:17:15.955078
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:26.287229
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:17:35.013409
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import BaseNamespaceModule

    class MockModule(BaseNamespaceModule):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin/ohai'


# Generated at 2022-06-17 01:17:42.870668
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, binary):
            return '/usr/bin/ohai'

        def run_command(self, binary):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:17:58.678121
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['filter'] = '*'
            self.params['gather_timeout'] = 10
            self.params['gather_network_resources'] = 'no'
            self.params['gather_subset'] = ['all']
            self.params['filter'] = '*'
            self.params['gather_timeout'] = 10
            self.params['gather_network_resources'] = 'no'
            self.params['gather_subset'] = ['all']
            self.params['filter'] = '*'
            self.params['gather_timeout'] = 10

# Generated at 2022-06-17 01:18:13.014915
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import get_collector_names_for_fact
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_names_from_collectors

# Generated at 2022-06-17 01:18:20.072088
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Test with no module
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect()
    assert ohai_facts == {}

    # Test with module
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect(module=None)
    assert ohai_facts == {}

# Generated at 2022-06-17 01:18:28.809254
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_namespace
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_namespace_facts
   

# Generated at 2022-06-17 01:18:38.727966
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:18:48.937941
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:18:59.863711
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:19:05.348895
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_collector = get_collector_instance('ohai')
    assert ohai_collector.get_ohai_output(None) is None

# Generated at 2022-06-17 01:19:17.456287
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''


# Generated at 2022-06-17 01:19:24.988842
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceValueError
    from ansible.module_utils.facts.namespace import NamespaceTypeError
    from ansible.module_utils.facts.namespace import NamespaceAttributeError

# Generated at 2022-06-17 01:19:42.252427
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:19:54.637620
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_return = (0, '{"foo": "bar"}', '')
            self.run_command_called = False
            self.get_bin_path_return = '/usr/bin/ohai'
            self.get_bin_path_called = False

        def run_command(self, cmd):
            self.run_command_called = True
            return self.run_command_return

        def get_bin_path(self, cmd):
            self.get_bin_path_called = True
            return self.get_bin_path_return

    # Create a mock module
    module = MockModule()

    # Create a OhaiFactCollector object
    ohai_fact_collector = OhaiFactCollect

# Generated at 2022-06-17 01:20:06.522032
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_file
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_path

# Generated at 2022-06-17 01:20:15.610805
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_distribution
    from ansible.module_utils.facts.collector import get_collector_for_os_family
    from ansible.module_utils.facts.collector import get_collector_for_os_name
    from ansible.module_utils.facts.collector import get_collector_for_os_version

# Generated at 2022-06-17 01:20:24.898503
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetail
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailKey
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorDetailValue

# Generated at 2022-06-17 01:20:35.084721
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import NamespaceFactCache
    from ansible.module_utils.facts.namespace import NamespaceFactCacheData
    from ansible.module_utils.facts.namespace import NamespaceFactCacheManager
    from ansible.module_utils.facts.namespace import NamespaceFactSearch

# Generated at 2022-06-17 01:20:45.465174
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, '{"foo": "bar"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}

    module = MockModule()
    ohai = get

# Generated at 2022-06-17 01:20:55.412496
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.ohai
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.fips

# Generated at 2022-06-17 01:21:06.130422
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test with no module
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_

# Generated at 2022-06-17 01:21:14.335771
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subsets
    from ansible.module_utils.facts.collector import list_fact_subset_classes
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import Prefix

# Generated at 2022-06-17 01:21:41.574049
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.openvz

# Generated at 2022-06-17 01:21:52.692946
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:22:01.605083
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = AnsibleModuleMock()
    ohai_path = '/usr/bin/ohai'
    ohai_output = '{"foo": "bar"}'
    ohai_facts = {'foo': 'bar'}
    module.run_command = MagicMock(return_value=(0, ohai_output, None))
    module.get_bin_path = MagicMock(return_value=ohai_path)
    ohai_collector = OhaiFactCollector()
    assert ohai_collector.collect(module=module) == ohai_facts


# Generated at 2022-06-17 01:22:11.669426
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the Ohai fact collector is available
    assert 'ohai' in get_collector_names()

    # Test that the Ohai fact collector is available
    assert 'ohai' in list_collectors()

    # Test that the Ohai fact collector is available
    assert isinstance(get_collector_instance('ohai'), OhaiFactCollector)

    # Test that the Ohai fact collector is available
    assert isinstance(get_collector_instance('ohai'), OhaiFactCollector)

    # Test that the Ohai fact collector is available

# Generated at 2022-06-17 01:22:22.852321
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactDict
    from ansible.module_utils.facts.namespace import NamespaceFactList
    from ansible.module_utils.facts.namespace import NamespaceFactString
    from ansible.module_utils.facts.namespace import NamespaceFactInt
    from ansible.module_utils.facts.namespace import NamespaceFactBool

# Generated at 2022-06-17 01:22:33.975892
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import list_fact_names
    from ansible.module_utils.facts.collector import list_fact_subclasses
    from ansible.module_utils.facts.collector import list_fact_subclass_names
    from ansible.module_utils.facts.collector import list_fact_subclass_namespaces
    from ansible.module_utils.facts.collector import list_fact_subclass_namespace_names

# Generated at 2022-06-17 01:22:45.810950
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:22:53.726102
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_names_from_collectors
    from ansible.module_utils.facts.collector import get_fact_names_from_namespaces
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:23:01.571137
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution_version
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os_version
    from ansible.module_utils.facts.collector import get_collector_for

# Generated at 2022-06-17 01:23:12.345636
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:24:04.670452
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DarwinDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector