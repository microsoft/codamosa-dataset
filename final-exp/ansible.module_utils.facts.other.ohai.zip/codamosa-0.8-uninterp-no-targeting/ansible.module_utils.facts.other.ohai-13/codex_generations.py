

# Generated at 2022-06-20 18:30:33.964233
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import os
    import sys
    ok = False

# Generated at 2022-06-20 18:30:44.615447
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ohai_test_data_path = os.path.join(os.path.dirname(__file__), 'test_data', 'ohai_test_data.json')

    with open(ohai_test_data_path) as ohai_test_data_file:
        TEST_OHAI_OUTPUT = ohai_test_data_file.read()

    def dummy_run_command(module, command):
        rc = 0
        out

# Generated at 2022-06-20 18:30:54.693961
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import unittest2 as unittest
    from ansible.module_utils.facts.collector import BaseFactCollector, Namespace

    class Module(object):
        def __init__(self, ohai_path):
            self._ohai_path = ohai_path

        def get_bin_path(self, name, required=True):
            return self._ohai_path

    class FakeResult(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

        def exit_status(self):
            return self.rc


# Generated at 2022-06-20 18:31:02.808111
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    class Options(object):
        def __init__(self, verbosity=None, timeout=None, connection=None,
                     remote_user=None, private_key_file=None,
                     remote_pass=None, become=False, become_method=None,
                     become_user=None, become_flags=None, workdir=None,
                     check=False, diff=False, listhosts=None,
                     module_path=None, listtasks=None, listtags=None,
                     syntax=None, start_at_task=None, step=None):
            self.verbosity = verbosity
            self.timeout = timeout
            self.connection = connection
            self.remote_user = remote_user
            self.private_key_file = private_key_file
            self.remote_pass = remote_pass
            self.bec

# Generated at 2022-06-20 18:31:13.862369
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    import sys

    o = get_collector_instance(BaseFactCollector)
    ohai_path = o.find_ohai()
    if not ohai_path:
        sys.exit("Ohai not found")

    print('The following is the output of Ohai:')
    rc, out, err = o.run_ohai(ohai_path)
    print(out.decode('utf8'))
    sys.exit(rc)

if __name__ == '__main__':
    # FIXME: Figure out what logger ansible is using, or change this to not
    #        use logging, if possible
    import logging, logging.handlers


# Generated at 2022-06-20 18:31:17.896834
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    task = OhaiFactCollector()
    task.collect()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-20 18:31:28.195888
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = None
    collected_facts = None
    ohai_facts = []
    test_OhaiFactCollector = OhaiFactCollector()

    # Testing when ohai_output is valid
    ohai_output = "{\n\"fqdn\": \"test.domain.com\",\n\"os\": \"Linux\",\n\"datacenter\": \"us1\",\n\"build\": \"test\"\n}"
    test_OhaiFactCollector.get_ohai_output = lambda x: ohai_output

    # Testing when ohai_output is None
    assert ohai_facts == test_OhaiFactCollector.collect(module, collected_facts)

    # Testing when ohai_output is valid

# Generated at 2022-06-20 18:31:34.900130
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.ohai_collector.ohai_collector as oc
    class Module:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, binary):
            if binary == 'ohai':
                return '/opt/chefdk/bin/ohai'
    module = Module()
    collector = oc.OhaiFactCollector()
    value = collector.find_ohai(module)
    assert value == '/opt/chefdk/bin/ohai'


# Generated at 2022-06-20 18:31:46.164390
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible
    import ansible.module_utils.facts.system.ohai as ohai
    import ansible.module_utils.facts.facts as facts

    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    test_module.run_command = mock_module_run_command

    test_ohai_module = ohai.OhaiFactCollector(
        collectors=facts.DEFAULT_COLLECTORS,
        namespace=facts.DEFAULT_NAMESPACE
    )

    ohai_output = test_ohai_module.get_ohai_output(test_module)

# Generated at 2022-06-20 18:31:54.681423
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import CollectorsFinder
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache

    ansible_collectors = CollectorsFinder(collectors=ansible_collector)
    ansible_collector_obj = ansible_collectors.fetch_collector('ansible')
    ansible_collector_obj.populate()
    mock_module = MockModule(ansible_collector_obj.ansible_facts)

    ohai_collector = OhaiFactCollector()
    found_ohai_path = ohai_collector.find_ohai(module=mock_module)

    # This test is not Linux specific, it just depends on the set up for
    # the environment where tests are being run

# Generated at 2022-06-20 18:32:03.453681
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'
    assert o._fact_ids == set()
    assert isinstance(o._namespace, PrefixFactNamespace)
    assert o._namespace._name == 'ohai'
    assert o._namespace._prefix == 'ohai_'
    assert o._collectors == None


# Generated at 2022-06-20 18:32:11.146272
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_fact_collector = get_collector_instance('ohai')
    ohai_path = '/usr/bin/ohai'
    module = type('module', (object,), dict(run_command=lambda x: (0, '[{"a":"b"}]', '')))

    rc, out, err = ohai_fact_collector.run_ohai(module, ohai_path)
    assert rc == 0
    assert out == '[{"a":"b"}]'
    assert err == ''

# Generated at 2022-06-20 18:32:16.896755
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    expected = """{
  "platform": "ubuntu",
  "platform_version": "18.04"
}"""

    class mock_module(object):
        def get_bin_path(self, program):
            return '/usr/bin/ohai'

        def run_command(self, ohai_path):
            return 0, expected, ''

    module = mock_module()
    collector = OhaiFactCollector(module=module)
    result = collector.get_ohai_output(module=module)
    assert result == expected



# Generated at 2022-06-20 18:32:19.462550
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    c = OhaiFactCollector()
    assert isinstance(c, OhaiFactCollector)
    assert isinstance(c, BaseFactCollector)


# Generated at 2022-06-20 18:32:25.899550
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    OHAI_FACTS = {'platform': 'linux'}

    class FakeModule:
        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

        def run_command(self, name):
            return 0, json.dumps(OHAI_FACTS), ''

    fake_module = FakeModule()
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.collect(module=fake_module) == OHAI_FACTS

# Generated at 2022-06-20 18:32:33.515187
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ''' Unit Test for method get_ohai_output method of class OhaiFactCollector
        The test can be run in stand alone mode by invoking the module as
        python -m ansible.module_utils.facts.ohai.test_ohai_facts
    '''
    import ansible.module_utils.facts.ohai as ohai
    print ('Running unit test function test_OhaiFactCollector_collect')
    ohai_collector = ohai.OhaiFactCollector()
    ohai_facts = ohai_collector.collect()
    assert isinstance(ohai_facts, dict)
    return


# Generated at 2022-06-20 18:32:44.490715
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual

    import ansible.module_utils.facts.ohai

    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts.collectors import (
        AllCollector,
        LegacyCollector,
        SystemCollector,
        VirtualCollector,
        OhaiCollector
    )

    # Define input values
    ohai_path = '/usr/bin/ohai'
    ohai_output = json.dumps({'ohai_test': 'ohai_test'})

# Generated at 2022-06-20 18:32:45.443697
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # FIXME: No unit tests for this
    pass


# Generated at 2022-06-20 18:32:55.734048
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ohai_facts = {}
    ohai_facts['a'] = {'b': 'c'}
    ohai_facts['d'] = {'e': 'f'}
    test_module = {
        'run_command': lambda ohai_path: (0, json.dumps(ohai_facts), None),
        'get_bin_path': lambda cmd, opts: cmd,
    }
    ofc = OhaiFactCollector()
    test_ohai_facts = ofc.get_ohai_output(test_module)
    assert test_ohai_facts == json.dumps(ohai_facts)


# Generated at 2022-06-20 18:33:03.330718
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    system_path = module.get_bin_path('ohai')
    module.run_command = lambda x: (0, '{"ohai": "successful"}', '')

    ohai_collectour = OhaiFactCollector()
    results = ohai_collectour.get_ohai_output(module)
    assert results == '{"ohai": "successful"}'

# Generated at 2022-06-20 18:33:16.971743
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.test import MockModule

    # Create a MockModule for collecting ohai facts
    m = MockModule('mock')

    # Create a instance of OhaiFactCollector for collecting ohai facts
    ohai_facts = OhaiFactCollector()

    # Call the get_ohai_output method of the OhaiFactCollector
    ohai_facts_output = ohai_facts.get_ohai_output(m)

    if ohai_facts_output:
        return True
    else:
        return False



# Generated at 2022-06-20 18:33:21.590409
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai = OhaiFactCollector()
    assert ohai.name == 'ohai'
    assert ohai.namespace.name == 'ohai'
    assert ohai.namespace.prefix == 'ohai_'
    assert ohai._fact_ids == set()


# Generated at 2022-06-20 18:33:24.955738
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact = OhaiFactCollector()
    assert ohai_fact.name == 'ohai'
    assert ohai_fact.namespace.get_name() == 'ohai'
    assert ohai_fact.namespace.get_prefix() == 'ohai_'



# Generated at 2022-06-20 18:33:36.262707
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    """ Unit test for method run_ohai of class OhaiFactCollector """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import b
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    import tempfile

    ohai_content = b("""
{
  "ipaddress": "localhost",
  "platform": "linux"
}
""")

    # Setup test Ohai executable
    tmp_fd, tmp_path = tempfile.mkstemp()

# Generated at 2022-06-20 18:33:42.677679
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ofc = OhaiFactCollector(None)

    assert ofc.name == "ohai"
    assert ofc.namespace == PrefixFactNamespace(namespace_name='ohai', prefix='ohai_')
    assert ofc._fact_ids == set()
    assert ofc.find_ohai(None) is None
    assert ofc.get_ohai_output(None) is None

# Generated at 2022-06-20 18:33:50.108717
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # Test with an existing ohai_path
    import ansible.module_utils.facts.collector.ohai
    from ansible.module_utils.facts.utils import FactsFiles
    import shutil
    import tempfile
    import yaml
    ohai_fact_collector = ansible.module_utils.facts.collector.ohai.OhaiFactCollector()
    tmpdir = tempfile.mkdtemp()
    test_file_name = 'test_run_ohai.yaml'
    test_file_path = '%s/%s' % (tmpdir, test_file_name)
    test_ohai_path = '/bin/echo'
    test_ohai_result = """{
        "test_key": "test_value"
    }"""
    test_ohai_result = test_oh

# Generated at 2022-06-20 18:33:57.962251
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import mock
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.ohai

    module = mock.MagicMock()
    ohai_path = mock.MagicMock()
    rc = 0
    out = '''
    {
      "platform": "ubuntu",
      "platform_version": "14.04"
    }'''
    err = ''

    module.run_command.return_value = (rc, out, err)

    ohai_fact_collector = OhaiFactCollector()

    rc, out, err = ohai_fact_collector.run_ohai(module, ohai_path)

    assert rc == 0
    assert out == out
    assert err == err



# Generated at 2022-06-20 18:33:59.995669
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    return True


# Generated at 2022-06-20 18:34:09.708665
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import os
    import tempfile
    import unittest
    try:
        # Python 3
        from unittest import mock
    except:
        # Python 2
        import mock

    from ansible.module_utils.facts.Collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.ohai.collector import OhaiFactCollector

    class PlatformMock():
        @property
        def dist(self):
            return ('Ubuntu', '18.04', '')

    class ModuleMock():
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, name, opt_dirs=[]):
            return os

# Generated at 2022-06-20 18:34:19.614495
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Importing here because in top level of Ansible, __init__ prevents these imports
    from ansible.module_utils.common.process import supress_logs_context
    from ansible.module_utils.facts import collected_facts
    import ansible.module_utils.facts.collectors.ohai as ohai

    # Module class is a abstract base class
    # Need to create a subclass to instantiate
    class MyModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, name, opt_dirs=[]):
            return None

# Generated at 2022-06-20 18:34:38.812348
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import imp
    import os
    import sys
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collector as module_utils_facts_collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.common._collections_compat import Mapping

    # Module name to use for import
    module_name = 'ansible.module_utils.facts.collector'

    # Make sure the module is reloaded for each test
    if module_name in sys.modules:
        del(sys.modules[module_name])

    # Setup the environment so that the module can be imported
    path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, path)
   

# Generated at 2022-06-20 18:34:44.167932
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'
    assert ohai_fact_collector.namespace.namespace_name == 'ohai'
    assert ohai_fact_collector.namespace.prefix == 'ohai_'


# Generated at 2022-06-20 18:34:55.225376
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = AnsibleModuleMock()
    o = OhaiFactCollector()

    # command which fails
    module.run_command = AnsibleModuleMock.run_command_fail
    assert o.get_ohai_output(module) is None

    # command whic succeeds but returns no data
    module.run_command = AnsibleModuleMock.run_command_no_data
    assert o.get_ohai_output(module) is None

    # command which succeeds but returns broken json
    module.run_command = AnsibleModuleMock.run_command_broken_json
    assert o.get_ohai_output(module) is None

    # command which succeeds and returns correct json
    module.run_command = AnsibleModuleMock.run_command_ok
    assert o.get_ohai_output(module)



# Generated at 2022-06-20 18:35:02.025630
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # Setup
    module = AnsibleModule(argument_spec={})
    ohai_path = '/usr/bin/ohai'
    def module_run_command(command, check_rc=False, close_fds=True, executable=None, data=None):
        return (0, '{"test": 1}', '')
    module.run_command = module_run_command

    # Test
    collector = OhaiFactCollector()
    rc, out, err = collector.run_ohai(module, ohai_path)
    assert rc == 0
    assert out == "{\"test\": 1}"
    assert err == ""


# FIXME: this needs to be split up into multiple tests

# Generated at 2022-06-20 18:35:04.047039
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()


# Generated at 2022-06-20 18:35:14.556546
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import sys
    if sys.version_info[0] == 3:
        builtins_name = 'builtins'
    else:
        builtins_name = '__builtin__'
    mod_mock = Mock(name='module')
    ohai_path = '/usr/bin/ohai'
    rc = 0
    output = '{"foo": "bar"}'
    err = ''
    rc_mock = Mock(name='rc')
    rc_mock.side_effect = [rc]
    out_mock = Mock(name='out')
    out_mock.side_effect = [output]
    err_mock = Mock(name='err')
    err_mock.side_effect = [err]
    run_cmd_mock = Mock(name='run_command')
    run_cmd_

# Generated at 2022-06-20 18:35:25.330150
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai_collector = OhaiFactCollector()

    # Test that ohai returned a non-zero exit code
    module.run_command.return_value = [1, '', '']
    assert ohai_collector.get_ohai_output(module) is None

    # Test that ohai wasn't on the PATH
    if 'PATH' in os.environ:
        del os.environ['PATH']
    assert ohai_collector.get_ohai_output(module) is None

    # Test that ohai returned JSON data
    module.run_command.return_value = [0, '{"ohai": "gimme some chicken"}', '']
    assert ohai_collector.get_ohai_output(module) == '{"ohai": "gimme some chicken"}'

# Generated at 2022-06-20 18:35:31.938484
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.COLLECTORS = []
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    ohai = OhaiFactCollector()
    # FIXME: mock ohai_path, run_ohai
    ohai_output = ohai.get_ohai_output(module)
    assert ohai_output is not None

# Generated at 2022-06-20 18:35:42.725798
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import \
        get_collector_instance

    module = FakeAnsibleModule()
    name = 'ohai'
    collector = get_collector_instance(name, module)

    # testing collect method of OhaiFactCollector
    # with empty list of Ohai facts
    # expected results: empty dict
    ohai_facts = {}
    module.ohai_output = json.dumps(ohai_facts)
    collected_facts = collector.collect(module=module)
    assert collected_facts == ohai_facts

    # testing collect method of OhaiFactCollector
    # with non-empty list of Ohai facts
    # expected results: known Ohai facts
    ohai_facts = {'platform': 'foo'}
    module.ohai_output = json.d

# Generated at 2022-06-20 18:35:50.304433
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    module = MockModule(
        'ansible_module_test',
        params=dict()
    )
    # ohai not available
    ohai_fact_collector = OhaiFactCollector()
    try:
        ohai_fact_collector.get_ohai_output(module)
    except Exception:
        pass
    ohai_fact_collector = OhaiFactCollector()
    module = MockModule(
        'ansible_module_test',
        params=dict(),
    )
    # ohai available, return ohai facts
    ohai_fact_collector.get_ohai_output(module)

# Generated at 2022-06-20 18:36:12.694904
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector
    o = ansible.module_utils.facts.collector.OhaiFactCollector()
    fake_module = FakeModule()
    o.run_ohai(fake_module, '/bin/true')
# end of test_OhaiFactCollector_run_ohai()


# Generated at 2022-06-20 18:36:21.250399
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    import tempfile

    _temp_dir = tempfile.TemporaryDirectory()
    temp_dir = _temp_dir.name

    ohai_bin_contents = '''#!/bin/sh
echo '{"foo": "bar" }'
exit 0
'''

    ohai_bin_path = temp_dir + '/ohai'
    with open(ohai_bin_path, 'w') as f:
        f.write(ohai_bin_contents)

    ohai_module

# Generated at 2022-06-20 18:36:32.543750
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import imp
    module = imp.new_module('test.module')

    class dummy_module:
        def __init__(self, o_path=None, o_rc=None, o_out=None, o_err=None):
            self.ohai_path = o_path
            self.ohai_rc = o_rc
            self.ohai_out = o_out
            self.ohai_err = o_err

        def get_bin_path(self, value):
            return self.ohai_path

        def run_command(self, command):
            return (self.ohai_rc, self.ohai_out, self.ohai_err)

    module.run_command = dummy_module().run_command
    module.get_bin_path = dummy_module().get_bin_path

   

# Generated at 2022-06-20 18:36:43.510791
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ModuleDeprecationWarning

    class MockModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=None, required=False):
            return '/usr/bin/ohai'

        def run_command(self, cmd):
            return 0, "[{'test':'facts'}]", None

    ohai_collector = OhaiFactCollector()
    ohai_facts = ohai_collector.get_ohai_output(MockModule())
    assert isinstance(ohai_facts, list), 'ohai_facts: %s' % ohai_facts

# Generated at 2022-06-20 18:36:55.518617
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.basic
    o_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            ohai_path=dict(type='path', required=True)
        )
    )
    instance = OhaiFactCollector()
    ohai_path = "/home/doug/repos/ansible/lib/ansible/module_utils/facts/ohai/tests/files/bin/ohai"
    rc, out, err = instance.run_ohai(o_module, ohai_path)
    print("rc: %s" % rc)
    print("out: %s" % out)
    print("err: %s" % err)
    assert rc == 0
    assert out == b''
    assert err == b''


# Generated at 2022-06-20 18:37:00.519611
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    module_mock = MockModule(params={})
    module_mock.get_bin_path = Mock(return_value=True)

    ohai_path = OhaiFactCollector.find_ohai(module_mock)
    assert ohai_path is True


# Generated at 2022-06-20 18:37:01.086947
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass

# Generated at 2022-06-20 18:37:09.172816
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts import Namespace
    collectors = (OhaiFactCollector(),)
    namespace = Namespace()
    ofc = OhaiFactCollector(collectors=collectors, namespace=namespace)
    from ansible.module_utils._text import to_bytes
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            if command == u'/tmp/doesntexist':
                return 255, b'', b'ohai cmd not found'
            elif command == u'/bin/ls':
                return 0, b'', b''
            else:
                return 0, to_bytes(json.dumps({u'a': u'b'})), b''

# Generated at 2022-06-20 18:37:19.355618
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collectors
    import ansible.module_utils.facts.collector

    # mocking out 'run_command' method of base class.
    def mock_run_command(self, module, name, paths=None, data=None, check_rc=True):
        import os
        import subprocess
        if '/bin/bash' in name and len(name) == 10:
            return 123, "out", "err"
        elif '/bin/bash' in name and len(name) == 34:
            return 0, "/bin/ohai", "err"

# Generated at 2022-06-20 18:37:29.639842
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector

    class FakeModule(object):
        def __init__(self, ohai_data):
            self.ohai_data = ohai_data

        def get_bin_path(self, arg):
            return '/usr/bin/%s' % arg

        def run_command(self, arg):
            return (0, self.ohai_data, '')

    module = FakeModule('{ "test_fact": "rspec" }')
    ofc = ansible.module_utils.facts.collector.get_collector('ohai')

    result = ofc.get_ohai_output(module)
    assert result == '{ "test_fact": "rspec" }'

# Generated at 2022-06-20 18:38:15.330497
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    try:
        obj = OhaiFactCollector()
    except Exception:
        pass


# Generated at 2022-06-20 18:38:24.960368
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'
    assert ohai_fact_collector._fact_ids == set()
    assert ohai_fact_collector._namespace.namespace_name == 'ohai'
    assert ohai_fact_collector._namespace.prefix == 'ohai_'
    assert ohai_fact_collector._collectors is None


# Generated at 2022-06-20 18:38:32.965098
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_file_content

    module = get_file_content(base_dir=(os.path.dirname(os.path.abspath(__file__))),
                              rel_path='../module_utils/facts/test_module.py')
    ohai_collector = get_collector_instance('ohai')
    ohai_output = ohai_collector.get_ohai_output(module)
    assert ohai_output is None

# Generated at 2022-06-20 18:38:34.155264
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    assert OhaiFactCollector().find_ohai is not None


# Generated at 2022-06-20 18:38:39.794661
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import tempfile
    import os
    import shutil

    testdir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:38:44.872371
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    OhaiFactCollector_collector = OhaiFactCollector()
    test_data_file = 'test/test_OhaiFactCollector.json'
    ohai_facts = OhaiFactCollector_collector.collect(test_data_file)
    assert ohai_facts['ohai_os'] == 'linux'

# Generated at 2022-06-20 18:38:51.667937
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():

    class testModule():
        def get_bin_path(self,binpath):
            if binpath == 'ohai':
                return '/usr/bin/ohai'
            return None
        def run_command(self, ohai_path):
            if ohai_path == '/usr/bin/ohai':
                return 0, '{"one": 1}', ''
            return None

    tmod = testModule()
    ofc = OhaiFactCollector()
    assert ofc.name == 'ohai'
    assert type(ofc) == OhaiFactCollector
    assert ofc.get_ohai_output(tmod) == '{"one": 1}'
    assert ofc.collect(module=tmod) == {"one": 1}

# Generated at 2022-06-20 18:38:53.739353
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = None
    collector = OhaiFactCollector()
    result = collector.get_ohai_output(module)
    assert result is None

# Generated at 2022-06-20 18:38:55.285743
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'

# Generated at 2022-06-20 18:39:03.782141
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # only needed to make method available for testing
    module_class = type('AnsibleModule', (), {})
    module = module_class()

    # TODO: why is this necessary?
    module.get_bin_path = lambda *args: '/usr/bin/ohai'

    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    ohai_collector = OhaiFactCollector()

    ohai_path = ohai_collector.find_ohai(module)

    assert ohai_path == '/usr/bin/ohai'

