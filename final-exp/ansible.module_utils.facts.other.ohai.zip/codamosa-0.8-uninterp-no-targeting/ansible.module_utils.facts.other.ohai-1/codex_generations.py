

# Generated at 2022-06-20 18:30:34.001158
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    # create a mock module object
    class OhaiMockModule(object):
        class OhaiResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def __init__(self):
            self.ohai_exe = None
            self.ohai_return = OhaiResult(0, '{"cheese": "true"}', '')

        def get_bin_path(self, exe_name):
            self.ohai_exe = exe_name
            if exe_name == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None

        def run_command(self, ohai_exe):
            return self.ohai_return.rc, self.ohai_

# Generated at 2022-06-20 18:30:40.104556
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():

    class MockModule(object):
        def get_bin_path(self, path):
            return "/bin/%s" % path

    mock_module = MockModule()
    collector = OhaiFactCollector()
    assert collector.find_ohai(mock_module) == "/bin/ohai"


# Generated at 2022-06-20 18:30:53.404514
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import shutil
    import tempfile
    import subprocess as sp

    # make a file
    tmpdir = tempfile.mkdtemp()
    file_name = tmpdir + '/ohai'
    file_handle = open(file_name, 'w')
    file_handle.write("#! /bin/bash\n")
    file_handle.write("echo '{\"foo\": \"bar\"}'\n")
    file_handle.close()
    os.chmod(file_name, 0o700)

    # set up the test
    ohai = OhaiFactCollector(namespace='ohai')
    module = FakeModule(tmpdir)

    # run the code
    rc, out, err = ohai.run_ohai(module, file_name)

    # get the results
    shutil.rmt

# Generated at 2022-06-20 18:31:04.313118
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import which
    from ansible.module_utils.facts.system import ohai
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.system.ohai import OhaiFactCollector

    dyn_ohai_collector = get_collector_instance(OhaiFactCollector)
    file_path = which('ohai')

    # Test with no ohai installed
    ohai_obj = OhaiFactCollector()

# Generated at 2022-06-20 18:31:08.471782
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'
    assert not ohai_fact_collector._fact_ids

# Generated at 2022-06-20 18:31:14.729326
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    class MockModule():
        def run_command(self, ohai_path):
            # ohai_path = self.find_ohai(module)
            return 0, "{'platform':'freebsd'}", ""
        def get_bin_path(self, ohai):
            return "ohai"

    class MockFactCollector():
        def __init__(self, collectors=None, namespace=None):
            pass

    module = MockModule()

    c = OhaiFactCollector(collectors=MockFactCollector())
    ohai_facts = c.get_ohai_output(module)

    assert ohai_facts is not None

# Generated at 2022-06-20 18:31:17.971886
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    module = None
    ohai_path = OhaiFactCollector().find_ohai(module)
    assert type(ohai_path) is str

# Generated at 2022-06-20 18:31:28.225835
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import sys
    import io

    # Mock module
    class MockModule():
        def __init__(self):
            self.params = {'_ansible_version': '2.8.0'}
            self.fail_json = lambda msg: print(msg, file=sys.stderr)
            self.run_command = lambda command: ('ohai_path', '', '')
            self.get_bin_path = lambda command: 'ohai_path'
            self.log = lambda msg: print(msg, file=sys.stderr)
            self.deprecate = lambda msg: print(msg, file=sys.stderr)

    # Get ohai output
    module = MockModule()
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.find_oh

# Generated at 2022-06-20 18:31:29.121026
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass

# Generated at 2022-06-20 18:31:35.714980
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    def get_bin_path(module, executable):
        return '/usr/bin/ohai'

    import ansible.module_utils.basic
    mod = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    mod.get_bin_path = get_bin_path  # monkey patch method

    f = OhaiFactCollector()
    result = f.find_ohai(mod)
    assert result == '/usr/bin/ohai'

# Generated at 2022-06-20 18:31:39.984288
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert type(ohai_fact_collector) == OhaiFactCollector
    assert ohai_fact_collector.name == 'ohai'

# Generated at 2022-06-20 18:31:46.518578
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact = OhaiFactCollector()
    assert ohai_fact.name == 'ohai'
    assert ohai_fact.collectors is None
    assert ohai_fact.namespace.namespace_name == 'ohai'
    assert ohai_fact.namespace.prefix == 'ohai_'
    # Make sure that ohai is installed, so that the ohai command can be run
    # It is only installed on Linux, so this will break if it is run from another OS
    import platform
    if platform.system() == 'Linux':
        assert ohai_fact.find_ohai('/usr/bin/ruby') is not None
    else:
        assert ohai_fact.find_ohai('/usr/bin/ruby') is None

# Generated at 2022-06-20 18:31:52.579500
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import parse_fact
    from ansible.module_utils.facts.utils import parse_facts

    # Initialize FactsCollector with OhaiFactCollector
    ohai_fact_collector = get_collector_instance(OhaiFactCollector)
    facts_collector = FactsCollector(ohai_fact_collector)

    # Call collect method of FactsCollector

# Generated at 2022-06-20 18:32:05.605815
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content

    # ohai test
    # plugin output
    test_plugin_output = get_file_content(path='/tmp/ansible_test_ohai_plugin.json')
    test_plugin_output = to_text(test_plugin_output)
    # plugin output parsed
    test_plugin_output_parsed = json.loads(test_plugin_output)

    # ohai output
    test_ohai_output = get_file_content(path='/tmp/ansible_test_ohai.json')
    test_ohai_output = to_text(test_ohai_output)
    # ohai output parsed

# Generated at 2022-06-20 18:32:12.513668
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    # Without parameters
    fact_collector = OhaiFactCollector()

    # Check default values
    assert fact_collector.name == 'ohai'

    # Values from base constructor
    assert fact_collector.collectors == []
    assert fact_collector.namespace

    # With parameters
    fact_collector = OhaiFactCollector(collectors=[], namespace='')

    # Check values
    assert fact_collector.collectors == []
    assert fact_collector.namespace


# Generated at 2022-06-20 18:32:23.693936
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import unittest
    import ansible.module_utils.facts.collector

    find_ohai_test_cases = [
        {
            'description': 'Ohai is available',
            'bin_paths': {
                'ohai': '/usr/bin/ohai'
            },
            'expected': '/usr/bin/ohai'
        },
        {
            'description': 'Ohai not available',
            'bin_paths': {},
            'expected': None,
        },
        {
            'description': 'Ohai not available, fake fact present',
            'bin_paths': {
                'ohai': None
            },
            'expected': None,
        },
    ]

    class FakeModule:
        """Fake module for OhaiFactCollector.find_ohai"""

# Generated at 2022-06-20 18:32:27.031253
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    collector = OhaiFactCollector()
    assert collector.name == "ohai"
    assert collector.namespace.namespace_name == "ohai"
    assert collector.namespace.prefix == "ohai_"

# Generated at 2022-06-20 18:32:29.199374
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():

    '''Gets the OhaiFactCollector.'''

    ofc = OhaiFactCollector()
    assert ofc is not None

# Generated at 2022-06-20 18:32:41.049047
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.collector.test_ohai
    import ansible.module_utils.facts.test_utils
    ohai=ansible.module_utils.facts.collector.ohai.OhaiFactCollector()
    ansible.module_utils.facts.test_utils._create_class_instance(ohai)
    test_ohai=ansible.module_utils.facts.collector.test_ohai.TestOhai()
    ansible.module_utils.facts.test_utils._create_class_instance(test_ohai)
    out = ohai.run_ohai(test_ohai, test_ohai.get_bin_path('ohai'))
    assert out[0]==0

# Generated at 2022-06-20 18:32:47.982997
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_data = {'kernel': {'name': 'Linux'}, 'machinename': 'testhost',
                 'hostname': 'testhost', 'fqdn': 'testhost.testdomain.com',
                 'domain': 'testdomain.com'}
    ohai_json = json.dumps(ohai_data)

    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector # pylint: disable=import-error

    test_module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['all'], type='list'),
            gather_timeout = dict(default=10, type='int')
        ),
        supports_check_mode=True
    )

    ohai_fact_collector = OhaiFactCollector()



# Generated at 2022-06-20 18:33:00.624272
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    class MockModule(object):
        @staticmethod
        def get_bin_path(binary):
            if binary == 'ohai':
                return '/usr/local/bin/ohai'

        @staticmethod
        def run_command(copy_path):
            results = dict()
            results['rc'] = 0
            results['out'] = '{ "foo": "bar" }'
            results['err'] = ""
            return results['rc'], results['out'], results['err']

    module = MockModule()
    ohai_path = '/usr/local/bin/ohai'
    ohai = OhaiFactCollector()
    rc, out, err = ohai.run_ohai(module, ohai_path)
    assert rc == 0 and out == '{ "foo": "bar" }' and err == ""



# Generated at 2022-06-20 18:33:11.083288
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    class TestModule(object):

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

        def run_command(self, cmd):
            return 0, '', ''

    from ansible.module_utils.facts.collector import BaseFactCollector

    module = TestModule()
    ohai_collector = OhaiFactCollector()

    ohai_path = '/usr/bin/ohai'
    ohai_cmd = ['ohai', '--format', 'json']

    rc, out, err = ohai_collector.run_ohai(module, ohai_path)

    assert rc == 0
    assert out == ''
    assert err == ''


# Generated at 2022-06-20 18:33:22.525059
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.called_command = None

        def get_bin_path(self, executable, required=False):
            return "/bin/" + executable

        def run_command(self, args, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False):
            self.called_command = args
            if args[0] == "/bin/ohai":
                return (0, '{ "os": "linux" }', '')
            return (1, '', 'FAILED')

    test_module = MockModule()
    ohai = OhaiFactCollector()

# Generated at 2022-06-20 18:33:27.853234
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    import ansible.module_utils.facts.collector

    for fact_collector in ansible.module_utils.facts.collector.fact_collector_classes:
        if fact_collector is OhaiFactCollector:
            # If the above list comprehension doesn't yield the desired result
            # then we have to raise an exception
            raise Exception("OhaiFactCollector is not being registered as a fact collector")

# Generated at 2022-06-20 18:33:40.320028
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ''' Unit tests for method get_ohai_output of class OhaiFactCollector '''

    import ansible.module_utils.facts.collector

    class MockModule:
        def __init__(self, out=None):
            self.run_command_out = out

        def get_bin_path(self, arg):
            return '/path/to/ohai'

        def run_command(self, arg):
            return '0', self.run_command_out, ''


    # Case 1: ohai output is none
    module = MockModule()
    fact_collector = OhaiFactCollector()
    ohai_output = fact_collector.get_ohai_output(module)
    assert ohai_output is None

    # Case 2: ohai_output is json

# Generated at 2022-06-20 18:33:41.818710
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai = OhaiFactCollector()
    assert ohai is not None

# Generated at 2022-06-20 18:33:52.793834
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import callback
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import namespace

    ohai_facts = {}
    def mock_run_ohai(module, ohai_path):
        ohai_data = '{"hostname": "host_name","fqdn": "host_name.local",' \
                    '"ipaddress": "192.168.1.1","uptime_seconds": 3600}'
        return 0, ohai_data, ''

    mock_module = callback.FactsCollectorModule()
    mock_module.run_command = mock_

# Generated at 2022-06-20 18:34:05.741104
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class MockModule(object):
        def __init__(self, binnames, binpath):
            self.bin_path_list = binnames
            self.binpath = binpath

        def get_bin_path(self, *paths, **kwargs):
            for binpath in paths:
                if binpath in self.bin_path_list:
                    return self.binpath

        def run_command(self, *args, **kwargs):
            return (0, '{}', '')

    module_paths = {'/usr/bin/ohai': 'ohai',
                    '/bin/nope': 'nope'}
    for ohai_in_path, binpath in module_paths.iteritems():
        module = MockModule(['ohai'], ohai_in_path)
        ohai_

# Generated at 2022-06-20 18:34:17.816531
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    def get_bin_path(*args, **kwargs):
        return '/usr/bin/ohai'

    def run_command(*args, **kwargs):
        return (0, '{"foo": "bar", "baz": "qux"}', None)

    class FakeModule(object):
        def __init__(*args, **kwargs):
            pass

        def get_bin_path(*args, **kwargs):
            return get_bin_path(*args, **kwargs)

        def run_command(*args, **kwargs):
            return run_command(*args, **kwargs)

    ohai = OhaiFactCollector()
    ohai_facts = ohai.collect(module=FakeModule())


# Generated at 2022-06-20 18:34:28.413350
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts
    import ansible

    # Create an instance of BaseModule
    fake_module = ansible.module_utils.facts.utils.BaseModule("", "/bin/false", "")

    # Mock function get_bin_path()
    def get_bin_path(binary):
        if binary == "ohai":
            return "/usr/bin/ohai"

# Generated at 2022-06-20 18:34:48.978589
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import os
    import sys
    import subprocess

    if sys.version_info[0] >= 3:
        import unittest.mock as mock
    else:
        import mock

    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = \
        '/Users/anatoly/src/ansible/module_utils/facts/collector/../../../hacking/test-module'
    rc, out, err = OhaiFactCollector().run_ohai(mock_module, '/Users/anatoly/src/ansible/module_utils/facts/collector/../../../hacking/test-module')
    assert rc == 0
    assert out == '{"ohai": "yes"}\n'

    mock_module.run_command.side_effect = O

# Generated at 2022-06-20 18:34:59.134636
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector

    temp_dir = tempfile.mkdtemp()
    dummy_ohai_path = os.path.join(temp_dir, 'ohai')

    with open(dummy_ohai_path, 'w') as dummy_ohai:
        dummy_ohai.write('''#!/bin/sh
        echo '{"silly": "bean"}'
        exit 0
        ''')

    class DummyModule(object):
        def get_bin_path(self, binary):
            return dummy_ohai

# Generated at 2022-06-20 18:35:00.823391
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    test_collector = OhaiFactCollector(namespace='ohai')
    assert 'ohai' in str(test_collector)


# Generated at 2022-06-20 18:35:09.452245
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_path = OhaiFactCollector()
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/ohai'
    module = MockModule()
    result_ohai_path = ohai_path.find_ohai(module)
    assert type(result_ohai_path) is str
    assert result_ohai_path == "/usr/bin/ohai"

# Generated at 2022-06-20 18:35:17.194366
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_namespace

    test_namespace = get_collector_namespace('ohai') 
    assert test_namespace == 'ohai_'

    test_facts = OhaiFactCollector()

    import ansible.module_utils.facts.test_module
    test_module = ansible.module_utils.facts.test_module.TestModule()
    bin_path = test_facts.find_ohai(test_module)

    # Lookup path, this will be None
    assert bin_path is None

    # Mock the path, this should work
    test_module.bin_path = '/usr/bin'
    bin_path = test_facts.find_ohai(test_module)
    assert bin_path == '/usr/bin/ohai'

# Generated at 2022-06-20 18:35:25.257127
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import AnsibleFactsCollector
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    module = AnsibleModule({})
    o = OhaiFactCollector()

    assert(isinstance(o, AnsibleFactsCollector))
    assert(isinstance(o, OhaiFactCollector))

    rc, out, err = o.run_ohai(module, '/bin/false')

    assert(rc == 1)
    assert(out == '')
    assert(err != '')

# Generated at 2022-06-20 18:35:29.337532
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect()
    # This "is not None" test is the point of this test.
    assert ohai_facts is not None

# Generated at 2022-06-20 18:35:32.056358
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_factCollector = OhaiFactCollector()
    assert ohai_factCollector.name == 'ohai'
    assert ohai_factCollector._fact_ids == set()


# Generated at 2022-06-20 18:35:37.177483
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    import ansible.module_utils.facts.test_ohai_module
    ohai_path = OhaiFactCollector().find_ohai(ansible.module_utils.facts.test_ohai_module.TestModule())
    assert ohai_path == ansible.module_utils.facts.test_ohai_module.TestModule.bin_path_msg


# Generated at 2022-06-20 18:35:39.339433
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = TestModule()
    ohai_fact_collector = OhaiFactCollector()
    ohai_output = ohai_fact_collector.get_ohai_output(module)
    ohai_fact_collector.run_ohai(module, 'bin/ohai')
    assert ohai_output is not None


# Generated at 2022-06-20 18:36:07.007348
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.ohai
    import ansible_collections.ansible.community.plugins.module_utils.basic
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors

    try:
        import json
    except ImportError:
        import simplejson as json

    import sys

    class FakeModule():
        def __init__(self):
            class AnsibleModule(object):
                def __init__(self):
                    self.exit_json = lambda: sys.exit(1)

                def fail_json(self, *args, **kwargs):
                    sys.exit(1)

            self._AnsibleModule = AnsibleModule


# Generated at 2022-06-20 18:36:10.284703
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    oc = OhaiFactCollector()
    oc.get_ohai_output = lambda module: '{"foo": "bar"}'

    assert oc.collect() == {'ohai': {'foo': 'bar'}}

# Generated at 2022-06-20 18:36:15.616978
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule

    ohai = OhaiFactCollector()
    module = AnsibleModule(argument_spec={'path': {}})
    facts = Facts(module=module, collectors=[ohai])
    module.exit_json(ansible_facts=facts.get_facts())


# vim: set et:

# Generated at 2022-06-20 18:36:19.989652
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_path = 'tests/fixtures/ohai/ohai'
    module = MockModule()
    module.run_command = run_command
    rc, out, err = OhaiFactCollector().run_ohai(module, ohai_path)
    assert rc == 0
    assert out
    assert err is None

# Test the get_ohai_output of class OhaiFactCollector

# Generated at 2022-06-20 18:36:31.323946
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    o = OhaiFactCollector()
    class sysmock():
        def __init__(self):
            self.args = {
                'Ohai is not available': [],
                'Bad Ohai output': [],
                'Good Ohai output': ['{}']
            }
            self.ans = {
                'Ohai is not available': None,
                'Bad Ohai output': None,
                'Good Ohai output': {}
            }
            self.fail = ['Ohai is not available', 'Bad Ohai output']
            self.call_count = 0
        def get_bin_path(self, command):
            if command == 'ohai':
                return 'Ohai is not available'
        def run_command(self, cmd):
            a = self.args[cmd]

# Generated at 2022-06-20 18:36:42.673104
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import os
    import tempfile
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.path = os.environ['PATH']
            self.params = {}
        def get_bin_path(self, exe):
            if os.path.isfile(exe):
                return exe
            for path in self.path.split(os.pathsep):
                full = os.path.join(path, exe)
                if os.path.isfile(full):
                    return full
            return None

# Generated at 2022-06-20 18:36:48.996664
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector._COLLECTOR_CACHE['network'] = FauxNetworkFactCollector()
    ansible.module_utils.facts.collector._COLLECTOR_CACHE['ohai'] = FauxOhaiFactCollector()
    ohai_override = ansible.module_utils.facts.collector._COLLECTOR_CACHE['ohai'].collect(module=FauxAnsibleModule())
    assert ohai_override == FauxOhaiFactCollector.faux_ohai_data
    # The facts are prefixed with ohai_, so the keys will be 'ohai_os' and 'ohai_platform'
    assert 'ohai_os' in ohai_override

# Generated at 2022-06-20 18:36:57.763849
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import subprocess
    from ansible.module_utils.facts import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    class fake_ansible_module:
        def __init__(self, **kwargs):
            self.run_command_calls = []
            self.get_bin_path_calls = []
            self.get_bin_path_call_count = 0
            self.params = kwargs


# Generated at 2022-06-20 18:37:04.445661
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    assert isinstance(OhaiFactCollector(), ansible.module_utils.facts.namespace.PrefixFactNamespace)
    assert OhaiFactCollector().name == 'ohai'
    assert isinstance(OhaiFactCollector(), ansible.module_utils.facts.collector.BaseFactCollector)

# Generated at 2022-06-20 18:37:09.171413
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai = OhaiFactCollector()
    import ansible.module_utils.facts.file.system.posix.file
    module = ansible.module_utils.facts.file.system.posix.file
    rc, out, err = ohai.run_ohai(module, '/tmp/doesnotexist')
    assert rc is not 0



# Generated at 2022-06-20 18:38:06.711721
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.collector
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self):
            self.params = {
                'bin_path': '/bin'
            }

        def get_bin_path(self, *args, **kwargs):
            return self.params['bin_path']

    def wrapped_find_ohai(self):
        return self.find_ohai(self.module)

    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.module = MockModule()

    # The default bin_path should be /bin
    bin_path = ohai_fact_collector.module.get_bin_path()
    assert bin_path == '/bin'

    # Mock

# Generated at 2022-06-20 18:38:16.776546
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, executable):
            return "/usr/bin/ohai"
        def run_command(self, cmd):
            return 0, "", ""

    module = MockModule()
    fact_collector = OhaiFactCollector()
    ohai_facts = fact_collector.collect(module=module)
    assert ohai_facts != {}
    assert 'platform' in ohai_facts
    assert 'platform_family' in ohai_facts
    assert 'platform_version' in ohai_facts
    assert 'os' in ohai_facts
    assert 'os_family' in ohai_facts

# Generated at 2022-06-20 18:38:27.352648
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    # pylint: disable=import-error,no-name-in-module
    from ansible.module_utils.facts.system.ohai import OhaiFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six.moves import StringIO
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.test_utils import AnsibleModuleMock

    # pylint: disable=unused-variable
    # Using fixtures to mock the required objects,
    # and mocking the_ansible_module.exit_json() and AnsibleModuleMock.run_command() methods

    ansible_module = AnsibleModuleMock()
    ansible_module.exit_json = lambda x: x
    ansible_module.run_

# Generated at 2022-06-20 18:38:34.235543
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic

    # Preparing a Mock module object
    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd: (0, to_bytes('{ "a": "b" }'), '')

    # Testing
    ohai_fact_collector = OhaiFactCollector(module=module)

    assert ohai_fact_collector.get_ohai_output(module) == to_bytes('{ "a": "b" }')

# Generated at 2022-06-20 18:38:45.064637
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # NOTE: this makes this test more difficult to execute outside of
    # the ansible source tree, but allows us to accurately test what
    # Ansible would do.
    module = MockModule()
    ohai_path = module.get_bin_path('ohai')
    if not ohai_path:
        return

    collector = OhaiFactCollector()
    ohai_output = collector.get_ohai_output(module)
    assert ohai_output is not None

    try:
        ohai_facts = json.loads(ohai_output)
        assert(isinstance(ohai_facts, dict))
    except Exception:
        # FIXME: useful error, logging, something...
        pass


# Generated at 2022-06-20 18:38:47.834562
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    # TODO:
    #
    # ohai_facts = OhaiFactCollector()
    # assert(ohai_facts.name == 'ohai')
    return None

# Generated at 2022-06-20 18:38:59.086780
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    ''' Test collect method of class OhaiFactCollector '''
    # Test 1: ohai_output is None
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.collectors.ohai as ohai
    import ansible.module_utils.facts.namespace as ns

    o = ohai.OhaiFactCollector(collectors=None, namespace=ns.PrefixFactNamespace(namespace_name='test', prefix='test_'))

    # Simulate the scenario when ohai_output is None
    o.get_ohai_output = lambda x: None
    assert (len(o.collect()) == 0)

    # Required objects for test
    import ansible.module_utils.facts.module_common as module_common
    import ansible.module_utils.facts

# Generated at 2022-06-20 18:39:04.410828
# Unit test for method run_ohai of class OhaiFactCollector

# Generated at 2022-06-20 18:39:13.358839
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance

    module = get_collector_instance('ansible.module_utils.facts.collector.OhaiFactCollector')
    module.run_command = lambda ohai_path: (0, '{"a": "b"}', '')

    # Return values
    rc, out, err = module.run_ohai(module, '/usr/bin/ohai')
    assert rc == 0
    assert out == '{"a": "b"}'
    assert err == ''

    # No ohai binary in path
    module.get_bin_path = lambda x: None
    assert module.run_ohai(module, '/usr/bin/ohai') == (None, None, None)

    # Maybe ohai is running on a different path
    module.get

# Generated at 2022-06-20 18:39:18.295046
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_collector = get_collector_instance('ohai')
    print(ohai_collector.find_ohai())

