

# Generated at 2022-06-20 18:30:32.472999
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    # create a class instance
    ohai = OhaiFactCollector()

    # create a module class instance
    from ansible.module_utils.facts.test.test_ohai import FakeModule
    module = FakeModule()

    # collect Ohai facts
    collected_facts = ohai.collect(module=module, collected_facts=None)

    # check that Ohai facts have been collected
    assert collected_facts['ohai_platform'] == 'linux'
    assert collected_facts['ohai_platform_version'] == '3.10.0-862.el7.x86_64'

# Generated at 2022-06-20 18:30:44.362023
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # FIXME: This needs some work.
    # This is why it is disabled.
    # The code in the method does not work with the output of the real ohai.
    # We need to mock or stub the module object that the method uses.
    return

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = AnsibleModule(argument_spec={})

    ohai_path = '/bin/echo'
    ohai_args = b'{ "platform" : "mac_os_x" }'

    module.run_command = lambda args: (0, ohai_args, '')

    ohai_fact_collector = OhaiFactCollector()

    rc, out

# Generated at 2022-06-20 18:30:50.757302
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    o = OhaiFactCollector()
    o.find_ohai = lambda x: '/usr/bin/ohai'
    o.run_ohai = lambda x,y: (0, '{ "ohai": "facts" }', '')
    ohai_output = o.get_ohai_output(None)
    assert (ohai_output == '{ "ohai": "facts" }')

# Generated at 2022-06-20 18:31:01.331390
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    '''
    Test the get_ohai_output method of class OhaiFactCollector.
    '''
    module = AnsibleModuleMock()
    module.run_command = module.run_command_mock
    module.get_bin_path = module.get_bin_path_mock

    collector = OhaiFactCollector()
    result = collector.get_ohai_output(module)
    assert result == '''{
            "platform": "ubuntu",
            "platform_version": "10.04",
            "platform_family": "debian"
        }'''


# Generated at 2022-06-20 18:31:08.681271
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    module = MockModule()
    try:
        find_ohai = OhaiFactCollector().find_ohai(module)
        assert find_ohai == '/usr/bin/ohai', "Incorrect path returned by fact collector"
    except Exception as e:
        assert False, "Incorrect path returned by fact collector"


# Generated at 2022-06-20 18:31:15.412798
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # create instance of OhaiFactCollector
    ohai_collector = OhaiFactCollector()
    # create class DummyModule()
    class DummyModule():
        # create method for get_bin_path
        def get_bin_path(self, cmd):
            return "bin/ohai"
        # create method for run_command
        def run_command(self, ohai_path):
            stdout = '{"ipaddress": "192.168.0.1"}'
            stderr = ''
            return 0, stdout, stderr
    # create instance of DummyModule class
    module = DummyModule()
    # call method collect()
    result = ohai_collector.collect(module)
    # assert, check result of collect()

# Generated at 2022-06-20 18:31:26.935082
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector
    import platform

    module_mock = basic.AnsibleModule(
        argument_spec=dict()
    )

    ohai_collector = ansible.module_utils.facts.collector.OhaiFactCollector(
        collectors=None,
        namespace=None
    )

    # If ohai binary is not present
    ohai_fact_collector = ohai_collector.get_ohai_output(module=module_mock)
    assert ohai_fact_collector is None

    # If ohai binary is present
    if platform.system() == "Darwin":
        module_mock = basic.AnsibleModule(
            argument_spec=dict()
        )


# Generated at 2022-06-20 18:31:27.548845
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    pass

# Generated at 2022-06-20 18:31:34.589620
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    """
    Unit test for the collect() method
    """
    import ansible.module_utils.facts.system.ohai
    m = ansible.module_utils.facts.system.ohai.AnsibleModuleFake()
    o = ansible.module_utils.facts.system.ohai.OhaiFactCollector()
    o.collect(module=m)

if __name__ == '__main__':
    test_OhaiFactCollector_collect()

# Generated at 2022-06-20 18:31:40.894458
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import Facts

    class base_module:
        def get_bin_path(self, name):
            return 'found/'+name

    baseobj = BaseFactCollector(collectors=None,
                                namespace=PrefixFactNamespace(namespace_name='ohai',
                                                               prefix='ohai_'))
    # Inherit from BaseFactCollector, remove dependency on BaseFactCollector

# Generated at 2022-06-20 18:31:50.948840
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    ohai_path = "/usr/bin/ohai"
    module = None
    ohai = OhaiFactCollector(collectors=None, namespace=None)
    
    rc, out, err = ohai.run_ohai(module, ohai_path)

    assert rc == 0
    assert out != None
    assert out != ""
    assert err == ""

# Generated at 2022-06-20 18:31:59.171982
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils import basic
    import sys

    fake_module = basic.AnsibleModule(
        arg_spec=dict(),
        supports_check_mode=True,
    )
    fake_module.run_command = _test_run_command

    _test_ohai_path = _test_find_ohai()
    ofc = OhaiFactCollector(collectors=None, namespace=None)

    ohai_output = ofc.get_ohai_output(fake_module)
    assert ohai_output == _test_ohai_path + 'fake output', \
        'OhaiFactCollector.get_ohai_output'

    _test_ohai_failure = _test_ohai_path + 'fake output failure'
    ohai_output = ofc.get_ohai_

# Generated at 2022-06-20 18:32:04.057451
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    '''Test constructor of class OhaiFactCollector'''
    ohai_collector = OhaiFactCollector()
    assert ohai_collector.name == 'ohai'
    assert ohai_collector._fact_ids == set()

# Generated at 2022-06-20 18:32:14.191716
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class FakeModule:
        class FakeRun:
            rc = 0
            stdout = '{"ohai": {"output": "ohai"}}'
            stderr = ''

        def __init__(self):
            self.bin_path_results = {'ohai': '/usr/bin/ohai'}

        def get_bin_path(self, executable):
            return self.bin_path_results.get(executable)

        def run_command(self, executable, *args, **kwargs):
            return self.FakeRun()

    module = FakeModule()
    result = OhaiFactCollector()
    output = result.get_ohai_output(module)
    assert output == '{"ohai": {"output": "ohai"}}'


# Generated at 2022-06-20 18:32:19.234664
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts
    ansible_facts = ansible.module_utils.facts.Facts(["ohai"])
    facts = ansible_facts.get_facts()

    ohai_facts = facts['ohai']
    assert isinstance(ohai_facts, dict)
    assert 'os' in ohai_facts

# Generated at 2022-06-20 18:32:22.820957
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    module = AnsibleModule(
        argument_spec = dict()
    )

    ofc = OhaiFactCollector()

    assert ofc.find_ohai(module) != None


# Generated at 2022-06-20 18:32:28.011355
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():

    class MockModule(object):
        def get_bin_path(self, path):
            if path == 'ohai':
                return '/usr/bin/ohai'
            return None

    module = MockModule()

    ohai_facts = OhaiFactCollector()
    assert ohai_facts.find_ohai(module) == '/usr/bin/ohai'


# Generated at 2022-06-20 18:32:40.008274
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Test with valid ohai
    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts import ansible_local

    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector._find_ohai = lambda module: '/usr/bin/ohai'

    def mock_run_ohai(module, ohai_path):
        return 0, '{"foo":"bar"}', ''

    ohai_fact_collector._run_ohai = mock_run_ohai
    ohai_output = ohai_fact_collector.get_ohai_output(ansible_local)

    assert json.loads(ohai_output)["foo"] == "bar"

    # Test with non-existing ohai
    ohai_fact_

# Generated at 2022-06-20 18:32:42.249302
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    c = OhaiFactCollector()
    ohai_output = c.get_ohai_output()
    assert ohai_output is not None
    assert ohai_output[0] == '{'

# Generated at 2022-06-20 18:32:43.851352
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.find_ohai()


# Generated at 2022-06-20 18:32:56.397127
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.ansible_local.ohai.test.fact_collector_ohai_output_fixture as fixture_module

    collector = OhaiFactCollector()
    output = collector.get_ohai_output(fixture_module)

    assert output == '{\n  "a_plugin": "Gathering data from a_plugin", \n  "a_plugin_1": "Gathering data from a_plugin_1", \n  "a_plugin_2": "Gathering data from a_plugin_2"\n}\n'


# Generated at 2022-06-20 18:33:08.398706
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # Initialize OhaiFactCollector instance
    collectors = None
    namespace = None
    ohaiFactCollector = OhaiFactCollector(collectors, namespace)

    # Mock AnsibleModule instance
    class AnsibleModuleMock:

        def get_bin_path(self, ohai):
            # Mock get_bin_path
            return "/usr/bin/ohai"

        def run_command(self, ohai_path):
            return 0, json.dumps({"test": "ohai"}), ""

    ansibleModuleMock = AnsibleModuleMock()

    # Call method
    rc, out, err = ohaiFactCollector.run_ohai(ansibleModuleMock, ohai_path="/usr/bin/ohai")
    assert rc == 0

# Generated at 2022-06-20 18:33:20.331923
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module = AnsibleModule()

# Generated at 2022-06-20 18:33:27.431061
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Setup
    collected_facts = dict(is_a_test=True)
    class MockModule:
        def get_bin_path(self, command):
            self.command_called_with = command
            return '/usr/bin/ohai'
        def run_command(self, command_arg, expand_user_and_vars=False):
            self.command_called_with = command_arg
            return (0, '{}', '')
    m = MockModule()
    # Call target method
    ofc = OhaiFactCollector()
    res = ofc.collect(module=m, collected_facts=collected_facts)
    # Check results
    assert res == {"ohai_is_a_test": True}

# Generated at 2022-06-20 18:33:29.970352
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact = OhaiFactCollector()
    assert ohai_fact.collect() == {}
    assert ohai_fact.name == 'ohai'

# Generated at 2022-06-20 18:33:34.304955
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    fake_module = DummyAnsibleModule()
    ohai_facts = OhaiFactCollector(collectors=None, namespace=None)
    ohai_facts.get_ohai_output(fake_module)



# Generated at 2022-06-20 18:33:45.376824
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    def mock_get_bin_path(name, opts=None):
        ohai_path = '/bin/ohai'
        if name == 'ohai':
            return ohai_path

        return None

    def mock_run_command(path, check_rc=True):
        rc = 0
        stdout = 'stdout from ohai'
        stderr = 'stderr from ohai'
        if path == ohai_path:
            return (rc, stdout, stderr)

        return (rc, '', '')

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opts=None):
            return mock_get_bin_path(name, opts)


# Generated at 2022-06-20 18:33:56.169210
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    class MockModule():
        def __init__(self, ohai_path):
            self.called_commands = []
            self.ohai_path = ohai_path
            pass
        def get_bin_path(self, program):
            return self.ohai_path
        def run_command(self, command_args):
            self.called_commands.append(command_args)
            return 0, json.dumps({'foo': 'bar'}), ''

    # When ohai is found, collect returns ohai data
    module = MockModule('/path/to/ohai')
    ohai_fact_collector = OhaiFactCollector()
    ohai_facts = ohai_fact_collector.collect(module)
    assert(ohai_facts['foo'] == 'bar')

    # When ohai

# Generated at 2022-06-20 18:34:07.867354
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.facts.collector.ohai

    ohai_path = 'ohai'
    input_ohai_out = {
        'ipaddress': '10.0.0.1',
        'macaddress': '52:54:00:f3:73:ce'
    }
    out = StringIO()
    out.write(json.dumps(input_ohai_out))
    out.seek(0)

    ohai_mod = ansible.module_utils.facts.collector.ohai
    o = ohai_mod.OhaiFactCollector()
    m = MockModule(out, None)
    o.run_ohai(m, ohai_path)
    assert m.rc == 0
    assert m.out

# Generated at 2022-06-20 18:34:17.594044
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.ohai import OhaiFactCollector

    OhaiFactCollector.run_ohai = lambda x,y,z: (0, '{"ohai":"test"}', '')
    OhaiFactCollector.find_ohai = lambda x: 1

    ohai_collector = OhaiFactCollector()
    facts_collector = FactsCollector(collectors=[ohai_collector])
    facts = facts_collector.collect()

    assert facts['ohai']['ohai'] == 'test'

# Generated at 2022-06-20 18:34:35.605287
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class OhaiFactCollector(BaseFactCollector):
        def find_ohai(self, module):
            return True

    ohai_fact_collector = OhaiFactCollector()
    class Module(object):
        def get_bin_path(self, program):
            return program

        def run_command(self, ohai_path):
            return (0, '{"foo": "bar"}', '')

    module = Module()
    ohai_output = ohai_fact_collector.get_ohai_output(module)
    assert ohai_output == '{"foo": "bar"}'

    module = Module()
    module.get_bin_path = lambda program: None
    ohai_output = ohai_fact_collector.get_ohai_output(module)
    assert ohai_output is None



# Generated at 2022-06-20 18:34:42.491225
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    def get_bin_path(self, executable):
        return '/usr/local/bin/ohai'

    def run_command(self, executable):
        rc = 0
        out = "{}"
        err = ""
        return rc, out, err

    ModuleFacts.get_bin_path = get_bin_path
    ModuleFacts.run_command = run_command

    module = ModuleFacts()
    obj = OhaiFactCollector()
    result = obj.get_ohai_output(module)

    assert(result)
    assert(isinstance(result, str))
    assert('{}' == result)

# Generated at 2022-06-20 18:34:43.800812
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector(namespace='ohai')
    assert isinstance(ohai_fact_collector, BaseFactCollector)

# Generated at 2022-06-20 18:34:54.908153
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.ohai.collector import OhaiFactCollector
    from ansible.module_utils.facts.utils import ModuleDepFailedImplementation
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import builtins

    test_module = 'ansible.module_utils.facts.ohai.collector'
    test_method_name = 'test_OhaiFactCollector_get_ohai_output'

    def temp_module():
        changed = False
        setattr(builtins, 'open', original_open)

        facts = OhaiFactCollector().collect(test_module, {})

        assert len(facts) == 2

# Generated at 2022-06-20 18:34:58.469406
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_collector = OhaiFactCollector()
    assert ohai_collector.name == 'ohai'
    assert ohai_collector._fact_ids == set()
    assert ohai_collector.namespace.namespace_name == 'ohai'

# Generated at 2022-06-20 18:35:00.450780
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    # Constructor test
    o = OhaiFactCollector()
    assert o.name == 'ohai'
    assert o._collectors == []
    assert o._fact_ids == set()

# Generated at 2022-06-20 18:35:12.868206
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.ohai

    # To replace ansible.module_utils.facts.collector.run_command
    import ansible.module_utils.facts.collector
    import unittest
    import mock

    class TestCommandCall(unittest.TestCase):
        def run_call(self, ohai_path):
            self.ohai_path = ohai_path
            return 0, '{\n"moo": "cow"\n}', ''

        def run_fail_path_not_found(self, ohai_path):
            self.ohai_path = ohai_path
            return 1, '', ''


# Generated at 2022-06-20 18:35:13.847044
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    pass

# Generated at 2022-06-20 18:35:18.257782
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert(ohai_fact_collector.name == 'ohai')
    assert(ohai_fact_collector._fact_ids is not None)


# Generated at 2022-06-20 18:35:23.760719
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''
    Test if OhaiFactCollector.run_ohai() method returns the expected result.
    '''

    class Module:

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/ohai'

        def run_command(self, cmd, check_rc=True):
            return 0, '{}', ''

    collector = OhaiFactCollector()
    module = Module()
    rc, out, err = collector.run_ohai(module, '/bin/ohai')
    assert rc == 0
    assert out == '{}'
    assert err == ''


# Generated at 2022-06-20 18:35:53.514503
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import get_module_facts
    import os

    def run_ohai(module, ohai_path,):
        return 0, '{"testkey": "testvalue"}', ''

    def find_ohai(module,):
        return os.path.join(os.path.dirname(__file__), '..', '..', 'utils', 'test_ohai.sh')

    # test for success method run_ohai
    module = ModuleForTesting()
    ohai_obj = OhaiFactCollector()
    ohai_obj.find_ohai = find_ohai
    ohai_obj.run_ohai = run_ohai
    ohai_output = ohai_obj.get_ohai_output(module)
    assert ohai_output is not None

# Generated at 2022-06-20 18:35:57.506169
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ''' Returns an object of OhaiFactCollector '''
    f = OhaiFactCollector(namespace='foo')
    assert isinstance(f, OhaiFactCollector)

# Generated at 2022-06-20 18:36:05.938625
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # The method must return path to ohai.
    # In this test we don't have ohai installed, so path to ohai should be None.
    # It's important to know that method get_bin_path from AnsibleModule
    # is mocked (see below).
    from ansible.module_utils.facts import ansible_module_mock
    from ansible.module_utils.facts.collector import AnsibleModuleMock
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = ansible_module_mock.AnsibleModuleMock()
    collector = BaseFactCollector()
    ohai_path = collector.find_ohai(module)
    assert ohai_path is None

    # Mock method get_bin_path.
    # When it's called with parameter 'ohai', then it

# Generated at 2022-06-20 18:36:07.422022
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    pass


# Generated at 2022-06-20 18:36:09.323950
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert o.name == 'ohai'


# Generated at 2022-06-20 18:36:17.435795
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import ansible.module_utils.facts.collector
    #module = True
    #ohai_output = True
    #ohai_facts = True
    ohaiFc = OhaiFactCollector()
    ohaiFc.get_ohai_output = lambda module:ohai_output
    ohaiFc.run_ohai = lambda module,ohai_path: (0,ohai_output,None)
    ohaiFc.find_ohai = lambda module:True
    ansible.module_utils.facts.collector.module_cache[__name__] = module
    if ohaiFc.collect():
        assert ohai_facts == ohaiFc.collect()

# Generated at 2022-06-20 18:36:18.204678
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    pass


# Generated at 2022-06-20 18:36:30.579725
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import update_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines_with_prefix
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import search_file_for_string
    from ansible.module_utils.facts.utils import get_file_checksum

# Generated at 2022-06-20 18:36:41.955695
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    # we need to set up a fake module and test against that
    class FakeModule(object):
        def __init__(self):
            self.ohai_path = None

        def get_bin_path(self, name):
            return self.ohai_path

    def test_path(ohai_path, expected_return):
        fake_module = FakeModule()
        fake_module.ohai_path = ohai_path

        ohai_finder = OhaiFactCollector()
        eq_(ohai_finder.find_ohai(fake_module), expected_return)

    # test some common values for ohai
    yield test_path, '/sbin/ohai', '/sbin/ohai'
    yield test_path, '/usr/sbin/ohai', '/usr/sbin/ohai'
    yield test_

# Generated at 2022-06-20 18:36:48.551134
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    """Function to test find_ohai function of class OhaiFactCollector """
    from ansible.module_utils.facts.utils import ModuleUtils
    test_module_utils = ModuleUtils({"module_utils": "ansible.module_utils.facts.utils"})
    ohai_path = OhaiFactCollector.find_ohai(test_module_utils)
    assert ohai_path


# Generated at 2022-06-20 18:37:33.908127
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import sys
    import os

    # Creating an empty AnsibleModule object
    from ansible.module_utils.facts.ohai.ohai import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    # Creating a mock class for our module
    from collections import namedtuple

    MockClass = namedtuple('MockClass', ['name', 'version'])

    mock_class = MockClass('test', '1.0')

    # Create a MockModule class to return our mock class
    class MockModule:
        pass
    mock_module = MockModule()
    mock_module.params = dict()
    mock_module.params['name'] = 'test'
    mock_module.params['version'] = '1.0'

    # Adding the mock class to our module

# Generated at 2022-06-20 18:37:44.268266
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts import ansible_facts
    import sys

    # Simulate collection of facts
    ansible_facts.get_facts(force=True)

    # Get an instance of OhaiFactCollector
    facts_collector = OhaiFactCollector()

    # Get a mock module
    if sys.version_info < (3, ):
        try:
            from mock import MagicMock
        except ImportError:
            from unittest.mock import MagicMock
    else:
        from unittest.mock import MagicMock

    module = MagicMock()

    # Bind module.get_bin_path return value to ohai_path
    module.get_bin_path.return_value = '/opt/chef/bin/ohai'

    # Get ohai path from module
    ohai

# Generated at 2022-06-20 18:37:47.308382
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = AnsibleModule(argument_spec=dict())
    ohai_output = OhaiFactCollector().get_ohai_output(module)
    assert type(ohai_output) == type("")


# Generated at 2022-06-20 18:37:49.323290
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_facts = OhaiFactCollector()
    assert ohai_facts.name == 'ohai'

# Generated at 2022-06-20 18:37:59.320838
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai = OhaiFactCollector(collectors=None, namespace=None)
    facts = {'foo': 'bar', 'baz': 'qux'}
    ohai_out = json.dumps(facts)
    # ohai_out must be bytes not unicode
    ohai_out = bytes(ohai_out, 'UTF-8')
    # Mock commands run by OhaiFactCollector.run_ohai
    module.run_command.side_effect = [
        (0, ohai_out, ''),
        (0, ohai_out, '')
    ]
    # Mock command run by OhaiFactCollector.find_ohai
    module.get_bin_path.side_effect = ('/usr/bin/ohai',)

    ohai_facts = ohai

# Generated at 2022-06-20 18:38:01.703514
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    test_collector = OhaiFactCollector()
    assert test_collector.find_ohai(None) is None

# Generated at 2022-06-20 18:38:06.592337
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector

    temp_collector = ansible.module_utils.facts.collector.OhaiFactCollector()
    temp_collector.get_bin_path = lambda x: 'test/path'
    assert temp_collector.find_ohai('test') == 'test/path'

# Generated at 2022-06-20 18:38:12.564640
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # Setup test, create object to test, and test pre-conditions
    test_obj = OhaiFactCollector()
    ohai_path = test_obj.find_ohai(None)
    assert not ohai_path
    rc, out, err = test_obj.run_ohai('','test')
    assert rc == 256
    assert out == ''
    assert err == 'test: command not found\n'

# Generated at 2022-06-20 18:38:22.396011
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = AnsibleModuleMock()
    ohai = OhaiFactCollector()
    # The return value of get_ohai_output() is expected to be a string
    # containing JSON-formatted ohai data. Some of the ohai data is
    # added in the ohai_facts variable below.
    ohai_facts = {'os': 'linux', 'platform': 'centos'}
    module.run_command = run_command_mock
    ohai.run_ohai = run_ohai_mock
    ohai.find_ohai = find_ohai_mock
    # The expected ohai-output is a stringified version of ohai_facts
    expected_ohai_output = json.dumps(ohai_facts)
    ohai_output = ohai.get_ohai_output(module)

# Generated at 2022-06-20 18:38:30.153885
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.six import PY3

    if PY3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    ohai_path = '/ohai_path/ohai'
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = ohai_path

    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.module = mock_module
    ohai_fact_collector.collector = ModuleCollector(module=mock_module)

    assert ohai_fact_collector.find_ohai(mock_module) == ohai_path



# Generated at 2022-06-20 18:40:06.286967
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    class FakeModule(object):
        def __init__(self, return_value):
            self.return_value = return_value
            self.fake_output = None
            self.fake_err = None
            self.fake_rc = 0

        def get_bin_path(self, executable):
            return self.return_value

        def run_command(self, executable):
            return self.fake_rc, self.fake_output, self.fake_err

    class FakeCollectors(object):
        pass

    fake_output = """{'platform': 'fake', 'platform_version': '1.0.0'}"""
    module = FakeModule('/bin/ohai')
    module.fake_output = fake_output

# Generated at 2022-06-20 18:40:10.368746
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    module = None
    ohai_output = OhaiFactCollector().get_ohai_output(module)
    assert ohai_output is None

test_OhaiFactCollector_get_ohai_output()

# Generated at 2022-06-20 18:40:19.958292
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import OhaiFactCollector
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/bin/ohai'

        def run_command(self, *args, **kwargs):
            return 0, 'success', ''

    fake_module = FakeModule()

    bfc = BaseFactCollector(None, None)
    ohai = OhaiFactCollector(None, None)

# Generated at 2022-06-20 18:40:26.570339
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    import ansible.module_utils.facts.ohai as ohai
    m_module = MagicMock()
    m_get_bin_path = m_module.get_bin_path
    m_get_bin_path.return_value = '/bin/ohai'

    m_run_command = m_module.run_command
    m_run_command.return_value = (0, '{ "test_key": "test_value" }', '')

    m_OhaiFactCollector = ohai.OhaiFactCollector()

    assert m_OhaiFactCollector.get_ohai_output(m_module) == '{ "test_key": "test_value" }'
    m_get_bin_path.assert_called_with('ohai')
    m_run_command.assert_called_with