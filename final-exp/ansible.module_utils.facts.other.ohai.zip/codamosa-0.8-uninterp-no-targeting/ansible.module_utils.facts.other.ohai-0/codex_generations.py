

# Generated at 2022-06-20 18:30:34.054291
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.utils import FactsModule
    import mock
    import json

    module = FactsModule()
    ohai_fact_collector = OhaiFactCollector(module=module)
    with mock.patch.object(builtins, 'open', mock.mock_open(read_data=json.dumps({}))):
        ohai_output = ohai_fact_collector.get_ohai_output(module)
    assert ohai_output is not None


# Generated at 2022-06-20 18:30:43.578657
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.system.ohai import OhaiFactCollector
    from ansible.module_utils.facts.test_utils.test_collector import BaseAnsibleCollectorTest
    from ansible.module_utils._text import to_bytes
    import contextlib

    class TestCollector(BaseAnsibleCollectorTest):
        def _mocked_module(self):
            # FIXME: Should be able to simply call
            #        super(TestCollector, self)._mocked_module()
            #        and then adjust the module object.  Should
            #        fix this in a separate commit though.
            module = super(BaseAnsibleCollectorTest, self)._mocked_module()


# Generated at 2022-06-20 18:30:47.675727
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    collector = OhaiFactCollector()
    assert collector is not None, 'Failed to instantiate OhaiFactCollector()'

if __name__ == '__main__':
    test_OhaiFactCollector()

# Generated at 2022-06-20 18:30:54.980474
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    ohai_collector = OhaiFactCollector()

    assert isinstance(ohai_collector, BaseFactCollector)
    assert ohai_collector.name == 'ohai'
    assert ohai_collector.namespace.namespace_name == 'ohai'
    assert ohai_collector.namespace.prefix == 'ohai_'

# Generated at 2022-06-20 18:31:00.346804
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
	mockModule = MockModule()
	mockModule.run_command = Mock(return_value=(0, '{"platform": "linux"}', ''))
	collector = OhaiFactCollector()
	rc, out, err = collector.run_ohai(mockModule, 'ohai')
	assert rc == 0
	assert out == '{"platform": "linux"}'
	assert err == ''

# Generated at 2022-06-20 18:31:13.191201
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import DictModule
    from ansible.module_utils.facts.collector import ModuleDepFactsCollector

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    module.run_command = lambda x: (0, to_bytes(StringIO(json.dumps({'test_key': 'test_value', 'test_key_int': 1})).getvalue()), '')
    o = OhaiFactCollector([], module)
    o

# Generated at 2022-06-20 18:31:26.139199
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    class Mock_Module():
        class Mock_Run():
            stdout = '{'
        def __init__(self):
            self.run_command = self.Mock_Run()
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/ohai'
    class Mock_OhaiFactCollector():
        def __init__(self):
            self.ohai_facts = {}
        def find_ohai(self, *args, **kwargs):
            return '/usr/bin/ohai'
    mock_module = Mock_Module()
    mock_ohai_facts = Mock_OhaiFactCollector()
    rc, out, err = mock_ohai_facts.run_ohai(mock_module, '/usr/bin/ohai')
    assert rc == 0


# Generated at 2022-06-20 18:31:36.916486
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    collector = OhaiFactCollector()

    # Case: no ohai is on the path
    module.run_command = Mock(return_value=(0, '', ''))
    rc, out, err = collector.run_ohai(module, '/not/there')
    assert rc == 0
    assert out == ''
    assert err == ''

    # Case: ohai is successfully invoked
    module.run_command = Mock(return_value=(0, '{"ohai": "facts"}', ''))
    rc, out, err = collector.run_ohai(module, 'path/to/ohai')
    assert rc == 0
    assert out == '{"ohai": "facts"}'
    assert err == ''

   

# Generated at 2022-06-20 18:31:47.134629
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts import AnsibleModule
    import os

    # set up
    m = AnsibleModule(name='test')
    o = OhaiFactCollector()

    # tests
    assert o.get_ohai_output(m)

    # override mocked ohai_path with invalid path and check that None is returned
    old_ohai_path = o.find_ohai
    o.find_ohai = lambda x: os.path.join('wrong_path', 'ohai')
    assert o.get_ohai_output(m) is None

    # override mocked rc and check that None is returned
    old_run_ohai = o.run_ohai
    o.run_ohai = lambda x, y: (1, '', '')

# Generated at 2022-06-20 18:31:52.512635
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = FakeModule()
    o = OhaiFactCollector()
    ansible_facts = {}
    o.collect(module=module, collected_facts=ansible_facts)
    assert ansible_facts['ansible_local']['ohai'] == {'ipaddress': '127.0.0.1'}


# Generated at 2022-06-20 18:31:59.361381
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohfc = OhaiFactCollector()
    assert ohfc.name == 'ohai', 'Unexpected ohai name'
    assert not ohfc.collectors, 'Unexpected collectors'

# Generated at 2022-06-20 18:32:02.883716
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    o = OhaiFactCollector()
    assert isinstance(o, OhaiFactCollector)
    assert o.name == 'ohai'


# Generated at 2022-06-20 18:32:05.616497
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'

# Generated at 2022-06-20 18:32:15.546743
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    ''' Test for method get_ohai_output of class OhaiFactCollector'''

# Generated at 2022-06-20 18:32:24.880154
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import sys
    import tempfile
    from ansible.module_utils.facts.collector import get_collector_instance

    fd, name = tempfile.mkstemp(suffix='.py')

# Generated at 2022-06-20 18:32:36.824062
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():

    def _load_ohai_path(module, *args, **kwargs):
        return '/usr/bin/ohai'

    def _run_command(*args, **kwargs):
        return (0, '{"test": true}', '')

    module = Mock()
    module.run_command = _run_command
    module.get_bin_path = _load_ohai_path

    ohai_fact_collector = OhaiFactCollector()
    ohai_fact_collector.run_ohai(module, '/usr/bin/ohai')
    assert ohai_fact_collector.get_ohai_output(module) == '{"test": true}'

    def _run_command_fail(*args, **kwargs):
        return (1, '', 'failed')

    module.run_command = _

# Generated at 2022-06-20 18:32:45.659398
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    class Module(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def get_bin_path(self, binary_name, **kwargs):
            if binary_name == 'ohai':
                return '/usr/bin/ohai'
            else:
                return None
        def run_command(self, binary_path, **kwargs):
            if binary_path == '/usr/bin/ohai':
                return 0, '{"foo": [1,2,3], "bar": "baz"}', ''
            else:
                return None
    module = Module()
    ohai_output = OhaiFactCollector().get_ohai_output(module)
    assert ohai_output == '{"foo": [1,2,3], "bar": "baz"}'

   

# Generated at 2022-06-20 18:32:57.789767
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import OhaiFactCollector
    from ansible.module_utils._text import to_bytes

    # Mock the base collector to create a new collector that can run
    # on a system without ohai.
    def find_ohai(module):
        return None

    collector = BaseFactCollector()
    test_collector = OhaiFactCollector([collector])
    test_collector.find_ohai = find_ohai

    # The fake module class has a run_command method that simulates
    # the ohai output
    class FakeModule:
        def __init__(self):
            self.rc = 0
            self.ohai_output = b'{ "1": "2" }'


# Generated at 2022-06-20 18:33:04.641692
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module = FakeModule()
    collector = OhaiFactCollector()
    ohai_path = '/usr/bin/ohai'
    module_out = '{"test": "out"}'

    module.run_command = FakeRunCommand(0, module_out)

    rc, out, err = collector.run_ohai(module, ohai_path)

    assert rc == 0
    assert out == module_out
    assert err is None


# Generated at 2022-06-20 18:33:07.352466
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    try:
        assert(isinstance(OhaiFactCollector(), OhaiFactCollector))
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-20 18:33:17.992106
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    module=MockModule()
    ohai_path='/usr/local/bin/ohai'
    ohi=OhaiFactCollector()
    rc, out, err = ohi.run_ohai(module, ohai_path)
    assert rc == 0
    assert type(out) == str


# Generated at 2022-06-20 18:33:26.847178
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():

    # fake module class and instance
    class FakeModule:
        def __init__(self):
            self.bin_path_cache = {}

        def get_bin_path(self, exe_name, opt_dirs=None):
            return self.bin_path_cache[exe_name]

        def run_command(self, exe_path, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
            return 0, '{"ohai": "output"}', ''

    fake_module = FakeModule()

    ohai_fact_collector = OhaiFactCollector()

    # if no ohai command is found, collect returns ohai_facts dict to be empty

# Generated at 2022-06-20 18:33:30.055283
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():

    # Test default constructor
    collector = OhaiFactCollector()
    assert collector.name == 'ohai'
    assert collector._fact_ids == set()
    assert type(collector._namespace) == PrefixFactNamespace

# Generated at 2022-06-20 18:33:42.287847
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.nested
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.cloud
    import ansible.module_utils.facts.collector.ohai
    import ansible.module_utils.facts.data

    m = ansible.module_utils.facts.collector.OhaiFactCollector()
    m.find_ohai(m)
   

# Generated at 2022-06-20 18:33:49.884929
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    import os
    import ansible.module_utils.facts.collector as base_collector
    import ansible.module_utils.facts.namespace as base_namespace
    import ansible.module_utils.facts.utils as base_utils
    import ansible.module_utils.facts.collectors.ohai as ohai_collector
    import ansible.module_utils.facts.collectors.system as system_collector
    import ansible.module_utils.facts.collectors.pkg_mgr as pkg_mgr_collector

    os.environ['ANSIBLE_COLLECTORS'] = "system,pkg_mgr,ohai"
    collectors_list = base_collector.get_collectors_list()


# Generated at 2022-06-20 18:33:52.107912
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    # Tests for this method are implemented in unit/module_utils/facts/ohai/test_ohai.py
    pass

# Generated at 2022-06-20 18:33:57.193467
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    class DummyModule(object):
        def get_bin_path(self, path):
            return 'ohai_path'

        def run_command(self, ohai_path):
            return 0, "ohai_output", ""

    ohai_collector = OhaiFactCollector()
    ohai_output = ohai_collector.get_ohai_output(DummyModule())

    assert ohai_output == "ohai_output"


# Generated at 2022-06-20 18:34:03.534993
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = MockModule()
    ohai_collector = OhaiFactCollector()
    result = ohai_collector.collect(module)

    assert len(result) == 3
    assert result['os'] == 'linux'
    assert result['platform'] == 'ubuntu'
    assert result['platform_version'] == '14.04'


# Generated at 2022-06-20 18:34:09.401464
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    #FIXME: test is inaccurate, we should be testing in an environemnt where
    #       ohai is not installed
    from ansible.module_utils.facts.collector import AnsibleModule

    module = AnsibleModule(
        argument_spec={}
    )

    ohai_collecter = OhaiFactCollector()
    ohai_output = ohai_collecter.get_ohai_output(module)

    assert not ohai_output


# Generated at 2022-06-20 18:34:19.586692
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.ohai import OhaiFactCollector

    facts = {'ohai_data': None}

    # fixtures is a subdirectory of tests/units/module_utils.
    fixture_file = 'fixtures/facts/ohai_facts.txt'
    fixture_file_content = get_file_content(fixture_file)
    fact_collector = get_collector_instance(OhaiFactCollector)
    fact_collector.get_ohai_output = lambda module: fixture_file_content

# Generated at 2022-06-20 18:34:30.872385
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module = None
    collected_facts = None
    ofc = OhaiFactCollector()
    facts = ofc.collect(module, collected_facts)
    assert facts != {}

# Generated at 2022-06-20 18:34:36.652031
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    '''Test run_ohai method of class OhaiFactCollector'''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    ohai = OhaiFactCollector()

    ohai_path = ohai.find_ohai(module)
    assert ohai_path is not None

    rc, out, err = ohai.run_ohai(module, ohai_path)
    assert rc == 0
    assert err == b''
    assert out != b''
    # return value of run_ohai is json
    json.loads(to_bytes(out))

# Generated at 2022-06-20 18:34:47.086570
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # TODO: create a mock for AnsibleModule for the sake of this unit test.
    #       See current workaround in the method below.
    pass


if __name__ == '__main__':
    import sys
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args: sys.executable

    ohai = OhaiFactCollector()
    ansible_facts = ohai.collect(module=module)

    module.exit_json(ansible_facts=ansible_facts)

# Generated at 2022-06-20 18:34:51.455403
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    mock_module = MockAnsibleModule()
    fact_collector = OhaiFactCollector()
    fact_collector.find_ohai(mock_module)
    mock_module.get_bin_path.assert_called_with('ohai')


# Generated at 2022-06-20 18:35:00.960744
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    """ Unit test for method get_ohai_output of class OhaiFactCollector """
    import tempfile

    def get_bin_path(binary, required=True):
        return "/tmp/ohai"

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, "test output", "test errors")

    class FakeModule(object):
        def get_bin_path(self, binary, required=False):
            return get_bin_path(binary, required)


# Generated at 2022-06-20 18:35:04.805475
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ohai_fact_collector = OhaiFactCollector()
    assert ohai_fact_collector.name == 'ohai'


# Generated at 2022-06-20 18:35:15.058881
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    # Without module argument
    ohai_facts = OhaiFactCollector()
    assert {} == ohai_facts.collect()

    # With a module, but mocked Ohai not found
    ohai_facts = OhaiFactCollector()
    from ansible.module_utils.facts import ansible_module
    module = ansible_module()
    module.params = {}
    module.get_bin_path = lambda x: None
    assert {} == ohai_facts.collect(module)

    # With a module, mocked Ohai found, but json.loads() fails
    ohai_facts = OhaiFactCollector()
    from ansible.module_utils.facts import ansible_module
    module = ansible_module()
    module.params = {}

# Generated at 2022-06-20 18:35:18.439161
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    c = OhaiFactCollector()
    assert c.name == "ohai"
    assert isinstance(c._fact_ids, set)

# Generated at 2022-06-20 18:35:19.110372
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    pass

# Generated at 2022-06-20 18:35:27.284906
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    # Unit test for get_ohai_output where ohai is installed
    def test_ohai_installed(self):

        # Ohai exists
        self.find_ohai = Mock(return_value='/usr/bin/ohai')

        # Ohai is executed successfully
        self.run_ohai = Mock(return_value=(0, '{}', ''))
        ohai_output = self.get_ohai_output(Mock())
        self.assertEqual(ohai_output, '{}')

        # Ohai is executed unsuccessfully
        self.run_ohai = Mock(return_value=(1, '', 'Error'))
        ohai_output = self.get_ohai_output(Mock())
        self.assertEqual(ohai_output, None)


    # Unit test for get_oh

# Generated at 2022-06-20 18:35:53.181746
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    m_module = Mock(params={})
    m_module.get_bin_path.return_value = '/usr/bin/ohai'

    # ohai returns non-zero exit status
    m_module.run_command.return_value = (1, '', '')
    ohai_collector = OhaiFactCollector()
    result = ohai_collector.get_ohai_output(m_module)
    assert result is None

    # ohai returns zero exit status, but non-json output
    m_module.run_command.return_value = (0, 'oh-hai', '')
    ohai_collector = OhaiFactCollector()
    result = ohai_collector.get_ohai_output(m_module)
    assert result is None

    # ohai returns zero exit status, and json

# Generated at 2022-06-20 18:35:58.319046
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ohaiFactCollector = OhaiFactCollector()
    ohai_path = ohaiFactCollector.find_ohai("")
    # ohai_path should be None if ohai is not available in $PATH
    assert ohai_path is None


# Generated at 2022-06-20 18:36:06.562143
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    class MyModule:
        def __init__(self):
            self.path = 'path-to-ohai'
            self.params = {'path': 'path-from-params'}

        def get_bin_path(self, name, opt_dirs=[]):
            return self.path

    module = MyModule()
    ohai_collector = OhaiFactCollector()

    assert ohai_collector.find_ohai(module) == 'path-to-ohai'

    del module.path
    assert ohai_collector.find_ohai(module) == 'path-from-params/bin/ohai'

    module.params['path'] = '/path-from-params'
    assert ohai_collector.find_ohai(module) == '/path-from-params/ohai'

#

# Generated at 2022-06-20 18:36:16.467794
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    tfc = OhaiFactCollector()
    # Create a mock module object with attributes that would be set by AnsibleModule

# Generated at 2022-06-20 18:36:23.438124
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():

    from ansible.module_utils.facts.ohai import OhaiFactCollector
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils._text import to_bytes

    # Generate mock module and test object
    module = ansible_module()
    mock_ohai_output = b'{"mock_ohai_output":true}'

    # Mock module.run_command
    def run_command(self, arg1, check_rc=True):

        # Mock exit_json
        self.exit_json = lambda self, **kwargs: None

        # Mock params.get
        self.params = {'get': lambda self, arg1: '/bin/ohai'}

        return 0, mock_ohai_output, ''

    module.run_command = run_command.__get

# Generated at 2022-06-20 18:36:25.317927
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    co = OhaiFactCollector()
    assert co.name == 'ohai'
    assert not co._fact_ids

# Generated at 2022-06-20 18:36:36.779570
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    # This test needs to be run in unit/module_utils/facts/collectors/
    # directory.
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    import ansible.module_utils.basic

    win = False
    if ansible.module_utils.basic.ANSIBLE_VERSION < '2.4':
        # Ohai is not supported on Windows for Ansible version < 2.4
        win = ansible.module_utils.facts.collector.base.is_platform('windows')


# Generated at 2022-06-20 18:36:46.113576
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    module_mock = mock.Mock()
    ohai_path = 'ohai_bin_path'

# Generated at 2022-06-20 18:36:55.294763
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    ohai_collector = get_collector_instance('ohai')
    from ansible.module_utils._text import to_text
    import ansible.module_utils.facts.system.ohai
    out = ansible.module_utils.facts.system.ohai.get_file_content(filename='output.json')
    out = to_text(out)
    import mock
    with mock.patch.object(ohai_collector, 'get_ohai_output', return_value=out):
        result = ohai_collector.get_ohai_output(mock.Mock())
        assert result

# Generated at 2022-06-20 18:37:05.897440
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    import sys
    import tempfile
    import time
    import json
    from ansible.module_utils.facts.utils import FactsFilesLocator

    class MockModule:
        def __init__(self):
            self.exit_json = self.exit_json
            self.fail_json = self.fail_json
            self._ansible_version = '2.4.1.0'
            self.params = {}
            self.paths = ['/sbin/', '/usr/sbin/', '/bin/', '/usr/bin']
            self.bin_path = self.get_bin_path

# Generated at 2022-06-20 18:37:58.258723
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    fact_collector = OhaiFactCollector()
    assert fact_collector.find_ohai is not None
    assert fact_collector.find_ohai("") is None

# Generated at 2022-06-20 18:37:59.792475
# Unit test for constructor of class OhaiFactCollector
def test_OhaiFactCollector():
    ofc = OhaiFactCollector()
    assert ofc


# Generated at 2022-06-20 18:38:04.679543
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    """Test for method run_ohai of module ansible.module_utils.facts.system.ohai."""

    from ansible.module_utils.facts.system.ohai import OhaiFactCollector
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    ohai_facts = OhaiFactCollector()

    ohai_path = ohai_facts.find_ohai(module)

    if ohai_path:
        rc, out, err = ohai_facts.run_ohai(module, ohai_path)
        assert isinstance(rc, int)
        assert isinstance(err, str)
        assert isinstance(out, str)
    else:
        assert not ohai_path


# Generated at 2022-06-20 18:38:08.882055
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    ''' Unit test for method find_ohai of class OhaiFactCollector
    '''
    class Mod:
        def get_bin_path(self, str):
            return str

    m = Mod()
    c = OhaiFactCollector()
    assert c.find_ohai(m) == 'ohai'


# Generated at 2022-06-20 18:38:14.389295
# Unit test for method run_ohai of class OhaiFactCollector
def test_OhaiFactCollector_run_ohai():
    from ansible.module_utils.facts.collector import TestModule
    test = TestModule()
    if test.collector.find_ohai(test.module):
        test.collector.run_ohai(test.module, test.collector.find_ohai(test.module))

# Generated at 2022-06-20 18:38:26.199118
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    import ansible.module_utils.facts.ohai as ohai
    o = ohai.OhaiFactCollector()
    class m:
        def __init__(self, bin_path):
            self.bin = bin_path

        def get_bin_path(self, bin_name):
            if bin_name == 'ohai':
                return self.bin
    # no bin, no bin found
    res = o.find_ohai(m(''))
    assert res is None, 'No ohai binary specified, but the test still found it.'
    # test for successful case
    res = o.find_ohai(m('/bin/ohai'))
    assert res == '/bin/ohai', 'Ohai binary not found.'


# Generated at 2022-06-20 18:38:35.356231
# Unit test for method collect of class OhaiFactCollector
def test_OhaiFactCollector_collect():
    from ansible.module_utils import basic
    import ansible.constants as C
    import ansible.module_utils.facts.collector
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda x: x

    C.DEFAULT_MODULE_PATH = '/path/to/library'

    # We can't test this if we have ohai, so make sure it's not on the PATH
    for path in module.get_bin_path('', False, ['/bin', '/usr/bin']).split(':'):
        if module.ospath.exists(module.ospath.join(path, 'ohai')):
            raise RuntimeError("ohai exists on PATH")

    # If we don't have ohai, the OhaiFactCollector should return

# Generated at 2022-06-20 18:38:46.570199
# Unit test for method find_ohai of class OhaiFactCollector
def test_OhaiFactCollector_find_ohai():
    from ansible.module_utils.facts.collector.ohai import OhaiFactCollector
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts.ansible_module_mock import AnsibleModuleMock

    module = AnsibleModuleMock()

    test_obj = OhaiFactCollector()

    # Lets try with a module that returns no Ohai executable
    module.get_bin_path.return_value = None
    #print(test_obj.find_ohai(module))

    # Lets try with a module that returns some Ohai executable
    module.get_bin_path.return_value = "/tmp/test_ohai"
    #print(test_obj.find_ohai(module))



# Generated at 2022-06-20 18:38:57.378305
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    """checks if OhaiFactCollector.get_ohai_output returns the proper output value"""
    from ansible.module_utils.facts.collector import AnsibleModuleFake
    from ansible.module_utils.facts.collector import BaseFactCollector

    dict_ohai_output = {'ohai_ipaddress': '192.168.1.1'}

    fake_module = AnsibleModuleFake(
        dict(
            ohai = BaseFactCollector(),
        )
    )

    fake_module.run_command = lambda x: (0, json.dumps(dict_ohai_output), None)
    result = OhaiFactCollector().get_ohai_output(fake_module)
    assert result == json.dumps(dict_ohai_output)

# Generated at 2022-06-20 18:39:02.312579
# Unit test for method get_ohai_output of class OhaiFactCollector
def test_OhaiFactCollector_get_ohai_output():
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    fc = OhaiFactCollector()
    ohai_output = fc.get_ohai_output(m)

    facts = json.loads(ohai_output)
    assert 'platform_family' in facts
    assert 'platform' in facts
