

# Generated at 2022-06-23 11:49:29.612187
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader is not None
    assert lookup_plugin._templar is not None

# Generated at 2022-06-23 11:49:33.730353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = ['all']
    lu.inventory = {'group_names': ['ungrouped'], 'groups': {'ungrouped': {'hosts': ['localhost'], 'vars': {}}}}

    assert(lu.run(terms) == ['localhost'])

# Generated at 2022-06-23 11:49:36.211031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader is not None


# Generated at 2022-06-23 11:49:46.821369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    # get the path of current dir
    current_dir = os.path.dirname(__file__)

    # create a temporary copy of the fake inventory
    tmp = tempfile.NamedTemporaryFile(delete=False)
    original_file = open(os.path.join(current_dir, 'host_pattern_inventory'), 'r')
    tmp.write(original_file.read())
    original_file.close()

    # instantiate the object
    lookup = LookupModule()

    # run the test case
    terms = 'all'

# Generated at 2022-06-23 11:49:51.225294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    o_LookupModule = LookupModule()
    terms = {'all':'!www'}
    variables = {'groups': {'all': ['host1', 'host2'], 'www': ['host3', 'host4']}}
    result = o_LookupModule.run(terms, variables)
    assert result == ['host1', 'host2']

# Generated at 2022-06-23 11:49:54.016148
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This is a test function to test the LookupModule class
    """
    import ansible.plugins
    lookup_module = ansible.plugins.lookup.inventory_hostnames.LookupModule()
    lookup_module.run([])

# Generated at 2022-06-23 11:50:00.628030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        'localhost'
    ]
    variables = {
        'groups': {
            'web': [
                'localhost',
                'web1'
            ]
        }
    }

    hostnames = LookupModule().run(terms, variables)
    assert len(hostnames) == 1
    assert hostnames[0] == terms[0]


# Generated at 2022-06-23 11:50:02.338888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None



# Generated at 2022-06-23 11:50:09.955304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.plugins.loader import LookupModule
    fake_executive = FakeExecutive()
    fake_loader = FakeLoader()
    lookup_module = LookupModule(executive=fake_executive, loader=fake_loader)
    assert lookup_module
    test_data = {"hostvars": {}, "groups": {}}
    json_string = json.dumps(test_data)
    result = lookup_module.run('test_pattern', variables=json_string)
    assert result == []


# This class mimics the class ansible.plugin.PluginLoader
# with a small set of methods rewritten

# Generated at 2022-06-23 11:50:19.525528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(dir(LookupModule))

# Generated at 2022-06-23 11:50:25.496470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    i_m = InventoryManager(loader=None, parse=False)
    i_m.add_group("g1")
    i_m.add_host("h1", group="g1")
    i_m.add_host("h2", group="g1")
    i_m.add_host("h3", group="g1")

    i_m.add_group("g2")
    i_m.add_host("h4", group="g2")
    i_m.add_group("g3")
    i_m.add_host("h5", group="g3")
    i_m.add_host("h1", group="g3")


# Generated at 2022-06-23 11:50:34.297639
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    loader = "dummy"
    testobj = LookupModule(loader)

    # Test Case-1: One possible hostname pattern
    values = [ "all" ]
    groups = { "all": ["localhost"] }
    variables = {"groups": groups}
    assert testobj.run(terms=values, variables=variables) == ["localhost"]

    # Test Case-2: Two possible hostname patterns
    values = [ "all", "!all" ]
    groups = { "all": ["localhost"] }
    variables = {"groups": groups}
    assert testobj.run(terms=values, variables=variables) == ["localhost"]

    # Test Case-3: Hostname pattern matches all hosts
    values = [ "all" ]

# Generated at 2022-06-23 11:50:36.797931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(terms = ["all:!www"]) == []

# Generated at 2022-06-23 11:50:37.804984
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:50:40.678817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['all:!www']
    test_variables = {'groups': {'all': ['serverA', 'serverB']}}
    l = LookupModule()
    assert(l.run(test_terms, test_variables) == ['serverA', 'serverB'])

# Generated at 2022-06-23 11:50:48.649630
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.lookup import LookupBase
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    import ansible.constants

    ansible.constants.HOST_KEY_CHECKING = False
    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return []

    dummy_loader = DataLoader()
    dummy_inventory = InventoryManager(dummy_loader, sources='localhost,')
    dummy_inventory.add_group('group1')
    dummy_inventory.add_host(Host("host1"), group='group1')

# Generated at 2022-06-23 11:50:58.308599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # In this case, the used "method" is really a function.
    # The "_loader" attribute exists in the base class self.
    # The "parse" defaults to True.
    # The values in the dictionary that is used to overwrite the
    # mocked "add_groups" function, has no relevant impact at all.
    # So, I am not bothering with creating a proper mock of the
    # "InventoryManager" here.
    # The actual "get_hosts" is not mocked because I don't need it
    # to be.
    manager = InventoryManager(
        lookup._loader,
        parse=False,
        groups={
            'group1': ['host1', 'host2'],
            'group2': ['host1', 'host3'],
        }
    )
    manager.add_

# Generated at 2022-06-23 11:51:08.445731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys
    import os

    class LookupModuleTest(unittest.TestCase):
        """
        Define a unit test class with a method which can run a test case.
        """

        def test_run(self):
            """
            Define a unit test case.
            """

            # Build a lookup plugin to pass as `self` to run.
            self.plugin_dir = None
            self.plugin_dir = os.path.dirname(sys.modules[LookupModule.__module__].__file__)
            self._loader = None
            self._templar = None

            # Set test inputs and expected outputs.
            test_args = ['hostname_pattern']

# Generated at 2022-06-23 11:51:09.001118
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:51:09.999414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 11:51:21.423106
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys;sys.path.insert(0, '../../')
    import json
    import ansible.module_utils.basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    import ansible.constants as C


# Generated at 2022-06-23 11:51:24.626757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'my_host'
    variables = {'groups':{'all':['my_host','your_host','their_host']}}
    l = LookupModule()
    assert l.run(terms=terms, variables=variables) == ['my_host']


# Generated at 2022-06-23 11:51:36.013420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock the Ansible inventory to return a particular groups/hosts combination
    from ansible.inventory.manager import InventoryManager
    from unittest.mock import Mock, patch
    from ansible import context
    from ansible.plugins.loader import lookup_loader

    inv_source = [
        '# inventory hosts',
        '# group_name: [host_names]',
        'www: [www1,www2,www3]',
        'db: [db1,db2]',
        '# inventory hosts']
    inv_inventory = InventoryManager(loader=None, sources=inv_source)

    # Mock the loader so it can be passed to the inventory
    # class as per method run.
    lmMock = Mock()
    lmMock.get_basedir.return_value = ""
    lmMock

# Generated at 2022-06-23 11:51:47.255986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _hosts_list = [
              {'hostname': 'localhost', 'groups': ['ungrouped']},
              {'hostname': 'webserver', 'groups': ['webservers', 'www']},
              {'hostname': 'databaseserver', 'groups': ['databases']}
            ]
    _loader_mock = Mock(get_basedir=lambda self: os.path.join(os.path.dirname(__file__), 'data'))
    _inventory_manager_mock = Mock(InventoryManager)

# Generated at 2022-06-23 11:51:48.658137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []

# Generated at 2022-06-23 11:51:55.889643
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test single group
    class TestPlay():
        groups = dict()
        groups['group1'] = ['host1', 'host2']
        inventory = dict()
        inventory['groups'] = groups

    test_play = TestPlay()

    lMod = LookupModule()
    results = lMod.run(['group1'], test_play.inventory, loader=None)
    assert results == ['host1', 'host2']

    results = lMod.run(['group2'], test_play.inventory, loader=None)
    assert results == []

    # Test single host
    results = lMod.run(['host1'], test_play.inventory, loader=None)
    assert results == ['host1']

    results = lMod.run(['host3'], test_play.inventory, loader=None)
    assert results

# Generated at 2022-06-23 11:51:57.183517
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert(LookupModule())

# Generated at 2022-06-23 11:51:57.762030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:52:00.052820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test constructor of LookupModule")
    assert (isinstance(LookupModule(), LookupModule))


# Generated at 2022-06-23 11:52:00.985789
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, type)

# Generated at 2022-06-23 11:52:02.493279
# Unit test for constructor of class LookupModule
def test_LookupModule():
    manager = InventoryManager(LookupModule._loader, parse=False)


# Generated at 2022-06-23 11:52:12.639193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test method run of class LookupModule")

    #load lookupModule
    lookup_plugin = LookupModule()

    #test with an existing pattern (all)
    terms = [ "all" ]
    variables = { "groups": { "all": [ "localhost" ] } }
    item = ""
    expected_result = [ "localhost" ]
    result = lookup_plugin.run(terms, variables, item)
    if result != expected_result:
        print("result: %s should be: %s" % (result, expected_result))
        raise Exception("result: %s should be: %s" % (result, expected_result))

    #test with an existing pattern (all:!localhost)
    terms = [ "all:!localhost" ]
    variables = { "groups": { "all": [ "localhost" ] } }


# Generated at 2022-06-23 11:52:15.930112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    hostnameList = ['ansible', 'www']
    class_name = LookupModule()
    assert isinstance(class_name, LookupBase)
    assert class_name._loader is not None
    assert class_name._templar is not None
    assert class_name.run(hostnameList) == hostnameList

# Generated at 2022-06-23 11:52:27.015568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for inventory.
    mock_loader = None
    mock_variables = {'groups': {'all': ['localhost', '10.5.5.5']}}
    # By default, all hosts are listed.
    lookup_module = LookupModule(loader=mock_loader)
    assert lookup_module.run(terms=['localhost', '10.5.5.5'], variables=mock_variables) == ['localhost', '10.5.5.5']
    # Test for hostname pattern.
    assert lookup_module.run(terms=['all'], variables=mock_variables) == ['localhost', '10.5.5.5']
    assert lookup_module.run(terms=['all:!localhost'], variables=mock_variables) == ['10.5.5.5']

# Generated at 2022-06-23 11:52:29.091182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupBase)

# Generated at 2022-06-23 11:52:36.739780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()
    terms = 'all'
    variables = {'groups': {'all': ['host_1', 'host_2']}}
    result = test_lookup_module.run(terms, variables)
    assert result == ['host_1', 'host_2']
    
    terms = 'none'
    variables = {'groups': {'all': ['host_1', 'host_2']}}
    result = test_lookup_module.run(terms, variables)
    assert result == []

# Generated at 2022-06-23 11:52:40.458390
# Unit test for constructor of class LookupModule
def test_LookupModule():

    groups = {
        'all': ['foo', 'bar'],
        'nope': ['baz']
    }
    terms = 'all:!nope'
    variables = {
        'groups': groups
    }
    m = LookupModule(loader=None)
    res = m.run(terms=terms, variables=variables)
    assert res == ['foo', 'bar']

# Generated at 2022-06-23 11:52:42.906519
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:52:44.262728
# Unit test for constructor of class LookupModule
def test_LookupModule():
   assert LookupModule().run(terms=["all:!foo"])


# Generated at 2022-06-23 11:52:45.619538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert lookup_class is not None

# Generated at 2022-06-23 11:52:55.964522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    manager = InventoryManager(loader=None, parse=False)
    group1 = 'group1'
    group2 = 'group2'
    group3 = 'www'
    host1 = 'host1'
    host2 = 'host2'
    host3 = 'host3'
    host4 = 'host4'
    host5 = 'host5'
    host6 = 'host6'
    host7 = 'host7'
    host8 = 'host8'


# Generated at 2022-06-23 11:53:05.549261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of Class LookupModule
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Setup
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    host_1 = Host(name="test_host_1", port=22)
    inv_manager.add_host(host=host_1, group='test_hosts')
    group_1 = inv_manager.groups['test_hosts']
    variables = dict(groups=dict(test_hosts=group_1))

# Generated at 2022-06-23 11:53:11.878401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup:
    terms = 'all:!www'
    variables = dict()
    variables['groups'] = dict()
    variables['groups']['all'] = ['alice','bob','carol','dave']
    variables['groups']['www'] = ['carol','dave']

    # Exercise:
    x = LookupModule()
    result = x.run(terms, variables)

    # Verify:
    expected = ['alice','bob']
    assert result == expected

# Generated at 2022-06-23 11:53:14.462317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.get_basedir({}) == [None, '~']

# Generated at 2022-06-23 11:53:23.272816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    pattern = {'all': '!www'}
    hosts = {
        'group_one': [
            'web',
            'db',
            'vpn',
        ],
        'www': [
            'mhvfr',
            'n01',
            'n02',
        ],
        'databases': [
            'db_master',
            'db_2',
            'db_3',
        ]
    }
    expected = [
        'web',
        'db',
        'vpn',
        'db_master',
        'db_2',
        'db_3',
    ]

    assert lookup_plugin.run(pattern, {'groups': hosts}) == expected

# Generated at 2022-06-23 11:53:28.827442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    hostname = 'localhost'
    pattern = 'all'
    lm = LookupModule(loader=None)    
    assert lm.run(terms=[pattern], variables={'groups': {pattern: [hostname]}}) == [hostname]

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:53:36.874701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method lookup_module.run of class LookupModule
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.strategy import StrategyBase
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.inventory.inventory import Inventory
   

# Generated at 2022-06-23 11:53:45.958340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Use a fixture of the hosts file for this test
    # (test/units/test_playbook.c.hosts)
    test_hosts_file = 'test/units/test_playbook.c.hosts'
    loader = DictDataLoader({'test/units/test_playbook.c.hosts': test_hosts_file})
    inventory = InventoryManager(loader=loader)
    inventory.parse_inventory(host_list=test_hosts_file)
    # Get the group names to test the host patterns
    groups = inventory.groups_list()
    # Method run needs variables['groups'] to generate the dict of hosts by
    # group name
    variables = dict()
    variables['groups'] = dict()

# Generated at 2022-06-23 11:53:51.348335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.inventory_hostnames import LookupModule
    hostnames = ['apache1.example.com', 'apache2.example.com']
    groups = {'apaches': hostnames}
    terms = 'apache*'
    assert LookupModule().run(terms, variables={'groups': groups}) == hostnames

# Generated at 2022-06-23 11:54:02.022330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lk = LookupModule()
    # Set the inventory
    inventory = '''
[all]
a
b
c

[www]
a
b

[other]
a
b
c
d
e
    '''
    # Set the inventory in the loader
    lk._loader = FakeLoader()
    lk._loader._inventory = inventory
    # Test the run() method with a non-existent host pattern in inventory
    assert lk.run('non-existent-host-pattern', variables={'groups': {'all': ['a', 'b', 'c'], 'www': ['a', 'b'], 'other': ['a', 'b', 'c', 'd', 'e']}}) == []
    # Test the run() method with an existent host pattern in inventory

# Generated at 2022-06-23 11:54:07.035869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = 'all'
    variables = {'groups': {'all': [ 'server1', 'server2', 'server3' ]}}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == [ u'server1', u'server2', u'server3' ]

# Generated at 2022-06-23 11:54:07.857158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:54:20.058521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _create_inventory(hosts):
        inventory = InventoryManager(loader=None, variable_manager=None, host_list=None)
        for hostname in hosts:
            host = inventory.add_host(hostname)
            group = inventory.add_group(hostname + "_group")
            group.add_host(host)
        return inventory

    # No hosts in the inventory - should return an empty list
    assert [] == LookupModule().run(None, variables={})

    # Simple hosts group in the inventory - should return the hostnames
    hosts = ['myhost1', 'myhost2']
    inventory = _create_inventory(hosts)
    assert hosts == LookupModule().run(None, variables=inventory._hosts_cache, groups=inventory.groups)

    # Non-matching pattern - should return an empty list
   

# Generated at 2022-06-23 11:54:31.451734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    groups = {'default': ['kube-apiserver-10-0-0-11', 'kube-apiserver-10-0-0-12', 'kube-controller-10-0-0-11', 'kube-controller-10-0-0-12', 'kube-scheduler-10-0-0-11', 'kube-scheduler-10-0-0-12', 'kube-proxy-10-0-0-11', 'kube-proxy-10-0-0-12', 'kube-node-10-0-0-13']}
    res = lookup_module.run(terms = 'kube-node-10-0-0-13', variables = {'groups' : groups})
    assert type(res) == list

# Generated at 2022-06-23 11:54:32.717523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True


# Generated at 2022-06-23 11:54:44.195087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    hosts = {
        'web': [
          'alpha',
          'beta'
        ],
        'win': [
          'gamma'
        ]
    }

    play_context = dict(
        basedir='.',
        remote_addr='127.0.0.1',
        port=22,
        remote_user='root',
        password=None,
        private_key_file=None,
        connection='ssh',
        timeout=10,
        shell=None,
        become=True,
        become_method=None,
        become_user=None,
        become_pass=None,
        environment=None,
        no_log=True,
    )


# Generated at 2022-06-23 11:54:45.007195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule is actually an abstract base class and should not be constructed directly.
    # See notes in ansible.plugins.loader.py.
    pass

# Generated at 2022-06-23 11:54:46.184986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:54:52.776897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(test_dir + "/../")
    from common_test_data import INVENTORY, VARS

    LookupModule =LookupModule()
    LookupModule._loader = DictDataLoader({'': {'vars': VARS, 'inventory': INVENTORY}})
    assert(LookupModule.run(['all']) == ['first', 'second', 'third'])
    assert(LookupModule.run(['all:!www']) == ['first', 'second'])
    assert(LookupModule.run(['all:&db']) == ['second'])

# Generated at 2022-06-23 11:55:02.935572
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Imports
    import ansible.plugins.lookup
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.group

    # Fixtures
    test_pattern = "testpatter"
    test_host_names = ["host1", "host2", "host3", "host4"]
    test_group_names = ["group1", "group2", "group3", "group4"]
    test_hosts = [ansible.inventory.host.Host(name=name) for name in test_host_names]
    test_groups = [ansible.inventory.group.Group(name=name) for name in test_group_names]

# Generated at 2022-06-23 11:55:14.327533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

# Generated at 2022-06-23 11:55:24.412644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_ = {'groups': {
        'web': ['192.168.0.1', '192.168.0.2', '192.168.0.3'],
        'database': ['192.168.0.4', '192.168.0.5', '192.168.0.6']
    }}
    lm = LookupModule()
    assert ['192.168.0.1', '192.168.0.2', '192.168.0.3'] == lm.run(terms=['web'], variables=vars_)
    assert ['192.168.0.4', '192.168.0.5', '192.168.0.6'] == lm.run(terms=['database'], variables=vars_)

# Generated at 2022-06-23 11:55:26.633257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of the class
    lookup_plugin = LookupModule()
    # Check that the instance is of the correct class
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:55:27.648064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule.run(["all"]) == [])

# Generated at 2022-06-23 11:55:28.960403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._loader

# Generated at 2022-06-23 11:55:32.294837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-23 11:55:37.755688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.set_loader()
    inventory = {
        'all': ["host1", "host2"],
        'app': ["host2", "host3"]
    }
    variables = {
        'groups': inventory
    }
    matches = lookup_module.run(terms='all:!host1', variables=variables)
    assert matches == ['host2']

# Generated at 2022-06-23 11:55:39.205008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:55:42.408829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    manager = InventoryManager(None, parse=False)
    lookup_module = LookupModule([], inventory=manager)
    assert lookup_module

# Generated at 2022-06-23 11:55:52.668872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # First test: first argument is a string
    assert isinstance(LookupModule('abc'), LookupModule)
    assert isinstance(LookupModule(terms=['abc']), LookupModule)
    assert isinstance(LookupModule(terms='abc', variables={'a': 'b'}), LookupModule)
    assert isinstance(LookupModule(['abc'], {'a': 'b'}), LookupModule)
    assert isinstance(LookupModule(['abc'], variables={'a': 'b'}), LookupModule)

    # Second test: first argument is a list
    assert isinstance(LookupModule(['abc']), LookupModule)
    assert isinstance(LookupModule(terms=['abc']), LookupModule)

# Generated at 2022-06-23 11:56:01.812978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # First test case
    # This test case assumes the groups variable was defined and has a group with hosts
    test_groups1 = {
        'test_group': [
            'test_host1',
            'test_host2'
            ]
        }

    # Configure the test variables
    test_hosts = []
    test_variables = {'groups':test_groups1}
    test_terms = 'test_group'

    # Mock the inventory to return test_hosts
    class MockInventoryManager:
        def __init__(self, loader, parse):
            pass

        def get_hosts(self, pattern):
            return test_hosts

    lookup_module._loader.inventory = MockInventoryManager

    # Run the test

# Generated at 2022-06-23 11:56:03.231053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # instantiate the lookup module class
    lookup_module = LookupModule()

    # compare the returned inventory hosts
    assert lookup_module._hosts==None

# Generated at 2022-06-23 11:56:11.813418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # with static inventory
    manager = InventoryManager(loader=None, sources=[], parse=False)
    for group in ["group1", "group2", "dev"]:
        manager.add_group(group)
    for host in ["host1", "host2", "dev_host"]:
        manager.add_host(host, group="dev")
    manager.add_host("host1", group="group1")
    manager.add_host("host2", group="group2")
    group1 = manager.groups.get("group1")
    group2 = manager.groups.get("group2")
    group_all = manager.groups.get("all")
    group_dev = manager.groups.get("dev")

    assert group1.hosts_list == [manager.get_host("host1")]

# Generated at 2022-06-23 11:56:15.143685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, '__init__')
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-23 11:56:20.823767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class Vars:
        def __init__(self):
            self.groups = {
                'group1': ['localhost'],
                'group2': ['db-01', 'db-02']
            }
    vars = Vars()
    terms = 'all'
    l = LookupModule()
    res = l.run(terms=terms, variables=vars)
    assert res == ['localhost', 'db-01', 'db-02']

# Generated at 2022-06-23 11:56:31.509574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    inventory_content = b"""
    [webservers_in_us-east-1]
    host01.example.com
    host02.example.com
    [webservers_in_us-west-1]
    host11.example.com
    host12.example.com
    """

    # assert method run returns list of group names and host names
    assert module.run([inventory_content], variables={'groups':{'all':['host01.example.com','host02.example.com','host11.example.com','host12.example.com']}}) == ['host01.example.com','host02.example.com','host11.example.com','host12.example.com']


# Generated at 2022-06-23 11:56:42.048655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    paths = 'file_paths' in os.getcwd() and 'file_paths' or 'docs/docsite/rst/plugins/lookup_plugins/file_paths'
    path = os.path.join(paths, 'host_vars/hosts')
    host_vars = yaml.safe_load(open(path).read())

    inventory = InventoryManager(loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = host_vars

    lu = Lookup

# Generated at 2022-06-23 11:56:43.874062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert LookupModule().run(terms, variables) == ["..."]
    assert 1 == 1

# Generated at 2022-06-23 11:56:44.437718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True  # TODO

# Generated at 2022-06-23 11:56:52.785592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate class LookupModule
    lookup = LookupModule()
    # assign value to terms
    terms = ['all']
    # assign value to variables
    variables = {'groups': {'all': ['localhost']}}
    # assign value to kwargs
    kwargs = {}
    # expected result
    result = ['localhost']
    # method run of class LookupModule
    assert list(result) == lookup.run(terms, variables, **kwargs)

    # assign value to terms
    terms = ['all']
    # assign value to variables
    variables = {'groups': {'all': ['localhost', 'localhost1']}}
    # method run of class LookupModule
    assert list(result) == lookup.run(terms, variables, **kwargs)

    # assign value to terms
    terms = ['all']
    #

# Generated at 2022-06-23 11:57:03.467133
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 11:57:08.656785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creating instance with empty loader
    lm = LookupModule()
    assert lm._loader is None

    # Test creating instance with a loader
    from ansible.parsing.dataloader import DataLoader
    lm = LookupModule(DataLoader())
    assert lm._loader is not None

# Generated at 2022-06-23 11:57:09.769269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global _hostnames
    assert _hostnames is not None

# Generated at 2022-06-23 11:57:17.789959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global loader
    loader = DictDataLoader({})

    # 1. test with_inventory_hostnames

    # 1.1. success
    b_hashes = {
        'all': ['b1', 'b2', 'b3'],
        'alpha': ['b1', 'b2'],
        'beta': ['b3']
    }
    variables = {
        'groups': b_hashes
    }
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=['alpha'], variables=variables)
    assert result == ['b1', 'b2']

    # 1.2. failed
    result = lookup_plugin.run(terms=['unknown_name'], variables=variables)
    assert result == []

# Generated at 2022-06-23 11:57:20.545343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = ['group1', 'group2']
    l2 = ['group2', 'group3']
    v = {'groups': {'group1': l, 'group2': l2}}
    lookup_obj = LookupModule()
    assert lookup_obj.run('group1', variables=v) == l
    assert lookup_obj.run('all:!group1', variables=v) == l2

# Generated at 2022-06-23 11:57:26.964182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_patterns = ['all', '*']
    for test_pattern in test_patterns:
        test_hosts = LookupModule()
        print(test_hosts.run(test_pattern))
        assert isinstance(test_hosts.run(test_pattern)[0], str)
    #assert test_hosts.run(test_pattern) == ['host1', 'host2']


# Generated at 2022-06-23 11:57:27.726703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:57:39.436358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModule(object):
        def __init__(self):
            self.params = 'test'
            self.args = {'terms': ['example']}
            self.env = []
        def fail_json(self, *args, **kwargs):
            raise Exception('Failed')

    class MockLookupBase(object):
        def __init__(self, loader):
            self.loader = loader
        def _flatten(self, terms):
            return terms

    terms = "example"
    variables = {'groups': {'example': ['localhost']}}

    lookup_module = LookupModule()

    assert lookup_module.run(terms, variables=variables) == ['localhost']
    assert lookup_module.run(terms, variables=variables, _templar=MockModule()) == ['localhost']
    assert lookup

# Generated at 2022-06-23 11:57:50.171168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager

    variables = VariableManager()
    variables.add_host(host='localhost', group='group1')
    variables.add_host(host='127.0.0.1', group='group2')
    variables.add_host(host='127.0.0.2', group='group2')

    lookup_module = LookupModule()
    lookup_module.set_loader({'vars': variables})

    results = lookup_module.run(terms=['127*'], variables=variables)
    assert isinstance(results, list)
    assert '127.0.0.1' in results
    assert '127.0.0.2' in results

# Generated at 2022-06-23 11:57:53.043292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup_loader._load_lookup_plugins()
    plugin = lookup_loader.get('inventory_hostnames', class_only=True)
    assert plugin is not None

# Generated at 2022-06-23 11:58:04.753376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule(None, None, None)

    variables = { 'groups' : { 'group1' : [ 'host1', 'host2'], 'group2' : [ 'host1', 'host2' ] }, 'inventory_hostname' : 'host2' }

    result = lookup.run( [ 'host1' ], variables)
    assert result == [ 'host1' ]

    result = lookup.run( [ 'host2' ], variables)
    assert result == [ 'host2' ]

    result = lookup.run( [ '*' ], variables)
    result.sort()
    assert result == [ 'host1', 'host2' ]

    result = lookup.run( [ 'host1:group2' ], variables)
    assert result == [ 'host1' ]


# Generated at 2022-06-23 11:58:15.034605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestVariables:
        def __init__(self):
            self.groups = {
                'localhost': ['test1.example.com'],
                'webservers': ['test2.example.com'],
                'others': ['test3.example.com']
            }

    # Unittest for hostname lookup
    lookup_instance = LookupModule()
    test_variables = TestVariables()

    result = lookup_instance.run(
        ['all'],
        variables=test_variables
    )

    assert result == ['test1.example.com', 'test2.example.com', 'test3.example.com']

    # Unittest for hostname lookup - Exclude one group
    lookup_instance = LookupModule()
    test_variables = TestVariables()

    result = lookup_

# Generated at 2022-06-23 11:58:18.728857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule = LookupModule()
    assert [] == LookupModule.run(terms='www', variables={'groups': {'all': ['localhost']}})
    assert ['localhost'] == LookupModule.run(terms='all', variables={'groups': {'all': ['localhost']}})
    assert ['localhost'] == LookupModule.run(terms='all:!www', variables={'groups': {'all': ['localhost']}})

# Generated at 2022-06-23 11:58:19.610456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 11:58:24.917962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible -m ansible.modules.system.ping example.com
    m = LookupModule()
    with pytest.raises(AnsibleError) as e_info:
        m.run(terms=None, variables=None, inject=None)
    #assert m.run(terms=None, variables=None, inject=None) is None
    #assert m.run(terms='', variables=None, inject=None) == []
    print(e_info)

# Generated at 2022-06-23 11:58:27.814161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' Unit test for constructor of class LookupModule '''
    lu = LookupModule()
    assert len(lu.run) == 3

# Generated at 2022-06-23 11:58:29.614567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Unit Test - AnsibleError is raised

# Generated at 2022-06-23 11:58:33.852083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._loader = DictDataLoader({})
    l.run(["all"])
    l.run(["all:!www"])
    assert_raises(AnsibleError, l.run, ["all:"], {"groups": {}})


# Generated at 2022-06-23 11:58:37.627456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['foo*'], variables={'groups': {'all': ['foo1', 'foo2', 'bar']}})
    assert result == ['foo1', 'foo2']

# Generated at 2022-06-23 11:58:39.333052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:58:45.377522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Check LookupModule_run method of class LookupModule """
    lookup_module = LookupModule()
    terms = 'fake_terms'
    variables = {
        'groups': {
            'fake_group1': ['fake_host1', 'fake_host2'],
            'fake_group2': ['fake_host3', 'fake_host4'],
        }
    }
    result = lookup_module.run(terms=terms, variables=variables)
    assert result == ['fake_host1', 'fake_host2', 'fake_host3', 'fake_host4']

    terms = 'fake_group1'
    result = lookup_module.run(terms=terms, variables=variables)
    assert result == ['fake_host1', 'fake_host2']

# Generated at 2022-06-23 11:58:46.369659
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Construct class LookupModule."""
    pass

# Generated at 2022-06-23 11:58:48.357113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:58:56.458397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    
    terms = "all"
    variables = {
        'groups': {
            'all': [
                'alpha',
                'bravo',
                'charlie',
                'delta'
            ],
            'group2': [
                'alpha',
                'bravo',
                'charlie',
                'delta'
            ]
        }
    }
    result = m.run(terms, variables)
    assert result == ['alpha', 'bravo', 'charlie', 'delta']

    terms = "group2"
    result = m.run(terms, variables)
    assert result == ['alpha', 'bravo', 'charlie', 'delta']

# Generated at 2022-06-23 11:59:05.818687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    host_1 = Host(name='host1')
    host_2 = Host(name='host2')
    host_3 = Host(name='host3')
    host_4 = Host(name='host4')
    inventory.add_group('all')
    inventory.add_host(host_1, group='all')
    inventory.add_host(host_2, group='all')

# Generated at 2022-06-23 11:59:08.445375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 11:59:16.653070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader)
    host = Host(name="foobar")
    inventory.add_host(host)
    inventory.add_group("new_group")
    inventory.add_child("new_group", host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms="foobar[0-5]", variables=variable_manager.get_vars(host=host))
    assert result == ["foobar"]

# Generated at 2022-06-23 11:59:27.786501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hosts = []
    hosts.append(Host('stargate-1'))
    hosts.append(Host('stargate-2'))
    hosts.append(Host('stargate-3'))
    hosts.append(Host('dhd-1'))
    hosts.append(Host('dhd-2'))
    hosts.append(Host('dhd-3'))
    hosts.append(Host('dhd-4'))
    hosts.append(Host('dhd-5'))

    groups = []
    groups.append(HostGroup('stargates', host_names=['stargate-1', 'stargate-2', 'stargate-3']))