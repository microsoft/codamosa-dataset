

# Generated at 2022-06-21 06:14:27.616799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize host names and group names
    host1 = 'host1'
    host2 = 'host2'
    host3 = 'host3'
    host4 = 'host4'
    host5 = 'host5'
    hosts = [host1, host2, host3, host4, host5]
    group_all = 'all'
    group_www = 'www'
    group_db = 'db'
    group_ctrl = 'ctrl'
    group_backend = 'backend'
    group_frontend = 'frontend'
    group_latam = 'latam'
    group_us = 'us'
    group_www_latam_us = 'www:latam:us'
    group_www_latam = 'www:latam'

# Generated at 2022-06-21 06:14:39.751578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    manager = InventoryManager(lookup._loader, parse=False)
    groups = {
        "alphabet": ['a', 'b', 'c'],
        "numbers": ['1', '2', '3'],
    }
    for group, hosts in groups.items():
        manager.add_group(group)
        for host in hosts:
            manager.add_host(host, group=group)
    # Test for several queries
    assert ['c'] == lookup.run(['c'], {'groups': groups})
    assert ['1', '2'] == lookup.run(['1', '2'], {'groups': groups})

# Generated at 2022-06-21 06:14:43.859282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    inventory = InventoryManager(loader=None, sources=None, sources_list=None)
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-21 06:14:53.285233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils._text import to_bytes

    # Create some mock variables for test.
    mock_plugin = LookupModule()
    mock_plugin._loader = object
    inventory_hosts = {"all":["host1", "host2", "host3"]}
    mock_variables = {'groups': inventory_hosts}

    # Test positive case.
    results = mock_plugin.run(["all:!host2"], mock_variables)
    assert results == ["host1", "host3"]

    results = mock_plugin.run(["all:!host2"], mock_variables)
    assert results == ["host1", "host3"]


# Generated at 2022-06-21 06:14:55.575083
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 06:15:04.707322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of class LookupModule
    """
    terms = ['all']  # get all hosts
    variables = {'groups': {'webservers': ['host1','host2','host3']}}
    lookup_module = LookupModule()
    hosts = lookup_module.run(terms, variables)
    assert hosts == ['host1', 'host2', 'host3']
    terms = ['webservers']  # get hosts from group webservers
    hosts = lookup_module.run(terms, variables)
    assert hosts == ['host1', 'host2', 'host3']
    terms = ['!webservers']  # get hosts that not in group webservers
    hosts = lookup_module.run(terms, variables)
    assert hosts == []

# Generated at 2022-06-21 06:15:06.446440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the instance was created properly
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:15:07.031609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()

# Generated at 2022-06-21 06:15:10.333546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module = LookupModule()
   inventory = {'groups': {
         'all': ['somehost1', 'somehost2', 'somehostall']
    }}
   lookup_module.run(['all'], variables={'groups': inventory['groups']})

# Generated at 2022-06-21 06:15:12.100091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 06:15:14.455458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 06:15:17.587493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    manager = InventoryManager(LookupBase._loader, parse=False)
    assert isinstance(manager, InventoryManager)

# Generated at 2022-06-21 06:15:19.155879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of class LookupModule.
    """
    l = LookupModule()
    assert l._loader is not None

# Generated at 2022-06-21 06:15:29.458821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test object
    lm = LookupModule()
    # Create test data
    x = dict(
        groups = dict(
            group_1 = ['1.1.1.1', '2.2.2.2']
            ),
        all = ['1.1.1.1', '2.2.2.2'],
        pattern = 'group_1:all',
        inventory_hostnames = ['1.1.1.1', '2.2.2.2']
        )
    # test run method
    assert lm.run(terms=x['pattern'], variables=x) == x['inventory_hostnames']

# Generated at 2022-06-21 06:15:35.772334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['all:!www']

    m = LookupModule()
    ret_val = m.run(terms, variables={'groups': {'all': ['foo', 'bar'], 'www': ['baz']}})
    assert ret_val == ['foo', 'bar']

# Generated at 2022-06-21 06:15:43.491499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a simple mock that represents a group and host
    group = {'example': ['localhost']}
    # Create an inventory manager to add the group to with parse set to false
    manager = InventoryManager(None, parse=False)
    #Add the group to the manager
    manager.add_group('example')
    #Add the host to the manager
    manager.add_host('localhost', group='example')
    #Create and run a LookupModule object with the method run to get a list of hosts for the pattern localhost
    #Using _loader because it is not required for this unit test
    lookup_module = LookupModule(loader=None)
    #The pattern localhost matches one host so the list has one item
    assert lookup_module.run(terms='localhost', variables={'groups': group}) == ['localhost']

# Generated at 2022-06-21 06:15:49.877858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    inventory_manager = InventoryManager('ansible/inventory', parse=True)
    terms = 'all'
    variables = {
        "groups": {
            "group1": [
                "server1",
                "server2"
            ],
            "group2": [
                "server3",
                "server4"
            ],
        }
    }
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)

# Generated at 2022-06-21 06:16:02.794242
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create an instance of class LookupModule
    x = LookupModule()

    # Create a list of groups
    groups = {'foo': {'hosts': ['example.com', 'company.com']}, 'bar': {'hosts': ['192.168.1.1', '192.168.1.2']}}
    # Create a list of variables
    variables = {'ansible_connection': 'local', 'groups': groups}

    assert x.run(['foo'], variables) == ['example.com', 'company.com']
    assert x.run(['all'], variables) == ['example.com', 'company.com', '192.168.1.1', '192.168.1.2']

# Generated at 2022-06-21 06:16:14.090717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader
    # Create a dummy class which will be used only to create a test object of class Ansible.parsing.dataloader.DataLoader
    class DummyClass:
        def __init__(self):
            pass
    loader = ansible.parsing.dataloader.DataLoader(DummyClass())
    test_obj = LookupModule(loader)
    # Create a dictionary which will be used to create object of class ansible.inventory.manager.InventoryManager
    groups_dict = {'group': ['host1', 'host2']}
    variables = {'groups': groups_dict}
    terms = ['host1']
    assert test_obj.run(terms, variables, **kwargs) == ['host1']

# Generated at 2022-06-21 06:16:14.607379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:16:20.787143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Given.
    host = "foo"
    hostname = "bar"
    lu = LookupModule()
    groups = {
        host: [hostname],
    }
    # When.
    lu.run(terms=host, variables={"groups": groups})

# Generated at 2022-06-21 06:16:32.795130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader, {}))

# Generated at 2022-06-21 06:16:36.889502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['blah']
    variables = {
        'groups': {
            'test': {
                'test1'
            }
        }
    }

    result = module.run(terms, variables)

    assert result == []

    terms = ['test1']

    result = module.run(terms, variables)

    assert result == ['test1']

# Generated at 2022-06-21 06:16:37.543929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)

# Generated at 2022-06-21 06:16:46.585347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Return array of matching hosts
    host_pattern = 'all'
    lookup_module = LookupModule()
    manager = InventoryManager(lookup_module._loader, parse=False)
    groups = {
      'all': ['18.33.222.22']
    }
    variables = {'groups': groups} # pass all the group variables to the lookup module
    for group, hosts in variables['groups'].items():
        manager.add_group(group)
        for host in hosts:
            manager.add_host(host, group=group)
    assert lookup_module.run([host_pattern], variables) == ['18.33.222.22']

    # Return empty array
    host_pattern = 'test'
    assert lookup_module.run([host_pattern], variables) == []

    # Return array of matching hosts
    host

# Generated at 2022-06-21 06:16:55.459771
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class LookupBase
    class LookupBase_mock:
        _loader = 'mock_loader'

    # Mock class InventoryManager
    class InventoryManager_mock:
        def __init__(self, loader, parse=False):
            self.loader = loader
            self.parse = parse

        def add_group(self, group):
            self.group = group

        def add_host(self, host, group=None):
            self.host = host

    # Mock object LookupBase_obj
    class LookupBase_obj:
        def __init__(self, loader):
            self.loader = loader

    # Mock object InventoryManager_obj
    class InventoryManager_obj:
        def __init__(self, loader, parse=False):
            self.loader = loader
            self.parse = parse


# Generated at 2022-06-21 06:16:56.898220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-21 06:17:03.948828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    hosts = {'group1':['host1.example.com'],'group2':['host2.example.com']}
    variables = {'groups':hosts}
    terms = ['all']
    assert lookupModule.run(terms,variables,**{}) == ['host1.example.com', 'host2.example.com']
    terms = ['group1']
    assert lookupModule.run(terms,variables,**{}) == ['host1.example.com']
    terms = ['group1:group2']
    assert lookupModule.run(terms,variables,**{}) == ['host1.example.com', 'host2.example.com']
    terms = ['group1:group2', '!group1']

# Generated at 2022-06-21 06:17:12.417538
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class CallbackModule:
        def __init__(self):
            self.results = []

        def v2_runner_on_ok(results, task_results):
            self.results.append(task_results)

    class CallbackModule2:
        def __init__(self):
            self.results = []

        def v2_runner_on_ok(self, results, task_results):
            self.results.append(task_results)

    import pytest
    from unittest.mock import patch

    # Setup
    with patch.dict('os.environ', {'ANSIBLE_INVENTORY': 'tests/inventory.yml'}):
        terms = 'all'

# Generated at 2022-06-21 06:17:21.651322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class inventory:
        def __init__(self, groups=None):
            if not groups:
                groups = {}
            self.groups = groups

    class loader:
        def __init__(self, basedir=None):
            if not basedir:
                basedir = '/'
            self.basedir = basedir

        def load_from_file(self, filename):
            pass

        def get_basedir(self):
            return self.basedir


# Generated at 2022-06-21 06:17:27.413492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(TypeError) as exceptioninfo: # error must be raised
        LookupModule()
    assert 'missing 1 required positional argument' in str(exceptioninfo.value)


# Generated at 2022-06-21 06:17:33.262959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    print(lookup_plugin)
    assert(lookup_plugin.get_loader() is not None)
    assert(lookup_plugin.get_basedir() is not None)

# Test for run method of class LookupModule

# Generated at 2022-06-21 06:17:40.541770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    assert L.run(terms=["test"], variables={"groups": {"test": ["localhost"]}}) == ["localhost"]
    assert L.run(terms=["test"], variables={"groups": {"test": ["localhost", "127.0.0.1"]}}) == ["localhost", "127.0.0.1"]
    assert L.run(terms=["test"], variables={"groups": {"test": ["localhost", "127.0.0.1"]}}) == ["localhost", "127.0.0.1"]

# Generated at 2022-06-21 06:17:49.886134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    hostvars = { 
        'groups': {
            'all': ['localhost', '127.0.0.1']
        },
        'hostvars': {
            'localhost': {},
            '127.0.0.1': {}
        }
    }

    terms = "localhost"
    assert lookup.run(terms, hostvars) == ['localhost']

    terms = ["localhost", "127.0.0.1"]
    assert lookup.run(terms, hostvars) == ['localhost', '127.0.0.1']

    terms = "nohost"
    assert lookup.run(terms, hostvars) == []

# Generated at 2022-06-21 06:17:52.018730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert type(l) == LookupModule

# Generated at 2022-06-21 06:18:01.293683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self):
            self._loader = None
            self.params = None

    lookup_module = TestLookupModule()
    hostnames = lookup_module.run([
        "all:!www"
    ], variables={
        "groups": {
            "www": ["www01", "www02"],
            "group1": ["host1", "host2"],
            "all": ["host1", "host2", "www01", "www02"]
        }
    })

    assert hostnames == ["host1", "host2"]

# Generated at 2022-06-21 06:18:10.267742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ""
    variables = {}
    assert len(lookup_module.run(terms, variables)) == 0
    terms = "all"
    variables = {}
    assert len(lookup_module.run(terms, variables)) == 0
    variables['groups'] = {}
    assert len(lookup_module.run(terms, variables)) == 0
    variables['groups']['alpha'] = ['1.2.2.2']
    variables['groups']['beta'] = ['1.2.2.3']
    assert len(lookup_module.run(terms, variables)) == 2
    terms = "group1"
    assert len(lookup_module.run(terms, variables)) == 1
    terms = "group2"

# Generated at 2022-06-21 06:18:13.995061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    assert hasattr(lm, 'run')
    assert hasattr(lm, '_loader')
    assert hasattr(lm, 'test')

# Generated at 2022-06-21 06:18:14.960253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms='test') == []

# Generated at 2022-06-21 06:18:22.469981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inventory = dict(
        group_a=[
            dict(
                host=dict(
                    name='1.1.1.1'
                )
            ),
            dict(
                host=dict(
                    name='1.1.1.2'
                )
            )
        ],
        group_b=[
            dict(
                host=dict(
                    name='1.1.1.3'
                )
            ),
            dict(
                host=dict(
                    name='1.1.1.4'
                )
            )
        ]
    )
    loader = DictDataLoader(dict(
        inventory=json.dumps(inventory)
    ))
    variable_manager = VariableManager(loader=loader, inventory=Inventory(loader=loader, variable_manager=variable_manager))

# Generated at 2022-06-21 06:18:32.575799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {"groups": {"test_group": ["test_host"]}}

    terms = ["test_group"]
    result = LookupModule().run(terms, hostvars)
    assert result == ["test_host"]


# Generated at 2022-06-21 06:18:33.321273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add tests
    pass

# Generated at 2022-06-21 06:18:41.299015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    # Patch the loader so that it finds our test lookup plugin (test_plugin_loader.py)
    lookup_loader.find_plugin = lambda name, *args, **kwargs: { 'test': __name__ }

    lookup = lookup_loader.get('test')

    # Load up the inventory
    variables = { 'groups': { 'all': ['localhost', 'ell'], 'www': ['webserver'] } }

    # Test it works as expected
    assert lookup.run(['localhost', 'ell'], variables=variables) == ['localhost', 'ell']
    assert lookup.run(['!www'], variables=variables) == ['localhost', 'ell']
    assert lookup.run(['all:!www'], variables=variables) == ['localhost', 'ell']
    assert lookup

# Generated at 2022-06-21 06:18:46.200522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def empty_variable(key):
        return None

    # setup class instance
    lookup_plugin = LookupModule()
    lookup_plugin._options = {
        '_loader': None,
        'inventory': None,
        'variable_manager': None,
        '_connection': object()
    }
    lookup_plugin._loader = empty_variable
    lookup_plugin._templar = empty_variable
    lookup_plugin.set_options({})
    inventory = {
        'all': {'hosts': ['host_all']},
        'group_1': {'hosts': ['host_group_1']},
        'group_2': {'hosts': ['host_group_2']},
    }
    variables = {
        'groups': inventory,
    }

    # single host in playbook inventory

# Generated at 2022-06-21 06:18:55.922007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["all"], variables={"groups":{"all":["host1", "host2", "host3"]}})
    assert result == ["host1", "host2", "host3"]
    result = lookup_module.run(["all:!host1"], variables={"groups":{"all":["host1", "host2", "host3"]}})
    assert result == ["host2", "host3"]

# Unit tests for method run of class LookupModule with a pattern containing a key

# Generated at 2022-06-21 06:19:04.529368
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _assert_run(terms, variables, expected):
        assert LookupModule().run(terms, variables=variables) == expected

    terms = 'all'
    variables = dict(
        ansible_ssh_host='localhost',
        groups=dict(
            all=['some_host'],
        ),
    )
    expected = ['some_host']
    _assert_run(terms, variables, expected)

    terms = 'all'
    variables = dict(
        ansible_ssh_host='localhost',
        groups=dict(
            all=['some_host'],
            other_group=['some_host'],
        ),
    )
    expected = ['some_host']
    _assert_run(terms, variables, expected)

    terms = 'all'

# Generated at 2022-06-21 06:19:05.642471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plug = LookupModule()

# Generated at 2022-06-21 06:19:10.565834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['all:!www']
    variables = {}
    variables['groups'] = {}
    variables['groups']['www'] = ['web01', 'web02']
    variables['groups']['dep'] = ['web01', 'dep01']

    lm = LookupModule()
    hostnames = lm.run(terms, variables)
    assert hostnames == ['web02', 'dep01']

# Generated at 2022-06-21 06:19:13.025767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-21 06:19:15.069305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__ == "ansible lookup module."


# Generated at 2022-06-21 06:19:34.023708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyLoader:
        pass

    DummyLoaderClass = DummyLoader()
    assert not DummyLoaderClass
    lookup_module = LookupModule(loader=DummyLoaderClass)
    assert lookup_module

# Generated at 2022-06-21 06:19:42.696940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host

    # Empty inventory
    inventory = {}
    # Empty inventory_manager
    inventory_manager = InventoryManager(None, parse=False)
    for group, hosts in inventory.items():
        inventory_manager.add_group(group)
        for host in hosts:
            inventory_manager.add_host(host, group=group)

    # Mocks
    terms = ['all']
    variables = {'groups': {'hosts': ['host_1', 'host_2', 'host_3']}}
    kwargs = {}

    # Run method
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    
    # Result of run method

# Generated at 2022-06-21 06:19:52.072438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases = (
        (  # Run the method with terms that are not match
            ('undefined'),
            {
                "groups": {
                    "test_group": {
                        "test_host_1": None,
                        "test_host_2": None,
                        "test_host_3": None
                    }
                }
            },
            []
        ),
        (  # Run the method with terms that are match
            ('test_host_1,test_host_2'),
            {
                "groups": {
                    "test_group": {
                        "test_host_1": None,
                        "test_host_2": None,
                        "test_host_3": None
                    }
                }
            },
            ["test_host_1", "test_host_2"]
        )
    )



# Generated at 2022-06-21 06:19:53.490452
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:19:59.419907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = "all:!www"
    variables = {'groups': {'all': ['foo','bar','ansible','www'], 'www': ['www']}}
    result = lm.run(terms, variables)
    assert result == ['foo', 'bar', 'ansible']


# Generated at 2022-06-21 06:20:02.833065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term_list = ['all', '!www']
    result = lookup.run(term_list, {'groups': {'all': ['dbserver', 'www', 'clients']}})
    assert result == ['dbserver', 'clients']

# Generated at 2022-06-21 06:20:09.194919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup.inventory_hostnames import LookupModule

    lookup = LookupModule()
    inventory = {'all': {'hosts': ['test1', 'test2']}}
    assert lookup.run('all', variables={'groups': inventory}) == [ 'test1', 'test2' ]

# Generated at 2022-06-21 06:20:16.803069
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:20:23.463949
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule for testing.
    la = LookupModule()

    # Test variable groups

    groups = {}

    groups['all'] = ['www1', 'www2', 'www3', 'www4']
    groups['app'] = ['www1', 'www2', 'www3', 'www4']
    groups['db'] = ['db1', 'db2', 'db3', 'db4']
    groups['db-master'] = ['db1']
    groups['db-slave'] = ['db2', 'db3', 'db4']
    groups['www'] = ['www1', 'www2', 'www3']

    templates = {}
    templates['hostvars'] = {}
    for group, hosts in groups.items():
        templates['hostvars'][group] = {}

# Generated at 2022-06-21 06:20:27.839773
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible import constants as C
    assert hasattr(C, 'DEFAULT_INVENTORY_ENABLED')
    assert C.DEFAULT_INVENTORY_ENABLED
    assert C.DEFAULT_INVENTORY_ENABLED == True


# Generated at 2022-06-21 06:21:05.611212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #
    # test with good data
    #
    hosts = {'all': [{'hostname': 'host1'}, {'hostname': 'host2'}]}
    variables = {'groups': hosts,
                 'group_names': hosts.keys()}
    result = lookup.run(terms='all', variables=variables)
    assert result == ['host1', 'host2'], \
        "Returned value '%s' is not '%s'" % (result, ['host1', 'host2'])
    #
    # test with bad data
    #
    hosts = {'all': [{'hostname': 'host1'}, {'hostname': 'host2'}]}
    variables = {'groups': hosts,
                 'group_names': hosts.keys()}


# Generated at 2022-06-21 06:21:06.236315
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:21:14.738410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host1 = AnsibleHost("host1")
    host2 = AnsibleHost("host2")
    host3 = AnsibleHost("host3")
    host4 = AnsibleHost("host4")
    host5 = AnsibleHost("host5")
    group1 = AnsibleGroup("group1", [host1, host2])
    group2 = AnsibleGroup("group2", [host3, host4])
    group3 = AnsibleGroup("group3", [host5])

    args = []
    kwargs = {}
    result = []

    actual = LookupModule().run()
    assert actual == result

    args = [["host1", "host2", "host3", "host4", "host5"]]
    result = ["host1", "host2", "host3", "host4", "host5"]

    actual

# Generated at 2022-06-21 06:21:21.725565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    variable_manager = cutlass.VariableManager()
    loader = cutlass.DataLoader()
    variable_manager.set_inventory(cutlass.Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory.py'))
    cutlass.set_variable_manager(variable_manager)
    print(lookup_plugin.run(terms=['all'], variables=cutlass.get_variables()))

# Generated at 2022-06-21 06:21:22.277479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:21:23.657124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # py3 only
    LookupModule(None, None, None)

# Generated at 2022-06-21 06:21:24.272922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 06:21:30.319164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    import sys

    # Patch lookup module
    class fake_loader_mock(object):
        def __init__(self):
            self.basedir = "./test_basedir"

    class fake_inventory_mock(object):
        def __init__(self):
            self.loader = fake_loader_mock()
            self.entries = {}
        def add_group(self, group):
            self.entries[group] = []
        def add_host(self, host, group):
            self.entries[group].append(host)
        def get_hosts(self, pattern=None):
            if pattern is None:
                return [h for h in self.entries.keys()]

# Generated at 2022-06-21 06:21:35.329606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('inventory_hostnames', class_only=True)()
    lookup.set_loader({'_basedir': '.', 'vars': {'groups': {'test': ['localhost']}}})
    assert lookup.run(['localhost']) == ['localhost']

# Generated at 2022-06-21 06:21:46.263758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for 'lookup_plugins/inventory_hostnames.py' """

    ############################
    # instantiate class LookupModule
    ############################
    lookup_module = LookupModule()

    ############################
    # test normal LookupBase method with inventory
    ############################
    class MockLoader:
        def get_basedir(self):
            return '/ansible/test/dir'

    class MockHost:
        def __init__(self, name):
            self.name = name

    class MockHostManager:
        def __init__(self, groups):
            self.groups = groups
            self.hosts = {}

        def add_group(self, name):
            self.groups[name] = []


# Generated at 2022-06-21 06:22:41.813045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import __main__
    __main__.lookup_loader = None
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule) == True
    assert isinstance(lookup_module._loader, type(None)) == True


# Generated at 2022-06-21 06:22:42.622494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None) is not None

# Generated at 2022-06-21 06:22:44.023285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run('foo', {}) == []

# Generated at 2022-06-21 06:22:45.494876
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None
    assert l.run is not None

# Generated at 2022-06-21 06:22:49.731928
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test regular constructor
    lookup = LookupModule()

    # Test for class variables
    assert lookup._templar is not None
    assert lookup._loader is not None

# Generated at 2022-06-21 06:22:58.518564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    lookup_plugin = LookupModule()
    host = Host(name='dummy', port=22)
    groups = [Group(name='nginx'), Group(name='drupal')]
    inventory = InventoryManager(loader=None, hosts=[host], groups=groups,
                                          sources=['localhost'])
    inventory.subset('nginx')
    hostvars = inventory.get_hosts()
    variables = {'groups': {'nginx': ['dummy']}}
    result = lookup_plugin.run(terms='all', variables=variables)
    assert result == ['dummy']

# Generated at 2022-06-21 06:23:09.842180
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:23:20.857457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    inv = dict(
            group_names = dict(
                group1 = ['host2'],
                group2 = ['host3'],
                group3 = ['host1'],
                group4 = ['host1', 'host2', 'host3']
                ),
            hostvars = dict(
                host1 = dict(ansible_host='1.1.1.1'),
                host2 = dict(ansible_host='2.2.2.2'),
                host3 = dict(ansible_host='3.3.3.3')
                )
            )
    
    hosts_pat1 = ['host1']
    res = lm.run(hosts_pat1, variables=inv)
    assert(res == hosts_pat1)
    

# Generated at 2022-06-21 06:23:29.559129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class ansible_variable:
        def __init__(self, groups):
            self.groups = groups

    class ansible_loader:
        def __init__(self):
            pass

    def create_group(group):
        self.groups[group] = []

    def create_host(host, group):
        self.groups[group].append(host)

    class inventory_manager:
        def __init__(self, loader, parse="False"):
            self.loader = loader
            self.groups = {}
            self.add_group = create_group
            self.add_host = create_host

        def get_hosts(self, pattern):
            hosts = []
            for group in self.groups:
                if group in pattern:
                    hosts.extend(self.groups[group])

            return hosts

    variables

# Generated at 2022-06-21 06:23:34.292540
# Unit test for method run of class LookupModule