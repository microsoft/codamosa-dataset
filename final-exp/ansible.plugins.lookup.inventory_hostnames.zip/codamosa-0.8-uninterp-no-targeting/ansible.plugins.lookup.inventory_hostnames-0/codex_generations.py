

# Generated at 2022-06-21 06:14:13.748792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None).run([], {}) == []

# Generated at 2022-06-21 06:14:14.676071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._loader is not None


# Generated at 2022-06-21 06:14:27.516990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of class LookupModule
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

    # set empty inventory
    lm._loader.set_inventory(InventoryManager(''))
    # set variable groups
    lm._loader.set_variable('groups', {'www': ['test1.example.com', 'test2.example.com', 'test3.example.com'],
                                       'db': ['test4.example.com', 'test5.example.com', 'test6.example.com']})

    # check with given method call

# Generated at 2022-06-21 06:14:29.402109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)


# Generated at 2022-06-21 06:14:29.957841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__

# Generated at 2022-06-21 06:14:34.480355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['all', '!www']
    variables = {'groups': {'all': ['host1', 'host2'], 'www': ['host1', 'host3']}}
    instances = [
        {
            'return_value': ['host2'],
            '_loader': {
                'get_basedir': lambda self: '/etc/ansible'
            }
        },
        {
            'return_value': ['host1', 'host2'],
            '_loader': {
                'get_basedir': lambda self: '/etc/ansible'
            }
        },
        {
            'return_value': [],
            '_loader': {
                'get_basedir': lambda self: '/etc/ansible'
            }
        }
    ]

    for instance in instances:
        lookup_module

# Generated at 2022-06-21 06:14:37.818473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run()


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:14:40.568209
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule().run(terms=['all'])) != None

# Generated at 2022-06-21 06:14:41.926846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule('', '', '') != None

# Generated at 2022-06-21 06:14:52.398683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    groups = {
        'test': [
            'test1',
            'test2'
        ],
        'www': [
            'www1',
            'www2',
            'www3'
        ],
        'app': [
            'app1',
            'app2'
        ]
    }

    # Case: 1
    # Test: when term is empty, empty list should return
    term = "";
    result = lookup.run([term], variables={'groups': groups})
    assert result == []

    # Case: 2
    # Test: when terms is not a list, empty list should return
    terms = {};
    result = lookup.run(terms, variables={'groups': groups})
    assert result == []

    # Case: 3
    # Test: when term is not

# Generated at 2022-06-21 06:14:58.595032
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    print(lookup_plugin)
    assert isinstance(lookup_plugin, LookupModule)

# Run with `module=test_module` in ansible-playbook command to execute the unit test for class LookupModule

# Generated at 2022-06-21 06:15:01.221716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:15:12.182087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host1 = dict()
    host2 = dict()
    host3 = dict()
    host4 = dict()
    host1["hostname"] = "host1"
    host2["hostname"] = "host2"
    host3["hostname"] = "host3"
    host4["hostname"] = "host4"
    host1["groups"] = ["group1"]
    host2["groups"] = ["group2"]
    host3["groups"] = ["group1","group2"]
    host4["groups"] = ["group3"]
    hosts = dict()
    hosts["host1"] = host1
    hosts["host2"] = host2
    hosts["host3"] = host3
    hosts["host4"] = host4
    groups = dict()
    groups["group1"] = ["host1","host3"]
   

# Generated at 2022-06-21 06:15:18.512119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms="test",variables={'groups': {"test": ["test.se"]}}) == ["test.se"]
    assert LookupModule().run(terms="test,!test1",variables={'groups': {"test": ["test.se"],"test1": ["test1.se"]}}) == ["test.se"]

# Generated at 2022-06-21 06:15:30.369940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    hosts = list()
    hosts.append("group1")
    hosts.append("group2")
    hosts.append("group3")
    hosts.append("group4")

    groups = {}
    groups['group1'] = list()
    groups['group1'].append("host1")
    groups['group1'].append("host2")
    groups['group2'] = list()
    groups['group2'].append("host3")

    groups['group3'] = list()
    groups['group3'].append("host4")
    groups['group3'].append("host5")

    groups['group4'] = list()
    groups['group4'].append("host6")
    groups['group4'].append("host7")
    groups['group4'].append("host8")



# Generated at 2022-06-21 06:15:42.270475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    assert (LookupModule(None,None,None).run(None,variables={'groups': {'testgroup': [Host(name='testhost',vars={})]}})) == ['testhost']
    assert (LookupModule(None, None, None).run(None, variables={'groups': {'testgroup': [Host(name='testhost', vars={})]}})) != ['testhost1']
    assert (LookupModule(None, None, None).run(None, variables={'groups': {'testgroup': [Host(name='testhost', vars={})]}})) != 'testhost'

# Generated at 2022-06-21 06:15:53.018357
# Unit test for constructor of class LookupModule
def test_LookupModule():

    groups = ['web', 'mbox']
    hosts = ['host1', 'host2', 'host3', 'host4']
    list_group = list(dict.fromkeys(groups))
    list_hosts = list(dict.fromkeys(hosts))

    # Create inventory and add group and host to it
    inventory = InventoryManager(loader=None, sources=["localhost"])
    for group in list_group:
        inventory.add_group(group)
    for host in list_hosts:
        inventory.add_host(host=host, groups=['web'])

    # Test AttributeError - No such attribute: _loader
    try:
        LookupBase()._loader
        assert False
    except AttributeError:
        pass

    # Test AttributeError - No such attribute: _templar

# Generated at 2022-06-21 06:15:56.353008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)
    assert isinstance(l._loader, object)


# Generated at 2022-06-21 06:16:02.305914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg = ['all:!www']
    variables = {
        'groups': {'all': ['dock1.example.com', 'web1.example.com', 'web2.example.com'], 'www': ['web1.example.com', 'web2.example.com']}
    }
    module = LookupModule()

    assert module.run(arg, variables=variables) == ['dock1.example.com']

# Generated at 2022-06-21 06:16:14.347485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        Unit test for method run of class LookupModule
    """
    # pylint: disable=attribute-defined-outside-init
    import ast
    import errno
    import shutil
    import sys
    import tempfile
    import os

    def global_setup_module():
        """
            Global set up for test_LookupModule_run
        """
        global global_dir
        global_dir = tempfile.TemporaryDirectory()
        os.environ['INVENTORY_DIR'] = global_dir.name
        os.environ['INVENTORY_FILE'] = 'hosts'
        os.environ['INVENTORY_DICT'] = '{}'

    def global_teardown_module():
        """
            Global set up for test_LookupModule_run
        """

# Generated at 2022-06-21 06:16:26.925257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Basic case for _hosts: all
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {'groups': {u'all': [u'localhost', u'localhost.localdomain', u'h01', u'h02']}}
    variable_manager.__contains__.return_value = True
    loader = Mock()
    loader.path_dwim.return_value = 'file'
    module._loader = loader
    module.run(terms=['all'], variables=variable_manager)

    # Basic case for _hosts: grass
    variable_manager = MagicMock()

# Generated at 2022-06-21 06:16:36.178772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    host_1 = Host(name='www-1', port=22)
    host_2 = Host(name='www-2', port=22)
    host_3 = Host(name='db-1', port=22)
    host_4 = Host(name='db-2', port=22)
    hosts = [host_1, host_2, host_3, host_4]
    group_db = Group('databases')
    group_www = Group('webservers')
    groups = [group_db, group_www]

# Generated at 2022-06-21 06:16:38.131169
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-21 06:16:40.784626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule("", "", "", "") is None

# Generated at 2022-06-21 06:16:53.697798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert(lm.run(terms="all",variables={"groups":{"all":["foo","bar"]}}) == ["foo","bar"])
    assert(lm.run(terms="all:!foo",variables={"groups":{"all":["foo","bar"]}}) == ["bar"])
    assert(lm.run(terms="all:foo",variables={"groups":{"all":["foo","bar"]}}) == ["foo"])
    assert(lm.run(terms="all:foo|bar",variables={"groups":{"all":["foo","bar"]}}) == ["bar","foo"])
    assert(lm.run(terms="all:&group1:&group2",variables={"groups":{"all":["foo","bar"],"group1":["foo"],"group2":["bar"]}})==["bar"])

# Generated at 2022-06-21 06:17:01.714245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plug_loader
    import sys
    pl = plug_loader.LookupModuleLoader()
    mod = pl.find_plugin('inventory_hostnames')
    inst = mod()

    terms = ['all:!www']
    variables = {'groups': {
        'all': ['localhost'],
        'webservers': ['www'],
        'www': ['www'],
        'databases': ['db'],
        'db': ['db']
    }}

    result = inst.run(terms, variables)

    assert result == [u'localhost']


# Generated at 2022-06-21 06:17:03.964768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module._loader is not None

# Generated at 2022-06-21 06:17:10.611201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostname_list_1 = ['all']
    variables_1 = {'groups': {'all': ['localhost']}}

    instance = LookupModule()
    output = instance.run(hostname_list_1, variables=variables_1)
    assert output == ['localhost']

    hostname_list_2 = ['all', '!localhost']
    variables_2 = {'groups': {'all': ['localhost', 'server1']}}

    output = instance.run(hostname_list_2, variables=variables_2)
    assert output == ['server1']



# Generated at 2022-06-21 06:17:11.151015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:17:19.192462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    class LoaderMock:
        def __init__(self):
            pass

    class InventoryManagerMock:
        def __init__(self):
            self.inventory_manager_mock = []
            self.add_group_call_count = 0
            self.add_host_call_count = 0
            self.get_hosts_call_count = 0

        def add_group(self, group_name):
            self.add_group_call_count += 1

        def add_host(self, host, group=None):
            self.add_host_call_count += 1

        def get_hosts(self, pattern=None):
            self.get_hosts_call_count += 1

# Generated at 2022-06-21 06:17:25.155638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(loader=None, templar=None, **{}), LookupModule)

# Generated at 2022-06-21 06:17:30.165546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case for happy path
    terms = 'all'
    inventory_hosts = ['127.0.0.1']
    variables = {'groups': {'all': [inventory_hosts[0]]}}
    class _Loader(object):
        def __init__(self): pass
    lookup = LookupModule(_Loader())
    assert lookup.run(terms, variables) == inventory_hosts

    # Test case where pattern does not match any host
    assert lookup.run('notfound', variables) == []

    # Test case where pattern is invalid
    with pytest.raises(AnsibleError):
        lookup.run('a*', variables)

# Generated at 2022-06-21 06:17:36.746363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['all']
    variables = {'groups': {'all': ['127.0.0.1'], 'webservers': ['127.0.0.2']}}
    l = LookupModule()
    result = l.run(terms, variables)
    assert result == ['127.0.0.1']

# Generated at 2022-06-21 06:17:38.687691
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert isinstance(lm, LookupModule)
  assert lm._loader is None


# Generated at 2022-06-21 06:17:45.148009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Method run of module class LookupModule should return a list and a non-empty list when a host pattern is given as argument."""
    lm = LookupModule()
    assert type(lm.run('all')) is list
    assert len(lm.run('all')) > 0

# Generated at 2022-06-21 06:17:45.758411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule({}, {}, None, None, None)

# Generated at 2022-06-21 06:17:49.055689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['*']
    variables = {'groups': {'group_01': ['all', '!www']}}
    # Unit test for method run of class LookupModule > True
    assert LookupModule().run(terms, variables) == ['all', '!www']

# Generated at 2022-06-21 06:17:51.132809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule(loader=None, templar=None)) is LookupModule

# Generated at 2022-06-21 06:18:03.014234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    hostvars = {
        'all': ['localhost', 'example.org', 'example.com'],
        'www': ['example.org'],
        'www-1': ['example.org'],
        'www-2': ['example.com'],
    }

    test_hostvars = {}

    for group, hosts in hostvars.items():
        for host in hosts:
            test_hostvars.setdefault(host, {})['group_names'] = set(hostvars.keys()) - set([host])
            test_hostvars[host]['group_names'].add(group)
            test_hostvars[host]['group_names'] = list(test_hostvars[host]['group_names'])

    lm = LookupModule(None, loader=None)
    lm

# Generated at 2022-06-21 06:18:11.466410
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests with correct parameters.
    host_variable1 = {'groups': {'all': ['node1', 'node2'], 'webs': ['node1', 'node2']}}
    host_variable2 = {'groups': {'all': ['node1', 'node2'], 'webs': ['node1', 'node2']}, '_host_pattern': 'all'}

    with pytest.raises(AnsibleError):
        assert LookupModule(None).run(terms=None, variables=host_variable1) == [u'node1', 'node2']

    with pytest.raises(AnsibleError):
        assert LookupModule(None).run(terms='', variables=host_variable2) == [u'node1', u'node2']


# Generated at 2022-06-21 06:18:27.386655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {}
    data['groups'] = {
      'test_group': ['test_host'],
    }
    data['_hostvars'] = {
      'test_host': {
        'some_variable': 'some_value',
      }
    }

    # test, that _hostvars is not part of the result
    terms = ['all']
    l = LookupModule()
    result = l.run(terms, data)
    assert result == ['test_host']

# Generated at 2022-06-21 06:18:35.116919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host_name = 'test'
    host = Host(name=host_name)
    inventory.add_host(host)
    variable_manager._hostvars = {host_name: dict()}
    variable_manager._hostvars[host_name]['ansible_inventory_sources'] = ['localhost,']

# Generated at 2022-06-21 06:18:35.580295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-21 06:18:41.657534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()

    # test basics
    my_lookup.run('all:!host1,host2')
    my_lookup.run(['all:!host1,host2', 'web:host1,host3'])

    # test that it works with Ansible variables
    my_lookup.run([], variables={'group_names': {'test1': ['host1', 'host2'], 'test2': ['host2']}, 'groups': {'test1': ['host1', 'host2'], 'test2': ['host2']}})

    # test if it works on an object
    class Dummy:
        def __init__(self, name, filename):
            self.name = name
            self.filename = filename

# Generated at 2022-06-21 06:18:46.159597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FauxInventory(object):
        def __init__(self):
            self.hosts = {}

        def get_hosts(self, terms):
            return [self.hosts[h] for h in terms]

    class FauxHost(object):
        def __init__(self, host_name):
            self.name = host_name
        def __repr__(self):
            return self.name

    # Without inventory_hostnames
    inventory_manager = FauxInventory()
    groups = {"foo": [FauxHost("host_1"), FauxHost("host_2"), FauxHost("host_3")]}
    lookup_module = LookupModule()
    assert lookup_module.run([], variables={'groups': groups}, inventory_manager=inventory_manager) == []

    # With inventory_hostnames


# Generated at 2022-06-21 06:18:58.184641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hosts_list = ["localhost", "remote1", "remote2", "remote3"]
    def get_hosts_method(pattern):
        return hosts_list

    manager = MockInventoryManager(get_hosts_method)
    lookup = LookupModule(manager)
    assert lookup.run("dummy") == hosts_list
    assert lookup.run("localhost") == ["localhost"]
    assert lookup.run("remote1") == ["remote1"]
    assert lookup.run("remote2") == ["remote2"]
    assert lookup.run("remote3") == ["remote3"]
    assert lookup.run("*") == hosts_list
    assert lookup.run("*3") == ["remote3"]
    assert lookup.run("remote*") == hosts_list[1:]
    assert lookup.run("remote*2") == ["remote2"]



# Generated at 2022-06-21 06:19:10.731083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_group_names(variables):
        group_names = []
        for group, hosts in variables['groups'].items():
            group_names.append(group)
        return group_names

    loader_mock = MagicMock()
    inventory_manager_mock = MagicMock()
    dummy_class = type('dummy_class', (object,), {})
    dummy_class.vars = {'groups': {'dummy_group' : ['dummy_host']}}
    lookup_module = LookupModule(loader=loader_mock)

    # Test when terms = 'all'
    terms = 'all'
    inventory_manager_mock.get_hosts.return_value = [dummy_class]
    loader_mock.get_basedir.return_value = ''
    ret = lookup

# Generated at 2022-06-21 06:19:22.310239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup_module = LookupModule()
    test_terms = "all"
    test_variables = {
        'inventory_dir': '',
        'inventory_file': '',
        'groups': {
            "all": {
                "hosts": {
                    "host1": {},
                    "host2": {},
                    "host3": {}
                },
                "children": {}
            },
            "www": {
                "hosts": {
                    "host4": {},
                    "host5": {},
                    "host6": {}
                },
                "children": {}
            }
        }
    }

    result = lookup_module.run(test_terms, test_variables)

# Generated at 2022-06-21 06:19:25.283250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("--- test_LookupModule ---")
    lookup_module = LookupModule()
    print(lookup_module)


# Generated at 2022-06-21 06:19:28.947357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert repr(module) == "<ansible.plugins.lookup.inventory_hostnames.LookupModule object at 0x7f66a53bc5d0>"
    assert module._loader is None
