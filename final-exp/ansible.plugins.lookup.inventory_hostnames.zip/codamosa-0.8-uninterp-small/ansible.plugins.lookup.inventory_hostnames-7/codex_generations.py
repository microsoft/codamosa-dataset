

# Generated at 2022-06-25 10:53:36.073515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0 = None
    lookup_module_0 = LookupModule()

# Unit testing for the class LookupModule

# Generated at 2022-06-25 10:53:37.066195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #assert(LookupModule.run() == )
    assert(True)


# Generated at 2022-06-25 10:53:47.515416
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule(5)
    lookup_module_1 = LookupModule('foo')
    lookup_module_2 = LookupModule(1)

    # In test case 0, the variable `terms` should be of type <class 'list'>.
    terms = ['foo']

    # In test case 0, the variable `variables` should be of type <class 'dict'>.
    variables = {
        'groups': {
            'test1': ['test2', 'test3'],
            'test4': [
                'test5', 'test6'
            ]
        }
    }

    # In test case 0, the variable `kwargs` should be of type <class 'dict'>.

# Generated at 2022-06-25 10:53:58.182685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # case 0
    float_0 = 1.8608462865
    lookup_module_0 = LookupModule(float_0)

    terms = [
            'tomcat-servers', 'openstack-servers', 'bastions'
    ]
    variables = {
            'groups': {
                    'bastions': [
                            'bastion_0', 'bastion_1', 'bastion_2'
                    ],
                    'openstack-servers': [
                            'openstack_0', 'openstack_1'
                    ],
                    'tomcat-servers': [
                            'tomcat_0', 'tomcat_1', 'tomcat_3', 'tomcat_4'
                    ]
            }
    }
    result = lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 10:54:07.416606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['a', 'b', 'c']
    var_1 = dict(
        a = dict(
            _meta = dict(
                hostvars = {}
            )
        ),
        b = dict(
            _meta = dict(
                hostvars = {}
            )
        ),
        c = dict(
            _meta = dict(
                hostvars = {}
            )
        )
    )
    lookup_module_0 = LookupModule(var_0)
    var_2 = 'a'
    actual = lookup_module_0.run(var_2, variables=var_1)
    assert actual == ['a'], actual



# Generated at 2022-06-25 10:54:14.136229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 99.73544
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run('-o')
    lookup_module_0.run('-o', '-v')

# main function
if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:54:16.489895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms='inventory_hostnames')

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:54:21.329768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = bool
    map_0 = map
    lookup_module_0 = LookupModule(map_0)
    str_0 = str
    list_0 = list
    lookup_module_0.run(list_0, str_0)


test_LookupModule_run()

# Generated at 2022-06-25 10:54:29.028742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2864.05479
    terms_0 = float_0
    variables_0 = float_0
    lookup_module_0 = LookupModule(float_0)
    try:
        result = lookup_module_0.run(terms_0, variables_0)
    except:
        result = True
    assert result

# Generated at 2022-06-25 10:54:37.646539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = 'foo'
    arg_1 = None
    arg_2 = 'foo'
    arg_3 = None
    arg_4 = 'foo'
    arg_5 = None
    arg_6 = 'foo'
    arg_7 = ['foo', 'foo', 'foo']
    arg_8 = ['foo', 'foo']
    arg_9 = ['foo', 'foo']
    arg_10 = 'foo'
    arg_11 = 'foo'
    arg_12 = None
    arg_13 = 'foo'
    arg_14 = ['foo', 'foo']
    arg_15 = 'foo'
    arg_16 = ['foo', 'foo']
    arg_17 = ['foo', 'foo']
    arg_18 = 'foo'
    arg_

# Generated at 2022-06-25 10:54:42.210549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run()

# Generated at 2022-06-25 10:54:46.464132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:54:52.988220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_module()
    terms_0 = 'terms_0'
    variables_0 = 'variables_0'
    test_run(lookup_module_0, terms_0, variables_0)
    lookup_module_0 = lookup_module()
    assert_equal(lookup_module_0.run(terms_0, variables_0), 'expected_0')
    

# Generated at 2022-06-25 10:54:54.917963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:54:56.677916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule._run_ansible_loop()) == 0

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:55:02.187437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # these tests just test the default implementation of the base class, but they do so
    # by running code, so we should keep them here rather than in a unit test.
    manager = InventoryManager(loader=None, sources=None)
    group = group('testg')
    assert group not in manager._inventory.groups
    assert group not in manager._inventory.hosts

    group.add_host(host(name='testh'))
    manager.add_group(group)

    assert group in manager._inventory.groups
    assert group in manager._inventory.hosts

    assert manager.get_hosts('testh') == [group]

    assert manager.get_groups('test*') == [group]

# Generated at 2022-06-25 10:55:09.027896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    terms = list(range(0,3))
    variables = {'groups':{'group1':['localhost'], 'group2':['localhost']}}
    assert_equal(lookup_module_0.run(terms, variables), ['127.0.0.1'], 'AssertionError')

# Generated at 2022-06-25 10:55:19.559803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    manager_0 = InventoryManager()
    manager_0.add_group('mysql_servers')
    manager_0.add_host('db001.test', group='mysql_servers')
    manager_0.add_host('db002.test', group='mysql_servers')
    manager_0.add_group('webservers')
    manager_0.add_host('web1.test', group='webservers')
    manager_0.add_host('web2.test', group='webservers')
    manager_0.add_host('web3.test', group='webservers')
    lookup_module_0 = LookupModule()
    bool_0 = bool()
    bool_1 = bool()

    # lookup_module_0.run(): AssertionError
    # lookup_

# Generated at 2022-06-25 10:55:23.254690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule()
    class_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 10:55:28.122147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0 = {u'groups': {}}
    list_0 = list()
    list_0.append(dict_0)
    list_0.append(u'all:!www')
    dict_0 = dict()
    dict_0 = {u'vars': {}}
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0, variables=dict_0)
    var_0 = lookup_module_0.run(list_0)
    return var_0

# Generated at 2022-06-25 10:55:41.375811
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:55:45.125770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'prop'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:55:48.720129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    inventory_manager_0 = InventoryManager()
    boolean_0 = true
    boolean_1 = false
    var_0 = lookup_module_0.run(inventory_manager_0, boolean_0, boolean_1)
    var_1 = lookup_module_0.run(inventory_manager_0, boolean_0)

# Generated at 2022-06-25 10:55:53.779752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:55:55.007108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()


# Generated at 2022-06-25 10:56:01.637018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_args = get_lookup_args(lookup_args_fixture)
    lookup_options = get_lookup_options(lookup_options_fixture)

    result = LookupModule.run(lookup_args, lookup_options)

    assert result == expected_return_value



# Generated at 2022-06-25 10:56:06.313305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 292.3
    string_0 = '*'
    lookup_module_0 = LookupModule(float_0)
    var_1 = lookup_module_0.run(string_0)



# Generated at 2022-06-25 10:56:07.379041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:56:10.486649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [['y'], [1]]
    lookup_module_0 = LookupModule()
    list_0 = lookup_module_0.run(list_1)

    assert(list_0 == [1])


# Generated at 2022-06-25 10:56:16.318460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.lookup import LookupBase

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms="terms_0")
    assert var_0 in [None, [], ""]

# Generated at 2022-06-25 10:56:23.466992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    var_0 = lookup_module_0.run(terms, variables)
    assert var_0 == ['b'], var_0

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:56:31.399398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host_1 = Host.get(name='jupiter')
    group_1 = Group.create(name='example')
    group_1.add_host(host_1)
    var_1 = dict(groups={'example': [host_1]})
    var_2 = ["example"]
    var_3 = dict(groups={'example': [host_1]})
    lookup_module_1 = LookupModule(var_1)
    var_4 = lookup_module_1.run(var_2, var_3)
    print("{} \n".format(var_4))

# Generated at 2022-06-25 10:56:34.356069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(True)
    assert True



# Generated at 2022-06-25 10:56:38.811983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1._loader
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 10:56:44.917305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'module'
    terms = 'test'
    variables = 'test'
    kwargs = 'test'
    lookup_module_1 = LookupModule(module)
    var_1 = lookup_module_1.run(terms, variables, kwargs)

# Generated at 2022-06-25 10:56:50.713654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 4862.2
    lookup_module_1 = LookupModule(float_1)
    lookup_module_1.run(terms, variables=None)

# Generated at 2022-06-25 10:56:55.061076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _hostnames = [u'w2k16']
    bool_0 = False
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_module_0.run(bool_0)
    assert var_0 == _hostnames


# Generated at 2022-06-25 10:57:02.845203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(42.5)
    terms_1 = "ho"

# Generated at 2022-06-25 10:57:04.367922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(Terms, Variables) == LookupModule(Terms, Variables)

# Generated at 2022-06-25 10:57:07.218397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run of LookupModule")
    lookup_module_0 = LookupModule()
    value = lookup_run()
    assert value == None

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:57:43.992589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  bool_run = True
  float_run = 4862.2
  lookup_module_run = LookupModule(float_run)
  var_run = lookup_module_run.run()
  assert var_run == [], "Expected [], but got %s" % var_run



# Generated at 2022-06-25 10:57:55.990310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 5487.9
    lookup_module_0 = LookupModule(float_0)
    int_0 = 992
    float_1 = 1407.8
    bool_0 = True
    bool_1 = True
    dict_0 = dict()
    dict_0['groups'] = dict()
    dict_0['groups']['localhost'] = ['localhost']
    dict_0['groups']['all'] = ['localhost']
    str_0 = 'localhost'
    list_0 = list()
    list_0.append(str_0)
    dict_0['groups']['groupa'] = list_0
    dict_0['groups']['groupb'] = list_0
    dict_0['groups']['groupc'] = list_0

# Generated at 2022-06-25 10:58:00.199479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assume that the groups dictionary of the Ansible inventory is provided to format of {hostname: [groups]}
    groups = {
        'host_0': ['group_0'],
        'host_1': ['group_1'],
        'host_2': ['group_2'],
        'host_3': ['group_2', 'group_0', 'group_1']
    }
    var_0 = LookupModule(0).run(['group_0'], {'groups': groups})
    assert var_0 == ['host_0', 'host_3']
    var_1 = LookupModule(0).run(['group_1'], {'groups': groups})
    assert var_1 == ['host_1', 'host_3']

# Generated at 2022-06-25 10:58:05.869115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule(False)
    class_0.lookup_module_0 = test_case_0()
    args = [1, 2, 3]
    class_0.run(args)

# Generated at 2022-06-25 10:58:10.612613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:58:14.486350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(LookupModule)
    lookup_module_0.run(None, None)

# Generated at 2022-06-25 10:58:18.099547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_run(bool_0)



# Generated at 2022-06-25 10:58:24.374541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    int_0 = 20
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(bool_0)



# Generated at 2022-06-25 10:58:30.692517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    manager_0 = InventoryManager(list_0, 'b-0')
    float_0 = 0.0
    var_0 = manager_0.get_hosts(pattern=float_0)
    var_1 = LookupModule(var_0)
    var_1.run('', variables=dict_0)


# Generated at 2022-06-25 10:58:35.871889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = set(['list_0'])
    float_0 = iter(set(['list_0']))
    str_0 = set(['list_0'])
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run(bool_0, list_0=str_0)


# Generated at 2022-06-25 10:58:53.693454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1.623E+2
    str_0 = "O"
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_module_0.run(str_0)
    print(var_0)
    print(var_0)
    print(var_0)

# Generated at 2022-06-25 10:58:55.546218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = run(bool_0)


# Generated at 2022-06-25 10:59:00.196625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(float_0)

    # No exception should be raised
    try:
        lookup_module_0.run(terms, variables=None)
    except Exception as e:
        assert False, 'No exception should have been raised'


# Generated at 2022-06-25 10:59:07.648403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_run(bool_0)
    assert var_0


# Generated at 2022-06-25 10:59:09.121791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() is None

# Generated at 2022-06-25 10:59:12.171952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3513.4
    lookup_module_0 = LookupModule(float_0)
    # test for argument 'terms'
    terms_0 = 11512.1
    # test returned value from function.
    assert lookup_module_0.run(terms=terms_0) is not False


# Generated at 2022-06-25 10:59:18.566584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words_0 = [][10]
    number_0 = 27.21
    lookup_module_0 = LookupModule(words_0)
    lookup_module_0.run(words_0, number_0)
    number_1 = 3781.47
    lookup_module_0.run(words_0, number_1)
    words_1 = [][0].split()
    lookup_module_0 = LookupModule(words_1)
    lookup_module_0.run(words_1, number_0)
    lookup_module_0.run(words_1, number_1)


# Generated at 2022-06-25 10:59:25.110113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    str_0 = 'y'
    list_0 = [str_0]
    dict_0 = {'b': list_0, 'str_0': str_0}
    str_1 = lookup_run(float_0, dict_0)
    assert str_1 == 'y'


# Generated at 2022-06-25 10:59:27.075054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:59:29.815255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 8927.59
    lookup_module_0 = LookupModule(float_0)
    str_0 = lookup_module_0.run(bool_0)
    print(str_0)

# Generated at 2022-06-25 11:00:01.497706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 11:00:04.460669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(LookupModule.run())


# Generated at 2022-06-25 11:00:07.595432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms, variables=dict(groups=dict())) == [h.name for h in InventoryManager(lookup_module_0._loader, parse=False).get_hosts(pattern=terms)]

# Generated at 2022-06-25 11:00:11.690704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ["foo", "bar"]
    str_0 = "foo"
    bool_0 = True
    str_1 = str(list_0)
    lookup_module_0 = LookupModule(str_1)
    assert isinstance(lookup_module_0.run(str_0, bool_0), list) is True

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:00:13.293784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 90109.0
    list_0 = []
    list_0 = lookup_module_0.run(float_0)

# Generated at 2022-06-25 11:00:17.621071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(object())
    assert(lookup_module.run(['a'], 'b') == [])

# Generated at 2022-06-25 11:00:19.758364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(argments_0)
    lookup_module_0.run(terms_0)
    #assert var_0 == var_0

# Generated at 2022-06-25 11:00:21.954558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_0 = 4862.2
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:00:24.890309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = 5714.0
    str_0 = 'host_0'
    dict_0 = {str_0: list_0}
    lookup_module_0 = LookupModule(float_0)
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:00:26.483397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = {'inv_name': ['test_host', 'test_host2'],
                'inv_group': ['all', 'test_group']}

# Generated at 2022-06-25 11:01:30.903638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters
    terms = None
    variables = None
    test_LookupModule_run_INPUT = 1
    lookup_module_0 = LookupModule(test_LookupModule_run_INPUT)
    assert terms is None
    assert variables is None
    # test result of method run
    lookup_module_0.run(terms, variables)
    return

# Generated at 2022-06-25 11:01:43.901344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    float_1 = 4862.2
    lookup_module_0 = LookupModule(float_1)
    list_0 = []
    str_0 = str()
    str_1 = str('sdossett@panath.com')
    str_2 = str('Michael DeHaan')
    str_3 = str()
    int_0 = 4862
    int_1 = 4862
    int_2 = 4862
    list_1 = []
    int_3 = 4862
    lookup_module_0.run(list_0, {'groups': {str_0: [str_1, str_2], str_3: [int_0, int_1, int_2, list_1, int_3]}})

# Generated at 2022-06-25 11:01:46.539714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        self.run_0()
        self.run_1()
        self.run_2()
        self.run_3()
    except LookupError:
        self.fail('Raised LookupError')
        raise


# Generated at 2022-06-25 11:01:57.723667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == 1

#	- name: show all the hosts matching the pattern, i.e. all but the group www
#	  debug:
#	    msg: "{{ item }}"
#	  with_inventory_hostnames:
#	    - all:!www
#
#	- name: show all the hosts matching the pattern, i.e. web+ with www in the name
#	  debug:
#	    msg: "{{ item }}"
#	  with_inventory_hostnames:
#	    - all:web+:www
#
#	- name: show all the hosts matching the pattern, i.e. web+ with www in the name and all hosts
#	  debug:
#	    msg: "{{ item }}"
#	  with_inventory_hostnames:
#	   

# Generated at 2022-06-25 11:01:59.029867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = True
    var_1 = 4862.2
    lookup_module_0 = LookupModule(var_1)
    var_2 = lookup_run(var_0)

# Generated at 2022-06-25 11:02:05.412727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(False)
    terms = [[["all"], ["!www"]]]
    variables = {'groups': {'group2': ['host1'], 'group1': ['host2', 'host3'], 'group3': ['host2']}}
    assert ["host2","host3"] == lookup_module_0.run(terms, variables)
    terms = [[["all"], ["!group1"]]]
    variables = {'groups': {'group2': ['host1'], 'group1': ['host2', 'host3'], 'group3': ['host2']}}
    assert ["host1"] == lookup_module_0.run(terms, variables)
    terms = [[["all"], ["!host2"]]]

# Generated at 2022-06-25 11:02:05.859460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:02:13.274987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host_names = ["test_host1", "test_host2"]
    groups = {"test_group": host_names}
    test_terms = "test_host1"
    test_vars = {"groups": groups}
    test_loader = "test_loader"
    test_load = LookupModule(test_loader, test_vars)
    expected_result = ["test_host1"]
    assert test_load.run(test_terms, test_vars) == expected_result


# Generated at 2022-06-25 11:02:14.611562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:02:15.317459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False