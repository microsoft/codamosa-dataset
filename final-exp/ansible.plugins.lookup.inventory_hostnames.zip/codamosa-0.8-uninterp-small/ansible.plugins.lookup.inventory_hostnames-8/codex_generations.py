

# Generated at 2022-06-25 10:53:40.207016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inventory_manager_0 = InventoryManager('/root/ansible/ansible/plugins/inventory')
    str_0 = 'foo'
    set_0 = {'groups': {'bar': ['foo']}}
    list_0 = [str_0]
    list_4 = [list_0]
    str_1 = 'bar'
    list_1 = [str_1]
    list_5 = [list_1]
    dict_0 = dict(zip(list_4, list_5))

    try:
        assert (lookup_module_0.run(list_0, dict_0) == list_0)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 10:53:42.967899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 10:53:46.748344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "all"
    variables_0 = {}
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    

# Generated at 2022-06-25 10:53:55.538353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.run('all',
                            variables=None,
                            loader=None)
    with pytest.raises(AnsibleError):
        lookup_module_0.run('p1,p2',
                            variables=None,
                            loader=None)
    lookup_module_0.run('all',
                            variables=None,
                            loader=None)
    with pytest.raises(AnsibleError):
        lookup_module_0.run('p1,p2',
                            variables=None,
                            loader=None)

# Generated at 2022-06-25 10:53:58.012662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) is None

# Generated at 2022-06-25 10:54:08.595143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = [{'groups': {'group': ['hostname']}}]
    result = ['hostname']
    assert lookup_module_0.run(terms, variables=variables) == result

    my_var_0 = 'all:!www'
    terms = [my_var_0]
    variables = [{'groups': {'all': ['host1', 'host2', 'host3'], 'www': ['host2', 'host3'], 'deploy': ['host1']}}]
    result = ['host1', 'host2', 'host3']
    assert lookup_module_0.run(terms, variables=variables) == result

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:54:18.364592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = '''all:!www'''
    variables = dict()
    variables['groups'] = dict()

    variables['groups']['all'] = list()
    variables['groups']['all'].append('''h1''')
    variables['groups']['all'].append('''h2''')

    variables['groups']['www'] = list()
    variables['groups']['www'].append('''h1''')
    variables['groups']['www'].append('''h2''')
    variables['groups']['www'].append('''h3''')
    variables['groups']['www'].append('''h4''')

    variables['groups']['db'] = list()

# Generated at 2022-06-25 10:54:26.765219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_groups_0 = {}
  var_groups_0['first_group'] = ['a', 'b', 'c']
  var_groups_0['second_group'] = ['d']
  var_groups_0['third_group'] = ['a', 'b', 'e']
  var_groups_0['fourth_group'] = ['f', 'g', 'h']
  var_variables_0 = {}
  var_variables_0['groups'] = var_groups_0
  terms_0 = 'all'
  terms_0 = terms_0.split()
  ret_0 = lookup_module_0.run(terms_0, variables=var_variables_0)
  print(ret_0)


# Generated at 2022-06-25 10:54:28.805633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:54:33.187263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    data = {'groups': {u'all': [u'host1', u'host11', u'host2', u'host3'], u'www': [u'host1', u'host11']}}
    terms = ['all:!www']
    result = lookup_module_obj.run(terms, data)

    assert result == ['host2', 'host3']

# Generated at 2022-06-25 10:54:40.037743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inventory_path = 'examples/ansible_hosts'
    loader = None
    manager = InventoryManager(loader, sources=inventory_path)
    variables = None
    terms = '*'
    lookup_module = LookupModule()
    result = lookup_module.run(terms=terms, variables=variables)

    assert len(result) == 5
    assert 'www0' in result
    assert 'db0' in result
    assert 'db1' in result
    assert 'db2' in result
    assert 'db3' in result

# Generated at 2022-06-25 10:54:44.155994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_variable_0 = {'groups': {'group1': ['host1', 'host2', 'host3', 'host4']}}
    assert lookup_module_0.run('all', variables=test_variable_0) == ['host1', 'host2', 'host3', 'host4']

# Generated at 2022-06-25 10:54:52.321521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms=['']
    variables={'ansible_host':'hostname', 'ansible_hostname':'hostname', 'groups': {'group1': {'host1', 'host2'}}, 'host_names': ['hostname', 'hostname'], 'inventory_hostname': 'hostname'}
    kwargs={}
    ret = lookup_module.run(terms=terms, variables=variables, **kwargs)
    assert ret == [h.name for h in manager.get_hosts(pattern=terms)]
    return ret


# Generated at 2022-06-25 10:54:56.954058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader.path_finder._paths.insert(0, "./test/files/lookup_plugins/inventory_hostnames")
    variables_0 = {"groups": {"all": ["host_a"], "not_all": ["host_a"], "host_a": ["host_a"], "host_b": ["host_b"], "not_host_a": ["host_b"], "not_host_b": ["host_a"], "all_group": ["host_a", "host_b"]}}
    lookup_module_0.run(["all"], variables_0)

# Generated at 2022-06-25 10:55:01.979549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader([('default', '', '', '')])
    # case 0
    assert(lookup_module.run([]) == [])
    # case 1
    assert(lookup_module.run(["all"]) == [])
    # case 2
    assert(lookup_module.run(["all", "!www"]) == [])
    # case 3
    assert(lookup_module.run(["all", "!www", "!other"]) == [])
    # case 4
    assert(lookup_module.run(["all", "!www", "!other", "!unknown"]) == [])

# Generated at 2022-06-25 10:55:06.361499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_args_0 = {
        '_loader': None,
        '_templar': None,
        '_inventory': None,
    }
    lookup_module_0 = LookupModule(**lookup_module_args_0)
    # Run the method
    test_case_0(lookup_module_0)
    # TBD


# Generated at 2022-06-25 10:55:17.008285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run(terms, variables={'groups': {u'all': [u'centos7'], u'webservers': [u'centos7']}})
    assert str(excinfo.value) == "No match found for search: ['all']"

    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run(terms, variables={'groups': {u'all': [u'centos7'], u'webservers': [u'centos7']}})
    assert str(excinfo.value) == "No match found for search: ['all']"


# Generated at 2022-06-25 10:55:25.250984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inventory_manager_0 = InventoryManager(loader=None, parse=False)
    names_0 = ['group_names']
    hosts_0 = [
        'a.example.com', 'b.example.com', 'c.example.com',
        'd.example.com', 'e.example.com', 'f.example.com'
    ]
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([1, 2, 3], variables=dict(zip(names_0, hosts_0))) == []


# Generated at 2022-06-25 10:55:33.595007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variable 'inventory_manager' is a LookupModule object
    inventory_manager = LookupModule()

    # Variable 'matrix' is a dict that contains the arguments to be passed to the test cases

# Generated at 2022-06-25 10:55:38.021282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    method = lookup_module.run()
    assert isinstance(method, list)
    assert isinstance(method, list)

# Generated at 2022-06-25 10:55:42.658275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()

    # Test with valid arguments
    lookup_module_run.run(terms=['test'])

    # Test with bad arguments
    try:
        lookup_module_run.run(terms='')
    except:
        pass

# Generated at 2022-06-25 10:55:47.825241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ''
    variables_2 = dict()
    variables_2['groups'] = dict()
    variables_2['groups']['www'] = []
    variables_2['groups']['www'].append('10.12.85.4')
    variables_2['groups']['www'].append('10.12.85.47')
    variables_2['groups']['www'].append('10.12.85.49')
    variables_2['groups']['www'].append('10.12.85.50')
    variables_2['groups']['www'].append('10.12.85.6')
    variables_2['groups']['www'].append('10.12.85.8')

# Generated at 2022-06-25 10:55:50.159040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:55:52.038353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule().run(terms=['all']), list)
    assert isinstance(LookupModule().run(terms=['all:!www']), list)

# Generated at 2022-06-25 10:55:57.476233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = MockLoader()
    lookup_module_0.run(terms, variables=None)
    assert lookup_module_0._loader.get_basedir.call_count == 1
    lookup_module_0._loader.get_basedir.assert_called_with(terms)


import collections

MockLoader = collections.namedtuple('MockLoader', ['get_basedir'])
terms = 'terms'
lookup_module_0 = None # type: LookupModule

# Generated at 2022-06-25 10:55:59.943159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    return_value = lookup_module_0.run(terms, variables)
    assert return_value
    assert type(return_value) == list

# Generated at 2022-06-25 10:56:09.525229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['any hostname']
    inventory_manager_0 = InventoryManager(lookup_module_0._loader, parse=False)
    for group_0, hosts_0 in variables['groups'].items():
        inventory_manager_0.add_group(group_0)
        for host_0 in hosts_0:
            inventory_manager_0.add_host(host_0, group=group_0)

    returned_value_0 = inventory_manager_0.get_hosts(pattern=terms_0)
    try:
        assert [h.name for h in returned_value_0] == [h.name for h in returned_value_0]
    except AssertionError:
        return
    return

# Testing method run of class LookupModule

# Generated at 2022-06-25 10:56:11.653976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run(terms, variables=None, **kwargs)
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 10:56:17.522520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'test_terms_0'
    variables_0 = 'test_variables_0'
    kwargs_0 = 'test_kwargs_0'
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == []

# Generated at 2022-06-25 10:56:20.231937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run()
    assert result_0 is None
    result_1 = lookup_module_0.run()
    assert result_1 == []


# Generated at 2022-06-25 10:56:33.941924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    hostname_match_0 = ['test_hostname']
    terms_0 = ['test_hostname']
    variables_0 = {'groups': {'group_name_0': hostname_match_0}}
    kwargs_0 = {'wantlist': False}
    x_0 = lookup_module_1.run(terms_0, variables_0, **kwargs_0)
    assert x_0 == hostname_match_0

    hostname_match_1 = ['test_hostname_0', 'test_hostname_1', 'test_hostname_2']
    terms_1 = ['test_hostname_?', 'test_hostname_1']
    variables_1 = {'groups': {'group_name_0': hostname_match_1}}

# Generated at 2022-06-25 10:56:40.513407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate a mocked LookupModule object
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    lookup_module_0._templar = MockTemplar()
    lookup_module_0._loader = MockLoader()

    # Create a parameter for the run method
    params = MockParams()

    # Call the run method of the LookupModule object with the mocked parameter
    result = lookup_module_0.run(params)

    # Check the result
    assert result  == []


# Generated at 2022-06-25 10:56:44.602021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0.run(None, None)
    lookup_module_0.run(terms=[None], variables=None)

# Generated at 2022-06-25 10:56:51.357681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = ()
    kwargs = {'terms': "test"}

    # AssertionError: 'LookupModule' object is not callable
    #assert lookup_module_0.run(*args, **kwargs) == expected_0

# Generated at 2022-06-25 10:56:53.904906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run([], {}), list)



# Generated at 2022-06-25 10:56:55.762128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0.run([])).__name__ == 'list'


# Generated at 2022-06-25 10:56:59.787604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test withterms with values
    withterms = "all"
    vars = {}
    lookup_module.run(withterms, variables=vars)
    # test withoutterms
    withoutterms = None
    vars = {}
    lookup_module.run(withoutterms, variables=vars)

# Generated at 2022-06-25 10:57:02.348889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = {'groups': {'my_group': ['my_host_0', 'my_host_1']}}
    assert lookup_module_0.run(['all'], x) == ['my_host_0', 'my_host_1']

# Generated at 2022-06-25 10:57:11.889152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._loader = MockAnsibleLoader()

    # Get inventory hostnames for group test, pattern all
    terms = ['all']
    results = lookup_module_1.run(terms, variables={'inventory_dir': '/path/to/inventory', 'groups': {'test': ['foo', 'bar']}}, **{'inventory_basedirs': ['/path/to/inventory']})
    assert len(results) == 2
    assert results == ['foo', 'bar']

    # Get inventory hostnames for group test, pattern foo
    terms = ['foo']

# Generated at 2022-06-25 10:57:20.937560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ['all']

    variables_1 = dict()
    variables_1['groups'] = dict()
    hosts_1 = dict()
    hosts_1['test2'] = dict()
    hosts_1['test2']['hostname'] = 'test2'
    hosts_1['test2']['groups'] = ['test']
    hosts_1['test2']['vars'] = dict()
    hosts_1['test2']['vars']['ansible_host'] = '127.0.0.1'
    hosts_1['test2']['vars']['ansible_port'] = 2222
    hosts_1['test3'] = dict()
    hosts_1['test3']['hostname'] = 'test3'


# Generated at 2022-06-25 10:57:35.276597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Use specified inventory path to generate inventory.
    variables = {
        'groups': {
            'all': ['node1', 'node2', 'node3']
        }
    }
    terms = ['all']
    output = lookup_module.run(terms=terms, variables=variables)
    assert output == ['node1', 'node2', 'node3']


# Generated at 2022-06-25 10:57:38.691823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    objs = test_case_0()
    assert lookup_module_0.run(terms=[''], variables={'groups': {}}) == [], " lookup_module_0.run(terms=[''], variables={'groups': {}}) returned unexpected value"

# Generated at 2022-06-25 10:57:45.675270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    lookup_module_0.run(terms_0, variables=variables_0)


if __name__ == '__main__':

    t = 'test_case_0'
    testlist = [x for x in locals().keys() if x.startswith(t)]
    for test in testlist:
        print('Running: {} ... '.format(test), end='')
        try:
            locals()[test]()
            print('OK')
        except Exception as e:
            print('ERROR: {}'.format(e))
            raise e

# Generated at 2022-06-25 10:57:49.901944
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class mock_self():
        def __init__(self):
            self._loader = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(mock_self, terms, variables={'groups':{'a':['b', 'c'], 'd':['e']}})


# Generated at 2022-06-25 10:57:58.698889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['']
  variables = dict()
  variables['groups'] = dict()
  variables['groups']['group1'] = ['']
  variables['groups']['group1'][0] = 'host1'
  variables['groups']['group1'].append('host2')
  variables['groups']['group2'] = ['']
  variables['groups']['group2'][0] = 'host3'
  variables['groups']['group2'].append('host4')
  lookup_module = LookupModule()
  result = lookup_module.run(terms, variables)
  assert result == ['host1', 'host2', 'host3', 'host4']



# Generated at 2022-06-25 10:58:05.127638
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Successful run
    # --------------------------------------
    hostvars = {
        'groups': {
            'all': ['host1', 'host2', 'host3'],
            'webservers': ['host1', 'host2'],
        },
    }

    terms = "all"

    ret = lookup_module.run(terms=terms, variables=hostvars)

    assert(len(ret) == 3)
    assert('host1' in ret)
    assert('host2' in ret)
    assert('host3' in ret)

    terms = "all:!host1"
    ret = lookup_module.run(terms=terms, variables=hostvars)

    assert(len(ret) == 2)
    assert('host2' in ret)

# Generated at 2022-06-25 10:58:11.467695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['all']
    variables_0 = {'groups': {'UNKNOWN': ['ansible.example.com']}}
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:58:15.880754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms,variables)

# Generated at 2022-06-25 10:58:18.749325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar']
    variables_0 = { 'groups': { 'foogroup': {}, 'bargroup': {} } }
    lookup_module_0.run(terms_0, variables=variables_0)

# Generated at 2022-06-25 10:58:20.628024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    hosts = {'all': ['localhost']}
    lookup_module.run(terms=None, variables={'groups': hosts}, loader=None)

# Generated at 2022-06-25 10:58:42.883524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(DictDataLoader())
    vars = {"groups": {"all": ["localhost","127.0.0.1"], "webservers": ["192.168.0.1"], "www": ["192.168.0.2"]}}

    # Test case with args - terms = [all:!www]
    result = lookup_module_0.run(["all:!www"], variables=vars)
    assert result[0] == 'localhost'
    assert result[1] == '127.0.0.1'
    assert result[2] == '192.168.0.1'

# Test class for class LookupModule

# Generated at 2022-06-25 10:58:51.781764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host_1 = '127.0.0.1'
    host_2 = '127.0.0.3'
    host_3 = '127.0.0.4'
    host_4 = '127.0.0.6'
    host_list_1 = [host_1]
    host_list_2 = [host_2]
    host_list_3 = [host_3]
    host_list_4 = [host_4]
    group_1 = 'host_group_1'
    group_2 = 'host_group_2'
    group_3 = 'host_group_3'
    group_4 = 'host_group_4'
    group_list_1 = [group_1]
    group_list_2 = [group_2]

# Generated at 2022-06-25 10:58:58.187677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test arguments
    terms = ['']
    variables = {'groups':{'group_vars':['host_vars']}}
    kwargs = {}

    # Execute the run function
    ret = test_case_0.run(terms, variables, **kwargs)

    # Check if the return value is correct
    assert ret == []

# Generated at 2022-06-25 10:59:05.374864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case 0
    # checking special case when
    # get_hosts calls method get_hosts
    # and method get_hosts returs an empty list
    # get_group returns a list
    # get_group returns an empty list
    # method get_hosts returns an empty list
    # and method get_hosts returns an empty list
    # and method get_hosts returns an empty list
    # and method get_hosts returns an empty list


# Generated at 2022-06-25 10:59:14.179018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.run('any')
    lookup_module.run('all')
    lookup_module.run('all:!www')
    lookup_module.run('webservers')
    lookup_module.run('x')
    lookup_module.run('x:!y')
    lookup_module.run('!y:!z')
    lookup_module.run('x:!y:!z')
    lookup_module.run('y:!z')
    lookup_module.run('!z')
    lookup_module.run('!y:z')
    lookup_module.run('y:!z:x')
    lookup_module.run('!:!z:x')
    lookup_module.run('y:!z:!x')

# Generated at 2022-06-25 10:59:17.066878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 10:59:24.095771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic test on a hostname
    lookup_module_0 = LookupModule()
    terms = "toto"
    variables = {'groups': {'group_1': ['toto']}}
    result_0 = lookup_module_0.run(terms, variables=variables)
    result = ["toto"]
    assert result_0 == result


# Generated at 2022-06-25 10:59:32.122789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'foo',
        'bar',
        'baz',
    ]
    variables_0 = {
        'groups': {
            'foo': [
                'bar',
            ],
            'baz': [
                'bar',
            ],
            'bar': [
                'bar',
            ],
        },
    }
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == ['bar']

# Generated at 2022-06-25 10:59:34.607820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {'value': 'value0'}
    kwargs_0 = {'variable': 'variable0'}
    assert lookup_module_0.run(terms_0, kwargs_0) == []

# Generated at 2022-06-25 10:59:39.341702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = ""
    lookup_module_0._templar = ""
    lookup_module_0.set_options('')
    lookup_module_0.run('', {'groups': {'www': {'kali'}}})
    lookup_module_0.run([], {'groups': {'www': {'kali'}}})
    lookup_module_0.run('', '', {})

# Generated at 2022-06-25 11:00:18.071231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
      "deployer",
      "deployer1",
      "deployer2",
      "deployer1.internal",
      "deployer2.internal",
    ]
    variables_0 = {
      "groups": {
        "deployer1": [
          "deployer11",
          "deployer12",
        ],
        "deployer2": [
          "deployer21",
          "deployer22",
        ],
        "deployer": [
          "deployer1",
          "deployer2",
        ],
      },
    }

# Generated at 2022-06-25 11:00:24.394237
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms = [
        "all:!www"
    ]

    variables={"groups": {"all": ['"127.0.0.1"', '"localhost"']}}
    assert lookup_module_0.run(terms, variables=variables) == ['"127.0.0.1"', '"localhost"']


# Generated at 2022-06-25 11:00:28.946925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    manager = InventoryManager(lookup_module._loader)
    manager.add_group('group1')
    manager.add_group('group2')
    manager.add_host('localhost', group='group1', port=22)
    manager.add_host('127.0.0.1', group='group2', port=23)
    variables = {'groups': manager.groups}
    terms = ['localhost', '127.0.0.1']
    result = lookup_module.run(terms, variables)
    assert result == ['localhost', '127.0.0.1']


# Generated at 2022-06-25 11:00:30.896832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = {}
    variables_0 = {}
    kwargs_0 = {}
    returned_value_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:00:35.432838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_2 = LookupModule()
  hosts = ["dummy1", "dummy2"]
  groups = {"test": hosts}
  variables = {"groups": groups}
  assert lookup_module_2.run(terms=['test'], variables=variables) == hosts
  assert lookup_module_2.run(terms=['all', 'test'], variables=variables) == hosts

# Generated at 2022-06-25 11:00:41.421277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['all:!www'], variables={'groups': {'www': ['web.example.com'], 'all': ['web.example.com', 'db.example.com']}}) == ['web.example.com', 'db.example.com']



# Generated at 2022-06-25 11:00:44.104255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['', ''], variables=None, kwargs=None)
    lookup_module_0._loader.get_basedir(['', ''])
    lookup_module_0._loader.path_dwim(['', ''])

# Generated at 2022-06-25 11:00:50.182974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = ''
    kwargs = ''
    lookup_module_1 = LookupModule()
    lookup_module_1._loader = ''
    result = lookup_module_1.run(terms, variables, kwargs)
    assert result == []

# Generated at 2022-06-25 11:00:57.837206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = [{'_hostvars': {'ansible_host': '127.0.0.1.xip.io', 'ansible_connection': 'local', 'ansible_port': '22', 'ansible_user': 'vagrant', 'ansible_password': 'vagrant', 'ansible_ssh_pass': 'vagrant', 'ansible_sudo_pass': 'vagrant', 'ansible_become_password': 'vagrant'}, '_hostname': '127.0.0.1.xip.io', '_pattern': None, '_terms': ['all'], '_ordered_terms': ['all']}]
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['all'])==result

# Generated at 2022-06-25 11:01:01.291825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    data_0 = [ 'all' ]
    data_1 = {}
    assertion_failed_0 = AssertionError()
    try:
        lookup_module_0.run(data_0, variables=data_1)
    except AssertionError:
        raise assertion_failed_0

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:02:11.426575
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['www,app']) == []

# Generated at 2022-06-25 11:02:19.378707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    hosts = [
        'host1',
        'host2',
        'host3'
    ]
    lookup_module_0.set_options(
        direct=dict(
            _hosts=hosts
        )
    )
    terms = [
        'host3'
    ]
    variables = {
        'groups': {
            'test_group': hosts
        }
    }
    test_list = [
        'host3',
    ]
    test_list_0 = lookup_module_0.run(terms, variables)
    assert test_list_0 == test_list

# Generated at 2022-06-25 11:02:23.931762
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = ["all:!www"]
    variables = {}
    variables['groups'] = {}
    variables['groups'] = {'all': {'host1', 'host2', 'host3'}, 'www': {'host4'}}

    hostnames = ['host1', 'host2', 'host3']

    # Test when called with good parameters.
    assert lookup_module.run(terms, variables=variables) == hostnames

# Generated at 2022-06-25 11:02:28.239497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'all'
    variables = {'groups': {'www': ['127.0.0.1', '127.0.0.3']}}
    lookup_module_0.run(terms_0, variables=variables)

test_LookupModule_run()

# Generated at 2022-06-25 11:02:36.532324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'all'
    variables_0 = {'groups': {'group_names': ['group_names_0']}}
    # kwargs = {'wantlist': True}
    # kwargs = dict(wantlist=True)
    kwargs = dict(wantlist=True)
    result_test_case_0 = lookup_module_0.run(terms_0, variables_0, **kwargs)
    assert result_test_case_0 == ['group_names_0']

# from units.mock.loader import DictDataLoader
# from units.plugins.inventory import InventoryPlugin
# from ansible.inventory.manager import InventoryManager
# from ansible.vars import VariableManager

# loader = DictDataLoader({
#     'hosts':

# Generated at 2022-06-25 11:02:40.665919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   assert lookup_module_0 != None

# Generated at 2022-06-25 11:02:43.279889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms={'ansible_ssh_port': 22}, variables={'groups': {'all': ['localhost']}})
    assert len(result) == 1

# Generated at 2022-06-25 11:02:45.087841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ""
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:02:51.849261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms=['all'], variables={"groups": {"group_name_0": ["hostname_0"]}}), list)
    assert not isinstance(lookup_module.run(terms=['all'], variables={"groups": {"group_name_0": ["hostname_0"]}}), str)
    assert not isinstance(lookup_module.run(terms=['all'], variables={"groups": {"group_name_0": ["hostname_0"]}}), tuple)
    assert not isinstance(lookup_module.run(terms=['all'], variables={"groups": {"group_name_0": ["hostname_0"]}}), set)

# Generated at 2022-06-25 11:03:01.808610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    terms_0 = (
        'all',
    )
    variables_0 = dict()
    variables_0['groups'] = dict()
    variables_0['groups']['all'] = (
        'foo',
        'bar',
    )
    variables_0['groups']['web'] = (
        'foo',
    )
    kwargs_0 = dict()
    result = lookup_module_0.run(terms_0, variables=variables_0, **kwargs_0)
    assert result == ['foo', 'bar']
