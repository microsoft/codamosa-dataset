

# Generated at 2022-06-25 10:53:40.245653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xfa\xfaa\x8c\xa0n\xf7\xde\x16\x9b\xcc\x15\x05'
    lookup_module_0 = LookupModule(bytes_0)
    arguments_0 = {'variables': None}
    terms = [""]
    test_0 = lookup_module_0.run(terms, arguments_0)

    assert test_0 == []
    bytes_0 = b"\xcb\xcf\xee%_\xac\x7f\xce\xc8\x97\x88\xe7\xc0"
    lookup_module_0 = LookupModule(bytes_0)
    arguments_0 = {'variables': None}
    terms = [""]

# Generated at 2022-06-25 10:53:45.537086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xe6\xf7\xfan\xe9\xac\x82gA\xb0\x95\xf1`d='
    
    # Check for exceptions
    try:
        lookup_module_0.run(bytes_0, bytes_0)
    except Exception:
        pass
    else:
        assert 0

# Generated at 2022-06-25 10:53:52.402957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xe6\xf7\xfan\xe9\xac\x82gA\xb0\x95\xf1`d='
    lookup_module_0 = LookupModule(bytes_0)
    dict_0 = dict()
    dict_0['_terms'] = list()
    dict_0['_variables'] = dict()
    dict_0['_loader'] = lookup_module_0._loader
    dict_0['groups'] = dict()

    # Call method run of LookupModule
    lookup_module_0.run(**dict_0)

# Generated at 2022-06-25 10:53:55.577230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Return type test
    assert isinstance(test_case_0(), list)


# Generated at 2022-06-25 10:54:03.493995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xe6\xf7\xfan\xe9\xac\x82gA\xb0\x95\xf1`d='
    lookup_module_0 = LookupModule(bytes_0)
    class_0 = {b'groups': {b'group_names': [b'group_names'], b'group_vars': {b'group_vars': b'group_vars'}, b'groups': {b'subgroup': b'subgroup'}, b'all': {b'hosts': [b'host_0', b'host_1']}, b'hostvars': {b'host_0': {b'host_0': b'host_0'}, b'host_1': {b'host_1': b'host_1'}}}}
    bytes_1 = b

# Generated at 2022-06-25 10:54:04.012941
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert test_case_0() == "The test case is empty."

# Generated at 2022-06-25 10:54:06.836821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run("hadoop-master")
    assert result == ['hadoop-master']

# Generated at 2022-06-25 10:54:09.146749
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule('', '')
    lookup_module_0.run([], {})
    lookup_module_0_1 = LookupModule('', '')
    lookup_module_0_1.run([], {})


# Generated at 2022-06-25 10:54:18.078148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd0\xf6\x0c\xbb\xad\x98\xa6\x82\xbf\xe8\xea\xa7\xa5\xc7'
    lookup_module_0 = LookupModule(bytes_0)
    terms = [None]
    variables = {}
    variables['groups'] = {'group_1': ['host_0', 'host_1']}
    kwargs = {}
    kwargs['variables'] = variables
    _hostnames = lookup_module_0.run(terms, **kwargs)
    assert _hostnames == ['host_0', 'host_1']


# Generated at 2022-06-25 10:54:21.533358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'\x8e\x94\xcc\x13\xf6\x8fU\x80\xd1\x9a\xab\x7f\xcc\xda')
    str_0 = '\x85\xc3\x98\xca\x8c\xee;\xad\xbc\xbd\xb1\xac\xec\xb5\x84O\xde'
    list_0 = []
    dict_0 = {}
    assert lookup_module_0.run(str_0, variables=dict_0) == list_0


# Generated at 2022-06-25 10:54:31.483082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    variables_1 = {'groups': {'group_1': ['host_1', 'host_2']}}
    terms_1 = ['all:!group_I']
    result_1 = lookup_module_1.run(terms_1, variables_1, **{})
    assert result_1 == []

# Generated at 2022-06-25 10:54:38.297934
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=['ansible_windows'], variables={'groups': {'all': ['192.168.56.10', 'localhost', '192.168.56.11'], 'test-nodes': ['192.168.56.10', '192.168.56.11'], 'unreachable': [], 'ok': ['192.168.56.10', '192.168.56.11'], 'all_unreachable': []}})
    assert result_0 == ['192.168.56.11']

# Generated at 2022-06-25 10:54:42.613000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(loader_1)
    assert lookup_module_0.run(terms=['all']) == ["all"]


# Generated at 2022-06-25 10:54:45.375695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run("all:!www")

# Generated at 2022-06-25 10:54:53.155292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
                'all',
                'all:!www',
                'all:&foo:bar:!baz'
            ]
    variables_0 = {
                    'groups': {
                                'all': ['foo', 'bar', 'baz'],
                                'foo': ['foo'],
                                'bar': ['bar'],
                                'baz': ['baz']
                            }
                    }
    names_0 = [
                'foo',
                'bar',
                'baz'
               ]
    res_0 = lookup_module_0.run(terms_0, variables=variables_0)
    assert all([name in res_0 for name in names_0])

# Generated at 2022-06-25 10:54:56.794521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=u'webservers.example.com', variables=None, **kwargs) == results

# Generated at 2022-06-25 10:54:58.796635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    variables_1 = {}
    terms_1 = 'foo'
    lookup_module_1.run(terms_1, variables=variables_1)


# Generated at 2022-06-25 10:55:08.718114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        "all",
        "!www"
    ]
    variables = {
        "groups": {
            "all": ["a", "b", "c"],
            "www": ["a", "b"],
            "webservers": ["foo.com", "bar.com"],
            "group_with_vars": {
                "hosts": [
                    "a"
                ],
                "vars": {
                    "var1": "foo"
                }
            }
        }
    }
    kwargs = {}
    ret_val = lookup_module.run(terms, variables, kwargs)
    assert ret_val == ['c']

# Generated at 2022-06-25 10:55:11.454835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms_0 = []
    var_variables_0 = {}
    var_kwargs_0 = {}
    data = lookup_module_0.run(var_terms_0, var_variables_0, **var_kwargs_0)



# Generated at 2022-06-25 10:55:16.920791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    inventory = {'group1': ['host1', 'host2', 'host3'], 'group2': ['host4', 'host5', 'host6'], 'group3': ['host7']}
    results = lookup.run(['group1:host1', 'group1:host3'], {'groups': inventory})
    assert results == ['group1:host1', 'group1:host3']
    results = lookup.run(['all:host2', 'group2'], {'groups': inventory})
    assert results == ['all:host2', 'group2']
    results = lookup.run(['all:host1', 'group3'], {'groups': inventory})
    assert results == ['all:host1', 'group3']

# Generated at 2022-06-25 10:55:24.143582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'all'
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule()
    results = lookup_module_0.run(terms, variables, **kwargs)
    assert results == []

# Generated at 2022-06-25 10:55:31.789123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['all']
    variables = {'groups': {'all': ['host1', 'host2']}}
    result = lookup_module_0.run(terms, variables=variables)
    assert result[0] == 'host1'
    assert result[1] == 'host2'
# END of unit tests

if __name__ == '__main__':
    print("Module 'inventory_hostnames' was successfully loaded")
    print("Executing Unit Tests")
    print("====================")
    print("")
    test_case_0()
    test_LookupModule_run()
    print("")
    print("Unit Tests completed")

# Generated at 2022-06-25 10:55:34.464585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'test_terms_0'
    variables = dict()
    kwargs = dict()
    ret = lookup_module_0.run(terms_0, variables=variables, **kwargs)
    assert ret == []

# Generated at 2022-06-25 10:55:43.745721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0.set_runner(None)
    # Case 0

# Generated at 2022-06-25 10:55:46.201262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_instance = lookup_module_0.run('terms')
  assert lookup_instance is None


# Generated at 2022-06-25 10:55:50.159524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None, variables=None, **None) is None

# Generated at 2022-06-25 10:55:53.224531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test with invalid group name
    assert lookup_module_1.run(('test_group'), variables={'groups': {'test_group': ['test_host1', 'test_host2']}}) == ['test_host1', 'test_host2']


# Generated at 2022-06-25 10:56:03.640846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_0._loader = None
    lookup_module_obj_0.get_basedir = lambda: 'C:\\Windows\\Temp\\'
    lookup_module_obj_0.set_options = lambda: None
    lookup_module_obj_0.run = lambda *arg: []

    # Unit test for method run of class LookupModule with args
    # [{'name': 'groups'}] and kwargs {}
    assert lookup_module_obj_0.run(terms=[{'name': 'groups'}], variables=None) == []

    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_0._loader = None

# Generated at 2022-06-25 10:56:09.288986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # @TODO
    # assert lookup_module_0.run(["[all:vars]"]) == [], 'Failed to assert test case 0'

# Generated at 2022-06-25 10:56:13.088642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    entities = {
        'groups': {
            'all': ['test']
        }
    }
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['all'], variables=entities)
    assert result == ['test']

# Generated at 2022-06-25 10:56:23.429131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0._inventory = None
    lookup_module_0._basedir = None
    lookup_module_0.myconfig = None
    lookup_module_0.myterms = None
    lookup_module_0.myvars = None
    lookup_module_0.myadds = None
    lookup_module_0.mykwargs = {'vault_password': 'password'}
    lookup_module_0.myrunner_args = None
    lookup_module_0.myplay_context = None
    lookup_module_0.mynew_vars = None
    lookup_module_0.mynew_vars_templated = False
    lookup_module_

# Generated at 2022-06-25 10:56:25.869310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_instance = LookupModule()
    terms_0 = []
    variables_0 = {'groups': {}}
    assert lookup_module_0_instance.run(terms_0, variables_0) == []

# Generated at 2022-06-25 10:56:30.304535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_run = LookupModule()

  # TODO: Put dev test code here, and "return None"
  return None


# Generated at 2022-06-25 10:56:34.373556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'all']
    variables = {u'groups': {u'group_0': [u'host_0']}}
    kwargs = {u'_terms': [u'all']}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == [u'host_0']


# Generated at 2022-06-25 10:56:42.301858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    hosts_0 = {'srv': ['myserver'], 'grp': ['mygroup'], 'web': ['myweb']}
    hosts_1 = {'srv': ['myserver'], 'grp': ['mygroup'], 'web': ['myweb']}
    hosts_2 = {'srv': ['myserver'], 'grp': ['mygroup'], 'web': ['myweb']}
    hosts_3 = {'srv': ['myserver'], 'grp': ['mygroup'], 'web': ['myweb']}
    hosts_4 = {'srv': ['myserver'], 'grp': ['mygroup'], 'web': ['myweb']}

# Generated at 2022-06-25 10:56:45.690771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        'localhost',
    ]
    variables = {
        'groups': {
            'group1': [
                'localhost',
            ],
        },
    }
    assert lookup_module_0.run(terms, variables) == [
        'localhost',
    ]


# Generated at 2022-06-25 10:56:51.848382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "test_terms"

    variables = {'groups': {'test_group': ['test_hostname']}}
    kwargs = {}
    result = lookup_module_0.run(terms_0, variables, **kwargs)
    print(result)



# Generated at 2022-06-25 10:56:54.785294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret_lookup_module_0 = lookup_module_0.run(['all', '!www'], variables=None, **None)

# Generated at 2022-06-25 10:56:56.812510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = None
    variables=None
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:56:57.992902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(test_LookupModule_run, object) is True


# Generated at 2022-06-25 10:57:11.385823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {'groups': {'group_0': ['host_0', 'host_3', 'host_1'], 'group_2': ['host_3', 'host_1', 'host_2'], 'group_1': ['host_0', 'host_2', 'host_1']}}
    assert lookup_module_0.run(terms, variables) == ['host_0', 'host_3', 'host_1', 'host_3', 'host_1', 'host_2', 'host_0', 'host_2', 'host_1']

    terms = []

# Generated at 2022-06-25 10:57:14.135830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('web') == []


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:57:17.075861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=[], variables={'groups': {'test': ['test1']}})
    assert result == []


# Generated at 2022-06-25 10:57:18.621682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    #lookup_module.run('terms', 'variables')
    assert 1 == 1

# Generated at 2022-06-25 10:57:19.829644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 10:57:25.929308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GIVEN
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(null_loader)

    # WHEN
    result = lookup_module_0.run([u'all'], {u'groups': {u'nginx': [u'localhost']}})

    # THEN
    assert result == [u'localhost']

# Function null_loader is a stub function that returns None.

# Generated at 2022-06-25 10:57:27.977199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  terms_1 = '*'
  variables_1 = 'groups'
  assert lookup_module_1.run(terms_1, variables_1) == []

# Generated at 2022-06-25 10:57:34.242791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = 'all:!www'
    variables = {'groups': {'all': ['localhost'], 'www': ['10.0.0.2'], 'subnet1': ['10.0.0.3']}}
    assert lookup_module.run(terms=terms, variables=variables) == ['localhost', 'subnet1']

# Generated at 2022-06-25 10:57:41.232832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    kwargs_0 = {}
    varargs_0 = {}
    # Test with missing argument
    try:
        lookup_module_0.run(terms_0, variables_0, kwargs_0, varargs_0)
        assert True
    except TypeError:
        assert False
    else:
        assert False

# Generated at 2022-06-25 10:57:42.225699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run()

# Generated at 2022-06-25 10:57:57.414695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set the fixtures
    terms = ["all"]
    variables = {"groups": {"all": ["www.example.com","db.example.com","app.example.com", "app1.example.com", "app2.example.com"]}}

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables)

    assert result == ['www.example.com', 'db.example.com', 'app.example.com', 'app1.example.com', 'app2.example.com']


# Generated at 2022-06-25 10:57:58.639139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == []


# Generated at 2022-06-25 10:58:04.228775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    #Test 1: Terms represents a list and variables represents a valid dictionary
    assert lookup_module_1.run(["blog*"],{'groups':{'blog-servers': ['192.168.1.1']}}) == ['192.168.1.1']
    #Test 2: Terms represents a empty list and variables represents a valid dictionary
    assert lookup_module_1.run([],{'groups':{'blog-servers': ['192.168.1.1']}}) == []
    #Test 3: Terms represents a list and variables represents a None
    assert lookup_module_1.run(["blog*"], None) == []

# Generated at 2022-06-25 10:58:08.312982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostnames = ['key1', 'key2', 'key3']
    group_name = 'PASTE_GROUP_NAME'
    groups = {group_name: hostnames}
    lookup_module = LookupModule()
    result = lookup_module.run(group_name, variables={'groups': groups})
    assert result == hostnames


# Generated at 2022-06-25 10:58:09.653420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms='foo') == []

# Generated at 2022-06-25 10:58:16.723889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'all'
    variables_0 = {
        'groups': {
            'foo': {
                'hostvars': {},
                'children': []
            }
        }
    }
    assert lookup_module_0.run(terms_0, variables_0) is None

# Generated at 2022-06-25 10:58:21.978220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run('all:!www') == ['www']
    assert lookup_module_0.run('all') == ['www']
    assert lookup_module_0.run('app:*') == ['app1', 'app2']
    assert lookup_module_0.run('app') == ['app1', 'app2']
    assert lookup_module_0.run('app:&db') == ['app1', 'app2']
    assert lookup_module_0.run('all:&db') == ['app1', 'app2', 'db1', 'db2']

# Generated at 2022-06-25 10:58:25.324917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['all'],{'groups': {'all': []}})
    print('result is {0}'.format(result))

# Generated at 2022-06-25 10:58:28.316445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = str()
    variables = {}
    result = lookup_module_0.run(terms, variables=variables)
    assert len(result) == 0


# Generated at 2022-06-25 10:58:31.853902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['all:!web'], {'hostvars': {}, 'groups': {'webservers': {'host1'}, 'all': {'host1', 'host2'}}})
    assert result == ['host2']


# Generated at 2022-06-25 10:58:53.914772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ""
    variables_1 = ""
    kwargs_1 = {
        '_terms': [
            'webservers'
        ]
    }
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == [
        'www1',
        'www2',
    ]

    lookup_module_2 = LookupModule()
    terms_2 = ""
    variables_2 = {
        'groups': {
            'servers': [
                'www1',
                'www2',
                'www3',
            ]
        }
    }

# Generated at 2022-06-25 10:58:59.869004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = test_variable_0['terms']
    variables = test_variable_0['variables']
    assert lookup_module.run(terms, variables) == test_variable_0['expected_stdout_0']

# Generated at 2022-06-25 10:59:05.316060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    manager = InventoryManager(lookup_module._loader, parse=False)
    for group, hosts in {'all': ['host-0', 'host-1', 'host-2']}.items():
        manager.add_group(group)
        for host in hosts:
            manager.add_host(host, group=group)

    try:
        result = lookup_module.run('all', variables={'groups': {'all': ['host-0', 'host-1', 'host-2']}})
        return result
    except Exception as e:
        print(e)


# Generated at 2022-06-25 10:59:09.435202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    assert isinstance(lookup_module_0.run(terms='foo', variables={'groups': {'all': ['foo', 'bar'], 'webservers': ['foo']}}), list)

# Generated at 2022-06-25 10:59:13.841354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0._basedir = None
    lookup_module_0._inventory = None
    lookup_module_0._display = None
    lookup_module_0._hostvars = None
    lookup_module_0._play = None
    lookup_module_0._options = None
    lookup_module_0._task = None
    lookup_module_0._variables = None
    lookup_module_0._connection = None
    lookup_module_0._cache = None
    lookup_module_0._tmp_path = None
    lookup_module_0._low_level_plugins = None
    lookup_module_0.task_vars = None

# Generated at 2022-06-25 10:59:20.600901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    groups = dict(
        group_1=['host_1'],
        group_2=['host_2', 'host_3'],
    )
    # Positive test case
    # Test case with multiple groups
    result = lookup_module.run(terms="group_1:!host_1", variables=dict(groups=groups))
    assert type(result) is list
    assert result == []
    # Test case with one group
    result = lookup_module.run(terms="group_2:!host_2", variables=dict(groups=groups))
    assert type(result) is list
    assert result == ['host_3']
    # Test case for all
    result = lookup_module.run(terms="all:!host_1", variables=dict(groups=groups))
    assert type

# Generated at 2022-06-25 10:59:21.914770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=None)


# Generated at 2022-06-25 10:59:26.206350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {'groups': {'group_0': ['ansible_0', 'ansible_1', 'ansible_2']}}
    test_terms_0 = ['ansible_']
    results_0 = lookup_module_0.run(test_terms_0, variables=vars_0)
    assert(results_0 == ['ansible_0', 'ansible_1', 'ansible_2'])


# Generated at 2022-06-25 10:59:27.202978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['all'], {}) is not None

# Generated at 2022-06-25 10:59:27.692440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:59:46.628309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:59:51.398847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  str_0 = 'groups'
  str_1 = {}
  str_2 = {str_0: str_1}
  var_0 = lookup_module_0.run(str_1, str_2, **str_1)
  str_3 = {}
  str_4 = {'all': '!www'}
  str_2[str_0] = str_3
  str_5 = 'hostvars'
  str_6 = 'hosts'
  str_7 = 'all'
  str_8 = '!www'
  str_2[str_5] = str_1
  str_2[str_6] = str_3

# Generated at 2022-06-25 10:59:56.428708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)
    assert var_0 is None

# Generated at 2022-06-25 10:59:58.668214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var = lookup_run('', '', **'')


# Generated at 2022-06-25 11:00:01.570140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)
    assert var_0 == []


# Generated at 2022-06-25 11:00:04.903141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.Run()



# Generated at 2022-06-25 11:00:09.313899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    terms = {}
    variables = {str_0: str_1}
    obj = LookupModule()
    result = obj.run(terms, variables)
    assert result == [], result


# Generated at 2022-06-25 11:00:12.225134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg_0 = [{'name': '_terms', 'doc': '', 'default': None}, {'name': 'variables', 'doc': '', 'default': None}]
    arg_1 = 'LookupModule'
    return_0 = inspect_getargspec(arg_1, arg_0)
    assert return_0


# Generated at 2022-06-25 11:00:19.252096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_3 = 'groups'
    str_4 = {}
    str_5 = {str_3: str_4}
    var_0 = lookup_run(str_4, str_5, **str_4)
    # assert the 2nd item in the returned list is equal to '127.0.0.1'
    assert var_0[1] == '127.0.0.1'

# Generated at 2022-06-25 11:00:21.979176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = 'groups'
    dict_0 = {}
    dict_1 = {str_0: dict_0}
    var_0 = lookup_run(dict_0, dict_1, **dict_0)

# Generated at 2022-06-25 11:00:47.223769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2)
    str_3 = {}
    str_4 = {str_0: str_3}
    var_1 = lookup_module_0.run(str_3, str_4)
    str_5 = 'host_pattern'
    str_6 = 'hosts'
    str_7 = 'hostvars'
    str_8 = 'inventory_hostname'
    str_9 = 'groups'
    str_10 = '_hostnames'
    str_11 = 'msg'

# Generated at 2022-06-25 11:00:49.513146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_3 = 'groups'
    str_4 = {}
    str_5 = {str_3: str_4}
    var_1 = lookup_run(str_4, str_5, **str_4)

# Generated at 2022-06-25 11:00:54.753279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  str_0 = 'item'
  str_1 = 'msg'
  str_2 = "{{ item }}"
  str_3 = {str_1: str_2}
  str_4 = 'debug'
  str_5 = 'name'
  str_6 = 'show all the hosts matching the pattern, i.e. all but the group www'
  str_7 = 'with_inventory_hostnames'
  str_8 = 'all:!www'
  str_9 = [str_8]
  str_10 = {str_5: str_6, str_4: str_3, str_7: str_9}
  str_11 = {str_0: str_10}
  str_12 = 'groups'
  str_13 = {}
 

# Generated at 2022-06-25 11:00:57.907137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_1 = lookup_module_1.run(str_0, str_2, **str_1)

# Generated at 2022-06-25 11:00:58.610773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == {}


# Generated at 2022-06-25 11:01:01.747623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)
    print(var_0)

# Generated at 2022-06-25 11:01:02.403970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:01:03.003115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:01:08.808018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)

# Generated at 2022-06-25 11:01:15.571166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'all'
    str_1 = 'www'
    str_2 = [str_0, str_1]
    str_3 = 'groups'
    str_4 = 'all'
    str_5 = {}
    str_6 = [str_4, str_5]
    str_7 = {}
    str_8 = {str_3: str_6}
    var_0 = lookup_run(str_2, str_8, **str_7)

# Generated at 2022-06-25 11:01:57.685044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 =  1
    var_2 = []
    var_3 = var_2
    var_4 = "Item count is %d"
    var_2.append(var_4 % var_1)
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_5 = lookup_module_0.run(var_0, str_2, **str_1)
    var_2.append(var_5)
    var_6 = var_2[::var_1]
    del var_2[:]
    var_2.extend(var_6)
    test_case_0()
    test_case_1()
    
# Unit test

# Generated at 2022-06-25 11:02:02.233762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'all'
    var_0 = lookup_module_0._loader
    str_1 = 'test_case_0'
    str_2 = 'manager'
    str_3 = '_hosts'
    str_4 = 'add_host'
    str_5 = 'add_group'
    str_6 = 'groups'
    str_7 = {}
    str_8 = {str_6: str_7}
    str_9 = 'get_hosts'
    str_10 = 'name'
    str_11 = lookup_module_0.run(str_0, str_8, **str_7)
    try:
        assert (str_1 == str_11)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 11:02:05.233083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)


test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:02:07.819766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_key = 'groups'
    lookup_value = {}
    lookup_variables = {lookup_key: lookup_value}
    lookup_key = lookup_value
    lookup_module.run(lookup_key, lookup_variables, **lookup_key)


# Generated at 2022-06-25 11:02:11.811195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_2, **str_1)

# Generated at 2022-06-25 11:02:20.957592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = {'group_names': 'group_names', 'groups': 'groups'}
    list_0 = []
    list_1 = ['group_names', 'groups']
    dict_0 = dict(zip(list_1, list_0))
    str_1 = {'groups': dict_0}
    str_2 = 'group_names'
    exception_0 = AnsibleError('AnsibleError: Invalid regular expression: no argument for repetition operator: `+`\n')
    dict_1 = {'msg': 'AnsibleError: Invalid regular expression: no argument for repetition operator: `+`\n'}
    dict_2 = {'Invocation': {'module_name': 'debug', 'module_args': dict_1}, 'item': 'www'}

# Generated at 2022-06-25 11:02:24.828843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_result = LookupModule().run(['all'], variables={'groups': {'all': ['test_0', 'test_1']}})
    assert lookup_result == ['test_0', 'test_1']
    #assert len(lookup_result) == 2
    #assert lookup_result[0] == 'test_0'
    #assert lookup_result[1] == 'test_1'

# Generated at 2022-06-25 11:02:28.478530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_run(str_1, str_2, **str_1)



# Generated at 2022-06-25 11:02:33.543906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_run(str_1, str_2, **str_1)


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 11:02:38.669230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'groups'
    str_1 = {}
    str_2 = {str_0: str_1}
    var_0 = lookup_run(str_1, str_2, **str_1)
    var_1 = lookup_module_0.run(str_1, str_2, **str_1)
    assert var_0 == var_1