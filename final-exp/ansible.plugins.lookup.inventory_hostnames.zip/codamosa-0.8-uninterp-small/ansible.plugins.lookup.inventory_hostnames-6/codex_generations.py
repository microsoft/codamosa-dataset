

# Generated at 2022-06-25 10:53:34.608008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ''
    variables = ''
    kwargs = {}
    result = lookup_module_0.run(terms=terms, variables=variables, **kwargs)
    assert isinstance(result, list)
    assert len(result) == 0

# Generated at 2022-06-25 10:53:42.039472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case when all inputs to method run are valid or expected
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    result = lookup_module_0.run(None, None, terms = "test_terms", variables = {'groups': {'test_group': ['test_host1', 'test_host2'], 'test_group2': ['test_host2']}}, **{'vault_password': 'test_vault_password'})
    assert result == ['test_host1', 'test_host2'], "Test case when all inputs to method run are valid or expected failed"



# Generated at 2022-06-25 10:53:49.504515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    vars_1 = {'groups': {u'lazy': [u'bar'], u'foo': [u'foo', u'bar']}}
    terms_1 = [u'all']
    assert lookup_module_1.run(terms_1, vars_1) == ['bar', 'foo']

    lookup_module_2 = LookupModule()
    vars_2 = {'groups': {u'all': [u'foo', u'bar']}}
    terms_2 = None
    assert lookup_module_2.run(terms_2, vars_2) == ['bar', 'foo']


# Generated at 2022-06-25 10:53:51.395012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: setup test environment here
    assert True # TODO: implement your test here


# Generated at 2022-06-25 10:53:58.192986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    mock_loader = MagicMock()

    manager = InventoryManager(loader=mock_loader, parse=False)
    manager.add_group("all")
    manager.add_host("example", group="all")
    manager.add_host("example2", group="all")
    manager.add_host("web", group="web")

    variables = dict()
    variables['groups'] = dict()
    variables['groups']['all'] = ["example", "example2"]
    variables['groups']['web'] = ["web"]

    result = lookup_module.run(terms="all", variables=variables)

    assert result == ["example", "example2"]



# Generated at 2022-06-25 10:54:03.436205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._load_name = 'lookup_module_0._load_name'
    lookup_module_0._templar = 'lookup_module_0._templar'
    lookup_module_0._loader = 'lookup_module_0._loader'
    terms_0 = 'terms_0'
    variables_0 = 'variables_0'
    kwargs_0 = dict({'kwargs_0_key': 'kwargs_0_value'})
    res_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    assert type(res_0) == list

# Generated at 2022-06-25 10:54:03.917898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:54:05.882649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None, variables=None, **kwargs) == None


# Generated at 2022-06-25 10:54:12.660646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "all"
    variables_0 = {'groups': {'group_0': ['host_0', 'host_1']}}
    kwargs_0 = None

    # Call method run of class LookupModule with arguments terms_0, variables_0, **kwargs_0
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == ['host_0', 'host_1']
    # Test if exception was raised for unexpected arguments
    with pytest.raises(TypeError):
        lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)

if __name__ == '__main__':
    import pytest

# Generated at 2022-06-25 10:54:20.169973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # set up test case inputs
    terms = ""
    variables = {u'groups': {u'all': [u'host1', u'host2']}}

    # Call method run with the appropriate args
    # This will return a list
    return_value = lookup_module_0.run(terms, variables)

    # Assert that the return value from the method run is equal to the expected value
    assert return_value == [u'host1', u'host2']


# Generated at 2022-06-25 10:54:25.616415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:54:32.295162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)
    lookup_module_2 = LookupModule()
    dict_1 = {}
    lookup_module_3 = LookupModule(**dict_1)
    var_1 = lookup_module_3.run(lookup_module_2)

# Generated at 2022-06-25 10:54:37.145165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Add a term
    terms = ['', ]
    variables = {'groups': {'all': ['', ],}, }
    lookup_module_0.run(terms, variables)
    lookup_module_0.run(terms, variables=variables)
    lookup_module_0.run(terms, variables=variables)

    # Add another term
    # Add a group
    # Add a group
    # Add a group
    # Add a group
    # Add a group
    # Add a group
    terms = ['', ]
    variables = {'groups': None,}
    lookup_module_0.run(terms, variables)
    terms = ['', ]
    variables = {'groups': {None: ['', ],},}

# Generated at 2022-06-25 10:54:47.649035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()
    assert lookup_module_1.run(lookup_module_0) == ()

# Generated at 2022-06-25 10:54:51.668099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('all')
    var_1 = lookup_module_0.run(var_0)
    var_2 = lookup_module_0.run(var_1)
    var_3 = lookup_module_0.run(var_2)
    var_4 = lookup_module_0.run(var_3)

# Generated at 2022-06-25 10:54:53.414973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:54:57.342884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 10:54:59.146925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 10:55:06.362562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    dict_1 = {}
    lookup_module_1 = LookupModule(**dict_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_1.run(lookup_module_0, dict_1)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:55:07.367880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = "term"
    var_0 = lookup_module_0.run(term)
    assert var_0 == '_hostnames'

# Generated at 2022-06-25 10:55:11.386578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms_0 = ['localhost', 'all']
    var_0 = lookup_module_1.run(terms=terms_0, lookup_module_0=lookup_module_0)

# Generated at 2022-06-25 10:55:12.777369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0)

# Generated at 2022-06-25 10:55:14.085696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 10:55:15.754899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run("all")
    assert var_0 == []

# Generated at 2022-06-25 10:55:19.499972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None, None)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 10:55:24.145366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 10:55:31.199636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_0 = LookupModule()
    dict_3 = {}
    lookupmodule_1 = LookupModule(**dict_3)
    list_0 = []
    str_0 = lookupmodule_1.run(lookupmodule_0, list_0)

# Generated at 2022-06-25 10:55:35.385757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == [], "Expected: [], Actual: " + str(var_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:55:37.584678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 10:55:41.505408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([], {"groups": {"foo": ["bar"]}})
    assert var_0 == []

# Generated at 2022-06-25 10:55:49.869568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run()
    assert str_0 == None

# Generated at 2022-06-25 10:55:54.309848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement test

    # Setup test environment
    lookup_module = LookupModule()
    lookup_module.set_options()

    # Exercise code path
    #result = lookup_module.run(**kwargs)

    # Teardown test environment
    #return result

# Run tests
if __name__ == "__main__":
    # Run Unit tests
    #test_case_0()
    test_LookupModule_run()
    # Clean up test environment

# Generated at 2022-06-25 10:56:04.740780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    dict_0 = {'item': lookup_module_0, 'var': lookup_module_1}
    list_0 = [dict_0, {'item': lookup_module_0}, {'var': lookup_module_1}, {}, {'var': lookup_module_0}, {'item': lookup_module_1}]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == []
    # in 1st tuple: lookup_module_0 and lookup_module_0
    # in 2nd tuple: lookup_module_1 and lookup_module_1
    # in 3rd tuple: {} and {}
    # in 4th tuple: {}, {'item': lookup_module_0}, {'

# Generated at 2022-06-25 10:56:07.033038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    dict = {}
    lookup_module.run(dict)



# Generated at 2022-06-25 10:56:10.220601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 10:56:15.397545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_0 = "f"
    variables_0 = {}
    kwargs_0 = {}
    var_0 = lookup_module_2.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:56:20.388619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    # call to run method, with args type(var_0) 
    # call to run method, with args type(var_0) 
    # call to run method, with args type(var_0) 
    print("result of call to run method", lookup_module_1.run(lookup_module_0))

# Generated at 2022-06-25 10:56:22.520140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = {}
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:56:29.293426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = {'groups': {'group_names': ['group_name_0', 'group_name_1', 'group_name_2', 'group_name_3'], 'group_name_0': ['host_name_0', 'host_name_1', 'host_name_2', 'host_name_3'], 'group_name_1': ['host_name_4', 'host_name_5', 'host_name_6', 'host_name_7'], 'group_name_2': ['host_name_8', 'host_name_9', 'host_name_10', 'host_name_11'], 'group_name_3': ['host_name_12', 'host_name_13', 'host_name_14', 'host_name_15']}}
    lookup_module_2 = LookupModule

# Generated at 2022-06-25 10:56:32.964664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "db*"
    dict_0 = {'groups': {}}
    var_0 = lookup_module_0.run(str_0, dict_0)
    assert isinstance(var_0, list)
    assert var_0 == []

# Generated at 2022-06-25 10:56:44.721422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # 1. When
    var_0 = lookup_module_0.run(lookup_module_0)

    # 2.
    assert var_0 == None, "Test. When var_0 == null"

# Generated at 2022-06-25 10:56:47.471549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('httpd')


# Generated at 2022-06-25 10:56:51.576904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('p0')
    var_1 = lookup_module_0.run('p0')
    assert var_0 == var_1
    assert var_0 == [None]

# Generated at 2022-06-25 10:56:55.490932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [{}]
    lookup_module_1 = LookupModule(**var_0)
    # Call the method
    method_result = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 10:56:57.876433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test raise exception
    with pytest.raises(AnsibleError):
        lookup_module_0.run()



# Generated at 2022-06-25 10:57:00.011758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid arguments and valid results
    # Test with valid arguments and invalid results
    # Test with invalid arguments and valid results
    # Test with invalid arguments and invalid results
    pass

# Generated at 2022-06-25 10:57:09.010110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostname_1 = 'localhost'
    repository_name = 'michael_dehaan/ansible'
    field_name = '_hostnames'
    terms_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule(**variables_0)
    lookup_module_1 = LookupModule()
    hostname_0 = 'ansible.thefunkybunch.club'
    lookup_module_2 = lookup_module_0.run(lookup_module_1, hostname_1, field_name, repository_name, terms_0)
    lookup_module_3 = lookup_module_0.run(lookup_module_1, hostname_0, field_name, repository_name, terms_0)

# Generated at 2022-06-25 10:57:13.455701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['*']
    var_1 = {}
    var_1["groups"] = {"var1": 'var1', 'var2': dict()}
    var_2 = lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 10:57:16.401472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict = {}
    obj = LookupModule(**dict)
    var = obj.run()
    obj = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 10:57:19.701554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)
    assert var_0 == []

# Generated at 2022-06-25 10:57:39.284384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    assert lookup_module_0.run(lookup_module_0) == []


test_LookupModule_run()

# Generated at 2022-06-25 10:57:42.673730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)
    assert var_0 == [], "Unit test failed. Expected {}, got {}.".format([], var_0)


# Generated at 2022-06-25 10:57:49.234673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:57:53.797181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)


# Generated at 2022-06-25 10:57:56.722898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 10:57:59.033362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    dict_1 = {}
    lookup_module_4 = LookupModule(**dict_1)
    var_1 = lookup_module_4.run(lookup_module_3)

# Generated at 2022-06-25 10:58:01.942715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    lookup_module_0.run(lookup_module_1)
    var_0 = lookup_module_0.run(lookup_module_1)


# Generated at 2022-06-25 10:58:09.654408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    manager_0 = InventoryManager()
    inventory_0 = manager_0.get_hosts()
    var_0 = lookup_module_0.run(inventory_0)
    assert var_0 == [inventory_0]
    lookup_module_1 = LookupModule()
    manager_1 = InventoryManager()
    inventory_1 = manager_1.get_hosts(pattern=lookup_module_1)
    var_1 = lookup_module_1.run(inventory_1)
    assert var_1 == [inventory_1]

# Generated at 2022-06-25 10:58:20.780504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_0['_loader'] = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['groups'] = dict_1
    dict_0['_loader']['_templar'] = dict_2
    dict_0['_loader']['_templar']['vars'] = {}
    dict_0['_loader']['_templar']['vars']['groups'] = {}
    dict_0['_loader']['_templar']['vars']['groups']['webserver'] = ['host_2']
    dict_0['_loader']['_templar']['vars']['groups']['dbserver'] = ['host_0']

# Generated at 2022-06-25 10:58:27.339980
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    kwargs = {}
    lookup_module.run(**kwargs)

test_LookupModule_run()

test_case_0()

# Generated at 2022-06-25 10:59:00.243963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    items_0 = {}
    dict_0 = {}
    dict_0["groups"] = items_0
    dict_1 = {}
    dict_0["_terms"] = dict_1
    var_0 = lookup_module_0.run(dict_0)


# Generated at 2022-06-25 10:59:08.871806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module_var_0 = "ansible/plugins/lookup/inventory_hostnames.py"
    var_0 = {}
    lookup_module = LookupModule(**var_0)
    assert lookup_module is not None
    terms = {}
    variables = {}
    try:
        lookup_module.run(**terms, variables=variables)
        assert False
    except:
        assert True

# Generated at 2022-06-25 10:59:10.291539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 10:59:14.602921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_0.set_options(**dict_0)
    dict_0 = {}
    dict_1 = {}
    dict_1['groups'] = dict_0
    var_0 = lookup_module_0.run('', variables=dict_1)


# Generated at 2022-06-25 10:59:15.675705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    c = LookupModule()
    c.run()


# Generated at 2022-06-25 10:59:18.213570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    dict_0 = {}
    lookup_module_3 = LookupModule(**dict_0)
    var_0 = lookup_module_3.run(lookup_module_2)

# Generated at 2022-06-25 10:59:22.782160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0.run(lookup_module_0)]


# Generated at 2022-06-25 10:59:28.264783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'oyster'
    var_0 = lookup_module_0.run()


# Generated at 2022-06-25 10:59:33.736268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0)
    return var_0

# Generated at 2022-06-25 10:59:37.683404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {}
    lookup_module_1 = LookupModule(**vars_0)
    lookup_module_2 = lookup_module_1.run(lookup_module_0)

# Generated at 2022-06-25 11:00:40.415002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    str_0 = ""
    str_1 = "hosts"
    str_2 = "hosts"
    str_3 = "hosts"
    str_4 = "hosts"
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17

# Generated at 2022-06-25 11:00:41.795704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 11:00:45.063698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_1 = LookupModule(**dict_0)
    lookup_module_1.run(dict_1)


# Generated at 2022-06-25 11:00:46.614713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test case for 'hosts' keyword

    assert True == True

# Generated at 2022-06-25 11:00:49.496069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = LookupModule()
    mock_self.run()
    var_0 = mock_self.run(mock_self)


# Generated at 2022-06-25 11:00:54.309295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'_loader': {}, 'groups': {'www': [{'foo': 'bar'}], 'databases': [{'foo': 'bar'}]}}
    for var_1 in var_0:
        for var_2 in var_0[var_1]:
            var_3 = var_0[var_1][var_2]
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_3)

# Generated at 2022-06-25 11:01:00.873033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'not.a.valid.hostname'
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(str_0, dict_0)


# Generated at 2022-06-25 11:01:07.156923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_4 = LookupModule()
    arg_0 = ['', '']
    arg_1 = {}
    lookup_module_4.run(arg_0, arg_1)

# Generated at 2022-06-25 11:01:12.746391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    dict_1 = {}
    lookup_module_3 = LookupModule(**dict_1)
    var_1 = lookup_module_3.run(lookup_module_2)

# Generated at 2022-06-25 11:01:15.366656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_arg_0 = 'host-3'
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lo

# Generated at 2022-06-25 11:03:10.105979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    var_1 = ['/var/log/httpd/access_log', '/var/log/httpd/error_log']
    lookup_module_2 = LookupModule(var_1)
    var_2 = lookup_module_2.run(lookup_module_1)
    lookup_module_0 = LookupModule()
    var_0 = ['']
    lookup_module_3 = LookupModule(var_0)
    var_3 = lookup_module_3.run(lookup_module_0)

# Generated at 2022-06-25 11:03:12.753741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_1 = LookupModule(**dict_0)
    terms_0 = ''
    lookup_module_2 = lookup_module_1.run(terms_0)


# Generated at 2022-06-25 11:03:21.546285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [2, 6]
    dict_0 = {'groups': {'test': [0, 5], 'all': [1, 5], 'test:children': [4, 0], 'test:vars': {2: 0, 1: 3}, 'all:children': [4, 'test'], 'all:vars': {0: 5, 2: 0, 1: 3}}}
    var_0 = lookup_module_0.run(terms_0, variables=dict_0)
    print(var_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:03:24.687296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_0.append("sdossett@panath.com")
    var_0.append("!UNKNOWN")
    var_0.append("Michael DeHaan")
    lookup_module_1 = LookupModule(var_0)
    var_1 = lookup_module_1.run(lookup_module_0)
    assert var_1 == None