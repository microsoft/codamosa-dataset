

# Generated at 2022-06-26 03:11:32.070162
# Unit test for function add_status_code
def test_add_status_code():
    # a decorator is used to add exceptions to SanicException
    # the function can add status_code, quiet=None/False/True for each exception
    # when quiet is None/False, it means that the exception does not need to be logged
    # when quiet is True, it means that the exception needs to be logged
    # the default code is 500, and the default quiet is None
    invalid_use = InvalidUsage()
    assert invalid_use.status_code == 400
    assert invalid_use.quiet is None

    method_not_support = MethodNotSupported(method=None, allowed_methods=["GET"])
    assert method_not_support.status_code == 405
    assert method_not_support.quiet is None

    server_error = ServerError()
    assert server_error.status_code == 500
    assert server_error.quiet

# Generated at 2022-06-26 03:11:37.499564
# Unit test for function add_status_code
def test_add_status_code():
    # Test for add_status_code class decorator
    test_class = type(
        "TestAddStatusCode",
        (Exception, ),
        {
            "status_code": 200,
            "quiet": False
        }
    )

    assert test_class.status_code == 200
    assert test_class.quiet == False

    # Test for add_status_code function decorator
    @add_status_code(403)
    def test_func():
        pass

    assert test_func.status_code == 403
    assert test_func.quiet == False

# Generated at 2022-06-26 03:11:41.310581
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.exceptions import add_status_code

    @add_status_code(200, quiet=True)
    class Foo(SanicException):
        pass

    def test_case_0():
        foo_0 = Foo(test_case_0)



# Generated at 2022-06-26 03:11:53.553452
# Unit test for function add_status_code
def test_add_status_code():
    # A simple unit test for add_status_code
    class MyClass:
        def __init__(self, status_code):
            self.status_code = status_code

    # create a MyClass object
    my_instance = MyClass(404)

    # add status_code to my_instance
    new_instance = add_status_code(403)(my_instance)
    assert new_instance.status_code == 403

    # add status_code again to my_instance
    next_instance = add_status_code(300)(new_instance)
    assert next_instance.status_code == 300

    # add different status_code to my_instance
    last_instance = add_status_code(200)(next_instance)
    assert last_instance.status_code == 200

# Generated at 2022-06-26 03:11:55.858061
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 500
    not_found_0 = add_status_code(status_code_0)




# Generated at 2022-06-26 03:11:59.273541
# Unit test for function add_status_code
def test_add_status_code():
    # test_case_0
    def test_eq_0():
        test_eq_0.counter += 1
    test_eq_0.counter = 0
    test_case_0()
    assert test_eq_0.counter == 1

# Generated at 2022-06-26 03:12:02.853866
# Unit test for function add_status_code
def test_add_status_code():
    # No error
    try:
        class_decorator = add_status_code(1)
        @class_decorator
        class Forbidden:
            pass
        forbidden_1 = Forbidden(1)
    except Exception:
        raise Exception("Test case 0 fail, cannot add status code to a class")


# Generated at 2022-06-26 03:12:07.242815
# Unit test for function add_status_code
def test_add_status_code():
    class exc0(SanicException):
        pass
    @add_status_code(200)
    class exc0_200(exc0):
        pass
    @add_status_code(400)
    class exc0_400(exc0):
        pass
    assert exc0_200.status_code == 200
    assert exc0_400.status_code == 400

    # Classes that define a status_code take precedence
    @add_status_code(404)
    class exc1(ServerError):
        status_code = 500
    assert exc1.status_code == 500

    pass

# Test cases for function abort

# Generated at 2022-06-26 03:12:17.581805
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        pass

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    @add_status_code(408)
    class RequestTimeout(SanicException):
        pass

    @add_status_code(413)
    class PayloadTooLarge(SanicException):
        pass

# Generated at 2022-06-26 03:12:26.744379
# Unit test for function add_status_code
def test_add_status_code():
    class Test_sanic_exception_0():
        def __init__(self, message, status_code=None, quiet=None):
            self.message = message
            self.status_code = status_code
            self.quiet = quiet

        def set_attribute_status_code(self):
            self.status_code = code

    # Check that there are no exceptions
    assert len(_sanic_exceptions) == 0

    code = "code"
    quiet = "quiet"
    test_sanic_exception = Test_sanic_exception_0(code)
    @add_status_code(code, quiet=quiet)
    def class_decorator(test_sanic_exception):
        return test_sanic_exception

    class_decorator(test_sanic_exception)

# Generated at 2022-06-26 03:12:30.350743
# Unit test for function add_status_code
def test_add_status_code():
    test_case0 = add_status_code(404)



# Generated at 2022-06-26 03:12:39.931658
# Unit test for function add_status_code
def test_add_status_code():
    # Testing a function largely dependent on decorators is extremely
    # difficult, so this unit test focuses on whether or not the
    # decorator is adding anything to the __dict__ of the class
    def get_status_code():
        return add_status_code(404)

    def get_status_code_quiet():
        return add_status_code(404, quiet=True)

    def get_status_code_quiet_none():
        return add_status_code(404, quiet=None)

    def get_status_code_quiet_false():
        return add_status_code(500, quiet=False)

    orig_dict_status_code = NotFound.__dict__
    orig_dict_status_code_quiet = NotFound.__dict__
    orig_dict_status_code_quiet_none = NotFound.__dict__

# Generated at 2022-06-26 03:12:49.416556
# Unit test for function add_status_code
def test_add_status_code():
    # unit test for add_status_code()
    @add_status_code(200)
    class SaneicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    assert SaneicException.status_code == 200


# Generated at 2022-06-26 03:12:53.774074
# Unit test for function add_status_code
def test_add_status_code():
    content_range_error_0 = None
    forbidden_0 = Forbidden(content_range_error_0)
    assert isinstance(forbidden_0, SanicException) == True
    assert forbidden_0.status_code == 403
    try:
        raise forbidden_0
    except forbidden_0:
        pass


# Generated at 2022-06-26 03:13:04.321039
# Unit test for function add_status_code
def test_add_status_code():
    import unittest

    add_status_code()
    add_status_code(500)
    add_status_code(500, True)
    add_status_code(500, False)
    add_status_code("500")
    add_status_code("500", True)
    add_status_code("500", False)

    class TestSanicException(Exception):
        pass
    assert _sanic_exceptions == {404: NotFound,
                                 400: InvalidUsage,
                                 405: MethodNotSupported,
                                 500: ServerError,
                                 503: ServiceUnavailable,
                                 408: RequestTimeout,
                                 413: PayloadTooLarge,
                                 416: ContentRangeError,
                                 417: HeaderExpectationFailed,
                                 403: Forbidden,
                                 401: Unauthorized}



# Generated at 2022-06-26 03:13:09.115358
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_0():
        pass

    test_class_0 = add_status_code(404)(test_class_0)
    assert test_class_0.status_code == 404


# Generated at 2022-06-26 03:13:10.129827
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(0)



# Generated at 2022-06-26 03:13:15.961493
# Unit test for function add_status_code
def test_add_status_code():
    # pass
    add_status_code(404)
    add_status_code(400)
    add_status_code(405)
    add_status_code(500)
    add_status_code(503)
    add_status_code(408)
    add_status_code(413)
    add_status_code(416)
    add_status_code(417)
    add_status_code(403)
    add_status_code(401)



# Generated at 2022-06-26 03:13:22.307572
# Unit test for function add_status_code
def test_add_status_code():
    sanic_exception_0 = SanicException(None, None, None)
    sanic_exception_1 = add_status_code(None, None)(sanic_exception_0)
    assert sanic_exception_1.status_code == None
    assert not hasattr(sanic_exception_1, 'quiet')
    sanic_exception_2 = add_status_code(1, None)(sanic_exception_0)
    assert sanic_exception_2.status_code == 1
    assert not hasattr(sanic_exception_2, 'quiet')
    sanic_exception_3 = add_status_code(2, True)(sanic_exception_0)
    assert sanic_exception_3.status_code == 2
    assert sanic_exception_3.quiet

# Generated at 2022-06-26 03:13:23.383301
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:13:28.109490
# Unit test for function add_status_code
def test_add_status_code():
    assert not add_status_code(200)


# Generated at 2022-06-26 03:13:29.336316
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(423)



# Generated at 2022-06-26 03:13:31.310200
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(200, "blah")



# Generated at 2022-06-26 03:13:42.286942
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException0:
        def __init__(self):
            self

    not_found_0 = add_status_code(404)(SanicException0())
    invalid_usage_0 = add_status_code(400)(SanicException0())
    method_not_supported_0 = add_status_code(405)(SanicException0())
    server_error_0 = add_status_code(500)(SanicException0())
    service_unavailable_0 = add_status_code(503)(SanicException0())
    payload_too_large_0 = add_status_code(413)(SanicException0())
    request_timeout_0 = add_status_code(408)(SanicException0())
    content_range_error_0 = add_status_code(416)(SanicException0())
    header_ex

# Generated at 2022-06-26 03:13:45.605419
# Unit test for function add_status_code
def test_add_status_code():
    print("Test add_status_code")
    try:
        with add_status_code(404):
            add_status_code(400)
    except Exception as e:
        assert isinstance(e, TypeError)
        assert e.args[0] == "add_status_code() missing 1 required positional argument: 'code'"


# Generated at 2022-06-26 03:13:52.623894
# Unit test for function add_status_code
def test_add_status_code():
    set_of_status_codes = set()
    for code in _sanic_exceptions:
        set_of_status_codes.add(code)

    for code in STATUS_CODES:
        assert code in set_of_status_codes
    return


if __name__ == "__main__":
    # test_case_0()
    test_add_status_code()

# Generated at 2022-06-26 03:13:55.001747
# Unit test for function add_status_code
def test_add_status_code():
    def case_0():
        def class_decorator(cls):
            cls.status_code = 400
            cls.quiet = True
        cls = case_0
        code = 400
        add_status_code(code)(cls)
        return cls.status_code



# Generated at 2022-06-26 03:14:05.144312
# Unit test for function add_status_code

# Generated at 2022-06-26 03:14:12.062910
# Unit test for function add_status_code
def test_add_status_code():
    # Try to call the function with a wrong number of parameters
    try:
        add_status_code(code=0)
    except TypeError:
        pass

    # Call the function with correct arguments types
    add_status_code(code=0, quiet=False)

    # Call the function with a correct number of arguments and a wrong value
    try:
        add_status_code(code=2, quiet=0)
    except Exception:
        pass


# Generated at 2022-06-26 03:14:14.658541
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(1)
    add_status_code(1, False)
    add_status_code(1, True)
    add_status_code(1, None)


# Generated at 2022-06-26 03:14:25.330401
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 200
    add_status_code_ret_0 = add_status_code(status_code_0)
    status_code_1 = 500
    add_status_code_ret_1 = add_status_code(status_code_1)


# Generated at 2022-06-26 03:14:35.915452
# Unit test for function add_status_code
def test_add_status_code():
    # Tests related to case 1
    status_code_0 = 404
    quiet_0 = None
    class_decorator_0 = add_status_code(status_code_0, quiet_0)
    not_found_0 = class_decorator_0(NotFound)
    not_found_1 = class_decorator_0(NotFound)
    assert not_found_0.status_code == status_code_0, "Not equal. Expected {}, but got {}.".format(status_code_0, not_found_0.status_code)
    assert not_found_0.quiet == quiet_0

# Generated at 2022-06-26 03:14:39.211008
# Unit test for function add_status_code
def test_add_status_code():
    """ Unit test for add_status_code """

    # write code here to test "add_status_code"
    result = add_status_code(200)
    assert(result)


# Generated at 2022-06-26 03:14:50.549316
# Unit test for function add_status_code
def test_add_status_code():
    # replace all exception classes with SanicException
    import sanic.exceptions
    import types

    class SanicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    for name, obj in vars(sanic.exceptions).items():
        if isinstance(obj, type) and issubclass(obj, SanicException):
            setattr(sanic.exceptions, name, SanicException)

    # add custom code

# Generated at 2022-06-26 03:14:52.193723
# Unit test for function add_status_code
def test_add_status_code():
    x = add_status_code(404, True)
    y = add_status_code(500)


# Generated at 2022-06-26 03:14:56.363101
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
    return class_decorator


# Generated at 2022-06-26 03:15:08.560202
# Unit test for function add_status_code
def test_add_status_code():
    # 20
    invalid_usage_0 = InvalidUsage(None)
    assert invalid_usage_0.status_code == 400
    assert invalid_usage_0.quiet == True

    invalid_usage_1 = InvalidUsage(None, 400)
    assert invalid_usage_1.status_code == 400
    assert invalid_usage_1.quiet == True

    invalid_usage_2 = InvalidUsage(None, 400, None)
    assert invalid_usage_2.status_code == 400
    assert invalid_usage_2.quiet == True

    invalid_usage_3 = InvalidUsage(None, 400, True)
    assert invalid_usage_3.status_code == 400
    assert invalid_usage_3.quiet == True

    invalid_usage_4 = InvalidUsage(None, 400, False)

# Generated at 2022-06-26 03:15:15.381822
# Unit test for function add_status_code
def test_add_status_code():

    def test_class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    code = 404
    quiet = 1
    class_decorator = test_class_decorator
    add_status_code(code, quiet)



# Generated at 2022-06-26 03:15:18.643688
# Unit test for function add_status_code
def test_add_status_code():
    try:
        forbidden_0 = Forbidden(Status_code, 500, True)
    except TypeError as e:
        print("TypeError:", e)
    else:
        raise AssertionError("Raise TypeError failed")


# Generated at 2022-06-26 03:15:27.067295
# Unit test for function add_status_code
def test_add_status_code():
    # Test for line 77
    test_exception_0 = ServerError(forbidden_0)
    test_add_status_code_0 = add_status_code(403)
    test_add_status_code_0(test_exception_0)
    # Test for line 83
    test_add_status_code_1 = add_status_code(404, True)
    test_add_status_code_1(test_exception_0)
    # Test for line 83
    test_add_status_code_2 = add_status_code(500, False)
    test_add_status_code_2(test_exception_0)


# Generated at 2022-06-26 03:15:43.332232
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls
    assert add_status_code(None)(class_decorator) == class_decorator

# Generated at 2022-06-26 03:15:48.079251
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    code = 400
    quiet = None
    add_status_code(code=code, quiet=quiet)

# Generated at 2022-06-26 03:15:52.428148
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) is add_status_code(404)
    assert add_status_code(400) is add_status_code(400)
    assert add_status_code(500) is add_status_code(500)


# Generated at 2022-06-26 03:16:01.557204
# Unit test for function add_status_code
def test_add_status_code():
    """Test add status code.

    :return: None
    """
    def class_decorator(cls):
        cls.status_code = 100
        return cls

    def function(cls):
        cls.status_code = 100
        return cls

    class_decorator = add_status_code(100)
    assert class_decorator is not None

    assert add_status_code(100, True) != function
    assert add_status_code(100) != function
    assert add_status_code(100) is not None
    assert add_status_code(100, True) is not None

    assert add_status_code(100, True) == add_status_code(100, True)
    assert add_status_code(100) == add_status_code(100)


# Unit

# Generated at 2022-06-26 03:16:07.391709
# Unit test for function add_status_code
def test_add_status_code():
    functionCalled = False
    def class_decorator(cls):
        global functionCalled
        functionCalled = True
        cls.status_code = 200
        _sanic_exceptions[200] = cls
        return cls
        
    add_status_code(200, True)(test_case_0)
    assert functionCalled is True

# Generated at 2022-06-26 03:16:13.141626
# Unit test for function add_status_code
def test_add_status_code():
    # Test for a happy path through the function
    status = add_status_code(500)
    assert status.status_code == 500

    # Test for a happy path through the function
    status = add_status_code(500)
    assert status.status_code == 500

    # Test for a happy path through the function
    status = add_status_code(500)
    assert status.status_code == 500



# Generated at 2022-06-26 03:16:18.800026
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[0] == SanicException
    # add_status_code(404) is called above
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable



# Generated at 2022-06-26 03:16:21.053508
# Unit test for function add_status_code
def test_add_status_code():
    try:
        abort(404)
    except NotFound as e:
        assert e.message == "404 Not Found"


# Generated at 2022-06-26 03:16:22.754811
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(NotImplementedError):
        add_status_code(None)


# Generated at 2022-06-26 03:16:23.884029
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(content_range_error_0, None)



# Generated at 2022-06-26 03:16:55.800877
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_1():
        import inspect

        def class_decorator(cls):
            return cls

        test_case_1_0 = class_decorator
        return test_case_1_0

    def test_case_2():
        test_case_2_0 = test_case_1()
        test_case_2_1 = test_case_2_0(test_case_1())
        test_case_2_2 = test_case_2_1(test_case_1())

        if False:
            test_case_2_3 = test_case_1()
            test_case_2_4 = test_case_2_3(test_case_1())
            test_case_2_5 = test_case_2_4

# Generated at 2022-06-26 03:16:58.728382
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 200
    quiet_0 = None
    content_range_error_0 = None
    forbidden_0 = Forbidden(content_range_error_0)
    assert add_status_code(status_code_0, quiet_0)(forbidden_0).status_code == status_code_0
    assert add_status_code(status_code_0, quiet_0)(forbidden_0).quiet is True

# Generated at 2022-06-26 03:17:06.856510
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None) -> class_decorator
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    # add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass
    # add_status_code(400)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass
    # add_status_code(405)
    class MethodNotSupported(SanicException):
        """
        **Status**: 405 Method Not Allowed
        """

# Generated at 2022-06-26 03:17:11.016785
# Unit test for function add_status_code
def test_add_status_code():
    #assert add_status_code(404, quiet=None)() is expected
    assert add_status_code(404, quiet=None)(NotFound) is NotFound

if __name__ == '__main__':
    test_case_0()
    test_add_status_code()

# Generated at 2022-06-26 03:17:12.826528
# Unit test for function add_status_code
def test_add_status_code():
    # Test for input content_range_error_0
    content_range_error_0 = None
    add_status_code(content_range_error_0)


# Generated at 2022-06-26 03:17:13.414491
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(status_code=None, quiet=None)


# Generated at 2022-06-26 03:17:18.430411
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator(NotFound)
    class_decorator(InvalidUsage)
    class_decorator(MethodNotSupported)
    class_decorator(ServerError)
    class_decorator(ServiceUnavailable)
    class_decorator(RequestTimeout)
    class_decorator(PayloadTooLarge)
    class_decorator(ContentRangeError)
    class_decorator(HeaderExpectationFailed)
    class_decorator(Forbidden)
    class_decorator(Unauthorized)


# Generated at 2022-06-26 03:17:19.620346
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404, quiet=None)(NotFound)

# Generated at 2022-06-26 03:17:24.855338
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 400
        if None:
            cls.quiet = True
        _sanic_exceptions[400] = cls
        return cls

    # Test 1
    class_decorator(InvalidUsage)
    assert _sanic_exceptions[400].status_code == 400


# Generated at 2022-06-26 03:17:30.980321
# Unit test for function add_status_code
def test_add_status_code():
    s100_code = "100"
    test_class = SanicException("test", status_code=s100_code, quiet=True)
    add_status_code(100)(test_class)
    class_code = test_class.status_code
    #assert class_code == s100_code
    #assert test_class.status_code == s100_code


# Unit tests for class SanicException

# Generated at 2022-06-26 03:18:38.209194
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    quiet = True
    class_decorator = add_status_code(status_code, quiet)
    try:
        class_decorator(None)
    except TypeError as e:
        assert str(e) == 'decorator() takes 1 positional argument but 2 were given'

    def class_decorator2(cls):
        return cls
    class DecoClass: pass
    class DecoClass2(DecoClass): pass
    assert class_decorator2(DecoClass) == DecoClass
    r = class_decorator2(DecoClass2)
    assert not isinstance(r, DecoClass)
    assert isinstance(r, DecoClass2)


# Generated at 2022-06-26 03:18:45.552386
# Unit test for function add_status_code
def test_add_status_code():
    # Test if add_status_code function is of function type
    assert isinstance(add_status_code, types.FunctionType)
    # Test if add_status_code function returns a function
    assert isinstance(add_status_code(404), types.FunctionType)
    # Test if add_status_code function returns a class
    assert isinstance(add_status_code(404)(NotFound), type)
    # Test if add_status_code function returns an exception
    assert issubclass(add_status_code(404)(NotFound), Exception)


# Generated at 2022-06-26 03:18:48.194632
# Unit test for function add_status_code
def test_add_status_code():
    # Test that the keyword arg quiet is accepted
    @add_status_code(418, quiet=True)
    class ImATeapot(SanicException):
        pass

    assert ImATeapot.quiet



# Generated at 2022-06-26 03:18:50.396347
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class A(SanicException):
        pass

    a = A(message="Not Found")
    assert A.quiet == False


# Generated at 2022-06-26 03:18:51.423975
# Unit test for function add_status_code
def test_add_status_code():
    assert Abort.status_code == status_code

# Generated at 2022-06-26 03:18:55.043452
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls
    return class_decorator(class_decorator)

# Generated at 2022-06-26 03:19:05.343464
# Unit test for function add_status_code
def test_add_status_code():
    class ContentRangeError_test():
        def __init__(self, message, content_range):
            self.headers = {"Content-Range": f"bytes */{content_range.total}"}

    add_status_code_test = add_status_code(416)

    @add_status_code_test
    class ContentRangeError_test_decorated(SanicException):
        pass
    # Class ContentRangeError_test is not changed
    content_range_error_0 = ContentRangeError_test(None, None)
    # Class ContentRangeError_test_decorated is changed
    content_range_error_1 = ContentRangeError_test_decorated(None, None)
    assert content_range_error_0.headers is None
    assert content_range_error_1.headers is not None

# Unit test

# Generated at 2022-06-26 03:19:15.995237
# Unit test for function add_status_code
def test_add_status_code():
    # Add test cases to test the function of add_status_code
    code_0 = 500
    quiet_0 = None

    # Calling add_status_code(500, None) should return class ServerError instance which has status code 500
    server_error = add_status_code(code_0, quiet_0)
    assert server_error.__name__ == 'ServerError'
    assert server_error.status_code == 500
    assert server_error.quiet == False

    # Calling add_status_code(404, None) should return class NotFound instance which has status code 404
    not_found = add_status_code(404, quiet_0)
    assert not_found.__name__ == 'NotFound'
    assert not_found.status_code == 404
    assert not_found.quiet == True


# Generated at 2022-06-26 03:19:24.797848
# Unit test for function add_status_code
def test_add_status_code():
    # Test status_code is None
    add_status_code_exception = SanicException("Doesn't matter")
    add_status_code_0 = add_status_code(0, None)(add_status_code_exception)
    assert add_status_code_0.status_code == 0
    assert add_status_code_0.quiet == False
    # Test status_code is not None
    add_status_code_1 = add_status_code(1, True)(add_status_code_exception)
    assert add_status_code_1.status_code == 1
    assert add_status_code_1.quiet == True


# Generated at 2022-06-26 03:19:29.208364
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    code = 404
    quiet = None
    add_status_code(code, quiet)
