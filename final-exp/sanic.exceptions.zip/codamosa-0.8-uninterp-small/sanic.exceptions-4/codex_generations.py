

# Generated at 2022-06-26 03:11:14.935612
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exc_Unauthorized = Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    return exc_Unauthorized

# Test case from function abort

# Generated at 2022-06-26 03:11:23.675567
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    int_0 = -582
    var_0 = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    var_0 = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    var_1 = Unauthorized("Auth required.", scheme="Bearer")
    var_1 = Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    var_2 = Unauthorized("Auth required.", status_code=int_0, scheme="Basic", realm="Restricted Area")


# Generated at 2022-06-26 03:11:27.663678
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    var_1 = Unauthorized(message = "Auth required.", scheme = "Basic", realm = "Restricted Area")


# Generated at 2022-06-26 03:11:30.550229
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 400
    if var_0 is not None:
        var_1 = InvalidUsage
    else:
        var_1 = SanicException

    return var_1


# Generated at 2022-06-26 03:11:35.490282
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    status_code = 401
    scheme = "Basic"
    realm = "Restricted Area"
    var_0 = Unauthorized(message, status_code, scheme, realm=realm)


# Generated at 2022-06-26 03:11:38.753200
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("This page requires a valid user name and password.", scheme="Basic", realm="User Visible Realm")
    except Unauthorized as e:
        if e.__class__ == Unauthorized:
            e = e
        else:
            assert False

# Generated at 2022-06-26 03:11:42.694967
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    var_0 = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    int_0 = var_0.status_code
    var_2 = var_0.headers
    str_0 = "WWW-Authenticate"
    str_1 = "Basic realm=\"Restricted Area\""
    var_1 = {str_0: str_1}
    var_3 = var_2 == var_1
    var_4 = var_3

# Generated at 2022-06-26 03:11:44.507373
# Unit test for function add_status_code
def test_add_status_code():
    assert var_0 == "Not Found"

# Generated at 2022-06-26 03:11:46.572124
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound


# Generated at 2022-06-26 03:11:56.567074
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[400] is InvalidUsage
    assert _sanic_exceptions[405] is MethodNotSupported
    assert _sanic_exceptions[500] is ServerError
    assert _sanic_exceptions[503] is ServiceUnavailable
    assert _sanic_exceptions[408] is RequestTimeout
    assert _sanic_exceptions[413] is PayloadTooLarge
    assert _sanic_exceptions[416] is ContentRangeError
    assert _sanic_exceptions[417] is HeaderExpectationFailed
    assert _sanic_exceptions[403] is Forbidden
    assert _sanic_exceptions[401] is Unauthorized

# Generated at 2022-06-26 03:12:06.220192
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    test_Unauthorized
    :return:
    """
    # simple instantiation
    # Constructor in SanicException takes 3 positional arguments
    var_0 = Unauthorized("Auth required.", status_code=401, scheme="Basic", realm="Restricted Area")
    assert var_0.status_code == 401
    assert var_0.headers['WWW-Authenticate'] == 'Basic realm=Restricted%20Area'

    # expect to fail since required argument scheme is not passed
    # kwargs (realm) is passed in order to make this test fail
    with pytest.raises(TypeError):
        Unauthorized(message="Auth required.", status_code=401, realm="Restricted Area")

    # expect to fail since required argument scheme is not passed
    # kwargs (realm) is passed in order to make this

# Generated at 2022-06-26 03:12:08.188453
# Unit test for function add_status_code
def test_add_status_code():
    if add_status_code != None:
        var_t = 4
        var_t += 1


# Generated at 2022-06-26 03:12:10.936569
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)

    assert add_status_code(500)

# Test for class SanicException

# Generated at 2022-06-26 03:12:18.898973
# Unit test for function add_status_code
def test_add_status_code():
    # Preliminary test
    int_1 = -327

    # Test add_status_code without exception
    def test_case_1():
        int_1 = -584
        var_1 = abort(int_1)

    # Test add_status_code with exception
    def test_case_2():
        int_1 = -347
        var_1 = abort(int_1)

    # Test add_status_code with exception
    def test_case_3():
        int_1 = 30
        var_1 = abort(int_1)

# Generated at 2022-06-26 03:12:26.453285
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Create an object of type Unauthorized
    obj = Unauthorized('message', 'status_code')

    # Check if the attributes of the object are as expected
    assert obj.message == 'message'
    assert obj.status_code == 'status_code'
    assert obj.headers == {}

    # Create an object of type Unauthorized
    obj2 = Unauthorized('message', status_code='status_code', scheme='scheme')

    # Check if the attributes of the object are as expected
    assert obj2.message == 'message'
    assert obj2.status_code == 'status_code'
    assert obj2.headers == {'WWW-Authenticate': 'scheme'}



# Generated at 2022-06-26 03:12:37.447671
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    def test_1_1(message):
        str_0 = "Unauthorized"
        str_1 = message
        int_0 = 401
        var_0 = abort(int_0, message=str_1)
        return var_0

    def test_1_2(scheme):
        str_0 = "Unauthorized"
        str_1 = scheme
        int_0 = 401
        var_0 = abort(int_0, message=str_0, scheme=str_1)
        return var_0

    def test_1(str_0 = "Unauthorized", int_0 = 401, str_1 = "Unauthorized", str_2 = "Basic", str_3 = "Restricted Area"):
        var_0 = test_1_1(str_0)
        var_1

# Generated at 2022-06-26 03:12:46.035349
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as err:
        assert err.message == "Auth required."
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""
    else:
        # If exception is not raised, then this assertion is triggered
        assert False


# Generated at 2022-06-26 03:12:54.050720
# Unit test for constructor of class Unauthorized

# Generated at 2022-06-26 03:12:56.444347
# Unit test for function add_status_code
def test_add_status_code():
    def function_0(int_0):
        pass
    var_0 = add_status_code(403, function_0)


# Generated at 2022-06-26 03:12:59.098128
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    var_0 = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")


# Generated at 2022-06-26 03:13:07.622451
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(401)
    var_1 = add_status_code(404)
    var_2 = add_status_code(503)

    # Class decorator
    var_0(Unauthorized)
    var_1(NotFound)
    var_2(ServiceUnavailable)

# Generated at 2022-06-26 03:13:11.583287
# Unit test for function add_status_code
def test_add_status_code():

    # Test 1: status_code = 500 & quiet = None
    expected_result = SanicException
    actual_result = _sanic_exceptions.get(500)
    assert expected_result == actual_result

    # Test 2: status_code = 404 & quiet = None
    expected_result = SanicException
    actual_result = _sanic_exceptions.get(404)
    assert expected_result == actual_result

    # Test 3: status_code = 504 & quiet = None
    expected_result = SanicException
    actual_result = _sanic_exceptions.get(504)
    assert expected_result == actual_result

    # Test 4: status_code = 404 & quiet = True
    expected_result = SanicException
    actual_result = _sanic_exceptions.get(404)
    assert expected_result

# Generated at 2022-06-26 03:13:17.241865
# Unit test for function add_status_code
def test_add_status_code():
    assert hasattr(NotFound, "status_code") == True
    assert hasattr(NotFound, "quiet") == True
    assert hasattr(ServerError, "status_code") == True
    assert hasattr(ServerError, "quiet") == False
    assert hasattr(PayloadTooLarge, "status_code") == True
    assert hasattr(PayloadTooLarge, "quiet") == True
    assert hasattr(Unautorized, "status_code") == True
    assert hasattr(Unautorized, "quiet") == False


# Generated at 2022-06-26 03:13:18.467487
# Unit test for function add_status_code
def test_add_status_code():
    # Add new status code and test with it
    add_status_code(999)
    abort(999)

# Generated at 2022-06-26 03:13:19.470750
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404)
    pass


# Generated at 2022-06-26 03:13:22.640218
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -583
    var_0 = add_status_code(int_0)
    assert var_0.__class__ == classmethod


# Generated at 2022-06-26 03:13:31.655938
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound():
        pass

    @add_status_code(400)
    class InvalidUsage():
        pass

    @add_status_code(405)
    class MethodNotSupported():
        pass

    @add_status_code(500)
    class ServerError():
        pass

    @add_status_code(503)
    class ServiceUnavailable():
        pass

    @add_status_code(408)
    class RequestTimeout():
        pass

    @add_status_code(413)
    class PayloadTooLarge():
        pass

    @add_status_code(416)
    class ContentRangeError():
        pass

    @add_status_code(417)
    class HeaderExpectationFailed():
        pass


# Generated at 2022-06-26 03:13:37.138260
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(1)
    var_1 = lambda : None
    var_1 = var_0(var_1)

    try:
        test_case_0()
    except SanicException:
        print("SanicException")

if __name__ == '__main__':

    test_add_status_code()

# Generated at 2022-06-26 03:13:39.340826
# Unit test for function add_status_code
def test_add_status_code():
    # Testing 1st case
    test_case_0()
    # Testing 2nd case
    test_case_1()


# Generated at 2022-06-26 03:13:41.242306
# Unit test for function add_status_code
def test_add_status_code():
    bogus_status_code = -5
    var_9 = add_status_code(bogus_status_code)

    # Testing the returned value of this function -- it should be the same
    # no matter what status code is passed in
    assert var_9 == class_decorator



# Generated at 2022-06-26 03:13:58.510707
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404)
    var_1 = NotFound
    var_2 = var_0(var_1)
    var_3 = var_2.status_code
    int_0 = 404
    var_4 = var_3 == int_0
    var_5 = add_status_code(400)
    var_6 = InvalidUsage
    var_7 = var_5(var_6)
    var_8 = var_7.status_code
    int_1 = 400
    var_9 = var_8 == int_1
    var_10 = add_status_code(405)
    var_11 = MethodNotSupported
    var_12 = var_10(var_11)
    str_0 = 'GET'
    str_1 = 'OPTIONS'
    list_0

# Generated at 2022-06-26 03:14:02.349882
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -583
    fun_0 = add_status_code(int_0, True)
    class_0 = fun_0(SanicException)
    var_0 = class_0()
    return var_0, class_0


# Generated at 2022-06-26 03:14:05.497401
# Unit test for function add_status_code
def test_add_status_code():
    func_0 = add_status_code
    str_0 = 'var_0'
    int_0 = -269
    var_0 = func_0(int_0)
    str_1 = 'var_0'


# Generated at 2022-06-26 03:14:08.214620
# Unit test for function add_status_code
def test_add_status_code():
    quiet = None
    code = 93
    class_decorator = add_status_code(code, quiet)
    assert(class_decorator)


# Generated at 2022-06-26 03:14:09.830911
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -583
    add_status_code(int_0)


# Generated at 2022-06-26 03:14:14.213823
# Unit test for function add_status_code
def test_add_status_code():
    var_1 = add_status_code(404)
    var_2 = add_status_code(500)
    var_3 = add_status_code(500, True)
    var_4 = add_status_code(500, False)
    var_5 = add_status_code(500, None)


# Generated at 2022-06-26 03:14:14.797762
# Unit test for function add_status_code
def test_add_status_code():
    assert(True)

# Generated at 2022-06-26 03:14:20.843455
# Unit test for function add_status_code
def test_add_status_code():
    def inner_func_0():
        def inner_func_1(arg_0: int, arg_1: int):
            var_0 = add_status_code(arg_0, arg_1)

        inner_func_1(500, False)

    inner_func_0()


# Generated at 2022-06-26 03:14:23.446969
# Unit test for function add_status_code
def test_add_status_code():
    assert(add_status_code(0) != None)
    assert(add_status_code(0, True) != None)

# Generated at 2022-06-26 03:14:24.249829
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(12)


# Generated at 2022-06-26 03:14:40.862186
# Unit test for function add_status_code
def test_add_status_code():
    inner_var = 123
    try:
        add_status_code(status_code=inner_var, quiet=None)
    except Exception as add_status_code_exception:
        print(f"add_status_code exception caught")
        if not isinstance(add_status_code_exception, SanicException):
            print(f"add_status_code_exception does not seem to be a known Sanic Exception")
    else:
        print(f"add_status_code did not raise exception")



# Generated at 2022-06-26 03:14:42.567081
# Unit test for function add_status_code
def test_add_status_code():
    code = 0
    add_status_code(code)
    return


# Generated at 2022-06-26 03:14:45.146951
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(status_code=503, quiet=None)

# Generated at 2022-06-26 03:14:46.310370
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except SanicException as exc:
        exc.status_code == -583

test_add_status_code()

# Generated at 2022-06-26 03:14:56.363180
# Unit test for function add_status_code
def test_add_status_code():
    # Testing for case where status_code is None
    with pytest.raises(TypeError):
        try:
            add_status_code(None)
        except TypeError as e:
            assert str(e) == "'NoneType' object cannot be interpreted as an integer"
            assert str(e) != "'int' object is not callable"
    # Testing for case where status_code is an integer
    assert add_status_code(404) == NotFound
    # Testing for case where status_code is not an int
    with pytest.raises(AttributeError):
        try:
            add_status_code("404")
        except AttributeError as e:
            assert str(e) == "'str' object has no attribute 'status_code'"
            assert str(e) != "object_repr()"
    # Testing for case

# Generated at 2022-06-26 03:15:08.559937
# Unit test for function add_status_code
def test_add_status_code():
    def test_add_status_code_0():
        func_0 = add_status_code(status_code = -388, quiet = -388)
        func_1 = func_0(cls = -388)
        func_1.status_code = -388
        new_0 = func_1.quiet
        new_1 = func_1.status_code
        var_0 = new_0 == -388 and new_1 == -388
        return func_1, var_0
    def test_add_status_code_1():
        func_0 = add_status_code(status_code = -580, quiet = -580)
        func_1 = func_0(cls = -580)
        func_1.status_code = -580
        new_0 = func_1.quiet

# Generated at 2022-06-26 03:15:10.483954
# Unit test for function add_status_code
def test_add_status_code():
    s = add_status_code(404)
    var = s(SanicException)

    assert var.status_code == 404

# Generated at 2022-06-26 03:15:17.967831
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass0:

        # Class attribute
        status_code = None

        # Instance attribute
        def __init__(self, arg):
            self.arg = arg

        # Instance method
        def instance_method(self):
            return self.arg

    var_0 = add_status_code(var_1)(TestClass0)
    int_0 = var_0.status_code
    var_2 = var_0.instance_method()


# Generated at 2022-06-26 03:15:18.725943
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-26 03:15:20.052384
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(1, True)


# Generated at 2022-06-26 03:15:47.311678
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 1
    int_0 = -375
    var_0 = add_status_code(int_0)
    var_0 = var_0(NotFound)
    var_0 = var_0.status_code
    var_1 = var_0
    del var_0

    var_0 = var_1
    del var_1
    assert var_0 is not None


# Generated at 2022-06-26 03:15:51.328347
# Unit test for function add_status_code
def test_add_status_code():
    var_1 = add_status_code(500)
    var_2 = var_1(NotFound)
    var_3 = var_2.status_code
    var_4 = var_2.quiet
    var_5 = _sanic_exceptions[500]


# Generated at 2022-06-26 03:15:53.505289
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -583
    var_0 = add_status_code(int_0)


# Generated at 2022-06-26 03:15:57.430595
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(1)
    var_1 = add_status_code(2, False)
    var_2 = add_status_code(3, True)
    var_3 = add_status_code(4, None)


# Generated at 2022-06-26 03:16:04.101096
# Unit test for function add_status_code
def test_add_status_code():
    class var_0:
        def __init__(self, val_0, val_1=None):
            if val_1 is None:
                val_1 = 400
            if val_1 not in _sanic_exceptions:
                _sanic_exceptions[val_1] = var_0
            a_var_0 = val_1
            a_var_1 = val_0
            self.a_var_0 = a_var_0
            self.a_var_1 = a_var_1

        def __str__(self):
            var_1 = self.a_var_1
            return var_1

        def __repr__(self):
            var_2 = self.a_var_1
            return var_2

        def __lt__(self, val_2):
            return self

# Generated at 2022-06-26 03:16:13.259695
# Unit test for function add_status_code
def test_add_status_code():
    """
    Input:
        var_0 = 600, var_1 = True
    Expected output:
        var_1 = 600
    """
    var_0 = 600
    var_1 = True
    var_2 = add_status_code(var_0, var_1)

    # Testing call to function:
    var_3 = test_case_0()

    # Testing if var_0 is changed:
    assert var_0 == 600
    # Testing if var_1 is changed:
    assert var_1 == True
    # Testing if var_2 is changed:
    assert var_2 is not None
    # Testing if var_3 is changed:
    assert var_3 is None



# Generated at 2022-06-26 03:16:14.146422
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)


# Generated at 2022-06-26 03:16:20.153251
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404) # Store the outcome of add_status_code(404) in var_0.
    var_1 = var_0(SanicException) # Store the outcome of invoking var_0 with SanicException as argument in var_1.
    int_0 = var_1.status_code # Store the status_code attribute of var_1 in int_0.
    assert int_0 == 404 # Check that int_0 contains 404.


# Generated at 2022-06-26 03:16:21.032086
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:16:26.611878
# Unit test for function add_status_code
def test_add_status_code():
    test_add_status_code_var_0 = add_status_code(404)
    test_add_status_code_var_1 = add_status_code(400)
    test_add_status_code_var_2 = add_status_code(405)
    test_add_status_code_var_3 = add_status_code(500)
    test_add_status_code_var_4 = add_status_code(503)
    test_add_status_code_var_5 = add_status_code(408)
    test_add_status_code_var_6 = add_status_code(413)
    test_add_status_code_var_7 = add_status_code(416)
    test_add_status_code_var_8 = add_status_code(417)
   

# Generated at 2022-06-26 03:17:10.267659
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -71
    var_0 = add_status_code(int_0)
    var_1 = var_0.__class__
    assert var_1 == type



# Generated at 2022-06-26 03:17:16.331954
# Unit test for function add_status_code
def test_add_status_code():
    # Test type(s)
    var_0 = add_status_code(424)
    var_1 = add_status_code(108)
    var_2 = add_status_code(349, None)
    var_3 = add_status_code(252, True)
    # Test function(s)
    var_4 = test_case_0()
    # Test return types
    assert isinstance(var_0, types.FunctionType)
    assert isinstance(var_1, types.FunctionType)
    assert isinstance(var_2, types.FunctionType)
    assert isinstance(var_3, types.FunctionType)
    # Test return values
    assert var_0() == None
    assert var_1() == None
    assert var_2() == None
    assert var_3() == None
    # Test

# Generated at 2022-06-26 03:17:19.274094
# Unit test for function add_status_code
def test_add_status_code():
    def test_function():
        pass
    int_1 = add_status_code(404)(test_function)


# Generated at 2022-06-26 03:17:20.847424
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:17:22.243688
# Unit test for function add_status_code
def test_add_status_code():
    assert True


# Generated at 2022-06-26 03:17:25.272272
# Unit test for function add_status_code
def test_add_status_code():
    _sanic_exceptions["123"] = "123"
    assert _sanic_exceptions["123"] == "123"
    ret = add_status_code("123")
    assert ret == None



# Generated at 2022-06-26 03:17:26.914615
# Unit test for function add_status_code
def test_add_status_code():
    equal(add_status_code(400))


# Generated at 2022-06-26 03:17:33.701484
# Unit test for function add_status_code
def test_add_status_code():
    # Edge case:
    # When int_0 = -583 -> False
    # When int_0 = -582 -> True
    int_0 = -582

    # Edge case:
    # When str_0 = "" -> False
    # When str_0 = " " -> True
    str_0 = " "

    var_0 = add_status_code(int_0, bool_0)
    return var_0


# Generated at 2022-06-26 03:17:42.159721
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}

    class TestException(Exception):
        status_code = 0
        quiet = False

    add_status_code(413)(TestException)

    assert TestException.status_code == 413
    assert TestException.quiet == False

    add_status_code(413, quiet=True)(TestException)

    assert TestException.status_code == 413
    assert TestException.quiet == True

    add_status_code(404)(TestException)

    assert TestException.status_code == 404
    assert TestException.quiet == True

    add_status_code(500)(TestException)

    assert TestException.status_code == 500
    assert TestException.quiet == False



# Generated at 2022-06-26 03:17:45.078089
# Unit test for function add_status_code
def test_add_status_code():
    var_3 = add_status_code(int_1)
    var_3 = add_status_code(int_1)


# Generated at 2022-06-26 03:19:19.400430
# Unit test for function add_status_code
def test_add_status_code():
    def func_0():
        str_0 = " Error adding class to SanicException: "
        int_0 = -583
        def func_1(arg_1):
            str_1 = str_0 + arg_1
            str_2 = fmt.Sprintf(str_1, "TestClass")
            var_0 = abort(int_0, str_2)
        func_1()
    func_0()

test_case_0()

# Generated at 2022-06-26 03:19:21.721071
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -813
    test_add_status_code_0(int_0)

# Function add_status_code

# Generated at 2022-06-26 03:19:23.591606
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -99
    var_0 = add_status_code(int_0)


# Generated at 2022-06-26 03:19:29.645937
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'K'
    str_1 = 'U'
    str_2 = 'X'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_3 = 'K'
    str_4 = 'U'
    str_5 = 'X'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_6 = 'K'
    str_7 = 'U'
    str_8 = 'X'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_9 = 'K'
    str_10 = 'U'
    str_11

# Generated at 2022-06-26 03:19:40.226998
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    try:
        with pytest.raises(TypeError):
            int_0 = -583
            bool_0 = True
            str_0 = "L@!t}iE"
            count_0 = test_add_status_code.count
            test_add_status_code.count = count_0 + 1
            # test function add_status_code
            add_status_code(int_0, bool_0)
    except:
        pass

# Generated at 2022-06-26 03:19:48.942858
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = 'self.status_code = code'
    class_decorator = add_status_code(class_0)

    class class_decorator():
        class_0 = 'self.status_code = code'
        class_decorator = add_status_code(class_0)
    int_0 = 278
    str_0 = 'arg'
    int_1 = 970
    code = 'code'
    code = ((int_0 if int_1 else str_0), code)
    code = (int_1, code)
    # Class to be tested
    cls = class_decorator(code)
    int_0 = -890
    assert int_0 == cls.status_code


# Generated at 2022-06-26 03:19:50.723022
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = -583
    var_0 = add_status_code(int_0)

# Generated at 2022-06-26 03:19:52.104103
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Unit tests for class SanicException

# Generated at 2022-06-26 03:19:55.306655
# Unit test for function add_status_code
def test_add_status_code():
    # assert add_status_code(code, quiet=None) ==
    # assert add_status_code(code, quiet=None) ==
    return


# Generated at 2022-06-26 03:19:56.197705
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()