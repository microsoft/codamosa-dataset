

# Generated at 2022-06-26 03:11:17.752846
# Unit test for function add_status_code
def test_add_status_code():
    # test cases
    # Case 0 (SanicException)
    test_case_0()
    # Case 1
    add_status_code(200)
    try:
        add_status_code(500)
        add_status_code(500, True)
        add_status_code(500, False)
        add_status_code(500, None)
    except:
        pass
    # Case 2
    def test_case_2():
        return NotFound('NBaTw$<WW\\Z]i')
    test_case_2()



# Generated at 2022-06-26 03:11:18.731910
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:11:28.985763
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Tests to make sure that the Unauthorized exception is being properly
    thrown.
    """
    # Test when message is not given
    try:
        Unauthorized()
    except TypeError:
        print("Unauthorized exception thrown correctly")
    else:
        print("Unauthorized exception not thrown correctly")

    # Test when scheme not given
    try:
        Unauthorized("hello")
    except TypeError:
        print("Unauthorized exception thrown correctly")
    else:
        print("Unauthorized exception not thrown correctly")

    # Test when realm not provided
    try:
        Unauthorized("hello", scheme = "Basic")
    except TypeError:
        print("Unauthorized exception thrown correctly")
    else:
        print("Unauthorized exception not thrown correctly")

    # Test when realm is provided
   

# Generated at 2022-06-26 03:11:38.826352
# Unit test for function add_status_code
def test_add_status_code():
    # def __init__(self, message, status_code=None, quiet=None):
    str_0 = 'vS8K%mwB2P]{'
    invalid_usage_0 = InvalidUsage(str_0, 565)
    str_1 = '\\QkIm{H@J=nj'
    method_not_supported_0 = MethodNotSupported(str_1, 565, [565, 565])
    str_2 = 'NRyjJuxc%XNl'
    content_range_error_0 = ContentRangeError(str_2, 565)
    str_3 = 'pmApnkzt d:r'
    file_not_found_0 = FileNotFound(str_3, 565, 565)

# Generated at 2022-06-26 03:11:40.090408
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:11:43.030489
# Unit test for function add_status_code
def test_add_status_code():
    sanic_exception = ServerError()
    sanic_exception = ServerError('Internal server error')


# Generated at 2022-06-26 03:11:51.530595
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 337
    quiet_0 = None
    code_1 = code_0
    quiet_1 = quiet_0
    not_found_0 = NotFound
    not_found_1 = _sanic_exceptions[code_1]
    payload_too_large_0 = PayloadTooLarge
    payload_too_large_1 = _sanic_exceptions[code_0]
    assert(issubclass(not_found_1, SanicException))
    assert(issubclass(payload_too_large_1, SanicException))



# Generated at 2022-06-26 03:11:54.163661
# Unit test for function add_status_code
def test_add_status_code():
    func_0 = add_status_code(test_case_0)
    func_1 = add_status_code(test_case_0, quiet=True)
    func_2 = add_status_code(test_case_0, quiet=False)
    func_3 = add_status_code(test_case_0, quiet=None)


# Generated at 2022-06-26 03:12:01.898586
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Create an UnauthorizedException and check if scheme, realm and message are correctly set
    str_0 = 'wwKd8Z^p,}v4'
    str_1 = 'm)2U$$m6s-s'
    str_2 = 'R{v@\\9\\\\<~'
    str_3 = 'q!oT=6S'
    str_4 = '8_vBRp9{]4'
    str_5 = 'd6Uf^5r5z]{'
    str_6 = '5<m9cs@';
    str_7 = 'xilp&'
    str_8 = 'z$*%3FV!X'
    str_9 = 'l[xsfTX#'
    str_10 = '{Zd$3'

# Generated at 2022-06-26 03:12:03.459150
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = 'KPYw=J`hQW&|}K>q'
    unauthorized_0 = Unauthorized(str_0)



# Generated at 2022-06-26 03:12:08.277963
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except NotFound as not_found_0:
        assert not_found_0.status_code == 404



# Generated at 2022-06-26 03:12:14.048375
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = 'h`sW/\\rj_G'
    scheme_0 = 'Basic'
    realm_0 = 'a"Yj@L:.P?f'
    Unauthorized(str_0, status_code=401, scheme=scheme_0, realm=realm_0)


# Generated at 2022-06-26 03:12:17.707169
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # Instantiate a class Unauthorized and test if it is handled correctly.
        raise Unauthorized('Unauthorized', scheme='Digest', realme='Restricted Area')
    except Unauthorized:
        pass



# Generated at 2022-06-26 03:12:21.789327
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    msg_0 = '{F_K)Zk'
    status_0 = 'basic'
    realm_0 = 'msU1x|!'
    Unauthorized(msg_0, status_0, scheme=status_0, realm=realm_0)


# Generated at 2022-06-26 03:12:31.764870
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'mv \\^l'
    not_found_0 = NotFound(str_0)
    # Test that both arguments are optional
    try:
        add_status_code(0)
        assert False
        # Test that kwargs are unused in SanicException
    except TypeError:
        # Expected exception
        pass
    # Test that SanicException is written to both arguments
    # Test that status_code is written to SanicException
    # Test that kwargs are unused in SanicException
    exception_0 = SanicException(str_0)
    # Test that str_0 is written to SanicException
    assert exception_0.message == str_0
    # Test that status_code is written to SanicException
    assert exception_0.status_code is None
    # Test that status_code is

# Generated at 2022-06-26 03:12:33.090614
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)


# Generated at 2022-06-26 03:12:35.437308
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 0
    # Object not found
    # Should raise NotFound exception with message NBaTw$<WW\Z]i
    test_case_0()


# Generated at 2022-06-26 03:12:39.344503
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(None, None)
    except NotFound as not_found_0:
        str_0 = 'NBaTw$<WW\\Z]i'
        assert not_found_0.message == str_0
    else:
        assert False


# Generated at 2022-06-26 03:12:41.346472
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized_0 = Unauthorized('Yc|@R^.')


# Generated at 2022-06-26 03:12:43.797499
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404, quiet=None).__name__ == 'NotFound'


# Generated at 2022-06-26 03:12:55.139822
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    t_0 = Unauthorized("Auth required.", status_code=401)
    haha = t_0.headers.get("WWW-Authenticate")
    print(haha)
    t_1 = Unauthorized("Auth required.", status_code=401, scheme="Basic", realm="Restricted Area")
    print(t_1.headers.get("WWW-Authenticate"))
    t_2 = Unauthorized("Auth required.", status_code=401, scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    print(t_2.headers.get("WWW-Authenticate"))
    t_3 = Unauthorized("Auth required.", status_code=401, scheme="Bearer")

# Generated at 2022-06-26 03:13:04.379932
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = 'NBaTw$<WW\\Z]i'
    str_1 = 'C`Jt7G+9XZDV/'
    str_2 = '|zI5+wVf{R-Jp'
    str_3 = '<^+R=[NH@p@= '
    unauthorized_0 = Unauthorized(str_0, scheme=str_1, realm=str_2, qop=str_3)
    assert unauthorized_0.status_code == 401
    assert unauthorized_0.scheme == '<^+R=[NH@p@= '
    assert unauthorized_0.message == 'NBaTw$<WW\\Z]i'


# Generated at 2022-06-26 03:13:08.752422
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = 'invalid credentials'
    scheme = 'Basic'
    unauthorized = Unauthorized(message, scheme='Basic', realm='Restricted Area')


# Generated at 2022-06-26 03:13:13.997382
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = 'isJh{'
    byte_0 = b'X_h;'
    byte_1 = b'G>S\\f'
    byte_2 = b'G>S\\f'
    unauthorized_0 = Unauthorized(str_0, scheme=byte_0, realm=byte_1, qop=byte_2)


# Generated at 2022-06-26 03:13:21.398057
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)

    def class_decorator(cls):
        cls.status_code = 500
        _sanic_exceptions[500] = cls
        return cls

    NotFound(status_code=500)


# Generated at 2022-06-26 03:13:28.800022
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    unau_0 = Unauthorized("Auth required.")
    unau_1 = Unauthorized("Invalid login.", scheme="Basic", realm="Restricted Area")
    unau_2 = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    unau_3 = Unauthorized("Auth required.", scheme="Bearer")
    unau_4 = Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

# Generated at 2022-06-26 03:13:34.521595
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = 'NBaTw$<WW\\Z]i'
    int_0 = 206
    Forbidden.__init__(Forbidden(), str_0, int_0, 'Basic', realm='Restricted Area')
    Forbidden.__init__(Forbidden(), str_0, int_0, 'Basic')
    Unauthorized.__init__(Unauthorized(), str_0, int_0, 'Basic', realm='Restricted Area')
    Unauthorized.__init__(Unauthorized(), str_0, int_0, 'Basic')
    Unauthorized.__init__(Unauthorized(), str_0, int_0, 'Digest', realm='Restricted Area', qop='auth, auth-int', algorithm='MD5', nonce='abcdef', opaque='zyxwvu')

# Generated at 2022-06-26 03:13:37.232602
# Unit test for function add_status_code
def test_add_status_code():
    # Test for function add_status_code
    # TODO: Write unit tests for add_status_code
    pass



# Generated at 2022-06-26 03:13:41.205800
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = add_status_code(404)
    server_error_0 = ServerError('8"ZWpGow?L=R')
    server_error_0.status_code = 503
    server_error_0.status_code = 500


# Generated at 2022-06-26 03:13:42.400745
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code == FunctionType


# Generated at 2022-06-26 03:13:49.905188
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message_0 = 'jYq!q3@zZg9X&'
    scheme_0 = 'QV7{5Q$**rYw'
    realm_0 = 'z7C_9?*0Dp+$'
    Unauthorized(message_0, scheme_0, realm=realm_0)


# Generated at 2022-06-26 03:13:54.551952
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(404)
    handler_0 = class_decorator_0(NotFound)
    add_status_code(404, True)
    add_status_code(500)
    add_status_code(500, False)


# Generated at 2022-06-26 03:13:56.294391
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = '%u-%u-%u'
    Unauthorized(message)


# Generated at 2022-06-26 03:13:58.558795
# Unit test for function add_status_code
def test_add_status_code():

    # Negative case #1: NotFound(str_0)
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 03:14:03.802330
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message_0 = 'test_message_0'
    status_code_0 = 'test_status_code_0'
    scheme_0 = 'test_scheme_0'
    realm_0 = 'test_realm_0'
    unauthorized_0 = Unauthorized(message_0, status_code=status_code_0, scheme=scheme_0, realm=realm_0)


# Generated at 2022-06-26 03:14:09.117287
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message_0 = '\x05.\x9d\x8e\x94'
    str_0 = '<\x11%\x92\x0b\xcd'
    str_1 = '\xbc\x1b\x8e\x8b'
    _Unauthorized = Unauthorized(message_0, scheme='Basic', realm='')
    str_2 = '\x05.\x9d\x8e\x94'
    str_3 = '<\x11%\x92\x0b\xcd'
    str_4 = '\xbc\x1b\x8e\x8b'
    _Unauthorized = Unauthorized(str_2, scheme=str_3, realm=str_4)



# Generated at 2022-06-26 03:14:11.188341
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except NotFound:
        pass


# Generated at 2022-06-26 03:14:17.541403
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized

# Generated at 2022-06-26 03:14:19.252978
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized_0 = Unauthorized("", scheme="")


# Generated at 2022-06-26 03:14:24.180295
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    status_code_0 = True * 0
    message_0 = bool() * -1
    scheme_0 = float()
    kwargs_0 = dict()
    unauthorized_0 = Unauthorized(message_0, status_code_0, scheme_0, **kwargs_0)


# Generated at 2022-06-26 03:14:35.399690
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException_0(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True
        
    add_status_code_0 = add_status_code(200)
    add_status_code_0(SanicException_0)


# Generated at 2022-06-26 03:14:37.729023
# Unit test for function add_status_code
def test_add_status_code():
    # key=405, value=<class 'sanic.exceptions.MethodNotSupported'>
    method_not_supported = {(405, MethodNotSupported)}


# Generated at 2022-06-26 03:14:49.345663
# Unit test for function add_status_code
def test_add_status_code():

    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    str_0 = 'E:o>aYw'
    test_add_status_code_0 = add_status_code(404)
    @add_status_code(404)
    class TestCase:
        pass
    test_add_status_code_1 = add_status_code(405)
    @add_status_code(405)
    class TestCase1:
        pass
    str_1 = 'c%>e@CZKlW'
    quiet = None

# Generated at 2022-06-26 03:14:54.272173
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = None
    assert add_status_code(status_code_0)(NotFound) is NotFound
    status_code_0 = 408
    class Class_0():
        status_code = 408

    assert add_status_code(status_code_0)(Class_0) is Class_0


# Generated at 2022-06-26 03:14:58.486831
# Unit test for function add_status_code
def test_add_status_code():
    str_2 = 'NBaTw$<WW\\Z]i'
    not_found_3 = NotFound(str_0)
    # check the __init__ of NotFound, it will assert status_code == 404
    try:
        assert not_found_3.status_code == 404
    except:
        NotFound.status_code = 404



# Generated at 2022-06-26 03:14:59.413344
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:15:08.380545
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_0():
        add_status_code(500)

    def test_case_1():
        add_status_code(200, quiet=True)

    def test_case_2():
        add_status_code(200, quiet=False)

    def test_case_3():
        add_status_code(None)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 03:15:09.776563
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)


# Generated at 2022-06-26 03:15:14.518906
# Unit test for function add_status_code
def test_add_status_code():
    global add_status_code
    def add_status_code(code):
      def class_decorator(cls):
        return cls()
      return class_decorator

    # Test case 0
    test_case_0()



# Generated at 2022-06-26 03:15:20.288714
# Unit test for function add_status_code
def test_add_status_code():
    # Test add_status_code function exception.
    try:
        add_status_code()
        assert False
    except TypeError:
        pass

    # Test add_status_code function exception.
    try:
        add_status_code(1)
        assert False
    except TypeError:
        pass

    # Test add_status_code function exception.
    try:
        add_status_code(1, 2, 3)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-26 03:15:29.045966
# Unit test for function add_status_code
def test_add_status_code():
    if _sanic_exceptions.get(404) is not NotFound:
        raise AssertionError('expected to get NotFound on key 404, got None')



# Generated at 2022-06-26 03:15:32.073840
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound('NBaTw$<WW\\Z]i')
    assert not_found_0.status_code == 404


# Generated at 2022-06-26 03:15:35.466519
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(NotFound) as exc_info:
        test_case_0()
    assert exc_info.type == NotFound

test_add_status_code()

# Generated at 2022-06-26 03:15:47.141532
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(0)
    add_status_code(0, False)
    add_status_code(0, True)
    add_status_code(1)
    add_status_code(1, True)
    add_status_code(1, False)
    add_status_code(2, True)
    add_status_code(2)
    add_status_code(2, False)
    add_status_code(3, True)
    add_status_code(3)
    add_status_code(3, False)
    add_status_code(4, True)
    add_status_code(4, False)
    add_status_code(4)
    add_status_code(5, False)
    add_status_code(5, True)
    add_status_

# Generated at 2022-06-26 03:15:49.830589
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    TestClass = add_status_code(404)(TestClass)
    assert TestClass.status_code == 404


# Generated at 2022-06-26 03:15:53.180904
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except NotFound as not_found_0:
        assert not_found_0.args[0] == 'NBaTw$<WW\\Z]i'


# Generated at 2022-06-26 03:15:58.193383
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator = add_status_code(404)
    new_class = class_decorator(NotFound)
    # check status code
    assert new_class.status_code == 404
    # check quiet value
    assert new_class.quiet == True
    assert new_class.message == 'NBaTw$<WW\\Z]i'


# Generated at 2022-06-26 03:16:02.131884
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 0
    str_0 = 'H0D^k:F)S'
    service_unavailable_0 = ServiceUnavailable(str_0)
    not_found_0 = NotFound(str_0)
    assert status_code_0 == service_unavailable_0.status_code
    if 'H0D^k:F)S' is not None:
        assert not_found_0.message is None

# Generated at 2022-06-26 03:16:10.286912
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 404
    quiet_0 = None
    def callback_0(cls_0):
        cls_0.status_code = code_0
        if(quiet_0 or (quiet_0 is None and (code_0 != 500))):
            cls_0.quiet = True
        _sanic_exceptions[code_0] = cls_0
        return cls_0
    retval_0 = add_status_code(code_0, quiet_0)
    assert(retval_0 == callback_0)


# Generated at 2022-06-26 03:16:11.944029
# Unit test for function add_status_code
def test_add_status_code():
    assert_true(add_status_code)


# Generated at 2022-06-26 03:16:24.174994
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(str_0, str_0) is Unauthorized


# Generated at 2022-06-26 03:16:35.165339
# Unit test for function add_status_code
def test_add_status_code():
    test_case_1_not_found_0 = NotFound('')
    test_case_1_not_found_0.status_code = 404
    test_case_1_not_found_1 = NotFound('')
    test_case_1_not_found_1.status_code = 404
    test_case_1_invalid_usage_0 = InvalidUsage('')
    test_case_1_invalid_usage_0.status_code = 400
    test_case_1_invalid_usage_1 = InvalidUsage('')
    test_case_1_invalid_usage_1.status_code = 400
    test_case_1_method_not_supported_0 = MethodNotSupported('', '', '')
    test_case_1_method_not_supported_0.status_code

# Generated at 2022-06-26 03:16:44.641286
# Unit test for function add_status_code

# Generated at 2022-06-26 03:16:57.031602
# Unit test for function add_status_code
def test_add_status_code():
    # Test with arg: 'value' at position 0
    result = add_status_code('value')
    assert result == class_decorator
    # Test with arg: 'value' at position 0
    result = add_status_code('value')
    assert result == class_decorator
    # Test with arg: 'value' at position 0
    result = add_status_code('value')
    assert result == class_decorator
    # Test with arg: 'value' at position 0
    result = add_status_code('value')
    assert result == class_decorator
    # Test with arg: 'value' at position 0
    result = add_status_code('value')
    assert result == class_decorator
    # Test with arg: 'value' at position 0
    result = add_status_code('value')

# Generated at 2022-06-26 03:16:59.426635
# Unit test for function add_status_code
def test_add_status_code():
    quiet_0 = True
    code_0 = 409
    add_status_code(code_0, quiet_0)


# Generated at 2022-06-26 03:17:07.200957
# Unit test for function add_status_code
def test_add_status_code():
    # initialize the value of "status_code" in the NotFound exception
    not_found = NotFound('Not found')
    # initialize the value of "status_code" in the InvalidUsage exception
    invalid_usage = InvalidUsage('Invalid usage')
    # initialize the value of "status_code" in the MethodNotSupported exception
    method_not_supported = MethodNotSupported(
        'Method not supported',
        method='POST',
        allowed_methods=['GET', 'HEAD'])
    # initialize the value of "status_code" in the ServerError exception
    server_error = ServerError('Server error')
    # initialize the value of "status_code" in the ServiceUnavailable exception
    service_unavailable = ServiceUnavailable('Service unavailable')
    # initialize the value of "status_code" in the URLBuildError exception
    url_build_

# Generated at 2022-06-26 03:17:08.859926
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:17:12.770003
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 0
    for code_0 in range(status_code_0, 0, 0):
        add_status_code(code_0)
    with raises(NotImplementedError):
        add_status_code(status_code_0, quiet=True)


# Generated at 2022-06-26 03:17:17.634771
# Unit test for function add_status_code
def test_add_status_code():
    class sanic_exception_0:
        status_code = -1
        quiet = None
    sanic_exception_0.status_code = sanic_exception_0.status_code + 0
    # No exception was thrown
    class sanic_exception_1:
        status_code = -1
        quiet = None
    sanic_exception_1.status_code = sanic_exception_1.status_code + 0
    # No exception was thrown


# Generated at 2022-06-26 03:17:24.628360
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test0(SanicException):
        pass
    assert Test0.status_code == 200

    @add_status_code(200,True)
    class Test1(SanicException):
        pass
    assert Test1.status_code == 200
    assert Test1.quiet == True

    @add_status_code(300, False)
    class Test2(SanicException):
        pass
    assert Test2.status_code == 300
    assert Test2.quiet == False


# Generated at 2022-06-26 03:17:51.089782
# Unit test for function add_status_code
def test_add_status_code():
    assert callable(add_status_code)
    assert isinstance(add_status_code, (type(Callable), type(FunctionType)))
    assert callable(add_status_code.__code__)
    assert isinstance(add_status_code.__code__, (type(Callable), type(FunctionType)))



# Generated at 2022-06-26 03:17:56.343495
# Unit test for function add_status_code
def test_add_status_code():
    # Create a test case for function add_status_code
    def test_case_0():
        str_0 = 'WV[vf^0:uQE'
        server_error_0 = ServerError(str_0)
    def test_case_1():
        str_1 = 'I5G6S\\DA/D'
        server_error_1 = ServerError(str_1)


# Generated at 2022-06-26 03:18:03.596109
# Unit test for function add_status_code
def test_add_status_code():
    # Check if the instance is created with the correct
    # status code
    assert NotFound.status_code == 404

    # Check that the quiet attribute is updated
    assert NotFound.quiet == True

    # Check the global dictionary was updated
    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-26 03:18:05.007419
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(205) is not None


# Generated at 2022-06-26 03:18:06.656460
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 03:18:15.805182
# Unit test for function add_status_code
def test_add_status_code():
    # Pass

    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Not Found"
        assert e.quiet == True

    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"
        assert e.quiet == True

    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.message == "Method Not Allowed"
        assert e.quiet == True

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
        assert e.quiet == False


# Generated at 2022-06-26 03:18:28.790613
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 204
    class_decorator_0 = add_status_code(status_code_0)
    status_code_1 = 200
    class_decorator_1 = add_status_code(status_code_1)
    status_code_2 = 404
    class_decorator_2 = add_status_code(status_code_2)
    status_code_3 = 505
    class_decorator_3 = add_status_code(status_code_3)
    status_code_4 = 201
    class_decorator_4 = add_status_code(status_code_4, False)



# Generated at 2022-06-26 03:18:29.546597
# Unit test for function add_status_code
def test_add_status_code():
    # unit test for function add_status_code
    return



# Generated at 2022-06-26 03:18:40.790907
# Unit test for function add_status_code
def test_add_status_code():
    
    # Test Case 0
    str_0 = 'NBaTw$<WW\\Z]i'
    add_status_code_0 = add_status_code(str_0)
    not_found_0 = add_status_code_0(NotFound)
    not_found_0_0 = NotFound(str_0)

    # Test Case 1
    add_status_code_1 = add_status_code(type)
    str_1 = 'U'
    invalid_usage_1 = add_status_code_1(InvalidUsage)
    invalid_usage_1_0 = InvalidUsage(str_1, type)

    # Test Case 2
    add_status_code_2 = add_status_code(int)
    str_2 = '#'
    method_not_supported_2 = add_status_

# Generated at 2022-06-26 03:18:42.065962
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) == NotFound


# Generated at 2022-06-26 03:19:30.930926
# Unit test for function add_status_code
def test_add_status_code():
    # Define a function that raises an exception
    def function_0(str_0):
        raise NotFound(str_0)

    # Call the function
    try:
        function_0('NBaTw$<WW\\Z]i')
    except NotFound as e:
        assert e.message == 'NBaTw$<WW\\Z]i'

# Generated at 2022-06-26 03:19:35.392260
# Unit test for function add_status_code
def test_add_status_code():
  global _sanic_exceptions
  global NotFound
  global test_case_0
  _sanic_exceptions.update({404: NotFound})
  test_case_0()

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:19:43.746643
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'NBaTw$<WW\\Z]i'
    assert type(str_0) == str
    not_found_0 = NotFound(str_0)
    test_case_0()
    invalid_usage_0 = InvalidUsage("you messed up", 400)
    my_exception = InvalidUsage("you messed up", 400)
    assert my_exception.status_code == 400
    assert type(invalid_usage_0) == InvalidUsage
    invalid_usage_0 = InvalidUsage("you messed up")
    assert invalid_usage_0.status_code == 400
    assert type(invalid_usage_0) == InvalidUsage


# Generated at 2022-06-26 03:19:44.687466
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:19:49.873047
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'G*[Ov|u$3V>cS'
    invalid_usage_0 = InvalidUsage(str_0)
    assert not_found_0.message == str_0
    assert not_found_0.status_code == 404
    assert not_found_0.quiet == True
    assert invalid_usage_0.message == str_0
    assert invalid_usage_0.status_code == 400
    assert invalid_usage_0.quiet == True


# Generated at 2022-06-26 03:19:50.977532
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(100)


# Generated at 2022-06-26 03:19:53.724950
# Unit test for function add_status_code
def test_add_status_code():
    status_codes = [200, 400, 404, 407, 408, 414, 500]
    assert len(status_codes) == len(set(status_codes))


# Generated at 2022-06-26 03:19:55.700887
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound('NBaTw$<WW\\Z]i')
    test_case_0()

# Generated at 2022-06-26 03:19:57.766565
# Unit test for function add_status_code
def test_add_status_code():
    str_1 = 'NBaTw$<WW\\Z]i'
    not_found_0 = NotFound(str_1)


# Generated at 2022-06-26 03:20:07.215928
# Unit test for function add_status_code
def test_add_status_code():
    def func_0():
        test_case_0()

    test_num = 500

    # Assert add_status_code without arguments
    res_0 = add_status_code(test_num)
    res_1 = add_status_code(test_num)
    res_1()

    # Assert function add_status_code with arguments
    res_2 = add_status_code(test_num)
    res_3 = add_status_code(test_num, quiet=False)
    res_3()

    # Assert function add_status_code with bad arguments
    res_4 = add_status_code(test_num)
    res_5 = add_status_code(test_num, quiet=False)

    # Assert function add_status_code with a different set of bad arguments
    res_6