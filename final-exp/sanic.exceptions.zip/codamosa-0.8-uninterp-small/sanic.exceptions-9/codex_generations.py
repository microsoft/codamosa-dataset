

# Generated at 2022-06-26 03:11:25.881239
# Unit test for function add_status_code
def test_add_status_code():
    retval = add_status_code(test_case_0)
    assert True

# Generated at 2022-06-26 03:11:28.081310
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        notfound_0 = NotFound(None)
    except TypeError:
        pass


# Generated at 2022-06-26 03:11:30.231005
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        invalid_signal_0 = InvalidSignal()


# Generated at 2022-06-26 03:11:34.105305
# Unit test for constructor of class SanicException
def test_SanicException():
    sanic_exception_0 = SanicException("message", 100)
    assert sanic_exception_0.args == ("message",)
    assert sanic_exception_0.status_code is 100


# Generated at 2022-06-26 03:11:35.943898
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    value = ServiceUnavailable (
        message = None, status_code = None, quiet = None
    )


# Generated at 2022-06-26 03:11:37.486136
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:11:40.236311
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 03:11:45.041382
# Unit test for constructor of class Forbidden
def test_Forbidden():

    forbidden = Forbidden('forbidden')
    assert forbidden.args[0] == 'forbidden'
    assert forbidden.message == 'forbidden'
    assert forbidden.status_code == 403
    # assert forbidden.status_name == 'forbidden'


# Generated at 2022-06-26 03:11:46.573266
# Unit test for constructor of class NotFound
def test_NotFound():
	notfound_0 = NotFound()
	return


# Generated at 2022-06-26 03:11:47.431452
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_0 = Forbidden(bytes(), None)


# Generated at 2022-06-26 03:11:54.234640
# Unit test for function add_status_code
def test_add_status_code():
    class CustomError(SanicException):
        pass
    try:
        add_status_code(418)(CustomError)
        raise Exception("unreachable")
    except TypeError:
        return True



# Generated at 2022-06-26 03:11:57.971360
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        assert cls.status_code == None
        return cls

    test_class_decorator = add_status_code(None)(test_class_decorator)
    assert test_class_decorator.status_code == None



# Generated at 2022-06-26 03:12:00.998484
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404, quiet=True)
    assert type(add_status_code(404, quiet=True)) == function
    assert type(add_status_code(500, quiet=True)) == function


# Generated at 2022-06-26 03:12:04.543795
# Unit test for function add_status_code
def test_add_status_code():
    def custom_exception(message, status_code=None, quiet=None):
        SanicException.__init__(self, message, status_code=None, quiet=None)
    custom_exception = add_status_code(200, True)
    assert custom_exception.status_code == 200
    assert custom_exception.quiet == True

# Generated at 2022-06-26 03:12:09.812771
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 1:
    # This raise SanicException() exception
    sanic_exception = SanicException()

    # Error: abort() expected type 'SanicException', but got 'SanicException'
    # abort(500, message="This will error")


# Generated at 2022-06-26 03:12:10.839047
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)(Exception)

# Generated at 2022-06-26 03:12:14.872197
# Unit test for function add_status_code
def test_add_status_code():
    # Test to check if key and values are being passed as expected
    assert _sanic_exceptions[404] == NotFound
    # Test to check if key is being passed as expected
    assert _sanic_exceptions[503] == ServiceUnavailable

# Generated at 2022-06-26 03:12:16.607046
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}
    ## noqa: E501
    add_status_code(400)

    assert _sanic_exceptions == {400: InvalidUsage}


# Generated at 2022-06-26 03:12:20.890484
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    global STATUS_CODES
    add_status_code(400, True)(CustomException)

    assert _sanic_exceptions[400] == CustomException
    assert STATUS_CODES[400] == "Bad Request"



# Generated at 2022-06-26 03:12:28.170500
# Unit test for function add_status_code
def test_add_status_code():
    def test(x):
        pass
    
    # Test function decorator
    decorator_test_0 = add_status_code(500)(test)
    decorator_test_1 = add_status_code(500, quiet=True)(test)
    
    # Test exceptions
    not_found_0 = NotFound()
    invalid_usage_0 = InvalidUsage()
    method_not_supported_0 = MethodNotSupported("a", "b", ["c"])
    server_error_0 = ServerError()
    service_unavailable_0 = ServiceUnavailable()
    url_build_error_0 = URLBuildError()
    file_not_found_0 = FileNotFound("a", "b", "c")
    request_timeout_0 = RequestTimeout("a")
    payload_too_large_0 = PayloadTooLarge

# Generated at 2022-06-26 03:12:32.740944
# Unit test for function add_status_code
def test_add_status_code():
    def dummy(var_0):
        return var_0
    test_0 = add_status_code(404)(dummy)



# Generated at 2022-06-26 03:12:41.326371
# Unit test for function add_status_code
def test_add_status_code():
    import random
    from types import FunctionType, MethodType
    from types import BuiltinFunctionType, BuiltinMethodType

    def f(x):
        return x

    def g(self, x):
        return x

    def h(cls, x):
        return x

    c = random.randint(0, 100)
    assert isinstance(add_status_code(c)(f), FunctionType)
    assert isinstance(add_status_code(c)(g), MethodType)
    assert isinstance(add_status_code(c)(h), BuiltinMethodType)
    assert add_status_code(c)(h) == h

    def _(cls):
        def _(x):
            return x

        return _

    assert isinstance(add_status_code(c)(_(h)), BuiltinFunctionType)




# Generated at 2022-06-26 03:12:52.096061
# Unit test for function add_status_code
def test_add_status_code():
    # test for condition ' if status_code not in (None, 500):'
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized:
        pass
    # test for condition 'status_code is not None:'
    try:
        raise Unauthorized("Auth required.", status_code=200, scheme="Bearer")
    except Unauthorized:
        pass
    # test for condition 'if status_code is not None:'
    try:
        raise Unauthorized("Auth required.", status_code=200, scheme="Bearer")
    except Unauthorized:
        pass
    # test for body of else clause
    try:
        raise SanicException()
    except SanicException:
        pass


# Generated at 2022-06-26 03:12:54.518744
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(Forbidden):
        test_case_0()



# Generated at 2022-06-26 03:12:57.427200
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(var_0)
    class var_1(SanicException):
        pass


# Generated at 2022-06-26 03:13:03.510974
# Unit test for function add_status_code
def test_add_status_code():
    def function(x):
        return x
    ADD_STATUS_CODE_0 = add_status_code(function)
    ADD_STATUS_CODE_1 = add_status_code(
        function, quiet=None, status_code=0, message=''
    )
    ADD_STATUS_CODE_2 = add_status_code(
        function, quiet=None, status_code=0, message=''
    )


# Generated at 2022-06-26 03:13:04.441715
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:13:13.914290
# Unit test for function add_status_code
def test_add_status_code():
    var_1 = int()
    var_2 = bool()
    assert isinstance(add_status_code(var_1, var_2)(_sanic_exceptions.get(var_1)), type(_sanic_exceptions.get(var_1)))
    assert add_status_code(var_1, var_2)(_sanic_exceptions.get(var_1)).status_code == var_1
    assert add_status_code(var_1, var_2)(_sanic_exceptions.get(var_1)).quiet == var_2


# Generated at 2022-06-26 03:13:28.071667
# Unit test for function add_status_code
def test_add_status_code():
    # Test for NotFound
    not_found = NotFound('message')
    assert not_found.status_code == 404
    assert not_found.quiet == True

    # Test for InvalidUsage
    invalid_usage = InvalidUsage('message')
    assert invalid_usage.status_code == 400
    assert invalid_usage.quiet == True

    # Test for MethodNotSupported
    method_not_supported = MethodNotSupported('message', 'method', None)
    assert method_not_supported.status_code == 405
    assert method_not_supported.quiet == False

    # Test for ServerError
    server_error = ServerError('message')
    assert server_error.status_code == 500
    assert server_error.quiet == False

    # Test for ServiceUnavailable
    service_unavailable = ServiceUnavailable('message')
    assert service_un

# Generated at 2022-06-26 03:13:31.507527
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(404, True)
    except Exception:
        pass
    assert True

# Generated at 2022-06-26 03:13:43.737527
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)(InvalidUsage).status_code == 400
    assert add_status_code(400, quiet=False)(InvalidUsage).status_code == 400
    assert add_status_code(400, quiet=True)(InvalidUsage).status_code == 400
    assert add_status_code(400, quiet=None)(InvalidUsage).status_code == 400
    assert add_status_code(500, quiet=True)(InvalidUsage).status_code == 500
    assert add_status_code(500, quiet=None)(InvalidUsage).status_code == 500
    assert add_status_code(500, quiet=False)(InvalidUsage).status_code == 500



# Generated at 2022-06-26 03:13:52.085604
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)
    add_status_code(400)
    add_status_code(405)
    add_status_code(500)
    add_status_code(503)
    add_status_code(408)
    add_status_code(413)
    add_status_code(416)
    add_status_code(417)
    add_status_code(403)
    add_status_code(401)
    add_status_code(200)



# Generated at 2022-06-26 03:13:54.131691
# Unit test for function add_status_code
def test_add_status_code():
    try:
        # test case 0
        test_case_0()
    except Exception:
        pass

# Generated at 2022-06-26 03:13:55.792857
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(var_0)
    assert var_0 is forbidden_0


# Generated at 2022-06-26 03:13:58.453295
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except Forbidden as forbidden_0:
        print(forbidden_0)



# Generated at 2022-06-26 03:14:02.305836
# Unit test for function add_status_code
def test_add_status_code():
    # Test 1
    # Create an instance of Forbidden
    forbidden_0 = Forbidden('Error 400', 400)

    # Test 2
    # Create an instance of MethodNotSupported
    methodnotsupported_0 = MethodNotSupported('POST', ['POST'])


# Generated at 2022-06-26 03:14:04.959780
# Unit test for function add_status_code
def test_add_status_code():
    url_func = add_status_code(1)
    url_deco = url_func(methodNotSupported_0)

    assert(url_deco == methodNotSupported_0)


# Generated at 2022-06-26 03:14:14.949053
# Unit test for function add_status_code
def test_add_status_code():
    forbidden_0 = Forbidden()
    assert forbidden_0.status_code == 403
    assert forbidden_0.quiet == True

    var_2 = bytes()
    forbidden_1 = Forbidden(var_2, var_2)
    assert forbidden_0.status_code == 403
    assert forbidden_0.quiet == True

    invalid_usage_0 = InvalidUsage()
    assert invalid_usage_0.status_code == 400
    assert invalid_usage_0.quiet == True

    var_5 = bytes()
    invalid_usage_1 = InvalidUsage(var_5, var_5)
    assert invalid_usage_1.status_code == 400
    assert invalid_usage_1.quiet == True

    method_not_supported_0 = MethodNotSupported()
    assert method_not_supported_0.status_code == 405
    assert method

# Generated at 2022-06-26 03:14:17.640938
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 03:14:18.825110
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:14:29.919883
# Unit test for function add_status_code
def test_add_status_code():
    var_1: int = 200
    forbidden_1 = add_status_code(var_1)(forbidden_0)
    assert forbidden_1 is forbidden_0



# Generated at 2022-06-26 03:14:34.208458
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code("test_value0")
    except BaseException as exception_0:
        str_0 = str()
        invalid_usage_0 = InvalidUsage(str_0, str_0)
        assert len(str(invalid_usage_0)) == 0


# Generated at 2022-06-26 03:14:35.763732
# Unit test for function add_status_code
def test_add_status_code():
    # Test for the decorator usage
    assert test_case_0() is None


# Generated at 2022-06-26 03:14:47.561931
# Unit test for function add_status_code
def test_add_status_code():
    # noinspection PyUnresolvedReferences
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case

# Generated at 2022-06-26 03:14:50.216474
# Unit test for function add_status_code
def test_add_status_code():
    """Test that the status code is set correctly."""
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400


# Generated at 2022-06-26 03:14:51.124708
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(0)


# Generated at 2022-06-26 03:14:53.206815
# Unit test for function add_status_code
def test_add_status_code():
    assert(add_status_code(200)(Forbidden))


# Generated at 2022-06-26 03:14:55.991532
# Unit test for function add_status_code
def test_add_status_code():
    # Test for "0x1e" (status code)
    forbidden = Forbidden()
    expected = 0x1e
    actual = forbidden.status_code
    assert actual == expected, "403 Forbidden"



# Generated at 2022-06-26 03:15:02.163255
# Unit test for function add_status_code
def test_add_status_code():
    func = add_status_code(404)

    var_0 = bytes()
    func(SanicException(var_0, var_0))
    func(SanicException(var_0))
    func(NotFound())
    assert len(_sanic_exceptions) == 4
    func(ServerError(var_0, var_0))
    func(ServerError(var_0))
    assert len(_sanic_exceptions) == 5
    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[500] is ServerError
    _sanic_exceptions[500] = NotFound
    assert _sanic_exceptions[500] is NotFound
    func(NotFound())
    assert len(_sanic_exceptions) == 5
    assert _sanic_exceptions[404] is Not

# Generated at 2022-06-26 03:15:05.697984
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(var_0)
    test_case_0()
    var_0 = dict()
    test_case_1()
    return



# Generated at 2022-06-26 03:15:29.360542
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-26 03:15:36.523175
# Unit test for function add_status_code
def test_add_status_code():
    return

if __name__ == "__main__":
    from sys import argv
    from optparse import OptionParser

    parser = OptionParser()

    parser.add_option(
        "-t",
        "--test",
        action="count",
        default=True,
        help="Run test_case_0",
    )

    (options, _) = parser.parse_args(argv)

    if options.test:
        test_case_0()

        test_add_status_code()

# Generated at 2022-06-26 03:15:38.123979
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(int(), bool())


# Generated at 2022-06-26 03:15:39.678601
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)


# Generated at 2022-06-26 03:15:41.004056
# Unit test for function add_status_code
def test_add_status_code():
    assert isinstance(add_status_code(500, True), type)


# Generated at 2022-06-26 03:15:52.883946
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = bytes()
    var_1 = int()
    not_found_0 = NotFound(var_0, var_1)
    var_2 = bytes()
    var_3 = int()
    invalid_usage_0 = InvalidUsage(var_2, var_3)
    var_4 = bytes()
    var_5 = int()
    method_not_supported_0 = MethodNotSupported(var_4, var_4, var_4)
    var_6 = bytes()
    var_7 = int()
    server_error_0 = ServerError(var_6, var_7)
    var_8 = bytes()
    var_9 = int()
    service_unavailable_0 = ServiceUnavailable(var_8, var_9)
    var_10 = bytes()
    file_not_found_

# Generated at 2022-06-26 03:15:54.212397
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Unit test file

# Generated at 2022-06-26 03:16:02.543501
# Unit test for function add_status_code
def test_add_status_code():
    def function_add_status_code_0():
        code_0 = 200
        add_status_code(code_0)

    def function_add_status_code_1():
        code_0 = 300
        add_status_code(code_0)

    def function_add_status_code_2():
        code_0 = 400
        add_status_code(code_0)

    def function_add_status_code_3():
        code_0 = 500
        add_status_code(code_0)

    def function_add_status_code_4():
        code_0 = 600
        add_status_code(code_0)

    def function_add_status_code_5():
        code_0 = 400
        add_status_code(code_0, quiet=0)


# Generated at 2022-06-26 03:16:05.788836
# Unit test for function add_status_code
def test_add_status_code():
    try:
        server_error_0 = ServerError(bytes(), 408)
        raise server_error_0
    except Exception as exception_0:
        assert exception_0.status_code == 500


# Generated at 2022-06-26 03:16:08.993157
# Unit test for function add_status_code
def test_add_status_code():
    status_code=5
    def class_decorator(cls):
        cls.status_code = status_code
        return cls

    add_status_code(status_code)


# Generated at 2022-06-26 03:16:46.617609
# Unit test for function add_status_code
def test_add_status_code():
    def test_function(code, quiet):
        print("running test_function")
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator

    var_0 = 500
    var_1 = test_function(var_0, var_0)
    @var_1
    class test_case_1():
        pass
    test_case_1()
    return var_0 == 500



# Generated at 2022-06-26 03:16:49.224191
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(var_0)
    assert not var_0


# Generated at 2022-06-26 03:16:52.389168
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = int()
    add_status_code(var_0, var_0)



# Generated at 2022-06-26 03:17:00.767337
# Unit test for function add_status_code
def test_add_status_code():
    """
    pytest unit test using assert to compare return value of function
    raise_for_status in client.py with expected value.
    """
    # Test 0
    test_add_status_code_0 = 400
    test_add_status_code_1 = "t3st"
    test_add_status_code_2 = MethodNotSupported(test_add_status_code_0, test_add_status_code_0, test_add_status_code_1)
    assert test_add_status_code_2.status_code == 400
    assert test_add_status_code_2.headers == {'Allow': 't3st'}


# Generated at 2022-06-26 03:17:08.062007
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(status_code=403)
    class Forbidden(Exception):
        status_code = None
        quiet = None
        pass

    forbidden = Forbidden("123")
    assert forbidden.status_code == 403
    assert forbidden.args[0] == "123"

    @add_status_code(status_code=404)
    class NotFound(Exception):
        status_code = None
        quiet = None
        pass

    not_found = NotFound("123")
    assert not_found.status_code == 404
    assert not_found.args[0] == "123"

    @add_status_code(status_code=500)
    class ServerError(Exception):
        status_code = None
        quiet = None
        pass

    server_error = ServerError("123")

# Generated at 2022-06-26 03:17:10.768232
# Unit test for function add_status_code
def test_add_status_code():
    # Check for expected outputs of given input
    assert add_status_code(200, True) == None
    assert add_status_code(200, False) == None



# Generated at 2022-06-26 03:17:11.416158
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()



# Generated at 2022-06-26 03:17:18.728935
# Unit test for function add_status_code
def test_add_status_code():
    pass_0: t.Iterable[str]
    pass_1: t.Iterable[str]
    pass_2: t.Iterable[str]
    pass_3: t.Iterable[str]

    # This is the type of output that should be returned
    # from the function.
    output: type

    # Test 1
    pass_0 = (
        "../really/big/path/to/import/sanic/exceptions.py",
    )
    pass_1 = "r"
    output = add_status_code(pass_0, pass_1)

    # Test 2
    pass_0 = (
        "../really/big/path/to/import/sanic/exceptions.py",
    )
    pass_1 = "r"

# Generated at 2022-06-26 03:17:20.736870
# Unit test for function add_status_code
def test_add_status_code():
    input = 12
    expected_output = 12
    actual_output = add_status_code(input)
    assert actual_output == expected_output


# Generated at 2022-06-26 03:17:31.545246
# Unit test for function add_status_code
def test_add_status_code():
    assert (add_status_code(404) == NotFound)
    assert (add_status_code(400) == InvalidUsage)
    assert (add_status_code(405) == MethodNotSupported)
    assert (add_status_code(500) == ServerError)
    assert (add_status_code(503) == ServiceUnavailable)
    assert (add_status_code(408) == RequestTimeout)
    assert (add_status_code(413) == PayloadTooLarge)
    assert (add_status_code(416) == ContentRangeError)
    assert (add_status_code(417) == HeaderExpectationFailed)
    assert (add_status_code(403) == Forbidden)
    assert (add_status_code(401) == Unauthorized)


# Generated at 2022-06-26 03:18:47.069291
# Unit test for function add_status_code

# Generated at 2022-06-26 03:18:54.133450
# Unit test for function add_status_code
def test_add_status_code():
    # Test with single line function
    def class_decorator_0(cls_0):
        return cls_0
    def add_status_code_0(code_0, quiet_0=None):
        def class_decorator(cls_0):
            return cls_0
        return class_decorator
    test_obj_0 = add_status_code_0(add_status_code_0, add_status_code_0)
    class_decorator_0(test_obj_0)

    # Test with multiple line function
    def class_decorator_1(cls_0):
        return cls_0
    def add_status_code_1(code_0, quiet_0=None):
        def class_decorator(cls_0):
            return cls

# Generated at 2022-06-26 03:18:54.678204
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(1)



# Generated at 2022-06-26 03:18:56.678037
# Unit test for function add_status_code
def test_add_status_code():
    # Unit test for function add_status_code
    # This function is not available from Python

    return



# Generated at 2022-06-26 03:18:59.470894
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(500)
    server_error_0 = ServerError(500, False)

    payload_too_large_0 = PayloadTooLarge(500)


# Generated at 2022-06-26 03:19:01.455713
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)('404')


# Generated at 2022-06-26 03:19:06.818389
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(MethodNotSupported) as e:
        var_0 = bytes()
        # var_1 = add_status_code(var_0, None)
        method_not_supported = MethodNotSupported(var_0, var_0, [var_0])
        raise method_not_supported
    # assert e.value.status_code == var_0



# Generated at 2022-06-26 03:19:17.720770
# Unit test for function add_status_code
def test_add_status_code():

    import inspect
    import os
    import sys

    this_folder = os.path.abspath(os.path.dirname(inspect.getfile(inspect.currentframe())))
    parent_folder = os.path.abspath(os.path.join(this_folder, os.pardir))

    sys.path.append(parent_folder)

    from sanic.exceptions import add_status_code

    def test_case_1():
        var_0 = int()
        add_status_code(var_0, var_0)

    def test_case_2():
        var_0 = bytes()
        add_status_code(var_0, var_0)

    def test_case_3():
        var_0 = str()
        add_status_code(var_0, var_0)

# Generated at 2022-06-26 03:19:23.271631
# Unit test for function add_status_code
def test_add_status_code():
    code = 0
    quiet = None
    def class_decorator():
        return 0

    expected_result = 0
    result = add_status_code(code, quiet)(class_decorator)
    try:
        assert result == expected_result
    except AssertionError:
        print("Expected:", expected_result, "\nGot:", result)
        raise



# Generated at 2022-06-26 03:19:29.507824
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator = add_status_code(404)
    class_decorator = add_status_code(0)
    class_decorator = add_status_code(503)
    class_decorator = add_status_code(408)
    class_decorator = add_status_code(400)
    class_decorator = add_status_code(401)
    class_decorator = add_status_code(500)
    class_decorator = add_status_code(401)
    class_decorator = add_status_code(401)
    class_decorator = add_status_code(408)
    class_decorator = add_status_code(413)
    class_decorator = add_status_code(401)