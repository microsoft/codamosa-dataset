

# Generated at 2022-06-26 03:11:34.261077
# Unit test for function add_status_code
def test_add_status_code():
    assert hasattr(NotFound, 'quiet')
    assert hasattr(NotFound, 'status_code')
    assert hasattr(InvalidUsage, 'quiet')
    assert hasattr(InvalidUsage, 'status_code')
    assert hasattr(MethodNotSupported, 'status_code')
    assert hasattr(ServerError, 'quiet')
    assert hasattr(ServerError, 'status_code')
    assert hasattr(ServiceUnavailable, 'quiet')
    assert hasattr(ServiceUnavailable, 'status_code')
    assert hasattr(FileNotFound, 'quiet')
    assert hasattr(FileNotFound, 'status_code')
    assert hasattr(RequestTimeout, 'quiet')
    assert hasattr(RequestTimeout, 'status_code')
    assert hasattr(PayloadTooLarge, 'quiet')

# Generated at 2022-06-26 03:11:38.046751
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # type: () -> None
    scheme = 'Basic'
    realm = 'Restricted Area'
    Unauthorized('Auth required.', scheme=scheme, realm=realm)
    message = 'Auth required.'
    Unauthorized(message, scheme=scheme, realm=realm)



# Generated at 2022-06-26 03:11:45.186427
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'

    # Call the decorated NotFound class
    not_found_0 = NotFound(str_0)

    # Make sure the right status code is set
    assert not_found_0.status_code == 404

    # Make sure the right message is set
    assert not_found_0.args[0] == str_0


# Generated at 2022-06-26 03:11:48.408305
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound(':BI|4')
    not_found_0_check = add_status_code(404)(NotFound)
    if not_found_0 == not_found_0_check:
        print("Passed Unit test - add_status_code")
    else:
        print("FAILED Unit test - add_status_code")

# Generated at 2022-06-26 03:11:50.155060
# Unit test for function add_status_code
def test_add_status_code():
    str_1 = ':BI|4'
    not_found_1 = NotFound(str_1)


# Generated at 2022-06-26 03:12:04.316700
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    unauthorized_0 = Unauthorized('s*#G!UJ!LP!6')
    str_0 = 'C`,J>x@'
    str_1 = '+E/'
    str_2 = '+E/'
    str_3 = 'nG'
    str_4 = '3%5'
    str_5 = 'E+'
    str_6 = 'E+'
    unauthorized_1 = Unauthorized(str_0, status_code=None, scheme=str_1, realm=str_2, qop=str_3, algorithm=str_4, nonce=str_5, opaque=str_6)
    str_7 = 's*#G!UJ!LP!6'
    str_8 = 'C`,J>x@'
    str_9 = '+E/'


# Generated at 2022-06-26 03:12:16.837426
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-26 03:12:18.237088
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 404
    quiet_0 = None
    not_found_0 = NotFound('____')
    return add_status_code(status_code_0, quiet_0)


# Generated at 2022-06-26 03:12:20.434881
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    auth_req = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")


# Generated at 2022-06-26 03:12:24.753894
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'S5$Sw,I!l'
    invalid_usage_0 = InvalidUsage(str_0)
    str_1 = 'G?'
    invalid_usage_1 = InvalidUsage(str_1)
    str_2 = '|j0|0&w'
    server_error_0 = ServerError(str_2)
    str_3 = '#'
    server_error_1 = ServerError(str_3)
    str_4 = 'Z9'
    service_unavailable_0 = ServiceUnavailable(str_4)
    str_5 = 'mT'
    service_unavailable_1 = ServiceUnavailable(str_5)
    str_6 = ';'
    file_not_found_0 = FileNotFound(str_6, str_5, str_5)
   

# Generated at 2022-06-26 03:12:31.086957
# Unit test for function add_status_code
def test_add_status_code():
    class InvalidUsage_0(InvalidUsage):
        pass
    add_status_code(400, True)(InvalidUsage_0)
    add_status_code(500, False)(ServerError)


# Generated at 2022-06-26 03:12:32.637267
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 100
    quiet_0 = True
    class_decorator_0 = add_status_code(status_code_0, quiet=quiet_0)
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)


# Generated at 2022-06-26 03:12:37.252360
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 0
    code_1 = 0
    code_2 = 1
    code_3 = 1
    not_found_0 = NotFound(':BI|4', code_0)
    assert not_found_0.status_code == code_1
    not_found_0.quiet == code_2
    assert not_found_0.status_code == code_3

# Generated at 2022-06-26 03:12:38.310717
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)



# Generated at 2022-06-26 03:12:41.101801
# Unit test for function add_status_code
def test_add_status_code():
    str_1 = '#'
    int_0 = 500
    add_status_code(int_0)


# Generated at 2022-06-26 03:12:52.278997
# Unit test for function add_status_code
def test_add_status_code():
    '''
    SanicException.status_code = 404
    '''
    func_0 = add_status_code(404)
    class_0 = func_0(SanicException)
    str_0 = 'y5K)Ui'
    not_found_0 = NotFound(str_0)
    not_found_0.status_code = class_0.status_code
    str_0 = ':BI|4'
    str_1 = 'BI|4'
    str_2 = ':BI|4'
    not_found_1 = NotFound(str_1)
    not_found_2 = NotFound(str_2)
    not_found_1.status_code = not_found_2.status_code


# Generated at 2022-06-26 03:12:54.794681
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_0():
        not_found_0 = NotFound(':BI|4')
        pass

    if __name__ == '__main__':
        test_add_status_code()

# Generated at 2022-06-26 03:13:03.877467
# Unit test for function add_status_code
def test_add_status_code():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()

# Test case 1

# Generated at 2022-06-26 03:13:04.448880
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:13:10.036968
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[4] == ServiceUnavailable


# Generated at 2022-06-26 03:13:19.471451
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(NotFound) == NotFound
    assert add_status_code(400)(InvalidUsage) == InvalidUsage
    assert add_status_code(405)(MethodNotSupported) == MethodNotSupported
    assert add_status_code(500)(ServerError) == ServerError
    assert add_status_code(503)(ServiceUnavailable) == ServiceUnavailable
    assert add_status_code(408)(RequestTimeout) == RequestTimeout
    assert add_status_code(413)(PayloadTooLarge) == PayloadTooLarge
    assert add_status_code(416)(ContentRangeError) == ContentRangeError
    assert add_status_code(417)(HeaderExpectationFailed) == HeaderExpectationFailed
    assert add_status_code(403)(Forbidden) == Forbidden

# Generated at 2022-06-26 03:13:24.627751
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound()
    not_found_1 = NotFound('int' + 'ing')
    not_found_2 = NotFound(int)
    not_found_3 = NotFound(int())
    not_found_4 = NotFound(int(4))
    not_found_5 = NotFound(int('4'))
    not_found_6 = NotFound(int('4\\n'))
    not_found_7 = NotFound(int(str()))
    not_found_8 = NotFound(int(str('')))
    not_found_9 = NotFound(int(str('4')))
    not_found_10 = NotFound(int(str('4\\n')))
    not_found_11 = NotFound(int(-4))

# Generated at 2022-06-26 03:13:27.421588
# Unit test for function add_status_code
def test_add_status_code():
    # Case 0
    status_code_0 = 'G#b'
    quiet_0 = 'k*E'
    test_case_0()


# Generated at 2022-06-26 03:13:36.331527
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert not_found_0.message == str_0
    assert not_found_0.status_code == 404
    assert not_found_0.quiet == True
    assert type(SanicException) == type(SanicException)
    assert type(SanicException) == type(SanicException)


# Generated at 2022-06-26 03:13:44.494518
# Unit test for function add_status_code
def test_add_status_code():
    # Call function with args (500, None) and check the returned values are
    # as expected:
    ret_val = add_status_code(500, None)
    assert ret_val.__name__ == 'ServerError'
    # Call function with args (500, True) and check the returned values are
    # as expected:
    ret_val = add_status_code(500, True)
    assert ret_val.__name__ == 'ServerError'
    # Call function with args (500, False) and check the returned values are
    # as expected:
    ret_val = add_status_code(500, False)
    assert ret_val.__name__ == 'ServerError'


# Generated at 2022-06-26 03:13:46.968196
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise NotFound('Invalid URL')
    except NotFound as e:
        assert e.status_code == 404



# Generated at 2022-06-26 03:13:49.999759
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = SanicException
    add_status_code(400)(class_0)


# Generated at 2022-06-26 03:14:01.113463
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(TypeError) as exc_info:
        add_status_code(1)
    exc_info.match(r"add_status_code\(\) takes at least 2 arguments \(1 given\)")

    # Test if the decorator returns an object of the correct type
    def class_decorator(cls):
        return cls
    assert isinstance(add_status_code(1, True), type(class_decorator))
    assert add_status_code(1, True)(1) == 1

    # Test if the function throws a TypeError if the
    # first argument is not an int
    with pytest.raises(TypeError) as exc_info:
        add_status_code('a_string')

# Generated at 2022-06-26 03:14:11.104576
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(0)
    class_decorator_1 = add_status_code(3, None)
    try:
        @add_status_code(1)
        class TestClass:
            def __init__(self):
                self.status_code = 1

            def __init__(self):
                self.quiet = False


        TestClass = TestClass()
    except:
        TestClass = None
    assert TestClass.status_code == 1
    assert TestClass.quiet is False

# Generated at 2022-06-26 03:14:12.505375
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:14:16.902993
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-26 03:14:19.803578
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_0():
        test_case_0()

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:14:21.047205
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:14:24.636559
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert isinstance(not_found_0, NotFound)
    assert not_found_0.status_code == 404


# Generated at 2022-06-26 03:14:29.172340
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ';Lq3b@hW7y|'
    not_found_0 = NotFound(str_0)
    assert not_found_0.message == str_0
    not_found_0.status_code
    assert not_found_0.status_code == 404


# Generated at 2022-06-26 03:14:31.384662
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(404, False)
    internal_server_error_0 = ServerError('!g:')

# Generated at 2022-06-26 03:14:32.075835
# Unit test for function add_status_code
def test_add_status_code():
    assert type(add_status_code(404, None)) == function


# Generated at 2022-06-26 03:14:39.141907
# Unit test for function add_status_code
def test_add_status_code():
    # Verify Exception NotFound with status_code=404
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert not_found_0.status_code == 404

    # Verify Exception ServerError with status_code=500
    str_1 = '9'
    server_error_0 = ServerError(str_1)
    assert server_error_0.status_code == 500

    # Verify Exception ServiceUnavailable with status_code=503
    str_2 = '4'
    service_unavailable_0 = ServiceUnavailable(str_2)
    assert service_unavailable_0.status_code == 503

    # Verify Exception RequestTimeout with status_code=408
    str_3 = '%B1f'
    request_timeout_0 = RequestTimeout(str_3)

# Generated at 2022-06-26 03:14:41.743825
# Unit test for function add_status_code
def test_add_status_code():
    # Test for function body, branch: True
    print(test_add_status_code)
    # Test for function body, branch: True


# Generated at 2022-06-26 03:14:50.352071
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code.__doc__ == """
    Decorator used for adding exceptions to :class:`SanicException`.
    """
    assert NotFound.__name__ == "NotFound"
    assert not hasattr(NotFound, 'status_code')
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert len(_sanic_exceptions) == 6


# Generated at 2022-06-26 03:14:58.333834
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) is _sanic_exceptions[404]


# Generated at 2022-06-26 03:15:03.010945
# Unit test for function add_status_code
def test_add_status_code():

    __exception_0 = SanicException
    __exception_1 = SanicException
    class_0 = add_status_code(200)(__exception_0)
    class_1 = add_status_code(404)(__exception_1)


# Generated at 2022-06-26 03:15:05.478480
# Unit test for function add_status_code
def test_add_status_code():
    # Put here code to test the function add_status_code
    print("Function add_status_code")
    print("Not yet implemented")


# Generated at 2022-06-26 03:15:09.112096
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert not_found_0.status_code == 404


# Generated at 2022-06-26 03:15:15.026645
# Unit test for function add_status_code
def test_add_status_code():
    # Test arguments
    code_0 = 500
    _sanic_exceptions_0 = {}

    # Test function
    try:
        add_status_code(code_0, quiet=None)(ServerError)
        success = True
    except Exception:
        success = False

    assert success
    assert _sanic_exceptions_0 != {}



# Generated at 2022-06-26 03:15:20.617575
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 0
    quiet_0 = None

    class_decorator_0 = add_status_code(code_0, quiet_0)

    class cls_1:
        pass
    cls_0 = cls_1()
    add_status_code_0 = class_decorator_0(cls_0)
    if add_status_code_0 == cls_0:
        pass
    else:
        raise RuntimeError('Assertion failed')


# Generated at 2022-06-26 03:15:29.345435
# Unit test for function add_status_code
def test_add_status_code():
    # Create an object of type 'Class_0'
    class_0 = Class_0('String_0', 'String_1')
    # Create an object of type 'Class_1'
    class_1 = Class_1(0, 'String_2', class_0)
    # Function call with arguments '503', '', 'class_1' returns
    # 'class_1'
    try:
        return_value_0 = add_status_code(503, '', class_1)
    except Exception:
        return_value_0 = None
    return_value_1 = add_status_code(503, '')
    # Function call with arguments '503', '', 'class_1' returns
    # 'class_1'
    return_value_2 = add_status_code(503, '')
    return_value_

# Generated at 2022-06-26 03:15:33.275226
# Unit test for function add_status_code
def test_add_status_code():
    func_add_status_code_0 = add_status_code(200)
    str_0 = ':BI|4'
    not_found_0 = func_add_status_code_0(NotFound)(str_0)


# Generated at 2022-06-26 03:15:36.839138
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    test_case_0()


if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:15:41.424901
# Unit test for function add_status_code
def test_add_status_code():
    def fn_0(*args):
        return args
    class_add_status_code_0 = add_status_code(fn_0)
    class_0 = class_add_status_code_0(fn_0)
    assert class_0.status_code == fn_0


# Generated at 2022-06-26 03:15:55.062486
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:15:56.054423
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:15:58.434358
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 0
    inv_use_0 = InvalidUsage()
    add_status_code(int_0, inv_use_0)


# Generated at 2022-06-26 03:16:00.310685
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)


# Generated at 2022-06-26 03:16:10.928959
# Unit test for function add_status_code
def test_add_status_code():
    #Error: test_case_0() in SanicException.py:25:
    #__init__ get exception, 'status_code', test_case_0() in SanicException.py:25:
    #__init__ get exception, 'quiet', 
    #__init__ get exception, 'message', str_0
    # __init__ get exception, 'self', <__main__.NotFound object at 0x10cd7c8d0>
    # __init__ get exception, 'status_code', None
    # __init__ get exception, 'quiet', None
    # __init__ get exception, 'message', ':BI|4'
    # __init__ get exception, 'self', <__main__.NotFound object at 0x10cd7c8d0>
    test_case_0()


# Generated at 2022-06-26 03:16:13.141758
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(404)
    add_status_code_0(SanicException)



# Generated at 2022-06-26 03:16:15.906455
# Unit test for function add_status_code
def test_add_status_code():
    invalid_usage_0 = InvalidUsage('eB2')
    assert (invalid_usage_0.status_code == 400)
    add_status_code(400)


# Generated at 2022-06-26 03:16:24.025741
# Unit test for function add_status_code
def test_add_status_code():
    def func_0():
        status_code_0 = 404
        func_1 = add_status_code(status_code_0)
        class_0 = SanicException(',', 200)
        class_1 = func_1(class_0)
        str_0 = '~0A@'
        str_1 = 'O4^'
        invalid_usage_0 = InvalidUsage(str_0, status_code=None, quiet=str_1)
        not_found_0 = NotFound('', quiet=None)
        str_2 = '|QE'
        str_3 = 'b'
        server_error_0 = ServerError(str_2, status_code=500, quiet=str_3)
        str_4 = 'c'

# Generated at 2022-06-26 03:16:34.924353
# Unit test for function add_status_code
def test_add_status_code():
    assert(Code_0.status_code == 404)
    assert(Code_1.status_code == 404)
    assert(Code_2.status_code == 400)
    assert(Code_3.status_code == 405)
    assert(Code_4.status_code == 500)
    assert(Code_5.status_code == 503)
    assert(Code_6.status_code == 500)
    assert(Code_7.status_code == 408)
    assert(Code_8.status_code == 413)
    assert(Code_9.status_code == 416)
    assert(Code_10.status_code == 417)
    assert(Code_11.status_code == 403)
    assert(Code_12.status_code == 416)
    assert(Code_13.status_code == 416)

# Generated at 2022-06-26 03:16:40.731376
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound(message=';=[b')
    class_type_0_0 = type(NotFound)
    assert_equal(not_found_0.status_code, 404)
    assert_equal(not_found_0.quiet, True)
    assert_equal(_sanic_exceptions[404], class_type_0_0)
    test_case_0()


# Generated at 2022-06-26 03:17:16.144382
# Unit test for function add_status_code
def test_add_status_code():
    def function_0(param_0 = ':BI|4'):
        assert param_0 == ':BI|4'
        raise NotFound('not found')

    not_found_0 = NotFound('not found')
    invalid_usage_0 = InvalidUsage('invalid usage')
    method_not_supported_0 = MethodNotSupported('method not supported', 'POST', ['GET', 'HEAD'])
    server_error_0 = ServerError('server error')
    service_unavailable_0 = ServiceUnavailable('service unavailable')
    invalid_usage_1 = InvalidUsage('invalid usage')
    not_found_1 = NotFound('not found')
    server_error_1 = ServerError('server error')
    service_unavailable_1 = ServiceUnavailable('service unavailable')
    not_found_2 = NotFound('not found')

# Generated at 2022-06-26 03:17:21.386624
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert not_found_0.status_code == 404
    assert not_found_0.args[0] == str_0
    assert not_found_0.quiet == True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 03:17:26.213021
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 583
        if None or None is None and 583 != 500:
            cls.quiet = True
        _sanic_exceptions[583] = cls
        return cls

    return class_decorator


# Generated at 2022-06-26 03:17:29.852900
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = test_case_0()
    str_0 = str(not_found_0)
    assert str_0 == str(NotFound(str_0))


# Generated at 2022-06-26 03:17:31.504008
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 987
    add_status_code(status_code)
    test_case_0()

# Generated at 2022-06-26 03:17:34.799670
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ";"
    str_1 = "^"
    not_found_0 = NotFound(str_0)
    invalid_usage_0 = InvalidUsage(str_1)


# Generated at 2022-06-26 03:17:36.333998
# Unit test for function add_status_code
def test_add_status_code():
    test_1 = add_status_code(500)


# Generated at 2022-06-26 03:17:44.047910
# Unit test for function add_status_code
def test_add_status_code():
    # Test for coverage for the added status codes
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case

# Generated at 2022-06-26 03:17:54.790359
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = ':BI|4'
    status_code_0 = 500
    add_status_code_0 = add_status_code(status_code_0)
    status_code_1 = 500
    add_status_code_1 = add_status_code(status_code_1)
    status_code_2 = None
    add_status_code_2 = add_status_code(status_code_2)
    status_code_3 = None
    add_status_code_3 = add_status_code(status_code_3)
    status_code_4 = 503
    add_status_code_4 = add_status_code(status_code_4)
    status_code_5 = 403
    add_status_code_5 = add_status_code(status_code_5)
   

# Generated at 2022-06-26 03:18:08.895703
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(404)
    # Test Class NotFound
    str_0 = ':BI|4'
    not_found_0 = NotFound(str_0)
    assert not_found_0.message == ':BI|4'
    assert not_found_0.status_code == 404
    assert not_found_0._app is None
    assert not_found_0.quiet is True
    # Test Class MethodNotSupported

    def test_case_0():
        message_0 = 'nGk984'
        method_0 = 'POST'
        allowed_methods_0 = {'PUT', 'POST'}
        method_not_supported_0 = MethodNotSupported(message_0, method_0, allowed_methods_0)
        assert method_not_supported

# Generated at 2022-06-26 03:19:03.396440
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)

# Generated at 2022-06-26 03:19:04.641008
# Unit test for function add_status_code
def test_add_status_code():
    print('testing function add_status_code')
    test_case_0()


# Generated at 2022-06-26 03:19:06.270784
# Unit test for function add_status_code
def test_add_status_code():
    a = add_status_code()
    a.class_decorator(a)
    

# Generated at 2022-06-26 03:19:09.996337
# Unit test for function add_status_code
def test_add_status_code():
    # test 1
    def test_add_status_code_0():
        str_1 = 'R:D'
        not_found_1 = NotFound(str_1)
        not_found_1.status_code = 404


# Generated at 2022-06-26 03:19:19.576931
# Unit test for function add_status_code
def test_add_status_code():
    test_0 = add_status_code(404)
    test_1 = add_status_code(400)
    test_2 = add_status_code(405)
    test_3 = add_status_code(500)
    test_4 = add_status_code(503)
    test_5 = add_status_code(408)
    test_6 = add_status_code(413)
    test_7 = add_status_code(416)
    test_8 = add_status_code(417)
    test_9 = add_status_code(403)
    test_10 = add_status_code(401)
    test_case_0()


test_add_status_code()

# Generated at 2022-06-26 03:19:20.786830
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()



# Generated at 2022-06-26 03:19:28.379054
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None)
    str_1 = '}u@Xz5V7'
    add_status_code(str_1)
    str_2 = '@b`xq3Mxf`MES'
    add_status_code(str_2)
    str_3 = '4ZJ_!s+9e1c'
    add_status_code(str_3)
    str_4 = 'O9#z.N#N'
    add_status_code(str_4)
    str_5 = 'T%{m&9,!m3l$'
    add_status_code(str_5)
    str_6 = 'y0u*XbKc7{'
    add_status_code(str_6)
    str_7

# Generated at 2022-06-26 03:19:28.901536
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-26 03:19:31.974808
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 201
    quiet = False
    add_status_code(status_code, quiet)
    return True


# Generated at 2022-06-26 03:19:32.897463
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

