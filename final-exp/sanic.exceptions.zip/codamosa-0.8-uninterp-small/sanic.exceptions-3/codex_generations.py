

# Generated at 2022-06-26 03:11:27.941209
# Unit test for function add_status_code
def test_add_status_code():
    deco_fun = add_status_code(200)
    @deco_fun
    class Test_class_0():
        def __init__(self):
            pass
    
    test_instance = Test_class_0()
    assert test_instance.status_code == 200


# Generated at 2022-06-26 03:11:30.055034
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:11:35.775557
# Unit test for function add_status_code
def test_add_status_code():
    # This test is complete.
    # This test needs refactoring. 
    add_status_code_0 = add_status_code(0)
    sanic_exception_0 = SanicException()
    sanic_exception_0 = sanic_exception_0.__init__()
    add_status_code_0 = add_status_code_0(sanic_exception_0)


# Generated at 2022-06-26 03:11:38.084662
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_0['status_code'] = 400
    dict_0['message'] = 'hello'
    InvalidUsage(dict_0)


# Generated at 2022-06-26 03:11:43.517921
# Unit test for function add_status_code
def test_add_status_code():
    bad_status_code = 9999
    expected_value = 9999
    add_status_code(bad_status_code, quiet=None)
    res = test_add_status_code()
    assert res == expected_value

# Generated at 2022-06-26 03:11:47.044561
# Unit test for function add_status_code
def test_add_status_code():
    class C:
        def __init__(self):
            raise NotFound

    assert type(C()) == NotFound


# Generated at 2022-06-26 03:11:57.648228
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_0['abort'] = 0
    dict_0['no_status_code'] = 1
    dict_0['sanic_exceptions'] = 2
    dict_0['status_code'] = 3
    dict_0['quiet'] = 4
    dict_0['Test_case_0'] = 5
    dict_0['Sanic_exception_0'] = 6
    dict_0['Test_case_1'] = 7
    dict_0['Sanic_exception_1'] = 8
    dict_0['Test_case_2'] = 9
    dict_0['Sanic_exception_2'] = 10
    dict_0['Test_case_3'] = 11
    dict_0['Sanic_exception_3'] = 12
    dict_0['__init__'] = 13

# Generated at 2022-06-26 03:11:58.593967
# Unit test for function add_status_code
def test_add_status_code():
    print("test_add_status_code")

test_add_status_code()



# Generated at 2022-06-26 03:11:59.557292
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(SystemError):
        test_case_0()


# Generated at 2022-06-26 03:12:03.082296
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    class_decorator_0 = add_status_code(sanic_exception_0)
    class_0 = class_decorator_0(sanic_exception_0)


# Generated at 2022-06-26 03:12:06.974537
# Unit test for function add_status_code
def test_add_status_code():
    print('Testing add_status_code()')


# Generated at 2022-06-26 03:12:15.963985
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 1
    
    # Function: Test function add_status_code
    
    # Declaration of variable
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    
    # Try
    try:
        var_0 = None
    except:
        var_1 = None
    # Catch
    try:
        var_2 = None
    except:
        var_3 = None
    # Finally
    try:
        var_4 = None
    except:
        pass


# Generated at 2022-06-26 03:12:23.942104
# Unit test for function add_status_code
def test_add_status_code():
    class _temp():
        pass
    _temp.__name__ = "TestClass"
    var_0 = add_status_code(404)(_temp)
    var_0.status_code = 404
    var_1 = add_status_code(500)(_temp)
    var_1.status_code = 500
    var_2 = add_status_code(403)(_temp)
    var_2.status_code = 403
    assert var_0.status_code == 404
    assert var_1.status_code == 500
    assert var_2.status_code == 403


# Generated at 2022-06-26 03:12:32.047495
# Unit test for function add_status_code
def test_add_status_code():
    var_1 = {}
    try:
        var_1[""]
    except KeyError:
        if test_add_status_code.__annotations__["return"] == type(abort(500)):
            pass
    print("Unit test for function add_status_code")
    print("Assertion status: " + str(test_add_status_code.__annotations__["return"] == type(abort(500))))


# Generated at 2022-06-26 03:12:35.194929
# Unit test for function add_status_code
def test_add_status_code():
    # Case 1
    try:
        add_status_code(404, quiet=None)
    except Exception as e:
        print("Exception ", e)
    # Case 2
    add_status_code(500, quiet=True)


# Generated at 2022-06-26 03:12:37.292395
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = {}
    var_1 = add_status_code(404)
    test_case_0()
    return 0


# Generated at 2022-06-26 03:12:40.386398
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = {}
    var_1 = add_status_code(503)
    var_0['test_1'] = add_status_code(200)
    var_0['test_2'] = add_status_code(502)


# Generated at 2022-06-26 03:12:47.085824
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404)
    var_1 = var_0('NotFound')
    assert var_1.status_code == 404
    assert var_1.quiet == True
    var_2 = var_0('NotFound')
    assert var_2.status_code == 404
    assert var_2.quiet == True


# Generated at 2022-06-26 03:12:51.662700
# Unit test for function add_status_code
def test_add_status_code():
    global var_0
    test_case_0()
    var_1 = 404
    var_2 = None
    var_3 = NotFound
    add_status_code(var_1, var_2)
    var_4 = add_status_code(var_1, var_2)
    var_4(var_3)


# Generated at 2022-06-26 03:12:53.609039
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Test the abort function

# Generated at 2022-06-26 03:13:05.751432
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 1
    var_0 = {}
    status_code = 400
    quiet = None

    # Test case 2
    var_1 = {}
    status_code = 500
    quiet = None

    # Test case 3
    var_2 = {}
    status_code = 404
    quiet = None

    # Test case 4
    var_3 = {}
    status_code = 405
    quiet = None

    # Test case 5
    var_4 = {}
    status_code = 503
    quiet = None

    # Test case 6
    var_5 = {}
    status_code = 408
    quiet = None

    # Test case 7
    var_6 = {}
    status_code = 413
    quiet = None

    # Test case 8
    var_7 = {}
    status_code = 416
    quiet = None

# Generated at 2022-06-26 03:13:08.853115
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(123, None)


# Generated at 2022-06-26 03:13:15.891091
# Unit test for function add_status_code
def test_add_status_code():
    # Check for 404 status code
    class A(Exception):
        pass

    A = add_status_code(404)(A)
    if A.status_code == 404:
        assert 1
    else:
        assert 0
    # Check for 401 status code
    class A(Exception):
        pass

    A = add_status_code(401)(A)
    if A.status_code == 401:
        if A.headers["WWW-Authenticate"] == 'Bearer ':
            assert 1
        else:
            assert 0
    else:
        assert 0


# Generated at 2022-06-26 03:13:21.282453
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code()
    except Exception:
        pass
    else:
        assert False


# Generated at 2022-06-26 03:13:29.888133
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404, None) is not None
    assert add_status_code(400, None) is not None
    assert add_status_code(405, None) is not None
    assert add_status_code(500, None) is not None
    assert add_status_code(503, None) is not None

    assert add_status_code(408, None) is not None
    assert add_status_code(413, None) is not None
    assert add_status_code(416, None) is not None
    assert add_status_code(417, None) is not None
    assert add_status_code(403, None) is not None


# Generated at 2022-06-26 03:13:33.088570
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(code = 200)
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-26 03:13:38.130953
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        pass
    TestClass.status_code = 0
    TestClass.quiet = False
    _sanic_exceptions[0] = TestClass
    assert _sanic_exceptions[0].status_code == 0 and _sanic_exceptions[0].quiet is False


# Generated at 2022-06-26 03:13:41.288199
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = {}
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    return


# Generated at 2022-06-26 03:13:48.438685
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = 500
    var_1 = lambda var_0: var_0
    var_2 = test_case_0
    var_2()
    var_3 = var_1(var_0)
    var_4 = _sanic_exceptions
    var_4[var_3] = var_2
    var_2 = var_4
    var_5 = None
    var_6 = "var_5"
    var_0.get(var_6)


# Generated at 2022-06-26 03:13:53.302759
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404)
    var_0 = add_status_code(500, None)
    var_0 = add_status_code(500, True)
    var_0 = add_status_code(500, False)


# Generated at 2022-06-26 03:14:00.781154
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(0,0)
    var_0 = var_0(0)
    var_0.status_code = 0 #@type: int
    var_0.quiet = True #@type: bool


# Generated at 2022-06-26 03:14:06.007195
# Unit test for function add_status_code
def test_add_status_code():
    var_add_status_code_0 = add_status_code(code=var_0, quiet=var_0)
    var_add_status_code_1 = add_status_code(code=var_0)
    var_add_status_code_2 = add_status_code(code=var_0)
    var_add_status_code_3 = add_status_code(code=var_0)


# Generated at 2022-06-26 03:14:15.663681
# Unit test for function add_status_code
def test_add_status_code():
    class statusCode_500(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code != 500:
                self.quiet = True

    add_status_code(500)(statusCode_500)

    assert isinstance(statusCode_500, SanicException)
    assert statusCode_500.status_code == 500

    class statusCode_500(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)


# Generated at 2022-06-26 03:14:20.683518
# Unit test for function add_status_code
def test_add_status_code():
    decision_0 = add_status_code(404)
    decision_0(NotFound)
    print('var_0 = %s' % var_0)
    if var_0 == 404:
        test_case_0()


# Generated at 2022-06-26 03:14:32.066042
# Unit test for function add_status_code
def test_add_status_code():
    # A call to add_status_code()
    var_1 = add_status_code(status_code=404, quiet=None)
    # A call to class_decorator()
    var_2 = var_1(cls=NotFound)
    # A call to NotFound.__init__()
    var_3 = NotFound(message="", status_code=None, quiet=None)
    # A call to super().__init__()
    # A call to ServerError.__init__()
    var_4 = ServerError(message="", status_code=500, quiet=None)
    # A call to super().__init__()
    # A call to SanicException.__init__()
    var_5 = SanicException(message="", status_code=None, quiet=None)
    # A call to super

# Generated at 2022-06-26 03:14:33.011240
# Unit test for function add_status_code
def test_add_status_code():
    #todo
    return



# Generated at 2022-06-26 03:14:34.936967
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator(test_case_0)
    add_status_code(test_case_0)


# Generated at 2022-06-26 03:14:36.648769
# Unit test for function add_status_code
def test_add_status_code():
    res = add_status_code(status_code = 404)
    res(cls = NotFound)
    test_case_0()


# Generated at 2022-06-26 03:14:40.116306
# Unit test for function add_status_code
def test_add_status_code():
    try:
        var_2 = None
        var_2 = var_2
    except TypeError:
        var_3 = None
        var_3 = var_3
    test_case_0()


# Generated at 2022-06-26 03:14:42.276112
# Unit test for function add_status_code
def test_add_status_code():
    var_0 = add_status_code(404)
    var_0(NotFound)


# Generated at 2022-06-26 03:14:47.283658
# Unit test for function add_status_code
def test_add_status_code():
    pass


if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:14:49.229155
# Unit test for function add_status_code
def test_add_status_code():
    """Test add_status_code function"""
    assert add_status_code(500)

# Generated at 2022-06-26 03:14:50.144987
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions


# Generated at 2022-06-26 03:14:51.746025
# Unit test for function add_status_code
def test_add_status_code():
    exc_0 = NotFound("foo", 100, True)
    assert exc_0.status_code == 100

# Generated at 2022-06-26 03:14:54.973414
# Unit test for function add_status_code
def test_add_status_code():
    cls = lambda : 0
    dict_0 = {}
    dict_1 = dict_0
    add_status_code(cls)



# Generated at 2022-06-26 03:14:58.754873
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 03:15:04.978463
# Unit test for function add_status_code
def test_add_status_code():
    param_0 = 500
    quiet_0 = True
    sanic_exception_0 = ServerError('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', status_code=None, quiet=None)
    assert _sanic_exceptions.get(param_0) == sanic_exception_0.__class__


# Generated at 2022-06-26 03:15:17.442196
# Unit test for function add_status_code
def test_add_status_code():
    """ Test module -- add_status_code"""
    # test1
    ''' Test case from the project'''
    obj = add_status_code(401)
    obj = add_status_code(402)
    obj = add_status_code(403)
    obj = add_status_code(404)
    obj = add_status_code(405)
    obj = add_status_code(406)
    obj = add_status_code(407)
    obj = add_status_code(408)
    obj = add_status_code(409)
    obj = add_status_code(410)
    obj = add_status_code(411)
    obj = add_status_code(412)
    obj = add_status_code(413)
    obj = add_status_code(414)

# Generated at 2022-06-26 03:15:22.466858
# Unit test for function add_status_code
def test_add_status_code():
    # add SanicException to class
    sanic_exception = SanicException(None)
    sanic_exception.status_code = 0
    sanic_exception.quiet = False
    assert _sanic_exceptions.get(0) == SanicException
test_case_0()

# Generated at 2022-06-26 03:15:25.201671
# Unit test for function add_status_code
def test_add_status_code():
    def __init__(self, status_code=None, quiet=None):
        self.status_code = status_code
        if quiet or quiet is None and status_code != 500:
            self.quiet = True
    sanic_exception_0 = SanicException(dict_0)
    add_status_code(sanic_exception_0, sanic_exception_0)


# Generated at 2022-06-26 03:15:36.027753
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 600
    quiet_0 = None
    class_decorator_0 = add_status_code(status_code_0, quiet_0)
    class_0 = NotFound
    class_decorator_0(class_0)

# Generated at 2022-06-26 03:15:38.451532
# Unit test for function add_status_code
def test_add_status_code():
    test_add_status_code_0()
    test_add_status_code_1()
    test_add_status_code_2()



# Generated at 2022-06-26 03:15:40.834926
# Unit test for function add_status_code
def test_add_status_code():
    try:
        _sanic_exceptions[404]
        return False
    except KeyError:
        return True


# Generated at 2022-06-26 03:15:42.287965
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(dict_0, dict_1)

# Generated at 2022-06-26 03:15:44.837180
# Unit test for function add_status_code
def test_add_status_code():
    # Expected:  400
    assert add_status_code(400)


# Generated at 2022-06-26 03:15:50.843463
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = SanicException
    class_0.status_code = 404
    # quiet=None/False/True with None meaning choose by status
    if None or None is None and 404 not in (None, 500):
        class_0.quiet = True
    dict_0 = {}
    dict_0[404] = class_0
    dict_0[404]
    dict_0[404]


# Generated at 2022-06-26 03:15:57.840762
# Unit test for function add_status_code
def test_add_status_code():
    def function_0(arg_0):
        var_0 = arg_0
        try:
            raise NotFound(var_0)
        except NotFound:
            pass
    class_0 = SanicException(1)
    class_0.status_code = 1
    class_0.quiet = True
    dict_0 = {}
    dict_0[1] = class_0
    function_0(1)
    function_0(2)
    function_0(3)


# Generated at 2022-06-26 03:16:04.256225
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_1 = {}
    sanic_exception_2 = SanicException(dict_1)
    sanic_exception_0 = SanicException(dict_0)
    sanic_exception_1 = SanicException(dict_1)
    # Unit: add_status_code#L15
    assert hasattr(sanic_exception_1, 'status_code') is False
    add_status_code(sanic_exception_1, sanic_exception_2)
    assert sanic_exception_1.status_code == sanic_exception_2
    assert sanic_exception_1.status_code == sanic_exception_2
    add_status_code(sanic_exception_0, sanic_exception_2)


# Generated at 2022-06-26 03:16:14.861598
# Unit test for function add_status_code
def test_add_status_code():
    # Test 1
    from test.test_exception.test_case_1 import test_case_1
    test_case_1()
    # Test 2
    from test.test_exception.test_case_2 import test_case_2
    test_case_2()
    # Test 3
    from test.test_exception.test_case_3 import test_case_3
    test_case_3()
    # Test 4
    from test.test_exception.test_case_4 import test_case_4
    test_case_4()
    # Test 5
    from test.test_exception.test_case_5 import test_case_5
    test_case_5()

if __name__=="__main__":
    test_add_status_code()
    # Unit test for class San

# Generated at 2022-06-26 03:16:23.346450
# Unit test for function add_status_code
def test_add_status_code():
    # No Exception
    try:
        add_status_code(code=0,
                        quiet=0)
    except Exception:
        pass
    # Exception: `code` should be an int
    with pytest.raises(TypeError):
        add_status_code(code='str',
                        quiet=0)
    # Exception: `quiet` should be a bool or None
    with pytest.raises(TypeError):
        add_status_code(code=0,
                        quiet='str')
    # Exception: `quiet` should be a bool or None
    with pytest.raises(TypeError):
        add_status_code(code=0,
                        quiet=1.0)
    # Exception: `quiet` should be a bool or None
    with pytest.raises(TypeError):
        add_status_code

# Generated at 2022-06-26 03:16:39.070142
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    def class_decorator():
        sanic_exception_0.status_code = dict_0
        dict_1 = _sanic_exceptions
        dict_1[dict_0] = sanic_exception_0
        return sanic_exception_0
    class_decorator()


# Generated at 2022-06-26 03:16:44.520164
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 40
    quiet_0 = None
    cls_0 = lambda:0
    class_decorator_0 = add_status_code(code_0, quiet_0)
    # assert callable(class_decorator_0)
    cls_0 = class_decorator_0(cls_0)
    # assert isinstance(cls_0, type)
    # => assert all([isinstance(cls_0.status_code, int), isinstance(cls_0.status_code, int)])


# Generated at 2022-06-26 03:16:56.889155
# Unit test for function add_status_code
def test_add_status_code():
    # Test case 1
    status_code_1 = None
    quiet_1 = True
    NotFound_1 = add_status_code(status_code_1, quiet_1)
    message_1 = {}
    sanic_exception_1 = NotFound_1(message_1, status_code_1, quiet_1)
    # Test case 2
    status_code_2 = 500
    quiet_2 = None
    MethodNotSupported_2 = add_status_code(status_code_2, quiet_2)
    message_2 = {}
    method_2 = {}
    allowed_methods_2 = {}
    sanic_exception_2 = MethodNotSupported_2(message_2, status_code_2, quiet_2)
    # Test case 3
    status_code_3 = None
    quiet_

# Generated at 2022-06-26 03:17:00.299614
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(4)
    except Exception as e:
        # raise an error if status code is not an int
        assert str(e) == '4 is not an integer'
    else:
        assert True


# Generated at 2022-06-26 03:17:07.732538
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    code_0 = test_add_status_code.status_code_0
    sanic_exception_0 = SanicException(dict_0)
    sanic_exception_0.status_code = code_0
    sanic_exception_0.quiet = (test_add_status_code.quiet_0 and code_0)
    sanic_exception_1 = SanicException(dict_0)
    sanic_exception_1.status_code = code_0
    sanic_exception_1.quiet = (test_add_status_code.quiet_1 and code_0)
    sanic_exception_2 = SanicException(dict_0)
    sanic_exception_2.status_code = code_0
    sanic_exception_2.quiet

# Generated at 2022-06-26 03:17:16.949151
# Unit test for function add_status_code
def test_add_status_code():
    # Add Status Code
    add_status_code(500, True)

    # Add Not Found
    add_status_code(404, True)

    # Add Invalid Usage
    add_status_code(400, True)

    # Add Method Not Supported
    add_status_code(405, True)

    # Add Server Error
    add_status_code(500, True)

    # Add Service Unavailable
    add_status_code(503, True)

    # Add Payload Too Large
    add_status_code(413, True)

    # Add Content Range Error
    add_status_code(416, True)

    # Add Header Expectation Failed
    add_status_code(417, True)

    # Add Forbidden
    add_status_code(403, True)

    # Add Unauthorized

# Generated at 2022-06-26 03:17:21.101904
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.exceptions import SanicException
    SanicException.status_code = 404
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    sanic_exception_0.status_code = sanic_exception_0.status_code


# Generated at 2022-06-26 03:17:24.030245
# Unit test for function add_status_code
def test_add_status_code():
    assert callable(add_status_code)
    source_0 = add_status_code(500)
    assert callable(source_0)


# Generated at 2022-06-26 03:17:30.722570
# Unit test for function add_status_code
def test_add_status_code():
    test_sanic_exception_0 = SanicException("Message")
    test_add_status_code_0 = add_status_code("Message")
    test_add_status_code_1 = add_status_code("Message", True)
    test_add_status_code_2 = add_status_code("Message", None)
    test_add_status_code_2(test_sanic_exception_0)


# Generated at 2022-06-26 03:17:38.085163
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = NotFound
    class_1 = add_status_code(404, None)
    class_1 = class_1(class_0)

    dict_0 = {}
    dict_1 = {}
    sanic_exception_0 = SanicException(dict_0)
    sanic_exception_1 = SanicException(dict_1)
    sanic_exception_0.status_code = dict_0
    sanic_exception_1.status_code = dict_1


# Generated at 2022-06-26 03:18:10.658389
# Unit test for function add_status_code
def test_add_status_code():
    # Test with status_code = 500
    # Status code is not in _sanic_exceptions
    with pytest.raises(ServerError) as e:
        abort(500)

    # Status code is already in _sanic_exceptions
    # Should raise NotFound
    with pytest.raises(NotFound) as e:
        abort(404)


# Generated at 2022-06-26 03:18:12.556510
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    add_status_code('', False)


# Generated at 2022-06-26 03:18:16.299632
# Unit test for function add_status_code
def test_add_status_code():
    # Test for internal function
    sanic_exception_0 = SanicException(Exception)
    class_decorator_0 = add_status_code(1, sanic_exception_0)
    sanic_exception_1 = class_decorator_0(sanic_exception_0)



# Generated at 2022-06-26 03:18:22.460590
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(500)
    exception_1 = class_decorator_0(ServerError)
    assert exception_1.status_code == 500


# Generated at 2022-06-26 03:18:23.854033
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:18:28.110364
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(500)

    class_decorator_1 = add_status_code(500, True)

    test_case_0()


# Generated at 2022-06-26 03:18:29.512810
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {"status_code":200, "quiet":1}


# Generated at 2022-06-26 03:18:36.104082
# Unit test for function add_status_code
def test_add_status_code():
    # Generating SanicException
    SanicException_0 = SanicException()
    # Generating int
    int_0 = 0
    # Applying the add_status_code function
    add_status_code_0 = add_status_code(int_0)
    # Testing if the function add_status_code works
    assert add_status_code_0(SanicException_0) == SanicException_0


# Generated at 2022-06-26 03:18:40.250515
# Unit test for function add_status_code
def test_add_status_code():
    def function_0():
        str_0 = ''
        sanic_exception_0 = SanicException('', str_0)
        return sanic_exception_0

    add_status_code(function_0())
    # Unit test for function SanicException


# Generated at 2022-06-26 03:18:41.155197
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(dict_0)

# Generated at 2022-06-26 03:19:41.157770
# Unit test for function add_status_code
def test_add_status_code():
    # Call the function with arguments: 500, true
    test_code = 500
    test_quiet = True
    
    # Call function
    class_decorator(class_decorator.cls)
    class_decorator.cls.status_code = test_code
    if (test_quiet or test_quiet is None and test_code != 500):
        class_decorator.cls.quiet = True
    _sanic_exceptions[test_code] = class_decorator.cls
    return class_decorator.cls


# Generated at 2022-06-26 03:19:42.819058
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-26 03:19:50.657211
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_0[0] = 0
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_0[4] = 4
    dict_0[5] = 5
    dict_0[6] = 6
    dict_0[7] = 7
    dict_0[8] = 8
    dict_0[9] = 9
    dict_0[10] = 10
    dict_0[11] = 11
    dict_0[12] = 12
    dict_0[13] = 13
    dict_0[14] = 14
    dict_0[15] = 15
    dict_0[16] = 16
    dict_0[17] = 17
    dict_0[18] = 18
    dict

# Generated at 2022-06-26 03:19:54.097550
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 404
    class_decorator = add_status_code(status_code)
    cls = class_decorator(NotFound)
    assert cls.status_code == 404



# Generated at 2022-06-26 03:20:03.904936
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException:
        def __init__(self, arg_0, arg_1=None, arg_2=None, arg_3=None, arg_4=None, arg_5=None):
            self.value_0 = arg_0
            self.value_1 = arg_1
            self.value_2 = arg_2
            self.value_3 = arg_3
            self.value_4 = arg_4
            self.value_5 = arg_5
        def __init__(self, arg_0, arg_1=None, arg_2=None, arg_3=None, arg_4=None, arg_5=None):
            self.value_0 = arg_0
            self.value_1 = arg_1
            self.value_2 = arg_2

# Generated at 2022-06-26 03:20:04.761238
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:20:05.618686
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(test_case_0)

# Generated at 2022-06-26 03:20:08.197046
# Unit test for function add_status_code
def test_add_status_code():
    keyword_arguments = {"dict_0" : {}}
    try:
        test_case_0(**keyword_arguments)
    except:
        pass



# Generated at 2022-06-26 03:20:10.752079
# Unit test for function add_status_code
def test_add_status_code():
    i_0 = 0
    assert add_status_code(i_0) != None
    i_1 = 1
    assert add_status_code(i_1) != None


# Generated at 2022-06-26 03:20:12.689244
# Unit test for function add_status_code
def test_add_status_code():
    ret0 = add_status_code(400)
    ret1 = add_status_code(404)
    assert ret1 is NotFound
