

# Generated at 2022-06-26 03:11:32.070155
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # Expected positive case, no exception raised
        Unauthorized('Auth required.', 401)
        # Expected positive case, no exception raised
        Unauthorized('Auth required.', 401, scheme='Basic', realm='Restricted')
    except SanicException as e:
        # Unexpected negative case, exception raised
        raise AssertionError from e

# Generated at 2022-06-26 03:11:33.483887
# Unit test for function add_status_code
def test_add_status_code():
    assert 200 in _sanic_exceptions



# Generated at 2022-06-26 03:11:37.749574
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator = add_status_code(401)
    sanic_exception = class_decorator(SanicException)
    unauthorized = class_decorator(Unauthorized)

    if sanic_exception.status_code != 401 or unauthorized.status_code != 401:
        raise Exception



# Generated at 2022-06-26 03:11:51.343777
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Unauthorized constructor with only one arguments
    assert(Unauthorized('This is a test message').message == 'This is a test message')
    assert(Unauthorized('This is a test message', scheme='Basic').message == 'This is a test message')
    # Unauthorized constructor with two arguments
    assert(Unauthorized('This is a test message', 401).message == 'This is a test message' and 
        Unauthorized('This is a test message', 401).status_code == 401)

# Generated at 2022-06-26 03:11:57.011743
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(NotFound) == NotFound


# Generated at 2022-06-26 03:11:59.405125
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    msg = 'message'
    code = 401
    scheme = 'Basic'
    realm = 'Restricted Area'
    Unauthorized(msg, code, scheme, realm)

# Generated at 2022-06-26 03:12:06.303069
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required"
    status_code = 401
    scheme = "Basic"
    realm = "Restricted Area"
    case_0 = Unauthorized(message, status_code, scheme, realm=realm)

    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"
    case_1 = Unauthorized(message, status_code, scheme, realm=realm, qop=qop, algorithm=algorithm, nonce=nonce, opaque=opaque)

    scheme = "Bearer"
    case_2 = Unauthorized(message, status_code, scheme, realm=realm)
    realm = "Restricted Area"

# Generated at 2022-06-26 03:12:09.582472
# Unit test for function add_status_code
def test_add_status_code():
    sanic_exception_0 = _sanic_exceptions.get(404, SanicException)
    assert sanic_exception_0.status_code == 404


# Generated at 2022-06-26 03:12:13.276217
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    status_code = 401
    scheme = "Basic"
    realm = "Restricted Area"
    unauthorized_0 = Unauthorized(message, status_code, scheme, realm)

# Generated at 2022-06-26 03:12:18.060216
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator():
        pass

    test_class_decorator = add_status_code(404)(test_class_decorator)

    assert test_class_decorator.__name__ == "test_class_decorator"
    assert test_class_decorator.status_code == 404



# Generated at 2022-06-26 03:12:24.265382
# Unit test for function add_status_code
def test_add_status_code():
    ServerError.status_code = 500
    ServerError.quiet = True
    add_status_code(501)


# Generated at 2022-06-26 03:12:29.924851
# Unit test for function add_status_code
def test_add_status_code():
    set_0 = set()
    server_error_0 = ServerError(set_0)
    server_error_0.status_code = 500
    if 500 not in _sanic_exceptions:
        server_error_0.quiet = True


# Generated at 2022-06-26 03:12:33.503764
# Unit test for function add_status_code
def test_add_status_code():
    class Class_0:
        pass

    class_0 = Class_0()
    class_0.status_code = 200
    class_0.quiet = True
    add_status_code(200)(Class_0)


# Generated at 2022-06-26 03:12:34.813875
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(1002, True)


# Generated at 2022-06-26 03:12:36.564590
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyExc(SanicException):

        def __init__(self, a, b):
            super().__init__()

    x = MyExc('1', 2)
    assert x.status_code == 400


# Generated at 2022-06-26 03:12:50.296642
# Unit test for function add_status_code
def test_add_status_code():
    # Test with OK status code
    decorator1 = add_status_code(200)
    class_decorator1 = decorator1(SanicException)
    sanic_exception1 = class_decorator1("Bla")
    assert sanic_exception1.status_code == 200
    assert sanic_exception1.message == "Bla"
    assert sanic_exception1.quiet == None

    # Test with CLIENT_ERROR status code
    decorator2 = add_status_code(404)
    class_decorator2 = decorator2(SanicException)
    sanic_exception2 = class_decorator2("Bla")
    assert sanic_exception2.status_code == 404
    assert sanic_exception2.message == "Bla"
    assert sanic_ex

# Generated at 2022-06-26 03:12:54.060849
# Unit test for function add_status_code
def test_add_status_code():
    test_sanic_exception_0 = SanicException(b"\x00\x01\x02\x03\x04\x05")
    print(repr(add_status_code(0, test_sanic_exception_0)))


# Generated at 2022-06-26 03:12:55.125374
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)

# Generated at 2022-06-26 03:12:56.640955
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(NotFound) == NotFound


# Generated at 2022-06-26 03:13:01.686322
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(TypeError):
        add_status_code()
    with pytest.raises(TypeError):
        add_status_code(None, None)
    with pytest.raises(TypeError):
        add_status_code(NotImplemented)


# Generated at 2022-06-26 03:13:08.116282
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        status_code = 500
        _sanic_exceptions[status_code] = cls
        return cls

    class Base(SanicException):
        status_code = 500
        message = 'base'

    class_decorator(Base)
    set_0 = set()
    server_error_0 = Base(set_0)

# Generated at 2022-06-26 03:13:12.796069
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        pass

    TestClass = add_status_code(404)(TestClass)

    assert TestClass.status_code == 404
    assert TestClass.quiet == True
    assert status_code not in _sanic_exceptions
    assert _sanic_exceptions[404] == TestClass


# Generated at 2022-06-26 03:13:22.775559
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator_0(cls):
        cls.status_code = 0
        if 0 or 0 is None and 0 != 500:
            cls.quiet = True
        _sanic_exceptions[0] = cls
        return cls

    status_code_0 = add_status_code(0)
    status_code_0(class_decorator_0)

# Generated at 2022-06-26 03:13:31.682942
# Unit test for function add_status_code
def test_add_status_code():
    # Test for status == None
    with pytest.raises(TypeError):
        add_status_code(None)
    # Test for status not in [100, 200, 300, 400, 500, 600]
    with pytest.raises(ValueError):
        add_status_code(999)
    # Test for status < 100
    with pytest.raises(ValueError):
        add_status_code(-1)
    # Test for status > 600
    with pytest.raises(ValueError):
        add_status_code(999)
    # Test for status == 600
    with pytest.raises(ValueError):
        add_status_code(600)
    # Test for status == 500
    with pytest.raises(ValueError):
        add_status_code(500)
    # Test for status ==

# Generated at 2022-06-26 03:13:40.156767
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        def __init__(self, x):
            self.x = x
    # Test 0:
    add_status_code(200)(TestClass)(1)
    # Test 1:
    add_status_code(404)(TestClass)("Test")
    # Test 2:
    add_status_code(500)(TestClass)([])
    # Test 3:
    add_status_code(503)(TestClass)({})
    # Test 4:
    add_status_code(400)(TestClass)({"status_code": 404})


# Generated at 2022-06-26 03:13:40.727006
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:13:42.892815
# Unit test for function add_status_code
def test_add_status_code():
    NotFound_0 = NotFound("404 Not Found", status_code=404)
    ServerError_0 = ServerError("500 Internal Server Error")
    assert ServerError_0.status_code == 500


# Generated at 2022-06-26 03:13:43.736701
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:13:44.768381
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)


# Generated at 2022-06-26 03:13:48.021094
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class temp_01(SanicException):
        pass
    set_0 = set()
    temp_02 = temp_01(set_0)



# Generated at 2022-06-26 03:14:03.614409
# Unit test for function add_status_code
def test_add_status_code():
    class InvalidUsage1(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsage2(SanicException):
        pass

    # let InvalidUsage1 be a subclass of SanicException and add_status_code 400
    assert SanicException in InvalidUsage1.__bases__
    assert 400 in _sanic_exceptions

    # let InvalidUsage2 be a subclass of SanicException and add_status_code 400
    assert SanicException in InvalidUsage2.__bases__
    assert 400 in _sanic_exceptions



# Generated at 2022-06-26 03:14:13.854449
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.server import HttpProtocol
    from sanic.response import text
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.exceptions import ServerError, add_status_code
    from sanic.helpers import STATUS_CODES

    @add_status_code(400)
    class Error400(ServerError):
        status_code = 400

    @add_status_code(404)
    class Error404(ServerError):
        status_code = 404
        
    @add_status_code(500)
    class Error500(ServerError):
        status_code = 500

    app = Sanic('sanic-test')

    @app.route('/')
    async def handler(request):
        1 / 0
        return text('OK')



# Generated at 2022-06-26 03:14:19.583811
# Unit test for function add_status_code
def test_add_status_code():
    class TestClassA:
        pass
    TestClassA = add_status_code(404)(TestClassA)
    test_class_a_0 = TestClassA("abc")
    test_class_a_1 = TestClassA(123)
    test_class_a_2 = TestClassA(1,2,3)



# Generated at 2022-06-26 03:14:21.357843
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code.__name__ == "add_status_code"


# Generated at 2022-06-26 03:14:23.758933
# Unit test for function add_status_code
def test_add_status_code():
    test_value_0 = ServerError("This is a test.")
    test_value_0.status_code = 404
    test_value_0.quiet = True
    test_value_2 = add_status_code(404, quiet=None)(NotFound)
    # Check if test_value_2 is in the dictionary _sanic_exceptions
    assert _sanic_exceptions.get(404) == test_value_2


# Generated at 2022-06-26 03:14:34.484495
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    quiet = None
    message = "Test"

    def class_decorator(cls):
        cls.status_code = status_code
        if quiet or quiet is None and status_code != 500:
            cls.quiet = True
        _sanic_exceptions[status_code] = cls
        return cls

    def test_decorator(cls):
        return cls
    test_decorator.__name__ = "TestDecorator"

    add_status_code.__code__ = class_decorator.__code__

    add_status_code(status_code, quiet)(test_decorator)

    assert _sanic_exceptions[status_code].status_code == status_code
    assert _sanic_exceptions[status_code].__name

# Generated at 2022-06-26 03:14:39.983622
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions == {
        404: NotFound,
        400: InvalidUsage,
        405: MethodNotSupported,
        500: ServerError,
        503: ServiceUnavailable,
        408: RequestTimeout,
        413: PayloadTooLarge,
        416: ContentRangeError,
        417: HeaderExpectationFailed,
        403: Forbidden,
        401: Unauthorized
    }, "The _sanic_exceptions mapping does not match the mapping in" \
      + "sanic_exceptions.py"

    # TODO: Test the rest of the methods
    test_case_0()


if __name__ == '__main__':
    # Test the unit test
    test_add_status_code()
    print("No errors found")

# Generated at 2022-06-26 03:14:42.178415
# Unit test for function add_status_code
def test_add_status_code():
    server_error_1 = ServerError(set())
    NotFound(set())
    test_case_0()

# Generated at 2022-06-26 03:14:47.841353
# Unit test for function add_status_code
def test_add_status_code():
    # Test if add_status_code() works properly
    def test_response():
        pass
    test_response.status_code = 999
    test_response.quiet = True
    add_status_code(999, True)(test_response)
    assert test_response == _sanic_exceptions[999]


# Generated at 2022-06-26 03:14:53.107680
# Unit test for function add_status_code
def test_add_status_code():
    if __name__ == '__main__':
        print("\nadd_status_code() Test Cases\n")

        test_case_0 = add_status_code(200)
        print("Test Case 0: ",  test_case_0)


# Generated at 2022-06-26 03:15:10.000083
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-26 03:15:12.626226
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 678
        return cls
    add_status_code(678)


# Generated at 2022-06-26 03:15:21.854368
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass: pass
    test_class = TestClass()

    def test_add_status_code_0():
        set_0 = set()
        status_code_0 = 1
        TestClass_0 = add_status_code(status_code_0, set_0)(TestClass)
        TestClass_0.status_code = status_code_0
        _sanic_exceptions[status_code_0] = TestClass_0

    def test_add_status_code_1():
        set_0 = set()
        status_code_0 = 1
        TestClass_0 = add_status_code(status_code_0, set_0)(TestClass)
        TestClass_0.status_code = status_code_0
        _sanic_exceptions[status_code_0] = TestClass_0

# Generated at 2022-06-26 03:15:23.134507
# Unit test for function add_status_code
def test_add_status_code():
    # TODO: impl test_add_status_code
    pass



# Generated at 2022-06-26 03:15:25.028112
# Unit test for function add_status_code
def test_add_status_code():
    test_obj = add_status_code(1, True)
    test_obj(1)


# Generated at 2022-06-26 03:15:29.052096
# Unit test for function add_status_code
def test_add_status_code():
    test_class = add_status_code(404)(SanicException)
    assert test_class.status_code == 404
    assert test_class.quiet


# Generated at 2022-06-26 03:15:33.857403
# Unit test for function add_status_code
def test_add_status_code():
    # TODO: Forward, rather than backward, compatible with Python 3.6

    def class_decorator(x, y):
        return (x, y)

    add_status_code(1, 2)
    assert add_status_code(1, 2) == class_decorator


# Generated at 2022-06-26 03:15:38.906680
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 404
    quiet = None
    sanic_exception = ServerError("message")
    add_status_code(status_code, quiet)(type("", (SanicException, ),
                                        {"__init__": lambda self, *args: SanicException.__init__(self, "message")}))


# Generated at 2022-06-26 03:15:45.949700
# Unit test for function add_status_code
def test_add_status_code():
    '''
    class_decorator is function that takes a class and return the same class.
    add_status_code(code, quiet=None) is to add exceptions to SanicException
    when called
    '''
    # Test: calling add_status_code with a int code and quiet=None will
    # return class_decorator(cls)
    assert add_status_code(200) == class_decorator 



# Generated at 2022-06-26 03:15:47.785913
# Unit test for function add_status_code
def test_add_status_code():

    set_1 = set()
    server_error_1 = ServerError(set_1)


# Generated at 2022-06-26 03:16:21.338284
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = add_status_code(200)(SanicException)
    assert class_0.status_code == 200

# Generated at 2022-06-26 03:16:24.317712
# Unit test for function add_status_code
def test_add_status_code():
    if "404" in _sanic_exceptions:
        assert _sanic_exceptions["404"] == NotFound
    else:
        pass  # Exception not defined

    if "500" in _sanic_exceptions:
        assert _sanic_exceptions["500"] == ServerError
    else:
        pass  # Exception not defined



# Generated at 2022-06-26 03:16:25.339215
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-26 03:16:26.579993
# Unit test for function add_status_code
def test_add_status_code():
    assert(NotFound.status_code == 404)



# Generated at 2022-06-26 03:16:29.535183
# Unit test for function add_status_code
def test_add_status_code():
    # Use function SanicError as decorator
    add_status_code()
    # Use class ServerError from global variables.
    add_status_code()


# Generated at 2022-06-26 03:16:40.801227
# Unit test for function add_status_code
def test_add_status_code():
    test_code1 = 1
    test_code2 = 2
    test_code3 = 3
    test_code4 = 4

    def test_class_decorator(cls):
        cls.a = test_code1
        _sanic_exceptions[test_code2] = cls
        return cls
    dummy_class = type("dummy", (object,), {})
    result_class = test_class_decorator(dummy_class)
    assert result_class.a == test_code1
    assert _sanic_exceptions[test_code2] == dummy_class
    assert _sanic_exceptions[test_code2] == result_class


# Generated at 2022-06-26 03:16:43.576588
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise ServerError(set())
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "unsupported operand type(s) for +: 'int' and 'set'"



# Generated at 2022-06-26 03:16:45.812895
# Unit test for function add_status_code
def test_add_status_code():
    test_code = 500
    # Use default arguments to verify it will not cause exceptions
    add_status_code(test_code)


# Generated at 2022-06-26 03:16:49.272595
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        pass

    assert add_status_code(404)(class_decorator) is class_decorator


# Generated at 2022-06-26 03:16:53.545496
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(SanicException)
    assert add_status_code(400)(SanicException)
    assert add_status_code(500)(SanicException)



# Generated at 2022-06-26 03:18:11.950576
# Unit test for function add_status_code
def test_add_status_code():
    # Adds 404 to _sanic_exceptions dictionary with key 404
    add_status_code(404)
    # Adds 400 to _sanic_exceptions dictionary with key 400
    add_status_code(400)
    # Adds 405 to _sanic_exceptions dictionary with key 405
    add_status_code(405)
    # Adds 500 to _sanic_exceptions dictionary with key 500
    add_status_code(500)
    # Adds 503 to _sanic_exceptions dictionary with key 503
    add_status_code(503)
    # Adds 408 to _sanic_exceptions dictionary with key 408
    add_status_code(408)
    # Adds 413 to _sanic_exceptions dictionary with key 413
    add_status_code(413)
    # Adds 416 to _sanic_exceptions dictionary with key 416
   

# Generated at 2022-06-26 03:18:16.334192
# Unit test for function add_status_code
def test_add_status_code():
    # Test Function with no parameter
    x = add_status_code()

    # Test Function with 1 parameter
    x = add_status_code(400)

    # Test Function with 2 parameters
    x = add_status_code(400, None)


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", "-s", "--capture=no", __file__])

# Generated at 2022-06-26 03:18:31.139313
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """
        pass

    assert _sanic_exceptions[404] == NotFound

    @add_status_code(400)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """
        pass

    assert _sanic_exceptions[400] == InvalidUsage

    @add_status_code(500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """
        pass

    assert _sanic_exceptions[500] == ServerError


# Generated at 2022-06-26 03:18:34.590499
# Unit test for function add_status_code
def test_add_status_code():
    code = 1
    _status_code = code
    _sanic_exceptions = {}
    def class_decorator():
        return 1
    assert add_status_code(code)(class_decorator) == 1


# Generated at 2022-06-26 03:18:43.402524
# Unit test for function add_status_code
def test_add_status_code():
    set_0 = set()
    server_error_1 = ServerError(set_0)
    assert server_error_1.status_code == 500
    assert server_error_1.quiet == False

    server_error_2 = ServerError(set_0, status_code=404)
    assert server_error_2.status_code == 404
    assert server_error_2.quiet == True

    server_error_3 = ServerError(set_0, status_code=404, quiet=False)
    assert server_error_3.status_code == 404
    assert server_error_3.quiet == False


# Generated at 2022-06-26 03:18:46.584799
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    quiet = True
    try:
        raise add_status_code(code, quiet)(SanicException(message='test'))
    except SanicException as e:
        assert e.status_code == code
        assert e.quiet == quiet

# Generated at 2022-06-26 03:18:47.500466
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(set())


# Generated at 2022-06-26 03:18:53.988089
# Unit test for function add_status_code
def test_add_status_code():
    def func_0(self, x, y):
        pass
    def func_1(self, x, y):
        pass
    # Assigning to a function
    func_0 = add_status_code(200, func_0)
    # Assigning to a class
    add_status_code(200, func_1)
    # Assigning to a callable
    class class_0():
        def __init__(self):
            pass
        def __call__(self):
            pass
    class_0 = add_status_code(200, class_0)
    # Assigning to a type
    add_status_code(200, type)
    # Assigning to a module
    add_status_code(200, sys)


# Generated at 2022-06-26 03:18:58.334595
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(0)
    class MyError(SanicException):
        pass
    assert MyError.status_code == 0
    assert _sanic_exceptions == {0: MyError}
    assert _sanic_exceptions[0] == MyError


# Generated at 2022-06-26 03:19:02.155207
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator = add_status_code(500)
    test_class = class_decorator('test')

    assert test_class.status_code == 500
    assert test_class.quiet is None
