

# Generated at 2022-06-26 03:11:34.574830
# Unit test for function add_status_code

# Generated at 2022-06-26 03:11:42.298789
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    str_0 = '<1'
    str_1 = '<1'
    str_2 = '<1'
    str_3 = '<1'
    int_0 = 0
    str_4 = '<1'
    str_5 = '<1'
    str_6 = '<1'
    str_7 = '<1'
    str_8 = '<1'
    str_9 = '<1'
    str_10 = '<1'
    str_11 = '<1'
    str_12 = '<1'
    str_13 = '<1'
    str_14 = '<1'
    str_15 = '<1'
    str_16 = '<1'
    str_17 = '<1'
    str_18 = '<1'
    str

# Generated at 2022-06-26 03:11:47.379733
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Create a new instance of Unauthorized
    str_0 = '<1'
    exception_0 = Unauthorized(str_0)
    # Test type and value of the Exception
    assert(isinstance(exception_0, SanicException))
    assert(exception_0.status_code == 401)



# Generated at 2022-06-26 03:11:57.897877
# Unit test for function add_status_code
def test_add_status_code():
    str_0: str

# import classes for testing
# from . import SanicException
# from . import NotFound
# from . import InvalidUsage
# from . import MethodNotSupported
# from . import ServerError
# from . import ServiceUnavailable
# from . import URLBuildError
# from . import FileNotFound
# from . import RequestTimeout
# from . import PayloadTooLarge
# from . import HeaderNotFound
# from . import ContentRangeError
# from . import HeaderExpectationFailed
# from . import Forbidden
# from . import InvalidRangeType
# from . import PyFileError
# from . import Unauthorized
# from . import LoadFileException
# from . import InvalidSignal
# from . import abort

# import function for testing
# from . import test_case_0
# from . import test_add_status_code