

# Generated at 2022-06-26 03:11:32.126993
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_1():
        not_found_1 = NotFound(message="404 Not Found")
        return not_found_1
    
    def test_case_2():
        invalid_usage_2 = InvalidUsage(message="400 Bad Request")
        return invalid_usage_2
    
    def test_case_3():
        method_not_supported_3 = MethodNotSupported(message="405 Method Not Allowed", method=405, allowed_methods=405)
        return method_not_supported_3
    
    def test_case_4():
        server_error_4 = ServerError(message="500 Internal Server Error")
        return server_error_4
    
    def test_case_5():
        server_error_5 = ServiceUnavailable("503 Service Unavailable")
        return server_error_5
    


# Generated at 2022-06-26 03:11:39.697331
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        def __init__(self, message):
            super().__init__(message)

    class B(A):
        def __init__(self, message):
            super().__init__(message)

    a = add_status_code(200)(A)
    b = add_status_code(202, True)(B)

    assert _sanic_exceptions[200] == A
    assert _sanic_exceptions[202] == B
    assert a.status_code == 200
    assert b.status_code == 202
    assert a.quiet is False
    assert b.quiet is True
    # TODO: Figure out how to get this to work with mypy --strict
    # Both a and b should be subclasses of A. However, mypy doesn't recognize
    # this.
   

# Generated at 2022-06-26 03:11:46.282704
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code="200")
    def class_decorator(cls):
        pass

    class_decorator("abc")

    @add_status_code(status_code="200")
    def class_decorator_1(cls):
        pass

    class_decorator_1("abc")


# Generated at 2022-06-26 03:11:50.501255
# Unit test for function add_status_code
def test_add_status_code():
    # Normal case.
    quiet: bool = False
    code: int = 404
    add_status_code(code, quiet)

    # Abnormal case.
    quiet: bool = True
    code: int = 500
    add_status_code(code, quiet)



# Generated at 2022-06-26 03:12:04.347161
# Unit test for function add_status_code
def test_add_status_code():
    def add_status_code(code, quiet=None):
        # Decorator used for adding exceptions to SanicException.
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator
    # test case
    # def add_status_code(code, quiet=None):
    # test case
    # def class_decorator(cls):
    # test case
    # cls.status_code = code
    # test case
    # if quiet or quiet is None and code != 500:
    # test case
    # cls.quiet = True
    # test case
    # _sanic_

# Generated at 2022-06-26 03:12:06.926627
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)(NotFound)



# Generated at 2022-06-26 03:12:18.413830
# Unit test for function add_status_code
def test_add_status_code():
    # default
    test_add_status_code_Class1 = add_status_code(404)
    assert isinstance(test_add_status_code_Class1, types.FunctionType)
    # quiet=False
    test_add_status_code_Class2 = add_status_code(403, quiet=False)
    assert isinstance(test_add_status_code_Class2, types.FunctionType)
    assert test_add_status_code_Class2.__name__ == "class_decorator"
    # quiet=True
    test_add_status_code_Class3 = add_status_code(403, quiet=True)
    assert isinstance(test_add_status_code_Class3, types.FunctionType)

# Generated at 2022-06-26 03:12:22.818508
# Unit test for function add_status_code
def test_add_status_code():
    
    add_status_code(500)
    add_status_code(503)
    add_status_code(408)
    add_status_code(504)
    add_status_code(404)
    add_status_code(400)
    add_status_code(405)

# Generated at 2022-06-26 03:12:24.746078
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Negative testing for Unauthorized
    unauthorized_0 = Unauthorized(None)
    assert unauthorized_0.message is None


# Generated at 2022-06-26 03:12:36.180520
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # Usuario no autorizado
    # autorizacion no definida
    with pytest.raises(TypeError) as e:
        Unauthorized()
        if DEBUG_PRINT_TEST_NAME:
            print(f"\n {test_Unauthorized.__name__}")

    exception_message = str(e.value)
    assert exception_message == "__init__() missing 2 required keyword-only " \
                                "arguments: 'status_code' and 'scheme'"

    # usuario no autorizado
    # autorizacion no definida
    with pytest.raises(TypeError) as e:
        Unauthorized(message="message")

# Generated at 2022-06-26 03:12:44.705882
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5",
                       nonce="abcdef", opaque="zyxwvu")
    Unauthorized("Auth required.", scheme="Bearer")
    Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

# Generated at 2022-06-26 03:12:49.887465
# Unit test for function add_status_code
def test_add_status_code():
    # Test content of add_status_code
    def test_add_status_code_0():
        """
        Test for not having a return statement.
        """
        class TestClass:
            status_code = 404
            quiet = True
        test = TestClass()
        test_decorator = add_status_code(400)
        test_decorator(test)
        assert test.status_code == 400

    # Test content of add_status_code
    def test_add_status_code_1():
        """
        Test for not having a return statement.
        """
        class TestClass:
            status_code = 404
            quiet = True
        test = TestClass()
        test_decorator = add_status_code(503)
        test_decorator(test)
        assert test.status_code

# Generated at 2022-06-26 03:12:52.307854
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    # true case
    add_status_code(code)
    # false case
    add_status_code(code)


# Generated at 2022-06-26 03:13:01.483755
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Unauthorized with message, status_code, scheme and other keywords
    message = "Auth required."
    status = 401
    scheme = "Bearer"
    other = {"realm": "Restricted Area"}
    try:
        raise Unauthorized(message, status, scheme, **other)
    except Unauthorized:
        pass

    # Unauthorized with message, status_code and scheme
    try:
        raise Unauthorized(message, status, scheme)
    except Unauthorized:
        pass

    # Unauthorized with message, status_code, scheme and other keywords and
    # headers
    try:
        raise Unauthorized(message, status, scheme, headers={}, **other)
    except Unauthorized:
        pass

    # Unauthorized with message, status_code, scheme and headers

# Generated at 2022-06-26 03:13:13.064911
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # testing with auth-scheme = "Basic"
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        # testing if the response header contains "WWW-Authenticate: Basic realm="Restricted Area"
        assert "WWW-Authenticate" in e.headers
        assert "Basic" in e.headers["WWW-Authenticate"]
        assert "Restricted Area" in e.headers["WWW-Authenticate"]

# Generated at 2022-06-26 03:13:27.553038
# Unit test for function add_status_code
def test_add_status_code():
    # Forbidden error
    assert isinstance(Forbidden(400), SanicException)
    assert Forbidden(400).status_code == 400
    assert Forbidden(400).quiet == False
    # NotFound error
    assert isinstance(NotFound(404), SanicException)
    assert NotFound(404).status_code == 404
    assert NotFound(404).quiet == True
    # ServerError error
    assert isinstance(ServerError(500), SanicException)
    assert ServerError(500).status_code == 500
    assert ServerError(500).quiet == False
    # MethodNotSupported error
    assert isinstance(MethodNotSupported(405), SanicException)
    assert MethodNotSupported(405).status_code == 405
    assert MethodNotSupported(405).quiet == False


# Generated at 2022-06-26 03:13:31.897955
# Unit test for function add_status_code
def test_add_status_code():
    # Test SanicException
    error_message = ''
    server_error = ServerError(error_message)
    assert server_error.status_code == 500

# Generated at 2022-06-26 03:13:42.740206
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert(e.status_code == 401)
        assert(str(e) == "Auth required.")
        assert(e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\"")
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert(e.status_code == 401)
        assert(str(e) == "Auth required.")

# Generated at 2022-06-26 03:13:47.621031
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    add_status_code(404)


# Generated at 2022-06-26 03:13:59.819845
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        pass

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    @add_status_code(408)
    class RequestTimeout(SanicException):
        pass

    @add_status_code(413)
    class PayloadTooLarge(SanicException):
        pass

    @add_status_code(416)
    class ContentRangeError(SanicException):
        pass


# Generated at 2022-06-26 03:14:11.302566
# Unit test for function add_status_code
def test_add_status_code():
    def function_add_status_code(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator

    class MethodNotSupported1(SanicException):
        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}

    @add_status_code(405)
    class MethodNotSupported2(SanicException):
        def __init__(self, message, method, allowed_methods):
            super().__init__(message)

# Generated at 2022-06-26 03:14:16.823476
# Unit test for function add_status_code
def test_add_status_code():
    def test_func():
        pass
    test_func_add_status_code_1 = add_status_code(200, True)
    test_func_add_status_code_2 = add_status_code(200, False)
    test_func_add_status_code_3 = add_status_code(200, None)
    test_func_add_status_code_1(test_func)
    test_func_add_status_code_2(test_func)
    test_func_add_status_code_3(test_func)


# Generated at 2022-06-26 03:14:26.509306
# Unit test for function add_status_code
def test_add_status_code():
    class ClassDecorator:
        def __init__(self, code, quiet=None):
            self.status_code = code
            if quiet and code != 500:
                self.quiet = True
            _sanic_exceptions[code] = self
            return self

    class Class:
        def __init__(self, code, quiet=None):
            self.status_code = code
            if quiet and code != 500:
                self.quiet = True
            _sanic_exceptions[code] = self
            return self

    instance_0 = ClassDecorator(404)
    instance_1 = Class(404)
    assert instance_0 == instance_1


# Generated at 2022-06-26 03:14:35.057954
# Unit test for function add_status_code
def test_add_status_code():
    # A normal use case of add_status_code
    # With test_case_0, this function should raise a Forbidden exception
    test_case_0()

    # A case for invalid usage of add_status_code
    # This code should raise an error
    server_error_1 = ServerError("ServerError")
    forbidden_1 = Forbidden(server_error_1)

    # In this test case, the code should raise an exception.
    # If not, the test case fails
    try:
        test_case_0()
        assert False
    except Forbidden:
        assert True
    except:
        assert False


# Generated at 2022-06-26 03:14:37.474541
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass


    assert NotFound.status_code == 404


# Generated at 2022-06-26 03:14:49.196512
# Unit test for function add_status_code
def test_add_status_code():
    a = add_status_code(1)
    b = add_status_code(2, quiet=True)
    c = add_status_code(3, quiet=False)
    d = add_status_code(5, quiet=None)

    # unit test for the decorator
    class A:
        pass
    class B:
        pass
    class C:
        pass
    class D:
        pass

    @a
    class A(SanicException):
        pass
    @b
    class B(SanicException):
        pass
    @c
    class C(SanicException):
        pass
    @d
    class D(SanicException):
        pass

    _sanic_exceptions_keys = set(_sanic_exceptions.keys())

# Generated at 2022-06-26 03:14:55.232433
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        cls.status_code = 400
        cls.quiet = True
        _sanic_exceptions[400] = cls
        return cls

    @add_status_code(400)
    class test(SanicException):
        pass

    test.quiet = True
    test.status_code = 400

    assert test_class_decorator(test) == test



# Generated at 2022-06-26 03:14:57.496733
# Unit test for function add_status_code
def test_add_status_code():
    status_code = "status_code"
    quiet = False
    cls = SanicException
    add_status_code(status_code, quiet)(cls)


# Generated at 2022-06-26 03:15:09.606694
# Unit test for function add_status_code
def test_add_status_code():
    # Add NotFound exception
    NotFound_0 = add_status_code(404)(SanicException)

    # Add InvalidUsage exception
    InvalidUsage_0 = add_status_code(400)(SanicException)

    # Add MethodNotSupported exception
    MethodNotSupported_0 = add_status_code(405)(SanicException)

    # Add ServerError exception
    ServerError_0 = add_status_code(500)(SanicException)

    # Add ServiceUnavailable exception
    ServiceUnavailable_0 = add_status_code(503)(SanicException)

    # Add PayloadTooLarge exception
    PayloadTooLarge_0 = add_status_code(413)(SanicException)

    # Add ContentRangeError exception
    ContentRangeError_0 = add_status_code(416)(SanicException)

    # Add HeaderExpectation

# Generated at 2022-06-26 03:15:16.448388
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    test_status_code = 500

    TestException = add_status_code(test_status_code)(TestException)

    assert TestException.status_code == test_status_code
    assert issubclass(_sanic_exceptions[test_status_code], SanicException)
    assert _sanic_exceptions[test_status_code] == TestException

# Generated at 2022-06-26 03:15:24.694245
# Unit test for function add_status_code
def test_add_status_code():
    class C:
        status_code = None
        quiet = None
    def decorator(cls):
        assert type(cls) is C
        return cls
    f = add_status_case(C, decorator)
    c = f()
    assert type(c) is C
    assert c.status_code is None
    assert c.quiet is None

# Generated at 2022-06-26 03:15:31.010517
# Unit test for function add_status_code
def test_add_status_code():
    dump_error_custom = add_status_code(399)(SanicException)
    assert dump_error_custom.status_code == 399
    assert "399 Custom Error" == str(dump_error_custom(message="Custom Error"))

    dump_error_default = add_status_code(400)(SanicException)
    assert dump_error_default.status_code == 400
    assert "400 Custom Error" == str(dump_error_default(message="Custom Error"))

    dump_error_500 = add_status_code(500)(SanicException)
    assert dump_error_500.status_code == 500
    assert "500 Custom Error" == str(dump_error_500(message="Custom Error"))

    dump_error_503 = add_status_code(503)(SanicException)
    assert dump_error_503.status_code

# Generated at 2022-06-26 03:15:41.897923
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(Exception):
        def __init__(self, message):
            super().__init__(message)

    def class_decorator_function(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator

    class_decorator_function(401)
    class MyException401(Exception):
        def __init__(self, message):
            super().__init__(message)

    class MyException401(MyException):
        def __init__(self, message):
            super().__init__(message)


# Generated at 2022-06-26 03:15:44.787107
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class A:
        pass

    assert _sanic_exceptions[200] is A

# Generated at 2022-06-26 03:15:52.740201
# Unit test for function add_status_code
def test_add_status_code():
    status_code = None
    quiet = None

    def class_decorator(cls):
        # pass
        cls.status_code = status_code
        if quiet or quiet is None and status_code != 500:
            cls.quiet = True
        _sanic_exceptions[status_code] = cls
        return cls

    assert add_status_code(status_code, quiet) == class_decorator
    assert add_status_code.__name__ == 'add_status_code'



# Generated at 2022-06-26 03:16:01.732089
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.request import Request
    from sanic.response import json
    from sanic.response import text
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketProtocol
    
    app_01 = Request()
    json_01 = json(app_01)
    rv_text = text(app_01)
    
    json_01 = json(app_01, dumps=text)
    json_01 = json(app_01, dumps=text, headers={"Cookie": "name=value"})
    json_01 = json(
        app_01, dumps=text, headers={"Cookie": "name=value"}, status=200
    )
    
    c

# Generated at 2022-06-26 03:16:12.678806
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None)
    test_code = '123'
    test_quiet = None
    test_quiet1 = True
    test_quiet2 = False
    test_quiet3 = None
    test_quiet4 = False
    test_quiet_1 = True

    # test case 1
    # class_decorator(cls):
    # cls.status_code = code
    # if quiet or quiet is None and code != 500:
    #     cls.quiet = True
    #     _sanic_exceptions[code] = cls
    #     return cls
    # class Test(SanicException):
    #     def __init__(self, message, status_code=None, quiet=None):
    #         super().__init__(message)
    #
    #        

# Generated at 2022-06-26 03:16:22.052530
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404].__name__ == 'NotFound'
    assert _sanic_exceptions[403].__name__ == 'Forbidden'
    assert _sanic_exceptions[400].__name__ == 'InvalidUsage'
    assert _sanic_exceptions[500].__name__ == 'ServerError'
    assert _sanic_exceptions[405].__name__ == 'MethodNotSupported'
    assert _sanic_exceptions[408].__name__ == 'RequestTimeout'
    assert _sanic_exceptions[401].__name__ == 'Unauthorized'
    assert _sanic_exceptions[416].__name__ == 'ContentRangeError'
    assert _sanic_exceptions[503].__name__ == 'ServiceUnavailable'
    assert _sanic_exceptions[413].__name__

# Generated at 2022-06-26 03:16:31.861563
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        message = 'Test'
        def __init__(self, message):
            self.message = message
    # Assert that the class was added to the dictionary
    test_add_status_code_0 = add_status_code(404)(TestClass)
    assert test_add_status_code_0.status_code == 404
    assert test_add_status_code_0.quiet == True
    assert _sanic_exceptions[404] == TestClass
    # Assert that the status_code and quiet were passed to the init of the
    # class.
    test_exception = TestClass('Test')
    assert test_exception.status_code == 404
    assert test_exception.quiet == True
    # Now try with a status_code that is not 404 and see if quiet is set to false.


# Generated at 2022-06-26 03:16:40.452361
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        def __init__(self, message):
            super().__init__(message)


    assert ServerError.status_code == 500
    assert ServerError.quiet == True
    assert _sanic_exceptions[500].__name__ == 'ServerError'
    assert _sanic_exceptions[500].__qualname__ == 'test_add_status_code.<locals>.ServerError'


# Generated at 2022-06-26 03:16:50.922648
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class A(SanicException):
        pass
    assert _sanic_exceptions[200] == A
    assert A.status_code == 200


# Generated at 2022-06-26 03:16:55.142940
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class _ClassForTestAddStatusCode(SanicException):
        pass

    assert _ClassForTestAddStatusCode.status_code == 1
    assert _sanic_exceptions[1] == _ClassForTestAddStatusCode



# Generated at 2022-06-26 03:17:01.459889
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(Exception):
        status_code = 404

    te1 = TestException(TestException.status_code)
    te2 = TestException(TestException.status_code)
    assert(te1.status_code == 404)
    assert(te2.status_code == 404)
    add_status_code(404)
    assert(te1.status_code == 404)
    assert(te2.status_code == 404)
    assert(_sanic_exceptions[404] == TestException)


# Generated at 2022-06-26 03:17:04.610985
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestClass:
        def __init__(self):
            pass

    t = TestClass()
    assert t.status_code == 404
    assert _sanic_exceptions[404] == TestClass

# Generated at 2022-06-26 03:17:14.706016
# Unit test for function add_status_code
def test_add_status_code():
    # Class decorator
    # calls class_decorator
    #   instantiate a class, add runtime attributes
    #   register the class to current module

    @add_status_code(401)
    class Unauthorized(SanicException):
        """
        **Status**: 401 Unauthorized
        """

        pass

    # Class decorator
    # calls class_decorator(SanicException)
    #   instantiate a class, add runtime attributes
    #   register the class to current module

    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    # Class decorator
    # calls class_decorator(SanicException)
    #   instantiate a class, add runtime attributes
    #   register the class to current module



# Generated at 2022-06-26 03:17:20.470633
# Unit test for function add_status_code
def test_add_status_code():
    # internal error
    assert 500 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[500], ServerError)
    assert _sanic_exceptions[500] == ServerError

    # not found
    assert 404 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[404], NotFound)
    assert _sanic_exceptions[404] == NotFound

    # method not supported
    assert 405 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[405], MethodNotSupported)
    assert _sanic_exceptions[405] == MethodNotSupported

    # no content
    assert 204 not in _sanic_exceptions

    # service unavailable
    assert 503 in _sanic_exceptions

# Generated at 2022-06-26 03:17:26.439205
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    code = 404
    quiet = None
    assert add_status_code(code, quiet)(NotFound) == test_decorator(NotFound)


# Generated at 2022-06-26 03:17:27.181539
# Unit test for function add_status_code
def test_add_status_code():
    def foo():
        pass
    add_status_code(123)(foo)
    assert foo.status_code == 123

# Generated at 2022-06-26 03:17:35.994678
# Unit test for function add_status_code
def test_add_status_code():
    class _TestAddStatusCode(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    _sanic_exceptions[101] = _TestAddStatusCode
    assert _sanic_exceptions[101].status_code == 101


# Generated at 2022-06-26 03:17:43.843691
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_1(a, b):
        if a > b:
            return 1
        else:
            return 0

    @add_status_code(123)
    def test_case_2():
        pass

    class TestCase123:
        @add_status_code(123)
        def test_case_2():
            pass

    @add_status_code(408)
    def test_case_3():
        pass

    class TestCase408:
        @add_status_code(408)
        def test_case_3():
            pass

    @add_status_code(500)
    def test_case_4():
        pass

    class TestCase500:
        @add_status_code(500)
        def test_case_4():
            pass


# Generated at 2022-06-26 03:18:04.660936
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)
    add_status_code(400)
    add_status_code(503)
    add_status_code(500)
    add_status_code(408)
    add_status_code(413)
    add_status_code(416)
    add_status_code(417)
    add_status_code(403)
    add_status_code(401)

# Generated at 2022-06-26 03:18:13.756091
# Unit test for function add_status_code
def test_add_status_code():
    # This script is executed from the project root dir
    status_code = 500
    file_path = "test/exceptions/SanicException_500.py"

    # This is the expected result
    expected_result = '500 Internal Server Error\n'

    # This is the function call to the function add_status_code
    add_status_code(status_code, True)

    # This will now write to the file
    with open(file_path, 'w') as f:
        f.write(expected_result)

    # This checks if the expected result actually matches with the file contents
    with open(file_path, 'r') as f:
        file_data = f.read()
        assert file_data == expected_result


# Generated at 2022-06-26 03:18:18.217563
# Unit test for function add_status_code
def test_add_status_code():
    class NotFound(SanicException):
        pass

    @add_status_code(404)
    class NotFound1(SanicException):
        pass

    @add_status_code(404, True)
    class NotFound2(SanicException):
        pass

    assert hasattr(NotFound, "status_code") == False
    assert hasattr(NotFound1, "status_code") == True
    assert hasattr(NotFound2, "status_code") == True

# Unit test function abort

# Generated at 2022-06-26 03:18:28.706325
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(None)
    except Exception:
        assert True
    else:
        assert False
    try:
        add_status_code(0)
    except Exception:
        assert True
    else:
        assert False
    try:
        add_status_code(400)
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-26 03:18:30.273179
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Test(SanicException):
        pass



# Generated at 2022-06-26 03:18:32.731506
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)
    add_status_code(400)
    add_status_code(405)
    add_status_code(500)



# Generated at 2022-06-26 03:18:37.005093
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass0(SanicException):
        pass

    t = TestClass0()
    t0 = add_status_code(200)(t)
    assert t0.__class__ == t.__class__


# Generated at 2022-06-26 03:18:39.698141
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 100

# Generated at 2022-06-26 03:18:45.097708
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(code=404)(NotFound).status_code == 404
    assert add_status_code(code=404)(NotFound).quiet == True
    assert add_status_code(code=400)(InvalidUsage).status_code == 400
    assert add_status_code(code=500)(ServerError).status_code == 500
    assert add_status_code(code=503)(ServiceUnavailable).status_code == 503


# Generated at 2022-06-26 03:18:50.720918
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        """
        Test class for add_status_code decorator
        """
        pass

    @add_status_code(500)
    class TestClass2:
        """
        Test class for add_status_code decorator
        """
        pass

    assert issubclass(_sanic_exceptions[500], SanicException)
    assert issubclass(_sanic_exceptions[500], TestClass2)
    assert TestClass not in _sanic_exceptions.values()


# Generated at 2022-06-26 03:19:24.465442
# Unit test for function add_status_code
def test_add_status_code():
    server_error_1 = ServerError("Error")
    assert type(server_error_1) == _sanic_exceptions[500]
    assert server_error_1.status_code == 500
    assert server_error_1.quiet is False

    server_error_2 = ServerError("Error", 500, True)
    assert type(server_error_2) == _sanic_exceptions[500]
    assert server_error_2.status_code == 500
    assert server_error_2.quiet is True

    server_error_3 = ServerError("Error", 500, False)
    assert type(server_error_3) == _sanic_exceptions[500]
    assert server_error_3.status_code == 500
    assert server_error_3.quiet is False



# Generated at 2022-06-26 03:19:29.541035
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    # Here quiet is not None
    add_status_code(404, quiet=None)
    # Here quiet is None
    add_status_code(400, quiet=None)

# Generated at 2022-06-26 03:19:35.471079
# Unit test for function add_status_code
def test_add_status_code():
    server_error = ServerError("Failed")
    assert server_error.status_code == 500

    forbidden = Forbidden("Failed")
    assert forbidden.status_code == 403

    not_found = NotFound("Not Found")
    assert not_found.status_code == 404

    invalid_usage = InvalidUsage("Invalid Usage")
    assert invalid_usage.status_code == 400

# Generated at 2022-06-26 03:19:45.190069
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass:
        pass

    # # 1. test for status code 200
    # test_instance_200: TestClass = add_status_code(200)(TestClass)
    # assert test_instance_200.status_code == 200
    # assert test_instance_200.quiet == False

    # 2. test for status code 404
    test_instance_404: TestClass = add_status_code(404)(TestClass)
    assert test_instance_404.status_code == 404
    assert test_instance_404.quiet == True

    # 3. test for status code 500
    test_instance_500: TestClass = add_status_code(500)(TestClass)
    assert test_instance_500.status_code == 500
    assert test_instance_500.quiet == False



# Generated at 2022-06-26 03:19:46.288965
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError) as excinfo:
        # test for non-existing status code
        assert STATUS_CODES[200]

# Generated at 2022-06-26 03:19:48.890369
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=403)
    class Abc(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)
    abc = Abc("abc", status_code=403)
    assert abc.status_code == 403



# Generated at 2022-06-26 03:19:58.046669
# Unit test for function add_status_code
def test_add_status_code():

    class MyTestClass0():
        def __init__(self, status_code = None, quiet = None):
            self.status_code = status_code
            self.quiet = quiet

    # Add _sanic_exceptions[123] = MyTestClass0
    _sanic_exceptions[123] = MyTestClass0
    # Sanity check
    if _sanic_exceptions[123].status_code == None:
        print ("test_add_status_code: fail to get class added")
        return

    # Remove _sanic_exceptions[123] = MyTestClass0
    del _sanic_exceptions[123]
    print ("test_add_status_code: pass")


# Generated at 2022-06-26 03:19:59.245016
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(400)

    test_case_0()

# Generated at 2022-06-26 03:20:03.119870
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable

# Generated at 2022-06-26 03:20:04.328562
# Unit test for function add_status_code
def test_add_status_code():
    a = add_status_code(531)
    return a


# Generated at 2022-06-26 03:21:13.137563
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator(cls):
        cls.status_code = 1
        if False or False is None and 1 != 500:
            cls.quiet = True
        _sanic_exceptions[1] = cls
        return cls

    @test_decorator
    class TestClassDecorator:
        pass

    class_decorator_0 = TestClassDecorator()
    _sanic_exceptions[1] = class_decorator_0

    def class_decorator(cls):
        cls.status_code = 2
        if False or False is None and 2 != 500:
            cls.quiet = True
        _sanic_exceptions[2] = cls
        return cls


# Generated at 2022-06-26 03:21:15.587288
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    server_error_0 = None
    my_exception_0 = MyException(server_error_0)


# Generated at 2022-06-26 03:21:17.282093
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class A:
        pass
    assert A.status_code == 200
    assert A.quiet == True
