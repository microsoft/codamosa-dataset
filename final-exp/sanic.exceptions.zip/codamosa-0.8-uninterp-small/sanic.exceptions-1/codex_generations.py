

# Generated at 2022-06-26 03:11:12.187452
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    add_status_code(code)


# Generated at 2022-06-26 03:11:19.722298
# Unit test for function add_status_code
def test_add_status_code():

    status_code_0 = 1
    quiet_0 = None
    nop_decorator_0 = add_status_code(status_code_0, quiet_0)
    def func_1(x_0):
        return x_0

    nop_decorator_1 = nop_decorator_0(func_1)
    assert func_1 == nop_decorator_1
    # check if the decorated function is added to the dictionary
    #assert func_1.status_code == status_code_0



# Generated at 2022-06-26 03:11:20.865608
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(code = 500, quiet = False)



# Generated at 2022-06-26 03:11:26.070724
# Unit test for function add_status_code
def test_add_status_code():

    # mock arguments from real methods
    list_0 = []
    list_1 = [1,2,3]
    list_2 = [1,2]
    list_3 = [1,2,3,4]

    # run function
    add_status_code(list_0, list_1)
    add_status_code(list_2, list_3)


# Generated at 2022-06-26 03:11:32.166750
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 404
        CLASS_cls.status_code = 404
        if 404 in _sanic_exceptions:
            pass
        else:
            _sanic_exceptions[404] = cls
        return cls

    test = add_status_code(404)
    NotFound_ = test(test_case_0)


# Generated at 2022-06-26 03:11:33.524431
# Unit test for function add_status_code
def test_add_status_code():
    # SanicException was not expected to be raised
    pass


# Generated at 2022-06-26 03:11:34.668369
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(code)


# Generated at 2022-06-26 03:11:35.985216
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500, False)



# Generated at 2022-06-26 03:11:37.799610
# Unit test for function add_status_code
def test_add_status_code():
    # Test branch #0
    header_not_found_0 = HeaderNotFound('{0}')


# Generated at 2022-06-26 03:11:47.088652
# Unit test for function add_status_code
def test_add_status_code():
    # Check if add_status_code raises a SanicException when given an invalid status code
    try:
        add_status_code(900)
    except SanicException as e:
        assert type(e) is SanicException
    except:
        assert False
    # Check if add_status_code creates a new SanicException with a valid status code
    add_status_code(0)
    assert 900 not in _sanic_exceptions
    assert 0 in _sanic_exceptions


# Generated at 2022-06-26 03:11:53.120264
# Unit test for function add_status_code
def test_add_status_code():
    emp = ()
    my_list = []
    expected_result = ()
    result = add_status_code(emp, my_list)
    assert result == expected_result


# Generated at 2022-06-26 03:11:57.801646
# Unit test for function add_status_code
def test_add_status_code():
    i_0 = 0
    list_0 = []
    add_status_code(i_0, list_0)


# Generated at 2022-06-26 03:12:02.815286
# Unit test for function add_status_code
def test_add_status_code():
    # Test exception handling.
    try:
        add_status_code("a")
    except:
        pass
    try:
        add_status_code(None)
    except:
        pass
    try:
        add_status_code("b")("c")
    except:
        pass
    try:
        add_status_code("b", "c")("c")
    except:
        pass


# Generated at 2022-06-26 03:12:04.189168
# Unit test for function add_status_code
def test_add_status_code():
    message_0 = 'message'
    invalid_usage_0 = InvalidUsage(message_0)


# Generated at 2022-06-26 03:12:07.970349
# Unit test for function add_status_code
def test_add_status_code():
    # Setup
    code_0 = 1

    # Testing
    # Function call
    assert callable(add_status_code(code_0))



# Generated at 2022-06-26 03:12:14.872135
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(0)
    assert add_status_code(1)
    assert add_status_code(2)
    assert add_status_code(3)
    assert add_status_code(4)
    assert add_status_code(5)
    assert add_status_code(6)
    assert add_status_code(7)
    # test case for assertation 
    test_case_0()



# Generated at 2022-06-26 03:12:19.552339
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200)(SanicException)("abc", 'abc')
    assert add_status_code(404)(NotFound)("abc", 'abc')
    assert add_status_code(400)(InvalidUsage)("abc", 'abc')
    assert add_status_code(405)(MethodNotSupported)("abc", 'abc')
    assert add_status_code(500)(ServerError)("abc", 'abc')
    assert add_status_code(503)(ServiceUnavailable)("abc", 'abc')
    assert add_status_code(408)(RequestTimeout)("abc", 'abc')
    assert add_status_code(413)(PayloadTooLarge)("abc", 'abc')
    assert add_status_code(416)(ContentRangeError)("abc", 'abc')

# Generated at 2022-06-26 03:12:27.369161
# Unit test for function add_status_code
def test_add_status_code():
    invalid_usage_0 = InvalidUsage(None, 408, False)

    #Test if all the values are correct
    if invalid_usage_0.status_code == 408 and \
        invalid_usage_0.quiet == False:
        invalid_usage_0 = InvalidUsage(None, 408, True)
        #Checking if the value of the object is changed after the if
        if invalid_usage_0.quiet == True:
            return False

    #Test if the class is changed
    if not isinstance(invalid_usage_0, InvalidUsage):  # Throws exception
        return False

    server_error_0 = ServerError(None, None, None)
    if server_error_0.status_code != 500:
        return False
    return True



# Generated at 2022-06-26 03:12:37.213455
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized



# Generated at 2022-06-26 03:12:38.930378
# Unit test for function add_status_code
def test_add_status_code():
    # Test that function doesn't crash.
    add_status_code(000, False)


# Generated at 2022-06-26 03:12:54.062445
# Unit test for function add_status_code
def test_add_status_code():
    print("Test #1")
    print("Status_code: 700, quiet: None")
    status_code_0 = 700
    quiet_0 = None
    add_status_code(status_code_0, quiet_0)
    print()
    
    print("Test #2")
    print("Status_code: 200, quiet: True")
    status_code_1 = 200
    quiet_1 = True
    add_status_code(status_code_1, quiet_1)
    print()
    
    print("Test #3")
    print("Status_code: 200, quiet: False")
    status_code_2 = 200
    quiet_2 = False
    add_status_code(status_code_2, quiet_2)
    print()
    
    print("Test #4")

# Generated at 2022-06-26 03:12:56.129342
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(403)
    add_status_code(404)


# Generated at 2022-06-26 03:13:00.668590
# Unit test for function add_status_code
def test_add_status_code():
    message = "p"
    status_code = 1
    quiet = None
    forbidden_0 = Forbidden(message, status_code, quiet)
    assert forbidden_0.message == message
    assert forbidden_0.status_code == status_code
    assert forbidden_0.quiet == quiet

# Generated at 2022-06-26 03:13:02.058917
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500, quiet=False)


# Generated at 2022-06-26 03:13:02.690631
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)



# Generated at 2022-06-26 03:13:07.342569
# Unit test for function add_status_code
def test_add_status_code():
    # function call
    add_status_code()
    # function call
    add_status_code()
    # function call
    add_status_code(code, quiet)


# Generated at 2022-06-26 03:13:14.398184
# Unit test for function add_status_code
def test_add_status_code():
    # Don't forget to also test negative integers
    # ex) -2 = 404
    header_expectation_failed_0 = add_status_code(417)(HeaderExpectationFailed)
    assert header_expectation_failed_0.status_code == 417
    assert header_expectation_failed_0.quiet == True
    # Make sure it is a subclass of the SanicException class
    assert issubclass(header_expectation_failed_0, SanicException)



# Generated at 2022-06-26 03:13:19.632399
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(500)
    add_status_code_0(HeaderNotFound)



# Generated at 2022-06-26 03:13:23.252005
# Unit test for function add_status_code
def test_add_status_code():
    test_header_not_found = HeaderNotFound("header not found")
    assert test_header_not_found.status_code == 400
    assert test_header_not_found.message == "header not found"


# Generated at 2022-06-26 03:13:31.952140
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code
    header_expectation_failed_0 = HeaderExpectationFailed(list())

    exception_0 = SanicException(
        'Message')
    exception_1 = SanicException(
        'Message',
        415)
    exception_2 = SanicException(
        'Message',
        415,
        True)
    exception_3 = SanicException(
        'Message',
        415,
        False)

    # Unexpect
    exception_4 = SanicException(
        'Message',
        415,
        1)
    exception_5 = SanicException(
        'Message',
        415,
        0)
    exception_6 = SanicException(
        'Message',
        415,
        3)


# Generated at 2022-06-26 03:13:52.583395
# Unit test for function add_status_code
def test_add_status_code():
    class Class_0:
        status_code = None
        quiet = None
        pass
    Class_0 = add_status_code(404)(Class_0)
    assert Class_0.status_code == 404
    assert Class_0.quiet == True

    class Class_1:
        status_code = None
        quiet = None
        pass
    Class_1 = add_status_code(500)(Class_1)
    assert Class_1.status_code == 500
    assert Class_1.quiet == False

    class Class_2:
        status_code = None
        quiet = None
        pass
    Class_2 = add_status_code(500, True)(Class_2)
    assert Class_2.status_code == 500
    assert Class_2.quiet == True


# Generated at 2022-06-26 03:13:56.019323
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    code = 403
    cls = ServicUnavailable
    quiet = True
    class_decorator(cls)
    assert _sanic_exceptions == {403: cls}

#Unit test for class SanicException

# Generated at 2022-06-26 03:13:58.654504
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 418
    not_found_0 = NotFound(code_0)
    add_status_code(code_0)


# Generated at 2022-06-26 03:14:01.063276
# Unit test for function add_status_code
def test_add_status_code():
    def func_0(arg):
        return arg

    add_status_code_0 = add_status_code(func_0)



# Generated at 2022-06-26 03:14:03.761320
# Unit test for function add_status_code
def test_add_status_code():
    # A quick test to make sure we can create some exceptions.
    with pytest.raises(ServerError):
        raise ServerError()
    with pytest.raises(NotFound):
        raise NotFound()



# Generated at 2022-06-26 03:14:09.117997
# Unit test for function add_status_code
def test_add_status_code():
    assert STATUS_CODES[404] == b'Not Found'
    assert STATUS_CODES[400] == b'Bad Request'
    assert STATUS_CODES[405] == b'Method Not Allowed'
    assert STATUS_CODES[500] == b'Internal Server Error'
    assert STATUS_CODES[503] == b'Service Unavailable'
    assert STATUS_CODES[408] == b'Request Timeout'
    assert STATUS_CODES[413] == b'Payload Too Large'
    assert STATUS_CODES[416] == b'Range Not Satisfiable'
    assert STATUS_CODES[417] == b'Expectation Failed'
    assert STATUS_CODES[403] == b'Forbidden'
    assert STATUS_CODES

# Generated at 2022-06-26 03:14:12.712404
# Unit test for function add_status_code
def test_add_status_code():
    list_0 = []
    header_expectation_failed_0 = HeaderExpectationFailed(list_0)
    assert header_expectation_failed_0.status_code == 417


# Generated at 2022-06-26 03:14:14.852446
# Unit test for function add_status_code
def test_add_status_code():
    """
        Testing for add_status_code
        Expected result:
        Result should not be none
    """
    assert add_status_code(500) is not None



# Generated at 2022-06-26 03:14:18.871304
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = add_status_code(400, None)

    class Class_0():
        pass

    not_found_0(Class_0)



# Generated at 2022-06-26 03:14:30.350598
# Unit test for function add_status_code
def test_add_status_code():
    params = [
        (
            408,
            True,
            408,
        ),
        (
            404,
            None,
            404,
        ),
    ]
    return_value = add_status_code(
        params[0][0],
        quiet=params[0][1]
    )
    return_value_0 = return_value(RequestTimeout)
    assert return_value_0.status_code == params[0][2]
    return_value_0_0 = return_value_0.status_code
    class_decorator = add_status_code(
        params[1][0],
        quiet=params[1][1]
    )
    return_value_1 = class_decorator(SanicException)

# Generated at 2022-06-26 03:14:58.036688
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(503, None) == ServiceUnavailable
    assert _sanic_exceptions.get(404, None) == NotFound
    assert _sanic_exceptions.get(500, None) == ServerError
    assert _sanic_exceptions.get(413, None) == PayloadTooLarge
    assert _sanic_exceptions.get(400, None) == InvalidUsage
    assert _sanic_exceptions.get(408, None) == RequestTimeout
    assert _sanic_exceptions.get(405, None) == MethodNotSupported
    assert _sanic_exceptions.get(416, None) == ContentRangeError
    assert _sanic_exceptions.get(401, None) == Unauthorized
    assert _sanic_exceptions.get(417, None) == HeaderExpectationFailed


# Generated at 2022-06-26 03:14:59.257955
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) != None


# Generated at 2022-06-26 03:15:07.675921
# Unit test for function add_status_code
def test_add_status_code():
    # Test for a known HTTP status code.
    add_status_code_0 = add_status_code(500)
    class_decorator_0 = add_status_code_0(SanicException)
    # Test for a status code which is not a known HTTP status code.
    add_status_code_1 = add_status_code(0)
    class_decorator_1 = add_status_code_1(SanicException)


# Generated at 2022-06-26 03:15:17.524251
# Unit test for function add_status_code
def test_add_status_code():
    def function_0():
        list_0 = []
        add_status_code(list_0, list_0)
    try:
        function_0()
    except ArgumentTypeError as ex:
        assert ex.message == 'Parameter `code` must be an int, not <class \'list\'>', str(ex)

    def function_1():
        list_0 = []
        add_status_code(None, list_0)
    try:
        function_1()
    except ArgumentTypeError as ex:
        assert ex.message == 'Parameter `code` must be an int, not <class \'NoneType\'>', str(ex)


# Generated at 2022-06-26 03:15:22.504590
# Unit test for function add_status_code
def test_add_status_code():
    exception_0 = add_status_code(797)
    exception_0.__name__ = 'else'
    exception_1 = add_status_code(797)
    exception_1.__name__ = 'else'
    assert exception_0.__name__ == exception_1.__name__


# Generated at 2022-06-26 03:15:23.189112
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()



# Generated at 2022-06-26 03:15:30.413860
# Unit test for function add_status_code
def test_add_status_code():
    list_0 = []

    add_status_code(403)
    result = add_status_code(403)
    assert result(Forbidden) == Forbidden
    assert Forbidden.quiet == True
    assert Forbidden.status_code == 403
    assert _sanic_exceptions[403] == Forbidden
    assert Forbidden.__doc__.startswith("\n**Status**: 403 Forbidden\n")
    assert Forbidden.__init__.__doc__.startswith("class Forbidden(SanicException):")

    add_status_code(408)
    result = add_status_code(408)
    assert result(RequestTimeout) == RequestTimeout
    assert RequestTimeout.quiet == True
    assert RequestTimeout.status_code == 408
    assert _sanic_exceptions[408] == RequestTimeout
    assert RequestTimeout.__doc__.startsw

# Generated at 2022-06-26 03:15:35.262388
# Unit test for function add_status_code
def test_add_status_code():
    class Class0:
        pass

    add_status_code(200)(Class0)
    if Class0.status_code != 200:
        raise Exception()
    if Class0.quiet != True:
        raise Exception()
    if 200 not in _sanic_exceptions:
        raise Exception()

# Generated at 2022-06-26 03:15:41.425922
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator_0(cls):
        cls.status_code = 404
        cls.quiet = True
        _sanic_exceptions[404] = cls
        return cls
    add_status_code_ret_0 = add_status_code(404)
    add_status_code_ret_0 = add_status_code_ret_0(class_decorator_0)


# Generated at 2022-06-26 03:15:53.181076
# Unit test for function add_status_code
def test_add_status_code():
    not_allowed_1 = MethodNotSupported(str, str, str)
    not_allowed_0 = not_allowed_1
    not_found_0 = NotFound(str)
    invalid_range_type_0 = InvalidRangeType(str, int)
    invalid_usage_0 = InvalidUsage(str)
    forbidden_0 = Forbidden(str)
    not_found_1 = NotFound(str)
    server_error_0 = ServerError(str)
    service_unavailable_0 = ServiceUnavailable(str)
    request_timeout_0 = RequestTimeout(str)
    load_file_exception_0 = LoadFileException(str)
    url_build_error_0 = URLBuildError(str)
    not_allowed_2 = not_allowed_1
    not_allowed_3 = not_allowed_2
   

# Generated at 2022-06-26 03:16:32.747281
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException:
        pass

    class NotFound(SanicException):
        pass
    not_found = NotFound()
    test_add_status_code.__dict__["test_case_0"]()


# Generated at 2022-06-26 03:16:43.242484
# Unit test for function add_status_code

# Generated at 2022-06-26 03:16:45.814548
# Unit test for function add_status_code
def test_add_status_code():
    # SanicException class is added to _sanic_exceptions dictionary
    with assert_raises(AssertionError):
        add_status_code(0)


# Generated at 2022-06-26 03:16:48.000191
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(1)


# Generated at 2022-06-26 03:16:55.228586
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500) == ServerError
    try:
        raise PayloadTooLarge()
    except PayloadTooLarge as e:
        assert e.status_code == 413
    try:
        raise MethodNotSupported("error message", "method", ["method1", "method2", "method3"])
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "method1, method2, method3"}


# Generated at 2022-06-26 03:16:56.640722
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(403) is not None


# Generated at 2022-06-26 03:17:05.519818
# Unit test for function add_status_code
def test_add_status_code():
    # Testing code was generated by pytest_sanic_fixtures.py
    status_code_0 = 2
    add_status_code(status_code_0)
    # Testing code was generated by pytest_sanic_fixtures.py
    status_code_1 = 3
    add_status_code(status_code_1)
    # Testing code was generated by pytest_sanic_fixtures.py
    status_code_2 = 4
    add_status_code(status_code_2)
    # Testing code was generated by pytest_sanic_fixtures.py
    status_code_3 = 5
    add_status_code(status_code_3)
    # Testing code was generated by pytest_sanic_fixtures.py
    status_code_4 = 6

# Generated at 2022-06-26 03:17:08.533000
# Unit test for function add_status_code
def test_add_status_code():
    # Note: This test is currently untestable because the decorator's
    # actual return value is not used.
    # assert False, "TODO"
    pass


# Generated at 2022-06-26 03:17:09.085379
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-26 03:17:10.570117
# Unit test for function add_status_code
def test_add_status_code():
    server_error_0 = ServerError('ServerError')
    assert server_error_0.status_code == 500
    assert server_error_0.quiet is False


# Generated at 2022-06-26 03:18:36.800369
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_test_0 = add_status_code(0)
    add_status_code_test_1 = add_status_code(0, quiet=True)
    add_status_code_test_2 = add_status_code(0, '0')
    add_status_code_test_3 = add_status_code(0, quiet='0')
    add_status_code_test_4 = add_status_code(0, 0)
    add_status_code_test_5 = add_status_code(0, quiet=0)
    add_status_code_test_6 = add_status_code(0, None)
    add_status_code_test_7 = add_status_code(0, quiet=None)


test_case_0()
test_add_status_code()

# Generated at 2022-06-26 03:18:45.814970
# Unit test for function add_status_code
def test_add_status_code():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from io import StringIO
    import sys
    # Set up context manager to mock stdout
    mock_stdout = StringIO()
    stdout_context_manager = patch('sys.stdout', new=mock_stdout)
    with stdout_context_manager as mock_stdout:
        # Call function to be tested
        add_status_code(200)
        add_status_code.__call__(200)
        # Check if stdout was written to
        mock_stdout.write.assert_any_call("")
        mock_stdout.write.assert_any_call("")


# Generated at 2022-06-26 03:18:46.702652
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:18:47.639199
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code()


# Generated at 2022-06-26 03:18:54.406981
# Unit test for function add_status_code
def test_add_status_code():
    # TypeError1: add_status_code expected 1 argument, got 0
    #return add_status_code()
    # TypeError2: add_status_code expects a function or method
    # return add_status_code([])
    # return add_status_code({})
    # return add_status_code(None)
    # return add_status_code(())
    return add_status_code(1)(1)
    # TypeError3: add_status_code expected 1 positional argument, got 2
    # return add_status_code(1, '')
    # TypeError4: add_status_code() got an unexpected keyword argument 'n'
    # return add_status_code(n=1)
    # TypeError5: add_status_code() missing 1 required positional argument: 'code'
    # return add_status

# Generated at 2022-06-26 03:19:05.124526
# Unit test for function add_status_code
def test_add_status_code():

    class FakeClass(object):
        def __init__(self, io):
            self.io = io

    # This function will call the FakeClass's constructor with the content:
    # {'foo': 'bar'}
    test_add_status_code_0 = add_status_code(400, True)

    # This function will call the FakeClass's constructor with the content:
    # {'foo': 'bar'}
    test_add_status_code_1 = add_status_code(404)

    # This function will call the FakeClass's constructor with the content:
    # {'foo': 'bar'}
    test_add_status_code_2 = add_status_code(408, True)

    # This function will call the FakeClass's constructor with the content:
    # {'foo': 'bar'}
   

# Generated at 2022-06-26 03:19:15.771247
# Unit test for function add_status_code
def test_add_status_code():
    # Make sure that it returns correct type.
    with pytest.raises(TypeError, match=r".* 'function' object is not iterable.*"):
        _sanic_exceptions = {}
        add_status_code(status_code=404)
    # Make sure that it returns correct value.
    with pytest.raises(ValueError, match=r".*too many values to unpack \(expected 2\).*"):
        add_status_code(status_code=404, quiet=None)
    # Make sure that it returns correct value.
    with pytest.raises(RuntimeError, match=r".*maximum recursion depth exceeded.*"):
        add_status_code(status_code=404, quiet=None)
    # Make sure that it returns correct value.

# Generated at 2022-06-26 03:19:19.116002
# Unit test for function add_status_code
def test_add_status_code():
    parameter_0 = 500
    parameter_1 = _sanic_exceptions
    _sanic_exceptions = add_status_code(parameter_0, parameter_1)


# Generated at 2022-06-26 03:19:21.087042
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) == add_status_code(404)
# Test case 0

# Generated at 2022-06-26 03:19:28.541941
# Unit test for function add_status_code
def test_add_status_code():
    # Test number 0:
    try:
        assert False
    except:
        sanic_exception_0 = SanicException
    # Test number 1:
    try:
        assert False
    except:
        exception_0 = Exception
    # Test number 2:
    try:
        assert False
    except:
        invalid_usage_0 = InvalidUsage
    # Test number 3:
    try:
        assert False
    except:
        method_not_supported_0 = MethodNotSupported
    # Test number 4:
    try:
        assert False
    except:
        server_error_0 = ServerError
    # Test number 5:
    try:
        assert False
    except:
        service_unavailable_0 = ServiceUnavailable
    # Test number 6:
        assert _sanic_exceptions[503] != []