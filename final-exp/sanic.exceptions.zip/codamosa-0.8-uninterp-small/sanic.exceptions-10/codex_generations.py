

# Generated at 2022-06-26 03:11:24.759821
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    var_0 = Unauthorized("Auth required.")


# Generated at 2022-06-26 03:11:28.428468
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401


# Generated at 2022-06-26 03:11:29.753284
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:11:32.817848
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    int_0 = 401;
    str_0 = "Auth required.";
    str_1 = "Bearer";
    var_0 = Unauthorized(str_0, int_0, str_1);

# Generated at 2022-06-26 03:11:41.412401
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    msg: str = "Auth required."
    status_code: int = 401
    scheme: str = "Basic"
    realm: str = "Restricted Area"
    ex: Unauthorized = Unauthorized(msg, status_code, scheme, realm=realm)
    assert ex.status_code == status_code
    assert ex.scheme == scheme
    assert ex.realm == realm
    assert ex.kwargs == {'realm': realm}

    status_code = 403
    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"

# Generated at 2022-06-26 03:11:44.507055
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    ab = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert ab.message == "Auth required."

# Generated at 2022-06-26 03:11:47.257568
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    test_case_0()
    test_case_0()
    test_case_0()

if __name__ == "__main__":
    test_Unauthorized()

# Generated at 2022-06-26 03:11:50.020042
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Case when nothing is passed
    test_Unauthorized_0()
    # Case when everything is passed
    test_Unauthorized_1()


# Generated at 2022-06-26 03:11:56.771539
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 750
    def func_0(arg_0):
        return arg_0
    status_0 = add_status_code(int_0)(func_0)
    list_0 = [status_0]
    status_0 = list_0[0]
    return status_0.status_code



# Generated at 2022-06-26 03:11:59.187447
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    var_0 = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")


test_case_0()
test_Unauthorized()

# Generated at 2022-06-26 03:12:06.546512
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test with scheme=None, status_code=None, kwargs={}
    unauthorized_obj = Unauthorized("Auth required.", scheme=None, status_code=None, **{})
    # Assert that unauthorized_obj.headers == {}
    assert unauthorized_obj.headers == {}
    if (unauthorized_obj is not None):
        # Test with scheme=None, status_code=None, kwargs={'realm': 'Restricted Area'}
        unauthorized_obj = Unauthorized("Auth required.", scheme=None, status_code=None, **{'realm': 'Restricted Area'})
        # Assert that unauthorized_obj.headers == {}
        assert unauthorized_obj.headers == {}

# Generated at 2022-06-26 03:12:09.673760
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 0
    bool_0 = False
    bool_1 = bool_0
    add_status_code(int_0, bool_1)


# Generated at 2022-06-26 03:12:10.704161
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)


# Generated at 2022-06-26 03:12:15.630079
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)
    @add_status_code(500)
    class SanicException(): pass
    status_code = 500
    assert SanicException.status_code == status_code
    assert SanicException.quiet is False
    assert status_code in _sanic_exceptions


# Generated at 2022-06-26 03:12:16.664498
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(True)


# Generated at 2022-06-26 03:12:20.564450
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls
    cls_0 = class_decorator(_sanic_exceptions[500])
    assert cls_0.status_code == 500


# Generated at 2022-06-26 03:12:28.021263
# Unit test for function add_status_code
def test_add_status_code():
    def function_0():
        bool_0 = True
        server_error_0 = ServerError(True, 500)
        return
    function_0()
    function_0()
    function_0()
    function_0()
    def function_1():
        server_error_0 = ServerError("O\u00b7A\u00b7F\u00b7O\u00b7W\u00b7C", 500)
        return
    function_1()
    function_1()
    function_1()
    function_1()
    def function_2():
        server_error_0 = ServerError("L>\u00b7R\u00b7V\u00b7B", 500)
        return
    function_2()
    function_2()
    function_2()
    function

# Generated at 2022-06-26 03:12:33.994176
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(
        200
    )  # Add status code of type int, with optional parameter quiet
    add_status_code(
        200,
        None
    )  # Add status code of type int, with optional parameter of type None
    add_status_code(
        200,
        True
    )  # Add status code of type int, with optional parameter of type bool


# Generated at 2022-06-26 03:12:38.263342
# Unit test for constructor of class Unauthorized

# Generated at 2022-06-26 03:12:42.496879
# Unit test for function add_status_code
def test_add_status_code():
    bool_0 = False
    except_instance = HeaderNotFound(bool_0)
    status = except_instance.status_code
    return status


# Generated at 2022-06-26 03:12:50.597139
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 1
    str_0 = "7"
    int_1 = int(str_0)
    str_1 = str(int_0)
    dict_0 = {
        str_0: int_0,
        str_1: int_1,
    }
    assert dict_0 == {
        "1": 1,
        "7": 7,
    }


# Generated at 2022-06-26 03:12:53.987106
# Unit test for function add_status_code
def test_add_status_code():
    def func_0():
        pass

    def func_1():
        pass
    add_status_code(200, True)(func_0)
    add_status_code(302)(func_1)

# Function test for function abort

# Generated at 2022-06-26 03:13:03.327639
# Unit test for function add_status_code
def test_add_status_code():
    # Tests function with invalid parameters
    try:
        add_status_code(1)
    except:
        pass
    # Tests function with invalid parameters
    try:
        add_status_code(1, 1)
    except:
        pass
    # Tests function with invalid parameters
    try:
        add_status_code(1.0, 1.0)
    except:
        pass
    # Tests function with invalid parameters
    try:
        add_status_code("string", "string")
    except:
        pass
    # Tests function with invalid parameters
    try:
        add_status_code(None, None)
    except:
        pass


# Generated at 2022-06-26 03:13:09.696247
# Unit test for function add_status_code
def test_add_status_code():
    # Check code 0
    func_0 = add_status_code(0)
    # Call the function to get the status_code
    bool_0 = bool("0" in _sanic_exceptions)
    assert bool_0 == True
    # Call the function to get the status_code
    test_case_0()


# Generated at 2022-06-26 03:13:14.120242
# Unit test for function add_status_code
def test_add_status_code():
    test_code = 0
    test_quiet = None
    test_class_decorator = add_status_code(test_code, test_quiet)

    # Test the type of the returned object
    assert isinstance(test_class_decorator, status_code_0)


# Generated at 2022-06-26 03:13:28.110397
# Unit test for function add_status_code
def test_add_status_code():
    bool_0 = False
    add_status_code_0 = add_status_code(bool_0)
    dict_0 = {}
    dict_0['Internal Server Error'] = ServerError
    dict_0['Improperly formatted multipart body'] = InvalidUsage
    dict_0['Content Range Not Satisfiable'] = SanicException
    dict_0['Request Timeout'] = SanicException

    dict_1 = {}
    dict_1['Forbidden'] = SanicException
    dict_1['Method Not Allowed'] = SanicException
    dict_1['Digest'] = Unauthorized
    dict_1['Service Unavailable'] = ServiceUnavailable
    dict_1['Header Expectation Failed'] = SanicException

    dict_2 = {}
    dict_2['LoadFileException'] = LoadFileException

# Generated at 2022-06-26 03:13:28.927977
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        add_status_code(1)


# Generated at 2022-06-26 03:13:32.370717
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(408)

# Generated at 2022-06-26 03:13:43.097215
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions['503'] is ServiceUnavailable
    assert _sanic_exceptions['404'] is NotFound
    assert _sanic_exceptions['400'] is InvalidUsage
    assert _sanic_exceptions['405'] is MethodNotSupported
    assert _sanic_exceptions['500'] is ServerError
    assert ServiceUnavailable.status_code == 503
    assert NotFound.status_code == 404
    assert InvalidUsage.status_code == 400
    assert MethodNotSupported.status_code == 405
    assert ServerError.status_code == 500
    assert ServiceUnavailable.quiet == True
    assert NotFound.quiet == True
    assert InvalidUsage.quiet == True
    assert MethodNotSupported.quiet is None
    assert ServerError.quiet is None
    # assert add_status_code(503) is add_status_code(

# Generated at 2022-06-26 03:13:47.277771
# Unit test for function add_status_code
def test_add_status_code():
    # Testing if status code is returned
    if _sanic_exceptions[500].status_code == 500:
        print("Test add_status_code(): PASS")
    else:
        print("Test add_status_code(): FAIL")


# Generated at 2022-06-26 03:13:56.580241
# Unit test for function add_status_code
def test_add_status_code():
    f_0 = add_status_code(404)
    bool_0 = f_0(NotFound)
    assert(bool_0.status_code == 404)

if __name__ == "__main__":
    test_case_0()
    test_add_status_code()

# Generated at 2022-06-26 03:13:57.716407
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(True)

# Generated at 2022-06-26 03:13:59.429329
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 500
    str_0 = "SanicException"
    str_1 = "status_code"
    add_status_code(str_0=str_0, int_0=int_0, str_1=str_1)

# Generated at 2022-06-26 03:13:59.983697
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)

# Generated at 2022-06-26 03:14:01.373273
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(0, True)


# Generated at 2022-06-26 03:14:02.212760
# Unit test for function add_status_code
def test_add_status_code():
	assert add_status_code(404)


# Generated at 2022-06-26 03:14:04.984825
# Unit test for function add_status_code
def test_add_status_code():
    def func_1():
        pass

    int_0 = 1
    class_0 = add_status_code(int_0)(func_1)


# Generated at 2022-06-26 03:14:14.948358
# Unit test for function add_status_code
def test_add_status_code():
    # Test 1
    assert add_status_code(404) == class_decorator
    assert add_status_code(404, None) == class_decorator
    assert add_status_code(404, True) == class_decorator
    assert add_status_code(404, False) == class_decorator
    # Test 2
    assert add_status_code(400) == class_decorator
    assert add_status_code(400, None) == class_decorator
    assert add_status_code(400, True) == class_decorator
    assert add_status_code(400, False) == class_decorator
    # Test 3
    assert add_status_code(405) == class_decorator
    assert add_status_code(405, None) == class_decorator


# Generated at 2022-06-26 03:14:27.052348
# Unit test for function add_status_code
def test_add_status_code():
    test_code = 404
    test_quiet = None
    # Test a function
    def test_class_decorator(cls):
        cls.status_code = test_code
        if test_quiet or test_quiet is None and test_code != 500:
            cls.quiet = True
        _sanic_exceptions[test_code] = cls
        return cls

    # Test calling the function
    @add_status_code(test_code, test_quiet)
    class TestClass(SanicException):
        # Test a class
        pass

    # Test the class
    assert hasattr(TestClass, "status_code")
    assert TestClass.status_code == test_code
    assert hasattr(TestClass, "quiet")
    assert TestClass.quiet == True
    assert _sanic_exceptions

# Generated at 2022-06-26 03:14:28.050185
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:14:48.655736
# Unit test for function add_status_code
def test_add_status_code():
    # Test with code = None,quiet = False
    status_code_0 = None
    quiet_0 = False
    header_not_found_0 = HeaderNotFound(status_code_0,quiet_0)

    # Test with code = None,quiet = None
    status_code_1 = None
    quiet_1 = None
    header_not_found_1 = HeaderNotFound(status_code_1,quiet_1)

    # Test with code = None,quiet = True
    status_code_2 = None
    quiet_2 = True
    header_not_found_2 = HeaderNotFound(status_code_2,quiet_2)



# Generated at 2022-06-26 03:14:50.677256
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = type('', (), {})()
    add_status_code(400, False)(class_0)


# Generated at 2022-06-26 03:14:59.771633
# Unit test for function add_status_code
def test_add_status_code():
    # function_add_status_code_0
    with pytest.raises(TypeError):
        add_status_code({}, quiet)
    # function_add_status_code_1
    with pytest.raises(TypeError):
        add_status_code(408, 'PayLoadTooLarge')
    # function_add_status_code_2
    add_status_code(404, quiet=False)
    # function_add_status_code_3
    with pytest.raises(TypeError):
        add_status_code('FileNotFound', quiet=None)
    # function_add_status_code_4
    add_status_code(500, quiet)
    # function_add_status_code_5

# Generated at 2022-06-26 03:15:00.921672
# Unit test for function add_status_code
def test_add_status_code():
    assert callable(add_status_code)

# Generated at 2022-06-26 03:15:07.722856
# Unit test for function add_status_code
def test_add_status_code():
    try:
        assert not _sanic_exceptions
        _0 = add_status_code(404)(NotFound)
        _sanic_exceptions
    except AssertionError:
        pass
    finally:
        try:
            assert _sanic_exceptions
        except AssertionError:
            pass



# Generated at 2022-06-26 03:15:08.746040
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:15:14.215452
# Unit test for function add_status_code
def test_add_status_code():
    def func_0(code, quiet=None):
        pass

    func_1 = add_status_code(500, False)
    func_2 = add_status_code(500)
    func_3 = add_status_code(404, True)
    func_4 = add_status_code(404)


# Generated at 2022-06-26 03:15:24.693127
# Unit test for function add_status_code
def test_add_status_code():

    class NotFound_0(SanicException):
        pass

    not_found_0 = NotFound_0()
    test_0 = not_found_0.status_code
    not_found_1 = NotFound_0()
    test_1 = not_found_1.status_code

    class Unauthorized_0(SanicException):
        pass

    unauthorized_0 = Unauthorized_0()
    test_2 = unauthorized_0.status_code
    unauthorized_1 = Unauthorized_0()
    test_3 = unauthorized_1.status_code


# Generated at 2022-06-26 03:15:25.535803
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:15:27.442512
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:15:58.650898
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

    class_0 = NotFound
    assert class_0.__name__ == "NotFound", "sanic.exceptions.test_add_status_code:0"
    assert class_0.__qualname__ == "NotFound", "sanic.exceptions.test_add_status_code:1"
    assert class_0.__doc__ == "**Status**: 404 Not Found", "sanic.exceptions.test_add_status_code:2"
    assert class_0.status_code == 404, "sanic.exceptions.test_add_status_code:3"


# Generated at 2022-06-26 03:16:00.842276
# Unit test for function add_status_code
def test_add_status_code():
    # Case 1

    # Case 2
    class_0 = SanicException
    add_status_code_0 = add_status_code(class_0)
    class_1 = add_status_code_0(class_0)


# Generated at 2022-06-26 03:16:04.629174
# Unit test for function add_status_code
def test_add_status_code():
    def function_0(arg_0):
        var_0 = NotFound()
        return var_0
    var_0 = add_status_code(int(), function_0)
    var_0(NotFound())


# Generated at 2022-06-26 03:16:05.562204
# Unit test for function add_status_code
def test_add_status_code():
    # test exception
    # test success case
    pass

# Generated at 2022-06-26 03:16:08.579205
# Unit test for function add_status_code
def test_add_status_code():
    bool_0 = True
    # SanicException.__init__
    custom_exception_1 = add_status_code(bool_0)(SanicException)
    return


# Generated at 2022-06-26 03:16:10.094928
# Unit test for function add_status_code
def test_add_status_code():
    pass
    add_status_code(415)


# Generated at 2022-06-26 03:16:12.062756
# Unit test for function add_status_code
def test_add_status_code():
    """
    :return:
    """
    add_status_code(4)


# Generated at 2022-06-26 03:16:13.718509
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:16:19.375060
# Unit test for function add_status_code
def test_add_status_code():
    class ExpectedException(Exception):
        pass

    @add_status_code(404, quiet=True)
    class _ExpectedException(ExpectedException):
        pass

    # Assert status code was added to class
    assert _ExpectedException.status_code == 404

    # Assert the quiet flag was set if expected
    assert _ExpectedException().quiet

    with assert_raises(Exception):
        raise _ExpectedException()

# Generated at 2022-06-26 03:16:21.600823
# Unit test for function add_status_code
def test_add_status_code():
    bool_0 = False
    expected_0 = NotFound
    actual_0 = add_status_code(expected_0)
    assert actual_0 == expected_0

# Generated at 2022-06-26 03:17:09.079729
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert add_status_code(404).__code__.co_varnames == ("cls",)

# Generated at 2022-06-26 03:17:15.592539
# Unit test for function add_status_code
def test_add_status_code():
    # Initialize test case
    add_status_code_test_case_0 = [None, None, None, None]


    def class_decorator_0(cls_0):
        return (cls_0)


    add_status_code_test_case_0[0] = class_decorator_0

    # Function test
    add_status_code_0 = add_status_code(None, None)
    assert(add_status_code_test_case_0[0] == add_status_code_0)



# Generated at 2022-06-26 03:17:26.428622
# Unit test for function add_status_code
def test_add_status_code():
  status_code_0 = 404
  add_status_code_0 = add_status_code(status_code_0)
  status_code_1 = 500
  add_status_code_1 = add_status_code(status_code_1)
  status_code_2 = 408
  add_status_code_2 = add_status_code(status_code_2)
  status_code_3 = 5
  add_status_code_3 = add_status_code(status_code_3)
  status_code_4 = 400
  add_status_code_4 = add_status_code(status_code_4)
  status_code_5 = 413
  add_status_code_5 = add_status_code(status_code_5)
  status_code_6 = 401
  add_status

# Generated at 2022-06-26 03:17:37.911597
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = None
    expected_result_0 = -1

    add_status_code_1 = None
    expected_result_1 = -1

    add_status_code_0, expected_result_0 = (
        add_status_code(400, quiet=False),
        400,
    )
    add_status_code_1, expected_result_1 = (
        add_status_code(400, quiet=True),
        400,
    )
    assert add_status_code_0.quiet != add_status_code_1.quiet
    assert (
        add_status_code_0.status_code == expected_result_0
        and add_status_code_1.status_code == expected_result_1
    )


# Generated at 2022-06-26 03:17:44.664217
# Unit test for function add_status_code
def test_add_status_code():
    cls_0 = NotFound
    not_found_0 = cls_0()
    assert not_found_0.status_code == 404


# Generated at 2022-06-26 03:17:48.216990
# Unit test for function add_status_code
def test_add_status_code():
    """
    Run a unit test for function add_status_code
    """
    int_0 = 0
    add_status_code_0 = add_status_code(int_0)
    assert add_status_code_0 != None


# Generated at 2022-06-26 03:17:49.954637
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(1, True)
    except HeaderNotFound:
        pass

# Generated at 2022-06-26 03:17:57.853675
# Unit test for function add_status_code
def test_add_status_code():
    bool_1 = False
    class_0 = NotFound
    add_status_code_0 = add_status_code(bool_1, bool_1)
    add_status_code_0(class_0 = class_0)
    add_status_code_0 = add_status_code(bool_1, bool_1)
    add_status_code_0(class_0 = class_0)
    add_status_code_0 = add_status_code(bool_1, bool_1)
    add_status_code_0(class_0 = class_0)
    add_status_code_0 = add_status_code(bool_1, bool_1)
    add_status_code_0(class_0 = class_0)


# Generated at 2022-06-26 03:18:10.906837
# Unit test for function add_status_code
def test_add_status_code():
    # from SanicExceptions import add_status_code, SanicException
    # print(add_status_code.__code__.co_varnames)
    # print(add_status_code.__code__.co_argcount)
    def class_decorator(cls):
        # cls.status_code = code
        pass

    class SanicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    class_decorator(SanicException)

# Generated at 2022-06-26 03:18:13.721975
# Unit test for function add_status_code
def test_add_status_code():
    print('Testing test_add_status_code')
    class_decorator_ret_val = add_status_code(404)
    assert class_decorator_ret_val.status_code == 404


# Generated at 2022-06-26 03:19:49.873070
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    bool_0 = False
    header_not_found_0 = HeaderNotFound(bool_0)

# skipped unit test for class InvalidUsage


# Generated at 2022-06-26 03:19:52.121468
# Unit test for function add_status_code
def test_add_status_code():
    func_0 = add_status_code
    int_0 = 1
    func_0(int_0)


# Generated at 2022-06-26 03:20:02.771004
# Unit test for function add_status_code
def test_add_status_code():
    # Create an instance of ServerError
    server_error_0 = ServerError("message_0", status_code=2, quiet=1)
    # Create an instance of SanicException
    sanic_exception_0 = SanicException("message_1", status_code=0, quiet=0)
    # Create an instance of PayloadTooLarge
    payload_too_large_0 = PayloadTooLarge("message_2", status_code=0, quiet=0)
    # Create an instance of URLBuildError
    url_build_error_0 = URLBuildError("message_3", status_code=0, quiet=1)
    # Create an instance of ServiceUnavailable
    service_unavailable_0 = ServiceUnavailable("message_4", status_code=2, quiet=0)
    # Create an instance of NotFound
    not_

# Generated at 2022-06-26 03:20:10.193335
# Unit test for function add_status_code
def test_add_status_code():
    code = 500
    quiet = True

    # Test with quiet
    class TestClass1(SanicException):
        pass
    TestClass1 = add_status_code(code)(TestClass1)
    assert TestClass1.status_code == code
    assert TestClass1.quiet == quiet
    assert TestClass1(bool_0)

    # Test without quiet
    class TestClass2(SanicException):
        pass
    TestClass2 = add_status_code(code, quiet=quiet)(TestClass2)
    assert TestClass2.status_code == code
    assert TestClass2.quiet == quiet
    assert TestClass2(bool_0)



# Generated at 2022-06-26 03:20:15.663974
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 407
    quiet_0 = False
    add_status_code_0 = add_status_code(status_code_0, quiet_0)
    class_name_0 = "TestClass"
    class_decorator_0 = type(class_name_0, (object,), {})
    sanic_exception_0 = add_status_code_0(class_decorator_0)
    assert sanic_exception_0.__name__ == class_name_0
    assert sanic_exception_0.status_code == status_code_0
    assert sanic_exception_0.quiet == quiet_0


# Generated at 2022-06-26 03:20:17.858430
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(True)
    add_status_code_1 = add_status_code(True, True)

# Generated at 2022-06-26 03:20:19.556026
# Unit test for function add_status_code
def test_add_status_code():
    bool_0 = False
    add_status_code(bool_0)


# Generated at 2022-06-26 03:20:26.842149
# Unit test for function add_status_code
def test_add_status_code():
    # Test attributes of function add_status_code for type
    status_code = ''
    quiet = False
    def class_decorator(cls):
        cls.status_code = status_code
        if quiet or quiet is None and status_code != 500:
            cls.quiet = True
        _sanic_exceptions[status_code] = cls
        return cls
    assert class_decorator('') is None



# Generated at 2022-06-26 03:20:34.235865
# Unit test for function add_status_code
def test_add_status_code():
    # Test class SanicException
    try:
        add_status_code(None)
    except TypeError as e:
        print(e)

    try:
        add_status_code(None, None)
    except TypeError as e:
        print(e)

    try:
        add_status_code(None, None)
    except TypeError as e:
        print(e)

    # Test class NotFound
    try:
        add_status_code(404)
    except TypeError as e:
        print(e)

    try:
        add_status_code(404, None)
    except TypeError as e:
        print(e)

    try:
        add_status_code(404, None)
    except TypeError as e:
        print(e)

    # Test class InvalidUsage
   

# Generated at 2022-06-26 03:20:39.347006
# Unit test for function add_status_code
def test_add_status_code():
    test_var_0 = 500
    add_status_code_0 = add_status_code(test_var_0)
    load_file_exception_0 = LoadFileException(None)
    status_code_0 = load_file_exception_0.status_code
    assert status_code_0 == test_var_0