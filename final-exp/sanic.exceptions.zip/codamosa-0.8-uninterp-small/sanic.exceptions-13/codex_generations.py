

# Generated at 2022-06-26 03:11:24.759766
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    not_found_0 = NotFound(float_0)
    float_1 = 15.0
    invalid_usage_0 = InvalidUsage(float_1)
    float_2 = 15.0
    method_not_supported_0 = MethodNotSupported(float_2, "GET", {"POST", "PUT"})
    float_3 = 15.0
    server_error_0 = ServerError(float_3)
    float_4 = 15.0
    service_unavailable_0 = ServiceUnavailable(float_4)
    float_5 = 15.0
    request_timeout_0 = RequestTimeout(float_5)
    float_6 = 15.0
    payload_too_large_0 = PayloadTooLarge(float_6)
    float_7 = 15.0
    content_

# Generated at 2022-06-26 03:11:26.700597
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise NotFound("hi")
    except NotFound as e:
        assert e.status_code == 404
    try:
        raise PayloadTooLarge("hi")
    except PayloadTooLarge as e:
        assert e.status_code == 413


# Generated at 2022-06-26 03:11:30.280478
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 1
    add_status_code_0 = add_status_code(status_code_0)
    add_status_code_0()



# Generated at 2022-06-26 03:11:34.104703
# Unit test for function add_status_code
def test_add_status_code():
    # In function call to add_status_code, __init__ is called
    # with two parameters, one of which is evaluated as runtime
    test_case_0()


test_add_status_code()

# Generated at 2022-06-26 03:11:42.157817
# Unit test for function add_status_code
def test_add_status_code():
    # Test No.1:
    # Functionality:
    #   Test if a status_code of '403' is added
    # Arguments:
    #   code: 403
    # Return value:
    #   Test sample is not expecting a return value.
    # Exception raised:
    #   Not expecting an exception to be raised
    # Test result:
    #   If status_code is added, test passes.
    #   If exception is raised, test fails.
    #   If function cannot be tested, test fails
    status_code = 403
    try:
        add_status_code(status_code)
    except Exception as e:
        # Test fails on any exception
        assert False

    # Test No.2:
    # Functionality:
    #   Test if a status_code of '503' is added
    # Arguments

# Generated at 2022-06-26 03:11:54.121778
# Unit test for function add_status_code

# Generated at 2022-06-26 03:11:55.111443
# Unit test for function add_status_code
def test_add_status_code():
    assert (add_status_code(404))

# Generated at 2022-06-26 03:12:02.431249
# Unit test for function add_status_code
def test_add_status_code():
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
    dummy_variable = 123
    add_status_code(2, dummy_variable)
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
    dummy_variable = 123
    add_status_code(2, dummy_variable)
    dummy_variable = 'dummy_variable'
    add_status_code(2, dummy_variable)
   

# Generated at 2022-06-26 03:12:06.027725
# Unit test for function add_status_code
def test_add_status_code():
    result_0 = add_status_code(204)
    result_1 = add_status_code(code=404, quiet=False)
    result_2 = add_status_code(code=400, quiet=None)
    result_3 = add_status_code(code=405, quiet=True)
    result_4 = add_status_code(code=503, quiet=False)
    result_5 = add_status_code(code=500, quiet=None)


# Generated at 2022-06-26 03:12:07.593834
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) == class_decorator


# Generated at 2022-06-26 03:12:15.832620
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    not_found_0 = NotFound(float_0)
    assert hasattr(not_found_0, "status_code")
    assert not hasattr(not_found_0, "quiet")
    not_found_0.status_code is exception_0
    assert isinstance(exception_0, ValueError)
    assert exception_0.args[0] == "Exception message"



# Generated at 2022-06-26 03:12:16.813475
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    not_found_0 = NotFound(float_0)



# Generated at 2022-06-26 03:12:23.318363
# Unit test for function add_status_code
def test_add_status_code():
    # Test with valid arguments
    def function_0(int_0):
        invalid_usage_0 = InvalidUsage(int_0)
    # Test with valid arguments
    def function_1(int_0):
        name_ioerror_0 = FileNotFound(int_0, int_0, int_0)
    # Test with valid arguments
    def function_2(str_0):
        range_not_satisfiable_0 = InvalidRangeType(str_0)



# Generated at 2022-06-26 03:12:29.664603
# Unit test for function add_status_code
def test_add_status_code():
    # ANSWER: It is the decorator.
    # First case: the status code is 200, so it is a valid code.
    # Second case: the status code is not a valid code, so we raise an error.
    add_status_code(200)
    with pytest.raises(ValueError):
        add_status_code("404 Not Found")


# Generated at 2022-06-26 03:12:33.993889
# Unit test for function add_status_code
def test_add_status_code():
    try:
        http_413 = PayloadTooLarge(message="too_large", status_code=413)
        assert http_413.status_code == 413
    except AssertionError:
        print("test_add_status_code::test_case_0 failed")
        raise


# Generated at 2022-06-26 03:12:35.278321
# Unit test for function add_status_code
def test_add_status_code():
    # Test case from __main__.py
    test_case_0()

# Generated at 2022-06-26 03:12:36.139885
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:12:42.380260
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) is not None
    assert add_status_code(400) is not None
    assert add_status_code(405) is not None
    assert add_status_code(500) is not None
    assert add_status_code(503) is not None
    assert add_status_code(408) is not None
    assert add_status_code(413) is not None
    assert add_status_code(416) is not None
    assert add_status_code(417) is not None
    assert add_status_code(403) is not None
    assert add_status_code(401) is not None


# Generated at 2022-06-26 03:12:43.851695
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(53)


# Generated at 2022-06-26 03:12:54.344221
# Unit test for function add_status_code
def test_add_status_code():
    tmp = "should add status code correctly"
    status = 412
    class_decorator_0 = add_status_code(status)
    class_decorator_1 = class_decorator_0
    class_decorator_2 = class_decorator_0

    class class_decorator_0(object):
        def __init__(self, float_0):
            self.exception_message = float_0

        def set_status_code(self):
            self.status_code = status

        def set_quiet(self):
            self.quiet = True

    c = class_decorator_0(tmp)

    # Check exception message is correct
    assert c.exception_message == tmp

    # Check status code is correct
    c.set_status_code()
    assert c.status_

# Generated at 2022-06-26 03:13:00.514937
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 404
        if 404:
            cls.quiet = True
        _sanic_exceptions[404] = cls
        return cls
    x = test_add_status_code()


# Generated at 2022-06-26 03:13:11.381765
# Unit test for function add_status_code
def test_add_status_code():
    import types
    import sys

    add_status_code(404)

    # Test SanicException class
    assert SanicException.__module__ == 'sanic.exceptions'
    assert SanicException.__name__ == 'SanicException'
    assert SanicException.__bases__ == (Exception,)
    assert SanicException.__doc__ == '\n    A base exception class for all Sanic Exceptions\n    '
    assert SanicException.__init__.__name__ == '__init__'
    assert SanicException.__init__.__doc__ == '\n        :param message: Error message\n        :param status_code: HTTP Status code\n        '

    # Test NotFound class with code 404
    assert NotFound.__module__ == 'sanic.exceptions'
    assert NotFound.__name

# Generated at 2022-06-26 03:13:19.335791
# Unit test for function add_status_code
def test_add_status_code():
    # Test for parameter `code`:
    assert add_status_code(401)
    # Test for parameter `quiet`:
    assert add_status_code(403, quiet=None)
    # Test for parameter `code`:
    assert add_status_code(404)
    # Test for parameter `quiet`:
    assert add_status_code(400, quiet=None)
    # Test for parameter `quiet`:
    assert add_status_code(405, quiet=None)
    # Test for parameter `code`:
    assert add_status_code(500)
    # Test for parameter `quiet`:
    assert add_status_code(503, quiet=None)
    # Test for parameter `quiet`:
    assert add_status_code(408, quiet=None)
    # Test for parameter `code`:
   

# Generated at 2022-06-26 03:13:20.291271
# Unit test for function add_status_code
def test_add_status_code():
    not_found_0 = NotFound(15.0)
    return not_found_0


# Generated at 2022-06-26 03:13:23.340242
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 0
    exc = add_status_code(int_0)(Exception)
    assert exc.status_code == int_0


# Generated at 2022-06-26 03:13:26.164324
# Unit test for function add_status_code
def test_add_status_code():
    # test the function
    add_status_code(404)
    add_status_code(405)
    add_status_code(500)


# Generated at 2022-06-26 03:13:28.761864
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = lambda cls: cls
    assert add_status_code(float_0, class_decorator_0) != NotFound



# Generated at 2022-06-26 03:13:29.560808
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:13:31.983718
# Unit test for function add_status_code
def test_add_status_code():
    # main
    assert add_status_code(404)(NotFound) == NotFound


# Generated at 2022-06-26 03:13:36.212038
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(416)
    assert add_status_code(417)


# Generated at 2022-06-26 03:13:46.855161
# Unit test for function add_status_code
def test_add_status_code():
    func_0 = add_status_code
    str_0 = 'Test Case 0'
    str_1 = 'Test Case 1'
    str_2 = 'Test Case 2'
    str_3 = 'Test Case 3'
    str_4 = 'Test Case 4'
    str_5 = 'Test Case 5'
    str_6 = 'Test Case 6'
    str_7 = 'Test Case 7'
    str_8 = 'Test Case 8'
    str_9 = 'Test Case 9'
    str_10 = 'Test Case 10'
    floating_point_0 = 84.94397
    func_0(floating_point_0)
    func_0 = add_status_code
    floating_point_1 = -40.50155
    func_0(floating_point_1, str_0)
   

# Generated at 2022-06-26 03:13:50.820758
# Unit test for function add_status_code
def test_add_status_code():
    default_0 = 400
    class_decorator = add_status_code(default_0)
    class_decorator(bool)



# Generated at 2022-06-26 03:13:52.595611
# Unit test for function add_status_code
def test_add_status_code():
    """Check if a NotFound exception has the correct status code"""
    not_found_0 = NotFound("")
    assert not_found_0.status_code == 404, "NotFound did not have the correct status code"


# Generated at 2022-06-26 03:14:03.208927
# Unit test for function add_status_code
def test_add_status_code():
    def case_0():
        int_0 = 77
        add_status_code_0 = add_status_code(int_0)
        return add_status_code_0

    def case_1():
        int_1 = 0
        add_status_code_1 = add_status_code(int_1)
        return add_status_code_1

    def case_2():
        int_2 = 5
        add_status_code_2 = add_status_code(int_2)
        return add_status_code_2

    def case_3():
        int_3 = -5
        add_status_code_3 = add_status_code(int_3)
        return add_status_code_3

    def case_4():
        int_4 = 88
        add_status_code_4

# Generated at 2022-06-26 03:14:04.430718
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404, quiet = None)



# Generated at 2022-06-26 03:14:12.419790
# Unit test for function add_status_code
def test_add_status_code():
    # Tests whether the decorator being made functions properly
    valid_0 = 201
    valid_1 = "status"
    valid_2 = "Unknown"
    # Testing with valid inputs
    assert add_status_code(valid_0, valid_1)(valid_2) == "Unknown"
    # Testing raised exceptions
    with pytest.raises(Exception):
        add_status_code("abc", valid_2)
    # Testing with invalid inputs
    with pytest.raises(Exception):
        add_status_code(valid_2, valid_1)


# Generated at 2022-06-26 03:14:13.950844
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = add_status_code(200)
    class_0(InvalidUsage)
    test_case_0()

# Generated at 2022-06-26 03:14:25.848713
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(500)(SanicException)
    add_status_code_1 = add_status_code()(SanicException)
    server_error_0 = ServerError('hello')
    test_0 = add_status_code_0 is ServerError
    test_1 = add_status_code_1.status_code == 500
    test_2 = server_error_0.status_code == 500
    test_3 = server_error_0.message == 'hello'
    test_4 = server_error_0.quiet is None
    test_5 = not_found_0.quiet is False
    test_6 = not_found_0.message == float_0

if __name__ == '__main__':
    test_case_0()
    # Unit test for function test

# Generated at 2022-06-26 03:14:36.338113
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    not_found_0 = NotFound(float_0)

    float_1 = 0.0
    not_found_1 = NotFound(float_1)

    float_2 = 10.0
    not_found_2 = NotFound(float_2)

    float_3 = 0.0
    not_found_3 = NotFound(float_3)

    float_4 = 10.0
    not_found_4 = NotFound(float_4)

    assert not_found_0.status_code == 404
    assert not_found_1.status_code == 404
    assert not_found_2.status_code == 404
    assert not_found_3.status_code == 404
    assert not_found_4.status_code == 404

# Generated at 2022-06-26 03:14:48.226649
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 100

    # This should fail with a RuntimeError
    # add_status_code('aaa', quiet=True)
    sanic_exception_0 = SanicException(int_0)
    sanic_exception_1 = SanicException(message=int_0)
    invalid_usage_0 = InvalidUsage(message=int_0, status_code=int_0)
    method_not_supported_0 = MethodNotSupported(message=int_0, method=int_0, allowed_methods=int_0)
    server_error_0 = ServerError(message=int_0, status_code=int_0, quiet=True)
    service_unavailable_0 = ServiceUnavailable(message=int_0, status_code=int_0)

# Generated at 2022-06-26 03:14:55.146317
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:14:56.781394
# Unit test for function add_status_code
def test_add_status_code():
    # Valid input
    code = 404
    add_status_code(code)


# Generated at 2022-06-26 03:15:08.745941
# Unit test for function add_status_code
def test_add_status_code():
    # Quiet and status code not specified
    not_found_0 = NotFound("test_message")
    assert not_found_0.status_code == 404
    assert not_found_0.quiet == True
    # Quiet specified and status code specified
    server_error_0 = ServerError("test_message", 500, True)
    assert server_error_0.status_code == 500
    assert server_error_0.quiet == True
    # Quiet specified and status code not specified
    not_found_0 = NotFound("test_message", None, True)
    assert not_found_0.status_code == 404
    assert not_found_0.quiet == True
    # Quiet not specified and status code specified
    server_error_0 = ServerError("test_message", 500, False)
    assert server_error_0.status_code

# Generated at 2022-06-26 03:15:10.430823
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(False)(None).__doc__ is not None


# Generated at 2022-06-26 03:15:12.341974
# Unit test for function add_status_code
def test_add_status_code():
    for i in range(0, 10):
        test_case_0()

    test_case_0()

# Generated at 2022-06-26 03:15:21.701547
# Unit test for function add_status_code
def test_add_status_code():
    # Test for correct usage
    def correct_add_status_code(code: int, silent: bool):
        # Make a function for testing
        def test_func():
            # Test for the correct variables
            if not hasattr(test_func, "status_code") or test_func.status_code != code or not hasattr(test_func, "quiet") or test_func.quiet != silent:
                # The test fails
                return False
            else:
                # The output of the test
                return True
        # Add the status code
        test_func = add_status_code(code, quiet=silent)(test_func)
        # Return the result
        return test_func()
    # Test the function
    assert correct_add_status_code(404, silent=True)

# Generated at 2022-06-26 03:15:25.567588
# Unit test for function add_status_code
def test_add_status_code():
    # Call function add_status_code and pass the following parameters:
    add_status_code(404)
    add_status_code(400)
    add_status_code(405)
    add_status_code(500)
    add_status_code(503)
    add_status_code(408)
    add_status_code(413)
    add_status_code(416)
    add_status_code(417)
    add_status_code(403)
    add_status_code(401)


# Generated at 2022-06-26 03:15:27.442592
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(0)


# Generated at 2022-06-26 03:15:30.250611
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions.get(404).status_code == 404


# Generated at 2022-06-26 03:15:32.319117
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test for adding status code
    """
    add_status_code(404)


# Generated at 2022-06-26 03:15:45.778510
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    not_found_0 = NotFound(float_0)


# Generated at 2022-06-26 03:15:47.272000
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(403, True)


# Generated at 2022-06-26 03:15:58.084622
# Unit test for function add_status_code
def test_add_status_code():

    def test_case_1():
        int_0 = 523
        not_found_0 = NotFound(int_0)
        not_found_1 = NotFound(int_0)
        test_case_1.not_found_0 = not_found_0
        test_case_1.not_found_1 = not_found_1

    # Unit test for function add_status_code
    def test_add_status_code():
        NotFound.status_code = 404
        NotFound.quiet = True
        assert (_sanic_exceptions[404] == NotFound)

    test_add_status_code()

    test_case_1()
    assert (test_case_1.not_found_0.status_code == test_case_1.not_found_1.status_code)


test_

# Generated at 2022-06-26 03:16:07.388203
# Unit test for function add_status_code
def test_add_status_code():
    assert(isinstance(add_status_code(404)(SanicException)(), NotFound))
    assert(isinstance(add_status_code(400)(SanicException)(), InvalidUsage))
    assert(isinstance(add_status_code(500)(SanicException)(), ServerError))
    assert(isinstance(add_status_code(503)(SanicException)(), ServiceUnavailable))
    assert(isinstance(add_status_code(408)(SanicException)(), RequestTimeout))
    assert(isinstance(add_status_code(413)(SanicException)(), PayloadTooLarge))
    assert(isinstance(add_status_code(416)(SanicException)(), ContentRangeError))
    assert(isinstance(add_status_code(417)(SanicException)(), HeaderExpectationFailed))

# Generated at 2022-06-26 03:16:08.730980
# Unit test for function add_status_code
def test_add_status_code():
        assert add_status_code(404) is class_decorator


# Generated at 2022-06-26 03:16:11.055821
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(NotFound)
    add_status_code_0(ServerError)


# Generated at 2022-06-26 03:16:13.601744
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except NotFound as e:
        assert isinstance(e, NotFound)
    except SanicException:
        assert False


# Generated at 2022-06-26 03:16:15.265225
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    add_status_code(code)


# Generated at 2022-06-26 03:16:20.832858
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 13
    method_not_supported_0 = MethodNotSupported(str_0, str_0, list_0)
    method_not_supported_0 = add_status_code(int_0)(method_not_supported_0)
    int_1 = method_not_supported_0.status_code
    pass

str_0 = "Method Not Supported"
str_1 = "GET"
list_0 = ["GET"]


# Generated at 2022-06-26 03:16:30.275746
# Unit test for function add_status_code
def test_add_status_code():
    expected_0 = 200
    expected_1 = True
    actual_0, actual_1 = None, None
    try:
        actual_0, actual_1 = NotFound.status_code, NotFound.quiet
    except NameError:
        if float_0 is float_0:
            actual_0, actual_1 = NotFound.status_code, NotFound.quiet
    error_1 = True
    try:
        assert (expected_0 == actual_0)
    except AssertionError:
        error_1 = False
    error_2 = True
    try:
        assert (expected_1 == actual_1)
    except AssertionError:
        error_2 = False
    if not error_1 and not error_2:
        raise RuntimeError("Something went wrong")

# Generated at 2022-06-26 03:16:58.234983
# Unit test for function add_status_code
def test_add_status_code():
    status_code = add_status_code(405)
    test_case_0()
    # assert status_code.__class__.__name__ == 'function'
    assert status_code.__code__.co_name == 'class_decorator'


# Generated at 2022-06-26 03:17:01.617597
# Unit test for function add_status_code
def test_add_status_code():
    NotFound.status_code = 404
    ServerError.status_code = 500

    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert ServerError.status_code == 500
    assert ServerError.quiet == False



# Generated at 2022-06-26 03:17:03.302205
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500, True) is add_status_code(500, True)


# Generated at 2022-06-26 03:17:13.655883
# Unit test for function add_status_code
def test_add_status_code():

    # Test for 'code'
    test_code = 200
    test_code_1 = 204

    # Test for 'quiet'
    test_quiet = True
    test_quiet_1 = False
    test_quiet_2 = None
    test_quiet_3 = None
    test_quiet_4 = False
    test_quiet_5 = True

    @add_status_code(test_code)
    class test_add_status_code_class_0:
        pass

    @add_status_code(test_code_1, test_quiet)
    class test_add_status_code_class_1:
        pass

    @add_status_code(test_code_1, test_quiet)
    class test_add_status_code_class_2:
        pass


# Generated at 2022-06-26 03:17:22.283098
# Unit test for function add_status_code
def test_add_status_code():
    float_0 = 15.0
    int_0 = 200
    #  Testing the default value of quiet, which shoud be True
    not_found_0 = NotFound(float_0)
    #  Testing the case of quiet=True
    not_found_1 = NotFound(float_0, quiet=True)
    #  Testing the case of quiet=False
    not_found_2 = NotFound(float_0, quiet=False)
    #  Testing the default value of quiet, which shoud be False
    server_error_0 = ServerError(float_0)
    #  Testing the case of quiet=False
    server_error_1 = ServerError(float_0, quiet=False)
    #  Testing the case of quiet=None
    not_found_3 = NotFound(float_0, quiet=None)
   

# Generated at 2022-06-26 03:17:24.070617
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(300)
    assert 300 in _sanic_exceptions.keys()



# Generated at 2022-06-26 03:17:26.652880
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)
    assert add_status_code(403)
    test_case_0()


# Generated at 2022-06-26 03:17:38.129102
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 15
    code_1 = 18
    code_2 = 15
    quiet_0 = False
    quiet_1 = True
    quiet_2 = None
    quiet_3 = False
    quiet_4 = True
    quiet_5 = None
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError:

# Generated at 2022-06-26 03:17:42.435488
# Unit test for function add_status_code
def test_add_status_code():
    test_add_status_code_0()


# Generated at 2022-06-26 03:17:53.872451
# Unit test for function add_status_code
def test_add_status_code():
    # Status code: 404
    test_case_0()
    float_1 = 2.0
    invalid_usage_0 = InvalidUsage(float_1)
    # Status code: 400
    test_case_1()
    string_0 = "not_allowed"
    list_0 = list()
    method_not_supported_0 = MethodNotSupported(string_0, string_0, list_0)
    # Status code: 405
    test_case_2()
    string_1 = "data"
    server_error_0 = ServerError(string_1)
    # Status code: 500
    test_case_3()
    double_0 = 1.941499780181858E-290
    service_unavailable_0 = ServiceUnavailable(double_0)
    # Status code: 503
    test_case

# Generated at 2022-06-26 03:18:48.408227
# Unit test for function add_status_code
def test_add_status_code():
    # Create an add_status_code
    a_add_status_code = add_status_code(500)

# Generated at 2022-06-26 03:18:54.837894
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions.get(400) == InvalidUsage
    assert _sanic_exceptions[400].status_code == 400
    assert _sanic_exceptions.get(405) == MethodNotSupported
    assert _sanic_exceptions[405].status_code == 405
    assert _sanic_exceptions.get(500) == ServerError
    assert _sanic_exceptions[500].status_code == 500
    assert _sanic_exceptions.get(503) == ServiceUnavailable
    assert _sanic_exceptions[503].status_code == 503
    assert _sanic_exceptions.get(408) == RequestTimeout

# Generated at 2022-06-26 03:18:55.976625
# Unit test for function add_status_code
def test_add_status_code():
    assert 500 == add_status_code(500)
    assert 503 == add_status_code(503)


# Generated at 2022-06-26 03:18:58.332677
# Unit test for function add_status_code
def test_add_status_code():
    _sanic_exceptions = {}
    assert add_status_code(1)(SanicException) in _sanic_exceptions

# unit test for class SanicException

# Generated at 2022-06-26 03:18:59.370652
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)


# Generated at 2022-06-26 03:19:08.075524
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 0
    message = 'message'
    quiet = True
    expected_exception = SanicException(message, status_code, quiet)
    exception = add_status_code(status_code, quiet)(SanicException)
    assert (exception(message).message == expected_exception.message)
    assert (exception(message).status_code == expected_exception.status_code)
    assert (exception(message).quiet == expected_exception.quiet)
    assert (exception(message).headers == expected_exception.headers)
    assert (str(exception(message)) == str(expected_exception))


# Generated at 2022-06-26 03:19:16.199824
# Unit test for function add_status_code
def test_add_status_code():
    import pytest
    # Case 0
    # Expected values:
    #   not_found_0 -> NotFound(15.0)
    float_0 = 15.0
    not_found_0 = NotFound(float_0)

    # Tests:
    #   not_found_0 -> NotFound(15.0)
    assert not_found_0.status_code == 404
    assert not_found_0.args == (15.0,)
    assert isinstance(not_found_0, NotFound)
    assert isinstance(not_found_0, SanicException)


# Generated at 2022-06-26 03:19:18.313781
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:19:19.352143
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:19:26.128554
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500, None)
    add_status_code(500, True)
    add_status_code(500, False)
    msg_0 = SanicException((float(False) if False else False), 500, False if (not (float(False) if False else False)) else False)
    add_status_code([], False)
    add_status_code(False, False)
    add_status_code(True, False)
    add_status_code(None, False)
    add_status_code(float(False) if False else False, False)
