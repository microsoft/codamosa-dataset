

# Generated at 2022-06-26 03:11:21.256644
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    load_file_exception = LoadFileException("Error!")


# Generated at 2022-06-26 03:11:22.668027
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("msg")

# Generated at 2022-06-26 03:11:27.253594
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid_usage_0 = InvalidUsage("Cannot handle {0} request")



# Generated at 2022-06-26 03:11:31.494800
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    urlbuilderror_0 = URLBuildError("ValueError", 405)
    assert urlbuilderror_0.status_code == 405
    assert urlbuilderror_0.args == ("ValueError",)
    assert str(urlbuilderror_0) == "ValueError"


# Generated at 2022-06-26 03:11:39.659270
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Test constructor of class URLBuildError
    # while the parameter is wrong.
    # The type of parameter is str, bool, int and float
    try:
        url_build_error_0 = None
        url_build_error_0 = URLBuildError(3)
    except TypeError as exception:
        assert isinstance(exception, TypeError), 'The type of exception is wrong'
    except AttributeError as exception:
        assert isinstance(exception, AttributeError), \
            'The type of exception is wrong'
    except Exception as exception:
        assert isinstance(exception, Exception), 'The type of exception is wrong'
    else:
        assert False, 'No exception was thrown.'
    # while the parameter is correct.

# Generated at 2022-06-26 03:11:52.633578
# Unit test for function add_status_code
def test_add_status_code():
    # Test when quiet=None and code=500
    exception_0 = add_status_code(500)
    exception_0(SanicException)
    # Test when quiet=False and code=500
    exception_1 = add_status_code(500, False)
    exception_1(SanicException)
    # Test when quiet=True and code=500
    exception_2 = add_status_code(500, True)
    exception_2(SanicException)
    # Test when quiet=None and code=404
    exception_3 = add_status_code(404)
    exception_3(SanicException)
    # Test when quiet=False and code=404
    exception_4 = add_status_code(404, False)
    exception_4(SanicException)
    # Test when quiet=True and code=404
   

# Generated at 2022-06-26 03:12:00.523201
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Calling with one argument
    tempHeaderExpectationFailed = HeaderExpectationFailed("TestFailed")
    assert(tempHeaderExpectationFailed.message == "TestFailed")

    # Calling with two arguments
    tempHeaderExpectationFailed = HeaderExpectationFailed("TestFailed", 400)
    assert(tempHeaderExpectationFailed.message == "TestFailed")


# Generated at 2022-06-26 03:12:02.974895
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found_0 = NotFound()
    not_found_1 = NotFound("asdf")
    not_found_2 = NotFound("asdf", 200)
    not_found_3 = NotFound("sdfs")
    not_found_3.status_code = 200


# Generated at 2022-06-26 03:12:05.729715
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    status_code_invalid_usage = 400
    string_invalid_usage = "Invalid Usage"
    error_invalid_usage_0 = InvalidUsage(string_invalid_usage, status_code_invalid_usage)
    error_invalid_usage_1 = InvalidUsage(string_invalid_usage)



# Generated at 2022-06-26 03:12:09.720729
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed_0 = HeaderExpectationFailed()
    assert header_expectation_failed_0._status_code == 417
    assert header_expectation_failed_0.status_code == 417

# Generated at 2022-06-26 03:12:15.788015
# Unit test for function add_status_code
def test_add_status_code():
    try:
        class Test(SanicException):
            @add_status_code(404)
            def __init__(self, message):
                super().__init__(message)
    except None:
        pass

# Generated at 2022-06-26 03:12:19.759620
# Unit test for function add_status_code
def test_add_status_code():
    code = [200, 404, 405, 500, 503]
    quiet = [True, False, None]
    for c in code:
        for q in quiet:
            assert add_status_code(c, q)


# Generated at 2022-06-26 03:12:24.208797
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized


# Generated at 2022-06-26 03:12:35.109962
# Unit test for function add_status_code
def test_add_status_code():
    def test_func():
        pass

    add_status_code(500)(test_func)

    assert test_func.__name__ == "test_func"
    assert test_func.status_code == 500

    add_status_code(500, quiet=False)(test_func)
    assert test_func.status_code == 500
    assert not test_func.quiet

    add_status_code(500, quiet=True)(test_func)
    assert test_func.status_code == 500
    assert test_func.quiet

    add_status_code(500)(test_func)
    assert test_func.status_code == 500
    assert test_func.quiet


# Generated at 2022-06-26 03:12:40.220411
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class SanicExceptionSub(SanicException):
        """
        **Status**: 400 Bad Request
        """
        pass

    assert '400' in _sanic_exceptions.keys()
    assert _sanic_exceptions[400] == SanicExceptionSub

if __name__ == "__main__":
    test_case_0()
    test_add_status_code()

# Generated at 2022-06-26 03:12:44.608525
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    status_code = 200
    quiet = True

    add_status_code(status_code, quiet)

    assert status_code in _sanic_exceptions


# Generated at 2022-06-26 03:12:54.628290
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400) == class_decorator
    assert add_status_code(404) == class_decorator
    assert add_status_code(405) == class_decorator
    assert add_status_code(408) == class_decorator
    assert add_status_code(413) == class_decorator
    assert add_status_code(416) == class_decorator
    assert add_status_code(417) == class_decorator
    assert add_status_code(500) == class_decorator
    assert add_status_code(503) == class_decorator
    assert add_status_code(400) == add_status_code(400)
    assert add_status_code(404) == add_status_code(404)
    assert add_status_

# Generated at 2022-06-26 03:13:04.786266
# Unit test for function add_status_code
def test_add_status_code():
    # Test with SanicException
    class test_class_0(SanicException):
        status_code = 400

    test_class_0 = add_status_code(400)(test_class_0)

    assert test_class_0.status_code == 400
    assert test_class_0.message == 'No message provided.'
    assert test_class_0.args == ('No message provided.',)
    assert test_class_0.kwargs == {}

    # Test with NotFound
    class test_class_1(NotFound):
        status_code = 404

    test_class_1 = add_status_code(404)(test_class_1)

    assert test_class_1.status_code == 404
    assert test_class_1.message == 'Not Found'

# Generated at 2022-06-26 03:13:12.841588
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    add_status_code(404, quiet=None)
    test_case_0()


if __name__ == '__main__':
    test_add_status_code()


# Generated at 2022-06-26 03:13:14.843892
# Unit test for function add_status_code
def test_add_status_code():
    # Case 0
    test_case_0()

# Generated at 2022-06-26 03:13:21.767776
# Unit test for function add_status_code
def test_add_status_code():
    not_found_404 = add_status_code(404)(NotFound("404 Not Found"))

    # Raise exception
    test_case_0()



# Generated at 2022-06-26 03:13:27.336975
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls

    add_status_code(
        code=200,
        quiet=None,
    )
    add_status_code(
        code=200,
        quiet=False,
    )
    add_status_code(
        code=200,
        quiet=True,
    )


# Generated at 2022-06-26 03:13:40.156750
# Unit test for function add_status_code
def test_add_status_code():
    # Make sure a SanicException-based exception can be created
    load_file_exception_1 = LoadFileException(message="load_file")

    # Make sure a SanicException-based exception can be created using the
    #   decorator
    @add_status_code(408)
    class RequestTimeout(SanicException):
        pass

    request_timeout_1 = RequestTimeout(message="request_time")

    # Make sure a non-SanicException-based exception cannot be created
    #   using the decorator
    try:
        @add_status_code(408)
        class LoadFileException(Exception):
            pass

        load_file_exception_2 = LoadFileException()
    except TypeError:
        pass


# Generated at 2022-06-26 03:13:47.365892
# Unit test for function add_status_code
def test_add_status_code():
    from sanic import response

    @add_status_code(400)
    class AsyncError(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

    try:
        raise AsyncError("this is a test message")
    except AsyncError as e:
        @add_status_code(400)
        class AsyncError1(SanicException):
            """
            **Status**: 400 Bad Request
            """

            pass

        try:
            raise AsyncError1("this is a test message")
        except AsyncError1 as e:
            assert e.status_code == 400



# Generated at 2022-06-26 03:13:57.772816
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(404, quiet)
        add_status_code(400, quiet)
        add_status_code(405, quiet)
        add_status_code(500, quiet)
        add_status_code(503, quiet)
        add_status_code(409, quiet)
        add_status_code(413, quiet)
        add_status_code(416, quiet)
        add_status_code(417, quiet)
        add_status_code(403, quiet)
        add_status_code(401, quiet)
        add_status_code(408, quiet)
    except Exception:
        pass



# Generated at 2022-06-26 03:13:58.668560
# Unit test for function add_status_code
def test_add_status_code():
    _ = add_status_code(0)


# Generated at 2022-06-26 03:14:08.522868
# Unit test for function add_status_code
def test_add_status_code():
    # Check 1 - 404
    try:
        raise NotFound('Not Found')
    except NotFound as error:
        result_1 = error.status_code
    assert result_1 == 404
    # Check 2 - 400
    try:
        raise InvalidUsage('Invalid Usage')
    except InvalidUsage as error:
        result_2 = error.status_code
    assert result_2 == 400
    # Check 3 - 500
    try:
        raise ServerError('Server Error')
    except ServerError as error:
        result_3 = error.status_code
    assert result_3 == 500
    # Check 4 - 501
    try:
        raise ServiceUnavailable('Service Unavailable')
    except ServiceUnavailable as error:
        result_4 = error.status_code
    assert result_4 == 503
    # Check 5 - 400
   

# Generated at 2022-06-26 03:14:10.271464
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound



# Generated at 2022-06-26 03:14:13.069726
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 200
    quiet_0 = None

    # Test the function
    add_status_code(status_code_0, quiet_0)



# Generated at 2022-06-26 03:14:14.183059
# Unit test for function add_status_code
def test_add_status_code():
    # This should raise LoadFileException
    test_case_0()

# Generated at 2022-06-26 03:14:19.484796
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code()
    except TypeError:
        pass


# Generated at 2022-06-26 03:14:21.357975
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) is not None


# Generated at 2022-06-26 03:14:22.393318
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()



# Generated at 2022-06-26 03:14:24.005225
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 200
    assert add_status_code(status_code)

# Generated at 2022-06-26 03:14:24.941838
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:14:35.572459
# Unit test for function add_status_code
def test_add_status_code():
    assert PayloadTooLarge.status_code == 413
    assert FileNotFound.status_code == 404
    assert RequestTimeout.status_code == 408
    assert ServerError.status_code == 500
    assert LoadFileException.status_code == 500
    assert ContentRangeError.status_code == 416
    assert HeaderExpectationFailed.status_code == 417
    assert Forbidden.status_code == 403
    assert InvalidRangeType.status_code == 416
    assert HeaderNotFound.status_code == 400
    assert InvalidUsage.status_code == 400
    assert NotFound.status_code == 404
    assert MethodNotSupported.status_code == 405
    assert ServiceUnavailable.status_code == 503
    assert PayloadTooLarge.status_code == 413
    assert URLBuildError.status_code == 500
    assert Unauthorized.status_code

# Generated at 2022-06-26 03:14:47.284888
# Unit test for function add_status_code
def test_add_status_code():
    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

    def function():
        pass

# Generated at 2022-06-26 03:14:48.917006
# Unit test for function add_status_code
def test_add_status_code():
    class_return = add_status_code(404)
    assert isinstance(class_return, type)


# Generated at 2022-06-26 03:14:58.582980
# Unit test for function add_status_code
def test_add_status_code():
    test_0 = None
    status_code_0 = test_0
    is_quiet_0 = test_0
    quiet_0 = is_quiet_0
    # the function named add_status_code is a decorator
    # instead of writing
    #     add_status_code(test_0, quiet_0)(test_0)
    # we write
    #     @add_status_code(test_0, quiet_0)
    #     def test_0():
    #         pass
    @add_status_code(status_code_0, quiet_0)
    def test_0():
        pass
    sanic_exception_0 = SanicException(test_0, status_code_0, quiet_0)
    test_1 = None
    message_0 = test_1
    status_code_

# Generated at 2022-06-26 03:15:10.796350
# Unit test for function add_status_code
def test_add_status_code():
    # Test that the SanicException is the one that's added to status codes
    SanicException(None, None, None)
    assert _sanic_exceptions[500] is not None
    assert _sanic_exceptions[500] is SanicException
    # Test that NotFound is added properly
    NotFound(None)
    assert _sanic_exceptions[404] is not None
    assert _sanic_exceptions[404] is NotFound
    # Test that the custom SanicException is assigned the correct code
    custom_sanic_exception = SanicException(None, None, None)
    custom_sanic_exception.status_code = 501
    assert _sanic_exceptions[501] is not None
    assert _sanic_exceptions[501] is custom_sanic_exception

# Generated at 2022-06-26 03:15:25.149033
# Unit test for function add_status_code
def test_add_status_code():
    # The function add_exception returned a function decorator that decorates a
    # function and converts it to a SanicException class that returns the
    # status code.
    @add_status_code(401, True)
    class Unauthorized(SanicException):
        """ Docstring """

        pass

    # 123 is not a valid status code.
    with pytest.raises(TypeError):
        @add_status_code(123)
        class TestClass(SanicException):
            """ Test docstring """

            pass



# Generated at 2022-06-26 03:15:37.605781
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404).func(NotFound) == _sanic_exceptions[404]
    assert add_status_code(400).func(InvalidUsage) == _sanic_exceptions[400]
    assert add_status_code(405).func(MethodNotSupported) == _sanic_exceptions[405]
    assert add_status_code(500).func(ServerError) == _sanic_exceptions[500]
    assert add_status_code(503).func(ServiceUnavailable) == _sanic_exceptions[503]
    assert add_status_code(408).func(RequestTimeout) == _sanic_exceptions[408]
    assert add_status_code(413).func(PayloadTooLarge) == _sanic_exceptions[413]

# Generated at 2022-06-26 03:15:38.619496
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:15:41.469363
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test whether add_status_code creates a class
    """
    assert type(add_status_code(200, True) is type)


# Generated at 2022-06-26 03:15:52.037435
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(404)
    add_status_code_1 = add_status_code(404)
    add_status_code_2 = add_status_code(404, quiet=None)
    add_status_code_3 = add_status_code(404, quiet=None)
    add_status_code_4 = add_status_code("handler", 501)
    add_status_code_5 = add_status_code("handler", 501)
    add_status_code_6 = add_status_code("handler", 501, quiet=None)
    add_status_code_7 = add_status_code("handler", 501, quiet=None)


# Generated at 2022-06-26 03:15:53.460130
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) != None


# Generated at 2022-06-26 03:15:54.544355
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:16:00.815680
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(400)
    assert add_status_code(405)
    assert add_status_code(500)
    assert add_status_code(503)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(415)
    assert add_status_code(416)
    assert add_status_code(417)
    assert add_status_code(403)
    assert add_status_code(401)

# Generated at 2022-06-26 03:16:11.777822
# Unit test for function add_status_code
def test_add_status_code():
    payload_too_large_0 = PayloadTooLarge("", "")
    load_file_exception_0 = LoadFileException(payload_too_large_0)
    assert "The request entity is larger than limits defined by server" == load_file_exception_0.message == "Payload Too Large"
    assert "400" == str(load_file_exception_0.status_code) == "413"
    assert load_file_exception_0.quiet == False
    assert str(load_file_exception_0) == "Payload Too Large"
    pyfileerror_0 = PyFileError(load_file_exception_0)
    assert "could not execute config file Payload Too Large" == pyfileerror_0.message

# Generated at 2022-06-26 03:16:16.665410
# Unit test for function add_status_code
def test_add_status_code():
    payload_too_large_0 = PayloadTooLarge("test_value_0", "test_value_1")
    load_file_exception_0 = LoadFileException(payload_too_large_0)
    test_value_0: Union[str, bytes] = payload_too_large_0.message
    print(test_value_0)


# Generated at 2022-06-26 03:16:33.276224
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(500, quiet=False)
    add_status_code_1 = add_status_code(500, quiet=True)


# Generated at 2022-06-26 03:16:35.971284
# Unit test for function add_status_code
def test_add_status_code():
    try:
        server_error_0 = ServerError(None)
    except Exception as e:
        assert True
    else:
        assert False

# Generated at 2022-06-26 03:16:45.115901
# Unit test for function add_status_code

# Generated at 2022-06-26 03:16:46.561864
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(ServiceUnavailable).status_code == 404

# Generated at 2022-06-26 03:16:52.502493
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = False
    add_status_code_1 = add_status_code(add_status_code_0)
    add_status_code_2 = SanicException("test_message", add_status_code_0)


# Generated at 2022-06-26 03:16:57.168829
# Unit test for function add_status_code
def test_add_status_code():
    # This test doesn't really reveal any information about the functioning of
    # `add_status_code`.
    # For example, we don't know if it successfully adds to the dictionary,
    # whether it adds SanicExceptions with the correct status codes.
    assert len(_sanic_exceptions) == 0
    assert InvalidUsage.status_code == 400
    assert NotFound.status_code == 404
    assert MethodNotSupported.status_code == 405
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503
    assert RequestTimeout.status_code == 408
    assert PayloadTooLarge.status_code == 413
    assert ContentRangeError.status_code == 416
    assert HeaderExpectationFailed.status_code == 417
    assert Forbidden.status_code == 403

# Generated at 2022-06-26 03:17:02.921148
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404, quiet=True)
    add_status_code(400)
    add_status_code(405)
    add_status_code(500)
    add_status_code(503)
    add_status_code(408)
    add_status_code(413)
    add_status_code(416)
    add_status_code(417)
    add_status_code(403)
    add_status_code(401)


# Generated at 2022-06-26 03:17:06.588898
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None)
    status_code = 500
    quiet = None
    result = add_status_code(status_code, quiet)

    # assert isinstance(result, add_status_code)
    assert callable(result)
    assert result(object) is None or \
        isinstance(result(object), object)


# Generated at 2022-06-26 03:17:11.786738
# Unit test for function add_status_code
def test_add_status_code():
    message_0 = None
    status_code_0 = None
    quiet_0 = None
    add_status_code(status_code_0, quiet_0)
    status_code_1 = None
    quiet_1 = None
    add_status_code(status_code_1, quiet_1)(SanicException(message_0))


# Generated at 2022-06-26 03:17:13.166122
# Unit test for function add_status_code
def test_add_status_code():
    def f(x, y):
        return x + y

    assert f(1, 2) == 3

# Generated at 2022-06-26 03:17:41.275768
# Unit test for function add_status_code
def test_add_status_code():
    invalid_usage_0 = InvalidUsage(None, 200)
    # Validate function module.add_status_code
    assert invalid_usage_0.status_code == 200

# Generated at 2022-06-26 03:17:46.052524
# Unit test for function add_status_code
def test_add_status_code():
    import types

    # Case: InvalidAddException
    def func(code):
        add_status_code(code)

    func(None)
    try:
        func(None, quiet=None)
    except AssertionError:
        pass


# Generated at 2022-06-26 03:17:49.871435
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(PayloadTooLarge) is PayloadTooLarge
    assert add_status_code(404, False)(PayloadTooLarge) is PayloadTooLarge
    assert add_status_code(404, True)(PayloadTooLarge) is PayloadTooLarge



# Generated at 2022-06-26 03:17:50.822627
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200)


# Generated at 2022-06-26 03:17:55.430137
# Unit test for function add_status_code
def test_add_status_code():
    # Case 0:
    #   For adding different types of exceptions to SanicException
    #   class. The status code of the exception should be added to the
    #   `_sanic_exceptions` and then raise the exception.
    test_case_0()
    return

# Nested Component


# Generated at 2022-06-26 03:17:58.171845
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(500)
    except Exception as e:
        raise e



# Generated at 2022-06-26 03:18:03.645135
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code_0 = add_status_code(500)
    except:
        pass
    else:
        assert False


# Unit tests for SanicException class

# Generated at 2022-06-26 03:18:06.984982
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_add_status_code_0(add_status_code)
        test_add_status_code_1(add_status_code)
    except Exception as e:
        assert False



# Generated at 2022-06-26 03:18:07.946312
# Unit test for function add_status_code
def test_add_status_code():
    # should throw an error
    add_status_code(0)

    # should pass silently
    add_status_code(404, True)


# Generated at 2022-06-26 03:18:09.633516
# Unit test for function add_status_code
def test_add_status_code():
    exceptions_0 = dict()
    add_status_code(201, True)(SanicException)

# Generated at 2022-06-26 03:19:09.508198
# Unit test for function add_status_code
def test_add_status_code():
    def test_add_status_code_0():
        assert code == expected_code
        assert cls.status_code == expected_code
        return None

    def test_add_status_code_1():
        assert code == expected_code
        assert cls.status_code == expected_code
        return None



# Generated at 2022-06-26 03:19:13.014485
# Unit test for function add_status_code
def test_add_status_code():
    print("test_add_status_code")
    load_file_exception_0 = LoadFileException(payload_too_large_0)



test_case_0()
test_add_status_code()

# Generated at 2022-06-26 03:19:23.310382
# Unit test for function add_status_code
def test_add_status_code():
    # Function add_status_code's return value is of type class_decorator.
    assert callable(add_status_code(400))
    # main/sanic/exceptions.py: SANIC_EXCEPTIONS={}
    assert len(_sanic_exceptions) == 0
    status_code = 400
    quiet = None
    assert add_status_code(status_code, quiet) == add_status_code(status_code, quiet)
    assert callable(add_status_code(status_code, quiet))
    # Update SANIC_EXCEPTIONS
    add_status_code(status_code, quiet)(SanicException)
    assert len(_sanic_exceptions) == 1
    assert status_code in _sanic_exceptions
    assert _sanic_exceptions[400] == SanicException

# Generated at 2022-06-26 03:19:24.046158
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code("200")("cls") == "200"


# Generated at 2022-06-26 03:19:31.340058
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0: int = 404
    quiet_0 = None
    payload_too_large_0 = None
    load_file_exception_0 = LoadFileException(payload_too_large_0)

    class_decorator_0 = add_status_code(status_code_0, quiet_0)
    cls_0 = class_decorator_0(load_file_exception_0)

    assert cls_0.status_code == status_code_0
    assert cls_0.quiet
    assert _sanic_exceptions[status_code_0] == load_file_exception_0



# Generated at 2022-06-26 03:19:35.429152
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[401] == Unauthorized
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[504] == ServiceUnavailable


# Generated at 2022-06-26 03:19:37.595948
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 400
        return cls

    assert add_status_code(400) == class_decorator



# Generated at 2022-06-26 03:19:47.468991
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(400, False)
    add_status_code_1 = add_status_code(200, False)
    add_status_code_2 = add_status_code(204, False)
    add_status_code_3 = add_status_code(208, False)
    add_status_code_4 = add_status_code(404, False)
    add_status_code_5 = add_status_code(404, True)
    add_status_code_6 = add_status_code(500, True)
    add_status_code_7 = add_status_code(500, False)
    add_status_code_8 = add_status_code(304, True)
    add_status_code_9 = add_status_code(304, False)

# Generated at 2022-06-26 03:19:49.174829
# Unit test for function add_status_code
def test_add_status_code():
    service_unavailable_0 = ServiceUnavailable(None)
    assert service_unavailable_0.status_code == 503


# Generated at 2022-06-26 03:19:51.477827
# Unit test for function add_status_code
def test_add_status_code():
    """
    test add_status_code function
    """
    assert _sanic_exceptions[404] == NotFound
