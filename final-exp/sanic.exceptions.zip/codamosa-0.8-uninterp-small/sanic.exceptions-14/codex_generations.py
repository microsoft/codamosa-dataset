

# Generated at 2022-06-26 03:11:32.656569
# Unit test for constructor of class SanicException
def test_SanicException():
    dict_0 = {True: True}
    dict_0[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_0 = dict_1
    dict_1 = {True: True}
    dict_1[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_0[True] = True
    dict_1 = {True: True}
    dict_1[True] = True
    dict_1 = {True: True}
   

# Generated at 2022-06-26 03:11:35.577110
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # check the type of LoadFileException("error message")
    file_error_0 = LoadFileException("error message")
    assert(isinstance(file_error_0, LoadFileException))



# Generated at 2022-06-26 03:11:38.831804
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Hey')
    except InvalidUsage as e:
        assert str(e) == 'Hey'
        assert e.status_code == 400
        assert e.headers == {}
        assert e.args == ('Hey',)


# Generated at 2022-06-26 03:11:43.867169
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():

    status_code = 408
    message = 'Request Timeout'
    request_timeout = RequestTimeout(message, status_code)

    # Verify that status_code is set as expected
    assert request_timeout.status_code == 408


# Generated at 2022-06-26 03:11:46.351930
# Unit test for constructor of class NotFound
def test_NotFound():
    notification_0 = NotFound()


# Generated at 2022-06-26 03:11:48.663776
# Unit test for constructor of class ServerError
def test_ServerError():
    ServerError_0 = ServerError
    server_error_0 = ServerError_0('error_0')


# Generated at 2022-06-26 03:11:51.342261
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    message = "Testing exception"
    config_error = URLBuildError(message)
    assert config_error.message == message



# Generated at 2022-06-26 03:12:04.213607
# Unit test for function add_status_code
def test_add_status_code():
    empty_0 = ""
    dict_0 = {None: empty_0}
    invalid_usage_0 = InvalidUsage(dict_0)
    string_0 = str(invalid_usage_0)
    dict_1 = {string_0: dict_0}
    not_found_0 = NotFound(dict_1)
    dict_2 = {string_0: invalid_usage_0}
    method_not_supported_0 = MethodNotSupported(dict_1, string_0, dict_2)
    dict_3 = {string_0: dict_1}
    server_error_0 = ServerError(dict_3)
    dict_4 = {string_0: dict_2}
    urlbuilderror_0 = URLBuildError(dict_3)
    dict_5 = {string_0: dict_3}


# Generated at 2022-06-26 03:12:11.275183
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    service_unavailable_0 = ServiceUnavailable()
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    service_unavailable_0 = ServiceUnavailable(dict_0)
    try:
        service_unavailable_0 = ServiceUnavailable()
    except MissingSchema:
        pass
    except ValueError:
        pass
    except Exception:
        pass

# Generated at 2022-06-26 03:12:22.549614
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed_0 = HeaderExpectationFailed()
    header_expectation_failed_1 = HeaderExpectationFailed("")
    header_expectation_failed_2 = HeaderExpectationFailed("", 500)
    assert_exception = "assert"
    assert_exception_0 = assert_exception(header_expectation_failed_0)
    assert_exception_0 = assert_exception(header_expectation_failed_1, "")
    assert_exception_0 = assert_exception(header_expectation_failed_2, "")
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    service_unavailable_0 = ServiceUnavailable(dict_0)

# Generated at 2022-06-26 03:12:29.982213
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        InvalidSignal(message="error message", status_code=500, quiet=None)
    except InvalidSignal as e:
        assert e.message == "error message"
        assert e.status_code == 500
        assert e.quiet == True


# Generated at 2022-06-26 03:12:31.649394
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_0 = Forbidden()
    forbidden_1 = Forbidden("a")


# Generated at 2022-06-26 03:12:40.632610
# Unit test for constructor of class SanicException
def test_SanicException():
    # Correct arguments
    SanicException("a", status_code=200, quiet=True)
    SanicException("a", status_code=200, quiet=False)
    SanicException("a", status_code=200, quiet=None)
    SanicException("a", status_code=500, quiet=None)
    SanicException("a", status_code=500, quiet=True)
    SanicException("a", status_code=500, quiet=False)
    SanicException("a", status_code=500)
    SanicException("a", status_code=None)
    SanicException("a")

    # Incorrect type of argument
    try:
        SanicException("a", status_code=300.5, quiet=True)
    except TypeError:
        pass

# Generated at 2022-06-26 03:12:44.504338
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class UxException(SanicException):
        pass

    ux_exception = UxException()



# Generated at 2022-06-26 03:12:47.862923
# Unit test for constructor of class ServerError
def test_ServerError():
    # test_case_1
    server_error_0 = ServerError()
    assert server_error_0.status_code == 500
    assert server_error_0.quiet == False


# Generated at 2022-06-26 03:12:50.296501
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError) as e:
        raise URLBuildError(message="Error in sending 404 Request", 
                            status_code=404)


# Generated at 2022-06-26 03:12:52.978161
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test_URLBuildError")
    except URLBuildError as e:
        assert e.args[0] == "test_URLBuildError"

# Generated at 2022-06-26 03:12:56.029159
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(321)
    class Custom_StatusCode_0(SanicException):  # noqa
        pass
    custom_status_0 = Custom_StatusCode_0()

# Generated at 2022-06-26 03:13:00.559763
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."
        assert e._headers["WWW-Authenticate"] == "Bearer"


# Generated at 2022-06-26 03:13:02.108796
# Unit test for constructor of class Forbidden
def test_Forbidden():
    obj = Forbidden()
    assert isinstance(obj, SanicException)
    assert obj.status_code == 403
    assert obj.quiet == True

# Generated at 2022-06-26 03:13:07.406906
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    auth_required = Unauthorized("Auth required.", scheme="Basic", realm="Realm")


# Generated at 2022-06-26 03:13:17.083202
# Unit test for function add_status_code
def test_add_status_code():
    # Test case with status code and quiet value false
    add_status_code(400, False)
    assert _sanic_exceptions[400].status_code == 400
    assert _sanic_exceptions[400].quiet == False

    # Test case with status code and quiet value true
    add_status_code(500, True)
    assert _sanic_exceptions[500].status_code == 500
    assert _sanic_exceptions[500].quiet == True

    # Test case with status code and no quiet value
    add_status_code(404)
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet == True

    # Test case with status code and no quiet value
    add_status_code(500)

# Generated at 2022-06-26 03:13:17.845024
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(111)


# Generated at 2022-06-26 03:13:20.337448
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth Required.",
                           scheme="Bearer",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth Required."
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": "Bearer realm=\"Restricted Area\""
        }


# Generated at 2022-06-26 03:13:22.507989
# Unit test for function add_status_code
def test_add_status_code():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 03:13:26.524580
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        class A:
            def __init__(self):
                raise Unauthorized("Auth required.",
                                   scheme="Basic",
                                   realm="Restricted Area")
        a = A()
    except Unauthorized as e:
        assert e.status_code == 401

# Generated at 2022-06-26 03:13:30.671761
# Unit test for function add_status_code
def test_add_status_code():
    test_var = 5
    @add_status_code(test_var)
    class SanicException_test(SanicException):
        pass
    assert SanicException_test.status_code == test_var
    assert SanicException_test.quiet == True
    assert _sanic_exceptions[test_var] == SanicException_test


# Generated at 2022-06-26 03:13:41.929506
# Unit test for function add_status_code
def test_add_status_code():
    cases2 = [
        (404, "Not Found"),
        (400, "Bad Request"),
        (405, "Method Not Allowed"),
        (500, "Internal Server Error"),
        (503, "Service Unavailable")
    ]

    cases3 = [
        (408, "Request Timeout"),
        (413, "Payload Too Large"),
        (416, "Not Satisfiable"),
        (417, "Expectation Failed"),
        (403, "Forbidden"),
        (401, "Unauthorized")
    ]

    for i in range(len(cases2)):
        if not isinstance(_sanic_exceptions[cases2[i][0]], SanicException):
            return False

# Generated at 2022-06-26 03:13:46.064784
# Unit test for function add_status_code
def test_add_status_code():
    a1 = add_status_code(404)
    print(a1)
    a2 = add_status_code(500, True)
    print(a2)

# Unit tests for all the SanicException classes

# Generated at 2022-06-26 03:13:55.079588
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    assert (Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
            == "Auth required.")
    assert (Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int",
                         algorithm="MD5", nonce="abcdef", opaque="zyxwvu")) == "Auth required."
    assert (Unauthorized("Auth required.", scheme="Bearer")) == "Auth required."
    assert (Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")) == "Auth required."



# Generated at 2022-06-26 03:14:07.137053
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    not_found_1 = NotFound()

    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    invalid_usage_1 = InvalidUsage()

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        pass

    method_not_supported_1 = MethodNotSupported(
        message="",
        method="POST",
        allowed_methods=["GET", "POST"]
    )

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    server_error_1 = ServerError()

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    service_

# Generated at 2022-06-26 03:14:10.230586
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=200)
    class NotFound200: pass

    assert NotFound200.status_code == 200



# Generated at 2022-06-26 03:14:17.632857
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions.get(400).status_code == 400
    assert _sanic_exceptions.get(405).status_code == 405
    assert _sanic_exceptions.get(500).status_code == 500
    assert _sanic_exceptions.get(503).status_code == 503
    assert _sanic_exceptions.get(408).status_code == 408
    assert _sanic_exceptions.get(413).status_code == 413
    assert _sanic_exceptions.get(416).status_code == 416
    assert _sanic_exceptions.get(417).status_code == 417
    assert _sanic_exceptions.get(403).status_code == 403

# Generated at 2022-06-26 03:14:21.402053
# Unit test for function add_status_code
def test_add_status_code():
    # Arrange
    @add_status_code(200)
    class Test:
        pass

    # Act
    t = Test()

    # Assert
    assert t.status_code == 200



# Generated at 2022-06-26 03:14:23.446760
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")


# Generated at 2022-06-26 03:14:29.553028
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    import os
    import random
    from urllib.parse import urlparse
    from datetime import datetime
    from itertools import cycle
    from string import ascii_lowercase
    from sys import argv
    def random_string(length):
        return "".join(random.choice(ascii_lowercase) for _ in range(length))

    def random_date():
        begin_date = datetime(1990, 1, 1)
        end_date = datetime(2030, 1, 1)
        time_between_dates = end_date - begin_date
        days_between_dates = time_between_dates.days
        random_number_of_days = random.randrange(days_between_dates)
        return begin_date + timedelta(days=random_number_of_days)


# Generated at 2022-06-26 03:14:34.796982
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert "404" in _sanic_exceptions.keys()
    assert _sanic_exceptions[404] == NotFound
    not_found_0 = NotFound()
    assert not_found_0.status_code == 404
    assert not_found_0.quiet is True

# Generated at 2022-06-26 03:14:36.833008
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class _500(SanicException):
        pass
    assert _500.status_code == 500
    assert _500.quiet == False

# Generated at 2022-06-26 03:14:39.375844
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    expected_str = "Authorization required."
    assert Unauthorized(expected_str).message == expected_str

client_abort = abort

# Generated at 2022-06-26 03:14:41.972523
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    test_Unauth = Unauthorized("Auth required.",
                               scheme="Basic",
                               realm="Restricted Area")
pass

# Generated at 2022-06-26 03:14:52.006306
# Unit test for function add_status_code
def test_add_status_code():
    invalid_usage_0 = InvalidUsage('Hey')
    return_value_0 = add_status_code(400)(InvalidUsage)
    assert return_value_0 == InvalidUsage
    return_value_1 = add_status_code(400, False)(InvalidUsage)
    assert return_value_1 == InvalidUsage
    return_value_2 = add_status_code(400, None)(InvalidUsage)
    assert return_value_2 == InvalidUsage
    return_value_3 = add_status_code(400, True)(InvalidUsage)
    assert return_value_3 == InvalidUsage
    return_value_4 = add_status_code(500)(InvalidUsage)
    assert return_value_4 == InvalidUsage
    return_value_5 = add_status_code(500, True)(InvalidUsage)
    assert return_value_5 == Invalid

# Generated at 2022-06-26 03:14:55.231744
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)
    assert(invalid_usage_0.status_code == 400)

# Generated at 2022-06-26 03:14:55.765629
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:14:56.699278
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:15:02.703863
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)
    add_status_code(421)

test_add_status_code()
if __name__ == '__main__':
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)

    # Unit test for function add_status_code
    add_status_code(404)
    add_status_code(421)

# Generated at 2022-06-26 03:15:08.559834
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)
    assert invalid_usage_0.status_code == 400
    assert invalid_usage_0.message == str_0

if __name__ == '__main__':
    # Unit test for function add_status_code
    test_add_status_code()

# Generated at 2022-06-26 03:15:10.296567
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)


# Generated at 2022-06-26 03:15:17.483966
# Unit test for function add_status_code
def test_add_status_code():
    # Check the status code of the class is given status code
    assert NotFound.status_code == 404
    # Check the message is given message
    assert InvalidUsage.__init__.__doc__ == 'Initialize self.  See help(type(self)) for accurate signature.'
    # Check the message is given message
    assert ServiceUnavailable.__init__.__doc__ == 'Initialize self.  See help(type(self)) for accurate signature.'

# Generated at 2022-06-26 03:15:18.317029
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:15:20.424463
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)
    add_status_code(404)


# Generated at 2022-06-26 03:15:26.701336
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 404
    not_found_0 = add_status_code(status_code_0)
    assert not_found_0.status_code == status_code_0


# Generated at 2022-06-26 03:15:28.996166
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 404
    quiet_0 = None
    add_status_code(status_code_0, quiet_0)


# Generated at 2022-06-26 03:15:33.818269
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'This is a test'
    invalid_usage_0 = InvalidUsage(str_0)
    assert(not hasattr(invalid_usage_0, 'status_code'))
    add_status_code(400)(InvalidUsage)
    assert(invalid_usage_0.status_code == 400)

# Generated at 2022-06-26 03:15:36.190111
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions.get(500).quiet == False


# Generated at 2022-06-26 03:15:42.032578
# Unit test for function add_status_code
def test_add_status_code():
    mocked_status_code = 500
    mocked_quiet = None

    mocked_cls = type('mocked_cls', (), {})

    mocked_cls.status_code = mocked_status_code
    mocked_cls.quiet = quiet = mocked_quiet or mocked_status_code != 500
    _sanic_exceptions[mocked_status_code] = mocked_cls



# Generated at 2022-06-26 03:15:46.138528
# Unit test for function add_status_code
def test_add_status_code():
    # Check if there are any exceptions raised
    try:
        add_status_code(700)
    except Exception as e:
        print("Exception raised: " + str(e))
        assert False


# Generated at 2022-06-26 03:15:48.948292
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)
    test_case_0()

# unit test for class SanicException

# Generated at 2022-06-26 03:15:49.978676
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)



# Generated at 2022-06-26 03:15:52.531906
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 500
    assert _sanic_exceptions[code_0].__name__ == 'ServerError'


# Generated at 2022-06-26 03:15:57.557450
# Unit test for function add_status_code
def test_add_status_code():
    def foo_func_0(code, quiet=None):
        def foo_func_0_0(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls

        return foo_func_0_0


# Generated at 2022-06-26 03:16:13.061268
# Unit test for function add_status_code
def test_add_status_code():
    # Invalid type
    try:
        add_status_code('404', None)
    except TypeError as e:
        pass
    # Invalid type
    try:
        add_status_code(404, 'None')
    except TypeError as e:
        pass
    # Invalid type
    try:
        add_status_code(None, None, None)
    except TypeError as e:
        pass
    # Invalid type
    try:
        add_status_code(None, None, None)
    except TypeError as e:
        pass


# Generated at 2022-06-26 03:16:17.275298
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(200, quiet=None)
    add_status_code(400, quiet=True)
    add_status_code(500, quiet=False)
    add_status_code(503, quiet=None)
    add_status_code(201, quiet=True)


# Generated at 2022-06-26 03:16:23.969673
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) == NotFound
    assert add_status_code(400) == InvalidUsage
    assert add_status_code(405) == MethodNotSupported
    assert add_status_code(500) == ServerError
    assert add_status_code(503) == ServiceUnavailable
    assert add_status_code(408) == RequestTimeout
    assert add_status_code(413) == PayloadTooLarge
    assert add_status_code(416) == ContentRangeError
    assert add_status_code(417) == HeaderExpectationFailed
    assert add_status_code(403) == Forbidden
    assert add_status_code(401) == Unauthorized


# Generated at 2022-06-26 03:16:25.016039
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(404)


# Generated at 2022-06-26 03:16:35.215041
# Unit test for function add_status_code
def test_add_status_code():
    # Create an instance of a class with attribute status_code equal to 404
    not_found_0 = NotFound('Hey')
    assert(not_found_0.status_code == 404)
    # Create an instance of a class with attribute quiet equal to True
    not_found_1 = NotFound('Hey')
    assert(not_found_1.quiet == True)
    # Create an instance of a class with attribute status_code equal to 500
    not_found_2 = NotFound('Hey')
    assert(not_found_2.status_code == 500)
    # Create an instance of a class with attribute quiet equal to False
    not_found_3 = NotFound('Hey')
    assert(not_found_3.quiet == False)


# Generated at 2022-06-26 03:16:38.167172
# Unit test for function add_status_code
def test_add_status_code():
    if __name__ == '__main__':
        add_status_code(400)
    test_case_0()


# Generated at 2022-06-26 03:16:41.197355
# Unit test for function add_status_code
def test_add_status_code():
    # TypeError
    try:
        add_status_code('status_code', 'quiet')
        assert False
    except:
        assert True

    assert isinstance(add_status_code(404, True), type)


# Generated at 2022-06-26 03:16:45.331082
# Unit test for function add_status_code
def test_add_status_code():

    expected_result_0 = ''
    invalid_usage_0 = InvalidUsage(expected_result_0, 400, False)

    expected_result_1 = ''
    not_found_0 = NotFound(expected_result_1, 404, True)

    expected_result_2 = ''
    server_error_0 = ServerError(expected_result_2, 500, False)


# Generated at 2022-06-26 03:16:55.738193
# Unit test for function add_status_code
def test_add_status_code():
    # Invalid status code
    try:
        add_status_code(400)(InvalidUsage)
        assert False
    except Exception as e:
        assert e.args[0] == 'Status code %s is already defined.'

    # valid status code
    add_status_code(410)(InvalidUsage)

    try:
        Unauthorized('unauthorized')
        assert False
    except Unauthorized as e:
        assert e.args[0] == 'unauthorized'

    try:
        abort(400, 'bad_request')
        assert False
    except InvalidUsage as e:
        assert e.args[0] == 'bad_request'

# Generated at 2022-06-26 03:16:56.682668
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:17:12.585015
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None)
    # is not a pure function
    # -- No return statement
    pass


# Generated at 2022-06-26 03:17:13.836115
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()
    test_add_status_code()

# Generated at 2022-06-26 03:17:17.005356
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'hey'
    invalid_usage_0 = InvalidUsage(str_0)
    # - Example from issue #45
    invalid_usage_0.__class__.__name__ == 'InvalidUsage'
    assert invalid_usage_0.status_code == 400


# Generated at 2022-06-26 03:17:28.367314
# Unit test for function add_status_code
def test_add_status_code():
    import re
    import io
    import sys
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        """
        **Status**: 503 Service Unavailable

        The server is currently unavailable (because it is overloaded or
        down for maintenance). Generally, this is a temporary state.
        """

       

# Generated at 2022-06-26 03:17:30.502957
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(400) == InvalidUsage
    assert _sanic_exceptions.get(404) == NotFound


# Generated at 2022-06-26 03:17:31.470531
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:17:41.458439
# Unit test for function add_status_code
def test_add_status_code():
    #int_0 = 1
    int_1 = 2
    exception_0 = NotFound()
    int_2 = 3
    invalid_usage_0 = InvalidUsage('Hey')
    method_not_supported_0 = MethodNotSupported(str_0, 'Hey', [])
    service_unavailable_0 = ServiceUnavailable(str_0)
    invalid_usage_1 = InvalidUsage(str_0)
    file_not_found_0 = FileNotFound(str_0, 'Hey', 'Hey')
    request_timeout_0 = RequestTimeout(str_0)
    payload_too_large_0 = PayloadTooLarge(str_0)
    header_not_found_0 = HeaderNotFound('Hey')
    content_range_error_0 = ContentRangeError(str_0, 'Hey')
    header_expect

# Generated at 2022-06-26 03:17:53.190794
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_0():
        str_0 = 'Hey'
        add_status_code_0 = add_status_code(str_0)
        sanic_exception_0 = SanicException(str_0, add_status_code_0)
        add_status_code_0 = add_status_code(sanic_exception_0)

    def test_case_1():
        str_0 = 'Hey'
        add_status_code_0 = add_status_code(str_0)
        add_status_code_1 = add_status_code(add_status_code_0)
        sanic_exception_0 = SanicException(add_status_code_1, str_0)

    def test_case_2():
        str_0 = 'Hey'
        add_status_

# Generated at 2022-06-26 03:17:56.203786
# Unit test for function add_status_code
def test_add_status_code():
    class_0 = InvalidUsage
    status_code_0 = 400
    add_status_code(status_code_0)(class_0)
    str_0 = 'Hey'
    invalid_usage_1 = InvalidUsage(str_0)


# Generated at 2022-06-26 03:18:09.842240
# Unit test for function add_status_code
def test_add_status_code():
    T0 = Callable[[Type['Exception']], Type['SanicException']]
    C0 = add_status_code(404, None)
    T1 = T0(NotFound)
    assert C0(NotFound) == T1
    T2 = NotFound
    assert NotFound.status_code == 404
    C1 = add_status_code(500, None)
    T3 = T0(ServerError)
    assert C1(ServerError) == T3
    T4 = ServerError
    assert ServerError.status_code == 500
    C2 = add_status_code(503, None)
    T5 = T0(ServiceUnavailable)
    assert C2(ServiceUnavailable) == T5
    T6 = ServiceUnavailable
    assert ServiceUnavailable.status_code == 503
    C3 = add_status

# Generated at 2022-06-26 03:18:44.651022
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except InvalidUsage as e:
        print(e.status_code)


if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:18:52.719696
# Unit test for function add_status_code
def test_add_status_code():
    # Test with different values for code, quiet and status_code,
    # expecting different exceptions
    # Test with quiet=True and status_code=404
    not_found_0 = NotFound('message')
    test_case = not_found_0
    message = test_case.message
    status_code = test_case.status_code
    assert(message == 'message')
    assert(status_code == 404)
    # Test with quiet=True and status_code=400
    invalid_usage_0 = InvalidUsage('message')
    test_case = invalid_usage_0
    message = test_case.message
    status_code = test_case.status_code
    assert(message == 'message')
    assert(status_code == 400)
    # Test with quiet=True and status_code=405
    method_not_

# Generated at 2022-06-26 03:19:04.238353
# Unit test for function add_status_code
def test_add_status_code():
    def test_case_1():
        test_case_1_dict_0 = {}
        test_case_1_kwargs_0 = {
            'message': 'Hey',
            'status_code': None,
            'quiet': None
        }
        test_case_1_kwargs_1 = {
            'message': 'Hey',
            'status_code': None,
            'quiet': None
        }
        test_case_1_kwargs_2 = {
            'message': 'Hey',
            'status_code': None,
            'quiet': None
        }
        str_0 = 'Hey'
        test_case_1_dict_0[{'code': 503, 'quiet': True}] = ServiceUnavailable(str_0)

# Generated at 2022-06-26 03:19:06.858636
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(int_0)
    not_found_0 = class_decorator_0(SanicException)


# Generated at 2022-06-26 03:19:17.764523
# Unit test for function add_status_code
def test_add_status_code():
    # Add status code 200 (OK) to SanicException
    add_status_code(200)
    # Check that SanicException has status code 200
    str_0 = 'OK'
    assert _sanic_exceptions[200].status_code == 200
    assert _sanic_exceptions[200].message == str_0
    # Check that SanicException has default is quiet to False
    assert _sanic_exceptions[200].quiet == False
    # Add status code 400 (Bad Request) to SanicException with quiet True
    add_status_code(400, quiet=True)
    # Check that SanicException has status code 400
    str_1 = 'Bad Request'
    assert _sanic_exceptions[400].status_code == 400
    assert _sanic_exceptions[400].message == str_1
    # Check

# Generated at 2022-06-26 03:19:18.828642
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:19:23.552339
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code
    test_code = 404
    test_quiet = None
    test_cls = SanicException
    real_result = add_status_code(test_code, test_quiet)
    expected_result = class_decorator(test_cls)
    assert real_result == expected_result


# Generated at 2022-06-26 03:19:26.903340
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 404
    quiet_0 = None
    not_found_0 = NotFound('Hello')
    # __init__(self: NotFound, message: str) -> None
    # __init__(self: SanicException, message: str, status_code: int = None, quiet: bool = None) -> None


# Generated at 2022-06-26 03:19:29.056538
# Unit test for function add_status_code
def test_add_status_code():
    temp_0 = add_status_code(500)
    temp_1 = temp_0(ServerError)
    temp_1()


# Generated at 2022-06-26 03:19:33.496340
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_gen = add_status_code(0)
    class_decorator = class_decorator_gen(SanicException)
    class_instance_0 = class_decorator()
    class_instance_0.quiet = True


# Generated at 2022-06-26 03:20:49.554429
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(101)(SanicException)

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-26 03:20:52.260977
# Unit test for function add_status_code
def test_add_status_code():
    # Test the return type of function add_status_code
    assert isinstance(add_status_code(404), classmethod),\
        'Function add_status_code did not return the correct type'


# Generated at 2022-06-26 03:20:54.548147
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 404
    quiet_0 = None
    class_decorator_0 = add_status_code(int_0, quiet_0)
    test_case_0()

# Generated at 2022-06-26 03:20:55.233615
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:20:58.234372
# Unit test for function add_status_code
def test_add_status_code():
    func_0 = lambda x, y, z : x + y + z
    not_found_0 = add_status_code(404, quiet=None)
    not_found_1 = not_found_0(func_0)


# Generated at 2022-06-26 03:21:02.351612
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'Hey'
    invalid_usage_0 = InvalidUsage(str_0)
    add_status_code(404)(invalid_usage_0)
    print(invalid_usage_0.status_code)
    assert invalid_usage_0.status_code == 404


# Generated at 2022-06-26 03:21:03.402904
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(1, True)

test_case_0()

# Generated at 2022-06-26 03:21:12.981607
# Unit test for function add_status_code
def test_add_status_code():
    obj = SanicException()
    add_status_code(200, quiet=False)(obj)
    assert obj.status_code == 200
    assert not obj.quiet
    obj = SanicException()
    add_status_code(200)(obj)
    assert obj.status_code == 200
    assert obj.quiet
    obj = SanicException()
    add_status_code(400, quiet=False)(obj)
    assert obj.status_code == 400
    assert not obj.quiet
    obj = SanicException()
    add_status_code(400)(obj)
    assert obj.status_code == 400
    assert not obj.quiet
    obj = SanicException()
    add_status_code(403, quiet=False)(obj)
    assert obj.status_code == 403
    assert not obj.quiet

# Generated at 2022-06-26 03:21:15.132626
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(404)
    str_0 = 'Hey'
    not_found_0 = class_decorator_0(NotFound(str_0))


# Generated at 2022-06-26 03:21:17.202561
# Unit test for function add_status_code
def test_add_status_code():
    print('')
    print('Function add_status_code:')
    print('  Run it with a debugger to see results')
    print('  of running this test case.')
    print('')
