

# Generated at 2022-06-26 03:11:25.836114
# Unit test for function add_status_code
def test_add_status_code():
    cls_0 = NotFound
    add_status_code(cls_0)


# Generated at 2022-06-26 03:11:28.029993
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise Exception
    except Exception as e:
        add_status_code(403)




# Generated at 2022-06-26 03:11:30.550219
# Unit test for function add_status_code
def test_add_status_code():
    import pytest
    add_status_code_0 = add_status_code(500)
    test_case_0()



# Generated at 2022-06-26 03:11:39.659316
# Unit test for function add_status_code
def test_add_status_code():
    message_0 = 'exception message'
    status_code_0 = dict()
    not_found_0 = NotFound(message_0, status_code=status_code_0)

    message_1 = 'Exception message'
    status_code_1 = dict()
    server_error_0 = ServerError(message_1, status_code=status_code_1)

    message_2 = 'Exception message'
    status_code_2 = dict()
    server_error_1 = ServerError(message_2, status_code=status_code_2)

    message_3 = 'Exception message'
    status_code_3 = dict()
    server_error_2 = ServerError(message_3, status_code=status_code_3)

    message_4 = 'Exception message'
    status_code_4 = dict

# Generated at 2022-06-26 03:11:43.720924
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator():
        raise NotImplementedError

    arr_0 = [class_decorator]
    add_status_code(arr_0)


# Generated at 2022-06-26 03:11:49.970987
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_0 = {}
    dict_1 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2 = {}
    pyfile_error_0 = PyFileError(dict_0)
    ServerError_0 = ServerError("RUJh0", dict_1)
    not_found_0 = NotFound("aWYkGFS6", dict_2)
    not_found_1 = NotFound("aWYkGFS6", dict_2)
    not_found_1.status_code = 404
    not_found_1.quiet = True
    assert not_found_1 is not None



# Generated at 2022-06-26 03:11:58.686728
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    header_not_found_0 = HeaderNotFound(dict_0, 200)
    header_not_found_0.status_code = 200
    header_not_found_0.status_code = 201


# Generated at 2022-06-26 03:11:59.632913
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:12:04.036412
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    add_status_code(123, sanic_exception_0)
    add_status_code(0, sanic_exception_0)
    add_status_code(123, sanic_exception_0)
    add_status_code(0, sanic_exception_0)


# Generated at 2022-06-26 03:12:05.895330
# Unit test for function add_status_code
def test_add_status_code():
    assert True



# Generated at 2022-06-26 03:12:12.493409
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException_0(Exception):
        status_code = 200
        quiet = True
    add_status_code(SanicException_0.status_code, SanicException_0.quiet)(SanicException_0)


# Generated at 2022-06-26 03:12:23.000478
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    header_not_found_0 = HeaderNotFound(dict_0)
    add_status_code(header_not_found_0)


if __name__ == "__main__":
    import sys, json
    import os.path as path
    root = path.dirname(path.dirname(path.dirname(path.abspath(__file__))))
    sys.path.insert(0, root)
    from other_generators.sanic.sanic import _sanic_exceptions

    with open(path.join(root, 'other_generators/sanic/locals.json'), 'r') as fp:
        data = json.load(fp)

# Generated at 2022-06-26 03:12:25.760807
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(500)
    exception_0 = class_decorator_0(Exception)
    server_error_0 = ServerError('', 500)
    exception_0._sanic_exceptions(500)

# Generated at 2022-06-26 03:12:37.015929
# Unit test for function add_status_code
def test_add_status_code():
    from sys import version_info
    from types import FunctionType
    from types import LambdaType

    def add_status_code_0(code, quiet=None):

        # Call the decorated function 'add_status_code'.
        @add_status_code(code, quiet)
        def class_decorator():
            pass

        return class_decorator

    def test_add_status_code_0():
        class_decorator_0 = None
        class_decorator_0 = add_status_code_0(300)
        assert class_decorator_0.status_code == 300
        assert class_decorator_0.quiet is False

    def test_add_status_code_1():
        class_decorator_1 = None
        class_decorator_1 = add_status_code

# Generated at 2022-06-26 03:12:41.517510
# Unit test for function add_status_code
def test_add_status_code():
    # assert True
    # actual = add_status_code(404)
    # expected = {404: 'NotFound'}
    # assert actual == expected
    pass



# Generated at 2022-06-26 03:12:44.150296
# Unit test for function add_status_code
def test_add_status_code():
    result: int = add_status_code(status_code=200)
    assert result == 200


# Generated at 2022-06-26 03:12:45.982409
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-26 03:12:55.299750
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}

    not_found_0 = HeaderNotFound(dict_0)
    not_found_1 = HeaderNotFound(dict_1)
    not_found_2 = HeaderNotFound(dict_2)
    not_found_3 = HeaderNotFound(dict_3)

    dict_0['status_code'] = 404
    dict_1['quiet'] = False
    dict_2['quiet'] = True
    dict_3['quiet'] = False

    if (not isinstance(not_found_0, SanicException)):
        print('[ERROR] Test case #0 failed')

    if (hasattr(not_found_1, 'quiet')):
        if (not_found_1.quiet != False):
            print

# Generated at 2022-06-26 03:12:56.309264
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code


# Generated at 2022-06-26 03:13:05.605950
# Unit test for function add_status_code
def test_add_status_code():
    # Called a function which return an object
    test_status_code_0 = add_status_code(1)
    assert test_status_code_0 is None

    # Called a function which return an object
    test_status_code_1 = add_status_code(1)
    assert test_status_code_1 is not None

    # Called a function which return an object
    test_status_code_2 = add_status_code(1)
    assert test_status_code_2 is None

    # Called a function which return an object
    test_status_code_3 = add_status_code(1)
    assert test_status_code_3 is not None

    # Called a function which return an object
    test_status_code_4 = add_status_code(1)
    assert test_status_code_4

# Generated at 2022-06-26 03:13:10.926982
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage()



# Generated at 2022-06-26 03:13:19.143199
# Unit test for function add_status_code
def test_add_status_code():
    assert Unauthorized(status_code=401, message="Unauthorized") == Unauthorized(
        status_code=401, message="Unauthorized"
    )
    assert PayloadTooLarge(status_code=413, message="Payload Too Large") == PayloadTooLarge(
        status_code=413, message="Payload Too Large"
    )
    assert Forbidden(status_code=403, message="Forbidden") == Forbidden(
        status_code=403, message="Forbidden"
    )
    assert ServerError(status_code=500, message="Internal Server Error") == ServerError(
        status_code=500, message="Internal Server Error"
    )

# Generated at 2022-06-26 03:13:29.853705
# Unit test for function add_status_code
def test_add_status_code():
    code_0, add_status_code_0 = 0, add_status_code(0)
    code_1, add_status_code_1 = 1, add_status_code(1)
    code_2, add_status_code_2 = 2, add_status_code(2)
    code_3, add_status_code_3 = 3, add_status_code(3, quiet=True)
    code_4, add_status_code_4 = 4, add_status_code(4, quiet=True)
    code_5, add_status_code_5 = 5, add_status_code(5, quiet=True)
    code_6, add_status_code_6 = 6, add_status_code(6, quiet=True)
    code_7, add_status_code_7 = 7,

# Generated at 2022-06-26 03:13:32.620381
# Unit test for function add_status_code
def test_add_status_code():
    value = 1
    rv = add_status_code(value)
    assert type(rv) is type(lambda x: x)


# Generated at 2022-06-26 03:13:38.083986
# Unit test for function add_status_code
def test_add_status_code():
    http_status_code = 400
    message = "This is Test Case for add_status_code"
    test_case_0 = NotFound(message, http_status_code)


if __name__ == "__main__":
    # Testing for function add_status_code
    test_add_status_code()
    test_case_0()

# Generated at 2022-06-26 03:13:40.156493
# Unit test for function add_status_code
def test_add_status_code():
    # Test for args/kwargs, ignore return value
    add_status_code(400, False)



# Generated at 2022-06-26 03:13:42.438674
# Unit test for function add_status_code
def test_add_status_code():
    """
    >>> test_case_0()
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 03:13:48.397555
# Unit test for function add_status_code
def test_add_status_code():
    # class decorator
    code = 404
    @add_status_code(code)
    class cls:
        status_code = code
    # test "status_code"
    assert cls.status_code == code
    # test "quiet"
    assert not hasattr(cls, "quiet")

    code = 404
    @add_status_code(code, True)
    class cls:
        status_code = code
    # test "status_code"
    assert cls.status_code == code
    # test "quiet"
    assert hasattr(cls, "quiet")
    assert cls.quiet is True

    code = 500
    @add_status_code(code)
    class cls:
        status_code = code
    # test "status_code"
    assert cls.status_

# Generated at 2022-06-26 03:13:50.277573
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()


# Generated at 2022-06-26 03:13:52.414251
# Unit test for function add_status_code
def test_add_status_code():
    test_class_0 = add_status_code(int_0, bool_0)


# Generated at 2022-06-26 03:14:05.402533
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 404
        if 404 != 500:
            cls.quiet = True
        _sanic_exceptions[404] = cls
        return cls
    test_case_0()
    test_case_1(404)
    test_case_1(add_status_code(404))
    test_case_1(add_status_code(404, quiet=None))


# Generated at 2022-06-26 03:14:06.758896
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator():
        pass


# Generated at 2022-06-26 03:14:08.296511
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code is not None


# Generated at 2022-06-26 03:14:12.016725
# Unit test for function add_status_code
def test_add_status_code():
    file_not_found_0 = FileNotFound(100.0, 100.0, 100.0)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:14:13.004194
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:14:20.245312
# Unit test for function add_status_code
def test_add_status_code():
    # exception cases
    assert _sanic_exceptions == {
        404: NotFound,
        400: InvalidUsage,
        405: MethodNotSupported,
        500: ServerError,
        503: ServiceUnavailable,
        400: InvalidUsage,
        408: RequestTimeout,
        413: PayloadTooLarge,
        416: ContentRangeError,
        417: HeaderExpectationFailed,
        403: Forbidden,
        401: Unauthorized,
    }


# Generated at 2022-06-26 03:14:24.553335
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 0
    quiet_0 = True
    class_decorator_0 = add_status_code(status_code_0, quiet_0)
    class_0 = object()
    class_decorator_0(class_0)


# Generated at 2022-06-26 03:14:28.281134
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test function add_status_code
    """
    arglist = [1, 2]
    arglist[0] = 100
    arglist[1] = 200

    # local variable result
    result = add_status_code(arglist[0], arglist[1])

    # local variable expected
    expected = 100

    assert result == expected


# Generated at 2022-06-26 03:14:30.619155
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(ServerError):
        add_status_code(500)(FileNotFound)


# Generated at 2022-06-26 03:14:38.537289
# Unit test for function add_status_code
def test_add_status_code():
    httpd_0 = add_status_code('httpd', False)

    class httpd_1(SanicException):
        status_code = 'httpd'
        headers = {}
        pass
        #  type: SanicException
        #  type: str
        #  type: dict
        #  type: str
        #  attr: 'httpd'
        #  attr: {}

    dict_0 = {}
    dict_0['httpd'] = httpd_1
    dict_0[404] = NotFound
    add_status_code('httpd', False)

    class httpd_1(SanicException):
        status_code = 'httpd'
        headers = {}
        pass
        #  type: SanicException
        #  type: str
        #  type: dict
        #  type

# Generated at 2022-06-26 03:14:55.882568
# Unit test for function add_status_code

# Generated at 2022-06-26 03:14:59.834234
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(100)
    class_decorator_1 = add_status_code(100, False)
    class_decorator_2 = add_status_code(100, True)
    class_decorator_3 = add_status_code(500)
    class_decorator_4 = add_status_code(500, True)



# Generated at 2022-06-26 03:15:01.339813
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(0)


# Generated at 2022-06-26 03:15:03.974496
# Unit test for function add_status_code
def test_add_status_code():
    code = 0
    test_case_0(code)	


# Generated at 2022-06-26 03:15:06.861565
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator_0(arg_0):
        pass

    add_status_code(0, class_decorator_0)


# Generated at 2022-06-26 03:15:18.608335
# Unit test for function add_status_code
def test_add_status_code():
    # Zero-argument test case
    class_decorator_0 = add_status_code()
    def cls_0():
        pass
    add_status_code_0 = class_decorator_0(cls_0)
    add_status_code_0.status_code = 408

    # Zero-argument test case
    class_decorator_1 = add_status_code()
    def cls_1():
        pass
    add_status_code_1 = class_decorator_1(cls_1)
    add_status_code_1.status_code = 411

    # Verifies that the `add_status_code` function doesn't raise any exceptions
    # when it's arguments are valid.
    try:
        add_status_code(500)
    except Exception:
        _coverage

# Generated at 2022-06-26 03:15:28.149773
# Unit test for function add_status_code
def test_add_status_code():
    dict_0 = {}
    sanic_exception_0 = SanicException(dict_0)
    status_code_0 = -1
    add_status_code(status_code_0)
    not_found_0 = NotFound(dict_0)
    server_error_0 = ServerError(dict_0)
    invalid_usage_0 = InvalidUsage(dict_0)
    method_not_supported_0 = MethodNotSupported(dict_0, not_found_0, invalid_usage_0)
    service_unavailable_0 = ServiceUnavailable(dict_0)
    url_build_error_0 = URLBuildError(dict_0)
    request_timeout_0 = RequestTimeout(dict_0)
    payload_too_large_0 = PayloadTooLarge(dict_0)
    forbidden_0 = Forbidden

# Generated at 2022-06-26 03:15:34.322414
# Unit test for function add_status_code
def test_add_status_code():
    # Test with a valid status code
    assert add_status_code(200) == list.__dict__["append"]

    # Test with an invalid status code
    with pytest.raises(TypeError):
        add_status_code(200.0)

    # Test with a quiet status code
    assert add_status_code(500) == list.__dict__["append"]



# Generated at 2022-06-26 03:15:41.850719
# Unit test for function add_status_code
def test_add_status_code():
    code_int = 42
    code_str = str(code_int)
    add_status_code_0 = add_status_code(code_int)

    class class_0:
        pass

    class_0 = add_status_code_0(class_0)
    assert class_0.status_code == code_int

    dict_0 = {}
    invalid_usage_0 = InvalidUsage(dict_0, code_str, True)
    assert invalid_usage_0.status_code == code_int


# Generated at 2022-06-26 03:15:45.143205
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 500
    message = ""
    quiet = None
    server_error_0 = ServerError(message, status_code, quiet)
    pass



# Generated at 2022-06-26 03:16:21.978769
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 503
    message = "Not Found"
    headers = {"Allow": ", ".join(["GET", "HEAD", "POST", "PUT", "DELETE", "PATCH"])}
    expected = dict(status_code=503, message=message, headers=headers)
    result = {'status':503, 'reason':'Not Found', 'headers':{"Allow": ", ".join(["GET", "HEAD", "POST", "PUT", "DELETE", "PATCH"])}}
    assert expected == result #Failing Case


# Generated at 2022-06-26 03:16:30.883322
# Unit test for function add_status_code
def test_add_status_code():
    import pytest

    @add_status_code(400)
    class MyHTTPError(SanicException):
        pass

    my_http_error = MyHTTPError("Bad Request")

    assert my_http_error.status_code == 400

    try:
        @add_status_code(401)
        class HTTPUnauthorized(SanicException):
            status_code = 400

        pytest.fail()
    except ValueError:
        pass

    @add_status_code(400)
    class MyHTTPErrorWithoutStatusCode(SanicException):
        pass

    my_http_error_0 = MyHTTPErrorWithoutStatusCode("Bad Request")

    assert my_http_error_0.status_code == 400


# Generated at 2022-06-26 03:16:36.796614
# Unit test for function add_status_code
def test_add_status_code():
    header_not_found_0 = HeaderNotFound()
    add_status_code_0 = add_status_code(header_not_found_0)
    invalid_usage_0 = InvalidUsage()
    # AssertionError: Expected status code 400, but got 404
    assert add_status_code_0 is invalid_usage_0
    test_case_0()


# Generated at 2022-06-26 03:16:37.851307
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(1, 2)
    except Exception as e:
        print(e)
    else:
        print("Error")

# Generated at 2022-06-26 03:16:45.836762
# Unit test for function add_status_code
def test_add_status_code():
    i = 10
    dict_0 = {}
    class_decorator_0 = add_status_code(i, dict_0)

# Generated at 2022-06-26 03:16:46.908673
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()

# Generated at 2022-06-26 03:16:57.074108
# Unit test for function add_status_code
def test_add_status_code():
    class SanicError0(SanicException):
        def __init__(self):
            super().__init__()

    # Test no error
    try:
        add_status_code(SanicError0)
    except:
        assert False

    # Test no error
    try:
        add_status_code(1000, SanicError0)
    except:
        assert False

    # Test no error
    try:
        add_status_code(1000)
    except:
        assert False

    # Test no error
    try:
        add_status_code()
    except:
        assert False


# Generated at 2022-06-26 03:17:03.302591
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator_0 = add_status_code(0)
    class_decorator_1 = add_status_code(1)
    class_decorator_2 = add_status_code(2)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}

# Generated at 2022-06-26 03:17:13.325998
# Unit test for function add_status_code
def test_add_status_code():
    # Test for code 701
    code = 701
    quiet = None
    class_decorator_0 = add_status_code(code, quiet)
    class_0 = class_decorator_0(SanicException)
    assert type(class_0) == SanicException
    assert class_0.status_code == code
    assert class_0.quiet == True
    assert _sanic_exceptions[code] == class_0

    # Test for an invalid status code
    code = 701
    quiet = None
    try:
        class_decorator_1 = add_status_code(code, quiet)
        class_1 = class_decorator_1(SanicException)
    except KeyError:
        return True
    assert False


# Generated at 2022-06-26 03:17:14.972853
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    add_status_code_0 = add_status_code(1)
    _sanic_exceptions[1] = add_status_code_0

# Generated at 2022-06-26 03:18:28.706771
# Unit test for function add_status_code
def test_add_status_code():
    def func_0(code, quiet=None):
        def class_decorator_0(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls

        return class_decorator_0
    func_0(404)


# Generated at 2022-06-26 03:18:30.729269
# Unit test for function add_status_code
def test_add_status_code():
    func_1 = add_status_code(0)
    class_0 = func_1(SanicException)
    assert class_0.status_code == 0
    assert class_0.quiet == False
    assert _sanic_exceptions[0] == class_0
    

# Generated at 2022-06-26 03:18:32.410109
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(None)
    add_status_code(None, None)
    add_status_code(None, False)
    add_status_code(None, True)


# Generated at 2022-06-26 03:18:43.649258
# Unit test for function add_status_code
def test_add_status_code():
    class ClassNotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    class_not_found_1 = add_status_code(404)
    class_not_found_2 = class_not_found_1(ClassNotFound)

    dict_1 = {}
    request_time_out_0 = RequestTimeout(dict_1)
    dict_2 = {}
    header_not_found_1 = HeaderNotFound(dict_2)
    dict_3 = {}
    header_not_found_2 = HeaderNotFound(dict_3)
    dict_4 = {}
    header_not_found_3 = HeaderNotFound(dict_4)

    dict_5 = {}
    header_not_found_4 = HeaderNotFound(dict_5)
    dict_6 = {}

# Generated at 2022-06-26 03:18:45.310441
# Unit test for function add_status_code
def test_add_status_code():
    pass
    # Test a few values

    # Test all values

    # Test Random values



# Generated at 2022-06-26 03:18:46.224455
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-26 03:18:47.154449
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(1)


# Generated at 2022-06-26 03:18:52.719628
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls

    def class_decorator_1(cls):
        return cls

    test_add_status_code_0 = add_status_code(300, False)
    list_1 = [test_add_status_code_0(None), test_add_status_code(100, True)]

    class_decorator(test_add_status_code_0(None))
    class_decorator_1(test_add_status_code(200, None))


# Generated at 2022-06-26 03:18:56.554200
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 200
    def function_0():
        add_status_code(status_code_0)
    function_0()


# Generated at 2022-06-26 03:18:57.793955
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404, None) == NotFound
