

# Generated at 2022-06-26 03:11:32.777436
# Unit test for function add_status_code
def test_add_status_code():
    print("Test test_add_status_code")
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    u_r_l_build_error_0 = URLBuildError(bytes_0)
    print(u_r_l_build_error_0.__class__.__name__)
    print(str(u_r_l_build_error_0))
    print(u_r_l_build_error_0.status_code)
    return



# Generated at 2022-06-26 03:11:34.619703
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(503) 
    assert add_status_code(status_code=503)

# Generated at 2022-06-26 03:11:42.321120
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = 'a9\xf9\x17\x02\x94\x8d\x84\x87\xb0\xad\x9f\xaa\x9e\x94\xca\xe8\x8d\x0e\xf3\x85\xc2\x90'
    bytes_0 = b'6\xf7f\xaa\x17\x0b\x9d\xcc\xf4\x86\xce0\x8d\x95\xce\xcf\x9f\x9d\xc4\xcb\xce\xcb\xcf'
    # Verify that we can catch an exception of class URLBuildError

# Generated at 2022-06-26 03:11:44.258103
# Unit test for function add_status_code
def test_add_status_code():
    from io import BytesIO
    from io import StringIO



# Generated at 2022-06-26 03:11:50.719459
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions == {404: NotFound, 400: InvalidUsage,
                                 500: ServerError, 503: ServiceUnavailable,
                                 405: MethodNotSupported, 408: RequestTimeout,
                                 413: PayloadTooLarge, 416: ContentRangeError,
                                 417: HeaderExpectationFailed, 403: Forbidden}

# Generated at 2022-06-26 03:12:00.825730
# Unit test for function add_status_code
def test_add_status_code():
    url_build_error_0 = URLBuildError(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-26 03:12:01.759485
# Unit test for function add_status_code
def test_add_status_code():
    dummy_var_0 = None
    add_status_code_0 = add_status_code(dummy_var_0)


# Generated at 2022-06-26 03:12:03.131024
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(500, None)
        assert False
    except SanicException:
        pass


# Generated at 2022-06-26 03:12:08.233076
# Unit test for function add_status_code
def test_add_status_code():
    bytes_0 = b'z\x90{\xc9\x9b\xea\xcd\x0c\x1a\xd4\xdf\x99\x8f\x9f'
    # unit test for add_status_code
    assert pytest.raises(KeyError, abort, 404, "")
    assert pytest.raises(KeyError, abort, 403, bytes_0)
    assert pytest.raises(KeyError, abort, 413, "")
    assert pytest.raises(KeyError, abort, 400, "")
    assert pytest.raises(KeyError, abort, 500, bytes_0)
    assert pytest.raises(KeyError, abort, 503, bytes_0)
    assert pytest.raises(KeyError, abort, 408, bytes_0)
    # unit

# Generated at 2022-06-26 03:12:19.400141
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized


# Generated at 2022-06-26 03:12:26.850696
# Unit test for function add_status_code
def test_add_status_code():
    # Tests that the correct exception is raised
    server_error_0 = ServerError('test')
    test_status_code = 200
    with pytest.raises(SanicException) as e_info_0:
        server_error_0.status_code = test_status_code
    # Tests that the correct status code is attached to the exception
    with pytest.raises(ServerError) as e_info_1:
        add_status_code(status_code=500)(SanicException)


# Generated at 2022-06-26 03:12:29.866192
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-26 03:12:35.237188
# Unit test for function add_status_code
def test_add_status_code():
    str_0 = '@add_status_code(404)'
    int_0 = 48

    @add_status_code(int_0)
    class Class_0:
        def __init__(self, str_0):
            self.u_r_l_build_error_0 = str_0

    assert str_0 == str(Class_0.__qualname__)



# Generated at 2022-06-26 03:12:42.836657
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 404
    quiet_0 = None
    class_decorator_0 = add_status_code(status_code_0, quiet_0)
    not_found_0 = NotFound(None)
    not_found_1 = NotFound(Exception())
    not_found_2 = NotFound(bytes())
    not_found_3 = NotFound('I<')
    not_found_4 = NotFound('\n')
    class_decorator_1 = add_status_code(status_code_0, quiet_0)
    invalid_usage_0 = InvalidUsage(None)
    invalid_usage_1 = InvalidUsage(Exception())
    invalid_usage_2 = InvalidUsage(bytes())
    invalid_usage_3 = InvalidUsage('\x9d')
    invalid_usage_4 = InvalidUsage

# Generated at 2022-06-26 03:12:53.551078
# Unit test for function add_status_code
def test_add_status_code():
    # Test raising NotFound exception with add_status_code
    try:
        raise NotFound('404')
    except NotFound as e:
        pass
    # Test raising ServerError exception with add_status_code
    try:
        raise ServerError('500')
    except ServerError as e:
        pass
    # Test raising MethodNotSupported with add_status_code
    message = "MethodNotSupported"
    try:
        raise MethodNotSupported(message, 'POST', 'GET')
    except MethodNotSupported as e:
        pass
    # Test raising Unauthorized with add_status_code
    try:
        raise Unauthorized('401')
    except Unauthorized as e:
        pass
    # Test raising ServiceUnavailable with add_status_code

# Generated at 2022-06-26 03:12:58.105013
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 500
    url_build_error_0 = URLBuildError(None)
    add_status_code(status_code_0)(URLBuildError)
    assert _sanic_exceptions[status_code_0] == URLBuildError
    assert url_build_error_0.status_code == status_code_0
    assert url_build_error_0.quiet == True


# Generated at 2022-06-26 03:13:03.020561
# Unit test for function add_status_code
def test_add_status_code():
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    u_n_a_u_t_h_o_r_i_z_e_d_0 = Unauthorized(bytes_0, "Basic", "Restricted Area")


# Generated at 2022-06-26 03:13:15.056452
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 0
    class_decorator_0 = add_status_code(status_code_0)
    status_code_1 = 200
    class_decorator_1 = add_status_code(status_code_1)
    status_code_2 = 400
    class_decorator_2 = add_status_code(status_code_2)
    status_code_3 = 700
    quiet_0 = None
    class_decorator_3 = add_status_code(status_code_3, quiet_0)
    status_code_4 = 500
    quiet_1 = True
    class_decorator_4 = add_status_code(status_code_4, quiet_1)

    class SanicException_0(Exception):
        pass

    status_code_5 = 500

# Generated at 2022-06-26 03:13:26.525065
# Unit test for function add_status_code
def test_add_status_code():
    t_param_0 = 1
    name_0 = "invalid-usage"
    sanic_exception_0 = SanicException(name_0)
    sanic_exception_0.status_code = t_param_0
    t_param_0 = 0
    sanic_exception_0.quiet = t_param_0
    t_param_0 = 1
    assert sanic_exception_0.status_code is t_param_0
    t_param_0 = 0
    assert sanic_exception_0.quiet is t_param_0


# Generated at 2022-06-26 03:13:27.876446
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(123)


# Generated at 2022-06-26 03:13:33.138896
# Unit test for function add_status_code
def test_add_status_code():
    test_case_0()



# Generated at 2022-06-26 03:13:34.889780
# Unit test for function add_status_code
def test_add_status_code():
    # Add your own test values here!
    pass


# Generated at 2022-06-26 03:13:37.560976
# Unit test for function add_status_code
def test_add_status_code():
    # Assume that for function add_status_code, the argument does not matter
    add_status_code(0)


# Generated at 2022-06-26 03:13:42.738802
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = b'\x00'
    func_0 = add_status_code(code_0)
    code_1 = b'\x00'
    func_1 = add_status_code(code_1, quiet=False)
    code_2 = b'\x00'
    func_2 = add_status_code(code_2, quiet=False)


# Generated at 2022-06-26 03:13:47.119417
# Unit test for function add_status_code
def test_add_status_code():
    # def function_1(cls_0) -> bool:
    #     pass
    #     return bool()
    class_0 = NotFound()
    value_1 = add_status_code(404, class_0)
    value_2 = add_status_code(404, class_0)
    value_3 = add_status_code(404, class_0)
    value_4 = add_status_code(500)
    assert value_1 == value_2 == value_3
    assert value_4 == value_1



# Generated at 2022-06-26 03:13:50.577202
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 6
    quiet = True
    unit_test_0 = add_status_code(status_code, quiet)


# Generated at 2022-06-26 03:14:01.508423
# Unit test for function add_status_code
def test_add_status_code():
    import pytest
    bytes_0 = b'N\xce\xe3w\x8e\xda\x81\x12\x84\x9d\xff\x1f=\xbeT\x8a\xee\xdf\xfa'

# Generated at 2022-06-26 03:14:05.567461
# Unit test for function add_status_code
def test_add_status_code():
    # No exception raised

    # No exception raised
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    u_r_l_build_error_0 = URLBuildError(bytes_0)


# Generated at 2022-06-26 03:14:06.908458
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(SanicException) == NotFound


# Generated at 2022-06-26 03:14:12.671803
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code_0 = add_status_code(status_code=513)
    add_status_code_1 = add_status_code(status_code=516)
    add_status_code_2 = add_status_code(status_code=520)
    add_status_code_3 = add_status_code(status_code=524)



# Generated at 2022-06-26 03:14:23.448446
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(None, None) == add_status_code(None, None)


# Generated at 2022-06-26 03:14:24.389645
# Unit test for function add_status_code
def test_add_status_code():
    pass



# Generated at 2022-06-26 03:14:35.095582
# Unit test for function add_status_code

# Generated at 2022-06-26 03:14:44.717586
# Unit test for function add_status_code
def test_add_status_code():
    # Create a dictionary for testing
    _sanic_exceptions_0 = {}
    # Call the decorated function
    service_unavailable_0 = add_status_code(503)(ServiceUnavailable)
    # Check if the function returns a value
    if (service_unavailable_0 is not None):
        _sanic_exceptions_0[503] = service_unavailable_0
    # Test function calls
    if (service_unavailable_0.status_code == 503):
        if (service_unavailable_0.quiet is True):
            if (_sanic_exceptions_0[503] == service_unavailable_0):
                pass


# Generated at 2022-06-26 03:14:48.300530
# Unit test for function add_status_code
def test_add_status_code():
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    urllib_parse_1_0 = URLBuildError(bytes_0)


# Generated at 2022-06-26 03:14:58.224674
# Unit test for function add_status_code
def test_add_status_code():
    # Try add_status_code(code, quiet=None) with valid values
    a1 = add_status_code(404)
    # Try add_status_code(code, quiet=None) with valid values
    a2 = add_status_code(400)
    # Try add_status_code(code, quiet=None) with valid values
    a3 = add_status_code(405)
    # Try add_status_code(code, quiet=None) with valid values
    a4 = add_status_code(500)
    # Try add_status_code(code, quiet=None) with valid values
    a5 = add_status_code(503)
    # Try add_status_code(code, quiet=None) with valid values
    a6 = add_status_code(408)
    # Try add_status_

# Generated at 2022-06-26 03:15:05.084750
# Unit test for function add_status_code
def test_add_status_code():
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    u_r_l_build_error_0 = URLBuildError(bytes_0)
    u_r_l_build_error_0.quiet = True
    assert u_r_l_build_error_0.status_code == 500


# Generated at 2022-06-26 03:15:16.833392
# Unit test for function add_status_code
def test_add_status_code():
    assert callable(add_status_code(404))
    # assert callable(add_status_code(400))
    assert callable(add_status_code(405))
    assert callable(add_status_code(500))
    assert callable(add_status_code(503))
    assert callable(add_status_code(408))
    assert callable(add_status_code(413))
    assert callable(add_status_code(416))
    assert callable(add_status_code(417))
    assert callable(add_status_code(403))
    assert callable(add_status_code(401))
    assert callable(add_status_code(503, quiet=True))


# Generated at 2022-06-26 03:15:25.420564
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 200
    code_1 = 500
    code_2 = 500
    quiet_0 = True
    result_0 = add_status_code(code_0, quiet=quiet_0)
    assert result_0 == _sanic_exceptions.get(code_0)
    result_1 = add_status_code(code_1)
    assert result_1 == _sanic_exceptions.get(code_1)
    result_2 = add_status_code(code_2, quiet=quiet_0)
    assert result_2 == _sanic_exceptions.get(code_2)


# Generated at 2022-06-26 03:15:31.079297
# Unit test for function add_status_code
def test_add_status_code():
    u_r_l_build_error_0 = URLBuildError('')
    status_code_0 = 404
    sanic_exception_0 = add_status_code(status_code_0)(SanicException(u_r_l_build_error_0))


# Generated at 2022-06-26 03:15:49.830692
# Unit test for function add_status_code
def test_add_status_code():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 03:15:53.588577
# Unit test for function add_status_code
def test_add_status_code():
    file_not_found_type = type(FileNotFound(message=bytes_0))
    file_not_found_status_code = 404
    assert file_not_found_type.status_code == file_not_found_status_code



# Generated at 2022-06-26 03:15:57.516612
# Unit test for function add_status_code
def test_add_status_code():
    u_r_l_build_error_0 = URLBuildError()
    try:
        raise u_r_l_build_error_0
    except Exception as e:
        assert True
        pytest.fail(e, pytrace=False)


# Generated at 2022-06-26 03:16:04.121299
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise LoadFileException(b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR')
    except LoadFileException as load_file_exception_0:
        pass
    else:
        raise Exception('Failed to raise exception LoadFileException')
    abort(404)
    try:
        raise ServerError(b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR')
    except ServerError as server_error_0:
        pass
    else:
        raise Exception('Failed to raise exception ServerError')

# Generated at 2022-06-26 03:16:14.585349
# Unit test for function add_status_code
def test_add_status_code():
    string_0 = 'l\x13\xdbU\x87a\x7f\xb6\x05\xce\xcdf\xf7\xba\xc4\x8e\x99\xa7J'
    message_0 = '2\xf3\x15\x98\xab\xa8\x9f\x05\xbc\xa1K\xd8\xa0\xed\x9c\x12H}'

    # Call function add_status_code with argument status_code=500
    # and argument message=message_0
    # to get __return_value_0
    __return_value_0 = add_status_code(500, message_0)

    # Assign function add_status_code to class_decorator_0

# Generated at 2022-06-26 03:16:15.995264
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(False) is None


# Generated at 2022-06-26 03:16:21.483283
# Unit test for function add_status_code
def test_add_status_code():
    bytes_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    u_r_l_build_error_0 = URLBuildError(bytes_0)
    # TypeError: 'str' object is not callable
    # add_status_code(bytes_0)(u_r_l_build_error_0)


# Generated at 2022-06-26 03:16:22.618670
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500)



# Generated at 2022-06-26 03:16:24.175437
# Unit test for function add_status_code
def test_add_status_code():
    # Unit tests for add_status_code.
    assert False # TODO: implement your test here


# Generated at 2022-06-26 03:16:35.164265
# Unit test for function add_status_code
def test_add_status_code():
    # Create an object of the class SanicException to initialize the
    # class Variable _sanic_exceptions
    s_a_n_i_c_exception_0 = SanicException('',  0)
    sanic_exception_0 = SanicException('',  0)
    sanic_exception_0.status_code = 0
    # Create an object of the class NotFound
    not_found_0 = NotFound('',  0)
    not_found_0.status_code = 0
    # Create an object of the class ServerError
    server_error_0 = ServerError('',  0)
    server_error_0.status_code = 0
    # Create an object of the class ServiceUnavailable
    service_unavailable_0 = ServiceUnavailable('',  0)

# Generated at 2022-06-26 03:17:13.168355
# Unit test for function add_status_code
def test_add_status_code():
    int_0 = 1
    int_1 = 200
    class_decorator_0 = add_status_code(int_1)
    class_0 = class_decorator_0(type)
    # No check on the assignment


# Generated at 2022-06-26 03:17:21.055540
# Unit test for function add_status_code
def test_add_status_code():
    # given
    expected_0 = b'a\xe8`\x03P^\x9d\xc2\xfd\xaa{\x0f\xf3\xbf\xdeeR'
    expected_1 = True
    expected_2 = (None)
    expected_3 = (None)
    expected_4 = (None)
    expected_5 = (None)
    expected_6 = (None)
    expected_7 = (None)

    # when
    actual_0 = RequestTimeout.message
    actual_1 = RequestTimeout.quiet
    actual_2 = RequestTimeout.__dict__.get('status_code')
    actual_3 = ContentRangeError.message
    actual_4 = ContentRangeError.quiet
    actual_5 = ContentRangeError.__dict__.get('status_code')
    actual_

# Generated at 2022-06-26 03:17:24.543937
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 1000
    class_decorator_0 = add_status_code(code_0)
    _sanic_exceptions.__setitem__(code_0, SanicException)


# Generated at 2022-06-26 03:17:26.915045
# Unit test for function add_status_code
def test_add_status_code():
    code_0 = 503
    quiet_0 = None
    add_status_code(code_0, quiet_0)


# Generated at 2022-06-26 03:17:35.251104
# Unit test for function add_status_code
def test_add_status_code():
    from unittest.mock import Mock
    class_decorator_0 = add_status_code(1024)
    for _ in range(10):
        class_0 = Mock()
        class_decorator_0(class_0)
        if (class_0.status_code is not 1024):
            raise Exception('AssertionError')
        if (class_0.quiet is not None):
            raise Exception('AssertionError')
        if (1024 not in _sanic_exceptions):
            raise Exception('AssertionError')


# Generated at 2022-06-26 03:17:37.035668
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    ok = None
    add_status_code(code, ok)


# Generated at 2022-06-26 03:17:49.432368
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(402)
    class MyException1(SanicException):
        pass

    @add_status_code(502, quiet=False)
    class MyException2(SanicException):
        pass

    @add_status_code(401)
    class MyException3(SanicException):
        pass

    assert MyException1.status_code == 402
    assert MyException1.quiet

    assert MyException2.status_code == 502
    assert not MyException2.quiet

    assert MyException3.status_code == 401
    assert MyException3.quiet

# Generated at 2022-06-26 03:17:52.173090
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = add_status_code(405, False)
    assert status_code_0.__closure__[0].cell_contents == 405


# Generated at 2022-06-26 03:17:56.372847
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 206
    status_code_0 = 405
    quiet = False
    client_error_0 = add_status_code(status_code, quiet)(SanicException)
    quiet_0 = True
    client_error_1 = add_status_code(status_code_0, quiet_0)(SanicException)


# Generated at 2022-06-26 03:18:09.590391
# Unit test for function add_status_code
def test_add_status_code():
    try:
        test_case_0()
    except AssertionError:
        global_name_table['stypy_debug_wrapper'] = globals()
        global_name_table['stypy_debug_wrapper_verbose'] = globals()
        global_name_table['stypy_return_type_dict'] = None
        global_name_table['stypy_return_type_list'] = None
        global_name_table['stypy_function_dict'] = None
        global_name_table['stypy_function_list'] = None
        global_name_table['stypy_param_function_dict'] = None

        return
    # Exception must not be raised
    raise TypeError("The function does not correctly raises the expected exception")

# Generated at 2022-06-26 03:19:23.784255
# Unit test for function add_status_code
def test_add_status_code():
    val = add_status_code(400)
    status_code_0 = val(NotFound)


# Generated at 2022-06-26 03:19:25.573581
# Unit test for function add_status_code
def test_add_status_code():
    # Testing for TypeError:
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-26 03:19:36.193953
# Unit test for function add_status_code
def test_add_status_code():
    server_error_0 = ServerError(b'\x1b\x8a\x85\xad\xcd\x1d\xe2\x15\xe6\xc9')
    server_error_1 = ServerError(b'\x1b\x8a\x85\xad\xcd\x1d\xe2\x15\xe6\xc9')
    assert (server_error_0 == server_error_1)
    inv_usg_0 = InvalidUsage(b'', 612)
    inv_usg_1 = InvalidUsage(b'', 612)
    assert (inv_usg_0 == inv_usg_1)

# Generated at 2022-06-26 03:19:41.104197
# Unit test for function add_status_code
def test_add_status_code():
    # Parameterize the testing object
    new_class = type('TestClass', (SanicException,), {})
    # Test with true boolean
    add_status_code(200, True)(new_class)
    # Test with false boolean
    add_status_code(400, False)(new_class)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:19:44.194069
# Unit test for function add_status_code
def test_add_status_code():
    status_code = add_status_code(404)
    # Exception that was raised
    try:
        status_code(SanicException)
    except Exception as e:
        pass

# Generated at 2022-06-26 03:19:51.239857
# Unit test for function add_status_code
def test_add_status_code():
    status_code_0 = 200
    quiet_0 = False
    result_0 = add_status_code(status_code_0, quiet_0)
    print("result_0:", result_0)
    result_1 = add_status_code(status_code_0)
    print("result_1:", result_1)

if __name__ == "__main__":
    test_add_status_code()
    print("Expect: <function add_status_code.<locals>.class_decorator at 0x7f9e4b4f3ea0>")
    print("Expect: <function add_status_code.<locals>.class_decorator at 0x7f9e4b4f3ea0>")

# Generated at 2022-06-26 03:19:52.925455
# Unit test for function add_status_code
def test_add_status_code():
    # TODO: Implement the unit test for function add_status_code
    pass


# Generated at 2022-06-26 03:19:56.081737
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(ServerError):
        test_case_0()

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-26 03:19:59.133611
# Unit test for function add_status_code
def test_add_status_code():
    # Test the case where status_code is equal to 500 which returns the
    # class: 'ServerError'
    def f():
        if 500 == 500:
            return True
        else:
            return False
    assert f()

# Generated at 2022-06-26 03:20:03.293441
# Unit test for function add_status_code
def test_add_status_code():
    # Tests for handling invalid inputs
    try:
        add_status_code('')
    except TypeError:
        pass
    # Tests for normal behaviour
    function_0 = add_status_code(404)
    function_0(test_case_0)
