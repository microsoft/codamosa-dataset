

# Generated at 2022-06-12 08:44:35.868901
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402)
    class TestException(SanicException):
        pass
    assert 400 in _sanic_exceptions
    assert 402 in _sanic_exceptions
    assert _sanic_exceptions[402] == TestException
    assert _sanic_exceptions[400] == InvalidUsage

# Generated at 2022-06-12 08:44:39.882225
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions

    @add_status_code(555)
    class MyException(SanicException):
        pass

    assert 555 in _sanic_exceptions
    assert _sanic_exceptions[555] is MyException



# Generated at 2022-06-12 08:44:48.930500
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class Class(SanicException):
        pass
    assert Class.status_code == 404
    assert Class(message='test').status_code == 404
    assert not Class(message='test').quiet
    assert _sanic_exceptions.get(404) == Class
    assert _sanic_exceptions.get(404)(message='test').status_code == 404

    @add_status_code(403)
    class Class(SanicException):
        pass
    assert Class.status_code == 403
    assert Class(message='test').status_code == 403
    assert Class(message='test').quiet
    assert _sanic_exceptions.get(403) == Class
    assert _sanic_exceptions.get(403)(message='test').status_code == 403


# Generated at 2022-06-12 08:45:01.946294
# Unit test for function add_status_code
def test_add_status_code():
    class AException(SanicException):
        pass

    a_exception = add_status_code(404)(AException)
    # Check if add_status_code  add status code correctly
    assert a_exception.status_code == 404
    # Check if add_status_code add quiet correctly
    assert a_exception.quiet == True

    class BException(SanicException):
        pass

    b_exception = add_status_code(500)(BException)
    # Check if add_status_code  add status code correctly
    assert b_exception.status_code == 500
    # Check if add_status_code add quiet correctly
    assert b_exception.quiet == False

    class CException(SanicException):
        pass


# Generated at 2022-06-12 08:45:08.060396
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        """
        **Status**: 501 Not Implemented
        """

        pass

    assert len(_sanic_exceptions) == 11
    assert _sanic_exceptions[501] == NotImplemented
    assert NotImplemented.status_code == 501

# Generated at 2022-06-12 08:45:10.839601
# Unit test for function add_status_code
def test_add_status_code():
    """
    Decorator used for adding exceptions to :class:`SanicException`.
    """
    code = 0
    assert code == 0

# Generated at 2022-06-12 08:45:17.864829
# Unit test for function add_status_code

# Generated at 2022-06-12 08:45:21.161192
# Unit test for function add_status_code
def test_add_status_code():
    class UninitException(Exception):
        pass

    add_status_code(500)(UninitException)
    assert _sanic_exceptions[500] == UninitException

# Generated at 2022-06-12 08:45:24.301016
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert str(_sanic_exceptions[404]) == "<class 'sanic.exceptions.NotFound'>"

# Generated at 2022-06-12 08:45:28.720836
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound2(Exception):
        pass

    @add_status_code(400)
    class Error400(Exception):
        pass

    assert NotFound == NotFound2
    assert InvalidUsage == Error400
    assert 400 in _sanic_exceptions

# Generated at 2022-06-12 08:45:34.710715
# Unit test for function add_status_code
def test_add_status_code():
    # Test a status code
    code = 400
    quiet = False
    @add_status_code(code)
    class test(SanicException):
        pass
    assert _sanic_exceptions == {code: test}
    assert test.status_code == code
    assert test.quiet is True


# Generated at 2022-06-12 08:45:36.708964
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100100)
    class TestException(Exception):
        pass
    assert TestException.status_code == 100100

# Generated at 2022-06-12 08:45:41.864971
# Unit test for function add_status_code
def test_add_status_code():
    class Error400(SanicException):
        pass

    class Error503_quiet(SanicException):
        pass

    @add_status_code(400)
    class Error400_decorated(SanicException):
        pass

    @add_status_code(503, quiet=True)
    class Error503_quiet_decorated(SanicException):
        pass

    assert issubclass(Error400, SanicException)
    assert issubclass(Error400_decorated, SanicException)
    assert issubclass(Error503_quiet_decorated, SanicException)

    assert Error400.status_code == 400
    assert Error400_decorated.status_code == 400
    assert Error503_quiet_decorated.status_code == 503

    assert Error400_decorated.quiet == False
   

# Generated at 2022-06-12 08:45:47.806474
# Unit test for function add_status_code
def test_add_status_code():
    # Test add_status_code() by creating a dummy exception class and registering
    # it with the add_status_code() decorator.
    @add_status_code(555)
    class MyTestException(SanicException):
        pass

    # Make sure the exception class is stored correctly.
    assert _sanic_exceptions[555] == MyTestException  # type: ignore

    # Make sure the exception class gets the right status code.
    exc = MyTestException("")
    assert exc.status_code == 555


# Generated at 2022-06-12 08:45:58.493126
# Unit test for function add_status_code
def test_add_status_code():
    class test_sanic_exception_1(SanicException):
        pass

    class test_sanic_exception_2(SanicException):
        pass

    class test_sanic_exception_3(SanicException):
        pass

    add_status_code(123)(test_sanic_exception_1)
    add_status_code(456, quiet=True)(test_sanic_exception_2)
    add_status_code(789, quiet=False)(test_sanic_exception_3)

    assert _sanic_exceptions[123] == test_sanic_exception_1
    assert _sanic_exceptions[456].quiet == True
    assert _sanic_exceptions[789].quiet == False

# Generated at 2022-06-12 08:46:08.950046
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class _100(SanicException): pass
    @add_status_code(200)
    class _200(SanicException): pass
    assert STATUS_CODES.get(100) is not None
    assert STATUS_CODES.get(200) is not None
    assert _sanic_exceptions.get(100) is not None
    assert _sanic_exceptions.get(200) is not None
    assert _sanic_exceptions.get(400) is not None
    assert _sanic_exceptions.get(404) is not None
    assert _sanic_exceptions.get(405) is not None
    assert _sanic_exceptions.get(500) is not None
    assert _sanic_exceptions.get(503) is not None

# Generated at 2022-06-12 08:46:12.369552
# Unit test for function add_status_code
def test_add_status_code():
    # Test for add_status_code and update excpetion
    @add_status_code(400)
    class Test(SanicException):
        pass

    assert Test.status_code == 400

    # Test for add_status_code and update excpetion
    @add_status_code(404)
    class Test(SanicException):
        pass

    assert Test.status_code == 404

# Generated at 2022-06-12 08:46:15.429186
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class OK200(SanicException):
        """
        **Status**: 200 OK
        """

        pass

    assert OK200.status_code == 200
    assert _sanic_exceptions[200] == OK200



# Generated at 2022-06-12 08:46:25.855420
# Unit test for function add_status_code
def test_add_status_code():
    class Exc(SanicException):
        ...

    assert _sanic_exceptions == {}

    def class_decorator(cls):
        # keep ref of cls
        cls_ = cls
        cls.status_code = 404
        _sanic_exceptions[404] = cls
        return cls

    assert add_status_code(404, False)(Exc) is Exc
    assert add_status_code(404, True)(Exc) is Exc
    assert add_status_code(404, None)(Exc) is Exc

    assert _sanic_exceptions == {404: Exc}
    exc = _sanic_exceptions[404]
    assert exc.__name__ == "Exc"
    assert exc.status_code == 404


# Generated at 2022-06-12 08:46:33.392291
# Unit test for function add_status_code
def test_add_status_code():
    class E1(SanicException):
        pass
        
    class E2(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable

    add_status_code(404)(E1)
    add_status_code(500)(E2)

    assert _sanic_exceptions[404] == E1
    assert _sanic_exceptions[500] == E2

# Generated at 2022-06-12 08:46:43.673570
# Unit test for function add_status_code
def test_add_status_code():
    class Testing(SanicException):
        pass
    assert Testing.status_code == 0
    assert Testing.quiet == False
    assert Testing not in _sanic_exceptions.values()
    add_status_code(200)(Testing)
    assert Testing.status_code == 200
    assert Testing.quiet == True
    assert Testing in _sanic_exceptions.values()

# Generated at 2022-06-12 08:46:54.248507
# Unit test for function add_status_code
def test_add_status_code():
    class SomeException(SanicException):
        pass
    assert issubclass(SomeException, SanicException)
    assert SomeException.status_code is None
    assert SomeException.quiet is None
    assert SomeException() is not None

    @add_status_code(300)
    class SomeExceptionWithCode(SanicException):
        pass

    assert issubclass(SomeExceptionWithCode, SanicException)
    assert SomeExceptionWithCode.status_code == 300
    assert SomeExceptionWithCode.quiet == True
    assert SomeExceptionWithCode() is not None

    @add_status_code(400, quiet=True)
    class SomeExceptionWithCodeQuiet(SanicException):
        pass

    assert issubclass(SomeExceptionWithCodeQuiet, SanicException)
    assert SomeExceptionWithCodeQuiet.status_code == 400
   

# Generated at 2022-06-12 08:46:55.106123
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200) is not None


# Generated at 2022-06-12 08:47:04.299357
# Unit test for function add_status_code
def test_add_status_code():
    """
    Properly setup our add_status_code decorator
    """
    # Adding custom status codes that exist in STATUS_CODES
    @add_status_code(200)
    class CustomSanicException(SanicException):
        pass
    assert CustomSanicException.status_code == 200
    assert not CustomSanicException.quiet

    # Add a custom status code that doesn't exist in STATUS_CODES
    @add_status_code(999)
    class CustomSanicException999(SanicException):
        pass
    assert CustomSanicException999.status_code == 999
    assert CustomSanicException999.quiet

    # Add a custom status code that doesn't exist in STATUS_CODES with quiet=True

# Generated at 2022-06-12 08:47:16.000760
# Unit test for function add_status_code
def test_add_status_code():
    status_code_1 = 400
    @add_status_code(status_code_1)
    class TestSanicException1(SanicException):
        pass

    status_code_2 = 401
    @add_status_code(status_code_2)
    class TestSanicException2(SanicException):
        pass

    status_code_3 = 402
    @add_status_code(status_code_3, quiet=True)
    class TestSanicException3(SanicException):
        pass

    global _sanic_exceptions
    assert len(_sanic_exceptions) == 3
    assert _sanic_exceptions.get(status_code_1) == TestSanicException1
    assert _sanic_exceptions.get(status_code_2) == TestSanicException2
    assert _sanic

# Generated at 2022-06-12 08:47:23.935146
# Unit test for function add_status_code
def test_add_status_code():
    # test if add_status_code can add an exception to SanicException
    @add_status_code(123)
    class TestException(SanicException):
        pass

    assert_equal(_sanic_exceptions[123], TestException)

    # test if add_status_code can add different type exception to SanicException
    # Note: NotFound is already added to SanicException at the same time
    # SanicException is defined so there is no need to check that case
    @add_status_code(200)
    class TestException1(Exception):
        pass

    # Note: This is the expected exception
    with assert_raises(AssertionError):
        # This is the actual exception
        assert_is_instance(TestException1(), SanicException)



# Generated at 2022-06-12 08:47:29.477982
# Unit test for function add_status_code
def test_add_status_code():
    class BasicError(SanicException):
        pass
    assert _sanic_exceptions.get(400) == None
    assert _sanic_exceptions.get(500) == None
    add_status_code(400)(BasicError)
    add_status_code(500)(BasicError)
    assert _sanic_exceptions.get(400) == BasicError
    assert _sanic_exceptions.get(500) == BasicError

# Generated at 2022-06-12 08:47:37.276938
# Unit test for function add_status_code
def test_add_status_code():
    # test add status code both into and not into sanic.exceptions
    not_in_exceptions_code = 2000
    in_exceptions_code = 405

    @add_status_code(not_in_exceptions_code)
    class NotFound(SanicException):
        pass

    @add_status_code(in_exceptions_code, quiet=True)
    class MethodNotSupported(SanicException):
        pass

    assert _sanic_exceptions[not_in_exceptions_code] == NotFound
    assert _sanic_exceptions[in_exceptions_code] == MethodNotSupported

test_add_status_code()

# Generated at 2022-06-12 08:47:43.236730
# Unit test for function add_status_code
def test_add_status_code():
    class First(SanicException):
        '''
        First status code will be 404
        '''
    @add_status_code(401)
    class Second(SanicException):
        '''
        Second status code will be 401
        '''
    assert _sanic_exceptions[404].__name__ == 'First'
    assert _sanic_exceptions[401].__name__ == 'Second'

# Generated at 2022-06-12 08:47:52.976681
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class ServerError(SanicException):
        pass

    a = ServerError('error')
    assert a.quiet == False

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    b = ServerError('error')
    assert b.quiet == True

    @add_status_code(404, quiet=True)
    class NotFound(SanicException):
        pass

    c = NotFound('error')
    assert c.quiet == True

    @add_status_code(404, quiet=False)
    class NotFound(SanicException):
        pass

    d = NotFound('error')
    assert d.quiet == False

# Generated at 2022-06-12 08:48:08.453652
# Unit test for function add_status_code
def test_add_status_code():
    expected = {
        404: "foo",
        400: "bar",
        500: "baz"
    }

    @add_status_code(404)
    class Foo(SanicException):
        pass

    @add_status_code(400)
    class Bar(SanicException):
        pass

    @add_status_code(500)
    class Baz(SanicException):
        pass

    assert _sanic_exceptions == expected

# Generated at 2022-06-12 08:48:13.247848
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    assert 400 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[400], SanicException)
    assert issubclass(_sanic_exceptions[400], CustomException)



# Generated at 2022-06-12 08:48:20.453913
# Unit test for function add_status_code
def test_add_status_code():

    def print_status_code(status_code):
        print("{} {} {}".format(status_code,
                                _sanic_exceptions[status_code].__name__,
                                _sanic_exceptions[status_code].quiet))

    for code in [404, 400, 405, 500, 503, 408, 413, 416, 417, 403, 401]:
        print_status_code(code)

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:28.745215
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404, quiet=True)
    class NotFound(SanicException):
        pass

    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert _sanic_exceptions[404] == NotFound

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        pass

    assert MethodNotSupported.status_code == 405
    assert MethodNotSupported.quiet == False
    assert _sanic_exceptions[405] == MethodNotSupported

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert ServerError.status_code == 500
    assert ServerError.quiet == False
    assert _sanic_exceptions[500] == ServerError


# Generated at 2022-06-12 08:48:32.202068
# Unit test for function add_status_code
def test_add_status_code():

    import types

    @add_status_code(998)
    class Exception998(SanicException):
        pass

    assert isinstance(_sanic_exceptions[998], types.FunctionType)
    assert _sanic_exceptions[998].__name__ == "Exception998"

# Generated at 2022-06-12 08:48:39.548688
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        def __init__(self, message):
            super().__init__(message)
    # add_status_code(code, quiet=None)
    a = add_status_code(1)(A)
    assert a.status_code == 1
    assert a.quiet == False
    b = add_status_code(2, quiet=True)(A)
    assert b.status_code == 2
    assert b.quiet == True
    c =  add_status_code(3)(A)
    assert c.status_code == 3
    assert c.quiet == True

# Generated at 2022-06-12 08:48:41.106123
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(405)(ServerError).status_code == 405

# Generated at 2022-06-12 08:48:48.028953
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class SomeException(SanicException):
        pass

    class SomeExceptionError(SanicException):
        pass

    add_status_code(404, quiet=True)(SomeExceptionError)

    assert _sanic_exceptions[404] == SomeException
    assert _sanic_exceptions[404].status_code == 404
    assert issubclass(SomeException, SanicException)
    assert _sanic_exceptions[404].quiet
    assert SomeExceptionError.status_code == 404
    assert SomeExceptionError.quiet

# Generated at 2022-06-12 08:48:53.846771
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(405)
    class MethodNotSupported(SanicException):
        """
        **Status**: 405 Method Not Allowed
        """

        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}

    assert MethodNotSupported.status_code == 405

# Generated at 2022-06-12 08:48:56.656837
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class test_add_status_code(SanicException):
        pass

    assert len(_sanic_exceptions) == 12

# Generated at 2022-06-12 08:49:20.257259
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test function to add status code
    :return:
    """
    def class_decorator(cls):
        cls.status_code = 404
        cls.quiet = True
        _sanic_exceptions[404] = cls
        return cls

    class_decorator(NotFound)
    assert _sanic_exceptions == {404: NotFound}

# Generated at 2022-06-12 08:49:26.527812
# Unit test for function add_status_code
def test_add_status_code():
    # raised = False
    # try:
    #     raise abort(status_code=451)
    # except Exception as e:
    #     raised = True
    # assert raised

    @add_status_code(451, True)
    class UnavailableForLegalReasons(SanicException):
        pass

    raised = False
    try:
        abort(451)
    except UnavailableForLegalReasons as e:
        assert e.message == "451 Unavailable For Legal Reasons"
        assert e.status_code == 451
        raised = True
    assert raised

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:30.279347
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class HttpException1(SanicException):
        pass
    assert _sanic_exceptions[201] is HttpException1
    assert HttpException1.status_code == 201


# Generated at 2022-06-12 08:49:36.653726
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TemplateException(SanicException):
        pass

    @add_status_code(200, quiet=True)
    class TemplateException2(SanicException):
        pass

    assert isinstance(TemplateException, SanicException), \
        "TemplateException should inherit from SanicException"
    assert isinstance(TemplateException2, SanicException), \
        "TemplateException2 should inherit from SanicException"
    assert TemplateException.status_code == 200
    assert TemplateException.quiet == False
    assert TemplateException2.status_code == 200
    assert TemplateException2.quiet == True

# Generated at 2022-06-12 08:49:40.427722
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=100)
    class Test100(SanicException):
        pass

    assert Test100.status_code == 100, 'Not equal status code'



# Generated at 2022-06-12 08:49:46.931251
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(400)
    assert add_status_code(405)
    assert add_status_code(500)
    assert add_status_code(503)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(416)
    assert add_status_code(417)
    assert add_status_code(403)
    assert add_status_code(401)

# Generated at 2022-06-12 08:49:53.558591
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Hi(SanicException):
        pass

    # Check if 200 is added to _sanic_exceptions dictionary
    assert isinstance(_sanic_exceptions[200], type(Hi))

    # Check if 200 is added to _sanic_exceptions and the status_code attribute is
    # set.
    assert _sanic_exceptions[200].status_code == 200



# Generated at 2022-06-12 08:50:00.398151
# Unit test for function add_status_code
def test_add_status_code():
    """
    add_status_code is a decorator that adds a SanicException class to _sanic_exceptions.
    This is used for convenience when creating exception classes for status codes in http responses.
    """
    class MyException(SanicException):
        pass

    # add class MyException to _sanic_exceptions with an empty dictionary
    add_status_code(status_code=300)(MyException)
    assert MyException.status_code == 300
    assert _sanic_exceptions[300] == MyException

    # update status_code and dictionary of MyException class
    add_status_code(status_code=301)(MyException)
    assert MyException.status_code == 301
    assert _sanic_exceptions[301] == MyException

# Generated at 2022-06-12 08:50:04.145338
# Unit test for function add_status_code
def test_add_status_code():
    try:
        @add_status_code(501)
        class test(SanicException):
            pass
        assert False
    except:
        assert True
    assert test.status_code == 501
    assert test.quiet == None

# Generated at 2022-06-12 08:50:10.051019
# Unit test for function add_status_code
def test_add_status_code():
    # test StatusCode class decorator
    class StatusCode(SanicException):
        pass

    # This is required because we need to access the decorator after it
    # has been decorated (i.e. multiple calls).
    dec = add_status_code(503)
    dec(StatusCode)

    exception = _sanic_exceptions[503]
    assert issubclass(exception, SanicException)
    assert exception is StatusCode

# Generated at 2022-06-12 08:50:53.339408
# Unit test for function add_status_code
def test_add_status_code():

    class C(SanicException):
        pass

    class D(SanicException):
        pass

    c = add_status_code(400)(C)
    assert c.status_code == 400
    assert c.quiet == True

    d = add_status_code(500, quiet=True)(D)
    assert d.status_code == 500
    assert d.quiet == True

    e = add_status_code(500, quiet=False)(D)
    assert e.status_code == 500
    assert e.quiet == False



# Generated at 2022-06-12 08:50:56.266426
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class MySanicException(SanicException):
        pass

    assert _sanic_exceptions[403] == MySanicException



# Generated at 2022-06-12 08:51:08.653742
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 418
    assert TestException.quiet is False
    assert TestException.__name__ == 'TestException'
    assert TestException('A message').status_code == 418

    @add_status_code(429)
    class TestException429(SanicException):
        pass

    assert TestException429.status_code == 429
    assert TestException429.quiet is True
    assert TestException429.__name__ == 'TestException429'

    @add_status_code(500)
    class TestException500(SanicException):
        pass

    assert TestException500.status_code == 500
    assert TestException500.quiet is False

# Generated at 2022-06-12 08:51:12.461164
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    exc = add_status_code(status_code)(SanicException)
    assert exc.status_code == status_code
    assert exc.quiet == True

# Generated at 2022-06-12 08:51:19.597408
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class _TestAddStatusCode(SanicException):
        pass
    assert _TestAddStatusCode.status_code == 123
    assert _TestAddStatusCode.quiet is None
    assert 123 in _sanic_exceptions
    assert _TestAddStatusCode is _sanic_exceptions[123]

    @add_status_code(456, quiet=False)
    class _TestAddStatusCode(SanicException):
        pass
    assert _TestAddStatusCode.status_code == 456
    assert _TestAddStatusCode.quiet is False
    assert 456 in _sanic_exceptions
    assert _TestAddStatusCode is _sanic_exceptions[456]


# Generated at 2022-06-12 08:51:25.905703
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MySanicException(SanicException):
        pass

    assert MySanicException.status_code == 400
    assert _sanic_exceptions[400] == MySanicException

    @add_status_code(400, quiet=True)
    class MySanicException(SanicException):
        pass

    assert MySanicException.quiet == True

# Generated at 2022-06-12 08:51:35.694598
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100, quiet=True)
    class TestException1(SanicException):
        pass

    assert TestException1.status_code == 100
    assert TestException1.quiet == True

    @add_status_code(400, quiet=False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 400
    assert TestException2.quiet == False

    @add_status_code(300)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 300
    assert TestException3.quiet == False

    @add_status_code(200)
    class TestException4(SanicException):
        pass

    assert TestException4.status_code == 200
    assert TestException4.quiet == True


# Generated at 2022-06-12 08:51:37.322003
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert hasattr(MyException, "status_code")
    assert MyException.status_code == 200

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:51:42.630023
# Unit test for function add_status_code
def test_add_status_code():

    class MyException(SanicException):
        pass

    # New status
    add_status_code(998)(MyException)

    # Existing status
    MyException2 = add_status_code(404)(MyException)
    assert MyException2 is NotFound

    # New status with quiet=True
    add_status_code(997, quiet=True)(MyException)

    # Existing status with quiet=False
    MyException4 = add_status_code(404, quiet=False)(MyException)
    assert MyException4 is NotFound

# Generated at 2022-06-12 08:51:46.245959
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class _408(SanicException):
        pass

    assert STATUS_CODES[408] == b"Request Timeout"
    assert _sanic_exceptions[408] == _408

# Generated at 2022-06-12 08:53:10.700109
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410)
    class Gone(SanicException):
        pass
    assert _sanic_exceptions[410] == Gone



# Generated at 2022-06-12 08:53:16.903336
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(204, quiet=True)
    class NoContent(SanicException):
        pass
    assert NoContent.status_code == 204
    assert NoContent.quiet == True

    @add_status_code(412)
    class PreconditionFailed(SanicException):
        pass
    assert PreconditionFailed.status_code == 412
    assert PreconditionFailed.quiet == False

    @add_status_code(503, quiet=False)
    class ServiceUnavailable(SanicException):
        pass
    assert ServiceUnavailable.status_code == 503
    assert ServiceUnavailable.quiet == False


# Generated at 2022-06-12 08:53:20.327351
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert '400' in _sanic_exceptions

# Generated at 2022-06-12 08:53:26.071279
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        """
        **Status**: 418 I Am A Teapot
        """
        pass
    assert IAmATeaPot(message="Hi").status_code == 418
    assert IAmATeaPot(message="Hi", status_code=500).status_code == 500
    assert _sanic_exceptions[418] == IAmATeaPot


# Generated at 2022-06-12 08:53:33.443610
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestClass:
        pass

    assert TestClass.status_code == 200
    assert TestClass.quiet is False

    @add_status_code(500, quiet=True)
    class TestClass2:
        pass

    assert TestClass2.status_code == 500
    assert TestClass2.quiet is True

    @add_status_code(400)
    class TestClass3:
        pass

    assert TestClass3.status_code == 400
    assert TestClass3.quiet is True

# Generated at 2022-06-12 08:53:36.558448
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions.get(400).__name__ == "MyException"


if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-12 08:53:42.472650
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest.status_code == 400
    assert _sanic_exceptions[400].__name__ == "BadRequest"

    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert NotFound.status_code == 404
    assert _sanic_exceptions[404].__name__ == "NotFound"

# Generated at 2022-06-12 08:53:50.061733
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    test_class_1 = SanicException(message="message", status_code=status_code)
    assert test_class_1.status_code == status_code

    status_code = 401
    test_class_2 = SanicException(message="message", status_code=status_code)
    assert test_class_2.status_code == status_code

    status_code = 402
    test_class_3 = SanicException(message="message", status_code=status_code)
    assert test_class_3.status_code == status_code

# Generated at 2022-06-12 08:53:55.128406
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        pass

    add_status_code(404)(CustomException)
    assert isinstance(abort(404), CustomException)
    assert isinstance(abort(404), NotFound)

    with raises(KeyError):
        # Default status_code=500
        assert isinstance(abort(500), ServerError)

# Generated at 2022-06-12 08:54:02.918328
# Unit test for function add_status_code
def test_add_status_code():
    class test(SanicException):
        pass
    assert test.status_code == None
    assert test.quiet == None
    assert test(1).quiet == None

    # add non-quiet class
    add_status_code(400)(test)
    assert test.quiet == False

    # add quiet class
    add_status_code(404)(test)
    assert test.quiet == True

    # add non-quiet class
    add_status_code(500)(test)
    assert test.quiet == False

    class test(SanicException):
        pass

    # add non-quiet class
    add_status_code(400, False)(test)
    assert test.quiet == False

    # add quiet class
    add_status_code(404, True)(test)
    assert test.quiet == True

    # add non-quiet class