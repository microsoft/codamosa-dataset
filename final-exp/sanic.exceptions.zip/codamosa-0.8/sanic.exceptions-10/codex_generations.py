

# Generated at 2022-06-12 08:44:34.162248
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    @add_status_code(status_code)
    class C(Exception):
        pass
    exc = C()
    assert exc.status_code == status_code

# Generated at 2022-06-12 08:44:37.523388
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}
    add_status_code(status_code=108, quiet=True)(SanicException)
    add_status_code(status_code=502, quiet=None)(SanicException)
    assert _sanic_exceptions[502].quiet == False
    assert _sanic_exceptions[108].quiet == True

# Generated at 2022-06-12 08:44:47.641508
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("401", 400)
    except Unauthorized as e:
        assert e.message == "401"
        assert e.status_code == 400
        assert e.headers == {}

    try:
        raise Unauthorized("401", scheme="Basic")
    except Unauthorized as e:
        assert e.message == "401"
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Basic"}

    try:
        raise Unauthorized("401", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "401"
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }


# Generated at 2022-06-12 08:44:54.015302
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(404, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True

    @add_status_code(403)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 403
    assert TestException.quiet is True

# Generated at 2022-06-12 08:45:05.283324
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Unauthorized class with scheme arguments
    u1 = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert u1.headers == { "WWW-Authenticate": 'Basic realm="Restricted Area"' }

    # Unauthorized class with scheme and kwargs arguments
    u2 = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert u2.headers == { "WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"' }

# Generated at 2022-06-12 08:45:13.129768
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test for the default scheme
    try:
        raise Unauthorized("Auth required.")
    except Unauthorized as e:
        assert e.headers is None and e.status_code == 401 and \
               e.message == "Auth required."
    # Test for Basic scheme
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers is not None and e.status_code == 401 and \
               e.message == "Auth required."
    # Test for Digest scheme

# Generated at 2022-06-12 08:45:26.341964
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as raised:
        raise Unauthorized("Unauthorized", scheme="Bearer")
    assert str(raised.value) == "Unauthorized"
    assert raised.value.status_code == 401
    assert raised.value.headers["WWW-Authenticate"] == "Bearer"

    with pytest.raises(Unauthorized) as raised:
        raise Unauthorized("Unauthorized", scheme="Basic", realm="Restricted Area")
    assert str(raised.value) == "Unauthorized"
    assert raised.value.status_code == 401
    assert raised.value.headers["WWW-Authenticate"] == "Basic realm=Restricted Area"


# Generated at 2022-06-12 08:45:32.076260
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True
    
    add_status_code(800)(MyException)
    assert _sanic_exceptions[800] == MyException



# Generated at 2022-06-12 08:45:42.859600
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions

    # 1. "Test" is not a subclass of SanicException.
    #    Exception should be raised.
    try:
        add_status_code(100)(Test)
    except Exception as e:
        print("Test 1: PASS")
    else:
        print("Test 1: FAIL")
        print("Test 1: add_status_code should not accept class: Test.")
        print("Test 1: Instead, add_status_code accepted class: Test.")

    # 2. The second argument is neither True nor False.
    #    Exception should be raised.
    try:
        add_status_code(100, "not_bool")(Test)
    except Exception as e:
        print("Test 2: PASS")
    else:
        print("Test 2: FAIL")

# Generated at 2022-06-12 08:45:45.739600
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 500
    assert _sanic_exceptions.get(500, None) == CustomException

# Generated at 2022-06-12 08:45:57.739965
# Unit test for function add_status_code
def test_add_status_code():
    sanic_exceptions = _sanic_exceptions
    assert len(sanic_exceptions) == 8

    assert sanic_exceptions[404] is NotFound
    assert sanic_exceptions[400] is InvalidUsage
    assert sanic_exceptions[405] is MethodNotSupported
    assert sanic_exceptions[500] is ServerError
    assert sanic_exceptions[503] is ServiceUnavailable
    assert sanic_exceptions[408] is RequestTimeout
    assert sanic_exceptions[413] is PayloadTooLarge
    assert sanic_exceptions[416] is ContentRangeError
    assert sanic_exceptions[417] is HeaderExpectationFailed

# Generated at 2022-06-12 08:46:08.154011
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        def __init__(self):
            super().__init__("Test message")
    test_exception = TestException()
    assert _sanic_exceptions.get(200) is None
    assert _sanic_exceptions.get(200) == add_status_code(200)(TestException)
    assert _sanic_exceptions.get(200) == test_exception
    assert test_exception.quiet is True
    assert _sanic_exceptions.get(500) is None
    assert _sanic_exceptions.get(500) == add_status_code(500)(TestException)
    assert _sanic_exceptions.get(500) == test_exception
    assert test_exception.quiet is False
    assert _sanic_exceptions.get(500) is None

# Generated at 2022-06-12 08:46:15.251793
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        add_status_code(200)

    @add_status_code(403)
    class MyException(SanicException):
        pass

    @add_status_code(404, quiet=True)
    class MyException2(SanicException):
        pass

    assert MyException.status_code == 403
    assert MyException2.status_code == 404
    assert not hasattr(MyException, "quiet")
    assert MyException2.quiet

    assert _sanic_exceptions[403] is MyException
    assert _sanic_exceptions[404] is MyException2



# Generated at 2022-06-12 08:46:24.354351
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException(Exception):
        pass

    _sanic_exceptions = {}

    def fake_add_status_code(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls

        return class_decorator

    @fake_add_status_code(404)
    class NotFound(SanicException):
        """ Adding status code for NotFound"""

        pass

    assert _sanic_exceptions[404].__name__ == "NotFound"



# Generated at 2022-06-12 08:46:27.052946
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        abort(418)
    @add_status_code(418)
    class IAmATeapotError(SanicException):
        """
        **Status**: 418 I Am A Teapot
        """
        pass


    with pytest.raises(IAmATeapotError):
        abort(418)



# Generated at 2022-06-12 08:46:30.256304
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 202
    assert _sanic_exceptions[202] == TestException



# Generated at 2022-06-12 08:46:35.532733
# Unit test for function add_status_code
def test_add_status_code():
    '''
    Test for _sanic_exceptions and status_code attribute
    '''
    @add_status_code(403)
    class Forbidden(SanicException):
        """
        **Status**: 403 Forbidden
        """
        pass

    assert(_sanic_exceptions[403] == Forbidden)
    assert(Forbidden.status_code == 403)

# Generated at 2022-06-12 08:46:39.415953
# Unit test for function add_status_code
def test_add_status_code():
    values = _sanic_exceptions.values()
    for v in values:
        assert callable(v) == True
    for v in values:
        assert getattr(v,"status_code") == True
    for v in values:
        assert getattr(v,"quiet") == True

test_add_status_code()

# Generated at 2022-06-12 08:46:46.048271
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(400, True)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 400
    assert TestException2.quiet == True



# Generated at 2022-06-12 08:46:51.265807
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class SanicException1(SanicException):
        pass
    
    @add_status_code(2)
    class SanicException2(SanicException):
        pass
    
    assert _sanic_exceptions[1] == SanicException1
    assert _sanic_exceptions[2] == SanicException2


# Generated at 2022-06-12 08:46:57.517237
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101, quiet=True)
    class SwitchingProtocols(SanicException):
        pass

    assert SwitchingProtocols.status_code == 101
    assert SwitchingProtocols.quiet is True

# Generated at 2022-06-12 08:47:00.980657
# Unit test for function add_status_code
def test_add_status_code():
    new_exception_code = 999

    @add_status_code(new_exception_code)
    class NewException(SanicException):
        pass

    assert NewException.status_code == new_exception_code
    assert NewException.quiet == False

# Generated at 2022-06-12 08:47:10.570265
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Foo(SanicException):
        pass
    assert isinstance(Foo(message="test"), SanicException)
    assert Foo.status_code == 200
    add_status_code(201, quiet=True)(Foo)
    assert Foo.status_code == 201
    assert Foo.quiet
    add_status_code(202, quiet=False)(Foo)
    assert Foo.status_code == 202
    assert not Foo.quiet
    add_status_code(203)(Foo)
    assert Foo.status_code == 203
    assert not Foo.quiet


# Generated at 2022-06-12 08:47:14.291307
# Unit test for function add_status_code
def test_add_status_code():
    original_codes = _sanic_exceptions.copy()
    add_status_code(600)(SanicException)
    assert 500 in _sanic_exceptions
    assert 600 in _sanic_exceptions
    _sanic_exceptions = original_codes

# Generated at 2022-06-12 08:47:22.191666
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestCustomException1(SanicException):
        pass

    assert TestCustomException1.status_code == 400
    assert _sanic_exceptions[400] == TestCustomException1

    @add_status_code(408)
    class TestCustomException2(SanicException):
        pass

    assert TestCustomException2.status_code == 408
    assert _sanic_exceptions[408] == TestCustomException2

    @add_status_code(411)
    class TestCustomException3(SanicException):
        pass

    assert TestCustomException3.status_code == 411
    assert _sanic_exceptions[411] == TestCustomException3


# Generated at 2022-06-12 08:47:29.596356
# Unit test for function add_status_code
def test_add_status_code():
    class ApiException(Exception):
        pass

    def add_status_code(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator

    exception_class = add_status_code(404)(ApiException)

    assert exception_class.status_code == 404
    assert isinstance(exception_class, ApiException)

# Generated at 2022-06-12 08:47:31.633972
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class _Test(SanicException):
        pass
        
    assert str(_Test("Test")) == "Test"


# Generated at 2022-06-12 08:47:38.919596
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 401
    assert _sanic_exceptions[401] is MyException

    exception = MyException("This is an exception")
    assert exception.status_code == 401

    # unit test for parameter quiet
    @add_status_code(500, quiet=False)
    class Exception500(SanicException):
        pass

    assert Exception500.status_code == 500
    assert Exception500.quiet == False


# Generated at 2022-06-12 08:47:44.889833
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(Exception):
        status_code = None
        quiet = None

    @add_status_code(504)
    class ThisException(TestException):
        """
        **Status**: 504 Gateway Timeout
        """

        pass

    assert ThisException.status_code == 504
    assert ThisException.quiet == False
    assert _sanic_exceptions[504] == ThisException

# Generated at 2022-06-12 08:47:55.049084
# Unit test for function add_status_code
def test_add_status_code():
    # Test for no decorator
    assert _sanic_exceptions == {}

    # Test for decorator with status code
    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass
    assert _sanic_exceptions == {503: ServiceUnavailable}

    # Test for added status code being successfully added to _sanic_exceptions
    assert _sanic_exceptions[503].status_code == 503

    # Test for decorator with no status code
    @add_status_code
    class ServiceUnavailable(SanicException):
        pass
    assert _sanic_exceptions == {503: ServiceUnavailable}

    # Test for decorator with status code
    @add_status_code(404)
    class ServiceUnavailable(SanicException):
        pass
    assert _sanic_exceptions

# Generated at 2022-06-12 08:48:08.350523
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator():
        return add_status_code(404,True)
    decorator = test_decorator()
    @decorator
    class TestException(SanicException):
        pass
    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert isinstance(_sanic_exceptions[404], TestException)



# Generated at 2022-06-12 08:48:16.506871
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}

    assert add_status_code(200, quiet=True)
    assert add_status_code(300, quiet=False)
    assert add_status_code(400)
    assert add_status_code(500)

    assert _sanic_exceptions == {
        200: SanicException,
        300: SanicException,
        400: SanicException,
        500: SanicException,
    }


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:20.037231
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    add_status_code(1, True)(MyException)
    assert MyException.status_code == 1
    assert MyException.quiet == True

# Generated at 2022-06-12 08:48:21.402334
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(200)
    class A(SanicException):
        pass
    
    assert A.status_code == 200
    assert _sanic_exceptions[200]

# Generated at 2022-06-12 08:48:27.350890
# Unit test for function add_status_code
def test_add_status_code():
    """
    Assert that the add_status_code decorator correctly sets up a SanicException
    based class with status_code and quiet attributes.
    """
    @add_status_code(400)
    class TestException(SanicException):
        def __init__(self):
            super().__init__("test")
    assert TestException.status_code == 400
    assert TestException.quiet
    assert TestException.__name__ == "TestException"
    assert TestException().status_code == 400
    assert TestException().quiet
    assert TestException().args[0] == "test"



# Generated at 2022-06-12 08:48:29.988263
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400



# Generated at 2022-06-12 08:48:39.505666
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 123
    assert _sanic_exceptions[123] is MyException
    assert _sanic_exceptions[123]() is MyException()

    @add_status_code(200)
    class MyOtherException(SanicException):
        pass

    assert MyOtherException.status_code == 200
    assert _sanic_exceptions[200] is MyOtherException
    assert _sanic_exceptions[200]() is MyOtherException()
    assert not MyOtherException.quiet
    assert not _sanic_exceptions[200]().quiet

    @add_status_code(200, quiet=True)
    class MyOtherException(SanicException):
        pass

    assert MyOtherException.status_

# Generated at 2022-06-12 08:48:40.723543
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code


# Generated at 2022-06-12 08:48:51.044563
# Unit test for function add_status_code
def test_add_status_code():
    code = 502
    new_exception = add_status_code(code)(type("TestSanicException", (SanicException,),
                                               {"__init__": lambda *args: SanicException.__init__(*args)}))
    assert new_exception.status_code == code
    assert _sanic_exceptions[code] == new_exception

    code = 503
    new_exception = add_status_code(code, quiet=True)(type("TestSanicException", (SanicException,),
                                               {"__init__": lambda *args: SanicException.__init__(*args)}))
    assert new_exception.status_code == code
    assert _sanic_exceptions[code] == new_exception
    assert new_exception.quiet == True


# Generated at 2022-06-12 08:48:59.208807
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException().status_code == 400
    assert _sanic_exceptions[400] is MyException
    assert _sanic_exceptions[500] is ServerError

    @add_status_code(401)
    class MyError(SanicException):
        pass

    assert MyError.status_code == 401
    assert MyError().status_code == 401

    # Test the quiet attribute by default vs. no default
    assert MyError.quiet is True
    assert ServerError.quiet is False

# Generated at 2022-06-12 08:49:20.428096
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(Exception):
        pass
    test_exception_class = TestException('')
    assert test_exception_class.status_code == 400

    test_exception_class_quiet = TestException('')
    test_exception_class_quiet.status_code = 501
    assert test_exception_class_quiet.status_code == 501

# Generated at 2022-06-12 08:49:30.190828
# Unit test for function add_status_code
def test_add_status_code():
    class SampleException(SanicException):
        status_code = 0

    assert hasattr(SampleException, 'status_code')
    assert hasattr(SampleException, 'quiet')

    add_status_code(200, quiet=None)
    add_status_code(404, quiet=None)
    add_status_code(400, quiet=None)
    add_status_code(405, quiet=None)
    add_status_code(500, quiet=None)
    add_status_code(503, quiet=None)
    add_status_code(408, quiet=None)
    add_status_code(413, quiet=None)
    add_status_code(416, quiet=None)
    add_status_code(417, quiet=None)
    add_status_code(403, quiet=None)
    add

# Generated at 2022-06-12 08:49:38.019789
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    @add_status_code(400)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        """
        **Status**: 405 Method Not Allowed
        """

        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}

    @add_status_code(500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

# Generated at 2022-06-12 08:49:41.536896
# Unit test for function add_status_code
def test_add_status_code():
    class test_class(Exception):
        pass

    class_decorator = add_status_code(111)
    assert class_decorator(test_class).status_code == 111

    class_decorator = add_status_code(222, quiet=True)
    assert class_decorator(test_class).status_code == 222
    assert class_decorator(test_class).quiet == True

    class_decorator = add_status_code(333, quiet=False)
    assert class_decorator(test_class).status_code == 333
    assert class_decorator(test_class).quiet == False


# Generated at 2022-06-12 08:49:49.588433
# Unit test for function add_status_code
def test_add_status_code():
    """
    Testing function add_status_code by defining a custom exception and
    seeing if it can be used to instantiate a correct response.
    """
    # Ensure there are no exceptions with code 999 in _sanic_exceptions
    assert 999 not in _sanic_exceptions
    # Define a custom exception
    @add_status_code(999)
    class CustomException(SanicException):
        """
        **Status**: 999 Custom Exception
        """
        pass
    # Ensure our custom exception is added to _sanic_exceptions
    assert 999 in _sanic_exceptions
    # Check that our custom exception is returned by abort()
    try:
        abort(999)
    except CustomException:
        # Expected behaviour
        pass
    else:
        # Unexpected behaviour - abort() did not raise our custom exception
        raise

# Generated at 2022-06-12 08:49:56.269313
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class DummyException501(SanicException):
        pass

    @add_status_code(502, True)
    class DummyException502Quiet(SanicException):
        pass

    assert _sanic_exceptions[501] == DummyException501
    assert _sanic_exceptions[502] == DummyException502Quiet
    assert _sanic_exceptions[502].quiet == True

# Generated at 2022-06-12 08:49:59.925294
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(400)
    class Error(SanicException):
        pass

    assert Error().status_code == 400

    assert Error(message="Not found", status_code=404).status_code == 404



# Generated at 2022-06-12 08:50:08.480493
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class SwitchingProtocols(SanicException):
        pass

    assert SwitchingProtocols.status_code == 101
    assert SwitchingProtocols(message="error").status_code == 101

    @add_status_code(401)
    class UnauthorizedTest(SanicException):
        pass

    assert UnauthorizedTest.status_code == 401
    assert UnauthorizedTest(message="error").status_code == 401

    @add_status_code(100)
    class ContinueTest(SanicException):
        pass

    assert ContinueTest.status_code == 100
    assert ContinueTest(message="error").status_code == 100

# Generated at 2022-06-12 08:50:11.459053
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, quiet=True)
    class Created(SanicException):
        pass

    assert Created.status_code == 201
    assert Created.quiet is True

# Generated at 2022-06-12 08:50:14.823259
# Unit test for function add_status_code
def test_add_status_code():
    """Add a status code to the status code list"""
    @add_status_code(555)
    class NewSanicException(SanicException):
        pass

    assert NewSanicException.status_code == 555

# Generated at 2022-06-12 08:50:50.989303
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):

        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

    assert TestException.status_code == 400
    assert TestException.quiet is True


# Generated at 2022-06-12 08:50:55.932278
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code(code, quiet=None)
    # def class_decorator(cls)

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400

    try:
        raise TestException()
    except TestException as e:
        assert e.status_code == 400

# Generated at 2022-06-12 08:51:03.910560
# Unit test for function add_status_code
def test_add_status_code():
    # SanicException will be used if the status_code is not added to this dict
    _sanic_exceptions[400] = SanicException

    @add_status_code(400)
    class Stray_Exception(SanicException):
        status_code = 400
        quiet = True

    assert(isinstance(Stray_Exception(""), Stray_Exception))
    assert(Stray_Exception("").status_code == 400)
    assert(Stray_Exception("").quiet == True)

# Generated at 2022-06-12 08:51:07.362876
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestExceptionType2(SanicException):
        pass

    assert TestExceptionType2.status_code == 200
    assert TestExceptionType2.quiet == None

# Generated at 2022-06-12 08:51:11.354929
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class AddStatusCode(SanicException):
        pass

    exc = AddStatusCode("some error")
    assert exc.status_code == 444
    assert exc.quiet is True



# Generated at 2022-06-12 08:51:15.350932
# Unit test for function add_status_code
def test_add_status_code():
    NOT_FOUND = add_status_code(404)(SanicException)
    assert isinstance(NOT_FOUND(''), SanicException)
    assert NOT_FOUND.status_code == 404
    assert NOT_FOUND('').status_code == 404


# Generated at 2022-06-12 08:51:18.685196
# Unit test for function add_status_code
def test_add_status_code():
    class _UnexpectedError(SanicException):
        pass

    @add_status_code(500)
    class UnexpectedError(_UnexpectedError):
        pass

    assert _sanic_exceptions[500] == UnexpectedError



# Generated at 2022-06-12 08:51:28.888783
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Example(SanicException):
        pass

    @add_status_code(201)
    class Example2(SanicException):
        pass

    assert Example.status_code == 200
    assert Example2.status_code == 201

    @add_status_code(400)
    class Example3(SanicException):
        pass

    assert Example3.status_code == 400
    assert Example3.quiet == True

    @add_status_code(500)
    class Example4(SanicException):
        pass

    assert Example4.status_code == 500
    assert Example4.quiet == False

    print("Passed test_add_status_code()...")


# Generated at 2022-06-12 08:51:38.386291
# Unit test for function add_status_code
def test_add_status_code():
    global NotFound
    global InvalidUsage
    global MethodNotSupported
    global ServerError
    global ServiceUnavailable
    global URLBuildError
    global FileNotFound
    global RequestTimeout
    global PayloadTooLarge
    global HeaderNotFound
    global ContentRangeError
    global HeaderExpectationFailed
    global Forbidden
    global InvalidRangeType
    global PyFileError
    global Unauthorized
    global LoadFileException
    global InvalidSignal

    @add_status_code(404, True)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass
    @add_status_code(400, True)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

# Generated at 2022-06-12 08:51:41.407023
# Unit test for function add_status_code
def test_add_status_code():
    _sanic_exceptions[424] = add_status_code(424)
    assert _sanic_exceptions[424] is not None
    assert _sanic_exceptions[424]().status_code == 424
    assert _sanic_exceptions[424].status_code == 424

# Generated at 2022-06-12 08:52:59.470893
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class Dummy(SanicException):
        pass

    assert Dummy.status_code == 300
    assert Dummy('').status_code == 300
    assert Dummy('').message == ''

    @add_status_code(9999)
    class Dummy2(SanicException):
        pass

    assert Dummy2.status_code == 9999
    assert Dummy2('').status_code == 9999

# Generated at 2022-06-12 08:53:10.152254
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class test_class(SanicException):
        pass
    assert _sanic_exceptions.get(123) == test_class
    assert test_class.status_code == 123
    assert test_class.quiet == False
    del _sanic_exceptions[123]
    @add_status_code(123, quiet = True)
    class test_class(SanicException):
        pass
    assert _sanic_exceptions.get(123) == test_class
    assert test_class.status_code == 123
    assert test_class.quiet == True
    del _sanic_exceptions[123]

# Generated at 2022-06-12 08:53:17.220184
# Unit test for function add_status_code
def test_add_status_code():
    # Test that add_status_code decorates SanicException correctly
    @add_status_code(450)
    class WrongSanicException(SanicException):
        pass
    # The underlying type of WrongSanicException is
    # _sanic_exceptions[450]
    assert type(WrongSanicException()) == _sanic_exceptions[450]
    # The decorated class should also have status code attribute:
    assert WrongSanicException.status_code == 450

    # Test that add_status_code updates _sanic_exceptions
    assert _sanic_exceptions[450] == WrongSanicException
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[500] == ServerError



# Generated at 2022-06-12 08:53:19.950000
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeapot(SanicException):
        pass

    assert _sanic_exceptions[418] == IAmATeapot

# Generated at 2022-06-12 08:53:24.100881
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert issubclass(IAmATeaPot, SanicException)
    assert IAmATeaPot.status_code == 418
    assert isinstance(_sanic_exceptions[418], IAmATeaPot)

# Generated at 2022-06-12 08:53:34.391523
# Unit test for function add_status_code
def test_add_status_code():
    # assert that status code is raised with default quiet=False
    try:
        raise NotFound("Test exception message.")
    except SanicException as exc:
        assert exc.status_code == 404, "Status code not set"
        assert not exc.quiet, "Wrong default for quiet"

    # assert that raised exception is the correct one
    try:
        raise NotFound("Test exception message.")
    except NotFound as exc:
        assert exc.quiet, "Exception should be quiet"

    # assert that quiet=False raises the modified exception
    try:
        raise NotFound("Test exception message.", quiet=False)
    except NotFound as exc:
        assert not exc.quiet, "Exception should not be quiet"

    # assert that quiet=True raises the modified exception

# Generated at 2022-06-12 08:53:43.604184
# Unit test for function add_status_code
def test_add_status_code():
    """
    We don't want to use add_status_code in the code base.
    However, we need to ensure that it works.
    """

    # We can't import the code from the exception file because we
    # would create a circular import.  So we generate the code
    # dynamically.
    import sanic.app
    sanic.app.app.handle_request = lambda request: None

    class TestException(SanicException):
        pass

    import inspect
    assert 'status_code' not in inspect.getargspec(TestException).args

    # The echo() function simply returns the response.
    @add_status_code(418)
    class TestException(SanicException):
        pass

    import sanic.app
    sanic.app.app.handle_request = lambda request: None


# Generated at 2022-06-12 08:53:46.498331
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class test(Exception):
        pass
    assert _sanic_exceptions[1] == test
    assert test.status_code == 1

# Generated at 2022-06-12 08:53:53.352783
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(object):
        message = "test"

    test_instance = TestClass()
    globals()['_sanic_exceptions'] = {404: test_instance, 500: ServerError}
    assert _sanic_exceptions == {404: test_instance, 500: ServerError}

    @add_status_code(500, quiet=True)
    class NotFound2(SanicException):
        pass

    assert _sanic_exceptions == {404: test_instance, 500: NotFound2}

# Generated at 2022-06-12 08:53:55.674415
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)(SanicException).status_code == 400
    assert SanicException.status_code != 400
