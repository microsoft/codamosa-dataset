

# Generated at 2022-06-12 08:44:37.385949
# Unit test for function add_status_code
def test_add_status_code():
    def get_status_code(code):
        class test(SanicException):
            pass
        test = add_status_code(code)(test)
        return test.status_code

    assert get_status_code(999) == 999
    assert get_status_code(555) == 555
    assert get_status_code(1337) == 1337
    assert get_status_code(123) == 123

# Generated at 2022-06-12 08:44:46.721268
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(800)
    class CustomException1(SanicException):
        pass

    @add_status_code(801, True)
    class CustomException2(SanicException):
        pass

    assert issubclass(CustomException1, SanicException)
    assert CustomException1.status_code == 800
    assert CustomException1.quiet == False

    assert issubclass(CustomException2, SanicException)
    assert CustomException2.status_code == 801
    assert CustomException2.quiet == True

    assert len(_sanic_exceptions.keys()) == 9
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[801] == CustomException2

# Generated at 2022-06-12 08:44:48.682282
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(status_code= 429, quiet=True)
    #assert result.value == 1/0, "Unittest failed"

# Generated at 2022-06-12 08:44:55.645374
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test for add_status_code
    """
    @add_status_code(201)
    class TestException(SanicException): # pylint: disable=unused-variable
        """
        Test Exception
        """

    assert TestException.status_code == 201
    assert _sanic_exceptions[201] == TestException

# Generated at 2022-06-12 08:45:00.527127
# Unit test for function add_status_code
def test_add_status_code():
    # create new class
    @add_status_code(1)
    class test_class(SanicException):
        pass

    assert test_class.status_code == 1
    assert test_class.quiet == False

    assert _sanic_exceptions[1] == test_class

# Generated at 2022-06-12 08:45:12.200438
# Unit test for function add_status_code
def test_add_status_code():
    def test_abort(status_code: int, message: Optional[Union[str, bytes]] = None):
        """
        Raise an exception based on SanicException. Returns the HTTP response
        message appropriate for the given status code, unless provided.

        STATUS_CODES from sanic.helpers for the given status code.

        :param status_code: The HTTP status code to return.
        :param message: The HTTP response body. Defaults to the messages in
        """
        if message is None:
            msg: bytes = STATUS_CODES[status_code]
            # These are stored as bytes in the STATUS_CODES dict
            message = msg.decode("utf8")
        sanic_exception = _sanic_exceptions.get(status_code, SanicException)

# Generated at 2022-06-12 08:45:20.822548
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test function add_status_code

    :return: None
    """
    assert _sanic_exceptions[500] == ServerError
    assert ServerError(message="Test message").status_code == 500
    with pytest.raises(TypeError):
        # status_code is int
        add_status_code("asd")
    @add_status_code("", False)
    class TestException(SanicException):
        pass
    assert TestException().quiet is False
    assert TestException("Test message").status_code == ""
    with pytest.raises(TypeError):
        # quiet is boolean
        add_status_code(200, 1)

# Generated at 2022-06-12 08:45:22.603306
# Unit test for function add_status_code
def test_add_status_code():
    assert(add_status_code(405, quiet=True) is _sanic_exceptions[405])

# Generated at 2022-06-12 08:45:32.769717
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Http100(SanicException):
        pass

    assert Http100.status_code == 100
    assert _sanic_exceptions[100] is Http100

    @add_status_code(200)
    class Http200(SanicException):
        pass

    assert Http200.status_code == 200
    assert _sanic_exceptions[200] is Http200

    @add_status_code(300)
    class Http300(SanicException):
        pass

    assert Http300.status_code == 300
    assert Http300.quiet

    @add_status_code(400)
    class Http400(SanicException):
        pass

    assert Http400.status_code == 400
    assert not Http400.quiet


# Generated at 2022-06-12 08:45:35.461879
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500, quiet = True)
    class TestException(Exception):
        pass

    e = TestException("500", status_code = 500)
    assert e.status_code == 500
    assert e.quiet == True

# Generated at 2022-06-12 08:45:43.398926
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(499)
    class MyCustomException(SanicException):
        pass

    assert_equal(MyCustomException.status_code, 499)
    assert_true(499 in _sanic_exceptions)
    assert_is_instance(_sanic_exceptions[499], type)



# Generated at 2022-06-12 08:45:48.368459
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, quiet=True)
    class Quiet(SanicException):
        pass

    assert Quiet.status_code == 400
    assert Quiet.quiet
    assert _sanic_exceptions[400] is Quiet

    @add_status_code(500)
    class Loud(SanicException):
        pass

    assert Loud.status_code == 500
    assert not Loud.quiet
    assert _sanic_exceptions[500] is Loud

# Generated at 2022-06-12 08:45:52.495025
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class test(SanicException):
        pass
    assert test.status_code == 200
    assert test(message="test").status_code == 200
    assert test(message="test").quiet == True

# Generated at 2022-06-12 08:45:55.291852
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound2(SanicException):
        pass
    assert _sanic_exceptions[404] is NotFound2
    

# Generated at 2022-06-12 08:46:00.858809
# Unit test for function add_status_code
def test_add_status_code():
    def decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    code = 400
    quiet = None
    add_status_code(code, quiet)(SanicException)



# Generated at 2022-06-12 08:46:08.255116
# Unit test for function add_status_code
def test_add_status_code():
    exc = add_status_code(200)(SanicException)
    # test add_status_code decorator
    assert exc.status_code == 200
    # check quiet default to True for status != 500
    assert exc.quiet == True

    exc = add_status_code(500)(SanicException)
    assert exc.status_code == 500
    assert exc.quiet == False

    exc = add_status_code(404, quiet=False)(SanicException)
    # check quiet can be set by argument
    assert exc.status_code == 404
    assert exc.quiet == False


# Generated at 2022-06-12 08:46:13.455615
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestStatusCode(SanicException):
        pass

    assert TestStatusCode.status_code == 200
    assert TestStatusCode.quiet is False

    @add_status_code(200, True)
    class TestQuietStatusCode(SanicException):
        pass

    assert TestQuietStatusCode.status_code == 200
    assert TestQuietStatusCode.quiet is True



# Generated at 2022-06-12 08:46:16.032223
# Unit test for function add_status_code
def test_add_status_code():
    decorator = add_status_code(404, True)

    @decorator
    class Test(SanicException):
        pass

    assert issubclass(Test, NotFound)
    assert Test.status_code == 404
    assert Test.quiet is True

# Generated at 2022-06-12 08:46:26.519306
# Unit test for function add_status_code
def test_add_status_code():
    class _:
        @add_status_code(420)
        class EnhanceYourCalm(SanicException):
            """
            **Status**: 420 Enhance Your Calm
            """

            pass

    assert _.EnhanceYourCalm.status_code == 420
    assert _.EnhanceYourCalm.quiet == True
    assert _.EnhanceYourCalm.__doc__ == "**Status**: 420 Enhance Your Calm"
    assert _.EnhanceYourCalm.__repr__() == "<class '__main__._.EnhanceYourCalm'>"
    assert _.EnhanceYourCalm.__name__ == "EnhanceYourCalm"
    assert _.EnhanceYourCalm.__module__ == "__main__"


# Generated at 2022-06-12 08:46:29.764424
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(555)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 555
    assert _sanic_exceptions[555].__name__ == "MyException"

# Generated at 2022-06-12 08:46:36.248657
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class UnknownForum(SanicException):
        pass

    assert _sanic_exceptions[202] == UnknownForum

# Generated at 2022-06-12 08:46:39.043968
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403, quiet=False)
    class CustomException(SanicException):
        pass
    custom_exception_instance = CustomException('custom exception')
    assert custom_exception_instance.status_code == 403

# Generated at 2022-06-12 08:46:43.776349
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    add_status_code(code=404, quiet=True)(TestException)
    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert _sanic_exceptions[404] is TestException

# Generated at 2022-06-12 08:46:47.476990
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=404)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[404].__name__ == "MyException"
    assert MyException.quiet is True


# Generated at 2022-06-12 08:46:56.937252
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class Created(SanicException):
        pass
    assert 201 in _sanic_exceptions
    assert Created.status_code == 201
    # Test that the decorator works on the return object from the class
    # constructor when invoked with the default arguments.
    created: Created = Created("test")
    assert created.status_code == 201

    # Test that the decorator works with the default arguments.
    class CreatedWithoutDecorator(SanicException):
        pass
    created_without_decorator: CreatedWithoutDecorator = add_status_code(
        201
    )(CreatedWithoutDecorator)
    assert CreatedWithoutDecorator.status_code == 201
    assert created_without_decorator.status_code == 201



# Generated at 2022-06-12 08:47:03.442975
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class SpecialError(SanicException):
        pass
    assert isinstance(_sanic_exceptions[999], SpecialError)
    # 999 is not a standard HTTP status code.
    assert not hasattr(_sanic_exceptions[999], "quiet")
    assert _sanic_exceptions[999].status_code == 999

    # Defining a new subclass of an exception overrides the old one.
    @add_status_code(404)
    class Special404(SanicException):
        pass
    assert isinstance(_sanic_exceptions[404], Special404)
    # 404 is not a standard HTTP error code.
    assert not hasattr(_sanic_exceptions[404], "quiet")
    assert _sanic_exceptions[404].status_code == 404

    # Defining a new

# Generated at 2022-06-12 08:47:07.769950
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Status200(SanicException):
        pass
    
    assert _sanic_exceptions[200] == Status200
    with pytest.raises(Status200):
        raise Status200()
    

# Generated at 2022-06-12 08:47:13.715035
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        pass

    # make sure the status code was set
    assert Unauthorized.status_code == 401
    # make sure the exception class was added to _sanic_exceptions
    assert _sanic_exceptions[401] == Unauthorized


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:22.677480
# Unit test for function add_status_code
def test_add_status_code():
    # Testing for decorator
    class Test1(SanicException):  # noqa
        pass

    assert Test1 in _sanic_exceptions.values()

    # Testing passing in quiet
    @add_status_code(202, quiet=False)
    class Test2(SanicException):  # noqa
        pass

    assert Test2 not in _sanic_exceptions.values()

    # Testing passing in a code without a quiet flag, but is an error code
    @add_status_code(501)
    class Test3(SanicException):  # noqa
        pass

    assert Test3 not in _sanic_exceptions.values()

    # Testing passing in a code without a quiet flag, but is not an error code

# Generated at 2022-06-12 08:47:27.555798
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[999] is MyException

    @add_status_code(998)
    class MyException2(SanicException):
        pass

    assert _sanic_exceptions[998] is MyException2

# Generated at 2022-06-12 08:47:38.588045
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123, quiet=True)
    class Error(SanicException):
        pass

    assert _sanic_exceptions[123] == Error



# Generated at 2022-06-12 08:47:49.327381
# Unit test for function add_status_code
def test_add_status_code():
    """
    Tasks:
    1. Test add_status_code function.
    2. Test 400 Exception
    3. Test No Exception
    """
    # Test 1. Test add_status_code function.
    assert add_status_code(status_code=400) == add_status_code(status_code=400)
    # Test 2. Test 400 Exception
    try:
        add_status_code(status_code=400)
        # If no exception occurs, assert success.
        assert True
    except:
        # If an exception occurs, assert failure.
        assert False
    # Test 3. Test No Exception

# Generated at 2022-06-12 08:47:57.979538
# Unit test for function add_status_code
def test_add_status_code():
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic.exceptions import (
        SanicException, add_status_code, NotFound, InvalidUsage,
        MethodNotSupported, ServerError, ServiceUnavailable, URLBuildError,
        FileNotFound, RequestTimeout, PayloadTooLarge, HeaderNotFound,
        ContentRangeError, HeaderExpectationFailed, Forbidden,
        InvalidRangeType, PyFileError, Unauthorized, LoadFileException,
        InvalidSignal
    )

    app = Sanic("")

    @app.exception(NotFound)
    def handler_not_found(request, exception):
        return HTTPResponse("exception: 404")

    @app.exception(InvalidUsage)
    def handler_invalid_usage(request, exception):
        return HTT

# Generated at 2022-06-12 08:48:01.999245
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(Exception):
        pass
    
    assert 400 in _sanic_exceptions.keys()
    assert _sanic_exceptions[400].__name__ == 'TestException'

# Generated at 2022-06-12 08:48:09.126134
# Unit test for function add_status_code
def test_add_status_code():
    # add a new exception to SanicException
    @add_status_code(400)
    class MyException(SanicException):
        pass

    my_exception = MyException("a bad request", quiet=True)
    assert my_exception.status_code == 400
    assert my_exception.quiet is True

    # raise the exception
    try:
        raise my_exception
    except SanicException as e:
        assert e.status_code == 400
        assert e.quiet is True

# Generated at 2022-06-12 08:48:13.092351
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeapot(SanicException):
        pass

    assert 418 in _sanic_exceptions
    assert _sanic_exceptions[418] == IAmATeapot

# Generated at 2022-06-12 08:48:21.711424
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(403) is add_status_code(403, quiet=False)
    assert add_status_code(403, quiet=True) is add_status_code(403, quiet=True)
    assert add_status_code(403, quiet=False) is not add_status_code(403, quiet=True)
    assert add_status_code(403) is not add_status_code(403, quiet=False)
    assert add_status_code(403) is not add_status_code(403, quiet=True)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:23.441327
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class C(SanicException):
        pass
    assert issubclass(C, SanicException)
    assert C().status_code == 404

# Generated at 2022-06-12 08:48:30.165810
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(603)
    class Goodbye(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    assert _sanic_exceptions[603] == Goodbye



# Generated at 2022-06-12 08:48:33.270319
# Unit test for function add_status_code
def test_add_status_code():
    assert SanicException.status_code is None
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503
    assert ServiceUnavailable.quiet is True


# Unit tests for class SanicException

# Generated at 2022-06-12 08:48:54.806231
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(200, quiet=True)
    assert _sanic_exceptions[200].status_code == 200

    with pytest.raises(Exception) as e:
        add_status_code(400)  # ToDo: Replace Exception with specific one
        assert "is already used" in str(e.value)



# Generated at 2022-06-12 08:48:58.782298
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(409)
    class Conflict(SanicException):
        pass

    assert StatusCodeException.__class__.__name__ == 'StatusCodeException'
    assert _sanic_exceptions[409] == Conflict
    assert Conflict.__name__ == 'Conflict'


# Generated at 2022-06-12 08:49:06.547326
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Error(SanicException):
        pass
    assert Error.status_code == 400
    assert Error in _sanic_exceptions.values()
    try:
        raise Error
    except Error as e:
        assert e.status_code == 400
        assert e.message is None
        assert e.__class__ == Error
    try:
        raise Error('message')
    except Error as e:
        assert e.status_code == 400
        assert e.message == 'message'
        assert e.__class__ == Error
    @add_status_code(405)
    class MethodNotSupported(SanicException):
        def __init__(self, message, method, allowed_methods):
            super().__init__(message)

# Generated at 2022-06-12 08:49:17.151886
# Unit test for function add_status_code

# Generated at 2022-06-12 08:49:20.427369
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.exceptions import TEST_EXCEPTION
    add_status_code(599)(TEST_EXCEPTION)
    assert TEST_EXCEPTION.status_code == 599
    assert 599 in _sanic_exceptions

# Generated at 2022-06-12 08:49:26.305303
# Unit test for function add_status_code
def test_add_status_code():
    # Test 1: Success
    @add_status_code(100)
    class TestException(Exception):
        pass
    assert TestException.status_code == 100

    # Test 2: Failure
    try:
        @add_status_code(100)
        class TestException2(Exception):
            pass
    except:
        assert True
    else:
        assert False


if __name__ == "__main__":
    # Unit test for function add_status_code
    test_add_status_code()

# Generated at 2022-06-12 08:49:31.026105
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(Exception):
        pass
    assert _sanic_exceptions[200] is MyException
    assert issubclass(_sanic_exceptions[200], SanicException)
    assert _sanic_exceptions[200]().status_code == 200


# Generated at 2022-06-12 08:49:39.684383
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=missing-docstring
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass
    assert TestException2.status_code == 500
    assert TestException2.quiet == False

    @add_status_code(501)
    class TestException3(SanicException):
        pass
    assert TestException3.status_code == 501
    assert TestException3.quiet == True

# Generated at 2022-06-12 08:49:42.430286
# Unit test for function add_status_code
def test_add_status_code():
    assert NotFound.status_code == 404
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503



# Generated at 2022-06-12 08:49:49.800584
# Unit test for function add_status_code
def test_add_status_code():
    # Use add_status_code decorator function
    @add_status_code(status_code=400, quiet=False)
    class TestSanicException(SanicException):
        pass

    status_code = 400
    message = "Test Message"

    # Raise exception of class TestSanicException
    with pytest.raises(TestSanicException):
        raise TestSanicException(message=message, status_code=status_code)

    # Assert exception status code
    with pytest.raises(TestSanicException) as raised:
        raise TestSanicException(message=message, status_code=status_code)
    assert raised.value.status_code == status_code

    # Assert exception message

# Generated at 2022-06-12 08:50:33.203868
# Unit test for function add_status_code
def test_add_status_code():
    # Add an exception, test if it has been added
    @add_status_code(501)
    class NotImplementedError(SanicException):
        pass

    assert NotImplementedError.status_code == 501
    assert NotImplementedError(message="Not implemented").status_code == 501
    assert _sanic_exceptions[501] == NotImplementedError
    
    # Add an exception, test if it has been added (with quiet=False)
    @add_status_code(502, quiet=False)
    class BadGateway(SanicException):
        pass

    assert BadGateway.status_code == 502
    assert BadGateway(message="Bad gateway!").status_code == 502
    assert not hasattr(BadGateway(message="Bad gateway!"), "quiet")
    assert _sanic_exceptions

# Generated at 2022-06-12 08:50:36.185739
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class CustomError(SanicException):
        pass
    assert _sanic_exceptions.get(444, None) == CustomError

# Generated at 2022-06-12 08:50:43.359313
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest.status_code == 400
    assert BadRequest in _sanic_exceptions.values()

    assert _sanic_exceptions[400] is BadRequest
    assert BadRequest is type(_sanic_exceptions[400]())

    @add_status_code(500, True)
    class InternalServerErrorQuiet(SanicException):
        pass

    assert InternalServerErrorQuiet.quiet is True

    @add_status_code(500, False)
    class InternalServerErrorNoisy(SanicException):
        pass

    assert InternalServerErrorNoisy.quiet is False



# Generated at 2022-06-12 08:50:46.993346
# Unit test for function add_status_code
def test_add_status_code():
    global SanicException
    SanicException = SanicException
    class TestClass(SanicException):
        pass

    SanicException = TestClass
    add_status_code(418)(TestClass)

    assert TestClass.status_code == 418

# Generated at 2022-06-12 08:50:54.495854
# Unit test for function add_status_code
def test_add_status_code():
    """
    Confirm add_status_code works as expected.
    """

    @add_status_code(200)
    class TestStatusCode:
        pass

    @add_status_code(201)
    class TestStatusCodeQuiet:
        pass

    @add_status_code(202, quiet=False)
    class TestStatusCodeNoisy:
        pass

    assert TestStatusCode.status_code == 200
    assert TestStatusCode.quiet is None
    assert TestStatusCodeQuiet.status_code == 201
    assert TestStatusCodeQuiet.quiet is True
    assert TestStatusCodeNoisy.status_code == 202
    assert TestStatusCodeNoisy.quiet is False



# Generated at 2022-06-12 08:50:57.182086
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass

    assert add_status_code(100)(A)
    assert A.status_code == 100


# Generated at 2022-06-12 08:51:09.441779
# Unit test for function add_status_code
def test_add_status_code():
    class _Test1(SanicException):
        pass

    # status_code = None
    assert _Test1.status_code is None
    assert _Test1.quiet is None
    assert _Test1.__doc__ == 'SanicException\n    '

    # status_code != None
    class _Test2(SanicException):
        status_code = 999
        quiet = True

    assert _Test2.status_code == 999
    assert _Test2.quiet is True
    assert _Test2.__doc__ == 'SanicException\n    '

    # status_code defined by function add_status_code
    class _Test3(SanicException):
        pass

    _Test3 = add_status_code(404)(_Test3)

    assert _Test3.status_code == 404

# Generated at 2022-06-12 08:51:14.049968
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=501)
    class NotImplementedException(SanicException):
        pass
    exception = NotImplementedException("Custom exception")
    assert exception.status_code == 501



# Generated at 2022-06-12 08:51:24.225332
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass

    assert 999 in _sanic_exceptions
    assert _sanic_exceptions[999] == TestException
    assert TestException.status_code == 999
    assert TestException.quiet is True

    assert add_status_code(999)(TestException) == TestException
    assert _sanic_exceptions[999] == TestException

    # Danger! Defining the same status code twice will overwrite the old code
    @add_status_code(999)
    class TestException(SanicException):
        pass

    assert 999 in _sanic_exceptions
    assert _sanic_exceptions[999] == TestException
    assert TestException.quiet is True


# Generated at 2022-06-12 08:51:34.225979
# Unit test for function add_status_code
def test_add_status_code():
    # These are just the status codes at the end of Jan 2020:
    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[400] is InvalidUsage
    assert _sanic_exceptions[405] is MethodNotSupported
    assert _sanic_exceptions[500] is ServerError
    assert _sanic_exceptions[503] is ServiceUnavailable, "No 503 entry"
    assert _sanic_exceptions[408] is RequestTimeout
    assert _sanic_exceptions[413] is PayloadTooLarge, "No 413 entry"
    assert _sanic_exceptions[416] is ContentRangeError
    assert _sanic_exceptions[417] is HeaderExpectationFailed
    assert _sanic_exceptions[403] is Forbidden, "No 403 entry"
    assert _sanic_ex

# Generated at 2022-06-12 08:52:53.131265
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(101)(SanicException)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-12 08:52:54.092888
# Unit test for function add_status_code
def test_add_status_code():
  assert type(abort(500)) == ServerError

# Generated at 2022-06-12 08:53:04.464062
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        def __init__(self, msg):
            super().__init__(msg)

    @add_status_code(400)
    class TestException2(SanicException):
        pass

    assert STATUS_CODES[400] == b'Bad Request'
    assert STATUS_CODES[401] == b'Unauthorized'

    try:
        raise TestException('test')
    except SanicException as e:
        pass
    assert e.status_code == 500

    try:
        raise TestException2('test')
    except SanicException as e:
        pass
    assert e.status_code == 400
    assert e.quiet == True


# Generated at 2022-06-12 08:53:14.002247
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class StatusCode200(SanicException):
        pass

    @add_status_code(300)
    class StatusCode300(SanicException):
        pass

    @add_status_code(500)
    class StatusCode500(SanicException):
        pass

    @add_status_code(400)
    class StatusCode400(SanicException):
        pass

    @add_status_code(400, quiet=True)
    class StatusCode400Quiet(SanicException):
        pass

    assert issubclass(StatusCode200, SanicException)
    assert issubclass(StatusCode500, SanicException)
    assert issubclass(StatusCode300, SanicException)
    assert issubclass(StatusCode400, SanicException)
    assert _sanic_exceptions

# Generated at 2022-06-12 08:53:17.704737
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class MyException(SanicException):
        pass

    assert 501 == MyException().status_code
    assert 501 == MyException.status_code
    assert _sanic_exceptions[501] is MyException

# Generated at 2022-06-12 08:53:20.098576
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class TestError(SanicException):
        pass
    
    assert TestError.status_code == 1

# Generated at 2022-06-12 08:53:30.687074
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TempClass1(SanicException):
        pass

    assert 400 in _sanic_exceptions.keys()
    assert TempClass1 == _sanic_exceptions[400]

    @add_status_code(500, quiet=True)
    class TempClass2(SanicException):
        pass

    assert TempClass2 == _sanic_exceptions[500]
    assert TempClass2().quiet == True

    @add_status_code(500, quiet=False)
    class TempClass3(SanicException):
        pass

    assert TempClass3 == _sanic_exceptions[500]
    assert TempClass3().quiet == False

    @add_status_code(404, quiet=None)
    class TempClass4(SanicException):
        pass

    assert TempClass4

# Generated at 2022-06-12 08:53:37.831957
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(555)
    class Test_status(SanicException):
        pass

    try:
        raise Test_status("test")
    except Test_status as ex:
        assert ex.status_code == 555
        assert str(ex) == "test"

    @add_status_code(666, quiet=True)
    class Test_status2(SanicException):
        pass

    try:
        raise Test_status2("test11")
    except Test_status2 as ex:
        assert ex.status_code == 666
        assert str(ex) == "test11"
        assert ex.quiet == True

    @add_status_code(777, quiet=False)
    class Test_status3(SanicException):
        pass


# Generated at 2022-06-12 08:53:42.805251
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestClass(SanicException):
        pass

    class TestClass2(SanicException):
        pass

    assert _sanic_exceptions[404] == TestClass
    with pytest.raises(SanicException):
        class TestClass2:
            pass
        add_status_code(401)(TestClass2)



# Generated at 2022-06-12 08:53:45.150966
# Unit test for function add_status_code
def test_add_status_code():
    try:
        @add_status_code(200)
        class CustomException(SanicException):
            pass
    except Exception:
        assert False
    else:
        assert True