

# Generated at 2022-06-12 08:44:34.493661
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestStatusCode(NotFound):
        pass

    assert TestStatusCode.status_code == 404

# Generated at 2022-06-12 08:44:44.523035
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    # Add status_code 404 and 405
    add_status_code(404)(MyException)
    add_status_code(405, quiet=True)(MyException)
    # Make sure we have the correct classes for these codes
    assert _sanic_exceptions[404] == MyException
    assert _sanic_exceptions[405] == MyException
    assert MyException.status_code == 404
    assert MyException(message="msg").status_code == 404
    assert MyException(message="msg").quiet == False
    assert MyException(message="msg", status_code=405).status_code == 405
    assert MyException(message="msg", status_code=405).quiet == True

# Generated at 2022-06-12 08:44:52.522434
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class RequestTimeout(SanicException):
        """The Web server (running the Web site) thinks that there has been too
        long an interval of time between 1) the establishment of an IP
        connection (socket) between the client and the server and
        2) the receipt of any data on that socket, so the server has dropped
        the connection. The socket connection has actually been lost - the Web
        server has 'timed out' on that particular socket connection.
        """

        pass
    # Test if RequestTimeout class is added to status_code
    assert RequestTimeout in _sanic_exceptions
    # Test if RequestTimeout is added with code 408
    assert RequestTimeout.status_code == 408



# Generated at 2022-06-12 08:45:01.355767
# Unit test for function add_status_code
def test_add_status_code():
    '''
    add_status_code 是一个装饰器，用于为SanicException添加异常。
    '''
    @add_status_code(100)
    class SanicException100(SanicException):
        pass

    assert(SanicException100.status_code == 100)
    assert(_sanic_exceptions[100] is SanicException100)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:11.983075
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test add_status_code, checking that it's properly setting the
    status code and quiet flag.
    """

    class FooException(SanicException):
        pass

    # Test a new exception type with a new status code
    add_status_code(418)(FooException)
    assert _sanic_exceptions[418] is FooException
    assert FooException.quiet

    # Test a new status code with an existing exception type
    add_status_code(404)(ServerError)
    assert _sanic_exceptions[404] is ServerError
    assert not ServerError.quiet

    # Test updating a status code to a different exception type
    add_status_code(418)(ServerError)
    assert _sanic_exceptions[418] is ServerError
    assert ServerError.quiet

# Generated at 2022-06-12 08:45:18.725327
# Unit test for function add_status_code
def test_add_status_code():
    try:
        class MyException(SanicException):
            pass
    except NameError:
        MyException = SanicException
    assert MyException.status_code is None
    assert MyException.quiet is None
    assert MyException().status_code is None
    assert MyException().quiet is None

    MyException = add_status_code(999)(MyException)
    assert MyException.status_code == 999
    assert MyException.quiet is None
    assert MyException().status_code == 999
    assert MyException().quiet is None

    MyException = add_status_code(500, quiet=True)(MyException)
    assert MyException.status_code == 500
    assert MyException.quiet is True
    assert MyException().status_code == 500
    assert MyException().quiet is True


# Generated at 2022-06-12 08:45:20.571887
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert _sanic_exceptions[400] is MyException



# Generated at 2022-06-12 08:45:27.496393
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class CustomException(SanicException):
        """
        **Status**: 501 Not Implemented
        """

        pass

    assert issubclass(CustomException, SanicException)
    assert CustomException.status_code == 501
    assert CustomException.__doc__ == "**Status**: 501 Not Implemented"
    c = CustomException("hello")
    assert c.status_code == 501
    assert c.__str__() == "hello"



# Generated at 2022-06-12 08:45:36.121974
# Unit test for function add_status_code
def test_add_status_code():
    # when decorate class with status_code, the class will be added to the _sanic_exceptions dict
    # with the code as key and the class as value
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable

    # Given the status code, get the corresponding class
    assert abort(404) == NotFound
    assert abort(400) == InvalidUsage
    assert abort(405) == MethodNotSupported
    assert abort(500) == ServerError
    assert abort(503) == ServiceUnavailable
    # When the status_code does not exist in the dict, it will return the San

# Generated at 2022-06-12 08:45:45.462049
# Unit test for function add_status_code
def test_add_status_code():
    print("test add_status_code")
    @add_status_code(400)
    class DemoException(SanicException):
        pass
    
    assert DemoException.status_code == 400
    assert DemoException().status_code == 400
    assert DemoException().message == 'DemoException'
    assert DemoException('kao').message == 'kao'
    
    # run demo class
    try:
        raise DemoException()
    except DemoException as e:
        pass
        print(f'{e}: {e.status_code}')
    except:
        pass


# Generated at 2022-06-12 08:45:58.679718
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        status_code = 400

    assert TestException.status_code == 400
    assert TestException.quiet == False

    @add_status_code(400, quiet=False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 400
    assert TestException2.quiet == False

    @add_status_code(404)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 404
    assert TestException3.quiet == True

    @add_status_code(500)
    class TestException4(SanicException):
        pass

    assert TestException4.status_code == 500
    assert TestException4.quiet == False



# Generated at 2022-06-12 08:46:07.259305
# Unit test for function add_status_code
def test_add_status_code():
    class Test(SanicException):
        pass
    add_status_code(500)(Test)
    assert Test.status_code == 500
    add_status_code(400, quiet=False)(Test)
    assert Test.status_code == 400
    assert Test.quiet == False
    add_status_code(200, quiet=True)(Test)
    assert Test.status_code == 200
    assert Test.quiet == True
    add_status_code(200)(Test)
    assert Test.status_code == 200
    assert Test.quiet == True
    add_status_code(200, quiet=None)(Test)
    assert Test.status_code == 200
    assert Test.quiet == False

# Generated at 2022-06-12 08:46:16.190953
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(200)
    class CustomSanicException(SanicException):
        pass

    assert _sanic_exceptions[200] is CustomSanicException
    assert _sanic_exceptions[201] is not CustomSanicException
    assert _sanic_exceptions[202] is not CustomSanicException
    assert _sanic_exceptions[203] is not CustomSanicException
    assert _sanic_exceptions[204] is not CustomSanicException
    assert _sanic_exceptions[205] is not CustomSanicException
    assert _sanic_exceptions[206] is not CustomSanicException

    @add_status_code(206)
    class CustomSanicExceptionTwo(SanicException):
        pass

    assert _sanic_exceptions[200] is CustomSanicException
    assert _san

# Generated at 2022-06-12 08:46:26.690264
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502, quiet=True)
    class BadGateway(SanicException):
        pass
    # test the class added
    assert issubclass(_sanic_exceptions[502], SanicException)
    assert _sanic_exceptions[502] == BadGateway
    assert _sanic_exceptions[502].status_code == 502
    assert _sanic_exceptions[502].quiet == True

    @add_status_code(501)
    class BadGateway(SanicException):
        pass

    assert issubclass(_sanic_exceptions[501], SanicException)
    assert _sanic_exceptions[501] == BadGateway
    assert _sanic_exceptions[501].status_code == 501
    assert _sanic_exceptions[501].quiet == False

# Generated at 2022-06-12 08:46:30.687896
# Unit test for function add_status_code
def test_add_status_code():

    # test class_decorator
    @add_status_code(555)
    class TestClass(SanicException):
        pass

    # test function return value
    assert isinstance(add_status_code(555)(TestClass), TestClass)



# Generated at 2022-06-12 08:46:36.887440
# Unit test for function add_status_code
def test_add_status_code():
    class_decorator = add_status_code(201)
    assert class_decorator
    assert callable(class_decorator)

    class SanicException:
        def __init__(self, message, status_code=None):
            self.status_code = status_code

    @class_decorator
    class TestException(SanicException):
        pass

    assert TestException.status_code == 201
    assert TestException in _sanic_exceptions.values()

# Generated at 2022-06-12 08:46:47.088329
# Unit test for function add_status_code
def test_add_status_code():
    class TestSanicException(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

    assert 405 not in _sanic_exceptions

    @add_status_code(405)
    class TestSanicException2(TestSanicException):
        """
        **Status**: 405 Method Not Allowed
        """

        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}

    assert 405 in _sanic_exceptions
    assert _sanic_exceptions[405] is TestSanicException2



# Generated at 2022-06-12 08:46:51.459153
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        _sanic_exceptions[404]

    @add_status_code(404)
    class UselessException(SanicException):
        pass

    assert UselessException.status_code == 404
    assert _sanic_exceptions[404] is not None

# Generated at 2022-06-12 08:46:57.780903
# Unit test for function add_status_code
def test_add_status_code():
    """
    this method is for unit test add_status_code
    """
    @add_status_code(222)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 222
    assert _sanic_exceptions[222] == TestException
    assert issubclass(TestException, SanicException)

    try:
        raise TestException
    except SanicException:
        pass
    else:
        assert False


if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:47:00.981651
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(888)
    class CustomException(Exception):
        pass
    assert issubclass(CustomException, SanicException)
    assert CustomException.status_code == 888
    assert CustomException.quiet == True

# Generated at 2022-06-12 08:47:07.661835
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class CustomError(SanicException):
        pass
    assert _sanic_exceptions[500] == CustomError

# Generated at 2022-06-12 08:47:18.396116
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    other_exception = add_status_code(402, quiet=True)(SanicException)
    my_exception = add_status_code(403, quiet=False)(MyException)

    assert isinstance(other_exception, SanicException)
    assert other_exception.quiet is True

    assert isinstance(my_exception, MyException)
    assert my_exception.quiet is False

    assert other_exception.status_code == 402
    assert my_exception.status_code == 403


# Generated at 2022-06-12 08:47:28.967277
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402)
    class TestException(SanicException):
        pass
    exc = TestException("Test Exception")
    assert exc.status_code == 402
    assert exc.quiet is None
    assert _sanic_exceptions[402] == TestException

    @add_status_code(403)
    class TestException(SanicException):
        pass
    exc = TestException("Test Exception")
    assert exc.status_code == 403
    assert exc.quiet is True
    assert _sanic_exceptions[403] == TestException

    @add_status_code(403, quiet=False)
    class TestException(SanicException):
        pass
    exc = TestException("Test Exception")
    assert exc.status_code == 403
    assert exc.quiet is False

# Generated at 2022-06-12 08:47:38.578405
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(456)
    class A(SanicException): pass

    @add_status_code(123, quiet=True)
    class B(SanicException): pass

    @add_status_code(789, quiet=False)
    class C(SanicException): pass

    @add_status_code(456)
    class D(SanicException): pass

    assert not hasattr(A, 'quiet')
    assert B.quiet
    assert not C.quiet
    assert A.status_code == 456
    assert B.status_code == 123
    assert C.status_code == 789
    assert D.status_code == 456

    # fail to override status_code

# Generated at 2022-06-12 08:47:49.327111
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException100(SanicException):
        pass

    assert TestException100.status_code == 100

    @add_status_code(200)
    class TestException200(SanicException):
        pass

    assert TestException200.status_code == 200
    assert TestException200.quiet is False

    @add_status_code(200, True)
    class TestException200_quiet(SanicException):
        pass

    assert TestException200_quiet.status_code == 200
    assert TestException200_quiet.quiet is True

    @add_status_code(200, False)
    class TestException200_quiet_not(SanicException):
        pass

    assert TestException200_quiet_not.status_code == 200
    assert TestException200_quiet_not.quiet is False

# Generated at 2022-06-12 08:47:55.690596
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(456)
    class TestCode(SanicException):
        pass

    assert TestCode.status_code == 456
    assert _sanic_exceptions[456] == TestCode

    @add_status_code(456, quiet=True)
    class TestCode2(SanicException):
        pass

    assert TestCode2.status_code == 456
    assert TestCode2.quiet is True
    assert _sanic_exceptions[456] == TestCode2



# Generated at 2022-06-12 08:47:58.491868
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(NotFound):
        raise NotFound()
    with pytest.raises(InvalidUsage):
        raise InvalidUsage()
    with pytest.raises(ServerError):
        raise ServerError()


# Generated at 2022-06-12 08:48:05.260301
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestSanicException(SanicException):
        pass

    assert TestSanicException.status_code == 200
    assert _sanic_exceptions[200].__name__ == 'TestSanicException'
    assert _sanic_exceptions[200].__module__ == 'sanic.exceptions'
    assert _sanic_exceptions[200]().status_code == 200



# Generated at 2022-06-12 08:48:09.773663
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions

    assert len(_sanic_exceptions) == 0
    code = 418
    add_status_code(code)

    assert len(_sanic_exceptions) == 1
    assert code in _sanic_exceptions

    _sanic_exceptions = {}



# Generated at 2022-06-12 08:48:13.349542
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1, quiet=False)
    class MyNewException(SanicException):
        pass

    assert MyNewException.status_code == 1
    assert MyNewException.quiet is False



# Generated at 2022-06-12 08:48:29.497984
# Unit test for function add_status_code
def test_add_status_code():
    try:
        @add_status_code(410)
        class Gone(SanicException):
            pass
    except Exception as e:
        assert False, e
    assert _sanic_exceptions[410] == Gone
    assert Gone.status_code == 410

    try:
        @add_status_code(410, True)
        class Gone(SanicException):
            pass
    except Exception as e:
        assert False, e
    assert _sanic_exceptions[410] == Gone
    assert Gone.status_code == 410
    assert Gone.quiet

    try:
        @add_status_code(401)
        class MyUnauthorized(SanicException):
            pass
    except Exception as e:
        assert False, e
    assert _sanic_exceptions[401] == MyUnauthorized
   

# Generated at 2022-06-12 08:48:31.501226
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-12 08:48:33.482645
# Unit test for function add_status_code
def test_add_status_code():
    assert SanicException(message="test SanicException", status_code=404, quiet=None) == \
            abort(404, message="test SanicException")

# Generated at 2022-06-12 08:48:37.515773
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class SomeException(SanicException):
        pass

    assert SomeException.status_code == 200
    s = SomeException("some message")
    assert s.status_code == 200
    assert s.message == "some message"


# Unit tests for class SanicException

# Generated at 2022-06-12 08:48:39.443309
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass
    assert isinstance(MyException().__class__, SanicException)
    assert MyException.status_code == 404
    assert _sanic_exceptions[404] == MyException

# Generated at 2022-06-12 08:48:49.343774
# Unit test for function add_status_code
def test_add_status_code():
    """
    SanicException.__init__ add a default status code only for
    internal status codes
    """
    # for internal SanicException
    assert add_status_code(200)(SanicException)(
        "test_message"
    ).status_code == 200
    # for internal SanicException
    assert add_status_code(200)(SanicException)(
        "test_message", status_code=200
    ).status_code == 200
    # for given SanicException
    assert add_status_code(200)(SanicException)(
        "test_message", status_code=201
    ).status_code == 201


if __name__ == "__main__":
    try:
        test_add_status_code()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 08:48:56.820920
# Unit test for function add_status_code
def test_add_status_code():
    # Define a custom exception class
    @add_status_code(501)
    class NotImplemented(SanicException):
        """
        **Status**: 501 Not Implemented

        The server either does not recognize the request method.
        """
        pass

    assert NotImplemented.status_code == 501

    # Raise the custom exception
    try:
        raise NotImplemented("Not Implemented")
    except SanicException as e:
        assert e.status_code == 501
        assert str(e) == "Not Implemented"

# Generated at 2022-06-12 08:48:59.802740
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 400
    assert issubclass(_sanic_exceptions[400], CustomException)


# Unit tests for function abort

# Generated at 2022-06-12 08:49:02.115191
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        assert cls.status_code == 400
        assert cls.quiet == True
        _sanic_exceptions[400] = cls
        return cls

    assert add_status_code(400, quiet=True) == test_class_decorator

# Generated at 2022-06-12 08:49:04.105823
# Unit test for function add_status_code
def test_add_status_code():
    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-12 08:49:26.860209
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(7)
    class PottyMouth(SanicException):

        '''
        **Status**: 7 Potty Mouth

        Someone is having a bad day.
        '''
        pass

    assert PottyMouth.status_code == 7
    assert PottyMouth.quiet is None
    assert PottyMouth.__doc__ == '**Status**: 7 Potty Mouth\n\nSomeone is having a bad day.'

    @add_status_code(500, False)
    class NotMyFault(SanicException):

        '''
        **Status**: 500 Not my fault

        I saw someone else do it.
        '''

        pass

    assert NotMyFault.status_code == 500
    assert NotMyFault.quiet is False

# Generated at 2022-06-12 08:49:33.238215
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class MockedException(SanicException):
        # Unit test for function add_status_code
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)

    me = MockedException(message="Testing")
    assert me.status_code == 600
    assert me.message == "Testing"
    assert _sanic_exceptions[600] == MockedException

# Generated at 2022-06-12 08:49:39.699758
# Unit test for function add_status_code

# Generated at 2022-06-12 08:49:43.462224
# Unit test for function add_status_code
def test_add_status_code():
    code = 999
    @add_status_code(code)
    class _test_exception(SanicException):
        pass
    assert _test_exception.status_code == code
    assert _test_exception('').status_code == code
    assert _test_exception('', status_code=code).status_code == code
    ex = _test_exception('', status_code=code)
    assert ex.status_code == code
    assert ex.status_code == ex.status_code
    assert len(_sanic_exceptions) == code
    assert _sanic_exceptions[code] is _test_exception

# Generated at 2022-06-12 08:49:50.113718
# Unit test for function add_status_code
def test_add_status_code():
    # Test base functionality
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    assert _sanic_exceptions[400] == CustomException
    assert CustomException.status_code == 400
    assert CustomException('').status_code == 400

    # Test overwrite
    @add_status_code(400, quiet=True)
    class CustomException(SanicException):
        pass

    assert _sanic_exceptions[400] == CustomException
    assert CustomException.status_code == 400
    assert CustomException('').status_code == 400
    assert CustomException('').quiet is True

    # Test default quiet
    @add_status_code(500)
    class CustomException(SanicException):
        pass

    assert _sanic_exceptions[500] == CustomException

# Generated at 2022-06-12 08:49:59.541714
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass
    a = A()
    try:
        raise a
    except SanicException as e:
        assert e.status_code is None
        assert a.status_code is None

    # disable the quiet attribute for status code 500
    class B(SanicException):
        pass
    b = B()
    try:
        raise b
    except SanicException as e:
        assert e.status_code is None
        assert b.status_code is None
        assert b.quiet is True

    # enable the quiet attribute for status code 500
    class C(SanicException):
        pass
    c = C()
    try:
        raise c
    except SanicException as e:
        assert e.status_code is None
        assert c.status_code is None

# Generated at 2022-06-12 08:50:05.701015
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

    assert CustomException.status_code == 400
    assert CustomException().status_code == 400

    try:
        raise CustomException("custom error")
    except SanicException as ex:
        assert ex.status_code == 400

# Generated at 2022-06-12 08:50:15.039996
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet is None

    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest.status_code == 400
    assert BadRequest.quiet is True

    @add_status_code(300, quiet=False)
    class Redirection(SanicException):
        pass

    assert Redirection.status_code == 300
    assert Redirection.quiet is False

if __name__ == "__main__":
    pytest.main(["-v", "-s", __file__])

# Generated at 2022-06-12 08:50:18.868420
# Unit test for function add_status_code
def test_add_status_code():
    class TestStatusException(SanicException):
        pass

    exception = add_status_code(123)(TestStatusException)
    assert exception.status_code == 123
    assert exception.quiet is None

    exception = add_status_code(123, quiet=True)(TestStatusException)
    assert exception.status_code == 123
    assert exception.quiet is True



# Generated at 2022-06-12 08:50:23.733120
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    @add_status_code(500, True)
    class CustomException500(SanicException):
        pass

    assert CustomException().status_code == 400
    assert CustomException500().status_code == 500
    assert CustomException500().quiet is True

# Generated at 2022-06-12 08:50:58.843078
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 404
    assert type(MyException('ignore')) is MyException
    # Check that the exception is registered in the _sanic_exceptions dict
    assert _sanic_exceptions[404] is MyException

# Generated at 2022-06-12 08:51:07.940223
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException(SanicException):
        pass
    assert TestException in _sanic_exceptions.values()
    assert TestException.status_code == 404
    assert _sanic_exceptions[404] == TestException
    assert _sanic_exceptions[404] is not TestException

    @add_status_code(405)
    class TestException(SanicException):
        pass
    assert TestException in _sanic_exceptions.values()
    assert TestException.status_code == 405
    assert _sanic_exceptions[405] == TestException

# Generated at 2022-06-12 08:51:17.961846
# Unit test for function add_status_code
def test_add_status_code():

    def decorator_for_200(cls):
        cls.status_code = 200

        return cls
    # decrat the 200
    @decorator_for_200
    class Do:
        pass
    assert Do.status_code == 200
    assert not hasattr(Do, 'quiet')
    # decrat the 201
    @add_status_code(201)
    class Do:
        pass
    assert Do.status_code == 201
    assert Do.quiet is True
    # decrat the 500
    @add_status_code(500)
    class Do:
        pass
    assert Do.status_code == 500
    assert not hasattr(Do, 'quiet')
    # decrat the 500
    @add_status_code(500,quiet=True)
    class Do:
        pass

# Generated at 2022-06-12 08:51:20.564060
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestNotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == TestNotFound



# Generated at 2022-06-12 08:51:25.651962
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402)
    class PaymentRequired(SanicException):
        """
        **Status**: 402 Payment Required
        """
        pass

    try:
        raise PaymentRequired(message="Unable to make payment")
    except PaymentRequired as e:
        assert e.status_code == 402

# Generated at 2022-06-12 08:51:34.753962
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized


# Generated at 2022-06-12 08:51:39.582470
# Unit test for function add_status_code
def test_add_status_code():
    # add new status code 1001
    @add_status_code(1001)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 1001

    # add new status code 1002
    @add_status_code(1002)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 1002



# Generated at 2022-06-12 08:51:42.601412
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100, quiet=True)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[100] is TestException
    assert TestException.quiet is True

# Generated at 2022-06-12 08:51:47.385980
# Unit test for function add_status_code
def test_add_status_code():
    # SanicException
    assert 500 in _sanic_exceptions
    assert _sanic_exceptions[500] is ServerError
    assert ServerError.quiet is False
    # NotFound
    assert 404 in _sanic_exceptions
    assert _sanic_exceptions[404] is NotFound
    assert NotFound.quiet is True

# Generated at 2022-06-12 08:51:51.120966
# Unit test for function add_status_code
def test_add_status_code():
    class NotFound(SanicException):
        pass
    code = 404
    quiet = None
    class NotFound(SanicException):
        pass
    assert(NotFound.status_code == code)
    assert(NotFound.quiet == quiet)
    

# Generated at 2022-06-12 08:53:09.979025
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, quiet=True)
    class Custom400Exception(SanicException):
        pass
    @add_status_code(400)
    class Custom400Exception2(SanicException):
        pass
    @add_status_code(500, quiet=True)
    class Custom500Exception(SanicException):
        pass
    @add_status_code(500)
    class Custom500Exception2(SanicException):
        pass
    assert _sanic_exceptions[400].quiet == True
    assert _sanic_exceptions[400].__name__ == "Custom400Exception"
    assert _sanic_exceptions[500].quiet == False
    assert _sanic_exceptions[500].__name__ == "Custom500Exception2"

# Generated at 2022-06-12 08:53:13.212706
# Unit test for function add_status_code
def test_add_status_code():
    class ExampleException(SanicException):
        pass

    add_status_code(123, quiet=True)(ExampleException)

    assert _sanic_exceptions[123] == ExampleException
    assert ExampleException.status_code == 123
    assert ExampleException.quiet == True


# Generated at 2022-06-12 08:53:20.196215
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(999)
    assert _sanic_exceptions[999].status_code == 999

    class TestException2(SanicException):
        pass

    add_status_code(998, quiet=False)(TestException2)
    assert _sanic_exceptions[998].status_code == 998

    class TestException3(SanicException):
        pass

    add_status_code(997, quiet=True)(TestException3)
    assert _sanic_exceptions[997].status_code == 997

# Generated at 2022-06-12 08:53:31.021478
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(Exception):
        pass

    add_status_code(408, quiet=True)(TestException)
    assert issubclass(TestException, SanicException)
    assert TestException.status_code == 408
    assert TestException.quiet is True
    assert _sanic_exceptions[408] == TestException
    assert issubclass(TestException, _sanic_exceptions[408])
    assert issubclass(_sanic_exceptions[408], SanicException)

    class TestException2(Exception):
        pass

    add_status_code(404)(TestException2)
    assert issubclass(TestException2, SanicException)
    assert TestException2.status_code == 404
    assert TestException2.quiet is False
    assert _sanic_exceptions[404] == TestException2
    assert issubclass

# Generated at 2022-06-12 08:53:37.950292
# Unit test for function add_status_code
def test_add_status_code():
    # Raise the SanicException with status code 204
    # If error occured, the test fails
    try:
        abort(204)
    except SanicException as e:
        assert e.status_code == 204
        assert not getattr(e, "quiet", False)
        assert e.message == STATUS_CODES[204].decode("utf-8")

    # Raise the SanicException with status code 404
    # If error occured, the test fails
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.quiet
        assert e.message == STATUS_CODES[404].decode("utf-8")

    # Raise the SanicException with status code 400
    # If error occured, the test fails

# Generated at 2022-06-12 08:53:43.273122
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class _401(SanicException):
        pass

    @add_status_code(500, quiet=True)
    class _500(SanicException):
        pass

    _sanic_exceptions[401].status_code == 401
    _sanic_exceptions[500].status_code == 500
    _sanic_exceptions[500].quiet == True

# Generated at 2022-06-12 08:53:45.613324
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class SanicExceptionCustom(SanicException):
        pass
    assert _sanic_exceptions[444] == SanicExceptionCustom

# Generated at 2022-06-12 08:53:54.922941
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[400] is InvalidUsage
    assert _sanic_exceptions[403] is Forbidden
    assert _sanic_exceptions[500] is ServerError
    assert _sanic_exceptions[503] is ServiceUnavailable

    # Test quiet
    assert _sanic_exceptions[404].quiet is True
    assert _sanic_exceptions[400].quiet is True
    assert _sanic_exceptions[403].quiet is True
    assert _sanic_exceptions[500].quiet is False
    assert _sanic_exceptions[503].quiet is True

# Generated at 2022-06-12 08:54:02.567390
# Unit test for function add_status_code
def test_add_status_code():
    # test for function add_status_code

    # add a new class
    @add_status_code(601)
    class MyException(Exception):
        pass

    # test class name
    assert _sanic_exceptions[601].__name__ == "MyException"

    # test status_code
    assert getattr(_sanic_exceptions[601], "status_code", None) == 601

    # test quiet
    assert not getattr(_sanic_exceptions[601], "quiet", False)
    assert getattr(_sanic_exceptions[404], "quiet", False)

    # test add class which has already existed
    with pytest.raises(KeyError):
        @add_status_code(404)
        class MyException(Exception):
            pass

# Generated at 2022-06-12 08:54:06.600676
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class SanicNotFound(SanicException):
        pass

    assert SanicNotFound.status_code == 404
    assert SanicNotFound.quiet is True
