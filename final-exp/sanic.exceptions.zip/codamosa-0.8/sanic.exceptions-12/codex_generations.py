

# Generated at 2022-06-12 08:44:36.447411
# Unit test for function add_status_code
def test_add_status_code():
    class Dummy(SanicException):
        pass
    assert add_status_code(500)(Dummy).status_code == 500
    assert add_status_code(500, False)(Dummy).quiet == False
    assert add_status_code(500, True)(Dummy).quiet == True


# Generated at 2022-06-12 08:44:44.010970
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 404
    assert MyException in _sanic_exceptions.values()

    # This will not change the status code, it's defined in the class
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 404
    assert MyException in _sanic_exceptions.values()



# Generated at 2022-06-12 08:44:53.034290
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert issubclass(_sanic_exceptions[400], SanicException)
    assert issubclass(MyException, SanicException)
    assert _sanic_exceptions[400] == MyException
    assert issubclass(InvalidUsage, SanicException)

    @add_status_code(503)
    class MyException(SanicException):
        pass

    assert issubclass(_sanic_exceptions[503], SanicException)
    assert issubclass(MyException, SanicException)
    assert _sanic_exceptions[503] == MyException
    assert issubclass(ServiceUnavailable, SanicException)

    # Automatic quiet attribute

# Generated at 2022-06-12 08:45:00.062896
# Unit test for function add_status_code
def test_add_status_code():
    # Adding status code 500
    @add_status_code(500)
    class Test(SanicException):
        pass

    assert _sanic_exceptions[500].__name__ == "Test"
    assert _sanic_exceptions[500].status_code == 500
    assert _sanic_exceptions[500].quiet == False

    # Adding status code 404
    @add_status_code(404)
    class Test(SanicException):
        pass

    assert _sanic_exceptions[404].__name__ == "Test"
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet == True



# Generated at 2022-06-12 08:45:12.300381
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is False

    @add_status_code(400, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is False

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False


# Generated at 2022-06-12 08:45:22.488396
# Unit test for function add_status_code
def test_add_status_code():
    def assert_exists(since, add_status_code_args, status_code, message, quiet):
        exc = _sanic_exceptions[status_code]
        assert issubclass(exc, SanicException), \
            f"Expected exception for status code {status_code} to be an instance of SanicException"

        assert exc.status_code == status_code, \
            f"Expected exception for status code {status_code} to have status_code {status_code}"

        assert exc(message).__str__() == message, \
            f"Expected exception for status code {status_code} to be callable via: exc('{message}')"

        assert exc.quiet == quiet, \
            f"Expected exception for status code {status_code} to have quiet == {quiet}"

    # these are the stat

# Generated at 2022-06-12 08:45:24.885498
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert issubclass(TestException, SanicException)
    assert _sanic_exceptions[400] == TestException


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:34.560653
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass

    class B(SanicException):
        pass

    class C(A):
        pass

    assert SanicException not in _sanic_exceptions.values()
    assert A not in _sanic_exceptions.values()
    assert B not in _sanic_exceptions.values()
    assert C not in _sanic_exceptions.values()

    @add_status_code(500)
    class A(SanicException):
        pass

    @add_status_code(501)
    class B(SanicException):
        pass

    @add_status_code(502)
    class C(A):
        pass

    assert isinstance(_sanic_exceptions[500](), SanicException)

# Generated at 2022-06-12 08:45:36.918609
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert _sanic_exceptions[502] == BadGateway



# Generated at 2022-06-12 08:45:39.464469
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class Foo(SanicException):
        pass

    assert bool(Foo.status_code) == True


# Generated at 2022-06-12 08:45:47.610806
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    assert InvalidUsage.status_code == 400

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert ServerError.status_code == 500

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    assert ServerError.status_code == 500
    assert ServerError.quiet == True


# Generated at 2022-06-12 08:45:58.395961
# Unit test for function add_status_code
def test_add_status_code():

    # Test adding a custom status code
    @add_status_code(517)
    class NewError(SanicException):
        pass

    # Test an unregistered status code
    with pytest.raises(SanicException) as e:
        abort(517)

    assert e.value.status_code == 517
    assert e.value.message == "Internal Server Error"
    assert not hasattr(e.value, "headers")

    # Test a registered status code
    with pytest.raises(NewError) as e:
        abort(517)

    assert e.value.status_code == 517
    assert e.value.message == "Internal Server Error"
    assert not hasattr(e.value, "headers")



# Generated at 2022-06-12 08:46:02.064561
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert _sanic_exceptions[418] == IAmATeaPot
    assert IAmATeaPot.status_code == 418

# Generated at 2022-06-12 08:46:11.915543
# Unit test for function add_status_code
def test_add_status_code():
    # Use a random status code to test
    status_code = 654

    @add_status_code(status_code)
    class TestException(SanicException):
        pass

    # Make sure the TestException is registered in _sanic_exceptions
    assert TestException == _sanic_exceptions[status_code]

    # Check the status_code and quiet attributes
    assert TestException.status_code == status_code
    assert TestException.quiet is True

    # Use a random status code to test
    status_code = 654

    @add_status_code(status_code, quiet=False)
    class TestException(SanicException):
        pass

    # Make sure the TestException is registered in _sanic_exceptions
    assert TestException == _sanic_exceptions[status_code]

    # Check the status_

# Generated at 2022-06-12 08:46:16.403094
# Unit test for function add_status_code
def test_add_status_code():
    class SanicExceptionT(SanicException):
        pass

    add_status_code(404)(SanicExceptionT)
    add_status_code(403)(SanicExceptionT)
    assert _sanic_exceptions[404].__name__ == "SanicExceptionT"
    assert _sanic_exceptions[403].__name__ == "SanicExceptionT"


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:18.852367
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1000)
    class _1000(SanicException):
        pass

    assert _1000.status_code == 1000
    _1000("x")


# Generated at 2022-06-12 08:46:20.568262
# Unit test for function add_status_code
def test_add_status_code():
    assert issubclass(ServerError, SanicException)
    assert ServerError.status_code == 500

# Generated at 2022-06-12 08:46:30.055254
# Unit test for function add_status_code
def test_add_status_code():
    class BaseException(Exception):
        status = None
    
    # add status code, with all the params. 
    BaseException = add_status_code(404, False)(BaseException)
    assert BaseException.status == 404
    assert BaseException.quiet == False

    # test to add status code, with no params given.
    BaseException = add_status_code(404)(BaseException)
    assert BaseException.status == 404
    assert BaseException.quiet == True

    # test to add null status code with no params given.
    BaseException = add_status_code(500)(BaseException)
    assert BaseException.status == 500
    assert BaseException.quiet == False

# Generated at 2022-06-12 08:46:32.982218
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class DemoException(SanicException):
        pass
    assert type(_sanic_exceptions[100]) == DemoException



# Generated at 2022-06-12 08:46:36.206380
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404, quiet=False)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 404
    assert TestException.quiet == False
    assert TestException.__name__ == "TestException"

# Generated at 2022-06-12 08:46:51.318421
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass

    class B(SanicException):
        pass

    class C(SanicException):
        pass

    add_status_code(404)(A)
    add_status_code(400)(B)
    add_status_code(501)(C)

    assert isinstance(A(), NotFound)
    assert isinstance(B(), InvalidUsage)
    assert isinstance(C(), SanicException)

    assert _sanic_exceptions[404] == A
    assert _sanic_exceptions[400] == B
    assert _sanic_exceptions[501] == C

    assert A.quiet is not False
    assert B.quiet is not False
    assert C.quiet is False


# Generated at 2022-06-12 08:46:56.374736
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        def __init__(self, message, status_code=200, quiet=None):
            super().__init__(message, status_code, quiet)

    new_exception = add_status_code(409)(CustomException)
    assert new_exception.status_code == 409
    assert new_exception(message='Testing').status_code == 409


# Generated at 2022-06-12 08:47:03.314228
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[404] is MyException
    assert MyException.status_code == 404
    assert MyException('Message').status_code == 404

    @add_status_code(408)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[408] is MyException
    assert MyException.status_code == 408
    assert MyException('Message').status_code == 408

test_add_status_code()

# Generated at 2022-06-12 08:47:07.129049
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass
    assert MyException.status_code == 200
    assert _sanic_exceptions[200] == MyException

# Generated at 2022-06-12 08:47:18.001554
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Exception200(SanicException):
        pass
    @add_status_code(200, quiet=True)
    class Exception200a(SanicException):
        pass
    @add_status_code(500, quiet=True)
    class Exception500(SanicException):
        pass
    assert issubclass(Exception200, SanicException)
    assert issubclass(Exception200a, SanicException)
    assert issubclass(Exception500, SanicException)
    assert Exception200.quiet is False
    assert Exception200a.quiet is True
    assert Exception500.quiet is True

    assert Exception200.status_code == 200
    assert Exception200a.status_code == 200
    assert Exception500.status_code == 500

# Generated at 2022-06-12 08:47:26.772335
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        """
        **Status**: 200 OK
        """

        pass

    assert Test('').status_code == 200
    assert Test('').quiet == True

    assert Test('', quiet = False).quiet == False
    assert Test('', quiet = True).quiet == True

    assert Test('', status_code = 400).status_code == 400
    assert Test('', quiet = False, status_code = 400).quiet == False
    assert Test('', quiet = True, status_code = 400).quiet == True


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:31.202764
# Unit test for function add_status_code
def test_add_status_code():
    def abc(cls):
        pass

    add_status_code(404)(abc)
    assert abc.__dict__['status_code'] == 404
    add_status_code(418,quiet = True)(abc)
    assert abc.__dict__['status_code'] == 418
    assert abc.__dict__['quiet'] == True
# Unit tests for class SanicException

# Generated at 2022-06-12 08:47:39.970550
# Unit test for function add_status_code
def test_add_status_code():
    # test default param
    assert(add_status_code(400) is add_status_code(400, None))
    # test with quiet=None
    assert(add_status_code(404) is add_status_code(404, None))
    assert(add_status_code(500) is not add_status_code(500, None))
    # test with bool value
    assert(add_status_code(400, False) is not add_status_code(400, True))
    assert(add_status_code(400) is not add_status_code(400, True))

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:43.502118
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class MyException(SanicException):
        pass
    assert MyException.status_code == 403
    assert _sanic_exceptions[403] == MyException

# Generated at 2022-06-12 08:47:48.544002
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 401

    # Test error case
    with pytest.raises(ValueError):
        @add_status_code(500, quiet=True)
        class TestException(SanicException):
            pass



# Generated at 2022-06-12 08:47:58.016352
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyNotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    assert MyNotFound.status_code == 404

# Generated at 2022-06-12 08:48:02.897679
# Unit test for function add_status_code
def test_add_status_code():
    code = 123

    @add_status_code(123, quiet=True)
    class MyException(SanicException):
        pass
    
    assert MyException.status_code == 123
    assert MyException.quiet == True
    assert _sanic_exceptions[123] == MyException

# Generated at 2022-06-12 08:48:09.177180
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class newSanicException(SanicException):
        pass

    @add_status_code(998,True)
    class newSanicException2(SanicException):
        pass

    assert newSanicException.status_code == 999
    assert newSanicException2.status_code == 998
    assert newSanicException.quiet == False
    assert newSanicException2.quiet == True

# Generated at 2022-06-12 08:48:11.250705
# Unit test for function add_status_code
def test_add_status_code():
    assert 404 in _sanic_exceptions, "NotFound not added to _sanic_exceptions"

# Generated at 2022-06-12 08:48:21.751708
# Unit test for function add_status_code
def test_add_status_code():

    code = 404

    def class_decorator(cls):
        cls.status_code = code
        _sanic_exceptions[code] = cls
        return cls

    @class_decorator
    class SanicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True


# Generated at 2022-06-12 08:48:25.321789
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(507, quiet=True)
    class InsufficientStorage(SanicException):
        pass
    assert InsufficientStorage.status_code == 507
    assert InsufficientStorage().status_code == 507
    assert InsufficientStorage.quiet is True
    assert InsufficientStorage().quiet is True
    assert _sanic_exceptions[507] == InsufficientStorage

# Generated at 2022-06-12 08:48:29.100042
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(9001)
    class AwesomeException(SanicException):
        pass

    assert AwesomeException.status_code == 9001
    assert _sanic_exceptions[9001] == AwesomeException


# Generated at 2022-06-12 08:48:30.742334
# Unit test for function add_status_code
def test_add_status_code():
    assert 500 in _sanic_exceptions
    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-12 08:48:35.536433
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(Exception):
        pass
    
    @add_status_code(400)
    class MyException400(MyException):
        pass
    assert 400 in _sanic_exceptions.keys()

    @add_status_code(401)
    class MyException401(MyException):
        pass
    assert 401 in _sanic_exceptions.keys()



# Generated at 2022-06-12 08:48:39.754413
# Unit test for function add_status_code
def test_add_status_code():
    def test_sanic_exceptions():
        for cls in _sanic_exceptions.values():
            assert cls.status_code is not None

    test_sanic_exceptions()

    @add_status_code(501)
    class NotImplementedException(SanicException):
        pass

    test_sanic_exceptions()

# Generated at 2022-06-12 08:48:57.990893
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)
    exception = TestException("Test")
    assert exception.status_code == 500


# Generated at 2022-06-12 08:49:04.171750
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized

# Generated at 2022-06-12 08:49:11.070706
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    assert type(_sanic_exceptions[400]) is CustomException
    assert issubclass(CustomException, SanicException)
    assert issubclass(InvalidUsage, SanicException)

    @add_status_code(403)
    class CustomException(SanicException):
        pass

    assert type(_sanic_exceptions[403]) is CustomException

    assert issubclass(CustomException, SanicException)
    assert issubclass(Forbidden, SanicException)

# Generated at 2022-06-12 08:49:19.045526
# Unit test for function add_status_code
def test_add_status_code():
    """Unit test for add_status_code"""
    test_status_code = 999
    test_message = "test message"

    @add_status_code(test_status_code)
    class TestException(SanicException):
        pass

    test_exception = TestException(message=test_message)
    assert test_exception.status_code == test_status_code
    assert str(test_exception) == test_message

    # Test default status code
    default_exception = SanicException(message=test_message)
    assert default_exception.status_code == 500



# Generated at 2022-06-12 08:49:21.471857
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class A(SanicException):
        pass


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:23.611736
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class test_exception(SanicException):
        pass
    assert _sanic_exceptions[201] == test_exception

# Generated at 2022-06-12 08:49:25.578436
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class _404Err(SanicException):
        pass

    assert _sanic_exceptions[404] == _404Err

# Generated at 2022-06-12 08:49:28.202069
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=404)
    class NotFound(SanicException):
        pass
    exception = NotFound("Not Found")
    assert exception.status_code == 404

# Generated at 2022-06-12 08:49:33.832899
# Unit test for function add_status_code
def test_add_status_code():
    # Test for custom class definition
    @add_status_code(200)
    class Success(SanicException):
        def __init__(self, message):
            super().__init__(message)
    assert Success.status_code == 200
    assert _sanic_exceptions[200] == Success

    # Test for normal usage
    assert ServerError.status_code == 500
    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-12 08:49:37.743431
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404).status_code == 404
    assert _sanic_exceptions.get(500).quiet is False
    assert _sanic_exceptions.get(501).quiet is False

# Generated at 2022-06-12 08:50:10.805082
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Test100(SanicException):
        pass
    assert Test100.status_code == 100
    assert Test100.quiet is True

    @add_status_code(700)
    class Test700(SanicException):
        pass
    assert Test700.status_code == 700
    assert Test700.quiet is None
    assert Test700.quiet is False

# Generated at 2022-06-12 08:50:18.593689
# Unit test for function add_status_code
def test_add_status_code():
    from mock import patch, MagicMock

    with patch.dict(_sanic_exceptions, {}, clear=True):
        add_status_code(200)(MagicMock)
        assert _sanic_exceptions[200].status_code == 200
        assert _sanic_exceptions[200].quiet

        add_status_code(206, True)(MagicMock)
        assert _sanic_exceptions[206].status_code == 206
        assert _sanic_exceptions[206].quiet

        add_status_code(500, False)(MagicMock)
        assert _sanic_exceptions[500].status_code == 500
        assert not _sanic_exceptions[500].quiet

# Generated at 2022-06-12 08:50:22.056887
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test add_status_code function
    """
    @add_status_code(304)
    class Test(Exception):
        pass
    status_code = Test.status_code
    assert 304 == status_code
    assert Test() in _sanic_exceptions

# Generated at 2022-06-12 08:50:28.519432
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, True)
    class _InvalidUsage(SanicException):
        pass

    assert _sanic_exceptions[400].__name__ == '_InvalidUsage'
    assert _sanic_exceptions[400].__module__ == 'exceptions'
    assert _sanic_exceptions[400].status_code == 400
    assert _sanic_exceptions[400].quiet == True


# Generated at 2022-06-12 08:50:33.244530
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    # SanicException is inherited from Exception
    assert isinstance(TestException, Exception)
    # TestException's status code is 200
    assert TestException.status_code == 200
    # TestException is added to _sanic_exceptions
    assert _sanic_exceptions[200] == TestException

# Generated at 2022-06-12 08:50:42.873157
# Unit test for function add_status_code
def test_add_status_code():
    import sys
    import os
    import pytest

    dir_path = os.path.dirname(os.path.realpath(__file__))
    root_dir = os.path.join(dir_path, "..", "..")
    sys.path.append(root_dir)

    from sanic import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_add_status_code")
    assert len(_sanic_exceptions.keys()) == 13

    class MyException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status

# Generated at 2022-06-12 08:50:49.247215
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class TestException(SanicException):
        pass

    try:
        raise TestException()
    except TestException:
        assert True
    else:
        assert False

    assert TestException.status_code == 444
    assert TestException.quiet == True
    try:
        raise TestException()
    except TestException as e:
        assert e.status_code == 444



# Generated at 2022-06-12 08:50:53.735541
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(Exception):
        pass

    add_status_code(400)(MyException)
    add_status_code(401)(MyException)
    add_status_code(403)(MyException)

    assert issubclass(_sanic_exceptions[400], MyException)
    assert issubclass(_sanic_exceptions[401], MyException)
    assert issubclass(_sanic_exceptions[403], MyException)

# Generated at 2022-06-12 08:51:05.784478
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass
    assert IAmATeaPot.status_code == 418
    assert IAmATeaPot.quiet == True

    @add_status_code(418, True)
    class IAmATeaPot(SanicException):
        pass
    assert IAmATeaPot.status_code == 418
    assert IAmATeaPot.quiet == True

    with pytest.raises(SanicException) as e:
        raise IAmATeaPot("I'm a teapot")
    assert e.value.status_code == 418
    assert e.value.quiet == True

    @add_status_code(500, False)
    class IAmATeaPot(SanicException):
        pass

# Generated at 2022-06-12 08:51:14.897742
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class NotReady(SanicException):
        pass
    try:
        abort(408)
    except NotReady as exc:
        assert exc.status_code == 408
    else:
        assert False, "NotReady sanic_exceptions not working"



# Generated at 2022-06-12 08:52:17.933874
# Unit test for function add_status_code
def test_add_status_code():
    """
    insert your unit test code here.
    """
    @add_status_code(100)
    class ForTest(SanicException):
        pass
    assert issubclass(ForTest, SanicException)
    assert ForTest.status_code == 100

# Generated at 2022-06-12 08:52:26.234468
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code is a decorator, so we can use a closure here
    def testclass():
        @add_status_code(200)
        class MyTestClass(Exception):
            pass

        return MyTestClass

    MyTestClass = testclass()
    assert MyTestClass.status_code == 200
    assert MyTestClass('').status_code == 200
    assert MyTestClass('').quiet is False
    assert MyTestClass('').message == ''
    assert MyTestClass('', quiet=True).quiet is True
    assert MyTestClass('', quiet=False).quiet is False
    assert MyTestClass('', quiet=None).quiet is False
    assert MyTestClass('', status_code=500).quiet is True
    assert MyTestClass('', status_code=501).quiet is True

# Generated at 2022-06-12 08:52:34.359971
# Unit test for function add_status_code
def test_add_status_code():
    # Scenario 1: status_code 500
    @add_status_code(500)
    class Exception500(SanicException):
        pass

    # Expected: quiet=False
    assert Exception500.quiet == False


    # Scenario 2: status_code 200
    @add_status_code(200)
    class Exception200(SanicException):
        pass

    # Expected: quiet=True
    assert Exception200.quiet == True


    # Scenario 3: status_code 300, quiet=None
    @add_status_code(300)
    class Exception300(SanicException):
        pass

    # Expected: quiet=False
    assert Exception300.quiet == False


    # Scenario 4: status_code 300, quiet=True

# Generated at 2022-06-12 08:52:34.986369
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-12 08:52:36.375254
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(521)
    class Offline(SanicException):
        pass

# Generated at 2022-06-12 08:52:39.430942
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert isinstance(MyException(), MyException)
    assert isinstance(MyException(), SanicException)
    assert MyException.status_code == 400


# Generated at 2022-06-12 08:52:43.722314
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Foo(SanicException):
        pass

    assert Foo.status_code == 200
    assert Foo.quiet == True

    @add_status_code(500, quiet=False)
    class Bar(SanicException):
        pass

    assert Bar.status_code == 500
    assert Bar.quiet == False

# Generated at 2022-06-12 08:52:51.665599
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Ok(SanicException):
        """
        **Status**: 200 OK
        """

    assert _sanic_exceptions[200] == Ok
    assert Ok.status_code == 200
    assert Ok.quiet == False
    assert Ok.__doc__ == "**Status**: 200 OK"

    # quiet=None/False/True with None meaning choose by status
    @add_status_code(500)
    class InternalServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

    assert _sanic_exceptions[500] == InternalServerError
    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet == None
    assert InternalServerError.__doc__ == "**Status**: 500 Internal Server Error"


# Generated at 2022-06-12 08:53:01.836741
# Unit test for function add_status_code
def test_add_status_code():
    # Test that it adds a code to the _sanic_exceptions
    test_exception = add_status_code(400)(SanicException)
    assert _sanic_exceptions[400] == test_exception

    # Test that it sets the status code on the exception
    assert test_exception(message=None, status_code=None).status_code == 400

    # Test that it's quiet by default if not 500 or when asked
    assert test_exception(message=None, status_code=None).quiet is True
    assert test_exception(message=None, status_code=None, quiet=None).quiet is True
    assert test_exception(message=None, status_code=None, quiet=False).quiet is False

    # Test that it's not quiet when the status code is 500
    assert _sanic_exceptions

# Generated at 2022-06-12 08:53:07.677766
# Unit test for function add_status_code
def test_add_status_code():
    # Test for generator
    assert add_status_code(1)(Exception) == Exception
    # Test for status 201
    assert _sanic_exceptions[201].status_code == 201
    _sanic_exceptions[201] = Exception
    assert _sanic_exceptions[201] == Exception
    # Test for duplicate status_code
    assert _sanic_exceptions[500] == ServerError

