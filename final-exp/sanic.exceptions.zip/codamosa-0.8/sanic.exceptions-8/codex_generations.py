

# Generated at 2022-06-12 08:44:39.599348
# Unit test for function add_status_code
def test_add_status_code():
    class my_test(Exception):
        pass
    @add_status_code(100)
    class my_test_1(my_test):
        pass
    @add_status_code(100)
    class my_test_2(my_test):
        pass
    @add_status_code(100, quiet=True)
    class my_test_3(my_test):
        pass

    assert my_test_1.status_code == 100
    assert not hasattr(my_test_1, "quiet")
    assert my_test_2.status_code == 100
    assert not hasattr(my_test_2, "quiet")
    assert my_test_3.status_code == 100
    assert my_test_3.quiet

    assert isinstance(my_test_1(message=""), SanicException)

# Generated at 2022-06-12 08:44:44.013049
# Unit test for function add_status_code
def test_add_status_code():
    # this test is just a formality,
    # we have several add_status_code decorated classes above
    @add_status_code(555)
    class test_exception(SanicException):
        pass

    status_code = test_exception.status_code
    assert status_code == 555

# Generated at 2022-06-12 08:44:51.029759
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert 418 in _sanic_exceptions

    assert issubclass(_sanic_exceptions[418], SanicException)

    assert _sanic_exceptions[418] == IAmATeaPot

    assert _sanic_exceptions[418](message="Teapot").status_code == 418

    assert _sanic_exceptions[418](message="Teapot").message == "Teapot"

    assert _sanic_exceptions[418](message="Teapot").quiet is True

# Generated at 2022-06-12 08:44:55.240695
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Sanic200Exception(SanicException):
        pass
    x = Sanic200Exception("response message 200")
    assert x.status_code == 200

    @add_status_code(300)
    class Sanic300Exception(SanicException):
        pass
    x = Sanic300Exception("response message 300")
    assert x.status_code == 300


# Generated at 2022-06-12 08:45:06.152486
# Unit test for function add_status_code
def test_add_status_code():

    status_code = 404

    @add_status_code(status_code)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    assert NotFound.status_code == status_code
    assert _sanic_exceptions[status_code] == NotFound

    @add_status_code(500, quiet=False)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        pass

    assert ServerError.quiet is False

    @add_status_code(500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        pass

    assert ServerError.quiet is True


# Generated at 2022-06-12 08:45:11.428492
# Unit test for function add_status_code
def test_add_status_code():
    assert 408 not in _sanic_exceptions

    @add_status_code(408)
    class Timeout(SanicException):
        pass

    assert 408 in _sanic_exceptions

    assert Timeout().status_code == 408
    assert Timeout().quiet == True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert ServerError().status_code == 500
    assert ServerError().quiet == False

# Unit tests for function abort

# Generated at 2022-06-12 08:45:12.836038
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 404
    quiet = True
    assert _sanic_exceptions[status_code] == NotFound

# Generated at 2022-06-12 08:45:22.351529
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, False)
    class TestEx1(SanicException):
        pass

    assert _sanic_exceptions[201] == TestEx1
    assert TestEx1().status_code == 201
    assert not TestEx1().quiet

    @add_status_code(202, True)
    class TestEx2(SanicException):
        pass

    assert _sanic_exceptions[202] == TestEx2
    assert TestEx2().status_code == 202
    assert TestEx2().quiet

    @add_status_code(203)
    class TestEx3(SanicException):
        pass

    assert _sanic_exceptions[203] == TestEx3
    assert TestEx3().status_code == 203
    assert TestEx3().quiet

# Generated at 2022-06-12 08:45:28.535725
# Unit test for function add_status_code
def test_add_status_code():
    def test_class(cls):
        assert cls.status_code == code
        assert _sanic_exceptions[code] == test_class
        return cls

    for code in range(100, 600):
        test_class = add_status_code(code)(test_class)

    try:
        add_status_code(code)
    except TypeError:
        pass
    else:
        raise TypeError



# Generated at 2022-06-12 08:45:36.022019
# Unit test for function add_status_code
def test_add_status_code():
    test_class = add_status_code(400)(SanicException)
    assert test_class == SanicException
    assert test_class.status_code == 400
    assert _sanic_exceptions[400] is SanicException

    test_class = add_status_code(404)(SanicException)
    assert test_class == SanicException
    assert test_class.status_code == 404
    assert _sanic_exceptions[404] is SanicException

    test_class = add_status_code(405)(SanicException)
    assert test_class == SanicException
    assert test_class.status_code == 405
    assert _sanic_exceptions[405] is SanicException



# Generated at 2022-06-12 08:45:46.833289
# Unit test for function add_status_code
def test_add_status_code():
    '''
    运行测试
    python -m doctest -v app\exceptions.py

    >>> test_exception = add_status_code(404)
    >>> class TestException(Exception):
    ...     def __init__(self, message, status_code=None, quiet=None):
    ...         super().__init__(message)
    ...
    >>> new_exc = test_exception(TestException)
    >>> new_exc.status_code
    404
    >>> new_exc.quiet
    True
    >>> _sanic_exceptions[404] == new_exc
    True
    '''
    pass

# Generated at 2022-06-12 08:45:52.813081
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class TestSanicException(SanicException):
        pass
    assert _sanic_exceptions[600] is TestSanicException

    @add_status_code(601, quiet=True)
    class TestSanicException(SanicException):
        pass
    assert _sanic_exceptions[601] is TestSanicException

# Generated at 2022-06-12 08:45:59.509161
# Unit test for function add_status_code
def test_add_status_code():
    # Function add_status_code returns a class_decorator
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    # Assert that these two decorators are the same
    assert add_status_code(status_code=404) == class_decorator


# Generated at 2022-06-12 08:46:03.547371
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    add_status_code(400)(MyException)
    assert MyException.status_code == 400 and issubclass(
        MyException, SanicException)
    assert _sanic_exceptions[400] is MyException



# Generated at 2022-06-12 08:46:08.204806
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass
    
    assert InvalidUsage.status_code == 400
    assert InvalidUsage.quiet == True
    assert _sanic_exceptions[400] == InvalidUsage


# Generated at 2022-06-12 08:46:12.395132
# Unit test for function add_status_code
def test_add_status_code():
    # Test that add_status_code with a specific code
    # adds a class instance of SanicException with the specified code
    @add_status_code(403)
    class TestCodeClass(SanicException):
        pass

    assert type(TestCodeClass) == type
    assert TestCodeClass.status_code == 403


# Generated at 2022-06-12 08:46:17.875581
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomEx(Exception):
        pass

    assert isinstance(_sanic_exceptions[400], CustomEx)
    assert _sanic_exceptions[400]().status_code == 400
    assert _sanic_exceptions[400]().quiet is True

    @add_status_code(500)
    class CustomEx(Exception):
        pass

    assert isinstance(_sanic_exceptions[500], CustomEx)
    assert _sanic_exceptions[500]().status_code == 500
    assert _sanic_exceptions[500]().quiet is None

# Generated at 2022-06-12 08:46:20.615471
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        def __init__(self, message):
            super().__init__(message)
    
    return TestException.status_code

# Generated at 2022-06-12 08:46:25.990908
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class MyException(SanicException):
        """
        **Status**: 300 My Exception
        """
        pass

    assert _sanic_exceptions[300] == MyException
    assert _sanic_exceptions[300](message="OK").status_code == 300



# Generated at 2022-06-12 08:46:28.369113
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(Exception):
        pass
    add_status_code(418)(CustomException)
    assert _sanic_exceptions[418] == CustomException

# Generated at 2022-06-12 08:46:37.869559
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException(SanicException):
        def __init__(self, message, test_var, status_code=None, quiet=None):
            super().__init__(message)
            self.test_var = test_var

    test_instance = TestException('Message', test_var = 5)

    assert test_instance.status_code == 100
    assert test_instance.test_var == 5

    assert _sanic_exceptions[100] == TestException


# Generated at 2022-06-12 08:46:46.700187
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert IAmATeaPot.status_code == 418
    assert IAmATeaPot.__name__ == "IAmATeaPot"
    assert IAmATeaPot.__qualname__ == "IAmATeaPot"
    assert IAmATeaPot.__module__ == "sanic.exceptions"
    assert IAmATeaPot.__doc__ == None
    assert IAmATeaPot().status_code == 418
    assert _sanic_exceptions.get(418) == IAmATeaPot

# Generated at 2022-06-12 08:46:56.731425
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert _sanic_exceptions[400] is BadRequest
    assert BadRequest.status_code == 400
    assert BadRequest.quiet is True

    @add_status_code(401)
    class Unauthorized(SanicException):
        pass

    assert _sanic_exceptions[401] is Unauthorized
    assert Unauthorized.status_code == 401
    assert Unauthorized.quiet is False

    @add_status_code(500)
    class InternalServerError(SanicException):
        pass

    assert _sanic_exceptions[500] is InternalServerError
    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet is False


# Generated at 2022-06-12 08:47:00.223804
# Unit test for function add_status_code
def test_add_status_code():
    # Decorate the new SanicException class with the add_status_code decorator
    # The status code should be set to the expected status code
    @add_status_code(505)
    class SanicException505(SanicException):
        pass

    assert SanicException505.status_code == 505



# Generated at 2022-06-12 08:47:11.145696
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404) is not None
    assert add_status_code(400) is not None
    assert add_status_code(405) is not None
    assert add_status_code(500) is not None
    assert add_status_code(503) is not None
    assert add_status_code(408) is not None
    assert add_status_code(413) is not None
    assert add_status_code(416) is not None
    assert add_status_code(417) is not None
    assert add_status_code(403) is not None
    assert add_status_code(401) is not None

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:17.999940
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    @add_status_code(400)
    class MyException400(MyException):
        pass

    assert MyException400.status_code == 400
    assert _sanic_exceptions[400] == MyException400

    @add_status_code(500)
    class MyException500(MyException):
        pass

    assert MyException500.status_code == 500
    assert _sanic_exceptions[500] == MyException500



# Generated at 2022-06-12 08:47:28.322471
# Unit test for function add_status_code
def test_add_status_code():
    # Passing status code
    @add_status_code(404)
    class NotFoundException(Exception):
        pass
    assert getattr(NotFoundException, "status_code") == 404
    
    # Passing status code and quiet to quiet
    @add_status_code(404, quiet=True)
    class NotFoundException(Exception):
        pass
    assert getattr(NotFoundException, "status_code") == 404 and getattr(NotFoundException, "quiet") == True
    
    # Passing quiet=None, status code is 500, this should default to quiet=True
    @add_status_code(500, quiet=None)
    class NotFoundException(Exception):
        pass
    assert getattr(NotFoundException, "status_code") == 500 and getattr(NotFoundException, "quiet") == True
    
    # Passing

# Generated at 2022-06-12 08:47:29.277241
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200)(SanicException)

# Generated at 2022-06-12 08:47:31.302630
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestNotFound(SanicException):
        pass
    assert _sanic_exceptions == {404: TestNotFound}

# Generated at 2022-06-12 08:47:33.914396
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class TestException(Exception):
        pass

    TestException.status_code == 403
    TestException.quiet is True

# Generated at 2022-06-12 08:47:47.056376
# Unit test for function add_status_code
def test_add_status_code():
    class SanicTest(SanicException):
        pass

    @add_status_code(403)
    class TestException(SanicTest):
        pass

    assert TestException.status_code == 403
    assert TestException().status_code == 403
    assert TestException.quiet is True
    assert TestException().quiet is True
    assert TestException().__class__.__name__ == "TestException"

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:50.271222
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class c:
        pass
    assert c.status_code == 200
    assert c.quiet == True
    assert c in _sanic_exceptions


# Generated at 2022-06-12 08:47:54.930866
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=403, quiet=False)
    class DummyException(Exception):
        pass

    assert DummyException.status_code == 403
    assert DummyException.quiet is False
    assert _sanic_exceptions[403] == DummyException


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:56.495728
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[200] == MyException

# Generated at 2022-06-12 08:48:00.327218
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class UserException(SanicException):
        pass

    assert UserException.status_code == 500
    assert UserException.quiet is False
    assert _sanic_exceptions.get(500) is UserException

# Generated at 2022-06-12 08:48:03.620376
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Error200(SanicException):
        pass

    assert Error200.status_code == 200
    assert _sanic_exceptions[200].__name__ == 'Error200'

# Generated at 2022-06-12 08:48:07.068214
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class MyCustomException(SanicException):
        pass

    assert MyCustomException.status_code == 201
    assert _sanic_exceptions[201] == MyCustomException



# Generated at 2022-06-12 08:48:09.471126
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(99)
    class Foo(SanicException):
        pass

    assert Foo('').status_code == 99

# Generated at 2022-06-12 08:48:15.189614
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402)
    class PaymentRequired(SanicException):
        pass
    status_code = 402
    message = STATUS_CODES[status_code].decode("utf8")
    sanic_exception = PaymentRequired(message=message, status_code=status_code)

    assert sanic_exception.status_code == 402



# Generated at 2022-06-12 08:48:21.669257
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class _(SanicException):
        pass
    assert _sanic_exceptions[201] == _

    @add_status_code(200)
    class _(SanicException):
        pass
    assert _sanic_exceptions[200] == _

    @add_status_code(400)
    class _(SanicException):
        pass
    assert _sanic_exceptions[400] == _


# Generated at 2022-06-12 08:48:41.832060
# Unit test for function add_status_code
def test_add_status_code():
    ''' TODO: This needs to be updated for for Python 3 and Sanic
    '''
    @add_status_code(456)
    class CustomException(SanicException):
        pass
    assert CustomException.status_code == 456
    assert _sanic_exceptions[456] is CustomException

    @add_status_code(456)
    class CustomException1(SanicException):
        pass
    assert _sanic_exceptions[456] is CustomException1

    @add_status_code(500)
    class CustomException2(SanicException):
        pass
    assert CustomException2.quiet is False

# Generated at 2022-06-12 08:48:44.337606
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestClass(SanicException):
        pass
    assert TestClass.status_code == 100



# Generated at 2022-06-12 08:48:47.040619
# Unit test for function add_status_code
def test_add_status_code():
    def test_func():
        pass

    add_status_code(404)(test_func)
    assert test_func.status_code == 404
    assert test_func.quiet is True

# Generated at 2022-06-12 08:48:57.652079
# Unit test for function add_status_code
def test_add_status_code():
    def check_status_code(code, quiet):
        cls = _sanic_exceptions[code]
        assert cls.status_code == code
        assert cls.quiet == quiet

    @add_status_code(404)
    class Test1(SanicException):
        pass

    @add_status_code(500)
    class Test2(SanicException):
        pass

    @add_status_code(503)
    class Test3(SanicException):
        pass

    @add_status_code(400)
    class Test4(SanicException):
        pass

    @add_status_code(400, True)
    class Test5(SanicException):
        pass

    @add_status_code(400, False)
    class Test6(SanicException):
        pass

    check_status

# Generated at 2022-06-12 08:48:59.592453
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200)
    assert add_status_code(200, True)
    assert add_status_code(200, False)

# Generated at 2022-06-12 08:49:04.381106
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class CustomException600(SanicException):
        pass

    assert CustomException600.status_code == 600
    assert _sanic_exceptions[600] == CustomException600

    @add_status_code(601, quiet=True)
    class CustomException601(SanicException):
        pass

    assert CustomException601.quiet is True
    assert _sanic_exceptions[601] == CustomException601

# Generated at 2022-06-12 08:49:14.357618
# Unit test for function add_status_code
def test_add_status_code():
    def old_add_status_code(code, quiet=None):
        """
        Decorator used for adding exceptions to :class:`SanicException`.
        """

        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls

        return class_decorator

    @old_add_status_code(405)
    class MethodNotSupported(SanicException):
        """
        **Status**: 405 Method Not Allowed
        """


        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}



# Generated at 2022-06-12 08:49:19.305694
# Unit test for function add_status_code
def test_add_status_code():
    try:
        raise NotFound("Page not found")
    except NotFound as exc:
        assert exc.status_code == 404
        assert str(exc) == "Page not found"

    try:
        raise ServerError("Internal Server Error")
    except ServerError as exc:
        assert exc.status_code == 500
        assert str(exc) == "Internal Server Error"


# Generated at 2022-06-12 08:49:24.572455
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert ServerError.status_code == 500
    assert ServerError.quiet == False
    assert NotFound.status_code == 404
    assert NotFound.quiet == True

# Generated at 2022-06-12 08:49:32.399511
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(409)
    class Conflict(SanicException):
        """
        **Status**: 409 Conflict
        """
        pass

    assert Conflict.status_code == 409
    assert Conflict.quiet is True
    @add_status_code(409, False)
    class Conflict2(SanicException):
        """
        **Status**: 409 Conflict
        """
        pass
    assert Conflict2.status_code == 409
    assert Conflict2.quiet is False

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:58.879075
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(100)(Exception) # type: ignore



# Generated at 2022-06-12 08:50:02.292178
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(428)
    class PreconditionRequired(SanicException):
        pass

    assert _sanic_exceptions[428] == PreconditionRequired



# Generated at 2022-06-12 08:50:12.515869
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
        
    class SanicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True
            

# Generated at 2022-06-12 08:50:19.865833
# Unit test for function add_status_code
def test_add_status_code():
    test_exc = add_status_code(666, quiet=False)(SanicException)
    assert test_exc.status_code == 666
    assert test_exc.quiet is False

    test_exc = add_status_code(666, quiet=True)(SanicException)
    assert test_exc.status_code == 666
    assert test_exc.quiet is True

    test_exc = add_status_code(666)(SanicException)
    assert test_exc.status_code == 666
    assert test_exc.quiet is True

    test_exc = add_status_code(500)(SanicException)
    assert test_exc.status_code == 500
    assert test_exc.quiet is False



# Generated at 2022-06-12 08:50:28.270494
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException2(SanicException):
        pass
    assert TestException2.status_code == 500
    assert TestException2.quiet is False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass
    assert TestException3.status_code == 500
    assert TestException3.quiet is True

# Generated at 2022-06-12 08:50:30.269913
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Test(object):
        pass
    assert Test.status_code == 400



# Generated at 2022-06-12 08:50:38.712042
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class MyException500(SanicException):
        pass
    assert isinstance(MyException500, SanicException)
    assert _sanic_exceptions[500] is MyException500

    @add_status_code(502)
    class MyException502(SanicException):
        pass
    assert isinstance(MyException502, SanicException)
    assert _sanic_exceptions[502] is MyException502

    assert len(_sanic_exceptions) == 3
    assert MyException500.status_code == 500
    assert MyException502.status_code == 502

# Generated at 2022-06-12 08:50:40.661407
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(501)(SanicException)
    assert _sanic_exceptions.get(501) == SanicException

# Generated at 2022-06-12 08:50:51.355500
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class test_class(SanicException):
        pass
    assert test_class._sanic_exceptions[123] is test_class
    assert test_class.status_code == 123
    assert test_class.quiet == False

    @add_status_code(456, quiet=True)
    class test_class2(SanicException):
        pass
    assert test_class2._sanic_exceptions[456] is test_class2
    assert test_class2.status_code == 456
    assert test_class2.quiet == True

    @add_status_code(789)
    class test_class3(SanicException):
        pass
    assert test_class3._sanic_exceptions[789] is test_class3
    assert test_class3.status_code

# Generated at 2022-06-12 08:51:03.178672
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions.get(400) == InvalidUsage
    assert _sanic_exceptions.get(405) == MethodNotSupported
    assert _sanic_exceptions.get(500) == ServerError
    assert _sanic_exceptions.get(503) == ServiceUnavailable
    assert _sanic_exceptions.get(408) == RequestTimeout
    assert _sanic_exceptions.get(413) == PayloadTooLarge
    assert _sanic_exceptions.get(415) == UnsupportedMediaType
    assert _sanic_exceptions.get(416) == ExpectedException
    assert _sanic_exceptions.get(417) == HeaderExpectationFailed
    assert _sanic_exceptions.get(403) == Forbidden

# Generated at 2022-06-12 08:51:59.397206
# Unit test for function add_status_code
def test_add_status_code():
    code = 400
    # Create new class, add status_code and quiet attribute
    @add_status_code(code)
    class C:
        pass
    assert C.status_code == code
    assert C.quiet == True



# Generated at 2022-06-12 08:52:00.594632
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500, True)



# Generated at 2022-06-12 08:52:03.219346
# Unit test for function add_status_code
def test_add_status_code():
    class IAmNew(SanicException):
        pass

    add_status_code(600)(IAmNew)
    assert IAmNew().status_code == 600



# Generated at 2022-06-12 08:52:09.037731
# Unit test for function add_status_code
def test_add_status_code():

    class Custom(SanicException):
        def __init__(self):
            super().__init__("message", status_code=123)

    @add_status_code(123)
    class Custom2(SanicException):
        def __init__(self):
            super().__init__("message", status_code=123)

    assert Custom().status_code == 123
    assert Custom2().status_code == 123

    try:
        abort(123)
        assert False
    except Custom:
        assert True

    try:
        abort(123)
        assert False
    except Custom2:
        assert True

# Generated at 2022-06-12 08:52:14.001564
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(488)
    class Test(SanicException):
        pass

    @add_status_code(800)
    class Test2(SanicException):
        pass

    if _sanic_exceptions[488] is not Test:
        raise AssertionError("Test failed for function add_status_code")

    if _sanic_exceptions[800] is not Test2:
        raise AssertionError("Test failed for function add_status_code")

# Generated at 2022-06-12 08:52:15.656224
# Unit test for function add_status_code
def test_add_status_code():
    assert 408 in _sanic_exceptions
    assert _sanic_exceptions[408] == RequestTimeout

# Generated at 2022-06-12 08:52:24.502483
# Unit test for function add_status_code
def test_add_status_code():
    # Given
    class ErrorA(SanicException):
        pass

    class ErrorB(SanicException):
        pass

    class ErrorC(SanicException):
        pass

    class ErrorD(SanicException):
        pass

    class ErrorE(SanicException):
        pass

    # When
    add_status_code(100)(ErrorA)
    add_status_code(101)(ErrorB)
    add_status_code(102)(ErrorC)
    add_status_code(103)(ErrorD)
    add_status_code(103)(ErrorE)

    # Then
    assert _sanic_exceptions[100] == ErrorA
    assert _sanic_exceptions[101] == ErrorB
    assert _sanic_exceptions[102] == ErrorC

# Generated at 2022-06-12 08:52:27.548302
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        """
        **Status**: 401 Unauthorized
        """

    assert isinstance(_sanic_exceptions[401], SanicException)



# Generated at 2022-06-12 08:52:30.876364
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, quiet=True)
    class CustomException(SanicException):
        pass

    assert issubclass(_sanic_exceptions[201], CustomException)
    assert _sanic_exceptions[201]().status_code == 201
    assert _sanic_exceptions[201]().quiet

# Generated at 2022-06-12 08:52:33.333483
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(31337, True)
    class AwesomeException(SanicException):
        pass

    assert AwesomeException(message='foo', status_code=31337, quiet=True)



# Generated at 2022-06-12 08:54:32.666211
# Unit test for function add_status_code
def test_add_status_code():
    
    class A(SanicException):
        pass

    @add_status_code(403)
    class B(SanicException):
        pass

    @add_status_code(404)
    class C(SanicException):
        pass

    assert A.status_code == None
    assert A.quiet == None

    assert B.status_code == 403
    assert B.quiet == True

    assert C.status_code == 404
    assert C.quiet == False