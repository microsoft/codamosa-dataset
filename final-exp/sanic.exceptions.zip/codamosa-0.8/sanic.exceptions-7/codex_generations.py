

# Generated at 2022-06-12 08:44:35.973573
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class Created(SanicException):
        pass

    assert(STATUS_CODES[202] == 'Created')
    assert(Created.status_code == 202)
    assert(Created.quiet == True)

# Generated at 2022-06-12 08:44:40.794032
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    assert TestException.status_code is None
    assert TestException.quiet is None

    TestException = add_status_code(400)(TestException)

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert TestException() is not None

# Generated at 2022-06-12 08:44:50.283054
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(AttributeError):
        class UserError(SanicException):
            pass

    class UserError(SanicException):
        pass

    @add_status_code(123)
    class TestException(SanicException):
        pass

    with pytest.raises(AttributeError):
        TestException()

    with pytest.raises(AttributeError):
        UserError()

    class UserError(SanicException):
        def __init__(self):
            super().__init__(message="invalid input", status_code=123)
            raise Exception

    with pytest.raises(TypeError):
        UserError()

    class UserError(SanicException):
        def __init__(self):
            super().__init__(message="invalid input")
            raise Exception


# Generated at 2022-06-12 08:44:55.856720
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class FNotFound(SanicException):
        pass

    assert FNotFound.status_code == 404
    assert FNotFound.quiet == True
    assert _sanic_exceptions.get(404) == FNotFound

    @add_status_code(500)
    class FServerError(SanicException):
        pass

    assert FServerError.status_code == 500
    assert FServerError.quiet == False
    assert _sanic_exceptions.get(500) == FServerError

# Generated at 2022-06-12 08:45:05.589582
# Unit test for function add_status_code
def test_add_status_code():

    # _sanic_exceptions exists
    assert _sanic_exceptions

    # SanicException has status_code and quiet attributes
    assert hasattr(SanicException, "status_code") and hasattr(SanicException, "quiet")

    # No status code in _sanic_exceptions
    assert _sanic_exceptions.get(518) is None

    # Status code 518 added
    @add_status_code(518)
    class AddedException(SanicException):
        pass

    assert _sanic_exceptions.get(518) is AddedException

    # AddedException has status_code and quiet attributes
    assert hasattr(AddedException, "status_code") and hasattr(AddedException, "quiet")

# Generated at 2022-06-12 08:45:08.180259
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(405)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 405
    assert _sanic_exceptions[405] == TestException

# Generated at 2022-06-12 08:45:13.796194
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass
    with pytest.raises(TestException) as re:
        raise TestException("test")
    assert "test" in re
    @add_status_code(503, quiet=True)
    class TestException(SanicException):
        pass
    with pytest.raises(TestException) as re:
        raise TestException("test")
    assert "test" in re

# Generated at 2022-06-12 08:45:22.259799
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    @add_status_code(405)
    class MethodNotSupported(SanicException):
        pass

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[400] is InvalidUsage
    assert _sanic_exceptions[405] is MethodNotSupported
    assert _sanic_exceptions[500] is ServerError
    assert _sanic_exceptions[503] is ServiceUnavailable

# Generated at 2022-06-12 08:45:25.061205
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class StatusCode400(Exception):
        pass

    assert StatusCode400(400, "Item not found").status_code == 400

# Generated at 2022-06-12 08:45:34.673431
# Unit test for function add_status_code
def test_add_status_code():
    assert issubclass(_sanic_exceptions[404], SanicException)
    assert issubclass(_sanic_exceptions[500], SanicException)
    assert issubclass(_sanic_exceptions[400], SanicException)
    assert issubclass(_sanic_exceptions[405], SanicException)
    assert issubclass(_sanic_exceptions[408], SanicException)
    assert issubclass(_sanic_exceptions[413], SanicException)
    assert issubclass(_sanic_exceptions[416], SanicException)
    assert issubclass(_sanic_exceptions[417], SanicException)
    assert issubclass(_sanic_exceptions[403], SanicException)
    assert issubclass(_sanic_exceptions[401], SanicException)

# Generated at 2022-06-12 08:45:44.069089
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class StatusCode200(SanicException):
        pass

    assert StatusCode200.status_code == 200
    assert isinstance(_sanic_exceptions[200], type)

    @add_status_code(400, True)
    class StatusCode400(SanicException):
        pass

    assert StatusCode400.status_code == 400
    assert isinstance(_sanic_exceptions[400], type)

# Generated at 2022-06-12 08:45:51.208031
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class ServerErrorTest(SanicException):
        pass

    @add_status_code(404)
    class NotFoundTest(SanicException):
        pass

    assert ServerErrorTest.status_code == 500
    assert NotFoundTest.status_code == 404
    assert ServerErrorTest.quiet == False
    assert NotFoundTest.quiet == True


# Run code if the file is called directly
if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:54.366408
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(599, quiet=True)
    class CustomException(SanicException):
        pass
    assert CustomException.status_code == 599
    assert CustomException.quiet is True

# Generated at 2022-06-12 08:46:02.470141
# Unit test for function add_status_code
def test_add_status_code():

    # SanicException
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    # SanicException
    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    # SanicException
    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    assert _sanic_exceptions[501] == NotImplemented
    assert _sanic_exceptions[502] == BadGateway
    assert _sanic_exceptions[503] == ServiceUnavailable

# Generated at 2022-06-12 08:46:12.242092
# Unit test for function add_status_code
def test_add_status_code():
    assert "404" not in _sanic_exceptions
    assert "405" not in _sanic_exceptions
    assert "408" not in _sanic_exceptions
    assert "413" not in _sanic_exceptions
    assert "416" not in _sanic_exceptions
    assert "417" not in _sanic_exceptions
    assert "500" not in _sanic_exceptions

    @add_status_code(404)
    class TestNotFound(SanicException):
        pass

    @add_status_code(405, quiet=None)
    class TestMethodNotSupported(SanicException):
        pass

    @add_status_code(408, quiet=True)
    class TestRequestTimeout(SanicException):
        pass


# Generated at 2022-06-12 08:46:14.419782
# Unit test for function add_status_code
def test_add_status_code():
    code = 404

    @add_status_code(code)
    class class_decorator(SanicException):
        pass

    assert class_decorator.status_code == code

# Generated at 2022-06-12 08:46:19.880080
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    assert _sanic_exceptions[501] == NotImplemented
    assert NotImplemented.status_code == 501

    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert _sanic_exceptions[502] == BadGateway
    assert BadGateway.status_code == 502



# Generated at 2022-06-12 08:46:26.337215
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(0)
    class test0(SanicException):
        pass
    @add_status_code(1)
    class test1(SanicException):
        pass
    @add_status_code(10)
    class test10(SanicException):
        pass
    assert test0.status_code == 0
    assert test1.status_code == 1
    assert test10.status_code == 10

# Generated at 2022-06-12 08:46:31.864553
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class CustomException(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        pass

    assert issubclass(CustomException, SanicException)
    assert _sanic_exceptions[500] == CustomException
    assert _sanic_exceptions[404] == NotFound



# Generated at 2022-06-12 08:46:37.522727
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 400
    assert _sanic_exceptions[400] == NewException

    @add_status_code(500)
    class NewException2(SanicException):
        pass

    assert NewException2.status_code == 500
    assert NewException2.quiet is False
    assert _sanic_exceptions[500] == NewException2

# Generated at 2022-06-12 08:46:44.463021
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class SanicException200(SanicException):
        pass
    assert _sanic_exceptions[200] == SanicException200


# Generated at 2022-06-12 08:46:46.331960
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class _AddStatusCodeTestClass(SanicException):
        pass

    assert _AddStatusCodeTestClass.status_code == 200
    assert _AddStatusCodeTestClass.quiet == True
    assert _AddStatusCodeTestClass.__name__ == '_AddStatusCodeTestClass'


# Generated at 2022-06-12 08:46:50.750334
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    @add_status_code(505)
    class User(SanicException):
        pass

    assert _sanic_exceptions[400] == BadRequest
    assert _sanic_exceptions[505] == User

# Generated at 2022-06-12 08:46:54.157226
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        pass

    assert Unauthorized.status_code == 401
    assert _sanic_exceptions[401].__name__ == 'Unauthorized'

# Generated at 2022-06-12 08:47:01.134761
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        pass

    # We can add new status code with a custom exception
    add_status_code(500, quiet=False)(CustomException)
    assert CustomException().status_code == 500
    assert isinstance(CustomException(), ServerError)
    assert CustomException.quiet == False

    # If no custom exception is specified, a default SanicException is used
    add_status_code(404, quiet=True)
    assert isinstance(_sanic_exceptions[404], NotFound)
    assert _sanic_exceptions[404].quiet == True

    # The exception class is also added to the exceptions namespace
    assert globals().get("CustomException") == CustomException



# Generated at 2022-06-12 08:47:08.039060
# Unit test for function add_status_code
def test_add_status_code():
    def exception_class(cls):
        cls.status_code = 200
        _sanic_exceptions[200] = cls

    code = 500

    @add_status_code(code)
    class SanicException(Exception):
        def __init__(self, message):
            super(SanicException, self).__init__(message)

    assert SanicException(message="text").status_code == code



# Generated at 2022-06-12 08:47:17.314075
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(900)
    class SanicException900(SanicException):
        pass
    # print(_sanic_exceptions)
    assert '900' in _sanic_exceptions
    assert _sanic_exceptions[900]==SanicException900
    assert _sanic_exceptions[500]==ServerError

    @add_status_code(600, quiet=True)
    class SanicException600(SanicException):
        pass
    assert _sanic_exceptions[600]==SanicException600
    assert _sanic_exceptions[600]().quiet is True

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:20.103016
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        return cls

    status_code = 404
    assert add_status_code(status_code) == class_decorator
    assert add_status_code(status_code, quiet=True) == class_decorator
    assert add_status_code(status_code, quiet=False) == class_decorator

# Generated at 2022-06-12 08:47:30.955379
# Unit test for function add_status_code
def test_add_status_code():
    import re

    errors = []

    for status_code in sorted(_sanic_exceptions.keys()):
        cls = _sanic_exceptions[status_code]
        if status_code != cls.status_code:
            errors.append(
                "{} status_code set to {} instead of {}".format(
                    cls.__name__, cls.status_code, status_code
                )
            )

        if status_code == 500:
            if hasattr(cls, "quiet"):
                errors.append("{} quiet attribute defined.".format(cls.__name__))
        else:
            if not hasattr(cls, "quiet"):
                errors.append("{} quiet attribute not defined.".format(cls.__name__))


# Generated at 2022-06-12 08:47:36.922858
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class CustomException(SanicException):
        def __init__(self, message):
            super().__init__(message)
    
    customException = CustomException("Test Exception")
    assert customException.status_code == 600
    assert customException.quiet == True
    assert customException.message == "Test Exception"
    assert _sanic_exceptions[600] == CustomException



# Generated at 2022-06-12 08:47:48.145327
# Unit test for function add_status_code
def test_add_status_code():
    class Exception400(SanicException):
        pass

    add_status_code(400)(Exception400)
    assert _sanic_exceptions[400] == Exception400
    assert _sanic_exceptions[400]().quiet == True
    assert _sanic_exceptions[400]().status_code == 400

# Generated at 2022-06-12 08:47:51.858683
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 123
    assert 123 in _sanic_exceptions
    assert _sanic_exceptions[123] == NewException

# Generated at 2022-06-12 08:47:54.582376
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500, quiet=True)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet

# Generated at 2022-06-12 08:48:00.327350
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test class decorator and static method add_status_code
    """
    @add_status_code(202)
    class TestException(SanicException):
        """
        **Status**: 202 Accepted
        """
        pass

    assert _sanic_exceptions[202] == TestException
    assert TestException.status_code == 202
    assert TestException.quiet == True
    assert TestException.__doc__ == "**Status**: 202 Accepted"

# Generated at 2022-06-12 08:48:05.260125
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class ImATeapot(SanicException):
        pass

    assert ImATeapot.status_code == 418

    @add_status_code(9876)
    class AnException(SanicException):
        pass

    assert AnException.status_code == 9876


# Generated at 2022-06-12 08:48:07.523402
# Unit test for function add_status_code
def test_add_status_code():
    message = "a"
    status_code = 400
    class TestException(Exception):
        pass
    TestException = add_status_code(code=status_code, quiet=True)(TestException)
    assert TestException(message=message).status_code == status_code
    assert TestException(message=message).quiet
    assert _sanic_exceptions[status_code] == TestException



# Generated at 2022-06-12 08:48:19.084554
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test SanicException.
    """

    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    class TestException(SanicException):
        pass

    assert NotFound.status_code == 404
    assert 'quiet' in NotFound.__dict__
    assert InvalidUsage.status_code == 400
    assert 'quiet' in InvalidUsage.__dict__
    assert ServerError.status_code == 500
    assert 'quiet' in ServerError.__dict__
    assert TestException.status_code is None
    assert 'quiet' not in TestException.__dict__


# Generated at 2022-06-12 08:48:25.501442
# Unit test for function add_status_code
def test_add_status_code():
    # prepare test environment
    # assert sanic exception base classes
    assert vars(_sanic_exceptions)
    assert len(vars(_sanic_exceptions)) == 8
    # new sanic exception
    @add_status_code(0)
    class Foo(SanicException):
        pass
    assert Foo.status_code == 0
    assert len(vars(_sanic_exceptions)) == 9
    # overwrite sanic exception
    @add_status_code(0)
    class Bar(SanicException):
        pass
    assert Bar.status_code == 0
    assert len(vars(_sanic_exceptions)) == 9

# Generated at 2022-06-12 08:48:29.319739
# Unit test for function add_status_code
def test_add_status_code():
    def func(status_code):
        @add_status_code(status_code)
        class NewSanicException(SanicException):
            pass
        return NewSanicException

    assert(func(2) == func(2))



# Generated at 2022-06-12 08:48:33.127250
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, quiet=True)
    class _TestExc(SanicException):
        pass

    assert _TestExc.quiet == True
    assert _TestExc.status_code == 400
    assert issubclass(_TestExc, SanicException)
    assert 400 in _sanic_exceptions

# Generated at 2022-06-12 08:48:50.166781
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Test(SanicException):
        pass

    assert Test.status_code == 100
    assert _sanic_exceptions[100] == Test

# Generated at 2022-06-12 08:48:58.179758
# Unit test for function add_status_code
def test_add_status_code():
    # Add 400
    add_status_code(400)(InvalidUsage)
    add_status_code(500)(ServerError)
    add_status_code(404, True)(NotFound)
    add_status_code(500, True)(ServerError)
    # 400 should not be in _sanic_exceptions
    assert _sanic_exceptions[400] != InvalidUsage
    # 500 should not be in _sanic_exceptions
    assert _sanic_exceptions[500] == ServerError
    # 404 should be in _sanic_exceptions
    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-12 08:49:06.145437
# Unit test for function add_status_code
def test_add_status_code():
    # Load file Exception
    err_msg = "No module named 'module_does_not_exist'"
    exc_info = tuple([type("ModuleNotFoundError", (Exception,), {}),
                      ModuleNotFoundError(err_msg),
                      None])

    # It should raise a LoadFileException
    exception = LoadFileException(message=err_msg, exc_info=exc_info,
                                  status_code=500)
    assert isinstance(exception, LoadFileException)
    assert exception.status_code == 500
    assert exception.message == err_msg

    # Method not allowed
    http_method = 'GET'
    allowed_methods = ['GET']
    exception = MethodNotSupported('Method not allowed', http_method,
                                   allowed_methods)
    assert isinstance(exception, MethodNotSupported)

# Generated at 2022-06-12 08:49:09.554065
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class SanicException500(SanicException):
        pass

    assert isinstance(_sanic_exceptions, dict)
    assert _sanic_exceptions[500] == SanicException500

# Generated at 2022-06-12 08:49:18.033082
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(456)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 456
    assert TestException.quiet is True
    assert TestException().status_code == TestException.status_code

    @add_status_code(789, quiet=False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 789
    assert TestException2.quiet is False
    assert TestException2().status_code == TestException2.status_code


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:22.662166
# Unit test for function add_status_code
def test_add_status_code():
    class Error(SanicException):
        pass
    add_status_code(code=0)(Error)
    assert Error.status_code == 0
    assert Error.quiet == False
    add_status_code(code=500, quiet=True)(Error)
    assert Error.status_code == 500
    assert Error.quiet == True
    add_status_code(code=403, quiet=False)(Error)
    assert Error.status_code == 403
    assert Error.quiet == False

# Generated at 2022-06-12 08:49:32.543742
# Unit test for function add_status_code
def test_add_status_code():

    # Test 1: Quiet status code that is not 500
    @add_status_code(400, quiet=True)
    class A(SanicException):
        pass

    assert A.status_code is 400
    assert A.quiet

    # Test 2: Quiet status code that is 500 and quiet default to True
    @add_status_code(500, quiet=True)
    class B(SanicException):
        pass

    assert B.status_code is 500
    assert B.quiet

    # Test 3: Loud status code that is not 500 and quiet default is False
    @add_status_code(400, quiet=False)
    class C(SanicException):
        pass

    assert C.status_code is 400
    assert not C.quiet

    # Test 4: Loud status code that is 500 and quiet default to False

# Generated at 2022-06-12 08:49:39.285316
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized
    assert _sanic_exceptions[416] == ContentRangeError



# Generated at 2022-06-12 08:49:48.720412
# Unit test for function add_status_code
def test_add_status_code():
    # function decorator to add SanicExceptions
    @add_status_code(201)
    class Created(SanicException):
        pass
    @add_status_code(204)
    class NoContent(SanicException):
        pass
    @add_status_code(400)
    class BadRequest(SanicException):
        pass
    @add_status_code(405)
    class MethodNotAllowed(SanicException):
        pass
    @add_status_code(500)
    class InternalServerError(SanicException):
        pass

    # check the status codes we just added
    assert 201 == _sanic_exceptions[201].status_code
    assert 204 == _sanic_exceptions[204].status_code
    assert 400 == _sanic_exceptions[400].status_code

# Generated at 2022-06-12 08:49:51.506434
# Unit test for function add_status_code
def test_add_status_code():
    class NewException(SanicException):
        pass
    
    add_status_code(666)(NewException)
    assert NewException.status_code == 666

# Generated at 2022-06-12 08:50:30.064476
# Unit test for function add_status_code
def test_add_status_code():
    # assert @add_status_code(404) returns a class decorator that returns a class
    assert inspect.iscoroutinefunction(add_status_code(404))
    assert inspect.isfunction(add_status_code(404)(lambda: ""))
    assert inspect.isclass(add_status_code(404)(type("TestException", (Exception, object), {})))
    
    # assert that @add_status_code(500) raises a ServerError
    with pytest.raises(ServerError, match=r'This is a server error'):
        class ServerErrorTest(Exception):
            pass
        add_status_code(500)(ServerErrorTest)('This is a server error')

# Generated at 2022-06-12 08:50:39.623358
# Unit test for function add_status_code
def test_add_status_code():
    # test added status_code attribute
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    
    # test added status_code attribute on base class
    assert SanicException.status_code is None
    assert SanicException.status_code == None

    # test added quiet attribute
    assert TestException.quiet is None
    assert SanicException.quiet is None
    assert SanicException.quiet == None

    # test added quiet attribute on base class
    assert SanicException.quiet is None
    assert SanicException.quiet == None

    # test added _sanic_exceptions
    assert _sanic_exceptions[200] == TestException

# Generated at 2022-06-12 08:50:45.219820
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    @add_status_code(404)
    class MyException2(SanicException):
        pass

    assert _sanic_exceptions.get(404) == MyException2

    with pytest.raises(TypeError, match='status_code is missing'):
        add_status_code()(MyException)



# Generated at 2022-06-12 08:50:54.241744
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502)
    class SanicException502(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)
            self.status_code = status_code
        
            if quiet or quiet is None and status_code != 500:
                self.quiet = True

    assert 502 in _sanic_exceptions
    assert _sanic_exceptions[502] == SanicException502
    assert SanicException502.__name__ == 'SanicException502'
    assert str(SanicException502) == 'SanicException502'
    assert SanicException502.status_code == 502


# Generated at 2022-06-12 08:51:06.365462
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert TestException(message="test") == TestException(message="test")
    assert TestException(message="test") != NotFound(message="test")
    assert TestException in _sanic_exceptions.values()

    @add_status_code(400, quiet=False)
    class TestException2(SanicException):
        pass
    assert TestException2.status_code == 400
    assert TestException2.quiet == False
    assert TestException2(message="test") == TestException2(message="test")
    assert TestException2(message="test") != NotFound(message="test")
    assert TestException2 in _sanic_exceptions.values

# Generated at 2022-06-12 08:51:10.340165
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestSanicExc(SanicException):
        pass

    assert TestSanicExc.status_code == 400
    assert TestSanicExc.quiet == True
    assert _sanic_exceptions[400] == TestSanicExc


# Generated at 2022-06-12 08:51:15.308789
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418, quiet=True)
    class IAmATeaPot(SanicException):
        pass

    assert IAmATeaPot.status_code == 418
    assert IAmATeaPot.quiet is True
    assert _sanic_exceptions[418] == IAmATeaPot

# Generated at 2022-06-12 08:51:19.035017
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class a(SanicException):
        def __init__(self, message):
            super().__init__(message)
    assert a.status_code == 201
    assert _sanic_exceptions[201] == a

# Generated at 2022-06-12 08:51:23.215626
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound_4(SanicException):
        pass
    assert issubclass(_sanic_exceptions[404], NotFound_4)
    assert not issubclass(_sanic_exceptions[404], SanicException)

# Generated at 2022-06-12 08:51:25.284323
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)(Exception)
    assert _sanic_exceptions[500] == Exception

# Generated at 2022-06-12 08:52:30.694498
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(type("Error404", (Exception,), {}))

# Generated at 2022-06-12 08:52:35.584156
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass
    # add_status_code returns a decorator
    TestException = add_status_code(403)(TestException)
    assert TestException.status_code == 403
    assert TestException.quiet == False

    @add_status_code(404, quiet=True)
    class TestException2(SanicException):
        pass
    assert TestException2.status_code == 404
    assert TestException2.quiet == True

# Generated at 2022-06-12 08:52:38.571614
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class My403Exception(SanicException):
        pass
    assert _sanic_exceptions[403] is My403Exception
    assert _sanic_exceptions[500] is ServerError

# Generated at 2022-06-12 08:52:42.497167
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200, False)
    class test(SanicException):
        pass
    t = test("test")
    assert t.status_code == 200
    assert not t.quiet


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:52:50.740964
# Unit test for function add_status_code
def test_add_status_code():
    assert isinstance(
        NotFound("message", status_code=404),
        NotFound
    )
    assert isinstance(
        NotFound("message", status_code=404),
        SanicException
    )
    assert isinstance(
        NotFound("message"),
        NotFound
    )
    assert isinstance(
        NotFound("message"),
        SanicException
    )
    assert isinstance(
        Forbidden("message", status_code=403),
        Forbidden
    )
    assert isinstance(
        Forbidden("message"),
        Forbidden
    )
    assert isinstance(
        NotFound("message"),
        SanicException
    )
    assert isinstance(
        Forbidden("message"),
        SanicException
    )


# Generated at 2022-06-12 08:53:00.397898
# Unit test for function add_status_code
def test_add_status_code():
    from datetime import datetime
    import pytest
    from sanic import Sanic

    # Error with status code equal to 500
    @add_status_code(500)
    class Error500(SanicException):
        pass

    # Error with status code equal to 200
    @add_status_code(200)
    class Error200(SanicException):
        pass

    # Error with status code equal to 400 and quiet=False
    @add_status_code(400, quiet=False)
    class Error400(SanicException):
        pass

    # Error with status code equal to 400 and quiet=True
    @add_status_code(400, quiet=True)
    class ErrorTrue(SanicException):
        pass

    # Error with status code equal to 300 and quiet=None

# Generated at 2022-06-12 08:53:08.851199
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(404)
    class NotFoundException(Exception):
        pass

    assert add_status_code(404, False) is add_status_code(404)

    @add_status_code(404)
    class NotFoundException(Exception):
        pass

    assert add_status_code(500) is add_status_code(500, False)

    @add_status_code(500)
    class ServerErrorException(Exception):
        pass

    assert _sanic_exceptions[404] is NotFoundException
    assert _sanic_exceptions[500] is ServerErrorException

# Generated at 2022-06-12 08:53:10.868128
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert(BadRequest.status_code == 400)

# Generated at 2022-06-12 08:53:13.412554
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 200
    assert issubclass(_sanic_exceptions[200], MyException)

# Generated at 2022-06-12 08:53:16.565636
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest(message="BadRequest").status_code == 400