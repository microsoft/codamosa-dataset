

# Generated at 2022-06-12 08:44:41.066371
# Unit test for function add_status_code
def test_add_status_code():
    class Bar(SanicException):
        pass

    add_status_code(404)(Bar)

    assert hasattr(Bar, 'status_code')
    assert Bar.status_code == 404
    assert Bar.quiet is False

    assert isinstance(abort(404), Bar)

# Generated at 2022-06-12 08:44:49.539988
# Unit test for function add_status_code
def test_add_status_code():
    # Create a fake exception
    __exception = namedtuple("__exception", ("message", "status_code"))

    # Set status code and quiet
    _sanic_exceptions[500] = __exception(message="", status_code=500)
    assert _sanic_exceptions[500].status_code == 500
    assert not _sanic_exceptions[500].quiet

    # Add status code
    add_status_code(501)(__exception)
    assert _sanic_exceptions[501].status_code == 501
    assert _sanic_exceptions[501].quiet

    # Add status_code and quiet
    add_status_code(502, quiet=False)(__exception)
    assert _sanic_exceptions[502].status_code == 502

# Generated at 2022-06-12 08:44:56.418967
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502, quiet=False)
    class BadGateway(SanicException):
        """
        **Status**: 502 Bad Gateway
        """

        pass

    assert BadGateway.__name__ == "BadGateway"
    assert BadGateway.status_code == 502
    assert BadGateway.quiet is False
    assert _sanic_exceptions[502] == BadGateway

# Generated at 2022-06-12 08:45:00.585349
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class RequestTimeout(SanicException):
        pass

    RequestTimeout_instance = RequestTimeout('408 Request Timeout')
    assert RequestTimeout_instance.status_code == 408



# Generated at 2022-06-12 08:45:06.317905
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(asd=200)
    class A:
        pass
    assert getattr(A, 'asd', None) == 200



# Generated at 2022-06-12 08:45:09.434802
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code('test')
    class SampleException(SanicException):
        pass

    try:
        raise SampleException('', status_code='test')
    except SampleException:
        pass
    else:
        assert False, 'SampleException is not registered'

# Generated at 2022-06-12 08:45:10.878181
# Unit test for function add_status_code
def test_add_status_code():

    class CustomException(SanicException):
        pass

    add_status_code(404)(CustomException)



# Generated at 2022-06-12 08:45:14.232593
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=401)
    class SanicException401(SanicException):
        pass
    assert SanicException401.status_code == 401
    assert _sanic_exceptions[401] == SanicException401



# Generated at 2022-06-12 08:45:26.341586
# Unit test for function add_status_code
def test_add_status_code():
    def ver_class(code, as_cls):
        assert _sanic_exceptions[code] == as_cls
        assert _sanic_exceptions[code].status_code == code
        assert _sanic_exceptions[code].quiet

    def ver_exception(code, ex):
        assert isinstance(ex, _sanic_exceptions[code])
        assert ex.status_code == code
        assert not ex.quiet
        assert str(ex) == STATUS_CODES[code].decode("utf8")

    @add_status_code(999, quiet=True)
    class NewClass(SanicException):
        pass

    ver_class(999, NewClass)


# Generated at 2022-06-12 08:45:32.812052
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions.clear()

    @add_status_code(999)
    class TestException(Exception):
        pass

    assert len(_sanic_exceptions) == 1
    assert _sanic_exceptions[999] == TestException

    @add_status_code(998)
    class OtherTest(Exception):
        pass

    assert len(_sanic_exceptions) == 2
    assert _sanic_exceptions[998] == OtherTest

# Generated at 2022-06-12 08:45:37.399634
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class Test(SanicException):
        pass

    assert Test.status_code == 444
    assert Test.quiet == True

# Generated at 2022-06-12 08:45:41.719447
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(800)
    class TestException(SanicException):
        pass
    try:
        raise TestException()
    except TestException as e:
        assert e.status_code == 800
        assert e.quiet is None

# Generated at 2022-06-12 08:45:45.337915
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class ABCException(SanicException):
        pass
    assert ABCException.status_code == 123
    assert isinstance(_sanic_exceptions[123], ABCException)



# Generated at 2022-06-12 08:45:51.533748
# Unit test for function add_status_code
def test_add_status_code():
    # Given
    code = 404

    # When
    @add_status_code(code)
    class MyException(SanicException):
        def __init__(self, message, status_code=None):
            super().__init__(message, status_code)

    # Then
    assert MyException.status_code == code
    assert _sanic_exceptions[code] == MyException


# Generated at 2022-06-12 08:45:53.855288
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(500)
    assert add_status_code(200)


# Generated at 2022-06-12 08:46:04.640859
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass
    try:
        raise CustomException()

    except _sanic_exceptions[400] as e:
        assert isinstance(e, SanicException)
        assert isinstance(e, CustomException)
        assert e.status_code == 400
        assert e.quiet is True

    except Exception as e:
        assert Exception == e

    try:
        raise _sanic_exceptions[400]()
    except SanicException as e:
        assert isinstance(e, CustomException)

    @add_status_code(500)
    class CustomException(SanicException):
        pass
    try:
        raise CustomException()
    except SanicException as e:
        assert isinstance(e, SanicException)
        assert isinstance

# Generated at 2022-06-12 08:46:11.538027
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.exceptions import abort
    # Create a new status code:
    code = 418
    @add_status_code(code)
    class IAmATeapot(SanicException):
        """
        You tried to brew coffee with a teapot. How quaint.
        """
        pass
    # Use abort() to raise the new status code:
    abort(code, "I'm a teapot")
    # This will raise an IAmATeapot exception:
    # abort(418, "I'm a teapot")

# Generated at 2022-06-12 08:46:18.542060
# Unit test for function add_status_code
def test_add_status_code():
    # add_status_code class decorator
    @add_status_code(200)
    class OK(SanicException):
        def __init__(self, message="OK", status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)

    assert OK.status_code == 200
    assert OK.quiet == True
    assert len(_sanic_exceptions) == 9
    assert _sanic_exceptions[OK.status_code] == OK
    assert isinstance(OK("OK"), OK)
    assert issubclass(OK, SanicException)

    @add_status_code(501)
    class NotImplemented(SanicException):
        def __init__(self, message="Not Implemented", status_code=None, quiet=None):
            super().__init__

# Generated at 2022-06-12 08:46:21.320340
# Unit test for function add_status_code
def test_add_status_code():
    code = 400

    class AddStatusCodeException(Exception):
        pass

    add_status_code(code)(AddStatusCodeException)
    
    assert _sanic_exceptions[code] == AddStatusCodeException

# Generated at 2022-06-12 08:46:25.892856
# Unit test for function add_status_code
def test_add_status_code():
    class MyException:
        status_code = None

    add_status_code(100)(MyException)
    assert MyException.status_code == 100

    add_status_code(100, quiet=False)(MyException)
    assert MyException.status_code == 100

# Generated at 2022-06-12 08:46:33.795536
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class TestException(SanicException):
        pass

    # Assert the TestException has been added to the _sanic_exceptions dict
    assert TestException in _sanic_exceptions.values()

# Generated at 2022-06-12 08:46:36.529737
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(status_code=400)
    class TestException(SanicException):
        pass

    assert TestException(message="Test").status_code == 400


# Generated at 2022-06-12 08:46:46.149155
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(405)
    class MyException(SanicException):
        """
        **Status**: 405 Method Not Allowed
        """

        def __init__(self, message, method, allowed_methods):
            super().__init__(message)
            self.headers = {"Allow": ", ".join(allowed_methods)}

    my_exception = MyException("message", "GET", ["POST"])
    assert isinstance(my_exception, MyException)
    assert isinstance(my_exception, SanicException)
    assert my_exception.status_code == 405
    assert my_exception.headers['Allow'] == 'POST'
    assert my_exception.quiet is False

# Generated at 2022-06-12 08:46:56.213539
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(Exception):
        pass
    foo = add_status_code(400)(MyException)
    assert foo.status_code == 400
    assert foo not in _sanic_exceptions.values()
    _sanic_exceptions[400] = foo
    bar = add_status_code(401)(MyException)
    assert bar.status_code == 401
    assert bar not in _sanic_exceptions.values()
    _sanic_exceptions[401] = bar
    baz = add_status_code(402, quiet=False)(MyException)
    assert baz.status_code == 402
    assert baz.quiet == False
    assert baz not in _sanic_exceptions.values()
    _sanic_exceptions[402] = baz

# Generated at 2022-06-12 08:47:01.440240
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(406)
    class NotAcceptable(SanicException):
        pass

    @add_status_code(406, quiet=True)
    class NotAcceptableQuiet(SanicException):
        pass

    assert NotAcceptable.status_code == 406
    assert NotAcceptable.quiet == False
    assert NotAcceptableQuiet.status_code == 406
    assert NotAcceptableQuiet.quiet == True

# Generated at 2022-06-12 08:47:13.258098
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(Exception):
        pass

    def __init__(self, message, status_code=None, quiet=None):
        super().__init__(message)

        if status_code is not None:
            self.status_code = status_code

    add_status_code(408, quiet=False)(MyException)
    assert MyException.status_code == 408
    assert MyException.quiet == False
    add_status_code(500)(MyException)
    assert MyException.status_code == 408
    assert MyException.quiet == False
    add_status_code(200)(MyException)
    assert MyException.status_code == 408
    assert MyException.quiet == False
    add_status_code(201)(MyException)
    assert MyException.status_code == 201
    assert MyException.quiet == True


# Generated at 2022-06-12 08:47:18.571571
# Unit test for function add_status_code
def test_add_status_code():
    class Test1(SanicException):
        pass
    class Test2(SanicException):
        quiet = True
    class Test3(SanicException):
        quiet = False

    assert Test1().status_code is None
    assert not hasattr(Test1, "quiet")
    assert Test2().status_code is None
    assert Test3().status_code is None

    # Test the decorator with different arguments
    add_status_code(418)(Test1)
    assert Test1.status_code == 418
    assert hasattr(Test1, "quiet")
    assert not Test1().quiet

    # Test the decorator with different arguments
    add_status_code(418, True)(Test2)
    assert Test2.status_code == 418
    assert Test2().quiet

    # Test the decorator with different arguments
    add_

# Generated at 2022-06-12 08:47:22.355729
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class AuthError(SanicException):
        pass

    assert AuthError.status_code == 401


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:23.880613
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        """
        **Status**: 401 Unauthorized
        """
        pass
    assert '401 Unauthorized' in str(Unauthorized)

# Generated at 2022-06-12 08:47:27.404032
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class StatusCode500(SanicException):
        pass
    assert StatusCode500.status_code == 500
    assert _sanic_exceptions[500] == StatusCode500



# Generated at 2022-06-12 08:47:46.822680
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class SanicException400(SanicException):
        pass

    @add_status_code(500)
    class SanicException500(SanicException):
        pass

    @add_status_code(500, False)
    class SanicException500QuietFalse(SanicException):
        pass

    assert SanicException400.status_code == 400
    assert SanicException500.status_code == 500
    assert SanicException500.quiet is False
    assert SanicException500QuietFalse.status_code == 500
    assert SanicException500QuietFalse.quiet is False

    @add_status_code(400)
    class SanicException400QuietByDefault(SanicException):
        pass

    assert SanicException400QuietByDefault.status_code == 400

# Generated at 2022-06-12 08:47:50.850338
# Unit test for function add_status_code
def test_add_status_code():
    # This test is just to check that adding a new exception works

    @add_status_code(418, quiet=True)
    class IAmATeapot(SanicException):
        pass

    assert _sanic_exceptions[418] == IAmATeapot

# Generated at 2022-06-12 08:47:58.570555
# Unit test for function add_status_code
def test_add_status_code():

    def raise_status_code(status_code):
        raise abort(status_code)

    raise_status_code(404)
    raise_status_code(400)
    try:
        raise_status_code(500)
    except SanicException:
        pass
    else:
        raise AssertionError("SanicException should have been raised.")

    @add_status_code(200)
    class MySanicException(SanicException):
        pass

    @add_status_code(201)
    class MySanicException2(SanicException):
        pass

    assert 200 in _sanic_exceptions
    assert 201 in _sanic_exceptions

    raise_status_code(200)
    raise_status_code(201)

# Generated at 2022-06-12 08:48:10.033034
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(404, quiet=False)
    class NotFoundQuietFalse(SanicException):
        pass

    @add_status_code(404, quiet=True)
    class NotFoundQuietTrue(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404] == NotFoundQuietFalse
    assert _sanic_exceptions[404] == NotFoundQuietTrue

    assert NotFound().status_code == 404
    assert NotFoundQuietFalse().status_code == 404
    assert NotFoundQuietTrue().status_code == 404

    assert NotFound().quiet == None
    assert NotFoundQuietFalse().quiet == False

# Generated at 2022-06-12 08:48:14.465464
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 420

    @add_status_code(status_code)
    class TestException(SanicException):
        pass

    assert TestException.status_code == status_code
    assert _sanic_exceptions[status_code] == TestException



# Generated at 2022-06-12 08:48:18.174253
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert BadGateway.status_code == 502
    assert BadGateway.quiet is False
    

# Generated at 2022-06-12 08:48:26.036639
# Unit test for function add_status_code
def test_add_status_code():
    # Test if add_status_code register exception properly
    assert 500 not in _sanic_exceptions
    @add_status_code(500)
    class NewException(SanicException):
        pass
    assert 500 in _sanic_exceptions
    assert _sanic_exceptions[500] == NewException
    # Test if add_status_code can add exception without quiet
    assert _sanic_exceptions[500]().quiet is False
    assert _sanic_exceptions[500](quiet=False).quiet is False
    assert _sanic_exceptions[500](quiet=True).quiet is True
    assert _sanic_exceptions[500](quiet=None).quiet is False
    # Test if add_status_code can add exception with quiet

# Generated at 2022-06-12 08:48:30.165578
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        """
        **Status**: 400 Bad Request
        """
        pass

    assert _sanic_exceptions[400].__name__ == "MyException"


# Generated at 2022-06-12 08:48:39.672633
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(444, quiet=True)
    class A(SanicException):
        pass

    @add_status_code(445, quiet=False)
    class C(SanicException):
        pass

    @add_status_code(446)
    class B(SanicException):
        pass

    assert A.status_code == 444
    assert B.status_code == 446
    assert C.status_code == 445
    assert _sanic_exceptions[444] == A
    assert _sanic_exceptions[446] == B
    assert _sanic_exceptions[445] == C
    assert _sanic_exceptions[446].quiet is None
    assert _sanic_exceptions[445].quiet == False
    assert _sanic_exceptions[444].quiet == True

# Generated at 2022-06-12 08:48:43.644021
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        """
        **Status**: 400 Bad Request
        """
        pass
    BadRequest(message="BadRequest")

if __name__=="__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:05.454192
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class Create(SanicException):
        pass

    assert Create.status_code == 201
    assert Create.quiet == True

    @add_status_code(500, False)
    class Error(SanicException):
        pass

    assert Error.status_code == 500
    assert Error.quiet == False

    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert BadGateway.status_code == 502
    assert BadGateway.quiet == True

# Generated at 2022-06-12 08:49:07.904167
# Unit test for function add_status_code
def test_add_status_code():
    class Exception1(SanicException):
        pass

    add_status_code(302)(Exception1)
    assert _sanic_exceptions[302] == Exception1

# Generated at 2022-06-12 08:49:11.904512
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 200
    assert _sanic_exceptions[200] is not None
    assert _sanic_exceptions[200] == CustomException

# Generated at 2022-06-12 08:49:17.049563
# Unit test for function add_status_code
def test_add_status_code():
    """
    test add_status_code for decorator
    """
    @add_status_code(403, True)
    class Test(SanicException):
        """
        **Status**: 403 Forbidden
        """
        pass

    assert Test.status_code == 403
    assert Test.quiet == True
    assert _sanic_exceptions[403].__name__ == 'Test'

# Generated at 2022-06-12 08:49:19.501706
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(500)


if __name__ == "__main__":
    import pytest

    pytest.main(["test_exceptions.py"])

# Generated at 2022-06-12 08:49:23.956202
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    assert not hasattr(MyException, 'status_code')
    add_status_code(404)(MyException)
    assert MyException.status_code == 404
    assert 404 in _sanic_exceptions.keys()
    assert MyException == _sanic_exceptions[404]

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:28.589746
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    test_class = add_status_code(1001, quiet=True)(TestClass)

    assert test_class == TestClass
    assert test_class.status_code == 1001
    assert test_class.quiet is True
    assert test_class(message="Test Error")



# Generated at 2022-06-12 08:49:32.820575
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator(f):
        def wrapper(a, b):
            return f(a, b)
        return wrapper

    add_status_code(200)(test_decorator)(lambda x, y: x + y, 1, 2)


test_add_status_code()

# Generated at 2022-06-12 08:49:37.008838
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 200
    @add_status_code(status_code)
    class CustomException(SanicException):
        pass

    assert status_code in _sanic_exceptions
    assert CustomException.status_code == status_code

# Generated at 2022-06-12 08:49:47.618087
# Unit test for function add_status_code
def test_add_status_code():
    # Create a new exception class with a status code
    class Foo(SanicException):
        pass

    # register it in the registry
    add_status_code(400)(Foo)

    # update the registry with a new status code
    add_status_code(401)(Foo)

    # ensure the old status code was replaced and that the new one is there
    assert 400 not in _sanic_exceptions
    assert _sanic_exceptions[401] == Foo
    assert _sanic_exceptions[401]().status_code == 401

    # ensure the old status code was replaced and that the new one is there
    # there's no status code passed in for the class, so it defaults to 500
    add_status_code(500)(Foo)
    assert _sanic_exceptions[500] == Foo
    assert _sanic_

# Generated at 2022-06-12 08:50:26.039724
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404]().message == NotFound().message

# Generated at 2022-06-12 08:50:29.616849
# Unit test for function add_status_code
def test_add_status_code():
    # Testing the docstring example
    assert _sanic_exceptions[401].headers == {
        "WWW-Authenticate": 'Bearer realm="Restricted Area"'
    }


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:50:32.544531
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        pass

    add_status_code(403)(CustomException)
    assert _sanic_exceptions[403].__name__ == "CustomException"



# Generated at 2022-06-12 08:50:35.232849
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    assert _sanic_exceptions[501] == NotImplemented



# Generated at 2022-06-12 08:50:41.179304
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410)
    class Gone(SanicException):
        pass

    assert Gone.status_code == 410
    assert _sanic_exceptions.get(410) == Gone

    @add_status_code(507, quiet=True)
    class InsufficientStorage(SanicException):
        pass

    assert InsufficientStorage.status_code == 507
    assert _sanic_exceptions.get(507) == InsufficientStorage

# Generated at 2022-06-12 08:50:51.785859
# Unit test for function add_status_code
def test_add_status_code():
    class MockException(SanicException):
        pass
    cls = add_status_code(500)(MockException)
    assert cls.status_code == 500
    assert cls.quiet is None

    cls = add_status_code(500, True)(MockException)
    assert cls.status_code == 500
    assert cls.quiet is True

    cls = add_status_code(400)(MockException)
    assert cls.status_code == 400
    assert cls.quiet is True

    cls = add_status_code(400, False)(MockException)
    assert cls.status_code == 400
    assert cls.quiet is False


async def test_abort(app):
    @app.get("/")
    def handler(request):
        abort(400)



# Generated at 2022-06-12 08:51:00.769487
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class CustomException(SanicException):
        def __init__(self, message):
            super().__init__(message, status_code=404)

    class CustomException2(SanicException):
        status_code = 500

    _sanic_exceptions[CustomException.status_code] = CustomException
    _sanic_exceptions[CustomException2.status_code] = CustomException2

    assert _sanic_exceptions[404] == CustomException
    assert _sanic_exceptions[500] == CustomException2

# Generated at 2022-06-12 08:51:07.107759
# Unit test for function add_status_code
def test_add_status_code():
    class Exception400(SanicException):
        pass

    # Add status code to an already existing class
    # Code 400 already exists
    add_status_code(400)(Exception400)

    # Add status code to a new class
    exception_400 = add_status_code(400)(SanicException)
    assert isinstance(exception_400, SanicException)
    assert exception_400.status_code == 400



# Generated at 2022-06-12 08:51:10.720509
# Unit test for function add_status_code
def test_add_status_code():
    # Test the function add_status_code

    @add_status_code(400)
    class NewException(SanicException):
        pass
    assert 400 in _sanic_exceptions
    assert _sanic_exceptions[400] == NewException

# Generated at 2022-06-12 08:51:19.233842
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 1
    assert TestClass().status_code == 1
    assert _sanic_exceptions[1] is TestClass

    @add_status_code(2, True)
    class TestClass2(SanicException):
        pass

    assert TestClass2.status_code == 2
    assert TestClass2().status_code == 2
    assert TestClass2().quiet
    assert _sanic_exceptions[2] is TestClass2

    @add_status_code(3)
    class TestClass3(SanicException):
        pass

    assert TestClass3.status_code == 3
    assert TestClass3().status_code == 3
    assert not TestClass3().quiet
    assert _sanic

# Generated at 2022-06-12 08:52:43.126719
# Unit test for function add_status_code
def test_add_status_code():
    class MyClass(SanicException):
        pass

    test_code = 100

    # test if status_code is set
    assert add_status_code(test_code)(MyClass).status_code == test_code

    # test if quiet is set
    assert add_status_code(test_code, True)(MyClass).quiet == True
    assert add_status_code(test_code, False)(MyClass).quiet == False
    assert add_status_code(test_code, None)(MyClass).quiet == False
    assert add_status_code(test_code, True)(SanicException).quiet == True
    assert add_status_code(test_code, False)(SanicException).quiet == False
    assert add_status_code(test_code, None)(SanicException).quiet == False

# Generated at 2022-06-12 08:52:46.242683
# Unit test for function add_status_code
def test_add_status_code():
    # This is a exception class
    @add_status_code(411)
    class identity(SanicException):
        pass

    # Make sure the status code is added to the class
    assert identity.status_code == 411
    assert _sanic_exceptions.get(411) == identity

# Generated at 2022-06-12 08:52:50.804947
# Unit test for function add_status_code
def test_add_status_code():
    import pytest
    class TestException(SanicException):
        pass

    @add_status_code(403)
    class TestException(SanicException):
        pass

    test_exception = TestException(message="test", status_code=403)

    # Test that the status code is assigned correctly
    assert test_exception.status_code == 403

    # Test that the quiet variable is assigned correctly
    assert test_exception.quiet is True

# Generated at 2022-06-12 08:52:52.921535
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class Testing(SanicException):
        pass
    assert _sanic_exceptions.get(403) == Testing

# Generated at 2022-06-12 08:52:57.571837
# Unit test for function add_status_code
def test_add_status_code():
    class Base(SanicException):
        pass

    @add_status_code(101, quiet=True)
    class MyException(Base):
        pass

    assert issubclass(MyException, Base)
    assert MyException.status_code == 101
    assert MyException.quiet is True
    assert _sanic_exceptions[101] is MyException



# Generated at 2022-06-12 08:53:00.970804
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[444] == TestException
    assert _sanic_exceptions.get(444).status_code == 444

# Generated at 2022-06-12 08:53:11.410515
# Unit test for function add_status_code
def test_add_status_code():
    # Test with status code and quiet parameter
    @add_status_code(418, False)
    class IAmATeapot(SanicException):
        pass

    assert hasattr(IAmATeapot, "status_code")
    assert IAmATeapot.status_code == 418

    assert hasattr(IAmATeapot, "quiet")
    assert IAmATeapot.quiet == False

    # Test with status code, quiet parameter is None
    # class IAmATeapot(SanicException):
    #     pass
    @add_status_code(418, None)
    def IAmATeapot():
        pass

    assert hasattr(IAmATeapot, "status_code")
    assert IAmATeapot.status_code == 418


# Generated at 2022-06-12 08:53:18.352949
# Unit test for function add_status_code
def test_add_status_code():
    class AbcdError(SanicException):
        pass
    _code = 100
    add_status_code(_code)(AbcdError)
    assert _sanic_exceptions[_code] is AbcdError
    assert AbcdError.status_code is _code
    assert AbcdError.__qualname__ == 'AbcdError'
    assert AbcdError.__str__().startswith('AbcdError')
    err = AbcdError()
    assert err.status_code is _code
    assert str(err).startswith('AbcdError')
    assert err.__str__().startswith('AbcdError')
    err = AbcdError(message='Log error')
    assert err.status_code is _code
    assert str(err) == 'Log error'
    assert err.__str__() == 'Log error'

# Generated at 2022-06-12 08:53:22.236782
# Unit test for function add_status_code
def test_add_status_code():
    class TestCase(SanicException):
        pass

    # Add @add_status_code to TestCase
    add_status_code(200)(TestCase)

    # Test TestCase
    assert TestCase.status_code == 200
    assert TestCase.quiet is True



# Generated at 2022-06-12 08:53:29.158928
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(900)
    class DummyException(SanicException):
        pass

    assert DummyException.status_code == 900
    assert DummyException().status_code == 900

    @add_status_code(100, quiet=True)
    class DummyException(SanicException):
        pass

    assert DummyException.quiet

    @add_status_code(200)
    class DummyException(SanicException):
        pass

    assert not DummyException.quiet

