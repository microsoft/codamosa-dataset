

# Generated at 2022-06-12 08:44:31.512550
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized("Unauthorized", status_code=401, scheme="Basic",
                           realm="Restricted Area")
    assert (str(excinfo.value) == "Unauthorized")
    assert (excinfo.value.status_code == 401)
    assert (excinfo.value.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'})


# Unit testing for constructor of class SanicException

# Generated at 2022-06-12 08:44:38.674466
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as exc:
        assert exc.status_code == 401
        assert exc.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

    try:
        # With a Digest auth-scheme, things are a bit more complicated:
        raise Unauthorized(
            "Auth required.",
            scheme="Digest",
            realm="Restricted Area",
            qop="auth, auth-int",
            algorithm="MD5",
            nonce="abcdef",
            opaque="zyxwvu",
        )
    except Unauthorized as exc:
        assert exc.status_code == 401

# Generated at 2022-06-12 08:44:43.703869
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    caught_exception = None
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        caught_exception = e

    assert caught_exception.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

# Generated at 2022-06-12 08:44:51.720872
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class CustomServerError(ServerError):
        def __init__(self, message, status_code=None, quiet=None, test=None):
            super().__init__(message)
            self.status_code = status_code
            self.test = test
            if test:
                self.test_result = "function add_status_code worked"
            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    assert CustomServerError(message="Test", status_code=500, test=True).test_result == "function add_status_code worked"

# Generated at 2022-06-12 08:44:56.688426
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.",scheme="Basic", realm="Restricted Area")
    except Unauthorized:
        print(Unauthorized.headers)
        print(Unauthorized.status_code)
        print(Unauthorized.scheme)
        assert Unauthorized.headers == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""}
        assert Unauthorized.status_code == 401
        assert Unauthorized.scheme == "Basic"

# Generated at 2022-06-12 08:44:58.991074
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    except Exception as e:
        return e.headers

# Generated at 2022-06-12 08:45:00.123310
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    pass

# Generated at 2022-06-12 08:45:12.235074
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    u = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert u.message == "Auth required."
    assert u.status_code == 401
    assert u.headers == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""}

    u = Unauthorized("Auth required.", scheme="Digest",
                     realm="Restricted Area",
                     qop="auth, auth-int", algorithm="MD5",
                     nonce="abcdef", opaque="zyxwvu")
    assert u.headers == {"WWW-Authenticate": "Digest realm=\"Restricted Area\", "
                                             "qop=\"auth, auth-int\", "
                                             "algorithm=MD5, "
                                             "nonce=\"abcdef\", "
                                             "opaque=\"zyxwvu\""}
    u = Un

# Generated at 2022-06-12 08:45:22.440592
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    e = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert e.headers['WWW-Authenticate'] == "Basic realm=\"Restricted Area\""

    e = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert e.headers['WWW-Authenticate'] == "Digest realm=\"Restricted Area\", qop=\"auth, auth-int\", algorithm=\"MD5\", nonce=\"abcdef\", opaque=\"zyxwvu\""

    e = Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    assert e.headers['WWW-Authenticate'] == "Bearer realm=\"Restricted Area\""


# Generated at 2022-06-12 08:45:28.194682
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.scheme == "Basic"
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    else:
        raise Exception("Exception not raised.")

# Generated at 2022-06-12 08:45:34.449102
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class TestException(SanicException):
        """This is a test exception"""

    assert TestException.status_code == 123
    assert TestException.__doc__ == 'This is a test exception'
    assert _sanic_exceptions[123] == TestException



# Generated at 2022-06-12 08:45:36.424312
# Unit test for function add_status_code
def test_add_status_code():
    test_exception = add_status_code(418)(SanicException)

    assert test_exception.status_code == 418



# Generated at 2022-06-12 08:45:43.074717
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410, True)
    class TestException(SanicException):
        def __init__(self, message):
            super().__init__(message, status_code=410, quiet=True)
    
    _exception = TestException('test')
    assert _exception.status_code == 410
    assert _exception.quiet is True

# Generated at 2022-06-12 08:45:45.368284
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass
    assert issubclass(MyException, SanicException)
    assert _sanic_exceptions[404] == MyException


# Generated at 2022-06-12 08:45:48.119870
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[404] == TestException


# Generated at 2022-06-12 08:45:59.561333
# Unit test for function add_status_code
def test_add_status_code():
    def decorated_function(cls):
        pass


    code_arg = 1
    code_kwarg = 2

    # Test decorator
    decorator = add_status_code(code_arg, True)
    decorated_function_test = decorator(decorated_function)
    assert decorated_function_test.status_code == code_arg
    assert decorated_function_test.quiet == True

    decorator = add_status_code(code_kwarg)
    decorated_function_test = decorator(decorated_function)
    assert decorated_function_test.status_code == code_kwarg
    assert decorated_function_test.quiet == True

    decorator = add_status_code(code_kwarg, False)
    decorated_function_test = decorator(decorated_function)
    assert decorated_function

# Generated at 2022-06-12 08:46:03.635206
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(503)
    class UnitTest(SanicException):
        pass
    assert STATUS_CODES[503].decode("utf8") == UnitTest("").message
if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:06.841946
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert _sanic_exceptions[404] == TestException

# Generated at 2022-06-12 08:46:11.789771
# Unit test for function add_status_code
def test_add_status_code():
    # Test for function add_status_code
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[400] is TestException
    assert _sanic_exceptions[400]() is not None


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:17.500254
# Unit test for function add_status_code
def test_add_status_code():
    class my_exception(SanicException):
        status_code = 511
        message = "Network authentication required"

    assert my_exception.status_code == 511
    assert my_exception.message == "Network authentication required"

    @add_status_code(511)
    class my_exception(SanicException):
        pass

    assert my_exception.status_code == 511
    assert my_exception.message == ""
    assert _sanic_exceptions[511] == my_exception


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:28.271613
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert len(_sanic_exceptions) != 0
    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-12 08:46:33.188039
# Unit test for function add_status_code
def test_add_status_code():
    '''
    This is a unit test for the add_status_code function
    '''
    @add_status_code(987)
    class SanicCode987(SanicException):
        pass

    test_exception = SanicCode987("This is a test.")
    assert test_exception.status_code == 987

# Generated at 2022-06-12 08:46:37.292402
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    assert MyException.status_code is None
    add_status_code(42)(MyException)
    assert MyException.status_code == 42

    # Test that SanicException is correctly linked to the status code
    assert _sanic_exceptions[42] is MyException


# Generated at 2022-06-12 08:46:48.491625
# Unit test for function add_status_code
def test_add_status_code():
    # test status code
    assert NotFound.status_code==404
    assert InvalidUsage.status_code==400
    assert MethodNotSupported.status_code==405
    assert ServerError.status_code==500
    assert ServiceUnavailable.status_code==503
    assert URLBuildError.status_code==500
    assert FileNotFound.status_code==404
    assert RequestTimeout.status_code==408
    assert PayloadTooLarge.status_code==413
    assert HeaderNotFound.status_code==400
    assert ContentRangeError.status_code==416
    assert HeaderExpectationFailed.status_code==417
    assert Forbidden.status_code==403
    assert InvalidRangeType.status_code==416
    assert PyFileError.status_code==None
    assert Unauthorized.status_code==401
    assert LoadFile

# Generated at 2022-06-12 08:46:53.255449
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=404)
    class NotFound(SanicException):
         pass

    assert STATUS_CODES[404] == '404 Not Found'

if __name__ == "__main__":
    # Unit test for function add_status_code
    test_add_status_code()

# Generated at 2022-06-12 08:46:56.978318
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert issubclass(_sanic_exceptions.get(418), IAmATeaPot)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:04.095438
# Unit test for function add_status_code
def test_add_status_code():
    # Test 1
    class MyException(SanicException):
        pass
    assert MyException.status_code is None
    assert MyException.quiet is None
    print("Pass Test1.")

    # Test 2
    add_status_code(404)(MyException)
    assert MyException.status_code == 404
    assert MyException.quiet is True
    print("Pass Test2.")

    # Test 3
    add_status_code(500)(MyException)
    assert MyException.status_code == 500
    assert MyException.quiet is None
    print("Pass Test3.")



# Generated at 2022-06-12 08:47:07.552992
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(201)
    class Created(Exception):
        pass

    assert Created.status_code == 201


# Unit tests for function abort

# Generated at 2022-06-12 08:47:11.729985
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert len(_sanic_exceptions) == 7
    assert _sanic_exceptions[400].__name__ == 'MyException'

# Generated at 2022-06-12 08:47:18.133879
# Unit test for function add_status_code
def test_add_status_code():
    # test for decorator
    @add_status_code(400)
    class MyException(SanicException):
        pass
    assert MyException.status_code == 400

    # test for class generator
    exception_cls = add_status_code(401)(SanicException)
    assert exception_cls is SanicException
    assert exception_cls.status_code == 401

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:47:26.258636
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(302)
    class A(SanicException):
        pass

    assert A().status_code == 302

# Generated at 2022-06-12 08:47:29.712828
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        """
        **Status**: 501 Not Implemented
        """
        pass
    assert _sanic_exceptions[501] == NotImplemented


# Generated at 2022-06-12 08:47:35.856766
# Unit test for function add_status_code
def test_add_status_code():
    """
    When add_status_code() is used as decorator function for a class,
    status code of the class is updated to class itself and class is added to
    sanic exception
    """
    @add_status_code(505)
    class CustomException(Exception):
        pass

    # Status code of CustomException is updated to 505
    assert CustomException.status_code == 505
    # CustomException is added to _sanic_exception
    assert _sanic_exceptions[505] == CustomException


# Generated at 2022-06-12 08:47:38.716177
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Refuse(SanicException):
        pass

    assert Refuse.status_code == 400
    assert Refuse.quiet is None

# Generated at 2022-06-12 08:47:49.474083
# Unit test for function add_status_code
def test_add_status_code():
    def dummy_func():
        pass

    @add_status_code(123, quiet=False)
    class Dummy():
        pass

    assert Dummy.status_code == 123
    assert Dummy.quiet == False
    assert Dummy.__doc__ == "Dummy"
    assert Dummy.__module__ == __name__

    @add_status_code(123, quiet=True)
    class Dummy2():
        pass

    assert Dummy2.status_code == 123
    assert Dummy2.quiet == True
    assert Dummy2.__doc__ == "Dummy2"
    assert Dummy2.__module__ == __name__

    @add_status_code(123)
    class Dummy3():
        pass

    assert Dummy3.status_code == 123

# Generated at 2022-06-12 08:47:58.102542
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(999)
    class NewException(Exception):
        pass

    assert NewException.status_code == 999
    assert NewException.__name__ == "NewException"
    assert getattr(NewException, "quiet") is None
    assert _sanic_exceptions[999] == NewException

    @add_status_code(888)
    class AnotherException(Exception):
        def __init__(self, message, a=None, b=None):
            super().__init__(message)
            self.a = a
            self.b = b

    assert AnotherException.status_code == 888
    assert AnotherException.__name__ == "AnotherException"
    assert _sanic_exceptions[888] == AnotherException


# Generated at 2022-06-12 08:48:01.389863
# Unit test for function add_status_code
def test_add_status_code():
    class NewStatus(SanicException):
        pass

    add_status_code(123)(NewStatus)
    assert _sanic_exceptions[123] == NewStatus


# Generated at 2022-06-12 08:48:12.488554
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class TestException(SanicException):
        pass
    assert hasattr(TestException, "status_code") and TestException.status_code == 444
    assert TestException in _sanic_exceptions and _sanic_exceptions[444] == TestException

    @add_status_code(500)
    class TestException500(SanicException):
        pass
    assert hasattr(TestException500, "quiet") and TestException500.quiet is False

    @add_status_code(503)
    class TestException503(SanicException):
        pass
    assert hasattr(TestException503, "quiet") and TestException503.quiet is True

    @add_status_code(555, quiet=True)
    class TestException555(SanicException):
        pass

# Generated at 2022-06-12 08:48:15.395901
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(700)
    class NewException(SanicException):
        pass
    assert _sanic_exceptions[700].__name__ == "NewException"

# Generated at 2022-06-12 08:48:21.504209
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(SanicException):
        @add_status_code(404)
        class NotFound(SanicException):
            pass
    with pytest.raises(SanicException):
        add_status_code(500)
        class ServerError(SanicException):
            pass
    add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass
    ServerError.quiet == True

# Generated at 2022-06-12 08:48:42.987265
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(305)
    class TestClass(SanicException):
        def __init__(self, foo):
            self.foo = foo

    assert 305 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[305], SanicException)
    assert issubclass(_sanic_exceptions[305], TestClass)
    assert _sanic_exceptions[305].status_code == 305

    @add_status_code(305, quiet=True)
    class TestClass2(SanicException):
        def __init__(self, bar):
            self.bar = bar

    assert 305 in _sanic_exceptions
    assert _sanic_exceptions[305].quiet is True
    assert issubclass(_sanic_exceptions[305], SanicException)

# Generated at 2022-06-12 08:48:49.495042
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(400)
    assert add_status_code(405)
    assert add_status_code(500)
    assert add_status_code(503)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(416)
    assert add_status_code(417)
    assert add_status_code(403)
    assert add_status_code(401)



# Generated at 2022-06-12 08:48:59.718544
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass
    assert A.status_code is None
    assert A.quiet is False
    assert A.__name__

    class B(SanicException):
        pass

    add_status_code(200)(B)
    assert B.status_code == 200
    assert B.quiet is False
    assert B.__name__

    class C(SanicException):
        pass

    add_status_code(400)(C)
    assert C.status_code == 400
    assert C.quiet is True
    assert C.__name__

    class D(SanicException):
        pass

    add_status_code(401, True)(D)
    assert D.status_code == 401
    assert D.quiet is True
    assert D.__name__


# Generated at 2022-06-12 08:49:05.288368
# Unit test for function add_status_code
def test_add_status_code():
    assert(_sanic_exceptions[404].__name__ == "NotFound")
    assert(_sanic_exceptions[500].__name__ == "ServerError")
    assert(_sanic_exceptions[500].quiet == False)
    assert(_sanic_exceptions[503].__name__ == "ServiceUnavailable")
    assert(_sanic_exceptions[503].quiet == True)
    assert(_sanic_exceptions[404].__name__ == "NotFound")
    assert(_sanic_exceptions[404].quiet == True)

# Generated at 2022-06-12 08:49:08.156326
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class OK(SanicException):
        """
        **Status**: 200 OK
        """
        pass

    assert _sanic_exceptions[200] == OK

# Generated at 2022-06-12 08:49:09.307920
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class AddStatusCode(SanicException):
        pass

    assert _sanic_exceptions.get(404).__name__ == 'AddStatusCode'



# Generated at 2022-06-12 08:49:16.105482
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402, True)
    class My402Exception(SanicException): pass

    assert My402Exception.status_code == 402
    assert My402Exception.quiet == True

    @add_status_code(403)
    class My403Exception(SanicException): pass

    assert My403Exception.status_code == 403
    assert My403Exception.quiet == False

    with pytest.raises(ValueError):
        @add_status_code(1)
        class My1Exception(SanicException): pass

# Generated at 2022-06-12 08:49:19.134726
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(666)
    class CustomException(SanicException):
        pass

    assert 666 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[666], CustomException)

# Generated at 2022-06-12 08:49:25.019776
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class A(Exception):
        pass
    assert issubclass(A, SanicException)
    assert A.status_code == 200
    assert A.quiet is True
    assert _sanic_exceptions[200] == A

    @add_status_code(201)
    class B(Exception):
        pass
    assert issubclass(B, SanicException)
    assert B.status_code == 201
    assert B.quiet is True
    assert _sanic_exceptions[201] == B

# Generated at 2022-06-12 08:49:27.662177
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class TestException(SanicException):
        pass

    assert 401 == TestException.status_code


# Generated at 2022-06-12 08:49:56.430039
# Unit test for function add_status_code
def test_add_status_code():
    def foo():
        pass
    try:
        add_status_code(200)(foo)
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False
    try:
        add_status_code(200, quiet=1)(foo)
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-12 08:50:00.513632
# Unit test for function add_status_code
def test_add_status_code():

    # We create a dummy exception class and add status code via decorator
    @add_status_code(409)
    class MyException(SanicException):
        pass

    exc = MyException("test", quiet=True)
    assert exc.status_code == 409
    assert exc.quiet == True

# Generated at 2022-06-12 08:50:06.045245
# Unit test for function add_status_code
def test_add_status_code():
    def add_status_code(code, quiet=None):
        _sanic_exceptions[code] = quiet
        return code

    assert add_status_code(123, quiet=None) == 123
    assert add_status_code(234, quiet=False) == 234
    assert add_status_code(345, quiet=True) == 345
    assert add_status_code(456, quiet=None) == 456

# Generated at 2022-06-12 08:50:09.439233
# Unit test for function add_status_code
def test_add_status_code():
    """
    This function tests the output of the add_status_code decorator.
    """
    add_status_code(400)(SanicException)
    assert _sanic_exceptions[400]



# Generated at 2022-06-12 08:50:16.575626
# Unit test for function add_status_code
def test_add_status_code():
    # Test that add_status_code returns a class decorator
    @add_status_code(999)
    class Foo(SanicException):
        pass

    assert Foo.status_code == 999
    assert Foo.quiet

    @add_status_code(400)
    class Bar(SanicException):
        pass

    assert Bar.status_code == 400
    assert not Bar.quiet

    @add_status_code(500, quiet=False)
    class Baz(SanicException):
        pass

    assert Baz.status_code == 500
    assert not Baz.quiet

# Generated at 2022-06-12 08:50:18.186420
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert _sanic_exceptions[400] == BadRequest

# Generated at 2022-06-12 08:50:22.816283
# Unit test for function add_status_code
def test_add_status_code():
    # An exception class that does not inherit from SanicException
    class TestException(Exception):
        pass
    # Manually decorate it
    decorated_class = add_status_code(404)(TestException)
    assert decorated_class.status_code == 404
    assert decorated_class in _sanic_exceptions.values()


# Generated at 2022-06-12 08:50:29.296998
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert _sanic_exceptions[400] == BadRequest
    assert BadRequest.quiet

    @add_status_code(401, quiet=False)
    class Unauthorized(SanicException):
        pass

    assert _sanic_exceptions[401] == Unauthorized
    assert not Unauthorized.quiet


if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:50:39.958856
# Unit test for function add_status_code
def test_add_status_code():
    # mock_class is a class that can be used as a class decorator and mock the
    # decorated class __init__() and __call__() methods.
    class mock_class:
        def __init__(self, *args, **kwargs):
            setattr(self.cls, '__args__', args)
            setattr(self.cls, '__kwargs__', kwargs)

        def __call__(self, cls):
            self.cls = cls
            return cls

    # Mock classes to test the add_status_code() decorator.
    # Test the behaviour when the status code is 400.
    @add_status_code(400, quiet=True)
    class test_status_code_400: pass
    assert test_status_code_400.status_code == 400
    assert test

# Generated at 2022-06-12 08:50:50.905710
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class UnauthorizedException(SanicException):
        pass

    @add_status_code(403)
    class ForbiddenException(SanicException):
        pass

    @add_status_code(500)
    class ServerErrorException(SanicException):
        pass

    assert UnauthorizedException.status_code == 401
    assert ForbiddenException.status_code == 403
    assert ServerErrorException.status_code == 500
    assert _sanic_exceptions[401] == UnauthorizedException
    assert _sanic_exceptions[403] == ForbiddenException
    assert _sanic_exceptions[500] == ServerErrorException
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[413] == PayloadTooLarge

# Generated at 2022-06-12 08:51:40.795974
# Unit test for function add_status_code
def test_add_status_code():
    class MyOwnException(SanicException):
        pass


    # add a status code
    add_status_code(499)(MyOwnException)
    # this should be added to SanicException
    assert hasattr(_sanic_exceptions[499], 'status_code')



# Generated at 2022-06-12 08:51:51.122286
# Unit test for function add_status_code
def test_add_status_code():
	@add_status_code(200)
	class MockedException(Exception):
		def __init__(self, code, message):
			super().__init__(message)
			self.code = code
		
	assert _sanic_exceptions[200] == MockedException
	
	@add_status_code(201, quiet=True)
	class MockedException(Exception):
		def __init__(self, code, message):
			super().__init__(message)
			self.code = code
		
	assert _sanic_exceptions[201] == MockedException
	assert _sanic_exceptions[201].quiet == True
	

# Generated at 2022-06-12 08:51:55.308344
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        pass

    assert _sanic_exceptions[418] == IAmATeaPot

    # Create an instance of IAmATeaPot
    raised_exception = IAmATeaPot("I'm a teapot", status_code=418)
    assert raised_exception.exception is "I'm a teapot"
    assert raised_exception.status_code is 418

    # override the status code
    raised_exception = IAmATeaPot("I'm a teapot", status_code=200)
    assert raised_exception.exception is "I'm a teapot"
    assert raised_exception.status_code is 200



# Generated at 2022-06-12 08:52:00.919275
# Unit test for function add_status_code
def test_add_status_code():
    # It should be decorated with @add_status_code(code)
    @add_status_code(code=404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """
        pass

    try:
        raise NotFound(message="Not Found!")
    except SanicException as m:
        assert m.message == "Not Found!"
        assert m.status_code == 404
        assert m.quiet is True

# Generated at 2022-06-12 08:52:04.171888
# Unit test for function add_status_code
def test_add_status_code():
    error_code = 400
    @add_status_code(error_code)
    class MockSanicException(SanicException):
        pass

    mock_error = MockSanicException("test")
    assert mock_error.status_code == error_code

# Generated at 2022-06-12 08:52:10.798388
# Unit test for function add_status_code
def test_add_status_code():
    def add_status_code_without_parenthesis(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator
    @add_status_code_without_parenthesis(404)
    class NotFound1(SanicException):
        pass
    @add_status_code(403)
    class Forbidden1(SanicException):
        pass
    assert(NotFound1.status_code == 404)
    assert(403 in _sanic_exceptions)
    assert(Forbidden1.quiet == True)
    assert(NotFound1.quiet == True)

# Unit test

# Generated at 2022-06-12 08:52:17.978541
# Unit test for function add_status_code
def test_add_status_code():
    class test_class():
        pass
    _404_exception = add_status_code(404)(test_class)
    assert _404_exception.status_code == 404
    assert _404_exception.quiet

    _500_exception = add_status_code(500)(test_class)
    assert _500_exception.status_code == 500
    assert _500_exception.quiet == False

    _500_exception = add_status_code(500,True)(test_class)
    assert _500_exception.status_code == 500
    assert _500_exception.quiet == True

# Generated at 2022-06-12 08:52:22.304527
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        def __init__(self):
            super().__init__('message')

    add_status_code(200)(TestException)

    assert isinstance(_sanic_exceptions[200], type(TestException))

    add_status_code(300, quiet=True)(TestException)

    assert isinstance(_sanic_exceptions[300], type(TestException))

# Generated at 2022-06-12 08:52:30.733332
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(400)(TypeError)()
    except TypeError as e:
        assert str(e) == 'Expected SanicException, got TypeError'
    try:
        add_status_code(400, quiet=False)(TypeError)()
    except TypeError as e:
        assert str(e) == 'Expected SanicException, got TypeError'
    try:
        add_status_code(400, quiet=True)(TypeError)()
    except TypeError as e:
        assert str(e) == 'Expected SanicException, got TypeError'

    try:
        add_status_code(400, quiet=False)(InvalidUsage)()
    except Exception as e:
        assert e.quiet == False

# Generated at 2022-06-12 08:52:33.218642
# Unit test for function add_status_code
def test_add_status_code():
    # TODO: Find out a way to test this.
    class TestException(SanicException):
        pass
    add_status_code(200)(TestException)
    add_status_code(400)(TestException)

# Generated at 2022-06-12 08:54:18.519982
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert BadGateway.status_code == 502
    assert _sanic_exceptions[502] == BadGateway

# Generated at 2022-06-12 08:54:20.736652
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

    assert TestException.status_code == 400

# Generated at 2022-06-12 08:54:30.576569
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test add_status_code function.
    """
    assert callable(add_status_code)

    @add_status_code(200)
    class TestException(Exception):
        """
        Sanic exception for testing add_status_code
        """
        pass

    assert issubclass(TestException, SanicException)
    assert TestException().status_code == 200
    assert TestException().quiet is None

    @add_status_code(200, True)
    class TestException2(Exception):
        """
        Sanic exception for testing add_status_code
        """
        pass

    assert TestException2().quiet is True

    @add_status_code(500, True)
    class TestException3(Exception):
        """
        Sanic exception for testing add_status_code
        """
        pass

   