

# Generated at 2022-06-12 08:44:38.054396
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 300
    assert TestException.quiet == True

# Generated at 2022-06-12 08:44:42.203913
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class NewException(Exception):
        pass

    assert 999 in _sanic_exceptions

    try:
        raise NewException("Test")
    except NewException as e:
        assert e.status_code == 999

# Generated at 2022-06-12 08:44:46.492632
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test if the decorator add_status_code works or not.
    """

    @add_status_code(400, quiet=True)
    class TestStatus(SanicException):
        pass

    assert TestStatus.status_code == 400
    assert TestStatus.quiet == True
    assert _sanic_exceptions.get(400) == TestStatus



# Generated at 2022-06-12 08:44:49.105953
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions

    @add_status_code(999)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[999] == TestException



# Generated at 2022-06-12 08:44:56.418952
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200, True), _sanic_exceptions
    assert _sanic_exceptions[200]('test', 200)
    assert _sanic_exceptions[200]('test', 200, True).quiet
    assert not _sanic_exceptions[200]('test', 200, False).quiet
    assert _sanic_exceptions[200]('test', 200, None).quiet



# Generated at 2022-06-12 08:45:00.996407
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(666)
    class CrazyException(SanicException):
        """
        **Status**: 666 Crazy Exception
        """

        pass

    assert _sanic_exceptions[666] == CrazyException
    assert CrazyException.status_code == 666

# Generated at 2022-06-12 08:45:12.270265
# Unit test for function add_status_code
def test_add_status_code():
    """
    Tests for the decorator used for adding exceptions to SanicException
    """

    assert isinstance(NotFound(), NotFound)
    assert isinstance(InvalidUsage(), InvalidUsage)
    assert isinstance(MethodNotSupported("Message", "GET", ("GET",)),
                      MethodNotSupported)
    assert isinstance(ServerError("Message"), ServerError)
    assert isinstance(ServiceUnavailable("Message"), ServiceUnavailable)
    assert isinstance(ServerError("Message"), SanicException)
    assert isinstance(ServiceUnavailable("Message"), SanicException)
    assert isinstance(URLBuildError("Message"), URLBuildError)
    assert isinstance(FileNotFound("Message", "File", "RelativeURL"),
                      FileNotFound)
    assert isinstance(RequestTimeout("Message"), RequestTimeout)

# Generated at 2022-06-12 08:45:22.486425
# Unit test for function add_status_code
def test_add_status_code():
    # Test `code`
    try:
        class MyException(SanicException):
            pass

        add_status_code(200)(MyException)
        assert MyException().status_code == 200
    except:
        assert False
        
    # Test `quiet`
    try:
        class MyException(SanicException):
            pass

        add_status_code(200)(MyException)
        assert MyException().status_code == 200
    except:
        assert False
   
    # Test `code` and `quiet`
    try:
        class MyException(SanicException):
            pass

        add_status_code(200, False)(MyException)
        assert MyException().status_code == 200 and MyException().quiet == False
    except:
        assert False

    # Test `code` and `quiet`

# Generated at 2022-06-12 08:45:25.763615
# Unit test for function add_status_code
def test_add_status_code():
    class MyException1(SanicException):
        pass

    class MyException2(SanicException):
        pass

    add_status_code(status_code=555, quiet=False)(MyException1)
    add_status_code(status_code=555, quiet=True)(MyException2)

    assert _sanic_exceptions[555] is MyException2
    assert _sanic_exceptions[555].quiet is True



# Generated at 2022-06-12 08:45:32.597325
# Unit test for function add_status_code
def test_add_status_code():
    http_error = 'HttpError'
    http_status_code = 440
    def check_http_exception_raised(http_status_code):
        http_error = 'HttpError'
        raise _sanic_exceptions.get(http_status_code, SanicException)(http_error)

    add_status_code(http_status_code)(SanicException)
    try:
        check_http_exception_raised(http_status_code)
    except Exception as e:
        assert e.__str__() == http_error

# Generated at 2022-06-12 08:45:46.130141
# Unit test for function add_status_code
def test_add_status_code():
    def return_status_code():
        return 0
    def return_status_code1():
        return 1

    @add_status_code(123)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 123
    assert _sanic_exceptions[123] is MyException

    @add_status_code(124, quiet=False)
    class MyException1(SanicException):
        pass

    assert MyException1.status_code == 124
    assert MyException1.quiet == False
    assert _sanic_exceptions[124] is MyException1

    @add_status_code(125, quiet=True)
    class MyException2(SanicException):
        pass

    assert MyException2.status_code == 125
    assert MyException2.quiet == True
    assert _san

# Generated at 2022-06-12 08:45:57.894052
# Unit test for function add_status_code
def test_add_status_code():
    from sanic import Sanic, response
    from sanic.exceptions import SanicException, add_status_code
    app = Sanic(__name__)

    # @add_status_code exception
    @add_status_code(503)
    class My503Exception(SanicException):
        pass

    @app.exception(My503Exception)
    def handler503(request, exception):
        return response.text('<h1>503 Service Unavailable</h1>')

    def view1(request):
        raise My503Exception('I am a 503 exception')
    app.add_route(view1, '/503-view')


    # Custom exception
    @add_status_code(402)
    class My402Exception(SanicException):
        pass


# Generated at 2022-06-12 08:46:08.369029
# Unit test for function add_status_code
def test_add_status_code():
    test_class_message = "test message for exception class"
    try:
        # Status code of exception that does not exist
        abort(1000, test_class_message)
    except SanicException as e:
        # Should raise a SanicException
        assert e.message == test_class_message
        assert e.status_code == 1000
    try:
        # Status code of 404
        abort(404, test_class_message)
    except NotFound as e:
        # Should raise a NotFound
        assert e.message == test_class_message
        assert e.status_code == 404
    try:
        # Status code of 500
        abort(500, test_class_message)
    except ServerError as e:
        # Should raise a ServerError
        assert e.message == test_class_message
        assert e.status

# Generated at 2022-06-12 08:46:13.917920
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class A(SanicException):
        pass

    assert _sanic_exceptions[300] == A

    @add_status_code(400)
    class A(SanicException):
        pass

    assert _sanic_exceptions[400] == A

    @add_status_code(500, quiet=True)
    class A(SanicException):
        pass

    assert _sanic_exceptions[500] == A

# Generated at 2022-06-12 08:46:16.723134
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class Foo(SanicException):
        pass

    assert Foo.status_code == 501
    assert Foo().status_code == 501
    assert Foo.__name__ == "Foo"

# Generated at 2022-06-12 08:46:27.441750
# Unit test for function add_status_code
def test_add_status_code():
    import inspect

    def create_func(name, method_code, cls):
        def func(self, *args, **kwargs):
            pass

        func.__name__ = name
        setattr(func, method_code, cls)
        return func

    def add(name, method_code, cls):
        func = create_func(name, method_code, cls)
        setattr(cls, name, classmethod(func))

    @add_status_code(200)
    class Request(SanicException):
        pass

    for name, method_code in inspect.getmembers(Request, predicate=inspect.ismethod):
        if method_code.__name__ == "add_status_code":
            add("test_add_status_code", "add_status_code", Request)

# Generated at 2022-06-12 08:46:30.834326
# Unit test for function add_status_code
def test_add_status_code():
    x = add_status_code(404, quiet=True)
    y = add_status_code(500)
    return x, y

if __name__ == "__main__":
    print(test_add_status_code())

# Generated at 2022-06-12 08:46:36.371375
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=200, quiet=None)
    class TestAddStatusCode(SanicException):
        pass
    test_add_status_code = TestAddStatusCode("hello")
    assert test_add_status_code.message == "hello"
    assert test_add_status_code.status_code == 200
    assert test_add_status_code.quiet == False



# Generated at 2022-06-12 08:46:39.168956
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class Teapot(SanicException):
        pass

    assert Teapot.status_code == 418


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:45.312571
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class Exception300(SanicException):
        pass
    assert Exception300().status_code == 300
    exception300 = Exception300("exception300")
    assert isinstance(exception300, Exception300)
    assert exception300.status_code == 300


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:51.997499
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class Test_SanicException(SanicException):
        pass

    assert Test_SanicException.status_code == 403



# Generated at 2022-06-12 08:46:55.912123
# Unit test for function add_status_code
def test_add_status_code():
    a = NotFound('not found error')
    assert a.status_code == 404
    assert a.quiet == True
    b = MethodNotSupported('method do not support', 'GET', ['POST', 'DELETE'])
    assert b.headers == {'Allow': 'POST, DELETE'}

# Generated at 2022-06-12 08:47:05.698947
# Unit test for function add_status_code
def test_add_status_code():
    _sanic_exceptions.clear()

    class TestException1(SanicException): pass
    class TestException2(SanicException): pass

    # Quiet exceptions
    assert add_status_code(404)(TestException1) is TestException1
    assert add_status_code(500, quiet=True)(TestException2) is TestException2

    # Non-quiet exceptions
    assert add_status_code(503)(TestException2) is TestException2

    assert len(_sanic_exceptions) == 3

    with pytest.raises(ServerError):
        abort(500, "It's broken!")
    with pytest.raises(PayloadTooLarge):
        abort(413, "That's pretty big!")
    with pytest.raises(ServiceUnavailable):
        abort(503, "Try again later!")

# Generated at 2022-06-12 08:47:07.822238
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(999,'test')
    assert 999 in _sanic_exceptions

# Generated at 2022-06-12 08:47:12.938167
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class DummySanicException(SanicException):
        pass
    assert DummySanicException.status_code == 202
    assert _sanic_exceptions[202] == DummySanicException
    assert 'SanicException' in repr(SanicException)

test_add_status_code()

# Generated at 2022-06-12 08:47:15.596274
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class Created(SanicException):
        pass

    assert Created.status_code == 201
    assert _sanic_exceptions[201] == Created

# Generated at 2022-06-12 08:47:19.851474
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class SanicException100(SanicException):
        pass

    assert SanicException100.status_code == 100
    assert SanicException100.quiet == True
    assert SanicException100.__name__ == 'SanicException100'
    # TODO Add assert for addition to global dict...



# Generated at 2022-06-12 08:47:23.188236
# Unit test for function add_status_code
def test_add_status_code():
    """
    Tests add_status_code function.
    """
    def foo():
        pass

    # add_status_code returns a function that returns the decorated function
    @add_status_code(404)
    def bar():
        pass

    # TODO: how to verify that @add_status_code(404) has been applied to bar?

# Generated at 2022-06-12 08:47:32.078820
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class ImATeapotException(SanicException):
        """
        **Status**: 418 I'm A Teapot
        """
        pass

    assert ImATeapotException.status_code == 418
    im_a_teapot_exception = ImATeapotException(
        message='I am really a teapot',
        status_code=418)
    assert im_a_teapot_exception.status_code == 418

    @add_status_code(418, quiet=True)
    class ImATeapotException(SanicException):
        """
        **Status**: 418 I'm A Teapot
        """
        pass

    assert ImATeapotException.status_code == 418
    assert ImATeapotException.quiet is True

# Generated at 2022-06-12 08:47:42.465623
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(419)
    class InvalidCode(Exception):
        pass

    assert _sanic_exceptions[419] == InvalidCode
    assert InvalidCode.status_code == 419
    assert not InvalidCode().quiet

    @add_status_code(600, quiet=True)
    class CustomCode(Exception):
        pass

    assert _sanic_exceptions[600] == CustomCode
    assert CustomCode.status_code == 600
    assert CustomCode().quiet

    @add_status_code(601)
    class CustomCode(Exception):
        pass

    assert _sanic_exceptions[601] != CustomCode
    assert CustomCode.status_code == 601
    assert _sanic_exceptions[601].status_code == 601

# Generated at 2022-06-12 08:47:51.852934
# Unit test for function add_status_code
def test_add_status_code():
    try:
        add_status_code(300)(SanicException)('test_message')
    except SanicException as ex:
        assert ex.status_code == 300
        assert str(ex) == 'test_message'

# Generated at 2022-06-12 08:47:57.172021
# Unit test for function add_status_code
def test_add_status_code():
    from sanic import Sanic

    app = Sanic()

    @app.exception(None)
    def handler(request, exception):
        return text(exception.message, exception.status_code)

    @app.route("/")
    def handler(request):
        abort(418, "I'm a teapot")
        return text('OK')

    request, response = app.test_client.get("/")

    assert response.status == 418
    assert response.body == b"I'm a teapot"

# Generated at 2022-06-12 08:48:01.441593
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class SuccessResponse(SanicException):
        """
        **Status**: 200 Success
        """

        pass

    assert 200 == SuccessResponse.status_code
    assert SuccessResponse() is _sanic_exceptions[200]

# Generated at 2022-06-12 08:48:06.241707
# Unit test for function add_status_code
def test_add_status_code():
    class NewException(SanicException):
        pass

    add_status_code(123)(NewException)  # type: ignore
    exc = _sanic_exceptions.get(123)
    assert issubclass(exc, NewException)
    assert issubclass(exc, SanicException)
    assert exc is not NewException



# Generated at 2022-06-12 08:48:18.133832
# Unit test for function add_status_code
def test_add_status_code():
    # Instance the class
    x = SanicException(message="Test", status_code=201, quiet=False)

    # Test the status code
    print(x.status_code)
    print(x.quiet)

    # Test add_status_code decorator
    @add_status_code(200)
    class test1(SanicException):
        pass

    # Test the status code
    print(test1.status_code)
    print(test1.quiet)

    # Set the decorated class as a new class
    # Test add_status_code decorator
    @add_status_code(201)
    class test2(SanicException):
        pass

    # Test the status code
    print(test2.status_code)
    print(test2.quiet)

    # Test the status code

# Generated at 2022-06-12 08:48:21.331379
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        pass

    add_status_code(500)(TestException)

    assert _sanic_exceptions[500] == TestException



# Generated at 2022-06-12 08:48:23.825697
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(405)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 405
    assert TestException.quiet == True
    assert _sanic_exceptions[405] == TestException



# Generated at 2022-06-12 08:48:26.082080
# Unit test for function add_status_code
def test_add_status_code():
    def function():
        return "test"

    decorated = add_status_code(200)(function)

    assert decorated.status_code == 200
    assert decorated.quiet is False

# Generated at 2022-06-12 08:48:30.925245
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """
        pass

    new_exception = ServerError("Test")

    assert new_exception.status_code == 500
    assert new_exception.message == "Test"



# Generated at 2022-06-12 08:48:36.786257
# Unit test for function add_status_code
def test_add_status_code():
    # Normal case
    class NormalException(SanicException):
        pass
    add_status_code(400)(NormalException)
    assert NormalException.status_code == 400
    assert NormalException.quiet == False
    # The status code 500 is special in SanicException, so we need a case
    class QuietException(SanicException):
        pass
    add_status_code(500)(QuietException)
    assert QuietException.status_code == 500
    assert QuietException.quiet == True

# Generated at 2022-06-12 08:49:02.483715
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=no-member

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException().status_code == 400
    assert TestException.quiet is True
    assert TestException().quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2().status_code == 500
    assert TestException2.quiet is False
    assert TestException2().quiet is False
    assert _sanic_exceptions[500] == TestException2


# Generated at 2022-06-12 08:49:05.994540
# Unit test for function add_status_code
def test_add_status_code():
    def foo(status_code):
        @add_status_code(status_code)
        class FooBar:
            pass
        return FooBar

    assert isinstance(foo(404)(), NotFound)
    assert isinstance(foo(400)(), InvalidUsage)
    assert isinstance(foo(500)(), ServerError)



# Generated at 2022-06-12 08:49:13.255558
# Unit test for function add_status_code
def test_add_status_code():
    class Foo(SanicException):
        pass

    # add_status_code is a decorator
    decorated_class = add_status_code(404)(Foo)
    assert decorated_class.status_code == 404
    assert decorated_class.quiet == True

    class Foo(SanicException):
        pass

    # add_status_code is a decorator
    decorated_class = add_status_code(500, False)(Foo)
    assert decorated_class.status_code == 500
    assert decorated_class.quiet == False

# Generated at 2022-06-12 08:49:16.664423
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(411)
    class LengthRequired(Exception):
        pass

    e = LengthRequired('Length is required', 411)
    assert e.quiet is True
    assert e.status_code == 411



# Generated at 2022-06-12 08:49:25.442634
# Unit test for function add_status_code
def test_add_status_code():
    class ExampleException(Exception):
        pass

    @add_status_code(208)
    class AlreadyReported(ExampleException):
        pass

    @add_status_code(209)
    class IMUsed(ExampleException):
        pass

    @add_status_code(209, quiet=True)
    class IMUsedQuiet(ExampleException):
        pass

    assert STATUS_CODES[208] == "Already Reported"
    assert STATUS_CODES[209] == "IM Used"
    assert AlreadyReported.status_code == 208
    assert IMUsed.status_code == 209
    assert IMUsedQuiet.status_code == 209
    assert AlreadyReported("Error").status_code == 208
    assert IMUsed("Error").status_code == 209
    assert IMUsedQuiet("Error").status_code == 209


# Generated at 2022-06-12 08:49:28.864268
# Unit test for function add_status_code
def test_add_status_code():
    MyException = add_status_code(404)(Exception)
    assert MyException.status_code == 404
    assert isinstance(MyException("Oups"), MyException)
    assert isinstance(MyException("Oups"), NotFound)

# Generated at 2022-06-12 08:49:33.974027
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass

    @add_status_code(409)
    class MyException_409(SanicException):
        pass

    def get_exception_by_code(code):
        return _sanic_exceptions[code]

    assert issubclass(_sanic_exceptions[404], SanicException)
    assert issubclass(get_exception_by_code(404), SanicException)
    assert isinstance(_sanic_exceptions[404](), SanicException)
    assert _sanic_exceptions[404]().status_code == 404
    assert get_exception_by_code(404)().status_code == 404

    assert issubclass(_sanic_exceptions[409], SanicException)

# Generated at 2022-06-12 08:49:44.407698
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(420)
    class EnhanceYourCalm(SanicException):
        """
        **Status**: 420 Enhance Your Calm
        """
        pass

    assert EnhanceYourCalm().status_code == 420
    assert _sanic_exceptions[420] == EnhanceYourCalm
    assert EnhanceYourCalm().quiet is True

    @add_status_code(421)
    class MisdirectedRequest(SanicException):
        """
        **Status**: 421 Misdirected Request
        """
        pass

    assert MisdirectedRequest().status_code == 421
    assert _sanic_exceptions[421] == MisdirectedRequest
    assert MisdirectedRequest().quiet is True

# Generated at 2022-06-12 08:49:56.058137
# Unit test for function add_status_code
def test_add_status_code():
    class TestException1(SanicException):
        pass
    test_exception_1 = TestException1(message="Test message", status_code=400)
    assert test_exception_1.status_code == 400

    class TestException2(SanicException):
        pass
    test_exception_2 = TestException2(message="Test message", status_code=500)
    assert test_exception_2.status_code == 500
    assert test_exception_2.quiet is False

    class TestException3(SanicException):
        pass
    test_exception_3 = TestException3(message="Test message", status_code=503)
    assert test_exception_3.status_code == 503
    assert test_exception_3.quiet is True

    class TestException4(SanicException):
        pass


# Generated at 2022-06-12 08:50:06.520023
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test:
        pass

    assert _sanic_exceptions[200] == Test

    @add_status_code(201, quiet=True)
    class Test:
        pass

    assert _sanic_exceptions[201].quiet == True

    @add_status_code(202)
    class Test:
        pass

    assert _sanic_exceptions[202].quiet == True

    @add_status_code(202, quiet=False)
    class Test:
        pass

    assert _sanic_exceptions[202].quiet == False

    @add_status_code(203)
    class Test:
        pass

    assert _sanic_exceptions[203].quiet == True

    @add_status_code(204, quiet=False)
    class Test:
        pass

# Generated at 2022-06-12 08:50:46.216126
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(404)
    class NotFound(SanicException):
        pass

    @add_status_code(405, quiet=True)
    class MethodNotSupported(SanicException):
        pass

    assert issubclass(NotFound, SanicException)
    assert NotFound.status_code == 404
    assert issubclass(MethodNotSupported, SanicException)
    assert MethodNotSupported.status_code == 405
    assert MethodNotSupported.quiet is True

# Generated at 2022-06-12 08:50:49.253144
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=502)
    class BadGateway(SanicException):
        pass

    assert BadGateway.status_code == 502

# Generated at 2022-06-12 08:50:50.945809
# Unit test for function add_status_code
def test_add_status_code():
    assert STATUS_CODES[404] == NotFound.__doc__.strip()



# Generated at 2022-06-12 08:50:53.557225
# Unit test for function add_status_code
def test_add_status_code():
    class test:
        @add_status_code(200)
        def test():
            return 0

    assert _sanic_exceptions[200] == test.test

# Generated at 2022-06-12 08:50:56.523317
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeapot(SanicException):
        pass

    assert 418 in _sanic_exceptions
    assert IAmATeapot.status_code == 418

# Generated at 2022-06-12 08:51:00.822188
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException): pass
    add_status_code(code=999)(TestException)
    assert TestException._status_code == 999
    assert _sanic_exceptions[999] == TestException

# Generated at 2022-06-12 08:51:13.083820
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.views import CompositionView
    from sanic.response import text

    # 1. Add a view with a normal string
    @add_status_code(400)
    class NormalStringView(CompositionView):
        def compose(self, request):
            return text("I am a normal string")

    # 2. Add a view with a empty string
    @add_status_code(404)
    class EmptyStringView(CompositionView):
        def compose(self, request):
            return text("")

    # 3. Add a view with a None return value
    @add_status_code(500)
    class NoneStringView(CompositionView):
        def compose(self, request):
            return None

    # 4. Add a view with a not standard status_code

# Generated at 2022-06-12 08:51:15.076304
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[404] == TestException

# Generated at 2022-06-12 08:51:25.856197
# Unit test for function add_status_code
def test_add_status_code():
    # Test creating Exception class with 500 as a default status code
    @add_status_code(500)
    class Error(SanicException):
        pass
    assert Error.status_code == 500
    assert Error.quiet is False
    assert Error().status_code == 500
    assert Error().quiet is False

    # Test that the Exception class is referenced by status code in
    # _sanic_exceptions
    assert _sanic_exceptions[500] == Error

    # Test creating Exception class with quiet=True
    @add_status_code(500, quiet=True)
    class QuietError(SanicException):
        pass
    assert QuietError.status_code == 500
    assert QuietError.quiet is True
    assert QuietError().status_code == 500
    assert QuietError().quiet is True

    # Test that the Exception class is referenced by

# Generated at 2022-06-12 08:51:26.857019
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)



# Generated at 2022-06-12 08:52:43.683017
# Unit test for function add_status_code
def test_add_status_code():
    test_class = add_status_code(test_code=200)(test_class=SanicException)
    assert test_class.status_code == 200

    # create a new class and make sure it has the added status_code
    test_class_2 = SanicException(message="testing")
    assert test_class_2.status_code is None

# Generated at 2022-06-12 08:52:46.164373
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class TestException(SanicException):
        pass
    
    assert TestException.__name__ == 'TestException'
    assert TestException.status_code == 403

# Generated at 2022-06-12 08:52:49.032489
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class MyException(SanicException):
        pass
    try:
        raise MyException("Test MyException")
    except BaseException as e:
        assert e.status_code == 500



# Generated at 2022-06-12 08:52:52.361578
# Unit test for function add_status_code
def test_add_status_code():
    assert 1000 not in _sanic_exceptions
    with pytest.raises(NotFound):
        abort(404)
    assert 1000 not in _sanic_exceptions

    @add_status_code(1000)
    class TestException(SanicException):
        pass

    assert 1000 in _sanic_exceptions
    with pytest.raises(TestException):
        abort(1000)

# Generated at 2022-06-12 08:52:54.094194
# Unit test for function add_status_code
def test_add_status_code():
    assert NotFound.status_code == 404
    assert InvalidUsage.status_code == 400


# Generated at 2022-06-12 08:53:01.922146
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class Created(Exception):
        pass
    assert Created.status_code == 201
    assert Created.quiet is True
    assert _sanic_exceptions[201] is Created
    assert _sanic_exceptions.get(500) is ServerError
    assert _sanic_exceptions.get(500).status_code == 500
    assert _sanic_exceptions.get(500).quiet is False


# "Unit test" for function abort

# Generated at 2022-06-12 08:53:09.695765
# Unit test for function add_status_code
def test_add_status_code():
    def raise_code(code):
        raise code

    try:
        raise_code(9)
    except Exception as e:
        assert str(e) == '9'
    try:
        raise_code(107)
    except Exception as e:
        assert str(e) == '107'


if __name__ == "__main__":
    # Running this document will execute all >>> comments as test of this source.

    # Import doctest
    import doctest

    doctest.testmod()

    # Test of function add_status_code
    test_add_status_code()

# Generated at 2022-06-12 08:53:11.648289
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(Exception):
        pass

    assert TestException.status_code == 400

# Generated at 2022-06-12 08:53:16.785008
# Unit test for function add_status_code
def test_add_status_code():
    code = 418
    message = "I'm a teapot"
    class TeapotError(SanicException):
        pass

    @add_status_code(code)
    class TeapotError(SanicException):
        pass

    assert _sanic_exceptions[code] == TeapotError
    exc = TeapotError(message)
    assert exc.status_code == code
    assert exc.args[0] == message


# Generated at 2022-06-12 08:53:22.194020
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(4)
    class CustomException(Exception):
        pass
    assert _sanic_exceptions[4] is CustomException
    assert not hasattr(_sanic_exceptions[4], "quiet")

    @add_status_code(5, quiet=True)
    class CustomException(Exception):
        pass
    assert hasattr(_sanic_exceptions[5], "quiet")