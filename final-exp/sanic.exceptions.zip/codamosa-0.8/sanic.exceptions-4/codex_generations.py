

# Generated at 2022-06-12 08:44:43.630935
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    import unittest
    from unittest.mock import patch

    class TestCase(unittest.TestCase):
        @patch('sanic.exceptions.Unauthorized.__init__')
        def test_Unauthorized(self, mock_init):
            mock_init.return_value = None
            SanicException = Unauthorized('Test Auth')
            mock_init.assert_called_with('Test Auth', status_code=None, scheme=None)

    unittest.main()

# Generated at 2022-06-12 08:44:48.902704
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(666)
    class TestError(SanicException):
        pass

    assert _sanic_exceptions[666] == TestError
    assert TestError.status_code == 666
    assert TestError.quiet is True

    @add_status_code(999, False)
    class TestError2(SanicException):
        pass

    assert _sanic_exceptions[999] == TestError2
    assert TestError2.status_code == 999
    assert TestError2.quiet is False

# Generated at 2022-06-12 08:45:01.947008
# Unit test for function add_status_code
def test_add_status_code():
    """Test for function add_status_code"""

    # For the exception check, mock the raise statement:
    def mock_raise_statement(e):
        global result
        result = e

    old_raise_statement = globals()['raise']
    globals()['raise'] = mock_raise_statement

    # Test for custom exception class, with custom status code:
    @add_status_code(404)
    class My404Exception(SanicException):
        pass

    try:
        raise My404Exception()
    except Exception as e:
        assert e.status_code == 404

    # Test for custom exception class that inherits another exception class:
    class TestException(SanicException):
        pass

    @add_status_code(400)
    class My400Exception(TestException):
        pass


# Generated at 2022-06-12 08:45:08.378671
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert isinstance(e, SanicException)
        assert isinstance(e, Unauthorized)
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }



# Generated at 2022-06-12 08:45:13.524949
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(400)(Exception)

    with pytest.raises(Exception) as excinfo:
        raise Exception("error")

    assert excinfo.value.status_code == 400

# Unit tests for class SanicException

# Generated at 2022-06-12 08:45:18.589209
# Unit test for function add_status_code
def test_add_status_code():
    # Test for add_status_code
    assert add_status_code(200)(SanicException)
    assert add_status_code(404)(NotFound)
    assert add_status_code(500)(ServerError)


# Generated at 2022-06-12 08:45:24.104225
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410)
    class Gone(SanicException):
        """
        **Status**: 410 Gone
        """
        pass

    assert 410 in _sanic_exceptions
    assert _sanic_exceptions[410].status_code == 410
    assert _sanic_exceptions[410].__name__ == "Gone"

# Generated at 2022-06-12 08:45:33.903702
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    else:
        raise Exception("Unauthorized Exception should be raised")

# Generated at 2022-06-12 08:45:37.400300
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    ex = Unauthorized("Authentication required.", scheme="Basic", realm="Restricted Area")

    assert ex.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    assert ex.status_code == 401
    assert str(ex) == "Authentication required."

# Generated at 2022-06-12 08:45:47.829628
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(42)
    class MyException(SanicException):
        pass
    assert not _sanic_exceptions
    assert issubclass(MyException, _sanic_exceptions[42])

    try:
        abort(42)
    except _sanic_exceptions[42] as e:
        assert e.status_code == 42
    else:
        raise RuntimeError("Did not raise expected exception")

    @add_status_code(41, quiet=False)
    class MyQuietException(SanicException):
        pass
    try:
        abort(41)
    except _sanic_exceptions[41] as e:
        assert not e.quiet
    else:
        raise RuntimeError("Did not raise expected exception")


# Generated at 2022-06-12 08:45:53.340320
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        pass

    assert hasattr(Test, 'status_code')
    assert Test.status_code == 200



# Generated at 2022-06-12 08:46:03.452864
# Unit test for function add_status_code
def test_add_status_code():
    class StatusCodeDecoratedClass(object):
        '''
        This is a unit test class for SanicException
        '''
        pass

    # Test if status code is valid
    cls = add_status_code(code=200)(StatusCodeDecoratedClass)
    assert cls.status_code == 200
    assert cls.quiet == True

    # Test if status code is invalid
    with pytest.raises(TypeError):
        cls = add_status_code(code='Test')(StatusCodeDecoratedClass)
    with pytest.raises(TypeError):
        cls = add_status_code(code=256)(StatusCodeDecoratedClass)


# Unit tests for class SanicException

# Generated at 2022-06-12 08:46:05.512731
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-12 08:46:10.993256
# Unit test for function add_status_code
def test_add_status_code():
    # add status code 200
    @add_status_code(200)
    class CustomException(SanicException):
        pass
    assert _sanic_exceptions[200] == CustomException
    # add status code 400
    @add_status_code(400)
    class CustomException(SanicException):
        pass
    assert _sanic_exceptions[400] == CustomException



# Generated at 2022-06-12 08:46:17.639918
# Unit test for function add_status_code
def test_add_status_code():
    exc_name_list = [
        "NotFound",
        "InvalidUsage",
        "MethodNotSupported",
        "ServerError",
        "ServiceUnavailable",
        "URLBuildError",
        "FileNotFound",
        "RequestTimeout",
        "PayloadTooLarge",
        "HeaderNotFound",
        "ContentRangeError",
        "HeaderExpectationFailed",
        "Forbidden",
        "InvalidRangeType",
        "PyFileError",
        "Unauthorized",
        "LoadFileException",
        "InvalidSignal",
        "Abort"
    ]

    for exc_name in exc_name_list:
        assert hasattr(_sanic_exceptions, exc_name)

# Generated at 2022-06-12 08:46:28.423524
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass
    assert _sanic_exceptions[400] == BadRequest
    assert BadRequest.status_code == 400
    assert BadRequest.quiet is False
    assert BadRequest("Test").status_code == 400
    assert BadRequest("Test").quiet is False
    assert BadRequest("Test", quiet=True).quiet is True

    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet is True
    assert NotFound("Test").status_code == 404
    assert NotFound("Test").quiet is True


# Generated at 2022-06-12 08:46:33.341267
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    scheme = "Basic"
    realm = "Restricted Area"
    unauthorized = Unauthorized(message, scheme=scheme, realm=realm)
    key = "WWW-Authenticate"
    value = 'Basic realm="Restricted Area"'
    assert unauthorized.headers[key] == value


# Generated at 2022-06-12 08:46:35.831424
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(10)
    class myAbort(SanicException):
        pass
    assert myAbort._sanic_exception_code == 10

# Generated at 2022-06-12 08:46:41.180357
# Unit test for function add_status_code
def test_add_status_code():
    # Test for function add_status_code
    add_status_code(404)

    @add_status_code(400)
    class Test(SanicException):
        pass

    # Test for class Test
    with pytest.raises(Test):
        raise Test("message")

    # Test for class NotFound
    with pytest.raises(NotFound):
        raise NotFound("message")

# Generated at 2022-06-12 08:46:52.155901
# Unit test for function add_status_code
def test_add_status_code():

    global _sanic_exceptions

    @add_status_code(418)
    class IAmATeapot(Exception):
        """
        **Status**: 418 I'm a teapot
        """

        pass

    assert "I'm a teapot" in str(IAmATeapot("I am a teapot"))
    assert isinstance(_sanic_exceptions[418], IAmATeapot)
    assert (
        str(_sanic_exceptions[418](message="I am a teapot", status_code=418))
        == str(IAmATeapot("I am a teapot"))
    )
    assert not _sanic_exceptions[418]().quiet

    _sanic_exceptions = {}


# Generated at 2022-06-12 08:47:01.189867
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class A(SanicException):
        pass
    @add_status_code(401)
    class B(SanicException):
        pass

    assert A.status_code == 400
    assert B.status_code == 401
    assert A.quiet == True
    assert B.quiet == True


# Unit tests for function abort

# Generated at 2022-06-12 08:47:13.045797
# Unit test for function add_status_code
def test_add_status_code():
    # test default parameters
    @add_status_code(200)
    class Test_200(SanicException):
        pass
    assert Test_200.status_code == 200
    assert Test_200.quiet is True

    # test passing in quiet=False
    @add_status_code(200, quiet=False)
    class Test_200(SanicException):
        pass
    assert Test_200.status_code == 200
    assert Test_200.quiet is False

    # test passing in quiet=True
    @add_status_code(200, quiet=True)
    class Test_200(SanicException):
        pass
    assert Test_200.status_code == 200
    assert Test_200.quiet is True

    # test passing in quiet=None

# Generated at 2022-06-12 08:47:20.092643
# Unit test for function add_status_code
def test_add_status_code():
    def dummy_func(cls):
        return cls
    set_test_false = add_status_code(100, False)
    set_test_false(dummy_func)
    set_test_true = add_status_code(100, True)
    set_test_true(dummy_func)
    set_test_none = add_status_code(100)
    set_test_none(dummy_func)
    assert _sanic_exceptions[100].quiet == True
    assert _sanic_exceptions[100].status_code == 100

# Generated at 2022-06-12 08:47:28.530531
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        """
        **Status**: 418 I Am A Tea Pot
        """

        pass

    assert 418 in _sanic_exceptions
    assert _sanic_exceptions[418] == IAmATeaPot
    assert IAmATeaPot(message='Tea Time', status_code=418).message == 'Tea Time'
    assert IAmATeaPot(message='Tea Time', status_code=418).status_code == 418


# Generated at 2022-06-12 08:47:38.130064
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(777)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 777
    assert CustomException().status_code == 777
    assert CustomException.quiet is False

    @add_status_code(777, True)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 777
    assert CustomException().status_code == 777
    assert CustomException.quiet is True

    @add_status_code(777, quiet=True)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 777
    assert CustomException().status_code == 777
    assert CustomException.quiet is True

    @add_status_code(777, False)
    class CustomException(SanicException):
        pass


# Generated at 2022-06-12 08:47:40.346202
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-12 08:47:51.363332
# Unit test for function add_status_code
def test_add_status_code():
    print("test_add_status_code")
    @add_status_code(201)
    class MyException(Exception):
        pass

    class NotFound(Exception):
        pass

    my_exception = MyException("Some error")
    assert("MyException" in str(my_exception))
    assert("201" in str(my_exception))
    assert(my_exception.status_code == 201)

    #my_not_found = NotFound("Some error")
    #assert("NotFound" in str(my_not_found))
    #assert(my_not_found.status_code == 404)

    import inspect
    classes = dict(inspect.getmembers(sys.modules[__name__], inspect.isclass))
    for cls in classes:
        print(cls)
        #for key

# Generated at 2022-06-12 08:47:58.780436
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    # Create a new status code and class.
    assert 201 not in _sanic_exceptions
    add_status_code(201)(TestException)
    assert 201 in _sanic_exceptions
    assert _sanic_exceptions[201] is TestException

    e = _sanic_exceptions[201]("", 201)
    assert e.message is ""
    assert e.status_code == 201
    assert e.quiet is None

    e = _sanic_exceptions[201]("", 201, quiet=True)
    assert e.message is ""
    assert e.status_code == 201
    assert e.quiet

    e = _sanic_exceptions[201]("")
    assert e.message is ""
    assert e.status_code == 201
    assert e

# Generated at 2022-06-12 08:48:05.362226
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400

    @add_status_code(status_code)
    class TestException(SanicException):
        pass

    exception = TestException("Testing...")

    assert exception.status_code == status_code
    assert exception, "Testing..."
    global _sanic_exceptions
    assert status_code in _sanic_exceptions
    assert _sanic_exceptions[status_code] == TestException



# Generated at 2022-06-12 08:48:12.832923
# Unit test for function add_status_code
def test_add_status_code():
    code_list = [400, 401, 404]
    message_list = ["Bad Request", "Unauthorized", "Not Found"]
    
    for i in range(len(code_list)):
        status_code = code_list[i]
        message = message_list[i]
        sanic_exception = _sanic_exceptions.get(status_code, SanicException)
        assert isinstance(sanic_exception(message=message, status_code=status_code), Exception)


# Generated at 2022-06-12 08:48:23.138620
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass
    
    assert TestException.status_code == 999, "Failed to set the status_code"
    assert _sanic_exceptions[999] is TestException, "Failed to add TestException to _sanic_exceptions"


# Generated at 2022-06-12 08:48:27.260449
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        cls.status_code = 200
        cls.quiet = False
        _sanic_exceptions[200] = cls
        return cls
    add_status_code(400)(test_class_decorator)
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-12 08:48:35.937889
# Unit test for function add_status_code
def test_add_status_code():
    class DummyEx(SanicException):
        pass

    # quiet=True
    add_status_code(100, quiet=True)(DummyEx)
    assert DummyEx.quiet

    # quiet=True for error in 400s (excluding 500)
    assert InvalidUsage.quiet

    # quiet=True for error in 500s
    assert ServerError.quiet

    # quiet=False for error in 500s
    add_status_code(507, quiet=False)(DummyEx)
    assert not DummyEx.quiet

    # quiet=False
    add_status_code(101, quiet=False)(DummyEx)
    assert not DummyEx.quiet



# Generated at 2022-06-12 08:48:39.463488
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class DummyException(SanicException):
        pass

    assert _sanic_exceptions[400] == DummyException
    assert _sanic_exceptions[400](message="Test message").message == "Test message"



# Generated at 2022-06-12 08:48:43.108186
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        pass

    add_status_code(418, True)(CustomException)
    assert CustomException.status_code == 418
    assert CustomException.quiet is True
    assert _sanic_exceptions[418] == CustomException

# Generated at 2022-06-12 08:48:53.447226
# Unit test for function add_status_code
def test_add_status_code():
    # given
    @add_status_code(500)
    class ServerErrorSanic(SanicException):
        pass

    @add_status_code(404)
    class NotFoundSanic(SanicException):
        pass

    @add_status_code(400)
    class InvalidUsageSanic(SanicException):
        pass

    @add_status_code(405)
    class MethodNotSupportedSanic(SanicException):
        pass

    @add_status_code(503)
    class ServiceUnavailableSanic(SanicException):
        pass

    @add_status_code(408)
    class RequestTimeoutSanic(SanicException):
        pass

    @add_status_code(413)
    class PayloadTooLargeSanic(SanicException):
        pass


# Generated at 2022-06-12 08:48:55.442023
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    assert MyException is add_status_code(200)(MyException)

# Generated at 2022-06-12 08:48:57.562839
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class MyException(Exception):
        pass

    assert isinstance(_sanic_exceptions[401], type)

# Generated at 2022-06-12 08:49:05.488318
# Unit test for function add_status_code
def test_add_status_code():
    # Test add_status_code
    @add_status_code(202)
    class Accepted(SanicException):
        """
        **Status**: 202 Accepted
        """

        pass

    assert Accepted.status_code == 202
    assert Accepted.quiet is True
    assert _sanic_exceptions[202] == Accepted

    # Test add_status_code with quiet = False
    @add_status_code(202, quiet=False)  # pragma: no cover
    class Accepted2(SanicException):
        """
        **Status**: 202 Accepted
        """

        pass

    assert Accepted2.status_code == 202
    assert Accepted2.quiet is False
    assert _sanic_exceptions[202] == Accepted2

# Generated at 2022-06-12 08:49:09.553895
# Unit test for function add_status_code
def test_add_status_code():
    assert STATUS_CODES.get(1000) is None
    @add_status_code(1000)
    class NewException(SanicException):
        pass
    assert STATUS_CODES[1000] == "New Exception"


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:33.517022
# Unit test for function add_status_code
def test_add_status_code():
    # test for default
    @add_status_code(code=200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert TestException.quiet is True

    # test for quiet = True
    @add_status_code(code=202, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 202
    assert TestException.quiet is True

    # test for not quiet
    @add_status_code(code=500, quiet=False)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet is False



# Generated at 2022-06-12 08:49:44.703490
# Unit test for function add_status_code
def test_add_status_code():
    def fake_status_code():
        # No status_code
        try:
            fake_exception = add_status_code(0)
            fake_exception()
        except TypeError:
            pass
        else:
            assert False

        # False status_code
        try:
            fake_exception = add_status_code(0)
            fake_exception(0)
        except TypeError:
            pass
        else:
            assert False

        # Correct status_code
        try:
            fake_exception = add_status_code(0)
            fake_exception(status_code = 0)
        except TypeError:
            assert False
        else:
            pass

    fake_status_code()



# Generated at 2022-06-12 08:49:47.247260
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass
    assert _sanic_exceptions[400] is InvalidUsage

# Generated at 2022-06-12 08:49:51.581137
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(AttributeError):
        assert add_status_code(400)

    @add_status_code(400)
    class SampleException(SanicException):
        pass

    assert SampleException.status_code == 400

    assert SampleException.quiet

# Generated at 2022-06-12 08:50:00.000239
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(222)
    class Exception_A(SanicException):
        pass

    assert Exception_A.status_code == 222
    assert Exception_A.quiet == False

    @add_status_code(222,quiet=True)
    class Exception_B(SanicException):
        pass

    assert Exception_B.status_code == 222
    assert Exception_B.quiet == True

    @add_status_code(222,quiet=False)
    class Exception_C(SanicException):
        pass

    assert Exception_C.status_code == 222
    assert Exception_C.quiet == False

    @add_status_code(500,quiet=False)
    class Exception_D(SanicException):
        pass

    assert Exception_D.status_code == 500
    assert Exception_D.quiet == False

# Generated at 2022-06-12 08:50:04.501097
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class ImATeapot(SanicException):
        """
        **Status**: 418 I'm a teapot
        """

        pass

    assert 418 == ImATeapot.status_code
    assert ImATeapot.quiet is True


# Generated at 2022-06-12 08:50:06.948466
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class Test(SanicException):
        pass
    
    assert Test.status_code == 600


# Generated at 2022-06-12 08:50:13.138412
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest.status_code == 400
    assert _sanic_exceptions[400] == BadRequest

    try:
        raise BadRequest("This is a bad request")
    except BadRequest as e:
        assert e.__cause__ is None
        assert "400" in str(e)
        assert "This is a bad request" in str(e)



# Generated at 2022-06-12 08:50:20.762825
# Unit test for function add_status_code
def test_add_status_code():
    # Test SanicException's code
    status_code = 404
    assert SanicException(message='Message', status_code=status_code).status_code == status_code
    # Test add_status_code if no quiet
    @add_status_code(status_code)
    class TestException(SanicException):
        pass

    assert TestException(message='Message', status_code=status_code).status_code == status_code
    assert TestException(message='Message', status_code=status_code, quiet=False).status_code == status_code
    assert not hasattr(TestException(message='Message', status_code=status_code), 'quiet')
    assert not hasattr(TestException(message='Message', status_code=status_code, quiet=False), 'quiet')

# Generated at 2022-06-12 08:50:28.091974
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(777, quiet=True)
    class CustomException(SanicException):
        pass
    assert issubclass(CustomException, SanicException)
    assert issubclass(CustomException, _sanic_exceptions[777])
    assert issubclass(CustomException, _sanic_exceptions[777])
    assert issubclass(CustomException, _sanic_exceptions[777])
    assert CustomException.status_code == 777
    assert issubclass(CustomException, SanicException)

# Generated at 2022-06-12 08:51:03.424574
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(300)
    class myclass:
        pass
    i = myclass("hi")
    assert hasattr(i, "status_code") == True
    assert hasattr(i, "quiet") == True
    assert i.status_code == 300
    assert i.quiet is True

# Generated at 2022-06-12 08:51:09.818618
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(400)
    class test(SanicException):
        pass

    new_status_code = _sanic_exceptions.get(400)
    assert new_status_code == test

    @add_status_code(403, quiet=False)
    class test2(SanicException):
        pass

    new_status_code = _sanic_exceptions.get(403)
    assert new_status_code == test2

# Generated at 2022-06-12 08:51:15.979086
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class FakeSanicException(SanicException):
        """
        **Status**: 202 Accepted

        The request has been accepted for processing,
        but the processing has not been completed.
        """
        pass

    assert FakeSanicException.status_code == 202
    assert len(_sanic_exceptions) == 8
    assert 202 in _sanic_exceptions

# Generated at 2022-06-12 08:51:27.002653
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class SanicException200(SanicException):
        pass
    
    @add_status_code(500)
    class SanicException500(SanicException):
        pass
    
    @add_status_code(200)
    class SanicException200WithQuietTrue(SanicException):
        pass

    assert SanicException200(message="message").status_code == 200

    assert "200" in str(SanicException200(message="message"))

    assert SanicException200(message="message").message == "message"

    assert SanicException200(message="message").quiet is False

    assert SanicException200WithQuietTrue(message="message").quiet is True

    assert SanicException500(message="message").quiet is False

    # Test that status_codes are globally registered
   

# Generated at 2022-06-12 08:51:35.947841
# Unit test for function add_status_code
def test_add_status_code():
    def mock_class(cls):
        return cls

    test_class = mock_class(SanicException)
    test_class = mock_class(test_class)
    assert test_class is not SanicException
    assert test_class.status_code is None
    assert test_class.quiet is None

    test_class = add_status_code(200, False)(test_class)
    assert test_class is not SanicException
    assert test_class.status_code is 200
    assert test_class.quiet is False

    test_class = add_status_code(403, True)(test_class)
    assert test_class is not SanicException
    assert test_class.status_code is 403
    assert test_class.quiet is True

# Generated at 2022-06-12 08:51:39.704692
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(202)
    class FooException(SanicException):
        pass
    try:
        raise FooException("Foo", status_code=202)
    except FooException as e:
        assert e.status_code == 202
        assert _sanic_exceptions[202] == FooException

# Generated at 2022-06-12 08:51:42.772212
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class StatusCodeTest():
        pass

    assert StatusCodeTest.status_code == 200

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:51:45.436329
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class stuff(SanicException):
        pass
    assert _sanic_exceptions[1] is stuff


# Generated at 2022-06-12 08:51:48.112462
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(405)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 405
    assert TestException.quiet == True



# Generated at 2022-06-12 08:51:58.273371
# Unit test for function add_status_code
def test_add_status_code():
    """
    Edge cases in the decorator add_status_code.
    """
    class_decorator = add_status_code(400)
    assert class_decorator.__name__ == 'class_decorator'
    class_decorator = add_status_code(400, quiet=False)
    assert class_decorator.__name__ == 'class_decorator'
    class_decorator = add_status_code(400, quiet=True)
    assert class_decorator.__name__ == 'class_decorator'

    class_decorator = add_status_code(404)
    assert class_decorator.__name__ == 'class_decorator'
    class_decorator = add_status_code(404, quiet=False)
    assert class_decorator

# Generated at 2022-06-12 08:53:14.456623
# Unit test for function add_status_code
def test_add_status_code():
    # test for decorator add_status_code, check for _sanic_exceptions has new added exception
    @add_status_code(404)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[404].__name__ == "TestException"
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet == True

    # test for NotFound function
    exc = NotFound("Test exception")
    assert exc.status_code == 404
    assert exc.quiet == True

    # test for SanicException
    exc = SanicException("Test exception", 500)
    assert exc.status_code == 500

# Generated at 2022-06-12 08:53:17.281584
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=503)
    class TM(SanicException):
        pass

    assert TM.status_code == 503


# Generated at 2022-06-12 08:53:27.840412
# Unit test for function add_status_code
def test_add_status_code():
    # A simple error class with status code
    class E1(SanicException):
        pass

    add_status_code(status_code=402, quiet=True)(E1)
    assert _sanic_exceptions[402] is E1
    assert E1.status_code == 402
    assert E1.quiet is True

    # A simple error class without status code
    class E2(SanicException):
        pass

    add_status_code(status_code=403)(E2)
    assert _sanic_exceptions[403] is E2
    assert E2.status_code == 403
    assert E2.quiet is True

    # A simple error class with status code, but not quiet
    class E3(SanicException):
        pass


# Generated at 2022-06-12 08:53:36.595922
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    # Test the function add_status_code
    # First, set a static value in a function
    add_status_code(404)(MyException)
    assert MyException().status_code == 404

    # Test the default value of the status code
    assert SanicException(
        message="Hello World", status_code=404).status_code == 404

    # Test the default value of the quiet attribute
    assert SanicException(
        message="Hello World",
        status_code=404
    ).quiet is True
    assert SanicException(
        message="Hello World",
        status_code=404,
        quiet=False
    ).quiet is False
    assert SanicException(
        message="Hello World",
        status_code=500,
        quiet=False
    ).quiet is False

# Generated at 2022-06-12 08:53:43.563155
# Unit test for function add_status_code
def test_add_status_code():
    # Define TestException
    @add_status_code(505)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 505
    assert TestException.quiet == True
    assert TestException("")
    assert TestException("This is a test message.")
    assert TestException("This is another test message.", status_code=505)
    assert TestException("This is another test message.", status_code=505, quiet=True)
    assert TestException("This is another test message.", status_code=505, quiet=None)



# Generated at 2022-06-12 08:53:48.602301
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test that add_status_code is usable
    """
    @add_status_code(200)
    class TestException(SanicException):
        """
        **Status**: 200 OK
        """

        pass

    assert isinstance(_sanic_exceptions[200], type)
    assert _sanic_exceptions[200] is TestException

# Generated at 2022-06-12 08:53:56.179105
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestEx(SanicException):
        pass
    assert TestEx.status_code == 200
    assert TestEx('').message == ''
    assert TestEx('test').message == 'test'
    assert TestEx('test').status_code == 200
    assert TestEx('test').quiet is False
    assert TestEx('test', quiet=True).quiet is True
    assert TestEx('test', status_code=400).status_code == 400
    assert TestEx('test', status_code=200, quiet=True).quiet is True


# Generated at 2022-06-12 08:54:01.196942
# Unit test for function add_status_code
def test_add_status_code():
    # class_decorator = add_status_code(400, quiet=None)
    # @class_decorator
    @add_status_code(400, quiet=None)
    class TestClass(SanicException):
        pass

    assert _sanic_exceptions[400] is TestClass
    assert TestClass.status_code == 400
    assert TestClass.quiet is True


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:54:05.163379
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500, quiet=True)
    class SanicTestException(SanicException):
        pass

    assert SanicTestException.quiet == True
    assert SanicTestException.status_code == 500
    assert _sanic_exceptions[500] == SanicTestException

# Generated at 2022-06-12 08:54:12.336876
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(Exception):
        pass

    @add_status_code(501, quiet=True)
    class TestException2(Exception):
        pass

    test_exception_1 = TestException
    assert test_exception_1.status_code == 500
    assert not test_exception_1.quiet

    test_exception_2 = TestException2
    assert test_exception_2.status_code == 501
    assert test_exception_2.quiet

