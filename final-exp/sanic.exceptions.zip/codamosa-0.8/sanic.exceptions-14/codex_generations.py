

# Generated at 2022-06-12 08:44:40.639859
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(603, quiet=True)
    class MyException(SanicException):
        """
        **Status**: 603 Out Of Test
        """

        pass

    assert MyException.status_code == 603
    assert MyException.quiet is True
    assert _sanic_exceptions[603] == MyException


# Unit tests for function abort

# Generated at 2022-06-12 08:44:44.824954
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410)
    class Gone(SanicException):
        """
            **Status**: 410 Gone
        """
        pass

    assert _sanic_exceptions[410] == Gone
    assert Gone.status_code == 410
    assert Gone.quiet is True


# Generated at 2022-06-12 08:44:48.770013
# Unit test for function add_status_code
def test_add_status_code():
    assert NotFound.status_code == 404
    assert ServerError.status_code == 500
    assert NotFound.quiet == True
    assert PayloadTooLarge.status_code == 413
    assert PayloadTooLarge.quiet == False

# Generated at 2022-06-12 08:44:58.840194
# Unit test for function add_status_code
def test_add_status_code():
    class CustomSanicException(SanicException):
        pass
    add_status_code(501, quiet=True)(CustomSanicException)
    try:
        raise CustomSanicException("Error Message", 501, quiet=False)
    except Exception as e:
        assert type(e) == CustomSanicException
        assert e.status_code == 501
        assert e.quiet == False
    try:
        raise CustomSanicException("Error Message", 501)
    except Exception as e:
        assert type(e) == CustomSanicException
        assert e.status_code == 501
        assert e.quiet == True


# Generated at 2022-06-12 08:45:02.536633
# Unit test for function add_status_code
def test_add_status_code():
    class FooError(SanicException):
        pass
    add_status_code(418)(FooError)
    assert issubclass(FooError, SanicException)
    assert FooError.status_code == 418

# Generated at 2022-06-12 08:45:05.663288
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(413)
    class TestException(SanicException):
        status_code = 413
    
    assert _sanic_exceptions[413] == TestException



# Generated at 2022-06-12 08:45:13.309865
# Unit test for function add_status_code
def test_add_status_code():
    # Test for SanicException
    try:
        raise Exception("abc")
    except Exception as e:
        assert type(e) is type(Exception("abc"))

    # Test for SanicException
    try:
        raise SanicException("def")
    except SanicException as e:
        assert type(e) is type(SanicException("def"))

    # Test for NotFound
    try:
        raise NotFound("ghi")
    except SanicException as e:
        assert "Not Found" in str(e)
        assert type(e) is type(NotFound("ghi"))

    # Test for InvalidUsage
    try:
        raise InvalidUsage("jkl")
    except SanicException as e:
        assert "Bad Request" in str(e)
        assert type(e) is type(InvalidUsage("jkl"))

# Generated at 2022-06-12 08:45:19.026444
# Unit test for function add_status_code
def test_add_status_code():
    exception = add_status_code(400)(SanicException)

    assert exception.status_code == 400, \
        "400 exception status code is not 400"

    exception = add_status_code(500)(SanicException)
    assert exception.status_code == 500, \
        "500 exception status code is not 500"


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:27.907782
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500,quiet=True)
    class MyException1(Exception):
        pass

    @add_status_code(500)
    class MyException2(Exception):
        pass
    class MyException3(Exception):
        pass
    add_status_code(500)(MyException3)

    assert MyException1.status_code == 500
    assert MyException1.quiet == True

    assert MyException2.status_code == 500
    assert MyException2.quiet == True

    assert MyException3.status_code == 500
    assert MyException3.quiet == True

    assert _sanic_exceptions[500] == MyException3

# Generated at 2022-06-12 08:45:34.053368
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    assert _sanic_exceptions[501] == NotImplemented

    @add_status_code(502)
    class BadGateway(SanicException):
        pass

    assert _sanic_exceptions[502] == BadGateway

    @add_status_code(503)
    class ServiceUnavailable(SanicException):
        pass

    assert _sanic_exceptions[503] == ServiceUnavailable


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:44.620548
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass
    t = test = TestException("test")
    assert t.status_code is None
    assert t.quiet is None
    assert hasattr(TestException(), 'status_code')
    assert not hasattr(TestException(), 'quiet')
    assert t.status_code is None
    assert t.quiet is None
    assert status_code == 404
    assert code == 404
    assert quiet is None
    assert t.status_code == 404
    assert t.quiet is None


# Generated at 2022-06-12 08:45:55.550791
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    # Test that TestException.status_code is the status_code that was passed
    # to add_status_code
    add_status_code(420)(TestException)
    assert TestException.status_code == 420

    # Test that TestException.quiet is set to True for the default quiet
    # parameter of add_status_code
    add_status_code(200)(TestException)
    assert TestException.quiet is True

    # Test that TestException.quiet is set to False if quiet=False
    add_status_code(448, False)(TestException)
    assert TestException.quiet is False

    # Test that TestException.quiet is set to True if quiet=True
    add_status_code(450, True)(TestException)
    assert TestException.quiet is True

# Generated at 2022-06-12 08:46:04.917145
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        def __init__(self, message, status_code=None, scheme=None, **kwargs):
            super().__init__(message, status_code)

            # if auth-scheme is specified, set "WWW-Authenticate" header
            if scheme is not None:
                values = ['{!s}="{!s}"'.format(k, v) for k, v in kwargs.items()]
                challenge = ", ".join(values)

                self.headers = {
                    "WWW-Authenticate": f"{scheme} {challenge}".rstrip()
                }

    return True


# Generated at 2022-06-12 08:46:14.459017
# Unit test for function add_status_code
def test_add_status_code():
    # test cases
    test_list=(
        # (code, quiet, expected_class),
        (404, None, NotFound),
        (400, None, InvalidUsage),
        (405, None, MethodNotSupported),
        (500, None, ServerError),
        (503, None, ServiceUnavailable),
        (408, None, RequestTimeout),
        (413, None, PayloadTooLarge),
        (416, None, ContentRangeError),
        (417, None, HeaderExpectationFailed),
        (403, None, Forbidden),
        (401, None, Unauthorized)
    )
    def get_class_name(cls):
        return cls.__name__


# Generated at 2022-06-12 08:46:16.601753
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass
    assert CustomException.status_code == 400


# Generated at 2022-06-12 08:46:22.070674
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    @add_status_code(415)
    class MediaTypeNotSupported(SanicException):
        pass

    assert _sanic_exceptions[415] == MediaTypeNotSupported
    assert _sanic_exceptions[501] == NotImplemented

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:27.613030
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass
    assert _sanic_exceptions[400] == InvalidUsage
    assert hasattr(InvalidUsage, "status_code")
    assert InvalidUsage.status_code == 400


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:30.593307
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(505)
    class TestException(SanicException):
        def __init__(self):
            super().__init__('test')

    assert TestException.status_code == 505

# Generated at 2022-06-12 08:46:39.377171
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestSanicException(SanicException):
        pass

    assert TestSanicException.status_code == 100
    assert TestSanicException.quiet is True

    @add_status_code(100, quiet=True)
    class TestSanicException2(SanicException):
        pass

    @add_status_code(100, quiet=False)
    class TestSanicException3(SanicException):
        pass

    assert TestSanicException2.status_code == 100
    assert TestSanicException3.status_code == 100
    assert TestSanicException2.quiet is True
    assert TestSanicException3.quiet is False
    assert TestSanicException2._sanic_exceptions[100] == TestSanicException2
    assert TestSanicException3._sanic_ex

# Generated at 2022-06-12 08:46:42.503251
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class TestException(Exception):
        pass

    assert _sanic_exceptions[401] == TestException

# Generated at 2022-06-12 08:46:50.264936
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Exc1(Exception):
        pass

    assert Exc1.status_code == 400

    @add_status_code(201)
    class Exc2(Exception):
        pass

    assert Exc2.status_code == 201

# Generated at 2022-06-12 08:46:55.834035
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        cls.status_code = 449
        _sanic_exceptions[449] = cls
        return cls

    test_class_decorator = test_status_code(449)(test_class_decorator)
    assert test_class_decorator.__name__ == 'test_class_decorator'
    assert test_class_decorator.status_code == 449

# Generated at 2022-06-12 08:47:02.780647
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
   
    assert _sanic_exceptions[400].__name__ == 'TestException'
    assert TestException.status_code == 400
    assert TestException.quiet
   
    @add_status_code(500)
    class TestException500(SanicException):
        pass
   
    assert _sanic_exceptions[500].__name__ == 'TestException500'
    assert TestException500.status_code == 500
    assert not TestException500.quiet
   
    @add_status_code(501)
    class TestException501(SanicException):
        pass
   
    assert _sanic_exceptions[501] == TestException501
    assert TestException501.status_code == 501

# Generated at 2022-06-12 08:47:14.499780
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(2000)
    class NewSanicException(SanicException):
        """Exception class created in test_add_status_code"""

    assert NewSanicException.status_code == 2000
    assert NewSanicException.quiet is None

    @add_status_code(2002, quiet=True)
    class NewSanicExceptionQuiet(SanicException):
        """Exception class created in test_add_status_code, quiet exception"""

    assert NewSanicExceptionQuiet.status_code == 2002
    assert NewSanicExceptionQuiet.quiet

    inst = NewSanicExceptionQuiet("test of quiet exception")
    assert inst.quiet


# Generated at 2022-06-12 08:47:17.025544
# Unit test for function add_status_code
def test_add_status_code():
    assert len(_sanic_exceptions) == 5

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert len(_sanic_exceptions) == 6
    assert _sanic_exceptions[400].__name__ == "TestException"


# Generated at 2022-06-12 08:47:20.295233
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418, quiet=True)
    class IAmATeapot(SanicException):
        pass
    assert IAmATeapot.status_code == 418
    assert IAmATeapot.quiet is True


# Generated at 2022-06-12 08:47:27.504329
# Unit test for function add_status_code
def test_add_status_code():
    assert not hasattr(SanicException, 'status_code')
    assert 401 not in _sanic_exceptions
    
    @add_status_code(401)
    class MyException(SanicException):
        pass
    
    assert SanicException.status_code is None
    assert MyException.status_code == 401
    assert 401 in _sanic_exceptions
    assert _sanic_exceptions[401] is MyException

# Generated at 2022-06-12 08:47:36.631537
# Unit test for function add_status_code
def test_add_status_code():
    assert issubclass(_sanic_exceptions.get(404), NotFound)
    assert issubclass(_sanic_exceptions.get(400), InvalidUsage)
    assert issubclass(_sanic_exceptions.get(500), ServerError)
    assert issubclass(_sanic_exceptions.get(503), ServiceUnavailable)
    assert issubclass(_sanic_exceptions.get(408), RequestTimeout)
    assert issubclass(_sanic_exceptions.get(413), PayloadTooLarge)
    assert issubclass(_sanic_exceptions.get(416), ContentRangeError)
    assert issubclass(_sanic_exceptions.get(417), HeaderExpectationFailed)
    assert issubclass(_sanic_exceptions.get(403), Forbidden)

# Generated at 2022-06-12 08:47:39.269405
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Status200(SanicException):
        pass
    assert Status200.status_code == 200
    assert Status200.quiet is True

# Generated at 2022-06-12 08:47:50.322264
# Unit test for function add_status_code
def test_add_status_code():
    # Case 1: If we add a new class, should add it in _sanic_exceptions dict
    @add_status_code(200)
    class CustomException(SanicException):
        pass
    assert issubclass(CustomException, SanicException)
    assert _sanic_exceptions[200] == CustomException

    # Case 2: If we add a new class and set the custom quiet property to True,
    # then it should be updated in the created class
    @add_status_code(201, False)
    class CustomException2(SanicException):
        pass
    assert issubclass(CustomException2, SanicException)
    assert _sanic_exceptions[201] == CustomException2
    assert CustomException2.quiet == False

    # Case 3: If we add a new class and set quiet property to None, then it should

# Generated at 2022-06-12 08:48:05.811136
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(404, quiet=True)
    assert add_status_code(404, quiet=False)
    assert add_status_code(404, quiet=None)
    assert not add_status_code(500)
    assert add_status_code(500, quiet=True)
    assert not add_status_code(500, quiet=False)
    assert not add_status_code(500, quiet=None)
    class MyException(SanicException):
        status_code = 500
    MyException.quiet


# Generated at 2022-06-12 08:48:09.176812
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Http100Exception(SanicException):
        pass

    assert _sanic_exceptions[100] == Http100Exception


# Generated at 2022-06-12 08:48:15.698827
# Unit test for function add_status_code
def test_add_status_code():
    class FooSanicException(SanicException):
        def __init__(self):
            super().__init__("foo")

    foo_sanic_exception = add_status_code(200)(FooSanicException)
    assert foo_sanic_exception() == FooSanicException()
    assert foo_sanic_exception().status_code == 200


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:23.032898
# Unit test for function add_status_code
def test_add_status_code():
    class TestSanicException(SanicException):
        pass

    status_code = 601
    quiet = True

    assert not hasattr(TestSanicException, 'status_code')
    assert not hasattr(TestSanicException, 'quiet')
    add_status_code(status_code, quiet)(TestSanicException)
    assert TestSanicException.status_code == status_code
    assert TestSanicException.quiet == quiet
    assert TestSanicException in _sanic_exceptions.values()


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:27.129570
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[400]().status_code == 400
    assert _sanic_exceptions[400]().message == "Bad Request"



# Generated at 2022-06-12 08:48:29.458077
# Unit test for function add_status_code
def test_add_status_code():
    assert 500 in _sanic_exceptions
    assert _sanic_exceptions[500] == ServerError


# Generated at 2022-06-12 08:48:31.852677
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=unused-variable

    @add_status_code(999)
    class MyException(SanicException):
        pass



# Generated at 2022-06-12 08:48:39.549488
# Unit test for function add_status_code
def test_add_status_code():
    import pytest

    @add_status_code(302)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 302
    with pytest.raises(MyException, match="test message"):
        raise MyException("test message")

    # test quiet default
    assert not MyException.quiet

    @add_status_code(200, False)
    class MyException2(SanicException):
        pass

    assert MyException2.quiet == False

    @add_status_code(200)
    class MyException3(SanicException):
        pass

    assert MyException3.quiet == True

# Generated at 2022-06-12 08:48:45.845820
# Unit test for function add_status_code
def test_add_status_code():
    class Test:
        pass

    assert Test.status_code == 200
    t = Test()
    assert t.status_code == 200
    with pytest.raises(KeyError):
        _sanic_exceptions[401]

    add_status_code(401)(Test)
    t = Test()
    assert Test.status_code == 401
    assert _sanic_exceptions[401] == Test
    assert t.status_code == 401

# Generated at 2022-06-12 08:48:56.611044
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    @add_status_code(code=400, quiet=True)
    class _TestException(TestException):
        pass
    assert _TestException.status_code == 400
    assert _TestException.quiet is True

    @add_status_code(code=401, quiet=None)
    class _TestException(TestException):
        pass
    assert _TestException.status_code == 401
    assert _TestException.quiet is False

    @add_status_code(code=500, quiet=False)
    class _TestException(TestException):
        pass
    assert _TestException.status_code == 500
    assert _TestException.quiet is False

    @add_status_code(code=400, quiet=True)
    class _TestException(TestException):
        pass


# Generated at 2022-06-12 08:49:14.534165
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(600)
    class newSanicException(SanicException):
        pass

    assert _sanic_exceptions[600] == newSanicException

# Generated at 2022-06-12 08:49:18.034178
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestErr(SanicException):
        pass
    assert _sanic_exceptions[500] == TestErr
    assert _sanic_exceptions[500]().status_code == 500

# Generated at 2022-06-12 08:49:23.188224
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(000)
    class Test1(SanicException):
        pass

    assert Test1.status_code == 000
    assert Test1().quiet
    assert Test1().status_code == 000


# Generated at 2022-06-12 08:49:30.547212
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.helpers import STATUS_CODES

    @add_status_code(123)
    class TestException(Exception):
        pass

    assert TestException().status_code == 123
    assert TestException.status_code == 123
    assert (
        TestException().__str__()
        == "123 " + STATUS_CODES[TestException.status_code]
    )
    assert TestException().__repr__() == f"{TestException.__name__}(123)"

    @add_status_code(123, quiet=False)
    class TestException2(Exception):
        pass

    assert TestException2().status_code == 123
    assert TestException2().quiet is False

# Generated at 2022-06-12 08:49:35.099452
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(Exception):
        def __init__(self, message, status_code=None):
            super().__init__(message)
            self.status_code = status_code
    @add_status_code(100)
    class TestException100(TestException):
        pass
    class TestException200(TestException):
        pass
    class TestException300(TestException):
        pass
    @add_status_code(400)
    class TestException400(TestException):
        pass
    @add_status_code(500)
    class TestException500(TestException):
        pass
    @add_status_code(600)
    class TestException600(TestException):
        pass
    assert TestException100.status_code == 100
    assert TestException200.status_code == 200
    assert TestException300.status

# Generated at 2022-06-12 08:49:40.580730
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert (_sanic_exceptions[404] is TestException)


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:49:49.206946
# Unit test for function add_status_code
def test_add_status_code():
    # First, try to make an exception with the code 500
    # This should fail
    with pytest.raises(AttributeError):
        @add_status_code(500)
        class myException(SanicException):
            pass

    # Now, try to make an exception with the code 600
    # This should work
    @add_status_code(600)
    class myException(SanicException):
        pass

    # Check that the exception can be initialized
    exception_instance = myException("This is an exception")

    # Now, make a new exception with code 600
    @add_status_code(600)
    class myException2(SanicException):
        pass

    # Check that the exception can be initialized
    exception_instance2 = myException2("This is an exception")

    # Make sure the classes have the same code
   

# Generated at 2022-06-12 08:49:59.062236
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Example400(SanicException): pass
    # Test __str__
    status_code = 400
    message = STATUS_CODES[status_code].decode("utf8")
    e = Example400(message)
    assert str(e) == message
    assert e.status_code == status_code

    @add_status_code(400, False)
    class Example400NoQuiet(SanicException): pass

    e = Example400NoQuiet(message)
    assert e.quiet == False

    @add_status_code(500, False)
    class Example500NoQuiet(SanicException): pass

    e = Example500NoQuiet(message)
    assert e.quiet == False


# Generated at 2022-06-12 08:50:07.471768
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage(SanicException):
        pass

    assert InvalidUsage.status_code == 400
    assert InvalidUsage().status_code == 400

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    assert ServerError.status_code == 500
    assert ServerError().status_code == 500

    @add_status_code(200)
    class OK(SanicException):
        pass

    assert OK.status_code == 200
    assert OK().status_code == 200



# Generated at 2022-06-12 08:50:11.418165
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass
    assert MyException._status_code == 400
    assert MyException._message == 'MyException'
    assert MyException._headers == {}
    assert MyException._quiet == True


# Generated at 2022-06-12 08:50:46.636109
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestSanicException(SanicException):
        def __init__(self, message):
            super().__init__(message)

    assert TestSanicException.status_code == 400
    assert _sanic_exceptions[400] == TestSanicException

# Generated at 2022-06-12 08:50:50.733352
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class NewException(SanicException):
        pass

    assert _sanic_exceptions[123] == NewException
    assert NewException.status_code == 123

    assert issubclass(NewException, SanicException)



# Generated at 2022-06-12 08:51:02.042925
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Ok(SanicException):
        """
        **Status**: 200 OK
        """
        pass
    assert _sanic_exceptions[200] is Ok
    ok = Ok("message")
    assert ok.status_code == 200
    assert ok.quiet is None
    @add_status_code(200)
    class QuietOk(SanicException):
        """
        **Status**: 200 OK
        """
        pass
    assert _sanic_exceptions[200] is QuietOk
    quiet_ok = QuietOk("message")
    assert quiet_ok.status_code == 200
    assert quiet_ok.quiet is True

# Generated at 2022-06-12 08:51:05.984246
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(Exception):
        pass

    assert _sanic_exceptions[400] is CustomException
    assert CustomException.status_code is 400
    assert CustomException.quiet is True

# Generated at 2022-06-12 08:51:12.405493
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)  # 400 Bad Request
    class InvalidUsage(Exception):
        pass
    assert STATUS_CODES[400] == b'Bad Request'
    try: 
        raise InvalidUsage()
    except InvalidUsage:
        assert STATUS_CODES[400] == b'Bad Request'

# Unit tests for class SanicException

# Generated at 2022-06-12 08:51:15.471150
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class CustomException(SanicException):
        pass

    custom_exception = CustomException("Test Exception")
    assert STATUS_CODES[200] == custom_exception.message

# Generated at 2022-06-12 08:51:20.753164
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        add_status_code(666)

    @add_status_code(666)
    class UserDefinedException(SanicException):
        pass

    assert UserDefinedException.status_code == 666
    assert UserDefinedException.quiet is False
    assert 666 in _sanic_exceptions
    assert issubclass(_sanic_exceptions[666], SanicException)

# Generated at 2022-06-12 08:51:31.646131
# Unit test for function add_status_code
def test_add_status_code():
    class Test(SanicException):
        pass

    @add_status_code(409)
    class Test409(Test):
        pass

    @add_status_code(410, quiet=True)
    class Test410(Test):
        pass

    try:
        raise Test(status_code=404, message='Not Found')
    except Test as exc:
        assert exc.status_code == 404
        assert exc.quiet is False
        assert exc.message == 'Not Found'

    try:
        raise Test409(status_code=409, message='Conflict')
    except Test409 as exc:
        assert exc.status_code == 409
        assert exc.quiet is False
        assert exc.message == 'Conflict'


# Generated at 2022-06-12 08:51:33.899462
# Unit test for function add_status_code
def test_add_status_code():
    class Test():
        pass
    test = class_decorator(Test)
    assert test.status_code == 500
    assert not test.quiet

# Generated at 2022-06-12 08:51:42.284640
# Unit test for function add_status_code
def test_add_status_code():
    def add_status_code_test(status_code):
        @add_status_code(status_code)
        class SanicExceptionTest(SanicException):
            pass
        return SanicExceptionTest
    status_code = {'200': 'test', '404': 'test', '500': 'test'}
    SanicExceptionTest200 = add_status_code_test(status_code['200'])
    SanicExceptionTest404 = add_status_code_test(status_code['404'])
    SanicExceptionTest500 = add_status_code_test(status_code['500'])
    assert SanicExceptionTest200.status_code == status_code[
        '200'] and SanicExceptionTest404.status_code == status_code[
            '404'] and SanicExceptionTest500.status_code == status_

# Generated at 2022-06-12 08:52:58.380832
# Unit test for function add_status_code
def test_add_status_code():
    # Adding an exception with the default parameter
    class TestException(SanicException):
        pass

    add_status_code(404)(TestException)
    assert _sanic_exceptions[404] == TestException

    # Adding an exception without the default parameter
    class TestException2(SanicException):
        pass

    add_status_code(500, quiet=False)(TestException2)
    assert _sanic_exceptions[500] == TestException2
    assert _sanic_exceptions[500].quiet == False

# Unit tests for class SanicException

# Generated at 2022-06-12 08:53:00.926520
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(450)
    class TestException(Exception):
        pass

    assert '450' in _sanic_exceptions


# Generated at 2022-06-12 08:53:02.136886
# Unit test for function add_status_code
def test_add_status_code():
    # TODO: actually add tests
    pass

# Generated at 2022-06-12 08:53:12.312973
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class InternalServerError(SanicException):
        pass
    
    exception = InternalServerError("An error occurred")
    assert type(exception) == InternalServerError
    assert exception.status_code == 500
    assert exception.quiet == False

    @add_status_code(404)
    class NotFoundException(SanicException):
        pass

    exception = NotFoundException("Resource not found")
    assert type(exception) == NotFoundException
    assert exception.status_code == 404
    assert exception.quiet == True
    
    @add_status_code(503, quiet=False)
    class ServiceUnavailableException(SanicException):
        pass

    exception = ServiceUnavailableException("Service unavailable")
    assert type(exception) == ServiceUnavailableException
    assert exception.status_

# Generated at 2022-06-12 08:53:20.430547
# Unit test for function add_status_code
def test_add_status_code():
    code1 = 200
    code2 = 500
    message = "bad request"

    @add_status_code(code1)
    class BadRequestException(SanicException):
        pass

    @add_status_code(code2, quiet=True)
    class ServerException(SanicException):
        pass

    assert not hasattr(BadRequestException, "quiet")
    assert ServerException.quiet

    instance1 = BadRequestException(message)
    assert instance1.status_code == code1
    assert str(instance1) == message

    instance2 = ServerException(message)
    assert instance2.status_code == code2
    assert str(instance2) == message

# Generated at 2022-06-12 08:53:29.819767
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test cases:
        1. test add_status_code(100, None)
        2. test add_status_code(101, True)
    """
    status = 100
    quiet = None

    # Test case 1
    class TestClass1(SanicException):
        pass

    add_status_code(status, quiet)(TestClass1)
    assert TestClass1.status_code == status
    assert TestClass1.quiet is status != 500

    # Test case 2
    class TestClass2(SanicException):
        pass

    add_status_code(status, quiet)(TestClass2)
    assert TestClass2.status_code == status
    assert TestClass2.quiet is status != 500

# Generated at 2022-06-12 08:53:35.304306
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=418)
    class IAmATeapot(SanicException):
        pass

    assert 405 in _sanic_exceptions, "MethodNotSupported should be added to _sanic_exceptions"
    assert 418 in _sanic_exceptions, "IAmATeapot should be added to _sanic_exceptions"
    assert _sanic_exceptions[418] == IAmATeapot, "SanicException 404 should be NotFound"

# Generated at 2022-06-12 08:53:36.130591
# Unit test for function add_status_code
def test_add_status_code():
    pass


# Generated at 2022-06-12 08:53:41.531119
# Unit test for function add_status_code
def test_add_status_code():
    '''
    assert that the status code is added to SanicException
    '''
    @add_status_code(400)
    class exception1(SanicException):
        pass

    assert 400 in _sanic_exceptions, \
        "The status code was not added to the SanicException"
    assert exception1 == _sanic_exceptions[400], \
        "The exception was not added to the _sanic_exceptions"

# Generated at 2022-06-12 08:53:44.671610
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[200] == MyException


if __name__ == "__main__":
    test_add_status_code()