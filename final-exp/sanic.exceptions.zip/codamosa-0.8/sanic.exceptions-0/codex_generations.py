

# Generated at 2022-06-12 08:44:33.308289
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Scheme is mandatory for Basic Authentication
    # Realm is mandatory for Basic Authentication
    with pytest.raises(ValueError):
        raise Unauthorized("Auth required.",
                           scheme="Basic")
    # Scheme is mandatory for Digest Authentication
    # Realm is mandatory for Digest Authentication
    with pytest.raises(ValueError):
        raise Unauthorized("Auth required.",
                           scheme="Digest")

# Generated at 2022-06-12 08:44:37.202094
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    This test covers the constructors of class Unauthorized
    """

    # Arrange
    message = "Auth required."
    scheme = "Basic"
    realm = "Restricted Area"

    # Act
    exception = Unauthorized(message, scheme=scheme, realm=realm)

    # Assert
    assert exception.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

# Generated at 2022-06-12 08:44:39.635721
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present:
    raise Unauthorized(
        "Auth required.", scheme="Basic", realm="Restricted Area")

# Generated at 2022-06-12 08:44:42.981357
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # Should not raise the exception
        Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-12 08:44:52.646756
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Test the constructors of class Unauthorized.
    """
    """
    The Unauthorized constructor should accept no positional parameters
    """
    with pytest.raises(TypeError):
        Unauthorized()

    """
    The Unauthorized constructor should accept a mandatory positional parameter
    """
    U = Unauthorized('Unauthorized')
    assert U.status_code == 401
    assert U.scheme is None
    assert U.message == 'Unauthorized'
    assert U.headers is None

    """
    The Unauthorized constructor should accept a mandatory positional parameter,
    a keyword parameter 'status_code' and a keyword parameter 'scheme'.
    """
    U = Unauthorized('Unauthorized', status_code=401, scheme="Bearer")
    assert U.status_code == 401

# Generated at 2022-06-12 08:44:58.328060
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class DecoratedClass1(SanicException):
        pass

    @add_status_code(404)
    class DecoratedClass2(SanicException):
        pass

    assert DecoratedClass1.status_code == 400
    assert DecoratedClass2.status_code == 404

# Generated at 2022-06-12 08:45:08.067783
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is None

    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None

    @add_status_code(404, True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True


# Generated at 2022-06-12 08:45:12.616942
# Unit test for function add_status_code
def test_add_status_code():
    class TestingException(SanicException):
        pass

    class TestingError(SanicException):
        pass

    TestingException = add_status_code(200)(TestingException)
    TestingError = add_status_code(200, True)(TestingError)

    assert TestingException.status_code == 200
    assert TestingException.quiet is False

    assert TestingError.status_code == 200
    assert TestingError.quiet is True

    assert abort(200) == 'OK'
    assert abort(200, 'OK') == 'OK'
    assert abort(200, 'OK1') == 'OK1'

# Generated at 2022-06-12 08:45:15.328041
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}


# Generated at 2022-06-12 08:45:19.506752
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    instance = Unauthorized('this_is_forbidden', scheme='this_is_scheme', realm='this_is_realm')
    assert instance.__dict__ == {"scheme": 'this_is_scheme', "realm": 'this_is_realm'}

# Generated at 2022-06-12 08:45:25.857481
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(Exception) as error:
        @add_status_code(404, quiet=False)
        class _TestClass(SanicException):
            pass
    assert isinstance(error.value, TypeError)



# Generated at 2022-06-12 08:45:35.188530
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class a(SanicException):
        pass
    assert a.status_code == 200
    assert a().status_code == 200

    @add_status_code(201)
    class b(SanicException):
        pass
    assert b.status_code == 201
    assert b().status_code == 201

    @add_status_code(202)
    class c(SanicException):
        pass
    assert c.status_code == 202
    assert c().status_code == 202

    assert NotFound().status_code == 404
    assert InvalidUsage().status_code == 400
    assert MethodNotSupported().status_code == 405
    assert ServerError().status_code == 500
    assert ServiceUnavailable().status_code == 503

    assert URLBuildError().status_code == 500
   

# Generated at 2022-06-12 08:45:36.832185
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(100)
    assert _sanic_exceptions.get(100)


# Generated at 2022-06-12 08:45:38.689781
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(450)
    class BlockedByWindowsParentalControls(SanicException):
        pass
    assert BlockedByWindowsParentalControls.status_code == 450
    assert len(_sanic_exceptions) == 18

# Generated at 2022-06-12 08:45:44.169333
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class _200(SanicException):
        pass

    @add_status_code(200, quiet=True)
    class _200_quiet(SanicException):
        pass

    assert issubclass(_200, _200_quiet)

# Generated at 2022-06-12 08:45:47.288699
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(Exception):
        pass

    assert _sanic_exceptions[999] == TestException
    assert _sanic_exceptions[999]().status_code == 999
    assert _sanic_exceptions[999]().quiet is True

# Generated at 2022-06-12 08:45:59.014337
# Unit test for function add_status_code
def test_add_status_code():
    payload = [
        400,
        401,
        403,
        404,
        405,
        408,
        413,
        416,
        417,
        500,
        503,
    ]

    for payload_value in payload:
        try:
            abort(status_code=payload_value)
        except Exception as e:
            assert isinstance(e, SanicException)
            assert e.status_code == payload_value
            if e.status_code in (400, 401, 403, 404, 405, 408, 413, 416, 417):
                assert e.quiet is True
            elif e.status_code == 500:
                assert e.quiet is False
            elif e.status_code == 503:
                assert e.quiet is True

    # Other value

# Generated at 2022-06-12 08:46:03.821026
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(520)
    class UnknownError(SanicException):
        pass

    assert _sanic_exceptions[520] is UnknownError

    @add_status_code(505)
    class VersionNotSupported(SanicException):
        pass

    assert _sanic_exceptions[505] is VersionNotSupported

# Generated at 2022-06-12 08:46:08.101166
# Unit test for function add_status_code
def test_add_status_code():
    # Decorator used for adding exceptions to :class:`SanicException`.
    @add_status_code(code=500)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """

        pass

    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-12 08:46:13.988759
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    @add_status_code(499)
    class MyException2(SanicException):
        pass

    @add_status_code(500)
    class MyException3(SanicException):
        pass

    assert MyException.status_code == None
    assert MyException.quiet == False
    assert MyException2.status_code == 499
    assert MyException2.quiet == True
    assert MyException3.status_code == 500
    assert MyException3.quiet == False

# Generated at 2022-06-12 08:46:27.665472
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[400] == MyException
    assert MyException.status_code == 400
    assert MyException.quiet

    @add_status_code(500)
    class MyOtherException(SanicException):
        pass

    assert _sanic_exceptions[500] == MyOtherException
    assert MyOtherException.status_code == 500
    assert not MyOtherException.quiet

    @add_status_code(500, False)
    class MyOtherException(SanicException):
        pass

    assert _sanic_exceptions[500] == MyOtherException
    assert MyOtherException.status_code == 500
    assert MyOtherException.quiet


# Generated at 2022-06-12 08:46:30.255371
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(999)
    class Test_999(SanicException):
        pass

    assert status_code == 999
    assert message == "Message"
    assert quiet == True

# Generated at 2022-06-12 08:46:38.710141
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test if add_status_code is working properly.
    """
    @add_status_code(403)
    class ForbiddenTest(SanicException):
        pass

    assert ForbiddenTest.status_code == 403
    assert ForbiddenTest.quiet == True

    @add_status_code(401)
    class UnauthorizedTest(SanicException):
        pass

    assert UnauthorizedTest.status_code == 401
    assert UnauthorizedTest.quiet == True

    @add_status_code(500)
    class ServerErrorTest(SanicException):
        pass

    assert ServerErrorTest.status_code == 500
    assert ServerErrorTest.quiet == False

    assert _sanic_exceptions[500] is ServerErrorTest



# Generated at 2022-06-12 08:46:50.213536
# Unit test for function add_status_code
def test_add_status_code():
    a = add_status_code(444)(SanicException)
    assert a.status_code == 444
    a = add_status_code(445)(SanicException)
    assert a.status_code == 445
    a = add_status_code(500, quiet=True)(SanicException)
    assert a.status_code == 500
    assert a.quiet is True
    a = add_status_code(501)(SanicException)
    assert a.status_code == 501
    assert a.quiet is True
    a = add_status_code(502, quiet=False)(SanicException)
    assert a.status_code == 502
    assert a.quiet is False
    a = add_status_code(503)(SanicException)
    assert a.status_code == 503
    assert a.quiet is False

# Generated at 2022-06-12 08:46:56.771463
# Unit test for function add_status_code
def test_add_status_code():
    # Test SanicException, defined in the class itself
    exc = SanicException("Sanic Exception", 500)
    assert exc.status_code == 500
    assert exc.quiet is None

    # Test NotFound, defined as class decorator
    exc = NotFound("Not Found", 404)
    assert exc.status_code == 404
    assert exc.quiet is True

    # Test PayloadTooLarge, defined as function decorator
    exc = PayloadTooLarge("Payload Too Large", 413)
    assert exc.status_code == 413
    assert exc.quiet is True

# Generated at 2022-06-12 08:46:58.485015
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)(SanicException) # this should not raise an exception


# Generated at 2022-06-12 08:47:05.351270
# Unit test for function add_status_code
def test_add_status_code():
    # Test selecting only status code
    assert(add_status_code(200)(SanicException).status_code == 200)
    # Test passing in a custom exception
    assert(isinstance(add_status_code(200)(Exception()), Exception))
    # Test quiet is set correctly
    assert(add_status_code(200)(SanicException).quiet == True)
    # Test quiet is set correctly
    assert(add_status_code(500)(SanicException).quiet == False)



# Generated at 2022-06-12 08:47:10.725835
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass
    assert 999 in _sanic_exceptions


# Unit Test for method abort
# To keep the syntax simple, we use the assert raise function here.
# pylint: disable=W0123

# Generated at 2022-06-12 08:47:20.683361
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(100)
    class Foo(SanicException):
        pass

    assert _sanic_exceptions[100].__name__ == "Foo"
    assert _sanic_exceptions[100].status_code == 100
    assert _sanic_exceptions[100]().quiet is False

    @add_status_code(1001, True)
    class Foo(SanicException):
        pass

    assert _sanic_exceptions[1001].status_code == 1001
    assert _sanic_exceptions[1001]().quiet is True

    @add_status_code(1002, False)
    class Foo(SanicException):
        pass

    assert _sanic_exceptions[1002]().quiet is False


# Generated at 2022-06-12 08:47:26.468515
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass
    
    print(_sanic_exceptions)
    print(BadRequest.status_code)
    print("SanicException" in _sanic_exceptions[400])

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:47:35.156844
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(400)
    add_status_code(405)
    add_status_code(408)
    add_status_code(500)
    add_status_code(503)

# Generated at 2022-06-12 08:47:42.517251
# Unit test for function add_status_code
def test_add_status_code():

    # setup
    test_status_code = 503

    @add_status_code(test_status_code)
    class CustomException(SanicException):
        pass

    # test
    assert _sanic_exceptions[test_status_code] == CustomException

    # test
    # if error_handler is not a sub-class of SanicException, raise ValueError
    error_handler = lambda message: None
    with raises(ValueError):
        add_status_code(100, error_handler)

# Generated at 2022-06-12 08:47:48.335027
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class NoiConNoi(SanicException):
        pass

    try:
        raise NoiConNoi('We want your soul')
    except NoiConNoi as exc:
        assert exc.status_code == 418
        assert exc.args[0] == 'We want your soul'
    except:
        pass
    else:
        raise Exception('Shouldnt happen')


# Generated at 2022-06-12 08:47:52.101457
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class Foo(SanicException):
        pass

    assert _sanic_exceptions.get(408) == Foo
    assert _sanic_exceptions.get(408)().status_code == 408

# Generated at 2022-06-12 08:47:57.290256
# Unit test for function add_status_code
def test_add_status_code():
    """
    Simple test for the add_status_code decorator.
    """
    @add_status_code(400)
    class ResponseException(Exception):
        pass
    assert _sanic_exceptions[400] == ResponseException
    assert _sanic_exceptions[400]().status_code == 400
    assert _sanic_exceptions[400].__name__ == 'ResponseException'
    assert _sanic_exceptions[400]().__class__.__name__ == 'ResponseException'



# Generated at 2022-06-12 08:48:04.514480
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    @add_status_code(202)
    class MyOtherException(SanicException):
        pass

    assert _sanic_exceptions[202] == MyOtherException
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[500] is None
    assert issubclass(ServerError, SanicException)
    assert issubclass(MyException, SanicException)
    assert issubclass(MyOtherException, NotFound)

# Generated at 2022-06-12 08:48:14.467169
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert (_sanic_exceptions[503].__class__ == ServiceUnavailable) == True
    assert _sanic_exceptions[503].__doc__ ==\
        "**Status**: 503 Service Unavailable\n\nThe server is " \
        "currently unavailable (because it is overloaded or\n" \
        "down for maintenance). Generally, this is a temporary state."
    assert _sanic_exceptions[503].quiet == True
    assert _sanic_exceptions[501] == NotImplementedError

# Generated at 2022-06-12 08:48:20.452594
# Unit test for function add_status_code
def test_add_status_code():
    class Error(SanicException):
        pass

    assert Error.status_code is None
    assert list(_sanic_exceptions.keys()).count(418) == 0
    add_status_code(418)(Error)
    assert Error.status_code == 418
    assert list(_sanic_exceptions.keys()).count(418) == 1
    assert _sanic_exceptions[418] == Error



# Generated at 2022-06-12 08:48:23.608993
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class MyServerError(SanicException):
        pass

    assert MyServerError.status_code == 500
    assert MyServerError.quiet == True
    assert _sanic_exceptions.get(500) is MyServerError



# Generated at 2022-06-12 08:48:31.458606
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyZeroDivisionError(SanicException):
        pass
    assert MyZeroDivisionError.status_code == 404
    assert MyZeroDivisionError.quiet == True
    assert _sanic_exceptions[404] == MyZeroDivisionError

    @add_status_code(999)
    class MyUnknownException(SanicException):
        pass
    assert MyUnknownException.status_code == 999
    assert MyUnknownException.quiet == False
    assert _sanic_exceptions[999] == MyUnknownException

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:52.486354
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 501
    assert _sanic_exceptions[501] == MyException

    @add_status_code(502)
    class MyException2(SanicException):
        pass

    assert MyException2.status_code == 502
    assert _sanic_exceptions[502] == MyException2

    @add_status_code(503)
    class MyException3(SanicException):
        pass

    assert MyException3.status_code == 503
    assert _sanic_exceptions[503] == MyException3

    assert _sanic_exceptions[501] == MyException
    assert _sanic_exceptions[502] == MyException2

# Generated at 2022-06-12 08:48:56.060242
# Unit test for function add_status_code
def test_add_status_code():
    class SanicException1(SanicException):
        pass
    add_status_code(1000)(SanicException1)
    assert SanicException1.status_code == 1000
    assert SanicException1.quiet == True

    class SanicException2(SanicException):
        pass
    add_status_code(1001, quiet=False)(SanicException2)
    assert SanicException2.status_code == 1001
    assert SanicException2.quiet == False

    class SanicException3(SanicException):
        pass
    add_status_code(1002, quiet=True)(SanicException3)
    assert SanicException3.status_code == 1002
    assert SanicException3.quiet == True

# Generated at 2022-06-12 08:49:01.227966
# Unit test for function add_status_code
def test_add_status_code():
  """
  Test the add_status_code function.

  Create an object for each status code and test the object, including
  testing the mapping between the object and the status code.
  """

  @add_status_code(404)
  class X(Exception):
    """A test class."""
    pass

  x = X("Message")
  assert x.status_code == 404
  assert _sanic_exceptions.get(404) == X

# Generated at 2022-06-12 08:49:07.974677
# Unit test for function add_status_code
def test_add_status_code():
    arr = []

    @add_status_code(999)
    class TestException(SanicException):
        """
        **Status**: 999 Test Exception
        """

        pass

    arr.append(TestException.status_code)

    @add_status_code(999, True)
    class TestException2(SanicException):
        """
        **Status**: 999 Test Exception
        """

        pass

    assert 999 in _sanic_exceptions
    assert _sanic_exceptions[999] == TestException2
    arr.append(TestException2.status_code)
    arr.append(TestException2.quiet)

    @add_status_code(999)
    class TestException3(SanicException):
        """
        **Status**: 999 Test Exception
        """

        pass


# Generated at 2022-06-12 08:49:17.659760
# Unit test for function add_status_code
def test_add_status_code():
    def test_check(x, exp):
        assert _sanic_exceptions.get(x) == exp

    # call function add_status_code
    class_1 = add_status_code(999)(SanicException)
    class_2 = add_status_code(888, quiet=True)(SanicException)
    class_3 = add_status_code(777)(SanicException)
    class_4 = add_status_code(666, quiet=True)(SanicException)

    # test add_status_code
    test_check(999, SanicException)
    test_check(888, SanicException)
    test_check(777, SanicException)
    test_check(666, SanicException)



# Generated at 2022-06-12 08:49:22.554283
# Unit test for function add_status_code
def test_add_status_code():
    # Setup
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    code = 404
    class_decorator(NotFound)
    # Assertion
    assert _sanic_exceptions[code] == NotFound

# Generated at 2022-06-12 08:49:32.359119
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NoFoundException(SanicException):
        pass

    assert "NoFoundException" in _sanic_exceptions
    assert _sanic_exceptions[404].__name__ == "NoFoundException"
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet is True

    @add_status_code(500, quiet=False)
    class ServerErrorException(SanicException):
        pass

    assert "ServerErrorException" in _sanic_exceptions
    assert _sanic_exceptions[500].__name__ == "ServerErrorException"
    assert _sanic_exceptions[500].status_code == 500
    assert _sanic_exceptions[500].quiet is False



# Generated at 2022-06-12 08:49:39.184434
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass

    assert STATUS_CODES[999] == "Unknown Status Code"
    assert TestException.status_code == 999
    assert _sanic_exceptions[999] == TestException

    @add_status_code(998, quiet=True)
    class TestException2(SanicException):
        pass

    assert STATUS_CODES[998] == "Unknown Status Code"
    assert TestException2.status_code == 998
    assert TestException2.quiet == True
    assert _sanic_exceptions[998] == TestException2

    @add_status_code(997, quiet=False)
    class TestException3(SanicException):
        pass


# Generated at 2022-06-12 08:49:42.882381
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(505, quiet=True)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 505
    assert NewException.quiet is True



# Generated at 2022-06-12 08:49:49.316931
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(12345)
    class Foo(SanicException):
        pass

    assert Foo.status_code == 12345
    assert _sanic_exceptions[12345] is Foo
    assert Foo.quiet is None

    del _sanic_exceptions[12345]
    del Foo.status_code

    @add_status_code(54321, quiet=True)
    class Bar(SanicException):
        pass

    assert Bar.status_code == 54321
    assert _sanic_exceptions[54321] is Bar
    assert Bar.quiet is True

    del _sanic_exceptions[54321]
    del Bar.status_code

# Generated at 2022-06-12 08:50:14.738339
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(417)
    class MyTestException(SanicException):
        pass

    exception = MyTestException("Test")
    assert exception.status_code == 417

# Generated at 2022-06-12 08:50:16.935147
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(503)
    class Add503(SanicException):
        pass

    assert _sanic_exceptions[503] == Add503


# Generated at 2022-06-12 08:50:27.203800
# Unit test for function add_status_code
def test_add_status_code():
    class MyCustomException(SanicException):
        pass
    my_custom_exception = add_status_code(888)(MyCustomException)
    assert my_custom_exception.status_code == 888
    assert my_custom_exception.quiet == True
    customized_exception = _sanic_exceptions.get(888)
    assert customized_exception == MyCustomException

    class MyCustomException2(SanicException):
        pass
    my_custom_exception2 = add_status_code(500)(MyCustomException2)
    assert my_custom_exception2.status_code == 500
    assert my_custom_exception2.quiet == False
    customized_exception2 = _sanic_exceptions.get(500)
    assert customized_exception2 == MyCustomException2

# Generated at 2022-06-12 08:50:31.935427
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=unused-variable

    @add_status_code(400)  # had 404 in example code
    class NotFound(SanicException):
        pass

    assert NotFound.status_code == 400
    NotFound.status_code += 1
    assert NotFound.status_code == 401
    assert _sanic_exceptions[400] is NotFound

# Generated at 2022-06-12 08:50:34.349163
# Unit test for function add_status_code
def test_add_status_code():
    assert isinstance(NotFound(), SanicException)
    assert isinstance(ServerError(), SanicException)
    assert isinstance(ServiceUnavailable(), SanicException)

# Generated at 2022-06-12 08:50:40.962446
# Unit test for function add_status_code
def test_add_status_code():
    # test with 2 args
    @add_status_code(400)
    class A(SanicException):
        pass

    # test with 3 args
    @add_status_code(403, True)
    class B(SanicException):
        pass

    assert A.status_code == 400
    assert B.status_code == 403
    assert not A.quiet
    assert B.quiet
    assert isinstance(A(), SanicException)
    assert isinstance(B(), SanicException)

# Generated at 2022-06-12 08:50:51.554075
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyTestClass(SanicException):
        def __init__(self):
            pass

    assert _sanic_exceptions[200] == MyTestClass

    @add_status_code(201)
    class MyTestClass2(SanicException):
        def __init__(self):
            pass

    assert _sanic_exceptions[201] == MyTestClass2

    @add_status_code(500, quiet=True)
    class MyTestClass3(SanicException):
        def __init__(self):
            pass

    assert _sanic_exceptions[500] == MyTestClass3
    assert _sanic_exceptions[500]().quiet == True


# Generated at 2022-06-12 08:50:54.774171
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException().status_code == 200

# Generated at 2022-06-12 08:51:07.247906
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.helpers import STATUS_CODES
    from sanic import constants

    assert constants.SANIC_VERSION == "19.12.1"
    assert STATUS_CODES[418] == b"I'm a teapot"

    @add_status_code(418)
    class Teapot(SanicException):
        pass

    assert STATUS_CODES[418] == b"I'm a teapot"
    assert Teapot.status_code == 418
    assert Teapot.quiet == True
    assert Teapot("I'm a teapot").status_code == 418

    with pytest.raises(SanicException):
        abc = Teapot("I'm a teapot")


# Generated at 2022-06-12 08:51:16.096545
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass
    assert MyException(message="Awful request.").status_code == 400
    assert MyException(message="Awful request.", status_code=500).status_code == 500
    assert MyException(message="Awful request.", status_code=500).quiet == False
    assert MyException(message="Awful request.", status_code=403).quiet == False
    assert MyException(message="Awful request.", status_code=400).quiet == True
    assert MyException(message="Awful request.", status_code=400, quiet=False).quiet == False


# Generated at 2022-06-12 08:52:06.845156
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(200, quiet=True)(SanicException)
    assert _sanic_exceptions[200].__name__ == "SanicException"
    assert _sanic_exceptions[200].status_code == 200
    assert _sanic_exceptions[200].quiet is True



# Generated at 2022-06-12 08:52:09.696023
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert _sanic_exceptions[200] == TestException
    assert TestException().status_code == 200
    assert TestException().quiet == False

# Generated at 2022-06-12 08:52:12.102175
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class DummyException(SanicException):
        pass

    assert DummyException.status_code == 500
    assert 500 in _sanic_exceptions

# Generated at 2022-06-12 08:52:19.946229
# Unit test for function add_status_code
def test_add_status_code():
    '''
    add_status_code(code, quiet=None)

    Decorator used for adding exceptions to :class:`SanicException`.
    '''
    class_decorator = add_status_code(404)

    @add_status_code(404, quiet=True)
    class NotFound(SanicException):
        pass

    @class_decorator
    class NotFound(SanicException):
        pass

    assert str(NotFound) == '<class \'sanic.exceptions.NotFound\'>'
    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert _sanic_exceptions[404] == NotFound



# Generated at 2022-06-12 08:52:22.613029
# Unit test for function add_status_code
def test_add_status_code():
    # Given
    @add_status_code(400)
    class MyException(Exception):
        pass

    # When
    result = MyException("My Exception")

    # Then
    assert result.status_code == 400



# Generated at 2022-06-12 08:52:28.180619
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200].__name__ == 'TestException'
    assert _sanic_exceptions[200].status_code == 200
    assert _sanic_exceptions[200]().status_code == 200
    with pytest.raises(TestException) as exc:
        raise TestException('Unexpected error')
    assert 'Unexpected error' in str(exc)


# Generated at 2022-06-12 08:52:35.265948
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is False
    assert _sanic_exceptions[400] == TestException
    assert TestException.__name__ == "TestException"

# Generated at 2022-06-12 08:52:41.557335
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class SanicException200(SanicException):
        pass

    assert _sanic_exceptions[200] == SanicException200

    @add_status_code(400)
    class SanicException400(SanicException):
        pass
    assert _sanic_exceptions[400] == SanicException400

    @add_status_code(500)
    class SanicException500(SanicException):
        pass
    assert _sanic_exceptions[500] == SanicException500


# Generated at 2022-06-12 08:52:47.821146
# Unit test for function add_status_code
def test_add_status_code():

    # Decorator codes.
    @add_status_code(202)
    class Testing(SanicException):
        pass

    # Normal codes.
    class Testing2(SanicException):
        pass

    # Check that the codes have been added to the dictionary.
    assert _sanic_exceptions[202] == Testing
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions.get(300) is None

# Generated at 2022-06-12 08:52:48.880318
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class A(SanicException):
        pass
    assert A.status_code == A().status_code == 400