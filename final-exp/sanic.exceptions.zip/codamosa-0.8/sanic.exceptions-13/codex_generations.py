

# Generated at 2022-06-12 08:44:44.411253
# Unit test for function add_status_code
def test_add_status_code():
    class test_class:
        pass

    # Exception added to _sanic_exceptions
    assert add_status_code(999, False)(test_class).name in _sanic_exceptions

    # By default, quiet is set to True for 404 errors.
    assert _sanic_exceptions[404].quiet

    # Non-500 errors are set to quiet by default.
    assert add_status_code(555)(test_class).quiet

    # 500 errors are not set to quiet by default.
    assert not add_status_code(500)(test_class).quiet

    # Explicit quiet option overrides default.
    assert add_status_code(500, True)(test_class).quiet

# Generated at 2022-06-12 08:44:46.534509
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[500] == MyException

# Generated at 2022-06-12 08:44:53.900248
# Unit test for function add_status_code
def test_add_status_code():
  code = 500
  code_str = "Exception"
  code_object = {'code': code, 'code_str': code_str}

  def class_decorator(cls):
    cls.status_code = code
    cls.quiet = True
    return cls

  def test_add_status_code_callable(code):
    return class_decorator

  def test_add_status_code_mapping(code):
    return code_object

  test_add_status_code_callable(code)
  test_add_status_code_mapping(code)

  assert (_sanic_exceptions[code] == code_object)

# Generated at 2022-06-12 08:45:05.283172
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(400)(InvalidUsage)
    add_status_code(404)(NotFound)
    add_status_code(500)(ServerError)
    add_status_code(503)(ServiceUnavailable)
    add_status_code(408)(RequestTimeout)
    add_status_code(413)(PayloadTooLarge)
    add_status_code(416)(ContentRangeError)
    add_status_code(417)(HeaderExpectationFailed)
    add_status_code(403)(Forbidden)
    add_status_code(401)(Unauthorized)
    add_status_code(405)(MethodNotSupported)
    add_status_code(200)(MethodNotSupported)



# Generated at 2022-06-12 08:45:08.851862
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class TestException(SanicException):
        pass
    
    assert TestException.status_code == 1
    assert TestException.quiet == True
    
if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:45:15.156029
# Unit test for function add_status_code
def test_add_status_code():
    messages = {}
    for status_code in STATUS_CODES:
        messages[status_code] = STATUS_CODES[status_code].decode("utf8")
        
    for status_code in _sanic_exceptions:
        assert isinstance(_sanic_exceptions[status_code](), SanicException)

        exception = _sanic_exceptions[status_code](message=messages[status_code],status_code=status_code)
        assert exception.args[0] == messages[status_code]
        assert exception.status_code == status_code
        assert exception.message == messages[status_code]

        exception = _sanic_exceptions[status_code](message="Sanic exception test")
        assert exception.message == "Sanic exception test"
        assert exception.status_code == status

# Generated at 2022-06-12 08:45:17.863712
# Unit test for function add_status_code
def test_add_status_code():
    try:
        abort(400)
    except Exception as e:
        if e.status_code != 400:
            raise Exception("Status code is not expected")
    else:
        raise Exception("Status code is not expected")



# Generated at 2022-06-12 08:45:29.037581
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        """Test"""
        
        pass

    assert Test.status_code == 200
    assert Test.quiet is True
    assert isinstance(_sanic_exceptions[200], Test)

    # Test quiet=None
    @add_status_code(200, quiet=None)
    class Test(SanicException):
        """Test"""
        
        pass

    assert Test.status_code == 200
    assert Test.quiet is True
    assert isinstance(_sanic_exceptions[200], Test)

    # Test quiet=True
    @add_status_code(200, quiet=True)
    class Test(SanicException):
        """Test"""
        
        pass

    assert Test.status_code == 200
    assert Test.quiet is True
   

# Generated at 2022-06-12 08:45:32.884793
# Unit test for function add_status_code
def test_add_status_code():
    class MySanicException(SanicException):
        pass

    assert hasattr(MySanicException, "status_code") is False

    MySanicException = add_status_code(400)(MySanicException)

    assert hasattr(MySanicException, "status_code") is True
    assert MySanicException.status_code == 400

# Generated at 2022-06-12 08:45:37.194191
# Unit test for function add_status_code
def test_add_status_code():
    # Testing case for non existing status code
    class InvalidCode(SanicException):
        pass

    with pytest.raises(ValueError):
        add_status_code(-1)(InvalidCode)

    @add_status_code(100)
    class Code100(SanicException):
        pass

    assert Code100.status_code == 100



# Generated at 2022-06-12 08:45:44.770084
# Unit test for function add_status_code
def test_add_status_code():
    """ 
    Test add_status_code function for status_code 500.
    """
    @add_status_code(500, True)
    class TestClass(SanicException):
        pass
    assert _sanic_exceptions[500].status_code == 500

# Generated at 2022-06-12 08:45:55.800863
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class Exception123(Exception):
        pass

    assert _sanic_exceptions[123] is Exception123

    @add_status_code(456)
    class Exception456(Exception):
        # Don't set quiet
        pass

    assert _sanic_exceptions[456] is Exception456
    assert not hasattr(_sanic_exceptions[456], "quiet")

    @add_status_code(789)
    class Exception789Quiet(Exception):
        # Quiet is explicitly set to False
        quiet = False

    assert _sanic_exceptions[789] is Exception789Quiet
    assert not getattr(_sanic_exceptions[789], "quiet", False)


# Generated at 2022-06-12 08:46:04.367160
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Test100(SanicException):
        pass

    assert _sanic_exceptions[100] == Test100

    @add_status_code(101, True)
    class Test101(SanicException):
        pass

    assert _sanic_exceptions[101] == Test101

    @add_status_code(102)
    class Test102(SanicException):
        pass

    assert _sanic_exceptions[102] == Test102
    assert not hasattr(_sanic_exceptions[102], "quiet")


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:46:09.799464
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class CustomException(SanicException):
        pass
    assert CustomException.status_code == 999
    error = CustomException("CustomException", status_code=999, quiet=False)
    assert error.status_code == 999
    assert error.quiet is True
    assert error.message == "CustomException"
    assert _sanic_exceptions[999] == CustomException

# Generated at 2022-06-12 08:46:14.804856
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(400)(NotFound)
    assert NotFound.status_code == 400
    assert NotFound.quiet == True
    assert NotFound().status_code == 400
    assert NotFound().quiet == True

    add_status_code(500, quiet=True)(NotFound)
    assert NotFound.status_code == 500
    assert NotFound.quiet == True
    assert NotFound().status_code == 500
    assert NotFound().quiet == True

# Generated at 2022-06-12 08:46:25.020077
# Unit test for function add_status_code
def test_add_status_code():
    from sanic.helpers import STATUS_CODES

    @add_status_code(404)
    class Empty(SanicException):
        pass

    @add_status_code(400)
    class Empty2(SanicException):
        pass

    @add_status_code(500)
    class Empty3(SanicException):
        pass

    assert _sanic_exceptions[404] is Empty
    assert _sanic_exceptions[400] is Empty2
    assert _sanic_exceptions[500] is Empty3

    assert STATUS_CODES[403] == b"Forbidden"

    class Test(SanicException):
        pass

    new_exception = add_status_code(403)(Test)

    assert new_exception is Test
    assert _sanic_exceptions[403] is Test

# Generated at 2022-06-12 08:46:25.623828
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(500)

# Generated at 2022-06-12 08:46:31.186920
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    add_to_sanic = add_status_code(404)
    exc = add_to_sanic(TestException)
    assert id(exc) == id(TestException)
    assert exc.status_code == 404
    exc = add_to_sanic(TestException)
    assert id(exc) == id(TestException)



# Generated at 2022-06-12 08:46:34.844316
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[404]().status_code == 404



# Generated at 2022-06-12 08:46:42.093138
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class test1(SanicException):
        pass
    assert test1.quiet == True
    assert test1.status_code == 200
    @add_status_code(404, False)
    class test2(SanicException):
        pass
    assert test2.quiet == False
    assert test2.status_code == 404
    @add_status_code(500)
    class test3(SanicException):
        pass
    assert test3.quiet == False
    assert test3.status_code == 500

# Generated at 2022-06-12 08:46:53.024043
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[404] is MyException
    assert issubclass(MyException, SanicException)

    try:
        raise MyException(b'abc')
        assert False, 'Expected exception'
    except MyException as e:
        assert e.status_code == 404
        assert e.message == 'abc'
        assert str(e) == 'abc'


# Generated at 2022-06-12 08:46:56.771736
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(409)
    class Conflict(SanicException):
        """
        **Status**: 409 Conflict
        """

        pass
    assert _sanic_exceptions.get(409) is Conflict
    assert _sanic_exceptions.get(409)("msg").status_code == 409

# Generated at 2022-06-12 08:47:03.789139
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(209, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[209] == TestException
    assert hasattr(_sanic_exceptions[209], 'status_code')
    assert hasattr(_sanic_exceptions[209], 'quiet')
    assert getattr(_sanic_exceptions[209], 'status_code') == 209
    assert getattr(_sanic_exceptions[209], 'quiet') == True


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:15.446981
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class test_exception_200(SanicException):
        pass
    assert test_exception_200.status_code == 200
    assert test_exception_200.quiet is False
    _sanic_exceptions[200] = test_exception_200

    @add_status_code(201)
    class test_exception_201(SanicException):
        pass
    assert test_exception_201.status_code == 201
    assert test_exception_201.quiet is False
    _sanic_exceptions[201] = test_exception_201

    @add_status_code(500, quiet=True)
    class test_exception_500(SanicException):
        pass
    assert test_exception_500.status_code == 500
    assert test_

# Generated at 2022-06-12 08:47:23.652497
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(420)
    class EnhanceYourCalm(SanicException):
        pass

    assert EnhanceYourCalm.status_code == 420
    assert EnhanceYourCalm('').status_code == 420
    assert EnhanceYourCalm('', status_code=403).status_code == 403
    assert EnhanceYourCalm.quiet is False
    assert EnhanceYourCalm('', quiet=True).quiet is True
    assert (EnhanceYourCalm('', status_code=404).quiet is
            EnhanceYourCalm.quiet is
            NotFound.quiet is True)
    assert EnhanceYourCalm.__name__ == 'EnhanceYourCalm'
    assert EnhanceYourCalm('message').__class__ == EnhanceYourCalm

    # I'll only test this one
    assert InvalidUsage.status_code == 400
    assert InvalidUsage

# Generated at 2022-06-12 08:47:27.616414
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    add_status_code(404)(TestException)
    assert hasattr(TestException, "status_code")
    assert TestException.status_code == 404
    assert _sanic_exceptions[404] == TestException



# Generated at 2022-06-12 08:47:31.450920
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException(SanicException):
        pass

    code = 100
    test_exception = TestException("error", code)
    assert (_sanic_exceptions[code] == TestException)
    assert (test_exception.status_code == code)
    assert (str(test_exception) == "error")

# Generated at 2022-06-12 08:47:37.475477
# Unit test for function add_status_code
def test_add_status_code():
    class TestNotFound(SanicException):
        pass
    add_status_code(404)(TestNotFound)
    assert _sanic_exceptions[404] == TestNotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable

# Generated at 2022-06-12 08:47:42.669334
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class MyException(SanicException): pass

    @add_status_code(101, quiet=True)
    class MyException2(SanicException): pass

    assert _sanic_exceptions[100] is MyException
    assert _sanic_exceptions[101] is MyException2



# Generated at 2022-06-12 08:47:53.177535
# Unit test for function add_status_code
def test_add_status_code():
    # add a sanic exception with a specific status code
    @add_status_code(203)
    class MyException(SanicException):
        pass

    # raise that exception
    MyException("test message", status_code=201)

    assert MyException.status_code == 201

    # raise that exception without status code
    MyException("test message")

    assert MyException.status_code == 203

    # raise that exception again with a different status code
    # but with quiet=True to avoid that status code is set again
    MyException("test message", status_code=202, quiet=True)

    assert MyException.status_code == 203

    # raise that exception again with a different status code
    # but with quiet=None to let status code be overwritten
    MyException("test message", status_code=202, quiet=None)

   

# Generated at 2022-06-12 08:48:03.771912
# Unit test for function add_status_code
def test_add_status_code():
    class Test(SanicException):
        pass

    add_status_code(500)(Test)
    assert Test.status_code == 500

# Generated at 2022-06-12 08:48:11.396834
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass

    A = add_status_code(400)(A)
    assert A.status_code == 400

    class A(SanicException):
        pass

    A = add_status_code(408)(A)
    assert A.status_code == 408
    assert A.quiet == True

    class A(SanicException):
        pass

    A = add_status_code(213, True)(A)
    assert A.status_code == 213
    assert A.quiet == True



# Generated at 2022-06-12 08:48:12.678212
# Unit test for function add_status_code
def test_add_status_code():
    # Test of the add_status_code decorator 
    @add_status_code(404)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 404
    assert TestClass.quiet == True

# Generated at 2022-06-12 08:48:22.993318
# Unit test for function add_status_code
def test_add_status_code():
    # test is normally done inside of SanicException but is
    # a bit convoluted to test in the unit tests.
    def test_exception():
        pass

    add_status_code(300)(test_exception)
    assert test_exception.status_code == 300

    add_status_code(300, quiet=True)(test_exception)
    assert test_exception.status_code == 300
    assert test_exception.quiet

    add_status_code(300, quiet=False)(test_exception)
    assert test_exception.status_code == 300
    assert not test_exception.quiet

    add_status_code(300, quiet=None)(test_exception)
    assert test_exception.status_code == 300
    assert not test_exception.quiet


# Generated at 2022-06-12 08:48:24.600427
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] is NotFound

# Generated at 2022-06-12 08:48:28.788842
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyStatusCode(SanicException):
        pass

    assert MyStatusCode.status_code == 200
    assert MyStatusCode().status_code == 200
    assert isinstance(MyStatusCode().status_code, int)



# Generated at 2022-06-12 08:48:31.147632
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class TestException(Exception):
        pass
    
    TestException() == ("test")
    
    
    
    

# Generated at 2022-06-12 08:48:36.297016
# Unit test for function add_status_code
def test_add_status_code():
    # test params with status_code 200
    add_status_code(200)
    # quiet=True
    add_status_code(201, True)
    # quiet=False
    add_status_code(202, False)
    # quiet=None
    add_status_code(203, None)

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:48:43.243971
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class Foo(SanicException):
        pass
    assert Foo.status_code == 1
    assert Foo.quiet == True

    @add_status_code(1, quiet=False)
    class Foo(SanicException):
        pass
    assert Foo.status_code == 1
    assert Foo.quiet == False

    @add_status_code(1, quiet=True)
    class Foo(SanicException):
        pass
    assert Foo.status_code == 1
    assert Foo.quiet == True

# Generated at 2022-06-12 08:48:47.354952
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 200

    @add_status_code(status_code)
    class NewException(SanicException):
        pass

    assert status_code in _sanic_exceptions
    assert _sanic_exceptions[status_code] is NewException
    assert status_code == NewException.status_code

# Generated at 2022-06-12 08:49:06.772974
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400

    myexception = MyException("test", quiet=True)
    assert myexception.status_code == 400



# Generated at 2022-06-12 08:49:12.547802
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    
    add_status_code(200, True)(MyException)
    _sanic_exceptions[200]
    try:
        raise _sanic_exceptions[200]("error")
    except SanicException as e:
        assert e.status_code == 200
        assert e.quiet == True
        assert e.message == "error"

# Generated at 2022-06-12 08:49:20.344919
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class InvalidUsage1(SanicException):
        pass

    assert _sanic_exceptions[400] == InvalidUsage1

    @add_status_code(500)
    class ServerError1(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError1

    @add_status_code(500, quiet=False)
    class ServerError2(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError2
    assert not ServerError1.quiet
    assert not ServerError2.quiet

# Generated at 2022-06-12 08:49:24.110851
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class HttpCode200(SanicException):
        pass
    assert HttpCode200.status_code == 200

    @add_status_code(200, True)
    class HttpCode200(SanicException):
        pass
    assert HttpCode200.status_code == 200


# Generated at 2022-06-12 08:49:29.453800
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class NewStatusError(SanicException):
        pass

    @add_status_code(400, quiet=True)
    class NewStatusError1(SanicException):
        pass
    new_status = NewStatusError("test message")
    assert new_status.status_code == 400
    assert new_status.quiet == True
    new_status1 = NewStatusError1("test message")
    assert new_status1.status_code == 400
    assert new_status1.quiet == True

# Generated at 2022-06-12 08:49:37.558065
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(666)
    class TestClass(SanicException):
        pass

    class TestClass2(SanicException):
        pass
    add_status_code(667)(TestClass2)

    assert TestClass.status_code == 666
    assert TestClass.quiet == False
    assert TestClass2.status_code == 667
    assert TestClass2.quiet == True

    # Class instance
    tc = TestClass('test')
    assert tc.status_code == 666
    assert tc.quiet == False

    # Class instance
    tc2 = TestClass2('test')
    assert tc2.status_code == 667
    assert tc2.quiet == True

    # Exception instance
    try:
        raise SanicException('test', status_code=668)
    except Exception as ex:
        exc = ex

# Generated at 2022-06-12 08:49:43.655124
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """
        pass

    assert isinstance(_sanic_exceptions[404], NotFound)
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet == True



# Generated at 2022-06-12 08:49:48.209684
# Unit test for function add_status_code
def test_add_status_code():
    code = 400
    quiet = False
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    class Test(SanicException):
        pass
    class_decorator(Test)
    assert _sanic_exceptions[code] == Test

# Generated at 2022-06-12 08:49:54.355039
# Unit test for function add_status_code
def test_add_status_code():
    def add_200(cls):
        cls.status_code = 200
        return cls
    @add_200
    class NoStatusCode(SanicException):
        pass
    assert NoStatusCode.status_code == 200

    @add_status_code(201)
    class Created(SanicException):
        pass
    assert Created.status_code == 201

# Generated at 2022-06-12 08:49:57.021245
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(421)
    class MockException(SanicException):
        pass

    mocked = MockException(message="this is mocked")

    assert mocked.status_code == 421
    assert mocked.quiet is True

# Generated at 2022-06-12 08:50:33.072190
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class TestException(SanicException):
        message = "test"

    assert isinstance(_sanic_exceptions[401], type(TestException))

# Generated at 2022-06-12 08:50:41.420831
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] is NotFound
    assert _sanic_exceptions[404].quiet is True
    assert _sanic_exceptions[400] is InvalidUsage
    assert _sanic_exceptions[400].quiet is True
    assert _sanic_exceptions[405] is MethodNotSupported
    assert _sanic_exceptions[405].quiet is True
    assert _sanic_exceptions[500] is ServerError
    assert _sanic_exceptions[500].quiet is False
    assert _sanic_exceptions[503] is ServiceUnavailable
    assert _sanic_exceptions[503].quiet is True

# Generated at 2022-06-12 08:50:45.060414
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class SanicException(Exception):
        pass
    sanicexception = SanicException("test")
    assert sanicexception.status_code == 500
    assert sanicexception.message == "test"

# Generated at 2022-06-12 08:50:47.766445
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyStatusCode(SanicException):
        pass

    assert _sanic_exceptions[200] == MyStatusCode

# Generated at 2022-06-12 08:50:51.031002
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Created(SanicException):
        message='excpetion message'

    exception = Created("message")
    assert exception.status_code == 400


# Generated at 2022-06-12 08:50:59.236290
# Unit test for function add_status_code
def test_add_status_code():
    # can not use assertRaises here, so use try except
    try:
        class SanicException300(Exception):
            pass
        add_status_code(300)(SanicException300)
    except KeyError:
        assert True

    try:
        class SanicException999(Exception):
            pass
        add_status_code(999)(SanicException999)
    except KeyError:
        assert True

    try:
        class SanicException200(Exception):
            pass
        add_status_code(200)(SanicException200)
    except KeyError:
        assert True

# Generated at 2022-06-12 08:51:03.960012
# Unit test for function add_status_code
def test_add_status_code():
    def class_decorator(cls):
        cls.status_code = 404
        cls.quiet = True
        _sanic_exceptions[404] = cls
        return cls

    assert add_status_code(404, quiet=True) is class_decorator

# Generated at 2022-06-12 08:51:12.984539
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class TestingException(Exception):
        pass

    assert TestingException.status_code == 101
    assert isinstance(TestingException(), TestingException)
    assert _sanic_exceptions[101] == TestingException
    assert _sanic_exceptions[404] == NotFound

    @add_status_code(102, quiet=True)
    class TestingException(Exception):
        pass

    assert TestingException.status_code == 102
    assert TestingException.quiet is True
    assert _sanic_exceptions[102] == TestingException


# Generated at 2022-06-12 08:51:16.824186
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable


# Generated at 2022-06-12 08:51:23.771692
# Unit test for function add_status_code
def test_add_status_code():
    assert NotFound.status_code == 404
    assert InvalidUsage.status_code == 400
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503
    assert URLBuildError.status_code == 500
    assert FileNotFound.status_code == 404
    assert RequestTimeout.status_code == 408
    assert PayloadTooLarge.status_code == 413

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-12 08:52:46.626269
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(SanicException).status_code == 404
    assert add_status_code(404)(SanicException).quiet == True
    assert add_status_code(404)(SanicException).__name__ == "SanicException"

    assert add_status_code(404)(SanicException).__qualname__ == "SanicException"
    assert add_status_code(404)(SanicException).__module__ == SanicException.__module__
    assert add_status_code(404)(SanicException).__doc__ == SanicException.__doc__
    assert add_status_code(404)(SanicException).__classcell__ == SanicException.__classcell__
    assert add_status_code(404)(SanicException).__dict__ == SanicException.__dict__
    assert add_status_

# Generated at 2022-06-12 08:52:47.822479
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(302)(SanicException) is SanicException

# Generated at 2022-06-12 08:52:51.240727
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException(Exception):
        pass
    assert _sanic_exceptions[100] == TestException


if __name__ == "__main__":
    try:
        abort(500)
    except BaseException as e:
        print(e.status_code)
        print(e.message)

# Generated at 2022-06-12 08:52:53.767217
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 201
    assert TestClass.quiet is None



# Generated at 2022-06-12 08:52:59.023396
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == False
    assert 400 in _sanic_exceptions

    @add_status_code(404, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.quiet == True



# Generated at 2022-06-12 08:53:06.219219
# Unit test for function add_status_code
def test_add_status_code():
    class Test(SanicException):
        pass
    assert Test.status_code is None
    add_status_code(200)(Test)
    assert Test.status_code == 200
    assert _sanic_exceptions[200] == Test

    class TestQuiet(SanicException):
        pass
    add_status_code(200)(TestQuiet)
    assert TestQuiet.quiet is False # default
    add_status_code(200, quiet=True)(TestQuiet)
    assert TestQuiet.quiet is True

# Generated at 2022-06-12 08:53:09.166330
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class _500(Exception):
        pass

    assert len(_sanic_exceptions) == 7
    assert _sanic_exceptions[500] == _500

# Generated at 2022-06-12 08:53:12.479346
# Unit test for function add_status_code
def test_add_status_code():
    test_code = 420
    try:
        raise _sanic_exceptions[test_code]("test")
    except _sanic_exceptions[test_code]:
        pass
    else:
        assert False, "Status code was not added to SanicException"

# Generated at 2022-06-12 08:53:15.937737
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert isinstance(_sanic_exceptions[400], MyException)
    assert _sanic_exceptions[400]().status_code == 400
    assert MyException('').status_code == 400
    assert MyException('').quiet is not False

# Generated at 2022-06-12 08:53:18.916767
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test for function add_status_code
    :return:
    """
    add_status_code(status_code=202)(SanicException)
    assert 202 in _sanic_exceptions

