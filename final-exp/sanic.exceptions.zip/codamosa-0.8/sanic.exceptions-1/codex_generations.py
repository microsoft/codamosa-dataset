

# Generated at 2022-06-12 08:44:34.014485
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    add_status_code(200, quiet=True)
    assert 200 in _sanic_exceptions

    add_status_code(201)(TestClass)
    assert 201 in _sanic_exceptions



# Generated at 2022-06-12 08:44:39.695116
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # check that the "realm" keyword is required in a Basic auth-scheme
    try:
        raise Unauthorized("Auth required.", scheme="Basic")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Default realm"'}

    # check that the realm keyword is optional in a Bearer auth-scheme
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": 'Bearer'}

    # check that the realm keyword is optional in a Bearer auth-scheme

# Generated at 2022-06-12 08:44:43.741631
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class TestClass(SanicException):
        pass
    test_instance = TestClass()
    assert test_instance.status_code == 1
    assert _sanic_exceptions[1] == TestClass


# Generated at 2022-06-12 08:44:52.763882
# Unit test for function add_status_code
def test_add_status_code():
    class Exception500(SanicException):
        pass

    test_exception_500 = add_status_code(500)(Exception500)
    assert test_exception_500.status_code == 500
    assert not test_exception_500.quiet
    assert _sanic_exceptions[500] == test_exception_500

    test_exception_404 = add_status_code(404)(Exception500)
    assert test_exception_404.status_code == 404
    assert test_exception_404.quiet

    class Exception503(SanicException):
        pass

    test_exception_503 = add_status_code(503, quiet=True)(Exception503)
    assert test_exception_503.status_code == 503
    assert test_exception_503.quiet
    assert _sanic_exceptions[503]

# Generated at 2022-06-12 08:44:58.437639
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    add_status_code(400)(MyException)
    assert MyException.status_code == 400
    assert MyException.quiet == True
    add_status_code(500, quiet=False)(MyException)
    assert MyException.status_code == 500
    assert MyException.quiet == False

# Generated at 2022-06-12 08:45:02.837355
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, quiet=True)
    class NewError(SanicException):
        pass

    assert NewError.quiet
    assert NewError.status_code == 201
    assert _sanic_exceptions[201] is NewError

# Generated at 2022-06-12 08:45:06.790440
# Unit test for function add_status_code
def test_add_status_code():
    # Error case
    try:
        add_status_code(code=500)
    except Exception as ex:
        assert "add_status_code only works on classes" == str(ex)


# Generated at 2022-06-12 08:45:13.008186
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Bearer",
            realm="Restricted Area",
        )
    except Unauthorized as e:
        assert (
            f"{e}"
            == "Unauthorized: Auth required.\nStatus Code: 401\nHeaders: {{'WWW-Authenticate': 'Bearer realm=\"Restricted Area\"'}}"
        )

# Generated at 2022-06-12 08:45:19.467219
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area",
                 qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    Unauthorized("Auth required.", scheme="Bearer")
    Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

if __name__ == "__main__":
    test_Unauthorized()

# Generated at 2022-06-12 08:45:23.119195
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class OK(SanicException):
        pass

    assert _sanic_exceptions[200] == OK
    assert OK.status_code == 200
    assert _sanic_exceptions[200]() is not None

# Generated at 2022-06-12 08:45:29.910043
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions.get(403) is TestException

# Generated at 2022-06-12 08:45:34.709377
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass
    add_status_code(201, quiet=False)(MyException)
    assert MyException().status_code == 201
    assert MyException().quiet == False

    class YourException(SanicException):
        pass

    add_status_code(202)(YourException)
    assert YourException().status_code == 202
    assert YourException().quiet == True

# Generated at 2022-06-12 08:45:43.555658
# Unit test for function add_status_code
def test_add_status_code():
    dec_f = add_status_code(999)
    class TestClass(SanicException):
        pass
    test_obj = dec_f(TestClass)
    test_case = 'status code is not 999'
    assert test_obj.status_code == 999, test_case
    test_case = 'quiet is not false'
    assert test_obj.quiet == False, test_case
    test_case = 'status code 999 missing in _sanic_exceptions'
    assert _sanic_exceptions[999] == TestClass, test_case


# Generated at 2022-06-12 08:45:45.367418
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[400] == MyException



# Generated at 2022-06-12 08:45:56.816888
# Unit test for function add_status_code
def test_add_status_code():
    # Test if the add_status_code is working as expected
    @add_status_code(200)
    class IgnoreException(Exception):
        pass
    assert '200' in _sanic_exceptions
    assert _sanic_exceptions['200'] is IgnoreException

    # Test if the add_status_code is working as expected
    @add_status_code(405, quiet=True)
    class IgnoreException(Exception):
        pass
    assert '405' in _sanic_exceptions
    assert _sanic_exceptions['405'] is IgnoreException

    # Test if the add_status_code is working as expected
    @add_status_code(500, quiet=False)
    class IgnoreException(Exception):
        pass
    assert '500' in _sanic_exceptions
    assert _sanic_exceptions['500']

# Generated at 2022-06-12 08:46:05.237753
# Unit test for function add_status_code
def test_add_status_code():
    # without quiet
    class NewSanicException(SanicException):
        pass
    add_status_code(404)(NewSanicException)

    assert _sanic_exceptions[404] == NewSanicException
    assert NewSanicException.status_code == 404
    assert NewSanicException.quiet == False

    # with quiet
    class NewQuietException(SanicException):
        pass
    add_status_code(404, quiet=True)(NewQuietException)

    assert _sanic_exceptions[404] == NewQuietException
    assert NewQuietException.status_code == 404
    assert NewQuietException.quiet == True

# Generated at 2022-06-12 08:46:08.457768
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=400, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet is True

# Generated at 2022-06-12 08:46:09.700117
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418, True)
    class IAmATeaPot(SanicException):
        pass
    assert IAmATeaPot('').status_code == 418

# Generated at 2022-06-12 08:46:12.235158
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400, quiet=True)
    class CustomException(SanicException):
        pass

    try:
        raise CustomException('my message')
    except CustomException as e:
        assert e.status_code == 400
        assert e.message == 'my message'

# Generated at 2022-06-12 08:46:21.068736
# Unit test for function add_status_code
def test_add_status_code():
    """
    The decorator method add_status_code is to be used to assign a status
    code to a subclass of SanicException. The decorator updates the
    _sanic_exceptions dictionary with the status code as key and the
    class name as value, so that the exception may be raised with a
    simple call to abort(status_code). This testing method checks that
    the _sanic_exceptions dictionary is correctly updated for each
    status code.
    """
    # Define a list of status codes to test
    status_code = [300, 400, 404, 500]
    # Define a list of class that extend SanicException
    se = ['Redirection', 'InvalidUsage', 'NotFound', 'ServerError']

# Generated at 2022-06-12 08:46:30.919492
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    class NotFound(SanicException):
        pass

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    @add_status_code(404, True)
    class BadRequest(SanicException):
        pass

    try:
        raise TestException("This is an exception")
    except TestException as e:
        assert e.status_code is None
        assert e.quiet is None

    try:
        raise NotFound("Page not found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.quiet is True

    try:
        raise ServerError("Something went wrong")
    except ServerError as e:
        assert e.status_code == 500
        assert e.quiet is False


# Generated at 2022-06-12 08:46:39.535846
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(402)
    class PaymentRequired(SanicException):
        """
        ** Status ** : 402 Payment required
        """

    # Assert PaymentRequired has been added to _sanic_exceptions dict
    assert PaymentRequired.status_code == 402
    assert _sanic_exceptions.get(402) == PaymentRequired

    # Assert the function add_status_code correctly decide when to set the
    # quiet attribute to True
    @add_status_code(403, True)
    class Forbidden(SanicException):
        """
        ** Status ** : 403 Forbidden
        """

    assert Forbidden.status_code == 403
    assert Forbidden.quiet

    @add_status_code(501)
    class NotImplemented(SanicException):
        """
        ** Status ** : 501 Not Implemented
        """



# Generated at 2022-06-12 08:46:51.218910
# Unit test for function add_status_code
def test_add_status_code():
    assert 400 in _sanic_exceptions
    assert 500 in _sanic_exceptions
    assert 503 in _sanic_exceptions
    assert 404 in _sanic_exceptions
    assert 405 in _sanic_exceptions
    assert 408 in _sanic_exceptions
    assert 413 in _sanic_exceptions
    assert 416 in _sanic_exceptions
    assert 417 in _sanic_exceptions
    assert 403 in _sanic_exceptions
    assert 401 in _sanic_exceptions

    # Testing the exceptions
    # Exceptions with status code 400
    try:
        raise InvalidUsage("Testing")
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Testing"

    # Exceptions with status code 500

# Generated at 2022-06-12 08:46:59.761487
# Unit test for function add_status_code
def test_add_status_code():
    """
    tests the functionality of the add_status_code decorator.  Defines a class
    and registers it as a new status code, then checks that the decorator has
    initialized the effort correctly.
    """
    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[500] is MyException
    exception = MyException('message', None, True)
    assert exception.status_code == 500
    assert exception.quiet is True

    @add_status_code(503)
    class MyException(SanicException):
        pass

    assert _sanic_exceptions[503] is MyException
    exception = MyException('message', None, False)
    assert exception.status_code == 503
    assert exception.quiet is False

# Generated at 2022-06-12 08:47:11.627806
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        def __init__(self, message=None, test_variable=None):
            super().__init__(message)
            self.test_variable = test_variable

    class UnitTestSanicException(unittest.TestCase):
        def test_exception_raises(self):
            """
            To test that when we raise the custom exception, sanic
            handles it as having the status_code of HTTP 400.
            """
            with self.assertRaises(TestException) as context:
                raise TestException("Test message")

            self.assertEqual(context.exception.message, "Test message")
            self.assertEqual(context.exception.status_code, 400)


# Generated at 2022-06-12 08:47:16.938875
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestCls:
        pass

    status_code = TestCls.status_code
    sanic_except = _sanic_exceptions[404]
    assert status_code == 404
    assert TestCls == sanic_except

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:47:21.733623
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=1)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[1] is MyException
    # add_status_code(status_code: int, quiet: bool = None)
    @add_status_code(code=2, quiet=True)
    class MyException2(SanicException):
        pass
    assert _sanic_exceptions[2] is MyException2

# Generated at 2022-06-12 08:47:27.129187
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass
    
    assert MyException.status_code == 400
    assert MyException().status_code == 400

    @add_status_code(400, quiet=True)
    class MyException(SanicException):
        pass
    
    assert MyException.status_code == 400
    assert MyException().status_code == 400
    assert MyException().quiet == True
    
    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass
    
    assert MyException.status_code == 500
    assert MyException().status_code == 500
    assert MyException().quiet == False
    
    @add_status_code(500)
    class MyException(SanicException):
        pass
    

# Generated at 2022-06-12 08:47:30.011504
# Unit test for function add_status_code
def test_add_status_code():
    test_class = add_status_code(101)(SanicException)
    instance = test_class(message="Testing add_status_code")
    assert instance.status_code == 101
    assert isinstance(instance, SanicException)


# Generated at 2022-06-12 08:47:36.767527
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test add_status_code function
    """
    @add_status_code(200)
    class OK(SanicException):
        pass

    assert OK.status_code == 200
    assert _sanic_exceptions[200] == OK

    @add_status_code(500, quiet=True)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet is True
    assert _sanic_exceptions[500] == InternalServerError

# Generated at 2022-06-12 08:47:55.875980
# Unit test for function add_status_code
def test_add_status_code():
    class _SanicException(SanicException):
        pass

    assert _SanicException.status_code is None

    # If an exception status code is not in _sanic_exceptions,
    # the exception inherits from SanicException
    add_status_code(404)(_SanicException)
    assert _SanicException.status_code == 404
    assert issubclass(_SanicException, SanicException)

    # If the status code is 500, the exception inherits from SanicException
    add_status_code(500)(_SanicException)
    assert _SanicException.status_code == 500
    assert issubclass(_SanicException, SanicException)

    # If the status code is in _sanic_exceptions,
    # the exception inherits from the corresponding exception

# Generated at 2022-06-12 08:48:06.525896
# Unit test for function add_status_code
def test_add_status_code():
    # Add 500 to _sanic_exceptions without raising Exception
    add_status_code(500)(SanicException)
    # Raise Exception cause 500 already existed in _sanic_exceptions
    with pytest.raises(ValueError) as excinfo:
        add_status_code(500)(SanicException)
    assert "Status code 500 already registered" in str(excinfo.value)
    # Add 502 to _sanic_exceptions with raising Exception
    add_status_code(502)(SanicException)
    # Raise Exception cause 502 already existed in _sanic_exceptions
    with pytest.raises(ValueError) as excinfo:
        add_status_code(502)(SanicException)
    assert "Status code 502 already registered" in str(excinfo.value)
    # Add 401 to _sanic_exceptions which should

# Generated at 2022-06-12 08:48:14.056874
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(400)
    assert add_status_code(405)
    assert add_status_code(503)
    assert add_status_code(500)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(416)
    assert add_status_code(417)
    assert add_status_code(403)
    assert add_status_code(401)



# Generated at 2022-06-12 08:48:24.010862
# Unit test for function add_status_code
def test_add_status_code():
    class test_class(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)
            self.status_code = status_code


    class test_class_1(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)
            self.status_code = status_code

    test_class = add_status_code(202)(test_class)
    assert test_class.status_code == 202
    assert test_class.__doc__ == """
    **Status**: 202 Accepted
    """
    test_class_1 = add_status_code(302)(test_class_1)
    assert test_class_1.status_code == 302


# Generated at 2022-06-12 08:48:26.300027
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions.get(404).status_code==404

# Generated at 2022-06-12 08:48:36.433627
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(299)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 299
    assert MyException.quiet == True
    assert _sanic_exceptions[299] == MyException

    @add_status_code(500)
    class MyExceptionNoQuiet(SanicException):
        pass

    assert MyExceptionNoQuiet.status_code == 500
    assert MyExceptionNoQuiet.quiet == False
    assert _sanic_exceptions[500] == MyExceptionNoQuiet

    @add_status_code(202)
    class MyExceptionExplicitQuiet(SanicException):
        pass

    assert MyExceptionExplicitQuiet.status_code == 202
    assert MyExceptionExplicitQuiet.quiet == True
    assert _sanic_exceptions[202] == My

# Generated at 2022-06-12 08:48:38.895618
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class CustomException(SanicException):
        pass

    assert _sanic_exceptions[200] == CustomException()



# Generated at 2022-06-12 08:48:43.244060
# Unit test for function add_status_code
def test_add_status_code():
    # reset module variable
    global _sanic_exceptions
    _sanic_exceptions = {}
    @add_status_code(441)
    class Defined(SanicException):
        pass
    assert issubclass(_sanic_exceptions[441], Defined)
    assert ht

# Generated at 2022-06-12 08:48:53.656772
# Unit test for function add_status_code
def test_add_status_code():
    #test add_sanic_exception function
    @add_status_code(205,quiet=True)
    class TempException(SanicException):
        pass
    assert TempException.status_code == 205
    assert TempException.quiet == True

    @add_status_code(100)
    class TempException(SanicException):
        pass
    assert TempException.status_code == 100
    assert TempException.quiet == True

    @add_status_code(500)
    class TempException(SanicException):
        pass
    assert TempException.status_code == 500
    assert TempException.quiet == False

    #test add_sanic_exception function with no arguments
    @add_status_code()
    class TempException(SanicException):
        pass
    assert TempException.status_code == None
    assert Temp

# Generated at 2022-06-12 08:48:56.465779
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class Cls(SanicException):
        pass

    assert Cls.status_code == 404
    assert Cls.quiet == True

# Generated at 2022-06-12 08:49:22.349284
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        pass
    assert hasattr(Test, "status_code")
    assert Test.status_code == 200
    assert hasattr(Test, "quiet")
    assert Test.quiet == True

    @add_status_code(200, quiet=False)
    class Test(SanicException):
        pass
    assert hasattr(Test, "status_code")
    assert Test.status_code == 200
    assert hasattr(Test, "quiet")
    assert Test.quiet == False


# Generated at 2022-06-12 08:49:24.569589
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(444)
    assert len(_sanic_exceptions.keys()) == 8
    add_status_code(500)
    assert len(_sanic_exceptions.keys()) == 8

# Generated at 2022-06-12 08:49:27.825665
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class HttpRequestBadlyFormed(SanicException):
        pass

    assert HttpRequestBadlyFormed.status_code == 400


# Generated at 2022-06-12 08:49:29.856821
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions.keys() == {404, 400, 405, 500, 503}

# Generated at 2022-06-12 08:49:36.842048
# Unit test for function add_status_code
def test_add_status_code():
    status = 404
    msg = STATUS_CODES[status]

    @add_status_code(status)
    class test_exception(SanicException):
        pass

    try:
        raise test_exception()
    except test_exception:
        assert isinstance(test_exception, type)
        assert repr(test_exception) == f"<class '{test_exception.__name__}'>"
        assert test_exception.status_code == status
        assert test_exception.quiet == True
        assert test_exception.message == msg.decode("utf8")

# Generated at 2022-06-12 08:49:42.583171
# Unit test for function add_status_code
def test_add_status_code():
    try:
        @add_status_code(200)
        class TestException(SanicException):
            pass
    except Exception:
        assert False

    try:
        @add_status_code(400)
        class TestException(SanicException):
            pass
    except AssertionError:
        assert True


# Generated at 2022-06-12 08:49:45.813879
# Unit test for function add_status_code
def test_add_status_code():
    class derp:
        pass

    class derp2:
        pass

    assert(derp2 == add_status_code(404)(derp))
    assert(derp == add_status_code(404, True)(derp))



# Generated at 2022-06-12 08:49:52.299375
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410)
    class Gone(SanicException):
        pass

    assert Gone.status_code == 410
    assert _sanic_exceptions[410] == Gone
    assert Gone.quiet is True

    @add_status_code(410, quiet=False)
    class Gone(SanicException):
        pass

    assert Gone.status_code == 410
    assert _sanic_exceptions[410] == Gone
    assert Gone.quiet is False

# Generated at 2022-06-12 08:49:54.994369
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-12 08:49:57.626873
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class SpecialError(SanicException):
        pass
    assert SpecialError.status_code==404
    assert SpecialError.quiet==True
    assert _sanic_exceptions.get(404)==SpecialError

# Generated at 2022-06-12 08:50:42.505324
# Unit test for function add_status_code
def test_add_status_code():
    # add invalid status code
    try:
        class InvalidStatusCode(SanicException):
            pass

        add_status_code(124)(InvalidStatusCode)
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False

    # add valid status code
    try:
        class ValidStatusCode(SanicException):
            pass

        add_status_code(124)(ValidStatusCode)
        assert True
    except AssertionError:
        assert False
    except Exception:
        assert False

# Generated at 2022-06-12 08:50:50.022615
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    @add_status_code(code=401)
    class TestAddStatusCode(SanicException):
        pass

    assert TestAddStatusCode.__name__ == 'TestAddStatusCode'
    assert TestAddStatusCode.status_code == 401



# Generated at 2022-06-12 08:50:55.979146
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(599)
    class MyException(SanicException):
        pass

    assert 599 in _sanic_exceptions
    assert issubclass(MyException, SanicException)
    assert hasattr(_sanic_exceptions[599], "status_code")
    assert _sanic_exceptions[599].status_code == 599

    try:
        abort(599)
    except MyException as e:
        assert type(e) is MyException
        assert e.status_code == 599

# Generated at 2022-06-12 08:51:03.959867
# Unit test for function add_status_code
def test_add_status_code():
    class FooException(SanicException):
        pass

    @add_status_code(404, quiet=True)
    class BarException(SanicException):
        pass

    assert FooException.status_code == 404
    assert FooException().status_code == 404
    assert FooException().quiet == False
    assert BarException.status_code == 404
    assert BarException().status_code == 404
    assert BarException().quiet == True
    assert _sanic_exceptions[404] is BarException

# Generated at 2022-06-12 08:51:07.405162
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404] is not NotFound
    assert _sanic_exceptions[404]().status_code == 404

# Generated at 2022-06-12 08:51:14.985503
# Unit test for function add_status_code
def test_add_status_code():
    # Create new exception
    @add_status_code(400)
    class TestException(SanicException):
        pass

    exception = TestException("Test", status_code=400)

    assert exception.status_code == 400
    assert exception.message == "Test"

    # Use existing exception
    @add_status_code(404)
    class TestException(SanicException):
        pass

    assert TestException == NotFound


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:51:19.423054
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 400
    message = 'Bad Request'
    message_code = '%s\n%s' % (str(status_code), message)
    with pytest.raises(SanicException) as exc:
        raise InvalidUsage(message, status_code=status_code)
    assert str(exc.value) == message_code

# Generated at 2022-06-12 08:51:30.249242
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class CustomError(SanicException):
        pass

    c = CustomError("Message")
    assert c.status_code == 500
    assert c.message == "Message"

    @add_status_code(200)
    class CustomError(SanicException):
        pass

    c = CustomError("Message")
    assert c.status_code == 200
    assert c.message == "Message"

    @add_status_code(500, quiet=False)
    class CustomError(SanicException):
        pass

    c = CustomError("Message")
    assert c.quiet == False

    @add_status_code(500, quiet=True)
    class CustomError(SanicException):
        pass

    c = CustomError("Message")
    assert c.quiet == True


# Generated at 2022-06-12 08:51:34.401167
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert _sanic_exceptions[400] is MyException


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:51:42.137537
# Unit test for function add_status_code
def test_add_status_code():
    # The Base class for status code decorator
    class Base:
        def __init__(self, code):
            self.code = code

    @add_status_code(200)
    class B(Base):
        pass

    assert B(200).code == 200
    assert isinstance(B, Base)
    assert B(200).quiet == False
    assert _sanic_exceptions[200] == B

    # new status code should be added to _sanic_exceptions
    @add_status_code(201)
    class C(Base):
        pass

    assert C(201).code == 201
    assert isinstance(C, Base)
    assert C(201).quiet == False
    assert _sanic_exceptions[201] == C

# Generated at 2022-06-12 08:53:10.234183
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(400)
    class CustomException(SanicException):
        pass

    try:
        raise CustomException
    except CustomException as e:
        assert e.status_code == 400


# Generated at 2022-06-12 08:53:14.075788
# Unit test for function add_status_code
def test_add_status_code():
    code = 404

    class TestException(SanicException):
        pass

    test = add_status_code(code)(TestException)
    assert test.status_code == code

    test = add_status_code(code, quiet=1)(TestException)
    assert test.status_code == code
    assert test.quiet



# Generated at 2022-06-12 08:53:18.712851
# Unit test for function add_status_code
def test_add_status_code():
    class test(Exception):
        def __init__(self, msg):
            self.msg = msg

    assert HttpError(404) == NotFound()
    assert HttpError(500) == ServerError()
    t_exception = add_status_code(411)(test)
    assert t_exception() == test()

# Generated at 2022-06-12 08:53:28.361886
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class A(): pass
    assert A.status_code == 404
    assert A.quiet is True

    @add_status_code(500)
    class A(): pass
    assert A.status_code == 500
    assert A.quiet is False

    @add_status_code(400)
    class A(): pass
    assert A.status_code == 400
    assert A.quiet is True

    @add_status_code(400, True)
    class A(): pass
    assert A.status_code == 400
    assert A.quiet is True

    @add_status_code(400, False)
    class A(): pass
    assert A.status_code == 400
    assert A.quiet is False

# Generated at 2022-06-12 08:53:31.261422
# Unit test for function add_status_code
def test_add_status_code():
    test_exc = add_status_code(123, quiet=False)(SanicException)
    assert test_exc.status_code == 123
    assert test_exc.quiet == False

# Generated at 2022-06-12 08:53:36.566287
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions.get(500) is TestException

    @add_status_code(400)
    class TestExceptionQuiet(SanicException):
        pass

    assert TestExceptionQuiet.status_code == 400
    assert TestExceptionQuiet.quiet is True
    assert _sanic_exceptions.get(400) is TestExceptionQuiet

# Generated at 2022-06-12 08:53:43.523225
# Unit test for function add_status_code
def test_add_status_code():
    try:
        abort(503)
        assert False
    except ServiceUnavailable as e:
        assert e.status_code == status_code

    try:
        abort(404)
        assert False
    except NotFound as e:
        assert e.status_code == status_code

    try:
        abort(500)
        assert False
    except ServerError as e:
        assert e.status_code == status_code

    try:
        abort(400)
        assert False
    except InvalidUsage as e:
        assert e.status_code == status_code

# Generated at 2022-06-12 08:53:48.558796
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    @add_status_code(123)
    class TestClass2(SanicException):
        pass

    assert TestClass.status_code == None
    assert TestClass2.status_code == 123
    assert _sanic_exceptions.get(123) == TestClass2



# Generated at 2022-06-12 08:53:58.460147
# Unit test for function add_status_code
def test_add_status_code():
    class NewException(SanicException):
        pass
    # Unittest for passing an int as the first param
    NewException = add_status_code(400)(NewException)
    assert _sanic_exceptions[400] == NewException
    assert NewException.status_code == 400
    assert NewException.quiet == True

    # Unittest for passing a string as the first param
    class AnotherException(SanicException):
        pass
    AnotherException = add_status_code("404")(AnotherException)
    assert _sanic_exceptions[404] == AnotherException
    assert AnotherException.status_code == 404
    assert AnotherException.quiet == True

    # Unittest for passing a quiet=False as the second param
    class ExceptionWithStatusCode(SanicException):
        pass
    ExceptionWithStatusCode = add_status_code

# Generated at 2022-06-12 08:54:03.973840
# Unit test for function add_status_code
def test_add_status_code():
    import sys  # noqa: S404

    class MyException(SanicException):
        pass

    exception = MyException("Test exception")
    assert sys.exc_info() == (MyException, exception, None)

    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    exception = BadRequest("Test exception")
    assert sys.exc_info() == (BadRequest, exception, None)

    @add_status_code(401)
    class Unauthorized(SanicException):
        pass

    exception = Unauthorized("Test exception")
    assert sys.exc_info() == (Unauthorized, exception, None)

