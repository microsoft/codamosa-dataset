

# Generated at 2022-06-12 08:44:37.990121
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException1(SanicException):
        pass

    assert TestException1.quiet == False

    @add_status_code(400)
    class TestException2(SanicException):
        pass

    assert TestException2.quiet == False

    @add_status_code(500)
    class TestException3(SanicException):
        pass

    assert TestException3.quiet == True

    @add_status_code(500, quiet=True)
    class TestException4(SanicException):
        pass

    assert TestException4.quiet == True

    @add_status_code(500, quiet=False)
    class TestException5(SanicException):
        pass

    assert TestException5.quiet == False

# Generated at 2022-06-12 08:44:41.155436
# Unit test for function add_status_code
def test_add_status_code():

    # test for SanicException
    with pytest.raises(SanicException):
        abort(401)

    # test for Unauthorized
    with pytest.raises(Unauthorized):
        abort(401)

# Generated at 2022-06-12 08:44:46.977660
# Unit test for function add_status_code
def test_add_status_code():
    """
    Ensure that the add_status_code decorator is working as expected.
    """
    class MyException(SanicException): pass
    _sanic_exceptions_size = len(_sanic_exceptions)
    add_status_code(400)(MyException)
    assert len(_sanic_exceptions) == _sanic_exceptions_size + 1
    assert _sanic_exceptions[400] is MyException



# Generated at 2022-06-12 08:44:55.399203
# Unit test for function add_status_code
def test_add_status_code():
    def add_exception(status_code, quiet = None):
        @add_status_code(status_code, quiet)
        class Exception(SanicException):
            pass
    
    add_exception(451)
    assert 451 in _sanic_exceptions
    assert not _sanic_exceptions[451].quiet
    assert _sanic_exceptions[451].status_code == 451

    add_exception(500)
    assert 500 in _sanic_exceptions
    assert _sanic_exceptions[500].quiet
    assert _sanic_exceptions[500].status_code == 500

    add_exception(300, quiet = True)
    assert 300 in _sanic_exceptions
    assert _sanic_exceptions[300].quiet
    assert _sanic_exceptions[300].status_code == 300

# Generated at 2022-06-12 08:44:57.904309
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class SomeException(SanicException):
        pass

    # Test that the exception is in our dictionary
    assert _sanic_exceptions[201] is SomeException
    # Test that quiet was set, because 201 != 500
    assert SomeException.quiet



# Generated at 2022-06-12 08:45:07.778971
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1)
    class Ex(SanicException):
        pass
    assert Ex.status_code == 1
    assert Ex.quiet is True
    assert _sanic_exceptions[1] is Ex

    @add_status_code(2, quiet=False)
    class Ex2(SanicException):
        pass
    assert Ex2.status_code == 2
    assert Ex2.quiet is False
    assert _sanic_exceptions[2] is Ex2

    @add_status_code(3)
    class Ex3(SanicException):
        pass
    assert Ex3.status_code == 3
    assert Ex3.quiet is False
    assert _sanic_exceptions[3] is Ex3


# Generated at 2022-06-12 08:45:12.969878
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(416)
    class RangeNotSatisfiable(SanicException):
        """
        **Status**: 416 Range Not Satisfiable

        Sent when the bytes requested in Content-Range cannot be delivered.
        """

        def __init__(self, message, content_range):
            super().__init__(message)
            self.headers = {"Content-Range": f"bytes */{content_range.total}"}
    assert 416 in _sanic_exceptions
    assert _sanic_exceptions[416] == RangeNotSatisfiable
    assert RangeNotSatisfiable.quiet == True
    assert RangeNotSatisfiable.status_code == 416

# Generated at 2022-06-12 08:45:26.341361
# Unit test for function add_status_code
def test_add_status_code():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Not Found"
    except Exception:
        assert False, "Shouldn't reach here"

    try:
        abort(404, "Bad")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Bad"
    except Exception:
        assert False, "Shouldn't reach here"

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    except Exception:
        assert False, "Shouldn't reach here"

    try:
        abort(500, "Bad")
    except ServerError as e:
        assert e.status_code

# Generated at 2022-06-12 08:45:28.365946
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    add_status_code(404)(MyException)
    assert _sanic_exceptions[404] is MyException



# Generated at 2022-06-12 08:45:31.598996
# Unit test for function add_status_code
def test_add_status_code():
    def bad_use_of_add_status_code():
        @add_status_code(500)
        class BadStatusCode(SanicException):
            pass
    with pytest.raises(TypeError):
        bad_use_of_add_status_code()



# Generated at 2022-06-12 08:45:38.614765
# Unit test for function add_status_code
def test_add_status_code():
    """Test if add_status_code can add status code to SanicException
    """
    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert ServerError(message="ServerError").status_code == 500
    assert ServerError(message="ServerError").status_code == 500
    assert ServerError(message="ServerError").status_code == 500


# Generated at 2022-06-12 08:45:42.419603
# Unit test for function add_status_code
def test_add_status_code():
    # arrange
    custom_error_code = 999
    custom_exception_message = 'This a message for exception'

    # act
    @add_status_code(custom_error_code)
    class CustomException(SanicException):
        """
        **Status**: 999 Custom Exception
        """

        def __init__(self, message):
            super().__init__(message)

    # assert
    custom_exception = CustomException(custom_exception_message)
    assert custom_exception.status_code == custom_error_code
    assert custom_exception.message == custom_exception_message

# Generated at 2022-06-12 08:45:46.166951
# Unit test for function add_status_code
def test_add_status_code():
	class Test(SanicException):
		pass
	print(_sanic_exceptions)
	add_status_code(200)(Test)
	print(_sanic_exceptions)


if __name__ == "__main__":
	test_add_status_code()

# Generated at 2022-06-12 08:45:57.947797
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        def __init__(self, message, status_code):
            super().__init__(message, status_code)
    
    @add_status_code(0)
    class TestException0(SanicException):
        def __init__(self, message, status_code):
            super().__init__(message, status_code)

    assert _sanic_exceptions[0] == TestException0
    assert "SanicException" in str(TestException0)
    assert "status_code" in str(TestException0)
    assert "quiet" in str(TestException0)
    assert str(_sanic_exceptions[0]) == str(TestException0)

    assert TestException0.status_code == 0
    assert TestException0.quiet == False
    

# Generated at 2022-06-12 08:46:03.911366
# Unit test for function add_status_code
def test_add_status_code():
    # test_add_status_code
    class TestAddStatusCode(SanicException):
        pass
    assert 404 in _sanic_exceptions
    assert _sanic_exceptions[404] == NotFound
    # assert add_status_code(404)(TestAddStatusCode)[1] == 404
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404] != TestAddStatusCode

# Generated at 2022-06-12 08:46:13.584608
# Unit test for function add_status_code
def test_add_status_code():
    code = 900
    quiet = True
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls
    code = 900
    quiet = True
    assert add_status_code(code, quiet) == class_decorator(cls)
    assert add_status_code(code, quiet = True) == class_decorator(cls)
    assert add_status_code(code, quiet = False) == class_decorator(cls)
    assert add_status_code(code, quiet = None) == class_decorator(cls)

# Generated at 2022-06-12 08:46:23.750287
# Unit test for function add_status_code
def test_add_status_code():
    # Test if add_status_code works as intended
    # When decorating a class, add a field status_code and status codes
    # to _sanic_exceptions
    @add_status_code(123, quiet=False)
    class Test:
        pass

    assert Test.status_code == 123
    assert Test.quiet == False

    # SanicException should be a subclass of Exception
    assert issubclass(SanicException, Exception)
    # NotFound should be a subclass of SanicException
    assert issubclass(NotFound, SanicException)
    # NotFound should be a subclass of Exception
    assert issubclass(NotFound, Exception)

    # Abort should work as intended with known status code
    try:
        abort(123)
    except Exception as e:
        assert e.status_code == 123

# Generated at 2022-06-12 08:46:34.493827
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestStatus(SanicException):
        pass

    # Test SanicException created with status_code is added to sanic_exceptions
    assert 999 in _sanic_exceptions

    # Test that a class without a SanicException in its inheritance chain
    # is not added
    @add_status_code(998)
    class TestFail():
        pass

    assert 998 not in _sanic_exceptions

    # Test that a class with SanicException in its inheritance chain is added
    @add_status_code(997)
    class TestChild(TestStatus):
        pass

    assert 997 in _sanic_exceptions

    # Test that a SanicException that is not decorated is not added
    class TestFail2(SanicException):
        pass


# Generated at 2022-06-12 08:46:38.221541
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(666)
    class SanicException666(SanicException):
        pass
    assert SanicException666().status_code == 666
    assert SanicException666.status_code == 666
    assert _sanic_exceptions[666] == SanicException666



# Generated at 2022-06-12 08:46:49.760257
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class SpecificException(SanicException):
        pass

    assert _sanic_exceptions[999] == SpecificException
    assert _sanic_exceptions[999].status_code == 999
    assert _sanic_exceptions[999].quiet == False
    assert _sanic_exceptions[999]().status_code == 999
    assert _sanic_exceptions[999]().quiet == False

    @add_status_code(999, quiet=True)
    class SpecificException(SanicException):
        pass

    assert _sanic_exceptions[999] == SpecificException
    assert _sanic_exceptions[999].status_code == 999
    assert _sanic_exceptions[999].quiet == True
    assert _sanic_exceptions[999]().status_code == 999
   

# Generated at 2022-06-12 08:47:01.237905
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Exception100(SanicException):
        pass
    assert _sanic_exceptions[100] == Exception100
    assert _sanic_exceptions[100]().status_code == 100

    @add_status_code(200)
    class Exception200(SanicException):
        pass
    assert _sanic_exceptions[200] == Exception200
    assert _sanic_exceptions[200]().status_code == 200

    @add_status_code(300)
    class Exception300(SanicException):
        pass
    assert _sanic_exceptions[300] == Exception300
    assert _sanic_exceptions[300]().status_code == 300

    # Test quiet option

# Generated at 2022-06-12 08:47:04.231044
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class My404(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)
    my_404 = My404('404 message')
    assert my_404.status_code == '404'
    assert my_404.message == '404 message'
    assert my_404.quiet == True


# Generated at 2022-06-12 08:47:15.943029
# Unit test for function add_status_code
def test_add_status_code():
    # class_decorator
    class_decorator = add_status_code(404)
    # class_decorator(Test1)
    class Test1(SanicException):
        pass
    Test = class_decorator(Test1)
    assert Test.status_code == 404

    # class_decorator
    class_decorator = add_status_code(404, quiet=True)
    # class_decorator(Test2)
    class Test2(SanicException):
        pass
    Test = class_decorator(Test2)
    assert Test.status_code == 404
    assert Test.quiet == True

    # class_decorator
    class_decorator = add_status_code(500)
    # class_decorator(Test3)

# Generated at 2022-06-12 08:47:22.975941
# Unit test for function add_status_code
def test_add_status_code():
    class A(SanicException):
        pass

    class B(SanicException):
        pass

    assert add_status_code(123)(A) is A
    assert add_status_code(123)(B) is B

    assert A.status_code == 123
    assert B.status_code == 123

    assert _sanic_exceptions.get(123) is A
    assert _sanic_exceptions.get(123) is not B

    assert add_status_code(100)(A) is A
    assert A.status_code == 100
    assert _sanic_exceptions.get(100) is A

    assert _sanic_exceptions.get(123) is B



# Generated at 2022-06-12 08:47:25.703811
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class NotImplemented(SanicException):
        pass
    
    assert _sanic_exceptions[501] == NotImplemented

# Generated at 2022-06-12 08:47:33.298517
# Unit test for function add_status_code
def test_add_status_code():
    # 1. test add_status_code without quiet
    @add_status_code(200)
    class NewExceptionWithoutQuiet(Exception):
        pass

    assert issubclass(NewExceptionWithoutQuiet, Exception)
    assert NewExceptionWithoutQuiet().status_code == 200
    assert not hasattr(NewExceptionWithoutQuiet(), 'quiet')

    # 2. test add_status_code with quiet
    @add_status_code(201, quiet=True)
    class NewExceptionWithQuiet(Exception):
        pass

    assert issubclass(NewExceptionWithQuiet, Exception)
    assert NewExceptionWithQuiet().status_code == 201
    assert NewExceptionWithQuiet().quiet is True

    # 3. test add_status_code with quiet is None

# Generated at 2022-06-12 08:47:35.537845
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(504)
    print(_sanic_exceptions)
    assert 504 in _sanic_exceptions


# Generated at 2022-06-12 08:47:46.539990
# Unit test for function add_status_code
def test_add_status_code():

    def assert_status_code(exception: Exception, status_code: int, quiet: bool):
        assert isinstance(exception, SanicException)
        assert exception.status_code == status_code
        assert exception.quiet == quiet

    def assert_all_not_quiet():
        assert not NotFound.quiet
        assert not InvalidUsage.quiet
        assert not InvalidRangeType.quiet
        assert not InvalidRangeType.quiet

    def assert_all_quiet():
        assert NotFound.quiet
        assert InvalidUsage.quiet
        assert InvalidRangeType.quiet
        assert InvalidRangeType.quiet

    # Make sure that exceptions are added to the service-wide dict
    assert NotFound.status_code in _sanic_exceptions
    assert InvalidUsage.status_code in _sanic_exceptions
    assert InvalidRangeType.status_code in _

# Generated at 2022-06-12 08:47:49.862295
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, quiet=True)
    class Created(SanicException):
        pass

    assert Created.status_code == 201
    assert Created.quiet == True
    assert _sanic_exceptions[201] == Created

# Generated at 2022-06-12 08:47:52.347003
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class NewException(SanicException):
        pass
    assert _sanic_exceptions[123] == NewException

# Generated at 2022-06-12 08:48:06.738432
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)
    assert add_status_code(400)
    assert add_status_code(405)
    assert add_status_code(500)
    assert add_status_code(503)
    assert add_status_code(408)
    assert add_status_code(413)
    assert add_status_code(416)
    assert add_status_code(417)
    assert add_status_code(403)
    assert add_status_code(401)

# Generated at 2022-06-12 08:48:18.548681
# Unit test for function add_status_code
def test_add_status_code():
    # UserError is defined in this package and only has status_code:
    # code = 400 and quiet = True
    @add_status_code(400, quiet=True)
    class UserError(Exception):
        pass

    assert UserError.status_code == 400
    assert UserError.quiet is True
    assert _sanic_exceptions[400].__name__ == UserError.__name__

    @add_status_code(500, quiet=False)
    class SomeError(Exception):
        pass

    assert SomeError.status_code == 500
    assert SomeError.quiet is False
    assert _sanic_exceptions[500].__name__ == SomeError.__name__

    # "quiet" is None when calling add_status_code, so it should be False

# Generated at 2022-06-12 08:48:21.710045
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class MyError(SanicException):
        pass
    assert MyError.status_code == 123
    assert _sanic_exceptions[123] == MyError


# Unit tests for function abort

# Generated at 2022-06-12 08:48:23.800095
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class Message(SanicException):
        pass

    assert Message.status_code == 400
    assert Message().status_code == 400



# Generated at 2022-06-12 08:48:26.734303
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    add_status_code(1000)(MyException)
    assert _sanic_exceptions[1000] == MyException
    assert _sanic_exceptions[1000]().status_code == 1000

# Generated at 2022-06-12 08:48:30.475896
# Unit test for function add_status_code
def test_add_status_code():
    code = 200
    class Test(SanicException):
        pass
    Test = add_status_code(code)(Test)
    assert Test.status_code == code
    assert _sanic_exceptions[code] == Test


# Generated at 2022-06-12 08:48:39.303741
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        """
        **Status**: 401 Unauthorized
        """

        def __init__(self, message, status_code=None, scheme=None, **kwargs):
            super().__init__(message, status_code)
            if scheme is not None:
                values = ['{!s}="{!s}"'.format(k, v) for k, v in kwargs.items()]
                challenge = ", ".join(values)
                self.headers = {"WWW-Authenticate": f"{scheme} {challenge}".rstrip()}

    print(Unauthorized.status_code)
    print(Unauthorized.quiet)


# Generated at 2022-06-12 08:48:43.288777
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class A(SanicException):
        pass
    assert A.status_code == 200
    assert A('').status_code == 200
    assert _sanic_exceptions.get(200).status_code == 200

# Generated at 2022-06-12 08:48:47.760519
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(333)
    class B(SanicException):
        pass
        
    assert hasattr(B, 'status_code')
    assert B.status_code == 333
    assert 333 in _sanic_exceptions.keys()
    
if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:48:53.497676
# Unit test for function add_status_code
def test_add_status_code():
    """
    Decorator test for adding exceptions to :class:`SanicException`.
    """
    @add_status_code(200, quiet=True)
    class AddStatusCode(SanicException):
        """
        **Status**: 200 OK
        """
    assert AddStatusCode.status_code == 200
    assert AddStatusCode.quiet == True
    assert _sanic_exceptions[200] == AddStatusCode

# Generated at 2022-06-12 08:49:19.014193
# Unit test for function add_status_code
def test_add_status_code():
    original_exceptions = _sanic_exceptions.copy()

# Generated at 2022-06-12 08:49:26.977685
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeaPot(SanicException):
        """
        **Status**: 418 I'm a teapot.
        """
        pass
    assert 'I\'m a teapot.' in str(IAmATeaPot())
    assert 418 == IAmATeaPot.status_code
    assert hasattr(IAmATeaPot, 'quiet')

    @add_status_code(403, quiet=True)
    class Forbidden(SanicException):
        """
        **Status**: 403 Forbidden
        """
        pass
    assert Forbidden.quiet

    @add_status_code(500, quiet=False)
    class ServerError(SanicException):
        """
        **Status**: 500 Internal Server Error
        """
        pass
    assert not ServerError.quiet

# Generated at 2022-06-12 08:49:31.324663
# Unit test for function add_status_code
def test_add_status_code():
    # add custom status 20
    @add_status_code(20)
    class CustomException(SanicException):
        """
        **Status**: 20
        """
        pass
    assert _sanic_exceptions[20] == CustomException


# Generated at 2022-06-12 08:49:36.799662
# Unit test for function add_status_code
def test_add_status_code():
    msg = "Error 500"
    status_code = 500
    class NewStatusCode(SanicException):
        pass
    NewStatusCode = add_status_code(status_code)(NewStatusCode)
    try:
        raise NewStatusCode(msg)
    except NewStatusCode as e:
        assert status_code == e.status_code
        assert msg == str(e)

# Generated at 2022-06-12 08:49:42.997455
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class SanicExceptionTest(SanicException):
        pass
    sanic_exception_test = SanicExceptionTest(message='test', status_code=400)
    assert sanic_exception_test.status_code == 400
    assert sanic_exception_test.message == 'test'


# Generated at 2022-06-12 08:49:44.099284
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)

# Generated at 2022-06-12 08:49:48.506770
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class ImATeaPot(SanicException):
        pass

    assert isinstance(ImATeaPot(), ImATeaPot)
    assert ImATeaPot().status_code == 418
    assert ImATeaPot().quiet is None



# Generated at 2022-06-12 08:49:56.143469
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(777)
    class IAmAnException(SanicException):
        pass

    assert IAmAnException.status_code == 777
    assert 777 in _sanic_exceptions
    assert type(_sanic_exceptions[777]) == IAmAnException

    # Test quiet
    assert IAmAnException(message="", status_code=777).quiet

    # Test not quiet
    assert not IAmAnException(message="", status_code=777, quiet=False).quiet



# Generated at 2022-06-12 08:49:57.664487
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class TestException(SanicException):
        pass
    TestException()

# Generated at 2022-06-12 08:50:01.225433
# Unit test for function add_status_code
def test_add_status_code():
    def test():
        pass
    result = add_status_code(200)(test)
    assert result.status_code == 200
    assert _sanic_exceptions.get(200) == result

# Generated at 2022-06-12 08:50:38.070263
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 401
    assert _sanic_exceptions[401] == MyException

    @add_status_code(403)
    class MyOtherException(SanicException):
        pass

    assert MyOtherException.status_code == 403
    assert _sanic_exceptions[403] == MyOtherException

# Generated at 2022-06-12 08:50:44.261221
# Unit test for function add_status_code
def test_add_status_code():
    """
    test case for function add_status_code
    :return: nothing
    """
    class TestStatusCodeException(SanicException):
        pass

    assert TestStatusCodeException.status_code == None
    assert TestStatusCodeException.quiet == None

    TestStatusCodeException = add_status_code(432)(TestStatusCodeException)
    assert TestStatusCodeException.status_code == 432
    assert TestStatusCodeException.quiet == None

    TestStatusCodeException = add_status_code(1337, quiet=True)(TestStatusCodeException)
    assert TestStatusCodeException.status_code == 1337
    assert TestStatusCodeException.quiet == True



# Generated at 2022-06-12 08:50:49.482769
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class ImATeapot(SanicException):
        """
        **Status**: 418 I'm a teapot
        """

        pass

    assert ImATeapot.status_code == 418
    assert _sanic_exceptions[418] == ImATeapot



# Generated at 2022-06-12 08:50:52.929398
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(302)
    class Redirect(SanicException):
        pass
    assert Redirect.status_code==302
    assert Redirect.quiet== True
    assert Redirect(message="not found").status_code==302
    assert Redirect(message="not found").quiet==True



# Generated at 2022-06-12 08:51:01.222334
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class Created(SanicException):
        pass
    assert Created.status_code == 201
    assert Created.quiet == False
    @add_status_code(500)
    class NewServerError(SanicException):
        pass
    assert NewServerError.status_code == 500
    @add_status_code(505, quiet=True)
    class NewMethodNotSupported(SanicException):
        pass
    assert NewMethodNotSupported.status_code == 505
    assert NewMethodNotSupported.quiet == True

# Generated at 2022-06-12 08:51:04.245773
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    add_status_code(456)(MyException)

    assert _sanic_exceptions[456] == MyException



# Generated at 2022-06-12 08:51:09.668239
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(Exception):
        pass
    test_status_code = 403
    assert test_status_code not in _sanic_exceptions
    add_status_code(test_status_code)(TestException)
    assert test_status_code in _sanic_exceptions
    with pytest.raises(TestException):
        abort(test_status_code)

# Generated at 2022-06-12 08:51:13.864835
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 404
    assert _sanic_exceptions == {404: MyException}



# Generated at 2022-06-12 08:51:19.731722
# Unit test for function add_status_code
def test_add_status_code():
    # Case 1:
    @add_status_code(200)
    class ClassA(SanicException):
        pass

    classA = ClassA()
    assert classA.status_code == 200

    # Case 2:
    @add_status_code(201)
    class ClassB(SanicException):
        pass

    classB = ClassB()
    assert classB.status_code == 201

    # Case 3:
    @add_status_code(202)
    class ClassC(SanicException):
        pass

    classC = ClassC()
    assert classC.status_code == 202


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-12 08:51:29.525916
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    @add_status_code(403)
    class Forbidden(SanicException):
        pass

    assert issubclass(Forbidden, SanicException)
    assert Forbidden.status_code == 403
    assert Forbidden.quiet is True

    @add_status_code(999)
    class AnotherSanicException(SanicException):
        pass

    assert issubclass(AnotherSanicException, SanicException)
    assert AnotherSanicException.status_code == 999
    assert AnotherSanicException.__name__ == "AnotherSanicException"

    with pytest.raises(TypeError):
        add_status_code(999)(MyException)



# Generated at 2022-06-12 08:52:40.269001
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True


# Generated at 2022-06-12 08:52:43.205141
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 1001
    cls = "This is the name of the class"
    add_status_code(status_code)(cls)
    assert _sanic_exceptions[status_code] == cls

# Generated at 2022-06-12 08:52:45.359815
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-12 08:52:52.547759
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    @add_status_code(409)
    class Conflict(SanicException):
        pass

    @add_status_code(204)
    class Success(SanicException):
        pass

    @add_status_code(200)
    class Ok(SanicException):
        pass

    @add_status_code(403)
    class Denied(SanicException):
        pass
    assert _sanic_exceptions[400] == BadRequest
    assert _sanic_exceptions[409] == Conflict
    assert _sanic_exceptions[204] == Success
    assert _sanic_exceptions[200] == Ok
    assert _sanic_exceptions[403] == Denied

# Generated at 2022-06-12 08:52:55.308054
# Unit test for function add_status_code
def test_add_status_code():
    
    @add_status_code(403)
    class Forbidden(SanicException):
        """
        **Status**: 403 Forbidden
        """
        pass

    assert Forbidden.status_code == 403



# Generated at 2022-06-12 08:53:00.173731
# Unit test for function add_status_code
def test_add_status_code():
    message = 'test message'
    class CustomException(SanicException):
        pass
    CustomException = add_status_code(403)(CustomException)()
    try:
        raise CustomException(message=message)
    except CustomException as e:
        assert e.status_code == 403
        assert e.message == message
    else:
        assert False, "CustomException should have been raised"

# Generated at 2022-06-12 08:53:10.826817
# Unit test for function add_status_code
def test_add_status_code():
    #Mock object which will store references to custom exceptions
    mock_object = {}

    class TestException(SanicException):

        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message=message)

    #Checking if status code is set appropriately
    add_status_code(code=404)(TestException)
    assert TestException.status_code == 404
    add_status_code(code=405)(TestException)
    assert TestException.status_code == 405

    #Checking if status code is added to mock_object
    add_status_code(code=405, quiet=True)(TestException)
    assert TestException.quiet == True
    mock_object[405] = TestException
    assert mock_object == _sanic_exceptions

# Generated at 2022-06-12 08:53:18.027240
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class CustomException(Exception):
        pass

    class NotCustomException(Exception):
        pass

    assert _sanic_exceptions[200] == CustomException
    assert _sanic_exceptions.get(404) == NotFound
    assert _sanic_exceptions.get(500) == ServerError
    assert _sanic_exceptions.get(400) == InvalidUsage
    assert _sanic_exceptions.get(405) == MethodNotSupported
    assert _sanic_exceptions.get(401) == Unauthorized
    assert _sanic_exceptions.get(408) == RequestTimeout
    assert _sanic_exceptions.get(413) == PayloadTooLarge
    assert _sanic_exceptions.get(416) == ContentRangeError
    assert _sanic_exceptions.get

# Generated at 2022-06-12 08:53:28.709546
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class A(SanicException):
        pass
    
    assert A.status_code == 100

    @add_status_code(200, True)
    class B(SanicException):
        pass
    
    assert B.status_code == 200
    assert B.quiet == True
    
    @add_status_code(300)
    class C(SanicException):
        pass
    
    assert C.status_code == 300
    assert C.quiet == True
    
    @add_status_code(400)
    class D(SanicException):
        pass
    
    assert D.status_code == 400
    assert D.quiet == True
    
    @add_status_code(500)
    class E(SanicException):
        pass
    

# Generated at 2022-06-12 08:53:32.361456
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestAddStatusCode(SanicException):
        pass
    assert TestAddStatusCode.status_code == 404
    assert _sanic_exceptions[404] == TestAddStatusCode