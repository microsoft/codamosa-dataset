

# Generated at 2022-06-24 03:37:17.062062
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as exc_info:
        raise ServiceUnavailable("This is a test")
    assert "This is a test" in str(exc_info.value)

# Generated at 2022-06-24 03:37:22.432923
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass
    TestException.__name__ = 'TestException'
    add_status_code(500, quiet=True)(TestException)
    Test = TestException("testing")
    assert Test.status_code == 500
    assert Test.quiet == True
    assert Test.__class__.__name__ == 'TestException'

# Generated at 2022-06-24 03:37:26.828656
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f = FileNotFound("this is wrong", "12/123.txt", "abcd")
    assert f.message == "this is wrong"
    assert f.path == "12/123.txt"
    assert f.relative_url == "abcd"
    assert f.status_code == 404
    assert f.quiet == True


# Generated at 2022-06-24 03:37:28.975404
# Unit test for constructor of class PyFileError
def test_PyFileError():
    exception = PyFileError('test')
    assert exception.args[0] == f"could not execute config file {'test'}"

# Generated at 2022-06-24 03:37:34.229317
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class First(SanicException):
        pass

    def another_decorator(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    @another_decorator
    @add_status_code(401)
    class Second(SanicException):
        pass

    assert _sanic_exceptions == {
        400: First,
        401: Second
    }

# Generated at 2022-06-24 03:37:38.734621
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert(PayloadTooLarge("error", 413).__dict__ == {
     'args': ('error',), 'status_code': 413, 'quiet': True})
    

# Generated at 2022-06-24 03:37:43.744570
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload = PayloadTooLarge('test_message', 'test_payload')
    assert payload.status_code == 413
    assert payload.message == 'test_message'
    assert payload.payload == 'test_payload'
    assert not hasattr(payload, 'headers')


# Generated at 2022-06-24 03:37:46.701591
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("error msg")
    except HeaderExpectationFailed:
        pass

# Generated at 2022-06-24 03:37:53.158541
# Unit test for function abort
def test_abort():
    exc = None
    try:
        abort(404, 'Here is a message')
    except Exception as e:
        exc = e
    assert isinstance(exc, NotFound)
    assert exc.message == 'Here is a message'
    assert exc.status_code == 404
    try:
        abort(400, "Here is a message")
    except Exception as e:
        exc = e
    assert isinstance(exc, InvalidUsage)
    assert exc.message == 'Here is a message'
    assert exc.status_code == 400

# Generated at 2022-06-24 03:37:55.265361
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Test signal exception")
    except InvalidSignal as exp:
        assert exp.__str__() == "Test signal exception"


# Generated at 2022-06-24 03:38:04.151419
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        # the 2nd argument is any content_range object, cannot be None
        raise ContentRangeError("content range error", None)
    except ContentRangeError as e:
        # if the 2nd argument is None, ContentRangeError should be raised
        assert(True)
        # the 'total' property of content_range object should be used to
        # complete the 'Content-Range' header
        assert(e.headers["Content-Range"] == "bytes */1")
    try:
        # the 2nd argument should not be None
        raise ContentRangeError("content range error")
    except TypeError as e:
        # if the 2nd argument is None, TypeError should be raised
        assert(True)

# Generated at 2022-06-24 03:38:07.357022
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    add_status_code(400)(TestException)
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-24 03:38:09.703267
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("wrong signal!")
    except InvalidSignal:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:38:17.312817
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Pass a mocking value for content_range
    content_range = "Test_Range"
    # Create an object of class InvalidRangeType
    invalid_range_type = InvalidRangeType("Test message", content_range)
    # Check the type of exception_object.
    assert isinstance(invalid_range_type, InvalidRangeType)
    # Check the attributes of exception_object
    assert invalid_range_type.message == "Test message"
    assert invalid_range_type.headers == {'Content-Range': 'bytes */Test_Range'}

# Generated at 2022-06-24 03:38:21.866060
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable(message="test").status_code == 503
    assert ServiceUnavailable().message == "Service Unavailable"
    assert ServiceUnavailable(status_code=400).status_code == 400
    assert ServiceUnavailable(message="test", status_code=400).status_code == 400
    assert ServiceUnavailable(message="test", status_code=400).message == "test"
    

# Generated at 2022-06-24 03:38:33.137225
# Unit test for function abort
def test_abort():
    def call_abort(status_code, message=None, **kwargs):
        try:
            abort(status_code, message=message, **kwargs)
        except SanicException as exc:
            return exc

    # Test defaults
    result = call_abort(404)
    assert result.status_code == 404
    assert result.message == b"Not Found"

    # Test allowed types
    result = call_abort(503, "Test message")
    assert result.status_code == 503
    assert result.message == "Test message"

    # Test that bytes can be passed/converted
    result = call_abort(503, b"Test message")
    assert result.status_code == 503
    assert result.message == "Test message"

    # Test special exceptions

# Generated at 2022-06-24 03:38:37.019878
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType('sample message')
    except Exception as e:
        assert e.status_code == 416
        assert e.__class__.__name__ == 'InvalidRangeType'
        assert e.message == 'sample message'



# Generated at 2022-06-24 03:38:43.759668
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # set up
    auth_scheme = "Basic"
    kwargs = {"realm": "Restricted Area"}
    message = "Auth required."

    # test
    unauthorized_obj = Unauthorized(message, scheme=auth_scheme, **kwargs)

    # verify
    assert isinstance(unauthorized_obj, Unauthorized)
    assert unauthorized_obj.headers["WWW-Authenticate"] == (
        f"{auth_scheme} realm=\"Restricted Area\""
    )

# Generated at 2022-06-24 03:38:51.459885
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('testing', 'POST', ['GET', 'PUT', 'OPTIONS'])
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.message == 'testing'
        assert e.method == 'POST'
        assert e.allowed_methods == ['GET', 'PUT', 'OPTIONS']
        assert e.headers['Allow'] == 'GET, PUT, OPTIONS'

# Generated at 2022-06-24 03:38:57.633333
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound) as e_info:
        raise NotFound()
    assert e_info.type is NotFound
    assert issubclass(NotFound, SanicException)
    assert str(e_info.value) == '404: Not Found'
    assert e_info.value.status_code == 404
    assert e_info.value.quiet is True


# Generated at 2022-06-24 03:39:06.110459
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        # Do not compare the stacktrace which is different on py3
        assert e.args[0] == "Bad Request"
        assert e.status_code == 400

    try:
        abort(400, "custom bad request")
    except InvalidUsage as e:
        # Do not compare the stacktrace which is different on py3
        assert e.args[0] == "custom bad request"
        assert e.status_code == 400

    try:
        abort(416, "Request Range Not Satisfiable")
    except ContentRangeError as e:
        # Do not compare the stacktrace which is different on py3
        assert e.args[0] == "Request Range Not Satisfiable"
        assert e.status_code == 416

# Generated at 2022-06-24 03:39:08.602116
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('an_error_message')
    except ServerError as e:
        assert e.status_code == 500

# Generated at 2022-06-24 03:39:14.385908
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    string = "The method is not supported."
    method = "PUT"
    allowed_methods = ["GET", "POST"]
    method_not_supported = MethodNotSupported(string, method, allowed_methods)
    assert method_not_supported.message == string
    assert method_not_supported.status_code == 405
    assert method_not_supported.headers["Allow"] == "GET, POST"

# Generated at 2022-06-24 03:39:22.917740
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "error message"
    status_code = "400"
    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"

    # Test with default status_code
    u1 = Unauthorized(message)
    assert u1.message == message
    assert u1.status_code == 401
    assert u1.headers == {}

    # Test with all parameters
    u2 = Unauthorized(message, status_code, scheme, realm=realm, qop=qop, algorithm=algorithm, nonce=nonce, opaque=opaque)
    assert u2.message == message
    assert u2.status_code == status_code
    assert u2.headers

# Generated at 2022-06-24 03:39:25.969893
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("hello world")
    except LoadFileException as e:
        # print(str(e))
        assert str(e) == "hello world"

# Generated at 2022-06-24 03:39:35.988136
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present:
    test_case = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert test_case.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    # With a Digest auth-scheme, things are a bit more complicated:
    test_case = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert test_case.headers == {'WWW-Authenticate': 'Digest algorithm="MD5", nonce="abcdef", qop="auth, auth-int", opaque="zyxwvu", realm="Restricted Area"'}
    # With a Bearer auth-scheme, realm is

# Generated at 2022-06-24 03:39:47.976079
# Unit test for function add_status_code
def test_add_status_code():

    class TestClass:
        status_code = None
        quiet = None

    # decorator with decorator parameter code as 200
    decor = add_status_code(200)
    assert decor.__name__ == "class_decorator"
    tc = decor(TestClass)
    # status code in TestClass should be 200
    assert tc.status_code == 200
    # no quiet attribute in TestClass
    assert tc.quiet is None

    # decorator with decorator parameter code as 500
    decor = add_status_code(500)
    assert decor.__name__ == "class_decorator"
    tc = decor(TestClass)
    # status code in TestClass should be 500
    assert tc.status_code == 500
    # no quiet attribute in TestClass
    assert tc.quiet is None

    # decorator with decorator

# Generated at 2022-06-24 03:39:49.780328
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("No more data", None)
    except ContentRangeError as  e:
        pass

# Generated at 2022-06-24 03:40:01.069650
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm=None)
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Basic"}
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area",
                           qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401

# Generated at 2022-06-24 03:40:09.064951
# Unit test for function abort
def test_abort():
    from sanic.response import text

    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.message == STATUS_CODES[e.status_code].decode("utf8")
        assert isinstance(e.get_response(), text)

    try:
        abort(418)
    except SanicException as e:
        assert e.status_code == 418
        assert e.message == STATUS_CODES[e.status_code].decode("utf8")
        assert isinstance(e.get_response(), text)

    try:
        abort(405, "custom message")
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.message == "custom message"

# Generated at 2022-06-24 03:40:14.920422
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_limit = 123
    err = PayloadTooLarge(
        message="The payload is too large",
        payload_limit=payload_limit)
    assert err.message == "The payload is too large"
    assert err.status_code == 413
    assert err.payload_limit == 123

# Generated at 2022-06-24 03:40:16.767142
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(TypeError):
        content_range = 'bytes */1234'
        raise InvalidRangeType("12345", content_range)

# Generated at 2022-06-24 03:40:20.750270
# Unit test for constructor of class NotFound
def test_NotFound():
    NotFound(message="404 Not Found", status_code=404, quiet=True)



# Generated at 2022-06-24 03:40:22.928297
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except Exception as e:
        assert isinstance(e, NotFound)
        assert e.status_code == 404

# Generated at 2022-06-24 03:40:25.092270
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("message", status_code=500)
    assert err.message == "message"
    assert err.status_code == 500
    assert err.quiet == True


# Generated at 2022-06-24 03:40:27.273772
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="m", status_code=503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
    except Exception as e:
        raise e

# Generated at 2022-06-24 03:40:30.306556
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hdr = HeaderNotFound("HeaderNotFound", "test", "test1")
    print(hdr.message)
    print(hdr.status_code)
    print(hdr.quiet)
    print(hdr.path)
    print(hdr.relative_url)


# Generated at 2022-06-24 03:40:34.191467
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as e:
        raise InvalidSignal("Invalid Signal", status_code=412)
    assert e.type is InvalidSignal

# Generated at 2022-06-24 03:40:37.200282
# Unit test for function abort
def test_abort():
    try:
        abort(404, "Not Found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Not Found"


# Generated at 2022-06-24 03:40:40.132286
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Server is unavailable")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Server is unavailable"


# Generated at 2022-06-24 03:40:46.582529
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Not Found"

# Generated at 2022-06-24 03:40:50.355402
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method_not_supported = MethodNotSupported("POST", ["GET", "PUT"])
    assert method_not_supported.headers == {"Allow": "GET, PUT"}

# Generated at 2022-06-24 03:40:52.514464
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h = HeaderExpectationFailed("Test")
    assert h.status_code == 417


# Generated at 2022-06-24 03:40:56.171973
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = "It's a good range."
    start = 10
    stop = 20
    total = 100

    range_ = Range(start, stop, total)
    error = ContentRangeError(message=msg, content_range=range_)
    assert error.message == msg
    assert error.headers == {'Content-Range': 'bytes */100'}

# Generated at 2022-06-24 03:40:59.016448
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError(message="ServerError", status_code=500)
    assert err.message == "ServerError"
    assert err.status_code == 500



# Generated at 2022-06-24 03:41:01.799542
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("test_msg")
    assert url_build_error.args == ("test_msg",)
    assert url_build_error.status_code == 500


# Generated at 2022-06-24 03:41:07.871637
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test all permutations of kwargs to ensure proper format of WWW-Authenticate header
    raise Unauthorized(message="Authentication required.", scheme="Basic", realm="Restricted Area")
    raise Unauthorized(message="Authentication required.", scheme="Digest", realm="Restricted Area", qop="auth", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    raise Unauthorized(message="Authentication required.", scheme="Bearer", realm="Restricted Area")
    raise Unauthorized(message="Authentication required.", scheme="Bearer")

# Generated at 2022-06-24 03:41:11.130528
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('testing error')
        assert False
    except ServiceUnavailable as e:
        assert e.message == 'testing error'
        assert e.status_code == 503


# Generated at 2022-06-24 03:41:15.280689
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("file not found", "path", "url")
    assert file_not_found.quiet is True
    assert file_not_found.path == "path"
    assert file_not_found.relative_url == "url"

# Generated at 2022-06-24 03:41:22.259357
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Test with file path that doesn't exist
    try:
        raise PyFileError("abc")
    except PyFileError:
        pass
    # Test with file path that exist
    try:
        raise PyFileError("./requirements.txt")
    except PyFileError:
        pass


# Generated at 2022-06-24 03:41:29.095903
# Unit test for constructor of class FileNotFound
def test_FileNotFound():

    root_dir = os.getcwd()
    test_dir = os.path.join(root_dir, "tests")

    # Constructor of class FileNotFound
    def test_FileNotFound_1():
        filename = "test01.txt"
        filename_path = os.path.join(test_dir, filename)
        relative_url = "/test01.txt"
        with pytest.raises(
            FileNotFound,
            match=f"FileNotFound: {filename_path} not found",
        ):
            raise FileNotFound(
                f"File {filename_path} not found",
                filename_path,
                relative_url,
            )
    test_FileNotFound_1()

# Generated at 2022-06-24 03:41:34.493618
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('some message')
    except HeaderNotFound as inst:
        assert inst.args[0] == 'some message'
        assert inst.status_code == 400
    except Exception as inst:
        assert inst.args[0] == 'some message'
        assert inst.status_code == 400

# Generated at 2022-06-24 03:41:37.398723
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    err = ContentRangeError(message="error", content_range=None)
    assert err.args == ("error",)
    assert err.headers == {"Content-Range": f"bytes */None"}

# Generated at 2022-06-24 03:41:44.772507
# Unit test for constructor of class SanicException
def test_SanicException():
    # type: () -> None
    try:
        raise SanicException("oops", status_code=500, quiet=True)
    except SanicException as se:
        assert se.__str__() == 'oops'
        assert se.quiet == True
    try:
        raise SanicException("oops")
    except SanicException as se:
        assert se.status_code == 500
        assert se.quiet == True

# Generated at 2022-06-24 03:41:48.641816
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Check that the class FileNotFound is properly created.
    try:
        raise FileNotFound("message", "path", "relative_url")
    except FileNotFound as exception:
        assert exception.path == "path"
        assert exception.relative_url == "relative_url"
        assert exception.status_code == 404
    else:
        raise Exception("Expected FileNotFound!")

# Generated at 2022-06-24 03:41:50.121411
# Unit test for constructor of class SanicException
def test_SanicException():
    se = SanicException('testing message')
    assert se.message == 'testing message'



# Generated at 2022-06-24 03:41:51.340836
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    a = HeaderNotFound('ttt', '')
    print(a)


# Generated at 2022-06-24 03:41:54.060609
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge('hello world')
    assert payload_too_large.status_code == 413


# Generated at 2022-06-24 03:41:57.129312
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("test.py").args[0] == "could not execute config file test.py"

# Generated at 2022-06-24 03:42:04.816868
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        print(e)
        assert e.status_code == 404
        assert e.message == 'Not Found'
        assert 'quiet' not in e.__dict__
    except Exception as e:
        raise e

    try:
        abort(500)
    except ServerError as e:
        print(e)
        assert e.status_code == 500
        assert e.message == 'Internal Server Error'
        assert 'quiet' not in e.__dict__
    except Exception as e:
        raise e

# Generated at 2022-06-24 03:42:07.031829
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    result = HeaderExpectationFailed("This is an expected error", status_code=417)
    assert result.status_code == 417

# Generated at 2022-06-24 03:42:10.889456
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # arrange
    exception = "The server is currently unavailable."
    status = 503
    with pytest.raises(Exception) as e:
        # act
        raise ServiceUnavailable(exception, status_code=status)
        # assert
        assert e.status == status
        assert e.message == exception
        assert e.headers is None

# Generated at 2022-06-24 03:42:12.631193
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except LoadFileException as exception:
        assert exception.status_code == 500



# Generated at 2022-06-24 03:42:15.461007
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('hello', status_code=403)
    except Forbidden as f:
        assert f.status_code == 403
        assert str(f) == 'hello'

# Generated at 2022-06-24 03:42:24.396503
# Unit test for function abort
def test_abort():
    from sanic.exceptions import abort
    from sanic.response import HTTPResponse

    # Check if Status Code is being set
    try:
        abort(404)
    except HTTPResponse as e:
        assert e.status == 404
        assert e.body == b"Not found"

    # Check if message is being set
    try:
        abort(404, "This is not a valid route.")
    except HTTPResponse as e:
        assert e.status == 404
        assert e.body == b"This is not a valid route."

# Generated at 2022-06-24 03:42:28.529162
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("FOO")
    except SanicException as e:
        assert e.status_code == 500
        assert str(e) == "FOO"
        assert e.message == "FOO"


# Generated at 2022-06-24 03:42:32.100824
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError
    except Exception as e:
        assert type(e) is URLBuildError
        assert type(e) is ServerError


# Generated at 2022-06-24 03:42:39.206824
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exc = MethodNotSupported('This method is not supported', 'POST', [])
    assert exc.headers['Allow'] == ''

    exc = MethodNotSupported('This method is not supported', 'POST', ['OPTIONS'])
    assert exc.headers['Allow'] == 'OPTIONS'

    exc = MethodNotSupported('This method is not supported', 'POST', ['GET', 'POST'])
    assert exc.headers['Allow'] == 'GET, POST'

    print('MethodNotSupported pass')
    

# Generated at 2022-06-24 03:42:42.212813
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('invalid usage')
    except InvalidUsage as e:
        assert type(e) == InvalidUsage
        assert str(e) == 'invalid usage'
        assert e.status_code == 400

# Generated at 2022-06-24 03:42:45.485423
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("header not found")
    except HeaderNotFound as e:
        assert isinstance(e, SanicException)
        assert isinstance(e, InvalidUsage)
        assert e.status_code == 400

# Generated at 2022-06-24 03:42:49.145030
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Test")
    except Forbidden as e:
        assert e.message == "Test"
        assert e.status_code == 403
    except:
        assert False


# Generated at 2022-06-24 03:42:54.766506
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("An error occurred while reading file.")
    except LoadFileException as e:
        assert str(e) == "An error occurred while reading file."


# Test for status_code, message and quiet parameters of constructor of class SanicException

# Generated at 2022-06-24 03:42:56.905946
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError) as ex:
        raise ServerError("self test")
    assert str(ex.value) == "self test"

# Generated at 2022-06-24 03:43:06.095610
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    assert isinstance(excinfo.value.headers, dict)
    assert excinfo.value.message == "Auth required."
    assert excinfo.value.status_code == 401
    assert excinfo.value.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")

# Generated at 2022-06-24 03:43:08.662892
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout")
    except SanicException:
        pass

# Generated at 2022-06-24 03:43:12.225876
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_object = PayloadTooLarge(message='Message', status_code=413, quiet=True)
    assert test_object.message == 'Message'
    assert test_object.status_code == 413
    assert test_object.quiet == True


# Generated at 2022-06-24 03:43:17.508985
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported("Test Exception", "POST", ["POST", "GET"])
    assert exception.headers == {"Allow": "POST, GET"}
    exception = MethodNotSupported("Test Exception", "POST", ["POST", "GET", "PUT"])
    assert exception.headers == {"Allow": "POST, GET, PUT"}
    exception = MethodNotSupported("Test Exception", "POST", [])
    assert exception.headers == {"Allow": ""}

# Generated at 2022-06-24 03:43:21.767115
# Unit test for constructor of class NotFound
def test_NotFound():
	# Create instance of class NotFound.
	exception = NotFound('This is a test message.', 404, False)
	# Check message.
	print(exception.message)
	assert(exception.message=='This is a test message.')
	# Check status code.
	assert(exception.status_code==404)
	# Check quiet.
	assert(exception.quiet==False)


# Generated at 2022-06-24 03:43:26.319340
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable()
    except ServiceUnavailable as e:
        assert (e.message is None)
        assert (e.status_code == 503)
        assert (e.quiet == True)

# Generated at 2022-06-24 03:43:34.317831
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise SanicException("message", status_code=400, quiet = True)
    except SanicException:
        # assertions for the exception attributes
        assert SanicException.status_code == 400
        assert SanicException.quiet == True

    try:
        raise SanicException(message="message", status_code=500)
    except SanicException:
        # assertions for the exception attributes
        assert SanicException.status_code == 500
        assert SanicException.quiet == False

# Generated at 2022-06-24 03:43:37.897678
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_obj = PayloadTooLarge("test_message", "Test_value")
    assert test_obj.message == "test_message"
    assert test_obj.headers["Content-Range"] == "bytes */Test_value"
    assert test_obj.headers == {"Content-Range": "bytes */Test_value"}

# Generated at 2022-06-24 03:43:48.006828
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError('Exception','[0,0]')
    if a.message=='Exception' and a.headers['Content-Range']=='bytes */[0,0]':
        print('TestCase1_Success')
    else:
        print('TestCase1_Failure')

    b = ContentRangeError('Exception',[0,0])
    if b.message=='Exception' and b.headers['Content-Range']=='bytes */0':
        print('TestCase2_Success')
    else:
        print('TestCase2_Failure')

    # Unit test for exception of constructor of class ContentRangeError
    try:
        c = ContentRangeError('Exception',None)
    except TypeError:
        print('TestCase3_Success')
    else:
        print('TestCase3_Failure')


# Generated at 2022-06-24 03:43:52.491719
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req = RequestTimeout("Request Timeout", 408)
    assert req.message == 'Request Timeout' and req.status_code == 408


# Generated at 2022-06-24 03:43:54.253366
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("timeout")


# Generated at 2022-06-24 03:43:58.431866
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        with open("test_class_LoadFileException.txt","r") as f:
            file_content = f.read()
    except IOError:
        raise LoadFileException("File not found")


# Generated at 2022-06-24 03:44:01.228424
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    Message = 'Test'
    try:
        raise HeaderNotFound(Message)
    except Exception as e:
        if e.args[0] != Message:
            return False
    return True


# Generated at 2022-06-24 03:44:05.608539
# Unit test for function abort
def test_abort():
    try:
        abort(400)
        assert False
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"

    try:
        abort(402, "Custom Status")
        assert False
    except InvalidUsage as e:
        assert e.status_code == 402
        assert e.message == "Custom Status"

# Generated at 2022-06-24 03:44:11.196962
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Test for constructor of InvalidRangeType,
    # assert the value of self.message, self.status_code, self.headers
    content_range = ContentRange(2, 3)
    error = InvalidRangeType('message', content_range)
    assert error.status_code == 416
    assert error.message == 'message'
    assert error.headers['Content-Range'] == 'bytes */3'



# Generated at 2022-06-24 03:44:13.947009
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found_exception = NotFound("Not found")
    assert not_found_exception.status_code == 404



# Generated at 2022-06-24 03:44:15.914975
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    headers = HeaderNotFound("header not found")
    assert headers.status_code == 400
    assert headers.message == "header not found"

# Generated at 2022-06-24 03:44:24.993895
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Create a FileNotFound instance with no parameters
    assert FileNotFound() == "expected message"
    # Create a FileNotFound instance with only a message
    assert FileNotFound("expected message") == "expected message"
    # Create a FileNotFound instance with message and path
    assert FileNotFound("expected message", "/vagrant_data/Sanic/sanic/tests.py") == "expected message"
    # Create a FileNotFound instance with message, path and relative url
    assert FileNotFound("expected message", "/vagrant_data/Sanic/sanic/tests.py", "test_exceptions.py") == "expected message"


# Generated at 2022-06-24 03:44:31.512775
# Unit test for constructor of class Forbidden
def test_Forbidden():
    msg = "This is an exception"
    status_code = 403
    f = Forbidden(msg, status_code)
    assert f.message == msg
    assert f.status_code == status_code
    assert f.quiet == True


if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-24 03:44:33.237562
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as e:
        raise HeaderNotFound("POST")
    assert e.value.status_code == 400

# Generated at 2022-06-24 03:44:38.945422
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert  ServiceUnavailable(message="test",status_code=503) is not None
    assert ServiceUnavailable(message="test", status_code=503).status_code == 503


# Generated at 2022-06-24 03:44:42.745641
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed('test')
    assert exception.status_code == 417
    assert exception.message == 'test'


# Generated at 2022-06-24 03:44:45.123088
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test")
    except ServerError as e:
        assert e.args[0] == "test"



# Generated at 2022-06-24 03:44:47.031442
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("error")
    assert url_build_error.args[0] == "error"

# Generated at 2022-06-24 03:44:51.795575
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('This is an error message', status_code=500)
    except LoadFileException as e:
        assert str(e) == 'This is an error message'
        assert e.status_code == 500

if __name__ == '__main__':
    test_LoadFileException()

# Generated at 2022-06-24 03:44:54.029332
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException()

# Generated at 2022-06-24 03:44:55.890109
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage('something error')



# Generated at 2022-06-24 03:44:59.884833
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exception = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert exception.headers == {
        "WWW-Authenticate": 'Basic realm="Restricted Area"'}
    assert exception.status_code == 401
    assert str(exception) == "Auth required."

# Generated at 2022-06-24 03:45:02.082353
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("message")
    except HeaderExpectationFailed as e:
        assert e.message == "message"

# Generated at 2022-06-24 03:45:03.657321
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    m = "hello"
    cr = 1
    ir = InvalidRangeType(m, cr)

# Generated at 2022-06-24 03:45:05.906024
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Service Unavailable")
    except SanicException as se:
        assert se.status_code == 503
        assert se.message == "Service Unavailable"
        assert se.quiet == True
    else:
        raise Exception("Test case failed")


# Generated at 2022-06-24 03:45:09.681917
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal


# Generated at 2022-06-24 03:45:12.154899
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge("message")
    # Test exception message
    assert "message" == str(exception)
    # Test exception status code
    assert 413 == exception.status_code

# Generated at 2022-06-24 03:45:14.198824
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    from app.exceptions import HeaderNotFound
    hnf_test = HeaderNotFound("test message")
    assert hnf_test

# Generated at 2022-06-24 03:45:21.443717
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    """
    Test the constructor of class FileNotFound
    """
    assert FileNotFound("File Not Found", "/test.txt", "../test.txt").message == "File Not Found"
    assert FileNotFound("File Not Found", "/test.txt", "../test.txt").path == "/test.txt"
    assert FileNotFound("File Not Found", "/test.txt", "../test.txt").relative_url == "../test.txt"


# Generated at 2022-06-24 03:45:24.396797
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    msg = "invalid range type"
    expected = "invalid range type"
    try:
        raise InvalidRangeType(msg, 20)
    except InvalidRangeType as e:
        assert e.args[0] == expected

# Generated at 2022-06-24 03:45:29.515316
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(ContentRangeError) as excinfo:
        raise InvalidRangeType('invalid range type')
    assert 'invalid range type' in str(excinfo.value)

# Generated at 2022-06-24 03:45:33.132837
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Message", 1)
    except ContentRangeError as e:
        assert e.status_code == 416
        assert e.message == "Message"


# Generated at 2022-06-24 03:45:35.065947
# Unit test for constructor of class ServerError
def test_ServerError():
    assert ServerError("Test Server Error", 412)


# Generated at 2022-06-24 03:45:37.448690
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="filepath")
    except LoadFileException:
        pass


# Generated at 2022-06-24 03:45:38.870481
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("test")
    assert err.args[0] == "test"

# Generated at 2022-06-24 03:45:39.915020
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert URLBuildError("The internal server error")

# Generated at 2022-06-24 03:45:42.976409
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("test")
    except Exception as e:
        assert e.__class__.__name__ == "HeaderExpectationFailed"



# Generated at 2022-06-24 03:45:45.342309
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "message"
    h = HeaderExpectationFailed(message)
    assert h.message == message
    assert h.status_code == 417

# Generated at 2022-06-24 03:45:47.335450
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    test_Exception = InvalidSignal("test_message")
    assert test_Exception.args[0] == "test_message"

# Generated at 2022-06-24 03:45:53.310030
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("service is down due to unexpected reasons")
    except ServiceUnavailable as e:
        assert e.message == "service is down due to unexpected reasons"
        assert e.status_code == 503
        assert e.__traceback__ is not None
        assert not e.quiet
    else:
        assert False  # should never reach this line



# Generated at 2022-06-24 03:45:59.782616
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(Exception) as e_info:
        with PyFileError(file=None):
            raise PyFileError(file=None)
    assert e_info.value.args[0] == 'could not execute config file %s'


# Generated at 2022-06-24 03:46:04.265264
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError('this is a message', 200)
    assert cr.status_code == 416
    assert cr.msg == 'this is a message'
    assert cr.headers['Content-Range'] == 'bytes */200'
    assert cr.to_dict() == {'message': 'this is a message'}


# Generated at 2022-06-24 03:46:09.168275
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    from sanic.exceptions import HeaderNotFound
    new_HeaderNotFound= HeaderNotFound(message='Invalid header', status_code=400, quiet=True)
    assert new_HeaderNotFound.__repr__() == '<HeaderNotFound: Invalid>'


# Generated at 2022-06-24 03:46:10.934045
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed_obj = HeaderExpectationFailed(message="")

# Generated at 2022-06-24 03:46:12.971859
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    test = URLBuildError("bad url path")
    assert test,"URLBuildError: bad url path"

# Generated at 2022-06-24 03:46:18.622624
# Unit test for constructor of class SanicException
def test_SanicException():
    msg = "hello world"
    try:
        raise SanicException(message=msg, status_code=400)
    except SanicException as sie:
        assert sie.message == msg
        assert sie.status_code == 400
        assert isinstance(sie, SanicException)
    else:
        assert False


# Unit tests for constructors of class SanicException

# Generated at 2022-06-24 03:46:21.384130
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert RequestTimeout(message="Timeout!", status_code=408).status_code == 408
    assert RequestTimeout(message="Timeout!").status_code == 408

# Generated at 2022-06-24 03:46:22.096817
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    abort(417)

# Generated at 2022-06-24 03:46:25.322078
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType('a')
    assert len(invalid_range_type.__dict__) == 1
    assert invalid_range_type.args[0] == 'a'

# Generated at 2022-06-24 03:46:28.128502
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = 'unit test for PyFileError'
    fileError = PyFileError(file)
    assert fileError.args[0] == 'could not execute config file %s'
    assert fileError.args[1] == file

# Generated at 2022-06-24 03:46:31.242201
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception = Forbidden('Test', 403)
    assert exception.status_code == 403
    assert exception.message == 'Test'
    assert exception.headers == {}

# Generated at 2022-06-24 03:46:33.626302
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout("408 Request Timeout Error")
    assert request_timeout.status_code == 408
    assert request_timeout.quiet

# Generated at 2022-06-24 03:46:43.388329
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
        assert e.message == "Auth required."
        assert e.status_code == 401


# Generated at 2022-06-24 03:46:46.743194
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test Service Unavailable.")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.quiet == True


# Generated at 2022-06-24 03:46:50.269076
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(421)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[421] == TestException
    assert _sanic_exceptions[421]().status_code == TestException().status_code
    assert TestException().status_code == 421


# Generated at 2022-06-24 03:46:53.790208
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    HeaderExpectationFailed("Testing", status_code = 417)
    #assert isinstance(self.cls, HeaderExpectationFailed)


# Generated at 2022-06-24 03:46:56.205770
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError):
        raise URLBuildError("foo")

# Generated at 2022-06-24 03:47:00.011072
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(
            "Test InvalidRangeType", content_range=ContentRange(10, 0, 100)
        )
    except InvalidRangeType as e:
        assert e.status_code == 416

# Generated at 2022-06-24 03:47:01.942817
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    err = ServiceUnavailable("Service Unavailable")
    assert err.status_code == 503


# Generated at 2022-06-24 03:47:06.614288
# Unit test for function add_status_code
def test_add_status_code():
    """
    Ensure that status code added to _sanic_exceptions with appropriate values
    """
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-24 03:47:10.786114
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('POST', ('GET', 'HEAD'))
    except MethodNotSupported as e:
        assert e.headers == {'Allow': 'GET, HEAD'}
    try:
        raise MethodNotSupported('POST', ('GET', 'HEAD', 'OPTIONS'))
    except MethodNotSupported as e:
        assert e.headers == {'Allow': 'GET, HEAD, OPTIONS'}

# Generated at 2022-06-24 03:47:13.991269
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
  try:
    raise InvalidRangeType()
  except InvalidRangeType as err:
    assert err.__cause__ is None
    assert issubclass(err.__class__, InvalidRangeType)
