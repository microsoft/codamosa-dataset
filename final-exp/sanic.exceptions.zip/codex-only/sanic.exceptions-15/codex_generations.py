

# Generated at 2022-06-24 03:37:27.027934
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    assert FileNotFound("msg", "path", "relative_url").message == "msg"
    assert FileNotFound("msg", "path", "relative_url").path == "path"
    assert FileNotFound("msg", "path", "relative_url").relative_url == "relative_url"


# Generated at 2022-06-24 03:37:35.679444
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present:
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        print(e.headers)

    # With a Digest auth-scheme, things are a bit more complicated:
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        print(e.headers)

    # With a Bearer auth-scheme, realm is optional so you can write:

# Generated at 2022-06-24 03:37:39.929988
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported(
            "messaage",
            method="method",
            allowed_methods=["a", "b", "c"]
        )
    except SanicException as e:
        assert e.headers == {"Allow": "a, b, c"}
        assert e.status_code == 405


# Generated at 2022-06-24 03:37:43.646522
# Unit test for constructor of class ServerError
def test_ServerError():
    """
    The following test case aims to test the constructor of class ServerError
    It should not throw any exception
    """
    try:
        raise ServerError
    except ServerError:
        pass

# Generated at 2022-06-24 03:37:47.470677
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Test", "GET", ["POST"])
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "POST"}
    else:
        assert False



# Generated at 2022-06-24 03:37:49.604430
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    t = RequestTimeout("server timed out", 408)
    assert t.status_code == 408
    assert t.message == "server timed out"

# Generated at 2022-06-24 03:37:54.299845
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found_object = HeaderNotFound('"Accept" header not found.')
    assert isinstance(header_not_found_object, InvalidUsage)
    assert header_not_found_object.status_code == 400


# Generated at 2022-06-24 03:37:57.421026
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    Unit test the constructor of class RequestTimeout
    :return: None
    """
    try:
        raise RequestTimeout("Exception: The request has timed out")
    except Exception as e:
        assert e.status_code == 408
        assert e.message == "Exception: The request has timed out"

# Generated at 2022-06-24 03:38:06.333156
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as exc_info:
        abort(404)
    assert exc_info.value.status_code == 404
    assert exc_info.value.message == "Not Found"

    with pytest.raises(NotFound) as exc_info:
        abort(404, "Not here")
    assert exc_info.value.status_code == 404
    assert exc_info.value.message == "Not here"

    with pytest.raises(ServerError) as exc_info:
        abort(500, "Something broke")
    assert exc_info.value.status_code == 500
    assert exc_info.value.message == "Something broke"

# Generated at 2022-06-24 03:38:11.505850
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = 'Method Not Allowed'
    method = 'GET'
    allowed_methods = ['POST', 'DELETE']
    meth = MethodNotSupported(message,method,allowed_methods)
    assert meth.message == message
    assert meth.headers['Allow'] == ", ".join(allowed_methods)


# Generated at 2022-06-24 03:38:13.130738
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert 'Range Not Satisfiable' == InvalidRangeType('a',1).message

# Generated at 2022-06-24 03:38:15.481338
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    load_file_exception = LoadFileException("json load faild")
    assert load_file_exception.message == "json load faild"

# Generated at 2022-06-24 03:38:27.448478
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as ex:
        raise MethodNotSupported(message="This is a mock error message",
                                 method='GET',
                                 allowed_methods=["GET", "HEAD"])
    assert ex.value.status_code == 405
    assert ex.value.args == ("This is a mock error message",)
    assert ex.value.headers == {'Allow': 'GET, HEAD'}

    with pytest.raises(MethodNotSupported) as ex:
        raise MethodNotSupported(message="This is a mock error message",
                                 method='POST',
                                 allowed_methods=["GET", "HEAD"])
    assert ex.value.status_code == 405
    assert ex.value.args == ("This is a mock error message",)

# Generated at 2022-06-24 03:38:31.335518
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test_exception = MethodNotSupported("test", "test", "test")
    assert 'test' == test_exception.message
    assert 'text/plain' == test_exception.content_type
    assert 'test' == test_exception.headers["Allow"]

# Generated at 2022-06-24 03:38:37.531761
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge(message="foobar")
    except PayloadTooLarge as e:
        assert e.message == "foobar"
        assert e.status_code == 413
        assert repr(e) == "PayloadTooLarge(message='foobar', status_code=413)"
        assert str(e) == "foobar"
    else:
        assert False


# Generated at 2022-06-24 03:38:40.870037
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid_usage_test = InvalidUsage("invalid usage test", None, None)
    assert invalid_usage_test.message == "invalid usage test"
    assert invalid_usage_test.status_code == 400
    assert invalid_usage_test.quiet == True

# Generated at 2022-06-24 03:38:44.354167
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    expected = 408
    msg = "Request Timeout"
    r = RequestTimeout(message=msg, status_code=expected)
    assert r.status_code == expected
    assert r.strerror == msg
    assert str(r) == msg

# Generated at 2022-06-24 03:38:52.766909
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    from sanic.response import text

    def app_exception(request):
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")

    @app_exception.exception(Unauthorized)
    async def auth_failed(request, exception):
        return text(str(exception), status=exception.status_code)

    _, response = app_exception.test_client.get('/')

    assert response.status == 401
    assert 'WWW-Authenticate' in response.headers

# Generated at 2022-06-24 03:38:55.683488
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass

    add_status_code(TestException.status_code)(TestException)

    assert _sanic_exceptions[TestException.status_code] == TestException

# Generated at 2022-06-24 03:38:58.520763
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    message = "Payload Too Large"
    try:
        abort(413, message)
    except PayloadTooLarge as e:
        assert message in str(e)
        assert e.status_code == 413

# Generated at 2022-06-24 03:39:00.298798
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test = LoadFileException('test')
    assert str(test) == 'test'


# Generated at 2022-06-24 03:39:01.568848
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Hello world!")
    except LoadFileException:
        pass

# Generated at 2022-06-24 03:39:03.322563
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert InvalidRangeType("a","b")


# Generated at 2022-06-24 03:39:15.095390
# Unit test for function add_status_code
def test_add_status_code():
    assert_raises(TypeError, add_status_code, None)
    assert_raises(TypeError, add_status_code, "")
    assert_raises(TypeError, add_status_code, 500, None, None)

    # Wrong add_status_code usage
    assert_raises(
        TypeError, lambda: add_status_code(500, None)(SanicException)
    )
    # Wrong SanicException raise
    assert_raises(
        TypeError,
        lambda: SanicException("message", status_code=0, quiet=None),
    )

    @add_status_code(500, True)
    class MyException(SanicException):
        pass

    @add_status_code(404, False)
    class MyException2(SanicException):
        pass

    assert_equal

# Generated at 2022-06-24 03:39:16.470020
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    message = 'Test ServiceUnavailable'
    exception = ServiceUnavailable(message=message)

    assert exception.message == message
    assert exception.status_code == 503
    assert exception.quiet == True



# Generated at 2022-06-24 03:39:21.617569
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('ok')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.args[0] == 'ok'
        assert e.message == 'ok'
        assert str(e) == 'ok'
        assert e.quiet == True


# Generated at 2022-06-24 03:39:25.388900
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("message", method="post", allowed_methods=['get'])
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "get"}, "Unexpected output"

# Generated at 2022-06-24 03:39:30.336799
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("test message", "test path", "test relative_url")
    assert file_not_found.message == "test message"
    assert file_not_found.path == "test path"
    assert file_not_found.relative_url == "test relative_url"
    assert file_not_found.status_code == 404


# Generated at 2022-06-24 03:39:34.010219
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Arrange
    message = "Auth required."
    exception = Forbidden(message)

    # Act
    result = str(exception)

    # Assert
    assert result == message

if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-24 03:39:35.652936
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
   exception = InvalidUsage("Hello World")
   assert exception.status_code == 400


# Generated at 2022-06-24 03:39:40.740315
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound")
    except HeaderNotFound as e:
        assert isinstance(e, InvalidUsage)
        assert e.status_code == 400
        assert str(e) == "HeaderNotFound"
        assert e.quiet is True


# Generated at 2022-06-24 03:39:45.357392
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("I don't know")
    assert exc.status_code == 417
    assert str(exc) == "I don't know"
    assert exc.headers == {}
    exc = HeaderExpectationFailed("foo", foo='bar')
    assert exc.status_code == 417
    assert exc.headers == {'foo': 'bar'}


# Generated at 2022-06-24 03:39:50.858915
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('test')
    except InvalidSignal as e:
        assert e.status_code == 500
        assert e.message == 'test'

# Generated at 2022-06-24 03:39:52.943697
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden
    assert forbidden.__name__ == "Forbidden"
    assert forbidden.__bases__[0] == SanicException

# Generated at 2022-06-24 03:39:59.063566
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as ex:
        error = ex
    assert error.status_code == 401
    assert error.message == "Auth required."
    assert error.headers["WWW-Authenticate"] == 'Digest algorithm="MD5", qop="auth, auth-int", opaque="zyxwvu", realm="Restricted Area", nonce="abcdef"'



# Generated at 2022-06-24 03:40:03.566064
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    x = None
    try:
        x = InvalidRangeType("Invalid Range Type: xyz", 3)
    except Exception as e:
        assert x is not None and type(x) == InvalidRangeType
        assert x.args[0] == "Invalid Range Type: xyz"
        assert x.status_code == 416
        assert x.content_range == 3
        assert x.headers["Content-Range"] == "bytes */3" 
    assert x is not None and type(x) == InvalidRangeType

# Generated at 2022-06-24 03:40:10.184175
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException('Testing message', 404, False).status_code == 404
    assert SanicException('Testing message', 404, True).status_code == 404
    assert SanicException('Testing message', 404).status_code == 404
    assert SanicException('Testing message', 405, True).status_code == 405
    assert SanicException('Testing message', 500).status_code == 500
    assert SanicException('Testing message', 405, False).status_code == 405
    assert SanicException('Testing message', 500).quiet == True

test_SanicException()

# Generated at 2022-06-24 03:40:13.653603
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("message", "method", "allowed_methods")
    except MethodNotSupported as error:
        assert error.status_code == 405

# Generated at 2022-06-24 03:40:14.817601
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    urlBuildError = URLBuildError('some error')
    assert urlBuildError.status_code == 500
    assert urlBuildError.quiet == True
    assert urlBuildError.args[0] == 'some error'

# Generated at 2022-06-24 03:40:16.997470
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("message")
    assert "message" == exc.args[0]
    assert 417 == exc.status_code
    assert exc.quiet

# Generated at 2022-06-24 03:40:19.084676
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exc = MethodNotSupported('unsupported method', 'GET', ['GET', 'POST'])
    assert exc.headers == {'Allow': 'GET, POST'}

# Generated at 2022-06-24 03:40:21.065131
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('Error message')
    except URLBuildError as e:
        assert str(e) == 'Error message'

# Generated at 2022-06-24 03:40:23.916858
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pfe = PyFileError("abc")
    assert "abc" in repr(pfe)

# Generated at 2022-06-24 03:40:26.158729
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("An error message")
    except InvalidUsage as e:
        assert e.message == "An error message"
        assert e.status_code == 400



# Generated at 2022-06-24 03:40:28.824895
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge('Sorry, I cannot accept more than 10 bytes')
    assert error.message == 'Sorry, I cannot accept more than 10 bytes'
    assert error.status_code == 413
    assert error.quiet == True



# Generated at 2022-06-24 03:40:33.372563
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    To test the constructor of class Unauthorized.
    """
    exception = Unauthorized("something wrong", 401, "Digest")
    assert exception.headers["WWW-Authenticate"] == "Digest"

# Generated at 2022-06-24 03:40:36.829897
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    total = len(list(range(100)))
    exception = ContentRangeError(
        message = 'range not satisfiable', content_range = total)
    assert exception.status_code == 416
    assert exception.message == 'range not satisfiable'
    assert exception.headers == {'Content-Range': 'bytes */100'}

# Generated at 2022-06-24 03:40:40.082112
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    except_obj = InvalidRangeType("message",10)
    assert except_obj.message == "message"
    assert except_obj.headers == {"Content-Range": f"bytes */{10}"}
    assert except_obj.status_code == 416


# Generated at 2022-06-24 03:40:50.297747
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rtmsg = "The Web server (running the Web site) thinks that there has been too" + \
            " long an interval of time between 1) the establishment of an IP" + \
            " connection (socket) between the client and the server and" + \
            " 2) the receipt of any data on that socket, so the server has dropped" + \
            " the connection. The socket connection has actually been lost - the Web" + \
            " server has 'timed out' on that particular socket connection."
    req_timeout = RequestTimeout(rtmsg)
    assert isinstance(req_timeout, SanicException)
    assert isinstance(req_timeout, Exception)
    assert req_timeout.status_code == 408
    assert req_timeout.message == rtmsg
    assert not req_timeout.quiet


# Generated at 2022-06-24 03:40:55.047947
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("test", "path", "relative_url")
    except FileNotFound as fileEx:
        assert fileEx.path == "path"
        assert fileEx.relative_url == "relative_url"
        assert fileEx.status_code == 404
        assert fileEx.message == "test"
    except Exception as exception:
        assert False

# Generated at 2022-06-24 03:41:02.267415
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    a = FileNotFound("File not found")
    assert a.status_code == 404
    assert a.args == ("File not found",)
    assert a.path is None
    assert a.relative_url is None
    b = FileNotFound("File not found", path="a/b/c/d", relative_url="a/b/c/d")
    assert b.path == "a/b/c/d"
    assert b.relative_url == "a/b/c/d"
    # TODO: Test constructor of class ServerError
    # TODO: Test constructor of class ServiceUnavailable
    # TODO: Test constructor of class URLBuildError
    # TODO: Test constructor of class FileNotFound
    # TODO: Test constructor of class RequestTimeout
    # TODO: Test constructor of class PayloadTooLarge
   

# Generated at 2022-06-24 03:41:04.338449
# Unit test for constructor of class NotFound
def test_NotFound():
    # Test for constructor
    N = NotFound('testNotFoundClass')
    assert N.message == 'testNotFoundClass'


# Generated at 2022-06-24 03:41:06.293577
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid_usage = InvalidUsage('test')
    assert invalid_usage.status_code == 400
    assert invalid_usage.message == 'test'

# Generated at 2022-06-24 03:41:10.211321
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Este es un error de prueba")
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Este es un error de prueba"



# Generated at 2022-06-24 03:41:12.970266
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pf = PyFileError("a")
    assert pf.args[0] == "could not execute config file %s"
    assert pf.args[1] == "a"

# Generated at 2022-06-24 03:41:18.965218
# Unit test for function add_status_code
def test_add_status_code():
    def _test_quiet(code, expected_quiet):
        assert add_status_code(code) is add_status_code(code, None)
        assert add_status_code(code).quiet == expected_quiet
        assert add_status_code(code, True).quiet
        assert not add_status_code(code, False).quiet

    _test_quiet(200, True)
    _test_quiet(201, True)
    _test_quiet(500, False)
    _test_quiet(200, True)
    


# Generated at 2022-06-24 03:41:25.198567
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload = 'x' * (1024*1024*1.1)
    try:
        abort(413, payload)
    except PayloadTooLarge as e:
        assert e.status_code == 413
        assert e.message == payload
        assert e.payload == payload
        assert e.__repr__() == "PayloadTooLarge(413, 'x' * (1024*1024*1.1))"



# Generated at 2022-06-24 03:41:30.190221
# Unit test for function abort
def test_abort():
    try:
        abort(404)
        assert False
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == STATUS_CODES[404].decode("utf8")

    try:
        abort(400, "Name too short")
        assert False
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Name too short"

# Generated at 2022-06-24 03:41:33.693432
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    instance = RequestTimeout("This is a test", None, None)
    assert "RequestTimeout" in str(instance)
    assert "This is a test" in str(instance)

# Generated at 2022-06-24 03:41:38.376072
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("You have sent a request without specifying a required header", "HeaderNotFound")
    except Exception as e:       
        assert e.args[0] == "You have sent a request without specifying a required header"
        assert e.args[1] == "HeaderNotFound"
        assert e.status_code == 400


# Generated at 2022-06-24 03:41:41.053775
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exc = ContentRangeError('test message', 'test content_range')
    assert exc.message == 'test message'
    assert exc.content_range == 'test content_range'
    assert 'Content-Range' in exc.headers
    assert exc.headers['Content-Range'] == 'bytes */test content_range'

# Generated at 2022-06-24 03:41:41.625042
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("")


# Generated at 2022-06-24 03:41:43.130242
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as e:
        print(e)

# Generated at 2022-06-24 03:41:46.737817
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    hh=HeaderExpectationFailed("hh", None)
    assert hh.headers =={}

# Generated at 2022-06-24 03:41:53.649997
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except SanicException as se:
        assert se.status_code == 500
        assert se.message == "Internal Server Error"
    try:
        abort(404)
    except NotFound as nf:
        assert nf.status_code == 404
        assert nf.message == "Not Found"

# Generated at 2022-06-24 03:41:57.744028
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url = URLBuildError("Test")
    assert url.message == "Test"
    assert url.status_code == 500
    assert url.quiet == True


# Generated at 2022-06-24 03:42:01.946740
# Unit test for constructor of class NotFound
def test_NotFound():
    NotFound('abc', 404, True)
    NotFound('abc', 404, False)
    NotFound('abc', 404)
    NotFound('abc', None, True)
    NotFound('abc', None, False)
    NotFound('abc', None)


# Generated at 2022-06-24 03:42:13.801570
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    err = Unauthorized('Auth required.', scheme='Basic',
                                   realm='Restricted Area')
    assert err.status_code == 401
    assert err.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'

    err = Unauthorized('Auth required.', scheme='Digest',
                                   realm='Restricted Area',
                                   qop="auth, auth-int",
                                   algorithm="MD5",
                                   nonce="abcdef",
                                   opaque="zyxwvu")
    assert err.status_code == 401
    assert err.headers['WWW-Authenticate'] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

    err = Unauthorized('Auth required.', scheme='Bearer')
    assert err

# Generated at 2022-06-24 03:42:16.522597
# Unit test for constructor of class PyFileError
def test_PyFileError():
  try:
    file = "file"
    raise PyFileError(file)
  except PyFileError as e:
    assert e.args[0] == "could not execute config file file"

# Generated at 2022-06-24 03:42:20.869034
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        filename = "file.txt"
        raise FileNotFound('File not found' + filename, filename, '')
    except FileNotFound as e:
        assert e.path == filename
        assert e.relative_url == ''

# Generated at 2022-06-24 03:42:30.567373
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound("Not found").status_code == 404
    assert NotFound("Not found", status_code=404).status_code == 404
    assert NotFound("Not found", status_code=500).status_code == 500
    assert NotFound("Not found", quiet=True).quiet is True
    assert NotFound("Not found", quiet=False).quiet is False
    assert NotFound("Not found", quiet=None).quiet is False
    assert NotFound("Not found", status_code=500, quiet=None).quiet is False
    assert NotFound("Not found", status_code=500, quiet=False).quiet is False
    assert NotFound("Not found", status_code=500, quiet=True).quiet is True
    assert NotFound("Not found", status_code=501, quiet=False).quiet is True


# Generated at 2022-06-24 03:42:33.371106
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class Foo(SanicException):
        pass
    assert Foo().status_code == 999
    @add_status_code(1000)
    class Foo(SanicException):
        pass
    assert Foo().status_code == 1000
    assert Foo.quiet is True


# Generated at 2022-06-24 03:42:36.623838
# Unit test for constructor of class SanicException
def test_SanicException():
    from sanic.exceptions import SanicException
    test_obj = SanicException(message='hello world')
    assert test_obj.args[0] == 'hello world'

# Generated at 2022-06-24 03:42:40.295858
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    _test_exception = ServiceUnavailable("test", 503)
    assert _test_exception.status_code == 503
    assert _test_exception.message == "test"
    assert _test_exception.quiet is True


# Generated at 2022-06-24 03:42:43.912806
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    print("test_RequestTimeout: begin")
    with pytest.raises(RequestTimeout) as excinfo:
        raise RequestTimeout("Timeout")
    print(excinfo.value)
    print("test_RequestTimeout: end")

if __name__=="__main__":
    test_RequestTimeout()

# Generated at 2022-06-24 03:42:48.374519
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('test message')
    except HeaderNotFound as err:
        assert err.message == 'test message'
        assert isinstance(err, SanicException)
        assert isinstance(err, InvalidUsage)
        assert err.status_code == 400

# Generated at 2022-06-24 03:42:50.946496
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('test')
    except URLBuildError as exc:
        assert exc.status_code == 500


# Generated at 2022-06-24 03:42:54.465463
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('Foo')
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert str(e) == 'Foo'



# Generated at 2022-06-24 03:42:57.018615
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError('message', 5)
    assert a.headers['Content-Range'] == 'bytes */5'

# Generated at 2022-06-24 03:43:00.682442
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exception = ContentRangeError(message="Error message", content_range=None)
    assert exception.message is "Error message"
    assert exception.status_code is 416
    assert exception.headers is {"Content-Range": "bytes */None"}

# Generated at 2022-06-24 03:43:03.551479
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge('size exceeds limit')
    assert exception.message == 'size exceeds limit'
    assert exception.status_code == 400
    assert exception.quiet == True


# Generated at 2022-06-24 03:43:13.714467
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet is True
    assert _sanic_exceptions[405].status_code == 405
    assert _sanic_exceptions[405].quiet is True
    assert _sanic_exceptions[400].status_code == 400
    assert _sanic_exceptions[400].quiet is True
    assert _sanic_exceptions[500].status_code == 500
    assert _sanic_exceptions[500].quiet is False
    assert _sanic_exceptions[503].status_code == 503
    assert _sanic_exceptions[503].quiet is True

# Generated at 2022-06-24 03:43:17.343846
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = "/test"
    relative_url = "test/url"
    msg = "test msg"
    exception = FileNotFound(msg, path, relative_url)

    assert exception.message == msg
    assert exception.path == path
    assert exception.relative_url == relative_url
    assert exception.quiet == True
    assert exception.status_code == 404

# Generated at 2022-06-24 03:43:21.023176
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('错误提示', status_code=400, quiet=True)
    except SanicException as e:
        print(e)
        print(e.status_code)
        print(e.quiet)
        print(e.__dict__)


# Generated at 2022-06-24 03:43:28.667457
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    def test(total: bytes, message: bytes):
        err = ContentRangeError(
            message=message,
            content_range=ContentRange(start=None, stop=None, total=total)
        )
        err_msg = "bytes */{!s}".format(total)
        assert (err.headers["Content-Range"] == err_msg)

    test(total=42, message=b"hello")
    test(total=3, message=b"")
    test(total=4.2, message=b"yo")



# Generated at 2022-06-24 03:43:31.038445
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert isinstance(Forbidden("this is forbidden"), Forbidden)

# Generated at 2022-06-24 03:43:33.495454
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # Test constructor without parameters
    service_unavailable_obj = ServiceUnavailable()
    assert service_unavailable_obj.status_code == 503

# Generated at 2022-06-24 03:43:37.091146
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Invalid usage")
    except SanicException as e:
        assert str(e) == "Invalid usage"
        assert e.status_code is None


# Generated at 2022-06-24 03:43:39.076373
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('aaa')
    except LoadFileException as e:
        assert e.message == 'aaa'

# Generated at 2022-06-24 03:43:44.171204
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable("Test message")
    assert type(exception) is ServiceUnavailable
    assert exception.status_code == 503
    assert exception.args == ("Test message",)
    expected_str = "<ServiceUnavailable: 503: Test message>"
    assert str(exception) == expected_str

# Generated at 2022-06-24 03:43:48.023335
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    iu = InvalidUsage('I am an InvalidUsage message.')
    assert(str(iu) == 'I am an InvalidUsage message.')
    try:
        iu = InvalidUsage('I am an InvalidUsage message.', status_code=404)
        assert 0, 'AssertionError should be raised'
    except AssertionError:
        assert 1

# Unit tets for add_status_code()

# Generated at 2022-06-24 03:43:51.456187
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    InvalidUsage("A fake exception for the unit test", status_code=600)

# Generated at 2022-06-24 03:43:54.741486
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound(message = "Not found", status_code = 404, quiet = True)
    assert not_found.message == "Not found" and not_found.status_code == 404 and not_found.quiet == True


# Generated at 2022-06-24 03:44:00.335806
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as excinfo:
        raise MethodNotSupported("msg", 'method', ['GET', 'POST'])
    assert "msg" in str(excinfo.value)
    assert excinfo.value.status_code == 405
    assert excinfo.value.headers['Allow'] == "GET, POST"


# Generated at 2022-06-24 03:44:04.606563
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        exception = MethodNotSupported("Method Not Supported", "GET", ["GET", "POST"])
        assert exception.status_code == 405
        assert exception.message == "Method Not Supported"
        assert exception.headers == {"Allow": "GET, POST"}
    except Exception as e:
        assert False
    

# Generated at 2022-06-24 03:44:08.655636
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Message')
    except ServerError as e:
        assert e.message == 'Message'
        assert e.status_code == 500
        assert e.__str__() == 'Message'


# Generated at 2022-06-24 03:44:09.959632
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    class_FileNotFound_instance = Fi

# Generated at 2022-06-24 03:44:12.954932
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Passing test")
    except ServiceUnavailable as e:
        print("Exception:", e)


# Generated at 2022-06-24 03:44:14.476702
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("")
    assert type(e) == URLBuildError


# Generated at 2022-06-24 03:44:16.431696
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge
    except Exception as exc:
        assert(str(exc) == 'Request body is too large')


# Generated at 2022-06-24 03:44:24.066363
# Unit test for function abort
def test_abort():
    """
    Unit test of function abort
    """
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    try:
        abort(403, "abort")
    except Forbidden as e:
        assert e.status_code == 403
        assert e.message == "abort"
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500


if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-24 03:44:25.315172
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError('Error', '1')
    assert error.headers == {'Content-Range': 'bytes */1'}

# Generated at 2022-06-24 03:44:30.379667
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    temp = RequestTimeout("RequestTimeout message")
    assert temp.message == "RequestTimeout message"
    assert temp.status_code == 408

# Generated at 2022-06-24 03:44:35.075386
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound("Header not found")
    assert exception.status_code == 400
    exception = HeaderNotFound("Header not found", 500)
    assert exception.status_code == 500


# Generated at 2022-06-24 03:44:39.451697
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
            raise ContentRangeError(message="Range not satisfiable", content_range=None)
    except Exception as e:
        print(e.headers)


if __name__ == '__main__':
    test_ContentRangeError()

# Generated at 2022-06-24 03:44:41.070551
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('message')
    except SanicException as e:
        assert e.message == 'message'


# Generated at 2022-06-24 03:44:42.392546
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "Header not found"
    HeaderNotFound(message)


# Generated at 2022-06-24 03:44:44.759095
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden('this is forbidden', status_code=403)


# Generated at 2022-06-24 03:44:46.894353
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    assert FileNotFound("message", "path", "relative_url").status_code == 404

if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-24 03:44:51.296030
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout!")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert str(e) == "Request Timeout!"


if __name__ == "__main__":
    test_RequestTimeout()

# Generated at 2022-06-24 03:44:56.790256
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("test error",
                        status_code=400)
        assert False
    except SanicException as err:
        assert (type(err) == SanicException)
        assert (err.message == "test error")
        assert (err.status_code == 400)
        assert (err.quiet == False)


# Generated at 2022-06-24 03:44:59.696439
# Unit test for constructor of class Forbidden
def test_Forbidden():
    test_forbidden = Forbidden("TestException")
    assert test_forbidden.status_code == 403

# Generated at 2022-06-24 03:45:04.926100
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = 'File not found'
    path = '/base/path/to/file'
    relative_url = '/static/js/main.js'
    file_not_found = FileNotFound(message=message, path=path, relative_url=relative_url)
    assert file_not_found.message == message
    assert file_not_found.path == path
    assert file_not_found.relative_url == relative_url

# Generated at 2022-06-24 03:45:06.505949
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    import pytest
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("The HTTP request took too long to process.")

# Generated at 2022-06-24 03:45:11.700552
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('error')
    except InvalidUsage as e:
        pass
    assert e.message=='error'
    assert e.status_code==400


# Generated at 2022-06-24 03:45:13.429171
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("timed out")


# Generated at 2022-06-24 03:45:20.916984
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method not supported"
    method = 'GET'
    allowed_methods = ['POST', 'GET']

    test_MethodNotSupported = MethodNotSupported(message, 'GET', ['POST', 'GET'])

    assert test_MethodNotSupported.status_code == 405
    assert test_MethodNotSupported.message == "Method not supported"
    assert test_MethodNotSupported.method == 'GET'
    assert test_MethodNotSupported.allowed_methods == ['POST', 'GET']

# Generated at 2022-06-24 03:45:24.074736
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """ Unit test for class: RequestTimeout """
    rt = RequestTimeout("408")
    assert rt.status_code == 408


if __name__ == "__main__":
    test_RequestTimeout()

# Generated at 2022-06-24 03:45:31.354050
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    auth_scheme = 'Basic'
    realm = 'Restricted Area'
    message = 'Auth required.'

    exception = Unauthorized(message, scheme=auth_scheme, realm=realm)
    expected_header = '%s realm="%s"' % (auth_scheme, realm)

    assert exception.status_code == 401
    assert exception.headers == {'WWW-Authenticate': expected_header}
    assert str(exception) == message

# Test for status code exceptions which do not have a specific class

# Generated at 2022-06-24 03:45:37.601055
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class TestException(SanicException):
        """description"""
        pass

    assert TestException.status_code == 123
    assert TestException.__doc__ == "description"
    assert TestException.quiet is None

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:45:38.220849
# Unit test for function add_status_code
def test_add_status_code():
    pass

# Generated at 2022-06-24 03:45:40.009277
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Timeout", "GET")
    except RequestTimeout as e:
        pass



# Generated at 2022-06-24 03:45:44.753885
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # valid name of YAML file
    with pytest.raises(LoadFileException):
        LoadFileException("data/config.yml")
    # invalid name of YAML file
    with pytest.raises(LoadFileException):
        LoadFileException("data/config1.yml")

# Generated at 2022-06-24 03:45:49.965634
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers.get("WWW-Authenticate") == "Basic realm=\"Restricted Area\""
        assert e.status_code == 401

# Generated at 2022-06-24 03:45:53.460931
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType('message', 'content_range')
    assert invalid_range_type.status_code == 416
    assert invalid_range_type.headers == {
        "Content-Range": "bytes */content_range"
    }


# Generated at 2022-06-24 03:46:02.376964
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as err:
        assert err.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as err:
        assert err.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-24 03:46:05.103821
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    reqTimeout = RequestTimeout("Test request timeout", 408)
    assert reqTimeout.message == "Test request timeout"
    assert reqTimeout.status_code == 408

# Generated at 2022-06-24 03:46:07.380704
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
        ret = HeaderNotFound("header not found")
        assert ret.status_code == 400

# Generated at 2022-06-24 03:46:10.805992
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Custom PayloadTooLarge")
    except PayloadTooLarge as err:
        assert str(err) == "Custom PayloadTooLarge"

# Generated at 2022-06-24 03:46:15.665917
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():

    class Range:
        def __init__(self, total):
            self.total = total

    content_range = Range(1000)
    try:
        raise InvalidRangeType("Error", content_range)
    except InvalidRangeType as e:
        assert(e.status_code == 416)
        assert(e.message == "Error")



# Generated at 2022-06-24 03:46:18.176945
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    e = HeaderExpectationFailed("expectation failed")
    assert e.status_code == 417
    assert e.message == e.__doc__

# Generated at 2022-06-24 03:46:22.171910
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("load_file function error")
    except LoadFileException as e:
        assert e.message == "load_file function error"
        assert e.status_code is None
        assert e.headers is None
        assert e.payload is None
        assert e.quiet is False


# Generated at 2022-06-24 03:46:26.492102
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound('Header not found', 'test')
    assert exception.status_code == 400
    assert exception.message == 'Header not found'


# Generated at 2022-06-24 03:46:29.818488
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    e = MethodNotSupported('message', 'method', ['allowed_methods'])
    assert e.message == 'message'

# Generated at 2022-06-24 03:46:32.861641
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException('Test Exception')
    assert exception.message == 'Test Exception'

if __name__ == "__main__":
    test_LoadFileException()

# Generated at 2022-06-24 03:46:34.020787
# Unit test for constructor of class NotFound
def test_NotFound():
    notfound = NotFound("NotFound")
    assert isinstance(notfound, SanicException) == True


# Generated at 2022-06-24 03:46:38.630846
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    x = ServiceUnavailable('message')
    if x.status_code == 503:
        print("Status code is correct.")
    else:
        print("Status code is incorrect.")
    if x.message == 'message':
        print("Message is correct.")
    else:
        print("Message is incorrect.")
test_ServiceUnavailable()

# Generated at 2022-06-24 03:46:41.205435
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    assert(HeaderNotFound("The Header is not found").message == "The Header is not found")
    assert(HeaderNotFound("The Header is not found").status_code == 400)

# Generated at 2022-06-24 03:46:43.753313
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test signal")
    except InvalidSignal as e:
        print(e.__str__())
        assert e.__str__() == "test signal"


# Generated at 2022-06-24 03:46:49.782427
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = "error"
    try:
        raise NotFound(msg)
    except NotFound as e:
        if not isinstance(e, SanicException):
            assert 0
        if e.status_code != 404:
            assert 0
        if e.message != msg:
            assert 0



# Generated at 2022-06-24 03:46:54.405081
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(409)
    class Conflict(SanicException):
        pass

    class Conflict2(SanicException):
        pass

    @add_status_code(409)
    class Conflict3(Conflict2):
        pass

    assert Conflict.status_code == 409
    assert Conflict3.status_code == 409
    assert Conflict2.status_code == 500

    lost_exception = _sanic_exceptions[409]
    assert lost_exception is Conflict


# Generated at 2022-06-24 03:46:56.448348
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    status_code = 401

    instance = Unauthorized(message, status_code)
    assert isinstance(instance, SanicException) is True
    assert instance.message == message
    assert instance.status_code == status_code

    return None



# Generated at 2022-06-24 03:46:58.892558
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    mylittleheader = HeaderNotFound("My little header")
    assert mylittleheader.status_code == 400

# Generated at 2022-06-24 03:47:05.192697
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Testing for normal input
    try:
        raise InvalidUsage("I am an invalid usage exception.")
    except InvalidUsage as e:
        assert e.status_code == 400

    # Testing for abnormal input
    try:
        raise InvalidUsage("I am an invalid usage exception.", status_code = 500)
    except InvalidUsage as e:
        assert e.status_code == 500

# Unit tests for constructor of class NotFound

# Generated at 2022-06-24 03:47:11.374828
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "message"
    method = "GET"
    allowed_methods = ["GET", "POST"]
    method_not_supported_exception = MethodNotSupported(message=message, method=method, allowed_methods=allowed_methods)
    assert method_not_supported_exception.status_code == 405 # "Method Not Allowed" in Status Code
    assert method_not_supported_exception.headers["Allow"] == "GET, POST" # allowed_methods in "Allow" header
    assert method_not_supported_exception.message == message # passed message in method_not_supported_exception


# Generated at 2022-06-24 03:47:14.392656
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Test case for InvalidUsage")
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == "Test case for InvalidUsage"


# Generated at 2022-06-24 03:47:15.912213
# Unit test for constructor of class Forbidden
def test_Forbidden():
    handler = Forbidden('Forbidden')
    assert handler.status_code == 403



# Generated at 2022-06-24 03:47:17.968257
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error_messege = "failed to construct a URL for endpoint 'option'"
    URLBuildError(error_messege)

# Generated at 2022-06-24 03:47:20.207045
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    IS = InvalidSignal("This is a test")
    assert IS.__str__() == "This is a test"


# Generated at 2022-06-24 03:47:21.662183
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    error = HeaderNotFound(message='Error Message')
    assert error.status_code == 400