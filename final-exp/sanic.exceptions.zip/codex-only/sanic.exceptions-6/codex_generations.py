

# Generated at 2022-06-24 03:37:15.880704
# Unit test for function add_status_code
def test_add_status_code():
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-24 03:37:19.679960
# Unit test for constructor of class PyFileError
def test_PyFileError():
    path='/home/shijie/test.py'
    pyfileerror = PyFileError(path)
    assert pyfileerror.args == ('could not execute config file %s',path)


# Generated at 2022-06-24 03:37:23.380952
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout('test', 10)
    assert request_timeout.status_code == 408
    assert request_timeout.message == 'test'
    assert request_timeout.status_code == 10

# Generated at 2022-06-24 03:37:24.914431
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    print(InvalidUsage)
    a = InvalidUsage("非法请求")
    print(a)

# Generated at 2022-06-24 03:37:29.956521
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden) as ex:
      raise Forbidden("403 Forbidden")
    assert ex.value.status_code == 403
    assert ex.value.message == "403 Forbidden"

# Generated at 2022-06-24 03:37:31.463703
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("Test_Exception")
    assert err.status_code == 500

# Generated at 2022-06-24 03:37:38.383516
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload = PayloadTooLarge(message='PayloadTooLarge', status_code=413)
    assert payload.status_code == 413

# Generated at 2022-06-24 03:37:43.049083
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("ServerUnavailable")
    except Exception as e:
        assert str(e) == "ServerUnavailable"
        assert e.status_code == 503


# Generated at 2022-06-24 03:37:48.333316
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("Message")
    assert hnf.status_code == 400
    assert hnf.message == "Message"
    assert hnf.args == ("Message",)


# Generated at 2022-06-24 03:37:49.124384
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    ServiceUnavailable("Hello",True)

# Generated at 2022-06-24 03:37:55.433497
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        exc = InvalidRangeType('test', 10)
        assert exc.args[0] == 'test'
        assert exc.status_code == 416
        assert exc.headers['Content-Range'] == 'bytes */10'
    except AssertionError as e:
        print(e)
        

# Generated at 2022-06-24 03:37:58.599798
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fileNotFound = FileNotFound('message', '/tmp/test.pdf', 'relative_url')
    assert fileNotFound.path == '/tmp/test.pdf'
    assert fileNotFound.relative_url == 'relative_url'



# Generated at 2022-06-24 03:38:02.935594
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("test error", status_code=400)
    except InvalidUsage as e:
        assert e.status_code == 400

if __name__ == "__main__":
    test_InvalidUsage()

# Generated at 2022-06-24 03:38:09.199326
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Test with all 3 arguments
    message = "file not found"
    path = "/img/file.png"
    relative_url = "/img/file.png"
    f = FileNotFound(message, path, relative_url)
    assert f.message == message
    assert f.path == path
    assert f.relative_url == relative_url

    # Test with no relative_url
    f = FileNotFound(message, path)
    assert f.message == message
    assert f.path == path
    assert not hasattr(f, "relative_url")



# Generated at 2022-06-24 03:38:11.722573
# Unit test for constructor of class NotFound
def test_NotFound():
    t = NotFound("abcd")
    assert t.message == "abcd"
    assert t.status_code == 404


# Generated at 2022-06-24 03:38:13.777714
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("Parameter 'name' is required")
    assert isinstance(err, HeaderNotFound)

# Generated at 2022-06-24 03:38:16.280778
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound(message='',status_code=None, quiet=None)
    assert isinstance(exception, SanicException)

# Generated at 2022-06-24 03:38:18.110503
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exc = ServiceUnavailable("test")
    assert exc.status_code == 503
    assert exc.message == "test"

# Generated at 2022-06-24 03:38:23.215568
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('test exception')
    except Exception as e:
        assert isinstance(e, InvalidSignal)
        assert isinstance(e, SanicException)
        assert isinstance(e, BaseException)
        assert isinstance(e, Exception)
    else:
        assert False, 'Exception is not raised'

# Generated at 2022-06-24 03:38:26.701129
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    error = InvalidRangeType(message="message1", content_range=12)
    assert error.status_code == 416
    assert error.message == "message1"



# Generated at 2022-06-24 03:38:31.575128
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # code = 403
    # auth = Forbidden("Auth required.", code)
    # assert auth.status_code == code

    code = 403
    auth = Forbidden("Auth required.", status_code = 403)
    assert auth.status_code == code

    # code = 500
    # auth = Exception("Auth required.")
    # assert auth.status_code != code


# Generated at 2022-06-24 03:38:35.907325
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    range = bytes([0, 256])
    content_range = range.split(b"/")[1]
    content_range_error = getattr(sys.modules[__name__], "ContentRangeError")(message, content_range)
    content_range_error.headers

# Generated at 2022-06-24 03:38:38.407353
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("file not found")
    except LoadFileException as e:
        pass


# Generated at 2022-06-24 03:38:40.869887
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message='Exception')
    except ServerError:
        pass
    else:
        assert False, 'ServerError not raised'

# Generated at 2022-06-24 03:38:44.435550
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("error_message")
    assert isinstance(error, Exception) == True
    assert isinstance(error, SanicException) == True
    assert error.status_code == 500
    assert error.message == "error_message"

# Generated at 2022-06-24 03:38:50.045516
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("something went wrong", None, None)
    except Exception as e:
        if str(e) == 'something went wrong':
            assert True
        else:
            assert False


# Generated at 2022-06-24 03:38:52.690996
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound()
    except HeaderNotFound as h:
        print(h.status_code, h.message)

# Generated at 2022-06-24 03:38:55.334203
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("test_HeaderExpectationFailed")
    except HeaderExpectationFailed as e:
        assert str(e) == "test_HeaderExpectationFailed"
        assert e.status_code == 417


# Generated at 2022-06-24 03:38:59.863974
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # test for default constructor
    a = HeaderExpectationFailed()
    # test for parameterized constructor
    b = HeaderExpectationFailed("error message")


# Generated at 2022-06-24 03:39:01.330732
# Unit test for constructor of class NotFound
def test_NotFound():
    error = NotFound('test')
    assert error.status_code == 404
    assert error.__str__() == 'test'

# Generated at 2022-06-24 03:39:05.189843
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        a = NotFound("Not Found")
        if a is None:
            return False
    except Exception as e:
        return False
    return True


# Generated at 2022-06-24 03:39:10.485453
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    '''
    This function tests if the constructor works with the parameters.
    '''
    test_headerexpectationfailed = HeaderExpectationFailed()
    assert hasattr(test_headerexpectationfailed, 'status_code')
    assert hasattr(test_headerexpectationfailed, 'message')


# Generated at 2022-06-24 03:39:15.925215
# Unit test for function add_status_code
def test_add_status_code():
    dummy_code = [666]
    assert dummy_code[0] not in _sanic_exceptions

    @add_status_code(dummy_code[0])
    class DummyException(SanicException):
        pass

    assert dummy_code[0] in _sanic_exceptions
    assert _sanic_exceptions[dummy_code[0]] == DummyException



# Generated at 2022-06-24 03:39:18.104438
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test server error.")
    except ServerError as error:
        assert error.status_code == 500


# Generated at 2022-06-24 03:39:29.152346
# Unit test for function add_status_code
def test_add_status_code():
    def check_code(code):
        check_code.called = True
        return code

    @add_status_code(200)
    class TestCode(SanicException):
        pass

    assert _sanic_exceptions[200] is TestCode
    assert TestCode.status_code == 200
    assert not hasattr(TestCode, "quiet")

    @add_status_code(404)
    class NotFound2(SanicException):
        pass

    assert _sanic_exceptions[404] is NotFound2
    assert NotFound2.status_code == 404
    assert NotFound2.quiet is True

    @add_status_code(500)
    class ServerError2(SanicException):
        pass

    assert _sanic_exceptions[500] is ServerError2

# Generated at 2022-06-24 03:39:32.809473
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Exception as ex:
        assert ex.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert ex.message == "Auth required."



# Generated at 2022-06-24 03:39:34.956906
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    Exception class RequestTimeout inherits from SanicException.
    """
    assert issubclass(RequestTimeout, SanicException)



# Generated at 2022-06-24 03:39:39.126147
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    Test the constructor of class ServiceUnavailable
    """
    exception = ServiceUnavailable("Service is unavailable")
    assert exception.status_code == 503
    assert exception.message == "Service is unavailable"
    exception = ServiceUnavailable("Service is unavailable", status_code=600)
    assert exception.status_code == 600
    assert exception.message == "Service is unavailable"

# Generated at 2022-06-24 03:39:44.248996
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("header not found")
    except SanicException as e:
        assert e.status_code == 400
    try:
        raise HeaderNotFound("header not found", status_code=404)
    except SanicException as e:
        assert e.status_code == 404

# Generated at 2022-06-24 03:39:45.748955
# Unit test for function abort
def test_abort():
    assert (str(abort(404, "Not Found")) == "Not Found")

# Generated at 2022-06-24 03:39:51.654300
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("HTTP request to URL failed")
    a = getattr(error, 'status_code', None)
    b = getattr(error, 'quiet', None)
    assert a == 500
    assert b == False

# Generated at 2022-06-24 03:39:53.692211
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "file"
    pe = PyFileError(file)
    assert pe.args[0] == "could not execute config file "+file

# Generated at 2022-06-24 03:39:57.260989
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    pass
    # msg = "test message"
    # HeadNotFoundException = HeaderNotFound(msg)
    # assert HeadNotFoundException.message is msg
    # assert HeadNotFoundException.status_code is 400
    # assert HeadNotFoundException.__str__() is msg


# Generated at 2022-06-24 03:39:58.776484
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("load error")
    except LoadFileException as err:
        assert err.status_code == 500

# Generated at 2022-06-24 03:40:00.942509
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge) as e:
        raise PayloadTooLarge("message", status_code=413)
    assert e.value.status_code == 413

# Generated at 2022-06-24 03:40:07.921333
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        e = SanicException('This is a SanicException')
        error = "%s: %s" % (type(e), e.args[0])
        assert (str(e) == 'This is a SanicException')
    except Exception as e:
        error = ("Error raised during SanicException. "
                 "Error type = %s, error message = %s" % (type(e), e))
    assert (error == 'This is a SanicException')



# Generated at 2022-06-24 03:40:14.837352
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(777)
    class CustomException(SanicException):
        pass

    assert isinstance(CustomException, type)
    assert _sanic_exceptions[777] == CustomException

    try:
        raise CustomException
    except CustomException as e:
        assert e.status_code == 777

# Generated at 2022-06-24 03:40:16.450261
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError("Test message", 1)
    assert e.message == "Test message"
    assert e.status_code == 416
    assert e.headers == {"Content-Range": "bytes */1"}

# Generated at 2022-06-24 03:40:23.318635
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}
    
    @add_status_code(666)
    class SomeException(SanicException):
        pass

    assert _sanic_exceptions == {666: SomeException}


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:40:26.197479
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('This is my message', 100)
    except ContentRangeError as exception:
        assert exception.message == 'This is my message'
        assert exception.status_code == 416
        assert exception.headers['Content-Range'] == 'bytes */100'

# Generated at 2022-06-24 03:40:28.562144
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Testing service unavailable.")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Testing service unavailable."


# Generated at 2022-06-24 03:40:33.190912
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(203)
    class MyException(Exception):
        pass

    assert MyException.status_code == 203
    assert _sanic_exceptions[203] == MyException

# Generated at 2022-06-24 03:40:42.710270
# Unit test for function add_status_code
def test_add_status_code():
    class test_add_code_exception_01(SanicException):
        pass
    class test_add_code_exception_02(SanicException):
        pass
    class test_add_code_exception_03(SanicException):
        pass

    add_status_code(100, True)(test_add_code_exception_01)
    add_status_code(200, False)(test_add_code_exception_02)
    add_status_code(500, None)(test_add_code_exception_03)

    assert _sanic_exceptions[100](message="test_add_code_exception_01").quiet == True
    assert _sanic_exceptions[200](message="test_add_code_exception_02").quiet == False

# Generated at 2022-06-24 03:40:46.229173
# Unit test for constructor of class ServerError
def test_ServerError():
    ExceptionMessage          = "test message"
    ServerErrorInstance       = ServerError(message = ExceptionMessage)
    assert str(ServerErrorInstance) == ExceptionMessage
    assert ServerErrorInstance.message == ExceptionMessage
    assert ServerErrorInstance.status_code == 500

# Generated at 2022-06-24 03:40:55.218982
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # The following tests are executed in the same order of the examples given
    # in the docstring of the constructor.
    # With a Basic auth-scheme, realm MUST be present:
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as err:
        status_code = 401
        expected_message = 'Basic realm="Restricted Area"'
    # With a Digest auth-scheme, things are a bit more complicated:
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as err:
        status_

# Generated at 2022-06-24 03:40:58.728120
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ["GET", "HEAD"]
    method = "POST"
    message = "Method Not Supported"
    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.headers == {'Allow': 'GET, HEAD'}

# Generated at 2022-06-24 03:41:01.263968
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("message", content_range=object())
    except ContentRangeError as inst:
        assert inst.headers["Content-Range"] == "bytes */None"

# Generated at 2022-06-24 03:41:03.625006
# Unit test for constructor of class ServerError
def test_ServerError():
    s = ServerError("test")
    assert(s.status_code==500)

if __name__ == "__main__":
    test_ServerError()

# Generated at 2022-06-24 03:41:06.642537
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as excinfo:
        raise InvalidUsage("cannot parse request body")
    assert excinfo.value.message == "cannot parse request body"
    assert excinfo.value.status_code == 400


# Generated at 2022-06-24 03:41:08.532870
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test_PyFileError")
    except PyFileError:
        pass

# Generated at 2022-06-24 03:41:14.466768
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        try:
            raise SanicException("Testing...")
        except SanicException as e:
            assert str(e) == "Testing..."
            e.status_code = 500
            raise e
    except SanicException as e:
        assert str(e) == "Testing..."
        assert e.status_code == 500
        assert SanicException.__mro__ == (SanicException, object)


# Generated at 2022-06-24 03:41:18.431185
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message='', content_range=5)
    except Exception:
        pass


# Generated at 2022-06-24 03:41:20.031950
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Range Not Satisfiable.", 0)
    except ContentRangeError as err:
        print(err)

# Generated at 2022-06-24 03:41:25.078457
# Unit test for constructor of class PyFileError
def test_PyFileError():
    """
    Checks the constructor of class PyFileError
    """
    pyfileerror = PyFileError('file.py')
    assert pyfileerror.args[0] == 'could not execute config file %s'
    assert pyfileerror.args[1] == 'file.py'

# Generated at 2022-06-24 03:41:26.620400
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("this is an InvalidSignal test.")
    except Exception as e:
        assert e.message == "this is an InvalidSignal test."

# Generated at 2022-06-24 03:41:33.811224
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Verify construction of class
    try:
        raise URLBuildError(message="This is a test")
    except Exception as e:
        assert isinstance(e, URLBuildError)
        assert isinstance(e, ServerError)
        assert isinstance(e, SanicException)
        assert "This is a test" == e.message
        assert "URLBuildError: This is a test" == str(e)
        assert "This is a test" == str(e)
        assert 500 == e.status_code
        assert False == e.quiet
        assert False == e.is_quiet


# Generated at 2022-06-24 03:41:35.590067
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('The service is unavailable')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == 'The service is unavailable'

# Generated at 2022-06-24 03:41:37.239553
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("pyfile.py")
    except PyFileError as e:
        assert str(e) == "could not execute config file pyfile.py"


# Generated at 2022-06-24 03:41:42.518768
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("This is an error message", status_code=400)
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.__str__() == 'This is an error message'

# Generated at 2022-06-24 03:41:49.835109
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404

    try:
        abort(400)
    except SanicException as e:
        assert e.status_code == 400

    # Custom message
    try:
        abort(400, 'Custom Message')
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == 'Custom Message'

# Generated at 2022-06-24 03:41:53.292315
# Unit test for constructor of class Forbidden
def test_Forbidden():
    print("\n============ Forbidden =============\n")
    a = Forbidden("I am Forbidden")

    # Test the message
    print(type(a.message))
    print(a.message)

    # Test the status_code
    print(type(a.status_code))
    print(a.status_code)


# Generated at 2022-06-24 03:41:58.551500
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert not e.has_headers
        assert e.headers is None

    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.has_headers
        assert e.headers is not None

# Generated at 2022-06-24 03:42:02.679827
# Unit test for function abort
def test_abort():
    try:
        abort(100)  # any code that is not exist in dict _sanic_exceptions
        assert False
    except SanicException:
        assert True

    try:
        abort(200)
    except SanicException:
        assert False



# Generated at 2022-06-24 03:42:05.765878
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        abort(123)
    except SanicException as e:
        assert e.status_code == 123

# Generated at 2022-06-24 03:42:10.823990
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('The file {} is not found.'.format('filename'))
    except FileNotFound as e:
        assert e.message == 'The file filename is not found.'
        assert e.path == 'The file {} is not found.'.format('filename')
        assert e.relative_url == 'filename'

# Generated at 2022-06-24 03:42:15.415085
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h = HeaderExpectationFailed("Expectation Failed")
    assert h.status_code == 417
    assert h.headers == {}
    assert h.quiet
    assert str(h) == "Expectation Failed"

# Generated at 2022-06-24 03:42:17.197786
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    err = LoadFileException('hello')
    assert err.message == 'hello'

# Generated at 2022-06-24 03:42:28.431390
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # message, status_code=None, scheme=None, **kwargs)
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": f"Basic realm=\"Restricted Area\""
        }
    try:
        raise Unauthorized("Auth required.",
                           scheme="Bearer")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": "Bearer"
        }

# Generated at 2022-06-24 03:42:31.986862
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="")
    except LoadFileException as e:
        assert e.message == ""
        assert issubclass(type(e), SanicException)

# Generated at 2022-06-24 03:42:40.907541
# Unit test for function abort
def test_abort():
    # try skipping required parameters
    try:
        abort()
    except TypeError:
        assert True

    # ordinary usage
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == b"Not Found".decode("utf8")
    except SanicException as e:
        assert False

    #  provide custom message
    try:
        abort(404, "Some custom message")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Some custom message"
    except SanicException as e:
        assert False

if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-24 03:42:43.312975
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Wrong usage")
    except InvalidUsage as e:
        assert e.status_code == 400 and e.message == "Wrong usage"


# Generated at 2022-06-24 03:42:47.272549
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    ir = InvalidRangeType("InvalidRangeType")
    assert ir.message == "InvalidRangeType"
    assert ir.status_code == 416
    assert ir.headers == {'Content-Range': 'bytes */None'}



# Generated at 2022-06-24 03:42:48.375108
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError("Error", 10)

# Generated at 2022-06-24 03:42:50.946369
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('test_HeaderNotFound')
    except HeaderNotFound as e:
        print(e)


# Generated at 2022-06-24 03:42:54.597572
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = 'file'
    error = PyFileError(file)
    assert error.args[0] == 'could not execute config file %s'

    error = PyFileError(file)
    assert error.args[1] == file

# Generated at 2022-06-24 03:43:02.151676
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # Test case 0 - provide all parameters to the
    message = "method not supported"
    method = 'GET'
    allowed_methods = ['OPTIONS', 'PUT', 'DELETE']
    expected_output = {'message': 'method not supported', 'headers': {'Allow': 'OPTIONS, PUT, DELETE'}}
    actual_output = MethodNotSupported(message, method, allowed_methods)
    assert actual_output.__dict__ == expected_output


# Generated at 2022-06-24 03:43:05.226970
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exc = ContentRangeError("...", 0)
    assert exc.status_code == 416
    assert exc.headers == {"Content-Range": f"bytes */0"}
    assert exc.__dict__ == {"headers": {"Content-Range": f"bytes */0"}}

# Generated at 2022-06-24 03:43:14.448669
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    msg = "some error message"
    method = "GET"
    allowed_methods = ['POST', 'GET']
    try:
        mns = MethodNotSupported(msg, method, allowed_methods)
    except Exception as err:
        pytest.fail('MethodNotSupported failed to initialize: ' + str(err))
    assert msg == str(mns)
    assert mns.status_code == 405
    assert mns.headers['Allow'] == "POST, GET"
    # check that quiet was set implicitly
    assert mns.quiet

# Testing the SanicException.__str__ method

# Generated at 2022-06-24 03:43:16.485048
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("Not Found", "/tmp/404.html", "/foo")
    except FileNotFound as e:
        pass

# Generated at 2022-06-24 03:43:18.551056
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("A invalid signal exception was raised", "SIGSEGV")
    except InvalidSignal as e:
        assert e.args[0] == "A invalid signal exception was raised"
        assert e.args[1] == "SIGSEGV"


# Generated at 2022-06-24 03:43:20.946319
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("test_RequestTimeout")
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:43:26.539489
# Unit test for constructor of class SanicException
def test_SanicException():
    status_code = 777
    quiet = True
    message = "Message"
    assert SanicException(message, status_code, quiet).message ==  message


if __name__ == "__main__":
    test_SanicException()

# Generated at 2022-06-24 03:43:29.239328
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    message = 'RequestTimeout'
    with pytest.raises(RequestTimeout) as excinfo:
        raise RequestTimeout(message)
    assert excinfo.value.quiet == True

# Generated at 2022-06-24 03:43:31.607682
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message="test")
    except ServerError as exc:
        print(exc.status_code)
        print(exc.args[0])

test_ServerError()

# Generated at 2022-06-24 03:43:34.932942
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    t = PayloadTooLarge("payload too large", status_code = 413)
    assert t.status_code == 413
    assert t.message == "payload too large"


# Generated at 2022-06-24 03:43:43.965937
# Unit test for constructor of class SanicException
def test_SanicException():
    parsed_args = {}
    test_exc = SanicException('Error message', **parsed_args)
    assert isinstance(test_exc, SanicException)
    assert test_exc.status_code == 500
    assert not test_exc.quiet

    # Test with status code as kwarg
    parsed_args = {'status_code': 503}
    test_exc = SanicException('Error message', **parsed_args)
    assert test_exc.status_code == 503
    assert test_exc.quiet

    # Test with quiet as kwarg
    parsed_args = {'quiet': False}
    test_exc = SanicException('Error message', **parsed_args)
    assert test_exc.status_code == 500
    assert not test_exc.quiet



# Generated at 2022-06-24 03:43:45.668893
# Unit test for function add_status_code
def test_add_status_code():
    assert STATUS_CODES[404] == "Not Found"
    with pytest.raises(NotFound):
        abort(404)

# Generated at 2022-06-24 03:43:47.468362
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage("Invalid usage")



# Generated at 2022-06-24 03:43:54.264538
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Forbidden as e:
        assert e.status_code is None or e.status_code == 403
        assert e.message == "Forbidden"
        assert e.status_code == 403
        assert e.quiet is True or e.quiet == None
        assert e.headers == {}


# Generated at 2022-06-24 03:43:55.775506
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("")
    except RequestTimeout as err:
        assert str(err) == ""
    try:
        raise RequestTimeout("1")
    except RequestTimeout as err:
        assert str(err) == "1"

# Generated at 2022-06-24 03:43:59.877620
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError):
        raise ServerError(message=None)


# Generated at 2022-06-24 03:44:01.716642
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('loadfileexception')
    except LoadFileException as e:
        return e

# Generated at 2022-06-24 03:44:05.458714
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    print("----test_LoadFileException----")
    path = "test.txt"
    exception = LoadFileException(message="load file failed", path=path)
    print(type(exception))
    print(exception.args)
    print(exception)



# Generated at 2022-06-24 03:44:07.858875
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound()
    except NotFound as e:
        assert isinstance(e, NotFound)


# Generated at 2022-06-24 03:44:12.858908
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("invalid signal", status_code=None, quiet=None)
    except InvalidSignal as e:
        msg = e.args[0]
        status_code = e.status_code

    assert msg == "invalid signal"
    assert status_code == 400


# Generated at 2022-06-24 03:44:22.471409
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class MyException(Exception):
        pass
    assert _sanic_exceptions[123] == MyException
    try:
        raise MyException("123")
    except SanicException as e:
        assert e.status_code == 123
    assert MyException("123").status_code == 123
    assert MyException("123").quiet
    assert ServerError("456").quiet is False
    assert ServerError("456").status_code == 500
    assert ServiceUnavailable("456").status_code == 503
    assert ServiceUnavailable("456").quiet
    assert NotFound("456").status_code == 404
    assert NotFound("456").quiet



# Generated at 2022-06-24 03:44:26.749717
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError(
        message='Content range not satisfiable',
        content_range=0)
    assert error.headers == {'Content-Range': 'bytes */0'}


# Generated at 2022-06-24 03:44:28.023391
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("config_file")
    except PyFileError as e:
        assert(str(e) == "could not execute config file config_file")

# Generated at 2022-06-24 03:44:32.270076
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(
            "message",
            path="file:///tmp",
            relative_url="file:///tmp/test.txt")
    except FileNotFound as e:
        assert e.args[0] == "message"
        assert e.path == "file:///tmp"
        assert e.relative_url == "file:///tmp/test.txt"

# Generated at 2022-06-24 03:44:33.219708
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal("message")

# Generated at 2022-06-24 03:44:36.778633
# Unit test for constructor of class NotFound
def test_NotFound():
    code = "404"
    message = 'not found'
    try:
        raise NotFound(message)
    except NotFound as e:
        assert e.status_code == int(code)
        assert e.__str__() == message


# Generated at 2022-06-24 03:44:39.358799
# Unit test for constructor of class NotFound
def test_NotFound():
    e=NotFound("404")
    assert str(e) == "404"
    assert e.status_code==404
    assert e.quiet==True

# Generated at 2022-06-24 03:44:43.268475
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("could not reverse endpoint 'reversme'")
    assert error.status_code == 500
    assert error.message == "could not reverse endpoint 'reversme'"
    assert error.__str__() == f"{error.__class__.__name__}: {error.message}"

# Generated at 2022-06-24 03:44:44.756830
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound("", "", "")



# Generated at 2022-06-24 03:44:47.976767
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal(message='message', status_code=123)
    except InvalidSignal as e:
        assert e.status_code == 123
        assert e.message == 'message'



# Generated at 2022-06-24 03:44:51.478704
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ce = ContentRangeError("message", "content_range")
    assert ce.message == "message"
    assert ce.status_code == 416
    assert ce.headers["Content-Range"] == "bytes */content_range"


# Generated at 2022-06-24 03:44:54.728751
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "Test Message"
    content_range = "Content Range"
    exception = ContentRangeError(message, content_range)
    assert exception.message == message
    assert exception.headers["Content-Range"] == f"bytes */{content_range}"

# Generated at 2022-06-24 03:44:58.492272
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    range_start = 0
    range_end = 0
    total = 0
    cr = ContentRangeError("message", content_range)
    assert cr.headers == {"Content-Range": f"bytes */{content_range.total}"}



# Generated at 2022-06-24 03:45:01.129698
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    msg = "HeaderExpectationFailed"
    e = HeaderExpectationFailed(message=msg)
    assert isinstance(e, HeaderExpectationFailed)
    assert e.message == msg

# Generated at 2022-06-24 03:45:05.777111
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge(message='This is a PayloadTooLarge exception', status_code=413)
    assert exception.status_code == 413


# Generated at 2022-06-24 03:45:12.202697
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "Range not satisfiable"
    content_range = ''
    exc = ContentRangeError(message=message, content_range=content_range)
    assert exc.message == message
    assert exc.content_range == content_range
    
    

# Generated at 2022-06-24 03:45:20.164603
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as exc:
        abort(404)
    assert exc.value.status_code == 404
    assert exc.value.message == b"Not Found"
    assert exc.value.quiet is True

    with pytest.raises(ServiceUnavailable) as exc:
        abort(503)
    assert exc.value.status_code == 503
    assert exc.value.message == b"Service Unavailable"
    assert exc.value.quiet is True

    with pytest.raises(SanicException) as exc:
        abort(418)
    assert exc.value.status_code == 418
    assert exc.value.message == b"I'm a teapot"
    assert exc.value.quiet is False

# Generated at 2022-06-24 03:45:23.068703
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    assert(ContentRangeError.status_code == 416)
    ContentRangeError("message",1)

# Generated at 2022-06-24 03:45:25.111856
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout) as excinfo:
        raise RequestTimeout('test')
    assert excinfo.value.status_code == 408

# Generated at 2022-06-24 03:45:27.843386
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "TEST"
    ContentRangeError(message, 1)

# Generated at 2022-06-24 03:45:33.090844
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    """
    Create the FileNotFound class
    """
    test_class = FileNotFound("Message", "Path", "Relative_url")
    
    assert test_class.path == "Path"
    assert test_class.relative_url == "Relative_url"
    assert test_class.message == "Message"
    assert test_class.status_code == 404
    assert test_class.__class__.__name__ == "FileNotFound"

# Generated at 2022-06-24 03:45:44.042383
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class SwitchingProtocols(SanicException):
        pass

    assert SwitchingProtocols.status_code == 101
    assert SwitchingProtocols().status_code == 101
    assert SwitchingProtocols.quiet is True
    assert SwitchingProtocols().quiet is True

    @add_status_code(500, quiet=False)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError().status_code == 500
    assert InternalServerError.quiet is False
    assert InternalServerError().quiet is False

    @add_status_code(204)
    class NoContent(SanicException):
        pass

    assert NoContent.status_code == 204
    assert NoContent().status_code == 204
   

# Generated at 2022-06-24 03:45:55.389345
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(KeyError):
        abort(123)

    @add_status_code(123)
    class MyException(Exception):
        pass

    assert _sanic_exceptions[123] == MyException
    with pytest.raises(MyException) as exc:
        abort(123)

    assert str(exc.value) == "MyException"
    assert exc.value.status_code == 123

    with pytest.raises(MyException) as exc:
        abort(123, "hello")

    assert str(exc.value) == "hello"
    assert exc.value.status_code == 123

    @add_status_code(124)
    class MyException2(Exception):
        pass

    assert _sanic_exceptions[124] == MyException2

# Generated at 2022-06-24 03:45:57.911250
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Error")
    except ServiceUnavailable as e:
        print(e.status_code)
        print(e.quiet)
        print(e.args)



# Generated at 2022-06-24 03:46:01.430190
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # assert isinstance(MethodNotSupported(
    #     "invalid method", 'POST', ('GET', 'POST')), MethodNotSupported)
    assert isinstance(MethodNotSupported(
        "invalid method", 'POST', ('GET', 'POST')), SanicException)

# Generated at 2022-06-24 03:46:04.265263
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    testRequestTimeout = RequestTimeout("test message", 408)
    assert testRequestTimeout.message == "test message"
    assert testRequestTimeout.status_code == 408
    assert hasattr(testRequestTimeout, "quiet") == True

# Generated at 2022-06-24 03:46:11.597334
# Unit test for constructor of class Forbidden
def test_Forbidden():
    code = 403
    msg = 'Forbidden'
    # for an object x of a class, isinstance(x, classinfo) returns True if the object is an instance or subclass of classinfo.
    assert isinstance(Forbidden(msg,code), Forbidden)
    assert Forbidden(msg,code).status_code == 403
    assert Forbidden(msg,code).quiet == True
    assert Forbidden(msg,code).args == (msg,)
    

# Generated at 2022-06-24 03:46:15.421577
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = 'No information'
    exception = HeaderExpectationFailed(message)
    assert (exception.message == message and exception.status_code == 417)
    with pytest.raises(AttributeError):
        exception.headers


# Generated at 2022-06-24 03:46:17.452209
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError()
    except ServerError as e:
        assert e.status_code == 500

# Generated at 2022-06-24 03:46:20.599140
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test", status_code=503)
    except ServerError as e:
        assert e.status_code == 503
        assert e.message == "Test"
        assert e.quiet == True


# Generated at 2022-06-24 03:46:25.783482
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("The file does not exist", None)
    except ContentRangeError as ex:
        assert ex.args == ("The file does not exist",)
        assert ex.headers == {"Content-Range": "bytes */None"}
        assert str(ex) == "The file does not exist"
        assert ex.status_code == 416

# Generated at 2022-06-24 03:46:28.143660
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test_InvalidSignal")
    except Exception as msg:
        print(msg)

if __name__ == "__main__":
    test_InvalidSignal()

# Generated at 2022-06-24 03:46:32.966932
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Error of ContentRangeError.", "1-9999/10000")
    except Exception as e:
        assert e.headers == {"Content-Range": "bytes */10000"}
        assert e.__str__() == "Error of ContentRangeError."

# Generated at 2022-06-24 03:46:42.345002
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert _sanic_exceptions.get(500) == MyException, '_sanic_exceptions is not set correctly'
    assert issubclass(MyException, SanicException), 'MyException class is not a subclass of SanicException'

    try:
        raise MyException('testing')
    except SanicException as e:
        assert e.status_code == 500, 'SanicException set to wrong status code'
        assert e.message == 'testing'
        assert e.args[0] == 'testing'

if __name__ == '__main__':
    test_add_status_code()

# Generated at 2022-06-24 03:46:45.313399
# Unit test for constructor of class PyFileError
def test_PyFileError():
    exception = PyFileError("test")
    assert isinstance(exception, Exception)
    assert exception.args == ("could not execute config file %s", "test")


# Generated at 2022-06-24 03:46:48.320836
# Unit test for constructor of class ServerError
def test_ServerError():
    e = ServerError(message = "test")
    assert e.status_code == 500
    assert e.message == "test"


# Generated at 2022-06-24 03:46:54.875856
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    for i in range(200, 600):
        try:
            abort(i)
        except SanicException as e:
            print(e)
            print(e.status_code)
            print(e.headers)

if __name__ == '__main__':
    # test_ContentRangeError()
    pass

# Generated at 2022-06-24 03:46:57.239677
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage("test message!", status_code=400, quiet=None)


# Generated at 2022-06-24 03:46:59.667049
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        abort(400)
    except SanicException as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:47:03.214067
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    m = InvalidRangeType("This is a test message", 10)
    assert m
    assert m.status_code == 416
    assert m.message == "This is a test message"
    assert m.headers["Content-Range"] == "bytes */10"

# Generated at 2022-06-24 03:47:04.696591
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge):
        raise PayloadTooLarge


# Generated at 2022-06-24 03:47:09.238841
# Unit test for constructor of class NotFound
def test_NotFound():
    
    from unittest import TestCase
    from unittest.mock import patch, Mock

    with patch('builtins.super') as superMock:
        test = NotFound("Not Found")
    
    assert test.message == "Not Found"
    assert test.status_code == 404
    assert test.quiet == True
    assert superMock.called


# Generated at 2022-06-24 03:47:12.188597
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "HeaderNotFound"
    status_code = 400
    quiet = False
    exception = HeaderNotFound(message, status_code, quiet)
    assert exception.message == message
    assert exception.status_code == status_code
    assert exception.quiet == quiet



# Generated at 2022-06-24 03:47:22.057562
# Unit test for function add_status_code
def test_add_status_code():
    class Test(SanicException):
        pass

    # Remove exception class
    if StatusCode.INTERNAL_SERVER_ERROR in _sanic_exceptions:
        _sanic_exceptions.pop(StatusCode.INTERNAL_SERVER_ERROR)

    assert StatusCode.INTERNAL_SERVER_ERROR not in _sanic_exceptions
    add_status_code(StatusCode.INTERNAL_SERVER_ERROR)(Test)
    assert StatusCode.INTERNAL_SERVER_ERROR in _sanic_exceptions
    assert isinstance(_sanic_exceptions[StatusCode.INTERNAL_SERVER_ERROR],
                      type)
    assert _sanic_exceptions[StatusCode.INTERNAL_SERVER_ERROR] is Test