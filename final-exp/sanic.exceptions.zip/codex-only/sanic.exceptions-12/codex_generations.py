

# Generated at 2022-06-24 03:37:28.976078
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # testing if the constructor works with message
    try:
        raise Forbidden("#1")
    except SanicException as e:
        assert "Forbidden" in str(e)
        assert "#1" in str(e)

    # testing if the constructor works without message
    try:
        raise Forbidden()
    except SanicException as e:
        assert "Forbidden" in str(e)



# Generated at 2022-06-24 03:37:30.811254
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Test suite
    with pytest.raises(PyFileError):
        raise PyFileError('file.py')

# Generated at 2022-06-24 03:37:35.698807
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("503", "<msg>")
    except ServiceUnavailable as status:
        assert "503" == status.message
        assert 503 == status.status_code
        assert status.quiet
        assert status.args[0] == "503"
        assert status.args[1] == "<msg>"


# Generated at 2022-06-24 03:37:36.927910
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("hello world")
    assert isinstance(exc, SanicException)
    assert exc.status_code == 417

# Generated at 2022-06-24 03:37:39.985214
# Unit test for constructor of class NotFound
def test_NotFound():
    # Should cause no errors
    exception = NotFound("Not Found", 404)


# Generated at 2022-06-24 03:37:51.080896
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():

    from ctypes import c_ubyte, sizeof
    from pathlib import Path
    from sanic.response import ContentRange
    from sanic.exceptions import ContentRangeError
    import os

    import pytest
    testdata_path = Path(os.path.dirname(__file__))/'testdata.bin'

    with pytest.raises(ContentRangeError) as exception_info:
        content_range = ContentRange(
            start_pos=0, end_pos=sizeof(c_ubyte)-1, total=sizeof(c_ubyte))
        with open(testdata_path, 'rb') as fp:
            response_body = fp.read()
        raise ContentRangeError(
            message='Reached maximum allowed uploads',
            content_range=content_range)
    assert exception_

# Generated at 2022-06-24 03:37:54.004866
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exc = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert exc.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

# Generated at 2022-06-24 03:37:55.981919
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("test", status_code=400)
    except SanicException as e:
        assert e.__str__() == "test"


# Generated at 2022-06-24 03:37:57.641877
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    service = ServiceUnavailable()
    assert service.message == STATUS_CODES[503].decode("utf8")

# Generated at 2022-06-24 03:38:07.948325
# Unit test for constructor of class SanicException
def test_SanicException():
    exc = SanicException("message")
    assert exc.status_code == 500
    assert exc.quiet == True
    assert str(exc) == "message"

    exc = SanicException("message2", 403, True)
    assert exc.status_code == 403
    assert exc.quiet == True
    assert str(exc) == "message2"
    exc.status_code = 500
    assert exc.status_code == 500

    exc = SanicException("message3", 500)
    assert exc.status_code == 500
    assert exc.quiet == False
    assert str(exc) == "message3"

    exc = SanicException("message4", 500, False)
    assert exc.status_code == 500
    assert exc.quiet == False
    assert str(exc) == "message4"


# Generated at 2022-06-24 03:38:09.856342
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(TypeError):
        raise InvalidRangeType(None, None)


# Generated at 2022-06-24 03:38:12.798645
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError('message', 'content_range')
    assert e.message == 'message'
    assert e.headers == {'Content-Range': 'bytes */content_range'}

# Generated at 2022-06-24 03:38:14.836445
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    x = RequestTimeout('message', status_code=408)
    assert type(x) == RequestTimeout

# Generated at 2022-06-24 03:38:23.017923
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Test for constructor of class InvalidUsage with no message
    try:
        raise InvalidUsage()
    except InvalidUsage as inst:
        assert(inst.status_code == 400)
        assert(inst.message == '')

    # Test for constructor of class InvalidUsage with message
    try:
        raise InvalidUsage('Invalid message')
    except InvalidUsage as inst:
        assert(inst.status_code == 400)
        assert(inst.message == 'Invalid message')

    # Test for constructor of class InvalidUsage with status code and message
    try:
        raise InvalidUsage('Invalid message', status_code=401)
    except InvalidUsage as inst:
        assert(inst.status_code == 401)
        assert(inst.message == 'Invalid message')

# Generated at 2022-06-24 03:38:26.960953
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable('message',status_code=503)
    assert exception.status_code == 503
    assert exception.quiet == True
    assert exception.message == 'message'


# Generated at 2022-06-24 03:38:38.425779
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test to see that unknown scheme does not raise an exception:
    try:
        raise Unauthorized(message="It didn't work!", scheme="Unknown")
    except Unauthorized as exc:
        assert exc.message == "It didn't work!"
        assert exc.status_code == 401
        assert exc.headers == {"WWW-Authenticate": "Unknown"}

    # Test to see that known schemes that do not require arguments do not
    # raise an exception:
    try:
        raise Unauthorized(message="It didn't work!", scheme="Basic")
    except Unauthorized as exc:
        assert exc.message == "It didn't work!"
        assert exc.status_code == 401
        assert exc.headers == {"WWW-Authenticate": "Basic"}


# Generated at 2022-06-24 03:38:42.841935
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = 4
    message = "message"
    exception = ContentRangeError(message=message, content_range=content_range)
    assert exception.content_range == content_range
    assert exception.message == message

# Generated at 2022-06-24 03:38:47.086034
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as err:
        raise HeaderNotFound('Message', 'header')
    assert err.value.args[0] == 'Message'
    # header is not stored as a property of the HeaderNotFound object
    assert not hasattr(err.value, 'header')


# Generated at 2022-06-24 03:38:49.731987
# Unit test for constructor of class PyFileError
def test_PyFileError():
    _ = PyFileError("The file is not found!")

# Generated at 2022-06-24 03:38:53.682315
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    Test the constructor of class ServiceUnavailable.
    """
    exception = ServiceUnavailable("Not Available");
    assert exception is not None
    assert exception.message == "Not Available"
    assert exception.status_code == 503
    assert exception.headers == {}

# Generated at 2022-06-24 03:38:58.172123
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test")
    except ServerError:
        pass


# Generated at 2022-06-24 03:39:01.684973
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(498)
    class TokenExpired(Exception):
        pass
    assert '498' in _sanic_exceptions
    assert _sanic_exceptions['498'].__name__ == 'TokenExpired'
    

# Generated at 2022-06-24 03:39:05.530564
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('file')
    except PyFileError as e:
        assert e.args[0] == 'could not execute config file file'

# Generated at 2022-06-24 03:39:08.093575
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('This is error message')
    except InvalidSignal as err:
        assert str(err) == 'This is error message'

# Generated at 2022-06-24 03:39:13.899232
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test_method = "GET"
    test_allowed_methods = ["GET", "POST"]
    try:
        raise MethodNotSupported("Test Message",
                                 method=test_method,
                                 allowed_methods=test_allowed_methods)
    except MethodNotSupported as e:
        assert e.message == "Test Message"
        assert e.headers["Allow"] == ", ".join(test_allowed_methods)

# Generated at 2022-06-24 03:39:17.422731
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class myException(SanicException):
        pass
    assert issubclass(myException, SanicException)
    try:
        raise myException('my test exception')
    except myException as inst:
        assert inst.status_code == 999

# Generated at 2022-06-24 03:39:19.426057
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge):
        raise PayloadTooLarge(message="Payload is too large", status_code=413)

# Generated at 2022-06-24 03:39:24.849246
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Unit: FileNotFound(message: str, path: str, relative_url: str) -> None
    obj = FileNotFound("message", "path", "relative_url")
    assert obj.message == "message"
    assert obj.path == "path"
    assert obj.relative_url == "relative_url"


# Generated at 2022-06-24 03:39:27.969065
# Unit test for constructor of class NotFound
def test_NotFound():
    message = 'Hello'
    status_code = 404
    not_found = NotFound(message, status_code)
    assert(not_found.status_code == status_code)


# Generated at 2022-06-24 03:39:32.386664
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Overloaded")
    except ServiceUnavailable as error:
        assert type(error) == ServiceUnavailable
        assert error.__class__ == ServiceUnavailable
        assert str(error) == "Overloaded"
        assert error.status_code == 503
        assert error.headers == {}


# Generated at 2022-06-24 03:39:36.217962
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="message", status_code=417)
    except HeaderExpectationFailed as err:
        assert err.status_code == 417
        assert err.message == "message"
        assert str(err) == "message"



# Generated at 2022-06-24 03:39:39.824654
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    err = InvalidUsage("Test Message")
    assert err.message == "Test Message"
    err2 = InvalidUsage("Test Message", status_code=400)
    assert err2.message == "Test Message"


# Generated at 2022-06-24 03:39:50.995434
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert "Auth required." == str(e)
        assert 401 == e.status_code
        assert e.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'
try:
    raise Unauthorized("Auth required.",
                       scheme="Digest",
                       realm="Restricted Area",
                       qop="auth, auth-int",
                       algorithm="MD5",
                       nonce="abcdef",
                       opaque="zyxwvu")
except Unauthorized as e:
    assert "Auth required." == str(e)

# Generated at 2022-06-24 03:39:58.711768
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except SanicException as e:
        assert e.status_code == 401
        assert e.quiet is True
        assert e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Digest",
            realm="Restricted Area",
            qop="auth, auth-int",
            algorithm="MD5",
            nonce="abcdef",
            opaque="zyxwvu",
        )
    except SanicException as e:
        assert e.status_code == 401
        assert e.quiet is True

# Generated at 2022-06-24 03:40:00.623580
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    from functools import partial
    get_response = partial(RequestTimeout, status_code=408)
    assert get_response("408 Request Timeout")

# Generated at 2022-06-24 03:40:02.736025
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("error message", 1001)
    except Exception as e:
        assert e.message == "error message"
        assert e.status_code == 416
        assert e.headers == {"Content-Range": "bytes */1001"}

# Generated at 2022-06-24 03:40:07.071495
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    too_long_msg = "message length is too long"
    payload_too_large = PayloadTooLarge(too_long_msg)
    assert payload_too_large.message == too_long_msg
    assert payload_too_large.status_code == 413
    assert payload_too_large.quiet is False

# Generated at 2022-06-24 03:40:09.437218
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    error = HeaderExpectationFailed(message="Test HeaderExpectationFailed", status_code=417)
    assert isinstance(error, SanicException)


# Generated at 2022-06-24 03:40:12.786692
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout = RequestTimeout("Timeout", status_code=408)
    assert timeout.status_code == 408
    assert timeout.message == "Timeout"


# Generated at 2022-06-24 03:40:16.371986
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = 'GET'
    allowed_methods = ['DELETE','POST']
    message = "You can't do it because you are not allowed to."
    MethodNotSupported(message = message, method = method, allowed_methods = allowed_methods)


# Generated at 2022-06-24 03:40:22.355190
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Must be a dictionary")
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.args[0] == "Must be a dictionary"


# Generated at 2022-06-24 03:40:24.154047
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    result = PayloadTooLarge("message").status_code
    expected_result = 413
    assert result == expected_result



# Generated at 2022-06-24 03:40:27.225149
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('method not supported', 'GET', ('OPTIONS', 'POST'))
    except MethodNotSupported as err:
        assert err.status_code == 405
        assert err.headers == {'Allow': 'OPTIONS, POST'}

# Generated at 2022-06-24 03:40:29.714500
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large_object = PayloadTooLarge("payload is too large")
    assert payload_too_large_object.status_code == 413


# Generated at 2022-06-24 03:40:31.952646
# Unit test for constructor of class ServerError
def test_ServerError():
    ServerError(message="test", status_code=500)

# Generated at 2022-06-24 03:40:34.626457
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('custom string')
    except InvalidSignal as e:
        assert str(e) == 'custom string'

# Generated at 2022-06-24 03:40:38.178056
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    m = "Auth required."
    sc = 401
    s = "Basic"
    r = "Restricted Area"
    assert Unauthorized(m, sc, s, r) == Unauthorized(m, sc, s, r)



# Generated at 2022-06-24 03:40:40.371800
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(code=400)(SanicException)
    assert _sanic_exceptions[400] == SanicException

# Generated at 2022-06-24 03:40:47.980722
# Unit test for function abort
def test_abort():
    from py.test import raises

    with raises(ServerError):
        abort(500)

    with raises(NotFound):
        abort(404)

    with raises(InvalidUsage):
        abort(400)

    with raises(MethodNotSupported):
        abort(405)

    with raises(ServiceUnavailable):
        abort(503)

    with raises(RequestTimeout):
        abort(408)

    with raises(PayloadTooLarge):
        abort(413)

    with raises(Forbidden):
        abort(403)

    with raises(Unauthorized):
        abort(401)

# Generated at 2022-06-24 03:40:53.415136
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "Test message"
    path = ""
    relative_url = ""
    try:
        raise FileNotFound(message, path, relative_url)
    except FileNotFound as exc:
        assert exc.path == path
        assert exc.relative_url == relative_url
        assert exc.status_code == 404
        assert str(exc) == message
        assert exc.args == (message,)

# Generated at 2022-06-24 03:40:54.264139
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("error")

# Generated at 2022-06-24 03:40:56.281423
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("404")
    except NotFound as exc:
        assert exc.status_code == 404
        assert exc.message == "404"



# Generated at 2022-06-24 03:41:00.262382
# Unit test for function abort
def test_abort():
    try:
        abort(status_code=400)
    except InvalidUsage as e:
        assert e.status_code == 400
    try:
        abort(status_code=403)
    except Forbidden as e:
        assert e.status_code == 403


# Generated at 2022-06-24 03:41:02.641533
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("errormessage")
    assert e.args[0] == "errormessage"
    assert e.status_code == 500



# Generated at 2022-06-24 03:41:05.498451
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise(Forbidden("Test forbidden", status_code=403))
    except SanicException as e:
        assert e.message == "Test forbidden"
        assert e.status_code == 403


# Generated at 2022-06-24 03:41:08.532645
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable()
    except ServiceUnavailable as e:
        assert e.status_code == 503


# Generated at 2022-06-24 03:41:12.315715
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as context:
        abort(404)
    assert context.value.status_code == 404
    assert str(context.value) == 'Not Found'
    with pytest.raises(InvalidUsage) as context:
        abort(400)
    assert context.value.status_code == 400
    assert str(context.value) == 'Bad Request'

# Generated at 2022-06-24 03:41:12.977763
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    pass

# Generated at 2022-06-24 03:41:19.515914
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(ContentRangeError):
        raise InvalidRangeType(
            "the first byte-range-spec in a byte-range-set"
            " MUST have a first-byte-pos that is less than or"
            " equal to the last-byte-pos, for %s",
        )

# Generated at 2022-06-24 03:41:23.860040
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = ContentRange(0, 0, 9)
    with pytest.raises(ContentRangeError) as err:
        raise ContentRangeError("Range Not Satisfiable.", content_range)
    assert err.value.headers["Content-Range"] == "bytes */9"

# Generated at 2022-06-24 03:41:31.640285
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
    else:
        assert 0, "Should've thrown exception"

    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    else:
        assert 0, "Should've thrown exception"

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
    else:
        assert 0, "Should've thrown exception"

    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
    else:
        assert 0, "Should've thrown exception"

# Generated at 2022-06-24 03:41:42.461312
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present:
    unauthorized = Unauthorized("Auth required.",scheme="Basic",realm="Restricted Area")
    assert unauthorized.status_code == 401
    assert unauthorized.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'

    # With a Digest auth-scheme, things are a bit more complicated:
    unauthorized = Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    assert unauthorized.status_code == 401

# Generated at 2022-06-24 03:41:43.488020
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert isinstance(Forbidden(), ServerError)

# Generated at 2022-06-24 03:41:45.829015
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound("not found").status_code == 404
    assert NotFound("not found", 404).status_code == 404
    assert NotFound("not found").message == "not found"


# Generated at 2022-06-24 03:41:51.847326
# Unit test for constructor of class SanicException
def test_SanicException():
    # Constructor should take message and status_code as input, without
    # status_code, it will be set to None
    msg = 'error message'
    exception = SanicException(message = msg)
    assert exception.message == msg
    assert exception.status_code == None
    # With a given status_code, status_code will be set to the given value
    status_code = 404
    exception = SanicException(message = msg, status_code = status_code)
    assert exception.message == msg
    assert exception.status_code == status_code



# Generated at 2022-06-24 03:41:55.739104
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert _sanic_exceptions[400] == TestException


# Unit tests for abort()

# Generated at 2022-06-24 03:41:58.272585
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("401")
    except ServiceUnavailable as e:
        assert(e.status_code == 503)


# Generated at 2022-06-24 03:42:01.214890
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    message = "Error: Invalid field"
    obj = InvalidUsage(message)
    assert obj.status_code == 400
    assert obj.message == message

# Generated at 2022-06-24 03:42:07.120248
# Unit test for constructor of class SanicException
def test_SanicException():
    # call function to test
    sanic_exception = SanicException(message="404 Not Found", status_code=404, quiet=False)

    # assert
    assert sanic_exception.__str__() == "404 Not Found"
    assert sanic_exception.status_code == 404
    assert sanic_exception.quiet == False

# Generated at 2022-06-24 03:42:11.352758
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized(message="Auth required.", scheme="Basic")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Basic"}
    try:
        raise Unauthorized(message="Auth required.", scheme="Digest", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Digest realm=\"Restricted Area\""}


# Generated at 2022-06-24 03:42:12.804346
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError):
        raise ContentRangeError("First byte position is not valid.", 100)

# Generated at 2022-06-24 03:42:16.051449
# Unit test for constructor of class Forbidden
def test_Forbidden():
    res = Forbidden("You cannot do that!", 403)
    assert res.status_code == 403
    assert res.quiet == True

if __name__ == '__main__':
    test_Forbidden()

# Generated at 2022-06-24 03:42:19.802824
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('InvalidUsage')
    except Exception as e:
        assert e.status_code == 400
        assert e.args[0] == 'InvalidUsage'


# Generated at 2022-06-24 03:42:28.543143
# Unit test for function abort
def test_abort():
    """
    Test the abort function, ensuring the expected exceptions are raised.
    """
    _test_abort(200, "OK")
    _test_abort(404, "Not Found")
    _test_abort(405, "Method Not Allowed")
    _test_abort(408, "Request Timeout")
    _test_abort(413, "Payload Too Large")
    _test_abort(416, "Range Not Satisfiable")
    _test_abort(417, "Expectation Failed")
    _test_abort(500, "Internal Server Error")
    _test_abort(503, "Service Unavailable")



# Generated at 2022-06-24 03:42:32.583115
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Not Found")
    except NotFound as e2:
        assert e2.status_code == 404
        assert e2.__str__() == "Not Found"


# Generated at 2022-06-24 03:42:35.892892
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Bad request.", status_code=400)
    except InvalidUsage as exc:
        assert exc.message == "Bad request."
        assert exc.status_code == 400


# Generated at 2022-06-24 03:42:38.144796
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage("hello")
    assert exception.message == "hello"
    assert exception.status_code == 400


# Generated at 2022-06-24 03:42:40.295900
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable):
        raise ServiceUnavailable("Test")


# Generated at 2022-06-24 03:42:42.810011
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message="Test ServerError")
    except ServerError as e:
        assert e.message == "Test ServerError"
        assert e.status_code == 500


# Generated at 2022-06-24 03:42:45.834294
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound("test message",status_code=404)
    assert exception.status_code == 404
    assert exception.message == "test message"
    assert exception.quiet == True



# Generated at 2022-06-24 03:42:50.080867
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError) as excinfo:
        raise URLBuildError("b'\\xfe'")
    assert "URLBuildError: b'\\xfe'" in str(excinfo.value)


# Generated at 2022-06-24 03:42:53.239836
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test ServerError.")
    except ServerError as err:
        assert err.message == "Test ServerError."
        assert err.status_code == 500
        assert not err.quiet

# Generated at 2022-06-24 03:42:55.451512
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exc = ContentRangeError('message', 'content_range')
    assert exc.headers == {'Content-Range': 'bytes */content_range'}

# Generated at 2022-06-24 03:42:57.387036
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h_e_f = HeaderExpectationFailed("message")
    assert h_e_f.status_code == 417

# Generated at 2022-06-24 03:43:02.630004
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "MethodNotSupported"
    method = "method"
    allowed_methods = ["allowed_method1", "allowed_method2"]
    methodNotSupportedException = MethodNotSupported(message, method, allowed_methods)
    assert methodNotSupportedException.message == message
    assert methodNotSupportedException.headers["Allow"] == "allowed_method1, allowed_method2"


# Generated at 2022-06-24 03:43:07.279714
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    error = FileNotFound('file not found','some_directory','some_url')
    assert error.path == 'some_directory'
    assert error.relative_url == 'some_url'
    assert 'FileNotFound' in error.__class__.__name__



# Generated at 2022-06-24 03:43:13.481559
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "message"
    method = "method"
    allowed_methods = ["allowed_methods"]
    method_not_supported = MethodNotSupported(message, method, allowed_methods)
    assert method_not_supported.args == (message,)
    assert method_not_supported.headers == {"Allow": ", ".join(allowed_methods)}


# Generated at 2022-06-24 03:43:16.615959
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("file.txt")
    except PyFileError as e:
        assert e.args[0] == "could not execute config file %s"
        assert e.args[1] == "file.txt"

# Generated at 2022-06-24 03:43:19.787817
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Header is not found!')
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.message == 'Header is not found!'

# Generated at 2022-06-24 03:43:21.312531
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    obj = HeaderExpectationFailed('hello', None)
    assert obj.status_code == 417

# Generated at 2022-06-24 03:43:26.279980
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("this is message", "method", "allowed_methods")
    except MethodNotSupported as e:
        assert e.message == "this is message"
        assert e.status_code == 405

# Generated at 2022-06-24 03:43:29.024599
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Invalid signal', 'hello')
    except InvalidSignal as e:
        assert e.args[0]== 'Invalid signal'


# Generated at 2022-06-24 03:43:34.042782
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("404 not found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "404 not found"
        assert e.args == ("404 not found",)


# Generated at 2022-06-24 03:43:39.553561
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    content_range = ContentRange(0, 9, 10)
    with pytest.raises(Exception) as excinfo:
        SanicException("Message", status_code=500, quiet=False)
        SanicException("Message")
        InvalidRangeType("Message", content_range)
    assert excinfo.type == InvalidRangeType
    assert excinfo.value.args == ("Message",)

# Generated at 2022-06-24 03:43:42.984598
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Forbidden!")
    except Forbidden as error:
        assert error.__str__() == "Forbidden!"
        assert error.status_code == 403


# Generated at 2022-06-24 03:43:45.797684
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    from nose.tools import eq_
    with pytest.raises(ServiceUnavailable) as exc_info:
        raise ServiceUnavailable('test')
    eq_(exc_info.value.status_code, 503)

# Generated at 2022-06-24 03:43:53.426432
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Exception as e:
        assert "<Unauthorized: 401 Unauthorized>" == str(e)
        assert 401 == e.status_code
        assert {'WWW-Authenticate': 'Basic realm="Restricted Area"'} == e.headers

# Generated at 2022-06-24 03:43:57.091447
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message","path","relative_url")
    except FileNotFound as e:
        print("message: ",e.message)
        print("path: ",e.path)
        print("relative_url: ",e.relative_url)

# Generated at 2022-06-24 03:43:59.914799
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    e = HeaderExpectationFailed(b"You are not expected to be here")
    assert e.status_code == 417
    assert e.message == "You are not expected to be here"

# Generated at 2022-06-24 03:44:04.258053
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # Arrange
    test1 = MethodNotSupported("message", "one", ["one"])
    test2 = MethodNotSupported("message", "two", ["one", "two", "three"])

    # Assert
    assert test1.headers['Allow'] == "one"
    assert test2.headers['Allow'] == "one, two, three"

# Generated at 2022-06-24 03:44:05.810324
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    H = HeaderExpectationFailed("")

# Generated at 2022-06-24 03:44:07.000404
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage("lalala")

# Generated at 2022-06-24 03:44:09.164844
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message='Invalid Token')
    except HeaderNotFound as err:
        assert(err.status_code == 400)
        assert(err.message == 'Invalid Token')

# Generated at 2022-06-24 03:44:10.966810
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test = PyFileError("test")
    assert test.args == ('could not execute config file %s', 'test')

# Generated at 2022-06-24 03:44:14.108946
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("abc")
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == "abc"



# Generated at 2022-06-24 03:44:16.707163
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Server Error")
    except Exception as e:
        assert e.message == "Server Error"
        assert e.quiet == True
        assert e.status_code == 500


# Generated at 2022-06-24 03:44:21.748012
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "error"
    status_code = 600
    sanic_exception = SanicException(message, status_code)
    assert sanic_exception.status_code == status_code
    assert sanic_exception.__str__() == message


# Generated at 2022-06-24 03:44:28.298185
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Test header not found")
    except HeaderNotFound:
        header_not_found = HeaderNotFound("Test header not found")
        assert header_not_found.status_code == 400
        assert header_not_found.message == "Test header not found"
        assert header_not_found.quiet is None


# Generated at 2022-06-24 03:44:33.417972
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout = RequestTimeout(message='test', status_code=408)
    assert timeout.message == 'test'
    assert timeout.status_code == 408



# Generated at 2022-06-24 03:44:41.196496
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestNotFound(SanicException):
        pass
    @add_status_code(404, quiet=True)
    class TestInvalidUsage(SanicException):
        pass

    TestNotFound.status_code = 400
    TestInvalidUsage.status_code = 404
    TestInvalidUsage.quiet = True
    assert TestNotFound.status_code == 400
    assert TestInvalidUsage.quiet == True
    assert TestInvalidUsage.status_code == 404

# Generated at 2022-06-24 03:44:45.977085
# Unit test for constructor of class ServerError
def test_ServerError():
    print("test class ServerError ...")
    try:
        raise ServerError("ServerError Exception 1")
    except ServerError as e:
        print("e.args:", e.args)
        print("e.message:", e.message)
        print("e.status_code:", e.status_code)


# Generated at 2022-06-24 03:44:47.074335
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    _ = URLBuildError()


# Generated at 2022-06-24 03:44:53.815594
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as err:
        status_code = err.status_code
        headers = err.headers
        assert status_code == 401
        assert "WWW-Authenticate" in headers
        assert headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

# Generated at 2022-06-24 03:44:59.438190
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Error message", "content_range")
    except InvalidRangeType as e:
        assert(e.status_code == 416)
        assert(e.message == "Error message")
        assert(e.content_range == "content_range")
        assert(e.headers == {"Content-Range": "bytes */content_range"})

# Generated at 2022-06-24 03:45:02.038867
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("This is an error message")
    print("Error message: " + error.args[0] + error.args[1])


# Generated at 2022-06-24 03:45:06.170833
# Unit test for constructor of class PyFileError
def test_PyFileError():
    message = "could not execute config file abc.py"
    exception_message = "could not execute config file %s"
    py_file_name = "abc.py"
    with pytest.raises(PyFileError) as excinfo:
        raise PyFileError(py_file_name)
    assert str(excinfo.value) == message



# Generated at 2022-06-24 03:45:11.656051
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message="", status_code=404)
    except ServerError as e:
        assert e.status_code == 404
    except:
        assert False



# Generated at 2022-06-24 03:45:15.652394
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden("Test exception")
    try:
        raise Forbidden("Test exception")
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.status_code == 403


# Generated at 2022-06-24 03:45:22.712779
# Unit test for function abort
def test_abort():
    from sanic.helpers import STATUS_CODES
    try:
        abort(500)
    except SanicException as expected:
        assert expected.status_code == 500
        assert str(expected) == STATUS_CODES[500].decode("utf8")

    try:
        abort(404, "My error message")
    except SanicException as expected:
        assert expected.status_code == 404
        assert str(expected) == "My error message"

    try:
        abort(418, "My error message")
    except SanicException as expected:
        assert expected.status_code == 418
        assert str(expected) == "My error message"


# Here we add all the default exceptions that come with Sanic to the registry
# of status codes with the appropriate status code.
# We do this so instead of having to

# Generated at 2022-06-24 03:45:23.532089
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    obj = URLBuildError('Error')

# Generated at 2022-06-24 03:45:25.153103
# Unit test for constructor of class Forbidden
def test_Forbidden():
	forbidden = Forbidden("Forbidden!")
	assert forbidden.message == "Forbidden!"


# Generated at 2022-06-24 03:45:27.423392
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    def f():
        raise InvalidSignal('test', 'test')
    with pytest.raises(InvalidSignal):
        f()

# Generated at 2022-06-24 03:45:31.283872
# Unit test for function abort
def test_abort():
    assert abort
    assert abort(400)
    assert abort(404)
    assert abort(500)
    assert abort(503)
    assert abort(408)
    assert abort(416)
    assert abort(417)
    assert abort(417)
    assert abort(413)
    assert abort(401)

# Generated at 2022-06-24 03:45:39.923026
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    _sanic_exceptions = {}
    def add_status_code(code, quiet=None):
        def class_decorator(cls):
            cls.status_code = code
            if quiet or quiet is None and code != 500:
                cls.quiet = True
            _sanic_exceptions[code] = cls
            return cls
        return class_decorator
    @add_status_code(413)
    class PayloadTooLarge(SanicException):
        """
        **Status**: 413 Payload Too Large
        """
        pass 
    try:
        raise PayloadTooLarge("Payload too large.")
    except PayloadTooLarge as e:
        print(e)
        # **Status**: 413 Payload Too Large


# Generated at 2022-06-24 03:45:43.376472
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("invalid signal")
    except Exception as e:
        assert(str(e) == 'invalid signal')
        assert(type(e) == InvalidSignal)


# Generated at 2022-06-24 03:45:47.108804
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(TypeError) as e_info:
        raise InvalidRangeType("", None)
    assert str(e_info.value) == "Exception raised in test_InvalidRangeType: invalid range type"


# Generated at 2022-06-24 03:45:57.716440
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.message == "Not Found"
        assert e.status_code == 404
    else:
        raise Exception("Function abort doesn't raise exception")

    try:
        abort(404, "File not found")
    except NotFound as e:
        assert e.message == "File not found"
        assert e.status_code == 404
    else:
        raise Exception("Function abort doesn't raise exception")

    try:
        abort(400, "File not found")
    except InvalidUsage as e:
        assert e.message == "File not found"
        assert e.status_code == 400
    else:
        raise Exception("Function abort doesn't raise exception")


# Generated at 2022-06-24 03:45:59.951001
# Unit test for constructor of class PyFileError
def test_PyFileError():
    FileEx = PyFileError('fileerror')
    assert str(FileEx) == "could not execute config file fileerror"


# Generated at 2022-06-24 03:46:02.105016
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("/tmp/test.py")
    assert str(error) == "could not execute config file /tmp/test.py"

# Generated at 2022-06-24 03:46:04.179395
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Payload Too Large")
    except Exception as error:
        assert error.status_code == 413

# Generated at 2022-06-24 03:46:07.877645
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(705)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[705] == TestException

# Unit tests for function abort

# Generated at 2022-06-24 03:46:09.794795
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage("Invalid usage")
    assert error


# Generated at 2022-06-24 03:46:14.530918
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException) as excinfo:
        raise LoadFileException("LoadFileException failed")
    assert excinfo.value.message == "LoadFileException failed"
    assert excinfo.value.status_code == 500
    assert excinfo.value.__class__ == LoadFileException

# Generated at 2022-06-24 03:46:26.286883
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    e = SanicException("test")
    assert e.__class__.__name__ == "SanicException"
    assert e.message == "test"
    assert e.status_code == None
    assert e.quiet == None

    e = SanicException("test", 500)
    assert e.__class__.__name__ == "SanicException"
    assert e.message == "test"
    assert e.status_code == 500
    assert e.quiet == None

    e = SanicException("test", 500, True)
    assert e.__class__.__name__ == "SanicException"
    assert e.message == "test"
    assert e.status_code == 500
    assert e.quiet == True

    # Unit test for constructor of class LoadFileException
    e = LoadFileException("test")
    assert e

# Generated at 2022-06-24 03:46:28.459718
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound()
    except NotFound as e:
        assert e.status_code == 404
        assert type(e) == NotFound


# Generated at 2022-06-24 03:46:31.179263
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    my_error = URLBuildError('test')
    assert str(my_error) == 'test'

# Generated at 2022-06-24 03:46:40.003485
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("I am")
    assert exc.status_code == 417
    assert exc.message == "I am"
    assert exc.headers == {}

    exc = HeaderExpectationFailed("You are", headers={"Expires": "Not today"})
    assert exc.status_code == 417
    assert exc.message == "You are"
    assert exc.headers == {"Expires": "Not today"}

    exc = HeaderExpectationFailed("They are", headers={"Location": "/error"})
    assert exc.status_code == 417
    assert exc.message == "They are"
    assert exc.headers == {"Location": "/error"}


# Generated at 2022-06-24 03:46:41.842971
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage("wrong")
    assert a.message == "wrong"
    assert a.status_code == 400
    assert a.quiet is None


# Generated at 2022-06-24 03:46:46.245529
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound("404 not found")
    assert not_found.message == "404 not found"
    assert not_found.status_code == 404

if __name__ == "__main__":
    test_NotFound()
    try:
        abort(404)
    except NotFound as e:
        print(e.message)

# Generated at 2022-06-24 03:46:50.049460
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("InvalidArguments: InvalidArgument passed")
    except InvalidUsage as e:
        assert e.args[0] == "InvalidArguments: InvalidArgument passed"
        assert e.status_code == 400
        assert e.__class__.__name__ == "InvalidUsage"

# Generated at 2022-06-24 03:46:54.955322
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class NotFound(SanicException):
        pass
    assert getattr(NotFound, 'status_code', None) == 400
    try:
        raise NotFound()
    except SanicException as err:
        assert err.status_code == 400

    @add_status_code(405)
    class NotFound(SanicException):
        pass
    assert getattr(NotFound, 'status_code', None) == 405
    try:
        raise NotFound()
    except SanicException as err:
        assert err.status_code == 405

# Generated at 2022-06-24 03:47:07.232834
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    scheme = "Basic"
    realm = "Restricted Area"
    try:
        raise Unauthorized("Auth required.", scheme=scheme, realm=realm)
    except Unauthorized as e:
        assert (
            e.headers["WWW-Authenticate"]
            == f"{scheme} realm=\"{realm}\""
        )

    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"

# Generated at 2022-06-24 03:47:10.449666
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    obj = HeaderExpectationFailed('header_expectation_failed')
    obj.status_code == 417
    assert obj.status_code == 417
    assert obj.__class__.__name__ == 'HeaderExpectationFailed'

test_HeaderExpectationFailed()


# Generated at 2022-06-24 03:47:17.120050
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = 'The HTTP verb used is invalid for this endpoint'
    method = 'POST'
    allowed_methods = ['GET', 'POST']
    mns = MethodNotSupported(message, method, allowed_methods)
    assert mns.message == message
    assert mns.headers == {'Allow': 'GET, POST'}
    assert mns.method == method
    assert mns.allowed_methods == allowed_methods


# Generated at 2022-06-24 03:47:22.608469
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Using default message.
    expected = "Expectation failed."
    actual = HeaderExpectationFailed()
    assert actual.message == expected
    assert actual.status_code == 417

    # Using non-default message.
    expected = "Expectation failed with a non-default message"
    actual = HeaderExpectationFailed(expected)
    assert actual.message == expected
    assert actual.status_code == 417

# Generated at 2022-06-24 03:47:24.893803
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge):
        raise PayloadTooLarge("message")

