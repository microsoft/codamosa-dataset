

# Generated at 2022-06-24 03:37:29.145667
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('BAD REQUEST', 'GET', ['GET', 'POST'])
    except SanicException as e:
        assert(e.status_code == 405)
        assert(hasattr(e, 'headers'))
        assert(len(e.headers)==1)
        assert(e.headers['Allow'] == 'GET, POST')


# Generated at 2022-06-24 03:37:32.875474
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message="Error Message", status_code=400)
    except SanicException as exc:
        assert exc.status_code == 400
        assert exc.args[0] == "Error Message"
    else:
        raise Exception("SanicException not raised")



# Generated at 2022-06-24 03:37:39.225996
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    context = InvalidRangeType("test message", "test content_range")
    assert context.args[0] == "test message"
    assert context.headers["Content-Range"] == "bytes */test content_range"

if __name__ == "__main__":
    test_InvalidRangeType()

# Generated at 2022-06-24 03:37:46.787461
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    import os
    from unittest import mock
    path = os.getcwd()
    open_mock = mock.mock_open()

    with mock.patch('builtins.open', open_mock):
        try:
            raise LoadFileException('Error', path)
        except LoadFileException as e:
            assert e.args[0] == 'Error'
            assert e.args[1] == path
            assert e.path == path
            assert not os.path.exists(path)

# Generated at 2022-06-24 03:37:51.135031
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Test for the case when total is None
    with pytest.raises(AttributeError):
        exception = ContentRangeError("test message", None)
    # Test for the case when total is 0
    exception = ContentRangeError("test message", "0")
    assert exception.headers["Content-Range"] == "bytes */0"
    # Test for the case when total is 1
    exception = ContentRangeError("test message", "1")
    assert exception.headers["Content-Range"] == "bytes */1"
    # Test for the case when total is 2
    exception = ContentRangeError("test message", "2")
    assert exception.headers["Content-Range"] == "bytes */2"


# Generated at 2022-06-24 03:37:58.024854
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(status_code=404, quiet=False)
    except SanicException as err:
        assert err.status_code == 404
        assert err.quiet == False
        assert err.args == ('',)

    try:
        raise SanicException(message="not found", status_code=403, quiet=False)
    except SanicException as err:
        assert err.status_code == 403
        assert err.quiet == False
        assert err.args == ('not found',)


# Generated at 2022-06-24 03:38:02.369070
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("test_msg", "test_path", "test_relative_path")
    assert repr(err) == "test_msg"
    assert err.path == "test_path"
    assert err.relative_url == "test_relative_path"


# Generated at 2022-06-24 03:38:04.593286
# Unit test for constructor of class PyFileError
def test_PyFileError():
    import re
    error = PyFileError("test.py")
    assert re.match("could not execute config file.*", error.args[0]) is not None

# Generated at 2022-06-24 03:38:05.839629
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(Exception):
        error = PyFileError('testFile')

# Generated at 2022-06-24 03:38:11.058245
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as exc_info:
        raise ContentRangeError("message", content_range=12)
    assert exc_info.match("message")
    assert exc_info.value.headers == {"Content-Range" : "bytes */12" }


# Generated at 2022-06-24 03:38:20.694018
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass
    add_status_code(299)(TestClass)
    assert TestClass.status_code == 299
    assert TestClass.quiet == None
    add_status_code(300)(TestClass)
    assert TestClass.status_code == 300
    assert TestClass.quiet == True
    add_status_code(500, True)(TestClass)
    assert TestClass.status_code == 500
    assert TestClass.quiet == True
    add_status_code(500, False)(TestClass)
    assert TestClass.status_code == 500
    assert TestClass.quiet == False
    add_status_code(503)(TestClass)
    assert TestClass.status_code == 503
    assert TestClass.quiet == True

# Generated at 2022-06-24 03:38:23.269958
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    test_exc = InvalidSignal("Test Exception")
    assert test_exc.message == "Test Exception"
    assert test_exc.status_code == None

# Generated at 2022-06-24 03:38:33.992085
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required", scheme="Basic", realm="Restricted Area")
    except Unauthorized as ue:
        assert ue.args == ("Auth required",)
        assert ue.message == "Auth required"
        assert ue.status_code == 401
        assert ue.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    try:
        raise Unauthorized("Auth required", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as ue:
        assert ue.args == ("Auth required",)
        assert ue.message == "Auth required"
        assert ue.status_code == 401

# Generated at 2022-06-24 03:38:37.023006
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exc = LoadFileException(message="message")
    assert exc.message == "message"
    assert exc.status_code == 500
    assert exc.quiet == True

# Generated at 2022-06-24 03:38:40.111490
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test_file")
    except PyFileError as e:
        assert str(e) == "could not execute config file test_file"

# Unit tests for constructor of class FileNotFound

# Generated at 2022-06-24 03:38:42.389917
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test_ServiceUnavailable")
    except ServiceUnavailable as err:
        assert err.status_code == 503



# Generated at 2022-06-24 03:38:44.675904
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    obj = HeaderExpectationFailed(message='', status_code=417)
    assert obj.status_code == 417


# Generated at 2022-06-24 03:38:46.570867
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLError = URLBuildError('message')
    assert URLError.__repr__() == 'message'

# Generated at 2022-06-24 03:38:50.005506
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    x = InvalidSignal("hello")
    assert x.args[0] == "hello"

# Generated at 2022-06-24 03:38:53.590969
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test_URLBuildError")
    except Exception as e:
        assert str(e) == "test_URLBuildError"
        assert type(e) == URLBuildError and type(e) != SanicException

# Generated at 2022-06-24 03:39:02.973459
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method Not Supported"
    method = "GET"
    allowed_methods = ["GET", "POST"]
    e = MethodNotSupported(message, method, allowed_methods)
    assert (e.headers.get("Allow")) == "GET, POST"

# # Unit test for constructor of class Unauthorized
# def test_Unauthorized():
#     message = "Auth required."
#     scheme = "Basic"
#     realm = "Restricted Area"
#     e = Unauthorized(message, scheme, realm)
#     assert (e.headers.get("WWW-Authenticate")) == 'Basic realm="Restricted Area"'

# Generated at 2022-06-24 03:39:07.151782
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('signal not found')
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == 'signal not found'

# Generated at 2022-06-24 03:39:10.096315
# Unit test for constructor of class ServerError
def test_ServerError():
    server_error = ServerError("Test server error!")
    assert server_error.message == "Test server error!"
    assert server_error.status_code == 500


# Generated at 2022-06-24 03:39:12.470509
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('Request Timeout')
    except RequestTimeout as e:
        assert type(e) is RequestTimeout


# Generated at 2022-06-24 03:39:13.849470
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal('test')

# Generated at 2022-06-24 03:39:15.974093
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test")
    except PyFileError as e:
        assert str(e) == "could not execute config file test"

# Generated at 2022-06-24 03:39:18.538234
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = ContentRangeError('msg', 1)
    assert c.status_code == 416
    assert c.headers['Content-Range'] == 'bytes */1'


# Generated at 2022-06-24 03:39:20.818802
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    message = "invalid range type"
    content_range = '0-0/0'
    assert InvalidRangeType(message, content_range)

# Generated at 2022-06-24 03:39:27.894587
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert MethodNotSupported("test", "GET", ["GET"]).message == "test", \
        "message is not initialized properly"
    assert MethodNotSupported("test", "GET", ["GET"]).method == "GET", \
        "method is not initialized properly"
    assert MethodNotSupported("test", "GET", ["GET"]).allowed_methods == ["GET"],\
        "allowed_methods is not initialized properly"



# Generated at 2022-06-24 03:39:30.382445
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("This is a test")
    except SanicException as e:
        assert str(e) == "This is a test"



# Generated at 2022-06-24 03:39:38.729126
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    t = MethodNotSupported('Method Not Supported', 'PATCH', ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH'])
    assert t.message == 'Method Not Supported'
    assert t.method == 'PATCH'
    assert t.allowed_methods == ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']

test_MethodNotSupported()

# Generated at 2022-06-24 03:39:42.233411
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('test_InvalidUsage')
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == 'test_InvalidUsage'


# Generated at 2022-06-24 03:39:45.030963
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exc = InvalidUsage("balbal")

    assert exc.message == "balbal"
    assert exc.status_code == 400
    assert exc.quiet is True

# Generated at 2022-06-24 03:39:56.333280
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound):
        abort(404)
    with pytest.raises(NotFound):
        abort(404, "404 Not Found")
    with pytest.raises(InvalidUsage):
        abort(400)
    with pytest.raises(MethodNotSupported):
        abort(405)
    with pytest.raises(ServerError):
        abort(500)
    with pytest.raises(ServiceUnavailable):
        abort(503)
    with pytest.raises(RequestTimeout):
        abort(408)
    with pytest.raises(PayloadTooLarge):
        abort(413)
    with pytest.raises(HeaderExpectationFailed):
        abort(417)
    with pytest.raises(Forbidden):
        abort(403)

# Generated at 2022-06-24 03:39:58.013813
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test!")
    except InvalidSignal as err:
        print(err)

# Generated at 2022-06-24 03:40:00.052751
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    obj = MethodNotSupported('message', 'method', 'allowed_methods')
    assert obj.__class__ == MethodNotSupported and obj.message == 'message'

# Generated at 2022-06-24 03:40:03.535726
# Unit test for constructor of class Forbidden
def test_Forbidden():
    test_init= Forbidden("test",403)
    assert "test" in test_init.__str__()

# Generated at 2022-06-24 03:40:08.458312
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    status_code = 401
    message = 'Auth required'
    scheme = 'Basic'
    realm = 'Restricted Area'

    unauthorized = Unauthorized(message, status_code, scheme, realm=realm)
    assert unauthorized.message == message
    assert unauthorized.status_code == status_code
    assert unauthorized.scheme == scheme
    assert unauthorized.realm == realm

# Generated at 2022-06-24 03:40:10.712481
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = collections.namedtuple('ContentRange', ['total'])
    _ = ContentRangeError('sometest_message', content_range)



# Generated at 2022-06-24 03:40:12.709561
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test")
    except ServiceUnavailable:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:40:16.901597
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout_exception = RequestTimeout("Request Timeout")
    assert request_timeout_exception.status_code == 408
    print("Constructor of class RequestTimeout - Success!")


# Generated at 2022-06-24 03:40:21.471184
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    Initialize an object of class ServiceUnavailable using only the first
    parameter: message
    """
    try:
        raise ServiceUnavailable('Server Error')
    except ServiceUnavailable as e:
        assert e.message == 'Server Error'
        assert e.status_code == 503
        assert ServiceUnavailable.message == 'Server Error'
        assert ServiceUnavailable.status_code == 503

# Generated at 2022-06-24 03:40:24.907957
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound(message="", path="/blah", relative_url="")
    assert file_not_found.path == "/blah"
    assert file_not_found.relative_url == ""


# Generated at 2022-06-24 03:40:26.729310
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException('loadfileexception', 401, scheme='scheme', realm='realm')

# Generated at 2022-06-24 03:40:27.504477
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError('pyserver.py')

# Generated at 2022-06-24 03:40:29.368472
# Unit test for constructor of class NotFound
def test_NotFound():
    test = NotFound('error')
    assert test.status_code == 404
    assert test.message == 'error'
    assert test.quiet == True


# Generated at 2022-06-24 03:40:33.978749
# Unit test for constructor of class NotFound
def test_NotFound():
    message= 'test'
    status_code = 1
    exception = NotFound(message, status_code)
    assert exception.message == message and exception.status_code == status_code


# Generated at 2022-06-24 03:40:36.899026
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    expected = "test"
    exception = PayloadTooLarge(expected, None)
    actual = exception.__str__()
    assert actual == expected


# Generated at 2022-06-24 03:40:39.032592
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pl = PayloadTooLarge('message')
    assert pl.status_code == 413

# check if status code is set correctly

# Generated at 2022-06-24 03:40:41.249974
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("blah")
    except HeaderExpectationFailed as e:
        assert e.status_code == 417

# Generated at 2022-06-24 03:40:43.970142
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
	try:
		raise InvalidSignal("Invalid signal exists")	
	except InvalidSignal:
		print("Error occurred. The error is because InvalidSignal does not exist.")

# Generated at 2022-06-24 03:40:53.432163
# Unit test for constructor of class SanicException
def test_SanicException():
    # Testing message only
    try:
        raise SanicException("Testing only message")
    except SanicException as exc:
        assert exc.message == "Testing only message"
        assert exc.status_code is None
        assert exc.quiet is None

    # Testing message and status_code
    try:
        raise SanicException("Testing message and status", status_code=201)
    except SanicException as exc:
        assert exc.message == "Testing message and status"
        assert exc.status_code == 201
        assert exc.quiet is None

    # Testing message and quiet
    try:
        raise SanicException("Testing message and quiet", quiet=True)
    except SanicException as exc:
        assert exc.message == "Testing message and quiet"
        assert exc.status_code is None
        assert exc.quiet is True

# Generated at 2022-06-24 03:40:54.753146
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    temp = HeaderNotFound("testing")
    assert temp.message == "testing"

# Generated at 2022-06-24 03:40:58.670656
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("testheaderexpectationfailed")
    except HeaderExpectationFailed as err:
        assert err.status_code == 417
        assert err.message == "testheaderexpectationfailed"
    else:
        assert False, "Unexpected error"


# Generated at 2022-06-24 03:41:00.006491
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('test', 400)
        assert False
    except:
        assert True

# Generated at 2022-06-24 03:41:02.709945
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "test"
    path = "path"
    relative_url = "relative_url"
    file_not_found = FileNotFound(message, path, relative_url)
    assert file_not_found.path == path
    assert file_not_found.relative_url == relative_url
    assert file_not_found.message == message



# Generated at 2022-06-24 03:41:05.548965
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """
    Tests that PayloadTooLarge can be constructed
    """
    test = PayloadTooLarge("Too Large")
    assert(test.message) == "Too Large"
    assert(test.status_code) == 413

# Generated at 2022-06-24 03:41:09.499464
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound('header not found')
    assert isinstance(hnf, InvalidUsage)
    assert hnf.message == 'header not found'
    assert hnf.status_code == 400


# Generated at 2022-06-24 03:41:14.768503
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError) as excinfo:
        raise URLBuildError(message="Test message", status_code=500)
    assert excinfo.type is ServerError
    assert excinfo.value.__class__ is URLBuildError


# Generated at 2022-06-24 03:41:16.343127
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message="error")
    except HeaderNotFound as err:
        print(err)

# Generated at 2022-06-24 03:41:25.130848
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class CustomSanicException(SanicException):
        pass

    assert issubclass(_sanic_exceptions[201], CustomSanicException)
    assert _sanic_exceptions[201].status_code == 201
    assert _sanic_exceptions[201].quiet == True

    def assert_exception(code):
        try:
            assert _sanic_exceptions[code].status_code == code
        except Exception:
            assert False

    assert_exception(404)
    assert_exception(400)
    assert_exception(500)
    assert_exception(503)
    assert_exception(408)
    assert_exception(413)
    assert_exception(416)
    assert_exception(417)
    assert_exception(403)


# Generated at 2022-06-24 03:41:27.922859
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    error_msg = "Custom Error Message"
    with pytest.raises(RequestTimeout) as exception:
        raise RequestTimeout(error_msg, 408)

    assert error_msg in str(exception.value)

# Generated at 2022-06-24 03:41:30.513560
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("test","test");
        assert True;
    except HeaderExpectationFailed:
        assert True;
    except:
        assert False;


# Generated at 2022-06-24 03:41:41.587317
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # TODO: fix this test
    assert issubclass(Unauthorized, Exception)
    try:
        raise Unauthorized('Auth required.')
    except Unauthorized as exc:
        assert exc.message == 'Auth required.'
        assert exc.headers == {}
    try:
        raise Unauthorized('Auth required.',
                           scheme='Basic',
                           realm='Restricted Area')
    except Unauthorized as exc:
        assert exc.message == 'Auth required.'
        assert exc.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-24 03:41:44.616922
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    """
    Test that ContentRangeError has the required fields
    """
    error = ContentRangeError("An error message", 10)
    assert error.message == "An error message"
    assert error.headers == {"Content-Range": "bytes */10"}
    assert error.status_code == 416

# Generated at 2022-06-24 03:41:46.604171
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported):
        raise MethodNotSupported("Test", "GET", ["GET", "POST"])
    


# Generated at 2022-06-24 03:41:52.241460
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    ex = HeaderExpectationFailed("message", "header_expectation")
    assert ex.status_code == 417
    assert ex.message == "message"

# Generated at 2022-06-24 03:41:57.621462
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    msg = "Too large"
    ex = PayloadTooLarge(msg)
    assert ex.status_code == 413
    assert ex.message == msg


# Generated at 2022-06-24 03:42:03.031071
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test_msg = "Unit test for constructor of class LoadFileException"
    ex = LoadFileException(test_msg)
    # check message
    assert ex.args[0] == test_msg
    # check status code is None
    assert ex.status_code is None
    # check whether is instance of SanicException
    assert isinstance(ex, SanicException)

# Generated at 2022-06-24 03:42:13.656037
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[405] == MethodNotSupported
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert _sanic_exceptions[408] == RequestTimeout
    assert _sanic_exceptions[413] == PayloadTooLarge
    assert _sanic_exceptions[416] == ContentRangeError
    assert _sanic_exceptions[417] == HeaderExpectationFailed
    assert _sanic_exceptions[403] == Forbidden
    assert _sanic_exceptions[401] == Unauthorized

# Generated at 2022-06-24 03:42:16.029579
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    p = PayloadTooLarge(message="test", status_code=413)
    assert p.status_code == 413
    assert p.message == "test"


# Generated at 2022-06-24 03:42:18.333189
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError('error')
    assert err.status_code == 500
    assert str(err) == 'error'

# Generated at 2022-06-24 03:42:22.602119
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("fail", None)
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.quiet == True
        assert isinstance(e, SanicException)

# Generated at 2022-06-24 03:42:23.451065
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pl = PayloadTooLarge("test")
    assert pl.status_code == 413

# Generated at 2022-06-24 03:42:27.558553
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    # Test if the input of constructor is 1.name of the exception,
    # 2.the message which describes the exception
    try:
        raise InvalidSignal("message")
    except InvalidSignal as e:
        assert e.message == "message"


# Generated at 2022-06-24 03:42:30.069143
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("", "")
    except SanicException:
        pass

# Generated at 2022-06-24 03:42:33.274140
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("error message")
    except PayloadTooLarge as ex:
        assert str(ex) == "error message"

# Generated at 2022-06-24 03:42:37.278737
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("invalid usage")
        pytest.fail("invalid usage")
    except InvalidUsage as exc:
        assert exc.status_code == 400
        assert str(exc) == "invalid usage"


# Generated at 2022-06-24 03:42:43.568865
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = 'test'
    method = 'GET'
    allowed_methods = ['POST', 'PUT']
    method_not_supported = MethodNotSupported(message, method, allowed_methods)

    assert method_not_supported.headers == {'Allow': 'POST, PUT'}
    assert method_not_supported.status_code == 405
    assert method_not_supported.message == message
    assert isinstance(method_not_supported, SanicException)



# Generated at 2022-06-24 03:42:48.436052
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    filename = 'test/test_helpers.py'
    try:
        raise FileNotFound('', filename, 'test_helpers.py')
    except FileNotFound as fnf:
        assert fnf.path == filename
        assert fnf.relative_url == 'test_helpers.py'


# Generated at 2022-06-24 03:42:51.051119
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('Not allowed')
    except HeaderExpectationFailed as error:
        print(error)

# Generated at 2022-06-24 03:42:55.354624
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed = HeaderExpectationFailed(message="expectation failed", status_code=417)
    assert header_expectation_failed.status_code == 417
    assert header_expectation_failed.quiet == True
    assert header_expectation_failed.message == "expectation failed"

# Generated at 2022-06-24 03:42:59.434531
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException) as excinfo:
        raise LoadFileException("message", status_code=999)
    assert excinfo.value.args[0] == "message"
    assert excinfo.value.status_code == 999


# Generated at 2022-06-24 03:43:01.237102
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("message", 123)
    assert error.status_code == 416
    assert error.headers['Content-Range'] == "bytes */123"

# Generated at 2022-06-24 03:43:05.085111
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    irType = InvalidRangeType("RangeNotSatisfied",10)
    assert irType.status_code == 416
    assert irType.message == "RangeNotSatisfied"
    assert irType.headers == {"Content-Range": "bytes */10"}

# Generated at 2022-06-24 03:43:07.159983
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage("message")
    assert exception.message == "message"
    assert exception.status_code == 400

# Generated at 2022-06-24 03:43:10.854665
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('request timeout')
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == 'request timeout'

# Generated at 2022-06-24 03:43:16.486679
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = "Some path"
    relative_url = "Some relative url"
    exception1 = FileNotFound("File not found", path, relative_url)
    assert exception1.path == path
    assert exception1.relative_url == relative_url


# Generated at 2022-06-24 03:43:20.551833
# Unit test for function abort
def test_abort():
    try:
        abort(403, "Hi there")
        assert False
    except Forbidden as e:
        assert e.message == "Hi there"
        assert e.status_code == 403

    try:
        abort(408)
        assert False
    except RequestTimeout as e:
        assert e.message == "Request Timeout"
        assert e.status_code == 408

# Generated at 2022-06-24 03:43:24.438895
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        total = 256
        raise ContentRangeError("Range Not Satisfiable", total)
    except ContentRangeError as e:
        # print(e.m_Message)
        assert e.message == "Range Not Satisfiable"
        # print(e.m_Headers)
        expected_headers = {'Content-Range': 'bytes */256'}
        assert e.headers == expected_headers

test_ContentRangeError()


# Generated at 2022-06-24 03:43:30.028718
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200,True)
    class TestClass:
        pass
    test = TestClass('test',200)
    assert test.status_code == 200
    assert test.quiet == True
    assert test.args == ('test',)


# Generated at 2022-06-24 03:43:36.621131
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    import unittest

    class MyTests(unittest.TestCase):
        def test(self):
            x = MethodNotSupported("hello", "method", ["methods"])
            self.assertEqual(x.headers, {"Allow": "methods"})
            self.assertEqual(x.status_code, 405)

    # Run the unittest
    unittest.main()

# Generated at 2022-06-24 03:43:39.184890
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    good_loadfile = LoadFileException("Test LoadFileException")
    assert good_loadfile.status_code == None
    bad_loadfile = LoadFileException("Test Bad LoadFileException", status_code=500)
    assert bad_loadfile.status_code == 500



# Generated at 2022-06-24 03:43:42.133863
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('khalil')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.strerror == 'khalil'

# Generated at 2022-06-24 03:43:44.977284
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "The header couldn't be found in the request"
    exc = HeaderNotFound(message)
    assert exc.status_code == 400
    assert exc.message == message
    assert exc.quiet is False

# Generated at 2022-06-24 03:43:46.503707
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    msg_str = "Request timed out"
    req_timeout = RequestTimeout(message=msg_str)
    assert req_timeout.status_code == 408
    assert req_timeout.message == msg_str


# Generated at 2022-06-24 03:43:48.366066
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException("load file error")



# Generated at 2022-06-24 03:43:51.231503
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assertInvalidUsage("InvalidUsage constructor test")

# Generated at 2022-06-24 03:43:54.496913
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported("message", "method", "allowed_methods")
    assert mns.message == "message"
    assert mns.status_code == 405
    assert mns.headers["Allow"] == "allowed_methods"

# Generated at 2022-06-24 03:44:05.142414
# Unit test for function add_status_code
def test_add_status_code():
    """ Test add_status_code function with and without providing status code
    """
    @add_status_code(400)
    class MyException(SanicException):
        """ Test class with status code 400 and without """
        pass
    try:
        raise MyException("Test This")
    except MyException as e:
        if e.status_code != 400:
            raise Exception("Test 1 failed")

    @add_status_code(405)
    class MyException2(SanicException):
        """ Test class with status code 405 and without """
        pass
    try:
        raise MyException2("Test This")
    except MyException2 as e:
        if e.status_code != 405:
            raise Exception("Test 2 failed")

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:44:07.956634
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('/home/user/sanic/config.py')
    except PyFileError as e:
        assert type(e) == PyFileError

# Generated at 2022-06-24 03:44:13.948734
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(Exception) as context:
        try:
            raise InvalidRangeType("InvalidRangeType", 1)
        except InvalidRangeType as er:
            assert er.args[0] == "InvalidRangeType"
            assert er.args[1] == 1
            assert er.status_code == 416
            assert er.headers["Content-Range"] == "bytes */1"
            raise er

# Generated at 2022-06-24 03:44:24.253935
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == 'Not Found'

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == 'Internal Server Error'

    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == 'Service Unavailable'

    try:
        abort(503, 'Custom error message')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == 'Custom error message'

    try:
        abort(416)
    except ContentRangeError as e:
        assert e.status_code == 416

# Generated at 2022-06-24 03:44:29.057542
# Unit test for function add_status_code
def test_add_status_code():
    class MyError(SanicException):
        ...

    @add_status_code(400)
    class NewError(SanicException):
        ...

    class NewError2(SanicException):
        ...

    NewError2 = add_status_code(401)(NewError2)

    assert MyError.get_status() == 500
    assert MyError(message="MyError").get_status() == 500

    assert NewError.get_status() == 400
    assert NewError(message="NewError").get_status() == 400

    assert NewError2.get_status() == 401
    assert NewError2(message="NewError2").get_status() == 401

# Generated at 2022-06-24 03:44:35.944668
# Unit test for function abort
def test_abort():
    try:
        abort(500)
        assert False
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    try:
        abort(410)
        assert False
    except SanicException as e:
        assert e.status_code == 410
        assert e.message == "Gone"

# Generated at 2022-06-24 03:44:38.943960
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    myVar = HeaderNotFound('message', 'info')
    assert myVar.status_code == 400
    assert myVar.message == 'message'


# Generated at 2022-06-24 03:44:40.574288
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("error message")
    assert err.status_code == 400
    assert err.message == "error message"

# Generated at 2022-06-24 03:44:42.256194
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(None, None)
    except HeaderNotFound:
        pass

# Generated at 2022-06-24 03:44:45.489996
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('Request timeout')
    except Exception as e:
        assert(str(e) == 'RequestTimeout: Request timeout')
        assert(e.status_code == 408)


# Generated at 2022-06-24 03:44:47.817750
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    assert HeaderExpectationFailed("error message for HeaderExpectationFailed",
                                   status_code=417).status_code == 417

# Generated at 2022-06-24 03:44:51.737547
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("You are not authorized to do this")
    except SanicException as e:
        assert e.status_code == 403
        assert isinstance(e, Forbidden)
        assert e.message == "You are not authorized to do this"


# Generated at 2022-06-24 03:44:59.017798
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    f = open("testfile.txt", "w")
    f.write("This is test of SanicException.InvalidRangeType")
    f.close()
    try:
        f = open("testfile.txt", "r")
        f.seek(5)
        f.seek(0, 2)
        f.seek(5, 2)
        f.close()
    except IOError:
        print("Error: invalid range type")
    assert True

# Generated at 2022-06-24 03:45:02.730427
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # GIVEN
    valid_msg = 'This is a test message'

    # WHEN
    try:
        raise HeaderNotFound(valid_msg)
    except HeaderNotFound as e:
        pass

    # THEN
    assert valid_msg == e.args[0]

# Generated at 2022-06-24 03:45:06.916052
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("message", "content_range")
    except ContentRangeError as e:
        assert e.message == "message"
        assert e.headers == {"Content-Range": f"bytes */{'content_range'}"}


# Generated at 2022-06-24 03:45:11.761614
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_obj = Forbidden("Wrong input for the method")
    assert forbidden_obj.message == "Wrong input for the method"
    assert forbidden_obj.status_code == 403


# Generated at 2022-06-24 03:45:14.483562
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Abc")
    except HeaderNotFound as e:
        assert (e.status_code == 400)
        assert(e.message == "Abc")


# Generated at 2022-06-24 03:45:17.179331
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal("test")


# Generated at 2022-06-24 03:45:22.505730
# Unit test for constructor of class ServerError
def test_ServerError():
    import pytest
    try:
        raise ServerError(message="ServerError happened!", status_code=500)
    except ServerError as e:
        assert e.message == "ServerError happened!"
        assert e.status_code == 500
    else:
        pytest.fail(msg="Unexpected Exception: ServerError!", pytrace=False)

if __name__ == '__main__':
    test_ServerError()

# Generated at 2022-06-24 03:45:25.972005
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound")
    except HeaderNotFound as exception:
        assert isinstance(exception, HeaderNotFound)
        assert exception.status_code == 400
        assert exception.message == "HeaderNotFound"


# Generated at 2022-06-24 03:45:29.114580
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as exc_info:
        raise SanicException('test SanicException')
    assert exc_info.value.message == 'test SanicException'


# Generated at 2022-06-24 03:45:31.381572
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized('foo')
    except Unauthorized as e:
        assert e.args == ('foo',)


# Generated at 2022-06-24 03:45:35.609944
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test")
    except InvalidSignal as e:
        assert e.args[0] == "test"
        assert e.status_code == 400


# Generated at 2022-06-24 03:45:39.915439
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.")
    except SanicException as expected:
        assert expected.message == "Auth required."
        assert expected.status_code == 401
        assert expected.scheme is None
        assert expected.headers is None


# Generated at 2022-06-24 03:45:42.975069
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found = HeaderNotFound('Not Found!')
    assert header_not_found.status_code == 400
    assert header_not_found.message == 'Not Found!'

# Generated at 2022-06-24 03:45:54.450349
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException):
        SanicException(message = 'error')
    with pytest.raises(NotFound):
        SanicException(message = 'error', status_code = 404)
    with pytest.raises(InvalidUsage):
        SanicException(message = 'error', status_code = 400)
    with pytest.raises(MethodNotSupported):
        SanicException(message = 'error', status_code = 405)
    with pytest.raises(SanicException):
        SanicException(message = 'error', status_code = 500)
    with pytest.raises(ServiceUnavailable):
        SanicException(message = 'error', status_code = 503)

# Generated at 2022-06-24 03:46:00.256570
# Unit test for constructor of class Forbidden
def test_Forbidden():

    # Arrange
    msg = 'test_Forbidden'
    status_code = 403
    sanic_exception = Forbidden(message=msg, status_code=status_code)

    # Act
    actual = sanic_exception.__str__()

    # Assert
    assert msg == actual

# Generated at 2022-06-24 03:46:03.629930
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = 'Test Message'
    status_code = 417
    exception = HeaderExpectationFailed(message, status_code)
    assert exception.message == message
    assert exception.status_code == status_code


# Generated at 2022-06-24 03:46:12.754497
# Unit test for function abort
def test_abort():
    from sanic.exceptions import abort, NotFound

    try:
        abort(404, "File not found")
    except NotFound as ex:
        assert ex.message == "File not found"
        assert ex.status_code == 404

    try:
        abort(404)
    except NotFound as ex:
        assert ex.message == "404 - Not Found"
        assert ex.status_code == 404

    try:
        abort(500, "Server error")
    except NotFound as ex:
        assert ex.message == "Server error"
        assert ex.status_code == 500

# Generated at 2022-06-24 03:46:14.768848
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Missing args')
    except InvalidUsage as err:
        print(err)

# Generated at 2022-06-24 03:46:18.623030
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found = HeaderNotFound(message=None)
    assert isinstance(header_not_found, SanicException)
    assert header_not_found.message is None
    assert header_not_found.status_code == 400

# Generated at 2022-06-24 03:46:22.507301
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden(message="this is Forbidden")
    except Forbidden as err:
        assert err.status_code == 403
        assert err.message == "this is Forbidden"


# Generated at 2022-06-24 03:46:27.357549
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Success', 404)
    except SanicException as e:
        assert e.status_code == 404
        assert str(e) == 'Success'

# Generated at 2022-06-24 03:46:29.900457
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("")
    except Exception as e:
        assert type(e), ServiceUnavailable

# Generated at 2022-06-24 03:46:33.347082
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("unavailable")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "unavailable"


# Generated at 2022-06-24 03:46:40.108113
# Unit test for constructor of class NotFound
def test_NotFound():
    """
    Test if user can provide the parameters for the constructor of class NotFound
    """
    try:
        raise NotFound('NotFound test', status_code=123, quiet=True)
    except NotFound as e:
        assert e.message == 'NotFound test'
        assert e.status_code == 123
        assert e.quiet == True



# Generated at 2022-06-24 03:46:41.709650
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception_test = HeaderExpectationFailed('abandon', 'fail')
    assert exception_test.message == 'abandon'
    assert exception_test.status_code == 417

# Generated at 2022-06-24 03:46:45.112714
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "any"
    pyfileerror = PyFileError(file)
    assert(pyfileerror.args[0] == "could not execute config file %s")
    assert(pyfileerror.args[1] == file)

# Generated at 2022-06-24 03:46:47.880193
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    >>> SanicException(message="This is a test", status_code=400, quiet=True)
    SanicException(message='This is a test', status_code=400, quiet=True)
    """
    pass

# Generated at 2022-06-24 03:46:53.829761
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout!")
    except RequestTimeout as e:
        assert "Request Timeout!" == str(e)
        assert 408 == e.status_code
        assert e.quiet == True



# Generated at 2022-06-24 03:46:55.568740
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("test")
    except SanicException as S:
        assert S.message == "test"
        assert S.status_code == None
        assert S.quiet == False


# Generated at 2022-06-24 03:46:59.806990
# Unit test for constructor of class NotFound
def test_NotFound():
    error_message = "The Page You Are Looking For Is Not Found"
    try:
        raise NotFound(error_message)
    except NotFound as err:
        assert err.message == error_message, "Error message is not correct"


# Generated at 2022-06-24 03:47:01.739260
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as err:
        raise PyFileError("p.py")

# Generated at 2022-06-24 03:47:05.372528
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception =  ServiceUnavailable('error message')
    assert exception.message == 'error message'
    assert exception.status_code == 503
    assert exception.headers == None
    assert exception.quiet == True


# Generated at 2022-06-24 03:47:09.390451
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exception = ContentRangeError(
            message='Message from user', content_range={
                'total': '1234567'
            })
    assert exception.message == 'Message from user'
    assert exception.headers == {'Content-Range': 'bytes */1234567'}
    assert exception.content_range == {'total': '1234567'}
    assert exception.status_code == 416

# Generated at 2022-06-24 03:47:16.321501
# Unit test for function abort
def test_abort():
    try:
        abort(418)
    except Exception as e:
        assert e.status_code == 418
        assert e.message == b"I'm a teapot"
        assert isinstance(e, SanicException)
        assert str(e) == "I'm a teapot"

    try:
        abort(418, message='i am a teapot')
    except Exception as e:
        assert e.status_code == 418
        assert e.message == 'i am a teapot'
        assert isinstance(e, SanicException)
        assert str(e) == 'i am a teapot'

    try:
        abort(202)
    except Exception as e:
        assert e.status_code == 202
        assert e.message == b"Accepted"

# Generated at 2022-06-24 03:47:17.090812
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLBuildError("")

# Generated at 2022-06-24 03:47:19.313229
# Unit test for constructor of class NotFound
def test_NotFound():
    assert(NotFound("404 Not Found"))
    assert(NotFound("404"))
    assert(NotFound("Not Found"))



# Generated at 2022-06-24 03:47:24.066508
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    """
    test URLBuildError constructor
    """

    try:
        raise URLBuildError("err message")
    except:
        assert isinstance(sys.exc_info()[1], URLBuildError)
        assert sys.exc_info()[1].__str__() == 'err message'


# Generated at 2022-06-24 03:47:27.976652
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound):
        abort(404)

    with pytest.raises(NotFound) as exc_info:
        abort(404, "Not Found")
    assert str(exc_info.value) == "Not Found"

