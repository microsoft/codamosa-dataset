

# Generated at 2022-06-24 03:37:13.194171
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException("", status_code=404)
    assert exception.status_code == 404
    assert exception.message == ""

# Generated at 2022-06-24 03:37:15.933620
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    hef_ins = HeaderExpectationFailed('test')
    assert hef_ins.message == 'test'
    assert hef_ins.status_code == 417


# Generated at 2022-06-24 03:37:19.730254
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    e = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert e.status_code == 401
    assert e.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'

# Generated at 2022-06-24 03:37:23.753582
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # raise an exception
    try:
        raise ServiceUnavailable("Server unavailable")
    except ServiceUnavailable as err:
        assert isinstance(err, ServiceUnavailable)
        pass
    else:
        assert False  # exception not raised

# Generated at 2022-06-24 03:37:27.144431
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("test", object)
    except SanicException as e:
        assert e.status_code == 416
        assert e.headers["Content-Range"] == "bytes */<object object at 0x7fecb0e0dd10>"

# Generated at 2022-06-24 03:37:35.751042
# Unit test for constructor of class SanicException

# Generated at 2022-06-24 03:37:37.555709
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Range not satisfiable", 10)
    except Exception as exception:
        if exception.status_code != 416:
            assert False


# Generated at 2022-06-24 03:37:46.734019
# Unit test for function add_status_code
def test_add_status_code():
    def new_exception(message, status_code=None, quiet=None):
        return SanicException(message, status_code, quiet)
    assert NotFound.status_code == 404
    assert InvalidUsage.status_code == 400
    assert ServerError.status_code == 500
    assert ServiceUnavailable.status_code == 503
    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[400] == InvalidUsage
    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[503] == ServiceUnavailable
    assert NotFound.quiet
    assert InvalidUsage.quiet
    assert not ServerError.quiet
    assert not ServiceUnavailable.quiet
    def function_decorator(obj):
        return obj

# Generated at 2022-06-24 03:37:48.430348
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("test")
    assert exc.status_code == 417



# Generated at 2022-06-24 03:37:50.371876
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError('message', 'content_range')
    assert e.headers == {'Content-Range': 'bytes */content_range'}

# Generated at 2022-06-24 03:37:55.642134
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(f"Test's message", 1000)
    except ContentRangeError as cr_e:
        assert cr_e.message == "Test's message"
        assert cr_e.headers == {'Content-Range': 'bytes */1000'}
        assert cr_e.quiet == False
        assert cr_e.status_code == 416

# Generated at 2022-06-24 03:38:00.193862
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('test', 'test2')
    except Exception as e:
        assert e.args[0] == 'test'
        assert e.status_code == 417
        assert e.quiet == False
        assert e.headers['Allow'] == "test2"

# Generated at 2022-06-24 03:38:09.857851
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test for basic auth-scheme
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'
    # Test for digest auth-scheme
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers['WWW-Authenticate'] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-24 03:38:14.625311
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    args = dict(message="Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    try:
        raise Unauthorized(**args)
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-24 03:38:17.312683
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('SIGTERM', 15, None)
    except InvalidSignal as e:
        assert e.__str__() == 'SIGTERM'

# Generated at 2022-06-24 03:38:20.978509
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    msg = 'This is a custom message'
    try:
        raise ServiceUnavailable(message=msg)
    except ServiceUnavailable as e:
        assert e.message == msg

if __name__ == "__main__":
    test_ServiceUnavailable()

# Generated at 2022-06-24 03:38:23.536543
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("message")
    except InvalidSignal as e:
        assert e.args[0] == "message"

# Generated at 2022-06-24 03:38:27.444172
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as err:
        raise PyFileError("/tmp/test.py")
    assert str(err.value) == "could not execute config file /tmp/test.py"

# Generated at 2022-06-24 03:38:30.384257
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid = InvalidRangeType("Content pages error", 100)
    assert (invalid.message == "Content pages error")
    assert (invalid.headers == {"Content-Range": "bytes */100"})

# Generated at 2022-06-24 03:38:32.787190
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Invalid usage.")
    except Exception as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:38:36.113278
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as exn:
        raise PyFileError('')
    assert str(exn.value) == "could not execute config file ''"



# Generated at 2022-06-24 03:38:39.361557
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Arrange
    message = "Incorrect Password"
    # Act
    e = Forbidden(message)
    # Assert
    assert e.message == message
    assert e.status_code == 403

# Generated at 2022-06-24 03:38:41.604787
# Unit test for constructor of class NotFound
def test_NotFound():
    ex = NotFound("hello world")
    assert ex.message == "hello world"
    assert ex.status_code == 404
    assert type(ex) == NotFound


# Generated at 2022-06-24 03:38:45.093640
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError) as excinfo:
        raise URLBuildError(message='server error')
    assert excinfo.value.status_code == 500
    assert excinfo.value.args[0] == 'server error'


# Generated at 2022-06-24 03:38:53.468845
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class Test404(SanicException):
        pass
    assert _sanic_exceptions[404] is Test404
    assert issubclass(Test404, SanicException)
    assert Test404.status_code == 404
    assert Test404.quiet is True
    assert Test404.__name__ == 'Test404'

    @add_status_code(500)
    class Test500(SanicException):
        pass
    assert _sanic_exceptions[500] is Test500
    assert issubclass(Test500, SanicException)
    assert Test500.status_code == 500
    assert Test500.quiet is False
    assert Test500.__name__ == 'Test500'


# Generated at 2022-06-24 03:38:58.889373
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:  
        raise InvalidSignal('Message', status_code=403)
    except InvalidSignal as e:
        assert e.status_code == 403
        assert e.message == 'Message'

# Generated at 2022-06-24 03:39:02.159748
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = 'test'
    relative_url = 'test'
    fnf = FileNotFound("test", path, relative_url)

    assert fnf.path == path
    assert fnf.relative_url == relative_url



# Generated at 2022-06-24 03:39:07.044039
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported):
        message = "GET, POST"
        method = "PUT"
        allowed_methods = ["GET", "POST"]
        raise MethodNotSupported(message, method, allowed_methods)


# Generated at 2022-06-24 03:39:17.463926
# Unit test for constructor of class SanicException
def test_SanicException():
    # message: str
    # status_code: int
    # quiet: True/False
    # [1] status_code is not None, quiet is True
    se = SanicException(message="test_message", status_code=103, quiet=True)
    assert se.message == "test_message"
    assert se.status_code == 103
    assert se.quiet is True
    assert se.__class__.__name__ == "SanicException"
    # [2] status_code is None, quiet is True
    se = SanicException(message="test_message", quiet=True)
    assert se.message == "test_message"
    assert se.status_code != 103
    assert se.quiet is True
    assert se.__class__.__name__ == "SanicException"
    # [3] status_code

# Generated at 2022-06-24 03:39:20.113565
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert InvalidRangeType("Invalid Range Type", content_range=100).message == "Invalid Range Type"
    assert InvalidRangeType("Invalid Range Type", content_range=100).content_range == 100


# Generated at 2022-06-24 03:39:23.368887
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fnf = FileNotFound("message", "path", "relative_url")
    assert fnf.path == "path"
    assert fnf.relative_url == "relative_url"

# Generated at 2022-06-24 03:39:28.255792
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message", "path", "relative_url")
    except FileNotFound as e:
        assert e.message == "message"
        assert e.path == "path"
        assert e.relative_url == "relative_url"
        assert e.status_code == 404
        assert e.quiet == True


# Generated at 2022-06-24 03:39:31.922743
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("message", "status_code", "quiet")
    except NotFound as e:
        assert e.message == 'message'
        assert e.status_code == 'status_code'
        assert e.quiet == 'quiet'



# Generated at 2022-06-24 03:39:40.506025
# Unit test for function add_status_code
def test_add_status_code():
    class MyStatusCodeException(SanicException):
        pass

    @add_status_code(500, quiet=True)
    class MyNewStatusCodeException(Exception):
        pass

    @add_status_code(501)
    class MyNewStatusCodeException2(Exception):
        pass

    def test_add_status_code_with_quiet_true():
        assert _sanic_exceptions[500].__name__ == 'MyNewStatusCodeException'
        assert _sanic_exceptions[500].quiet

    def test_add_status_code_without_quiet():
        assert _sanic_exceptions[501].__name__ == 'MyNewStatusCodeException2'
        assert _sanic_exceptions[501].quiet == False

    test_add_status_code_with_quiet_true()
    test_add_status

# Generated at 2022-06-24 03:39:44.977654
# Unit test for function add_status_code
def test_add_status_code():
    # Make sure specific SanicException class exists
    assert (add_status_code(410))
    # Make sure class exists
    assert (add_status_code(410)(object))
    # Make sure SanicException class exists
    SanicException(message=None, status_code=410)

# Generated at 2022-06-24 03:39:53.576304
# Unit test for constructor of class NotFound
def test_NotFound():
    # Test for no arguments
    with pytest.raises(TypeError):
        NotFound()

    # Test for 1 argument (message)
    with pytest.raises(TypeError):
        NotFound('file not found')

    # Test for successful initialization
    not_found_exception = NotFound('file not found', 404)
    assert not_found_exception.status_code == 404
    assert not_found_exception.args == ("file not found",)

# Generated at 2022-06-24 03:39:57.143585
# Unit test for constructor of class ServerError
def test_ServerError():
    """
    Test the ServerError exception
    """
    try:
        raise ServerError("test message")
    except ServerError as err:
        assert err.status_code == 500
        assert str(err) == "test message"
        assert err.args[0] == "test message"


# Generated at 2022-06-24 03:39:59.841323
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(KeyError) as e:
        raise SanicException
    assert str(e.value) == "message"

    class_1 = SanicException("SanicException")
    assert class_1.message == "SanicException"

# Generated at 2022-06-24 03:40:03.498942
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal('Invalid Signal', status_code=500).__str__() == 'Invalid Signal'


# Generated at 2022-06-24 03:40:06.549880
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fileNotFound = FileNotFound("not found", "path", "relative_url")
    assert fileNotFound.path == "path"
    assert fileNotFound.relative_url == "relative_url"


# Generated at 2022-06-24 03:40:08.276232
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('a')
    except PyFileError as e:
        assert e


# Generated at 2022-06-24 03:40:12.199746
# Unit test for constructor of class PyFileError
def test_PyFileError():
    a = PyFileError("test")
    assert a.args == ("could not execute config file %s", "test")

# Generated at 2022-06-24 03:40:14.603824
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound('Not found exception')
    assert not_found.message == 'Not found exception'
    assert not_found.status_code == 404

# Generated at 2022-06-24 03:40:15.472315
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    Exception("test_FileNotFound")

# Generated at 2022-06-24 03:40:22.932961
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class SwitchingProtocols(SanicException):
        """
        **Status**: 101 Switching Protocols
        """

        pass

    assert SwitchingProtocols.status_code == 101
    assert _sanic_exceptions[101] == SwitchingProtocols

# Generated at 2022-06-24 03:40:27.239818
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed) as excinfo:
        raise HeaderExpectationFailed("Please set header Expect.", allowed_methods=["POST"])
    
    # print(excinfo.value)
    # print(excinfo.value.headers)
    assert excinfo.value.headers["Allow"] == "POST"
    assert "Please set header Expect." == str(excinfo.value)


# Generated at 2022-06-24 03:40:31.652974
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Not Found.')
    except (HeaderNotFound) as e:
        assert str(e) == 'Not Found.'
        assert e.status_code == 400
        assert e.quiet == True


# Generated at 2022-06-24 03:40:33.482757
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    e = InvalidSignal('test')
    assert str(e) == 'test'

# Generated at 2022-06-24 03:40:37.612777
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message='something went wrong', content_range=None)
    except Exception as e:
        assert (
            str(e)
            == "('something went wrong', headers={'Content-Range': 'bytes */None'})"
        )

# Generated at 2022-06-24 03:40:39.803878
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    ServiceUnavailable("The server is currently unavailable (because it is overloaded or\
    down for maintenance). Generally, this is a temporary state.")


# Generated at 2022-06-24 03:40:41.249957
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(SanicException):
        raise Forbidden(message="test")

# Generated at 2022-06-24 03:40:43.970505
# Unit test for constructor of class PyFileError
def test_PyFileError():
    expected_message = "could not execute config file %s"

    test = PyFileError("/testfile.txt")

    assert str(test) == expected_message

# Generated at 2022-06-24 03:40:45.312578
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("408 Request Timeout")
    except RequestTimeout as e:
        assert True
    else:
        raise AssertionError("RequestTimeout exception constructor incorrect")

# Generated at 2022-06-24 03:40:48.734264
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="Unit Test", status_code=500)
    except LoadFileException as e:
        assert e.message == "Unit Test"
        assert e.status_code == 500
        assert e.quiet == True

# Generated at 2022-06-24 03:40:49.736332
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge('the payload is too large')

# Generated at 2022-06-24 03:40:52.799851
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    sanic_exceptions = MethodNotSupported("Test", "POST", ["GET, POST"])
    exceptions_str = str(sanic_exceptions)
    assert exceptions_str == "Test"



# Generated at 2022-06-24 03:40:54.306789
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        exc = RequestTimeout("message")
    except Exception as e:
        assert(False)



# Generated at 2022-06-24 03:40:56.308813
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported(message="message body...",method="POST",allowed_methods=["GET","DELETE"])
    print(mns.headers)

# Generated at 2022-06-24 03:40:57.701763
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    class A(InvalidSignal):
        pass
    assert True

# Generated at 2022-06-24 03:41:09.024978
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(TypeError) as excinfo:
        URLBuildError()
    assert 'Expected 1 positional argument, got 0' in str(excinfo.value)

    # Unit test for constructor of class Unauthorized
    with pytest.raises(TypeError) as excinfo:
        Unauthorized()
    assert 'Expected 1 positional argument, got 0' in str(excinfo.value)

    # Unit test for constructor of class ContentRangeError
    with pytest.raises(TypeError) as excinfo:
        ContentRangeError()
    assert 'Expected 2 positional arguments, got 0' in str(excinfo.value)

    # Unit test for constructor of class ServerError
    with pytest.raises(TypeError) as excinfo:
        ServerError()

# Generated at 2022-06-24 03:41:10.534203
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    ex = InvalidUsage('Test exception')
    assert ex.status_code == 400


# Generated at 2022-06-24 03:41:13.245781
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as exc_info:
        raise InvalidSignal('hello world')
    assert str(exc_info.value) == 'hello world'

# Generated at 2022-06-24 03:41:20.532802
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    msg = 'test'
    allowed_methods = ['test1', 'test2']
    method = 'test3'
    e = MethodNotSupported(message=msg, method=method, allowed_methods=allowed_methods)
    assert e.message == msg
    assert e.method == method
    assert e.allowed_methods == allowed_methods


# Generated at 2022-06-24 03:41:26.620644
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('error', status_code=409, quiet=True)
    except LoadFileException as e:
        # status_code
        assert e.status_code == 409
        # message
        assert e.args[0] == 'error'
        # quiet
        assert e.quiet
    else:
        raise Exception('The code is wrong')



# Generated at 2022-06-24 03:41:33.810038
# Unit test for function add_status_code
def test_add_status_code():
    def func(i):
        pass

    class clas:
        pass

    func1 = add_status_code(200)(func)
    assert func1.status_code == 200

    func2 = add_status_code(400)(func)
    assert func2.status_code == 400

    assert clas.__name__ != func.__name__
    clas1 = add_status_code(200)(clas)
    assert clas1.status_code == 200
    clas2 = add_status_code(400)(clas)
    assert clas2.status_code == 400

# Generated at 2022-06-24 03:41:37.158780
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Payload is too large.")
    except Exception as e:
        assert e.message == "Payload is too large."
        assert e.status_code == 413


# Generated at 2022-06-24 03:41:44.001697
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("test_message", "POST", ["GET", "PUT", "DELETE"])
    except MethodNotSupported as err:
        assert err.status_code==405
        assert err.message=="test_message"
        assert err.headers=={'Allow': 'GET, PUT, DELETE'}
    

# Generated at 2022-06-24 03:41:47.686235
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise(PyFileError('/root/a.py'))
    except PyFileError as error:
        assert error.args[0] == 'could not execute config file %s'
        assert error.args[1] == '/root/a.py'

# Generated at 2022-06-24 03:41:51.733457
# Unit test for constructor of class SanicException
def test_SanicException():
    exception_name = SanicException("test")
    assert isinstance(exception_name, SanicException)

# Generated at 2022-06-24 03:41:54.506066
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Testing InvalidSignal")
    except InvalidSignal as e:
        assert str(e) == "Testing InvalidSignal"

# Generated at 2022-06-24 03:41:58.162998
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except Exception as e:
        print("LoadFileException: ", e)
        assert "test" in str(e)
        assert "LoadFileException" in str(e)

test_LoadFileException()

# Generated at 2022-06-24 03:42:00.678431
# Unit test for constructor of class ServerError
def test_ServerError():
    message = "test message"
    try:
        raise ServerError(message=message)
    except SanicException as e:
        assert e.message == message

# Generated at 2022-06-24 03:42:02.697953
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    e = InvalidRangeType("error", 3)
    assert e.message == "error"
    assert e.headers == {"Content-Range": "bytes */3"}

# Generated at 2022-06-24 03:42:07.062493
# Unit test for constructor of class NotFound
def test_NotFound():
    # define the function under test
    from sanic.exceptions import NotFound
    # start of the exception
    notFound = NotFound()
    # output
    print(notFound.__str__())

# Generated at 2022-06-24 03:42:09.817183
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError(
        "The specified range is not satisfiable. The server is willing to process the request only if the specified range is applied.",
        content_range=None
    )
    while cr.content_range is None:
        cr.content_range = 23
    cr.headers["Content-Range"] = "bytes */23"

# Generated at 2022-06-24 03:42:13.714600
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as except_info:
        raise HeaderNotFound('message', 'arg1')
    assert 'message' == str(except_info.value)
    assert 'arg1' == except_info.value.args[1]

# Generated at 2022-06-24 03:42:16.070426
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    #Arrange
    payload = "<<Too Large data>>"
    #Act
    response = PayloadTooLarge(payload)
    #Assert
    assert response.status_code == 413

# Generated at 2022-06-24 03:42:24.562528
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    http = "http"

    try:
        raise URLBuildError(http)
    except URLBuildError as e:
        assert e.status_code == 500 and e.message == http

    try:
        raise URLBuildError(http, 400)
    except URLBuildError as e:
        assert e.status_code == 400 and e.message == http

    try:
        raise URLBuildError(http, 200, True)
    except URLBuildError as e:
        assert e.status_code == 200 and e.message == http and e.quiet is True

# Generated at 2022-06-24 03:42:27.095521
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Test exception")
    except LoadFileException as e:
        assert e.status_code == 500


# Generated at 2022-06-24 03:42:30.486056
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    msg = "this is a test"
    e = RequestTimeout(msg, None)
    assert type(e) == RequestTimeout
    assert str(e) == msg

# Generated at 2022-06-24 03:42:32.522122
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    assert issubclass(HeaderExpectationFailed, SanicException)



# Generated at 2022-06-24 03:42:35.852543
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound(message="test", status_code=404, quiet=True)
    assert exception.status_code == 404
    assert exception.message == "test"
    assert exception.quiet is True

# Generated at 2022-06-24 03:42:37.718499
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound("Not Found")
    assert not_found.status_code == 404

# Generated at 2022-06-24 03:42:41.458712
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        def __init__(self,message):
            super().__init__(message)

    assert TestException(message="test").status_code == 200

# Generated at 2022-06-24 03:42:43.814598
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(404)(SanicException)
    assert _sanic_exceptions[404]
    assert _sanic_exceptions[404]().status_code == 404

# Generated at 2022-06-24 03:42:47.823522
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    print("\n\nUnit test for constructor of class InvalidUsage")
    il = InvalidUsage("Invalid parameter")
    print(il)
    print(il.message)
    print(il.status_code)
    print(il.quiet)

# Generated at 2022-06-24 03:42:50.842597
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('error')
    except InvalidUsage as e:
        assert e.message == 'error'
        assert e.status_code == 400


# Generated at 2022-06-24 03:42:54.766290
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal(
            "Invalid signal name provided: " + "test")
    except Exception as e:
        assert e.__class__.__name__ == "InvalidSignal"
        assert str(e) == "Invalid signal name provided: test"


# Generated at 2022-06-24 03:42:58.553151
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req_tmout = RequestTimeout(message="The server did not receive any request data within the timeout period", status_code=408)
    assert req_tmout.message == "The server did not receive any request data within the timeout period"
    assert req_tmout.status_code == 408


# Generated at 2022-06-24 03:43:00.746119
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signald")
        assert(False)
    except InvalidSignal as e:
        assert(e.__str__() == "Invalid Signald")

# Generated at 2022-06-24 03:43:03.876329
# Unit test for constructor of class ServerError
def test_ServerError():
    msg = 'SERVER ERROR'
    try:
        raise ServerError(msg)
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == msg

# Generated at 2022-06-24 03:43:06.725756
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError("hello.py")
    assert e.args[0] == "could not execute config file %s"
    assert e.args[1] == "hello.py"

# Generated at 2022-06-24 03:43:17.048715
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden(message="message", status_code="status_code",
                     quiet="quiet") == Forbidden(message="message",
                     status_code="status_code", quiet="quiet")
    assert Forbidden(message="message", status_code="status_code",
                     quiet="quiet") != Forbidden(message="message",
                     status_code="status_code", quiet="quiet1")
    assert Forbidden(message="message", status_code="status_code",
                     quiet="quiet") != Forbidden(message="message",
                     status_code="status_code1", quiet="quiet")
    assert Forbidden(message="message", status_code="status_code",
                     quiet="quiet") != Forbidden(message="message1",
                     status_code="status_code", quiet="quiet")

# Generated at 2022-06-24 03:43:18.116027
# Unit test for constructor of class NotFound
def test_NotFound():
    NotFound();
    assert True;


# Generated at 2022-06-24 03:43:19.991149
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    total = 1000
    # actual = InvalidRangeType('s','s').content_range.total
    # assert actual == total

# Generated at 2022-06-24 03:43:26.870034
# Unit test for function abort
def test_abort():
    raise_invalid_usage = False
    raise_invalid_usage_explicit = False
    try:
        abort(400)
    except InvalidUsage as error:
        assert error.status_code == 400
        assert error.message == "Bad Request"
        raise_invalid_usage = True

    try:
        abort(message='invalid usage', status_code=400)
    except InvalidUsage as error:
        assert error.status_code == 400
        assert error.message == "invalid usage"
        raise_invalid_usage_explicit = True

    try:
        abort(401)
    except Unauthorized as error:
        assert error.status_code == 401
        assert error.message == "Unauthorized"

# Generated at 2022-06-24 03:43:31.210781
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('file not found')
    except LoadFileException:
        exc = sys.exc_info()
        assert str(exc[1]) == 'file not found'


# Generated at 2022-06-24 03:43:33.656237
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Timeout.")
    except RequestTimeout as ex:
        assert ex.status_code == 408


# Generated at 2022-06-24 03:43:35.655483
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req = RequestTimeout('Request has failed', 408)
    assert req.status_code == 408



# Generated at 2022-06-24 03:43:39.118579
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError('Error', 1)
    assert error.headers == {'Content-Range': 'bytes */1'}


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 03:43:46.746208
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # set file path, relative url
    path = "path"
    relative_url = "/relative_url"
    # test: initialization
    fnf = FileNotFound("", path, relative_url)
    assert fnf.path == path
    assert fnf.relative_url == relative_url
    # test str()
    fnf_test = str(fnf)
    assert type(fnf_test) == str
    assert fnf_test == f"FileNotFound: File not found (path: '{path}', relative_url: '{relative_url}')"

# Generated at 2022-06-24 03:43:52.737180
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test_LoadFileException")
    except Exception as e:
        assert str(e) == "test_LoadFileException"


if __name__ == "__main__":
    test_LoadFileException()

# Generated at 2022-06-24 03:43:56.295279
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    msg = 'message'
    method = 'method'
    allowed_methods = 'allowed_methods'
    method_not_supported = MethodNotSupported(msg, method, allowed_methods)
    assert method_not_supported.headers == { "Allow": allowed_methods }

# Generated at 2022-06-24 03:43:59.293893
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("ERROR")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "ERROR"


# Generated at 2022-06-24 03:44:02.848867
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden) as exc_info:
        raise Forbidden("This is a test error message")
    assert str(exc_info.value) == "This is a test error message"
    assert exc_info.value.status_code == 403

# Generated at 2022-06-24 03:44:14.276712
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as e:
        raise Unauthorized("401 Unauthorized", scheme=None)
    assert e.value.status_code == 401
    assert e.value.headers == {}
    with pytest.raises(Unauthorized) as e:
        raise Unauthorized("401 Unauthorized", scheme="")
    assert e.value.status_code == 401
    assert e.value.headers == {}
    with pytest.raises(Unauthorized) as e:
        raise Unauthorized("401 Unauthorized", scheme="Basic")
    assert e.value.status_code == 401
    assert e.value.headers == {"WWW-Authenticate": "Basic"}

# Generated at 2022-06-24 03:44:17.393410
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method not supported"
    method = "GET"
    allowed_methods = ["POST", "PUT"]
    exception = MethodNotSupported(message, method, allowed_methods)

    assert exception.message == message
    assert exception.headers["Allow"] == ", ".join(allowed_methods)

# Generated at 2022-06-24 03:44:23.037909
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Create a InvalidRangeType instance
    it = InvalidRangeType('message', 'content_range')
    # Assert instance is created successfully
    assert it.message == 'message'
    assert it.content_range == 'content_range'
    print('test_InvalidRangeType passed!')

test_InvalidRangeType()


# Generated at 2022-06-24 03:44:27.333316
# Unit test for function add_status_code
def test_add_status_code():
    # Decorating SanicException with 200 status code
    @add_status_code(200)
    class TestException(SanicException):
        pass
    # Asserting that the exception is added for 200 code
    assert _sanic_exceptions[200] == TestException
    # Asserting that the status code is set on the class
    assert TestException.status_code == 200
    assert not hasattr(TestException, "headers")



# Generated at 2022-06-24 03:44:30.268430
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # This function has no doctest, leaving it for later.
    raise PyFileError("file")

# Generated at 2022-06-24 03:44:35.316117
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req_time = RequestTimeout(message="test", status_code=408)
    assert req_time.status_code == 408
    assert req_time.message == "test"
    assert req_time.quiet == True


# Generated at 2022-06-24 03:44:38.392401
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as exc:
        abort(405, 'Method Not Supported', "POST", ["GET", "PUT"])
    assert exc.value.headers == {'Allow': 'GET, PUT'}

# Generated at 2022-06-24 03:44:46.703714
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    lfe = LoadFileException("foo")
    assert lfe.status_code == 500
    assert lfe.message == "foo"
    assert lfe.quiet == False
    assert lfe.as_dict() == {'message': 'foo'}
    # Unit test for constructor of class InvalidUsage
    assert InvalidUsage("bar").status_code == 400
    assert NotFound("baz").status_code == 404
    assert ServerError("qux").status_code == 500
    assert ServiceUnavailable("quux").status_code == 503
    assert Forbidden("quuz").status_code == 403

# Generated at 2022-06-24 03:44:49.442478
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed("Header expectation failed.", \
                                        status_code=417)
    assert exception.status_code == 417
    assert exception.message == "Header expectation failed."

# Generated at 2022-06-24 03:44:58.478125
# Unit test for function abort
def test_abort():
    # Make sure a suitable exception is always raised
    for code in range(500, 600):  # Use SanicInternalError for all 500s
        try:
            abort(code)
            raise AssertionError()
        except ServerError:
            pass

    # Make sure the message is always set
    for code in range(500, 600):  # Use SanicInternalError for all 500s
        try:
            abort(code, "Something is wrong.")
            raise AssertionError()
        except ServerError as e:
            if e.args[0] != "Something is wrong.":
                raise AssertionError()

# Generated at 2022-06-24 03:45:02.257203
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("hello")
    except PyFileError as e:
        assert e.args[0] == "could not execute config file %s"
        assert e.args[1] == "hello"
    else:
        assert False


# Generated at 2022-06-24 03:45:05.442954
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        file = "test-file.py"
        raise PyFileError(file)
    except PyFileError as exp:
        # Check the value of Exception is correct
        assert exp.value == f"could not execute config file {file}"


# Generated at 2022-06-24 03:45:10.991940
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # Arrange
    message = 'Message'

    # Act
    load_file_exception = LoadFileException(message)

    # Assert
    assert load_file_exception.message == message


# Generated at 2022-06-24 03:45:16.745656
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message=None, path=None, relative_url=None)
    except FileNotFound as exc:
        assert exc.message == "File Not Found"
        assert exc.status_code == 404

if __name__ == '__main__':
    test_FileNotFound()

# Generated at 2022-06-24 03:45:23.519657
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "test"
    try:
        raise ServiceUnavailable("test", False)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "test"
    try:
        raise ServiceUnavailable("test", True)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "test"
    try:
        raise ServiceUnavailable("test", quiet=False)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "test"

# Generated at 2022-06-24 03:45:28.892409
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("")
    except SanicException as e:
        assert e.status_code is None
        assert e.quiet is False



# Generated at 2022-06-24 03:45:40.585497
# Unit test for constructor of class SanicException
def test_SanicException():
    def is_expected_status_error(status_code, status_text):
        try:
            # 引数に値を指定して実行
            raise_exception(status_code, status_text)
        except SanicException as e:
            assert e.status_code == status_code
            assert e.args[0] == status_text
        else:
            assert False
    # 引数に値を指定しないで実行
    try:
        raise SanicException()
    except SanicException as e:
        assert e.status_code == None
        assert e.args[0] == ""
    else:
        assert False
    is_expected_status_error(500, "Internal Server Error!")

# Generated at 2022-06-24 03:45:44.061315
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout("request_timeout message", 408)
    assert 408 == request_timeout.status_code
    assert "request_timeout message" == request_timeout.args[0]


# Generated at 2022-06-24 03:45:46.763208
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    foo = MethodNotSupported("message", "method", "allowed_methods")
    assert foo.headers == {"Allow": "allowed_methods"}

# Generated at 2022-06-24 03:45:57.205193
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(998)
    class CustomizedException(SanicException):
        pass

    assert _sanic_exceptions[998] == CustomizedException

    @add_status_code(999)
    class CustomizedException2(SanicException):
        def __init__(self, message, key=None):
            super().__init__(message)
            self.key = key

    assert _sanic_exceptions[999].__name__ == "CustomizedException2"
    assert issubclass(CustomizedException2, SanicException)

    @add_status_code(1010)
    class CustomizedException3(SanicException):
        pass

    assert _sanic_exceptions[1010] == CustomizedException3


# Generated at 2022-06-24 03:46:00.608936
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = ContentRangeError("message", 100)
    assert c.headers == {'Content-Range':'bytes */100'}
    assert c.status_code == 416
    assert c.message == "message"

# Generated at 2022-06-24 03:46:04.305510
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('Service is unavailable')
    except (ServiceUnavailable) as e:
        assert hasattr(e, 'status_code')
        assert e.status_code == 503
        assert hasattr(e, 'message')
        assert hasattr(e, 'quiet')

# Generated at 2022-06-24 03:46:07.001997
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Test SanicException")
    except SanicException as e:
        assert e.message == "Test SanicException"

# Generated at 2022-06-24 03:46:10.424315
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Cannot find page")
        assert False
    except NotFound as e:
        assert str(e) == "Cannot find page"


# Generated at 2022-06-24 03:46:12.535558
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError("Dummy", None)
    assert e.headers
    assert e.status_code == 416

# Generated at 2022-06-24 03:46:15.421259
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    ex = InvalidSignal('test')
    assert 'test' == ex.message
    assert 500 == ex.status_code
    assert 'test' in str(ex)

# Generated at 2022-06-24 03:46:18.435385
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError("message_test", "content_range_test")
    assert a.headers is not None
    a.headers = None
    assert a.headers is None


# Generated at 2022-06-24 03:46:23.196865
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fileNotFound = FileNotFound("test_message","test_path","test_relative")
    assert fileNotFound.message == "test_message"
    assert fileNotFound.path == "test_path"
    assert fileNotFound.relative_url == "test_relative"

# Generated at 2022-06-24 03:46:25.833845
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    assert LoadFileException("test").status_code == 500


# Generated at 2022-06-24 03:46:31.430368
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate' : 'Basic realm="Restricted Area"'}

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef",opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate' : 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef",opaque="zyxwvu"'}


# Generated at 2022-06-24 03:46:35.847274
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message="ContentRangeError test", content_range="", total=100)
    except ContentRangeError as e:
        assert e.headers == {"Content-Range":"bytes */100"}
        assert e.headers["Content-Range"] == "bytes */100"


# Generated at 2022-06-24 03:46:38.087979
# Unit test for constructor of class Forbidden
def test_Forbidden():
    excepted_exception = Forbidden('some message', 403)
    assert excepted_exception.status_code == 403


# Generated at 2022-06-24 03:46:39.558622
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except LoadFileException:
        assert True


# Generated at 2022-06-24 03:46:43.103010
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        url = "/test/url"
        c_range = 'bytes=0-1'
        raise InvalidRangeType("Invalid range type", c_range)
    except InvalidRangeType as e:
        if (e.path == url and e.c_range == c_range):
            print ("Test case passed")
        else:
            print ("Test case failed")


# Generated at 2022-06-24 03:46:45.153822
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal("test")

# Generated at 2022-06-24 03:46:49.048103
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    
    # Initialize a ServiceUnavailable object
    test = ServiceUnavailable("Service is unavailable for now!",quiet=False)
    
    # Check the status code
    assert test.status_code == 503

    # Check the message
    assert test.args[0] == "Service is unavailable for now!"

    # Check the quiet attribute
    assert test.quiet == False



# Generated at 2022-06-24 03:46:50.562504
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(TypeError):
        ContentRangeError("Test Message", [1,1,1])

# Generated at 2022-06-24 03:46:54.548674
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    a = HeaderNotFound('message', 400)
    assert a.status_code == 400
    assert a.message == 'HeaderNotFound: message'


# Generated at 2022-06-24 03:46:56.367529
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError('test case').args == ('could not execute config file %s', 'test case')


# Generated at 2022-06-24 03:46:59.717910
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Signal message is not support.")
    except Exception as e:
        assert(e.message == "Signal message is not support.")

# Generated at 2022-06-24 03:47:02.857792
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    m = MethodNotSupported("Test message", "POST", ["GET", "HEAD"])
    assert m.headers["Allow"] == "GET, HEAD"
    assert m.status_code == 405



# Generated at 2022-06-24 03:47:04.698064
# Unit test for constructor of class ServerError
def test_ServerError():
    ex = ServerError('error')
    assert ex.message == 'error'
    assert ex.status_code == 500



# Generated at 2022-06-24 03:47:05.890898
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable.status_code == 503, "Error"

# Generated at 2022-06-24 03:47:08.934812
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found")
    except HeaderNotFound as e:
        assert e.status_code==400
        assert e.message=="Header not found"

if __name__ == "__main__":
    test_HeaderNotFound()

# Generated at 2022-06-24 03:47:12.488138
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported(message='abcd', method='123', allowed_methods='456')
    expected_header = {"Allow": "456"}
    assert exception.message == 'abcd'
    assert exception.method == '123'
    assert exception.allowed_methods == '456'
    assert exception.headers == expected_header
