

# Generated at 2022-06-24 03:37:12.680242
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['GET', 'POST']
    method_not_supported = MethodNotSupported('message', 'PUT', allowed_methods)
    assert method_not_supported.headers['Allow'] == 'GET, POST'

# Generated at 2022-06-24 03:37:15.341484
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Incorrect case
    try:
        PyFileError(None)
    except TypeError:
        pass
    # Correct case
    PyFileError("file")


# Generated at 2022-06-24 03:37:20.477668
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    m = MethodNotSupported('test', 'get', ['get', 'post'])
    assert 'test' == m.message
    assert 'get' == m.method
    assert {'Allow': 'get, post'} == m.headers
    assert 405 == m.status_code

# Generated at 2022-06-24 03:37:23.633827
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header Not Found")
    except HeaderNotFound as e:
        assert e.message == "Header Not Found"


# Generated at 2022-06-24 03:37:25.478504
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('a')
    except InvalidSignal as e:
        assert str(e) == 'a'

# Generated at 2022-06-24 03:37:29.585488
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("File test not found")
    except Exception as err:
        assert err.args[0] == "File test not found"


# Generated at 2022-06-24 03:37:32.050990
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("message")
    except RequestTimeout as err:
        assert err.quiet == True
        assert err.status_code == 408


# Generated at 2022-06-24 03:37:34.452775
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException("test")
    assert exception.message == "test"
    assert exception.status_code == 400

# Generated at 2022-06-24 03:37:35.185845
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException('test')

# Generated at 2022-06-24 03:37:45.423813
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # When a scheme is given, a 401 is returned,
    # and the WWW-Authenticate header is completed,
    # e.g. WWW-Authenticate: Basic realm="Restricted Area"
    with pytest.raises(Unauthorized) as error:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")

    assert error.value.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

    # When a scheme is not given, a 500 is returned,
    # and the WWW-Authenticate header is not completed
    with pytest.raises(Unauthorized) as error:
        raise Unauthorized("Auth required.")

    assert not error.value.headers

    # When a scheme is given, a 401 is returned,
    # and the WWW

# Generated at 2022-06-24 03:37:47.905232
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('test', path='test', relative_url='test')
    except Exception as exception:
        if type(exception) != FileNotFound:
            raise exception

if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-24 03:37:51.956298
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # This test is added because the constructor in an abstract class
    # doesn't have any assert to test.

    message = 'This is a message'
    try:
        raise RequestTimeout(message)
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == message
        assert e.quiet == True



# Generated at 2022-06-24 03:37:58.130376
# Unit test for function abort
def test_abort():
    # Bad request
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400

    # Not Found
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404

    # Not Found with custom message
    try:
        message = "Custom Error"
        abort(404, message=message)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == message

# Generated at 2022-06-24 03:37:59.126932
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge("message", "header")

# Generated at 2022-06-24 03:38:03.022008
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test_class = LoadFileException('Message', 'Path', 'Reason')
    print(test_class.message)
    print(test_class.path)
    print(test_class.reason)


# Generated at 2022-06-24 03:38:05.712659
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("something")

    except PyFileError as e:
        assert e.args[0] == "could not execute config file %s"
        assert e.args[1] == "something"

# Generated at 2022-06-24 03:38:10.893937
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    msg = "test"
    method = "GET"
    allowed_methods = ["POST", "PUT"]
    e = MethodNotSupported(msg, method, allowed_methods)
    assert e.args[0] == msg
    assert e.headers["Allow"] == "POST, PUT"


# Generated at 2022-06-24 03:38:20.936148
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=protected-access

    # Test add_status_code for status code Integer, but non-standard status code
    @add_status_code(666, quiet=True)
    class TestAddStatusCodeIntNonStandardCode(SanicException):
        pass

    # Verify that new status code is documented in _sanic_exceptions
    assert 666 in _sanic_exceptions
    assert isinstance(_sanic_exceptions[666], TestAddStatusCodeIntNonStandardCode)

    # Test add_status_code for status code String, standard status code
    @add_status_code("400")
    class TestAddStatusCodeStrStandardCode(SanicException):
        pass

    # Verify that new status code is documented in _sanic_exceptions
    assert 400 in _sanic_exceptions

# Generated at 2022-06-24 03:38:23.480099
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    err = ContentRangeError("A", 1)
    assert err.message == "A"
    assert err.headers == {"Content-Range": "bytes */1"}

# Generated at 2022-06-24 03:38:34.148559
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # Without specifying the authentication scheme
        raise Unauthorized("Auth required.",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."
        assert not hasattr(e, "headers")

    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}


# Generated at 2022-06-24 03:38:38.272333
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    """
    Should raise an `FileNotFound` exception with the correct message.
    """
    path = "../static/test.txt"
    relative_url = "../static/test.txt"
    message = f"Requested URL {relative_url} not found."

    with pytest.raises(FileNotFound) as exception:
        raise FileNotFound(message, path, relative_url)
    assert exception.value.message == message
    assert exception.value.path == path
    assert exception.value.relative_url == relative_url
    assert exception.value.status_code == 404
    assert exception.value.quiet == True



# Generated at 2022-06-24 03:38:40.953183
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Signal Invalid')
    except InvalidSignal as err:
        assert err.__str__() == 'Signal Invalid'


# Generated at 2022-06-24 03:38:50.616880
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.headers == {
            'WWW-Authenticate': 'Basic realm="Restricted Area"'
        }
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401

# Generated at 2022-06-24 03:38:55.033582
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Auth required")
    except Forbidden as inst:
        assert inst.message == "Auth required"
        assert inst.status_code == 403


# Generated at 2022-06-24 03:39:01.997202
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException.__dict__.get('status_code') is None
    assert SanicException.__dict__.get('quiet') is None
    exception = SanicException('message', status_code=400, quiet=True)
    assert exception.status_code == 400
    assert exception.quiet == True

    exception = SanicException('message')
    assert exception.status_code is None
    assert exception.quiet is None


# Generated at 2022-06-24 03:39:05.814003
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("header not found", request)
    except HeaderNotFound as e:
        res = e
    assert res.message == "header not found"

# Generated at 2022-06-24 03:39:09.763104
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Test message.",100)
    except ContentRangeError as e:
        print(e.message)
        print(e.headers)

if __name__ == "__main__":
    test_ContentRangeError()

# Generated at 2022-06-24 03:39:13.346146
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test.py")
    except PyFileError as e:
        assert e.args[0] == "could not execute config file %s"
        assert e.args[1] == "test.py"


# Generated at 2022-06-24 03:39:15.925723
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("message", 0)
    except InvalidRangeType as e:
        assert e.headers == {"Content-Range": "bytes */0"}

# Generated at 2022-06-24 03:39:18.186902
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("", "TEST", ["TEST"])
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "TEST"}

# Generated at 2022-06-24 03:39:21.719832
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class MyTestException(SanicException):
        pass

    assert MyTestException.status_code == 201
    assert MyTestException.__name__ == "MyTestException"

# Generated at 2022-06-24 03:39:25.007055
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid signal", "SIGTERM")
    except InvalidSignal as e:
        assert e.args == ("Invalid signal", "SIGTERM")

# Generated at 2022-06-24 03:39:29.720188
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # If Status is not numbers, it will return an exception
    try:
        raise RequestTimeout("ERROR", status_code="a")
    except TypeError:
        pass
    # Status can be None
    RequestTimeout("ERROR", status_code=None)
    RequestTimeout("ERROR", status_code=408)
    RequestTimeout("ERROR", status_code=408, quiet=True)
    RequestTimeout("ERROR", status_code=408, quiet=False)
    RequestTimeout("ERROR", status_code=408, quiet="Yes")


# Generated at 2022-06-24 03:39:33.388280
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
  try:
    raise ServiceUnavailable("Test ServiceUnavailable",
                              status_code=503)
    assert False, "This statement should not be executed"
  except ServiceUnavailable as e:
    assert(503 == e.status_code)
    assert(503 == e.status_code)

# Generated at 2022-06-24 03:39:38.130227
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    lower = 0
    upper = 10
    total = 100
    range_header = f'bytes={lower}-{upper}'
    content_range = f'bytes {lower}-{upper}/{total}'
    test_object = ContentRangeError('Expected range could not be satisfied', content_range)
    assert test_object.headers['Content-Range'] == range_header


# Generated at 2022-06-24 03:39:40.791289
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError) as error:
        raise ServerError("test error")
    assert "test error" == str(error)

# Generated at 2022-06-24 03:39:42.694340
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException):
        raise SanicException("hello abc")

# Generated at 2022-06-24 03:39:45.545428
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as e:
        raise InvalidUsage()
    assert e.value.status_code == 400


# Generated at 2022-06-24 03:39:53.890551
# Unit test for constructor of class ServerError
def test_ServerError():
    # Test if message is required
    Message = "Error Message"
    error = ServerError(Message)
    assert error.args == (Message,)
    assert error.message == Message
    assert error.status_code == 500

    # Test the status code and quiet
    error = ServerError("Error Message", status_code=503, quiet=False)
    assert error.args == ("Error Message",)
    assert error.message == "Error Message"
    assert error.status_code == 503
    assert not error.quiet

# Generated at 2022-06-24 03:39:56.141846
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    message = "The requested Content-Range is invalid"
    total_length = 2048
    try:
        raise InvalidRangeType(message, total_length)
    except InvalidRangeType:
        pass

# Generated at 2022-06-24 03:39:59.081334
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    if isinstance(MethodNotSupported("message", "method", ["method"]).headers, dict) and \
       isinstance(MethodNotSupported("message", "method", ["method"]).allowed_methods,
                  list):
        print("Test Pass")

# Generated at 2022-06-24 03:40:01.811027
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    resp = InvalidSignal("Invalid signal", status_code=None, quiet=None)
    assert resp.status_code == None
    assert resp.quiet == None
    assert resp.message == "Invalid signal"


# Generated at 2022-06-24 03:40:03.361875
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError()
    except ServerError as se:
        assert 500 == se.status_code

# Generated at 2022-06-24 03:40:05.255923
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    s = str(URLBuildError('testing flag'))
    assert s == 'testing flag'


# Generated at 2022-06-24 03:40:10.185564
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("xxxxxxxxxxxx")
        assert False
    except HeaderExpectationFailed as e:
        assert str(e) == "'xxxxxxxxxxxx'"
        assert e.__cause__ is None
        assert e.__context__ is None
        assert e.args == ('xxxxxxxxxxxx',)
        assert e.message == 'xxxxxxxxxxxx'
        assert e.status_code == 417


# Generated at 2022-06-24 03:40:13.214321
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as e:
        raise InvalidSignal("Invalid signal 'a'")
    assert e.match("Invalid signal 'a'")


# Generated at 2022-06-24 03:40:14.359990
# Unit test for constructor of class NotFound
def test_NotFound():
    x=NotFound()


# Generated at 2022-06-24 03:40:18.626561
# Unit test for constructor of class ServerError
def test_ServerError():
    test_message = "Test Server Error"
    with pytest.raises(ServerError) as error:
        raise ServerError(test_message)
    assert test_message in str(error.value)
    assert 500 == error.value.status_code
    assert False == error.value.quiet


# Generated at 2022-06-24 03:40:20.436202
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("message", status_code=501, quiet=False)
    except SanicException as err:
        assert err.status_code == 501

# Generated at 2022-06-24 03:40:24.807877
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("auth-required", scheme="basic", realm="restricted area")
    except Unauthorized as e:
        assert e.message == "auth-required"
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == "basic realm=\"restricted area\""
        assert e.scheme is None
        assert e.quiet == True

# Generated at 2022-06-24 03:40:30.635789
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    HEADER_EXPECTATION_FAILED_MESSAGE = "Could not process headers"
    HEADER_EXPECTATION_FAILED_STATUS_CODE = 417

    obj = HeaderExpectationFailed(HEADER_EXPECTATION_FAILED_MESSAGE, HEADER_EXPECTATION_FAILED_STATUS_CODE)

    assert obj.status_code == HEADER_EXPECTATION_FAILED_STATUS_CODE
    assert obj.message == HEADER_EXPECTATION_FAILED_MESSAGE
    assert obj.status_code == 417


# Generated at 2022-06-24 03:40:37.328136
# Unit test for constructor of class SanicException
def test_SanicException():
    pass_exception = SanicException("message", status_code=404)
    assert(pass_exception.status_code == 404)

    default_exception = SanicException("message", status_code=500)
    assert(default_exception.status_code == 500)

    default_exception = SanicException("message", status_code=None)
    assert(default_exception.status_code == 500)

# Generated at 2022-06-24 03:40:39.079097
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert str(InvalidSignal("this is a test", status_code=500)) == "this is a test"

# Generated at 2022-06-24 03:40:42.567432
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = 'file.txt'
    file_error = PyFileError(file)
    assert file_error.args[0] == 'could not execute config file {!r}'.format(file)
    assert file_error.args[1] == file

# Generated at 2022-06-24 03:40:44.846437
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError('test', status_code = 500)
    assert exception.status_code == 500
    print(exception)

# Generated at 2022-06-24 03:40:47.489937
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Operation not permitted')
    except Forbidden as e:
        assert "Operation not permitted" in str(e)
        assert e.status_code == 403

# Generated at 2022-06-24 03:40:51.325310
# Unit test for constructor of class FileNotFound

# Generated at 2022-06-24 03:41:00.201449
# Unit test for function add_status_code
def test_add_status_code():
    """Test function add_status_code"""
    class ExceptionA(Exception):
        pass

    class NewA(ExceptionA):
        status_code = 204
        pass

    class ExceptionB(Exception):
        pass

    class NewB(ExceptionB):
        status_code = 304
        quiet = True
        pass

    class ExceptionC(Exception):
        pass

    class NewC(ExceptionC):
        status_code = 500
        quiet = False
        pass

    ExceptionA = add_status_code(200, False)(ExceptionA)
    ExceptionB = add_status_code(None, True)(ExceptionB)
    ExceptionC = add_status_code(None)(ExceptionC)
    NewA = add_status_code(204)(NewA)
    NewB = add_status_code(304)(NewB)

# Generated at 2022-06-24 03:41:04.514485
# Unit test for function abort
def test_abort():
    # test raise an Exception
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    # test raise customized Exception
    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Service Unavailable"

# Generated at 2022-06-24 03:41:09.082134
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('testing')
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'testing'
        assert e.quiet == True

# Generated at 2022-06-24 03:41:13.851942
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("Error")
    assert err.status_code == 500
    assert err.message == "Error"


# Generated at 2022-06-24 03:41:19.015258
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('test exception', 'test')
    except LoadFileException as e:
        assert str(e) == 'test exception'
        assert e.status_code == 'test'


# Generated at 2022-06-24 03:41:21.101827
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    tmp = MethodNotSupported("test", "GET", ["GET", "POST"])
    assert tmp.status_code == 405
    assert tmp.headers == {"Allow": "GET, POST"}

# Generated at 2022-06-24 03:41:25.444242
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('HeaderNotFound message')
    except InvalidUsage as e:
        assert e.message == 'HeaderNotFound message'
        assert e.status_code == 400


# Generated at 2022-06-24 03:41:28.315042
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("server error",status_code=500)
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "server error"

# Generated at 2022-06-24 03:41:30.261478
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test")
    except SanicException as e:
        assert e.status_code == 503


# Generated at 2022-06-24 03:41:33.078744
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Bad Request")
    except SanicException as e:
        assert isinstance(e, SanicException)
        assert isinstance(e, InvalidUsage)
        assert e.status_code == 400
        assert e.message == "Bad Request"


# Generated at 2022-06-24 03:41:36.748681
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    m = "503 Error"
    try:
        raise ServiceUnavailable(message=m)
    except ServiceUnavailable as e:
        assert e.message == m

# Generated at 2022-06-24 03:41:47.687564
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": 'Digest qop="auth, auth-int", '
                                'algorithm="MD5", nonce="abcdef", '
                                'opaque="zyxwvu", realm="Restricted Area"'}
    else:
        assert False, "Should not reach here"


# Generated at 2022-06-24 03:41:51.337909
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """
    Test if constructor of class PayloadTooLarge works correctly
    """
    test_message = "Test message"
    test_payload = SanicException(test_message, 413)
    assert(test_payload.status_code == 413)
    assert(test_payload.message == test_message)


# Generated at 2022-06-24 03:41:54.060360
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge):
        payload_too_large = PayloadTooLarge("Payload is too large")

# Generated at 2022-06-24 03:41:56.854348
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as excinfo:
        raise InvalidUsage("test for invalid usage")
    assert excinfo.value.message == "test for invalid usage"

# Generated at 2022-06-24 03:42:00.198968
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge('Too large', 4294967295)
    assert payload_too_large.status_code == 413
    assert payload_too_large.message == 'Too large'


# Generated at 2022-06-24 03:42:04.905395
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("message", "url", "param")
    except SanicException as e:
        assert e.status_code is None
        assert e.quiet is None
        assert e.args[0] == "message"


# Generated at 2022-06-24 03:42:07.473311
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exp = ServiceUnavailable("Message", 503)
    assert exp.message == "Message"
    assert exp.status_code == 503
    assert exp.headers == {}

# Generated at 2022-06-24 03:42:09.080029
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError("d", 0)
    assert a.headers=={"Content-Range": "bytes */0"}

# Generated at 2022-06-24 03:42:10.495129
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge("hello")
    assert error is not None

# Generated at 2022-06-24 03:42:15.168414
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test server error")
    except SanicException as e:
        assert e.message == "Test server error"
        assert e.status_code == 500
        assert e.quiet is False

# Generated at 2022-06-24 03:42:26.902642
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Basic auth-scheme, realm and message are specified,
    # but not any parameter that is required by the auth-scheme:

    # The following exception SHOULD NOT be raised because realm is present:
    # Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")

    Unauthorized("Auth required.", scheme="Basic")

    # Digest auth-scheme and message are specified,
    # but not any parameter that is required by the auth-scheme:
    # The following exception SHOULD be raised because realm is not present:
    try:
        Unauthorized("Auth required.", scheme="Digest")
    except Unauthorized as e:
        assert e.headers["WWW-Authenticate"] == "Digest"


# Generated at 2022-06-24 03:42:28.367043
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("error")

# Generated at 2022-06-24 03:42:34.772501
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # check if the status_code is correct
    test_exception = PayloadTooLarge("test message", quiet=False)
    assert test_exception.status_code == 413

    # check if the message is correct
    assert test_exception.args[0] == "test message"

    # check if the quiet is correct
    assert test_exception.quiet == False


# Generated at 2022-06-24 03:42:37.079710
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Headers not correct")
    except HeaderExpectationFailed as err:
        assert True

# Generated at 2022-06-24 03:42:38.473192
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    FileNotFound("Illegal file location", "a file path", "a URL")

# Generated at 2022-06-24 03:42:40.248542
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    a = URLBuildError("Testing Constructor")



# Generated at 2022-06-24 03:42:40.918949
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    pass

# Generated at 2022-06-24 03:42:43.111025
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Message", 503, True)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.quiet == True


# Generated at 2022-06-24 03:42:44.109780
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    c=ServiceUnavailable()
    c.status_code

# Generated at 2022-06-24 03:42:55.403907
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('/path/to/file', relative_url='/path/to/file')
    except FileNotFound as e:
        assert  e.path == '/path/to/file'
        assert e.relative_url == '/path/to/file'
        assert e.status_code == 404


if __name__ == "__main__":
    # Unit test for methods of class SanicException
    try:
        raise SanicException
    except SanicException as e:
        assert e.args == ()
    try:
        raise SanicException('Message from SanicException')
    except SanicException as e:
        assert e.args == ('Message from SanicException',)

# Generated at 2022-06-24 03:42:58.600986
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed()
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == 'Expectation Failed'


# Generated at 2022-06-24 03:43:01.908142
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Header Not Found')
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == 'Header Not Found'


# Generated at 2022-06-24 03:43:04.106200
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Test Message')
    except HeaderNotFound as e:
        assert e.args[0] == 'Test Message'


# Generated at 2022-06-24 03:43:06.549245
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = 'expected error'
    try:
        raise HeaderNotFound(message)
    except HeaderNotFound as err:
        assert err.message == message

# Generated at 2022-06-24 03:43:08.658727
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden('No permission to access')

# Generated at 2022-06-24 03:43:14.223881
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    test_path = "hello world"
    test_relative_url = "url"
    test_message = "test message"
    test_instance = FileNotFound(test_message, test_path, test_relative_url)
    assert test_instance.path == test_path
    assert test_instance.relative_url == test_relative_url
    assert test_instance.args == (test_message,)
    assert isinstance(test_instance, NotFound)
    assert isinstance(test_instance, SanicException)


# Generated at 2022-06-24 03:43:16.296688
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Test ServerError')
    except ServerError as e:
        assert repr(e) == 'ServerError: Test ServerError'

# Generated at 2022-06-24 03:43:20.240771
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "file"
    exception = PyFileError(file)
    assert isinstance(exception, PyFileError)
    assert isinstance(exception, Exception)
    assert exception.__str__() == "could not execute config file file"


# Generated at 2022-06-24 03:43:24.293327
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('hello world!')
    except InvalidUsage as e:
        assert e.message == 'hello world!'
        assert e.status_code == 400
        assert e.quiet == True

if __name__ == "__main__":
    import pytest
    pytest.main(["-q", "test_exceptions.py"])

# Generated at 2022-06-24 03:43:28.342401
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        assert ServerError(message='b', status_code=1, quiet=None)
        assert True
    except Error:
        assert False


# Generated at 2022-06-24 03:43:32.277632
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    headers = {'Content-Type': 'application/json'}
    assert HeaderNotFound().status_code == 400
    assert HeaderNotFound(headers=headers)

# Generated at 2022-06-24 03:43:36.471685
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test")
    except SanicException as err:
        assert err.status_code == 503



# Generated at 2022-06-24 03:43:45.527151
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Invalid Range Type Error!", "123")
    except InvalidRangeType as e:
        assert type(e) == InvalidRangeType
        assert e.args == ("Invalid Range Type Error!",)
        assert e.message == "Invalid Range Type Error!"
        assert e.status_code == 416
        assert e.__dict__ == {'message': 'Invalid Range Type Error!', 'headers': {'Content-Range': 'bytes */123'}}
        assert e.__repr__() == 'InvalidRangeType("Invalid Range Type Error!", "123")'

# Generated at 2022-06-24 03:43:46.503787
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(Exception):
        raise ContentRangeError(message="message",content_range=10)

# Generated at 2022-06-24 03:43:48.443397
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout('Content-Type', 'request_timeout')
    assert request_timeout.status_code == 408


# Generated at 2022-06-24 03:43:50.513937
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("This is a ServerError")
    except ServerError as e:
        assert(e.status_code == 500)


# Generated at 2022-06-24 03:43:53.962461
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # 503 Service Unavailable
    try:
        raise ServiceUnavailable("Service Unavailable")
    except ServiceUnavailable as e:
        assert(503 == e.status_code)


# Generated at 2022-06-24 03:44:04.102554
# Unit test for function add_status_code
def test_add_status_code():
    def test_class_decorator(cls):
        print(cls)

    new_class = type('my_subclass', (SanicException,),dict(__init__=lambda x: None))

    new_exception_subclass = test_class_decorator(new_class)
    assert add_status_code(405)(SanicException) == SanicException
    assert add_status_code(405)(new_exception_subclass) == new_exception_subclass
    test_code = add_status_code(405)(new_exception_subclass)
    assert test_code.status_code == 405



if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:44:07.406991
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as ex:
        assert ex.status_code == 500
        assert ex.message == "Invalid Signal"



# Generated at 2022-06-24 03:44:12.825223
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Test message"
    method = "GET"
    allowed_methods = ["POST", "GET"]
    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.status_code == 405
    assert exception.headers == {"Allow": ", ".join(allowed_methods)}
    assert exception.quiet



# Generated at 2022-06-24 03:44:16.329703
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = InvalidRangeType("test", "content")
    assert a.message == "test"
    assert a.content_range == "content"
    assert a.headers == {'Content-Range': 'bytes */content'}



# Generated at 2022-06-24 03:44:26.271350
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # The custom exception must contains a default msg when the user doesn't give any
    try:
        raise HeaderNotFound()
    except HeaderNotFound as e:
        assert 'Bad Request' == e.__str__()

    # The custom exception must contains the msg passed by the user
    try:
        raise HeaderNotFound('custom error message')
    except HeaderNotFound as e:
        assert 'custom error message' == e.__str__()

    # The custom exception must contains the msg passed by the user,
    # and the status and default msg should not be overwrite by the user
    try:
        raise HeaderNotFound('custom error message', status_code='403', quiet=True)
    except HeaderNotFound as e:
        assert '403' == e.status_code
        assert 'True' == e.__str__('quiet')


#

# Generated at 2022-06-24 03:44:29.112645
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound("Not Found")
    assert(exception.message == "Not Found")
    assert(exception.status_code == 404)
    assert(exception.quiet == True)


# Generated at 2022-06-24 03:44:32.206761
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound.__init__(NotFound, "404 Not Found") == None

# Generated at 2022-06-24 03:44:38.077241
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('A', 10)
    except SanicException as e:
        assert e.args[0] == 'A'
        assert e.status_code == 10
        assert e.quiet is False


# Generated at 2022-06-24 03:44:39.738470
# Unit test for constructor of class ServerError
def test_ServerError():
    message = 'some message'
    exc = ServerError(message)

    assert exc.status_code == 500
    assert exc.message == message

# Generated at 2022-06-24 03:44:42.590545
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        r = PyFileError("This is a file")
        assert r.args == ("This is a file",)
    except:
        print("Error in PyFileError")


# Generated at 2022-06-24 03:44:46.646077
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("example.py")
    except LoadFileException as e:
        assert e.status_code == 500
        assert e.args[0] == "could not execute config file %s"
    else:
        print("failed")


# Generated at 2022-06-24 03:44:49.388519
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="Service unavailable")
    except Exception as e:
        assert e.status_code == 503
        assert e.message == "Service unavailable"

# Generated at 2022-06-24 03:44:52.122979
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # Given
    header = "Header"
    # When
    # Then
    assert HeaderNotFound(header).status_code == 400
    assert HeaderNotFound(header).message == "Header"

# Generated at 2022-06-24 03:44:55.582259
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    error = InvalidSignal("signal is invalid")
    assert error.args[0] == "signal is invalid"
    assert error.status_code == 500



# Generated at 2022-06-24 03:44:58.980134
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        class TestException(LoadFileException):
            pass
        raise TestException(message=None, status_code=404)
    except LoadFileException as e:
        assert e.status_code == 404

# Generated at 2022-06-24 03:45:01.257995
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = 'the error message'
    obj = HeaderExpectationFailed(message)
    assert obj.message == message and obj.status_code == 417


# Generated at 2022-06-24 03:45:03.206902
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message='error')
    except ContentRangeError as e:
        assert e.message == 'error'


# Generated at 2022-06-24 03:45:07.345535
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    error = HeaderExpectationFailed(message="Header Expectation Failed", status_code=417)
    assert(error.message == "Header Expectation Failed")
    assert(error.status_code == 417)
    assert(error.__class__ == HeaderExpectationFailed)


# Generated at 2022-06-24 03:45:13.286588
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as info:
        raise PyFileError("/Users/user/Desktop/sanic/sanic_server.py")
    assert info.type == PyFileError
    assert str(info.value) == "could not execute config file /Users/user/Desktop/sanic/sanic_server.py"

# Generated at 2022-06-24 03:45:19.560926
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    result = MethodNotSupported("ABORT", method="POST", allowed_methods=["GET"])
    assert result.status_code == 405
    assert result.headers.get("Allow") == "GET"
    assert result.message == "ABORT"
    assert result.method == "POST"

if __name__ == "__main__":
    test_MethodNotSupported()

# Generated at 2022-06-24 03:45:23.610914
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("Server Error", 500)
    assert error.message == "Server Error"
    assert error.status_code == 500
    assert error.quiet == None


# Generated at 2022-06-24 03:45:29.696544
# Unit test for constructor of class NotFound
def test_NotFound():
    test_notfound = NotFound('testMessage', 404, False)
    assert test_notfound.message == 'testMessage'
    assert test_notfound.status_code == 404
    assert test_notfound.quiet == False


# Generated at 2022-06-24 03:45:33.949204
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfile_error = PyFileError("file_not_found.py")
    assert pyfile_error.args[0] == "could not execute config file %s"
    assert pyfile_error.args[1] == "file_not_found.py"

# Generated at 2022-06-24 03:45:35.260043
# Unit test for constructor of class SanicException
def test_SanicException():
    SanicException(message='hello')

# Generated at 2022-06-24 03:45:38.418518
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Forbidden Message')
    except Forbidden as e:
        assert e.message == 'Forbidden Message'
        assert e.status_code == 403


# Generated at 2022-06-24 03:45:40.252709
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("file")
    assert error.__repr__() == "could not execute config file file"

# Generated at 2022-06-24 03:45:43.680937
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "Test Message"
    exception = HeaderExpectationFailed(message, status_code=417)
    assert exception.status_code == 417
    assert exception.message == "Test Message"

# Generated at 2022-06-24 03:45:44.528873
# Unit test for function abort
def test_abort():
    abort(404)

# Generated at 2022-06-24 03:45:48.314892
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exc = ContentRangeError("Test", 10)
    assert str(exc) == "Test"
    assert dict(exc.headers) == {"Content-Range": "bytes */10"}


# Generated at 2022-06-24 03:45:52.552800
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound(message="File not found", path="you_path", relative_url="you_url")
    assert exception.message == "File not found"
    assert exception.path == "you_path"
    assert exception.relative_url == "you_url"

# Generated at 2022-06-24 03:45:53.979005
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal("hello")

# Generated at 2022-06-24 03:46:01.222671
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as m:
        raise Unauthorized(message="Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")

    assert m.value.status_code == 401
    assert m.value.args[0] == "Auth required."
    assert m.value.headers == {
        "WWW-Authenticate": "Basic realm=Restricted Area"
    }

# Generated at 2022-06-24 03:46:05.051904
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    #Test 1:
    try:
        raise InvalidUsage('Message')
    except InvalidUsage as e:
        assert e.status_code == 400

    #Test 2:
    try:
        raise InvalidUsage('Message', 400)
    except InvalidUsage as e:
        assert e.status_code == 400



# Generated at 2022-06-24 03:46:07.249577
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = ServerError()
    assert exception.status_code == 500
    assert exception.quiet == True


# Generated at 2022-06-24 03:46:10.174008
# Unit test for constructor of class NotFound
def test_NotFound():
    # Test for exception
    try:
        raise NotFound("A message", "404")
    except NotFound as err:
        print(err)

# Generated at 2022-06-24 03:46:12.754096
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("List index out of range")
    except URLBuildError as e:
        pass


# Generated at 2022-06-24 03:46:18.399628
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        exc = MethodNotSupported(message='Message', method='GET', allowed_methods=['GET', 'POST'])
    except Exception as e:
        assert False, "Exception raised"
    assert exc.status_code == 405
    assert repr(exc) == 'MethodNotSupported(Message, 405)'
    assert exc.headers['Allow'] == 'GET, POST'



# Generated at 2022-06-24 03:46:20.700198
# Unit test for constructor of class ServerError
def test_ServerError():
    ex = ServerError("Test error!")
    ex = ServerError("Test error!", status_code = 500)

# Generated at 2022-06-24 03:46:25.478780
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("message", "/path", "/relative_url")
    assert file_not_found.message == "message"
    assert file_not_found.path == "/path"
    assert file_not_found.relative_url == "/relative_url"

test_FileNotFound()

# Generated at 2022-06-24 03:46:28.037185
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    '''
    Test passes if the 503 - ServiceUnavailable message prints.
    :return:
    '''
    try:
        raise ServiceUnavailable('The service is temporarily unavailable.')
    except ServiceUnavailable as error:
        print(error)

# Generated at 2022-06-24 03:46:34.528923
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ["GET", "POST", "PUT", "DELETE"]
    exception_msg = "Method Not Supported"
    exception = MethodNotSupported(message=exception_msg, method="PATCH", allowed_methods=allowed_methods)
    assert exception.status_code == 405
    assert exception.message == exception_msg
    assert exception.headers["Allow"] == ", ".join(allowed_methods)

# Generated at 2022-06-24 03:46:40.075976
# Unit test for function add_status_code
def test_add_status_code():
    """
    Add status code for SanicException
    """
    @add_status_code(404)
    class TestCode(SanicException):
        """
        Test Status Code
        """
        pass

    assert TestCode.status_code == 404



# Generated at 2022-06-24 03:46:42.837574
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('header-not-found')
    except HeaderNotFound as e:
        assert str(e) == 'header-not-found'
        assert type(e) == HeaderNotFound
        assert e.status_code == 400


# Generated at 2022-06-24 03:46:45.192958
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType('message', None)
    assert exc.headers == {'Content-Range': 'bytes */None'}

# Generated at 2022-06-24 03:46:48.519783
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Timeout")
    except RequestTimeout as err:
        assert err.args[0] == "Timeout"
        assert err.status_code == 408
        assert err.quiet == True
    else:
        assert False, "RequestTimeout should raise RequestTimeout exception"



# Generated at 2022-06-24 03:46:53.913024
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType("test", 123)
    assert invalid_range_type.status_code == 416
    assert invalid_range_type.headers == {'Content-Range': 'bytes */123'}

# Generated at 2022-06-24 03:46:57.726048
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError("requested range not satisfiable", content_range=None)
    assert cr.status_code == 416
    cr = ContentRangeError("requested range not satisfiable", content_range=None, status_code=200)
    assert cr.status_code == 416
    cr = ContentRangeError("requested range not satisfiable", content_range=None, status_code=500)
    assert cr.status_code == 416
    cr = ContentRangeError("requested range not satisfiable", content_range=None, status_code=417)
    assert cr.status_code == 417


# Generated at 2022-06-24 03:47:01.133657
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = InvalidSignal(message='test', status_code=400)
    assert signal.message == 'test'
    assert signal.status_code == 400

# Generated at 2022-06-24 03:47:06.713486
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    e = FileNotFound('test', path="/test", relative_url="/test")
    assert e.path == "/test"
    assert e.relative_url == "/test"
    assert e.status_code == 404
    assert e.message == 'test'
    assert str(e) == 'test'
    assert repr(e) == "FileNotFound('test', path='/test', relative_url='/test')"


# Generated at 2022-06-24 03:47:08.955547
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    invalidSignal = InvalidSignal("Hello World", 404)
    assert invalidSignal.message == "Hello World"
    assert invalidSignal.status_code == 404


# Generated at 2022-06-24 03:47:11.489213
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found = HeaderNotFound('message', 'field_name')
    assert header_not_found.message == 'message'
    assert header_not_found.field_name == 'field_name'
    assert header_not_found.status_code == 400