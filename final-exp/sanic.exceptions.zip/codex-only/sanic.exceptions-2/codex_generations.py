

# Generated at 2022-06-24 03:37:17.419821
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        exc = ServerError("Test", quiet=True)
        assert exc.status_code == 500
    except:
        assert False, "constructor of SanicException failed to set quiet"


# Generated at 2022-06-24 03:37:25.191305
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 200
    @add_status_code(status_code)
    class MyException(SanicException):
        pass
    Exception = MyException("this is a test", status_code=status_code)
    assert Exception.status_code == status_code
    assert Exception.quiet is False
    
    @add_status_code(100)
    class TestException(SanicException):
        pass
    Exception = TestException("this is a test", status_code=100)
    assert Exception.status_code == 100
    assert Exception.quiet is False


# Generated at 2022-06-24 03:37:28.460519
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exc = ServiceUnavailable("Unable to connect")
    assert exc.status_code == 503
    assert exc.message == "Unable to connect"
    assert exc.headers == {}

# Generated at 2022-06-24 03:37:32.578965
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
    else:
        raise Exception("Unauthorized not raised")


# Generated at 2022-06-24 03:37:37.955551
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert str(MethodNotSupported("message", "method", ["method"])) == "message"


# Generated at 2022-06-24 03:37:40.041642
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound("Dont work")
    assert type(exception) == SanicException


# Generated at 2022-06-24 03:37:51.122748
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Test __init__ of class Unauthorized
    """
    # test for scheme is None.
    test_instance_1 = Unauthorized(message="Auth required.", scheme=None)
    assert test_instance_1.headers=={}

    # test for scheme is not None.
    test_instance_2 = Unauthorized(
        message="Auth required.",
        scheme="Basic",
        realm="Restricted Area"
    )
    assert test_instance_2.headers=={
        "WWW-Authenticate": f"Basic realm=\"Restricted Area\"".rstrip()
    }

    # test for scheme is not None.

# Generated at 2022-06-24 03:38:02.125133
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    """
    Test the constructor of class MethodNotSupported
    """
    method = "POST"
    allowed_methods = ["GET", "HEAD", "POST", "PUT", "DELETE", "CONNECT",
     "OPTIONS", "TRACE", "PATCH"]
    try:
        # Try the MethodNotSupported
        raise MethodNotSupported('Method is not supported', method, allowed_methods)
    except MethodNotSupported as e:
        # Check the type of exception
        assert type(e) is MethodNotSupported
        # Check the status code
        assert e.status_code == 405
        # Check the relation between paramters
        assert e.headers["Allow"] == "GET, HEAD, POST, PUT, DELETE, CONNECT, OPTIONS, TRACE, PATCH"

        x = Exception('Raise a Exception')
       

# Generated at 2022-06-24 03:38:04.546092
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try: 
        raise RequestTimeout("test", 408)
    except Exception as e:
        e.status_code == 408
        print(e)

# Generated at 2022-06-24 03:38:05.978853
# Unit test for constructor of class ServerError
def test_ServerError():
    assert str(ServerError("Something bad happened")) == "Something bad happened"


# Generated at 2022-06-24 03:38:09.807423
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == "Request Timeout"
        assert e.quiet == False


# Generated at 2022-06-24 03:38:14.154755
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Invalid Range Type", 1000)
    except InvalidRangeType as e:
        assert e.status_code == 416 # Given status code
        assert e.headers == {"Content-Range": f"bytes */1000"} # Given headers


# Generated at 2022-06-24 03:38:15.870430
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    e = ServiceUnavailable("test")
    assert e.status_code == 503


# Generated at 2022-06-24 03:38:18.515532
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("test")
    except HeaderNotFound as e:
        assert e.message == "test"



# Generated at 2022-06-24 03:38:20.417502
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException.__init__(LoadFileException, 'some message')

    

# Generated at 2022-06-24 03:38:31.738345
# Unit test for function abort
def test_abort():
    assert abort(200) == "OK"
    assert abort(400) == "Bad Request"
    assert abort(401) == "Unauthorized"
    assert abort(403) == "Forbidden"
    assert abort(404) == "Not Found"
    assert abort(405) == "Method Not Allowed"
    assert abort(406) == "Not Acceptable"
    assert abort(408) == "Request Timeout"
    assert abort(409) == "Conflict"
    assert abort(411) == "Length Required"
    assert abort(413) == "Payload Too Large"
    assert abort(416) == "Range Not Satisfiable"
    assert abort(417) == "Expectation Failed"
    assert abort(418) == "I'm a teapot"
    assert abort(422) == "Unprocessable Entity"

# Generated at 2022-06-24 03:38:33.863492
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError
    except SanicException as err:
        assert err.status_code == 500

# Generated at 2022-06-24 03:38:35.230507
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    e = InvalidSignal(message="Exiting...")
    assert e.message == "Exiting..."


# Generated at 2022-06-24 03:38:38.101381
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    iu = InvalidUsage(message="Test", status_code=400)
    assert iu.message == "Test"
    assert iu.status_code == 400

# Generated at 2022-06-24 03:38:41.569106
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    not_supported_object = MethodNotSupported("Message", "POST", ["GET", "POST"])
    assert not_supported_object.message == "Message"
    assert not_supported_object.headers["Allow"] == "GET, POST"

# Generated at 2022-06-24 03:38:45.514082
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("abort test")
    except InvalidSignal as ise:
        assert str(ise) == "abort test"

# Generated at 2022-06-24 03:38:50.085507
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    plt = PayloadTooLarge("Help! The payload was too large.", 413)
    assert plt.status_code == 413

# Generated at 2022-06-24 03:38:53.670720
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        abort(404, "Could not found the file.")
    except LoadFileException as e:
        # 404 Could not found the file.
        assert e.message == 'Could not found the file.'
        assert e.status_code == 404

# Generated at 2022-06-24 03:38:58.862780
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("abc")
    except URLBuildError as e:
        assert e.message == "abc"
        assert e.status_code ==500

# Generated at 2022-06-24 03:39:03.545077
# Unit test for constructor of class SanicException
def test_SanicException():
    inst = SanicException("hello", status_code = 404, quiet = False)
    assert inst.status_code == 404
    assert inst.message == "hello"
    assert inst.quiet == False


# Generated at 2022-06-24 03:39:15.245851
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # With a Basic auth-scheme, realm MUST be present:
    raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")

    # With a Digest auth-scheme, things are a bit more complicated:
    raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area",
                       qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")

    # With a Bearer auth-scheme, realm is optional so you can write:
    raise Unauthorized("Auth required.", scheme="Bearer")

    # or, if you want to specify the realm:
    raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

    # or, if you want no realm to be specified:

# Generated at 2022-06-24 03:39:17.333824
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("message")
    assert error.status_code == 500



# Generated at 2022-06-24 03:39:19.151508
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden("message")


# Generated at 2022-06-24 03:39:21.513148
# Unit test for constructor of class Forbidden
def test_Forbidden():
    e = Forbidden("Forbidden")
    assert isinstance(e, SanicException)
    assert e.status_code == 403


# Generated at 2022-06-24 03:39:26.577786
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("test message")
    except PayloadTooLarge as e:
        assert e.args[0] == "test message"
        assert e.status_code == 413
        assert e.message == "test message"
        assert str(e) == "test message"


# Generated at 2022-06-24 03:39:30.782055
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == 'Not Found'
    except Exception as e:
        raise e

# Generated at 2022-06-24 03:39:36.959447
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "my error message"
    class Bunch:
        """
        Code from sanic.request
        """
        pass

    _range = Bunch()
    _range.total = 6
    _range.start = 2
    _range.stop = 6

    http_exception = ContentRangeError(message, _range)

    assert http_exception.status_code == 416
    assert http_exception.message == message
    assert http_exception.headers == {"Content-Range": "bytes */6"}

# Generated at 2022-06-24 03:39:40.076491
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    sanic_exception = HeaderNotFound(message="test", status_code=400)
    assert sanic_exception.message == "test"
    assert sanic_exception.status_code == 400

# Generated at 2022-06-24 03:39:41.001526
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with raises(Forbidden):
        raise Forbidden("This is awesome")

# Generated at 2022-06-24 03:39:44.422216
# Unit test for constructor of class NotFound
def test_NotFound():
    test = NotFound(message = "Failure to find the resource sought in the server.",
    status_code = 404, quiet = False)
    assert test.status_code == 404 and test.quiet == False

# # Unit test for constructor of class InvalidUsage

# Generated at 2022-06-24 03:39:49.602004
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Test for accessing the status_code member of InvalidRangeType
    assert InvalidRangeType("", None).status_code == 416
    # Test for accessing the message member of InvalidRangeType
    assert InvalidRangeType("", None).message == "Range Not Satisfiable"
    # Test for accessing the __str__ member of InvalidRangeType
    assert str(InvalidRangeType("", None)) == "Range Not Satisfiable"

# Generated at 2022-06-24 03:39:57.654763
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Test for constructor of class Unauthorized
    """
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert getattr(e, 'message') == "Auth required."
        assert getattr(e, 'status_code') is None
        assert getattr(e, 'headers') == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert getattr(e, 'quiet') is False

# Generated at 2022-06-24 03:40:05.788569
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    import unittest

    class ContentRangeErrorTest(unittest.TestCase):
        def test_content_range(self):
            content_range = ContentRangeError(message='test test test', content_range=13)
            self.assertEqual(content_range.headers.get('Content-Range'), 'bytes */13')
            self.assertEqual(content_range.message, 'test test test')
            self.assertEqual(content_range.content_range, 13)

    suite = unittest.TestLoader().loadTestsFromTestCase(ContentRangeErrorTest)
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    test_ContentRangeError()

# Generated at 2022-06-24 03:40:07.141394
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = "not found"
    nf = NotFound(msg, status_code=404)
    assert nf.message == msg
    assert nf.status_code == 404


# Generated at 2022-06-24 03:40:09.146834
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("error message")
    except ServerError as instance:
        assert instance.status_code == 500



# Generated at 2022-06-24 03:40:18.127097
# Unit test for function abort
def test_abort():
    from sanic.response import text, json

    with pytest.raises(NotFound) as exc_info:
        abort(404)
    assert exc_info.value.status_code == 404
    assert exc_info.value.__str__() == "404: Not Found"

    with pytest.raises(InvalidUsage) as exc_info:
        abort(400)
    assert exc_info.value.status_code == 400
    assert len(exc_info.value.__str__()) > 10

    with pytest.raises(ServerError) as exc_info:
        abort(500)
    assert exc_info.value.status_code == 500
    assert len(exc_info.value.__str__()) > 10

    with pytest.raises(SanicException) as exc_info:
        abort(507)

# Generated at 2022-06-24 03:40:20.523177
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    test_case = HeaderExpectationFailed("Test", "Test")
    assert test_case.status_code == 417
    assert test_case.message == "Test"


# Generated at 2022-06-24 03:40:22.717423
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Error Building URL")
    except Exception as e:
        assert str(e) == "Error Building URL"

# Generated at 2022-06-24 03:40:26.174885
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge) as excinfo:
        raise PayloadTooLarge(message='Request entity too large')
    assert excinfo.value.message == 'Request entity too large'
    assert excinfo.value.status_code == 413
    assert excinfo.value.quiet == True


# Generated at 2022-06-24 03:40:29.443912
# Unit test for function add_status_code
def test_add_status_code():
    new_status_code = 449
    message = 'Retry With'
    new_class = add_status_code(new_status_code)(SanicException)
    new_instance = new_class(message)
    assert new_instance.message == message
    assert new_instance.status_code == new_status_code

# Generated at 2022-06-24 03:40:33.124980
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("file")
    except PyFileError as e:
        assert str(e) == "could not execute config file file"

# Generated at 2022-06-24 03:40:35.700772
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('file.py')
    except PyFileError as e:
        assert str(e) == "could not execute config file file.py"
        assert isinstance(e, PyFileError)


# Generated at 2022-06-24 03:40:40.786600
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("File not found.", "/home/user/file.txt", "localhost:8000/file.txt")
    except FileNotFound:
        assert True
    else:
        assert False

if __name__ == "__main__":
    test_FileNotFound()
    print("FileNotFound构造器测试通过")

# Generated at 2022-06-24 03:40:44.326195
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("message", "method", ["allowed_methods", "get"])
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "allowed_methods, get"}

# Generated at 2022-06-24 03:40:46.989912
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported("message", "GET", ["POST", "PUT"])
    assert(mns.headers == {"Allow": "POST, PUT"})

# Generated at 2022-06-24 03:40:50.253289
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payloadTooLarge = PayloadTooLarge('Payload Too Large', 40000)
    assert(payloadTooLarge.args[0] == 'Payload Too Large')
    assert(payloadTooLarge.status_code == 413)
    assert(payloadTooLarge.args[1] == 40000)


# Generated at 2022-06-24 03:40:52.123387
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError()
    assert exception.status_code == 500

# Generated at 2022-06-24 03:40:57.989737
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Testing HeaderExpectationFailed constructor with empty and non-empty message
    try:
        # Raising HeaderExpectationFailed
        raise HeaderExpectationFailed("HeaderExpectationFailed")
    except HeaderExpectationFailed as err:
        assert err.status_code == 417
        assert err.message == "HeaderExpectationFailed"
    try:
        # Raising HeaderExpectationFailed with empty message
        raise HeaderExpectationFailed()
    except HeaderExpectationFailed as err:
        assert err.status_code == 417


# Generated at 2022-06-24 03:41:00.478233
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "message"
    content_range = None
    err = ContentRangeError(message, content_range)
    assert str(err) == message

# Generated at 2022-06-24 03:41:02.856137
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as exc_info:
        raise InvalidUsage('Invalid param')
    assert exc_info.type is InvalidUsage


# Generated at 2022-06-24 03:41:06.642576
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal
    except Exception as e:
        assert str(invalid_signal) == repr(invalid_signal)
        assert str(invalid_signal) == invalid_signal.__class__.__qualname__
        assert invalid_signal.args == ()


# Generated at 2022-06-24 03:41:08.339921
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header = HeaderExpectationFailed('test header', 417)
    assert header.status_code == 417
    assert header.message == 'test header'

# Generated at 2022-06-24 03:41:17.027290
# Unit test for function abort
def test_abort():
    """
    Test that abort function works.
    """
    try:
        abort(404)
        assert False, "abort(404) did not raise an exception"
    except NotFound:
        pass

    try:
        abort(404, "File not found")
        assert False, "abort(404, 'File not found') did not raise an exception"
    except NotFound as ex:
        assert ex.message == "File not found"

    try:
        abort(502)
        assert False, "abort(502) did not raise an exception"
    except SanicException as ex:
        assert ex.message == "Bad Gateway"

if __name__ == '__main__':
    test_abort()

# Generated at 2022-06-24 03:41:21.834327
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    msg = ""
    timeout = RequestTimeout(message=msg)
    print(timeout)

if __name__=='__main__':
    test_RequestTimeout()

# Generated at 2022-06-24 03:41:27.940078
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    class SanicMock(SanicException):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)
    ContentRangeError("Parsing request failed", "content_range")
    # Also testing the add_status_code decorator
    SanicMock("Parsing request failed", "content_range")

# Generated at 2022-06-24 03:41:39.060139
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    with pytest.raises(Exception) as info:
        raise Unauthorized(
            'Authorization required',
            scheme='Basic',
            realm='Restricted Area'
        )

    with pytest.raises(Exception) as info:
        raise Unauthorized(
            'Authorization required',
            scheme='Digest',
            realm='Restricted Area',
            qop='auth, auth-int',
            algorithm='MD5',
            nonce='abcdef',
            opaque='zyxwvu'
        )

    with pytest.raises(Exception) as info:
        raise Unauthorized(
            'Authorization required',
            scheme='Bearer'
        )


# Generated at 2022-06-24 03:41:50.201380
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test with a Basic auth-scheme, realm MUST be present
    try:
        raise Unauthorized("Auth required.", scheme="Basic")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.headers["WWW-Authenticate"] == 'Basic realm=""'
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    # Test with a Digest auth-scheme, things are a bit more complicated

# Generated at 2022-06-24 03:41:53.109027
# Unit test for constructor of class PyFileError
def test_PyFileError():
    temp_pyerror = PyFileError('config')
    if str(temp_pyerror) != "could not execute config file config":
        raise Exception('Wrong error message')

# Generated at 2022-06-24 03:41:58.347205
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound: ", 400)
    except HeaderNotFound as err:
        assert err.status_code == 400
        assert err.message == "HeaderNotFound: "
        assert err.quiet is True

# Generated at 2022-06-24 03:42:00.892002
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Invalid Usage", "500")
    except Exception as ex:
        assert ex.args[0] == "Invalid Usage"

# Generated at 2022-06-24 03:42:09.724239
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    number_of_bytes_full_request=10000                  #Upper and lower bytes are 0
    total_number_of_bytes=1000                          #Total number of bytes in video file
    content_range=bytesio.ContentRange(0, number_of_bytes_full_request, total_number_of_bytes)
    content_range_error=ContentRangeError(message, content_range)
    assert content_range_error.message==expected_message
    assert content_range_error.headers["Content-Range"]=="bytes */"+str(total_number_of_bytes)


# Generated at 2022-06-24 03:42:15.090469
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as error:
        raise HeaderNotFound('test header not found')

    assert error.value.status_code == 400
    assert error.value.args[0] == 'test header not found'
    assert error.value.message == 'test header not found'



# Generated at 2022-06-24 03:42:18.755695
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    body = '{"title": "This is a test"}'
    with pytest.raises(InvalidUsage) as exc_info:
        raise InvalidUsage(body)

    assert str(exc_info.value) == body

# Generated at 2022-06-24 03:42:26.656996
# Unit test for function add_status_code
def test_add_status_code():
    code = 404
    quiet = None
    def class_decorator(cls):
        cls.status_code = code
        if quiet or quiet is None and code != 500:
            cls.quiet = True
        _sanic_exceptions[code] = cls
        return cls

    @add_status_code(404)
    class NewException(SanicException):
        pass
    assert NewException.status_code == 404
    assert _sanic_exceptions[404] == NewException
    del _sanic_exceptions[404]

# Generated at 2022-06-24 03:42:30.068367
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("message", 10)
    except InvalidRangeType as err:
        assert err.message == "message"
        assert err.content_range == 10

# Generated at 2022-06-24 03:42:31.237026
# Unit test for constructor of class ServerError
def test_ServerError():
    pass

# Generated at 2022-06-24 03:42:34.820639
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Test",status_code=404,quiet=True)
    except SanicException as e:
        assert e.status_code == 404
        assert e.quiet == True

# Generated at 2022-06-24 03:42:36.740444
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("test_error_url")
    assert error is not None
    print(error)

# Generated at 2022-06-24 03:42:41.269662
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fileNotFound = FileNotFound("File Not Found", "C:/f1.html", "/f1.html")
    assert fileNotFound.message == "File Not Found"
    assert fileNotFound.path == "C:/f1.html"
    assert fileNotFound.relative_url == "/f1.html"

# Generated at 2022-06-24 03:42:45.180534
# Unit test for function abort
def test_abort():
    """
    Testing sanic.exceptions.abort
    """
    # Test for GET
    try:
        abort(400)
    except SanicException as e:
        assert e.status_code == 400
        assert e.message == 'Bad Request'
        assert repr(e) == "<SanicException 'Bad Request' [400]>"

# Generated at 2022-06-24 03:42:49.923209
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        if not hasattr(signal, "SIGINT"):
            raise InvalidSignal("No support for SIGINT in this os")
    except InvalidSignal as e:
        print(e.status_code)
        print(e.message)


# Generated at 2022-06-24 03:42:59.372652
# Unit test for function abort
def test_abort():
    # Exception with status code and custom message
    try:
        abort(status_code=500, message="test")
    except SanicException as e:
        print(e)

    # Exception with status code only
    try:
        abort(status_code=500)
    except SanicException as e:
        print(e)

    # Exception with status code and default message
    try:
        abort(status_code=400)
    except SanicException as e:
        print(e)

    # Exception with status code and custom message
    try:
        abort(status_code=400, message="test")
    except SanicException as e:
        print(e)

if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-24 03:43:02.368862
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('hello')
    except LoadFileException as e:
        assert str(e) == 'hello'
        assert e.message == 'hello'
        assert e.status_code == None
        assert isinstance(e, Exception)


# Generated at 2022-06-24 03:43:06.318583
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError("test", 1024)
    assert a.status_code == 416
    assert a.headers["Content-Range"] == "bytes */1024"
    assert str(a) == "test"

# Generated at 2022-06-24 03:43:09.100188
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('test message')
    except Exception as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:43:14.771424
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = 'test message'
    header_not_found = HeaderNotFound(message)
    assert header_not_found.message == 'test message'
    assert header_not_found.status_code == 400

    header_not_found = HeaderNotFound(message, status_code=401)
    assert header_not_found.message == 'test message'
    assert header_not_found.status_code == 401

# Generated at 2022-06-24 03:43:18.848842
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = "Range Not Satisfiable"
    header = "bytes */18"
    try: 
        raise ContentRangeError(msg, header)
    except ContentRangeError as e:
        assert str(e) == msg
        assert e.headers == {'Content-Range': header}

# Generated at 2022-06-24 03:43:23.230573
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("/home/user/file", "http://www.somewebsite.com/file")
    except FileNotFound as e:
        assert e.status_code == 404
        assert e.path == "/home/user/file"
        assert e.relative_url == "http://www.somewebsite.com/file"



# Generated at 2022-06-24 03:43:24.504590
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    myObject = ServiceUnavailable("Service Unavailable")
    assert myObject.message == "Service Unavailable"


# Generated at 2022-06-24 03:43:29.228878
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        sanic_exception = ServiceUnavailable('503 ServiceUnavailable')
        assert sanic_exception.status_code == 503
    except AssertionError as e:
        return False
    return True


# Generated at 2022-06-24 03:43:33.079495
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """
    This test ensures that the PayloadTooLarge class is constructed correctly
    """
    message = "Message"
    ptlf = PayloadTooLarge(message)
    assert ptlf.status_code == 413
    assert ptlf.quiet == True
    assert ptlf.message == message

# Generated at 2022-06-24 03:43:38.544269
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # Create a PayloadTooLarge instance
    payload_too_large = PayloadTooLarge(
        message="The user has not been payed yet", status_code=413
    )
    # assert its status_code and message
    assert payload_too_large.status_code == 413
    assert str(payload_too_large) == "The user has not been payed yet"

# Generated at 2022-06-24 03:43:43.792998
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = "sample_path"
    relative_url = "sample_relative_url"
    message = "sample_message"

    fnf = FileNotFound(message, path, relative_url)

    assert fnf.message == message
    assert fnf.path == path
    assert fnf.relative_url == relative_url

# Generated at 2022-06-24 03:43:48.405533
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="LoadFileException Test", status_code=500)
    except Exception as e:
        assert "LoadFileException Test" == str(e)
        assert 500 == e.status_code

# Generated at 2022-06-24 03:43:51.626657
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    a = HeaderExpectationFailed("test", quiet=None)
    assert a.status_code == 417
    assert a.quiet == True
    assert a.message == "test"


if __name__ == '__main__':
    test_HeaderExpectationFailed()
    print("Test has passed!")

# Generated at 2022-06-24 03:43:55.666473
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType("message", None)
    assert not hasattr(exc,"content_range")
    assert exc.headers is not None
    assert exc.headers.get("Content-Range") is not None
    assert exc.headers.get("Content-Range") == "bytes */None"

# Generated at 2022-06-24 03:44:03.338282
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('The signal is invalid', status_code=400)
    except InvalidSignal as err:
        assert err.args == ('The signal is invalid',)
        assert err.message == 'The signal is invalid'
        assert err.status_code == 400
        assert str(err) == 'The signal is invalid'
        assert err.__class__.__name__ == 'InvalidSignal'
        assert err.__class__.__module__ == 'sanic.exceptions'



# Generated at 2022-06-24 03:44:14.590183
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    Test the base SanicException.
    """
    # Test default constructor
    sanic_exception = SanicException("An exception")
    assert sanic_exception.message == "An exception"
    assert sanic_exception.status_code is None
    assert sanic_exception.quiet is False

    # Test constructor with status_code
    sanic_exception = SanicException("An exception", status_code=400)
    assert sanic_exception.message == "An exception"
    assert sanic_exception.status_code == 400
    assert sanic_exception.quiet is False

    # Test constructor with quiet
    sanic_exception = SanicException("An exception", quiet=True)
    assert sanic_exception.message == "An exception"
    assert sanic_exception.status_

# Generated at 2022-06-24 03:44:17.417230
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(TypeError):
        SanicException()
    with pytest.raises(TypeError):
        SanicException(message='test message')
    with pytest.raises(TypeError):
        SanicException(status_code=400)



# Generated at 2022-06-24 03:44:23.067876
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message=None, status_code=404)
    except LoadFileException as exc:
        assert exc.message == "This resource could not be found"
        assert exc.status_code == 404

abort.__doc__ = abort.__doc__.format(**{"status_code": None})



# Generated at 2022-06-24 03:44:24.254500
# Unit test for constructor of class ServerError
def test_ServerError():
    exc = ServerError()
    assert exc.status_code == 500



# Generated at 2022-06-24 03:44:27.614353
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("testing")
    assert url_build_error.status_code == 500
    assert url_build_error.quiet == False
    assert url_build_error.message == "testing"
    assert url_build_error.payload == {'message': 'testing'}
    assert url_build_error.__repr__() == "URLBuildError(message='testing', status_code=500, quiet=False)"


# Generated at 2022-06-24 03:44:30.137129
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exc = MethodNotSupported('message', 'POST', ['GET', 'HEAD'])
    assert exc.args == ('message',)
    assert exc.headers == {'Allow': 'GET, HEAD'}

# Generated at 2022-06-24 03:44:32.811548
# Unit test for constructor of class NotFound
def test_NotFound():
    assert(404 == NotFound('').status_code)

# Generated at 2022-06-24 03:44:36.145909
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Service is still unavailable")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Service is still unavailable"
    else:
        assert False

# Generated at 2022-06-24 03:44:38.243323
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    my_file = LoadFileException(message='Failed to Load Configuration File')
    #print(my_file)


# Generated at 2022-06-24 03:44:39.660860
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert RequestTimeout("Request Timeout") is not None

# Generated at 2022-06-24 03:44:43.921276
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message="Invalid Range Type for test program.", content_range=0, status_code=500)
        assert False
    except InvalidRangeType as e:
        assert str(e) == "Invalid Range Type for test program."


# Generated at 2022-06-24 03:44:48.293933
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    client_exception = RequestTimeout("The client has not produced any request data for some time.",
                                      408)
    print(client_exception.__dict__)
    assert client_exception.status_code == 408
    assert client_exception.__dict__['status_code'] == 408
    assert client_exception.__dict__['message'] == "The client has not produced any request data for some time."
    assert client_exception.__dict__['quiet'] == True

# Generated at 2022-06-24 03:44:51.793604
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    message = "Hello"
    try:
        raise InvalidUsage(message)
    except Exception as e:
        assert e.status_code == 400
        assert str(e) == message

# Generated at 2022-06-24 03:44:56.097369
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    e = PayloadTooLarge(message="Payload Too Large")
    assert str(e) == 'Payload Too Large'
    assert e.status_code == 413
    assert e.message == 'Payload Too Large'



# Generated at 2022-06-24 03:44:59.694986
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    class ContentRange():
        def __init__(self):
            self.start = 0
            self.stop = 0
            self.total = 0
    content_range = ContentRange()
    exception = ContentRangeError("This is a test", content_range)

# Generated at 2022-06-24 03:45:01.963275
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge('message')
    assert exception.message == 'message'
    assert exception.status_code == 413
    assert str(exception) == 'message'

# Generated at 2022-06-24 03:45:04.517252
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    """
    Test InvalidRangeType class.
    """
    x = InvalidRangeType('Error', 1)
    assert x.headers['Content-Range'] == 'bytes */1'



# Generated at 2022-06-24 03:45:06.881767
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
  try:
    raise HeaderNotFound("Error message")
  except HeaderNotFound as e:
    assert e.message == "Error message"
    assert e.status_code == 400


# Generated at 2022-06-24 03:45:12.474070
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fl = FileNotFound('test','/home/user/Desktop/final/','/file')
    assert fl.message == 'test'
    assert fl.path == '/home/user/Desktop/final/'
    assert fl.relative_url == '/file'


# Generated at 2022-06-24 03:45:19.273862
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    def _test_assert(message, path, relative_url) -> URLBuildError:
        return URLBuildError(message, path, relative_url)

    assert _test_assert("path is not a regular file", 'path', '') is not None
    assert _test_assert("path is not a regular file", 'path', '').message == 'path is not a regular file'
    assert _test_assert("path is not a regular file", 'path', '').path == 'path'
    assert _test_assert("path is not a regular file", 'path', '').relative_url == ''


# Generated at 2022-06-24 03:45:22.607296
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    class InvalidUsage(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass
    try:
        raise InvalidUsage('invalid usage')
    except InvalidUsage as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:45:24.660475
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("url")
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "url"


# Generated at 2022-06-24 03:45:27.281352
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Resource not found")
    except LoadFileException as err:
        assert str(err) == "Resource not found"



# Generated at 2022-06-24 03:45:28.253894
# Unit test for constructor of class PyFileError
def test_PyFileError():
    PyFileError("file")

# Generated at 2022-06-24 03:45:31.699681
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    error = MethodNotSupported(
        "Method NotSupported not supported",
        method="POST",
        allowed_methods=["GET", "POST", "PUT"],
    )
    assert error.headers == {"Allow": "GET, POST, PUT"}



# Generated at 2022-06-24 03:45:40.582074
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except Exception as e:
        assert isinstance(e, NotFound)

    try:
        abort(404, "oops")
    except Exception as e:
        assert isinstance(e, NotFound)
        assert e.status_code == 404
        assert e.message == "oops"

    try:
        abort(404, message="oops")
    except Exception as e:
        assert isinstance(e, NotFound)
        assert e.status_code == 404
        assert e.message == "oops"

    try:
        abort(999, "unknown")
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.status_code == 999
        assert e.message == "unknown"


# Generated at 2022-06-24 03:45:46.182400
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    filename = '/tmp/foo.txt'
    url = '/bar/foo.txt'
    try:
        raise FileNotFound('File Not Found : {}'.format(filename), filename, url)
    except FileNotFound as e:
        assert e.path == filename
        assert e.relative_url == url

if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-24 03:45:51.454565
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.args[0] == "417 Expectation Failed"
        assert e.message == "417 Expectation Failed"
        assert e.headers is None

# Generated at 2022-06-24 03:45:58.526859
# Unit test for constructor of class SanicException
def test_SanicException():
    # Arrange
    message = 'error message'
    status_code = 400
    quiet = False
    sanicException = SanicException(message, status_code, quiet)

    # Act
    actual_message = sanicException.args[0]
    actual_status_code = sanicException.status_code
    actual_quiet = sanicException.quiet
    expected_message = message
    expected_status_code = status_code
    expected_quiet = quiet

    # Assert
    assert actual_message == expected_message
    assert actual_status_code == expected_status_code
    assert actual_quiet == expected_quiet

# Generated at 2022-06-24 03:46:01.135412
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("test error")
    except Forbidden as e:
        assert e.status_code == 403
        assert e.message == "test error"

# Generated at 2022-06-24 03:46:02.519242
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("Test").args == ('could not execute config file %s', "Test")

# Generated at 2022-06-24 03:46:06.178620
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("",status_code=503)
    except  ServiceUnavailable as e:
        assert e.message == "" and e.status_code == 503

# Generated at 2022-06-24 03:46:07.440717
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException('failed',400)

# Generated at 2022-06-24 03:46:10.870273
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="Some Expectation Failed")
    except HeaderExpectationFailed:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:46:14.958744
# Unit test for constructor of class SanicException
def test_SanicException():
    _str = "test"
    _int = 100
    _bool = True

    with pytest.raises(SanicException, message="Testing SanicException constructor"):
        SanicException(message=_str, status_code=_int, quiet=_bool)

# Generated at 2022-06-24 03:46:24.214221
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(501)
    class TestExtendSanicException(SanicException):
        pass

    @add_status_code(500)
    class TestExtendServerError(SanicException):
        pass

    class TestExtendAlias(ServerError):
        pass

    @add_status_code(501)
    class TestExtendAlias(SanicException):
        pass

    assert _sanic_exceptions[501] == TestExtendSanicException
    assert TestExtendServerError in _sanic_exceptions.values()
    assert TestExtendAlias in _sanic_exceptions.values()

# Generated at 2022-06-24 03:46:27.489424
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    a = HeaderExpectationFailed("msg")
    b = HeaderExpectationFailed("msg", status_code=417)
    assert a is not None
    assert b is not None

# Generated at 2022-06-24 03:46:29.613336
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Forbidden:
        pass

# Generated at 2022-06-24 03:46:34.053177
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('The path does not exist', '456', 'abc')
    except FileNotFound as e:
        assert e.path == '456'
        assert e.relative_url == 'abc'
    else:
        raise Exception('no FileNotFound raised')

# Generated at 2022-06-24 03:46:40.457507
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as ctx:
        raise MethodNotSupported("message", "method", ["allowed"])
    assert ctx.value.message == "message"
    assert ctx.value.status_code == 405
    assert ctx.value.headers == {"Allow": "allowed"}


# Generated at 2022-06-24 03:46:44.210925
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("test")
    assert hnf.message == "test"
    assert hnf.status_code == 400
    assert hnf.quiet is True

# Generated at 2022-06-24 03:46:52.243912
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    try:
        # Test authorization scheme 'Bearer' with no realm
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate":"Bearer"}
    try:
        # Test authorization scheme 'Bearer' with no realm
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""}

# Generated at 2022-06-24 03:46:59.050364
# Unit test for function abort
def test_abort():
    try:
        abort(500, 'Server Error')
    except SanicException as e:
        assert e.args[0] == 'Server Error'
        assert e.status_code == 500
        assert e.quiet is None

    try:
        abort(503)
    except ServiceUnavailable as e:
        assert str(e) == "503 Service Unavailable"
        assert e.status_code == 503
        assert e.quiet

    try:
        abort(322)
    except SanicException as e:
        assert str(e) == "322 Unknown Status"
        assert e.status_code == 322
        assert e.quiet is None

# Generated at 2022-06-24 03:47:01.059925
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exc = Forbidden("message")
    assert exc.status_code == 403
    assert exc.message == "message"


# Generated at 2022-06-24 03:47:05.457494
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # "Method Not Supported" is status code 405, with the header Allow: GET
    method_not_supported_exception = MethodNotSupported("GET")
    assert method_not_supported_exception.message == "GET"
    assert method_not_supported_exception.status_code == 405

# Generated at 2022-06-24 03:47:09.693296
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "method not supported"
    method = 'GET'
    allowed_methods = ('PUT', 'POST')
    e = MethodNotSupported(message, method, allowed_methods)
    assert e.args[0] is message
    assert e.headers['Allow'] is "PUT, POST"

# Generated at 2022-06-24 03:47:12.454194
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(b'abc', 'abc')
    except Exception as e:
        assert str(e) == 'abc'

# Generated at 2022-06-24 03:47:15.603991
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    total = 123
    ttt  = InvalidRangeType(f"bytes */{total}")
    headers = {'Content-Range': f'bytes */{total}'}
    assert (ttt.headers == headers)