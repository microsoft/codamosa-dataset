

# Generated at 2022-06-24 03:37:28.365608
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as excinfo:
        raise SanicException("hello")
    assert str(excinfo.value) == "hello"
    assert excinfo.value.status_code == 500
    with pytest.raises(SanicException) as excinfo:
        raise SanicException("hello", status_code=400)
    assert str(excinfo.value) == "hello"
    assert excinfo.value.status_code == 400
    with pytest.raises(SanicException) as excinfo:
        raise SanicException("hello", quiet=True)
    assert str(excinfo.value) == "hello"
    assert excinfo.value.status_code == 500

# Generated at 2022-06-24 03:37:30.297749
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("")
    except ServerError as e:
        assert e.status_code == 500


# Generated at 2022-06-24 03:37:32.129789
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        abort(400)
    except HeaderNotFound as e:
        print(e)

# Generated at 2022-06-24 03:37:38.057653
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout("408 Request Timeout")
    assert(rt.status_code == 408)

# Generated at 2022-06-24 03:37:43.049083
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("Message", status_code=500, quiet=True)
    assert error.status_code == 500
    assert error.message == "Message"
    assert error.quiet == True


# Generated at 2022-06-24 03:37:50.979516
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as excinfo:
        raise ContentRangeError("The request MUST include a Range header field",0)
    
    assert excinfo.errisinstance(ContentRangeError)
    assert excinfo.errisinstance(SanicException)
    assert excinfo.errisinstance(Exception)
    assert excinfo.value.status_code == 416
    assert excinfo.value.quiet == True
    assert excinfo.value.message == "The request MUST include a Range header field"



# Generated at 2022-06-24 03:37:54.005024
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        exc = Forbidden("This is forbidden.")
        assert True
    except Exception:
        assert False

    assert exc.status_code == 403



# Generated at 2022-06-24 03:37:59.274946
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("test").status_code is None
    assert SanicException("test", quiet=True).status_code is None
    assert SanicException("test", status_code=400).status_code == 400
    assert SanicException("test", 400, None).status_code == 400
    assert SanicException("test", status_code=404).quiet == True
    assert SanicException("test", status_code=500).quiet == False


# Generated at 2022-06-24 03:38:01.635092
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable):
        raise ServiceUnavailable("Test ServiceUnavailable")


# Generated at 2022-06-24 03:38:04.096240
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage('error_message')
    assert a.message == 'error_message'
    assert a.status_code == 400

# Generated at 2022-06-24 03:38:05.878332
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with raises(ServiceUnavailable):
        raise ServiceUnavailable("message", status_code=503, quiet=False)

# Generated at 2022-06-24 03:38:07.997170
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound.status_code==404
test_NotFound()


# Generated at 2022-06-24 03:38:13.186966
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # Given
    expected_message = "Test message"
    expected_status_code = 400

    # When
    exception = PayloadTooLarge(expected_message, expected_status_code)

    # Then
    assert exception.message == expected_message
    assert exception.status_code == expected_status_code
    assert exception.quiet == True

# Generated at 2022-06-24 03:38:14.679341
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError(None)
    except PyFileError:
        pass

# Generated at 2022-06-24 03:38:22.033266
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        with open('./logs/exception_logs_test.txt', 'a+') as fo:
            try:
                raise LoadFileException("test_LoadFileException")
            except LoadFileException as ex:
                log = str(datetime.datetime.now()) + ": " + str(ex)
                fo.writelines(log + "\n")
                print(log)
    except IOError as e:
        print("fail to open file")
test_LoadFileException()

# Generated at 2022-06-24 03:38:30.281454
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # the super() call of constructor of MethodNotSupported is
    # super().__init__(message), where super() is SanicException class
    # the __init__(self, message, status_code=None, quiet=None) of SanicException
    # assigns 'message' to self.message, 'status_code' to self.status_code,
    # and 'quiet' to self.quiet
    # then the self.headers = {"Allow": ", ".join(allowed_methods)}
    allowed_methods = ['GET', 'POST', 'PUT']
    method_not_supported = MethodNotSupported("Message", 'PUT', allowed_methods)
    assert method_not_supported.message == "Message"
    assert method_not_supported.status_code == 405
    assert method_not_supported.quiet is True
    assert method_not_

# Generated at 2022-06-24 03:38:33.969422
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = Bunch(total=100)
    err = ContentRangeError("message", content_range)
    assert err.headers == {"Content-Range": "bytes */100"}


# Generated at 2022-06-24 03:38:36.969053
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed(message="test", status_code=417)
    assert exception.status_code == 417
    assert exception.message == "test"

# Generated at 2022-06-24 03:38:44.924594
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException("Message", status_code=200, quiet=True)
    assert exception.args == ("Message",)
    assert exception.status_code == 200
    assert exception.quiet is True
    exception.quiet = False
    assert exception.quiet is False
    exception.quiet = None
    assert exception.quiet is None
    exception.status_code = 501
    assert exception.status_code == 501
    try:
        exception.status_code = "Code"
        assert False
    except TypeError as e:
        assert str(e) == "status_code must be an int"



# Generated at 2022-06-24 03:38:50.346798
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("boom")

    assert hnf.message  == 'boom'
    assert hnf.status_code == 400
    assert hnf.quiet is None



# Generated at 2022-06-24 03:38:58.005360
# Unit test for function add_status_code
def test_add_status_code():
    """
    Unit test for function add_status_code
    """
    @add_status_code(418)
    class IAmATeapot(SanicException):
        pass

    # _sanic_exceptions[418].__name__ should be IAmATeapot.__name__
    assert _sanic_exceptions[418].__name__ == "IAmATeapot"

    # test __init__ function of IAmATeapot
    assert _sanic_exceptions[418].__init__ is not SanicException.__init__

    assert _sanic_exceptions[418](message='I am a teapot').status_code == 418
    assert _sanic_exceptions[418](message='I am a teapot').message == 'I am a teapot'

# Generated at 2022-06-24 03:38:59.369319
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage(message='test', status_code=404) is None


# Generated at 2022-06-24 03:39:02.200076
# Unit test for constructor of class NotFound
def test_NotFound():
    exc = NotFound(message='test', status_code=404, quiet=False)
    assert exc.message == 'test'
    assert exc.status_code == 404
    assert exc.quiet == False


# Generated at 2022-06-24 03:39:08.805634
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "message"
    method = "method"
    allowed_methods = "allowed_methods"
    class_MethodNotSupported = MethodNotSupported(message, method, allowed_methods)
    assert class_MethodNotSupported.message == message
    assert class_MethodNotSupported.method == method
    assert class_MethodNotSupported.allowed_method == allowed_methods


# Generated at 2022-06-24 03:39:15.293715
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # This test is also a demonstration of how to use this class.
    # It will throw a ContentRangeError
    try:
        raise ContentRangeError("Range not satisfiable", -1)
    except ContentRangeError as err:
        assert err.status_code == 416
        # Don't forget "bytes=", the client will send it,
        # and if you expect it, always include it in the string.
        assert err.headers["Content-Range"] == "bytes */-1"

# Generated at 2022-06-24 03:39:20.807148
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('You can not watch this video')
    except Forbidden as err:
        assert isinstance(err, Exception)
        assert type(err) == Forbidden
        assert err.status_code == 403
        assert str(err) == "You can not watch this video"
        assert err.message == "You can not watch this video"
        assert err.quiet == True
    else:
        assert False


# Generated at 2022-06-24 03:39:24.953758
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    ptl = PayloadTooLarge("Too large", 100)
    # The expect value is "Too large"
    assert ptl.args[0] == "Too large"
    # The expect value is 100
    assert ptl.args[1] == 100

# Generated at 2022-06-24 03:39:27.682957
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = 'Header not found'
    try:
        raise HeaderNotFound(message)
    except HeaderNotFound as e:
        assert e.args[0] == message


# Generated at 2022-06-24 03:39:30.967312
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fn = FileNotFound('message', 'path', 'relative_url')
    assert fn.message == 'message'
    assert fn.path == 'path'
    assert fn.relative_url == 'relative_url'
    assert fn.status_code == 404

# Generated at 2022-06-24 03:39:36.347481
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        test = Forbidden("test message")
        assert test.message == "test message"
        assert test.status_code == 403
    except Exception as e:
        print("Exception occurred: {}".format(e))


# Generated at 2022-06-24 03:39:38.084879
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden('Forbidden')

# Generated at 2022-06-24 03:39:40.740861
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exception = InvalidSignal("invalid signal")
    assert exception.__str__() == "invalid signal"


# Generated at 2022-06-24 03:39:45.595325
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        # Create a Forbidden object
         forbidden = Forbidden('Forbidden')

         # get the message from the object
         message = forbidden.message

         # compare the received message with expected message
         assert message == 'Forbidden'

    except Exception as e:
         print("An error occurred in test_Forbidden: ", e)

# Generated at 2022-06-24 03:39:51.361774
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_exception = PayloadTooLarge(message="test message", status_code=413)
    assert test_exception.status_code == 413
    assert test_exception.message == "test message"

# Generated at 2022-06-24 03:39:55.530105
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    e = Exception()
    e.message = ""
    try:
        raise InvalidUsage(e)
        assert False
    except InvalidUsage as e:
        print(e)
        assert str(e) == ""
        assert e.status_code == 400
    except Exception:
        assert False
    assert True


# Generated at 2022-06-24 03:40:00.401811
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "This is an error message."
    method = "GET"
    allowed_methods = ["GET", "POST"]
    method_error = MethodNotSupported(message, method, allowed_methods)
    assert method_error.message == message
    assert method_error.status_code == 405
    assert method_error.quiet is None
    assert method_error.headers == {'Allow': 'GET, POST'}

# Generated at 2022-06-24 03:40:03.023755
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound
    except FileNotFound as e:
        #print(e.message)
        assert(e.message == "Not Found")
    except Exception as e:
        print(e)

# Generated at 2022-06-24 03:40:14.031494
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound:
        pass
    else:
        raise AssertionError("Expected NotFound exception.")

    try:
        abort(400)
    except InvalidUsage:
        pass
    else:
        raise AssertionError("Expected InvalidUsage exception.")

    try:
        abort(405)
    except MethodNotSupported:
        pass
    else:
        raise AssertionError("Expected MethodNotSupported exception.")

    try:
        abort(500)
    except ServerError:
        pass
    else:
        raise AssertionError("Expected ServerError exception.")

    try:
        abort(503)
    except ServiceUnavailable:
        pass
    else:
        raise AssertionError("Expected ServiceUnavailable exception.")


# Generated at 2022-06-24 03:40:20.522951
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"
    try:
        abort(400, "Incorrect password")
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Incorrect password"
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"

# Generated at 2022-06-24 03:40:22.394156
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('message')
    except InvalidSignal:
        pass


# Generated at 2022-06-24 03:40:30.376785
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Make sure the Unauthorized constructor works as intended.

    """
    with pytest.raises(Unauthorized) as ex:
        raise Unauthorized('TEST', scheme='Basic', realm='Restricted Area')
    assert ex.value.status_code == 401
    assert ex.value.message == 'TEST'
    assert ex.value.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    # Test that the constructor works with 'Bearer' scheme.
    with pytest.raises(Unauthorized) as ex:
        raise Unauthorized('TEST', scheme='Bearer')
    assert ex.value.message == 'TEST'
    assert ex.value.headers == {'WWW-Authenticate': 'Bearer'}

    # Test that the constructor works with 'Digest' scheme

# Generated at 2022-06-24 03:40:33.307811
# Unit test for function abort

# Generated at 2022-06-24 03:40:39.163340
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
    else:
        assert False
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
    else:
        assert False
    
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    else:
        assert False

# Generated at 2022-06-24 03:40:44.277421
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("URLBuildError")
    except Exception as e:
        assert e.status_code == 500
        assert e.__class__.__name__ == "URLBuildError"
        assert e.message == "URLBuildError"
        assert str(e) == "URLBuildError"

if __name__ == "__main__":
    test_URLBuildError()

# Generated at 2022-06-24 03:40:46.127207
# Unit test for constructor of class SanicException
def test_SanicException():
    test = SanicException('message')
    assert test.message == 'message'


# Generated at 2022-06-24 03:40:50.645109
# Unit test for constructor of class PyFileError
def test_PyFileError():
    x = PyFileError("test.py")
    assert x is not None
    assert x.args[0] == "could not execute config file %s"
    assert x.args[1] == "test.py"

# Generated at 2022-06-24 03:40:53.862664
# Unit test for function abort
def test_abort():
    assert abort(404).status == 404
    assert abort(405).status == 405
    assert abort(400).status == 400
    assert abort(500).status == 500

# Generated at 2022-06-24 03:41:01.074440
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("message").message == "message"
    assert SanicException("message", status_code=302).status_code == 302
    assert SanicException("message", status_code=302).quiet == True
    assert SanicException("message", status_code=500).quiet == None
    assert SanicException("message", status_code=500, quiet=True).quiet == True
    assert SanicException("message", status_code=500, quiet=False).quiet == False
    assert SanicException("message", status_code=500, quiet=None).quiet == None

# Generated at 2022-06-24 03:41:02.345815
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound(message="Header Not Found")


# Generated at 2022-06-24 03:41:05.537903
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("Not Found.")
    try:
        raise NotFound("Not Found.")
    except NotFound as e:
        assert e.status_code == 404



# Generated at 2022-06-24 03:41:10.264235
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType("message", None)
    assert exc.status_code == 416
    assert (
        exc.headers["Content-Range"]
        == "bytes */{0}".format(exc.content_range.total)
    )


# Generated at 2022-06-24 03:41:12.601260
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = SanicException.ServerError("Test Exception")
    assert exception.message == "Test Exception"
    assert exception.status_code == 500

# Generated at 2022-06-24 03:41:16.055921
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    """unit test function to check if the constructor of class HeaderNotFound
    """
    try:
        raise HeaderNotFound('TestHeaderNotFound')
    except (HeaderNotFound) as e:
        assert str(e) == 'TestHeaderNotFound'



# Generated at 2022-06-24 03:41:22.987980
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("InvalidRangeType: message=Data is not a range object", content_range=1)
    except InvalidRangeType as e:
        assert (e.message == "InvalidRangeType: message=Data is not a range object")
        assert (e.status_code == 416)
        assert (e.headers.get("Content-Range") == "bytes */1")

# Generated at 2022-06-24 03:41:31.494890
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    deduce the RequestTimeout constructor is correct
    """
    request_timeout=RequestTimeout("connection timeout", 408)
    assert isinstance(request_timeout, SanicException)
    assert 408 == request_timeout.status_code # status code is correct
    assert request_timeout.quiet == True # quiet is correct
    assert "connection timeout" == str(request_timeout) # message is correct


# Generated at 2022-06-24 03:41:35.548939
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError("range too small", range(1,5))
    assert cr.status_code == 416


# Generated at 2022-06-24 03:41:37.581666
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    msg = "msg"
    path = "path"
    relative_url = "relative_url"
    f = FileNotFound(message=msg, path=path, relative_url=relative_url)
    assert f.path == path
    assert f.relative_url == relative_url

# Generated at 2022-06-24 03:41:43.386854
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        abort(413)
    except PayloadTooLarge as e:
        assert e.message == 'Request Entity Too Large'
        assert e.status_code == 413


# Tests for class InvalidUsage
from pytest import raises
from sanic.exceptions import InvalidUsage


# Generated at 2022-06-24 03:41:47.187526
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout("408 Server Error")
    assert request_timeout.status_code == 408

# Test that a status code is able to be added to an exception

# Generated at 2022-06-24 03:41:53.156484
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """
    If the server returns a response with the 413 Payload Too Large status code,
    the client can repeat the request with a smaller payload
    """
    payload_too_large = PayloadTooLarge("Payload Too Large")
    assert  payload_too_large.status_code == 413

# Generated at 2022-06-24 03:41:54.953780
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("Not found")



# Generated at 2022-06-24 03:42:05.522216
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test the constructor with a Basic auth-scheme and with a Digest
    # auth-scheme

    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": '''Basic realm="Restricted Area"'''
        }

    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")

    except Unauthorized as e:
        assert e.status_code == 401

# Generated at 2022-06-24 03:42:08.087985
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test")
    except ServiceUnavailable as error:
        assert error.status_code == 503
        assert error.message == "Test"



# Generated at 2022-06-24 03:42:13.318248
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('The signal is not defined')
    except InvalidSignal as e:
        assert (e.args[0] == 'The signal is not defined')
        assert (str(e) == 'The signal is not defined')
        assert (repr(e) == "InvalidSignal('The signal is not defined',)")


# Generated at 2022-06-24 03:42:17.655411
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Code100(SanicException):
        pass

    assert _sanic_exceptions[100] == Code100

    @add_status_code(200)
    class Code200(SanicException):
        pass

    assert _sanic_exceptions[200] == Code200
    assert _sanic_exceptions[100] == Code100

# Generated at 2022-06-24 03:42:20.922491
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URL = "URLBuildError"
    try:
        raise URLBuildError(URL)
    except URLBuildError as e:
        assert e.args[0] == URL


# Generated at 2022-06-24 03:42:24.343231
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('test')
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == 'test'

# Generated at 2022-06-24 03:42:24.960147
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    pass

# Generated at 2022-06-24 03:42:26.370389
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert isinstance(PyFileError("a"), PyFileError)

# Generated at 2022-06-24 03:42:30.485937
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    test_instance = FileNotFound("message", "path", "relative_url")
    assert test_instance.path == "path"
    assert test_instance.relative_url == "relative_url"

# Generated at 2022-06-24 03:42:33.262694
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(FileNotFound) as excinfo:
        raise FileNotFound("test_FileNotFound: Test to check if SanicException is raised")
    assert "test_FileNotFound: Test to check if SanicException is raised" in str(excinfo.value)


# Generated at 2022-06-24 03:42:42.656683
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as info:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    assert info.value.status_code == 401
    assert info.value.headers == {'WWW-Authenticate': 'Digest algorithm="MD5", nonce="abcdef", opaque="zyxwvu", qop="auth, auth-int", realm="Restricted Area"'}
    assert info.value.message == 'Auth required.'

# Generated at 2022-06-24 03:42:43.963073
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with raises(LoadFileException):
        raise LoadFileException("message")

# Generated at 2022-06-24 03:42:55.308423
# Unit test for function abort
def test_abort():
    """
    The following code was copied from
    https://github.com/channelcat/sanic/blob/master/tests/test_exceptions.py
    """
    from unittest import TestCase, main

    class TestAbort(TestCase):
        def test_default(self):
            try:
                abort(404)
            except NotFound as e:
                assert e.status_code == 404

        def test_custom_message(self):
            try:
                abort(404, message="Test")
            except NotFound as e:
                assert e.status_code == 404
                assert e.message == "Test"

        def test_custom_status_code(self):
            try:
                abort(666)
            except SanicException as e:
                assert e.status_code == 666
                assert e.message

# Generated at 2022-06-24 03:42:59.382246
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    This unit test assert that you are able to instanciate
    the exception class Unauthorized.
    """

    result = Unauthorized("Test", scheme="Basic", realm="Restricted Area")
    assert isinstance(result, Unauthorized)



# Generated at 2022-06-24 03:43:06.817443
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound):
        abort(404, "Nothing here")

    with pytest.raises(NotFound) as e:
        abort(404)
    exc = e.value
    assert exc.message == "Not Found"
    assert exc.status_code == 404

    with pytest.raises(RequestTimeout) as e:
        abort(408)
    exc = e.value
    assert exc.message == "Request Timeout"
    assert exc.status_code == 408

    with pytest.raises(ServerError) as e:
        abort(500)
    exc = e.value
    assert exc.message == "Internal Server Error"
    assert exc.status_code == 500

    with pytest.raises(SanicException) as e:
        abort(999)
    exc = e.value

# Generated at 2022-06-24 03:43:16.749682
# Unit test for constructor of class SanicException
def test_SanicException():
    c = SanicException('hi')
    assert c.status_code == None
    assert c.quiet == False
    c = SanicException('hi', 400)
    assert c.status_code == 400
    assert c.quiet == True
    c = SanicException('hi', 400, True)
    assert c.status_code == 400
    assert c.quiet == True
    c = SanicException('hi', 400, False)
    assert c.status_code == 400
    assert c.quiet == False
    c = SanicException('hi', 400, None)
    assert c.status_code == 400
    assert c.quiet == True

# Make sure the decorated classes have the right status codes and quiet

# Generated at 2022-06-24 03:43:21.318862
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as excinfo:
        raise SanicException('SanicException', 500)
    assert excinfo.value.status_code == 500
    assert excinfo.value.message == 'SanicException'
    assert excinfo.value.headers is None
    assert excinfo.value.quiet is False


# Generated at 2022-06-24 03:43:26.868551
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('message', 'header')
    except HeaderNotFound as err:
        assert err.status_code == 400
        assert err.message == 'message'
        assert err.header == 'header'
        assert isinstance(err, SanicException)


# Generated at 2022-06-24 03:43:31.657550
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound
    except NotFound as error:
        assert error.status_code == 404
        assert type(error) == NotFound
        assert error.status_code == error.__class__.status_code


# Generated at 2022-06-24 03:43:34.095104
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('signal', 'test')
    except Exception as err:
        assert 'signal' in str(err)

# Generated at 2022-06-24 03:43:36.317476
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed, match="foo"):
        raise HeaderExpectationFailed("foo")


# Generated at 2022-06-24 03:43:42.661842
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = 'test_message'
    method = 'test_method'
    allowed_methods = ['test_allowed_methods']

    method_not_supported = MethodNotSupported(message, method, allowed_methods)
    assert method_not_supported.headers == {'Allow': 'test_allowed_methods'}

# Generated at 2022-06-24 03:43:44.679558
# Unit test for constructor of class Forbidden
def test_Forbidden():
    a = Forbidden("Auth required.")
    assert a.status_code == 403
    assert a.message == "Auth required."

# Generated at 2022-06-24 03:43:49.865454
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed) as e_info:
        raise HeaderExpectationFailed("Server cannot meet the requirements"
                                      " of the Expect request-header field."
                                      "\nServer cannot meet the requirements"
                                      " of the Expect request-header field.")
    assert e_info.value.status_code == 417
    assert e_info.value.message == "Server cannot meet the requirements" \
                                   " of the Expect request-header field." \
                                   "\nServer cannot meet the requirements" \
                                   " of the Expect request-header field."

# Generated at 2022-06-24 03:43:54.253695
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="message", status_code="status_code")
    except LoadFileException as exc:
        assert exc.status_code == "status_code"
        assert exc.message == "message"

# Generated at 2022-06-24 03:43:59.445536
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = "Method"
    allowed_methods = ["GET"]
    mess = "This is a test message"
    ms = MethodNotSupported(mess, method, allowed_methods)
    assert ms.status_code == 405
    assert ms.message == mess
    assert ms.method == method
    assert ms.allowed_methods == allowed_methods
    assert ms.headers["Allow"] == "GET"

# Generated at 2022-06-24 03:44:02.939844
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge('Payload is too large.', 10)
    assert error.status_code == 413
    assert error.quiet
    assert error.message == 'Payload is too large.'
    assert str(error) == 'Payload is too large.'

# Generated at 2022-06-24 03:44:03.948678
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError("hello, world")

# Generated at 2022-06-24 03:44:08.375155
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('This is a test exception')
    except LoadFileException as e:
        exc_info = sys.exc_info()
        assert exc_info[0] is LoadFileException
        assert e.__class__.__name__ == 'LoadFileException'

# Generated at 2022-06-24 03:44:11.014651
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    import pytest
    ex = URLBuildError("test_URLBuildError")
    assert ex.__repr__() == "test_URLBuildError"



# Generated at 2022-06-24 03:44:15.392327
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Fuck you,I am Jiaqi Ren")
        assert False
    except Forbidden as e:
        assert str(e) == "Fuck you,I am Jiaqi Ren"
        assert e.status_code == 403


# Generated at 2022-06-24 03:44:18.053057
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge("Payload Too Large")

# Generated at 2022-06-24 03:44:25.452135
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException):
        abort(999)
    with pytest.raises(NotFound):
        abort(404)
    try:
        abort(403, message="Forbidden")
    except Forbidden as e:
        assert e.status_code == 403
        assert e.message == "Forbidden"
    try:
        abort(409, message="Conflict")
    except SanicException as e:
        assert e.status_code == 409
        assert e.message == "Conflict"

# Generated at 2022-06-24 03:44:28.107033
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # test if status_code is set to 408
    try:
        raise RequestTimeout("RequestTimeout")
    except RequestTimeout as err:
        assert err.status_code == 408

# Generated at 2022-06-24 03:44:33.567344
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    response = MethodNotSupported(message='The method is not supported',
                                  method='GET', allowed_methods=['POST'])
    with pytest.raises(MethodNotSupported):
        raise response

# Generated at 2022-06-24 03:44:38.345333
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("Custom Header Not Found")

    assert err.status_code == 400
    assert err.message == "Custom Header Not Found"

# Generated at 2022-06-24 03:44:42.429380
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "test_HeaderNotFound"
    assert HeaderNotFound(message).args[0] == message

# Generated at 2022-06-24 03:44:45.654404
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    x = 1
    y = 0
    message = "Invalid Range Type"
    assert InvalidRangeType(message, x).message == message
    assert InvalidRangeType(message, x).content_range == x


# Generated at 2022-06-24 03:44:47.419380
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    e = PayloadTooLarge("hello world", 123)
    assert e.message == "hello world"
    assert e.status_code == 123

# Generated at 2022-06-24 03:44:51.899901
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as excinfo:
        print(excinfo)
        raise SanicException("SanicException error occured")
    assert excinfo.value.args[0] == "SanicException error occured"


# Generated at 2022-06-24 03:44:54.554706
# Unit test for constructor of class SanicException
def test_SanicException():
    exc = SanicException('invalid password!')
    assert exc.message == 'invalid password!'


# Generated at 2022-06-24 03:44:55.993598
# Unit test for constructor of class NotFound
def test_NotFound():
    assert isinstance(NotFound('test'), SanicException)


# Generated at 2022-06-24 03:45:01.596468
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError('Error 1')
    assert error.status_code == 500
    assert error.message == 'Error 1'
    assert error.quiet == None
    assert error.status_code == 500
    assert error.message == 'Error 1'
    assert error.quiet == None
    assert error.__str__() == 'Error 1'
    assert error.__repr__() == 'Error 1'

# Generated at 2022-06-24 03:45:05.491349
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    e = HeaderExpectationFailed("some error test")
    assert e.status_code == 417
    assert e.message == "some error test"

# Generated at 2022-06-24 03:45:11.836826
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header = HeaderNotFound('Authorization header is required',1)
    assert header.message == 'Authorization header is required', header.message
    assert header.status_code == 1, header.status_code


# test cases for add_status_code() function

# Generated at 2022-06-24 03:45:15.253524
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('LoadFileException')
    except LoadFileException as error:
        assert error.message == 'LoadFileException'
    except Exception as error:
        assert isinstance(error, LoadFileException)


# Generated at 2022-06-24 03:45:18.830354
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('test', status_code=500)
    except InvalidUsage as e:
        assert e.status_code == 400


# Generated at 2022-06-24 03:45:21.733531
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    assert HeaderNotFound("HeaderNotFound")
    try:
        raise HeaderNotFound("HeaderNotFound")
    except HeaderNotFound:
        assert True
    else:
        assert False
        

# Generated at 2022-06-24 03:45:29.595745
# Unit test for function abort
def test_abort():
    assert isinstance(abort(500), ServerError)
    assert repr(abort(500)) == "500: Internal Server Error"
    assert isinstance(abort(404), NotFound)
    assert repr(abort(404)) == "404: Not Found"
    assert not hasattr(abort(404), "quiet")
    assert isinstance(abort(403), Forbidden)
    assert repr(abort(403)) == "403: Forbidden"
    assert hasattr(abort(503), "quiet")
    assert isinstance(abort(503), ServiceUnavailable)
    assert repr(abort(503)) == "503: Service Unavailable"



# Generated at 2022-06-24 03:45:33.228959
# Unit test for constructor of class ServerError
def test_ServerError():
    message = 'test message'
    status_code = 522
    e = ServerError(message, status_code)
    assert e.status_code == status_code
    assert e.message == message

# Generated at 2022-06-24 03:45:35.660242
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as exc_info:
        message = "Test message to send via ServiceUnavailable exception"
        raise ServiceUnavailable(message)
    assert exc_info.value.message == message


# Generated at 2022-06-24 03:45:38.770639
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
   try:
       raise LoadFileException("This is an exception")
   except LoadFileException as e:
       print(e)

# test for constructor of class InvalidSignal

# Generated at 2022-06-24 03:45:43.330501
# Unit test for function abort
def test_abort():
    try:
        assert True
        abort(400, 'Test')
    except InvalidUsage:
        pass
    finally:
        assert False

    try:
        assert True
        abort(404, 'Test')
    except InvalidUsage:
        assert False
    except NotFound:
        pass
    finally:
        assert True



# Generated at 2022-06-24 03:45:48.430202
# Unit test for function abort
def test_abort():
  try:
    abort(status_code=403, message='Forbidden')
  except Forbidden as e:
    assert e.status_code == 403
    assert e.message == 'Forbidden'
  else:
    assert False


if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-24 03:45:52.651853
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    intr = InvalidRangeType("Some message",
        content_range = bytesio(''))
    assert isinstance(intr, ContentRangeError)
    assert isinstance(intr, InvalidRangeType)
    assert isinstance(intr, Exception)
    assert isinstance(intr, object)

# Generated at 2022-06-24 03:46:01.102565
# Unit test for function add_status_code
def test_add_status_code():
    # 400
    try:
        raise abort(400)
    except SanicException as e:
        assert e.status_code == 400
    except Exception as e:
        assert False, "Expected SanicException, got {}".format(repr(e))
    # 404
    try:
        raise abort(404)
    except SanicException as e:
        assert e.status_code == 404
    except Exception as e:
        assert False, "Expected SanicException, got {}".format(repr(e))
    # 500
    try:
        raise abort(500)
    except SanicException as e:
        assert e.status_code == 500
    except Exception as e:
        assert False, "Expected SanicException, got {}".format(repr(e))

test_add_status_code()

# Generated at 2022-06-24 03:46:03.633077
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("Header Expectation Failed")
    assert exc.status_code == 417
    assert exc.message == "Header Expectation Failed"


# Generated at 2022-06-24 03:46:09.413436
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Message", 1)
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.status_code == 416
        assert isinstance(e.headers, dict)
        assert "Content-Range" in e.headers.keys()
        assert "bytes */1" in e.headers.values()

# Generated at 2022-06-24 03:46:11.654300
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden('Request Forbidden')



# Generated at 2022-06-24 03:46:14.469569
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message='Empty range passed')
    except HeaderExpectationFailed:
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:46:17.452093
# Unit test for function abort
def test_abort():
    status_code = 404
    message = "test_abort"
    try:
        abort(status_code, message)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:46:19.023918
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable('503 Service Unavailable') is not None


# Generated at 2022-06-24 03:46:25.477769
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('This page could not be loaded properly')
    except HeaderExpectationFailed as e:
        if e.status_code == 417 and e.message == 'This page could not be loaded properly':
            print('HeaderExpectationFailed class is constructed properly')
        else:
            print('HeaderExpectationFailed class is not constructed properly')


# Generated at 2022-06-24 03:46:27.932978
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exp_filed = HeaderExpectationFailed("HeaderExpectationFailed")
    assert exp_filed.__class__.__name__ == 'HeaderExpectationFailed'

# Generated at 2022-06-24 03:46:31.495562
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(InvalidRangeType) as e:
        raise InvalidRangeType(message="test")
    assert e.value.message == "test"


# Generated at 2022-06-24 03:46:40.826677
# Unit test for constructor of class SanicException
def test_SanicException():
    # raising a 500 error
    with pytest.raises(ServerError):
        raise SanicException("Internal Error", status_code=500)
    # check if message is stored correctly:
    with pytest.raises(ServerError) as error:
        raise SanicException("Internal Error", status_code=500)
    assert str(error.value) == "Internal Error"
    # check if status code is stored correctly:
    with pytest.raises(ServerError) as error:
        raise SanicException("Internal Error", status_code=500)
    assert error.value.status_code == 500
    # check if quiet is stored correctly:
    with pytest.raises(ServerError) as error:
        raise SanicException("Internal Error", status_code=500, quiet=True)
    assert error.value.quiet == True



# Generated at 2022-06-24 03:46:41.877038
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert InvalidRangeType(message="Invalid Range Type", content_range=None)

# Generated at 2022-06-24 03:46:43.881765
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError("file1")
    expected_output = "could not execute config file file1"
    assert expected_output in str(pyfileerror)

# Generated at 2022-06-24 03:46:48.171476
# Unit test for function abort
def test_abort():
    try:
        abort(400, 'miss http method')
    except Exception as e:
        assert type(e) == InvalidUsage

# Generated at 2022-06-24 03:46:53.176153
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
	msg = "foo bar"
	request_timeout = RequestTimeout(message=msg)
	assert(request_timeout.__str__() == msg)

# Generated at 2022-06-24 03:46:56.451166
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden(message="Error")
    except Forbidden:
        assert True
    except:
        assert False



# Generated at 2022-06-24 03:46:58.892083
# Unit test for constructor of class SanicException
def test_SanicException():
    args = "what"
    instance = SanicException(args)

    assert(instance.args == args)

# Generated at 2022-06-24 03:47:01.740612
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('响应状态为503')
    except Exception as e:
        print(e.status_code)


# Generated at 2022-06-24 03:47:03.001337
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "abcdefg"
    assert file in PyFileError(file).args[0]

# Generated at 2022-06-24 03:47:06.780458
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('testing')
    except InvalidUsage as exc:
        assert exc.status_code == 400
        assert str(exc) == 'testing'

# Generated at 2022-06-24 03:47:09.461420
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Cannot load file")
    except LoadFileException as err:
        assert err.message == "Cannot load file"
        assert err.status_code is None
        assert err.quiet is False


# Generated at 2022-06-24 03:47:12.831818
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except SanicException as e:
        assert e.status_code == 404



# Generated at 2022-06-24 03:47:14.866948
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pl = PayloadTooLarge("test", 4)
    assert pl.headers["Content-Length"] == 4

# Generated at 2022-06-24 03:47:15.958465
# Unit test for constructor of class ServerError
def test_ServerError():
    e = ServerError("Test")


# Generated at 2022-06-24 03:47:19.602051
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "data.json"
    error_message = "could not execute config file %s" % file
    with pytest.raises(PyFileError) as excinfo:
        raise PyFileError(file)
    assert str(excinfo.value) == error_message

# Generated at 2022-06-24 03:47:22.301850
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test.py")
    except PyFileError as e:
        assert str(e) == "could not execute config file %s"