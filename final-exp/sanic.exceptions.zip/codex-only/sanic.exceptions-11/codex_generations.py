

# Generated at 2022-06-24 03:37:23.220695
# Unit test for constructor of class PyFileError
def test_PyFileError():
    message = "could not execute config file 123"
    err = PyFileError("123")
    assert err.args == (message,)

# Generated at 2022-06-24 03:37:28.892636
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(10)
    class Foo(SanicException):
        pass

    class Bar(SanicException):
        pass

    class Baz(SanicException):
        pass

    assert add_status_code(11)(Bar).status_code == 11
    assert add_status_code(0)(Baz).status_code == 0

    assert not Bar().quiet
    assert Baz(quiet=False).quiet is False
    assert Baz(quiet=True).quiet is True

# Generated at 2022-06-24 03:37:31.091181
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    ex =  HeaderExpectationFailed(message='header expectation failed')
    assert type(ex) is HeaderExpectationFailed

# Generated at 2022-06-24 03:37:37.986033
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise abort(408)


# Generated at 2022-06-24 03:37:43.249200
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    """
    Test SanicException
    """
    try:
        raise InvalidUsage('error', status_code=400, quiet=False)
    except InvalidUsage as e:
        assert isinstance(e, InvalidUsage)



# Generated at 2022-06-24 03:37:48.812295
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound(message="File not found.")
    assert not_found.message == "File not found."
    assert not_found.status_code == 404
    assert not_found.quiet is True

# Generated at 2022-06-24 03:37:51.795706
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 101
    assert TestException.quiet is False
    assert _sanic_exceptions[101] == TestException


# Generated at 2022-06-24 03:37:55.955865
# Unit test for function abort
def test_abort():
    from sanic.helpers import STATUS_CODES
    from sanic.exceptions import abort
    from sanic.exceptions import _sanic_exceptions

    for status_code in STATUS_CODES:
        try:
            abort(status_code)
        except _sanic_exceptions[status_code]:
            pass


# DeprecationWarnings have to be non-ignorable

# Generated at 2022-06-24 03:38:03.448794
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass
    
    assert TestException.status_code == 999
    assert TestException.quiet is True
    assert _sanic_exceptions[999] is TestException

    @add_status_code(987, quiet=False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 987
    assert TestException2.quiet is False
    assert _sanic_exceptions[987] is TestException2

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:38:07.889669
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("There is an error while load file")
    except LoadFileException as e:
        assert e.message == "There is an error while load file"
        assert e.status_code == None
        assert e.quiet == None


# Generated at 2022-06-24 03:38:11.223361
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    message = '1st ServiceUnavailable'
    a = ServiceUnavailable(message)
    assert a.message == message
    assert a.status_code == 503
    assert a.quiet is True


# Generated at 2022-06-24 03:38:15.022486
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Hello world", status_code=503)
    except ServiceUnavailable as ex:
        assert ex.message == "Hello world"
        assert ex.status_code == 503
        assert ex.quiet == True

# Generated at 2022-06-24 03:38:20.065548
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    test_exception=InvalidUsage('test message',
                                status_code=400,
                                quiet=None)
    assert(test_exception.args[0] == 'test message') and \
           (test_exception.status_code == 400) and \
           (test_exception.quiet == True)



# Generated at 2022-06-24 03:38:21.578398
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    result = LoadFileException("test")
    assert result.msg == "test"

# Generated at 2022-06-24 03:38:26.121757
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pyload_too_large = PayloadTooLarge(message="sanic_exceptions", status_code=413)
    assert pyload_too_large.message == "sanic_exceptions"
    assert pyload_too_large.status_code == 413

# Generated at 2022-06-24 03:38:28.819684
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    err = InvalidRangeType("Testing message", 10)
    assert err.message == "Testing message"
    assert err.headers == {'Content-Range': 'bytes */10'}

# Generated at 2022-06-24 03:38:31.468934
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exc = PayloadTooLarge('Payload Too Large')
    assert isinstance(exc, SanicException)


# Generated at 2022-06-24 03:38:34.022142
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    a = FileNotFound("asdasfd", "/", "/")
    assert a.status_code == 404


# Generated at 2022-06-24 03:38:36.694683
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "test method not supported"
    method = "GET"
    allowed_methods = ["POST", "PUT"]
    exception = MethodNotSupported(message,
                                   method,
                                   allowed_methods)
    assert exception.message == message
    assert exception.method == method
    assert exception.allowed_methods == allowed_methods

if __name__ == "__main__":
    test_MethodNotSupported()

# Generated at 2022-06-24 03:38:39.361680
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method_not_supported = MethodNotSupported("error message", "Method", "allowed methods")
    assert method_not_supported.headers == {"Allow": ", ".join("allowed methods")}

# Generated at 2022-06-24 03:38:42.027707
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('message')
    except HeaderExpectationFailed as e:
        assert e.status_code == 417


# Generated at 2022-06-24 03:38:42.655130
# Unit test for constructor of class HeaderNotFound

# Generated at 2022-06-24 03:38:47.319013
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    from sanic import Sanic
    from sanic.exceptions import LoadFileException
    app = Sanic()
    try:
        raise LoadFileException(app, 'app.app')
    except LoadFileException as LFE:
        assert LFE.args[0] == app
        assert LFE.args[1] == 'app.app'

# Generated at 2022-06-24 03:38:50.085272
# Unit test for function add_status_code
def test_add_status_code():
    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-24 03:38:52.535143
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
     msg = 'Unit testing purposes'
     content_range = ''
     err = ContentRangeError(message=msg, content_range=content_range)
     assert "Content-Range" in err.headers

# Generated at 2022-06-24 03:38:55.241411
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Internal Server Error")
    except ServerError as e:
        assert True is True
    else:
        assert True is False


# Generated at 2022-06-24 03:39:01.535057
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    msg = "DUMMY ERROR MESSAGE"
    path = "DUMMY PATH"
    relative_url = "DUMMY URL"
    e = FileNotFound(msg, path, relative_url)
    assert e.path == path
    assert e.relative_url == relative_url
    assert e.args[0] == msg
    assert str(e) == msg



# Generated at 2022-06-24 03:39:06.352876
# Unit test for constructor of class SanicException
def test_SanicException():
    init = SanicException("message", status_code=500, quiet=True)

    assert init.status_code == 500
    assert init.message == "message"
    assert init.quiet is True
    assert init.status_code == 500



# Generated at 2022-06-24 03:39:07.688884
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("The message is wrong!")
    except Exception as err:
        assert isinstance(err, ServerError)

# Generated at 2022-06-24 03:39:10.208598
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout
    except RequestTimeout as e:
        assert e.status_code == 408
     

# Generated at 2022-06-24 03:39:12.572571
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("could not build url")
    assert str(error) == "could not build url"


# Generated at 2022-06-24 03:39:16.282123
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("file not found","var/lib/","/usr/lib")
    except FileNotFound as fnf:
        assert fnf.path=='var/lib/'
        assert fnf.relative_url=='/usr/lib'

# Generated at 2022-06-24 03:39:18.490242
# Unit test for function abort
def test_abort():
    assert abort(404) is None
    assert abort(400) is None
    assert abort(500) is None
    assert abort(503) is None

# Generated at 2022-06-24 03:39:20.329603
# Unit test for constructor of class SanicException
def test_SanicException():
    try: SanicException(message='error')
    except: assert False
    else: assert True


# Generated at 2022-06-24 03:39:24.369258
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('server_busy_error', 408)
    except RequestTimeout as e:
        assert e.message == 'server_busy_error'
        assert e.status_code == 408


# Generated at 2022-06-24 03:39:26.898103
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Not Found Error")
    except NotFound as e:
        assert isinstance(e, NotFound)


# Generated at 2022-06-24 03:39:30.356428
# Unit test for constructor of class Forbidden
def test_Forbidden():
    a = Forbidden("Auth required.", scheme="Bearer", realm="Restricted Area")
    assert a.message == "Auth required."
    assert a.headers == {'WWW-Authenticate': 'Bearer realm="Restricted Area"'}

# Generated at 2022-06-24 03:39:34.959231
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('test', 0)
    except ContentRangeError as error:
        assert error.headers == {'Content-Range': 'bytes */0'}

# Generated at 2022-06-24 03:39:37.713368
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Failed')
    except SanicException as e:
        assert str(e) == 'Failed' 
        assert e.status_code is None


# Generated at 2022-06-24 03:39:46.406382
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "test"
    status_code = 404
    try:
        raise SanicException(message, status_code)
    except SanicException as e:
        assert e.status_code == status_code
        assert e.message == message
        assert e.quiet
        assert e.status_code in _sanic_exceptions
    try:
        raise SanicException(message)
    except SanicException as e:
        assert e.status_code == None
        assert e.message == message
        assert e.quiet == None
        assert e.status_code not in _sanic_exceptions

if __name__=='__main__':
    test_SanicException()

# Generated at 2022-06-24 03:39:51.726675
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException("hello", status_code=400)
    assert exception.message == "hello"
    assert exception.status_code == 400
    assert exception.__class__.__name__ == "SanicException"


# Generated at 2022-06-24 03:39:53.073556
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    SanicException('test', status_code=503)


# Generated at 2022-06-24 03:39:54.720046
# Unit test for function add_status_code
def test_add_status_code():
    error_class = add_status_code(401)(SanicException)
    assert error_class.status_code == 401

# Generated at 2022-06-24 03:39:56.267707
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    test_object = URLBuildError("test")
    assert type(test_object) == URLBuildError

# Generated at 2022-06-24 03:39:58.284117
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = InvalidSignal('SIGINT', 500)
    assert signal.message == 'SIGINT'
    assert signal.status_code == 500

# Generated at 2022-06-24 03:40:00.313311
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exc = HeaderNotFound("Header not found")
    assert exc.message == "Header not found"
    assert exc.status_code == 400

# Generated at 2022-06-24 03:40:02.618308
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Could not load file")
    except LoadFileException as err:
        assert str(err).startswith("Could not load file")


# Generated at 2022-06-24 03:40:05.354876
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable("example message")
    assert exception.message == "example message"
    assert exception.status_code == 503
    assert exception.quiet == True

# Generated at 2022-06-24 03:40:07.476637
# Unit test for constructor of class SanicException
def test_SanicException():
    assert isinstance(SanicException(message="message", status_code=500, quiet=True), SanicException)


# Generated at 2022-06-24 03:40:13.608723
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    from sanic.request import RequestRanges

    # _request._request_range is None
    request = RequestRanges(None)
    from pytest import raises
    with raises(TypeError):
        raise InvalidRangeType("message", request)

# Generated at 2022-06-24 03:40:15.701548
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Expectation failed")
    except HeaderExpectationFailed as e:
        assert (e.message == "Expectation failed")


# Generated at 2022-06-24 03:40:20.965820
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("test NotFound message", status_code=404, quiet=False)



# Generated at 2022-06-24 03:40:25.224330
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("한글")
    except ServerError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, SanicException)
        assert e.__str__() == "한글"
        assert e.status_code == 500

# Generated at 2022-06-24 03:40:28.398634
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported(message="method not allowed", method="GET", allowed_methods=["POST", "PUT"])
    assert exception.message == "method not allowed"
    assert exception.method == "GET"
    assert exception.allowed_methods == ["POST", "PUT"]
    assert exception.headers == {"Allow": "POST, PUT"}



# Generated at 2022-06-24 03:40:33.061682
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError("sorry, I can't find your file")
    assert pyfileerror.args == ("could not execute config file %s", "sorry, I can't find your file")



# Generated at 2022-06-24 03:40:34.958339
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload = PayloadTooLarge("message", "max_length")
    assert payload.quiet == False
    assert payload.message == "message"
    assert payload.max_length == "max_length"

# Generated at 2022-06-24 03:40:38.003766
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    testURLBuildError = URLBuildError("Test URLBuildError", status_code=500)
    if testURLBuildError.args[0] != "Test URLBuildError":
        raise Exception("Unexpected status_code")


# Generated at 2022-06-24 03:40:41.045878
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    add_status_code(404)(TestClass)

    assert TestClass.status_code == 404
    assert TestClass.quiet is True


# Generated at 2022-06-24 03:40:45.040889
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ["GET"]
    method = "POST"
    message = "Method Not Allowed"
    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.message == message
    assert exception.headers == {'Allow': 'GET'}

# Generated at 2022-06-24 03:40:49.902532
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("test", "/data", "/data/img")
    except FileNotFound as error:
        assert error.path == "/data"
        assert error.relative_url == "/data/img"
        assert "test" in error.args
        assert error.status_code == 404
    except InvalidUsage as error:
        assert error.status_code == 400

# Generated at 2022-06-24 03:40:52.670986
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Testing")
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Testing"


# Generated at 2022-06-24 03:40:54.807478
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException("Normal SanicException", status_code=400)
    assert e.status_code == 400
    assert e.quiet == True


# Generated at 2022-06-24 03:41:04.479256
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    """
    Description: Test the constructor of the HeaderExpectationFailed class
    """

    try:
        exception = HeaderExpectationFailed("Error", 417)
    except BaseException:
        assert 0, "Test failed. Exception not expected."

    assert exception.message == "Error"
    assert exception.status_code == 417
    assert exception.quiet is True

    try:
        exception = HeaderExpectationFailed("Error", 417, quiet=True)
    except BaseException:
        assert 0, "Test failed. Exception not expected."

    assert exception.message == "Error"
    assert exception.status_code == 417
    assert exception.quiet is True

    try:
        exception = HeaderExpectationFailed("Error", 417, quiet=False)
    except BaseException:
        assert 0, "Test failed. Exception not expected."

# Generated at 2022-06-24 03:41:08.157373
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("Could not find header")
    assert err.message == "Could not find header"
    assert err.status_code == 400

# Generated at 2022-06-24 03:41:10.961445
# Unit test for constructor of class PyFileError
def test_PyFileError():
    err = PyFileError('file1')
    assert err.__class__ == PyFileError
    assert err.args == ('could not execute config file %s', 'file1')

# Generated at 2022-06-24 03:41:13.989531
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Bad HTTP request")
    except Exception as exc:
        assert exc.args[0] == "Bad HTTP request"
        assert exc.status_code == 500
        assert exc.quiet == False

# Generated at 2022-06-24 03:41:17.931171
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("file not found", "test_url", "/test")

# Generated at 2022-06-24 03:41:20.215366
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = 'msg'
    total = 10
    range = '20'
    with pytest.raises(ContentRangeError):
        raise ContentRangeError(msg, total)

# Generated at 2022-06-24 03:41:24.753046
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("server error")
    except ServerError as se:
        assert(str(se) == "server error")
        assert(se.status_code == 500)
        assert(se.quiet != True)


# Generated at 2022-06-24 03:41:26.099313
# Unit test for constructor of class Forbidden
def test_Forbidden():
	assert Forbidden('hi',403).status_code == 403


# Generated at 2022-06-24 03:41:30.008508
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound
    except HeaderNotFound as HNF:
        assert HNF.message == 'header not found'
    try:
        raise HeaderNotFound('header_not_found')
    except HeaderNotFound as HNF:
        assert HNF.message == 'header_not_found'

# Generated at 2022-06-24 03:41:41.546068
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except Exception as e:
        assert type(e) == NotFound
        assert e.status_code == 404
        assert e.message == 'Not Found'
    else:
        assert False

    try:
        abort(400, "My Error Message")
    except Exception as e:
        assert type(e) == InvalidUsage
        assert e.status_code == 400
        assert e.message == 'My Error Message'
    else:
        assert False

    try:
        abort(500)
    except Exception as e:
        assert type(e) == ServerError
        assert e.status_code == 500
        assert e.message == 'Internal Server Error'
    else:
        assert False


# Generated at 2022-06-24 03:41:49.205390
# Unit test for function add_status_code
def test_add_status_code():
    # Code 500 is a quiet code
    assert ServerError.quiet == True
    assert 500 in _sanic_exceptions
    # New code is quiet if no quiet is specified
    assert InvalidUsage.quiet == True
    assert 400 in _sanic_exceptions
    # Code 500 is quiet if quiet is specified with any value
    assert ServiceUnavailable.quiet == True
    assert 503 in _sanic_exceptions
    # New code is quiet if quiet is specified as True
    @add_status_code(405, quiet=True)
    class NewException(SanicException):
        pass

    assert NewException.quiet == True
    assert 405 in _sanic_exceptions
    # New code is not quiet if quiet is specified as False
    @add_status_code(408, quiet=False)
    class NewException(SanicException):
        pass



# Generated at 2022-06-24 03:41:50.715333
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message")
    except FileNotFound:
        pass



# Generated at 2022-06-24 03:41:52.956758
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError('test')
    assert str(error) == "could not execute config file test"


# Generated at 2022-06-24 03:41:58.027362
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("RequestTimeout occured")
    except RequestTimeout as e:
        assert(e.status_code == 408)
        assert(e.args == ("RequestTimeout occured",))


# Generated at 2022-06-24 03:42:00.136267
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test = PyFileError("address is needed")
    assert test.args[0] == "address is needed"

# Generated at 2022-06-24 03:42:07.821792
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message, status_code, scheme, kwargs = \
        "Unauthorized request", 401, "Basic", {"realm": "Restricted Area"}

    # Create the exception
    exception: SanicException = Unauthorized(
        message, status_code, scheme, **kwargs)

    # Check if the exception has the right headers
    assert exception.headers \
        == {"WWW-Authenticate": f"{scheme} realm=\"{kwargs['realm']}\""}


# Generated at 2022-06-24 03:42:11.508859
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Method not supported.", "Get", ["POST"])
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.headers["Allow"] == "POST"
    else:
        assert False

# Generated at 2022-06-24 03:42:12.598196
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h = HeaderExpectationFailed(message='Wowowo')
    assert h.message == 'Wowowo'

# Generated at 2022-06-24 03:42:14.899340
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden(message="Forbidden", status_code=403)
    assert forbidden.status_code == 403
    assert forbidden.message == "Forbidden"
    assert forbidden.quiet is True


# Generated at 2022-06-24 03:42:18.033598
# Unit test for constructor of class ServerError
def test_ServerError():
    expected = ServerError(message = "Internal Server Error", status_code = 500)
    assert expected.args[0] == "Internal Server Error"


# Generated at 2022-06-24 03:42:20.117883
# Unit test for function abort
def test_abort():
    status_code = 500
    try:
        abort(status_code)
    except SanicException as ex:
        assert ex.status_code == status_code

# Generated at 2022-06-24 03:42:22.559434
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
	try:
		raise InvalidSignal('hello')
	except InvalidSignal:
		pass

# Generated at 2022-06-24 03:42:28.390097
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    print("testing InvalidSignal")
    try:
        raise InvalidSignal("testing", status_code=500)
    except InvalidSignal as e:
        assert e.status_code == 500 and e.args[0] == "testing"
    try:
        raise InvalidSignal("testing2")
    except InvalidSignal as e:
        assert e.status_code is None and e.args[0] == "testing2"


# Generated at 2022-06-24 03:42:32.401114
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("The signal SIGKILL is invalid")
    except Exception as exceptionObj:
        assert exceptionObj.args[0] == "The signal SIGKILL is invalid"


# Generated at 2022-06-24 03:42:35.016359
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    test = InvalidUsage("hello")
    assert test.status_code == 400
    assert test.message == "hello"


# Generated at 2022-06-24 03:42:39.597741
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():

    message = 'Error Message'
    status_code = 400
    with pytest.raises(InvalidUsage) as excinfo:
        raise InvalidUsage(message, status_code)
    assert excinfo.value.status_code == status_code
    assert excinfo.value.__str__() == message


# Generated at 2022-06-24 03:42:46.847309
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found1 = NotFound(message='not_found', status_code=404)
    not_found2 = NotFound(message='not_found', status_code=404, quiet=True)
    not_found2_expect = {
        'status_code': 404,
        'message': 'not_found',
        'quiet': True
    }
    assert(not_found1.status_code == 404)
    assert(not_found1.message == 'not_found')
    assert(not_found2.__dict__ == not_found2_expect)


# Generated at 2022-06-24 03:42:49.927685
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    import pytest
    from sanic import SanicException
    with pytest.raises(SanicException):
        raise InvalidRangeType('Testing error output from InvalidRangeType class', 200)

# Generated at 2022-06-24 03:42:51.236294
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("message")
    except InvalidSignal as error:
        assert error.status_code == 500
        assert error.message == "message"



# Generated at 2022-06-24 03:42:53.558244
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    e = LoadFileException('Test for LoadFileException.')
    # return a string representing the object
    assert str(e) == 'Test for LoadFileException.'

# Generated at 2022-06-24 03:42:56.047526
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    err=InvalidSignal('abc_def')

# Generated at 2022-06-24 03:42:58.072723
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    error = HeaderNotFound('Something failed.')
    assert error.status_code == 400 and error.message == 'Something failed.'

# Generated at 2022-06-24 03:43:00.464757
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    msg = "something wrong"
    try:
        raise InvalidSignal(msg)
    except Exception as e:
        assert e.message == msg

# Generated at 2022-06-24 03:43:03.342469
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('This is a test')
    except HeaderNotFound as error:
        assert error.status_code == 400
        assert error.message == 'This is a test'



# Generated at 2022-06-24 03:43:07.101374
# Unit test for constructor of class ServerError
def test_ServerError():
    def test_exception_msg():
        try:
            raise ServerError("testing exception")
        except Exception as err:
            assert str(err) == "testing exception"

    test_exception_msg()


# Generated at 2022-06-24 03:43:10.343125
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    err = MethodNotSupported('message', 'method', 'allowed_methods')
    assert(err.headers == {'Allow': 'allowed_methods'})

# Generated at 2022-06-24 03:43:13.721870
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test")
    except InvalidSignal:
        assert True

# Generated at 2022-06-24 03:43:16.119717
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Forbidden as e:
        assert e.status_code == 403
        assert str(e) == 'Status: 403 Forbidden'

# Generated at 2022-06-24 03:43:17.718047
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('The Forbidden exception')
    except Forbidden as e:
        assert e.status_code == 403

# Generated at 2022-06-24 03:43:20.162019
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    expected_output = "message"
    try:
        raise InvalidUsage("message")
    except InvalidUsage as exception:
        assert exception.message == expected_output
    # Unit test for constructor of class SanicException
    expected_output = "message"
    try:
        raise SanicException("message")
    except SanicException as exception:
        assert exception.message == expected_output

# Generated at 2022-06-24 03:43:21.774779
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("error message")
    assert isinstance(error, Exception)



# Generated at 2022-06-24 03:43:27.179919
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("test raise", "test_method", ["test_method"])
    except MethodNotSupported as exp:
        assert exp.status_code == 405
    assert exp.headers['Allow'] == 'test_method'
    assert exp.message == 'test raise'

# Generated at 2022-06-24 03:43:31.994912
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as e_info:
        raise ServiceUnavailable(message="bad request")
    assert e_info.value.status_code == 503
    assert e_info.value.message == "bad request"

# Generated at 2022-06-24 03:43:34.483070
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('error')
    except Forbidden as e:
        assert (e.status_code == 403)

# Generated at 2022-06-24 03:43:37.907020
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    err = FileNotFound("message", "path", "relative_url")

    assert err.message is "message"
    assert err.path is "path"
    assert err.relative_url is "relative_url"

# Generated at 2022-06-24 03:43:41.689643
# Unit test for constructor of class PyFileError
def test_PyFileError():
    err = PyFileError('test')
    assert err.args[0] == "could not execute config file %s"
    assert err.args[1] == 'test'


# Generated at 2022-06-24 03:43:47.331070
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    '''
    Test for the given parameters.
    For example:
    
    def __init__(self, message, method, allowed_methods):
        super().__init__(message)
        self.headers = {"Allow": ", ".join(allowed_methods)}
    '''

    message='405 Method Not Supported'
    method='GET'
    allowed_methods=['POST','PUT','GET']
    methodNotSupported=MethodNotSupported(message, method, allowed_methods)
    assert methodNotSupported.headers=={'Allow': 'POST, PUT, GET'}
    


# Generated at 2022-06-24 03:43:49.140013
# Unit test for constructor of class PyFileError
def test_PyFileError():
    py_file_error = PyFileError("file")
    assert str(py_file_error) == "could not execute config file file"

# Generated at 2022-06-24 03:43:53.239558
# Unit test for constructor of class NotFound
def test_NotFound():
    test_message = "testing, testing"
    exception = NotFound(test_message, None, None)
    assert exception.status_code == 404
    assert exception.message == test_message


# Generated at 2022-06-24 03:43:57.653876
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    """
    Test for constructor of class ContentRangeError
    """
    try:
        range = 'bytes=1-49/50'
        raise ContentRangeError('Content-Range error', range)
    except ContentRangeError as err:
        assert err.status_code == 416
        assert err.headers['Content-Range'] == 'bytes */50'

# Generated at 2022-06-24 03:43:59.731433
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Test")
    except SanicException as exc:
        assert str(exc) == "Test"


# Generated at 2022-06-24 03:44:03.159720
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError('test error')
    assert error.args[0] == 'test error'
    # Testing the object type
    assert isinstance(error, URLBuildError)
    assert isinstance(error, ServerError)
    assert isinstance(error, SanicException)
    assert isinstance(error, Exception)

# Generated at 2022-06-24 03:44:06.852480
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message='It is a SanicException')
    except SanicException as e:
        assert str(e) == 'It is a SanicException'


# Generated at 2022-06-24 03:44:10.788462
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    """
    One test case for class HeaderNotFound.
    """
    header_not_found = HeaderNotFound('header_not_found')
    assert header_not_found.status_code == 400
    assert header_not_found.quiet is True


# Generated at 2022-06-24 03:44:14.565174
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('Service is unavailable')
    except ServiceUnavailable as e:
        assert str(e) == 'Service is unavailable'
        assert e.message == 'Service is unavailable'
        assert e.status_code == 503

# Generated at 2022-06-24 03:44:16.494322
# Unit test for constructor of class PyFileError
def test_PyFileError():
    the_exception = PyFileError(file="a_file")
    assert str(the_exception) == "could not execute config file a_file"

# Generated at 2022-06-24 03:44:19.997741
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "test.py"
    e = PyFileError(file)
    assert e.args[0] == "could not execute config file {}".format(file)

# Generated at 2022-06-24 03:44:20.750357
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    pass

# Generated at 2022-06-24 03:44:26.026183
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    print('testing method MethodNotSupported')
    method = 'GET'
    allowed_methods = ['GET', 'POST']
    mns = MethodNotSupported('message', method, allowed_methods)
    #import pdb; pdb.set_trace()
    print(mns)

# Generated at 2022-06-24 03:44:35.488165
# Unit test for function add_status_code
def test_add_status_code():
    # Initialize the dictionary to test if it
    # succeeds to create a new instance

    @add_status_code(400)
    class TestAddStatusCode(SanicException):

        pass

    # Use the add_status_code decorator to create a new class
    _sanic_exceptions = {400: TestAddStatusCode}

    # Create a new instance of class TestAddStatusCode
    test_instance = TestAddStatusCode("test_message")

    # Find the key in the dictionary
    # If the key exists, it'll find the right class
    type(test_instance) == _sanic_exceptions[400]

    # Test if it's a SanicException instance
    assert isinstance(test_instance, SanicException)



# Generated at 2022-06-24 03:44:37.998690
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    ins = InvalidRangeType('Invalid Range Type',None)
    assert ins

# Generated at 2022-06-24 03:44:39.813424
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Sample error message", 500)
    except Exception:
        assert(True)

# Generated at 2022-06-24 03:44:41.217877
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # This should not throw an excepion.
    c = HeaderNotFound("some message")

# Generated at 2022-06-24 03:44:43.001297
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge.status_code==413
    assert PayloadTooLarge.quiet==True



# Generated at 2022-06-24 03:44:49.591442
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as mns_obj:
        raise MethodNotSupported("Method Not Supported", "GET", ["POST"])
        assert MethodNotSupported == mns_obj.type
        assert "Method Not Supported" in mns_obj.value.args
        assert "GET" in mns_obj.value.args
        assert ["POST"] in mns_obj.value.args
        assert 500 in mns_obj.value.args


# Generated at 2022-06-24 03:44:51.837635
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    a = LoadFileException("3")
    assert(a.__class__.__name__=="LoadFileException")
	

# Generated at 2022-06-24 03:44:57.353303
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "Test FileNotFound"
    path = "Test Path"
    relative_url = "Test Relative URL"
    e = FileNotFound(message, path, relative_url)
    assert message == e.args[0]
    assert path == e.path
    assert relative_url == e.relative_url



# Generated at 2022-06-24 03:45:06.661379
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as err:
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as err:
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == "Digest realm=\"Restricted Area\", qop=\"auth, auth-int\", algorithm=\"MD5\", nonce=\"abcdef\", opaque=\"zyxwvu\""

# Generated at 2022-06-24 03:45:07.914766
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge("test", 100)

# Generated at 2022-06-24 03:45:11.513799
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("The server is down")
    except SanicException as e:
        assert e.status_code == 503


# Generated at 2022-06-24 03:45:16.164622
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError) as excinfo:
        raise URLBuildError('message', 'path', 'relative_url')
    exception_info = excinfo.value
    assert exception_info.args[0] == 'message'
    assert exception_info.path == 'path'
    assert exception_info.relative_url == 'relative_url'

# Generated at 2022-06-24 03:45:18.178997
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "test-HeaderExpectationFailed"
    exception = HeaderExpectationFailed(message)
    assert exception.status_code == 417
    assert exception.message == message

# Generated at 2022-06-24 03:45:22.559835
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    obj = ContentRangeError("wrong")
    print(obj.headers)

# Generated at 2022-06-24 03:45:32.051993
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("404")
    except SanicException as e:
        assert e.status_code is None
        assert not hasattr(e, "quiet")
        assert str(e) == "404"
        assert repr(e) == "<SanicException: 404>"

    try:
        raise SanicException("500", status_code=500)
    except SanicException as e:
        assert e.status_code == 500
        assert not hasattr(e, "quiet")
        assert str(e) == "500"
        assert repr(e) == "<SanicException: 500>"

    try:
        raise SanicException("403", status_code=403, quiet=True)
    except SanicException as e:
        assert e.status_code == 403
        assert e.quiet

# Generated at 2022-06-24 03:45:35.208492
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        x=NotFound("Message")
        assert x.message=="Message"
    except Exception as e:
        print(e)


# Generated at 2022-06-24 03:45:41.824631
# Unit test for function abort
def test_abort():
    try:
        abort(404)
        abort(500, "message")
    except SanicException as e:
        assert e.status_code == 404
    else:
        raise Exception("Should not reach this case")
    try:
        abort(410, "message")
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "message"
    else:
        raise Exception("Should not reach this case")

# Generated at 2022-06-24 03:45:44.314711
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound
    except NotFound:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:45:46.764092
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('test')
    except InvalidSignal as e:
        assert e.__str__() == 'test'

# Generated at 2022-06-24 03:45:48.827590
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException('error')

# Generated at 2022-06-24 03:45:58.399820
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # test the init is correct
    try:
        raise FileNotFound("file not found", "file name", "relative_url")
    except FileNotFound as error:
        assert error.message == "file not found"
        assert error.path == "file name"
        assert error.relative_url == "relative_url"
    finally:
        print("Test on FileNotFound passed")
    # test the init is correct
    try:
        raise FileNotFound("file not found", "", "relative_url")
    except FileNotFound as error:
        assert error.message == "file not found"
        assert error.path == ""
        assert error.relative_url == "relative_url"
    finally:
        print("Test on FileNotFound passed")
    # test if the non-existence exception is raised

# Generated at 2022-06-24 03:46:00.475231
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError(message='URLBuildError')
    assert url_build_error.message == 'URLBuildError'


# Generated at 2022-06-24 03:46:03.147470
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("/test")
    except PyFileError as e:
        assert str(e) == "could not execute config file /test"


# Generated at 2022-06-24 03:46:06.689442
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    a = MethodNotSupported('Method Not Support', 'GET', ['POST'])
    assert a.message == 'Method Not Support'
    assert a.headers == {"Allow": "POST"}


# Generated at 2022-06-24 03:46:12.042376
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_size=20
    max_size=10
    expected_message="The request body is larger than the maximum payload size: %d" % (max_size)
    actual_message = PayloadTooLarge(expected_message,payload_size,max_size)
    assert actual_message == expected_message


# Generated at 2022-06-24 03:46:17.061376
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as excinfo:
        raise ServiceUnavailable('The server is currently unavailable')
    assert excinfo.value.status_code == 503
    assert str(excinfo.value) == 'The server is currently unavailable'
    assert excinfo.value.__class__.__name__ == 'ServiceUnavailable'


# Generated at 2022-06-24 03:46:21.177580
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("AAA:",403)
    forbidden.message == "AAA:"
    forbidden.status_code == 403
    forbidden.quiet == True

if __name__ == '__main__':
    test_Forbidden()
    print ("Test Success")

# Generated at 2022-06-24 03:46:24.690303
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Error message: Invalid Range Type", type(None))
    except InvalidRangeType as exception:
        assert exception
        assert exception.message == "Error message: Invalid Range Type"

# Generated at 2022-06-24 03:46:26.922244
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as err:
        assert err.message == "Invalid Signal"


# Generated at 2022-06-24 03:46:34.117794
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    mock_message = "Test Message"
    mock_status_code = 413

    pl = PayloadTooLarge(message=mock_message, status_code=mock_status_code)
    assert pl.message == mock_message
    assert pl.status_code == mock_status_code


# Generated at 2022-06-24 03:46:41.208462
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as exc:
        assert exc.status_code == 401
        assert exc.message == "Auth required."
        assert exc.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

if __name__ == '__main__':
    test_Unauthorized()

# Generated at 2022-06-24 03:46:43.583493
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError('/tmp/test.py')
    assert pyfileerror.message == 'could not execute config file /tmp/test.py'
    assert pyfileerror.args == ('could not execute config file /tmp/test.py', )

# Generated at 2022-06-24 03:46:47.527497
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_name = 'header1'
    header_not_found = HeaderNotFound(f'Header {header_name} not found')
    assert str(header_not_found) == f'Header {header_name} not found'
    assert header_not_found.status_code == 400

# Generated at 2022-06-24 03:46:50.029633
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(TypeError):
        ContentRangeError("hello", 12)
    with pytest.raises(ContentRangeError, match="hello"):
        ContentRangeError("hello", None)

# Generated at 2022-06-24 03:46:55.360068
# Unit test for constructor of class NotFound
def test_NotFound():
    import pytest
    try:
        raise NotFound('message')
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "message"
        assert e.args[0] == "message"
        assert repr(e) == f"NotFound(message='message')"

# Generated at 2022-06-24 03:46:56.924322
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    assert HeaderNotFound("Bad Request", status_code=400)

# Generated at 2022-06-24 03:47:00.266848
# Unit test for function abort
def test_abort():
    try:
        abort(401)
    except Unauthorized as e:
        assert e.message == "Unauthorized"
        assert e.status_code == 401


# Generated at 2022-06-24 03:47:03.365472
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('test exception')
    except SanicException as e:
        assert e.message == 'test exception'
        assert e.status_code == None


# Generated at 2022-06-24 03:47:08.190110
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Message", status_code=400, quiet=True)
    except Forbidden as e:
        assert e.status_code == 400
        assert isinstance(e, SanicException)
        assert e.message == "Message"


# Generated at 2022-06-24 03:47:12.727769
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    self = URLBuildError("Failed to create URL from endpoint")
    assert (
        str(self) == "Failed to create URL from endpoint"
    )

# Generated at 2022-06-24 03:47:17.515864
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType('Test Message', 'Content Range')
    assert invalid_range_type.message == 'Test Message'
    assert invalid_range_type.status_code == 416
    assert invalid_range_type.headers == {'Content-Range': 'bytes */Content Range'}


# Generated at 2022-06-24 03:47:19.754175
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal
    except InvalidSignal:
        assert True
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-24 03:47:27.014542
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class CustomException(SanicException):
        pass

    assert CustomException.status_code == 400
    assert CustomException.quiet is None
    assert _sanic_exceptions[400] is CustomException

    @add_status_code(500, quiet=True)
    class CustomException2(SanicException):
        pass

    assert CustomException2.status_code == 500
    assert CustomException2.quiet is True
    assert _sanic_exceptions[500] is CustomException2