

# Generated at 2022-06-24 03:37:08.224659
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Test")
    except Exception as e:
        assert e.message == 'Test'
        assert e.status_code == 500

# Generated at 2022-06-24 03:37:09.617976
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = InvalidRangeType(None, None)
    assert a.message == '[Failure instance: Traceback (failure with no frames): <class \'__main__.InvalidRangeType\'>: None\n]'

# Generated at 2022-06-24 03:37:12.780877
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Internal Error",status_code=500)
    except SanicException as err:
        assert err.message == "Internal Error"
        assert err.quiet is None
        assert err.status_code == 500


# Generated at 2022-06-24 03:37:16.231131
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("message")
    except Exception as e:
        assert e.args[0] == "message"
        assert e.status_code == 500
        assert e.quiet == False


# Generated at 2022-06-24 03:37:18.772643
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal
    except InvalidSignal as e:
        assert e.message == None



# Generated at 2022-06-24 03:37:20.804829
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    x = HeaderNotFound('This is a test')
    assert x.status_code == 400

# Generated at 2022-06-24 03:37:24.166756
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message='Test')
        assert False
    except SanicException as e:
        assert e.message == 'Test'
        assert e.status_code is None


# Generated at 2022-06-24 03:37:28.505856
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    my_message = "Just a message"
    my_method = "GET"
    my_allowed_methods = ["POST", "GET"]

    my_MethodNotSupported = MethodNotSupported(my_message, my_method, my_allowed_methods)

    assert my_MethodNotSupported.headers == {'Allow': 'POST, GET'}


# Generated at 2022-06-24 03:37:30.081964
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden) as info:
        forbidden = Forbidden("Forbidden.")


# Generated at 2022-06-24 03:37:31.896112
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found = HeaderNotFound()
    assert header_not_found.status_code == 400



# Generated at 2022-06-24 03:37:34.996086
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("408", "timeout")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == "timeout"

# Generated at 2022-06-24 03:37:36.686609
# Unit test for constructor of class ServerError
def test_ServerError():
    my_error = ServerError('Great error', status_code=404)
    assert my_error.message == 'Great error'
    assert my_error.status_code == 404

# Generated at 2022-06-24 03:37:42.057521
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request timeout")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert str(e) == "Request timeout"

# Generated at 2022-06-24 03:37:45.365176
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    err = ContentRangeError("Message", 10)
    assert err._message == "Message"
    assert err.status_code == 416
    assert err.headers == {"Content-Range": "bytes */10"}


# Generated at 2022-06-24 03:37:49.124820
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Invalid request")
    except Exception as e:
        assert e.message == "Invalid request"
        assert e.status_code == None


# Generated at 2022-06-24 03:37:55.401145
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "This is an error message"
    status_code = 404
    quiet = True
    exc = SanicException(message=message, status_code=status_code, quiet=quiet)
    assert exc.message == message
    assert exc.status_code == status_code
    assert exc.quiet == quiet


# Generated at 2022-06-24 03:37:58.280583
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    sc = InvalidSignal("Test: Please ignore.")
    assert sc.message == "Test: Please ignore."
    assert sc.status_code == None
    assert sc.quiet == None


# Generated at 2022-06-24 03:38:00.063914
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('an error occurs')
    except:
        assert True

# Generated at 2022-06-24 03:38:03.209386
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # Test the construction of a ServiceUnavailable
    with pytest.raises(ServiceUnavailable, match="Test error"):
        ServiceUnavailable("Test error")

# Generated at 2022-06-24 03:38:14.784513
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as ex:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    assert ex.value.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

    with pytest.raises(Unauthorized) as ex:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")

# Generated at 2022-06-24 03:38:17.408754
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported(
        "Test only", "POST", ("GET", "HEAD")
    )
    assert exception.headers["Allow"] == "GET, HEAD"

# Generated at 2022-06-24 03:38:20.671902
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    s = ServerError("Not found", status_code=404)
    assert str(s) == "Not found"
    assert s.status_code == 404
    assert s.quiet is True


# Generated at 2022-06-24 03:38:30.873126
# Unit test for constructor of class NotFound
def test_NotFound():
    msg: str
    nf: SanicException
    nf = NotFound(message='hello')
    nf.status_code
    msg = nf.__str__()
    assert msg == 'hello'
    assert nf.quiet == True
    nf = NotFound(message='hello', status_code=200)
    nf.status_code
    msg = nf.__str__()
    assert msg == 'hello'
    assert nf.quiet == None
    nf = NotFound(message='hello', status_code=None)
    nf.status_code
    msg = nf.__str__()
    assert msg == 'hello'
    assert nf.quiet == None

# Generated at 2022-06-24 03:38:35.382697
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError) as excinfo:
        raise ServerError(message="test server error")
    assert excinfo.value.args[0] == "test server error"
    assert excinfo.value.status_code == 500
    assert excinfo.value.quiet == False

# Generated at 2022-06-24 03:38:44.229936
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable.status_code == 503
    assert ServiceUnavailable.quiet is None
    assert str(ServiceUnavailable("Error Message1")) == "Error Message1"
    assert str(ServiceUnavailable("Error Message2", status_code=500)) == "Error Message2"
    assert str(ServiceUnavailable("Error Message3", status_code=500, quiet=False)) == "Error Message3"
    assert str(ServiceUnavailable("Error Message4", status_code=400, quiet=True)) == "Error Message4"
    assert str(ServiceUnavailable("Error Message5", status_code=503, quiet=True)) == "Error Message5"
    assert str(ServiceUnavailable("Error Message6", status_code=503, quiet=False)) == "Error Message6"

# Generated at 2022-06-24 03:38:47.203806
# Unit test for constructor of class NotFound
def test_NotFound():
    message = "Example text"
    status_code = 404
    notfound = NotFound(message=message, status_code=status_code, quiet=None)
    assert_equal(notfound.message, message)
    assert_equal(notfound.status_code, status_code)


# Generated at 2022-06-24 03:38:51.801085
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Error occurred")
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Error occurred"
        assert type(e) == ServerError


# Generated at 2022-06-24 03:38:54.490810
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    test_exception = InvalidRangeType("test")
    assert test_exception.__class__ == InvalidRangeType

# Generated at 2022-06-24 03:39:00.375320
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("message", status_code=500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "message"
        assert str(e) == "message"


# Generated at 2022-06-24 03:39:02.578809
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound("message", "path", "relative_url")
    assert exception.status_code == 404
    assert exception.message == "message"
    assert exception.path == "path"
    assert exception.relative_url == "relative_url"


# Generated at 2022-06-24 03:39:06.349213
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    e = MethodNotSupported("mock", "GET", allowed_methods=["GET", "POST"])
    assert e.headers == {"Allow": "GET, POST"}

# Generated at 2022-06-24 03:39:08.367747
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable, match="Service Unavailable"):
        abort(503) # Abort

# Generated at 2022-06-24 03:39:11.294230
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_exception = Forbidden("Authorization failed", 403)
    assert forbidden_exception.message == "Authorization failed"
    assert forbidden_exception.status_code == 403

# Generated at 2022-06-24 03:39:13.214610
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound("Test")
    assert str(exception) == "Test"
    assert exception.status_code == 404
    assert exception.message == "Test"


# Generated at 2022-06-24 03:39:16.157240
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    message = 'This is a test message of LoadFileException'
    exc = LoadFileException(message)
    assert exc.message == message
    assert exc.status_code == 500
    assert exc.quiet == False

# Generated at 2022-06-24 03:39:18.343344
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Test')
    except InvalidSignal as e:
        assert e.args == ('Test',)

# Generated at 2022-06-24 03:39:20.593541
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert MethodNotSupported('message', 'method', 'allowed_methods').__init__('message', 'method', 'allowed_methods')

# Generated at 2022-06-24 03:39:25.111340
# Unit test for function abort
def test_abort():
    status_code = 404
    message = STATUS_CODES[status_code]
    try:
        abort(status_code)
    except SanicException as exc:
        assert exc.message == message



# Generated at 2022-06-24 03:39:27.825498
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    msg = "test message"
    e = HeaderNotFound(msg)
    assert e.message == msg
    assert e.status_code == 400


# Generated at 2022-06-24 03:39:29.875030
# Unit test for constructor of class NotFound
def test_NotFound():
    a = NotFound("Not Found")
    assert isinstance(a, NotFound)



# Generated at 2022-06-24 03:39:34.681585
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Bearer auth-scheme, realm is optional so you can write:
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Exception as e:
        assert e.status_code == 401
        assert 'WWW-Authenticate' in e.headers.keys()
        assert e.headers['WWW-Authenticate'] == 'Bearer'

# Generated at 2022-06-24 03:39:36.506562
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 201

# Generated at 2022-06-24 03:39:38.176949
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("Internal Server Error")
    assert err.status_code == 500

# Generated at 2022-06-24 03:39:49.602239
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    testcases = [{
        'message': 'Auth required.',
        'scheme': 'Basic',
        'realm': 'Restricted Area'
    }, {
        'message': 'Auth required.',
        'scheme': 'Digest',
        'realm': 'Restricted Area',
        'qop': 'auth, auth-int',
        'algorithm': 'MD5',
        'nonce': 'abcdef',
        'opaque': 'zyxwvu'
    }, {
        'message': 'Auth required.',
        'scheme': 'Bearer'
    }, {
        'message': 'Auth required.',
        'scheme': 'Bearer',
        'realm': 'Restricted Area'
    }]


# Generated at 2022-06-24 03:39:54.920056
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    from sanic import Sanic

    app = Sanic(__name__)

    try:

        @app.route('/')
        async def test(request):
            raise URLBuildError('resource')

    except URLBuildError:
        pass

# Generated at 2022-06-24 03:39:58.771103
# Unit test for constructor of class PyFileError
def test_PyFileError():
    err = PyFileError("test")
    assert err.args[0] == "could not execute config file %s"
    assert err.args[1] == "test"

# Generated at 2022-06-24 03:40:03.363471
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    status_code = 400
    message = "message"
    # create InvalidUsage with message and status_code
    exception = InvalidUsage(message, status_code)
    # assert_that(exception.status_code).is_equal_to(status_code)
    # assert_that(exception.message).is_equal_to(message)
    sanic_exception = _sanic_exceptions.get(status_code, SanicException)
    assert sanic_exception is InvalidUsage


# Generated at 2022-06-24 03:40:06.780888
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    FNFE = FileNotFound("file not found", "path", "relative_url")
    assert FNFE.status_code == 404
    assert FNFE.path == "path"
    assert FNFE.relative_url == "relative_url"


# Generated at 2022-06-24 03:40:08.340565
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden("Forbidden")



# Generated at 2022-06-24 03:40:14.864400
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge
    except PayloadTooLarge:
        assert True
    except:
        assert False


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 03:40:16.075222
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    su = ServiceUnavailable('503 Service Unavailable')
    assert su.status_code == 503
    assert su.quiet is True


# Generated at 2022-06-24 03:40:22.638255
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = 'GET'
    allowed_methods = ('GET', 'POST')
    message = "Method not allowed"
    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.headers == {"Allow": "GET, POST"}
    assert exception.args == (message,)

# Generated at 2022-06-24 03:40:24.462684
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("SIGINT")
    except SanicException as e:
        print(e)
        assert True

# Generated at 2022-06-24 03:40:26.608961
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = ContentRangeError("test", None)
    assert("test" == c.args[0])
    assert("bytes */None" == c.headers['Content-Range'])

# Generated at 2022-06-24 03:40:28.897083
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestSanic(SanicException):
        pass
    assert _sanic_exceptions.get(200) == TestSanic

# Generated at 2022-06-24 03:40:36.011264
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert str(URLBuildError('message')) == 'message'
    assert str(URLBuildError('message', environ={'REQUEST_METHOD': 'GET'})) == 'message'
    assert str(URLBuildError('message', environ={'REQUEST_METHOD': 'GET'})) == 'message'
    assert str(URLBuildError('message', environ={'REQUEST_METHOD': 'POST'})) == 'message'

# Generated at 2022-06-24 03:40:39.567384
# Unit test for constructor of class NotFound
def test_NotFound():
    nf_object = NotFound('404 Not Found')
    assert nf_object.status_code == 404
    # Assert that it is decoded as a UTF-8 string
    assert nf_object.args[0] == '404 Not Found'


# Generated at 2022-06-24 03:40:40.751773
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError('error message', 1000)


# Generated at 2022-06-24 03:40:44.331518
# Unit test for function abort
def test_abort():
    with pytest.raises(UnicodeDecodeError):
        abort(400)
    with pytest.raises(ServerError):
        abort(500)
    with pytest.raises(SanicException):
        abort(100)

# Generated at 2022-06-24 03:40:46.737760
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_exception = URLBuildError("Test URLBuildError")
    assert url_build_exception.status_code == 500
    assert url_build_exception.quiet == False


# Generated at 2022-06-24 03:40:55.654224
# Unit test for constructor of class SanicException
def test_SanicException():
    # case 1: normal
    try:
        raise SanicException("test")
    except SanicException as e:
        assert e.message == "test"

    # case 2: 
    try:
        raise SanicException("test", 400)
    except SanicException as e:
        assert e.status_code == 400

    # case 3:
    try:
        raise SanicException("test", quiet=True)
    except SanicException as e:
        assert e.quiet == True

    # case 4:
    try:
        raise SanicException("test", 400, True)
    except SanicException as e:
        assert e.status_code == 400
        assert e.quiet == True

    # case 5:

# Generated at 2022-06-24 03:40:58.825914
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType('', '', '')
    assert invalid_range_type.headers['Content-Range'] == 'bytes */'
    assert invalid_range_type.status_code == 416

# Generated at 2022-06-24 03:41:01.888716
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    
    error = InvalidSignal('Test', 201)
    assert str(error).__eq__('Test')
    assert error.status_code.__eq__(201)
    
    
    error = InvalidSignal('Test')
    assert str(error).__eq__('Test')
    assert error.status_code.__eq__(500)
    

# Generated at 2022-06-24 03:41:02.778466
# Unit test for function abort
def test_abort():
    abort(405, 'Hello world')

# Generated at 2022-06-24 03:41:05.940556
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("")
    assert hnf.message == ""
    assert hnf.status_code == 400
    assert hnf.quiet is True
    assert hnf.headers == {}


# Generated at 2022-06-24 03:41:08.866898
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h = HeaderExpectationFailed("HTTP headers expectation is failed",417)
    assert h.__init__("HTTP headers expectation is failed",417)

# Generated at 2022-06-24 03:41:10.360788
# Unit test for constructor of class NotFound
def test_NotFound():
    error = NotFound("Not Found")
    assert error.status_code == 404


# Generated at 2022-06-24 03:41:18.219770
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        hdr = e.headers
        assert 'WWW-Authenticate' in hdr
        hdr_value = 'Basic realm="Restricted Area"'
        assert hdr['WWW-Authenticate'] == hdr_value


# Generated at 2022-06-24 03:41:20.166955
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    myHEF = HeaderExpectationFailed("myMessage")
    assert myHEF.status_code == 417
    assert myHEF.message == "myMessage"



# Generated at 2022-06-24 03:41:24.026528
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Test URLBuildError")
    except URLBuildError as e:
        assert e.args[0] == "Test URLBuildError"

# Generated at 2022-06-24 03:41:30.400017
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    from sanic.request import Request
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        get = None
        post = None

    r = Request("PUT", "/", data={"a": 1})
    v = MyView()
    try:
        v._handle(r, None, {"abc":"abcde"})
    except MethodNotSupported as e:
        assert e.message == 'The method is not supported for this route.'
        assert e.headers == {'Allow': 'GET, POST'}

# Generated at 2022-06-24 03:41:36.349178
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message="Bad gateway", status_code=502)
    except SanicException as e:
        assert isinstance(e, Exception)
        assert e.status_code == 502
        assert e.quiet == True
        assert e.message == "Bad gateway"
        print("SanicException passed!")


# Generated at 2022-06-24 03:41:38.181503
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError("config.py")

# Generated at 2022-06-24 03:41:43.385846
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    a = LoadFileException("test", message="test")
    assert a.message == "test"
    assert a.status_code == "test"
    assert a.__repr__() == 'test'

# Generated at 2022-06-24 03:41:45.718858
# Unit test for constructor of class SanicException
def test_SanicException():
    # This function needs to be tested for Student Work
    #print('No test for {!r}'.format(abort.__name__))
    None

# Generated at 2022-06-24 03:41:47.373201
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    lfexception = LoadFileException("load file exception")
    assert lfexception.message == "load file exception"



# Generated at 2022-06-24 03:41:54.223419
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # Given
    allowed_methods = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    method = "GET"
    message = "The method is not supported"

    # When
    exception = MethodNotSupported(message, method, allowed_methods)

    # Then
    assert exception.args[0] == message
    assert exception.headers["Allow"] == ", ".join(allowed_methods)

# Generated at 2022-06-24 03:41:56.600123
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    crange = ContentRangeError("Invalid Content-Range header value", 10)
    assert crange.headers == {"Content-Range": f"bytes */{10}"}

# Generated at 2022-06-24 03:41:58.109863
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError):
        raise URLBuildError

# Generated at 2022-06-24 03:41:58.845106
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    pass

# Generated at 2022-06-24 03:42:03.771701
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('FileNotFound')
    except LoadFileException as ex: 
        msg = ex.args
        status_code = ex.status_code
        quiet = ex.quiet
        assert msg == ('FileNotFound',)
        assert status_code == 500
        assert quiet == False


# Generated at 2022-06-24 03:42:10.867350
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message='Service unavailable')
    except ServiceUnavailable as e:
        assert e.status_code == 503, \
            "The status code of the exception is wrong, expected 503 but got {}".format(e.status_code)
        assert e.message == 'Service unavailable', \
            "The message of the exception is wrong, expected 'Service unavailable' but got {}".format(e.message)


# Generated at 2022-06-24 03:42:12.699261
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    var = HeaderNotFound()
    assert var.message == 'Bad Request'


# Generated at 2022-06-24 03:42:16.344737
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage(message = 'Invalid request')
    except InvalidUsage as e:
        print('Message: {}'.format(e))
        print('Status Code: {}'.format(e.status_code))

test_InvalidUsage()

# Generated at 2022-06-24 03:42:20.170665
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Client did not produce any request data "
                             "within a specific time frame.")
    except RequestTimeout as e:
        assert e.status_code == 408
# test_RequestTimeout()

# Generated at 2022-06-24 03:42:24.537200
# Unit test for function abort
def test_abort():
    """ Tests that abort function by calling function abort
        and checking that the expected exception is raised.
    """
    status_code = 400
    message = "User Exists"
    exc = None

    try:
        abort(status_code, message)
    except Exception as e:
        exc = e

    assert(isinstance(exc, InvalidUsage))
    assert(exc.status_code == status_code)
    assert(exc.message == message)

# Generated at 2022-06-24 03:42:28.694258
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("This is a Timeout message")
    except RequestTimeout as request_timeout:
        assert request_timeout.status_code == 408
        assert request_timeout.message == "This is a Timeout message"



# Generated at 2022-06-24 03:42:33.782927
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}


# Generated at 2022-06-24 03:42:35.421216
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert 'bytes */12' == InvalidRangeType("test",12).headers['Content-Range']

# Generated at 2022-06-24 03:42:38.807073
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as e:
        raise InvalidSignal("This method does not accept 'SIGUSR1' signal")

    assert "This method does not accept 'SIGUSR1' signal" in str(e)

# Generated at 2022-06-24 03:42:40.551758
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        PyFileError("config")

# Generated at 2022-06-24 03:42:43.357184
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound(message="Test message", status_code=400)
    assert exception.message == "Test message"
    assert exception.status_code == 400
    assert exception.quiet == False

# Generated at 2022-06-24 03:42:45.674658
# Unit test for constructor of class NotFound
def test_NotFound():
    notfound = NotFound('Some Exception')
    assert notfound.status_code == 404
    assert notfound.quiet is True


# Generated at 2022-06-24 03:42:56.814362
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400

    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404

    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500

    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503

    try:
        abort(408)
    except RequestTimeout as e:
        assert e.status_code == 408

    try:
        abort(413)
    except PayloadTooLarge as e:
        assert e.status_code == 413

# Generated at 2022-06-24 03:42:59.654965
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("hello")
    except ServerError as err:
        assert str(err) == "hello"
        assert err.status_code == 500

# Generated at 2022-06-24 03:43:02.368591
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as e_info:
        raise InvalidUsage("test message")
    assert str(e_info.value) == "test message"



# Generated at 2022-06-24 03:43:07.280568
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("This is a test")
    except Exception as e:
        print(e)
        assert(str(e) == "This is a test")

if __name__ == "__main__":
    test_LoadFileException()

# Generated at 2022-06-24 03:43:09.545835
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('test')
    except SanicException as e:
        assert e.message == 'test'
        assert e.status_code == 413


# Generated at 2022-06-24 03:43:13.667934
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('exception test',
                                 'POST',
                                 ['PUT', 'GET'])
    except MethodNotSupported as e:
        assert e.status_code == 405
        assert e.headers['Allow'] == 'PUT, GET'

# Generated at 2022-06-24 03:43:19.840867
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # assert pyfileerror is working
    try:
        pyfileerror = PyFileError("file")
        code = pyfileerror.__init__("file")
        if code:
            raise pyfileerror
    except:
        # if not in try block, assert will not be executed
        assert "could not execute config file file" in str(pyfileerror)

if __name__ == '__main__':
    test_PyFileError()

# Generated at 2022-06-24 03:43:21.068617
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    test_exception = URLBuildError("this is a TestError")


# Generated at 2022-06-24 03:43:26.240533
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("BADREQUEST")
    except Exception as error:
        assert error.status_code == 503
        assert error.__str__() == "BADREQUEST"

# Generated at 2022-06-24 03:43:28.540276
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test_obj = MethodNotSupported("Method Not Allowed", "GET", "POST")
    assert test_obj.headers == {'Allow': 'POST'}

# Generated at 2022-06-24 03:43:40.403596
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # missing realm
    with pytest.raises(Unauthorized) as exc:
        raise Unauthorized("Auth required.", scheme="Basic")
    assert str(exc.value) == "Auth required."
    assert exc.value.status_code == 401
    assert exc.value.headers == {"WWW-Authenticate": 'Basic realm=""'}

    # deprecated
    # with pytest.raises(Unauthorized) as exc:
    #    raise Unauthorized("Auth required.")
    # assert str(exc.value) == "Auth required."
    # assert exc.value.status_code == 401
    # assert exc.value.headers == {"WWW-Authenticate": 'Basic realm=""'}

    # missing scheme

# Generated at 2022-06-24 03:43:44.142951
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    su = ServiceUnavailable(message='Service Unavailable', status_code=503)
    assert str(su) == 'Service Unavailable'
    assert su.status_code == 503


if __name__ == "__main__":
    print(abort(500))

# Generated at 2022-06-24 03:43:46.079129
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as err:
        assert (str(err) == "Invalid Signal")

# Generated at 2022-06-24 03:43:52.532942
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported("test", "GET", ["GET", "POST"])

    assert exception.status_code == 405
    assert exception.message == "test"
    assert exception.method == "GET"
    assert exception.headers["Allow"] == "GET, POST"


# Generated at 2022-06-24 03:43:59.721872
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Test constructor of class RequestTimeout with no parameters
    assert RequestTimeout()
    # Test constructor of class RequestTimeout with message parameter
    assert RequestTimeout("hello world")
    # Test constructor of class RequestTimeout with status_code parameter
    assert RequestTimeout(status_code=400)
    # Test constructor of class RequestTimeout with quiet parameter
    assert RequestTimeout(quiet=True)
    # Test constructor of class RequestTimeout with status_code and quiet parameters
    assert RequestTimeout(status_code=400, quiet=True)
    # Test constructor of class RequestTimeout with all parameters
    assert RequestTimeout("hello world", status_code=400, quiet=True)

# Generated at 2022-06-24 03:44:06.571933
# Unit test for function abort
def test_abort():
    # SanicExceptions are usually quiet, but we set the quiet flag to false
    # so the exception will be propagated
    with pytest.raises(NotFound) as excinfo:
        abort(404, 'Page Not Found')
    assert str(excinfo.value) == 'Page Not Found'
    assert excinfo.value.status_code == 404

    # Default message should be used if not provided
    with pytest.raises(ServerError) as excinfo:
        abort(500)
    assert str(excinfo.value) == 'Internal Server Error'
    assert excinfo.value.status_code == 500

# Generated at 2022-06-24 03:44:09.052694
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("message")
    except HeaderNotFound as ex:
        assert ex.message == "message"
        assert ex.status_code == 400

# Generated at 2022-06-24 03:44:10.865617
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test = PyFileError("abc.py")
    assert not test.__eq__("abc.py")


# Generated at 2022-06-24 03:44:15.831003
# Unit test for constructor of class SanicException
def test_SanicException():
    message = 'message'
    status_code = 200
    quiet = True
    e = SanicException(message, status_code, quiet)
    assert e.message == message
    assert e.status_code == status_code
    assert e.quiet == quiet
    assert e.__class__ == SanicException
    

# Generated at 2022-06-24 03:44:21.339488
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    someErrorMsg = "some error message"
    try:
        raise LoadFileException(message=someErrorMsg, status_code=500)
    except LoadFileException as error:
        assert error.status_code == 500, "status_code was not set correctly"
        assert error.message == someErrorMsg, "message was not set correctly"

# Generated at 2022-06-24 03:44:25.412816
# Unit test for constructor of class PyFileError
def test_PyFileError():
    exception = PyFileError("test.py")
    assert exception.args[0] == "could not execute config file %s" and exception.args[1] == "test.py"

# Generated at 2022-06-24 03:44:32.258671
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "Not Satisfiable"
    class TestClass:
        total = 10
    content_range = TestClass()
    custom_exception = ContentRangeError(message, content_range)
    assert custom_exception.message == "Not Satisfiable"
    assert custom_exception.headers["Content-Range"] == "bytes */10"

# Generated at 2022-06-24 03:44:39.558972
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="abc", status_code=417)
    except Exception as e:
        try:
            assert e.message == "abc"
            assert e.status_code == 417
            assert e.quiet is True
        except Exception:
            print("test_HeaderExpectationFailed is incorrect!")
            print("error info: ", e)
            assert False

# Generated at 2022-06-24 03:44:43.369844
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Invalid Url.")
    except URLBuildError as e:
        print("Error code : {0}".format(e.args[0]))

test_URLBuildError()

# Generated at 2022-06-24 03:44:47.030903
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "bad request"
    status_code = 417
    exception = HeaderExpectationFailed(message)
    assert exception.status_code == status_code
    assert exception.message == message
    assert exception.quiet == True


# Generated at 2022-06-24 03:44:48.973811
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    a = ServiceUnavailable("Hello")
    assert type(a) == ServiceUnavailable
    assert a.status_code == 503

# Generated at 2022-06-24 03:44:59.295078
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    assert str(HeaderExpectationFailed("test", status_code=417)) == "test"
    assert str(HeaderExpectationFailed("test", status_code=417)) == "test"
    assert str(HeaderExpectationFailed("")) == ""
    assert str(HeaderExpectationFailed("test")) == "test"
    assert str(HeaderExpectationFailed(b"test", status_code=417)) == "test"
    assert str(HeaderExpectationFailed(b"test", status_code=417)) == "test"
    assert str(HeaderExpectationFailed(b"")) == ""
    assert str(HeaderExpectationFailed(b"test")) == "test"
    assert str(HeaderExpectationFailed("", status_code=417)) == ""

# Generated at 2022-06-24 03:45:02.262080
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="Test Service Unavailable")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Test Service Unavailable"

# Generated at 2022-06-24 03:45:04.150425
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(FileNotFound):
        FileNotFound(message="a", path="b", relative_url="c")

# Generated at 2022-06-24 03:45:06.434519
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    inst = PayloadTooLarge("payload too large!")
    assert inst.status_code==413
    assert inst.message=="payload too large!"
    
    

# Generated at 2022-06-24 03:45:12.427216
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # arrange
    message = "test message"
    # act
    headerExpectationFailed = HeaderExpectationFailed(
        message=message, status_code=417, quiet=False)
    # assert
    assert headerExpectationFailed.message == message, "message should match"

# Generated at 2022-06-24 03:45:14.126211
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_err = URLBuildError("%s", "Invalid Parameters")
    url_build_err.__str__()

# Generated at 2022-06-24 03:45:19.805035
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(Exception) as excinfo:
        raise FileNotFound('test', 'test', 'test')
    assert "test" in str(excinfo.value)
    assert "test" in str(excinfo.value)
    assert "test" in str(excinfo.value)


# Generated at 2022-06-24 03:45:21.971717
# Unit test for constructor of class ServerError
def test_ServerError():
    serverError = ServerError('str')
    assert serverError.status_code == 500
    assert serverError.quiet == False


# Generated at 2022-06-24 03:45:27.979181
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class CustomException(SanicException):
        pass

    ce = CustomException("Specified")
    assert ce.status_code == 200
    assert ce.quiet is None

    ce = CustomException("Specified", quiet=False)
    assert ce.status_code == 200
    assert ce.quiet is False

    ce = CustomException("Specified", quiet=True)
    assert ce.status_code == 200
    assert ce.quiet is True


# Generated at 2022-06-24 03:45:30.058459
# Unit test for constructor of class ServerError
def test_ServerError():
    s = ServerError("hello world", 500)
    assert(s.status_code == 500)
    assert(s.message == "hello world")

# Generated at 2022-06-24 03:45:42.226108
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    ua = Unauthorized("Auth required", scheme="Basic", realm="Restricted Area")
    assert ua.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    ua = Unauthorized("Auth required", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert ua.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", nonce="abcdef", opaque="zyxwvu", algorithm="MD5"'}

    ua = Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    assert ua.headers == {'WWW-Authenticate': 'Bearer realm="Restricted Area"'}

    ua

# Generated at 2022-06-24 03:45:44.760648
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message='abort')
    except LoadFileException as e:
        assert str(e) == 'abort'

# Generated at 2022-06-24 03:45:48.601387
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("file")
    except PyFileError as e:
        assert e.args[0] == "could not execute config file %s"
        assert e.args[1] == "file"

# Generated at 2022-06-24 03:45:58.412909
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    try:
        # With a Digest auth-scheme, things are a bit more complicated:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.message == "Auth required."

# Generated at 2022-06-24 03:46:05.038946
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Using assertRaises in this way will verify that the code raises the
    # InvalidUsage exception, which is what we are looking to test
    # default message
    with pytest.raises(InvalidUsage):
        raise InvalidUsage()
    # default message with custom status_code
    with pytest.raises(InvalidUsage):
        raise InvalidUsage(status_code=410)
    # custom message with custom status_code
    with pytest.raises(InvalidUsage):
        raise InvalidUsage(message='custom message', status_code=410)
    # custom message with default status_code
    with pytest.raises(InvalidUsage):
        raise InvalidUsage(message='custom message')
    # custom message with default status_code and quiet
    with pytest.raises(InvalidUsage):
        raise InvalidUsage(message='custom message', quiet=True)

# Generated at 2022-06-24 03:46:07.249973
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    err = Unauthorized("Auth required.")
    assert err.status_code == 401
    assert err.message == "Auth required."

# Generated at 2022-06-24 03:46:10.173182
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("My Message")
    assert err.status_code == 500
    assert err.message == "My Message"



# Generated at 2022-06-24 03:46:11.708819
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException('this is a test', status_code=400)


# Generated at 2022-06-24 03:46:19.825894
# Unit test for function abort
def test_abort():
    exceptions = [NotFound, InvalidUsage, MethodNotSupported, ServerError,
                  ServiceUnavailable, FileNotFound, RequestTimeout,
                  PayloadTooLarge, HeaderNotFound, ContentRangeError,
                  HeaderExpectationFailed, Forbidden, InvalidRangeType,
                  PyFileError, Unauthorized, LoadFileException,
                  InvalidSignal]
    for exception in exceptions:
        try:
            abort(exception.status_code)
        except exception:
            pass

if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-24 03:46:22.506979
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound:
        return True
    return False

assert test_abort() == True

# Generated at 2022-06-24 03:46:27.357576
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('load file error')
    except LoadFileException as e:
        print(e.message)

if __name__ == '__main__':
    test_LoadFileException()

# Generated at 2022-06-24 03:46:38.241781
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test the construction with the required parameters message and scheme
    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Basic",
            realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert "WWW-Authenticate" in e.headers
        # Check the WWW-Authenticate header.
        assert e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""
    # Test the construction with an additional parameter
    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Digest",
            realm="Restricted Area",
            username="John")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401

# Generated at 2022-06-24 03:46:46.989085
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class PageNotFound(SanicException):
       pass

    assert hasattr(PageNotFound, 'status_code') == True
    assert PageNotFound.status_code == 404

    @add_status_code(403, False)
    class PagesForbidden(SanicException):
       pass

    assert hasattr(PageNotFound, 'quiet') == True
    assert PagesForbidden.quiet == False

    @add_status_code(403, None)
    class PagesForbidden(SanicException):
       pass

    assert hasattr(PageNotFound, 'quiet') == True
    assert PagesForbidden.quiet == True

# Generated at 2022-06-24 03:46:48.946481
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('This is a test')
    except Exception as exc:
        assert exc.status_code == 500



# Generated at 2022-06-24 03:46:53.660320
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # When
    try:
        raise RequestTimeout(message="Test", status_code=408)
    # Then
    except RequestTimeout as e:
        assert e.status_code == 408

# Generated at 2022-06-24 03:47:03.929305
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    status_code = 401

    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"
    message = "Auth required."

    expected_header = "Digest realm=Restricted Area, qop=auth, auth-int, algorithm=MD5, nonce=abcdef, opaque=zyxwvu"

    e = Unauthorized(message, status_code, scheme, realm=realm, qop=qop, algorithm=algorithm, nonce=nonce, opaque=opaque)

    assert e.status_code == status_code
    assert e.message == "Auth required."
    assert e.headers["WWW-Authenticate"] == expected_header

# Generated at 2022-06-24 03:47:08.678884
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    message = ""
    try:
        raise ServiceUnavailable(message)
    except ServiceUnavailable as err:
        assert err.message == message
        assert err.status_code == 503
    else:
        assert False, "ServiceUnavailable not raised"
