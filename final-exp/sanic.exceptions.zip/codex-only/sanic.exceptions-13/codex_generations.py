

# Generated at 2022-06-24 03:37:33.005163
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("you are unauthorized")
    except Unauthorized as err:
        assert err.args[0] == "you are unauthorized"
        assert err.status_code == 401
        assert err.payload is None

    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as err:
        assert err.args[0] == "Auth required."
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
        assert err.payload is None


# Generated at 2022-06-24 03:37:36.393247
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('The method is unsupported', 'GET', ['PUT', 'POST'])
    except MethodNotSupported as e:
        assert isinstance(e, MethodNotSupported)
        assert e.headers == {'Allow': 'PUT, POST'}
        assert str(e) == 'The method is unsupported'


# Generated at 2022-06-24 03:37:42.057607
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    request_instance = MethodNotSupported('This request is not supported', 'POST', ['GET', 'PUT'])
    assert request_instance.headers == {'Allow': 'GET, PUT'}

# Generated at 2022-06-24 03:37:44.677075
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal("")
    assert "Invalid signal." in str(InvalidSignal(""))

# Generated at 2022-06-24 03:37:47.412414
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("message")
    except Exception as e:
        assert e.args[0] == "message"

# Generated at 2022-06-24 03:37:50.182036
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalidUsage = InvalidUsage("Invalid Usage");
    assert invalidUsage.message == "Invalid Usage"
    assert invalidUsage.status_code == 400
    assert invalidUsage.quiet == True


# Generated at 2022-06-24 03:37:53.481339
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("foo")
    assert f.status_code == 403


# Generated at 2022-06-24 03:38:01.986108
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Test case: FileNotFound(message=None, path=None, relative_url=None)
    with pytest.raises(TypeError):
        FileNotFound()
    
    # Test case: FileNotFound(message=message, path=None, relative_url=None)
    message = "test message"
    assert message == FileNotFound(message).message
    path = "test path"
    assert path == FileNotFound(message=None, path=path).path
    relative_url = "test relative_url"
    assert relative_url == FileNotFound(message=None, path=None, relative_url=relative_url).relative_url


# Generated at 2022-06-24 03:38:06.126510
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = "HTTP Error 416: Range Not Satisfiable"
    content_range = None
    e = ContentRangeError(msg, content_range)
    assert str(e) == msg
    assert e.headers == {"Content-Range": f"bytes */{content_range.total}"}

# Generated at 2022-06-24 03:38:08.639747
# Unit test for constructor of class ServerError
def test_ServerError():
    s = ServerError('test_message')
    assert s.message == 'test_message'

# Generated at 2022-06-24 03:38:11.114157
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    test_error = URLBuildError("This is a test.")
    assert test_error.args[0] == "This is a test."

# Generated at 2022-06-24 03:38:14.919881
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    ube = URLBuildError("Test")
    assert (ube.status_code == 500)
    assert (ube.args[0] == "Test")
    assert (ube.__repr__() == "Test")
    

# Generated at 2022-06-24 03:38:21.206856
# Unit test for function add_status_code
def test_add_status_code():
    # Decorator should create a new class (status_code is already present)
    @add_status_code(400)
    class MyException(BaseException):
        pass
    assert hasattr(MyException, 'status_code')

    # Decorator should add status_code to an existing class
    class MyException(BaseException):
        pass
    assert not hasattr(MyException, 'status_code')
    MyException = add_status_code(400)(MyException)
    assert hasattr(MyException, 'status_code')



# Generated at 2022-06-24 03:38:23.325078
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("main.py").args == ("could not execute config file %s", "main.py")

# Generated at 2022-06-24 03:38:27.235181
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test_URLBuildError: In construction of URLBuildError.")
    except URLBuildError as e:
        print ("test_URLBuildError: Exception caught:", e)



# Generated at 2022-06-24 03:38:33.261384
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    #Given
    allowed_methods = ['GET','POST','PUT','DELETE','OPTIONS','HEAD','TRACE','CONNECT']
    message = 'Method not supported'
    method = 'PATCH'
    #When
    mns = MethodNotSupported(message,method,allowed_methods)
    #Then
    assert mns.headers == {'Allow': 'GET, POST, PUT, DELETE, OPTIONS, HEAD, TRACE, CONNECT'}

# Generated at 2022-06-24 03:38:37.488242
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    try:
        abort(500, "Test")
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Test"
    try:
        abort(501, "Test")
    except SanicException as e:
        assert e.status_code == 501
        assert e.message == "Test"

# Generated at 2022-06-24 03:38:39.776580
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    urlBuildError = URLBuildError(message="test_message")
    assert urlBuildError.args[0] == "test_message"


# Generated at 2022-06-24 03:38:42.027120
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('test message')
    except URLBuildError as e:
        assert e.args[0] == 'test message'

# Generated at 2022-06-24 03:38:44.995556
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("blah", ContentRange(100, 250))
    except ContentRangeError as e:
        assert e.message == 'blah'
        assert e.headers == {'Content-Range': 'bytes */250'}


# Generated at 2022-06-24 03:38:50.124231
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Sevice Unavailable")
    except ServiceUnavailable as e:
        assert e.message == "Sevice Unavailable"

# Generated at 2022-06-24 03:38:52.772332
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound")
    except Exception as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:38:54.178623
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    e = LoadFileException('This is a exception')
    assert str(e) == 'This is a exception'

# Generated at 2022-06-24 03:39:00.901121
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as x:
        abort(404)
    assert str(x.value) == "Not Found"

    with pytest.raises(NotFound) as x:
        abort(404, "Not here!")
    assert str(x.value) == "Not here!"



# Generated at 2022-06-24 03:39:10.868403
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # The code below with "assert" is a unit test.
    # We always need unit tests for every function or class that we create.
    # The unit test below is checking that the value -1000 is not in the list
    # of values of the variable test_list.
    test_list = [0, 1, 2, 3, 4, 5]
    assert -1000 not in test_list

    # Now we'll write a unit test for the class Forbidden that we just wrote.
    # We'll create an object of the class and check the value of its attribute
    # status_code.
    test_object = Forbidden()
    assert test_object.status_code == 403

# Generated at 2022-06-24 03:39:14.194269
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as excinfo:
        raise ContentRangeError("Range not satisfiable", content_range=None)
    assert excinfo.match("Range not satisfiable")


# Generated at 2022-06-24 03:39:22.780069
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("message test", status_code=404, quiet=False)
    except Exception as e:
        assert type(e) == SanicException
        assert e.message == "message test"
        assert e.status_code == 404
        assert e.quiet == False
        assert type(e) is _sanic_exceptions[404]
    try:
        raise SanicException("message test", status_code=404, quiet=True)
    except Exception as e:
        assert e.quiet == True
    try:
        raise SanicException("message test", status_code=404, quiet=None)
    except Exception as e:
        assert e.quiet == True

# Generated at 2022-06-24 03:39:32.213775
# Unit test for constructor of class SanicException
def test_SanicException():
    # Case1: "message" is just a string
    message = 'Bad Request'
    expected = SanicException(message, 400)
    assert(expected.args[0] == message)
    assert(expected.status_code == 400)
    assert(expected.quiet == True)

    # Case2: "message" is a string with a status code
    message = 'Service Unavailable'
    sanic_exception = SanicException(message, 503)
    assert(sanic_exception.args[0] == message)
    assert(sanic_exception.status_code == 503)
    assert(sanic_exception.quiet == True)

    # Case3: "message" is a string with "quiet" as False
    message = 'Internal Server Error'

# Generated at 2022-06-24 03:39:37.112809
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("message")
    except URLBuildError as err:
        assert err.args[0] == "message"
        assert not hasattr(err, 'headers')
        assert err.status_code == 500
        assert not err.quiet


# Generated at 2022-06-24 03:39:39.826253
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Signal Number Out of Range')
    except InvalidSignal as e:
        assert str(e) == 'Signal Number Out of Range'

# Generated at 2022-06-24 03:39:42.337098
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found")
    except SanicException as e:
        assert e.args[0] == "Header not found"

# Generated at 2022-06-24 03:39:44.500313
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test 503")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "Test 503"

# Generated at 2022-06-24 03:39:47.158962
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('error msg')
    except ServiceUnavailable as e:
        assert e.args[0] == 'error msg'
        assert e.status_code == 503

# Generated at 2022-06-24 03:39:50.661522
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    instance = LoadFileException(message="Test", status_code=None, quiet=None)
    assert isinstance(instance, SanicException) is True
    assert isinstance(instance, LoadFileException) is True
    assert instance.__str__() == 'Test'

# Generated at 2022-06-24 03:39:54.581248
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    obj = RequestTimeout("Timeout", 408, True)
    assert obj.message == "Timeout"
    assert obj.status_code == 408
    assert obj.quiet == True

# Generated at 2022-06-24 03:39:56.142644
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed()
    assert exception.status_code == 417
    assert exception.quiet == True

# Generated at 2022-06-24 03:39:57.430914
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert URLBuildError("test_message").args[0] == "test_message"

# Generated at 2022-06-24 03:40:00.532914
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    from sanic.exceptions import InvalidSignal
    sig = 'SIGUSR1'
    error = InvalidSignal(sig)
    assert error.args[0] == 'Invalid signal: ' + sig
    assert error.status_code == 500

# Generated at 2022-06-24 03:40:03.880773
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('Forbidden')
    assert forbidden.status_code == 403
    assert forbidden.message == 'Forbidden'


# Generated at 2022-06-24 03:40:07.290737
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Error Message')
    except SanicException as e:
        assert e.status_code == 400
        assert e.quiet == True
        assert e.message == 'Error Message'


# Generated at 2022-06-24 03:40:09.634378
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"



# Generated at 2022-06-24 03:40:17.049300
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = InvalidSignal(message='Unknown assignment', status_code=1)
    # print(signal.__getattribute__())
    assert signal.message == 'Unknown assignment'
    assert signal.status_code == 1

if __name__ == '__main__':
    signal = InvalidSignal(message='Unknown assignment', status_code=1)
    # print(signal.__getattribute__())
    assert signal.message == 'Unknown assignment'
    assert signal.status_code == 1

# Generated at 2022-06-24 03:40:22.229350
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200].__name__ == "TestException"
    assert TestException().quiet == False
    assert _sanic_exceptions[200]().quiet == False
    assert _sanic_exceptions[200](quiet=False).quiet == False
    assert _sanic_exceptions[200](quiet=True).quiet == True

# Generated at 2022-06-24 03:40:25.047866
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # todo consider testing this with a mock exception
    try:
        raise PayloadTooLarge('request too large')
    except Exception as exception:
        assert str(exception) == 'request too large'
        assert exception.status_code == 413

# Generated at 2022-06-24 03:40:29.195451
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    msg = "Auth required."
    scheme = "Bearer"
    kwargs = {"realm":"Restricted Area", "myarg": "myval"}
    auth_exc = Unauthorized(message=msg, scheme=scheme, **kwargs)
    assert auth_exc.message == msg
    assert auth_exc.headers == {'WWW-Authenticate': 'Bearer realm="Restricted Area", myarg="myval"'}

# Generated at 2022-06-24 03:40:33.372411
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    #raise exception, then catch it and log the message
    try:
        raise RequestTimeout("test_RequestTimeout")
    except RequestTimeout as e:
        print(e)

# Generated at 2022-06-24 03:40:38.220556
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           "Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert(e.message == "Auth required.")
        assert(e.status_code == 401)
        assert(e.header == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""})

# Generated at 2022-06-24 03:40:40.039211
# Unit test for constructor of class LoadFileException
def test_LoadFileException():

    try:
        raise LoadFileException("SanicException_test")
    except LoadFileException:
        print("LoadFileException_test")


# Generated at 2022-06-24 03:40:43.603721
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("error message", "path", "relative_url")
    except FileNotFound as fe:
        assert fe.path == "path"
        assert fe.relative_url == "relative_url"



# Generated at 2022-06-24 03:40:46.432622
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout(message="Request Timeout", status_code=408, quiet=False)
    assert rt.message == "Request Timeout"
    assert rt.status_code == 408
    assert rt.quiet == False

# Generated at 2022-06-24 03:40:50.645529
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyFileError = PyFileError("test")
    assert pyFileError.args[0] == "could not execute config file %s"
    assert pyFileError.args[1] == "test"

# Generated at 2022-06-24 03:40:53.863077
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('the test message')
    except Exception as e:
        assert e.status_code == 503
        assert e.message == 'the test message'

# Generated at 2022-06-24 03:40:55.922626
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported, match='Method Not Allowed'):
        raise MethodNotSupported("Method Not Allowed", "TRACE", ["GET", "HEAD"])

# Generated at 2022-06-24 03:41:00.263518
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # Testing constructor of class PayloadTooLarge
    try:
        raise PayloadTooLarge('Test PayloadTooLarge')
    except PayloadTooLarge as p:
        assert p.status_code == 413
        assert str(p) == 'Test PayloadTooLarge'
test_PayloadTooLarge()

# Generated at 2022-06-24 03:41:02.291560
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    obj = ServiceUnavailable(message="hello", status_code=503)
    assert obj.status_code == 503
    assert obj.message == "hello"
    assert obj.quiet is True


# Generated at 2022-06-24 03:41:10.697412
# Unit test for constructor of class ContentRangeError

# Generated at 2022-06-24 03:41:15.213200
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('Too many requests')
    except Exception as e:
        assert e.args[0] == 'Too many requests'
        assert e.status_code == 408
        assert e.quiet == True


# Generated at 2022-06-24 03:41:18.257382
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Test URLBuildError")
    except URLBuildError as e:
        msg = e.args[0]
        assert msg == 'Test URLBuildError'

# Generated at 2022-06-24 03:41:20.923003
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error_code:int = 413
    error_msg:str = "Payload Too Large"
    error = PayloadTooLarge(error_msg, error_code)
    assert error.status_code == error_code
    assert error.message == error_msg

# Generated at 2022-06-24 03:41:25.258787
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Exception Message")
    except ServiceUnavailable as e:
        assert e.message == "Exception Message"
        assert e.args[0] == "Exception Message"


# Generated at 2022-06-24 03:41:28.554833
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(410, True)
    class MyTestClass(SanicException):
        pass
    assert issubclass(MyTestClass, SanicException)
    assert MyTestClass.status_code == 410
    assert MyTestClass.quiet is True



# Generated at 2022-06-24 03:41:29.610181
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLBuildError()


# Generated at 2022-06-24 03:41:38.865891
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    # By default, status code 500 should be quiet
    assert _sanic_exceptions[500].quiet is True

    # When we add a new status code, it should be quiet by default
    add_status_code(406)(MyException)
    assert MyException.quiet is True
    assert _sanic_exceptions[406].quiet is True

    add_status_code(407, quiet=False)(MyException)
    assert MyException.quiet is False
    assert _sanic_exceptions[407].quiet is False


# Generated at 2022-06-24 03:41:40.936672
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = InvalidSignal("Error", status_code=404)
    assert signal.status_code == 404
    assert signal.message == "Error"

# Generated at 2022-06-24 03:41:43.209962
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage(message = "Invalid message")
    assert error.message == "Invalid message"
    assert error.status_code == 400
    assert error.quiet == True



# Generated at 2022-06-24 03:41:50.524439
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404, quiet=True)
    class TestAddStatusCode(SanicException):
        """
        **Status**: 404
        """
        pass

    assert TestAddStatusCode.status_code == 404
    assert TestAddStatusCode.quiet

    @add_status_code(500)
    class TestAddStatusCode2(SanicException):
        """
        **Status**: 500
        """
        pass

    assert TestAddStatusCode2.status_code == 500
    assert TestAddStatusCode2.quiet == False

    @add_status_code(501)
    class TestAddStatusCode3(SanicException):
        """
        **Status**: 501
        """
        pass

    assert TestAddStatusCode3.status_code == 501
    assert TestAddStatusCode3.quiet == True


# Generated at 2022-06-24 03:41:58.550947
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    status_code = 404
    path = '/home/file'
    relative_url = 'test.txt'
    file_not_found = FileNotFound(status_code, path, relative_url)
    assert file_not_found.path == '/home/file'
    assert file_not_found.relative_url == 'test.txt'
    assert file_not_found.status_code == 404
    assert str(file_not_found) == "404 File Not Found: /home/file (test.txt)"

#Unit test for constructor of class SanicException

# Generated at 2022-06-24 03:42:00.198611
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert MethodNotSupported("test Message", "test method", ["test allowed method"])

# Generated at 2022-06-24 03:42:06.628532
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Constructor of class URLBuildError
    # Assert that the constructor works
    try:
        inst = URLBuildError(message="error")
        assert inst.message == "error"
    except:
        assert False
    # Inheritance test
    # Assert that this class inherits class Exception
    try:
        assert issubclass(URLBuildError,Exception)
    except:
        assert False 

# Generated at 2022-06-24 03:42:09.017192
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    test_client = RequestTimeout("408 Request Timeout")
    assert test_client.args == ("408 Request Timeout",)



# Generated at 2022-06-24 03:42:11.433008
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as err:
        raise InvalidSignal("Asynchronous event loop is not running.")
    assert err.value.message == "Asynchronous event loop is not running."



# Generated at 2022-06-24 03:42:13.994493
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as e:
        assert str(e) == STATUS_CODES[500].decode("utf8")

# Generated at 2022-06-24 03:42:15.889821
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Error message")
    except Forbidden as error:
        assert error.status_code == 403

# Generated at 2022-06-24 03:42:20.065544
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(408)
    class TimedOut(SanicException):
        pass

    assert _sanic_exceptions[408] == TimedOut
    assert _sanic_exceptions[408]().status_code == 408



# Generated at 2022-06-24 03:42:25.013023
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        # Test constructor with default Exception message.
        raise InvalidSignal()
    except InvalidSignal as ex:
        assert str(ex) == 'InvalidSignal'

    try:
        raise InvalidSignal('specific message')
    except InvalidSignal as ex:
        assert str(ex) == 'specific message'

# Generated at 2022-06-24 03:42:26.039670
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage.status_code==400

# Generated at 2022-06-24 03:42:38.628213
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # no auth-scheme:
    try:
        raise Unauthorized("Auth required.")
    except Unauthorized as err:
        assert err.message == "Auth required."
        assert err.headers == {}
        assert err.status_code == 401

    # with auth-scheme, but no realm
    try:
        raise Unauthorized("Auth required.", scheme="Basic")
    except Unauthorized as err:
        assert err.message == "Auth required."
        assert err.headers == {}
        assert err.status_code == 401

    # with auth-scheme and realm
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as err:
        assert err.message == "Auth required."

# Generated at 2022-06-24 03:42:41.985796
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported("error message", "POST", ["PUT"])
    assert exception.quiet == True
    assert exception.headers["Allow"] == "PUT"
    assert exception.status_code == 405

# Generated at 2022-06-24 03:42:44.817630
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Initialized class HeaderExpectationFailed with message and status_code
    exception = HeaderExpectationFailed('Invalid header input', status_code=417)
    assert exception.status_code == 417


# Generated at 2022-06-24 03:42:49.928721
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("PayloadTooLarge Exception Message", 10)
    except PayloadTooLarge as ex:
        assert ex.message == "PayloadTooLarge Exception Message"
        assert ex.status_code == 413
        assert ex.headers.get('Content-Length') == '10'


# Generated at 2022-06-24 03:42:59.081635
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("This is a test Exception")
    except HeaderNotFound as e:
        print(e.status_code)
        print(e.message)
        print(e.__class__.__name__)
        print('Printing exception from test_HeaderNotFound')
        print(e)
        assert e.status_code == 400
        assert e.message == "This is a test Exception"
        assert e.__class__.__name__ == "HeaderNotFound"
        assert str(e) == "This is a test Exception"
        assert repr(e) == "HeaderNotFound: This is a test Exception"
    else:
        print('Expected Exception is not raised')

# Generated at 2022-06-24 03:43:03.634167
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('FileNotFound', 'path', 'url')
    except FileNotFound as e:
        assert e.path == 'path'
        assert e.relative_url == 'url'
        assert e.status_code == 404
        assert e.message == 'FileNotFound'
        assert e.quiet is True

# Generated at 2022-06-24 03:43:06.978656
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('123')
    except FileNotFound as e:
        assert e.message == '123'
        assert e.path == undefined
        assert e.relative_url == undefined


# Generated at 2022-06-24 03:43:11.125438
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('hello world', 500)
    except ServerError as se:
        assert se.status_code == 500
        assert se.strerror == 'hello world'


# Generated at 2022-06-24 03:43:17.700360
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as exc_info:
        abort(404, message="not found")
    assert exc_info.value.status_code == 404
    with pytest.raises(SanicException) as exc_info:
        abort(9000, message="not found")
    assert exc_info.value.status_code == 9000

# Generated at 2022-06-24 03:43:26.868466
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class A(SanicException):
        pass

    assert A.status_code == 400
    assert A().status_code == 400
    assert A(quiet=True).quiet

    @add_status_code(401)
    class B(SanicException):
        pass

    assert B.status_code == 401
    assert B().status_code == 401
    assert B(quiet=True).quiet

    @add_status_code(500)
    class C(SanicException):
        pass

    assert C.status_code == 500
    assert C().status_code == 500
    assert not C(quiet=True).quiet

    # Explicit quiet is set, even if the default is to be quiet
    @add_status_code(401)
    class D(SanicException):
        pass



# Generated at 2022-06-24 03:43:32.946478
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # file_not_found = FileNotFound('', '', '')
    # assert file_not_found.path == ''
    # assert file_not_found.relative_url == ''
    # assert file_not_found.status_code == 404
    # assert file_not_found.quiet is True
    assert True

# Generated at 2022-06-24 03:43:37.314273
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("custom exception")
        assert "my_custom_exception_error_message"
    except SanicException as e:
        assert e.args[0] == "custom exception"


# Generated at 2022-06-24 03:43:40.557920
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test")
    except InvalidSignal as e:
        print(e)

# Generated at 2022-06-24 03:43:42.488239
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error_test = URLBuildError(message="Unit Test")
    assert str(error_test) == "Unit Test"

# Generated at 2022-06-24 03:43:45.668699
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('test', '/usr/bin', '/not_found')
    except Exception as e:
        assert e.status_code == 404
        assert e.path == '/usr/bin'
        assert e.relative_url == '/not_found'

# Generated at 2022-06-24 03:43:53.796931
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge()
    assert exception.status_code == 413
    exception = PayloadTooLarge("message", status_code=500)
    assert exception.status_code == 500
    exception = PayloadTooLarge("message", status_code=404, quiet=True)
    assert exception.status_code == 404
    exception = PayloadTooLarge("message", status_code=404, quiet=False)
    assert exception.status_code == 404

# Generated at 2022-06-24 03:43:57.565929
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed = HeaderExpectationFailed("a")
    assert header_expectation_failed

if __name__ == '__main__':
    test_HeaderExpectationFailed()

# Generated at 2022-06-24 03:44:00.381096
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = ServerError('Test message')
    assert exception
    assert exception.status_code == 500
    assert exception.message == 'Test message'
    assert exception.quiet == False


# Generated at 2022-06-24 03:44:03.169469
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    code = 503
    msg = "Serve unavailable"
    try:
        raise ServiceUnavailable(message=msg, status_code=code)
    except ServiceUnavailable as err:
        assert err.status_code == code and err.message == msg

# Generated at 2022-06-24 03:44:03.864706
# Unit test for constructor of class NotFound
def test_NotFound():
    pass

# Generated at 2022-06-24 03:44:07.908956
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f = FileNotFound(message="message", path="path", relative_url="relative_url")
    assert f.message == "message"
    assert f.path == "path"
    assert f.relative_url == "relative_url"

# Generated at 2022-06-24 03:44:11.014360
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == "Request Timeout"


# Generated at 2022-06-24 03:44:14.440084
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    """
    Test case for Content-Range error.
    """
    error = ContentRangeError('test', 'content-range')
    assert error.headers == {'Content-Range': 'bytes */content-range'}

# Generated at 2022-06-24 03:44:24.690349
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    "Unauthorized" is the exception to be raised when you want to request
    user authentication.
    """
    # If kwargs is not used, the header "WWW-Authenticate" would be empty
    try:
        raise Unauthorized("Auth required", scheme="Bearer")
    except Unauthorized as expt:
        assert expt.headers is not None
        assert expt.headers["WWW-Authenticate"] == "Bearer"
        assert str(expt) == "Auth required"
        assert expt.status_code == 401
    try:
        raise Unauthorized("Auth required", scheme="Basic")
    except Unauthorized as expt:
        assert expt.headers is not None
        assert expt.headers["WWW-Authenticate"] == "Basic"
        assert str(expt) == "Auth required"

# Generated at 2022-06-24 03:44:26.233764
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "Headers message"
    hnf = HeaderNotFound(message=message)
    assert hnf.message == message

# Generated at 2022-06-24 03:44:31.275467
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout", 408)
    except RequestTimeout as e:
        assert e.message == "Request Timeout"
        assert e.status_code == 408


# Generated at 2022-06-24 03:44:35.221622
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal("Invalid Signal!") != None
    assert InvalidSignal("Invalid Signal!").status_code != None
    assert InvalidSignal("Invalid Signal!").status_code == 500


# Generated at 2022-06-24 03:44:37.053813
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(status_code=999)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 999

# Generated at 2022-06-24 03:44:39.264586
# Unit test for constructor of class Forbidden
def test_Forbidden():
    """
    test_Forbidden()
    """
    exception = Forbidden("Test for status code 403")
    assert exception.status_code == 403


# Generated at 2022-06-24 03:44:43.886753
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('There is an internal Server Error.')
    except ServerError as e:
        assert e.status_code == 500
        assert str(e) == 'There is an internal Server Error.'
    else:
        raise


# Generated at 2022-06-24 03:44:47.977177
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Hello', status_code=400)
    except SanicException as e:
        assert e.args == ('Hello',)
        assert e.status_code == 400
        assert e.message == 'Hello'



# Generated at 2022-06-24 03:45:00.022532
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 100
    assert NewException.quiet is False
    assert _sanic_exceptions[100] == NewException

    @add_status_code(200)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 200
    assert NewException.quiet is True
    assert _sanic_exceptions[200] == NewException

    @add_status_code(300, quiet=True)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 300
    assert NewException.quiet is True
    assert _sanic_exceptions[300] == NewException


# Generated at 2022-06-24 03:45:01.462633
# Unit test for function abort
def test_abort():
    def dummy_func():
        abort(400, "Bad request")

    with pytest.raises(InvalidUsage):
        dummy_func()

    def dummy_func2():
        abort(503)

    with pytest.raises(ServiceUnavailable):
        dummy_func2()

# Generated at 2022-06-24 03:45:07.424040
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_message = "Payload Too Large"
    test_obj = PayloadTooLarge(test_message, status_code=413)
    # Assert message is set correctly
    assert test_obj.message == test_message
    # Assert status_code is set correctly
    assert test_obj.status_code == 413


# Generated at 2022-06-24 03:45:12.883957
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        # This statement should raise a HeaderExpectationFailed exception,
        # which is a subclass of SanicException
        raise HeaderExpectationFailed("Expectation Failed")
    except SanicException as ex:
        # The base class SanicException
        assert ex.__class__ is HeaderExpectationFailed

# Generated at 2022-06-24 03:45:21.187586
# Unit test for function abort
def test_abort():
    assert issubclass(abort(400).__class__, InvalidUsage)
    assert issubclass(abort(401).__class__, Unauthorized)
    assert issubclass(abort(402).__class__, SanicException)
    assert issubclass(abort(403).__class__, Forbidden)
    assert issubclass(abort(404).__class__, NotFound)
    assert issubclass(abort(405).__class__, MethodNotSupported)
    assert issubclass(abort(405).headers['Allow'], str)
    assert issubclass(abort(406).__class__, SanicException)
    assert issubclass(abort(407).__class__, SanicException)
    assert issubclass(abort(408).__class__, RequestTimeout)

# Generated at 2022-06-24 03:45:23.393152
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("No permission")
    except Forbidden as e:
        assert e.status_code == 403
        raise
test_Forbidden()

# Generated at 2022-06-24 03:45:29.668414
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    error = MethodNotSupported(message="test message", method="method",
                               allowed_methods=["allowed method"])
    assert error.message == "test message"
    assert error.headers == {"Allow": "allowed method"}


# Generated at 2022-06-24 03:45:35.184032
# Unit test for constructor of class SanicException
def test_SanicException():
    message = 'test message'
    status_code = 400
    sanic_exception = SanicException(message, status_code)
    assert str(sanic_exception) == message
    assert sanic_exception.status_code == status_code
    assert sanic_exception.quiet is None


# Generated at 2022-06-24 03:45:37.552473
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    print("Testing constructor of class LoadFileException")
    LoadFileException("This is a test")


# Generated at 2022-06-24 03:45:40.700346
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Not Found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "Not Found"
        assert e.quiet is True


# Generated at 2022-06-24 03:45:45.499807
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge(message='Test Message', status_code=413).payload == "Test Message"
    assert PayloadTooLarge(message='Test Message', status_code=413).status_code == 413
    assert PayloadTooLarge(message='Test Message', status_code=413).quiet == True


# Generated at 2022-06-24 03:45:50.728982
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Not Supported", "GET", {"PUT", "POST"})
    except MethodNotSupported as e:
        print("{}: {}".format(e.__class__.__name__, e))
        print("Allow: {}".format(e.headers["Allow"]))



# Generated at 2022-06-24 03:45:53.836282
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported("GET, POST, PUT", "GET", ["POST", "PUT"])
    assert mns.status_code == 405
    assert "Allow" in mns.headers

# Generated at 2022-06-24 03:45:58.715853
# Unit test for function add_status_code
def test_add_status_code():
    class TestException(SanicException):
        pass
    add_status_code(999)(TestException)
    assert _sanic_exceptions[999] == TestException

# Generated at 2022-06-24 03:46:00.783056
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("Not found", status_code=404)


# Generated at 2022-06-24 03:46:03.456032
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    error = HeaderExpectationFailed("Expectation failed")
    assert error.status_code == 417
    assert str(error) == "Expectation failed"

# Generated at 2022-06-24 03:46:07.002763
# Unit test for constructor of class NotFound
def test_NotFound():
    notfound = NotFound("not found")
    assert notfound.args[0] == "not found"
    assert notfound.status_code == 404
    assert notfound.quiet == True


# Generated at 2022-06-24 03:46:18.342480
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    assert FileNotFound("my message", "mypath", "myrelativeurl")
    assert FileNotFound("my message", "mypath", "myrelativeurl").message == "my message"
    assert FileNotFound("my message", "mypath", "myrelativeurl").path == "mypath"
    assert FileNotFound("my message", "mypath", "myrelativeurl").relative_url == "myrelativeurl"
    assert FileNotFound("my message", "mypath", "myrelativeurl") == FileNotFound("my message", "mypath", "myrelativeurl")
    assert FileNotFound("my message", "mypath", "myrelativeurl") != FileNotFound("my message2", "mypath", "myrelativeurl")

# Generated at 2022-06-24 03:46:22.225114
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid message")
    except InvalidSignal as e:
        assert e.status_code == 500
        assert e.message == "Invalid message"


# Generated at 2022-06-24 03:46:28.041953
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class ClassTest(Exception):
        pass
    assert issubclass(ClassTest, SanicException)
    assert _sanic_exceptions[400] == ClassTest
    instance = ClassTest()
    assert instance.status_code == 400
    assert instance.quiet == True


# Generated at 2022-06-24 03:46:32.860761
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        status_code = 413
        message = 'Payload Too Large'
        raise PayloadTooLarge(message, status_code)
    except PayloadTooLarge as exc:
        assert exc.status_code == status_code
        assert exc.message == message


# Generated at 2022-06-24 03:46:36.390958
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    class_MethodNotSupported = MethodNotSupported("error message", "method", "allowed_methods")
    assert class_MethodNotSupported.message == "error message"
    assert class_MethodNotSupported.headers == {"Allow": "allowed_methods"}

# Generated at 2022-06-24 03:46:38.276469
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    ex = InvalidRangeType("test", "content_range")
    assert ex.message == "test"
    assert ex.content_range == "content_range"

# Generated at 2022-06-24 03:46:48.216879
# Unit test for function add_status_code
def test_add_status_code():
    """
    All exceptions should inherit from SanicException
    """
    assert issubclass(NotFound, SanicException)
    assert issubclass(InvalidUsage, SanicException)
    assert issubclass(MethodNotSupported, SanicException)
    assert issubclass(ServerError, SanicException)
    assert issubclass(ServiceUnavailable, SanicException)
    assert issubclass(URLBuildError, ServerError)
    assert issubclass(FileNotFound, NotFound)
    assert issubclass(RequestTimeout, SanicException)
    assert issubclass(PayloadTooLarge, SanicException)
    assert issubclass(HeaderNotFound, InvalidUsage)
    assert issubclass(ContentRangeError, SanicException)
    assert issubclass(HeaderExpectationFailed, SanicException)

# Generated at 2022-06-24 03:46:59.425090
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as exc:
        assert exc.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""


# Generated at 2022-06-24 03:47:03.409238
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError(Exception())
    except URLBuildError as error:
        assert URLBuildError == type(error)
        assert isinstance(error, Exception)
        assert isinstance(error, ServerError)
        assert isinstance(error, SanicException)


# Generated at 2022-06-24 03:47:07.562499
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("expectation failed")
    except HeaderExpectationFailed as e:
        assert "expectation failed" == e.message
        assert 417 == e.status_code

# Generated at 2022-06-24 03:47:09.157588
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exc = URLBuildError("test")
    assert exc.status_code == 500
    assert exc.args == ("test",)

# Generated at 2022-06-24 03:47:12.413064
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as excinfo:
        raise ServiceUnavailable('something')
    assert excinfo.traceback[-1].line == 'raise ServiceUnavailable(\'something\')'
    assert excinfo.traceback[-3].line == '@add_status_code(503)'

# Generated at 2022-06-24 03:47:17.917668
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # For the first case the status_code is not given and the error message that is
    # displayed is the default one.
    error = Forbidden("Forbidden")
    assert error.status_code == 403
    assert error.message == "Forbidden"

    error = Forbidden("Forbidden", status_code=503)
    assert error.status_code == 503
    assert error.message == "Forbidden"

# Generated at 2022-06-24 03:47:26.049037
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    """
    Test the constructor of class ContentRangeError.
    """
    # Test with valid input
    with pytest.raises(ContentRangeError) as excinfo:
        test_range = slice(0, 50, 2)
        raise ContentRangeError("Range Not Satisfiable", test_range)

    # Assert that error message is "Range Not Satisfiable"
    assert excinfo.value.args[0] == "Range Not Satisfiable"

    # Assert that "Content-Range" header is "bytes */100"
    assert excinfo.value.headers["Content-Range"] == "bytes */100"
