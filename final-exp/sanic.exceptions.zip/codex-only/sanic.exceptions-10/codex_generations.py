

# Generated at 2022-06-24 03:37:12.741686
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    error = Unauthorized(message="Auth required.", scheme="Basic", realm="Restricted Area")
    assert error.status_code == 401
    assert error.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

    error = Unauthorized(message="Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert error.headers == {
        "WWW-Authenticate": 'Digest realm="Restricted Area", algorithm="MD5", nonce="abcdef", qop="auth, auth-int", opaque="zyxwvu"'
    }

    error = Unauthorized(message="Auth required.", scheme="Bearer")
    assert error.headers == {"WWW-Authenticate": 'Bearer'}

    error

# Generated at 2022-06-24 03:37:15.784878
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as exc_info:
        raise SanicException("hi", status_code=500)

    assert exc_info.value.status_code == 500



# Generated at 2022-06-24 03:37:18.070101
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    ube = URLBuildError("Unit test for URLBuildError")
    assert isinstance(ube, SanicException)

# Generated at 2022-06-24 03:37:25.366724
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except SanicException as e:
        assert e.message == "Bad Request"
        assert e.status_code == 400

    try:
        abort(404)
    except NotFound as e:
        assert e.message == "Not Found"
        assert e.status_code == 404

    try:
        abort(500, "My custom message")
    except SanicException as e:
        assert e.message == "My custom message"
        assert e.status_code == 500

# Generated at 2022-06-24 03:37:29.531499
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("") # the message is not used
    except LoadFileException as e:
        pass
    assert isinstance(e, LoadFileException)

# Generated at 2022-06-24 03:37:31.381624
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Bad data")
    except:
        pass

# Generated at 2022-06-24 03:37:38.383634
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError(message="error", content_range=130)
    assert e.headers == {"Content-Range": "bytes */130"}

# Generated at 2022-06-24 03:37:43.306330
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    content_range = "bytes 0-4/8"
    message = content_range
    test = InvalidRangeType(message, content_range)
    assert test.__str__() == message
    assert test.headers == {"Content-Range": "bytes */8"}

# Generated at 2022-06-24 03:37:48.370097
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    expect_code = 401
    expect_message = 'Auth required.'
    expect_scheme = 'Basic'
    expect_realm = 'Restricted Area'
    try:
        raise Unauthorized(expect_message, scheme=expect_scheme, realm=expect_realm)
    except Unauthorized as e:
        assert e.status_code == expect_code
        assert e.message == expect_message
        assert e.headers['WWW-Authenticate'] == expect_scheme + ' realm="' + expect_realm + '"'

# Generated at 2022-06-24 03:37:54.375388
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # Test for __init__() constructor with no parameter
    with pytest.raises(TypeError):
        LoadFileException()
    # Test for __init__() constructor with 0-1 parameters
    with pytest.raises(TypeError):
        LoadFileException("")
    # Test for __init__() constructor with more than 1 parameters
    with pytest.raises(TypeError):
        LoadFileException("", "")
    # Test for __init__() constructor with correct parameters
    with pytest.raises(SanicException):
        LoadFileException("test")



# Generated at 2022-06-24 03:37:57.181205
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        #raise RequestTimeout('408', 'Request Timeout')
        raise RequestTimeout('Request Timeout', 408)
    except RequestTimeout:
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:37:59.617223
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge(max_size=100)
    except PayloadTooLarge as e:
        assert str(e) == 'max_size=100'

# Generated at 2022-06-24 03:38:03.871520
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise(InvalidRangeType("Invalid range", None))
    except InvalidRangeType as e:
        assert e.message == "Invalid range"
        assert e.content_range == None
        assert e.status_code == 416


# Generated at 2022-06-24 03:38:05.281828
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError):
        raise URLBuildError('Exception message')

# Generated at 2022-06-24 03:38:09.907466
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Expected exception raised
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-24 03:38:13.539529
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    """
    A test for the constructor of class URLBuild().
    Test URLBuildError() --> ServerError() --> SanicException() --> Exception()
    """
    try:
        raise URLBuildError('No url object')
    except Exception as e:
        assert str(e) == 'No url object'
        assert type(e) is URLBuildError


# Generated at 2022-06-24 03:38:15.874179
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound(message="NotFound")
    assert exception.status_code == 404
    assert exception.message == "NotFound"
    

# Generated at 2022-06-24 03:38:17.948636
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found_instance = NotFound("404 Error")
    assert not_found_instance.status_code == 404

# Generated at 2022-06-24 03:38:20.722509
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("test")
    except Exception as e:
        assert e.status_code == 400
        assert e.message == "test"


# Generated at 2022-06-24 03:38:32.312988
# Unit test for function add_status_code
def test_add_status_code():
    class test_1(SanicException):
        pass

    class test_2(SanicException):
        pass

    test_1 = add_status_code(200, None)(test_1)
    assert test_1.status_code == 200
    assert test_1.quiet == False

    test_2 = add_status_code(201, None)(test_2)
    assert test_2.status_code == 201
    assert test_2.quiet == True

    test_3 = add_status_code(500, False)(ServerError)
    assert test_3.status_code == 500
    assert test_3.quiet == False

    test_4 = add_status_code(500, None)(ServerError)
    assert test_4.status_code == 500
    assert test_4.quiet == True

# Generated at 2022-06-24 03:38:33.006519
# Unit test for constructor of class NotFound
def test_NotFound():
    pass

# Generated at 2022-06-24 03:38:35.301192
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge("Payload Too Large")
    assert exception.status_code == 413
    assert exception.message == "Payload Too Large"
    assert str(exception) == "Payload Too Large"

# Generated at 2022-06-24 03:38:40.281591
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Positive test case
    try:
        try:
            raise FileNotFound("FileNotFound", "path", "relative_url")
        except FileNotFound as e:
            assert e.args[0] == "FileNotFound"
            assert e.path == "path"
            assert e.relative_url == "relative_url"
    except FileNotFound as e:
        assert e.args[0] == "FileNotFound"
        assert e.path == "path"
        assert e.relative_url == "relative_url"


# Generated at 2022-06-24 03:38:45.758859
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Make sure we can construct a PyFileError with valid input
    try:
        exc = PyFileError("foo")
    except Exception:
        assert False
    # Check that we get what we put in.
    assert str(exc) == "could not execute config file foo", \
        "Message should be: could not execute config file foo"

# Generated at 2022-06-24 03:38:51.699266
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # test the object ServiceUnavailable
    test_503 = ServiceUnavailable("Test", status_code=503)
    assert test_503.status_code == 503
    assert test_503.__str__() == "Test"



# Generated at 2022-06-24 03:38:55.482852
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    t = RequestTimeout("Request Timeout", 408)
    assert t.status_code == 408
    assert t.message == "Request Timeout"
    assert t.quiet is True


# Generated at 2022-06-24 03:38:58.293805
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Test SanicException')
    except SanicException as e:
        assert e.status_code is None
        assert e.quiet is False


# Generated at 2022-06-24 03:39:03.213426
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = 'Not found'
    status_code = 404
    quiet = True
    class_inst = NotFound(message=msg, status_code=status_code, quiet=quiet)
    assert isinstance(class_inst, SanicException)
    assert class_inst.status_code == status_code
    assert class_inst.quiet == quiet
    assert str(class_inst) == msg


# Generated at 2022-06-24 03:39:05.015084
# Unit test for constructor of class PyFileError
def test_PyFileError():
    exceptions.PyFileError("file")

# Generated at 2022-06-24 03:39:08.528872
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

# Generated at 2022-06-24 03:39:09.264252
# Unit test for constructor of class ServerError
def test_ServerError():
    pass

# Generated at 2022-06-24 03:39:12.105014
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(
            "message", silent=True
        )
    except ServiceUnavailable as e:
        assert str(e) == 'message'



# Generated at 2022-06-24 03:39:13.898704
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
	i = InvalidUsage("message",status_code=400)
	assert i.status_code == 400

# Generated at 2022-06-24 03:39:16.065202
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError):
        raise ServerError(message="You have an error", status_code=500)



# Generated at 2022-06-24 03:39:20.584461
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="ServiceUnavailable", status_code=503, quiet=True)
    except ServiceUnavailable as e:
        assert(e.message == 'ServiceUnavailable')
        assert(e.status_code == 503)
        assert(e.quiet == True)
    except:
        assert(True)

test_ServiceUnavailable()

# Generated at 2022-06-24 03:39:25.190920
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Create instance of Forbidden, passing in a message and a status code
    test = Forbidden("Forbidden", status_code=403)
    assert test.status_code == 403
    assert test.message == 'Forbidden'
    assert str(test) == 'Forbidden'


# Generated at 2022-06-24 03:39:28.628571
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound(message=404, status_code=404, quiet=True)
    assert not_found.status_code == 404
    assert not_found.message == 404
    assert not_found.quiet == True


# Generated at 2022-06-24 03:39:32.666519
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("error")
    # print(forbidden)
    # print(forbidden.message)
    # print(forbidden.status_code)
    assert str(forbidden) == 'error'
    assert forbidden.message == 'error'
    assert forbidden.status_code == 403


# Generated at 2022-06-24 03:39:35.162554
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError("file")
    assert e.args == ("could not execute config file %s", "file")
    assert str(e) == 'could not execute config file file'

# Generated at 2022-06-24 03:39:38.475610
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Sevice Down", True)
    except ServiceUnavailable as ex:
        assert ex.status_code == 503
        assert ex.quiet == True
        assert str(ex) == "Sevice Down"


# Generated at 2022-06-24 03:39:41.205058
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    ab = PayloadTooLarge("Payload Too Large", 413)
    assert ab.message == "Payload Too Large"
    assert ab.status_code == 413

# Generated at 2022-06-24 03:39:45.237878
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exception = InvalidRangeType("error", None)
    assert exception.args == ("error",)
    assert exception.status_code == 416
    assert exception.message == "error"
    assert exception.headers["Content-Range"] == "bytes */None"

# Generated at 2022-06-24 03:39:51.321986
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    a = ServiceUnavailable()
    assert isinstance(a, SanicException)
    assert a.status_code == 503


if __name__ == "__main__":
    test_ServiceUnavailable()

# Generated at 2022-06-24 03:39:59.013866
# Unit test for constructor of class NotFound
def test_NotFound():
    # use default status_code=404
    nf1 = NotFound(message="a")
    assert nf1.status_code==404
    assert nf1.quiet==True
    # not use default status_code=404
    nf2 = NotFound(message="b",status_code=4444)
    assert nf2.status_code==4444
    # use quiet=False, not use default
    nf3 = NotFound(message="b",quiet=False,status_code=404)
    assert nf3.quiet==False
    # use quiet=True
    nf4 = NotFound(message="b",quiet=True,status_code=404)
    assert nf4.quiet==True
    # use default quiet=True, not use default status_code=404

# Generated at 2022-06-24 03:40:00.122016
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("test_message")

# Generated at 2022-06-24 03:40:05.140306
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "Invalid"
    status_code = 400
    exception = SanicException(message, status_code)

    assert exception.status_code == status_code
    assert str(exception) == message


# Generated at 2022-06-24 03:40:11.134313
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("this is a test")
    except InvalidSignal as e:
        assert e.status_code == 500, \
            "status_code {} is not 500".format(e.status_code)
        assert e.quiet == True, \
            "quiet {} is not True".format(e.quiet)
        assert e.args[0] == "this is a test"
        assert e.__class__.__name__ == "InvalidSignal"
    else:
        assert False, "Expected to raise InvalidSignal"

# Generated at 2022-06-24 03:40:16.852254
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}


# Generated at 2022-06-24 03:40:21.737871
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Create the request timeout instance
    request_timeout = RequestTimeout('Request timeout')
    # Check the status code is correct
    assert request_timeout.status_code == 408

# Generated at 2022-06-24 03:40:23.877109
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal()
    except InvalidSignal as e:
        assert e.status_code == None
        assert e.message == None
        assert e.quiet == None

# Generated at 2022-06-24 03:40:25.717890
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test")
    except ServiceUnavailable as e:
        assert e.message == "Test"

# Generated at 2022-06-24 03:40:27.813334
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Testing for InvalidSignal")
    except SanicException as e:
        assert str(e) == 'Testing for InvalidSignal'


# Generated at 2022-06-24 03:40:33.307495
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as exception:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")

    assert "WWW-Authenticate" in exception.value.headers
    assert exception.value.status_code == 401


# Generated at 2022-06-24 03:40:33.938146
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLBuildError('a','b','c')

# Generated at 2022-06-24 03:40:35.810714
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException()
    assert exception.status_code == 500
    assert exception.message == 'Internal Server Error'

# Generated at 2022-06-24 03:40:37.439354
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout(None)


# Generated at 2022-06-24 03:40:42.051278
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed = HeaderExpectationFailed(message="error", status_code=417)
    assert header_expectation_failed.message == "error", "Exception should be raised with message error"
    assert header_expectation_failed.status_code == 417, "Exception should be raised with status code 417"


# Generated at 2022-06-24 03:40:46.786059
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    If passing a valid message,
    then you'll get back a ServiceUnavailable object
    """
    ### Arrange
    message = "Invalid Error"
    ### Act
    result = ServiceUnavailable(message, 503)
    ### Assert
    assert result.status_code == 503
    assert result.message == message


# Generated at 2022-06-24 03:40:51.038474
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("error message here")
    except ServerError as serverError:
        assert serverError.status_code == 500
        assert serverError.message == "error message here"


# Generated at 2022-06-24 03:40:54.021512
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="Header Expectation Failed")
    except HeaderExpectationFailed as err:
        assert(err.status_code == 417)
        assert(err.message == "Header Expectation Failed")

# Generated at 2022-06-24 03:41:00.884221
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # check if scheme is specified 
    scheme = "Basic"
    realm = "Restricted Area"
    message = "Auth required."

    try:
        raise Unauthorized(message, scheme=scheme, realm=realm)

    except Unauthorized as e:
        assert e.message == message
        assert e.scheme == scheme
        assert e.realm == realm
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == f"{scheme} realm={realm}"


# Generated at 2022-06-24 03:41:01.840212
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("message")
    assert forbidden is not None

# Generated at 2022-06-24 03:41:05.045408
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge("message", "status_code")
    assert isinstance(payload_too_large, SanicException)
    assert payload_too_large.status_code == 413


# Generated at 2022-06-24 03:41:11.854463
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('test', 417)
    except HeaderExpectationFailed as e:
        assert str(e) == 'test'
        assert e.status_code == 417
    try:
        raise HeaderExpectationFailed('test')
    except HeaderExpectationFailed as e:
        assert str(e) == 'test'
        assert e.status_code == 417

# Generated at 2022-06-24 03:41:13.291892
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    ex = LoadFileException("testing", "some_exception")
    asse

# Generated at 2022-06-24 03:41:20.297294
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # Exception is raised
    with pytest.raises(InvalidUsage) as excinfo:
        raise HeaderNotFound("HeaderNotFound")
    # We get what we expect
    assert excinfo.type == HeaderNotFound
    assert str(excinfo.value) == "HeaderNotFound"
    assert excinfo.value.status_code == 400


# Generated at 2022-06-24 03:41:24.903007
# Unit test for constructor of class PyFileError
def test_PyFileError():
    """Tests for constructor of class PyFileError"""
    with pytest.raises(PyFileError, match="could not execute config file /home/test/test.py"):
        raise PyFileError("/home/test/test.py")

# Generated at 2022-06-24 03:41:26.772169
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    abc = 'abc'
    try:
        LoadFileException(abc)
        assert 1 == 0
    except Exception:
        assert 1 == 1


# Generated at 2022-06-24 03:41:29.605125
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("error", "404")
    except ServerError as error:
        assert error.status_code is 500
        assert error.message == "error"

# Generated at 2022-06-24 03:41:33.644210
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('test')
        return False
    except InvalidSignal as e:
        assert str(e) == 'test'
        return True


# Generated at 2022-06-24 03:41:43.635045
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class NewException(SanicException):
        """
        **Status**: 123
        """
        pass
    assert NewException.status_code == 123
    assert 123 in _sanic_exceptions
    assert "123" in str(NewException)
    assert "123" in str(NewException("haha"))
    assert "123" in repr(NewException)
    assert "123" in repr(NewException("haha"))
    assert NewException.__doc__ == "**Status**: 123"

    @add_status_code(123, quiet=True)
    class NewException2(SanicException):
        """
        **Status**: 123
        """
        pass
    assert NewException2.status_code == 123
    assert 123 in _sanic_exceptions

# Generated at 2022-06-24 03:41:46.304970
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    obj = URLBuildError("This is an exception")
    assert obj.message == "This is an exception"
    assert obj.status_code == 500
    assert obj.headers == None


# Generated at 2022-06-24 03:41:48.845463
# Unit test for constructor of class SanicException
def test_SanicException():
    status_code = 500
    message = "test"
    se = SanicException(message, status_code)
    assert se.status_code == status_code
    assert se.message == message

# Generated at 2022-06-24 03:41:53.910362
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("File doesn't exist", "filename")
    except LoadFileException:
        # raise
        print('"{}" raised'.format(LoadFileException.__name__))


if __name__ == "__main__":
    test_LoadFileException()

# Generated at 2022-06-24 03:41:55.784166
# Unit test for constructor of class PyFileError
def test_PyFileError():
    obj = PyFileError("test_file.py")

# Generated at 2022-06-24 03:41:58.771640
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    message = "Test Message"
    try:
        raise InvalidUsage(message)
        assert True
    except InvalidUsage as e:
        assert str(e) == message

# Generated at 2022-06-24 03:42:01.333465
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pltl = PayloadTooLarge('payload too large', 50)
    assert pltl.status_code == 413
    assert pltl.quiet == True

# Generated at 2022-06-24 03:42:02.271447
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError('test', 1)

# Generated at 2022-06-24 03:42:07.061518
# Unit test for constructor of class NotFound
def test_NotFound():
    message='Not Found'
    status_code=404
    try:
        raise NotFound(message,status_code)
    except NotFound:
        pass
    else:
        assert False,'NotFound should be raised'


# Generated at 2022-06-24 03:42:10.372242
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert URLBuildError("message_test")
    assert URLBuildError("message_test", "args_test")
    assert URLBuildError("message_test", "value_test", "field_test")

# Generated at 2022-06-24 03:42:13.031614
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request timeout")
    except RequestTimeout as ex:
        assert ex.status_code == 408
        assert ex.message == "Request timeout"


# Generated at 2022-06-24 03:42:15.516045
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = None
    try:
        PyFileError(file)
    except Exception as e:
        assert str(e) == f"could not execute config file {file}"

# Generated at 2022-06-24 03:42:20.164506
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = "Not Found"
    status_code = 404
    nf = NotFound(msg,status_code)
    nf_exception = nf.__str__()
    assert nf_exception == msg
    assert nf.status_code == status_code

# Generated at 2022-06-24 03:42:25.457891
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("My message", "POST", ["GET", "POST"])
    except Exception as e:
        assert(str(e) == "My message")
        assert(e.status_code == 405)
        assert(e.headers["Allow"] == "GET, POST")
    else:
        assert(False)

# Generated at 2022-06-24 03:42:29.360119
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("My message")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == "My message"


# Generated at 2022-06-24 03:42:33.099684
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("test_message")
    assert error.status_code == 500
    assert error.quiet is False
    assert str(error) == "test_message"

# Generated at 2022-06-24 03:42:36.192102
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("Could not build url for endpoint")
    assert (
        error.args[0]
        == "Could not build url for endpoint"
    )

# Generated at 2022-06-24 03:42:38.576204
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """Test for ServiceUnavailable."""
    try:
        raise ServiceUnavailable(message='test_message')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert 'message' in dir(e)



# Generated at 2022-06-24 03:42:43.356724
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Create an instance of _RequestTimeout
    x = RequestTimeout("The request timed out", "POST", ["GET", "PUT", "POST"])
    # Test the status code of the instance
    assert x.status_code == 408
    # Test the exception message
    assert x.message == "The request timed out"


# Generated at 2022-06-24 03:42:46.896451
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    e1 = HeaderNotFound("abc")
    assert(e1.message == "abc")
    e2 = HeaderNotFound("abc", status_code=400)
    assert(e2.message == "abc")

# Generated at 2022-06-24 03:42:48.875576
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound('header error')
    assert hnf.message == 'header error'

# Generated at 2022-06-24 03:42:51.833371
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound exception test")
    except HeaderNotFound as e:
        assert e.status_code == 400



# Generated at 2022-06-24 03:42:54.912941
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = 'GET'
    allowed_methods = ['GET', 'POST']
    exc = MethodNotSupported('', method, allowed_methods)
    assert exc.headers['Allow'] == 'GET, POST'


# Generated at 2022-06-24 03:42:58.761300
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('test', 1024)
    except SanicException as se:
        assert(se.status_code == 416)
        assert(se.headers == {'Content-Range': 'bytes */1024'})

# Generated at 2022-06-24 03:43:01.567978
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound("Invaild path", "./XXX", "XX")
    assert exception.path == "./XXX"
    assert exception.relative_url == "XX"
    assert exception.message == "Invaild path"



# Generated at 2022-06-24 03:43:11.325563
# Unit test for function abort
def test_abort():
  try:
    abort(404, "Message for NotFound exception")
  except NotFound as e:
    assert e.status_code == 404 and "Not Found" in e.message

  try:
    abort(400, "Message for InvalidUsage exception")
  except InvalidUsage as e:
    assert e.status_code == 400 and "Bad Request" in e.message

  try:
    abort(405, "Message for MethodNotSupported exception")
  except MethodNotSupported as e:
    assert e.status_code == 405 and "Method Not Allowed" in e.message

# Run test
test_abort()

# Generated at 2022-06-24 03:43:17.014536
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('/usr')
    except PyFileError as e:
        assert e.args == ('could not execute config file %s', '/usr')
    else:
        assert False, 'PyFileError did not fail'


# Generated at 2022-06-24 03:43:21.192910
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # test_type
    assert isinstance(HeaderNotFound("test"), HeaderNotFound)

    # test_messages
    assert HeaderNotFound("test").args[0] == "test"

    # test_status_code
    assert HeaderNotFound("test").status_code == 400


# Generated at 2022-06-24 03:43:26.832526
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
  try:
    raise InvalidUsage("Testing")
  except Exception as e:
    print("String value: " + str(e))
    print("Description: " + e.__doc__)

if __name__ == '__main__':
  test_InvalidUsage()

# Generated at 2022-06-24 03:43:34.296408
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal("test").status_code == 500
    assert InvalidSignal("test", status_code=420).status_code == 420
    assert InvalidSignal("test", quiet=True).status_code == 500
    assert InvalidSignal("test", status_code=420, quiet=True).status_code == 420
    assert InvalidSignal("test", status_code=420, quiet=False).status_code == 420
    assert InvalidSignal("test", status_code=420, quiet=False).quiet == False
    assert InvalidSignal("test", status_code=420, quiet=True).quiet == True

# Generated at 2022-06-24 03:43:38.459434
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    str = "test message"
    with pytest.raises(HeaderExpectationFailed) as info:
        r = HeaderExpectationFailed(message=str, status_code=417)
    assert info.value.status_code == 417
    assert info.value.message == str

# Generated at 2022-06-24 03:43:42.638308
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    x = InvalidRangeType("exception message", "the content range")
    assert x.message == "exception message"
    assert x.headers == {"Content-Range": "bytes */the content range"}

# Generated at 2022-06-24 03:43:44.337378
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError):
        raise URLBuildError('message')


# Generated at 2022-06-24 03:43:47.735427
# Unit test for constructor of class NotFound
def test_NotFound():
    message = '404: Not Found'
    status_code = 404

    try:
        raise NotFound(message)
    except NotFound as error:
        #test if raise works
        assert error.args[0] == message

        #test status code
        assert error.status_code == status_code

        #test quiet flag
        assert error.quiet == True

# Generated at 2022-06-24 03:43:52.782303
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Negative cycle in the import graph.")
    except Exception as e:
        assert e.message == "Negative cycle in the import graph."


# Generated at 2022-06-24 03:43:53.970598
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal("Messsage") == InvalidSignal("Messsage")

# Generated at 2022-06-24 03:43:56.953180
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("get", "get")
    except MethodNotSupported as e:
        assert e.headers == {"Allow": "get"}
        assert e.args[0] == "get"

# Generated at 2022-06-24 03:43:58.714382
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ValueError):
        raise ContentRangeError('Error', None)



# Generated at 2022-06-24 03:44:00.383430
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    e = HeaderExpectationFailed("test")
    assert e.status_code == 417

# Generated at 2022-06-24 03:44:04.950578
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ["GET", "POST", "PUT", "DELETE"]
    try:
        raise MethodNotSupported("Method not supported", "PATCH", allowed_methods)
    except MethodNotSupported as e:
        assert e.status_code == 405


if __name__ == "__main__":
    import pytest

    pytest.main("test_exceptions.py")

# Generated at 2022-06-24 03:44:12.321030
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # No error
    exception_object = LoadFileException("message")
    assert exception_object.message == "message"
    assert exception_object.status_code == 500
    assert exception_object.quiet is False

    # With error
    exception_object2 = LoadFileException("message", status_code=404)
    assert exception_object2.message == "message"
    assert exception_object2.status_code == 404
    assert exception_object2.quiet is True


# Generated at 2022-06-24 03:44:16.034005
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound("File not found", "path", True)
    assert exception.status_code == 404
    assert str(exception) == "File not found"
    assert exception.path == "path"
    assert exception.relative_url == True


# Generated at 2022-06-24 03:44:23.984515
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # Without keyword arguments, it should raise Unauthorized with default
    # class params.
    try:
        raise Unauthorized("Unauthorized")
    except Unauthorized as error:
        assert error.status_code == 401

    # With keyword arguments, it should raise Unauthorized with user defined
    # params.
    try:
        raise Unauthorized("Unauthorized", scheme="Basic", realm="Protected Area")
    except Unauthorized as error:
        assert error.status_code == 401
        assert error.headers == {'WWW-Authenticate': 'Basic realm="Protected Area"'}

# Generated at 2022-06-24 03:44:27.094877
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Load Data File Error")
    except SanicException as e:
        pass

if __name__ == "__main__":
    test_LoadFileException()

# Generated at 2022-06-24 03:44:29.145014
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported(message='error message', method='PUT', allowed_methods=['PUT', 'POST'])
    except Exception as e:
        assert e.message == 'error message'
        assert e.headers == {'Allow': 'PUT, POST'}

# Generated at 2022-06-24 03:44:33.616562
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("I am a server error")
    except ServerError as e:
        assert e.message == "I am a server error"



# Generated at 2022-06-24 03:44:38.953328
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_msg = 'Requested endpoint is forbidden'
    forbidden = Forbidden(forbidden_msg)
    assert forbidden.message == forbidden_msg
    assert forbidden.status_code == 403
    assert forbidden.quiet == True

# Generated at 2022-06-24 03:44:45.116343
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    """
    Test for the MethodNotSupported class
    """
    msg = "method not allowed"
    header = {'Allow': 'GET'}
    try:
        raise MethodNotSupported(msg, "POST", ["GET"])
    except MethodNotSupported as ex:
        assert ex.__str__() == msg
        assert ex.headers == header
        assert ex.__class__.__name__ == "MethodNotSupported"


# Generated at 2022-06-24 03:44:46.941559
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("hello", range(0, 100))
    assert error.headers == {"Content-Range": f"bytes */100"}

# Generated at 2022-06-24 03:44:49.696250
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout")
    except RequestTimeout as e:
        assert e.status_code == 408
        assert str(e) == "Request Timeout"

# Generated at 2022-06-24 03:44:56.045971
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    msg = "server down!"
    try:
        raise ServiceUnavailable(message=msg)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.args[0] == msg
        assert e.get_body() == {"message": msg}
        assert e.get_headers() == {'Content-Type': 'application/json'}
        assert e.get_status() == 503
        assert e.get_message() == msg
        assert e.quiet is True


# Generated at 2022-06-24 03:45:05.639709
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class MyException(Exception):
        pass
    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(503)
    class MyQuietException(Exception):
        pass
    assert MyQuietException.status_code == 503
    assert MyQuietException.quiet is True

    my_exception = MyException('test')
    assert my_exception.status_code == 500
    assert my_exception.quiet is False

    my_quiet_exception = MyQuietException('test')
    assert my_quiet_exception.status_code == 503
    assert my_quiet_exception.quiet is True

    @add_status_code(418, quiet=True)
    class MyQuietException(Exception):
        pass
   

# Generated at 2022-06-24 03:45:11.656771
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("message", status_code=400, quiet=True)
    except SanicException as e:
        assert 'message' == e.__str__()
        assert 400 == e.status_code
        assert True == e.quiet

# Generated at 2022-06-24 03:45:16.596231
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
        assert e.status_code == 401


# Generated at 2022-06-24 03:45:19.618419
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Exercise Fails: the constructor of the 'Unauthorized' class does not accept
    # the arguments 'scheme' and '**kwargs'.
    try:
        raise Unauthorized("Auth required.",
                           scheme="Bearer",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers['WWW-Authenticate'] == 'Bearer realm="Restricted Area"'

# Generated at 2022-06-24 03:45:20.648769
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    pytest.raises(InvalidRangeType, lambda: InvalidRangeType("just a message"))

# Generated at 2022-06-24 03:45:24.625340
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = 'message'
    try:
        raise HeaderExpectationFailed(message=message)
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == message
        assert e.quiet == True


# Generated at 2022-06-24 03:45:26.504024
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable
    except ServiceUnavailable as e:
        assert e.status_code == 503


# Generated at 2022-06-24 03:45:30.058182
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception = Forbidden(message='Forbidden', status_code=403)
    assert exception.status_code == 403
    assert exception.message == 'Forbidden'


if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-24 03:45:33.949951
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage('Invalid usage.', status_code=400, quiet=None)
    assert exception.message == 'Invalid usage.'
    assert exception.status_code == 400
    assert exception.quiet == True

# Generated at 2022-06-24 03:45:36.496199
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Test Message", 101)
    except Forbidden as ex:
        assert ex.status_code == 101

# Generated at 2022-06-24 03:45:38.770726
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file_e = PyFileError(file)
    assert file_e.file == "could not execute config file %s"


# Generated at 2022-06-24 03:45:41.847547
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("404 Not Found")
    except SanicException as e:
        assert e.message == "404 Not Found"


# Generated at 2022-06-24 03:45:43.523986
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("Error")
    assert error.status_code == 500

# Generated at 2022-06-24 03:45:51.403294
# Unit test for constructor of class NotFound
def test_NotFound():
    # Both cases should work
    try:
        message = '404 Not Found'
        NotFound(message)
        NotFound(message, 404)
    except:
        assert False

    # Wrong input
    try:
        message = '404 Not Found'
        NotFound(message, 400)
        assert False
    except:
        assert True

    # Wrong input
    try:
        message = '404 Not Found'
        NotFound(message, '4040')
        assert False
    except:
        assert True

# Generated at 2022-06-24 03:46:00.133451
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test for a basic auth-scheme, realm MUST be present
    assert (Unauthorized("Auth required.", scheme="Basic",
                         realm="Restricted Area").headers ==
            {'WWW-Authenticate': 'Basic realm="Restricted Area"'})

    # Test for a Digest auth-scheme, things are a bit more complicated
    assert (Unauthorized("Auth required.", scheme="Digest",
                         realm="Restricted Area", qop="auth, auth-int",
                         algorithm="MD5", nonce="abcdef",
                         opaque="zyxwvu").headers ==
            {'WWW-Authenticate':
             'Digest realm="Restricted Area", nonce="abcdef", opaque="zyxwvu", '
             'qop="auth, auth-int", algorithm="MD5"'})

    # Test for a Bearer auth-

# Generated at 2022-06-24 03:46:02.327844
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    a=ServiceUnavailable("123")
    assert a.status_code == 503
    assert a.description == "123"


# Generated at 2022-06-24 03:46:14.685088
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # Standard constructor.
    error = Unauthorized("Auth required.")
    assert error.headers == {}
    assert error.message == "Auth required."
    assert error.status_code == 401

    # Constructor with the Basic scheme.
    error = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert error.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    assert error.message == "Auth required."
    assert error.status_code == 401

    # Constructor with the Digest scheme.
    error = Unauthorized("Auth required.", scheme="Digest",
                         realm="Restricted Area",
                         qop="auth, auth-int",
                         algorithm="MD5",
                         nonce="abcdef",
                         opaque="zyxwvu")

# Generated at 2022-06-24 03:46:16.428283
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Test error message")
    except:
        assert 1


# Generated at 2022-06-24 03:46:23.408314
# Unit test for function abort
def test_abort():
    abort(400, "message")
    abort(404, "message")
    abort(500, "message")
    abort(503, "message")
    abort(408, "message")
    abort(413, "message")
    abort(416, "message")
    abort(417, "message")
    abort(403, "message")
    abort(401, "message")
    abort(200, "message")
    print('test done')


# Generated at 2022-06-24 03:46:26.133864
# Unit test for function add_status_code
def test_add_status_code():
    class Foo(SanicException):
        pass
    func = add_status_code(404)
    r = func(Foo)
    assert r.status_code == 404

# Generated at 2022-06-24 03:46:28.124626
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = ServerError()
    assert exception.status_code == 500
    assert exception.message == STATUS_CODES[500]

# Generated at 2022-06-24 03:46:35.021744
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    r1 = InvalidRangeType("Range Error", "0-100/200")
    r2 = RequestTimeout("Timed Out")
    r3 = ServerError("Fast and Furious")
    r4 = ContentRangeError("Range Error", "0-100/200")

    assert r1.status_code == 416
    assert r2.status_code == 408
    assert r3.status_code == 500
    assert r4.status_code == 416

# Generated at 2022-06-24 03:46:39.854159
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("lolol")
    except PyFileError as err:
        assert isinstance(err, PyFileError)
# This is a test to verify the constructor of PyFileError
test_PyFileError()

# Generated at 2022-06-24 03:46:46.502065
# Unit test for function abort
def test_abort():
    # test for HTTP 200 (OK)
    try:
        abort(200)
    except SanicException as e:
        assert e.status_code == 200
    # test for HTTP 404 (Not Found)
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    # test for HTTP 400 (Bad Request)
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
    # test for HTTP 405 (Method Not Allowed)
    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405
    # test for HTTP 500 (Server Error)
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
   

# Generated at 2022-06-24 03:46:54.265268
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # test for schema
    try:
        raise Unauthorized('message', scheme='Basic')
    except Exception as e:
        assert 'WWW-Authenticate' in e.headers
    try:
        raise Unauthorized('message', scheme='Digest')
    except Exception as e:
        assert 'WWW-Authenticate' in e.headers.keys()
    try:
        raise Unauthorized('message', scheme='Bearer')
    except Exception as e:
        assert 'WWW-Authenticate' in e.headers.keys()
    # test with all args
    try:
        raise Unauthorized('message', 'Basic', realm='Restricted Area')
    except Exception as e:
        assert 'WWW-Authenticate' in e.headers.keys()

# Generated at 2022-06-24 03:46:59.825704
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
        raise Unauthorized("Auth required.", scheme="Bearer")
        raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    except Unauthorized as e:
        print(e.headers)

if __name__ == '__main__':
    test_Unauthorized()

# Generated at 2022-06-24 03:47:03.715305
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    a = FileNotFound('fdsfd', 'dafad', 'dfakfj')
    assert a.message == 'fdsfd'
    assert a.path == 'dafad'
    assert a.relative_url == 'dfakfj'


# Generated at 2022-06-24 03:47:10.996266
# Unit test for function add_status_code
def test_add_status_code():
    class test_class(SanicException):
        pass

    add_status_code(400)(test_class)
    assert _sanic_exceptions[400].status_code == 400

    add_status_code(404, quiet=True)(test_class)
    assert _sanic_exceptions[404].status_code == 404
    assert _sanic_exceptions[404].quiet

    add_status_code(501)(test_class)
    assert _sanic_exceptions[501].status_code == 501
    assert _sanic_exceptions[501].quiet