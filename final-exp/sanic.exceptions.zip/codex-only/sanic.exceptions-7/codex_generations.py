

# Generated at 2022-06-24 03:37:20.529833
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    """
    >>> str(InvalidUsage("test", status_code=403))
    'test'
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:37:23.300875
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    h = HeaderNotFound(message='test')
    assert h.status_code == 400
    assert h.message == 'test'

# Generated at 2022-06-24 03:37:25.157968
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden()
    forbidden.status_code == 403


if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-24 03:37:30.810927
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    ctx = {}
    try:
        abort(401, "Unauthorized")
    except Unauthorized as err:
        ctx = vars(err)
    assert ctx["status_code"] == 401
    assert ctx["message"] == "Unauthorized"

# Generated at 2022-06-24 03:37:36.855869
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "message"
    method = "method"
    allowed_methods = ['GET', 'POST']
    with pytest.raises(MethodNotSupported) as method_not_supported:
        exception = MethodNotSupported(message, method, allowed_methods)
        assert exception.message == "message"
        assert exception.headers == {'Allow': 'GET, POST'}

# Generated at 2022-06-24 03:37:40.115769
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError('error message', 'path', 'relative_url')
    assert exception.message == 'error message'
    assert exception.path == 'path'
    assert exception.relative_url == 'relative_url'

# Generated at 2022-06-24 03:37:43.919555
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    ex = PayloadTooLarge('This is PayloadTooLarge test')
    assert ex.status_code == 413
    assert ex.message == 'This is PayloadTooLarge test'

# Generated at 2022-06-24 03:37:55.193951
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Should not raise any exception
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert(e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\"")
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert(e.headers["WWW-Authenticate"] == "Digest realm=\"Restricted Area\", qop=\"auth, auth-int\", algorithm=\"MD5\", nonce=\"abcdef\", opaque=\"zyxwvu\"")

# Generated at 2022-06-24 03:38:05.331624
# Unit test for function add_status_code
def test_add_status_code():
    class testclass(SanicException):
        pass

    @add_status_code(200)
    class testclass_200(testclass):
        pass

    @add_status_code(300)
    class testclass_300(testclass):
        pass

    @add_status_code(400, True)
    class testclass_400(testclass):
        pass

    @add_status_code(500, True)
    class testclass_500(testclass):
        pass

    assert testclass_200.status_code == 200
    assert testclass_200.quiet == False
    assert testclass_300.status_code == 300
    assert testclass_300.quiet == False
    assert testclass_400.status_code == 400
    assert testclass_400.quiet == True
    assert testclass_500.status_code

# Generated at 2022-06-24 03:38:07.784916
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        a = MethodNotSupported("test", "GET", ["POST"])
    except Exception as e:
        pass

# Generated at 2022-06-24 03:38:10.218000
# Unit test for constructor of class PyFileError
def test_PyFileError():
    path = './test.py'
    err = PyFileError(path)
    assert './test.py' in str(err)

# Generated at 2022-06-24 03:38:17.361345
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # GIVEN
    message = "my custom message"
    path = "./my-custom-path"
    relative_url = "/my-custom-url"

    # WHEN
    e = FileNotFound(message, path, relative_url)

    # THEN
    assert e.message == message
    assert e.path == path
    assert e.relative_url == relative_url
    assert e.status_code == 404
    assert str(e) == f"404: {message}"



# Generated at 2022-06-24 03:38:19.809545
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    error = HeaderExpectationFailed("test message")
    assert error.status_code == 417
    assert "test message" in str(error)

# Generated at 2022-06-24 03:38:22.306134
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    result = LoadFileException('File not loaded', 500)
    assert result.message == 'File not loaded'
    assert result.status_code == 500

# Generated at 2022-06-24 03:38:25.808931
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("PayloadTooLarge!")
    except PayloadTooLarge as e:
        assert str(e) == 'PayloadTooLarge!'

# Generated at 2022-06-24 03:38:29.317015
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    headerExpectationFailed = HeaderExpectationFailed("Hello from the other side")
    assert headerExpectationFailed.status_code == 417
    assert headerExpectationFailed.message == "Hello from the other side"



# Generated at 2022-06-24 03:38:33.001190
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("test message", "test path", "test relative url")
    except Exception as e:
        assert e.path == "test path"
        assert e.relative_url == "test relative url"

# Generated at 2022-06-24 03:38:42.181572
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        exc = SanicException("testing")
        assert exc.message == "testing"
        assert exc.status_code is None
        assert exc.quiet is False
        exc = SanicException("testing", status_code=401)
        assert exc.message == "testing"
        assert exc.status_code == 401
        assert exc.quiet is True
        exc = SanicException("testing", status_code=401, quiet=False)
        assert exc.message == "testing"
        assert exc.status_code == 401
        assert exc.quiet is False
    except Exception as e:
        assert False #should not have raised an Exception
        print(e)


# Generated at 2022-06-24 03:38:45.656201
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('file size too large')
    except PayloadTooLarge as exc:
        assert exc.status_code == 413
        assert str(exc) == 'file size too large'


# Generated at 2022-06-24 03:38:53.414636
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test case for function add_status_code
    """
    CODE = 412

    @add_status_code(CODE)
    class MockException(SanicException):
        pass

    assert MockException.status_code == CODE

    assert issubclass(_sanic_exceptions.get(CODE, None), SanicException)
    assert issubclass(_sanic_exceptions.get(CODE, None), MockException)

# Generated at 2022-06-24 03:38:56.302027
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exc = ServiceUnavailable('test message')
    assert exc.message == 'test message'
    assert exc.status_code == 503
    assert exc.headers == None


# Generated at 2022-06-24 03:38:59.177880
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Create a test object
    try:
        test_obj = HeaderExpectationFailed("Header Expectation Failed", 417)
    except Exception:
        print("Header Expectation Failed constructor test failed")

    return

# Generated at 2022-06-24 03:39:03.598353
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound("message","path","relative_url")
    assert exception.path == "path"
    assert exception.message == "message"
    assert exception.relative_url == "relative_url"

# Generated at 2022-06-24 03:39:05.899163
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Signal don't exist.")
    except InvalidSignal as e:
        assert str(e) == "Signal don't exist.", "InvalidSignal constructor must return string"


# Generated at 2022-06-24 03:39:09.875836
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    o = InvalidSignal('Invalid Signal', 'The signal is invalid')
    assert o.message == 'Invalid Signal'
    assert o.args == ('Invalid Signal',)
    assert o.status_code == 'The signal is invalid'

# Generated at 2022-06-24 03:39:18.193501
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present:
    raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")

    # With a Digest auth-scheme, things are a bit more complicated:
    raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")

    # With a Bearer auth-scheme, realm is optional so you can write:
    raise Unauthorized("Auth required.", scheme="Bearer")

    # or, if you want to specify the realm:
    raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

# Generated at 2022-06-24 03:39:20.879692
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    hef = HeaderExpectationFailed("expectation failed","Expect")
    assert hef.status_code == 417
    assert hef.headers == {"Expect":"Expect"}

# Generated at 2022-06-24 03:39:25.002371
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    a = HeaderExpectationFailed(message = "I am writing a unit test", quiet = True)
    assert a.status_code == 417
    assert a.message == "I am writing a unit test"
    assert a.quiet == True

# Generated at 2022-06-24 03:39:28.863918
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    message = "Test Message"
    content_range = None
    provided_exception = InvalidRangeType(message, content_range)
    expected_exception = InvalidRangeType(message, content_range)
    assert provided_exception.args == expected_exception.args

# Generated at 2022-06-24 03:39:32.525542
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "Not Found"
    path = "path"
    relative_url = "/relative_url"
    exception = FileNotFound(message, path, relative_url)

    assert exception.message == message
    assert exception.path == path
    assert exception.relative_url == relative_url

# Generated at 2022-06-24 03:39:34.298608
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage(message=None, status_code=None, quiet=None)
    print(a)

# Generated at 2022-06-24 03:39:35.915871
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound("Header not Found")
    assert exception is not None


# Generated at 2022-06-24 03:39:39.340085
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    t = RequestTimeout(message="Timeout error.", status_code=408)
    assert t.message == "Timeout error."
    assert t.status_code == 408


# Generated at 2022-06-24 03:39:42.285264
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("message is here", 403)
    assert forbidden is not None
    assert forbidden.message == "message is here"
    assert forbidden.status_code == 403



# Generated at 2022-06-24 03:39:44.300927
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal('a', 1, 2)


# Generated at 2022-06-24 03:39:46.839198
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    mes = "Request Timeout"
    status_code = 408
    obj = RequestTimeout(mes, status_code)
    assert obj.args[0] == mes
    assert obj.status_code == status_code


# Generated at 2022-06-24 03:39:55.408199
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    assert LoadFileException("Test message") == LoadFileException("Test message")
    assert LoadFileException("Test message") != LoadFileException("Test message 2")
    assert LoadFileException("Test message") != LoadFileException("Test message", status_code=404)
    assert LoadFileException("Test message", status_code=500) != LoadFileException("Test message", status_code=404)
    assert LoadFileException("Test message", quiet=True) != SanicException("Test message")
    assert LoadFileException("Test message", status_code=500) != ServerError("Test message")
    # assert LoadFileException("Test message", status_code=500) == ServerError("Test message")

# Generated at 2022-06-24 03:39:59.187910
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    test_data = 'test data'
    timeout_instance = RequestTimeout(message=test_data)
    # Ensure that the message attribute is correctly set
    assert timeout_instance.args[0] == test_data
    # Ensure that the status code is correctly set
    assert timeout_instance.status_code == 408



# Generated at 2022-06-24 03:40:00.812216
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(Exception):
        raise InvalidRangeType('Test', 'test')


# Generated at 2022-06-24 03:40:04.934438
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException(message=None, status_code=None, quiet=None)
    assert isinstance(exception, LoadFileException)


# Generated at 2022-06-24 03:40:07.430124
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("Error Message", status_code=400)
    assert f.status_code == 400
    assert f.message == "Error Message"


# Generated at 2022-06-24 03:40:14.031750
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exception = InvalidSignal("message body")
    assert exception.message == "message body"
    # the constructor of SanicException should be called without param
    #status_code, so this exception can't be caught by sanic's error handler.
    assert exception.status_code is None
    # the constructor of SanicException should be called without param
    #quiet, so this exception can't be caught by sanic's error handler.
    assert exception.quiet is None

# Generated at 2022-06-24 03:40:20.046677
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    def get_www_auth(e):
        return e.headers.get('WWW-Authenticate')
    try:
        raise Unauthorized('Auth required', scheme='Basic')
    except Unauthorized as e:
        assert get_www_auth(e) == 'Basic'
    try:
        raise Unauthorized('Auth required', scheme='Digest', realm='Restricted Area', qop='auth, auth-int', algorithm='MD5', nonce='abcdef', opaque='zyxwvu')
    except Unauthorized as e:
        assert get_www_auth(e) == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-24 03:40:21.903177
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout = RequestTimeout('This is a timeout error', 408)

    assert timeout.status_code == 408

# Generated at 2022-06-24 03:40:23.717915
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        assert False
    except:
        e = sys.exc_info()[1]
        assert e.status_code == 403

# Generated at 2022-06-24 03:40:27.378832
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Prepare the input and expected output
    file = 'test.py'
    expected_output = "could not execute config file test.py"
    # Execute the function being tested
    test_output = PyFileError(file)
    # Assert that the expected value equals the function output
    assert expected_output == str(test_output)

# Generated at 2022-06-24 03:40:30.374446
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge(message='message', status_code=413)
    assert error.message == 'message'
    assert error.status_code == 413
    assert error.__str__() == 'message'
    assert error.__repr__() == '<PayloadTooLarge message=message>'


# Generated at 2022-06-24 03:40:35.861129
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("no result")
    except Exception as exc:
        assert exc.args[0] == "no result"
        assert exc.status_code == 500
        assert exc.message == "no result"
        assert str(exc) == "no result"
        assert exc.quiet is False

# Generated at 2022-06-24 03:40:39.421817
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # GIVEN
    message = "ERROR"
    status_code = 400

    # WHEN
    invalidUsage = InvalidUsage(message, status_code)

    # THEN
    assert invalidUsage.message == message
    assert invalidUsage.status_code == status_code


# Generated at 2022-06-24 03:40:49.692398
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Test")
    except SanicException as e:
        assert e.message == "Test"
    try:
        raise SanicException("Test", status_code=500)
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "Test"
    try:
        raise SanicException("Test", status_code=404)
    except SanicException as e:
        assert e.status_code == 404
        assert e.message == "Test"
    try:
        raise SanicException("Test", status_code=404, quiet=True)
    except SanicException as e:
        assert e.status_code == 404
        assert e.message == "Test"

# Generated at 2022-06-24 03:40:51.621816
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Unit test for constructor of class InvalidUsage
    try:
        raise InvalidUsage()
    except InvalidUsage as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:40:53.785647
# Unit test for constructor of class PyFileError
def test_PyFileError():
    err = PyFileError("test.py")
    # Using assert_raises to check if the exception is raised.
    assert_raises(PyFileError, err)

# Generated at 2022-06-24 03:40:54.902494
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = ContentRangeError("Hello" , 100)
    print(c.headers)

# Generated at 2022-06-24 03:40:57.075120
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exc = PayloadTooLarge(message='PayloadTooLarge')
    assert 'PayloadTooLarge' == exc.message
    assert 416 == exc.status_code

# Generated at 2022-06-24 03:40:58.777594
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

# Generated at 2022-06-24 03:41:03.355951
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Method Not Supported\n", "GET", ["POST", "PUT", "PATCH"])
    except SanicException as e:
        print('Status Code: ' + str(e.status_code))
        print('Message: ' + str(e.message))
        print('Allow: ' + str(e.headers["Allow"]))


# Generated at 2022-06-24 03:41:05.128994
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage(message='some invalid usage message')

# Generated at 2022-06-24 03:41:09.781734
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    hef = HeaderExpectationFailed("This is a test")
    assert hef.status_code == 417
    assert hef.message == "This is a test"
    assert hef.headers == {}


# Generated at 2022-06-24 03:41:13.676675
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Server Error")
    except ServerError as e:
        pass


# Generated at 2022-06-24 03:41:20.011922
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('Unauthorized access')
    class_name = forbidden.__class__.__name__
    status_code = forbidden.status_code
    message = forbidden.__str__()
    assert class_name == 'Forbidden'
    assert status_code == 403
    assert message == 'Unauthorized access'

# Generated at 2022-06-24 03:41:24.292978
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(code=400, quiet=True)(SanicException).status_code == 400
    assert add_status_code(code=400)(SanicException).status_code == 400

# Generated at 2022-06-24 03:41:27.136974
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("abcdef")
    except Exception as e:
        assert e.args == ("abcdef",)
        assert type(e) == URLBuildError


# Generated at 2022-06-24 03:41:30.225147
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test_load_file")
    except LoadFileException as e:
        assert e.message == "test_load_file"
        assert e.status_code == None
        assert e.quiet == None


# Generated at 2022-06-24 03:41:32.810527
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("something wrong", status_code=403, quiet=True)
    except SanicException as e:
        assert e.message == "something wrong"
        assert e.status_code == 403
        assert e.quiet == True


# Generated at 2022-06-24 03:41:34.648155
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    InvalidRangeType("Test", None)

# Generated at 2022-06-24 03:41:35.548895
# Unit test for constructor of class Forbidden
def test_Forbidden():
    Forbidden(message="test message", status_code=403)

# Generated at 2022-06-24 03:41:37.964931
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    r = InvalidRangeType('range错误', 'bytes */{content_range.total}')
    print(r)  # __init__

# Generated at 2022-06-24 03:41:42.262724
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden
    if forbidden is None:
        print('FAIL')
    else:
        print('PASS')

test_Forbidden()

# Generated at 2022-06-24 03:41:49.606668
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("not found", "path", "relative_url")
    assert file_not_found.path == "path"
    assert file_not_found.relative_url == "relative_url"
    assert file_not_found.status_code == 404
    assert file_not_found.quiet == True
    assert file_not_found.__init__ == "not found"


# Generated at 2022-06-24 03:41:53.292514
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("message")
    assert f.message == "message"
    assert f.status_code == 403
    assert f.kwargs == {}
    assert f.__str__() == "message"



# Generated at 2022-06-24 03:41:56.091904
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('Server error!')
        assert False
    except ServiceUnavailable as exc:
        assert str(exc) == 'Server error!'
        assert exc.status_code == 503

# Unit test when we call 'abort(503)'

# Generated at 2022-06-24 03:42:02.429435
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class CallMeTeapot(SanicException):
        """
        **Status**: 418 I'm a teapot.
        """

        pass

    assert 'I\'m a teapot.' == STATUS_CODES[418]
    assert isinstance(CallMeTeapot(''), SanicException)
    assert CallMeTeapot('', status_code=418).status_code == 418

# Generated at 2022-06-24 03:42:14.274597
# Unit test for function add_status_code
def test_add_status_code():
    CODE = 201

    @add_status_code(CODE)
    class TestClass(SanicException):
        pass

    assert issubclass(TestClass, SanicException)
    assert TestClass.status_code == CODE
    assert _sanic_exceptions[CODE] == TestClass

    # Quiet=None, so check that it's set if the status code is not 500
    @add_status_code(404, quiet=None)
    class TestClass(SanicException):
        pass

    assert TestClass.quiet is True

    @add_status_code(500, quiet=None)
    class TestClass(SanicException):
        pass

    assert TestClass.quiet is False

    @add_status_code(CODE, quiet=True)
    class TestClass(SanicException):
        pass


# Generated at 2022-06-24 03:42:15.275575
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert InvalidRangeType("message", "content_range")

# Generated at 2022-06-24 03:42:27.000837
# Unit test for constructor of class SanicException
def test_SanicException():
    err_1 = SanicException(message="This is a test", status_code=400)
    err_2 = SanicException(message="This is a test", status_code=404)
    err_3 = SanicException(message="This is a test", status_code=500)
    assert err_1.status_code == 400
    assert err_1.message == "This is a test"
    assert err_2.status_code == 404
    assert err_2.message == "This is a test"
    assert err_1.quiet == True
    assert err_2.quiet == True
    assert err_3.quiet == False
    # err_4 = SanicException("This is a test")
    # assert err_4.status_code == 500
    # assert err_4.message == "This is a test"



# Generated at 2022-06-24 03:42:30.367229
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed) as excinfo:
        raise HeaderExpectationFailed("Invalid Header")
    assert excinfo.value.status_code == 417

# Generated at 2022-06-24 03:42:33.613838
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert MethodNotSupported("message", "method", ["method1", "method2"]).headers["Allow"] == "method1, method2"

# Generated at 2022-06-24 03:42:37.430121
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Message")
    except InvalidUsage as e:
        assert isinstance(e, SanicException)
        assert str(e) == "Message"
        assert e.status_code == 400


# Generated at 2022-06-24 03:42:41.165718
# Unit test for function abort
def test_abort():
    aborted = False
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
        aborted = True
    assert aborted



# Generated at 2022-06-24 03:42:42.352806
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    MethodNotSupported("message", "method", ["allowed_methods"])

# Generated at 2022-06-24 03:42:47.327297
# Unit test for constructor of class ServerError
def test_ServerError():
    assert ServerError("msg").message == "msg"
    assert ServerError("msg", status_code=500).status_code == 500
    assert not ServerError("msg", status_code=500).quiet
    assert ServerError("msg", status_code=400).status_code == 400
    assert ServerError("msg", status_code=400).quiet

# Generated at 2022-06-24 03:42:49.921953
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("This is a timeout test.")
    except RequestTimeout as e:
        assert e.status_code == 408

# Generated at 2022-06-24 03:42:54.511293
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Missing Header', 'header_name')
    except HeaderNotFound as ex:
        assert ex.message == 'Missing Header'
        assert ex.status_code == 400
        assert ex.header_name == 'header_name'

# Generated at 2022-06-24 03:43:05.061700
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException(SanicException):
        pass
    assert isinstance(_sanic_exceptions.get(100), TestException)
    assert _sanic_exceptions.get(100).status_code == 100

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass
    assert isinstance(_sanic_exceptions.get(200), TestException)
    assert _sanic_exceptions.get(200).status_code == 200
    assert _sanic_exceptions.get(200).quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert isinstance(_sanic_exceptions.get(500), TestException)

# Generated at 2022-06-24 03:43:12.079833
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType("Range type not satisfiable", 100)
    assert exc.message == 'Range type not satisfiable'
    assert exc.headers == {'Content-Range': 'bytes */100'}
    assert exc.status_code == 416
    assert isinstance(exc, SanicException)


if __name__ == "__main__":
    # Unit test for constructor of class InvalidRangeType
    test_InvalidRangeType()

# Generated at 2022-06-24 03:43:17.123752
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('test', 'test', 'test')
    except FileNotFound as f:
        assert f.status_code == 404
        assert f.quiet is True
        assert f.path == 'test'
        assert f.relative_url == 'test'

# Generated at 2022-06-24 03:43:19.245724
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    urlerror = URLBuildError('Invalid URL')
    assert urlerror.status_code == 500
    assert urlerror.message == 'Invalid URL'


# Generated at 2022-06-24 03:43:22.218091
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = 'Error: header not found'
    header_not_found = HeaderNotFound(message)
    assert header_not_found.message == 'Error: header not found'
    assert header_not_found.status_code == 400


# Generated at 2022-06-24 03:43:26.046191
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    msg = "Invalid usage."
    sanic_exception = InvalidUsage(message=msg)
    assert sanic_exception.message == msg


# Generated at 2022-06-24 03:43:29.981626
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('ServerError')
    except Exception as e:
        assert e.status_code == 500



# Generated at 2022-06-24 03:43:33.838707
# Unit test for function abort
def test_abort():
    with pytest.raises(Forbidden):
        abort(403)
    with pytest.raises(Forbidden):
        abort(403, "")
    with pytest.raises(Forbidden):
        abort(403, "Custom Forbidden")
    with pytest.raises(InvalidUsage):
        abort(400, "Custon Bad Request")

test_abort()

# Generated at 2022-06-24 03:43:38.000124
# Unit test for function add_status_code
def test_add_status_code():
    # Test quiet
    assert BadRequest.quiet
    assert ServerError.quiet is False

    # Test status_code
    assert BadRequest.status_code == 400
    assert ServerError.status_code == 500

    # Test if it adds to _sanic_exceptions
    assert _sanic_exceptions[400] == BadRequest
    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-24 03:43:39.885242
# Unit test for constructor of class NotFound
def test_NotFound():
    assert str(NotFound('abc')) == "abc"



# Generated at 2022-06-24 03:43:46.428391
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # exact match
    message = "test_string"
    status_code = 0
    quiet = None
    exception = LoadFileException(message=message, status_code=status_code, quiet=quiet)
    assert exception.status_code == status_code
    assert exception.message == message
    assert exception.quiet == quiet
    assert exception.__cause__ == None
    assert exception.__context__ == None
    assert exception.__suppress_context__ == False


# Generated at 2022-06-24 03:43:48.822603
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert str(e) == "Test"


# Generated at 2022-06-24 03:43:52.776995
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test")
    except ServerError as e:
        assert isinstance(e, ServerError)
        assert isinstance(e, SanicException)
        assert str(e) == "test"
        assert e.status_code == 500
        assert isinstance(e.__cause__, None)
        assert isinstance(e.__context__, None)


# Generated at 2022-06-24 03:43:55.194746
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException):
        abort(500)
    with pytest.raises(NotFound):
        abort(404, 'not found')

# Generated at 2022-06-24 03:44:01.855707
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(
            "The server is currently unavailable (because it is overloaded or\
            down for maintenance). Generally, this is a temporary state.")
    except Exception as e:
        assert e.status_code == 503
        assert e.message == "The server is currently unavailable (because it is overloaded or\
            down for maintenance). Generally, this is a temporary state."
        assert e.quiet == False

test_ServiceUnavailable()

# Generated at 2022-06-24 03:44:02.546276
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    pass;


# Generated at 2022-06-24 03:44:04.122216
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    x = PayloadTooLarge("error message")
    assert x.status_code == 413


# Generated at 2022-06-24 03:44:06.998830
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # The Forbidden should not raise
    fb = Forbidden("Forbidden")
    print(fb)
    assert fb.status_code == 403

# Generated at 2022-06-24 03:44:09.972272
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    instance = FileNotFound("filename", "relative_url")
    assert instance.args[0] == "filename"
    assert instance.path == "filename"
    assert instance.relative_url == "relative_url"

# Generated at 2022-06-24 03:44:14.156854
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('Request Too Large', 413)
    except PayloadTooLarge as e:
        assert(e.message == 'Request Too Large')
        assert(e.status_code == 413)


# Generated at 2022-06-24 03:44:17.432554
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    filesize = 0
    content_range = (0, 0, filesize)
    message = "hello"
    err = ContentRangeError(message, content_range)
    assert err.headers == {"Content-Range": f"bytes */{filesize}"}
    assert err.message == message

# Generated at 2022-06-24 03:44:24.623805
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        from sanic.response import text
        import pytest
        from sanic.testing import SanicTestClient
        from sanic import Sanic
        from sanic.response import text
        app = Sanic("sanic")

        @app.route("/")
        async def test(request):
            r = text("OK")
            return r
        client = SanicTestClient(app,port=8000)
        response = client.get("/")
        assert response.status == 200
        assert response.text == "OK"
    except:
        assert False

# Generated at 2022-06-24 03:44:25.476689
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("asdf")

# Generated at 2022-06-24 03:44:28.708625
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_exc = PayloadTooLarge("test_msg", 100)
    assert test_exc.status_code == 413
    assert test_exc.__class__.__name__ == 'PayloadTooLarge'
    assert test_exc.__str__() == "test_msg"
    assert test_exc.quiet is True



# Generated at 2022-06-24 03:44:33.163256
# Unit test for constructor of class Forbidden
def test_Forbidden():

    forbidden_test = Forbidden('test')
    assert forbidden_test.status_code == 403
    assert forbidden_test.quiet == False



# Generated at 2022-06-24 03:44:35.781933
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception = Forbidden("Invalid credentials")
    assert exception.message == "Invalid credentials"
    assert exception.status_code == 403
    assert exception.quiet == True


# Generated at 2022-06-24 03:44:38.191547
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('message')
    except SanicException as e:
        print(e)
        assert e is not None


# Generated at 2022-06-24 03:44:41.576663
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Internal Error")
    except URLBuildError as err:
        assert err.status_code == 500
        assert isinstance(err, ServerError)
        assert err.message == "Internal Error"


# Generated at 2022-06-24 03:44:43.820082
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Restricted Area")
    except Forbidden as e:
        assert e.args[0] == "Restricted Area"

# Generated at 2022-06-24 03:44:49.131446
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Test for InvalidRangeType(message, content_range)
    try:
        raise InvalidRangeType("Error message", "content_range")
    except InvalidRangeType as e:
        assert e.message == "Error message"
        assert e.status_code == 416
        assert e.headers == {"Content-Range": "bytes */content_range"}


# Generated at 2022-06-24 03:44:51.646829
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('ERROR')
    except InvalidUsage as e:
        assert e.message == 'ERROR'



# Generated at 2022-06-24 03:44:54.912059
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Constructor call
    try:
        raise RequestTimeout("Test", 408)
    except RequestTimeout as e:
        assert e.__str__() == "Test"
        assert e.status_code == 408
        assert e.quiet


# Generated at 2022-06-24 03:44:58.545701
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge_exception = PayloadTooLarge(message="payload too large")
    assert PayloadTooLarge_exception.message == "payload too large"
    assert PayloadTooLarge_exception.status_code == 413


# Generated at 2022-06-24 03:45:01.951362
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="Hello World")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert not e.quiet
        assert e.message == "Hello World"



# Generated at 2022-06-24 03:45:06.181388
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    msg = "The server has been contacted but the client has not sent any data " \
          "for a certain period of time."
    instance = RequestTimeout(msg)
    assert (str(instance) == msg)

# Generated at 2022-06-24 03:45:13.864703
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        total = 5000
        filename = "a_filename"
        err = ContentRangeError(message="requested range not satisfiable", content_range=filename)
        assert err.message == "requested range not satisfiable"
        assert err.content_range == filename
        assert err.status_code == 416
    except Exception:
        print("Error: test_ContentRangeError()")



# Generated at 2022-06-24 03:45:17.352188
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    s = InvalidSignal("test", status_code=400)
    assert s.status_code == 400

# Generated at 2022-06-24 03:45:19.748044
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    res = InvalidSignal("This is a unit test for InvalidSignal!")
    assert res.message == "This is a unit test for InvalidSignal!" and res.status_code == 500

# Generated at 2022-06-24 03:45:27.328395
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    # Signal without signal's number
    assert(isinstance(InvalidSignal("No signal number"), InvalidSignal))
    assert(InvalidSignal("No signal number").__str__() == "No signal number")
    # Signal with signal's number
    assert(isinstance(InvalidSignal("No signal number", "10"), InvalidSignal))
    assert(InvalidSignal("No signal number", "10").__str__() == "No signal number")
    assert(InvalidSignal("No signal number", 10).__str__() == "No signal number")
    assert(InvalidSignal("No signal number", "10").signal == 10)

# Generated at 2022-06-24 03:45:30.519433
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable(message='The service is unavailable now.',
                                   status_code=503)
    assert exception.message == 'The service is unavailable now.'

    # Test quiet property
    assert exception.quiet == True



# Generated at 2022-06-24 03:45:34.102298
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("ServerError test")
    except ServerError as e:
        assert e.status_code == 500
        assert e.quiet == False

# Generated at 2022-06-24 03:45:44.584329
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # init input args = path, relative_url
    path = "/home/abc/project"
    relative_url = "/example"
    # Case 1: path is correct and relative_url is correct
    res = FileNotFound("File not Found", path, relative_url)
    assert res.path == path
    assert res.relative_url == relative_url
    # Case 2: path is NULL and relative_url is NULL
    res2 = FileNotFound("File not Found", None, None)
    assert res2.path == None
    assert res2.relative_url == None
    # Case 3: path is incorrect and relative_url is incorrect
    res3 = FileNotFound("File not Found", None, "/example2/")
    assert res3.path == None
    assert res3.relative_url == "/example2/"


# Unit test

# Generated at 2022-06-24 03:45:47.450244
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    test_obj = InvalidRangeType('message', 'content_range')
    assert test_obj.message == 'message'
    assert test_obj.content_range == 'content_range'

# Generated at 2022-06-24 03:45:50.891196
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise SanicException(message="test")
    except SanicException as e:
        assert e.status_code == None
        assert e.message == "test"

# Generated at 2022-06-24 03:45:51.564515
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    pass

# Generated at 2022-06-24 03:45:53.863333
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("my error")
    assert e.status_code == 500
    assert e.kwargs == {}
    assert e.args == ("my error", )

# Generated at 2022-06-24 03:45:56.982918
# Unit test for constructor of class PyFileError
def test_PyFileError():
    PyFileError('/some/path/a.txt')


# Generated at 2022-06-24 03:45:58.958107
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError("Hello World")

# Generated at 2022-06-24 03:46:01.490679
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "file"
    error = PyFileError(file)

    assert "could not execute config file file" == error.args[0]
    assert file == error.args[1]

# Generated at 2022-06-24 03:46:04.666897
# Unit test for constructor of class ServerError
def test_ServerError():
    serverError = (ServerError('Error message!', status_code=500, quiet=False))
    assert serverError.status_code == 500
    assert serverError.message == 'Error message!'
    assert serverError.quiet == False


# Generated at 2022-06-24 03:46:15.666231
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # Test the creation of a HeaderNotFound object by passing argument 'message'
    # and the creation of a HeaderNotFound object by passing no argument
    hnf1 = HeaderNotFound("Test of HeaderNotFound")
    hnf2 = HeaderNotFound()

    assert "message" in dir(hnf1)
    assert "message" in dir(hnf2)

    assert hnf1.message == "Test of HeaderNotFound"
    assert hnf2.message == "Invalid Usage"

    # Test the constructor of base class SanicException
    sf = SanicException("Test of SanicException", status_code=400)

    assert sf.message == "Test of SanicException"
    assert sf.status_code == 400

# Generated at 2022-06-24 03:46:18.649288
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("message")
    except ServerError as ex:
        assert ex.status_code == 500, "Error code is 500"
        assert ex.message == "message", "Error message is message"

# Generated at 2022-06-24 03:46:25.885705
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("error message", "http://sanic.bruh.com")
    assert err.message == "error message"
    assert err.status_code == 500
    assert err.url == "http://sanic.bruh.com"
    assert repr(err) == "error message: http://sanic.bruh.com"

# Unit tests for constructor of class SanicException
# test_SanicException_with_status_code

# Generated at 2022-06-24 03:46:28.543976
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    HEADER_NAME = "test"
    message = f"Header not found: {HEADER_NAME}"
    assert(HeaderNotFound(HEADER_NAME).message == message)



# Generated at 2022-06-24 03:46:30.853240
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    InvalidUsage("message", status_code=400, quiet=True)


# Generated at 2022-06-24 03:46:32.818906
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        file_id = PyFileError("filename")
    except Exception as e:
        print(e)

# Generated at 2022-06-24 03:46:37.938790
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = 'range is not available'
    class ContentRange:
        def __init__(self, t):
            self.total = t
    c_range = ContentRange(1000)
    try:
        e = ContentRangeError(msg, c_range)
    except:
        pass
    assert e.headers['Content-Range'] == 'bytes */1000'


# Generated at 2022-06-24 03:46:39.757614
# Unit test for constructor of class NotFound
def test_NotFound():
    ex = NotFound()
    assert ex.status_code == 404
    assert ex.quiet is True

# Generated at 2022-06-24 03:46:44.758128
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed("msg", "error")
    assert exception.status_code == 417
    assert exception.message == "msg"
    assert exception.args == ("msg", "error")
    assert exception.quiet == False

# Generated at 2022-06-24 03:46:47.869665
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('Header Expectation Failed!')
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == 'Header Expectation Failed!'
    except Exception as e:
        raise e


# Generated at 2022-06-24 03:46:50.780378
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found_error = NotFound("Test Error")
    assert (not_found_error.message == "Test Error" and
            not_found_error.status_code == 404 and
            not_found_error.quiet)


# Generated at 2022-06-24 03:46:54.213344
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed):
        raise HeaderExpectationFailed('HeaderExpectationFailed')

# Generated at 2022-06-24 03:46:55.660799
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError("", 10)

# Generated at 2022-06-24 03:46:58.517306
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException):
        raise SanicException('foo', status_code=invalid_status_code, quiet=True)

# Generated at 2022-06-24 03:47:00.940996
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    e = RequestTimeout("Test")
    if e.message != "Test":
        print("Constructor of class RequestTimeout does not work properly")


# Generated at 2022-06-24 03:47:04.988348
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """Test max_size parameter of the constructor of class PayloadTooLarge
    """
    try:
        raise PayloadTooLarge("test_max_size", 1024)
    except (PayloadTooLarge) as e:
        assert e.max_size == 1024

# Generated at 2022-06-24 03:47:09.033807
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as e:
        raise ServiceUnavailable("TestServiceUnavailable")
    assert e.value.message == "TestServiceUnavailable"
    assert e.value.status_code == 503
    assert e.value.quiet == True


# Generated at 2022-06-24 03:47:10.604020
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = 'test.py'
    test = PyFileError(file)
    assert test.args == ("could not execute config file test.py",)

# Generated at 2022-06-24 03:47:12.612029
# Unit test for constructor of class URLBuildError
def test_URLBuildError():

    try:
        raise URLBuildError("test")
    except URLBuildError as e:
        print(e)

# Generated at 2022-06-24 03:47:16.548640
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as e:
        assert str(e) == STATUS_CODES[500]  # "Internal Server Error"
    assert abort(404) == STATUS_CODES[404]

# Generated at 2022-06-24 03:47:21.031501
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message="test, a test", path="path", relative_url="relative_url")
    except FileNotFound as e:
        e.__str__()
        assert e.args[0] == "test, a test"
        assert e.path == "path"
        assert e.relative_url == "relative_url"