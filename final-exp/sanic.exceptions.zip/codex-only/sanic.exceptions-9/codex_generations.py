

# Generated at 2022-06-24 03:37:21.989199
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    """
    :return: Return 0 if not error has been raised by constructor.
    """
    try:
        exc = MethodNotSupported("Test message", method='GET', allowed_methods=['POST', 'PUT'])
    except Exception as e:
        return 1
    else:
        return 0

# Generated at 2022-06-24 03:37:23.836918
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException(message="test message")
    assert e.status_code is None
    assert e.quiet is False


# Generated at 2022-06-24 03:37:27.235235
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Error", 100)
    except ContentRangeError as error:
        assert error.status_code == 416
        assert error.message == "Error"
        assert error.headers == {"Content-Range": "bytes */100"}


# Generated at 2022-06-24 03:37:31.005838
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Arrange
    file = 'file.txt'
    expected_output = 'could not execute config file file.txt'

    # Act
    test_string = PyFileError(file)

    # Assert
    assert test_string.args[0] == expected_output

# Generated at 2022-06-24 03:37:38.700101
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test_file = 'customer.py'
    err = PyFileError(test_file)
    assert err.args == ("could not execute config file %s", test_file)

# Generated at 2022-06-24 03:37:46.757305
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # Should not raise any exception
    Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area", msg="Custom field")

    # Should raise a TypeError, because scheme is set to None
    try:
        Unauthorized("Auth required.", scheme=None, realm="Restricted Area")
        raise AssertionError("It should raise a TypeError, scheme is set to None")
    except TypeError as e:
        print ("It raises a TypeError, as expected")

    # Should raise a TypeError, because scheme is set to None

# Generated at 2022-06-24 03:37:48.789696
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        print(ServiceUnavailable('test', 503))
    except ServiceUnavailable as e:
        print(e)



# Generated at 2022-06-24 03:37:55.448008
# Unit test for constructor of class SanicException
def test_SanicException():
  class testexception(Exception):
    pass
  test1=testexception("test")
  test2=SanicException("test")
  #test3=SanicException("test",status_code=404, quiet=True)
  try:
    raise testexception("test")
  except Exception as err:
    print(err)
  try:
    raise SanicException("test")
  except Exception as err:
    print(err)
  #try:
  #  raise SanicException("test",status_code=404, quiet=True)
  #except Exception as err:
  #  print(err)

#test_SanicException()

# Generated at 2022-06-24 03:38:01.102887
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        e = Forbidden('You are not allowed to do that.')
        message = 'You are not allowed to do that.'
        status_code = 403
        assert (e.message == message)
        assert (e.status_code == status_code)
    except Exception as e:
        print(e)
        raise RuntimeError('Failed')

if __name__ == '__main__':
    test_Forbidden()

# Generated at 2022-06-24 03:38:04.124790
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    t = RequestTimeout(message="message", status_code=408)
    assert t.__str__() == "message"
    assert t.status_code == 408

# Generated at 2022-06-24 03:38:15.728489
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage:
        pass

    try:
        abort(401)
    except Unauthorized:
        pass

    try:
        abort(403)
    except Forbidden:
        pass

    try:
        abort(404)
    except NotFound:
        pass

    try:
        abort(405)
    except MethodNotSupported:
        pass

    try:
        abort(408)
    except RequestTimeout:
        pass

    try:
        abort(413)
    except PayloadTooLarge:
        pass

    try:
        abort(416)
    except ContentRangeError:
        pass

    try:
        abort(417)
    except HeaderExpectationFailed:
        pass

    try:
        abort(500)
    except ServerError:
        pass


# Generated at 2022-06-24 03:38:17.835011
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Signal is invalid")
    except InvalidSignal:
        pass

# Generated at 2022-06-24 03:38:21.359723
# Unit test for constructor of class NotFound
def test_NotFound():
  inst = NotFound("404 Not Found")
  assert inst.__class__.__name__ == "NotFound"
  assert inst.__class__.__base__.__name__ == "SanicException"
  assert inst.__doc__ == '\n    **Status**: 404 Not Found\n    '


# Generated at 2022-06-24 03:38:24.012272
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound
    except SanicException as e:
        assert str(e) == "400 Bad Request"



# Generated at 2022-06-24 03:38:29.507269
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(401)
    class Unauthorized(SanicException):
        """
        **Status**: 401 Unauthorized
        """
        pass

    assert Unauthorized.status_code == 401
    assert 401 in _sanic_exceptions


if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:38:36.216495
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Without parameter message
    try:
        raise InvalidUsage()
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'Unspecified error'


    # With parameter message == "Bad Request"
    try:
        raise InvalidUsage('Bad Request')
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'Bad Request'


# Generated at 2022-06-24 03:38:40.288197
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    HeadExpectFailed = HeaderExpectationFailed(
        message="Expectation Failed message!", status_code=417)
    assert HeadExpectFailed.status_code == 417
    assert str(HeadExpectFailed) == "Expectation Failed message!"


# Generated at 2022-06-24 03:38:41.084089
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden("It's forbidden")

# Generated at 2022-06-24 03:38:43.351247
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try :
        raise HeaderNotFound('HeaderNotFound')
    except HeaderNotFound as e:
        assert e.args[0] == 'HeaderNotFound'

# Generated at 2022-06-24 03:38:46.422971
# Unit test for constructor of class Forbidden
def test_Forbidden():
    e1 = Forbidden()
    assert e1.message == 'Forbidden'
    e2 = Forbidden('Text for Forbidden')
    assert e2.message == 'Text for Forbidden'


# Generated at 2022-06-24 03:38:51.495752
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(InvalidRangeType) as exception:
        raise InvalidRangeType("Invalid range type", 0)
    assert "Invalid range type" in str(exception)



# Generated at 2022-06-24 03:39:02.159799
# Unit test for constructor of class SanicException
def test_SanicException():
    print("\nUnit test for constructor of class SanicException\n")
    message = "Test Exception"
    status_code = 404
    quiet = None

    t = SanicException(message, status_code, quiet)
    assert t.args[0] == message
    assert t.status_code == status_code
    assert t.quiet == (quiet or quiet is None and status_code != 500)

    # test class functions of SanicException
    assert repr(t) == f"SanicException({message!r}, status_code={status_code}, quiet={quiet})"
    assert str(t) == message

    # test quiet
    for status_code in [None, 500]:
        t = SanicException(message, status_code)
        assert t.quiet is False

    # test status_code
    t = SanicException

# Generated at 2022-06-24 03:39:05.585994
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(SanicException, match=r"Custom error message"):
        raise RequestTimeout(message=r"Custom error message")



# Generated at 2022-06-24 03:39:10.430715
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = 'Some error'
    method = 'GET'
    allowed_methods = ['GET']
    methodNotSupported = MethodNotSupported(message, method, allowed_methods)
    assert methodNotSupported.status_code == 405
    assert methodNotSupported.headers == {'Allow': 'GET'}

# Generated at 2022-06-24 03:39:13.949144
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    """
    Tests to make sure the constructor of HeaderNotFound does not throw an error
    """
    header_not_found = HeaderNotFound("This header is not found")
    assert header_not_found.args[0] == "This header is not found"

# Generated at 2022-06-24 03:39:16.580128
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    print ("============== test_InvalidUsage start ==============")
    invalidUsage = InvalidUsage("test", status_code=400)
    print (invalidUsage.status_code)
    print (invalidUsage.message)
    print (invalidUsage.quiet)
    print ("============== test_InvalidUsage end ==============")

if __name__ == '__main__':
    test_InvalidUsage()

# Generated at 2022-06-24 03:39:18.344160
# Unit test for constructor of class NotFound
def test_NotFound():
    nf=NotFound("Not found")
    assert nf.__str__() == "Not found"


# Generated at 2022-06-24 03:39:21.461844
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = 'app.py'
    try:
        raise PyFileError(file)
    except PyFileError as e:
        assert str(e) == f"could not execute config file {file}"


# Generated at 2022-06-24 03:39:25.239191
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge) as exc_info:
        raise PayloadTooLarge("Payload Too Large")
    assert exc_info.value.status_code == 413

# Generated at 2022-06-24 03:39:28.677338
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed('Expectation failed')
    assert isinstance(exception, HeaderExpectationFailed)
    assert isinstance(exception, SanicException)
    assert isinstance(exception, Exception)


# Generated at 2022-06-24 03:39:31.969950
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    exception = FileNotFound("message", "path", "relative_url")
    assert exception.path == "path"
    assert exception.relative_url == "relative_url"
    assert str(exception) == "message"


# Generated at 2022-06-24 03:39:33.341294
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("'app.py' file not found in current directory")

# Generated at 2022-06-24 03:39:37.496627
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        with pytest.raises(ContentRangeError):
            raise ContentRangeError("Content Range Error", 10)
    except ContentRangeError as e:
        assert e.message == "Content Range Error"
        assert e.status_code == 416
        assert e.headers == {"Content-Range": "bytes */10"}



# Generated at 2022-06-24 03:39:44.150849
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    test_instance = ServiceUnavailable('Test Failed')
    assert test_instance.status_code == 503
    assert test_instance.quiet == True
    # Unit test for instance of class ServiceUnavailable
    assert isinstance(test_instance, SanicException)
    assert isinstance(test_instance, ServiceUnavailable)
    assert isinstance(test_instance, Exception)
    assert isinstance(test_instance, BaseException)


# Generated at 2022-06-24 03:39:46.451990
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test", relative_path="test")
    except Exception as e:
        assert e.relative_path == "test"

# Generated at 2022-06-24 03:39:51.092094
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "How did you get this? Really?"
    method = "PUT"
    allowed_methods = ["GET", "POST"]
    exception = MethodNotSupported(message=message, method=method, allowed_methods=allowed_methods)
    assert exception.message == message
    assert exception.headers["Allow"] == "GET, POST"

# Generated at 2022-06-24 03:39:55.281614
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "invalid usage"
    status_code = 400
    quiet = True
    sanic_exception = SanicException(message, status_code, quiet)
    assert sanic_exception.message, message
    assert sanic_exception.status_code, status_code
    assert sanic_exception.quiet, quiet


# Generated at 2022-06-24 03:39:58.372642
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert _sanic_exceptions[500].status_code == 500



# Generated at 2022-06-24 03:40:00.289247
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError(message="error message")
    except Exception as e:
        assert e.__str__() == "Exception: error message"

# Generated at 2022-06-24 03:40:03.812567
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout = RequestTimeout('Time out', 408)
    assert timeout.headers == None
    assert timeout.status_code == 408


# Generated at 2022-06-24 03:40:06.870435
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exception = InvalidRangeType('test', None)
    assert exception.headers == {'Content-Range': 'bytes */None'}

if __name__ == '__main__':
    test_InvalidRangeType()

# Generated at 2022-06-24 03:40:10.116634
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as excinfo:
        raise ContentRangeError("test", 1)
    assert excinfo.value.status_code == 416
    assert excinfo.value.headers == {'Content-Range': 'bytes */1'}


# Generated at 2022-06-24 03:40:16.573652
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    print("Constructor of class FileNotFound")
    exception = FileNotFound("file not found", "file_path", "relative_url")
    print("exception.path:", exception.path)
    print("exception.relative_url:", exception.relative_url)
    print("exception.message:", exception.message)
    print("exception.status_code:", exception.status_code)
    print("exception.quiet:", exception.quiet)
    print("exception.__dict__:", exception.__dict__)


# Generated at 2022-06-24 03:40:19.822091
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message='a', status_code=500)
    except SanicException as e:
        assert e.message=='a'
        assert e.status_code==500
        assert e.quiet==True

# Generated at 2022-06-24 03:40:21.065153
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable("test").status_code == 503


# Generated at 2022-06-24 03:40:28.947003
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except SanicException as exc:
        assert exc.status_code == 400
        assert str(exc) == STATUS_CODES[400].decode('utf8')

    try:
        abort(400, 'test')
    except SanicException as exc:
        assert exc.status_code == 400
        assert str(exc) == 'test'

    try:
        abort(500, 'test')
    except SanicException as exc:
        assert exc.status_code == 500
        assert str(exc) == 'test'
        assert exc.quiet is False

    try:
        abort(503, 'test')
    except SanicException as exc:
        assert exc.status_code == 503
        assert str(exc) == 'test'
        assert exc.quiet is True


# Generated at 2022-06-24 03:40:32.486349
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("test")
    except Forbidden as exc:
        assert exc.status_code == 403
        assert exc.message == "test"

# Generated at 2022-06-24 03:40:36.898332
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception1 = Forbidden(message='the forbidden error', status_code=403)
    assert exception1.status_code == 403
    exception2 = Forbidden(message='the forbidden error', status_code=400)
    assert exception2.status_code == 400

# Generated at 2022-06-24 03:40:38.670794
# Unit test for constructor of class Forbidden
def test_Forbidden():
    message = "Forbidden"
    forbidden = Forbidden(message, status_code=403)
    assert forbidden.message == message

# Generated at 2022-06-24 03:40:41.249840
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    h = HeaderNotFound("Header Not Found Exception")
    assert h.message == "Header Not Found Exception"
    assert h.status_code == 400
    assert h.quiet == True

# Generated at 2022-06-24 03:40:44.794674
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class ClassAddStatusCode(SanicException):
        pass
    assert ClassAddStatusCode.status_code == 404
    assert _sanic_exceptions[404] == ClassAddStatusCode

# Generated at 2022-06-24 03:40:48.225899
# Unit test for constructor of class NotFound
def test_NotFound():
    nf= NotFound("Message for the test for class NotFound")
    assert nf.status_code == 404
    assert nf.message == "Message for the test for class NotFound"
    assert nf.quiet is True


# Generated at 2022-06-24 03:40:49.900464
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(Exception, match="load file failed"):
        foo = 1 / 0

# Generated at 2022-06-24 03:40:51.839430
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("InvalidSignal")
    except InvalidSignal as e:
        assert str(e) == "InvalidSignal"

# Generated at 2022-06-24 03:40:59.703254
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exc = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert exc.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    exc = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert exc.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", algorithm="MD5", nonce="abcdef", opaque="zyxwvu", qop="auth, auth-int"'
    exc = Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    assert exc.headers["WWW-Authenticate"] == 'Bearer realm="Restricted Area"'
    exc = Unauthorized("Auth required.", scheme="Bearer")


# Generated at 2022-06-24 03:41:10.147584
# Unit test for function add_status_code
def test_add_status_code():
    class my_exception(SanicException):
        pass

    @add_status_code(404)
    class my_exception2(SanicException):
        pass

    @add_status_code(400)
    class my_exception3(SanicException):
        pass

    @add_status_code(500)
    class my_exception4(SanicException):
        pass

    @add_status_code(404, True)
    class my_exception5(SanicException):
        pass

    assert my_exception.status_code is None
    assert my_exception.quiet is False
    assert my_exception2.status_code == 404
    assert my_exception2.quiet is True
    assert my_exception3.status_code == 400

# Generated at 2022-06-24 03:41:13.678632
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden_obj = Forbidden("message")
    assert forbidden_obj.__class__.__name__ == "Forbidden"
    assert str(forbidden_obj) == "message"
    assert forbidden_obj.status_code == 403


# Generated at 2022-06-24 03:41:19.015145
# Unit test for constructor of class PyFileError
def test_PyFileError():
    expected_output = "could not execute config file %s"
    try:
        raise PyFileError("config_file.py")
    except Exception as e:
        assert str(e) == expected_output


# Generated at 2022-06-24 03:41:20.506260
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException



# Generated at 2022-06-24 03:41:25.443843
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal(message='signal_name_error')
    except InvalidSignal as e:
        assert e.args[0] == 'signal_name_error'
        assert e.args[1] == None
        assert e.args[2] == None

# Generated at 2022-06-24 03:41:27.651474
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    service_unavailable_obj = ServiceUnavailable("ServiceUnavailable_message")
    assert service_unavailable_obj.message == "ServiceUnavailable_message"

# Generated at 2022-06-24 03:41:29.391956
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError) as excinfo:
        raise ServerError('foo', 500)



# Generated at 2022-06-24 03:41:35.238957
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    x = ServiceUnavailable("Service Unavailable")
    print(x.status_code)
    print(x.message)
    x = ServiceUnavailable("Service Unavailable", 503)
    print(x.status_code)
    print(x.message)


if __name__ == "__main__":
    test_ServiceUnavailable()

# Generated at 2022-06-24 03:41:38.459845
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    obj = RequestTimeout("Hello World", None)
    assert obj.status_code == 408
    assert obj.__str__() == "Hello World"

test_RequestTimeout()

# Generated at 2022-06-24 03:41:40.674269
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert str(InvalidRangeType("message","content_range")).replace(" ","")\
    == "InvalidRangeType: message, headers={'Content-Range': 'bytes */content_range'}".replace(" ", "")


# Generated at 2022-06-24 03:41:42.330073
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden("there is a error")


# Generated at 2022-06-24 03:41:44.394391
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = InvalidRangeType("test message", 0)
    assert a.args[0] == "test message"
    assert a.headers == {"Content-Range": "bytes */0"}

# Generated at 2022-06-24 03:41:48.298024
# Unit test for constructor of class ServerError
def test_ServerError():
    # Arrange
    msg = 'test message'
    # Act
    ex = ServerError(msg)
    # Assert
    assert ex.message == msg
    assert ex.status_code == 500
    assert ex.quiet  == False


if __name__ == "__main__":
    test_ServerError()

# Generated at 2022-06-24 03:41:52.134910
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(FileNotFoundError):
        raise PyFileError('C:\\example\\example-dir')



# Generated at 2022-06-24 03:42:01.219627
# Unit test for function add_status_code
def test_add_status_code():
    def assert_add_status_code(status_code, expected_code):
        c = add_status_code(status_code)
        assert callable(c)
        assert len(c.__closure__) == 1
        assert c.__closure__[0].cell_contents == expected_code
        return c

    assert_add_status_code(404, 404)(SanicException)
    assert_add_status_code(500, 404)(SanicException)
    assert_add_status_code(None, 500)(SanicException)
    abort(404)
    abort(500)

# Generated at 2022-06-24 03:42:12.231988
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    Test SanicException.
    """
    with pytest.raises(SanicException, match="test"):
        SanicException("test")
    with pytest.raises(SanicException, match="test") as exception:
        SanicException("test", status_code=123)
        assert exception.status_code == 123
    with pytest.raises(SanicException, match="test") as exception:
        SanicException("test", quiet=True)
        assert exception.quiet
    with pytest.raises(SanicException, match="test") as exception:
        SanicException("test", status_code=123, quiet=True)
        assert exception.status_code == 123
        assert exception.quiet


# Generated at 2022-06-24 03:42:14.411996
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(FileNotFound):
        raise FileNotFound("File not found!", "test.py", "404.html")


# Generated at 2022-06-24 03:42:16.960490
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    err = InvalidUsage('msg', 599)
    assert err.message == 'msg'
    assert err.status_code == 599

# Generated at 2022-06-24 03:42:23.502105
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # SanicException(message, status_code=None, quiet=None)
    message1 = "test message"
    message2 = "test message"
    try:
        raise PayloadTooLarge(message1, message2)
    except SanicException:
        pass
    except Exception as e:
        print (e)

if __name__ == '__main__':
    test_PayloadTooLarge()

# Generated at 2022-06-24 03:42:27.599511
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    import pytest
    class FakeReq:
        pass
    req = FakeReq()

    with pytest.raises(Unauthorized):
        raise Unauthorized("Unauthorized...")


if __name__ == '__main__':
    test_Unauthorized()

# Generated at 2022-06-24 03:42:32.401808
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    total = 100
    content_range_error = ContentRangeError('test', total)
    assert content_range_error.message == 'test'
    assert content_range_error.headers['Content-Range'] == f'bytes */{total}'

# Generated at 2022-06-24 03:42:40.588168
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400 and str(e) == "400: Bad Request"
    else:
        assert False

    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404 and str(e) == "404: Not Found"
    else:
        assert False

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500 and str(e) == "500: Internal Server Error"
    else:
        assert False


test_abort()

# Generated at 2022-06-24 03:42:43.399256
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('time out')
    except Forbidden as e:
        assert e.status_code == 403
        assert e.quiet == True
        assert isinstance(e, SanicException)


# Generated at 2022-06-24 03:42:45.670928
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    msg = 'message'
    exception = HeaderExpectationFailed(msg)
    assert exception.message == msg
    assert exception.status_code == 417

# Generated at 2022-06-24 03:42:51.622553
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        headers = {
            'WWW-Authenticate': 'Basic realm="Restricted Area"',
            'Content-Type': 'text/html; charset=UTF-8',
        }
        raise Unauthorized("Auth required. Please login with username and password.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == headers

# Generated at 2022-06-24 03:42:54.366263
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found:abc")
    except HeaderNotFound as e:
        assert e.args[0] == "Header not found:abc"

# Generated at 2022-06-24 03:43:03.481493
# Unit test for function abort
def test_abort():
    # Make sure that status_code does not change if specific message
    # specified.
    try:
        abort(status_code=404, message="Example Message")
    except SanicException as e:
        assert e.status_code == 404

    # Test that message changes when passed a different status_code
    try:
        abort(status_code=401)
    except SanicException as e:
        assert e.message == "Unauthorized"

    # Test that message is not required.
    try:
        abort(status_code=400)
    except SanicException as e:
        assert e.message == "Bad Request"

# Generated at 2022-06-24 03:43:05.916588
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    e = PayloadTooLarge('Too Large')
    assert e.message == 'Too Large'
    assert e.status_code == 413

# Generated at 2022-06-24 03:43:12.405127
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    err = PayloadTooLarge("The payload is too large.")
    assert err.args == ("The payload is too large.",)
    assert err.status_code == 413
    assert err.message == "The payload is too large."
    assert err.quiet == True
    w = PayloadTooLarge("The payload is too large.")
    with pytest.raises(PayloadTooLarge):
        raise w

# Generated at 2022-06-24 03:43:18.638015
# Unit test for constructor of class ServerError
def test_ServerError():
    import unittest
    import sys
    class Tester(unittest.TestCase):
        def test_message(self):
            exc = ServerError("Exception occurs in the server")
            self.assertTrue("Exception occurs in the server" in str(exc))
    suite = unittest.TestLoader().loadTestsFromTestCase(Tester)
    unittest.TextTestRunner(verbosity=2, stream=sys.stderr).run(suite)

# ServerError class unit test
test_ServerError()


# Generated at 2022-06-24 03:43:20.075104
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    assert HeaderExpectationFailed("message", "test") is not None

# Generated at 2022-06-24 03:43:22.338925
# Unit test for function abort
def test_abort():
    try:
        abort(404, message="File not found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "File not found"

# Generated at 2022-06-24 03:43:25.118695
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert isinstance(URLBuildError('SOME MESSAGE'), SanicException)

# Generated at 2022-06-24 03:43:28.613393
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('InvalidUsage')
    except:
        pass


# Generated at 2022-06-24 03:43:33.274353
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # This code is executed when this module is run stand-alone
    ex = RequestTimeout('Message', 408)
    assert ex.status_code == 408
    assert ex.message == 'Message'



# Generated at 2022-06-24 03:43:36.625705
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException):
        abort(500)
    with pytest.raises(ServerError):
        abort(500, message="test")
    with pytest.raises(MethodNotSupported):
        abort(405, message="test")

# Generated at 2022-06-24 03:43:42.213753
# Unit test for function abort
def test_abort():
    abort(404)
    abort(404, "test")

    try:
        abort(500)
    except ServerError:
        pass

    try:
        abort(500, "test")
    except ServerError:
        pass

# Generated at 2022-06-24 03:43:48.172374
# Unit test for function abort
def test_abort():
    # Test with status code that exists in STATUS_CODES
    with pytest.raises(SanicException):
        abort(400)

    # Test with status code that does not exist in STATUS_CODES
    with pytest.raises(SanicException):
        abort(999)

# Generated at 2022-06-24 03:43:56.436200
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        # first test: nothing was passed
        raise SanicException()
    except SanicException as exc:
        assert exc.message == ""

    try:
        # second test: status_code was not passed
        raise SanicException("test")
    except SanicException as exc:
        assert exc.message == "test"
        assert exc.status_code == None
        assert exc.quiet == None

    try:
        # third test: status_code was passed
        raise SanicException("test", 400)
    except SanicException as exc:
        assert exc.message == "test"
        assert exc.status_code == 400
        assert exc.quiet == True


# Generated at 2022-06-24 03:43:58.239617
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException) as e:
        print(e)

# Generated at 2022-06-24 03:44:00.288632
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("The server timed out waiting for the request.")
    finally:
        pass

# Generated at 2022-06-24 03:44:03.397986
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test")
    except ServiceUnavailable as e:
        assert e.message == "test"
        assert e.status_code == 503
        assert e.quiet == True
        assert e.headers == None


# Generated at 2022-06-24 03:44:07.607557
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported) as exception:
        raise MethodNotSupported("message", "method", ["allowed_methods"])
    assert exception.value.headers['Allow'] == "allowed_methods"


# Generated at 2022-06-24 03:44:18.079484
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    from unittest.mock import Mock
    from sanic.response import HTTPResponse as Response
    r = PayloadTooLarge("a", 100, 100)
    # Mock sanic.request.Request
    r.request = Mock()
    # Mock sanic.response.BaseHTTPResponse
    r.request.response_class = Mock()
    # Mock sanic.response.HTTPResponse:
    r.request.response_class.return_value = Response("")
    # Set a logger
    r.request.app.logger = Mock()

    # If a response has a payload, status will be set to 200
    r.request.response_class.return_value.has_body = True
    r.request.response_class.return_value.body = "a"
    assert HTTPException(r).status

# Generated at 2022-06-24 03:44:20.691465
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Payload is too large", 413)
    except Exception as e:
        assert e.status_code == 413



# Generated at 2022-06-24 03:44:26.380798
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Exception as e:
        assert e.message == "Auth required."
        assert e.scheme == "Basic"
        assert e.kwargs == {"realm": "Restricted Area"}

# Generated at 2022-06-24 03:44:27.687162
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException('Test', 'Test')
    assert exception.message == 'Test'
    assert exception.status_code == 'Test'

# Generated at 2022-06-24 03:44:31.100943
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exc = HeaderNotFound(message='header not found')
    assert exc.args == ('header not found',)
    assert exc.status_code == 400
    assert exc.quiet == False

# Generated at 2022-06-24 03:44:34.384973
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Error de teste")
    except InvalidUsage as e:
        assert e.status_code == 400

# Generated at 2022-06-24 03:44:37.881414
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError("file")
    assert str(e) == "file"

# Generated at 2022-06-24 03:44:42.022073
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    fake_url = "https://www.example.com/test"
    fake_error = "Testing for URLBuildError"
    try:
        raise URLBuildError(fake_url, fake_error)
    except URLBuildError as e:
        assert e.url == fake_url
        assert e.error == fake_error

# Generated at 2022-06-24 03:44:43.924134
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout('abc', "GET")
    print(rt.args)
    print(rt.status_code)

# Generated at 2022-06-24 03:44:45.751892
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request is timeout.")
    except RequestTimeout as e:
        assert e.args[0] == 'Request is timeout.'

# Generated at 2022-06-24 03:44:51.247136
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method not supported"
    method = "POST"
    allowed_methods = ["GET", "PUT"]
    m = MethodNotSupported(message, method, allowed_methods)
    assert m.message == message
    assert m.method == method
    assert m.allowed_methods == allowed_methods

# Generated at 2022-06-24 03:44:54.710016
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Too large")
    except PayloadTooLarge as exc:
        assert exc.status_code == 413
        assert exc.quiet is True

# Generated at 2022-06-24 03:44:59.977678
# Unit test for function abort
def test_abort():
    abort_message = 'abort_message'
    try:
        abort(404, abort_message)
    except Exception as e:
        assert e.status_code == 404
        assert e.message == abort_message
    try:
        abort(503)
    except Exception as e:
        assert e.status_code == 503
        assert e.message == 'Service Unavailable'

# Generated at 2022-06-24 03:45:05.364484
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError, message="could not execute config file test"):
        raise PyFileError("test")


# Generated at 2022-06-24 03:45:07.904610
# Unit test for constructor of class SanicException
def test_SanicException():
    status_code = 404
    message = "Test"

    e = SanicException(message, status_code)
    assert e.status_code == status_code
    assert e.args == (message, )
    assert e.quiet is False



# Generated at 2022-06-24 03:45:11.881348
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('测试')
    except Exception as e:
        assert e.message == '测试'
        assert e.status_code == 500


# Generated at 2022-06-24 03:45:15.527453
# Unit test for constructor of class ServerError
def test_ServerError():
    msg = "This is an error message for testing ServerError"
    try:
        raise ServerError(msg)
    except Exception as err:
        assert (msg, 500) == (err.args[0], err.status_code)


# Generated at 2022-06-24 03:45:19.566205
# Unit test for function add_status_code
def test_add_status_code():
    exception_map = {}
    assert exception_map == {}
    for status_code, message in STATUS_CODES.items():
        exception_map[status_code] = add_status_code(status_code)(SanicException)
    assert exception_map == _sanic_exceptions

if __name__ == "__main__":
    test_add_status_code()

# Generated at 2022-06-24 03:45:24.237776
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("the size of the request is too long")
    except PayloadTooLarge as e:
        print(e.status_code)
        assert e.status_code == 413


# Generated at 2022-06-24 03:45:28.055384
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError()
    assert isinstance(pyfileerror, PyFileError)


# Generated at 2022-06-24 03:45:31.199544
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('You are not allowed to do this')
    except Forbidden:
        s = str(sys.exc_info()[1])
    assert s == 'You are not allowed to do this'


# Generated at 2022-06-24 03:45:34.395993
# Unit test for constructor of class ServerError
def test_ServerError():
    err = SanicException('some message', status_code=400)
    err.status_code = 1
    assert err.status_code == 400

# Generated at 2022-06-24 03:45:38.517896
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as context:
        raise InvalidUsage('Invalid usage', status_code=400)
    assert 'Invalid usage' in str(context.value)
    assert context.value.status_code == 400


# Generated at 2022-06-24 03:45:42.512234
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Hello world!", status_code=400)
    except InvalidUsage as e:
        assert(e.status_code == 400)
        assert(e.quiet == True)
        assert(e.message == "Hello world!")


# Generated at 2022-06-24 03:45:43.576986
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge("400")

# Generated at 2022-06-24 03:45:46.879889
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    test_HeaderNotFound = HeaderNotFound("Test")
    assert test_HeaderNotFound.status_code == 400
    assert str(test_HeaderNotFound) == "Test"


# Generated at 2022-06-24 03:45:53.309727
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(200)
    class OK(SanicException):
        pass

    assert OK.status_code == 200
    assert _sanic_exceptions[200] == OK

    @add_status_code(201)
    class Created(SanicException):
        pass

    assert Created.status_code == 201
    assert _sanic_exceptions[201] == Created


# Generated at 2022-06-24 03:45:56.575621
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert RequestTimeout('Timeout', status_code=408)

# Generated at 2022-06-24 03:46:00.685207
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Invalid Header 'test'")
    except HeaderNotFound as e:
        assert e.message == "Invalid Header 'test'"
        assert e.status_code is 400
        assert 'Invalid Header' in str(e)


# Generated at 2022-06-24 03:46:04.052011
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('Request timeout')
    except RequestTimeout as err:
        assert err.status_code == 408
        assert err.message == 'Request timeout'
        assert str(err) == '408: Request Timeout'


# Generated at 2022-06-24 03:46:06.180522
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound) as e:
        raise NotFound()


# Generated at 2022-06-24 03:46:09.603776
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):  # 测试抛出了 LoadFileException 异常
        raise LoadFileException


# Generated at 2022-06-24 03:46:20.186633
# Unit test for function abort
def test_abort():
    try:
        abort(403)
    except SanicException as ex:
        assert ex.status_code == 403
    try:
        abort(404)
    except NotFound as ex:
        assert ex.status_code == 404
    try:
        abort(500)
    except ServerError as ex:
        assert ex.status_code == 500
    try:
        abort(503)
    except ServiceUnavailable as ex:
        assert ex.status_code == 503
    try:
        abort(400)
    except InvalidUsage as ex:
        assert ex.status_code == 400
    try:
        abort(416)
    except ContentRangeError as ex:
        assert ex.status_code == 416
    try:
        abort(401)
    except Unauthorized as ex:
        assert ex.status_code == 401


# Generated at 2022-06-24 03:46:25.427978
# Unit test for constructor of class SanicException
def test_SanicException():
    assert(SanicException("Testing", 1, True).message == "Testing")
    assert(SanicException("Testing", 1, True).status_code == 1)
    assert(SanicException("Testing", 1, True).quiet == True)
    assert(SanicException("Testing", 1, True).__str__() == "Testing")


# Generated at 2022-06-24 03:46:27.583384
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test", "test")
    except Exception as e:
        assert e.args == ("test", "test")

# Generated at 2022-06-24 03:46:33.535795
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Any message')
    except ServerError as exc:
        assert exc.message == 'Any message'
        assert exc.status_code == 500
    else:
        raise Exception('ServerError was not raised')

# Generated at 2022-06-24 03:46:37.388159
# Unit test for function add_status_code
def test_add_status_code():
    def test_decorator(cls):
        cls.status_code = 423
        return cls

    @test_decorator
    class TestAbort(SanicException):
        pass

    assert TestAbort.status_code == 423



# Generated at 2022-06-24 03:46:45.446135
# Unit test for function add_status_code
def test_add_status_code():
    global STATUS_CODES
    old_count = len(_sanic_exceptions)

    class AwesomeError(Exception):
        pass

    @add_status_code(418, True)
    class AwesomeErrorImaTeapot(Exception):
        pass

    assert len(_sanic_exceptions) == (old_count + 2)
    assert _sanic_exceptions[418].__name__ == 'AwesomeErrorImaTeapot'
    assert _sanic_exceptions[418]().quiet is True
    assert _sanic_exceptions[418]().status_code == 418

    # Run the function twice to check that it is idempotent
    @add_status_code(418, True)
    class AwesomeErrorImaTeapot(Exception):
        pass


# Generated at 2022-06-24 03:46:47.565758
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file = FileNotFound("file not found","/home","/home/p")
    assert file.path == "/home"
    assert file.relative_url == "/home/p"

# Generated at 2022-06-24 03:46:48.909190
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("Timeout")

# Generated at 2022-06-24 03:46:53.617306
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exc = MethodNotSupported("test", "GET", ["HEAD"])
    assert exc.headers["Allow"] == "HEAD"
    assert exc.status_code == 405

# Generated at 2022-06-24 03:46:56.206360
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found = HeaderNotFound("test")
    assert header_not_found.status_code == 400

# Generated at 2022-06-24 03:46:59.566690
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid signal error")
    except InvalidSignal as e:
        msg = str(e)
        assert msg == "Invalid signal error"



# Generated at 2022-06-24 03:47:01.944007
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("")
    except RequestTimeout as e:
        assert e.__str__() == "RequestTimeout"

# Generated at 2022-06-24 03:47:07.321503
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    err = Unauthorized("foo", realm="bar")
    assert 400 <= err.status_code < 500
    assert "WWW-Authenticate" in err.headers
    assert err.headers["WWW-Authenticate"] == 'Basic realm="bar"'
    assert str(err) == "foo"
    assert err.args == ("foo",)

# Generated at 2022-06-24 03:47:09.810981
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Error loading config file")
    except LoadFileException as e:
        assert str(e) == "Error loading config file"
        assert e.status_code == 500


# Generated at 2022-06-24 03:47:14.047673
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['GET', 'POST']
    instance = MethodNotSupported("message", 'GET', allowed_methods)
    assert instance.status_code == 405
    assert instance.headers == {"Allow": ", ".join(allowed_methods)}


# Generated at 2022-06-24 03:47:17.866972
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "The header is not found"
    header_not_found = HeaderNotFound(message)
    assert header_not_found.message == message

if __name__ == "__main__":
    test_HeaderNotFound()