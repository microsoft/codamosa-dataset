

# Generated at 2022-06-24 03:37:27.027457
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException('message')


# Generated at 2022-06-24 03:37:30.255363
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    p = PayloadTooLarge("Payload exceeded the 2mb limit", 2)
    assert p.message == "Payload exceeded the 2mb limit"
    assert p.status_code == 413
    assert p.quiet == True

# Generated at 2022-06-24 03:37:32.355865
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError(message="test message")
    assert e.args[0] == "test message"


# Generated at 2022-06-24 03:37:38.957031
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test InvalidSignal")
    except Exception as e:
        assert type(e) == InvalidSignal
        assert e.args == ("test InvalidSignal",)

# Generated at 2022-06-24 03:37:41.439568
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pytest.raises(PayloadTooLarge, PayloadTooLarge, "GOT PAYLOAD TOO LARGE", 411)

# Generated at 2022-06-24 03:37:43.993088
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = ServerError(message='server error')
    assert exception.status_code == 500
    assert exception.message == 'server error'


# Generated at 2022-06-24 03:37:47.298658
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    class_instance = HeaderExpectationFailed("The server cannot meet the requirements of the Expect request-header field.")
    assert class_instance is not None
    assert class_instance.status_code == 417

# Generated at 2022-06-24 03:37:49.356438
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(SanicException):
        raise InvalidSignal(message=None, status_code=None, scheme=None, **None)

# Generated at 2022-06-24 03:37:57.395625
# Unit test for function abort
def test_abort():
    try:
        abort(401)
    except SanicException as e:
        assert e.status_code == 401

    try:
        abort(404, b"a")
    except SanicException as e:
        assert e.status_code == 404
        assert e.message == "a"

    try:
        abort(500, "a")
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "a"

# Generated at 2022-06-24 03:37:59.471768
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    exc = RequestTimeout('Syntax error')
    assert exc.status_code == 408
    assert str(exc) == 'Syntax error'

# Generated at 2022-06-24 03:38:03.398658
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """Test the constructor of class RequestTimeout."""
    request_timeout = RequestTimeout('1 hour')
    assert request_timeout.status_code == 408
    assert request_timeout.message == '1 hour'


# Generated at 2022-06-24 03:38:11.830835
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as err:
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", algorithm="MD5", nonce="abcdef", opaque="zyxwvu", qop="auth, auth-int"'

# Generated at 2022-06-24 03:38:12.906865
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    MethodNotSupported("Test", "GET", ["GET"])

# Generated at 2022-06-24 03:38:15.273167
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = "NotFound message"
    exc = NotFound(message=msg)
    assert exc.status_code == 404
    assert exc.message == msg


# Generated at 2022-06-24 03:38:17.822601
# Unit test for constructor of class PyFileError
def test_PyFileError():

    exception = PyFileError("example")
    assert exception.args[0] == "could not execute config file %s"
    assert exception.args[1] == "example"

# Generated at 2022-06-24 03:38:20.619312
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge("Test custom message")
    assert payload_too_large.message == "Test custom message"
    assert payload_too_large.status_code == 413

# Generated at 2022-06-24 03:38:25.596004
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exc = LoadFileException("message")
    assert exc.status_code == 500
    assert exc.quiet == True
    assert exc.headers == {}
    assert exc.message == "message"
    assert str(exc) == "message"
    return


# Generated at 2022-06-24 03:38:29.868735
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large_exc = PayloadTooLarge('Payload Too Large.')
    assert payload_too_large_exc.message == 'Payload Too Large.'
    assert payload_too_large_exc.status_code == 413
    assert payload_too_large_exc.headers == {}


# Generated at 2022-06-24 03:38:41.263878
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    message = "Error"
    path = "C:\\users\\SomeUser\\SomePath\\file.py"
    relative_url = "\\users\\SomeUser\\SomePath\\file.py"
    exception = FileNotFound(message=message, path=path, relative_url=relative_url)
    assert exception.message == message
    assert exception.path == path
    assert exception.relative_url == relative_url
    assert exception.__str__() == "Error"
    assert exception.status_code == 404
    response = exception.get_response()
    assert isinstance(response, HTTPResponse)
    assert response.status == 404
    assert response.body == message


# Generated at 2022-06-24 03:38:46.374484
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

# Generated at 2022-06-24 03:38:51.179540
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(InvalidRangeType) as ex:
        raise InvalidRangeType("", "")
    assert ex.match(r'\(\?\)$')

# Generated at 2022-06-24 03:38:54.404821
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    cls = MethodNotSupported("", "", [])
    assert cls.headers is not None

# Generated at 2022-06-24 03:39:00.668823
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("Not Found", "SOME_FILE", "/some/path")
    except FileNotFound as e:
        assert e.path == "SOME_FILE"
        assert e.relative_url == "/some/path"



# Generated at 2022-06-24 03:39:05.474104
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message", path="aa", relative_url="bb")
    except FileNotFound as e:
        assert e.path == "aa"
        assert e.relative_url == "bb"
        assert e.message == "message"


# Generated at 2022-06-24 03:39:09.429735
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("test_FileNotFound")
    except FileNotFound as file_not_found:
        assert file_not_found.path == None
        assert file_not_found.relative_url == None

# Generated at 2022-06-24 03:39:10.975098
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("test")
    except:
        pass

# Generated at 2022-06-24 03:39:14.098509
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as execinfo:
        raise PyFileError('text.py')
    assert str(execinfo.value) == 'could not execute config file text.py'

# Generated at 2022-06-24 03:39:16.973064
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as e:
        assert e.headers['WWW-Authenticate'] == 'Bearer'


# Generated at 2022-06-24 03:39:19.055855
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        a = InvalidRangeType("", None)
    except:
        assert False
        return
    assert True


# Generated at 2022-06-24 03:39:27.067311
# Unit test for constructor of class FileNotFound
def test_FileNotFound():

    message = "The requested file is not found"
    path = "/foo/bar/baz.txt"
    relative_url = "/baz.txt"

    try:
        raise FileNotFound(message=message, path=path, relative_url=relative_url)
    except FileNotFound as not_found:
        assert not_found.message == message
        assert not_found.path == path
        assert not_found.relative_url == relative_url


if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-24 03:39:30.614343
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('test')
    except (ServerError):
        pass
    else:
        raise Exception('URLBuildError did not cause exception')


# Generated at 2022-06-24 03:39:32.715913
# Unit test for constructor of class Forbidden
def test_Forbidden():
    ex = Forbidden(message="")
    assert ex.status_code == 403
    assert not hasattr(ex, 'headers')



# Generated at 2022-06-24 03:39:36.539899
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Method not supported.", "PUT", ["GET", "HEAD"])
    except MethodNotSupported as e:
        assert "Method not supported." in str(e)
        assert "Allow" in e.headers
        assert "GET, HEAD" in e.headers["Allow"]

# Generated at 2022-06-24 03:39:39.500454
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage("Invalid Message", status_code=400)
    assert error.message == "Invalid Message"
    assert error.status_code == 400


# Generated at 2022-06-24 03:39:50.744445
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        # With a Basic auth-scheme, realm MUST be present:
        raise Unauthorized(
            "Auth required.", scheme="Basic", realm="Restricted Area"
        )
    except Unauthorized as e:
        cmp_str = b'Basic realm="Restricted Area"'
        assert e.headers["WWW-Authenticate"].strip().encode() == cmp_str


# Generated at 2022-06-24 03:39:52.456249
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Forbidden:
        assert True
        return
    assert False

# Generated at 2022-06-24 03:39:57.726577
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("The data value transmitted exceeded the capacity limit.")
    except:
        response = {'text': '{"message":"The data value transmitted exceeded the capacity limit."}', 
                    'status': 413, 
                    'body': b'{"message":"The data value transmitted exceeded the capacity limit."}', 
                    'headers': {'Content-Type': 'application/json'}}
    
    assert response is not None
    assert response['status'] == 413


# Generated at 2022-06-24 03:40:01.186577
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found_object = HeaderNotFound("test header not found exception")
    assert header_not_found_object.message == "test header not found exception"
    assert header_not_found_object.args == ("test header not found exception",)
    assert header_not_found_object.status_code == 400


# Generated at 2022-06-24 03:40:04.969940
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message='TEST', status_code=200)
    except SanicException as e:
        assert e.status_code == 200


# Generated at 2022-06-24 03:40:06.275813
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden(message='Forbidden', status_code=403)

# Generated at 2022-06-24 03:40:08.721547
# Unit test for constructor of class Forbidden
def test_Forbidden():
    message = "hello world"
    status_code = 403
    f = Forbidden(message, status_code)
    assert f.message == message
    assert f.status_code == status_code

# Generated at 2022-06-24 03:40:14.667855
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("This is a test", "This is a test")
    except HeaderExpectationFailed as ex:
        assert ex.args[0] == "This is a test"
        assert ex.status_code == 417

# Generated at 2022-06-24 03:40:17.004559
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid signal")
    except InvalidSignal as e:
        assert str(e) == "Invalid signal"

# Generated at 2022-06-24 03:40:18.394411
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('Forbidden')
    assert forbidden.status_code == 403

# Generated at 2022-06-24 03:40:23.045108
# Unit test for function abort
def test_abort():
    with pytest.raises(InvalidUsage) as excinfo:
        abort(status_code=400)
    assert excinfo.value.__str__().strip() == "Bad Request"

    with pytest.raises(ServerError) as excinfo:
        abort(status_code=500, message="Test")
    assert excinfo.value.__str__().strip() == "Test"


# Copyright 2018 codedriver

# Generated at 2022-06-24 03:40:25.059900
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException().status_code == 400

# Generated at 2022-06-24 03:40:28.712777
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "this is a message"
    path = "this is a path"
    relative_url = "relative/url"
    exception = FileNotFound(message, path, relative_url)
    assert exception.message == message
    assert exception.path == path
    assert exception.relative_url == relative_url



# Generated at 2022-06-24 03:40:32.135014
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exc = URLBuildError("test error")
    assert exc.message == "test error"
    assert exc.status_code == 500


# Generated at 2022-06-24 03:40:35.206076
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    message = "This is a test InvalidUsage"
    test = InvalidUsage(message)
    assert test.message == message
    assert test.status_code == 400



# Generated at 2022-06-24 03:40:37.828651
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("message", status_code=403)
    assert f.args[0] == "message"
    assert f.status_code == 403
    assert str(f) == "message"

# Generated at 2022-06-24 03:40:42.105633
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as error:
        raise PyFileError('this is py file error')
    print(error.value)
    print(error.value.args)
    print(error.value.args[0])
    assert error.type == PyFileError


# Generated at 2022-06-24 03:40:45.612803
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid = InvalidUsage()
    assert invalid.status_code == 400
    assert invalid.quiet == True
    invalid = InvalidUsage(status_code=500)
    assert invalid.status_code == 500
    assert invalid.quiet == False

# Generated at 2022-06-24 03:40:48.226389
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    reqTime = RequestTimeout("timeout", 408)
    assert reqTime.message == "timeout"
    assert reqTime.status_code == 408
    assert reqTime.quiet == False



# Generated at 2022-06-24 03:40:51.522845
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pltl = PayloadTooLarge('test message')
    assert pltl.status_code == 413
    assert pltl.quiet == True
    assert pltl.message == 'test message'



# Generated at 2022-06-24 03:40:53.755609
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    c = MethodNotSupported(message="msg", method="POST", allowed_methods=["GET", "HEAD"])
    assert c.headers["Allow"] == "GET, HEAD"

# Generated at 2022-06-24 03:40:54.935978
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("test")  # noqa


# Generated at 2022-06-24 03:40:57.512690
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge, match='test_message') as exc:
        raise PayloadTooLarge('test_message')



# Generated at 2022-06-24 03:41:01.403673
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test_server")
        assert False
    except ServerError:
        assert True
    try:
        raise ServerError("test_server")
        assert False
    except SanicException:
        assert True


# Generated at 2022-06-24 03:41:04.548560
# Unit test for function abort
def test_abort():
    for _code in range(100, 600):
       try:
            abort(_code)
       except InvalidUsage as e:
            assert e.status_code == 400
       except RequestTimeout as e:
            assert e.status_code == 408

# Generated at 2022-06-24 03:41:16.098603
# Unit test for constructor of class Unauthorized
def test_Unauthorized():

    # Without kwargs
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as e:
        assert (e.message == "Auth required.")
        assert (e.status_code == 401)
        assert (e.headers == {"WWW-Authenticate": "Bearer"})

    # With kwargs

# Generated at 2022-06-24 03:41:22.145633
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message="Bytes", content_range=10)
    except InvalidRangeType as error:
        assert error.args == ("Bytes",)
        assert error.status_code == 416
        assert error.headers == {'Content-Range': 'bytes */10'}

# Generated at 2022-06-24 03:41:27.938938
# Unit test for function add_status_code
def test_add_status_code():
    code = 12

    def class_decorator(cls):
        return cls

    assert not hasattr(_sanic_exceptions, code)
    assert add_status_code(code)(class_decorator)
    assert hasattr(_sanic_exceptions, code)
    del _sanic_exceptions[code]

test_add_status_code()

# Generated at 2022-06-24 03:41:29.192104
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    message = 'signal signal signal'
    signal = InvalidSignal(message)
    assert signal.message == message

# Generated at 2022-06-24 03:41:30.330704
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed('test message', 'test scheme')

# Generated at 2022-06-24 03:41:32.409852
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal()
    except SanicException as e:
        msg = "Unknown signal."
        assert e.message == msg
        assert e.status_code == 400


# Generated at 2022-06-24 03:41:37.627173
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException()
    except LoadFileException as e:
        assert e
    try:
        raise LoadFileException("Custom exception !")
    except LoadFileException as e:
        assert e.args[0] == "Custom exception !"


# Generated at 2022-06-24 03:41:42.622423
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    """
    Test the constructor
    """
    error = HeaderExpectationFailed("expectation failed")
    assert error.status_code == 417
    assert error.message == "expectation failed"

# Generated at 2022-06-24 03:41:45.900826
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # The following raises:
    # - an instance of class Unauthorized
    # - with a message = "Auth required."
    # - and a status code = 401
    # - and a scheme = "Bearer"
    # - and some other arguments
    raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")

# Generated at 2022-06-24 03:41:48.539164
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    err = FileNotFound(message="message", path="path", relative_url="relative_url")
    assert err.relative_url == "relative_url"
    assert err.path == "path"
    assert str(err) == "message"
    assert err.status_code == 404

# Generated at 2022-06-24 03:41:54.959175
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        try:
            raise FileNotFound("not found", "./", "./")
        except FileNotFound as e:
            print(e)
            # print(e.message)
            # print(e.path)
            # print(e.relative_url)
    finally:
        pass
    pass


if __name__ == '__main__':
    # test_FileNotFound()

    try:
        # abort(0)
        abort(400, "1")
    except InvalidUsage as e:
        print(e)
        print(e.status_code)
        print(e.quiet)
    finally:
        pass
    pass

# Generated at 2022-06-24 03:42:03.199321
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    #if RequestTimeout("408 Request Timeout") == RequestTimeout("408 Request Timeout"):
    assert RequestTimeout("408 Request Timeout") == RequestTimeout("408 Request Timeout"), \
        "Error, they are not the same"
    assert NotFound("404 Not Found") == NotFound("404 Not Found"), \
        "Error, they are not the same"
    assert InvalidUsage("400 Bad Request") == InvalidUsage("400 Bad Request"), \
        "Error, they are not the same"
    assert MethodNotSupported("405 Method Not Allowed") == MethodNotSupported("405 Method Not Allowed"), \
        "Error, they are not the same"
    assert ServerError("500 Internal Server Error") == ServerError("500 Internal Server Error"), \
        "Error, they are not the same"

# Generated at 2022-06-24 03:42:10.208926
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as error:
        assert (error.status_code == 401)
        assert (error.message == "Auth required.")
        assert (error.headers == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""})
        assert (isinstance(error, SanicException))


# Generated at 2022-06-24 03:42:15.158187
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    range_total = 1
    msg = "test"
    class ContentRange:
        def __init__(self):
            self.total = range_total
    range_ = ContentRange()
    try:
        raise ContentRangeError(msg, range_)
    except ContentRangeError as e:
        assert e.headers["Content-Range"] == 'bytes */{}'.format(range_total)

# Generated at 2022-06-24 03:42:17.852699
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f = FileNotFound("Not found", "File path", "URL path")
    assert issubclass(f.__class__, Exception)


# Generated at 2022-06-24 03:42:25.478349
# Unit test for function add_status_code
def test_add_status_code():
    from types import FunctionType
    from inspect import signature

    # Ensure that the status code is set on the function
    @add_status_code(404)
    def f():
        pass
    assert f.status_code == 404

    # Ensure that the status code is set on the class
    @add_status_code(404)
    class C(SanicException):
        pass
    assert C.status_code == 404

    # Ensure the decorator is callable
    f.status_code = None
    assert f.status_code == None
    f = add_status_code(200)(f)
    assert f.status_code == 200

    # Ensure that the decorator is callable as a class decorator
    C.status_code = None
    assert C.status_code == None

# Generated at 2022-06-24 03:42:27.599159
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('invalid', 'name')
    except HeaderNotFound as _:
        pass

# Generated at 2022-06-24 03:42:32.401999
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "Expectation Failed"
    exception = HeaderExpectationFailed(message)
    assert type(exception)==HeaderExpectationFailed
    assert exception.message == "Expectation Failed"



# Generated at 2022-06-24 03:42:34.436198
# Unit test for constructor of class ServerError
def test_ServerError():
    a = ServerError("Bad Gateway")
    assert a.message == "Bad Gateway"
    assert a.status_code == 500

# Generated at 2022-06-24 03:42:44.527397
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Arrange
    expected_message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    expected_path = "/var/log/sanic/app.log"
    expected_relative_url = "/app.log"
    # Act

# Generated at 2022-06-24 03:42:55.833132
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    auth_req = "Authentication required for this endpoint"
    test_exception = Unauthorized(auth_req)
    assert test_exception.status_code == 401
    assert test_exception.message == auth_req
    assert test_exception.headers == {}

    test_exception = Unauthorized(auth_req, scheme="Basic", realm="Restricted Area")
    assert test_exception.status_code == 401
    assert test_exception.message == auth_req
    assert test_exception.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}


# Generated at 2022-06-24 03:42:59.108534
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage("invalid usage", 422, True)
    assert exception.message == "invalid usage"
    assert exception.status_code == 422
    assert exception.quiet == True


# Generated at 2022-06-24 03:43:05.461065
# Unit test for function abort
def test_abort():
    try:
        abort(
            status_code=404, message="Not Found"
        )
    except NotFound as e:
        assert isinstance(e, NotFound)

    try:
        abort(
            status_code=400, message="Invalid Usage"
        )
    except InvalidUsage as e:
        assert isinstance(e, InvalidUsage)

    try:
        abort(
            status_code=500, message="Server Error"
        )
    except SanicException as e:
        assert e.message == "Server Error"

# Generated at 2022-06-24 03:43:09.634230
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    obj = InvalidRangeType("message","contentRange")
    assert obj.headers == {'Content-Range': 'bytes */contentRange'}
    assert obj.args == ("message",)
    assert obj.message == "message"

# Generated at 2022-06-24 03:43:17.654293
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(403)
    class TestClass(SanicException):
        pass

    assert _sanic_exceptions.get(403) == TestClass

    # Test quiet=None/False/True with None defaulting to code != 500.
    @add_status_code(403)
    class TestClass(SanicException):
        pass

    assert TestClass._quiet is True

    @add_status_code(404)
    class TestClass(SanicException):
        pass

    assert TestClass._quiet is True

    @add_status_code(500)
    class TestClass(SanicException):
        pass

    assert TestClass._quiet is False

    @add_status_code(404, quiet=False)
    class TestClass(SanicException):
        pass

    assert TestClass._quiet is False


# Generated at 2022-06-24 03:43:19.527577
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("Header 'message' not found in request")
    assert err.status_code == 400
    assert str(err) == "Header 'message' not found in request"

# Generated at 2022-06-24 03:43:26.624260
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"
    instance = Unauthorized(message, scheme=scheme, realm=realm, qop=qop,
                            algorithm=algorithm, nonce=nonce, opaque=opaque)

    assert instance.message == message
    assert instance.status_code == 401
    assert instance.headers['WWW-Authenticate'] == ('Digest realm="Restricted '
                                                    'Area", qop="auth, auth-'
                                                    'int", algorithm="MD5", n'
                                                    'once="abcdef", opaque="z'
                                                    'yxwvu"')

# Generated at 2022-06-24 03:43:28.689578
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("", "")
    except InvalidRangeType:
        pass
    else:
        assert False



# Generated at 2022-06-24 03:43:33.764368
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # case 1: range error
    data = [('bytes', '0-0,0-0,0-0'), ('100', '100'), ('0-0', '100-100')]
    for r in data:
        try:
            err = ContentRangeError(f'Range {r[0]} is not satisfiable', r[1])
            print(f'Range {r[0]} is not satisfiable')
        except:
            continue

# Generated at 2022-06-24 03:43:45.543329
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    msg = "Auth required."
    scheme = "Basic"
    realm = "Restricted Area"

    with pytest.raises(Unauthorized) as e_info:
        raise Unauthorized(msg, scheme=scheme, realm=realm)

    assert e_info.value.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    assert str(e_info.value) == msg

    scheme = "Digest"
    qop = "auth, auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"


# Generated at 2022-06-24 03:43:48.256847
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("message", status_code=403, quiet=True)
    assert SanicException("message", status_code=403)
    assert SanicException("message", status_code=None)
    assert SanicException("message", status_code=None, quiet=True)

# Generated at 2022-06-24 03:43:52.532966
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = PyFileError('sample')
    assert file.args[0] == "could not execute config file %s"



# Generated at 2022-06-24 03:44:01.983054
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(503)
    class My503(Exception):
        """
        **Status**: 503 Service Unavailable
        """
        pass

    code = 503
    assert My503.status_code == code
    assert _sanic_exceptions[code] == My503
    assert issubclass(My503, SanicException)
    assert isinstance(My503(), SanicException)

    @add_status_code(404, quiet=True)
    class My404(Exception):
        """
        **Status**: 404 Not Found
        """
        pass

    code = 404
    assert My404.status_code == code
    assert My404.quiet == True
    assert _sanic_exceptions[code] == My404
    assert issubclass(My404, SanicException)

# Generated at 2022-06-24 03:44:04.042650
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestError(SanicException):
        pass

    assert TestError.__doc__.strip() == "**Status**: 500 Internal Server Error"

# Generated at 2022-06-24 03:44:07.711826
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden(message="forbidden")
    assert forbidden.message == "forbidden"
    forbidden = Forbidden(message="forbidden", status_code=401)
    assert forbidden.message == "forbidden"


# Generated at 2022-06-24 03:44:10.832711
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    error = FileNotFound( 'some message', 'some path', 'some relative url')
    assert error.path == 'some path'
    assert error.relative_url == 'some relative url'


# Generated at 2022-06-24 03:44:12.945115
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    t = HeaderNotFound("Field not found")
    assert t.status_code == 400

# Generated at 2022-06-24 03:44:14.735534
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout", 408)
    except RequestTimeout as e:
        assert e.status_code == 408


# Generated at 2022-06-24 03:44:16.622133
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    print("Testing ServiceUnavailable")
    t = ServiceUnavailable("message", 503)
    print(t.status_code)


# Generated at 2022-06-24 03:44:18.547018
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Access denied.")
    except Forbidden:
        exception_passed = True
    assert exception_passed == True

# Generated at 2022-06-24 03:44:21.068422
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Invalid user name or password.", 403)
    except Forbidden as e:
        str(e)
        assert e.status_code == 403
        assert str(e) == "Invalid user name or password."

# Generated at 2022-06-24 03:44:25.566331
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    headerNotFound = HeaderNotFound("no access token")
    assert headerNotFound.status_code == 400
    assert headerNotFound.quiet == False
    assert headerNotFound.message == "no access token"


# Generated at 2022-06-24 03:44:27.203496
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    my_range = InvalidRangeType("message","content_range")
    assert my_range.message == "message"
    assert my_range.headers == {"Content-Range": "bytes */content_range"}

# Generated at 2022-06-24 03:44:33.731477
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f = FileNotFound("test message", "test path", "test_relative_url")
    assert f.message == "test message"
    assert f.path == "test path"
    assert f.relative_url == "test_relative_url"
    assert f.status_code == 404
    assert f.quiet is True


# Unit tests for constructor of class RequestTimeout

# Generated at 2022-06-24 03:44:38.394247
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    ex = HeaderExpectationFailed("Content-Type is required", "text/plain")
    assert ex.status_code == 417

# Generated at 2022-06-24 03:44:44.355239
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    Unauthorized(message="Auth required.",
                 scheme="Basic",
                 realm="Restricted Area")
    Unauthorized(message="Auth required.",
                 scheme="Digest",
                 realm="Restricted Area",
                 qop="auth, auth-int",
                 algorithm="MD5",
                 nonce="abcdef",
                 opaque="zyxwvu")
    Unauthorized(message="Auth required.", scheme="Bearer")
    Unauthorized(message="Auth required.",
                 scheme="Bearer",
                 realm="Restricted Area")

# Generated at 2022-06-24 03:44:46.752904
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    m = MethodNotSupported('message', 'method', ['GET', 'POST'])
    assert m.headers['Allow'] == "GET, POST"

# Generated at 2022-06-24 03:44:50.802630
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('signal', 'signal number')
    except InvalidSignal as e:
        assert e.message == "signal"
        assert e.signal_num == "signal number"


# Generated at 2022-06-24 03:44:55.891353
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed) as excinfo:
        raise HeaderExpectationFailed("Test HeaderExpectationFailed")
    
    assert excinfo.value.status_code == 417
    assert str(excinfo.value) == "Test HeaderExpectationFailed"


# Generated at 2022-06-24 03:45:05.304620
# Unit test for function abort
def test_abort():
    # Status code 404
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.args[0] == "Not Found"
    # Status code 400
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.args[0] == "Bad Request"
    # Status code 500
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.args[0] == "Internal Server Error"
    # Status code 503
    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.args[0] == "Service Unavailable"
    # Status code

# Generated at 2022-06-24 03:45:10.421520
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal(message="Test")
    except InvalidSignal as e:
        assert str(e) == "Test"


# Generated at 2022-06-24 03:45:16.607844
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    headerExpectationFailed = HeaderExpectationFailed('TestHeaderExpectationFailed')
    assert headerExpectationFailed.message == 'TestHeaderExpectationFailed'
    assert headerExpectationFailed.status_code == 417
    assert headerExpectationFailed.quiet == True


# Generated at 2022-06-24 03:45:23.413546
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    from sanic.app import Sanic
    class JsonLoadFileException(LoadFileException):
        pass

    # Unit test for constructor of class Sanic
    class TestSanic(Sanic):
        def on_exception(self, request, exception):
            if isinstance(exception, JsonLoadFileException):
                return text('JsonLoadFileException occurred')
            else:
                return super().on_exception(request, exception)

    app = TestSanic()
    app.config.from_pyfile('test.json', silent=True, load_now=True)
    assert app.config.ATTEST == True

    app = TestSanic()
    app.config.from_pyfile('test.json', silent=True)
    assert app.config.ATTEST == True

    app = TestSanic()

# Generated at 2022-06-24 03:45:29.416357
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found.")
    except HeaderNotFound as exp:
        assert exp.args[0] == "Header not found."
        assert exp.status_code == 400


# Generated at 2022-06-24 03:45:34.695136
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("ServerError.")
    except SanicException as e:
        assert e.status_code == 500
    try:
        raise ServerError("ServerError", status_code=501)
    except SanicException as e:
        assert e.status_code == 501



# Generated at 2022-06-24 03:45:35.445991
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("Bad request", status_code=400)

# Generated at 2022-06-24 03:45:37.398171
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError(1)

# Generated at 2022-06-24 03:45:41.184384
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_message = "Test for class PayloadTooLarge"
    test_exception = PayloadTooLarge(test_message, None)
    assert test_exception.message == test_message
    assert test_exception.status_code == 413
    assert test_exception.quiet == True

# Generated at 2022-06-24 03:45:46.709719
# Unit test for function abort
def test_abort():
    try:
        abort(500, '500 Error')
    except Exception as exc:
        assert exc.args[0] == '500 Error'
        assert exc.status_code == 500

##############################################################################
# These exceptions will never propagate outside of Sanic as they will be
# caught by Sanic and transformed into a response.
##############################################################################


# Generated at 2022-06-24 03:45:49.746733
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    h_not_found = HeaderNotFound("Invalid Header")
    assert h_not_found.status_code == 400


# Generated at 2022-06-24 03:45:52.614219
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "Test"
    hnf = HeaderNotFound(message)
    assert hnf.status_code == 400
    assert hnf.message == message


# Generated at 2022-06-24 03:45:55.153460
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("My message")
    except RequestTimeout as e:
        assert e.message == "My message"
        assert e.status_code == 408

# Generated at 2022-06-24 03:45:58.456968
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("error")
    except Exception as e:
        assert e.message == "error"


# Generated at 2022-06-24 03:46:01.820811
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("expected header not found")
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == "expected header not found"

# Generated at 2022-06-24 03:46:03.629680
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException('error message', 600, True)
    assert exception.status_code == 600 and exception.quiet == True

# Generated at 2022-06-24 03:46:09.413321
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    test_msg = "Testing the Signal"
    test_signal = "abc"
    s = InvalidSignal(message=test_msg, status_code=400, signal=test_signal)
    assert s.message == test_msg
    assert s.status_code == 400
    assert s.signal == test_signal

# Generated at 2022-06-24 03:46:12.284660
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType('Error', ContentRange(10,199,200))
    except InvalidRangeType as e:
        assert e.status_code == 416
        assert e.message == 'Error'
        assert e.headers == {'Content-Range': 'bytes */200'}

# Generated at 2022-06-24 03:46:15.531800
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    print("Testing constructor of class ServiceUnavailable")
    service_unavailable_obj = ServiceUnavailable("The service is unavailable")
    print(service_unavailable_obj)
test_ServiceUnavailable()

# Generated at 2022-06-24 03:46:18.456958
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Forbidden")
    except Forbidden as e:
        assert e.status_code == 403
        assert e.quiet == True


# Generated at 2022-06-24 03:46:23.196138
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("This is my message", 'error')
    except ServiceUnavailable as e:
        assert e.message == "This is my message"
        assert e.__class__ == ServiceUnavailable
        assert e.status_code == 503


# Generated at 2022-06-24 03:46:25.940077
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound('the requested url was not found on the server.')
    except Exception as e:
        assert isinstance(e, SanicException)


# Generated at 2022-06-24 03:46:29.694883
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge(message = "Lorem ipsum dolor sit amet, conse¬ctetur adipiscing elit.")
    except PayloadTooLarge as e:
        print("That's an error: {}".format(e))
        assert e.message == "Lorem ipsum dolor sit amet, conse¬ctetur adipiscing elit."
        assert e.status_code == 413

# Generated at 2022-06-24 03:46:34.875154
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    Class SanicException:
        def __init__(self, message, status_code=None, quiet=None):
    """
    try:
        SanicException('SanicException', 'status_code', 'quiet')
    except Exception as e:
        print(e)
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:46:40.075761
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found_instance = FileNotFound("file not found","path","relative_url")
    assert file_not_found_instance.path == "path"
    assert file_not_found_instance.relative_url == "relative_url"


# Generated at 2022-06-24 03:46:41.084478
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable("msg")
    assert exception.status_code == 503
    assert exception.message == "msg"


# Generated at 2022-06-24 03:46:43.090188
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    i = InvalidSignal('error')
    with pytest.raises(InvalidSignal):
        raise i


# Generated at 2022-06-24 03:46:46.086309
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    request_timeout = RequestTimeout(message="408", status_code=408)
    assert request_timeout.status_code == 408
    assert request_timeout.quiet == True

# Generated at 2022-06-24 03:46:49.714916
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header Not Found", "header")
    except InvalidUsage as e:
        assert e.message == "Header Not Found"
        assert e.status_code == 400

if __name__ == "__main__":
    test_HeaderNotFound()

# Generated at 2022-06-24 03:46:54.678234
# Unit test for constructor of class PyFileError
def test_PyFileError():
    f = "tests/test_exception.py"
    with pytest.raises(PyFileError) as excinfo:
        raise PyFileError(file=f)
    assert "could not execute config file tests/test_exception.py" in str(excinfo.value)

# Generated at 2022-06-24 03:47:00.101022
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("This is a message.", "100-continue")
    except HeaderExpectationFailed as e:
        assert e.message == "This is a message."

if __name__ == "__main__":
    test_HeaderExpectationFailed()

# Generated at 2022-06-24 03:47:03.976844
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Create an exception
    e = InvalidUsage("Test", status_code=400)
    # Check that it has the correct type
    assert type(e) == InvalidUsage
    # Check validity of data
    assert e.message == "Test"
    assert e.status_code == 400

# Generated at 2022-06-24 03:47:08.529378
# Unit test for constructor of class NotFound
def test_NotFound():
    # setup
    status_code = 404
    message = "Not Found"
    # exercise
    exception = NotFound(message, status_code)
    # verify
    assert exception.status_code == status_code
    assert exception.message == message


# Generated at 2022-06-24 03:47:12.668224
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message="The method 'DUMMY_METHOD_NAME' is not supported for this route."
    method="DUMMY_METHOD_NAME"
    allowed_methods=["GET"]
    try:
        raise MethodNotSupported(message, method, allowed_methods)

    except MethodNotSupported as m:
        assert m.message==message
        assert m.headers["Allow"]==", ".join(allowed_methods)

# Generated at 2022-06-24 03:47:15.958972
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Bad request!')
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.message == 'Bad request!'

# Generated at 2022-06-24 03:47:21.627892
# Unit test for function abort
def test_abort():
    status_code = 404
    try:
        abort(status_code, message=None)
    except NotFound:
        assert 1
    status_code = 500
    try:
        abort(status_code, message=None)
    except ServerError:
        assert 1
    status_code = 200
    try:
        abort(status_code, message=None)
    except SanicException:
        assert 1

# Generated at 2022-06-24 03:47:30.126509
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Non-empty string for message and status_code.
    message = "test_message"
    status_code = 401
    # Just non-empty string for scheme
    scheme = "test_scheme"
    # Just non-empty string for realm
    realm = "test_realm"

    try:
        raise Unauthorized(message, status_code, scheme, realm=realm)
    except Unauthorized as err:
        assert (err.args == (message,))
        assert (err.status_code == status_code)
        assert (err.headers == {
            "WWW-Authenticate": "{} realm={}".format(scheme, realm)
        })