

# Generated at 2022-06-18 05:13:29.641329
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:13:40.091199
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:13:47.007522
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:13:53.649503
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:14:05.136144
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(201)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 201
    assert TestException.quiet is False
    assert _sanic_exceptions[201] == TestException

    @add_status_code(202, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 202
    assert TestException.quiet is True
    assert _sanic_exceptions[202] == TestException


# Generated at 2022-06-18 05:14:13.522452
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    else:
        assert False, "Unauthorized not raised"


# Generated at 2022-06-18 05:14:25.228562
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:14:37.595630
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:14:49.475514
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException2
    assert TestException2.status_code == 500
    assert TestException2.quiet == False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet == True

# Generated at 2022-06-18 05:14:57.321555
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."

# Generated at 2022-06-18 05:15:09.643499
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:15:20.760202
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:15:30.609039
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == __name__
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == __name__
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

# Generated at 2022-06-18 05:15:40.261491
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=None)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False


# Generated at 2022-06-18 05:15:49.341408
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:01.471416
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:16:12.081609
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:23.373996
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:16:33.995131
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException


# Generated at 2022-06-18 05:16:36.863378
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:48.244292
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:58.416948
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:17:07.299981
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:17:17.919088
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:17:28.997699
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.message == "Auth required."

# Generated at 2022-06-18 05:17:40.633859
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:17:50.065239
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }
        assert e.message == "Auth required."
    else:
        assert False, "Unauthorized exception not raised"

    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401

# Generated at 2022-06-18 05:17:59.917580
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:18:10.838641
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

# Generated at 2022-06-18 05:18:19.836011
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:18:39.073179
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False


# Generated at 2022-06-18 05:18:41.316165
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-18 05:18:53.520510
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert _sanic_exceptions[500] == MyException

    @add_status_code(404, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 404
    assert MyException.quiet is True
    assert _sanic_exceptions[404] == MyException

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code

# Generated at 2022-06-18 05:19:02.921269
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:19:14.848577
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:19:22.927005
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException2
    assert TestException2.status_code == 200
    assert TestException2.quiet is True

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet is False


# Generated at 2022-06-18 05:19:28.746890
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
        assert e.scheme == "Basic"
        assert e.realm == "Restricted Area"
    else:
        assert False


# Generated at 2022-06-18 05:19:41.408098
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is None

    @add_status_code(400, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False


# Generated at 2022-06-18 05:19:44.933614
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:19:54.737147
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."


# Generated at 2022-06-18 05:20:23.479715
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:35.174953
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:46.448376
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:20:56.659911
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:58.334685
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-18 05:21:08.687372
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:21:19.946071
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:21:31.859770
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:21:39.280725
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass
    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:21:47.020817
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 200
    assert TestException2.quiet == True
    assert _sanic_exceptions[200] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:22:23.879105
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:22:35.060084
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:22:46.789528
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == __name__

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == __name__

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:22:57.870216
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 200
    assert TestException2.quiet == True
    assert _sanic_exceptions[200] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:23:08.840990
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 200
    assert TestException2.quiet == True
    assert _sanic_exceptions[200] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:23:20.695323
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException
