

# Generated at 2022-06-18 05:14:06.221034
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:14:13.922272
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:14:25.597409
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False


# Generated at 2022-06-18 05:14:37.971051
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert _sanic_exceptions[500] == TestException

    @add_status_code(404, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert _sanic_exceptions[404] == TestException
    assert TestException.quiet is True

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code

# Generated at 2022-06-18 05:14:49.913585
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException2
    assert TestException2.status_code == 200
    assert TestException2.quiet is True

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet is True


# Generated at 2022-06-18 05:15:02.743949
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert TestException.__name__ == "TestException"
    assert TestException.__qualname__ == "TestException"
    assert TestException.__module__ == "sanic.exceptions"
    assert TestException.__doc__ == None
    assert TestException.__init__.__doc__ == None
    assert TestException.__init__.__annotations__ == {'message': str, 'status_code': int, 'quiet': bool}
    assert TestException.__init__.__defaults__ == (None, None, True)
    assert TestException.__init__.__kwdefaults

# Generated at 2022-06-18 05:15:13.563795
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3



# Generated at 2022-06-18 05:15:21.556057
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:15:30.863278
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False



# Generated at 2022-06-18 05:15:35.471554
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:15:48.645691
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:00.473720
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:16:07.451384
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:16:12.791349
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None

    @add_status_code(201, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 201
    assert TestException.quiet is True

    @add_status_code(202)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 202
    assert TestException.quiet is True

    @add_status_code(203, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 203
    assert TestException.quiet is False


# Generated at 2022-06-18 05:16:20.703830
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True

# Generated at 2022-06-18 05:16:27.924280
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:16:36.249781
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:38.384932
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-18 05:16:47.420433
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:16:57.564859
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is False
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:17:08.491951
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:17:19.825253
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is False
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:17:29.773403
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True
    assert _sanic_exceptions[500] == MyException

# Generated at 2022-06-18 05:17:31.475900
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200] == TestException

# Generated at 2022-06-18 05:17:43.779965
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:17:55.211060
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:18:03.721803
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

# Generated at 2022-06-18 05:18:14.945447
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:18:20.609623
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

# Generated at 2022-06-18 05:18:27.259966
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(400)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 400
    assert TestException2.quiet == True
    assert _sanic_exceptions[400] == TestException2

# Generated at 2022-06-18 05:18:40.760394
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False

# Generated at 2022-06-18 05:18:53.047633
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:19:02.569809
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:19:14.816818
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException


# Generated at 2022-06-18 05:19:22.483745
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:19:26.837275
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:19:34.124737
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True


# Generated at 2022-06-18 05:19:45.186663
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:19:55.023120
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=True)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException2
    assert TestException2.status_code == 200
    assert TestException2.quiet is True

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet is True


# Generated at 2022-06-18 05:20:06.203122
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:20:34.335746
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:45.178787
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True

    @add_status_code(500, quiet=False)
    class TestException4(SanicException):
        pass

    assert TestException4.status_code == 500
    assert TestException4.quiet is False

# Generated at 2022-06-18 05:20:56.305989
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:21:07.746066
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(201)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[201] == TestException2
    assert TestException2.status_code == 201
    assert TestException2.quiet is False

    @add_status_code(202, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[202] == TestException3
    assert TestException3.status_code == 202
    assert TestException3.quiet is True


# Generated at 2022-06-18 05:21:16.539146
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:21:24.069090
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:21:34.718429
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True
    assert _sanic_exceptions[500] == MyException


# Generated at 2022-06-18 05:21:37.253748
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-18 05:21:45.677305
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True

    @add_status_code(500, quiet=False)
    class TestException4(SanicException):
        pass

    assert TestException4.status_code == 500
    assert TestException4.quiet == False

# Generated at 2022-06-18 05:21:54.899951
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:22:36.349205
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:22:39.075018
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class NewException(SanicException):
        pass

    assert NewException.status_code == 400
    assert _sanic_exceptions[400] == NewException



# Generated at 2022-06-18 05:22:50.410971
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:23:01.791077
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert TestException.__name__ == "TestException"
    assert TestException.__qualname__ == "TestException"
    assert TestException.__module__ == __name__
    assert TestException.__doc__ is None
    assert TestException.__dict__ == {}

    assert _sanic_exceptions[400] is TestException

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert TestException.__name__ == "TestException"
    assert TestException.__qualname__ == "TestException"

# Generated at 2022-06-18 05:23:08.366438
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet == True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-18 05:23:17.150795
# Unit test for function add_status_code
def test_add_status_code():
    """
    Test for function add_status_code
    """
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:23:21.811297
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False

# Generated at 2022-06-18 05:23:32.164537
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:23:36.120518
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:23:46.378257
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(201)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 201
    assert TestException2.quiet == True
    assert _sanic_exceptions[201] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3
