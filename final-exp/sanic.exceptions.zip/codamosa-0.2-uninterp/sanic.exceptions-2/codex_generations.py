

# Generated at 2022-06-18 05:13:25.619608
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:13:35.731737
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Test with a Basic auth-scheme, realm MUST be present:
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    # Test with a Digest auth-scheme, things are a bit more complicated:

# Generated at 2022-06-18 05:13:46.004439
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] is TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] is TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] is TestException3

# Generated at 2022-06-18 05:13:52.804347
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

# Generated at 2022-06-18 05:14:04.419265
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404]().status_code == 404
    assert _sanic_exceptions[404]().quiet is True
    assert _sanic_exceptions[404]().message == "Not Found"

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[500]().status_code == 500
    assert _sanic_exceptions[500]().quiet is False
    assert _sanic_exceptions[500]().message == "Internal Server Error"


# Generated at 2022-06-18 05:14:13.159806
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:14:24.943418
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:14:36.907576
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:14:47.481947
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:14:55.260229
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:15:06.993029
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:15:15.988377
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(400, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 400
    assert TestException3.quiet is True
    assert _sanic_exceptions[400] == TestException3


# Generated at 2022-06-18 05:15:27.844029
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:15:34.489790
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:15:42.402712
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert _sanic_exceptions[404]().status_code == 404
    assert _sanic_exceptions[404]().quiet is True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert _sanic_exceptions[500]().status_code == 500
    assert _sanic_exceptions[500]().quiet is False

    @add_status_code(500, quiet=False)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError

# Generated at 2022-06-18 05:15:49.755787
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is False
    assert _sanic_exceptions[400] == TestException

    @add_status_code(401)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 401
    assert TestException2.quiet is True
    assert _sanic_exceptions[401] == TestException2

    @add_status_code(402, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 402
    assert TestException3.quiet is False
    assert _sanic_exceptions[402] == TestException3


# Generated at 2022-06-18 05:16:01.207714
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:06.371779
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    else:
        assert False

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:16:17.820702
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:16:24.297854
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is None
    assert _sanic_exceptions[400] is MyException

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True
    assert _sanic_exceptions[500] is MyException

# Generated at 2022-06-18 05:16:36.912267
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:16:46.807614
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:53.141615
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet == True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-18 05:17:02.833169
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:17:09.837291
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:17:19.286260
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:17:23.770925
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:17:32.918053
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:17:37.834283
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass
    assert MyException.status_code == 400
    assert MyException.quiet == True
    assert _sanic_exceptions[400] == MyException


# Generated at 2022-06-18 05:17:47.549454
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:18:12.013144
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True

    @add_status_code(500, quiet=False)
    class TestException4(SanicException):
        pass

    assert TestException4.status_code == 500
    assert TestException4.quiet is False

# Generated at 2022-06-18 05:18:20.549508
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:18:31.264315
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(400, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 400
    assert TestException3.quiet is False
    assert _sanic_exceptions[400] == TestException3


# Generated at 2022-06-18 05:18:42.741063
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet is True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet is False

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet is True

# Generated at 2022-06-18 05:18:47.875283
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class IAmATeapot(SanicException):
        pass

    assert IAmATeapot.status_code == 418
    assert IAmATeapot.quiet is True
    assert _sanic_exceptions[418] == IAmATeapot

# Generated at 2022-06-18 05:18:58.649873
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == True
    assert MyException.__name__ == "MyException"
    assert MyException.__qualname__ == "MyException"
    assert MyException.__module__ == __name__
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert MyException.__name__ == "MyException"
    assert MyException.__qualname__ == "MyException"
    assert MyException.__module__ == __name__
    assert _sanic_exceptions

# Generated at 2022-06-18 05:19:05.439901
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:19:13.857887
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False

# Generated at 2022-06-18 05:19:19.695733
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet == True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

# Generated at 2022-06-18 05:19:29.348647
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:19:54.046210
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:20:00.885376
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True


# Generated at 2022-06-18 05:20:11.793071
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is False
    assert _sanic_exceptions[500] == TestException3



# Generated at 2022-06-18 05:20:22.423994
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is False

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True

    @add_status_code(400, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True


# Generated at 2022-06-18 05:20:34.181205
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:20:44.000768
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:20:55.513335
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:21:07.365238
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

# Generated at 2022-06-18 05:21:18.998702
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:21:23.165651
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:21:58.781006
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException


# Generated at 2022-06-18 05:22:03.487657
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:22:09.061376
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False

# Generated at 2022-06-18 05:22:19.908605
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:22:31.011517
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet is True


# Generated at 2022-06-18 05:22:40.871344
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(201)
    class TestException2(SanicException):
        pass
    assert _sanic_exceptions[201] == TestException2
    assert TestException2.status_code == 201
    assert TestException2.quiet is False

    @add_status_code(202, quiet=True)
    class TestException3(SanicException):
        pass
    assert _sanic_exceptions[202] == TestException3
    assert TestException3.status_code == 202
    assert TestException3.quiet is True


# Generated at 2022-06-18 05:22:51.508971
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:23:02.913141
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(123)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 123
    assert TestException.quiet is False
    assert _sanic_exceptions[123] == TestException

    @add_status_code(123, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 123
    assert TestException.quiet is True
    assert _sanic_exceptions[123] == TestException

    @add_status_code(123, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 123
    assert TestException.quiet is False
    assert _sanic_exceptions[123] == TestException


# Generated at 2022-06-18 05:23:09.304344
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:23:20.852133
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException
