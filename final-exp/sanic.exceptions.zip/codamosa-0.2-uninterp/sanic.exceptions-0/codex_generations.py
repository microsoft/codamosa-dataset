

# Generated at 2022-06-18 05:14:01.689890
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:14:10.879885
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:14:23.349626
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException2
    assert TestException2.status_code == 500
    assert TestException2.quiet == False

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet == False


# Generated at 2022-06-18 05:14:30.023757
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:14:39.700357
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:14:48.275459
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 200
    assert TestClass.quiet == True

    @add_status_code(500)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 500
    assert TestClass.quiet == False

    @add_status_code(500, quiet=True)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 500
    assert TestClass.quiet == True

# Generated at 2022-06-18 05:14:55.477892
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:15:04.326158
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:15:14.504712
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet == True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet == False

    @add_status_code(500, quiet=False)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet == False


# Generated at 2022-06-18 05:15:26.509396
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3



# Generated at 2022-06-18 05:15:32.904391
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:15:41.798416
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:15:51.978641
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet is False

    @add_status_code(503, quiet=True)
    class ServiceUnavailable(SanicException):
        pass

    assert _sanic_exceptions[503] == ServiceUnavailable
    assert ServiceUnavailable.status_code == 503
    assert ServiceUnavailable.quiet is True

# Generated at 2022-06-18 05:16:02.358810
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(200, quiet=None)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None


# Generated at 2022-06-18 05:16:13.719426
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == False

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False


# Generated at 2022-06-18 05:16:23.462727
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:16:34.034045
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:45.142306
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False


# Generated at 2022-06-18 05:16:55.794782
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:17:04.801928
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet is True

# Generated at 2022-06-18 05:17:19.531085
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:17:22.578112
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException2
    assert TestException2.status_code == 500
    assert TestException2.quiet is False

# Generated at 2022-06-18 05:17:32.157495
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:17:37.454718
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:17:47.110848
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:17:57.607946
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound
    assert NotFound.status_code == 404
    assert NotFound.quiet is True

    @add_status_code(500)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet is False

    @add_status_code(500, quiet=True)
    class ServerError(SanicException):
        pass

    assert _sanic_exceptions[500] == ServerError
    assert ServerError.status_code == 500
    assert ServerError.quiet is True


# Generated at 2022-06-18 05:18:01.292016
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-18 05:18:12.885446
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False



# Generated at 2022-06-18 05:18:20.930382
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is False
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:18:31.263189
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:18:50.859278
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False
    assert _sanic_exceptions[500] == MyException


# Generated at 2022-06-18 05:19:00.954195
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(400, quiet=True)
    class TestException(SanicException):
        pass
    assert _sanic_exceptions[400] == TestException
    assert TestException.status_code == 400
    assert TestException.quiet == True


# Generated at 2022-06-18 05:19:04.597435
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

# Generated at 2022-06-18 05:19:17.010326
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        pass

    assert Test.status_code == 200
    assert Test.quiet == True
    assert _sanic_exceptions[200] == Test

    @add_status_code(500)
    class Test(SanicException):
        pass

    assert Test.status_code == 500
    assert Test.quiet == False
    assert _sanic_exceptions[500] == Test

    @add_status_code(500, quiet=True)
    class Test(SanicException):
        pass

    assert Test.status_code == 500
    assert Test.quiet == True
    assert _sanic_exceptions[500] == Test

    @add_status_code(500, quiet=False)
    class Test(SanicException):
        pass

    assert Test

# Generated at 2022-06-18 05:19:29.008960
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(404)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet == True
    assert _sanic_exceptions[404] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:19:41.491916
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:19:48.432479
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet is False

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is True

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet is False

# Generated at 2022-06-18 05:19:57.754281
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:05.149745
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:20:08.578720
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None
    assert _sanic_exceptions[200] == TestException

    @add_status_code(201, quiet=True)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 201
    assert TestException2.quiet is True
    assert _sanic_exceptions[201] == TestException2

# Generated at 2022-06-18 05:20:32.550610
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == False
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:20:41.748600
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert BadRequest.status_code == 400
    assert BadRequest.quiet == True

    @add_status_code(500)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet == False

    @add_status_code(500, quiet=True)
    class InternalServerError(SanicException):
        pass

    assert InternalServerError.status_code == 500
    assert InternalServerError.quiet == True

# Generated at 2022-06-18 05:20:53.048813
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:21:00.739704
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == False
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:21:10.095715
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:21:21.424384
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:21:33.844953
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:21:43.521603
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None
    assert _sanic_exceptions[200] == TestException

    @add_status_code(201)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 201
    assert TestException2.quiet is None
    assert _sanic_exceptions[201] == TestException2

    @add_status_code(202, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 202
    assert TestException3.quiet is True
    assert _sanic_exceptions[202] == TestException3


# Generated at 2022-06-18 05:21:49.316517
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(404, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert _sanic_exceptions[404] == TestException

    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:21:59.336814
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException
    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:22:34.181990
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:22:38.543349
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is True

# Generated at 2022-06-18 05:22:48.913551
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:22:59.993691
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False



# Generated at 2022-06-18 05:23:05.875031
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False



# Generated at 2022-06-18 05:23:14.156989
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:23:23.205936
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False

    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False


# Generated at 2022-06-18 05:23:28.925105
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == True

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False

# Generated at 2022-06-18 05:23:31.864421
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException

# Generated at 2022-06-18 05:23:41.595009
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == "sanic.exceptions"
    assert TestException.__qualname__ == "TestException"

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert TestException.__name__ == "TestException"
    assert TestException.__module__ == "sanic.exceptions"
    assert TestException.__qualname__ == "TestException"