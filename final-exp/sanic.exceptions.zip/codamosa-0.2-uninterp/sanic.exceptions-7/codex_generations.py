

# Generated at 2022-06-18 05:13:45.904254
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:13:51.066944
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:14:02.507247
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:14:12.116262
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:14:24.063981
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }
        assert e.status_code == 401
        assert e.message == "Auth required."


# Generated at 2022-06-18 05:14:31.101743
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:14:36.825796
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:14:47.430248
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:14:55.407457
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=False)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == False
    assert _sanic_exceptions[500] == TestException3


# Generated at 2022-06-18 05:15:04.271217
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:15:15.321781
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:15:27.229136
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:15:34.024859
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }
        assert e.status_code == 401
        assert e.message == "Auth required."


# Generated at 2022-06-18 05:15:42.404738
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:15:49.778503
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:15:58.892510
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:16:10.393077
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:16:21.593012
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:33.794668
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'

# Generated at 2022-06-18 05:16:37.795359
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

# Generated at 2022-06-18 05:16:47.976787
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:16:57.757775
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:17:06.656345
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException



# Generated at 2022-06-18 05:17:17.567398
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}


# Generated at 2022-06-18 05:17:28.641670
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:17:31.186870
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:17:44.269104
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}

# Generated at 2022-06-18 05:17:55.498323
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == "Digest realm=\"Restricted Area\", qop=\"auth, auth-int\", algorithm=\"MD5\", nonce=\"abcdef\", opaque=\"zyxwvu\""

# Generated at 2022-06-18 05:18:03.982535
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:18:12.313700
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

# Generated at 2022-06-18 05:18:22.713024
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."


# Generated at 2022-06-18 05:18:33.828689
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:18:42.104995
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        pass

    assert Test.status_code == 200
    assert Test.quiet == True

    @add_status_code(500)
    class Test(SanicException):
        pass

    assert Test.status_code == 500
    assert Test.quiet == False

    @add_status_code(500, quiet=True)
    class Test(SanicException):
        pass

    assert Test.status_code == 500
    assert Test.quiet == True

# Generated at 2022-06-18 05:18:53.996765
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert _sanic_exceptions[500] == MyException


# Generated at 2022-06-18 05:19:03.246825
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401
        assert e.message == "Auth required."
    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}
        assert e.status_code == 401

# Generated at 2022-06-18 05:19:08.235678
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
        assert e.message == "Auth required."


# Generated at 2022-06-18 05:19:16.181662
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

# Generated at 2022-06-18 05:19:28.256508
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:19:40.994261
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False

# Generated at 2022-06-18 05:19:49.846651
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
        assert str(e) == "Auth required."
    else:
        assert False, "Unauthorized exception not raised"

    try:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401

# Generated at 2022-06-18 05:19:57.905858
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-18 05:20:09.564666
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:20:16.120667
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet == False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet == True
    assert _sanic_exceptions[500] == TestException3

# Generated at 2022-06-18 05:20:20.053111
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:20:27.273271
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:20:36.465011
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is False
    assert _sanic_exceptions[500] == TestException2

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert TestException3.status_code == 500
    assert TestException3.quiet is True
    assert _sanic_exceptions[500] == TestException3



# Generated at 2022-06-18 05:20:46.952792
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet is False

    @add_status_code(201)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[201] == TestException2
    assert TestException2.status_code == 201
    assert TestException2.quiet is False

    @add_status_code(202, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[202] == TestException3
    assert TestException3.status_code == 202
    assert TestException3.quiet is True


# Generated at 2022-06-18 05:20:57.096522
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:21:08.100086
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is None

    @add_status_code(400, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is True

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False


# Generated at 2022-06-18 05:21:20.037404
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=False)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert _sanic_exceptions[500] == MyException


# Generated at 2022-06-18 05:21:37.674336
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet is True

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False

# Generated at 2022-06-18 05:21:45.467683
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:21:56.957707
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:22:00.784476
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert _sanic_exceptions[400] == TestException


# Generated at 2022-06-18 05:22:11.829818
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException


# Generated at 2022-06-18 05:22:22.522980
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == True
    assert _sanic_exceptions[200] == TestException

    @add_status_code(200, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet == False
    assert _sanic_exceptions[200] == TestException


# Generated at 2022-06-18 05:22:33.525931
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[200] == TestException
    assert TestException.status_code == 200
    assert TestException.quiet == True

    @add_status_code(500)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException2
    assert TestException2.status_code == 500
    assert TestException2.quiet == False

    @add_status_code(500, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[500] == TestException3
    assert TestException3.status_code == 500
    assert TestException3.quiet == True

# Generated at 2022-06-18 05:22:45.407635
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is False
    assert _sanic_exceptions[200] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet is False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(200, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is True
    assert _sanic_exceptions[200] == TestException


# Generated at 2022-06-18 05:22:47.325339
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass

    assert _sanic_exceptions[404] == NotFound

# Generated at 2022-06-18 05:22:58.634260
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert _sanic_exceptions[500] == TestException

    @add_status_code(404, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 404
    assert TestException.quiet is True
    assert _sanic_exceptions[404] == TestException

    @add_status_code(404, quiet=False)
    class TestException(SanicException):
        pass

    assert TestException.status_code

# Generated at 2022-06-18 05:23:32.275870
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400
    assert TestException.quiet == True
    assert _sanic_exceptions[400] == TestException

    @add_status_code(500)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == False
    assert _sanic_exceptions[500] == TestException

    @add_status_code(500, quiet=True)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 500
    assert TestException.quiet == True
    assert _sanic_exceptions[500] == TestException

# Generated at 2022-06-18 05:23:42.509216
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400
    assert MyException.quiet == True
    assert _sanic_exceptions[400] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == False
    assert _sanic_exceptions[500] == MyException

    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 500
    assert MyException.quiet == True
    assert _sanic_exceptions[500] == MyException
