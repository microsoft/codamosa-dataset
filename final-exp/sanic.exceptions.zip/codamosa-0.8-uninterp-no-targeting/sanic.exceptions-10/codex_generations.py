

# Generated at 2022-06-21 22:40:03.207598
# Unit test for function add_status_code
def test_add_status_code():
    class SampleException(SanicException):
        pass

    # Test wrapper
    @add_status_code(200)
    class TestException(SampleException):
        pass

    assert TestException.status_code == 200
    assert TestException.quiet is None

    def test_add_status_code():
        class SampleException(SanicException):
            pass

        # Test wrapper
        @add_status_code(200)
        class TestException(SampleException):
            pass

        assert TestException.status_code == 200
        assert TestException.quiet is None

    @add_status_code(500, quiet=True)
    class TestException2(SampleException):
        pass

    assert TestException2.status_code == 500
    assert TestException2.quiet is True

    # Test without wrapper

# Generated at 2022-06-21 22:40:06.307582
# Unit test for constructor of class NotFound
def test_NotFound():
    m = "test"
    exc = NotFound(message=m)
    assert isinstance(exc, NotFound)
    assert exc.message == m
    assert exc.status_code == 404



# Generated at 2022-06-21 22:40:13.702950
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    test_str = "Bad bad bad";
    test_invalid_usage = InvalidUsage(test_str, 404);
    test_exception = SanicException(test_str, 404);

    assert test_invalid_usage.status_code == test_exception.status_code;
    assert test_invalid_usage.message == test_exception.message;
    assert test_invalid_usage.__repr__() == test_exception.__repr__();

if __name__ == "__main__":
    test_InvalidUsage();

# Generated at 2022-06-21 22:40:15.146601
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    s = InvalidSignal("Invalid signal receive")
    assert s is not None


# Generated at 2022-06-21 22:40:17.422903
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    h = HeaderExpectationFailed("")
    assert h.status_code == 417
    assert h.message == ""

# Generated at 2022-06-21 22:40:19.300503
# Unit test for constructor of class NotFound
def test_NotFound():
    target = NotFound(message='test', status_code='404')
    assert target.message == 'test'
    assert target.status_code == '404'



# Generated at 2022-06-21 22:40:30.180384
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    def should_throw():
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
    assert_raises(Unauthorized, should_throw)

    try:
        should_throw()
    except Unauthorized as e:
        assert(e.headers["WWW-Authenticate"] ==
               'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"')
    else:
        assert(False)



# Generated at 2022-06-21 22:40:32.581026
# Unit test for constructor of class Forbidden
def test_Forbidden():
    foo = Forbidden('bar')
    assert isinstance(foo, Forbidden)


# Generated at 2022-06-21 22:40:35.018096
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden('This is not allowed')
    assert f.status_code == 403
    assert f.message == 'This is not allowed'
    print(repr(f)) # print a representation of the Forbidden exception

# Generated at 2022-06-21 22:40:40.155957
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("file not found","/home", "/home")
    assert(file_not_found.path=="/home" and file_not_found.relative_url=="/home")

# Unit Test for Constructor of class URLBuildError

# Generated at 2022-06-21 22:40:45.202460
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    ex = URLBuildError("Error raised")
    assert ex.args[0] == "Error raised"


# Generated at 2022-06-21 22:40:49.586659
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge("Payload Too Large", status_code=413)
    assert str(error) == "Payload Too Large"
    assert error.status_code == 413
    assert error.message == "Payload Too Large"

# Generated at 2022-06-21 22:40:50.953689
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("msg", status_code=403)
    return f



# Generated at 2022-06-21 22:40:53.773539
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    error_msg = "ServiceUnavailable sanic error"
    sanic_ex = ServiceUnavailable(error_msg)
    assert sanic_ex.status_code == 503
    assert sanic_ex.message == error_msg


# Generated at 2022-06-21 22:40:58.844284
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test = PyFileError("test.py")
    assert test.args[0] == "could not execute config file test.py"
    assert test.args[1] == "test.py"
    assert str(test) == "could not execute config file test.py"


# Generated at 2022-06-21 22:41:02.473064
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    instance_ServiceUnavailable = ServiceUnavailable(message=None, status_code=None, quiet=None)
    assert isinstance(instance_ServiceUnavailable, ServiceUnavailable)
    assert instance_ServiceUnavailable.status_code is 503
    assert instance_ServiceUnavailable.quiet is True


# Generated at 2022-06-21 22:41:04.435894
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("A request timeout occured")
    except RequestTimeout as e:
        # compare exception messages
        assert(str(e) == "A request timeout occured")

# Generated at 2022-06-21 22:41:12.578573
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    statuscode = 417
    error_title = "Expectation Failed"

    # test constructor
    error = HeaderExpectationFailed("Test Expectation Failed")
    assert error.status_code == statuscode
    assert str(error) == "Test Expectation Failed"

    # test status code
    try:
        abort(statuscode)
    except HeaderExpectationFailed as e:
        assert e.status_code == statuscode
        assert f"{error_title}: {statuscode}" in str(e)



# Generated at 2022-06-21 22:41:17.388920
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed) as context:
        raise HeaderExpectationFailed("Error")
    assert context.value.status_code == 417
    assert context.value.message == "Error"
    assert context.value.quiet == True



# Generated at 2022-06-21 22:41:20.418131
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = InvalidRangeType(message="ok", content_range=None)


# Generated at 2022-06-21 22:41:30.120664
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Bearer",
                           realm="Restricted Area")
    except Unauthorized as ex:
        assert ex.status_code == 401
        assert ex.scheme == "Bearer"
        assert ex.kwargs == {"realm": "Restricted Area"}
        assert ex.message == "Auth required."

# Generated at 2022-06-21 22:41:35.462095
# Unit test for function add_status_code
def test_add_status_code():
    class DummyErr(SanicException):
        pass
    assert DummyErr.status_code == 500
    assert DummyErr.quiet is None
    assert 404 not in _sanic_exceptions

    class DummyErr(SanicException):
        pass

    @add_status_code(404)
    class DummyErr(SanicException):
        pass

    assert DummyErr.status_code == 404
    assert DummyErr.quiet is True
    assert 404 in _sanic_exceptions

# Generated at 2022-06-21 22:41:37.096086
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exc = LoadFileException("message", status_code=400)
    assert exc.status_code == 400
    assert exc.message == "message"

# Generated at 2022-06-21 22:41:44.969237
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    Unit test for exception Unauthorized
    """
    # Test for Unauthorized constructor with only 2 arguments
    message = "Auth required."
    scheme = "Basic"
    try:
        raise Unauthorized(message=message, scheme=scheme)
    except Unauthorized as err:
        assert err.message == message
        assert err.status_code == 401
        assert err.headers["WWW-Authenticate"] == f"{scheme}"
    # Test for Unauthorized constructor with 3 arguments
    message = "Auth required."
    scheme = "Basic"
    realm = "Restricted Area"
    try:
        raise Unauthorized(message=message, scheme=scheme, realm=realm)
    except Unauthorized as err:
        assert err.message == message
        assert err.status_code == 401

# Generated at 2022-06-21 22:41:51.190694
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    from unittest.mock import Mock

    class MockHandler:
        _request = Mock()
        _request.path = '/'

    exc = Unauthorized("Auth required.", scheme='Digest', realm='Restricted Area', qop='auth, auth-int', algorithm='MD5', nonce='abcdef', opaque='zyxwvu')
    response = exc.handler(MockHandler())

    assert response.status == 401
    assert response.headers['WWW-Authenticate'] == 'Digest qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu", realm="Restricted Area"'

# Generated at 2022-06-21 22:41:53.769963
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    test_obj = HeaderExpectationFailed()
    try:
        raise test_obj
    except HeaderExpectationFailed as e:
        pass

# Generated at 2022-06-21 22:41:56.093562
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("problem in pyfile")
    except PyFileError as e:
        assert str(e) == "could not execute config file problem in pyfile"

# Generated at 2022-06-21 22:41:59.615117
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert(e.message=="Auth required.")
        assert(e.status_code==401)
        assert(e.headers=={'WWW-Authenticate': 'Basic realm="Restricted Area"'})


# Generated at 2022-06-21 22:42:02.307362
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("Test URLBuildError")
    assert url_build_error.args == ("Test URLBuildError",)

# Generated at 2022-06-21 22:42:04.344543
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Service unavailable")
    except ServiceUnavailable as err:
        assert err.status_code == 503

# Generated at 2022-06-21 22:42:25.292065
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Test')
    except SanicException as se:
        assert se.message == 'Test'
        assert se.status_code is None
        assert se.quiet is False
        pass
    try:
        raise SanicException('Test', status_code=500)
    except SanicException as se:
        assert se.message == 'Test'
        assert se.status_code == 500
        assert se.quiet is None
        pass
    try:
        raise SanicException('Test', status_code=404)
    except SanicException as se:
        assert se.message == 'Test'
        assert se.status_code == 404
        assert se.quiet is True
        pass

# Generated at 2022-06-21 22:42:30.364124
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound('message', 'status_code', 'quiet').message == 'message'
    assert NotFound('message', 'status_code', 'quiet').status_code == 'status_code'
    assert NotFound('message', 'status_code', 'quiet').quiet == 'quiet'


# Generated at 2022-06-21 22:42:34.924165
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message="test message", content_range=None)
    except ContentRangeError as error:
        assert error.__str__() == "test message"
        assert error.headers == {"Content-Range": "bytes */None"}


# Generated at 2022-06-21 22:42:38.882869
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable
    except ServiceUnavailable as exc:
        assert exc.status_code == 503
        assert exc.message == "Service Unavailable"
        assert exc.quiet == True


# Generated at 2022-06-21 22:42:43.758329
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Check that the constructor doesn't raise an exception
    try:
        exception = InvalidRangeType(message="test message", content_range=10000)
        assert exception
    except:
        assert False



# Generated at 2022-06-21 22:42:49.286799
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
        assert False
    except Unauthorized as e:
        assert e.args[0] == "Auth required."
        assert e.status_code == 401
        assert e.scheme == "Basic"
        assert e.realm == "Restricted Area"
        assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'


# Generated at 2022-06-21 22:42:53.367018
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class CustomError(SanicException):
        pass

    test_class = CustomError("test")

    assert test_class.status_code == 404
    assert test_class.message == "test"

    assert _sanic_exceptions[404] == CustomError



# Generated at 2022-06-21 22:42:55.626100
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("invalid file")
    except LoadFileException as e:
        assert e.message=="invalid file"

# Generated at 2022-06-21 22:42:59.737870
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with raises(PyFileError) as exc_info:
        raise PyFileError("file not found")

    assert str(exc_info.value) == "could not execute config file file not found"



# Generated at 2022-06-21 22:43:09.132225
# Unit test for function abort
def test_abort():
    for exception in _sanic_exceptions.values():
        try:
            abort(exception.status_code)
        except Exception as expected:
            assert issubclass(type(expected), exception)

    for code in STATUS_CODES.keys():
        if isinstance(code, int) and code not in _sanic_exceptions.keys():
            try:
                abort(code)
            except Exception as expected:
                assert issubclass(type(expected), SanicException)

    try:
        abort(status_code=531)
    except Exception as expected:
        assert issubclass(type(expected), SanicException)

    try:
        abort(status_code=402, message="Unable to delete")
    except Exception as expected:
        assert issubclass(type(expected), SanicException)




# Generated at 2022-06-21 22:43:29.621340
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("This is a invalid URL", "URL=\"test\"")
    assert url_build_error.args[0] == "This is a invalid URL"
    assert url_build_error.args[1] == "URL=\"test\""

# Generated at 2022-06-21 22:43:32.609123
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("HeaderExpectationFailed") 
    except HeaderExpectationFailed as e: 
        print("HeadExpectationFailed exception occurred: {0}".format(e))


# Generated at 2022-06-21 22:43:38.315418
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('Method Not Found', 'POST', ['GET', 'PUT'])
    except MethodNotSupported as error:
        assert error.args[0] == 'Method Not Found'
        assert error.method == 'POST'
        assert error.allowed_methods == ['GET', 'PUT']
        assert error.headers['Allow'] == 'GET, PUT'

# Generated at 2022-06-21 22:43:41.375976
# Unit test for constructor of class SanicException
def test_SanicException():
    SanicException("Message", status_code=200)
    SanicException("Message", status_code=200, quiet=True)

# Generated at 2022-06-21 22:43:51.521951
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized, match="Auth required."):
        raise Unauthorized("Auth required.")

    with pytest.raises(Unauthorized, match="Auth required."):
        raise Unauthorized("Auth required.", status_code=401)

    with pytest.raises(
        Unauthorized,
        match='Authentication scheme "Basic" used but realm "Restricted Area" was not specified.',
    ):
        raise Unauthorized("Auth required.", scheme="Basic")

    with pytest.raises(Unauthorized, match="Auth required."):
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")

    with pytest.raises(
        Unauthorized,
        match="Auth required.\nWWW-Authenticate: Digest realm=\"Restricted Area\"",
    ):
        raise Un

# Generated at 2022-06-21 22:43:53.888033
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        Forbidden('this is a test')
    except Exception as e:
        err = str(e)
        assert err == 'this is a test'

# Generated at 2022-06-21 22:44:01.215340
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        file = 'sanic/exceptions.py'
        e = PyFileError(file)
        assert str(e) == pytest.approx("could not execute config file sanic/exceptions.py")
        assert repr(e) == pytest.approx("could not execute config file sanic/exceptions.py")
        assert e.args[0] == pytest.approx("could not execute config file sanic/exceptions.py")
    except PyFileError:
        assert False, "PyFileError constructor is not creating exception properly"


# Generated at 2022-06-21 22:44:08.139987
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Error")
    except ServerError as e:
        assert e.message == "Error"
        assert e.status_code == 500

# Background of this test:
# SanicException does this:
#   def __init__(self, message, status_code=None, quiet=None):
#       ...
#       if status_code is not None:
#           self.status_code = status_code
#       ...
#       if quiet or quiet is None and status_code not in (None, 500):
#           self.quiet = True
#
# So:
#   If status_code is None, we can't pass quiet=True and
#   If we pass status_code=500, quiet=True will be ignored.
# (Unless we can change these conditions)
#
# The problem is that I need

# Generated at 2022-06-21 22:44:11.332334
# Unit test for function abort
def test_abort():
    try:
        abort(201)
    except Exception as error:
        assert error.status_code == 201
        assert error.message == 'Created'
        assert error.__class__ == SanicException

# Generated at 2022-06-21 22:44:12.921955
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(600)
    

# Generated at 2022-06-21 22:44:52.361430
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('test_message','test_content_range')
    except ContentRangeError as e:
        assert str(e) == 'test_message'
        assert e.status_code == 416

if __name__ == "__main__":
    test_ContentRangeError()

# Generated at 2022-06-21 22:44:53.810888
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    FileNotFound("Not found", path="sanic/exceptions.py", relative_url="www.github.com")

# Generated at 2022-06-21 22:44:55.946751
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Testing")
    except SanicException as e:
        assert e.message == "Testing"
        assert e.status_code is None
        assert e.quiet is None


# Generated at 2022-06-21 22:45:07.791459
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as ex:
        assert ex.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int",
                           algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as ex:
        assert ex.headers == {'WWW-Authenticate': 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'}


# Generated at 2022-06-21 22:45:11.665300
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # create a RequestTimeout instance
    try:
        raise RequestTimeout('The socket has time out.')
    except RequestTimeout as exception:
        assert exception.status_code == 408
        assert exception.quiet is True

if __name__ == "__main__":
    test_RequestTimeout()

# Generated at 2022-06-21 22:45:14.694032
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('Something is wrong')
    except PayloadTooLarge as error:
        print(error.status_code)
        print(error.message)


# Generated at 2022-06-21 22:45:16.462750
# Unit test for constructor of class NotFound
def test_NotFound():
    notfound = NotFound("Test message")
    assert notfound.message == "Test message"
    assert notfound.status_code == 404


# Generated at 2022-06-21 22:45:18.167452
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError('test')

# Generated at 2022-06-21 22:45:20.350742
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    input = "Invalid Usage"
    output = InvalidUsage(input)
    assert output == output


# Generated at 2022-06-21 22:45:25.097284
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported(message="search error", method="POST", allowed_methods=["GET", "POST"])
    except MethodNotSupported as exception:
        assert exception.status_code == 405
        assert exception.headers is not None
        assert exception.headers["Allow"] == "GET, POST"

# Generated at 2022-06-21 22:46:48.839564
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test_method = b'\x01'
    test_message_u8 = b'\x02'
    test_message_str = b'\x03'
    test_method_allowed = b'\x04'
    method_not_supported = MethodNotSupported(
        test_message_u8, test_method, ["Post", test_method_allowed])
    assert method_not_supported.message == test_message_u8
    assert method_not_supported.method == test_method
    assert method_not_supported.headers.get("Allow") == b'Post,\x04'
    # check if the constructor sanitize the message from byte to str
    method_not_supported = MethodNotSupported(
        test_message_str, test_method, ["Post", test_method_allowed])
    assert method_not_

# Generated at 2022-06-21 22:46:51.033678
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("abcd")
    except InvalidSignal as e:
        print(e)
    finally:
        print("This is InvalidSignal Exception.")


# Generated at 2022-06-21 22:46:54.897736
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f =  FileNotFound("This file does not exist", "./foo.txt", "http://url.com/foo.txt")
    assert f.args[0] == "This file does not exist"
    assert f.path == "./foo.txt"
    assert f.relative_url == "http://url.com/foo.txt"

# Generated at 2022-06-21 22:46:55.754188
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException):
        raise SanicException('Test SanicException')


# Generated at 2022-06-21 22:47:00.455398
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    class response():
        def __init__(self):
            self.headers = {}
        def setHeader(self,key,value):
            self.headers[key] = value
    cr_headers = sanic.exceptions.ContentRangeError(message="",content_range=response()).headers
    assert cr_headers["Content-Range"] == "bytes */12"

# Generated at 2022-06-21 22:47:11.211011
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException(message="abc")
    assert exception.message == "abc"
    assert exception.status_code is None
    assert exception.quiet is False

    exception = SanicException(message="abc", status_code=400)
    assert exception.status_code == 400
    assert exception.quiet is True

    exception = SanicException(message="abc", status_code=500)
    assert exception.status_code == 500
    assert exception.quiet is False

    exception = SanicException(message="abc", status_code=500, quiet=False)
    assert exception.status_code == 500
    assert exception.quiet is False

    exception = SanicException(message="abc", status_code=400, quiet=False)
    assert exception.status_code == 400
    assert exception.quiet is False


# Generated at 2022-06-21 22:47:15.619469
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message="This method is not supported!"
    method='POST'
    allowed_methods=['GET', 'HEAD', 'POST', 'OPTIONS']
    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.message == message
    assert exception.headers == {"Allow": ", ".join(allowed_methods)}

# Generated at 2022-06-21 22:47:16.667287
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage("message")

# Generated at 2022-06-21 22:47:19.072929
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exc = ServiceUnavailable("Testing Service Unavailable")
    assert exc.message == "Testing Service Unavailable"
    assert exc.status_code == 503
    assert exc.quiet is True

# Generated at 2022-06-21 22:47:29.810119
# Unit test for function abort
def test_abort():
    # No message specified
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    # message specified
    try:
        abort(500, "Goodbye")
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Goodbye"
        assert str(e) == '500: Goodbye'
    # message type is bytes
    try:
        abort(500, b'\xe6\x8b\xbf\xe4\xbb\xa3\xe8\x81\x94\xe7\x9b\x9f')
    except ServerError as e:
        assert e.status_code == 500