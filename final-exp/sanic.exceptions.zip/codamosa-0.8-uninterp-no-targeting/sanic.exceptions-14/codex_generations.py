

# Generated at 2022-06-21 22:40:08.495247
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("hello", 500)
    assert (f.message == "hello")
    assert (f.status_code == 500)
    f = Forbidden("hello", 500, False)
    assert (f.quiet == False)
    f = Forbidden("hello")
    assert (f.status_code == 403)


# Generated at 2022-06-21 22:40:10.179620
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(FileNotFound):
        exception = FileNotFound(
            message='FileNotFound', path='/data/haha', relative_url='/haha'
        )



# Generated at 2022-06-21 22:40:12.942347
# Unit test for constructor of class SanicException
def test_SanicException():
    error = SanicException("Error Message", 500, True)
    assert isinstance(error, SanicException)
    assert error.status_code == 500
    assert error.quiet == True

# Generated at 2022-06-21 22:40:17.082725
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    x = InvalidSignal('Incorrect signal')
    assert str(x) == 'Incorrect signal'
    assert x.status_code == 500
    assert x.__class__ == InvalidSignal


# Generated at 2022-06-21 22:40:22.147003
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_name = 'Accept-Encoding'
    err = HeaderNotFound(header_name)
    print(err)
    assert err.message == 'Header \'Accept-Encoding\' not found in request.'


# Generated at 2022-06-21 22:40:26.141622
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError("error")
    assert "URLBuildError: error" == str(exception)
    assert 500 == exception.status_code


if __name__ == '__main__':
    pass

# Generated at 2022-06-21 22:40:28.111508
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = ContentRangeError("error message", 10)

    assert(c.headers == {"Content-Range": "bytes */10"})
    assert(c.status_code == 416)

# Generated at 2022-06-21 22:40:30.180247
# Unit test for constructor of class ServerError
def test_ServerError():
    s = ServerError()
    assert s.status_code == 500

# Generated at 2022-06-21 22:40:34.895554
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Test for constructor with no message
    exception = HeaderExpectationFailed()

    assert exception.__str__() == 'Error occurred'
    assert exception.message == 'Error occurred'

# Unit tests for class InvalidUsage

# Generated at 2022-06-21 22:40:38.915584
# Unit test for constructor of class NotFound
def test_NotFound():
    nf = NotFound("This is a NotFound message")
    assert nf.message == "This is a NotFound message"
    assert nf.status_code == 404

# Generated at 2022-06-21 22:40:44.581434
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expectation_failed = HeaderExpectationFailed("hello")
    assert header_expectation_failed.status_code == 417
    assert header_expectation_failed.message == "hello"


# Generated at 2022-06-21 22:40:47.077595
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('file_name')
    except PyFileError as err:
        assert err.args[0] == "could not execute config file file_name"

# Generated at 2022-06-21 22:40:50.251259
# Unit test for function abort
def test_abort():
    abort(
        status_code=500,
        message="some message"
    )


# Generated at 2022-06-21 22:40:52.264459
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError('file')
    assert pyfileerror.args == ("could not execute config file %s", 'file')

# Generated at 2022-06-21 22:40:52.950769
# Unit test for function abort
def test_abort():
    abort(404)

# Generated at 2022-06-21 22:40:57.042956
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('ServiceUnavailable')
    except Exception as e:
        print(e.status_code)
        print(e.headers)
        print(e.__class__)


# Generated at 2022-06-21 22:40:59.637967
# Unit test for constructor of class ServerError
def test_ServerError():
    msg = 'message'
    exception = ServerError(msg)
    assert str(exception) == msg
    assert exception.quiet == True
    assert exception.status_code == 500

# Generated at 2022-06-21 22:41:01.691262
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("test message")
    except SanicException as e:
        assert e.message == "test message"
        assert e.status_code == 400
        assert e.quiet is False

# Generated at 2022-06-21 22:41:03.561278
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("test", 100)
    except SanicException as ex:
        assert ex.status_code == 413
        assert ex.headers == {"Content-Length": 100}

# Generated at 2022-06-21 22:41:09.568821
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message="File Not Available", path="/abc/def", relative_url="https://abc.com/abc/def")
    except FileNotFound as e:
        assert e.path == "/abc/def"
        assert e.relative_url == "https://abc.com/abc/def"
    else:
        assert False, "FileNotFound exception not raised"

# Generated at 2022-06-21 22:41:17.235873
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message="invalid file", path="myfile")
    except LoadFileException as err:
        assert err.message == "invalid file"
        assert err.path == "myfile"

# Generated at 2022-06-21 22:41:22.008441
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    message = 'This is an exception message'
    try:
        raise RequestTimeout(f'{message}')
    except RequestTimeout as e:
        assert e.args[0] == message, "Not the same message"

# Generated at 2022-06-21 22:41:24.502573
# Unit test for constructor of class NotFound

# Generated at 2022-06-21 22:41:27.359365
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Error')
    except InvalidUsage as e:
        assert e.status_code == 400
        assert str(e) == 'Error'

# Generated at 2022-06-21 22:41:31.392623
# Unit test for constructor of class SanicException
def test_SanicException():
    print(SanicException(message='error'))
    print(SanicException(message='error', status_code='300'))
    print(SanicException(message='error', status_code='300', quiet=True))

if __name__ == "__main__":
    test_SanicException()

# Generated at 2022-06-21 22:41:36.423310
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range = InvalidRangeType(message = 'the range for this request is invalid', content_range = 20)
    assert hasattr(invalid_range, 'message')
    assert hasattr(invalid_range, 'content_range')

# Generated at 2022-06-21 22:41:38.609610
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    err = PayloadTooLarge(message="Payload too large", status_code=413)
    assert isinstance(err, PayloadTooLarge)
    assert err.message == "Payload too large"
    assert err.status_code == 413

# Generated at 2022-06-21 22:41:41.562034
# Unit test for constructor of class Forbidden
def test_Forbidden():
    Forbidden("this_is_a_test_message", status_code=403)
    Forbidden("this_is_a_test_message", quiet=True)


# Generated at 2022-06-21 22:41:45.017055
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Unauthorized")
    except Unauthorized as err:
        assert str(err) == "Unauthorized"
        assert err.status_code == 401



# Generated at 2022-06-21 22:41:51.217639
# Unit test for function abort
def test_abort():
    with raises(NotFound) as err:
        abort(404)
    assert err.value.status_code == 404

    with raises(InvalidUsage) as err:
        abort(400, "Not working.")
    assert err.value.status_code == 400
    assert err.value.message == "Not working."

    with raises(ServerError) as err:
        abort(500)
    assert err.value.status_code == 500

    with raises(SanicException) as err:
        abort(201)
    assert err.value.status_code == 201
    assert err.value.message == "Created"

# Generated at 2022-06-21 22:42:02.110248
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError):
        raise ContentRangeError(message="Range Not Satisfiable",\
            content_range=None)

# Generated at 2022-06-21 22:42:09.045974
# Unit test for function abort
def test_abort():
    try:
        abort(418, message="Im a teapot")
    except SanicException as e:
        assert e.status_code == 418
        assert str(e) == "Im a teapot"

    try:
        abort(418)
    except SanicException as e:
        assert e.status_code == 418
        assert str(e) == "I'm a teapot"

    try:
        abort(500)
    except SanicException as e:
        assert e.status_code == 500
        assert str(e) == "Internal Server Error"

    try:
        abort(500, "Not the default message")
    except SanicException as e:
        assert e.status_code == 500
        assert str(e) == "Not the default message"

# Generated at 2022-06-21 22:42:10.923952
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    assert FileNotFound("error", "error", "error").message == "error"


# Generated at 2022-06-21 22:42:15.428615
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test.txt")
    except PyFileError as exception:
        assert str(exception) == "could not execute config file test.txt"

# Generated at 2022-06-21 22:42:27.399636
# Unit test for function abort
def test_abort():
    # For testing, create a sanic exception class that logs all calls to abort
    # and returns the message provided.
    abort_log = []
    class TestException(SanicException):
        pass
    _sanic_exceptions[666] = TestException

    def test_abort_call(status_code, message=None):
        abort_log.append((status_code, message))
        abort(status_code, message)

    try:
        # Test with message provided.
        test_abort_call(666, "Test message")
    except TestException as t:
        assert t.message == "Test message"
        assert len(abort_log) == 1
    else:
        assert False, "Abort did not raise TestException as expected"


# Generated at 2022-06-21 22:42:30.471812
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    error = MethodNotSupported('', '', [])
    assert 'Allow' in error.headers
    assert error.headers['Allow'] == ''

# Generated at 2022-06-21 22:42:32.984791
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException



# Generated at 2022-06-21 22:42:34.875214
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage("", 400)
    assert a.status_code == 400


# Generated at 2022-06-21 22:42:38.737627
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException) as excinfo:
        raise SanicException("message", status_code=400, quiet=True)
    assert excinfo.value.status_code == 400
    assert excinfo.value.message == "message"
    assert excinfo.value.quiet == True


# Generated at 2022-06-21 22:42:44.423632
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url = "http://localhost:8000/user/1"
    dic = {'id': 1, 'name':'张三', 'age': 18}
    try:
        raise URLBuildError(url, dic)
    except URLBuildError as e:
        print(e)

# Generated at 2022-06-21 22:42:56.651819
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound("message") is not None
    assert NotFound("message", quiet=True) is not None
    assert NotFound("message", status_code=500) is not None
    assert NotFound("message").status_code == 404


# Generated at 2022-06-21 22:43:00.192959
# Unit test for constructor of class ServerError
def test_ServerError():
	try:
		raise ServerError("This is an Exception")
	except Exception as e:
		assert str(e) == "This is an Exception"
	else:
		assert False


# Generated at 2022-06-21 22:43:02.816284
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert isinstance(MyException, type)
    assert MyException.status_code == 500
    assert MyException.quiet is True
    assert isinstance(_sanic_exceptions.get(500), type)
    assert _sanic_exceptions.get(500) == MyException



# Generated at 2022-06-21 22:43:04.657331
# Unit test for function add_status_code
def test_add_status_code():
    class Exception403(SanicException):
        pass

    class Exception500(SanicException):
        pass

    add_status_code(403)(Exception403)
    add_status_code(500)(Exception500)
    assert _sanic_exceptions[403] == Exception403
    assert _sanic_exceptions[500] == Exception500



# Generated at 2022-06-21 22:43:06.701439
# Unit test for constructor of class PyFileError
def test_PyFileError():
    print(PyFileError("dummy.py"))


if __name__ == "__main__":
    test_PyFileError()

# Generated at 2022-06-21 22:43:14.929584
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "POST method not supported."
    method = "POST"
    allowed_methods = ("GET", "HEAD", "OPTIONS")
    exception = MethodNotSupported(message=message, method=method, allowed_methods=allowed_methods)
    assert exception.message == message
    assert exception.method == method
    assert exception.allowed_methods == allowed_methods
    assert exception.headers == {"Allow": ", ".join(allowed_methods)}


# Generated at 2022-06-21 22:43:18.592379
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Initialize an exception with a message and status code
    exc = InvalidUsage("Hello", status_code=400)
    # Test if the message and status code are correct
    assert exc.status_code == 400
    assert exc.message == "Hello"

# Generated at 2022-06-21 22:43:21.026092
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden("forbidden").message == "forbidden"
    assert Forbidden("forbidden").status_code == 403

# Generated at 2022-06-21 22:43:25.277694
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("timeout for my rest")
    except RequestTimeout as ex:
        assert ex.__class__.__name__ == "RequestTimeout"
        assert ex.message == "timeout for my rest"


# Generated at 2022-06-21 22:43:26.972812
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    a = ContentRangeError(message='message', content_range=1)
    assert a.message == 'message'


# Generated at 2022-06-21 22:43:46.259911
# Unit test for constructor of class NotFound
def test_NotFound():
    # Make sure default parameters are set correctly
    assert NotFound("hello").message == "hello"
    assert NotFound("hello").status_code == 404
    assert NotFound("hello").quiet is True


# Generated at 2022-06-21 22:43:47.536744
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert(issubclass(Forbidden, Exception))


# Generated at 2022-06-21 22:43:49.720768
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported("message", "method", "allowed_methods")
    assert mns.headers['Allow']=="allowed_methods"

# Generated at 2022-06-21 22:43:51.306290
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable(message="hello world").status_code==503

# Generated at 2022-06-21 22:43:54.042648
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    test = HeaderExpectationFailed("test")
    assert test.status_code == 417
    assert test.args == ("test",)
    assert test.message == "test"

# Generated at 2022-06-21 22:43:57.245314
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("test")
    assert error.args[0] == "could not execute config file %s"
    assert error.args[1] == "test"

# Generated at 2022-06-21 22:43:59.987005
# Unit test for constructor of class Forbidden
def test_Forbidden():
  try:
    raise Forbidden("No Access Allowed")
  except Forbidden as fe:
    assert fe.status_code == 403
    assert fe.message == "No Access Allowed"


# Generated at 2022-06-21 22:44:01.172214
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed()
    assert exception.__str__() == ''

# Generated at 2022-06-21 22:44:04.714922
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('abc','abc','abc')
    except FileNotFound as e:
        assert e.message=='abc'
        assert e.status_code==404
        assert e.path=='abc'
        assert e.relative_url=='abc'


# Generated at 2022-06-21 22:44:07.878809
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("Not Found")


# Generated at 2022-06-21 22:44:44.762622
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("invalid signal caught")
    except InvalidSignal as e:
        assert e.args == ("invalid signal caught",)
        assert e.status_code == 500

# Generated at 2022-06-21 22:44:47.946790
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden("message", quiet=True).status_code == 403
    assert Forbidden("message").quiet == False
    assert Forbidden("message").status_code == 403

# Generated at 2022-06-21 22:44:50.461158
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    obj = PayloadTooLarge("payload too large")
    assert obj.status_code == 413
    assert obj.message == "payload too large"


# Generated at 2022-06-21 22:44:53.707077
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("any_file").args[0] == "could not execute config file %s"
    assert PyFileError("any_file").args[1] == "any_file"


# Generated at 2022-06-21 22:44:56.194738
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType('abc', 'abc1')
    except InvalidRangeType as e:
        assert 'abc' == e.args[0]
        assert 'bytes */abc1' == e.headers['Content-Range']


# Generated at 2022-06-21 22:44:59.661025
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    instance = PayloadTooLarge("Palyload exceeds max size: 100", max_size=100)
    assert instance.status_code == 413
    assert instance.quiet == True

# Generated at 2022-06-21 22:45:02.188085
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Not existed signal")
    except InvalidSignal as err:
        print(err)

# Generated at 2022-06-21 22:45:05.314020
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    ir = ContentRangeError("Invalid Content-Range", 100)
    assert ir.message == "Invalid Content-Range"
    assert ir.headers == {"Content-Range": "bytes */100"}
    assert ir.status_code == 416

# Generated at 2022-06-21 22:45:07.937613
# Unit test for function abort
def test_abort():
    try:
        abort(404, 'Not Found')
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == 'Not Found'



# Generated at 2022-06-21 22:45:11.477972
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found_obj = NotFound("not found")
    assert not_found_obj.status_code == 404
    assert not_found_obj.quiet == True
    assert not_found_obj.message == "not found"



# Generated at 2022-06-21 22:46:24.760343
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge(message="xxx")
    except PayloadTooLarge as _e:
        assert _e.message == "xxx"
        assert _e.status_code == 413



# Generated at 2022-06-21 22:46:27.438524
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Test Message")
    except Exception as e:
        assert type(e) == ServiceUnavailable
        assert e.message == "Test Message"


# Generated at 2022-06-21 22:46:37.236826
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        # Description of Error: "message" a parameter, it can not be an empty string
        raise SanicException("")
    except Exception as e:
        assert(str(e) == "message should not be empty!")

    try:
        # Description of Error: "status_code" a parameter of class, it can not be an empty string
        raise SanicException("message", "")
    except Exception as e:
        assert(str(e) == "status_code should not be empty!")

    try:
        # Description of Error: "status_code" a parameter, type of status_code should be "int"
        raise SanicException("message", "status_code")
    except Exception as e:
        assert(str(e) == "status_code should be int!")


# Generated at 2022-06-21 22:46:39.089734
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    obj = LoadFileException("testdata/testpath")
    assert obj.__str__() == "Unable to load testdata/testpath"


# Generated at 2022-06-21 22:46:41.244200
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = "NotFound: 404 Not Found"
    with pytest.raises(NotFound, match=msg):
        raise NotFound("Not Found")


# Generated at 2022-06-21 22:46:44.604425
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test_message = "Test message"
    load_file_exception = LoadFileException(message=test_message)
    assert load_file_exception.message == test_message
    assert load_file_exception.status_code == 500


# Generated at 2022-06-21 22:46:46.692554
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden(message='Failed')
    except Forbidden as e:
        assert e.status_code == 403
        assert e.message == 'Failed'


# Generated at 2022-06-21 22:46:47.934915
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError('Test URLBuildError')
    assert error.status_code == 500

# Generated at 2022-06-21 22:46:51.594244
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201, True)
    class Created(SanicException):
        pass
    try:
        raise Created(message='test_add_status_code',status_code=201)
    except Created:
        assert _sanic_exceptions.get(201) == Created
        assert Created.quiet == True
        assert Created.status_code == 201

# Generated at 2022-06-21 22:46:53.491839
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("Unknown User")
    assert f.message == "Unknown User"
    assert f.status_code == 403


# Generated at 2022-06-21 22:49:34.380554
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Test Message", content_range=object)
    except Exception as e:
        exception_header = e.headers["Content-Range"]
        assert exception_header.startswith("bytes */")

# Generated at 2022-06-21 22:49:36.293509
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError(message="message", status_code=500)
    assert error.status_code == 500



# Generated at 2022-06-21 22:49:42.710494
# Unit test for function abort
def test_abort():
    # Bad request
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
    except Exception as e:
        assert False, "InvalidUsage not raised"

    # Not found
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    except Exception as e:
        assert False, "NotFound not raised"

    # Method not supported
    try:
        abort(405)
    except MethodNotSupported as e:
        assert e.status_code == 405
    except Exception as e:
        assert False, "MethodNotSupported not raised"

    # Internal server error
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500

# Generated at 2022-06-21 22:49:43.987356
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError("message", 12)
    assert e.headers["Content-Range"] == "bytes */12"


# Generated at 2022-06-21 22:49:45.546387
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Test Forbidden')
    except Forbidden as e:
        assert e.status_code == 403

# Generated at 2022-06-21 22:49:47.270500
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fnf = FileNotFound(message="testing", path="testing", relative_url="testing")



# Generated at 2022-06-21 22:49:58.168877
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 400

    @add_status_code(400)
    class MyException2(SanicException):
        pass

    assert MyException2.status_code == 400
    assert MyException2 is _sanic_exceptions[400]

    @add_status_code(500)
    class MyException3(SanicException):
        pass

    assert MyException3.status_code == 500
    assert MyException3 is _sanic_exceptions[500]

    @add_status_code(500, quiet=True)
    class MyException4(SanicException):
        pass

    assert MyException4.status_code == 500
    assert MyException4 is _sanic_exceptions[500]

   

# Generated at 2022-06-21 22:50:00.474895
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("A")
    except InvalidSignal as e:
        assert str(e) == "A"
        assert e.__class__ == InvalidSignal
