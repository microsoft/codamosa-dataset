

# Generated at 2022-06-21 22:40:00.313748
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    '''
    This function is used to test the constructor of class InvalidSignal.
    Parameters:
    none
    Returns:
    none
    '''
    InvalidSignal('HTTPError')
    # Test this method with no exception
    try:
        InvalidSignal('HTTPError')
    except Exception as e:
        assert False

# Generated at 2022-06-21 22:40:02.167575
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("file")

# Generated at 2022-06-21 22:40:07.436727
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
	# Save log file
	logging.basicConfig(filename='InvalidRangeType.log', level=logging.DEBUG)
	# Sent message = "anh"
	logging.debug("anh")
	# Sent message = "linh"
	logging.debug("linh")
	# Sent mesage = "Linh"
	logging.debug("Linh")

# Generated at 2022-06-21 22:40:09.887491
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    example = InvalidUsage('A')
    assert example.message == 'A'
    assert example.status_code == 400



# Generated at 2022-06-21 22:40:13.789554
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('오류 난다.')
    except Exception as e:
        assert str(e) == '오류 난다.'
        assert type(e) == SanicException


# Generated at 2022-06-21 22:40:15.864581
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Signal is invalid")
    except InvalidSignal as err:
        assert str(err) == "Signal is invalid"

# Generated at 2022-06-21 22:40:20.101143
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("abcde", 23)
    except ContentRangeError as e:
        e.headers

# Generated at 2022-06-21 22:40:22.362870
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge.__init__ is not None


# Generated at 2022-06-21 22:40:25.049424
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    PayloadTooLarge('test')

# Generated at 2022-06-21 22:40:28.250819
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    errorMessage = "the range is too large"
    obj = ContentRangeError(errorMessage, 0)
    assert errorMessage == obj.args[0]
    assert "bytes */0" == obj.headers["Content-Range"]

# Generated at 2022-06-21 22:40:33.064282
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    print("testing InvalidUsage")
    try:
        raise InvalidUsage("test exception message")
    except Exception as e:
        assert e.args[0] == "test exception message"
        assert e.status_code == 400


# Generated at 2022-06-21 22:40:35.191991
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Test forbidden")
    except Forbidden as e:
        assert str(e) == "Test forbidden"
        assert e.status_code == 403


# Generated at 2022-06-21 22:40:40.675691
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message="test should not appear", content_range=1000)
    except InvalidRangeType as ex:
        assert ex.args[0] == "test should not appear"
        assert ex.headers == {"Content-Range": "bytes */1000"}
        assert ex.status_code == 416

# Generated at 2022-06-21 22:40:44.188872
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    assert issubclass(HeaderNotFound, InvalidUsage), "HeaderNotFound is a subclass of InvalidUsage"
    assert HeaderNotFound.__doc__ == "**Status**: 400 Bad Request", "HeaderNotFound docstring is wrong"


# Generated at 2022-06-21 22:40:49.313752
# Unit test for function abort
def test_abort():
    expected_message_404 = "Not Found"
    expected_message_500 = "Internal Server Error"
    expected_message_401 = "Unauthorized"
    assert abort(404).message == expected_message_404
    assert abort(500).message == expected_message_500
    assert abort(401).message == expected_message_401
    custom_error_message = "hello world"
    assert abort(404, custom_error_message).message == custom_error_message

# Generated at 2022-06-21 22:40:55.185012
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("Message", status_code=200).status_code == 200
    assert SanicException("Message", status_code=200, quiet=True).status_code == 200
    assert SanicException("Message", status_code=200, quiet=True).quiet == True
    assert SanicException("Message", status_code=200, quiet=False).quiet == False
    assert SanicException("Message", status_code=500, quiet=None).quiet == False
    assert SanicException("Message", status_code=200, quiet=None).quiet == True


# Generated at 2022-06-21 22:40:57.794583
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    allowed_methods = ["HEAD", "GET", "POST", "PUT", "DELETE"]
    message = "Dummy message"
    exc = ServiceUnavailable(message)
    assert exc.message == message
    assert exc.status_code == 503
    assert exc.quiet is None

# Generated at 2022-06-21 22:40:58.475047
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalidusage = InvalidUsage("Testing")



# Generated at 2022-06-21 22:41:04.403031
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Create a new instance of class ServerError
    message = "Something is wrong"
    status_code = 500

    # Create a new instance of class SanicException
    sanic_exception = SanicException(message, status_code)
    server_error = ServerError(message, status_code)

    # Create a new instance of class URLBuildError
    url_build_error = URLBuildError(message, status_code)
    # Test constructor of URLBuildError
    assert isinstance(url_build_error, URLBuildError) == True
    assert isinstance(url_build_error, ServerError) == True
    assert isinstance(server_error, SanicException) == True
    assert isinstance(url_build_error, SanicException) == True

# Generated at 2022-06-21 22:41:06.277788
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Test for ServerError')
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == 'Test for ServerError'



# Generated at 2022-06-21 22:41:13.268522
# Unit test for constructor of class SanicException
def test_SanicException():
    method = SanicException(message="Exception Test", status_code=500)
    assert method.message =="Exception Test" and method.status_code == 500


# Generated at 2022-06-21 22:41:17.184446
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        # Assign
        msg = "Request Timeout"
        # Action
        raise RequestTimeout(msg)
    except RequestTimeout as err:
        # Assert
        assert err.message == msg

# Generated at 2022-06-21 22:41:20.059731
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test")
    except SanicException as e:
        assert(e.message == "Test")
        assert(e.status_code == 500)


# Generated at 2022-06-21 22:41:23.169831
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    message = "Test"
    exception = ServiceUnavailable(message)
    assert message == exception.message
    assert exception.headers is None
    assert 503 == exception.status_code

# Generated at 2022-06-21 22:41:25.604043
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid signal")
    except Exception as error:
        assert str(error) == "Invalid signal"

# Generated at 2022-06-21 22:41:28.060950
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    ir = InvalidRangeType('expected range', 'range')
    assert ir.message == 'expected range'
    assert ir.content_range == 'range'

# Generated at 2022-06-21 22:41:30.361826
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge('Payload Too Large')
    assert exception
    assert exception.status_code == 413


# Generated at 2022-06-21 22:41:31.918029
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException("message")
    assert exception.message == "message"


# Generated at 2022-06-21 22:41:34.068934
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("header_name")
    except HeaderNotFound as e:
        assert e.message == "header_name"
    else:
        assert False

# Generated at 2022-06-21 22:41:38.366632
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    a = HeaderExpectationFailed("a", "b")
    assert a.status_code == 417
    assert a.message == "a"



# Generated at 2022-06-21 22:41:47.028582
# Unit test for constructor of class SanicException
def test_SanicException():
    SanicException('test', status_code=404)

# Generated at 2022-06-21 22:41:49.840289
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header is not found")
    except HeaderNotFound as exc:
        assert exc.args == ("Header is not found", )
        assert exc.status_code == 400

# Generated at 2022-06-21 22:41:51.468206
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Everything is broken')
    except Forbidden as e:
        pass

# Generated at 2022-06-21 22:41:53.996001
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("hello", 500)
    except InvalidUsage as e:
        assert str(e) == "hello"
        assert e.status_code == 500

# Generated at 2022-06-21 22:41:56.301639
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Test message")
    except URLBuildError as e:
        assert "Test message" == e.args[0]


# Generated at 2022-06-21 22:42:05.243985
# Unit test for function abort
def test_abort():
    try:
        abort(404)
        assert False
    except NotFound as e:
        assert e.status_code == 404
        assert "Not Found" == e.message
    try:
        abort(500)
        assert False
    except SanicException as e:
        assert e.status_code == 500
        assert "Internal Server Error" == e.message
    try:
        abort(400, "My Message")
        assert False
    except InvalidUsage as e:
        assert e.status_code == 400
        assert "My Message" == e.message
    try:
        abort(408)
        assert False
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.message == "Request Timeout"

# Generated at 2022-06-21 22:42:11.008619
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported('message', 'method', ['allowed_methods'])
    except MethodNotSupported as error:
        assert error.message == 'message'
        assert error.method == 'method'
        assert error.allowed_methods == ['allowed_methods']
        assert error.headers == {'Allow': 'allowed_methods'}

# Generated at 2022-06-21 22:42:14.967094
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test InvalidSignal")
    except InvalidSignal as e:
        assert str(e) == "test InvalidSignal"

# Generated at 2022-06-21 22:42:18.499798
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    message = 'Request entity too large'
    status_code = 413
    t = PayloadTooLarge(message, status_code)
    assert(t.status_code == status_code)


# Generated at 2022-06-21 22:42:22.623430
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = 400
    b = 'Bad Request'
    sanic_exception = _sanic_exceptions.get(a, SanicException)
    assert(sanic_exception == InvalidUsage)

# Generated at 2022-06-21 22:42:41.195774
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError('/test/')
    assert str(error) == "could not execute config file /test/"

# Generated at 2022-06-21 22:42:51.716446
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Basic",
            realm="Restricted Area"
        )
    except Unauthorized as exc:
        assert exc.message == "Auth required."
        assert exc.status_code is None
        assert exc.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }

    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Digest",
            realm="Restricted Area",
            qop="auth, auth-int",
            algorithm="MD5",
            nonce="abcdef",
            opaque="zyxwvu"
        )
    except Unauthorized as exc:
        assert exc.message == "Auth required."
        assert exc.status_code is None

# Generated at 2022-06-21 22:43:03.829973
# Unit test for function abort
def test_abort():
    # Test that we get the right status_code and message
    try:
        abort(400, "Bad Request")
    except SanicException as e:
        assert e.status_code == 400
        assert str(e) == "Bad Request"

    # Test that we get NotFound if 404
    try:
        abort(404)
    except SanicException as e:
        assert e.status_code == 404
        assert str(e) == "404 Not Found"

    # Test that we get NotFound if 404
    try:
        abort(408)
    except SanicException as e:
        assert e.status_code == 408
        assert str(e) == "408 Request Timeout"

    # Test that we get SanicException if 501

# Generated at 2022-06-21 22:43:06.319458
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("none")
    assert error.args[0] == "could not execute config file %s"
    assert error.args[1] == "none"

# Generated at 2022-06-21 22:43:09.880379
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Valid test
    a = ContentRangeError("Test error", "1-100/100")
    assert a.message == "Test error"
    assert a.headers == {'Content-Range': 'bytes */100'}
    # Invalid test
    b = ContentRangeError("Test error", "a-100/100")
    # Should raise an exception and AssertionError
    assert b.message == "Test error"

# Generated at 2022-06-21 22:43:16.402572
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    """
    Tests the constructor of FileNotFound by asserting that the
    error message contains the path and the relative url in the error message
    """
    path = "/foo/bar"
    relative_url = "http://localhost"
    error = FileNotFound(path=path, relative_url=relative_url)
    assert path in error.message
    assert relative_url in error.message

# Generated at 2022-06-21 22:43:17.858837
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge("__message__", 100, 200)
    assert(exception.args[0] == "__message__")
    assert(exception.status_code == 413)
    assert(exception.max_size == 200)
    assert(exception.length == 100)

# Generated at 2022-06-21 22:43:22.460837
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage(message="message", status_code=400, quiet=None)
    except InvalidUsage as error:
        print(error.message)
        print(error.status_code)
        print(error.quiet)
        print(error.headers)

# Generated at 2022-06-21 22:43:25.837307
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
   try:
      raise ServiceUnavailable(message='test message', status_code=500, quiet=True)
   except ServiceUnavailable:
      pass
   except Exception:
      assert False

# Generated at 2022-06-21 22:43:30.047260
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Range Not Satisfiable.", 10)
    except ContentRangeError as e:
        assert hasattr(e, 'headers')
        assert e.message == 'Range Not Satisfiable.'
        assert e.status_code == 416
        assert e.headers['Content-Range'] == 'bytes */10'


# Generated at 2022-06-21 22:44:05.085990
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    a=1
    b=2
    payload_too_large = PayloadTooLarge(a,b)
    assert(payload_too_large.message==a)
    assert(payload_too_large.status_code==b)


# Generated at 2022-06-21 22:44:09.979705
# Unit test for constructor of class NotFound
def test_NotFound():
    msg = 'this is not found'
    e = NotFound(message = msg)
    assert e.__class__.__name__ == 'NotFound'
    assert e.args == (msg,)
    assert e.message == msg


# Generated at 2022-06-21 22:44:12.711360
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    msg = "testing"
    try:
        raise HeaderNotFound(msg)
    except HeaderNotFound as e:
        assert e.message == msg
        assert e.status_code == 400

# Generated at 2022-06-21 22:44:16.737865
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    """
    When status code is 417, the message should be Header Expectation Failed
    """
    HeaderExpectationFailed = HeaderExpectationFailed(message="Header Expectation Failed", status_code=417)
    assert HeaderExpectationFailed.status_code == 417



# Generated at 2022-06-21 22:44:18.869114
# Unit test for constructor of class Forbidden
def test_Forbidden():
    error = Forbidden("Insufficient permissions")
    assert error.status_code == 403
    assert error.__str__() == "Insufficient permissions"

# Generated at 2022-06-21 22:44:20.915576
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported, match=r"test message"):
        raise MethodNotSupported("test message", "method", [])

# Generated at 2022-06-21 22:44:24.984217
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed("Description of the Exception")
    assert exception.status_code == 417
    assert exception.message == "Description of the Exception"
    assert exception.quiet == False
    assert exception.headers == None
    assert exception.payload == None
    assert exception.kwargs == {}

# Generated at 2022-06-21 22:44:33.001633
# Unit test for constructor of class SanicException
def test_SanicException():
    excp = SanicException(message='hello', status_code=403)
    assert(str(excp) == 'hello')
    assert(excp.status_code == 403)
    assert(excp.quiet == True)

    excp = SanicException(message='hello', status_code=500)
    assert(str(excp) == 'hello')
    assert(excp.status_code == 500)
    assert(excp.quiet == False)

# Generated at 2022-06-21 22:44:34.521472
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    assert(InvalidRangeType("HTTP Error: 416")=="HTTP Error: 416")

# Generated at 2022-06-21 22:44:39.408981
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == STATUS_CODES[404].decode('utf8')

    try:
        abort(404, 'File not found')
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == 'File not found'

# Generated at 2022-06-21 22:45:46.081891
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("msg", 'GET', ['POST'])
    except:
        assert MethodNotSupported("msg", 'GET', ['POST'])

# Generated at 2022-06-21 22:45:47.944601
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header = "test header"
    err = HeaderNotFound("header not found", header)
    if not isinstance(err, SanicException) or not isinstance(err, InvalidUsage):
        raise TypeError("type not match")
    if str(err) != "header not found":
        raise ValueError("Value not correct")

# Generated at 2022-06-21 22:45:58.407279
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    ex1 = HeaderNotFound("Couldn't find header")
    assert ex1.message == "Couldn't find header"
    assert ex1.status_code == 400
    assert ex1.quiet == True

    ex2 = HeaderNotFound("Couldn't find header", status_code = 404)
    assert ex2.message == "Couldn't find header"
    assert ex2.status_code == 404
    assert ex2.quiet == True

    ex2 = HeaderNotFound("Couldn't find header", status_code = 500)
    assert ex2.message == "Couldn't find header"
    assert ex2.status_code == 500
    assert ex2.quiet == False

    ex3 = HeaderNotFound("Couldn't find header", status_code = None)
    assert ex3.message == "Couldn't find header"
   

# Generated at 2022-06-21 22:46:00.276057
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden
    except Forbidden as e:
        assert e.message == "Forbidden"


# Generated at 2022-06-21 22:46:03.152167
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
   message = "Error: header not found."
   header_not_found = HeaderNotFound(message)
   assert header_not_found.message == message
   assert header_not_found.status_code == 400

# Generated at 2022-06-21 22:46:04.014587
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    e = RequestTimeout("Timeout")
    assert e.status_code == 408

# Generated at 2022-06-21 22:46:10.112253
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    from sanic.exceptions import HeaderNotFound

    with pytest.raises(HeaderNotFound) as error_info:
        raise HeaderNotFound('HeaderNotFound', foo="Bar")

    assert error_info.value.message == 'HeaderNotFound'
    assert error_info.value.foo == 'Bar'
    assert error_info.value.status_code == 400


# Generated at 2022-06-21 22:46:13.317147
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    start_range = 30
    end_range = 60
    total = 100
    content_range = {"type":"bytes", "start_range": start_range,
                     "end_range": end_range, "total_length": total}
    message = 'Range type is not supported'
    error = InvalidRangeType(message, content_range)
    assert error.headers == {"Content-Range": "bytes */100"}


# Generated at 2022-06-21 22:46:17.499075
# Unit test for constructor of class SanicException
def test_SanicException():
    # Arrange
    status_code = 404
    message = "This is a test"

    # Act
    exception = SanicException(message, status_code)

    # Assert
    assert exception
    assert exception.status_code == status_code
    assert exception.message == message
    assert exception.quiet is True

# Generated at 2022-06-21 22:46:27.658790
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exc = Unauthorized()
    assert exc.status_code == 401
    assert exc.headers is None
    assert str(exc) == "Unauthorized: Auth required."

    exc = Unauthorized(status_code=401)
    assert exc.status_code == 401
    assert exc.headers is None
    assert str(exc) == "Unauthorized: Auth required."

    exc = Unauthorized(status_code=403)
    assert exc.status_code == 403
    assert exc.headers is None
    assert str(exc) == "Unauthorized: Auth required."

    exc = Unauthorized(scheme="Basic", realm="Restricted Area")
    assert exc.status_code == 401
    assert exc.headers is not None
    assert exc.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

    exc

# Generated at 2022-06-21 22:48:54.068911
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    x = ServiceUnavailable("message")
    assert x.status_code == 503

# Generated at 2022-06-21 22:48:56.283368
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden("This is a test")
    assert f.status_code == 403
    assert f.message == "This is a test"


# Generated at 2022-06-21 22:48:59.197843
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("test error")
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.quiet == True
        assert str(e) == "test error"

# Generated at 2022-06-21 22:49:07.778935
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # all necessary information are fed into the constructor
    allowed_methods = ["GET", "POST"]
    error_message = "Error: Method is not supported. Allowed methods are GET and POST"
    method = "PUT"
    assert MethodNotSupported(error_message, method, allowed_methods).message == error_message
    assert MethodNotSupported(error_message, method, allowed_methods).headers["Allow"] == "GET, POST"

    # all necessary information are not fed into the constructor
    error_message = "Error: Method is not supported. Allowed methods are GET and POST"
    method = "PUT"
    assert MethodNotSupported(error_message, method).message == error_message

# Generated at 2022-06-21 22:49:11.452097
# Unit test for constructor of class Forbidden
def test_Forbidden():
	try:
		raise Forbidden("hello world")
	except Forbidden as e:
		assert(e.message == "hello world")
		assert(e.status_code == 403)
		assert(e.headers == {})
	else:
		assert(False)


# Generated at 2022-06-21 22:49:14.975601
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(PayloadTooLarge) as ex:
        msg = 'The content-length of the request is too large.'
        abort(413, msg)
    assert ex.value.status_code == 413
    assert str(ex.value) == 'The content-length of the request is too large.'

# Generated at 2022-06-21 22:49:17.907521
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('This is a PayloadTooLarge message')
    except PayloadTooLarge as e:
        assert e.status_code == 413
        assert e.message == 'This is a PayloadTooLarge message'


# Generated at 2022-06-21 22:49:20.298523
# Unit test for constructor of class NotFound
def test_NotFound():
    message = "Message Not Found"
    status_code = 404
    exception = NotFound(message)
    assert exception.status_code == status_code
    assert exception.message == message


# Generated at 2022-06-21 22:49:24.488942
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('forbidden message')
    assert hasattr(forbidden, 'message')
    assert hasattr(forbidden, 'status_code')
    assert hasattr(forbidden, 'quiet')
    assert forbidden.message == 'forbidden message'
    assert forbidden.status_code == 403
    assert forbidden.quiet == False


# Generated at 2022-06-21 22:49:26.534533
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout = RequestTimeout('msg', 408)
    assert timeout.status_code == 408
    assert timeout.quiet == True