

# Generated at 2022-06-21 22:40:02.845729
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Test the default constructor
    try:
        raise RequestTimeout()
    except RequestTimeout as e:
        assert e.status_code == 408

# Generated at 2022-06-21 22:40:05.102929
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge("Too large", 28).status_code == 413
    assert PayloadTooLarge("Too large", 28).quiet is True


# Generated at 2022-06-21 22:40:08.725915
# Unit test for constructor of class SanicException
def test_SanicException():
    sanicException = SanicException("SanicException", status_code=123, quiet=True)
    assert sanicException.status_code == 123
    assert sanicException.quiet == True and not sanicException.quiet is None


# Generated at 2022-06-21 22:40:12.027174
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Invalid Usage")
    except InvalidUsage as e:
        assert e.status_code == 400
    else:
        raise AssertionError("Exception has not raised.")


# Generated at 2022-06-21 22:40:15.112969
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        """
        **Status**: 400 Bad Request
        """

        pass

    assert _sanic_exceptions[400].__name__ == "BadRequest"

# Generated at 2022-06-21 22:40:18.725786
# Unit test for constructor of class PyFileError
def test_PyFileError():
    from pytest import raises

    with raises(PyFileError) as py_file_error:
        PyFileError('test')
    assert str(py_file_error.value) == 'could not execute config file test'

# Generated at 2022-06-21 22:40:22.256011
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(status_code=200)
    except SanicException as e:
        assert(e.status_code == 200)



# Generated at 2022-06-21 22:40:27.702770
# Unit test for constructor of class SanicException
def test_SanicException():
    exc = SanicException("test", status_code=404)
    assert exc.status_code == 404
    assert exc.args[0] == "test"
    exc = SanicException("test", status_code=404, quiet=True)
    assert exc.status_code == 404
    assert exc.args[0] == "test"
    assert exc.quiet == True

# Generated at 2022-06-21 22:40:31.581452
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("FileNotFound...", "a.txt", "url")
    except FileNotFound as e:
        assert(e.status_code == 404)
        assert(str(e) == "FileNotFound...")

# Generated at 2022-06-21 22:40:35.853344
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    content_range_error_obj = ContentRangeError(message='custom message',
                                                content_range=10)
    if(content_range_error_obj.headers['Content-Range'] == 'bytes */10'):
        print('constructor of class InvalidRangeType Test passed')
    else:
        print('constructor of class InvalidRangeType Test failed')


# Generated at 2022-06-21 22:40:42.762675
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exception = ContentRangeError("Range Not Satisfiable", 10)
    assert exception.headers["Content-Range"] == "bytes */10"
    assert exception.status_code == 416
    assert exception.message == "Range Not Satisfiable"

# Generated at 2022-06-21 22:40:46.044295
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge(message="Hello Sanic", status_code=413)
    assert error.message == "Hello Sanic"
    assert error.status_code == 413



# Generated at 2022-06-21 22:40:49.426729
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError()
    assert err.status_code == 500
    assert err.message == "Internal Server Error"


# Generated at 2022-06-21 22:40:51.902062
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('service unavailable exception')
    except Exception as e:
        assert e.status_code == 503
        assert e.quiet is True

# Generated at 2022-06-21 22:40:59.874308
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class MyException(SanicException):
        pass

    assert MyException.status_code == 200
    assert _sanic_exceptions[200].__name__ == "MyException"

    @add_status_code(500, quiet=True)
    class MyException2(SanicException):
        pass

    assert MyException2.status_code == 500
    assert MyException2.quiet == True
    assert _sanic_exceptions[500].__name__ == "MyException2"

# Generated at 2022-06-21 22:41:04.705741
# Unit test for function add_status_code
def test_add_status_code():
    def add_ok_status_code(cls):
        cls.status_code = 200
        cls.quiet = True
        return cls
    @add_ok_status_code
    class C(SanicException):
        pass
    assert C.status_code == 200
    assert C.quiet

    @add_status_code(200)
    class C(SanicException):
        pass
    assert C.status_code == 200
    assert C.quiet

# Generated at 2022-06-21 22:41:05.871618
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("", "", "")
    except:
        pass



# Generated at 2022-06-21 22:41:09.732477
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError('test message', 10)
    assert error.headers['Content-Range'] == 'bytes */10'
    assert error.status_code == 416
    assert str(error) == 'test message'

# Generated at 2022-06-21 22:41:12.793894
# Unit test for function abort
def test_abort():
    try:
        # Run the function
        abort(404)
    except Exception as exc:
        # Assert function returns the right exception
        assert exc.status_code == 404

# Generated at 2022-06-21 22:41:16.352251
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    err = HeaderNotFound("test")
    assert(err.status_code == 400)


if __name__ == "__main__":
    test_HeaderNotFound()

# Generated at 2022-06-21 22:41:23.111132
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message="Header not found in request.", headers=[])
    except HeaderNotFound as error:
        assert error.status_code == 400


# Generated at 2022-06-21 22:41:27.735523
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    with pytest.raises(FileNotFound) as exc:
        raise FileNotFound(message="File not found", path="SomePath", relative_url="SomeUrl")
    assert exc.value.path == "SomePath"
    assert exc.value.relative_url == "SomeUrl"



# Generated at 2022-06-21 22:41:29.531610
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    exception = ServiceUnavailable("Server is overloaded")
    assert exception.message == "Server is overloaded"

# Generated at 2022-06-21 22:41:37.479707
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(999)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[999] is TestException
    assert issubclass(TestException, SanicException)
    assert TestException().status_code == 999
    assert _sanic_exceptions.get(999) is TestException

    @add_status_code(998, quiet=False)
    class TestException2(SanicException):
        pass

    assert _sanic_exceptions[998] is TestException2
    assert not TestException2().quiet
    assert _sanic_exceptions.get(998) is TestException2

    @add_status_code(997, quiet=True)
    class TestException3(SanicException):
        pass

    assert _sanic_exceptions[997] is TestException3
   

# Generated at 2022-06-21 22:41:40.372146
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("This is a test")
    except URLBuildError as err:
        assert str(err) == "This is a test"



# Generated at 2022-06-21 22:41:44.341851
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException('Hello', status_code=200)
    assert isinstance(exception, Exception)
    assert exception.args == ('Hello',)
    assert exception.__str__() == 'Hello'
    assert exception.status_code == 200

# Generated at 2022-06-21 22:41:47.901243
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Create a HeaderExpectationFailed object with default parameters
    HeaderExpectationFailed()
    # Create a HeaderExpectationFailed object with custom parameters
    HeaderExpectationFailed("message", "status_code", "quiet")

# Generated at 2022-06-21 22:41:52.264224
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    message = 'Test Exception'
    content_range = 100
    with pytest.raises(InvalidRangeType) as exc:
        raise InvalidRangeType(message, content_range)
    assert exc.value.args[0] == message
    assert exc.value.headers == {'Content-Range': 'bytes */100'}

# Generated at 2022-06-21 22:41:55.076903
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('message', 'status_code')
    except Forbidden as exception:
        assert exception.status_code == 'status_code'
        assert exception.message == 'message'


# Generated at 2022-06-21 22:41:58.523787
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("123")
        assert False, "invalidusage"
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "123"
        assert e.__class__.__name__ == "InvalidUsage"


# Generated at 2022-06-21 22:42:08.775799
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("")
    except ServerError as err:
        assert err.status_code == 500
        assert err.args[0] == ""

# Generated at 2022-06-21 22:42:17.279854
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('non_existing_signal')
    except Exception as e:
        assert type(e) == InvalidSignal
        assert e.status_code == 500
        assert str(e) == 'non_existing_signal'


# Generated at 2022-06-21 22:42:23.721168
# Unit test for function abort
def test_abort():
    """
    Unit test for function abort
    :return:
    """
    # Given
    http_status = 400
    message = 'Bad Request'

    # When
    try:
        abort(http_status, message)
    except Exception as e:
        # Then
        expected = 'Bad Request'
        assert str(e) == expected


# Generated at 2022-06-21 22:42:24.380421
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError('asd')
    assert error is not None

# Generated at 2022-06-21 22:42:28.168506
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('InvalidUsage', status_code=None, quiet=None)
    except InvalidUsage as e:
        try:
            assert e.args[0] == 'InvalidUsage'
            assert e.status_code == 400
            assert e.quiet is False
        finally:
            pass

# Generated at 2022-06-21 22:42:30.178727
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("hi.py").args == ("could not execute config file hi.py",)


# Generated at 2022-06-21 22:42:34.368149
# Unit test for constructor of class Forbidden
def test_Forbidden():
    msg = "test"
    # Instantiate class and test if the message is set correctly
    f = Forbidden(msg)
    assert f.message == msg
    # Test if the status code is set correctly
    assert f.status_code == 403

# Generated at 2022-06-21 22:42:36.962551
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal) as exc_info:
        raise InvalidSignal()
    assert 'InvalidSignal' == exc_info.typename

# Generated at 2022-06-21 22:42:38.089619
# Unit test for constructor of class NotFound
def test_NotFound():
    nf = NotFound("")

# Generated at 2022-06-21 22:42:43.759070
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = "/tmp/file.txt"
    relative_url = "/file.txt"
    ex = FileNotFound('File not found', path, relative_url)

    assert ex.path == path
    assert ex.relative_url == relative_url

# Generated at 2022-06-21 22:42:58.602744
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    FNF = FileNotFound("message", "/usr/local/bin/test.py", "/usr/local/bin/test.py")
    assert FNF.message == "message"
    assert FNF.path == "/usr/local/bin/test.py"
    assert FNF.relative_url == "/usr/local/bin/test.py"


# Generated at 2022-06-21 22:43:04.195132
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert str(e) == '404: Not Found'

    try:
        abort(505, "Not Supported")
    except SanicException as e:
        assert e.status_code == 505
        assert str(e) == '505: Not Supported'



# Generated at 2022-06-21 22:43:05.941821
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('denied')
    except Forbidden as e:
        assert e.args[0] == 'denied'

# Test for Syntax Error

# Generated at 2022-06-21 22:43:11.368951
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported(
            "The method is not supported.", "PUT", ["GET", "POST", "HEAD"])
    except Exception as e:
        assert e.status_code == 405
        assert e.headers["Allow"] == "GET, POST, HEAD"
        assert e.message == "The method is not supported."

# Generated at 2022-06-21 22:43:14.983429
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req_timeout = RequestTimeout('expected error', 408)
    assert req_timeout.status_code == 408
    assert req_timeout.message == 'expected error'


# Generated at 2022-06-21 22:43:21.294966
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("hello")
        assert False, "Should have raised an exception"
    except ServiceUnavailable as e:
        assert isinstance(e, SanicException)
        assert e.message == "hello"
        assert e.status_code == 503
    finally:
        assert ServiceUnavailable.status_code == 503
        assert ServiceUnavailable.quiet is False



# Generated at 2022-06-21 22:43:22.711667
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout("Test RequestTimeout Message", 408)
    assert isinstance(rt, SanicException)
    assert rt.status_code == 408
    assert rt.message == "Test RequestTimeout Message"


# Generated at 2022-06-21 22:43:25.335033
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exc = InvalidUsage("test")
    assert exc.status_code == 400



# Generated at 2022-06-21 22:43:29.920707
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("missing file", "missing", "missing")
    except Exception as e:
        assert e.__class__ == FileNotFound
        assert e.args[0] == "missing file"
        assert e.path == "missing"
        assert e.relative_url == "missing"
    else:
        raise Exception("FileNotFound not raised")


# Generated at 2022-06-21 22:43:31.630294
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    r = RequestTimeout("message")
    assert r.status_code == 408 and r.quiet == True

# Generated at 2022-06-21 22:44:04.678037
# Unit test for function abort
def test_abort():
    """
    Test for function abort
    """
    from sanic.helpers import STATUS_CODES

    with pytest.raises(NotFound) as e:
        abort(404)

    assert STATUS_CODES[404].decode(
        "utf8"
    ) == e.value.args[0]  # pylint: disable=unsubscriptable-object

    with pytest.raises(Forbidden) as e:
        abort(403)

    assert STATUS_CODES[403].decode(
        "utf8"
    ) == e.value.args[0]  # pylint: disable=unsubscriptable-object

    with pytest.raises(ServerError) as e:
        abort(500)


# Generated at 2022-06-21 22:44:10.389086
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("URL not found")
    except NotFound as e:
        assert e._status_code == 404
        assert e.status_code == 404
        assert e.message == "URL not found"
        assert e.args[0] == "URL not found"



# Generated at 2022-06-21 22:44:13.695741
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():

    print("hello world")
    try:
        raise InvalidUsage("Bad Request", status_code=400)
    except InvalidUsage as e:
        assert e.message == "Bad Request"
        assert e.status_code == 400

# Generated at 2022-06-21 22:44:17.427864
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Invalid message')
    except InvalidUsage as e:
        assert e.status_code == 400

    try:
        raise InvalidUsage('Invalid message', status_code=404)
    except InvalidUsage as e:
        assert e.status_code == 404

# Generated at 2022-06-21 22:44:22.700742
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized('Basic', realm="Restricted Area")
    except Unauthorized as e:
        assert str(e) == "Auth required."
        assert e.status_code == 401
        assert e.scheme == 'Basic'
        assert e.realm == "Restricted Area"
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-21 22:44:25.529046
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_input = 1234
    payload_too_large = PayloadTooLarge(test_input)
    assert payload_too_large.status_code == 413
    assert payload_too_large.message == str(test_input)

# Generated at 2022-06-21 22:44:33.159054
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('test message', status_code=500)
    except ServerError as exc:
        assert isinstance(exc, ServerError)
        assert isinstance(exc, SanicException)
        assert isinstance(exc, Exception)
        assert exc.message == 'test message'
        assert exc.status_code == 500
        assert str(exc) == "test message"


# Generated at 2022-06-21 22:44:37.116236
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    message = "signal unknown"
    try:
        raise InvalidSignal(message)
    except InvalidSignal as err:
        assert err.message == message
        assert err.status_code == 500
        assert err.quiet is None


# Generated at 2022-06-21 22:44:38.517763
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout('408-RequestTimeout')

# Generated at 2022-06-21 22:44:40.521000
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(1234)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 1234



# Generated at 2022-06-21 22:45:35.669201
# Unit test for constructor of class NotFound
def test_NotFound():
    pass



# Generated at 2022-06-21 22:45:37.398451
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException()


# Generated at 2022-06-21 22:45:38.905296
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_inst = PayloadTooLarge("message")
    assert test_inst.message == "message"


# Generated at 2022-06-21 22:45:42.936246
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = "GET"
    allowed_methods = ["GET","POST"]
    message = "No matching method found."
    exception = MethodNotSupported(message=message, method=method, allowed_methods=allowed_methods)
    print(exception)
    assert exception.message == message
    assert exception.method == method
    assert exception.headers["Allow"] == ", ".join(allowed_methods)

if __name__ == "__main__":
    test_MethodNotSupported()

# Generated at 2022-06-21 22:45:45.164007
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("failure")
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == "failure"
        assert isinstance(e, SanicException)


# Generated at 2022-06-21 22:45:48.902192
# Unit test for function add_status_code
def test_add_status_code():
    class CustomException(SanicException):
        pass

    class CustomException1(SanicException):
        pass

    assert CustomException(message="Custom Exception", status_code=500).status_code == 500
    assert NotFound(message="Not Found").status_code == 404
    assert InvalidUsage(message="Invalid Usage").status_code == 400
    assert MethodNotSupported(message="Method Not Supported", method="POST", allowed_methods=["GET", "POST"]).status_code == 405
    assert ServerError(message="Server Error").status_code == 500
    assert CustomException1(message="Custom Exception1", status_code=503).status_code == 503
    assert PayloadTooLarge(message="Payload Too Large").status_code == 413

# Generated at 2022-06-21 22:45:49.743588
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    obj=PayloadTooLarge()

# Generated at 2022-06-21 22:45:51.644524
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Could not build URL.")
    except Exception as e:
        assert e.args[0] == "Could not build URL."

# Generated at 2022-06-21 22:45:55.106236
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError(message="Message", content_range=ContentRange(a=10, b=20, total=30))

test_ContentRangeError()

# Generated at 2022-06-21 22:45:57.622233
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        # Raise SanicException class with 404 exception
        abort(404)
    except SanicException as e:
        assert e.status_code == 404

# Generated at 2022-06-21 22:47:57.715615
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("ContentRangeError", 145633)
    except Exception as e:
        assert e.args[0] == "ContentRangeError"
        assert e.message == "ContentRangeError"
        assert e.status_code == 416
        assert e.headers == {"Content-Range": "bytes */145633"}

# Generated at 2022-06-21 22:47:59.844430
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound('Test')
    assert hnf.status_code == 400
    assert hnf.message == 'Test'

# Generated at 2022-06-21 22:48:00.745501
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    InvalidSignal('test')


# Generated at 2022-06-21 22:48:04.855487
# Unit test for function abort
def test_abort():
    # test sanic_exception
    try:
        abort(404, "abort message")
    except SanicException as e:
        assert repr(e) == 'SanicException("abort message", status_code=404)'
    except Exception:
        assert False, "Should be SanicException"

    # test SanicException
    try:
        abort(500)
    except SanicException as e:
        assert repr(e) == 'ServerError("Internal Server Error", status_code=500)'
    except Exception:
        assert False, "Should be SanicException"

    # test NotFound
    try:
        abort(404)
    except NotFound as e:
        assert repr(e) == 'NotFound("Not Found", status_code=404)'
    except Exception:
        assert False, "Should be NotFound"



# Generated at 2022-06-21 22:48:08.708740
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("test_message",400)
    except SanicException as err:
        assert(err.args[0] == "test_message")
        assert(err.status_code == 400)
        assert(err.quiet == False)


# Generated at 2022-06-21 22:48:12.714068
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound(message="Not Found", status_code=404).status_code == 404
    assert NotFound(message="Not Found", status_code=404).message == "Not Found"


# Generated at 2022-06-21 22:48:22.149762
# Unit test for function abort
def test_abort():
    _status_codes = {
        404: NotFound,
        400: InvalidUsage,
        405: MethodNotSupported,
        500: ServerError,
        503: ServiceUnavailable,
        400: InvalidUsage,
        408: RequestTimeout,
        413: PayloadTooLarge,
        416: ContentRangeError,
        417: HeaderExpectationFailed,
        403: Forbidden,
        401: Unauthorized,
    }
    for status_code, e in _status_codes.items():
        try:
            abort(status_code)
        except Exception as exception:
            assert isinstance(exception, e)
            assert exception.status_code == status_code
        else:
            assert False


# Generated at 2022-06-21 22:48:27.858569
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "The value of Content-Range must be 'bytes ' followed by an integer-valued byte-range-spec, which is of the form 'first-last/length', where first is the first byte-position of the byte-range-spec, last is the last byte-position of the byte-range-spec, and length is the length of the selected representation in bytes. Note that the byte positions are inclusive."
    ContentRangeError(message, 8)

# Generated at 2022-06-21 22:48:29.875302
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exc = Forbidden("Testing the Forbidden Exception")
    assert exc.status_code == 403


# Generated at 2022-06-21 22:48:31.188903
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test")
    except Exception:
        pass