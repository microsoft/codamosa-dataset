

# Generated at 2022-06-21 22:39:58.235783
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge("test", status_code=413, quiet=True).status_code == 413
    assert PayloadTooLarge("test", status_code=413, quiet=True).message == 'test'
    assert PayloadTooLarge("test", status_code=413, quiet=True).quiet == True

# Generated at 2022-06-21 22:40:01.912837
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError("message")
    assert str(exception) == "message"
    assert exception.status_code == 500
    exception = URLBuildError("message", status_code=418)
    assert str(exception) == "message"
    assert exception.status_code == 418
    assert exception.quiet is None
    exception = URLBuildError("message", quiet=True)
    assert str(exception) == "message"
    assert exception.status_code == 500
    assert exception.quiet is True

# Generated at 2022-06-21 22:40:03.585557
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = ContentRangeError('error', 0)
    assert a.message == 'error'
    assert a.headers == {'Content-Range': 'bytes */0'}

# Generated at 2022-06-21 22:40:04.185363
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLBuildError()

# Generated at 2022-06-21 22:40:09.575034
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message="Sample message", path="/path/to/file", relative_url="images/sample.png")
    except FileNotFound as err:
        assert isinstance(err, FileNotFound)
        assert err.path == "/path/to/file"
        assert err.relative_url == "images/sample.png"


# Generated at 2022-06-21 22:40:11.546247
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    urlbuilderror=URLBuildError("Test")
    assert urlbuilderror.message=="Test"


# Generated at 2022-06-21 22:40:17.471761
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("exception message", "path", "relative_url")
    except FileNotFound as inst:
        assert inst.path == "path"
        assert inst.relative_url == "relative_url"


# Generated at 2022-06-21 22:40:19.709527
# Unit test for constructor of class PyFileError
def test_PyFileError():
    exc = PyFileError('testfile.py')
    assert exc.__class__ == PyFileError
    assert str(exc) == "could not execute config file %s"
    assert exc.args[0] == 'testfile.py'

# Generated at 2022-06-21 22:40:25.388497
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("the path is not found", "the path", "the url")
    except FileNotFound as e:
        assert e.path == "the path"
        assert e.relative_url == "the url"
        assert e.status_code == 404
        assert e.message == "the path is not found"

# Generated at 2022-06-21 22:40:34.966564
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Ex1(SanicException):
        pass

    @add_status_code(200)
    class Ex2(SanicException):
        pass

    @add_status_code(200, True)
    class Ex3(SanicException):
        pass

    assert _sanic_exceptions[100] is Ex1
    assert _sanic_exceptions[200] is Ex2
    assert _sanic_exceptions[200] is Ex3

    assert Ex1().status_code == 100
    assert Ex2().status_code == 200
    assert Ex3().status_code == 200

    assert Ex1().quiet == False
    assert Ex2().quiet == None
    assert Ex3().quiet == True



# Generated at 2022-06-21 22:40:39.845373
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('a','b')
    except LoadFileException as e:
        assert str(e)=='a'
        assert e.status_code == 'b'

# Generated at 2022-06-21 22:40:41.716629
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as e_info:
        raise ServiceUnavailable('The service is unavailable')

# Generated at 2022-06-21 22:40:46.079350
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    filename = "abc.txt"
    relative_url = "abc.txt"
    exception = FileNotFound(filename, relative_url)
    if (exception.path != filename) or (exception.relative_url != relative_url):
        raise Exception("Test FileNotFound constructor failed!")

# Generated at 2022-06-21 22:40:56.031010
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as e:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    assert e.value.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

    with pytest.raises(Unauthorized) as e:
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")

# Generated at 2022-06-21 22:41:00.443346
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test1 = LoadFileException('Test1',status_code = 400)
    assert test1.message == 'Test1'
    assert test1.status_code == 400

    test2 = LoadFileException('Test2')
    assert test2.message == 'Test2'
    assert test2.status_code == 500



# Generated at 2022-06-21 22:41:01.690734
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException('Invalid file content!')


# Generated at 2022-06-21 22:41:03.114289
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Sanic web framework")
    except URLBuildError as e:
        print(e)

# Generated at 2022-06-21 22:41:07.634731
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    teststr = "Unicode String"
    testIRT = InvalidRangeType(teststr, 123)
    assert testIRT.status_code == 416
    assert testIRT.args[0] == teststr
    assert testIRT.headers['Content-Range'] == "bytes */123"



# Generated at 2022-06-21 22:41:17.290459
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    obj = HeaderExpectationFailed(message='content-length', quiet=None)
    obj.status_code = 417
    print(type(obj))
    print(type(obj.status_code))
    print(obj.status_code)
    print(obj.message)
    print(obj.headers)
    assert obj.message == 'content-length'
    assert obj.headers == {}
    print(STATUS_CODES[417])
    print(STATUS_CODES[obj.status_code])
    print(obj.status_code == 417)


# Generated at 2022-06-21 22:41:21.990650
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(
            message="file not found",
            path="abc/abc",
            relative_url="/abc/abc"
        )
    except FileNotFound as f:
        try:
            assert(f.message == "file not found")
            assert(f.path == "abc/abc")
            assert(f.relative_url == "/abc/abc")
        except AssertionError as e:
            raise e

# Generated at 2022-06-21 22:41:29.801582
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("not found")


# Generated at 2022-06-21 22:41:37.635463
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as exception_info:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert exception_info.value.status_code == 401
    assert exception_info.value.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

    with pytest.raises(Unauthorized) as exception_info:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")

# Generated at 2022-06-21 22:41:48.646381
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # testing with scheme=None
    try:
        raise Unauthorized("Auth required.")
    except Unauthorized as e:
        assert e.headers is None
    else:
        assert False, "Should raise Unauthorized"
    # testing with scheme='Basic'
    try:
        raise Unauthorized(
            "Auth required.",
            scheme="Basic",
            realm="Restricted Area")
    except Unauthorized as e:
        assert e.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }
    else:
        assert False, "Should raise Unauthorized"
    # testing with scheme='Digest'

# Generated at 2022-06-21 22:41:50.656359
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    err = InvalidRangeType('Please send a valid range', None)
    assert err.__dict__ == {'message': 'Please send a valid range', 'headers': {'Content-Range': 'bytes */None'}}

# Generated at 2022-06-21 22:41:54.043208
# Unit test for constructor of class NotFound
def test_NotFound():
    print("Test constructor of class NotFound")
    not_found = NotFound("message")
    assert not_found.message == "message"
    assert not_found.status_code == 404
    assert not_found.quiet == True


# Generated at 2022-06-21 22:41:57.004803
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("some message")
    except SanicException as e:
        assert e.status_code == None
        assert not e.quiet
        assert e.message == "some message"


# Generated at 2022-06-21 22:42:05.585020
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    class HeaderExpectationFailed1(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True

    class HeaderExpectationFailed(HeaderExpectationFailed1):

        status_code = 417

        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message, status_code, quiet)
    assert HeaderExpectationFailed.status_code == 417

# Generated at 2022-06-21 22:42:10.304014
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    message = 'Service Unavailable'
    status_code = 503
    sanicException = ServiceUnavailable(message, status_code)
    assert sanicException.status_code == 503
    assert sanicException.quiet == True

# Generated at 2022-06-21 22:42:15.721093
# Unit test for constructor of class NotFound
def test_NotFound():
    """
    Test for class NotFound constructor
    """
    not_found = NotFound("Not Found")
    assert not_found.message == "Not Found"
    assert not_found.status_code == 404

# Generated at 2022-06-21 22:42:18.328181
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class BadRequest(SanicException):
        pass

    assert _sanic_exceptions[400] == BadRequest

# Generated at 2022-06-21 22:42:22.897671
# Unit test for constructor of class SanicException
def test_SanicException():
    SanicException('test',status_code=100, quiet=True)

# Generated at 2022-06-21 22:42:27.287763
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('message','content_range')
    except ContentRangeError as e:
        assert e.message == 'message'
        assert e.content_range == 'content_range'
        assert e.headers == {'Content-Range' : 'bytes */content_range'}


# Generated at 2022-06-21 22:42:30.856888
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    s = ServiceUnavailable("Test Service Unavailable")
    assert s.message == "Test Service Unavailable"
    assert s.status_code == 503
    assert s.quiet == True

# Generated at 2022-06-21 22:42:33.742555
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    foo = LoadFileException
    try:
        raise foo
    except LoadFileException:
        foo.args


# Generated at 2022-06-21 22:42:35.992734
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Testing Sanic Exception", status_code=500)
    except SanicException as e:
        assert e

# Generated at 2022-06-21 22:42:40.048950
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException) as e:
        raise LoadFileException("File not found")
    assert e.value.message == "File not found"


# Generated at 2022-06-21 22:42:43.457836
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout(None, None)



# Generated at 2022-06-21 22:42:47.551039
# Unit test for function add_status_code
def test_add_status_code():

    @add_status_code(201, quiet=True)
    class TestException(SanicException):
        status_code = None

    assert 201 in _sanic_exceptions
    assert _sanic_exceptions[201] is TestException
    assert TestException.status_code == 201
    assert TestException.quiet



# Generated at 2022-06-21 22:42:52.031093
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound(
        message='',
        path='path',
        relative_url='relative_url',
    )
    assert file_not_found.message == ''
    assert file_not_found.path == 'path'
    assert file_not_found.relative_url == 'relative_url'


# Generated at 2022-06-21 22:42:54.532890
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except LoadFileException as e:
        assert isinstance(e, SanicException)



# Generated at 2022-06-21 22:43:05.407397
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert NotFound.status_code == 404


# Generated at 2022-06-21 22:43:10.314484
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    expected_message = "Could not find the file"
    expected_path = "path"
    expected_relative_url = "relative_url"
    file_not_found = FileNotFound(expected_message, expected_path, expected_relative_url)
    print(file_not_found)
    assert file_not_found.message == expected_message
    assert file_not_found.path == expected_path
    assert file_not_found.relative_url == expected_relative_url
    assert file_not_found.status_code == 404



# Generated at 2022-06-21 22:43:15.764949
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Sorry, Forbidden.')
    except Forbidden as ex:
        assert(ex.status_code == 403)
        assert(ex.args[0] == 'Sorry, Forbidden.')
        assert(ex.args[1] == 403)
        assert(ex.args[2] is False)

# Generated at 2022-06-21 22:43:19.120084
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    failed = HeaderExpectationFailed("Error", 500)
    assert failed.message == "Error"
    assert failed.status_code == 500
    assert failed.quiet == True


# Generated at 2022-06-21 22:43:20.141433
# Unit test for constructor of class Forbidden
def test_Forbidden():
    Forbidden("dummy message")

# Generated at 2022-06-21 22:43:25.665180
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    Tests if the constructor of RequestTimeout works as expected
    """
    try:
        exception = RequestTimeout("404 - Not found")
        assert exception.status_code == 408
        assert exception.message == "404 - Not found"
    except:
        raise AssertionError("RequestTimeout constructor does not work")
    pass

# Generated at 2022-06-21 22:43:28.821045
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    #pylint: disable=unused-variable
    try:
        raise PayloadTooLarge("test")
    except PayloadTooLarge as err:
        assert err.status_code == 413
        assert isinstance(err, SanicException)

# Generated at 2022-06-21 22:43:32.531078
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message="test", path="test.txt", relative_url="test.txt")
    except FileNotFound as e:
        assert e.message == "test"
        assert e.path == "test.txt"
        assert e.relative_url == "test.txt"


# Generated at 2022-06-21 22:43:33.661169
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    exception = LoadFileException('Some message')
    assert exception.message == 'Some message'

# Generated at 2022-06-21 22:43:35.160597
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError(3)

# Generated at 2022-06-21 22:43:55.025486
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # arrange
    msg = 'Test Message'

    # act
    obj = HeaderExpectationFailed(message=msg)

    # assert
    assert obj.message == msg


# Generated at 2022-06-21 22:43:57.746070
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("an exception")
    except Exception as e:
        status_code = e.status_code
        assert status_code is None



# Generated at 2022-06-21 22:44:01.745303
# Unit test for function add_status_code
def test_add_status_code():
    # Test add_status_code
    @add_status_code(700)
    class Test(SanicException):
        pass
    assert _sanic_exceptions[700] == Test
    assert Test.status_code == 700
    assert _sanic_exceptions[700]().status_code == 700
    assert Test.quiet

# Generated at 2022-06-21 22:44:03.702823
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException.__init__(SanicException, "test message", status_code=404, quiet=True)

# Generated at 2022-06-21 22:44:08.754260
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
	try:
		raise InvalidUsage("This is an error")
	except InvalidUsage as err:
		assert err.message == "This is an error"
		assert err.status_code == 400
		assert err.quiet == True

# Generated at 2022-06-21 22:44:11.943833
# Unit test for constructor of class NotFound
def test_NotFound():
    message = 'Not Found'
    status = 404
    status_code = NotFound(message, status)
    assert status_code.status_code == status
    assert status_code.message == message


# Generated at 2022-06-21 22:44:15.644760
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("asdasd")
    except Exception as e:
        assert type(e) == InvalidSignal
        assert e.status_code == 500
        assert e.message == "asdasd"

# Generated at 2022-06-21 22:44:18.314074
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Forbidden from server", status_code=403)
    except Forbidden as e:
        assert e.message == "Forbidden from server"
        assert e.status_code == 403


# Generated at 2022-06-21 22:44:20.317103
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('q')
    forbidden.status_code == 403
    forbidden.quiet == True
    forbidden.message == 'q'


# Generated at 2022-06-21 22:44:24.810802
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("Error message")
    assert error.__str__() == "Error message"

    error = ServerError("Error message", status_code=500, quiet=True)
    assert error.__str__() == "Error message"
    assert error.quiet == True
    assert error.status_code == 500


# Generated at 2022-06-21 22:45:00.668298
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method = "GET"
    message = "get"
    allowed_methods = ["GET"]
    a = MethodNotSupported(message, method, allowed_methods)



# Generated at 2022-06-21 22:45:03.978098
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError) as err:
        raise URLBuildError("message")
    assert str(err.value) == "message"



# Generated at 2022-06-21 22:45:10.105663
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(400)(SanicException)().status_code == 400
    assert add_status_code(500)(SanicException)().quiet == True
    assert add_status_code(404)(SanicException)().quiet == True
    assert add_status_code(500, quiet=False)(SanicException)().quiet == False
    assert add_status_code(500, quiet=True)(SanicException)().quiet == True

# Generated at 2022-06-21 22:45:12.453497
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    with pytest.raises(Exception):
        # In the source code, this constructor is not defined
        InvalidRangeType("Invalid range", "bytes 0-1/1")

# Generated at 2022-06-21 22:45:14.980933
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout(
            message="The request timed out.",
            status_code=408
        )


# Generated at 2022-06-21 22:45:21.412826
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large_exception = PayloadTooLarge(message="Payload Too Large", status_code=413)
    assert payload_too_large_exception.status_code == 413
    assert payload_too_large_exception.quiet == True 


# Generated at 2022-06-21 22:45:24.090252
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    x = ServiceUnavailable("test")
    assert x.status_code == 503
    assert x.quiet == True
    assert x.headers == {}


# Generated at 2022-06-21 22:45:28.485978
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed()
        print('Error: HeaderExpectationFailed is raised')
    except HeaderExpectationFailed as er:
        print('test_HeaderExpectationFailed is passed')
        print('code =', er.status_code)
        print('errno =', er.errno)
    except Exception as er:
        print('test_HeaderExpectationFailed is failed')
        print(er)


# Generated at 2022-06-21 22:45:33.432831
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge(message="greater than 1MB", status_code=413)
    except PayloadTooLarge as e:
        assert e.message == "greater than 1MB"
        assert e.status_code == 413
    else:
        assert False, "Expected exception"

# Generated at 2022-06-21 22:45:41.755816
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # happy flow
    try:
        raise Unauthorized("Auth required.", scheme="Basic",
                               realm="Restricted Area", foo="bar")
    except Unauthorized as e:
        assert e.headers == {
            "WWW-Authenticate": f'Basic realm="Restricted Area", foo="bar"'}
    # scheme and realm are mandatory
    try:
        raise Unauthorized("Auth required.", scheme="Scheme is Mandatory",
                               foo="bar")
    except Unauthorized:
        pass
    try:
        raise Unauthorized("Auth required.", realm="Realm is Mandatory",
                               foo="bar")
    except Unauthorized:
        pass
    # accept valid scheme
    try:
        raise Unauthorized("Auth required.", scheme="Basic",
                               realm="Restricted Area", foo="bar")
    except Unauthorized:
        pass


# Generated at 2022-06-21 22:46:53.655361
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Construct a simple request timeout object.
    requestTimeout = RequestTimeout("Request Timed Out", 408)
    assert requestTimeout.message == "Request Timed Out"
    assert requestTimeout.status_code == 408


# Generated at 2022-06-21 22:46:56.960761
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
	try:
		raise InvalidUsage('The operation is not permitted', status_code=403)
	except Exception as e:
		print(e.__doc__)
		print(e.message)
		print(e.status_code)

# Generated at 2022-06-21 22:47:01.457872
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("test", "test", "test")
    assert file_not_found.path == "test"
    assert file_not_found.relative_url == "test"
    assert file_not_found.quiet is True
    assert isinstance(file_not_found, NotFound)



# Generated at 2022-06-21 22:47:05.382369
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        from sanic.exceptions import URLBuildError
        raise URLBuildError("Bad Request")
    except Exception as error:
        assert error.status_code == 500

# Generated at 2022-06-21 22:47:07.883794
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Forbidden!")
    except Forbidden as e:
        assert e.message == "Forbidden!"
        assert e.status_code == 403


# Generated at 2022-06-21 22:47:17.309856
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    import os
    import sys
    import unittest
    try:
        import sanic
    except ImportError:
        sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir)))
        import sanic
    else:
        print('sanic module imported from {0}'.format(sanic.__file__))
    
    from sanic.exceptions import InvalidRangeType
    
    class TestInvalidRangeType(unittest.TestCase):
        def test_InvalidRangeType(self):
            try:
                raise InvalidRangeType
            except InvalidRangeType:
                assert True
            else:
                assert False
    
    unittest.main()

# Generated at 2022-06-21 22:47:24.294176
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as not_found:
        assert not_found.message == "Not Found"
    except SanicException as error:
        assert error.message == "Not Found"

    try:
        abort(404, "Not here")
    except NotFound as not_found:
        assert not_found.message == "Not here"
    except SanicException as error:
        assert error.message == "Not here"

# Generated at 2022-06-21 22:47:27.441913
# Unit test for function abort
def test_abort():
    with pytest.raises(ServerError) as e:
        abort(500)
    assert e.value.message == 'Internal Server Error'
    assert e.value.status_code == 500



# Generated at 2022-06-21 22:47:29.006400
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        content_range = 20
        raise ContentRangeError("message", content_range)
    except ContentRangeError as e:
        assert e.headers

# Generated at 2022-06-21 22:47:37.709040
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    assert MethodNotSupported("message", None, []).headers == {"Allow": ""}
    assert MethodNotSupported("message", None, ["GET"]).headers == {"Allow": "GET"}
    assert MethodNotSupported("message", None, ["GET", "POST"]).headers == {"Allow": "GET, POST"}
    assert MethodNotSupported("message", "POST", []).headers == {"Allow": ""}
    assert MethodNotSupported("message", "POST", ["GET"]).headers == {"Allow": "GET"}
    assert MethodNotSupported("message", "POST", ["GET", "POST"]).headers == {"Allow": "GET, POST"}