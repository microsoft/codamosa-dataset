

# Generated at 2022-06-21 22:39:58.994946
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException):
        abort(999)

    with pytest.raises(NotFound):
        abort(404)


# Generated at 2022-06-21 22:40:00.452436
# Unit test for constructor of class NotFound
def test_NotFound():  
    with pytest.raises(NotFound):
        raise NotFound('NotFound!!!')

# Generated at 2022-06-21 22:40:07.120921
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(414)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == 414
    assert TestClass.quiet is False

    @add_status_code(415)
    class TestClass2(SanicException):
        pass

    assert TestClass2.status_code == 415
    assert TestClass2.quiet is True


# Generated at 2022-06-21 22:40:10.757311
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message='')
    except HeaderExpectationFailed as e:
        print(e)
if __name__ == '__main__':
    test_HeaderExpectationFailed()

# Generated at 2022-06-21 22:40:14.642318
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Service Unavailable")
    except Exception as e:
        assert e.status_code == 503
        assert str(e) == "Service Unavailable"

# Generated at 2022-06-21 22:40:17.657394
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exc = PayloadTooLarge('Payload too large')
    assert exc.status_code == 413
    assert exc.message == 'Payload too large'


# Generated at 2022-06-21 22:40:20.091160
# Unit test for constructor of class PyFileError
def test_PyFileError():
    f = '/var/log/foobar.log'
    py_file_error = PyFileError(file=f)
    assert py_file_error.args[0] == "could not execute config file %s"
    assert py_file_error.args[1] == f


# Generated at 2022-06-21 22:40:22.361549
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    HeaderExpectationFailed("Expectation failed",status_code=417)

# Generated at 2022-06-21 22:40:30.180370
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(AttributeError) as excinfo:
        raise ContentRangeError("Range Not Satisfiable")
    assert excinfo.type == AttributeError
    assert excinfo.value.args == ("'ContentRangeError' object has no attribute 'total'", )
    raise ContentRangeError("Range Not Satisfiable", ContentRange(0,10,20))


# Generated at 2022-06-21 22:40:33.528848
# Unit test for constructor of class ServerError
def test_ServerError():
    msg = 'Some error'
    e = ServerError(msg)
    assert e.status_code == 500
    assert str(e) == msg
    assert e.message == msg


# Generated at 2022-06-21 22:40:37.658505
# Unit test for constructor of class SanicException
def test_SanicException():
    err = SanicException('ERROR occurred')
    print(err.status_code)


# Generated at 2022-06-21 22:40:41.385371
# Unit test for constructor of class SanicException
def test_SanicException():
    # check empty message
    message = None
    status_code = 404
    quiet = True
    exception = SanicException(message, status_code, quiet)
    assert exception.message == message
    assert exception.status_code == status_code
    assert exception.quiet == quiet

    # check with message
    message = 'InvalidUsage'
    status_code = 400
    quiet = True
    exception = SanicException(message, status_code, quiet)
    assert exception.message == message
    assert exception.status_code == status_code
    assert exception.quiet == quiet


# Generated at 2022-06-21 22:40:47.480438
# Unit test for constructor of class SanicException
def test_SanicException():
    exc = SanicException("test message")
    assert exc.status_code == None
    assert exc.quiet == None
    assert exc.message == "test message"
    assert exc.__str__() == "test message"

    exc = SanicException("test message", status_code=400)
    assert exc.status_code == 400
    assert exc.quiet == True
    assert exc.message == "test message"
    assert exc.__str__() == "test message"



# Generated at 2022-06-21 22:40:51.719262
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test")
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "test"
        assert e.quiet is False

# Generated at 2022-06-21 22:40:56.310576
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    filename = "file.txt"
    exception = FileNotFound(message="", path=filename, relative_url=filename)
    assert exception.path == filename
    assert exception.relative_url == filename


# Generated at 2022-06-21 22:41:00.303029
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    import sys
    try:
        raise MethodNotSupported("message", 'method', 'allowed_methods')
    except MethodNotSupported as e:
        assert e.message == 'message'
        assert e.headers == {'Allow': 'allowed_methods'}
        assert e.status_code == 405



# Generated at 2022-06-21 22:41:02.073364
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Test InvalidUsage")
    except InvalidUsage as e:
        assert e.message == "Test InvalidUsage"
        assert e.status_code == 400


# Generated at 2022-06-21 22:41:03.216478
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    s = ServiceUnavailable("test")
    assert s.message == "test"
    assert s.status_code == 503

# Generated at 2022-06-21 22:41:09.994339
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Testing class Unauthorized without auth-scheme
    try:
        raise Unauthorized("Auth required.")
    except Unauthorized as ex:
        assert ex.headers == {}
    
    # Testing class Unauthorized with auth-scheme
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as ex:
        assert ex.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-21 22:41:18.043716
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    class assert_RequestTimeout(SanicException):
            def __init__(self, message, status_code=None, quiet=None):
                super().__init__(message)
                self.status_code = status_code
                
    assert(RequestTimeout("Request Timeout") == assert_RequestTimeout("Request Timeout",status_code=408))
    assert(RequestTimeout("Request Timeout",quiet=True) == assert_RequestTimeout("Request Timeout",status_code=408,quiet=True))


# Generated at 2022-06-21 22:41:23.111496
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError):
        raise ServerError("Server Error")

# Generated at 2022-06-21 22:41:25.640678
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("Error: range not satisfiable.", 5)
    assert error.headers["Content-Range"] == "bytes */5"
    assert error.message == "Error: range not satisfiable."

# Generated at 2022-06-21 22:41:27.500828
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable()
    except Exception as e:
        assert e.status_code == 503
        assert e == ServiceUnavailable(e.args[0], e.status_code)

# Generated at 2022-06-21 22:41:30.924442
# Unit test for constructor of class NotFound
def test_NotFound():
    test_message = "Test message"
    err = NotFound(test_message)
    assert isinstance(err, NotFound)
    assert err.message == test_message
    assert err.status_code == 404
    assert not err.quiet


# Generated at 2022-06-21 22:41:34.068959
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as error:
        assert error.status_code == 400
        assert error.message == b'BAD REQUEST'.decode('utf8')

if __name__ == "__main__":
    test_abort()

# Generated at 2022-06-21 22:41:37.929090
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    a=PayloadTooLarge("hello", 'world')
    assert a.message == "hello"
    assert a.status_code == 413


# Generated at 2022-06-21 22:41:43.658396
# Unit test for constructor of class PyFileError
def test_PyFileError():
    msg = "could not execute config file %s"
    file = 'file.py'

    pyfileerror1 = PyFileError(file)
    pyfileerror2 = PyFileError(file)

    assert pyfileerror1.args == (msg,)
    assert pyfileerror1.args == pyfileerror2.args
    assert pyfileerror1.args == pyfileerror2.args

# Generated at 2022-06-21 22:41:44.792811
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    pass


# Generated at 2022-06-21 22:41:46.976032
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(" ")
    except ServiceUnavailable as e:
        assert e.status_code == 503

# Generated at 2022-06-21 22:41:49.787691
# Unit test for constructor of class ServerError
def test_ServerError():
    e = _sanic_exceptions[500]()
    assert e.status_code == 500
    assert e.quiet == True
    assert e.args[0] == 'None'



# Generated at 2022-06-21 22:41:57.246983
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    ServiceUnavailable("Testing 123")

# Generated at 2022-06-21 22:41:59.014606
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = InvalidSignal('Invalid Signal', status_code=500)
    signal.status_code = 500
    signal.message = 'Invalid signal'


# Generated at 2022-06-21 22:42:04.037144
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage("test message1",status_code=401)
    assert a.message == "test message1"
    assert a.status_code==401
    b = InvalidUsage("test message2")
    assert b.message == "test message2"
    assert b.status_code==400
    assert a.quiet == True
    assert b.quiet == True


# Generated at 2022-06-21 22:42:08.657475
# Unit test for constructor of class ServerError
def test_ServerError():
    message = "Testing constructing of ServerError"
    try:
        raise ServerError(message)
    except SanicException as e:
        assert message == e.args[0]


# Generated at 2022-06-21 22:42:12.016657
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():

    # Create a class instance for InvalidRangeType
    clazz = InvalidRangeType("message", 100)
    
    # Check if message is valid
    assert clazz.message == "message"
    assert clazz.status_code == 416

# Generated at 2022-06-21 22:42:13.870756
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout(message='Request Timeout', status_code=408)

# Generated at 2022-06-21 22:42:17.028284
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
	try:
		raise InvalidUsage("My Invalid Usage")
	except InvalidUsage as e:
		print(e)
		assert e.status_code == 400


# Generated at 2022-06-21 22:42:24.379808
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("Content Range error.", 100)
    except ContentRangeError as e:
        msg = e.args[0]
        code = e.status_code
        internal_code = e.code
        headers = e.headers
        assert msg == "Content Range error."
        assert code == 416
        assert internal_code == 416
        assert headers == {"Content-Range": "bytes */100"}



# Generated at 2022-06-21 22:42:28.688611
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exp = "This is a test Exception"
    val = 10
    total = 100
    try:
        raise InvalidRangeType(exp, val, total)
    except InvalidRangeType as irt:
        err = irt.args[0]
        assert err == exp
        assert irt.content_range == (val, total)

# Generated at 2022-06-21 22:42:35.079414
# Unit test for function add_status_code
def test_add_status_code():
    """
    Add status code and exception (Greeter) to _sanic_exceptions
    """
    @add_status_code(status_code=200, quiet=True)
    class Greeter(SanicException):
        pass
    assert Greeter(message='').status_code == 200
    assert Greeter(message='').quiet is True
    assert _sanic_exceptions[200] == Greeter

# Generated at 2022-06-21 22:42:49.610869
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("test123", stack_info=True)
    print(err)


# Generated at 2022-06-21 22:42:53.366542
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("file not found", "file", "null")
    except FileNotFound as e:
        assert e.__class__ == FileNotFound
        assert e.status_code == "404"
        assert e.message == "file not found"



# Generated at 2022-06-21 22:42:59.135309
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    c = 0
    for i in range(1, 1001):
        c += len(str(i))
    msg = "Hello world."
    r = ContentRangeError(msg, ContentRange(0, 20, 1000))
    assert r.message == msg
    assert r.headers == {"Content-Range": f"bytes */{c}"}

# Generated at 2022-06-21 22:43:02.312463
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("test_file.py")
    assert error.args[0] == "could not execute config file %s"
    assert error.args[1] == "test_file.py"

# Generated at 2022-06-21 22:43:05.736459
# Unit test for constructor of class SanicException
def test_SanicException():
    class SanicTest(SanicException):
        pass

    try:
        raise SanicTest("test_message")
    except SanicTest as t:
        assert t.message == "test_message"



# Generated at 2022-06-21 22:43:07.269715
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(InvalidSignal):
        raise InvalidSignal("test_InvalidSignal")

# Generated at 2022-06-21 22:43:16.496339
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage('I am mad')
    assert a.message == 'I am mad'
    assert a.status_code == 400
    assert a.quiet == True

    b = InvalidUsage('I am not mad', 404)
    assert b.message == 'I am not mad'
    assert b.status_code == 404
    assert b.quiet == True

    c = InvalidUsage('I am sad', quiet=False)
    assert c.message == 'I am sad'
    assert c.status_code == 400
    assert c.quiet == False


# Generated at 2022-06-21 22:43:25.094681
# Unit test for constructor of class ServerError
def test_ServerError():
    test_ServerError = ServerError(message = "msg", status_code = 500)
    if test_ServerError.status_code == 500:
        print("test_ServerError.status_code = 500 is right")
    if test_ServerError.message == "msg":
        print("test_ServerError.message = msg is right")
    if test_ServerError.args[0] == "msg":
        print("test_ServerError.args[0] = msg is right")

if __name__ == "__main__":
    test_ServerError()

# Generated at 2022-06-21 22:43:31.840952
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    test_ServiceUnavailable = ServiceUnavailable("some message")
    assert test_ServiceUnavailable.status_code == 503
    test_ServiceUnavailable = ServiceUnavailable("some message", 503)
    assert test_ServiceUnavailable.status_code == 503
    assert test_ServiceUnavailable.message == "some message"
    test_ServiceUnavailable.headers = "some headers"
    assert test_ServiceUnavailable.headers == "some headers"
    assert test_ServiceUnavailable.quiet is False
    test_ServiceUnavailable.quiet = True
    assert test_ServiceUnavailable.quiet is True


# Generated at 2022-06-21 22:43:34.751236
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
	try:
		req = RequestTimeout("The request timed out.","GET",["POST"])
		assert req.message == "The request timed out."
		assert req.status_code == 408
	except Exception as e:
		print("Exception:", e)
		assert False

# Generated at 2022-06-21 22:44:06.507195
# Unit test for constructor of class PyFileError
def test_PyFileError():
    f = open("test.py", "w")
    f.write("print(123)")
    f.close()
    test_file = "test.py"
    error = PyFileError(test_file)
    assert("could not execute config file %s", test_file) == error.args
    assert str(error) == 'could not execute config file %s'
    os.remove("test.py")



# Generated at 2022-06-21 22:44:10.653095
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    test = HeaderExpectationFailed("expect 100 continue")
    assert test.status_code == 417
    assert test.message == "expect 100 continue"
    assert test.quiet == True
    assert str(test) == "expect 100 continue"


# Generated at 2022-06-21 22:44:14.016578
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("forbidden!")
    except Forbidden as err:
        assert getattr(err, "status_code", None) == 403
        assert err.quiet == True


# Generated at 2022-06-21 22:44:18.041310
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    
    max_str_len = 1*(1024*1024*1024)

    # Create a huge string
    huge_str = "." * max_str_len

    with pytest.raises(PayloadTooLarge) as context:
        raise PayloadTooLarge("Request Too Large")



# Generated at 2022-06-21 22:44:22.701750
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        try:
            raise HeaderExpectationFailed(message='message', status_code=417)
        except HeaderExpectationFailed as err:
            assert err.args[0] == 'message'
            assert err.status_code == 417
    except Exception:
        assert False
    assert True



# Generated at 2022-06-21 22:44:23.933593
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    ex = HeaderExpectationFailed()
    assert ex.status_code == 417


# Generated at 2022-06-21 22:44:25.088066
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    n = ServiceUnavailable(message="Service Unavailable")
    assert n.message == "Service Unavailable"


# Generated at 2022-06-21 22:44:37.697270
# Unit test for function abort
def test_abort():
    """
    Test if the abort function throws a valid SanicException based on status_code.
    """
    with pytest.raises(NotFound) as e:
        abort(404)

    assert e.value.status_code == 404
    assert e.value.message == "Not Found"
    assert e.value.quiet == True

    with pytest.raises(Forbidden) as e:
        abort(403)

    assert e.value.status_code == 403
    assert e.value.message == "Forbidden"
    assert e.value.quiet == True

    # Pass a message that should overwrite the default message
    with pytest.raises(Forbidden) as e:
        abort(403, "Not allowed")

    assert e.value.status_code == 403
    assert e.value.message == "Not allowed"


# Generated at 2022-06-21 22:44:38.429123
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    range = InvalidRangeType('message', 'range')

# Generated at 2022-06-21 22:44:40.394904
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as excinfo:
        raise HeaderNotFound("HeaderNotFound")

    assert "HeaderNotFound" in str(excinfo.value)

# Generated at 2022-06-21 22:45:39.274541
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="message")
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert str(e) == 'message'

# Generated at 2022-06-21 22:45:40.912682
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("test")
    assert forbidden.message == "test"
    assert forbidden.status_code == 403


# Generated at 2022-06-21 22:45:44.550691
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
  fnf = FileNotFound("message","path","relative_url")
  assert fnf.status_code == 404


# Generated at 2022-06-21 22:45:47.121552
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(InvalidUsage) as e:
        raise HeaderNotFound('msg')
    assert str(e.value) == 'msg'
    assert e.value.status_code == 400


# Generated at 2022-06-21 22:45:50.235782
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test_URLBuildError")
    except URLBuildError as e:
        test_result = str(e)
        assert test_result == "test_URLBuildError"

# Generated at 2022-06-21 22:45:51.921815
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("Message", "status_code")
    result = hnf.__str__()
    assert result == "Message"


# Generated at 2022-06-21 22:45:57.195197
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class ClassNotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    assert ClassNotFound.status_code == 404
    assert _sanic_exceptions.get(404) == ClassNotFound



# Generated at 2022-06-21 22:45:59.375902
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed('message')
    except HeaderExpectationFailed as err:
        assert err.status_code == 417

# Generated at 2022-06-21 22:46:03.069284
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    t = InvalidRangeType("Range Not Satisfiable", 400)
    assert t.message == "Range Not Satisfiable"
    assert t.status_code == 400
    assert isinstance(t, SanicException)
    assert isinstance(t, ContentRangeError)


# Generated at 2022-06-21 22:46:10.008713
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage("This is invalid.", 1001)
    assert exception.status_code == 1001 and exception.quiet == True
    exception = InvalidUsage("This is invalid.", 1001, False)
    assert exception.status_code == 1001 and exception.quiet == False
    exception = InvalidUsage("This is invalid.", 1001, True)
    assert exception.status_code == 1001 and exception.quiet == True
    exception = InvalidUsage("This is invalid.", 1001, None)
    assert exception.status_code == 1001 and exception.quiet == True
    exception = InvalidUsage("This is invalid.", 400)
    assert exception.status_code == 400 and exception.quiet == True
    exception = InvalidUsage("This is invalid.", 400, False)
    assert exception.status_code == 400 and exception.quiet == False

# Generated at 2022-06-21 22:48:17.620848
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = 'resources/fixtures'
    relative_url = '/fixtures/hello.txt'
    message = 'Could not find the requested resource'
    exception = FileNotFound(message, path, relative_url)
    assert exception.message == message
    assert exception.relative_url == relative_url
    assert exception.path == path


# Generated at 2022-06-21 22:48:20.080118
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Build error.")
    except Exception as e:
        assert type(e) == URLBuildError
        assert str(e) == "Build error."



# Generated at 2022-06-21 22:48:26.237820
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 400

    @add_status_code(400, False)
    class TestException2(SanicException):
        pass

    assert TestException2.status_code == 400
    assert isinstance(TestException2(), TestException2)

    @add_status_code(400, True)
    class TestException3(SanicException):
        pass
    assert TestException3.status_code == 400
    assert isinstance(TestException3(), TestException3)
    assert TestException3().quiet == True

    @add_status_code(500, None)
    class TestException4(SanicException):
        pass
    assert TestException4.status_code == 500

# Generated at 2022-06-21 22:48:28.311658
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    error = LoadFileException(message="hi")
    assert error.args[0] == "hi"
    assert error.kwargs is not None
    assert error.status_code == 500
    assert error.kwargs["message"] == "hi"
    assert error.kwargs["status_code"] == 500


# Generated at 2022-06-21 22:48:31.025214
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    f = FileNotFound(message='test', path='test', relative_url='test')
    assert f.path == 'test'
    assert f.relative_url == 'test'

# Generated at 2022-06-21 22:48:33.269567
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert URLBuildError("ErrorTest").args[0] == URLBuildError.message
    assert URLBuildError("ErrorTest").status_code == None

# Generated at 2022-06-21 22:48:38.124213
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "message"
    method = "GET"
    allowed_methods = ["POST"]

    exception = MethodNotSupported(message, method, allowed_methods)
    assert exception.message == message
    assert exception.method == method
    assert exception.allowed_methods == allowed_methods
    assert exception.headers == {"Allow": "POST"}

# Generated at 2022-06-21 22:48:42.840348
# Unit test for constructor of class ServerError
def test_ServerError():
    with pytest.raises(ServerError) as exc_info:
        raise ServerError(message="Test", status_code=500, quiet=False)
    assert exc_info.value.message == 'Test'
    assert exc_info.value.status_code == 500
    assert exc_info.value.quiet is False


# Generated at 2022-06-21 22:48:44.461826
# Unit test for function add_status_code
def test_add_status_code():
    add_status_code(11, quiet=True)(SanicException)
    assert _sanic_exceptions[11].status_code == 11
    assert _sanic_exceptions[11].quiet



# Generated at 2022-06-21 22:48:47.006549
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as exc_info:
        raise HeaderNotFound('HeaderNotFound')
    assert exc_info.value.status_code == 400
