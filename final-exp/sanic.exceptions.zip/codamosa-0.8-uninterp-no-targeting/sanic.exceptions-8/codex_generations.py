

# Generated at 2022-06-21 22:40:05.204238
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("could not build")
    except URLBuildError as e:
        assert str(e) == "could not build"

# Generated at 2022-06-21 22:40:08.413753
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError('config')
    assert (str(pyfileerror) == "could not execute config file config")

if __name__ == "__main__":
    test_PyFileError()

# Generated at 2022-06-21 22:40:13.502769
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound("Not Found")
    assert not_found.status_code == 404
    assert not_found.quiet == True
    assert str(not_found) == "Not Found"
    not_found = NotFound("Not Found", status_code = 500)
    assert not_found.status_code == 500
    assert not_found.quiet == False
    assert str(not_found) == "Not Found"
    not_found = NotFound("Not Found", quiet = False)
    assert not_found.status_code == 404
    assert not_found.quiet == False
    assert str(not_found) == "Not Found"


# Generated at 2022-06-21 22:40:15.445153
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout(message='Timeout')
    except RequestTimeout as e:
        assert e.status_code == 408
        assert e.args == ('Timeout',)

# Generated at 2022-06-21 22:40:18.672244
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message='test message')
    except ServerError as e:
        if e.message != 'test message':
            raise Exception


# Generated at 2022-06-21 22:40:22.622731
# Unit test for constructor of class ServerError
def test_ServerError():
    err_msg = "Error message"
    err = ServerError(err_msg)
    assert err.message == err_msg
    assert err.status_code == 500
    assert err.quiet == False

# Generated at 2022-06-21 22:40:25.906091
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as error:
        error = PyFileError('C:\\Users\\invis\\Desktop\\blog.py')

# Generated at 2022-06-21 22:40:29.596803
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('ServerError')
    except ServerError as serverError:
        assert  serverError.status_code == 500
        assert serverError.message == 'ServerError'


# Generated at 2022-06-21 22:40:34.378061
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Internal Server Error", 500)
    except ServerError as test_e:
        assert(repr(test_e) == "Internal Server Error")
        assert(str(test_e) == "Internal Server Error")
        assert(test_e.status_code == 500)
        assert(test_e.quiet == False)

# Generated at 2022-06-21 22:40:38.299508
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():

    try:
        raise InvalidSignal("This is a new error")
    except InvalidSignal as err:
        assert "This is a new error" in str(err)



# Generated at 2022-06-21 22:40:45.518819
# Unit test for function add_status_code
def test_add_status_code():
    def test_1():
        return add_status_code(404)(SanicException)

    @add_status_code(404)
    class Test2(SanicException):
        pass
    
    assert test_1().status_code == 404
    assert hasattr(test_1(), 'quiet')
    assert Test2.status_code == 404
    assert hasattr(Test2, 'quiet')


# Generated at 2022-06-21 22:40:47.479294
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test error")
    except ServerError as e:
        assert str(e) == "test error"

# Generated at 2022-06-21 22:40:52.706421
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    >>> test_ServiceUnavailable()
    503
    """
    status_code = 503
    se = ServiceUnavailable("test", status_code)
    print(se.status_code)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:40:53.634068
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    URLBuildError('error message')

# Generated at 2022-06-21 22:40:57.041405
# Unit test for constructor of class Forbidden
def test_Forbidden():
    message = "test message for Forbiddden"
    exception = Forbidden(message)
    assert exception.message == message
    assert exception.status_code == 403

# Generated at 2022-06-21 22:40:59.002476
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("408 Timeout")
    except:
        exc = sys.exc_info()[1]
        if exc.status_code != 408:
            raise



# Generated at 2022-06-21 22:40:59.960785
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    assert LoadFileException('Load file failed') is not None

# Generated at 2022-06-21 22:41:01.754616
# Unit test for constructor of class ServerError
def test_ServerError():
    sr_exception = ServerError("Server Error")
    assert sr_exception.message == "Server Error"
    assert sr_exception.status_code == 500
    assert sr_exception.quiet == False

# Generated at 2022-06-21 22:41:06.004343
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == STATUS_CODES[404]

    try:
        abort(400, 'Bad request')
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'Bad request'

# Generated at 2022-06-21 22:41:10.397109
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HTTP Header Not Found Error", "Location")
    except HeaderNotFound as e:
        assert "HTTP Header Not Found Error" == str(e)
        assert "Location" == e.args[1]

# Generated at 2022-06-21 22:41:18.443204
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("error message")
    assert error.status_code == 500
    assert error.quiet is True

    error = ServerError("error message", status_code=503)
    assert error.status_code == 503
    assert error.quiet is None

    error = ServerError("error message", status_code=503, quiet=False)
    assert error.status_code == 503
    assert error.quiet is False

# Generated at 2022-06-21 22:41:21.501504
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "config.py"
    msg = "could not execute config file %s"
    with pytest.raises(PyFileError) as err:
        raise PyFileError(file)
    assert str(err.value) == msg % file


# Generated at 2022-06-21 22:41:24.073482
# Unit test for constructor of class NotFound
def test_NotFound():
    status_code = 404
    nf = NotFound(status_code)
    assert nf.status_code == status_code


# Generated at 2022-06-21 22:41:25.604517
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError('message', "bytes */100")

# Generated at 2022-06-21 22:41:31.048935
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = 'invalid range'
    range_total = 100
    content_range = ContentRange(range_total=range_total)
    content_range_error = ContentRangeError(message, content_range)
    assert content_range_error.message == message
    assert content_range_error.status_code == 416
    assert content_range_error.headers == {'Content-Range':'bytes */100'}

# Generated at 2022-06-21 22:41:32.912930
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("Not Found")


# Generated at 2022-06-21 22:41:36.255325
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("message", status_code=404, quiet=True)



# Generated at 2022-06-21 22:41:45.991343
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized(
            "testing",
            status_code=401,
            scheme="Bearer",
            realm="The Realm",
            randomKey="randomValue",
        )

    assert excinfo.value.args[0] == "testing"
    assert excinfo.value.kwargs == {
        "status_code": 401,
        "scheme": "Bearer",
        "realm": "The Realm",
        "randomKey": "randomValue",
    }
    assert excinfo.value.headers["WWW-Authenticate"] == 'Bearer realm="The Realm", randomKey="randomValue"'

# Generated at 2022-06-21 22:41:48.965887
# Unit test for constructor of class NotFound
def test_NotFound():
    status=404
    message="404 Not Found"
    quiet=True
    try:
        assert NotFound(message,status,quiet)
    except Exception as e:
        print(e)


# Generated at 2022-06-21 22:41:52.578901
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exc = InvalidSignal('test')
    assert exc.__class__ == InvalidSignal
    assert exc.__name__ == 'InvalidSignal'
    assert str(exc) == 'test'
    assert exc.__dict__ == {}

# Generated at 2022-06-21 22:41:56.927601
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    x = ContentRangeError(message="message", content_range=5)
    assert x.message == "message"
    assert x.headers["Content-Range"] == "bytes */5"
    assert x.status_code == 416
    assert x.quiet == True

# Generated at 2022-06-21 22:41:59.971613
# Unit test for constructor of class NotFound
def test_NotFound():
    """
    Test case for NotFound
    """
    try:
        raise NotFound("Test")
    except Exception as error:
        assert error.message == "Test"
        assert error.status_code == 404
        assert error.__class__.__name__ == "NotFound"


# Generated at 2022-06-21 22:42:01.852887
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("test.py")


# Generated at 2022-06-21 22:42:03.759954
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        e = Forbidden(message='test forbid message')
        assert e.message == 'test forbid message'
    except Exception as e:
        assert False

# Generated at 2022-06-21 22:42:07.717948
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message="test", content_range="test")
    except ContentRangeError as err:
        assert err.headers == {"Content-Range": "bytes */test"}

# Generated at 2022-06-21 22:42:08.884918
# Unit test for function abort
def test_abort():
    """
    Test abort function
    """
    try:
        abort(404)
    except NotFound:
        pass

# Generated at 2022-06-21 22:42:12.439290
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message='This is a message.',
                             status_code=400)
    except HeaderNotFound as err:
        assert err.message == 'This is a message.'
        assert err.status_code == 400


# Generated at 2022-06-21 22:42:17.130027
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Confirm that the constructor of class Forbidden works properly
    try:
        raise Forbidden("Forbidden")
    except Forbidden as err:
        # Get the expected output
        expected = {"status": "no", "message": "Forbidden"}
        assert str(err) == str(expected)

# Generated at 2022-06-21 22:42:19.204632
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    e = InvalidUsage("InvalidUsage Test")
    assert e.status_code == 400


# Generated at 2022-06-21 22:42:22.372515
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test_mulitiple_cons_obj = PayloadTooLarge('This is my test', status_code=413, quiet=True)


# Generated at 2022-06-21 22:42:24.805803
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    if not isinstance(LoadFileException("could not load config file"), Exception):
        raise AssertionError("LoadFileException is not derived from Exception")

# Generated at 2022-06-21 22:42:26.465353
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exc = Forbidden()
    assert exc.args[0] == ''
    assert exc.status_code == 403
    assert exc.args[0] == exc.message


# Generated at 2022-06-21 22:42:31.458432
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    r = Range(0, 100, 10)
    e = InvalidRangeType(message="a" + str(r.total), content_range=r)
    assert e.headers["Content-Range"] == "bytes */" + str(r.total)

# Generated at 2022-06-21 22:42:33.530620
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("test")
    assert error.__str__() == "test"

# Generated at 2022-06-21 22:42:34.553388
# Unit test for constructor of class NotFound
def test_NotFound():
    nf = NotFound('TestNotFound')
    assert nf.status_code == 404


# Generated at 2022-06-21 22:42:35.992681
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError('message')
    assert "message" == error.message

# Generated at 2022-06-21 22:42:40.049180
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    """
    Test :class:`ServiceUnavailable`

    :return: Successfully create the class if no exception was raised.
    """
    ServiceUnavailable("Service unavailable.")

# Generated at 2022-06-21 22:42:44.270776
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    x = InvalidSignal("This is a test for 'InvalidSignal' class.")
    assert x.message == "This is a test for 'InvalidSignal' class."

# Generated at 2022-06-21 22:42:45.900100
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(SystemExit):
        PyFileError("test.py")


# Generated at 2022-06-21 22:42:50.076722
# Unit test for function abort
def test_abort():
    try:
        abort(410)
    except SanicException as e:
        assert e.status_code == 410
        assert str(e) == "Gone"
    abort(404, message="File not found")
    try:
        abort(404, message="File not found")
    except NotFound as e:
        assert e.status_code == 404
        assert str(e) == "File not found"

# Generated at 2022-06-21 22:42:53.503715
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound(): 
    try:
        raise HeaderNotFound(message="HeaderNotFound")
    except HeaderNotFound as ex:
        assert ex.status_code == 400
        assert str(ex) == "HeaderNotFound"

# Generated at 2022-06-21 22:42:55.377682
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout('TIMEOUT', 408)
    assert rt.status_code == 408


# Generated at 2022-06-21 22:42:59.485638
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("Invalid usage!", status_code=400)
    except InvalidUsage as ex:
        assert ex.status_code == 400
        assert str(ex) == "Invalid usage!"

# Generated at 2022-06-21 22:43:01.818086
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Bad signal")
    except InvalidSignal as e:
        assert e.args == ("Bad signal",)

# Generated at 2022-06-21 22:43:08.431315
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    '''
    This method is for testing the constructor for the InvalidUsage exception
    '''
    # Test with status code 400
    try:
        raise InvalidUsage('Bad Request', status_code=400)
    except InvalidUsage as e:
        assert str(e) == 'Bad Request'
        assert e.status_code == 400

    # Test with status code 200
    try:
        raise InvalidUsage('OK', status_code=200)
    except InvalidUsage as e:
        assert str(e) == 'OK'
        assert e.status_code == 200

# Generated at 2022-06-21 22:43:11.999973
# Unit test for constructor of class Forbidden
def test_Forbidden():
    local_test_Forbidden = Forbidden("a test message")
    assert local_test_Forbidden.message == "a test message"
    assert local_test_Forbidden.status_code == 403


# Generated at 2022-06-21 22:43:15.466458
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        my_exception=InvalidRangeType("InvalidRangeType","content_range")
    except Exception:
        print("Exception raised")


# Generated at 2022-06-21 22:43:20.965583
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    hnf = HeaderNotFound("message")
    assert(hnf.status_code == 400)
    assert(hnf.message == "message")

    hnf = HeaderNotFound("message", status_code = 500)
    assert(hnf.status_code == 500)
    assert(hnf.message == "message")

# Generated at 2022-06-21 22:43:22.013189
# Unit test for constructor of class Forbidden
def test_Forbidden():
    pass


# Generated at 2022-06-21 22:43:23.775888
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError, match="could not execute config file"):
        raise PyFileError("test")

# Generated at 2022-06-21 22:43:26.883136
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    a = LoadFileException("Test")
    assert(a.message == "Test")


# Generated at 2022-06-21 22:43:28.953664
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage("Test").status_code == 400
    assert InvalidUsage("Test", status_code=401).status_code == 401


# Generated at 2022-06-21 22:43:36.483866
# Unit test for constructor of class URLBuildError
def test_URLBuildError():

    # Test case 1: Verify that value of object p1 (which has been passed to constructor of class URLBuildError) is equal to the value of object p1 (which has been returned by constructor of class URLBuildError)
    p1 = "A"
    a = URLBuildError(p1)
    assert a.__init__(p1) == a.__init__(p1)

    # Test case 2: Verify that value of object p2 (which has been passed to constructor of class URLBuildError) is not equal to the value of object p3 (which has been passed to constructor of class URLBuildError)
    p2 = "B"
    p3 = "C"
    a = URLBuildError(p2)
    assert a.__init__(p2) != a.__init__(p3)

    # Test case 3: Verify that value of

# Generated at 2022-06-21 22:43:44.437351
# Unit test for constructor of class Forbidden
def test_Forbidden():
    name = "Forbidden"
    status_code = 403
    message = "You are forbidden from accessing the requested resource."
    forbidden = Forbidden(message, status_code)
    assert forbidden.status_code == status_code, "Status code is incorrect"
    assert forbidden.message == message, "Message is incorrect"
    assert forbidden.__class__.__name__ == name, "Object has wrong type"
    print("Successfully finished '{}' class constructor test".format(name))

if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-21 22:43:45.824640
# Unit test for constructor of class NotFound
def test_NotFound():
    notfound = NotFound('404')
    assert notfound.args[0] == '404'
    assert notfound.status_code == 404


# Generated at 2022-06-21 22:43:48.913415
# Unit test for constructor of class ServerError
def test_ServerError():
    # ServerError has no additional arguments
    with pytest.raises(TypeError):
        ServerError('test', 400)

    server_error = ServerError('test')
    assert server_error.message == 'test'



# Generated at 2022-06-21 22:43:52.223387
# Unit test for constructor of class Forbidden
def test_Forbidden():
    for st in [400, 404, 500, 503]:
        try:
            abort(st)
        except SanicException as e:
            assert e.status_code == st
            assert e.quiet == False

# Generated at 2022-06-21 22:44:02.282072
# Unit test for function abort
def test_abort():
    try:
        abort(404, "File Not Found")
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == "File Not Found"
    else:
        raise AssertionError("Expecting NotFound exception")

    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad Request"
    else:
        raise AssertionError("Expecting InvalidUsage exception")

    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == "Internal Server Error"
    else:
        raise AssertionError("Expecting ServerError exception")


# Generated at 2022-06-21 22:44:04.463761
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert isinstance(Forbidden(), Exception)
    assert Forbidden().status_code == 403
    assert Forbidden("This is a test").status_code == 403


# Generated at 2022-06-21 22:44:08.033905
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge('Test message')
    assert error.status_code == 413
    assert error.message == 'Test message'

# Generated at 2022-06-21 22:44:13.201451
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(201)
    class CustomException(SanicException):
        pass

    assert _sanic_exceptions[201] == CustomException

# Generated at 2022-06-21 22:44:16.363898
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        abort(503)
    except ServiceUnavailable as err:
        assert err.status_code == 503
        assert err.message == "Service Unavailable"
        assert err.quiet == True

# Generated at 2022-06-21 22:44:19.121099
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    err = PayloadTooLarge('test exception')
    assert "test exception" == err.args[0]
    assert "413 Payload Too Large" == err.__str__()


# Generated at 2022-06-21 22:44:21.570275
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError):
        raise URLBuildError(url="test_url", status="test_status")


# Generated at 2022-06-21 22:44:23.542845
# Unit test for constructor of class NotFound
def test_NotFound():
    e = NotFound("test Not Found")
    assert e.status_code == 404
    assert str(e) == "test Not Found"


# Generated at 2022-06-21 22:44:26.316676
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed()
    except HeaderExpectationFailed as err:
        print(err.status_code)
        assert err.status_code == 417, "Expect status_code to be 417"


# Generated at 2022-06-21 22:44:31.380514
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    e = Unauthorized("test message", scheme="Basic", realm="Restricted Area")
    assert e.status_code == 401
    assert e.message == "test message"
    assert e.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'



# Generated at 2022-06-21 22:44:34.839804
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError('message', 666)
    assert cr.headers == {'Content-Range': 'bytes */666'}
    assert cr.status_code == 416



# Generated at 2022-06-21 22:44:38.169240
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418)
    class TestException(SanicException):
        pass

    assert TestException.status_code == 418
    assert TestException().status_code == 418


# Generated at 2022-06-21 22:44:45.164748
# Unit test for constructor of class SanicException
def test_SanicException():
    se = SanicException("test message",status_code = "404")
    assert se.status_code == 404
    se = SanicException("test message",status_code = "444")
    assert se.status_code == 444
    se = SanicException("test message",status_code = "500")
    assert se.status_code == 500
    se = SanicException("test message",status_code = "400")
    assert se.status_code == 400


if __name__ == "__main__":
    test_SanicException()

# Generated at 2022-06-21 22:44:54.026617
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        exc = InvalidRangeType("test", None)
    except Exception as e:
        assert False, "Exception is raised"
    assert exc.message == "test"
    assert exc.content_range is None
    assert exc.status_code == 416


# Generated at 2022-06-21 22:44:54.811467
# Unit test for constructor of class PyFileError
def test_PyFileError():
    PyFileError('hello')


# Generated at 2022-06-21 22:44:59.086844
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Bearer")
    except Unauthorized as err:
        assert err.status_code == 401
        assert err.message == "Auth required."
        assert err.headers == {"WWW-Authenticate": "Bearer"}

# Generated at 2022-06-21 22:45:10.412814
# Unit test for constructor of class SanicException
def test_SanicException():
    # Denormal case: status_code is None and quiet is None
    e1 = SanicException("abc", None, None)
    assert e1.args==('abc',)
    assert e1.message=='abc'
    assert e1.status_code==None
    assert e1.quiet==None

    # Normal case: status_code is not None and quiet is None
    e1 = SanicException("abc", status_code=200, quiet=None)
    assert e1.args==('abc',)
    assert e1.message=='abc'
    assert e1.status_code==200
    assert e1.quiet==True

    # Denormal case: status_code is not None and quiet is False
    e1 = SanicException("abc", status_code=500, quiet=False)

# Generated at 2022-06-21 22:45:14.185989
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    msg = "this is a test of class InvalidSignal"
    try:
        raise InvalidSignal(message=msg, status_code=101)
    except InvalidSignal as e:
        assert e.message == msg
        assert e.status_code == 101



# Generated at 2022-06-21 22:45:15.416515
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        LoadFileException()

# Generated at 2022-06-21 22:45:18.035938
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable):
        raise ServiceUnavailable('service unavailable')

# Generated at 2022-06-21 22:45:22.064809
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    result = HeaderExpectationFailed("test")
    assert "test" == result.args[0]
    assert 417 == result.status_code
    # test the correct initialization
    assert isinstance(result, SanicException)

# Generated at 2022-06-21 22:45:23.638414
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    assert Unauthorized("Unauthorized", scheme="Basic", realm="Restricted Area")

# Generated at 2022-06-21 22:45:25.154664
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('test service unavailable')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.message == 'test service unavailable'


# Generated at 2022-06-21 22:45:37.835036
# Unit test for constructor of class PyFileError
def test_PyFileError():
    a=PyFileError("test")
    b=PyFileError("test")
    assert a==b

# Generated at 2022-06-21 22:45:40.068948
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", realm="Restricted Area", scheme="Basic")
    except Exception as e:
        #print(e.headers)
        assert e.headers == {
            'WWW-Authenticate': 'Basic realm="Restricted Area"'
        }

# Generated at 2022-06-21 22:45:43.572615
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("some_message")
    assert(err.status_code == 500)


# Generated at 2022-06-21 22:45:46.275168
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message", "path", "relative_url")
    except Exception as e:
        assert e.path == "path"
        assert e.relative_url == "relative_url"

# Generated at 2022-06-21 22:45:49.666744
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    instance = MethodNotSupported(method='test_method', allowed_methods=['test_method'])
    assert instance.status_code == 405
    assert instance.headers['Allow'] == 'test_method'
    assert instance.quiet == True


# Generated at 2022-06-21 22:46:00.533898
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Exception as e:
        assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
        assert e.status_code == 401

# Generated at 2022-06-21 22:46:08.116264
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    # Given
    param = 'message'
    param1 = 'status_code'
    param2 = 'param2'

    assert param
    assert param1 is not None
    assert param2

    assert isinstance(param, str)
    assert isinstance(param1, str)
    assert not isinstance(param2, str)

    assert param == param
    assert param1 is not param
    assert param2 != param

    assert param != param1
    assert param1 != param2
    assert param != param2

    # When
    invalidUsageException = InvalidUsage(param, param1, param2)

    # Than
    assert invalidUsageException.message
    assert invalidUsageException.status_code is not None
    assert invalidUsageException.param2


# Generated at 2022-06-21 22:46:10.111111
# Unit test for constructor of class PyFileError
def test_PyFileError():
    test = PyFileError("test")
    assert test.args[0] == "could not execute config file test"

# Generated at 2022-06-21 22:46:12.962249
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage()
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "Bad request"

# Generated at 2022-06-21 22:46:15.774541
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed('Expectation failed', "this is wrong")
    assert exc.status_code == 417
    assert exc.message == 'Expectation failed'

# Generated at 2022-06-21 22:46:43.475379
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    tmp = RequestTimeout("message", "RequestTimeout")
    if tmp.__str__().find("RequestTimeout") >= 0:
        assert tmp


# Generated at 2022-06-21 22:46:45.920341
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test error message")
    except LoadFileException as e:
        assert e.message == "test error message"
        assert e.status_code == 500


# Generated at 2022-06-21 22:46:47.693094
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError(message='this is a test')
    assert url_build_error.status_code == 500

# Generated at 2022-06-21 22:46:54.779838
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized('an exception')
    except Unauthorized as ex:
        assert ex.message == 'an exception'
        assert ex.status_code == 401
        assert not hasattr(ex, 'headers')

    try:
        raise Unauthorized('an exception', scheme='Basic', realm='Restricted Area')
    except Unauthorized as ex:
        assert ex.message == 'an exception'
        assert ex.status_code == 401
        assert 'WWW-Authenticate' in ex.headers
        assert ex.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'


# Generated at 2022-06-21 22:46:56.281854
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    a = URLBuildError("asdf")
    assert a.status_code == 500


# Generated at 2022-06-21 22:47:07.241637
# Unit test for function add_status_code
def test_add_status_code():
    with pytest.raises(Exception) as e:
        @add_status_code(1000)
        class MyException(SanicException):
            pass
    assert e.type is TypeError
    assert e.value.args == ("The status code must be within the range of 400-599",)

    @add_status_code(401)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[401] == MyException

    @add_status_code(500)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[500] == MyException

    @add_status_code(400)
    class MyException(SanicException):
        pass
    assert _sanic_exceptions[400] == MyException

# Generated at 2022-06-21 22:47:08.943825
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pfe = PyFileError("test.txt")
    assert str(pfe) == "could not execute config file test.txt"


# Generated at 2022-06-21 22:47:11.946622
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "Expectation Failed"
    try:
        raise HeaderExpectationFailed(message)
    except HeaderExpectationFailed as err:
        assert type(err) is HeaderExpectationFailed
        assert message in err.args

# Generated at 2022-06-21 22:47:17.738426
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    """
    This test is to verify that the parameter message, content_range
    (which is of type ContentRanges) is put in the variable of the respected
    classes
    """
    test_message = "message"
    test_content_range = ContentRanges(0, 100, 200)
    test_range = ContentRangeError(
        message=test_message, content_range=test_content_range
    )
    assert test_range.message == test_message
    assert test_range.content_range == test_content_range

# Generated at 2022-06-21 22:47:19.485413
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = ContentRange(100,100)
    exception = ContentRangeError("My Error",content_range)
    assert exception.headers == {"Content-Range": "bytes */100"}

# Generated at 2022-06-21 22:48:18.143736
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
        raise Unauthorized("Auth required.",
                           scheme="Digest",
                           realm="Restricted Area",
                           qop="auth, auth-int",
                           algorithm="MD5",
                           nonce="abcdef",
                           opaque="zyxwvu")
        raise Unauthorized("Auth required.", scheme="Bearer")
        raise Unauthorized("Auth required.",
                           scheme="Bearer",
                           realm="Restricted Area")
    except:
        return
    assert False, "expected an exception"

# Generated at 2022-06-21 22:48:24.722232
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test")
    except ServerError as err:
        assert(err.message == "Test")
        assert(err.status_code == 500)
        assert(err.quiet == False)
    
    try:
        raise ServerError("Test", status_code=200, quiet=False)
    except ServerError as err:
        assert(err.message == "Test")
        assert(err.status_code == 200)
        assert(err.quiet == False)

    try:
        raise SanicException("Test", status_code=200, quiet=True)
    except ServerError as err:
        assert(err.message == "Test")
        assert(err.status_code == 200)
        assert(err.quiet == True)

# Generated at 2022-06-21 22:48:26.496702
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    x = InvalidUsage(message="bad request")
    assert x.status_code == 400



# Generated at 2022-06-21 22:48:28.154922
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message="Test for HeaderNotFound")
    except HeaderNotFound as err:
        pass

# Generated at 2022-06-21 22:48:31.588450
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('error.py')
    except Exception as e:
        assert e.args[0] == 'could not execute config file %s'
        assert e.args[1] == 'error.py'

# Generated at 2022-06-21 22:48:34.952020
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    header_not_found, header_not_found_message = HeaderNotFound('Header is not found'), 'Header is not found'
    assert header_not_found.message == header_not_found_message


# Generated at 2022-06-21 22:48:40.050402
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Set the parameters
    message = "test"
    content_range = 1
    test = InvalidRangeType(message, content_range)
    assert test.message == message
    assert test.headers["Content-Range"] == f"bytes */{content_range.total}"
    assert test.status_code == 416
    assert test.quiet == True


# Generated at 2022-06-21 22:48:42.345076
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge("message", 413)
    assert exception.__dict__ == {'args': ('message',), 'status_code': 413}

# Generated at 2022-06-21 22:48:45.508072
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = 'none'
    exception = ContentRangeError('none', content_range)
    assert exception.headers['Content-Range'] == f'bytes */{content_range}'

# Generated at 2022-06-21 22:48:47.297491
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage(_sanic_exceptions.get(400))
    except InvalidUsage:
        return True
    else:
        return False