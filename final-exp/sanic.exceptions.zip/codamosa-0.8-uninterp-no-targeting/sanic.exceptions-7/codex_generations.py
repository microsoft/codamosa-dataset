

# Generated at 2022-06-21 22:40:04.313863
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr_error = ContentRangeError(message="Error Message", content_range=100)
    assert cr_error.headers == {"Content-Range": "bytes */100"}
    assert cr_error.message == "Error Message"
    assert cr_error.status_code == 416

# Generated at 2022-06-21 22:40:07.884282
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable()
    except  ServiceUnavailable as e:
        assert e.__str__() == '503 Service Unavailable'
        assert str(e) == '503 Service Unavailable'


# Generated at 2022-06-21 22:40:12.210626
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("error",1)
    except InvalidRangeType:
        assert True
        print("test_InvalidRangeType is passed")
    finally:
        print("test_InvalidRangeType reaches the end of the method")

# Generated at 2022-06-21 22:40:14.637727
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("ERROR", 'var')
    except InvalidRangeType as err:
        assert 'var' in err.headers['Content-Range']

# Generated at 2022-06-21 22:40:18.990231
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        import requests
    except:
        assert True
    else:
        url = "https://www.google.com"
        try:
            r = requests.get(url)
        except Exception as e:
            raise URLBuildError("Error in requests.get(url)")

# Generated at 2022-06-21 22:40:24.642790
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('payload too large')
    except Exception as e:
        assert e.status_code == 413
    try:
        raise PayloadTooLarge('payload too large', quiet=True)
    except Exception as e:
        assert e.status_code == 413
        assert e.quiet == True

# Generated at 2022-06-21 22:40:34.412121
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert str(e) == "Not Found"
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert str(e) == "Bad Request"
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert str(e) == "Internal Server Error"
    try:
        abort(503)
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert str(e) == "Service Unavailable"
    try:
        abort(408)
    except RequestTimeout as e:
        assert e.status_code == 408

# Generated at 2022-06-21 22:40:38.763789
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as message:
        abort(401, "This is a test message")
    assert "This is a test message" in str(message.value)



# Generated at 2022-06-21 22:40:46.946550
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as err:
        assert err.message == "Internal Server Error"
        assert err.status_code == 500
    else:
        assert False, "Should have thrown ServerError exception."

    try:
        abort(404)
    except NotFound as err:
        assert err.message == "Not Found"
        assert err.status_code == 404
    else:
        assert False, "Should have thrown NotFound exception."

    try:
        abort(404, "Not found.")
    except NotFound as err:
        assert err.message == "Not found."
        assert err.status_code == 404
    else:
        assert False, "Should have thrown NotFound exception."

# Generated at 2022-06-21 22:40:50.907909
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class test_exception(Exception):
        pass
    assert issubclass(_sanic_exceptions[404], test_exception)

# Generated at 2022-06-21 22:40:56.825474
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('Payload Too Large', status_code=413)
    except PayloadTooLarge as err:
        assert err.message == 'Payload Too Large'
        assert err.status_code == 413


# Generated at 2022-06-21 22:40:59.779257
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported(message="test", method="test", allowed_methods=["test"])
    assert exception.headers["Allow"] == "test"
    assert exception.message == "test"



# Generated at 2022-06-21 22:41:05.164698
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('Some message', status_code=503)
    except SanicException as err:
        assert err.status_code == 503
        # TODO: assert err.request.path == '/some/path'
        # TODO: assert err.request.args == {}
        # TODO: assert err.headers['Content-Type'] == 'text/plain'
        assert err.body == 'Some message'
        # TODO: assert str(err) == 'SanicException: Some message'


# Generated at 2022-06-21 22:41:06.955203
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal()
    except InvalidSignal:
        return True
    return False



# Generated at 2022-06-21 22:41:10.400050
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message='test', content_range=1)
    except InvalidRangeType as e:
        assert e.message=='test'

# Generated at 2022-06-21 22:41:14.986293
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("This is an error message")
    except SanicException as e:
        assert e.message == "This is an error message"
        assert e.status_code == 400
        assert e.quiet == True


# Generated at 2022-06-21 22:41:16.172170
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError):
        exc = ContentRangeError('content-range is out of range', 100)


# Generated at 2022-06-21 22:41:21.249318
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "Test HeaderExpectationFailed"
    status_code = 417
    quiet = False
    header_exception = HeaderExpectationFailed(message, status_code, quiet)
    assert header_exception.message == message
    assert header_exception.status_code == status_code
    assert header_exception.quiet == quiet

# Generated at 2022-06-21 22:41:25.107123
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("100", 100)
    except InvalidSignal as err:
        assert err.args == ("100", 100)
        assert err.message == "100"
        assert err.status_code == 100

# Generated at 2022-06-21 22:41:28.361029
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        filename = 'no_file'
        raise LoadFileException(filename)
    except LoadFileException as e:
        assert e.args[0] == 'Could not load file (no_file)'

# Generated at 2022-06-21 22:41:33.711977
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert ServiceUnavailable("test", 503).status_code==503
    return True


# Generated at 2022-06-21 22:41:37.096532
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("HeaderExpectationFailed")
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == "HeaderExpectationFailed"
        assert e.__str__() == "HeaderExpectationFailed"


# Generated at 2022-06-21 22:41:40.425909
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage('Error: Base url not found')
    assert error.message == 'Error: Base url not found'
    assert error.status_code == 400
    assert error.quiet == True


# Generated at 2022-06-21 22:41:43.032660
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError('test_message')
    assert url_build_error.message == 'test_message'


# Generated at 2022-06-21 22:41:45.345065
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    assert URLBuildError('asdfg').__repr__() == 'asdfg'


# Generated at 2022-06-21 22:41:46.409883
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound('Header is not found')
    assert exception.status_code == 400

# Generated at 2022-06-21 22:41:55.033819
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    unauthorized = Unauthorized("Auth required.")
    assert unauthorized.message == "Auth required."
    assert unauthorized.status_code == 401

    unauthorized = Unauthorized("Auth required.", scheme="Basic")
    assert unauthorized.headers['WWW-Authenticate'] == 'Basic'

    unauthorized = Unauthorized("Auth required.", scheme="Basic", realm="Realm")
    assert unauthorized.headers['WWW-Authenticate'] == 'Basic realm="Realm"'

    unauthorized = Unauthorized("Auth required.", scheme="Digest", realm="Realm", qop="auth", algorithm="MD5")
    assert unauthorized.headers['WWW-Authenticate'] == 'Digest realm="Realm", qop="auth", algorithm="MD5"'

# Generated at 2022-06-21 22:41:56.913970
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(444)
    class TestException(SanicException):
        pass

    assert _sanic_exceptions[444] == TestException



# Generated at 2022-06-21 22:41:58.346208
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    with pytest.raises(MethodNotSupported):
        raise MethodNotSupported("bhargav", "GET", ["GET"])

# Generated at 2022-06-21 22:42:01.703098
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as excinfo:
        raise PyFileError('test_PyFileError')
    assert 'test_PyFileError' in str(excinfo.value)

# Generated at 2022-06-21 22:42:09.048274
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid_usage = InvalidUsage("error", 400)
    assert invalid_usage.status_code == 400
    assert invalid_usage.message == "error"

# Generated at 2022-06-21 22:42:17.881889
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    current_class = "HeaderExpectationFailed"
    expected_status = 417
    try:
        raise HeaderExpectationFailed(message="Expectation Failed")
    except HeaderExpectationFailed as e:
        assert type(e).__name__ == current_class
        assert e.status_code == expected_status
        assert str(e) == "Expectation Failed"


# Generated at 2022-06-21 22:42:23.436367
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = "The requested range is not satisfiable."
    content_range = range(10)
    ex = ContentRangeError(msg, content_range)
    assert str(ex) == msg
    assert ex.status_code == 416
    assert ex.headers == {"Content-Range": "bytes */10"}

# Generated at 2022-06-21 22:42:26.228552
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    with pytest.raises(HeaderExpectationFailed):
        raise HeaderExpectationFailed(message="message", status_code=417)


# Generated at 2022-06-21 22:42:38.360468
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == "Basic realm=\"Restricted Area\""

    try:
        raise Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    except Unauthorized as e:
        assert e.status_code == 401
        assert e.headers["WWW-Authenticate"] == 'Digest realm="Restricted Area", nonce="abcdef", opaque="zyxwvu", algorithm="MD5", qop="auth, auth-int"'


# Generated at 2022-06-21 22:42:41.273831
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404



# Generated at 2022-06-21 22:42:45.481551
# Unit test for function add_status_code
def test_add_status_code():
    """ """
    @add_status_code(201)
    class TestException(SanicException):
        pass
    e = TestException("test message", quiet=False)
    assert e.status_code == 201
    assert e.quiet is False

# Generated at 2022-06-21 22:42:49.130146
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    
    header_not_found = HeaderNotFound("HTTP header not found", "Content-Type", "*/*")
    assert header_not_found.message == "HTTP header not found"
    assert header_not_found.status_code == 400
    assert header_not_found.__class__.__name__ == 'HeaderNotFound'


# Generated at 2022-06-21 22:42:50.024634
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
	exc = InvalidUsage("test")
	assert exc.message == "test"
	assert exc.status_code == 400


# Generated at 2022-06-21 22:42:53.196472
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    range_type = InvalidRangeType("Range Type Test", 10)
    message = range_type.args[0]
    headers = range_type.headers
    assert message == "Range Type Test"
    assert headers["Content-Range"] == "bytes */10"

# Generated at 2022-06-21 22:43:08.394930
# Unit test for function abort
def test_abort():
    # test for known status codes
    for status_code in STATUS_CODES:
        try:
            abort(status_code)
        except SanicException as e:
            assert e.status_code == status_code
        else:
            assert False, "SanicException not raised"

    # test for status_code not in STATUS_CODES
    try:
        abort(599)
    except SanicException as e:
        assert e.status_code == 599
    else:
        assert False, "SanicException not raised"



# Generated at 2022-06-21 22:43:13.230226
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Test HeaderExpectationFailed")
    except HeaderExpectationFailed as err:
        assert err.status_code == 417
        assert err.args == ('Test HeaderExpectationFailed',)


# Generated at 2022-06-21 22:43:15.089000
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    class1 = LoadFileException("A","B","C")
    pass

# Generated at 2022-06-21 22:43:17.920411
# Unit test for constructor of class ServerError
def test_ServerError():
    a = ServerError("a")
    b = ServerError("b",400)
    assert str(a) == "a"
    assert str(b) == "b"

# Generated at 2022-06-21 22:43:19.883951
# Unit test for constructor of class SanicException
def test_SanicException():
    s = SanicException("Hello")
    assert s.message == "Hello"


# Generated at 2022-06-21 22:43:30.908250
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Test no args given
    exception = HeaderExpectationFailed()
    assert exception.message == 'Exception: None'
    assert exception.status_code == 417
    assert exception.quiet == True
    # Test only status code given
    exception = HeaderExpectationFailed(status_code=200)
    assert exception.message == 'Exception: None'
    assert exception.status_code == 200
    assert exception.quiet == False
    # Test only message given
    exception = HeaderExpectationFailed(message='test')
    assert exception.message == 'Exception: test'
    assert exception.status_code == 417
    assert exception.quiet == True
    # Test both args given
    exception = HeaderExpectationFailed(message='test', status_code=200)
    assert exception.message == 'Exception: test'

# Generated at 2022-06-21 22:43:34.592945
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "GET /search"
    method = "GET"
    allowed_methods = ["GET", "POST"]

    try:
        raise MethodNotSupported(message, method, allowed_methods)
    except MethodNotSupported as e:
        assert e.message == message
        assert e.headers == {"Allow": "GET, POST"}

# Generated at 2022-06-21 22:43:41.632915
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Test 1
    try:
        raise ContentRangeError("error.", "")
    except ContentRangeError as err:
        assert err.status_code == 416
        assert err.headers["Content-Range"] == "bytes */"
    # Test 1
    try:
        raise ContentRangeError("error.", "bytes 123-456/789")
    except ContentRangeError as err:
        assert err.status_code == 416
        assert err.headers["Content-Range"] == "bytes *"

# Generated at 2022-06-21 22:43:43.548905
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError('file')
    assert str(e) == "could not execute config file: file"

# Generated at 2022-06-21 22:43:49.772708
# Unit test for function abort
def test_abort():
    global _sanic_exceptions
    _sanic_exceptions = {400: InvalidUsage,
                         404: NotFound,
                         500: ServerError}
    abort(404)
    try:
        abort(408)
    except SanicException as e:
        assert e.status_code == 408
    try:
        abort(400, "This is an error")
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "This is an error"

# Generated at 2022-06-21 22:44:08.804400
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as excinfo:
        raise HeaderNotFound("message")
    assert excinfo.match("message")

# Generated at 2022-06-21 22:44:17.070088
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # Call constructor, passing in the message that we want to display
    header_not_found_object = HeaderNotFound("Content-type not found")
    # Assert that the message that we passed in matches the message that we get
    # out of the constructor
    assert (
        header_not_found_object.args[0] == "Content-type not found"
    )
    # Assert that this is a 400 Bad Request
    assert header_not_found_object.status_code == 400
    # Assert that we want to display this error to users
    assert header_not_found_object.quiet is False


# Generated at 2022-06-21 22:44:18.552393
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('LoadFileException','password')
    except Exception as error:
        print(error)

# Generated at 2022-06-21 22:44:22.872311
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Message"
    method = "method"
    allowed_methods = "allowed_methods"
    with pytest.raises(MethodNotSupported) as record:
        MethodNotSupported(message, method, allowed_methods)
    assert str(record.value) == "Message"


# Generated at 2022-06-21 22:44:25.052847
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        1/0
    except Exception as e:
        raise ServerError("test server error",status_code=500,quiet=True)


# Generated at 2022-06-21 22:44:30.416108
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """Test the Exception of class Unauthorized with the following parameters:

    message : string
    scheme : string
    realm : string
    qop : string
    algorithm : string
    nonce : string
    opaque : string
    """
    auth = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert auth.message == "Auth required."
    assert auth.headers["WWW-Authenticate"] == "Digest algorithm=MD5, nonce=abcdef, opaque=zyxwvu, qop=auth, auth-int, realm=Restricted Area"

# Generated at 2022-06-21 22:44:31.478846
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    _ = RequestTimeout("Test")

# Generated at 2022-06-21 22:44:32.844257
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Message")
    except HeaderNotFound as exception:
        assert exception.status_code == 400
        assert exception.message == "Message"


# Generated at 2022-06-21 22:44:38.253747
# Unit test for constructor of class ServerError
def test_ServerError():
    # Test with string parameter
    try:
        raise ServerError("Param")
    except ServerError as e:
        assert str(e) == "Param"
        assert e.status_code == 500
        assert e.args[0] == "Param"
        assert e.args[1] == 500
        assert isinstance(e.args, tuple)


# Generated at 2022-06-21 22:44:43.308496
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(418, quiet=False)
    class CoffeePot(SanicException):
        pass

    assert CoffeePot.status_code == 418
    assert CoffeePot.quiet is False

    @add_status_code(419)
    class TeaPot(SanicException):
        pass

    assert TeaPot.status_code == 419
    assert TeaPot.quiet is True

# Generated at 2022-06-21 22:45:18.210150
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    test = InvalidRangeType('test', None)
    assert (test.message == 'test')

# Generated at 2022-06-21 22:45:22.970213
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "header expectation failed"
    status_code = 417
    header_expectation_failed = HeaderExpectationFailed(message, status_code)
    assert header_expectation_failed.message == message
    assert header_expectation_failed.status_code == status_code

# Generated at 2022-06-21 22:45:25.709937
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized(message="test", status_code=401, realm="test")
    except Unauthorized as e:
        assert isinstance(e, SanicException)


# Generated at 2022-06-21 22:45:30.917134
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('URL Build Error')
    except ServerError as e:
        assert str(e) == 'URL Build Error'
        assert e.status_code == 500
        assert not e.quiet

        assert e.headers == {}

# Generated at 2022-06-21 22:45:34.371666
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("Request Timeout",408)
    except RequestTimeout as ex:
        assert ex.status_code == 408
        assert ex.__str__() == "Request Timeout"


# Generated at 2022-06-21 22:45:37.828043
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("test_message",status_code=999,quiet=True)
    except SanicException as e:
        assert e.message == "test_message"
        assert e.status_code == 999
        assert e.quiet == True


# Generated at 2022-06-21 22:45:39.603283
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge()
    except PayloadTooLarge as error:
        assert error.status_code == 413


# Generated at 2022-06-21 22:45:43.298014
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound('404 Error')
    except NotFound:
        assert True
    else:
        assert False 


# Generated at 2022-06-21 22:45:46.033706
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message = "Expectation Failed"
    exception = HeaderExpectationFailed(message)
    assert exception.message == message
    assert exception.status_code == 417
    assert exception.headers is None

# Generated at 2022-06-21 22:45:48.216473
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound):
        raise NotFound("test")


# Generated at 2022-06-21 22:47:01.140358
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError):
        raise PyFileError("wrong path")
    


# Generated at 2022-06-21 22:47:06.175429
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Invalid range", 100)
    except InvalidRangeType as e:
        assert e.status_code == 416
        assert e.args == ("Invalid range",)
        assert e.headers == {"Content-Range": "bytes */100"}

# Generated at 2022-06-21 22:47:08.296830
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    expected = "Test"
    except_object = ServiceUnavailable(expected)
    assert except_object.message == expected

# Generated at 2022-06-21 22:47:10.472922
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    e = LoadFileException("a","b")
    assert e.message == "a"
    assert e.name == "b"

# Generated at 2022-06-21 22:47:16.597655
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Test message"
    method = "method"
    allowed_methods = "allowed_methods"
    method_not_supported = MethodNotSupported(
        message=message, method=method, allowed_methods=allowed_methods)
    assert method_not_supported.message == message
    assert method_not_supported.method == method
    assert method_not_supported.allowed_methods == allowed_methods
    assert method_not_supported.headers == {"Allow": allowed_methods}



# Generated at 2022-06-21 22:47:18.340156
# Unit test for constructor of class PyFileError
def test_PyFileError():
    w = PyFileError('test.py')
    assert str(w) == 'could not execute config file test.py'

# Generated at 2022-06-21 22:47:29.284843
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    scheme = "Basic"
    realm = "Restricted Area"
    message = "Auth required."
    try:
        Unauthorized(message, scheme=scheme, realm=realm)
    except Unauthorized as err:
        assert err.headers == {
            "WWW-Authenticate": 'Basic realm="Restricted Area"'
        }

    scheme = "Digest"
    realm = "Restricted Area"
    qop = "auth,auth-int"
    algorithm = "MD5"
    nonce = "abcdef"
    opaque = "zyxwvu"

# Generated at 2022-06-21 22:47:31.473862
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(SanicException) as ee:
        raise InvalidSignal("Invalid signal")
    assert True

# Generated at 2022-06-21 22:47:35.216886
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_test = URLBuildError('test url', 'test path')
    assert url_test.args[0] == 'test url'
    assert url_test.args[1] == 'test path'
    assert url_test.path == 'test path'

# Generated at 2022-06-21 22:47:37.420496
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable):
        raise ServiceUnavailable("503 Service Unavailable")