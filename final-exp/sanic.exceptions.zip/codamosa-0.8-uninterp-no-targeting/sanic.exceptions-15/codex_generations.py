

# Generated at 2022-06-21 22:40:12.937942
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == STATUS_CODES[404].decode("utf8")
        assert e.__class__ == NotFound
    else:
        exit(1)

    try:
        abort(400, "test")
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == "test"
        assert e.__class__ == InvalidUsage
    else:
        exit(1)

# Generated at 2022-06-21 22:40:16.441442
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # PayloadTooLarge(message, status_code=None, quiet=None)
    assert issubclass(PayloadTooLarge, SanicException)

    with pytest.raises(TypeError):
        PayloadTooLarge()

    with pytest.raises(ValueError):
        PayloadTooLarge("")

    with pytest.raises(ValueError):
        PayloadTooLarge(" ")

    assert str(PayloadTooLarge("test"))



# Generated at 2022-06-21 22:40:19.503436
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("ServiceUnavailable", status_code=503)
    except ServiceUnavailable as e:
        assert e.message == "ServiceUnavailable"
        assert e.status_code == 503

# Generated at 2022-06-21 22:40:25.610097
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    code = 503
    srv_unavailable = ServiceUnavailable("Service Unavailable")
    assert srv_unavailable.status_code == code
    assert str(srv_unavailable) == "Service Unavailable"
    assert srv_unavailable.headers is None
    assert srv_unavailable.args[0] == "Service Unavailable"


# Generated at 2022-06-21 22:40:32.915509
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message='test_SanicException', status_code=404, quiet=True)
    except SanicException as err:
        assert err.message == 'test_SanicException'
        assert err.status_code == 404
        assert err.quiet == True
    try:
        raise SanicException(message='test_SanicException')
    except SanicException as err:
        assert err.message == 'test_SanicException'
        assert err.status_code == None
        assert err.quiet == None

# Generated at 2022-06-21 22:40:34.658285
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError('Payload Too Large.',1111)
    assert (cr.headers['Content-Range'] == 'bytes */1111')

# Generated at 2022-06-21 22:40:41.505377
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Given
    message = "Test message"
    path = "./data/test_file.txt"
    relative_url = "localhost:8000/index"

    # When
    f = FileNotFound(message=message, path=path, relative_url=relative_url)

    # Then
    assert f.args[0] == message
    assert f.path == path
    assert f.relative_url == relative_url

# Generated at 2022-06-21 22:40:44.189840
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    methodnotsupported = MethodNotSupported("message","method","allowed_methods")
    assert methodnotsupported.headers == {"Allow": ", ".join(["allowed_methods"])}

# Generated at 2022-06-21 22:40:47.117840
# Unit test for constructor of class Forbidden
def test_Forbidden():
    x = Forbidden("hello world")
    assert x.message == "hello world"
    assert x.status_code == 403
    assert x.__class__.__name__ == "Forbidden"
    
    

# Generated at 2022-06-21 22:40:51.408886
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyFileError = PyFileError("test_file")
    assert pyFileError.args[0] == "could not execute config file %s"
    assert pyFileError.args[1] == "test_file"

# Generated at 2022-06-21 22:41:03.854990
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # unit test for constructor of class HeaderExpectationFailed,
    # if message is correct or not
    with pytest.raises(Exception) as ex:
        raise HeaderExpectationFailed('test') # noqa
    assert 'test' not in str(ex.value)
    assert '417' in str(ex.value)

    # unit test for constructor of class HeaderExpectationFailed,
    # if status_code is correct or not
    with pytest.raises(Exception) as ex:
        raise HeaderExpectationFailed('test', status_code=500) # noqa
    assert 'test' not in str(ex.value)
    assert '500' in str(ex.value)

    # unit test for constructor of class HeaderExpectationFailed,
    # if quiet is correct or not

# Generated at 2022-06-21 22:41:06.296658
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    header_expection_failed = HeaderExpectationFailed(message='test')
    assert header_expection_failed.status_code == 417

# Generated at 2022-06-21 22:41:12.956437
# Unit test for function abort
def test_abort():
    status_code = 500
    try:
        abort(status_code)
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.status_code == status_code

    status_code = 404
    try:
        abort(status_code)
    except Exception as e:
        assert isinstance(e, NotFound)
        assert e.status_code == status_code



# Generated at 2022-06-21 22:41:16.925765
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge('message', 'status_code')
    assert payload_too_large.message == 'message'
    assert payload_too_large.status_code == 'status_code'

# Generated at 2022-06-21 22:41:18.739777
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    msg = "test"
    lfe = LoadFileException(msg)

    assert lfe.args == (msg,)

# Generated at 2022-06-21 22:41:21.694023
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    status_code = 408
    quiet = True
    message = "aaa"
    exception = RequestTimeout(message, status_code, quiet)
    assert str(exception) == "aaa"
    assert exception.status_code == 408
    assert exception.quiet == True

# Generated at 2022-06-21 22:41:28.998645
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException(message="Raise SanicException Message", quiet=True)
    except SanicException as e:
        assert e.message == "Raise SanicException Message"
        assert e.quiet == True
    # Test the default status code is 500
    try:
        raise SanicException(message="Raise SanicException Message")
    except SanicException as e:
        assert e.message == "Raise SanicException Message"
        assert e.status_code == 500


# Generated at 2022-06-21 22:41:33.348085
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    '''
    >>> try:
    ...     raise LoadFileException("LoadFileException", status_code=123)
    ... except Exception as e:
    ...     print(e.status_code)
    ...     print(e.args)
    ...     print(e)
    123
    ('LoadFileException',)
    LoadFileException
    '''


# Generated at 2022-06-21 22:41:35.342104
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr_exception = ContentRangeError(message="Content range not satisfiable", content_range=None)
    assert cr_exception.headers == {"Content-Range": "bytes */None"}

# Generated at 2022-06-21 22:41:38.811902
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    error = PayloadTooLarge("Too much data")
    assert error.status_code == 413
    assert "Too much data" in str(error)


# Generated at 2022-06-21 22:41:51.678649
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    exception = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert exception.status_code == 401
    assert exception.message == "Auth required."
    assert exception.headers == {"WWW-Authenticate": 'Basic realm="Restricted Area"'}

    exception = Unauthorized("Auth required.", scheme="Digest", realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu")
    assert exception.status_code == 401
    assert exception.message == "Auth required."
    assert exception.headers == {
        "WWW-Authenticate": 'Digest realm="Restricted Area", qop="auth, auth-int", algorithm="MD5", nonce="abcdef", opaque="zyxwvu"'
    }


# Generated at 2022-06-21 22:41:55.293427
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound("message", "path", "relative url")
    assert file_not_found.message == "message"
    assert file_not_found.path == "path"
    assert file_not_found.relative_url == "relative url"


# Generated at 2022-06-21 22:41:56.914117
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found")
    except HeaderNotFound as e:
        assert(e.message == "Header not found")

# Generated at 2022-06-21 22:41:58.642121
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('invalid signal name')
    except Exception as e :
        assert e.args[0]=='invalid signal name'

# Generated at 2022-06-21 22:42:01.597055
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    message = 'this is a test message'
    exception = URLBuildError(message=message)
    assert exception.message == message
    assert exception.status_code == 500



# Generated at 2022-06-21 22:42:02.880566
# Unit test for function abort
def test_abort():
    assert "aborted" in str(abort(401)).lower()



# Generated at 2022-06-21 22:42:07.443764
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # TODO: Add test for specific behavior for LoadFileException
    e = LoadFileException('Is a directory')
    assert e.message == 'Is a directory'
    assert e.status_code is None
    assert e.is_quiet is False

# Generated at 2022-06-21 22:42:09.224629
# Unit test for constructor of class NotFound
def test_NotFound():
    # Constructor of class NotFound
    NotFound("This is an incorrect url")

# Generated at 2022-06-21 22:42:13.969904
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    m = 'Method Not Supported.'
    method = 'POST'
    allowed_methods = ['GET', 'POST']
    e = MethodNotSupported(m, method, allowed_methods)
    # __init__ should set the attributes and then call superclass __init__
    assert e.message == m
    assert e.method == method
    assert e.headers == {'Allow': 'GET, POST'}

# Generated at 2022-06-21 22:42:16.673166
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError("config.py")
    assert str(pyfileerror) == "could not execute config file config.py"

# Generated at 2022-06-21 22:42:23.166981
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('hello world.')
    except URLBuildError as e:
        assert e.args[0] == 'hello world.'

# Generated at 2022-06-21 22:42:24.380854
# Unit test for constructor of class NotFound
def test_NotFound():
    with pytest.raises(NotFound, match="Not Found"):
        raise NotFound("Not Found")


# Generated at 2022-06-21 22:42:27.611763
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Bearer", realm="Restricted Area")
    except Unauthorized as e:
        print(e.headers)


if __name__ == '__main__':
    test_Unauthorized()

# Generated at 2022-06-21 22:42:30.908805
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    e = ContentRangeError("error", 10)
    assert str(e) == "error"
    assert e.status_code == 416
    assert e.quiet == True

# Generated at 2022-06-21 22:42:33.797023
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        Forbidden("this is an error message", status_code=403)
    except Forbidden as e:
        assert e.status_code == 403

# Generated at 2022-06-21 22:42:36.042341
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("load failed")
    except Exception as e:
        assert str(e) == 'load failed'

# Generated at 2022-06-21 22:42:40.102160
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try :
        raise LoadFileException("test_LoadFileException")
    except LoadFileException as e :
       assert e.status_code == None


# Generated at 2022-06-21 22:42:44.320884
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    expectedException = HeaderExpectationFailed("message")
    assert(expectedException.status_code == 417)
    assert(expectedException.quiet == True)


# Generated at 2022-06-21 22:42:47.591528
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("message", method="PUT", allowed_methods=["PUT", "POST"])
    except MethodNotSupported as e:
        assert e.headers["Allow"] == "PUT, POST"
        assert e.args[0] == "message"


# Generated at 2022-06-21 22:42:49.668361
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    object_InvalidSignal = InvalidSignal("Invalid signal number")
    assert object_InvalidSignal

# Generated at 2022-06-21 22:43:02.411906
# Unit test for constructor of class SanicException
def test_SanicException():
    error = SanicException('invalid usage', status_code=400)
    try:
        raise error
    except SanicException as e:
        assert e.message == 'invalid usage'
        assert e.status_code == 400
        assert e.quiet == True


# Generated at 2022-06-21 22:43:05.086249
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message='Header not found')
    except HeaderNotFound as err:
        assert err.message == 'Header not found'

# Generated at 2022-06-21 22:43:06.742577
# Unit test for constructor of class ServerError
def test_ServerError():
    message = "Server Error"
    exception = ServerError(message)
    assert exception.message == message


# Generated at 2022-06-21 22:43:09.184392
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('Test Forbidden')
    assert forbidden.message == 'Test Forbidden'


# Generated at 2022-06-21 22:43:18.646419
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    message = "File not exist."
    err = LoadFileException(message)
    assert err.message == message
    assert err.status_code is None
    assert str(err) == f"LoadFileException(message='File not exist.', status_code=None, quiet=False)"
    assert repr(err) == "LoadFileException(message='File not exist.', status_code=None, quiet=False)"

    message = "true"
    status_code = 500
    err = LoadFileException(message, status_code)
    assert err.message == message
    assert err.status_code == status_code



# Generated at 2022-06-21 22:43:29.920415
# Unit test for function add_status_code
def test_add_status_code():
    class test_class():
        pass

    test_class = add_status_code(100)(test_class)
    assert _sanic_exceptions.get(100) == test_class
    assert test_class.status_code == 100
    assert test_class.quiet == False
    del _sanic_exceptions[100]

    test_class = add_status_code(100, True)(test_class)
    assert _sanic_exceptions.get(100) == test_class
    assert test_class.status_code == 100
    assert test_class.quiet == True
    del _sanic_exceptions[100]

    test_class = add_status_code(500, True)(test_class)
    assert _sanic_exceptions.get(500) == test_class
    assert test_class.status_code

# Generated at 2022-06-21 22:43:31.924454
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    s = 'hello'
    with pytest.raises(URLBuildError, match=s):
        raise URLBuildError(s)


# Generated at 2022-06-21 22:43:33.698093
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException('test', status_code = 404)
    except SanicException as e:
        assert e.status_code == 404

# Generated at 2022-06-21 22:43:37.971135
# Unit test for function add_status_code
def test_add_status_code():
    # pylint: disable=missing-docstring
    class TestException(SanicException):
        pass
    new_exception = add_status_code(100)(TestException)
    assert new_exception.status_code == 100
    assert new_exception.quiet is False


# Generated at 2022-06-21 22:43:40.204622
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException.__init__ != Exception.__init__



# Generated at 2022-06-21 22:43:52.224032
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden(message="Url Not Found")
    except Forbidden as e:
        assert 'Url Not Found' in str(e)


# Generated at 2022-06-21 22:43:55.832196
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test_obj = MethodNotSupported("test message", "GET", ["POST","PUT"])

    assert test_obj.message == "test message"
    assert test_obj.headers == {"Allow": "POST, PUT"}

# Generated at 2022-06-21 22:43:58.015858
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error_test= URLBuildError("test")
    assert error_test.status_code == 500
    assert error_test.message == "test"

# Generated at 2022-06-21 22:44:00.971130
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as e:
        assert "Invalid Signal" == e.message
        assert 500 == e.status_code 
        assert False == e.quiet


# Generated at 2022-06-21 22:44:03.302132
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    unauthorized = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    print(unauthorized)
    print(unauthorized.headers)



# Generated at 2022-06-21 22:44:05.171820
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    ex = LoadFileException('', '', '', '')
    assert ex



# Generated at 2022-06-21 22:44:14.762991
# Unit test for function abort
def test_abort():
    # Given a status code
    for status_code in STATUS_CODES:
        # When
        try:
            abort(status_code)
        except SanicException as exc:
            # Then
            assert type(exc) is _sanic_exceptions.get(status_code, SanicException), \
                f"The wrong exception was raised for status code {status_code}"
            assert exc.status_code == status_code
            # Next
        else:
            assert False, "No exception was raised for status code {status_code}."
            # Next



# Generated at 2022-06-21 22:44:16.649994
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound:
        pass



# Generated at 2022-06-21 22:44:17.553237
# Unit test for function add_status_code
def test_add_status_code():
    assert InvalidUsage.status_code == 400

# Generated at 2022-06-21 22:44:19.043619
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType("", 0)
    assert exc.headers == {"Content-Range": "bytes */0"}

# Generated at 2022-06-21 22:44:39.874056
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("signal SIGINT")
    except InvalidSignal as e:
        assert e.status_code == 500
        assert e.message == "signal SIGINT"


# Generated at 2022-06-21 22:44:42.370600
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException("message")
    assert e.message == "message"


# Generated at 2022-06-21 22:44:45.019761
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    time_out = RequestTimeout(message="Service Timeout")
    assert time_out.status_code == 408
    assert time_out.message == "Service Timeout"


# Generated at 2022-06-21 22:44:48.268328
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    se = ServiceUnavailable("test", 503)
    assert se.status_code == 503
    assert se.message == "test"

# Generated at 2022-06-21 22:44:51.085419
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="", headers={"allow": "0"})
    except HeaderExpectationFailed as exc:
        assert exc.headers == {"allow": "0"}

# Generated at 2022-06-21 22:44:54.266756
# Unit test for constructor of class SanicException
def test_SanicException():
    exc = SanicException('message', status_code=500, quiet=False)
    assert exc.message == 'message'
    assert exc.status_code == 500
    assert exc.quiet == False


# Generated at 2022-06-21 22:44:56.152256
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('test_InvalidUsage')
    except InvalidUsage as e:
        assert e.message == 'test_InvalidUsage'


# Generated at 2022-06-21 22:44:58.428013
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Invalid Range",1)
    except InvalidRangeType as error:
        assert error.status_code == 416
        assert error.__str__() == "Invalid Range"
        assert error.headers['Content-Range'] == 'bytes */1'
    else:
        assert False

# Generated at 2022-06-21 22:45:01.046501
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    err = ServiceUnavailable("test message")
    assert err.message == "test message"
    assert err.status_code == 503
    assert err.quiet == True

# Generated at 2022-06-21 22:45:07.649235
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    """
    The PayloadTooLarge class should inherit the message and status_code from
    the SanicException class.

    :param message: The HTTP response body. Defaults to the messages in
                     STATUS_CODES from sanic.helpers for the given status code.
    :param status_code: The HTTP status code to return. Defaults to 500.
    """
    PayloadTooLarge('Test Message', status_code=413)

# Generated at 2022-06-21 22:45:51.292200
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    expected_message = "Service Unavailable"
    expected_status_code= 503
    expected_quiet= True
    try:
        raise ServiceUnavailable(expected_message)
    except ServiceUnavailable as exception:
        actual_message = exception.args[0]
        actual_status_code = exception.status_code
        actual_quiet = exception.quiet
        assert (expected_message == actual_message)
        assert (expected_status_code == actual_status_code)
        assert (expected_quiet == actual_quiet)


# Generated at 2022-06-21 22:45:53.569971
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal(message='INVALID', status_code = 500).message == 'INVALID'


# Generated at 2022-06-21 22:46:02.597991
# Unit test for function add_status_code
def test_add_status_code():
    exc = SanicException
    with_code = add_status_code(666)
    # assert with_code is the decorated SanicException
    assert with_code is SanicException
    # assert with_code is not SanicException
    assert SanicException is not SanicException
    # assert _sanic_exceptions[666] is SanicException
    assert _sanic_exceptions[666] is SanicException
    # assert except SanicException is a subclass of SanicException
    assert issubclass(SanicException, SanicException)
    # assert '666' in _sanic_exceptions
    assert '666' in _sanic_exceptions



# Generated at 2022-06-21 22:46:05.396466
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Normal case
    error = URLBuildError('a', 'b')
    assert error.args == ('a', 'b')

    # Abnormal case
    error = URLBuildError()
    assert error.args == (None, None)

# Generated at 2022-06-21 22:46:11.554696
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("sanic/response.py")
    assert str(error) == "could not execute config file sanic/response.py"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 22:46:17.084451
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():

    header_value = "Auth required."
    header_name = "WWW-Authenticate"
    header_value_msg = f"{header_name}: {header_value}"

    # Create a HeaderNotFound
    header_not_found = HeaderNotFound(header_value, header_name)

    # Check the correct message has been
    assert(header_not_found.message == header_value_msg)

# Generated at 2022-06-21 22:46:22.962624
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    crange = ContentRange(start=0, stop=0, total=0)
    message = "message"
    try:
        raise ContentRangeError(message, crange)
    except ContentRangeError as ex:
        assert ex.message == message
        assert ex.status_code == 416
        assert ex.headers == {"Content-Range": f"bytes */{crange.total}"}

# Generated at 2022-06-21 22:46:25.031214
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    url_build_error = URLBuildError("url error")
    assert url_build_error.args[0] == "url error"


# Generated at 2022-06-21 22:46:27.658573
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("A message", "DELETE", ["GET"])
    except MethodNotSupported as error:
        assert error.headers["Allow"] == "GET"
        assert error.status_code == 405

# Generated at 2022-06-21 22:46:29.157346
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("error", 111)
    assert error.headers['Content-Range'] == 'bytes */111'

# Generated at 2022-06-21 22:47:54.428888
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        print("Raising RequestTimeout")
        raise RequestTimeout("Time out")
    except RequestTimeout as t:
        print("Caught RequestTimeout")
        print("RequestTimeout.message = ", t.message)
        print("RequestTimeout.status_code = ", t.status_code)
        print("RequestTimeout.quiet = ", t.quiet)


# Generated at 2022-06-21 22:48:02.196243
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # Create an object of type PayloadTooLarge
    plt = PayloadTooLarge(message="Payload Too Large", status_code=413)

    # Check to see that the object is of type PayloadTooLarge
    assert isinstance(plt, PayloadTooLarge)

    # Check to see that the status_code is what we expect
    assert plt.status_code == 413

    # Check to see that the message is what we expect
    assert plt.message == "Payload Too Large"

    # Check to see that the quiet bool is true
    assert plt.quiet is True

    # Check to see that the PayloadTooLarge object is an exception
    assert issubclass(PayloadTooLarge, Exception)

    # Check to see that the PayloadTooLarge object is a SanicException

# Generated at 2022-06-21 22:48:06.180886
# Unit test for function add_status_code
def test_add_status_code():
    global _sanic_exceptions
    _sanic_exceptions = {}

    @add_status_code(200)
    class CustomException(SanicException):
        pass

    assert isinstance(CustomException.status_code, int)
    assert isinstance(_sanic_exceptions[200], CustomException)

# Generated at 2022-06-21 22:48:17.930089
# Unit test for constructor of class PyFileError

# Generated at 2022-06-21 22:48:21.703369
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("test msg", 520)
        assert False
    except ServiceUnavailable as e:
        assert e.status_code == 520
        assert e.message == "test msg"


# Generated at 2022-06-21 22:48:32.007562
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    Testing the constructor of class SanicException,
    """
    msg = "hello"
    try:
        raise SanicException(msg)
    except SanicException as exc:
        assert exc.message == msg
    try:
        raise SanicException(msg, 400)
    except SanicException as exc:
        assert exc.message == msg
        assert exc.status_code == 400
    try:
        raise SanicException(msg, 400, True)
    except SanicException as exc:
        assert exc.message == msg
        assert exc.status_code == 400
        assert exc.quiet == True
    try:
        raise SanicException(msg, 400, False)
    except SanicException as exc:
        assert exc.message == msg
        assert exc.status_code == 400
        assert exc.quiet == False

# Generated at 2022-06-21 22:48:35.040358
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    e = InvalidSignal("invalid Signal")
    assert e.args[0] == "invalid Signal"
    assert str(e) == "invalid Signal"


# Generated at 2022-06-21 22:48:45.862943
# Unit test for constructor of class SanicException
def test_SanicException():
    # https://github.com/huge-success/sanic/issues/1223
    class SanicException(Exception):
        def __init__(self, message, status_code=None, quiet=None):
            super().__init__(message)

            if status_code is not None:
                self.status_code = status_code

            # quiet=None/False/True with None meaning choose by status
            if quiet or quiet is None and status_code not in (None, 500):
                self.quiet = True


    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    assert NotFound('123', status_code=404).status_code == 404
    assert NotFound('123').status_code == 500
    assert NotFound('123', status_code=500).status_

# Generated at 2022-06-21 22:48:48.361507
# Unit test for constructor of class NotFound
def test_NotFound():
    err = NotFound(message="error")
    assert err.status_code == 404
    assert err.quiet == True
    assert err.message == "error"


# Generated at 2022-06-21 22:48:53.549513
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("message", "path", "relative_url")
    except FileNotFound as e:
        assert e.message == "message"
        assert e.path == "path"
        assert e.relative_url == "relative_url"