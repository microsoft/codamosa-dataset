

# Generated at 2022-06-21 22:40:07.172859
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    test_message = "Service Unavailable test"
    try:
        raise ServiceUnavailable(test_message)
    except Exception as e:
        assert e.message == test_message
        assert e.status_code == 503



# Generated at 2022-06-21 22:40:09.575249
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    lfe = LoadFileException("error")
    assert lfe.status_code == 500
    assert lfe.message == "error"

# Generated at 2022-06-21 22:40:16.617069
# Unit test for constructor of class SanicException
def test_SanicException():
    se_1 = SanicException("message")
    assert se_1.status_code == 500
    assert se_1.quiet == False

    se_2 = SanicException("message", status_code=404, quiet=True)
    assert se_2.status_code == 404
    assert se_2.quiet == True

    se_3 = SanicException("message", status_code=404, quiet=False)
    assert se_3.status_code == 404
    assert se_3.quiet == False

    se_4 = SanicException("message", status_code=404)
    assert se_4.status_code == 404
    assert se_4.quiet == True


# Generated at 2022-06-21 22:40:18.352747
# Unit test for constructor of class ServerError
def test_ServerError():
    assert ServerError

# Generated at 2022-06-21 22:40:21.925303
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('data.txt')
    except PyFileError as err:
        assert err.args[0] == "could not execute config file data.txt"

# Generated at 2022-06-21 22:40:26.141994
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == STATUS_CODES[400].decode("utf8")

# Generated at 2022-06-21 22:40:32.045462
# Unit test for constructor of class ServerError
def test_ServerError():
    e=ServerError("test test")
    assert e.message=="test test"
    assert str(e)=="test test"
    e=ServerError("test test 2", status_code=403, quiet=True)
    assert e.message=="test test 2"
    assert e.status_code==403
    assert e.quiet==True
    assert str(e)=="test test 2"

# Generated at 2022-06-21 22:40:34.745440
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("only post", 'get', ['post'])
    except MethodNotSupported as e:
        assert e.message == "only post"
        assert e.headers == {'Allow': 'post'}

# Generated at 2022-06-21 22:40:38.763180
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(Exception) as e1:
        raise InvalidSignal("Invalid")
    assert str(e1.type) == str(InvalidSignal)


# Generated at 2022-06-21 22:40:41.154555
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(message="Range Not Satisfiable", content_range=100)
    except ContentRangeError as exc:
        assert str(exc) == "Range Not Satisfiable"
        assert exc.status_code == 416

# Generated at 2022-06-21 22:40:46.538315
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    data_input = 'Hello World'
    try:
        raise HeaderExpectationFailed(data_input)
    except HeaderExpectationFailed as error:
        assert error.message == data_input
        assert error.status_code == 417

# Generated at 2022-06-21 22:40:49.640355
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage(message="this is a test").message == 'this is a test'

# Generated at 2022-06-21 22:40:50.381660
# Unit test for constructor of class Forbidden
def test_Forbidden():
	obj = Forbidden("Test")
	assert obj.status_code == 403


# Generated at 2022-06-21 22:40:52.338978
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file = 'test'
    relative_url = '/test'
    assert FileNotFound("Message", file, relative_url).path == file
    assert FileNotFound("Message", file, relative_url).relative_url == relative_url

if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-21 22:40:55.775704
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError, match="could not execute config file %s"):
        raise PyFileError('a.py')

# Generated at 2022-06-21 22:40:57.556762
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    s = InvalidSignal('message', 'status_code')
    assert isinstance(s, SanicException)

# Generated at 2022-06-21 22:41:00.158528
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType(message="An unexpected error occurred",
                               content_range=10)
    except InvalidRangeType as err:
        assert err.args[0] == "An unexpected error occurred"
        assert err.headers["Content-Range"] == "bytes */10"

# Generated at 2022-06-21 22:41:02.637268
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge()
    assert payload_too_large.status_code == 413
    assert payload_too_large.message == "Payload Too Large"
    assert payload_too_large.description == "Payload Too Large"


# Generated at 2022-06-21 22:41:05.372325
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    methodnotsupported = MethodNotSupported('a', 'b', ['c', 'd'])
    print(methodnotsupported.headers['Allow'])

# Generated at 2022-06-21 22:41:05.932667
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    HeaderNotFound("")

# Generated at 2022-06-21 22:41:14.501306
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('Cannot load the file')
    except LoadFileException as e:
        assert str(e) == 'Cannot load the file'


# Generated at 2022-06-21 22:41:15.016521
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    InvalidSignal("sigint", None)

# Generated at 2022-06-21 22:41:18.920706
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # test for the __init__ function of class ContentRangeError
    c = ContentRangeError("this is an error message", 10)
    assert c.headers['Content-Range'] == 'bytes */10'
    assert c.message == "this is an error message"


# Generated at 2022-06-21 22:41:20.763516
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found")
    except BaseException as e:
        assert e.status_code == 400

# Generated at 2022-06-21 22:41:29.299540
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."
    status_code = 401
    scheme = "Basic"
    realm = "Restricted Area"
    unauthorized = Unauthorized(message=message,
                                status_code=status_code,
                                scheme=scheme,
                                realm=realm)
    if message is not None:
        assert unauthorized.args[0] == message
    if status_code is not None:
        assert unauthorized.status_code == status_code
    if scheme is not None:
        assert unauthorized.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}


# Generated at 2022-06-21 22:41:32.575503
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("Invalid message", status_code=200, quiet=False)
    except SanicException as ex:
        assert str(ex) == "Invalid message"
        assert ex.status_code == 200
        assert ex.quiet == False


# Generated at 2022-06-21 22:41:35.522817
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = "message"
    content_range = 50
    obj = ContentRangeError(message, content_range)
    assert obj.message == message
    assert obj.status_code == 416
    assert obj.headers == {'Content-Range': 'bytes */50'}

# Generated at 2022-06-21 22:41:37.162081
# Unit test for constructor of class Forbidden
def test_Forbidden():
    f = Forbidden('message content', status_code=400)
    assert f.message == 'message content'
    assert f.status_code == 400

# Generated at 2022-06-21 22:41:45.183952
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except Exception as e:
        assert type(e) == NotFound
        assert e.status_code == 404
    try:
        abort(500, 'Something went wrong')
    except Exception as e:
        assert type(e) == ServerError
        assert e.status_code == 500
        assert e.message == 'Something went wrong'
    try:
        abort(408)
    except Exception as e:
        assert type(e) == RequestTimeout
        assert e.status_code == 408
    try:
        abort(200)
    except Exception as e:
        assert type(e) == SanicException
        assert e.status_code == 200
    try:
        abort(999)
    except Exception as e:
        assert type(e) == SanicException
        assert e.status

# Generated at 2022-06-21 22:41:49.056685
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        ContentRangeError('416 Range Not Satisfiable', 1)
    except Exception as e:
        assert str(e) == '416 Range Not Satisfiable'
        assert e.message == '416 Range Not Satisfiable'
        assert e.status_code == 416
    else:
        assert False


# Generated at 2022-06-21 22:41:55.527792
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    obj = InvalidUsage('error')
    assert obj.message == 'error'
    assert obj.status_code == 400


# Generated at 2022-06-21 22:41:56.585655
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    assert LoadFileException('sanic') == LoadFileException('sanic')

# Generated at 2022-06-21 22:41:58.595324
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound('not found')
    assert not_found.status_code == 404
    assert not_found.message == 'not found'



# Generated at 2022-06-21 22:42:01.170720
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("test", None)
    except Exception as err:
        assert err.headers["Content-Range"] == "bytes */None"

# Generated at 2022-06-21 22:42:04.192032
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message="Test error message", status_code=500)
    except ServerError as e:
        assert str(e) == "Test error message"
        assert e.status_code == 500


# Generated at 2022-06-21 22:42:07.718841
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout('message')
    except Exception as e:
        assert str(e) == '408: Request Timeout'

# Generated at 2022-06-21 22:42:10.708569
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("No reverse match.")
    assert err.args[0] == "No reverse match."
    assert err.status_code == 500


# Generated at 2022-06-21 22:42:14.921573
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404


# Generated at 2022-06-21 22:42:20.331013
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    msg = "test"
    method = "method"
    allowed_methods = ["a", "b", "c"]
    mnsp = MethodNotSupported(msg, method, allowed_methods)
    assert mnsp.message == msg
    assert mnsp.headers["Allow"] == ", ".join(allowed_methods)

# Generated at 2022-06-21 22:42:27.211579
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "Test SanicException"
    status_code = 500
    quiet = False
    exception = SanicException(message, status_code, quiet)
    assert exception.args[0] == message, "args[0] must be to equal to message"
    assert exception.status_code == status_code, "status_code must be equal to the input"
    assert exception.quiet == quiet, "quiet must be equal to the input"


# Generated at 2022-06-21 22:42:36.117080
# Unit test for constructor of class SanicException
def test_SanicException():
    error_message = "test"
    status_code = 400
    quiet = True
    try:
        raise SanicException(message=error_message, status_code=status_code, quiet=quiet)
    except SanicException:
        assert sys.exc_info()[1].status_code == status_code
        assert sys.exc_info()[1].quiet == quiet
        assert sys.exc_info()[0] == SanicException
        assert sys.exc_info()[1].args[0] == error_message

# Generated at 2022-06-21 22:42:47.265723
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(409)
    class Conflict(SanicException):
        pass

    @add_status_code(501)
    class NotImplemented(SanicException):
        pass

    @add_status_code(501)
    class Foo(SanicException):
        pass

    assert Conflict.status_code == 409
    assert Conflict.quiet is True
    assert NotImplemented.status_code == 501
    assert NotImplemented.quiet is None
    assert Foo.status_code == 501
    assert Foo.quiet is False
    assert _sanic_exceptions[409] == Conflict
    assert _sanic_exceptions[501] == NotImplemented

# Generated at 2022-06-21 22:42:57.840570
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test_case_1")
    except LoadFileException as exception:
        assert exception.__str__() == "test_case_1"
        assert exception.__repr__() == "LoadFileException('test_case_1')"
        assert exception.message == "test_case_1"
    try:
        raise LoadFileException("test_case_2", status_code=403)
    except LoadFileException as exception:
        assert exception.__str__() == "test_case_2"
        assert exception.__repr__() == "LoadFileException('test_case_2', status_code=403)"
        assert exception.message == "test_case_2"
        assert exception.status_code == 403

# Generated at 2022-06-21 22:43:01.363199
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("RequestTimeout Test")
    except (RequestTimeout) as exc:
        status_code = exc.status_code
        assert status_code == 408
    else:
        assert False



# Generated at 2022-06-21 22:43:06.363841
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # raise and check the exception
    try:
        raise URLBuildError("The URL could not be built.")
    except URLBuildError as e:
        # check attribute "str" of object e
        assert str(e) == "The URL could not be built."
        # check attribute "status_code" of object e
        assert e.status_code == 500

# Generated at 2022-06-21 22:43:09.586708
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exc = HeaderNotFound("a=b")
    assert exc.message == "a=b"

if __name__ == "__main__":
    test_HeaderNotFound()

# Generated at 2022-06-21 22:43:13.782817
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    u = Unauthorized("Auth required.", scheme="Bearer")
    assert u.message == "Auth required."
    assert u.status_code == 401
    assert u.headers == {"WWW-Authenticate": "Bearer"}

# Generated at 2022-06-21 22:43:17.531488
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    shortname_ServiceUnavailable = ServiceUnavailable("Service unavailable", status_code=503)
    assert type(shortname_ServiceUnavailable) == ServiceUnavailable
    assert shortname_ServiceUnavailable.status_code == 503



# Generated at 2022-06-21 22:43:18.655478
# Unit test for constructor of class NotFound
def test_NotFound():
    NotFound_obj = NotFound(message='test')

# Generated at 2022-06-21 22:43:20.180133
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Test for Forbidden
    with pytest.raises(Forbidden) as err_info:
        raise Forbidden(message='Forbidden')
    assert err_info.type == Forbidden
    assert err_info.value.status_code == 403
    assert err_info.value.message == 'Forbidden'

# Generated at 2022-06-21 22:43:31.248333
# Unit test for constructor of class ServerError
def test_ServerError():
    ServerError()

# Generated at 2022-06-21 22:43:33.988181
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    response = PayloadTooLarge("Message", "abc")
    assert response.headers == {"Content-Type": "text/plain; charset=utf-8"}
    assert response.message == "Message"
    assert response.status_code == 413

# Generated at 2022-06-21 22:43:43.948004
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except Exception as e:
        assert e.message == "NOT FOUND"
        assert e.status_code == 404
        assert e.__class__.__name__ == "NotFound"

    try:
        abort(404, "not found")
    except Exception as e:
        assert e.message == "not found"

    try:
        abort(405, "not found")
    except Exception as e:
        assert e.__class__.__name__ == "SanicException"

        # Test the case where no message is passed
    try:
        abort(500)
    except Exception as e:
        assert e.message == "INTERNAL SERVER ERROR"

# Generated at 2022-06-21 22:43:46.434757
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("testing")
    except InvalidUsage as error:
        assert error.status_code == 400
        assert error.message == "testing"


# Generated at 2022-06-21 22:43:47.709466
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    a = InvalidSignal("test")
    assert str(a) == "test"

# Generated at 2022-06-21 22:43:50.777692
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Error")
    except ServerError as e:
        assert e.status_code == 500
        assert e.quiet == False
        assert str(e) == "Error"

# Generated at 2022-06-21 22:43:53.588006
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("test")
    assert error.args[0] == "could not execute config file %s"
    assert error.args[1] == "test"



# Generated at 2022-06-21 22:43:56.395597
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    invalid_signal = InvalidSignal()
    assert isinstance(invalid_signal, SanicException)
    assert invalid_signal.message == None

# Generated at 2022-06-21 22:43:59.905877
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message="Server going down for maintenance.")
    except Exception as e:
        assert hasattr(e, "status_code")
        assert e.status_code == 503
        assert e.__class__.__name__ == "ServiceUnavailable"

# Generated at 2022-06-21 22:44:01.459390
# Unit test for constructor of class PyFileError
def test_PyFileError():
    assert PyFileError("test.py").args[0] == "could not execute config file test.py"

# Generated at 2022-06-21 22:44:23.614040
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exc = InvalidRangeType('Invalid input', 10)
    assert exc.status_code == 400


# Generated at 2022-06-21 22:44:24.526958
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException('message', 'status_code', 'quiet')


# Generated at 2022-06-21 22:44:28.554622
# Unit test for constructor of class NotFound
def test_NotFound():
    assert issubclass(NotFound, SanicException)
    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert NotFound(message='404 Not Found', status_code=404, quiet=True)


# Generated at 2022-06-21 22:44:31.332706
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Test Invalid Signal')
    except InvalidSignal as e:
        assert e.args[0] == 'Test Invalid Signal'


# Generated at 2022-06-21 22:44:34.840626
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exception = URLBuildError("Couldn't build static URL for endpoint 'static', "
                              "did you forget to specify url_prefix?")
    assert exception is not None

# Generated at 2022-06-21 22:44:39.088327
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    ex = MethodNotSupported("Method not supported", "GET", ["GET", "POST"])
    assert ex.headers == {"Allow": "GET, POST"}

    ex = MethodNotSupported("Method not supported", "GET", ["ACCEPT", "POST"])
    assert ex.headers == {"Allow": "ACCEPT, POST"}

# Generated at 2022-06-21 22:44:40.235836
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(ServerError):
        raise ServerError('test')

# Generated at 2022-06-21 22:44:43.210165
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError):
        raise ContentRangeError("range not satisfiable", 5)


# Generated at 2022-06-21 22:44:48.406696
# Unit test for constructor of class NotFound
def test_NotFound():
    message = 'Not Found'
    status_code = 404
    quiet = True
    notFound = NotFound(message, status_code, quiet)
    assert notFound.args[0] == message
    assert notFound.status_code == status_code
    assert notFound.quiet == quiet


# Generated at 2022-06-21 22:44:51.223976
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    with pytest.raises(Exception):
        pl = PayloadTooLarge(payload=1234, max_payload=10)

if __name__ == "__main__":
    test_PayloadTooLarge()

# Generated at 2022-06-21 22:45:38.073371
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("ServerError")
    except ServerError as e: pass
    assert e.responsible == "ServerError"
    assert e.status_code == 500


# Generated at 2022-06-21 22:45:39.569496
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Exception as e:
        assert e.status_code == 403



# Generated at 2022-06-21 22:45:40.548599
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("Message")
    assert err.args == ("Message",)

# Generated at 2022-06-21 22:45:45.192379
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('header not found')
    except HeaderNotFound as e:
        assert e.args[0] == 'header not found'
        assert e.status_code == 400


# Generated at 2022-06-21 22:45:49.931111
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = r"path"
    url = r"url"
    message = r"message"
    e = FileNotFound(message,path,url)
    assert str(e) == message
    assert e.status_code == 404
    assert e.message == message
    assert e.path == path
    assert e.relative_url == url


# Generated at 2022-06-21 22:46:00.083699
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # Testing the message
    with pytest.raises(ServiceUnavailable) as e:
        raise ServiceUnavailable("Custom Error Message")
    assert str(e.value) == "Custom Error Message"
    # Testing the status_code
    with pytest.raises(ServiceUnavailable) as e:
        raise ServiceUnavailable("Custom Error Message", status_code=401)
    assert e.value.status_code == 401
    assert e.value.message == "Custom Error Message"
    # Testing the quiet
    with pytest.raises(ServiceUnavailable) as e:
        raise ServiceUnavailable("Custom Error Message", quiet=True)
    assert e.value.quiet is True
    assert e.value.message == "Custom Error Message"


# Generated at 2022-06-21 22:46:04.614524
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert RequestTimeout('The Web server (running the Web site) thinks that there has been too long an interval of time between 1) the establishment of an IP connection (socket) between the client and the server and 2) the receipt of any data on that socket, so the server has dropped the connection. The socket connection has actually been lost - the Web server has \'timed out\' on that particular socket connection.', 408)

# Generated at 2022-06-21 22:46:16.874778
# Unit test for function add_status_code
def test_add_status_code():
    class TestSanicException(SanicException):
        pass
    
    assert TestSanicException.status_code is None
    test_exception = TestSanicException("test message")
    assert test_exception.status_code == TestSanicException.status_code
    TestSanicException.status_code = 200
    test_exception = TestSanicException("test message")
    assert test_exception.status_code == TestSanicException.status_code

    TestSanicException.status_code = None
    assert TestSanicException.status_code is None
    test_exception = TestSanicException("test message", 600)
    assert test_exception.status_code == 600

    @add_status_code(200)
    class TestException(SanicException):
        pass

    assert TestException.status_code

# Generated at 2022-06-21 22:46:19.687429
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exception = HeaderExpectationFailed("message", "headers")
    assert exception.status_code == 417
    assert exception.headers == "headers"


# Generated at 2022-06-21 22:46:23.194489
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound()
    except HeaderNotFound as err:
        assert err.status_code == 400
        assert err.message == 'Unknown header'

# Generated at 2022-06-21 22:48:03.157522
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable(message='Service Unavailable', status_code=500)
    except ServiceUnavailable as e:
        assert e.headers == {}
        assert e.status_code == 503
        assert e.quiet == False
        print('test_ServiceUnavailable passed')


# Generated at 2022-06-21 22:48:07.741295
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['GET', 'HEAD', 'POST', 'PUT']
    msg = "GET method is not supported"
    method_name = "GET"
    method_not_supported = MethodNotSupported(msg, method_name, allowed_methods)
    print(repr(method_not_supported))

# Generated at 2022-06-21 22:48:11.332088
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = 'no'
    content_range = 1
    content_range_error = ContentRangeError(message,content_range)
    assert content_range_error.status_code == 416

# Generated at 2022-06-21 22:48:15.623545
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("E")
    except InvalidSignal as e:
        pass
    except BaseException as e:
        assert False
    else:
        assert False

if __name__ == '__main__':
    test_InvalidSignal()

# Generated at 2022-06-21 22:48:21.034126
# Unit test for function abort
def test_abort():
    try:
        abort(400, message='abc')
    except InvalidUsage as e:
        message = str(e)
        assert e.status_code == 400
        assert message == 'abc'
    else:
        raise Exception('Not raised')

    try:
        abort(404)
    except NotFound as e:
        message = str(e)
        assert e.status_code == 404
        assert message == '404 Not Found'
    else:
        raise Exception('Not raised')

# Generated at 2022-06-21 22:48:25.198944
# Unit test for constructor of class SanicException
def test_SanicException():
    message = "Test SanicException"
    status_code = 500
    exception1 = SanicException(message,status_code)
    assert (exception1.status_code == status_code)
    assert (exception1.message == message)


# Generated at 2022-06-21 22:48:26.121779
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound("test")


# Generated at 2022-06-21 22:48:27.873335
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    rangeType = InvalidRangeType('message')
    assert rangeType.message == 'message'
    assert rangeType.status_code == 416
    assert rangeType.headers == {'Content-Range': 'bytes */0'}


# Generated at 2022-06-21 22:48:30.654791
# Unit test for constructor of class NotFound
def test_NotFound():
    assert issubclass(NotFound, SanicException)
    assert hasattr(NotFound, "__init__")
    assert hasattr(NotFound, "__doc__")

# Generated at 2022-06-21 22:48:32.207088
# Unit test for constructor of class ServerError
def test_ServerError():
    # Test the constructor of ServerError class
    assert ServerError.status_code == 500
    assert ServerError.quiet == False