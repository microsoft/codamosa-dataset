

# Generated at 2022-06-21 22:40:05.754013
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    filename='testfile.py'
    with pytest.raises(LoadFileException, match=f'could not execute config file {filename}'):
        raise LoadFileException(f"could not execute config file {filename}")

# Generated at 2022-06-21 22:40:08.571818
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    e = InvalidUsage("test")
    assert e.message == "test"
    assert e.status_code == 400
    assert e.quiet is None


# Generated at 2022-06-21 22:40:11.374867
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout(message="abc", status_code=408)
    assert rt.status_code == 408
    assert rt.message == "abc"



# Generated at 2022-06-21 22:40:17.034592
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Message")
    except HeaderExpectationFailed as e:
        assert e.message == "Message"
        assert e.status_code == 417


# Generated at 2022-06-21 22:40:20.102314
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Invalid request')
    except InvalidUsage as e:
        assert e.status_code == 400

# Generated at 2022-06-21 22:40:25.334876
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("hello", status_code=404, quiet=True)
    except SanicException as e:
        assert e.status_code == 404
        assert e.args[0] == "hello"
        assert e.quiet == True
    assert True


# Generated at 2022-06-21 22:40:30.324685
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as e:
        assert e.message == "Auth required."
        assert e.status_code == 401
        assert e.headers == {"WWW-Authenticate": "Basic realm=\"Restricted Area\""}


# Generated at 2022-06-21 22:40:34.895969
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("Header Expectation Failed Test")
    except HeaderExpectationFailed as err:
        assert err.status_code == 417
        assert err.args[0] == "Header Expectation Failed Test"

# Generated at 2022-06-21 22:40:38.098263
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception = Forbidden()
    assert exception.status_code == 403
    assert exception.message == "403 Forbidden"

# Generated at 2022-06-21 22:40:41.158498
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('message', 'header')

    except HeaderNotFound as e:
        assert e.message == 'message'
        assert e.header == 'header'
        assert e.status_code == 400

# Generated at 2022-06-21 22:40:48.567053
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    invalid_usage = InvalidUsage('Error 403')
    assert invalid_usage.status_code == 400
    assert invalid_usage.message == 'Error 403'
    assert invalid_usage.quiet == True
    invalid_usage_2 = InvalidUsage('Error 403', status_code=403)
    assert invalid_usage_2.status_code == 403
    assert invalid_usage_2.message == 'Error 403'
    assert invalid_usage_2.quiet == True


# Generated at 2022-06-21 22:40:53.192319
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException("This is a test.")
    assert e.message == "This is a test."
    assert e.status_code == None
    assert e.quiet == False
    e = SanicException("This is a test.", status_code=200)
    assert e.message == "This is a test."
    assert e.status_code == 200
    assert e.quiet == False
    e = SanicException("This is a test.", status_code=500)
    assert e.message == "This is a test."
    assert e.status_code == 500
    assert e.quiet == False
    e = SanicException("This is a test.", status_code=200, quiet=True)
    assert e.message == "This is a test."
    assert e.status_code == 200
    assert e.quiet == True
   

# Generated at 2022-06-21 22:40:55.424790
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
	a = InvalidRangeType("", 400)
	return a

# Generated at 2022-06-21 22:40:58.366281
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("503 Service Unavailable")
    except ServiceUnavailable as e:
        if e.args[0] != "503 Service Unavailable":
            raise


# Generated at 2022-06-21 22:41:00.092355
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound("NotFound")
    assert not_found.message == "NotFound"



# Generated at 2022-06-21 22:41:01.969997
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("The Web server (running the Web site) thinks that there has been too")

# Generated at 2022-06-21 22:41:03.961315
# Unit test for constructor of class ServerError
def test_ServerError():
    # Unit test for constructor
    obj = ServerError("New ServerError")
    assert obj.args[0] == "New ServerError"
    assert obj.status_code == 500

# Generated at 2022-06-21 22:41:08.054344
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "foo.py"
    with pytest.raises(PyFileError) as error:
        raise PyFileError(file)

    assert str(error.value).startswith("could not execute config file")
    assert str(error.value).endswith(file)

# Generated at 2022-06-21 22:41:11.341086
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("custom message")
    except SanicException as e:
        assert e.status_code == 500



# Generated at 2022-06-21 22:41:12.954873
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
  assert InvalidSignal().__init__("this is a test")

# Generated at 2022-06-21 22:41:16.405306
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable
    except ServiceUnavailable as e:
        assert e.status_code == 503

# Generated at 2022-06-21 22:41:20.932588
# Unit test for function abort
def test_abort():
    """
    Tests abort() function.
    """
    assert "No response message" == abort(400)

    assert "No response message" == abort(500)

    assert "No response message" == abort(503)

    assert "Not found" == abort(404)

    try:
        abort(999)
    except Exception as e:
        assert "999" in str(e)

# Generated at 2022-06-21 22:41:24.775369
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class MyException(SanicException): pass

    assert MyException.status_code == 404

    ex = MyException("Test")
    assert ex.status_code == 404
    assert str(ex) == "Test"

# Generated at 2022-06-21 22:41:28.049461
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    rtn = ServiceUnavailable(message='aa', status_code=503)
    assert rtn.status_code==503
    assert rtn.quiet==True
    assert rtn.message=='aa'



# Generated at 2022-06-21 22:41:30.203975
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("test_ServerError")
    except:
        assert isinstance(Exception, ServerError)



# Generated at 2022-06-21 22:41:33.065895
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('message', 'content_range')
    except ContentRangeError as e:
        assert e.message == 'message'
        assert e.content_range == 'content_range'


# Generated at 2022-06-21 22:41:39.591709
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("ClientClosedRequest", status_code=499, quiet=True)
    except SanicException as e:
        status_code = e.status_code
        msg = e.quiet
        assert status_code == 499
        assert msg == True
        assert "499" in str(e)



# Generated at 2022-06-21 22:41:43.996629
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Won't you be my neighbor?")
    except Forbidden:
        forbidden = Forbidden("Won't you be my neighbor?")
    assert str(forbidden) == forbidden.message
    assert forbidden.status_code == 403


# Generated at 2022-06-21 22:41:46.405967
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('a message')
    except InvalidSignal as e:
        assert e.args[0] == 'a message'

# Generated at 2022-06-21 22:41:49.840792
# Unit test for constructor of class SanicException
def test_SanicException():
    exc1 = SanicException(message='Bad Request\n', status_code=400)
    assert exc1.status_code == 400
    assert exc1.quiet == True
    assert exc1.message == 'Bad Request\n'


# Generated at 2022-06-21 22:41:53.897630
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    import pytest
    with pytest.raises(PayloadTooLarge):
        raise PayloadTooLarge(
            "Sorry, the file you're trying to upload is too large"
        )


# Generated at 2022-06-21 22:41:56.887729
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exc = HeaderNotFound("Host")
    assert exc.status_code == 400
    assert isinstance(exc, InvalidUsage)
    assert isinstance(exc, SanicException)
    assert isinstance(exc, Exception)

# Generated at 2022-06-21 22:41:59.685697
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('Payload Too Large')
    except PayloadTooLarge as e:
        assert(str(e) == 'Payload Too Large')
        assert(e.status_code == 413)


# Generated at 2022-06-21 22:42:01.213935
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    a = InvalidSignal("message")
    assert a

# Generated at 2022-06-21 22:42:02.813940
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError(1)
    assert error.args[0] == 'could not execute config file 1'

if __name__ == '__main__':
    test_PyFileError()

# Generated at 2022-06-21 22:42:09.861519
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        # invalid range type
        raise InvalidRangeType("invalid range type", "abcd")
    except InvalidRangeType as err:
        assert str(err) == "invalid range type"
        assert err.content_range == "abcd"
        assert err.args[0] == "invalid range type"
        assert err.args[1] == "abcd"
    else:
        assert False

# Generated at 2022-06-21 22:42:12.477793
# Unit test for constructor of class PyFileError
def test_PyFileError():
    filepath = "./test.py"
    pyfileerror = PyFileError(filepath)
    assert pyfileerror.args == ("could not execute config file %s", filepath)
    assert pyfileerror != None

# Generated at 2022-06-21 22:42:14.272150
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(FileNotFoundError) as e:
        raise LoadFileException('TestFile.json')



# Generated at 2022-06-21 22:42:16.960113
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('testing_exception')
    except InvalidUsage as e:
        assert e.status_code == 400


# Generated at 2022-06-21 22:42:26.769658
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # Constructor of class MethodNotSupported
    mns = MethodNotSupported('Method not supported', 'POST', ['HEAD', 'GET'])
    # MethodNotSupported should be a subclass of SanicException
    assert issubclass(MethodNotSupported, SanicException)
    # headers should be set to ['Allow: HEAD, GET']
    assert mns.headers == {'Allow':'HEAD, GET'}
    # Exception should have message
    assert mns.args[0] == 'Method not supported'
    # Exception should have status_code 405
    assert mns.status_code == 405


if __name__ == "__main__":
    test_MethodNotSupported()

# Generated at 2022-06-21 22:42:34.769432
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "test"
    path = "path"
    relative_url = "relative_url"
    fileNotFound = FileNotFound(message, path, relative_url)
    assert fileNotFound.message == message
    assert fileNotFound.path == path
    assert fileNotFound.relative_url == relative_url

# Generated at 2022-06-21 22:42:38.317280
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    Testing the constructor of class RequestTimeout
    Input:    A message
    Expected: An instance of class RequestTimeout
    """
    message = "Your request is taking too long!"
    result = RequestTimeout(message,408)
    assert type(result) == RequestTimeout


# Generated at 2022-06-21 22:42:43.266524
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    err = InvalidRangeType("InvalidRangeTypeClass")
    assert err.__class__.__name__ == "InvalidRangeType"
    assert err.__str__() == "InvalidRangeTypeClass"


# Generated at 2022-06-21 22:42:51.056510
# Unit test for constructor of class Forbidden
def test_Forbidden():
    err1 = Forbidden(message='bad')
    assert err1.message == 'bad'
    assert err1.status_code == 403
    assert err1.__class__.__name__ == 'Forbidden'
    assert err1.__class__.__module__ == 'sanic.exceptions'

    err2 = Forbidden(message='bad', status_code=200)
    assert err2.message == 'bad'
    assert err2.status_code == 200
    assert err2.__class__.__name__ == 'Forbidden'
    assert err2.__class__.__module__ == 'sanic.exceptions'


# Generated at 2022-06-21 22:43:02.610876
# Unit test for function abort
def test_abort():
    """
    Test abort.
    """

# Generated at 2022-06-21 22:43:07.010959
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # Test with message
    exc = HeaderExpectationFailed(message='Test message.')
    assert 'Test message.' == exc.args[0]

    # Test without message
    exc = HeaderExpectationFailed()
    assert 'Test message.' == exc.args[0]


# Generated at 2022-06-21 22:43:12.778943
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized as e:
        assert(e.status_code==401)

        assert(e.headers['WWW-Authenticate']=='Basic realm="Restricted Area"')


# Generated at 2022-06-21 22:43:16.403028
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound()
    except NotFound as e:
        assert e.message == ""
        assert e.status_code == 404
        assert e.quiet == True


# Generated at 2022-06-21 22:43:20.035808
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "not found"
    path = "test"
    relative_url = "test"
    f = FileNotFound(message, path, relative_url)
    assert f.path == path
    assert f.relative_url == relative_url

# Generated at 2022-06-21 22:43:27.060896
# Unit test for function abort
def test_abort():
    try:
        abort(500, "ERROR")
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "ERROR"

    try:
        abort(404)
    except SanicException as e:
        assert e.status_code == 404
        assert e.message == b'Not Found'
        assert e.message == STATUS_CODES[404].decode('utf8')

# Generated at 2022-06-21 22:43:36.590255
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pl = PayloadTooLarge(message="oops")
    assert pl.message == "oops"
    assert pl.status_code == 413
    assert pl.quiet == True
    assert str(pl) == 'oops'


# Generated at 2022-06-21 22:43:40.458274
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal('Bad signal', signal_name='SIGKILL')
    except InvalidSignal as e:
        assert e.signal_name == 'SIGKILL'

# Generated at 2022-06-21 22:43:42.323436
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    test = PayloadTooLarge("message")
    assert test.status_code == 413


# Generated at 2022-06-21 22:43:46.036422
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("forbidden")
    except Forbidden as e:
        assert str(e) == "forbidden"
        assert e.status_code == 403
        assert e.quiet is False

if __name__ == '__main__':
    test_Forbidden()

# Generated at 2022-06-21 22:43:48.766081
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("HeaderNotFound: 400 Bad Request")
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.message == "HeaderNotFound: 400 Bad Request"

# Generated at 2022-06-21 22:43:50.230648
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    exc = URLBuildError('Could not build url')



# Generated at 2022-06-21 22:43:53.936994
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    while True:
        try:
            invalid_message = "Invalid message"
            result = InvalidUsage(message=invalid_message)
            if isinstance(result,InvalidUsage):
                return True
        except:
            return False

# Generated at 2022-06-21 22:43:55.521959
# Unit test for constructor of class PyFileError
def test_PyFileError():
    PyFileError("file")

# Generated at 2022-06-21 22:43:56.715993
# Unit test for constructor of class PyFileError
def test_PyFileError():
    x = PyFileError("test")
    assert x.args[0] == "could not execute config file %s"
    assert x.args[1] == "test"


# Generated at 2022-06-21 22:43:57.498147
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden('test_message') == Forbidden('test_message')

# Generated at 2022-06-21 22:44:09.618785
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    global exception
    exception = URLBuildError()

# Generated at 2022-06-21 22:44:13.748083
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['GET']
    method_not_supported = MethodNotSupported("Method not supported", 'POST', allowed_methods)

    assert method_not_supported.status_code == 405
    assert method_not_supported.headers['Allow'] == "GET"

# Generated at 2022-06-21 22:44:16.457334
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    c = HeaderExpectationFailed("message")
    assert c.quiet is True
    assert str(c) == "message"
    assert c.status_code == 417

# Generated at 2022-06-21 22:44:24.839961
# Unit test for function abort
def test_abort():
    status_code, message = 404, None
    try:
        abort(status_code, message)
    except (SanicException) as e:
        assert e.status_code == status_code
        assert e.message == b'Not Found'
    try:
        abort(status_code, message)
    except (NotFound) as e:
        assert e.status_code == status_code
        assert e.message == b'Not Found'
    try:
        status_code = 404
        abort(status_code, message)
    except (NotFound) as e:
        assert e.status_code == status_code
        assert e.message == b'Not Found'

# Generated at 2022-06-21 22:44:26.428354
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError
    except SanicException:
        assert True
    

# Generated at 2022-06-21 22:44:28.898778
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("FileNotFound", "/root/very_secret_file", "secret")
    except FileNotFound as e:
        assert e.path == "/root/very_secret_file"
        assert e.relative_url == "secret"

# Generated at 2022-06-21 22:44:33.158624
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(TypeError)
        raise LoadFileException(TypeError, 't')
        raise LoadFileException()
        raise LoadFileException("t")
        pass
    except LoadFileException:
        pass

# Generated at 2022-06-21 22:44:39.598015
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    HTTPMethod = 'GET'
    allowed_methods = ['POST', 'PUT', 'GET', 'HEAD', 'DELETE']
    message = 'GET method not supported'

    try:
        raise MethodNotSupported(message, HTTPMethod, allowed_methods)
    except Exception as e:
        assert e.status_code == 405
        assert e.headers == {'Allow': 'POST, PUT, GET, HEAD, DELETE'}
        assert e.message == message


# Generated at 2022-06-21 22:44:51.172688
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """Tests SanicException.Unauthorized()."""
    # No scheme
    try:
        raise Unauthorized("Auth required.")
    except Exception as e:
        result = e.headers
        expected = None
    assert result == expected
    # Basic scheme, minimal parameters
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Exception as e:
        result = e.headers
        expected = {'WWW-Authenticate': 'Basic realm="Restricted Area"'}
    assert result == expected
    # Digest scheme, all parameters

# Generated at 2022-06-21 22:44:53.894893
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    file_not_found = FileNotFound(message="File not found", path=None, relative_url=None)
    assert str(file_not_found) == "File not found"

# Generated at 2022-06-21 22:45:22.462029
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        signal_1 = InvalidSignal("test_1_faktest")
        signal_2 = InvalidSignal("test_2_faktest")
        signal_3 = InvalidSignal("test_3_faktest", status_code=500)
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-21 22:45:23.595095
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound('NotFound')


# Generated at 2022-06-21 22:45:25.224740
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exception = InvalidSignal("No such signal")
    assert exception.message == "No such signal"

# Generated at 2022-06-21 22:45:28.149507
# Unit test for function abort
def test_abort():
    with pytest.raises(ServerError) as exc:
        abort(500, "Something went wrong")
    assert exc.value.status_code == 500

    with pytest.raises(ServiceUnavailable) as exc:
        abort(503)
    assert exc.value.status_code == 503

# Generated at 2022-06-21 22:45:30.569074
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge(message='PayloadTooLarge', status_code=413)
    assert exception is not None


# Generated at 2022-06-21 22:45:34.459940
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Signal is invalid!")
    except InvalidSignal as e:
        print(e)
        assert str(e) == "Signal is invalid!"
        assert e.status_code == 500


# Generated at 2022-06-21 22:45:38.235013
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    crange = 123
    msg = "test"
    e = ContentRangeError(msg, crange)
    assert(e.args == (msg, ))
    assert(e.status_code == 416)
    assert(e.headers == { "Content-Range": bytes("bytes */123", "utf8") })

# Generated at 2022-06-21 22:45:39.375063
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    e = ServiceUnavailable('I am unavailable')
    assert e.status_code == 503

# Generated at 2022-06-21 22:45:45.151053
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "not found"
    path = "path"
    relative_url = "relative_url"

    try:
        raise FileNotFound(message, path, relative_url)
    except FileNotFound as exc:
        assert exc.message == message
        assert exc.path == path
        assert exc.relative_url == relative_url

# Generated at 2022-06-21 22:45:51.625017
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage("This is a message", 400)
    except InvalidUsage as e:
        assert str(e) == "This is a message"
        assert e.status_code == 400
    try:
        raise InvalidUsage("This is a message", 401)
    except InvalidUsage as e:
        assert str(e) == "This is a message"
        assert e.status_code == 401
    # status_code not in 400...417
    try:
        raise InvalidUsage("This is a message", 418)
    except InvalidUsage as e:
        assert str(e) == "This is a message"
        assert e.status_code == 418
    # status_code is not integer
    try:
        raise InvalidUsage("This is a message", "418")
    except InvalidUsage as e:
        assert str(e)

# Generated at 2022-06-21 22:46:42.776499
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    ContentRangeError(message="hello", content_range=null)

# Generated at 2022-06-21 22:46:44.604416
# Unit test for function abort
def test_abort():
    with pytest.raises(ServerError) as exc_info:
        abort(500)
        assert exc_info.match("Internal Server Error")

# Generated at 2022-06-21 22:46:48.137809
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    from sanic.response import content_range
    try:
        raise InvalidRangeType("range is invalid", content_range(total=10))
    except Exception as e:
        assert e.message == 'range is invalid'
        assert e.headers == {"Content-Range": "bytes */10"}
        assert e.status_code == 416


# Generated at 2022-06-21 22:46:48.954068
# Unit test for constructor of class NotFound
def test_NotFound():
    pass


# Generated at 2022-06-21 22:46:50.332588
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    req_timeout = RequestTimeout('time out', 408)
    assert req_timeout.status_code == 408


# Generated at 2022-06-21 22:46:59.513052
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Check for Unauthorized exception with no arguments
    try:
        raise Unauthorized("Auth required.")
    except Unauthorized as e:
        assert e.args[0] == "Auth required."
        assert e.message == "Auth required."
        assert e.headers == {}
    
    # Check for Unauthorized exception with scheme argument
    try:
        raise Unauthorized("Auth required.", scheme="Basic")
    except Unauthorized as e:
        assert e.args[0] == "Auth required."
        assert e.message == "Auth required."
        assert e.headers["WWW-Authenticate"] == "Basic"

    # Check for Unauthorized exception with scheme and realm arguments

# Generated at 2022-06-21 22:47:01.382207
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("test")
    assert err.status_code == 500
    assert err.message == "test"


# Generated at 2022-06-21 22:47:05.283492
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("error message")
    assert error.status_code == 500
    assert error.message == "error message"
    assert error.quiet == True

# Generated at 2022-06-21 22:47:08.166977
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    print("MethodNotSupported")
    print("message,method,allowed_methods")
    print("1", "2", "3")
    assert True == False, "constructor failed"


# Generated at 2022-06-21 22:47:09.706288
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(URLBuildError) as ube:
        raise URLBuildError("Failed URL")

# Generated at 2022-06-21 22:48:59.197518
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    signal = 'SIGINT'
    try:
        raise InvalidSignal(f"Invalid signal {signal}")
    except InvalidSignal as e:
        assert e.__str__() == "Invalid signal SIGINT", "Invalid Signal"
        print(e.__str__())


# Generated at 2022-06-21 22:49:00.827845
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('500')
    except ServerError as ex:
        pass
    assert ex.message == '500'
    assert ex.status_code == 500


# Generated at 2022-06-21 22:49:10.960144
# Unit test for function abort
def test_abort():
    class TestException(SanicException):
        pass

    _sanic_exceptions[666] = TestException

    try:
        abort(404)
    except Exception as e:
        assert e.__class__ == NotFound
    else:
        raise AssertionError("abort(404) did not raise NotFound exception.")

    try:
        abort(666, message="test exception")
    except Exception as e:
        assert e.__class__ == TestException
    else:
        raise AssertionError(
            "abort(666, message='test exception') did not raise TestException exception."
        )

    try:
        abort(666)
    except Exception as e:
        assert e.__class__ == TestException

# Generated at 2022-06-21 22:49:11.730752
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    pass

# Generated at 2022-06-21 22:49:14.895396
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "somefile.py"
    try:
        raise PyFileError(file)
    except Exception as error:
        assert error.args[0] == 'could not execute config file %s'
        assert error.args[1] == 'somefile.py'

# Generated at 2022-06-21 22:49:16.141163
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    assert str(ServiceUnavailable("test exception")) == "test exception"

# Generated at 2022-06-21 22:49:18.207064
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    err = URLBuildError("test")
    assert err.__class__.__name__ == "URLBuildError"
    assert str(err) == "test"


# Generated at 2022-06-21 22:49:19.074771
# Unit test for constructor of class SanicException
def test_SanicException():
    SanicException('test_message', 400)

# Generated at 2022-06-21 22:49:22.187103
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    error_exception = ServiceUnavailable("Service unavailable.",
                                         status_code=503)
    assert status_code_of(error_exception) == 503
    assert message_of(error_exception) == "Service unavailable."



# Generated at 2022-06-21 22:49:24.841409
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as exc:
        assert exc.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'