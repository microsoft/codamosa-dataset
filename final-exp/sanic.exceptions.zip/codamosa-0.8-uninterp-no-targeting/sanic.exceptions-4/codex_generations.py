

# Generated at 2022-06-21 22:40:05.206013
# Unit test for function abort
def test_abort():
    """
    Run unittest on function abort.
    :return:    Success/Fail
    """
    try:
        abort(200, "Test")
    except SanicException:
        assert True
    except:
        assert False
    try:
        abort(401, "Test")
    except Unauthorized:
        assert True
    except:
        assert False



# Generated at 2022-06-21 22:40:06.258245
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
  Su = ServiceUnavailable("")

# Generated at 2022-06-21 22:40:15.876867
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException) as excinfo:
        abort(400)
    assert excinfo.value.status_code == 400
    with pytest.raises(SanicException) as excinfo:
        abort(401)
    assert excinfo.value.status_code == 401
    with pytest.raises(ServerError) as excinfo:
        abort(500)
    assert excinfo.value.status_code == 500
    with pytest.raises(NotFound) as excinfo:
        abort(404)
    assert excinfo.value.status_code == 404
    with pytest.raises(ServerError) as excinfo:
        abort(999)
    assert excinfo.value.status_code == 999

# Generated at 2022-06-21 22:40:21.165728
# Unit test for function add_status_code
def test_add_status_code():
    class test_for_add_status_code(SanicException):
        pass
    x = None
    if add_status_code(500)(test_for_add_status_code) == test_for_add_status_code:
        x = 0
    if _sanic_exceptions[500] == test_for_add_status_code:
        x = 1
    if test_for_add_status_code().status_code == 500:
        x = 2
    if x is None:
        return False
    return True

# Generated at 2022-06-21 22:40:24.314225
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLError(Exception)
    except Exception as err:
        assert err.__class__.__name__ == "URLError"

# Generated at 2022-06-21 22:40:25.277626
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge(message="Too Large",status_code=413) is not None

# Generated at 2022-06-21 22:40:35.545459
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import Sanic

    def get_response(request: Request) -> HTTPResponse:
        resp = HTTPResponse()
        resp.content_range(100, 0, 1024)
        return resp

    app = Sanic()

    app.add_route(get_response, uri="/")

    app.run(host="127.0.0.1", port=8000, debug=True)


if __name__ == "__main__":
    #
    # Unit test for constructor of class ContentRangeError
    #
    # 下面这段起到了什么作用？
    import doctest
    doctest.testmod()

    #

# Generated at 2022-06-21 22:40:38.539088
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage('test')

# Generated at 2022-06-21 22:40:48.405947
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    import pytest
    from datetime import date
    from sanic.helpers import SERVER_SOFTWARE
    from sanic import Sanic
    from sanic.exceptions import ServerError, InvalidRangeType

    # Test the constructor of class InvalidRangeType. It should raise an exception
    # -----------------------------------------------------------------------------
    with pytest.raises(InvalidRangeType) as excinfo:
        raise InvalidRangeType("hello", "world")

    with pytest.raises(ServerError) as excinfo:
        raise ServerError("hello")

    # Test the method make_response from class Sanic
    # -----------------------------------------------------------------------------
    app = Sanic()
    app.config.from_pyfile('config.py')
    app.config.from_envvar('APP_CONFIG_FILE')

# Generated at 2022-06-21 22:40:51.901825
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("ServerError message", status_code=400)
    except ServerError as err:
        assert str(err) == "ServerError message"
        assert err.status_code == 400

# Generated at 2022-06-21 22:40:56.093235
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Header not found.")
    except HeaderNotFound as error:
        assert error.status_code == 400
        assert error.args[0] == "Header not found."

# Generated at 2022-06-21 22:40:58.277001
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    h = HeaderNotFound("Error")
    assert h is not None
    assert h.message == "Error"


# Generated at 2022-06-21 22:41:06.098129
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(ServerError) as r:
        raise ServerError("test")
    assert str(r.value)=="test"
    assert r.value.status_code==500
    assert r.value.quiet==True
    with pytest.raises(ServerError) as r:
        raise ServerError("test2",status_code=502)
    assert r.value.status_code==502
    assert r.value.quiet==True

    with pytest.raises(ServerError) as r:
        raise ServerError("test3",status_code=502,quiet=True)
    assert r.value.status_code==502
    assert r.value.quiet==True

    with pytest.raises(ServerError) as r:
        raise ServerError("test4",status_code=502,quiet=True)

# Generated at 2022-06-21 22:41:11.066687
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # __init__(self, message, method, allowed_methods)
    with open("sanic_exception_pytest.txt", "w+") as f:
        f.write("Test for RequestTimeout")
    # --> Not test for this function, because there are no input and output

# Generated at 2022-06-21 22:41:15.624473
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('403 Forbidden')
    except Forbidden as e:
        assert '403 Forbidden' in str(e)
        assert e.status_code == 403

if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-21 22:41:19.761583
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    headers = {'Test': 'Test'}
    header_not_found_instance = HeaderNotFound('Test', headers)
    assert header_not_found_instance.status_code == 400
    assert header_not_found_instance.message == 'Test'
    assert header_not_found_instance.headers == headers

# Generated at 2022-06-21 22:41:29.198490
# Unit test for function abort
def test_abort():
    from sanic.testing import get_testing_exception

    # Test for sanic_exception that exists in the _sanic_exceptions dict
    testing_exception, traceback = get_testing_exception(NotFound)
    assert issubclass(testing_exception, NotFound)

    # Test for sanic_exception that does not exist in the _sanic_exceptions dict
    testing_exception, traceback = get_testing_exception(400)
    assert issubclass(testing_exception, SanicException)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:41:31.501213
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """ Unit test for `sanic.exceptions.RequestTimeout.__init__` """
    exception = RequestTimeout('message', 408)
    assert exception.status_code == 408

# Generated at 2022-06-21 22:41:34.592895
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exception = InvalidUsage("Invalid Usage")
    assert exception.status_code == 400
    try:
        raise exception
    except InvalidUsage as ex:
        assert str(ex) == "Invalid Usage"
        assert ex.status_code == 400
        assert ex.quiet == True


# Generated at 2022-06-21 22:41:38.094296
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test")
    except Exception as ex:
        assert ex.args[0] == "could not execute config file test"

# Generated at 2022-06-21 22:41:41.896811
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    s = ServiceUnavailable("error message")
    assert "error message" == s.message
    assert 503 == s.status_code
    assert s.quiet
    assert "Service unavailable" == str(s)



# Generated at 2022-06-21 22:41:45.773696
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Load file failed.")
    except Exception as e:
        assert e.__class__.__name__ == "LoadFileException"
        assert str(e) == "Load file failed."



# Generated at 2022-06-21 22:41:48.226039
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    a = InvalidUsage('abcd')
    print(type(a))
    print(a)
    print(a.args)

# test_InvalidUsage()

# Generated at 2022-06-21 22:41:50.623369
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("404 Not Found")
    except NotFound as e:
        assert e.status_code == 404


# Generated at 2022-06-21 22:41:52.428909
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    le = LoadFileException("Failed to load file")
    assert le.args[0] == "Failed to load file"


# Generated at 2022-06-21 22:41:55.014595
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Payload Too Large")
    except PayloadTooLarge as err:
        assert err.status_code == 413
        assert str(err) == 'Payload Too Large'


# Generated at 2022-06-21 22:41:57.801108
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(101)
    class TestingStatus(SanicException):
        pass
    assert TestingStatus.status_code == 101
    assert TestingStatus(message='test 101').status_code == 101
    assert TestingStatus(message='test 101').message == 'test 101'

# Generated at 2022-06-21 22:42:01.803788
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    ex = ServiceUnavailable('message')
    assert not hasattr(ex, 'headers')
    assert ex.message == 'message'
    ex = ServiceUnavailable('message', headers={'key': 'value'})
    assert ex.headers == {'key': 'value'}


# Generated at 2022-06-21 22:42:09.069019
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Create a new instance of class RequestTimeout with default parameter
    request_timeout_1 = RequestTimeout(message = "test_message")
    # Create a new instance of class RequestTimeout
    request_timeout_2 = RequestTimeout(message = "test_message", status_code = 408)
    # Create a new instance of class RequestTimeout
    request_timeout_3 = RequestTimeout(message = "test_message", status_code = 408, quiet = False)
    if (request_timeout_1.status_code != 408) or (request_timeout_2.status_code != 408) or (request_timeout_3.status_code != 408):
        return False
    if (request_timeout_1.quiet != True) or (request_timeout_2.quiet != True) or (request_timeout_3.quiet != False):
        return False

# Generated at 2022-06-21 22:42:15.547395
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class Test(SanicException):
        pass

    assert _sanic_exceptions.get(200) == Test
    assert _sanic_exceptions.get(200).status_code == 200



# Generated at 2022-06-21 22:42:20.856820
# Unit test for function abort
def test_abort():
    import pytest
    with pytest.raises(SanicException) as e:
        abort(403, "I am hungry")
    assert e.value.status_code == 403
    assert e.value.message == "I am hungry"

# Generated at 2022-06-21 22:42:25.341665
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    test_str = "InvalidUsage."
    test_code = 400
    err = InvalidUsage(test_str, test_code)
    assert err.status_code == test_code
    assert str(err) == test_str


# Generated at 2022-06-21 22:42:26.564929
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    Sanic_exception = ServiceUnavailable

    assert Sanic_exception is not None



# Generated at 2022-06-21 22:42:35.542847
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    test_value1 = LoadFileException
    test_value2 = LoadFileException('LoadFileException')
    assert isinstance(test_value1, SanicException), 'LoadFileException is not a subtype of SanicException.'
    assert isinstance(test_value2, SanicException), 'LoadFileException is not a subtype of SanicException.'
    assert test_value2.args[0] == 'LoadFileException', 'LoadFileException is not the right argument in LoadFileException.'


# Generated at 2022-06-21 22:42:37.276974
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(Exception):
        raise PyFileError("could not execute config file")

# Generated at 2022-06-21 22:42:40.354806
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    e = HeaderNotFound("msg")
    assert e.status_code == 400
    assert e.message == "msg"

# Generated at 2022-06-21 22:42:44.119514
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage("message", status_code=400, quiet=True)
    assert error.status_code == 400
    assert error.message == "message"

# Generated at 2022-06-21 22:42:45.818734
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    x = InvalidUsage("Alert")
    assert x.message == "Alert"


# Generated at 2022-06-21 22:42:53.863934
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # With a Basic auth-scheme, realm MUST be present.
    msg = "Auth required."
    exc = Unauthorized(msg,
                       scheme="Basic",
                       realm="Restricted Area")
    assert exc.status_code == 401
    assert exc.message == msg
    assert exc.headers["WWW-Authenticate"] == \
        'Basic realm="Restricted Area"'

    # With a Digest auth-scheme, things are a bit more complicated.
    msg = "Auth required."
    exc = Unauthorized(msg,
                       scheme="Digest",
                       realm="Restricted Area",
                       qop="auth, auth-int",
                       algorithm="MD5",
                       nonce="abcdef",
                       opaque="zyxwvu")
    assert exc.status_code == 401
    assert exc.message == msg

# Generated at 2022-06-21 22:42:57.576616
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("auth required")
    except Forbidden as e:
        assert e.args[0] == "auth required"
        assert e.status_code == 403

# Generated at 2022-06-21 22:43:03.528662
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exc = InvalidSignal("error.")
    assert str(exc) == "error."
    assert exc.status_code == 500
    assert exc.quiet == False

# Generated at 2022-06-21 22:43:05.313749
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal()
    except InvalidSignal:
        return True
    assert False

# Generated at 2022-06-21 22:43:07.524103
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError("filename")
    assert e.args[0] == "could not execute config file %s"
    assert e.args[1] == "filename"

# Generated at 2022-06-21 22:43:11.088004
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    with pytest.raises(Exception) as exception:
        raise InvalidSignal(message="Invalid signal handler")
    assert str(exception.value) == "Invalid signal handler"

# Generated at 2022-06-21 22:43:15.712508
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge("Payload Too Large")
    except PayloadTooLarge as exception:
        assert exception.message == "Payload Too Large"
        assert exception.status_code == 413
        assert exception.quiet == True


# Generated at 2022-06-21 22:43:18.127197
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("signal test")
    except InvalidSignal as e:
        assert e.__str__() == "signal test"

# Generated at 2022-06-21 22:43:22.639443
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    err = Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert err.status_code == 401
    assert err.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'
    assert str(err) == "Auth required."

# Generated at 2022-06-21 22:43:25.660622
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("a")
    except RequestTimeout as e:
        assert "408" in str(e)


# Generated at 2022-06-21 22:43:29.179102
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    instance_ServiceUnavailable = ServiceUnavailable("Service Unavailable")
    assert(instance_ServiceUnavailable.status_code == 503)
    assert(instance_ServiceUnavailable.message == "Service Unavailable")
    assert(instance_ServiceUnavailable.quiet == True)


# Generated at 2022-06-21 22:43:31.881525
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    """
    Tests the constructor of class InvalidRangeType
    """
    ex1 = InvalidRangeType('Error',1)
    assert ex1.message == 'Error'
    assert ex1.content_range == 1

# Generated at 2022-06-21 22:43:39.910997
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(200)
    class TestException(SanicException):
        pass

    try:
        raise TestException("testing")
    except TestException as e:
        assert e.status_code == 200
    assert 200 in _sanic_exceptions
    assert _sanic_exceptions[200] is TestException



# Generated at 2022-06-21 22:43:41.376723
# Unit test for constructor of class Forbidden
def test_Forbidden():

    exception = Forbidden("hello, world")
    assert exception.message == "hello, world"

# Generated at 2022-06-21 22:43:44.044958
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout) as e_info:
        raise RequestTimeout('timeout')
    assert str(e_info.value) == 'timeout'


# Generated at 2022-06-21 22:43:47.878421
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    lfe = LoadFileException("Message")
    assert lfe.status_code == 500
    assert lfe.args[0] == "Message"
    lfe = LoadFileException("Message", status_code=400)
    assert lfe.status_code == 400
    assert lfe.args[0] == "Message"

# Generated at 2022-06-21 22:43:57.007271
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException):
        abort(999, "Invalid status code")
    for code in STATUS_CODES:
        if code in _sanic_exceptions:
            with pytest.raises(_sanic_exceptions[code]):
                abort(code)
        else:
            with pytest.raises(SanicException):
                abort(code)
        # This will be removed in 3.1
        with pytest.raises(SanicException):
            abort(code, "Invalid")
    # This will be removed in 3.1
    with pytest.warns(DeprecationWarning):
        abort(999)

# Generated at 2022-06-21 22:43:59.050248
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Server Error')
    except ServerError as e:
        assert str(e) == 'Server Error'

# Generated at 2022-06-21 22:44:03.056858
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    # use default constructor
    test1 = HeaderExpectationFailed()
    print(test1)
    # use none string parameter
    test2 = HeaderExpectationFailed(None)
    print(test2)
    # use none string parameter
    test3 = HeaderExpectationFailed("")
    print(test3)


# Generated at 2022-06-21 22:44:15.015562
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class TestException1(SanicException):
        pass

    exc_class = TestException1(
        message="Test1", status_code=404, quiet=True
    )
    assert exc_class.status_code == 404
    assert exc_class.quiet == True

    @add_status_code(400)
    class TestException2(SanicException):
        pass

    exc_class = TestException2(message="Test2")
    assert exc_class.status_code == 400
    assert exc_class.quiet == True

    # add_status_code is called on a class that is not a subclass of
    # SanicException, but the method doesn't error out
    @add_status_code(405)
    class TestException3():
        pass

    assert TestException3.status

# Generated at 2022-06-21 22:44:18.838572
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("something went wrong!")
    except HeaderNotFound as e:
        assert e.status_code == 400
        assert e.message == "something went wrong!"
        assert e.args[0] == "something went wrong!"
        assert isinstance(e, SanicException)


# Generated at 2022-06-21 22:44:23.831028
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    hf = HeaderExpectationFailed("Custom Header Fail", status_code=417, quiet=True)
    hf.message = "XXXXXXXXXX"
    hf.status_code = 418
    if hf.message != "XXXXXXXXXX" or hf.status_code != 418:
        print("Test Failed")
    else:
        print("Test Succeeded")


# Generated at 2022-06-21 22:44:35.040558
# Unit test for function add_status_code
def test_add_status_code():
    # Save the original STATUS_CODES in a global variable
    global original_STATUS_CODES
    original_STATUS_CODES = STATUS_CODES

    # Test for status code in STATUS_CODES
    add_status_code(404)
    global _sanic_exceptions_test
    _sanic_exceptions_test = _sanic_exceptions

    # Revert changes to STATUS_CODES
    STATUS_CODES = original_STATUS_CODES

# Generated at 2022-06-21 22:44:36.938326
# Unit test for constructor of class ServerError
def test_ServerError():
	errorMsg = "This is a test for ServerError class"
	assert errorMsg == errorMsg

# Generated at 2022-06-21 22:44:39.627586
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('header not found')
        # assert(False)
    except HeaderNotFound as e:
        print(type(e))
    finally:
        print('header not found.')


# Generated at 2022-06-21 22:44:43.308851
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("error", "range")

    except InvalidRangeType as e:
        assert e.message == "error"
        assert e.headers == {"Content-Range": "bytes */range"}

# Generated at 2022-06-21 22:44:47.756695
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException("it's a error",status_code=404,quiet=False)
    assert exception.message == "it's a error"
    assert exception.status_code == 404
    assert exception.quiet == False


# Generated at 2022-06-21 22:44:49.185122
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert str(RequestTimeout("test")) == "test"



# Generated at 2022-06-21 22:44:58.941154
# Unit test for function abort
def test_abort():
    try:
        abort(status_code=500)
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "INTERNAL SERVER ERROR"

    try:
        abort(status_code=404)
    except SanicException as e:
        assert e.status_code == 404
        assert e.message == "NOT FOUND"

    try:
        abort(status_code=500, message="my exception")
    except SanicException as e:
        assert e.status_code == 500
        assert e.message == "my exception"

    try:
        abort(status_code=504, message="my exception")
    except SanicException as e:
        assert e.status_code == 504
        assert e.message == "my exception"



# Generated at 2022-06-21 22:45:02.239655
# Unit test for constructor of class PyFileError
def test_PyFileError():
    message = "could not execute config file /path/to/file_name.py"
    assert str(PyFileError("/path/to/file_name.py")) == message

# Generated at 2022-06-21 22:45:12.868831
# Unit test for function abort
def test_abort():
    """
    A simple test for `abort` function.
    """
    try:
        abort(404, 'test')
    except NotFound as err:
        assert err.message == 'test'
        assert err.status_code == 404
        assert err.quiet is True
    else:
        assert False, '404 should raise NotFound exception'

    try:
        abort(500, 'test')
    except ServerError as err:
        assert err.message == 'test'
        assert err.status_code == 500
        assert err.quiet is False
    else:
        assert False, '500 should raise ServerError exception'

    try:
        abort(600, 'test')
    except SanicException as err:
        assert err.message == 'test'
        assert err.status_code == 600
        assert err.quiet is False

# Generated at 2022-06-21 22:45:14.778904
# Unit test for function abort
def test_abort():
    global status_code
    with pytest.raises(SanicException):
        abort(status_code, message="Invalid HTTP Status Code")

_test_abort_request = test_abort()

# Generated at 2022-06-21 22:45:23.874855
# Unit test for constructor of class ServerError
def test_ServerError():
    # Test of constructor when message is provided, status code is not provided
    ServerError(message="test message")
    # Test of constructor when message is not provided, status code is provided
    ServerError(message=None, status_code=500)
    # Test of constructor when message is provided, status code is also provided
    ServerError(message="test message", status_code=500)


# Generated at 2022-06-21 22:45:26.362826
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    except_object = HeaderExpectationFailed("Warning, message!", 1)
    assert except_object.status_code == 417
    assert except_object.message == "Warning, message!"

# Generated at 2022-06-21 22:45:28.670912
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with raises(InvalidUsage):
        raise InvalidUsage()

# Generated at 2022-06-21 22:45:32.824339
# Unit test for constructor of class ServerError
def test_ServerError():
    test = ServerError("message", "status_code", "quiet")
    assert test.__str__() == 'message'
    assert test.status_code == 'status_code'
    assert test.quiet == 'quiet'


# Generated at 2022-06-21 22:45:34.852005
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("Error")
    if e.args[0] != "Error":
        raise Exception("Failed to create an instance of URLBuildError")

# Generated at 2022-06-21 22:45:37.293831
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Server Error")
    except ServerError as se:
        assert se.status_code == 500
        assert se.message == "Server Error"

# Generated at 2022-06-21 22:45:38.793676
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        abort(403, "Forbidden")


# Generated at 2022-06-21 22:45:39.926390
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    error = InvalidUsage("error")
    assert error.status_code == 400

# Generated at 2022-06-21 22:45:42.415019
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    new_HeaderExpectationFailed = HeaderExpectationFailed('expectation failed', 400) # Constructor with message and status_code as parameters
    assert isinstance(new_HeaderExpectationFailed, SanicException) # Test if it is a subclass of SanicException


# Generated at 2022-06-21 22:45:43.940566
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    r = ContentRangeError(message="test message",content_range="1 to 100")

# Generated at 2022-06-21 22:45:57.810113
# Unit test for constructor of class Unauthorized

# Generated at 2022-06-21 22:46:02.080500
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError(
            message = "Content-length invalid", content_range = 0)
    except ContentRangeError as e:
        assert e.message == "Content-length invalid"
        assert e.status_code == 416
        assert e.headers["Content-Range"] == "bytes */0"


# Generated at 2022-06-21 22:46:03.965883
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden('Test Forbidden')
    except Forbidden:
        assert True
    except:
        assert False


# Generated at 2022-06-21 22:46:05.490251
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden("this is my message")
    assert forbidden.message == "this is my message"
    assert forbidden.status_code == 403

# Generated at 2022-06-21 22:46:11.384520
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    sa = ServiceUnavailable('message', status_code=503, quiet=True)
    assert(sa.status_code == 503)
    assert(sa.quiet == True)
    assert(sa.message == 'message')
    assert(str(sa) == 'message')
    sa = ServiceUnavailable('message', status_code=503, quiet=False)
    assert(sa.status_code == 503)
    assert(sa.quiet == False)
    assert(sa.message == 'message')
    assert(str(sa) == 'message')
    sa = ServiceUnavailable('message', status_code=503)
    assert(sa.status_code == 503)
    assert(sa.quiet == True)
    assert(sa.message == 'message')
    assert(str(sa) == 'message')

# Generated at 2022-06-21 22:46:14.093211
# Unit test for constructor of class NotFound
def test_NotFound():
    assert NotFound.status_code == 404
    assert NotFound.quiet == True
    assert _sanic_exceptions[404] == NotFound


# Generated at 2022-06-21 22:46:19.048344
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    body = '''{
        "foo": "bar",
        "status_code": 404,
        "message": "The foo is not found."
    }'''
    exception = LoadFileException(body)
    assert exception.status_code == 404
    assert exception.message == body
    assert str(exception) == body
    assert exception.__repr__() == 'LoadFileException: status code = 404, message = ' + body



# Generated at 2022-06-21 22:46:21.202997
# Unit test for constructor of class ServerError
def test_ServerError():
    exc = ServerError("error")
    assert exc.status_code == 500

# Generated at 2022-06-21 22:46:24.987698
# Unit test for constructor of class SanicException
def test_SanicException():
    my_exception = SanicException("This is a test", status_code=404, quiet=True)
    assert my_exception.message == "This is a test"
    assert my_exception.status_code == 404
    assert my_exception.quiet == True



# Generated at 2022-06-21 22:46:26.948779
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("some message")
    except URLBuildError as u:
        assert u.args == ("some message",)

# Generated at 2022-06-21 22:46:35.720823
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    server_error_message = (
        "This method is not supported on this server,"
        "it should not reach this message class"
    )
    method = "GET"
    allowed_methods = ["POST"]
    methodNotSupported = MethodNotSupported(server_error_message, method, allowed_methods)
    assert methodNotSupported
    assert methodNotSupported.status_code == 405

# Generated at 2022-06-21 22:46:37.166249
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    assert InvalidSignal(message="No existe ninguna señal con ese nombre", status_code=405)

# Generated at 2022-06-21 22:46:39.027274
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException("test", 400)
    assert e.message == "test"
    assert e.status_code == 400
    assert e.quiet is True



# Generated at 2022-06-21 22:46:41.937831
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound
    except HeaderNotFound as hnfe:
        assert type(hnfe) == HeaderNotFound

# Generated at 2022-06-21 22:46:44.567598
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("/path/to/file")
    except PyFileError as err:
        assert (str(err) == "could not execute config file /path/to/file")

# Generated at 2022-06-21 22:46:45.723085
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    a = InvalidRangeType("invalid range type",0)
    print(a.headers)

# Generated at 2022-06-21 22:46:47.935426
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound("file not found")
    except FileNotFound as fnf:
        assert "file not found" == fnf.args[0]

# Generated at 2022-06-21 22:46:49.072245
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException("testing")

# Generated at 2022-06-21 22:46:51.797903
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("abc")
    except InvalidSignal as e:
        assert e.args[0] == "abc"

# Generated at 2022-06-21 22:46:53.310171
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("Message")
    assert error.status_code == 500
    assert not error.quiet


# Generated at 2022-06-21 22:47:07.241683
# Unit test for function add_status_code
def test_add_status_code():
    status_code = 100
    add_status_code(status_code)(SanicException)
    tmp = SanicException
    tmp.status_code = status_code
    assert tmp.status_code == status_code
    tmp.status_code = 500

    add_status_code(status_code, False)(SanicException)
    assert SanicException.status_code == status_code
    assert SanicException.quiet is False
    SanicException.status_code = 500
    SanicException.quiet = None

# Generated at 2022-06-21 22:47:08.898795
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("message")
    assert e.__str__() == "message"
    assert isinstance(e, ServerError)

# Generated at 2022-06-21 22:47:16.103701
# Unit test for constructor of class SanicException
def test_SanicException():
    # The top-level functions abort() and add_status_code() will have their
    # own unit tests.
    assert issubclass(SanicException, BaseException)
    # The constructor of SanicException() has one required, one optional,
    # and three optional+default parameters
    me = SanicException("Testing")
    assert me.args[0] == "Testing"
    assert me.status_code is None
    assert me.quiet is False
    # TODO: Does SanicException() get called anywhere in the code base?
    # TODO: If not, should this function be removed?


# Generated at 2022-06-21 22:47:17.135479
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("Timeout")

# Generated at 2022-06-21 22:47:22.098534
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("message", "content_range")
    except SanicException as e:
        assert(e.status_code == 416)
        assert(e.message == "message")
        assert(e.headers == {"Content-Range": "bytes */content_range"})

# Generated at 2022-06-21 22:47:25.137755
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("123")
    except HeaderExpectationFailed as header_expectation_failed:
        assert header_expectation_failed.status_code == 417



# Generated at 2022-06-21 22:47:27.785059
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.",
                           scheme="Basic",
                           realm="Restricted Area")
    except Unauthorized:
        assert True


# Generated at 2022-06-21 22:47:31.474052
# Unit test for constructor of class ServerError
def test_ServerError():
    # When
    expected_message = "Server error occurred"
    server_error = ServerError(message=expected_message)
    # Then
    assert server_error.status_code == 500
    assert str(server_error) == expected_message


# Generated at 2022-06-21 22:47:34.182289
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    payload_too_large = PayloadTooLarge("This is an test!","hoge")
    assert payload_too_large.quiet == True


# Generated at 2022-06-21 22:47:43.215714
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError(u"test_urlbuilderror")
    except URLBuildError as e:
        print(e)
    try:
        raise ServerError(u"test_servererror")
    except ServerError as e:
        print(e)
    try:
        raise SanicException(u"test_sanicexception", 505)
    except SanicException as e:
        print(e)
    try:
        raise InvalidUsage(u"test_invalidusage")
    except InvalidUsage as e:
        print(e)
    try:
        raise MethodNotSupported(u"test_methodnotsupported", 'GET', ['POST'])
    except MethodNotSupported as e:
        print(e)

# Generated at 2022-06-21 22:47:58.786503
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    error = HeaderNotFound("error message", "header")
    assert error.status_code == 400
    assert error.message == "error message"
    assert str(error) == "Could not find header 'error message'"

# Generated at 2022-06-21 22:48:01.141173
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    a = PayloadTooLarge("message", "context")
    assert a.status_code == 413
    assert a.message == "message"
    assert a.context == "context"

# Generated at 2022-06-21 22:48:06.128196
# Unit test for function add_status_code
def test_add_status_code():
    message = 'Test Message'
    code = 405
    message2 = 'test 2'
    code2 = 503
    @add_status_code(code)
    class TestClass(SanicException):
        pass
    test = TestClass(message)
    assert test.message == message
    assert test.status_code == code
    @add_status_code(code2, quiet=True)
    class TestClass2(SanicException):
        pass
    test2 = TestClass2(message2)
    assert test2.quiet
    assert test2.status_code == code2
    assert test2.message == message2

# Generated at 2022-06-21 22:48:10.138301
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("test forbidden exception handling")
    except Forbidden as e:
        assert e.message == 'test forbidden exception handling'
        assert e.status_code == 403
        assert e.quiet == True

# Generated at 2022-06-21 22:48:16.181619
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # Test for constructor ServiceUnavailable
    try:
        raise ServiceUnavailable("Service Unavailable", quiet=True)
    except (ServiceUnavailable) as err:
        assert str(err) == "Service Unavailable"
        assert err.status_code == 503
        assert err.quiet == True


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 22:48:20.423078
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    invalid_range_type = InvalidRangeType("testing message", range(1,10,1))
    assert isinstance(invalid_range_type, ContentRangeError)
    assert str(invalid_range_type) == "testing message"
    assert invalid_range_type.status_code == 416
    assert invalid_range_type.headers == {"Content-Range": "bytes */9"}

# Generated at 2022-06-21 22:48:23.464875
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "Error"
    relative_url = "/"
    path = "./test"
    fileNotFound = FileNotFound(message, relative_url, path)

    assert fileNotFound.message == message
    assert fileNotFound.relative_url == relative_url
    assert fileNotFound.path == path

# Generated at 2022-06-21 22:48:34.665429
# Unit test for constructor of class SanicException
def test_SanicException():
    msg = 'message'
    # Test constructor of SanicException
    exception = SanicException(message=msg)
    assert exception.status_code == None
    assert exception.message == msg 

# selftest
if __name__ == "__main__":
    # Test constructor of SanicException
    exception = SanicException(message='message')
    assert exception.status_code == None
    assert exception.message == 'message'
    # Test constructor of SanicException with status_code=500
    exception = SanicException(message='message', status_code=500)
    assert exception.status_code == 500
    assert exception.message == 'message'
    # Test constructor of SanicException with quiet=True
    exception = SanicException(message='message', quiet=True)
    assert exception.status_code == None
   

# Generated at 2022-06-21 22:48:38.119315
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(
            "Header Expectation Failed", "HeaderExpectationFailed")
    except HeaderExpectationFailed as err:
        assert err.status_code == 417



# Generated at 2022-06-21 22:48:41.104072
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("SanicException message test")
    except SanicException as e:
        assert e.args[0] == "SanicException message test"


# Generated at 2022-06-21 22:49:12.962592
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        #test_notFound = NotFound("test message")
        raise NotFound("test message")

    except NotFound as notFound :
        print(notFound.name)
        print(notFound.message)
        print(notFound.status_code)



# Generated at 2022-06-21 22:49:15.441781
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout(message="Bad request")
    except RequestTimeout as e:
        assert(e.message == "Bad request")
        assert(e.status_code == 408)


# Generated at 2022-06-21 22:49:18.075196
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Test the constructor
    result = URLBuildError('http')
    assert result.status_code == 500
    assert result.message == 'http'
    assert result.quiet == True


# Generated at 2022-06-21 22:49:19.606581
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    a = InvalidSignal('invalid signal')
    assert str(a) == 'invalid signal'


# Generated at 2022-06-21 22:49:23.148640
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    expected_code = 503
    message = 'Server Unavailable'
    sa_object = ServiceUnavailable(message=message, status_code=expected_code)
    assert(sa_object.status_code == expected_code and sa_object.message == message)


# Generated at 2022-06-21 22:49:25.756290
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException(message='test-message')
    except SanicException as e:
        assert e.message == 'test-message'

# Generated at 2022-06-21 22:49:31.726713
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    e = FileNotFound("file not found", "/a/b/c.txt", "c.txt")
    assert e.path == "/a/b/c.txt"
    assert e.relative_url == "c.txt"
    assert str(e) == "file not found"

if __name__ == "__main__":
    test_FileNotFound()

# Generated at 2022-06-21 22:49:34.951521
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('Invalid usage', status_code=400)
    except InvalidUsage as err:
        assert err.status_code == 400
        assert err.message == 'Invalid usage'


# Generated at 2022-06-21 22:49:37.440068
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    try:
        raise InvalidUsage('dummy', status_code=404)
    except InvalidUsage as error:
        assert error is not None
        assert error.status_code == 404


# Generated at 2022-06-21 22:49:38.219429
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException()
