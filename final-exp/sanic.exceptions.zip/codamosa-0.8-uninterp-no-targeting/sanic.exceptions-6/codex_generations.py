

# Generated at 2022-06-21 22:40:05.605121
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(code=101, quiet=True)
    class Error(SanicException):
        pass
    assert Error.status_code == 101
    assert _sanic_exceptions[101] == Error

# Generated at 2022-06-21 22:40:10.551987
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("expected format: bytes [first]-[last]/[total]")
    assert error.headers == { "Content-Range": "bytes */0" }
    error = ContentRangeError("expected format: bytes [first]-[last]/[total]", 100)
    assert error.headers == { "Content-Range": "bytes */100" }

# Generated at 2022-06-21 22:40:15.171443
# Unit test for constructor of class SanicException
def test_SanicException():
    exception = SanicException("Message")
    assert exception.message == "Message"

    exception = SanicException("Message", status_code=403)
    assert exception.message == "Message"
    assert exception.status_code == 403

    exception = SanicException("Message", quiet=True)
    assert exception.message == "Message"
    assert exception.quiet == True


# Generated at 2022-06-21 22:40:17.032966
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pyfileerror = PyFileError("file")



# Generated at 2022-06-21 22:40:30.324936
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    message = "Auth required."

    # With a Basic auth-scheme, realm MUST be present:
    with pytest.raises(Unauthorized) as exc_info:
        raise Unauthorized(message,
                           scheme="Basic",
                           realm="Restricted Area")
    assert 'Auth required.' in str(exc_info.value)
    assert exc_info.value.status_code == 401
    assert exc_info.value.headers == {
        'WWW-Authenticate': 'Basic realm="Restricted Area"'
    }

    # With a Digest auth-scheme, things are a bit more complicated:

# Generated at 2022-06-21 22:40:41.306180
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class TestException(SanicException):
        pass
    assert TestException.status_code == 100
    assert TestException().status_code == 100
    assert TestException.quiet is True
    # Allowed quiet values are None/False/True with None meaning choose based on status_code
    for quiet in [None, True, False]:
        @add_status_code(200, quiet=quiet)
        class TestException(SanicException):
            pass
        if quiet is None:
            assert TestException.quiet is True
        else:
            assert TestException.quiet is quiet
        assert TestException.status_code == 200
        assert TestException().status_code == 200

# Generated at 2022-06-21 22:40:44.782399
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    try:
        raise MethodNotSupported("Method not supported.", "POST", ["GET"])
    except MethodNotSupported as e:
        assert e.headers["Allow"] == "GET"
        assert e.message == "Method not supported."


# Generated at 2022-06-21 22:40:51.158638
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    """
    Tests if the __init__ function from MethodNotSupported class
    works properly.
    """
    # Check if class MethodNotSupported is properly
    # constructed without headers.
    for method in ['GET', 'POST', 'PUT', 'DELETE']:
        with pytest.raises(MethodNotSupported):
            raise MethodNotSupported("Server error", method, [method])

    # Check if class MethodNotSupported is properly
    # constructed without headers.
    for method in ['GET', 'POST', 'PUT', 'DELETE']:
        with pytest.raises(MethodNotSupported) as exc_info:
            raise MethodNotSupported("Server error", method, [method])
        assert exc_info.value.headers == {'Allow': method}



# Generated at 2022-06-21 22:40:53.623965
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("message")
    except Forbidden as e:
        assert e.__str__() == "message"
        assert e.status_code == 403
        assert e.quiet


# Generated at 2022-06-21 22:40:59.025949
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed("abc")
        assert False
    except HeaderExpectationFailed as e:
        assert e.status_code == 417
        assert e.message == "abc"
        assert e.__str__() == "abc"
        assert e.quiet == True


# Generated at 2022-06-21 22:41:02.150600
# Unit test for constructor of class PyFileError
def test_PyFileError():
    fe = PyFileError("Failed")
    assert str(fe) == "could not execute config file Failed"

# Generated at 2022-06-21 22:41:03.728525
# Unit test for constructor of class PyFileError
def test_PyFileError():
    e = PyFileError("test")
    assert e.args[0] == "could not execute config file %s"
    assert e.args[1] == "test"


# Generated at 2022-06-21 22:41:09.407089
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Raise PyFileError, with file name
    ob = PyFileError("test_file")
    # Print PyFileError message
    try:
        print(ob.args)
        # Raise PyFileError, without file name
    except PyFileError as e:
        print(e)


test_PyFileError()

# Generated at 2022-06-21 22:41:20.400748
# Unit test for function abort
def test_abort():
    # Test message passed is returned
    try:
        abort(404, "Not found at all")
        assert False, "Should raise Error"
    except NotFound as e:
        assert e.message == "Not found at all"
        assert e.status_code == 404

    # Test a returned status code will return a message
    try:
        abort(503)
        assert False, "Should raise Error"
    except ServiceUnavailable as e:
        assert e.message == "503 Service Unavailable"
        assert e.status_code == 503

    # Test non-200 status code returned
    try:
        abort(404)
        assert False, "Should raise Error"
    except NotFound as e:
        assert e.message == "404 Not Found"
        assert e.status_code == 404

# Generated at 2022-06-21 22:41:23.564713
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('my.txt')
    except LoadFileException as e:
        assert e.args[0] == 'my.txt'


# Generated at 2022-06-21 22:41:29.728243
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("not found")
    except NotFound as exception:
        assert exception.status_code == 404
        assert exception.message == "not found"

    try:
        raise NotFound("not found", status_code=400, quiet=True)
    except NotFound as exception:
        assert exception.status_code == 400
        assert exception.message == "not found"
        assert exception.quiet == True


# Generated at 2022-06-21 22:41:33.548251
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():

    payloadTooLarge = PayloadTooLarge("Payload Too Large", 52428800)

    assert payloadTooLarge.message == "Payload Too Large"
    assert payloadTooLarge.status_code == 413
    assert payloadTooLarge.quiet == True
    assert payloadTooLarge.headers == {"Content-Length": 52428800}


# Generated at 2022-06-21 22:41:46.672264
# Unit test for function abort
def test_abort():
    """
    Test function `abort`
    """

    # Test SanicException
    with pytest.raises(SanicException) as exc_info:
        # status code 500
        abort(500)
        assert str(exc_info.value) == 'Internal Server Error'

    # Test NotFound
    with pytest.raises(NotFound) as exc_info:
        # status code 404
        abort(404)
        assert str(exc_info.value) == 'Not Found'

    # Test InvalidUsage
    with pytest.raises(InvalidUsage) as exc_info:
        # status code 400
        abort(400)
        assert str(exc_info.value) == 'Bad Request'

    # Test MethodNotSupported

# Generated at 2022-06-21 22:41:49.842846
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge(message="payload size is too large than 4G",
                                status_code=413)
    assert exception.status_code == 413
    assert exception.message == "payload size is too large than 4G"

# Generated at 2022-06-21 22:41:59.066033
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    # Check if RequestTimeout throws an error when message is not passed
    try:
        r = RequestTimeout()
        assert(False)
    except TypeError as e:
        assert(True)
    # Check if RequestTimeout throws an error when message is of type int
    try:
        r = RequestTimeout(2)
        assert(False)
    except TypeError as e:
        assert(True)
    # Check if RequestTimeout throws an error when message is of type list
    try:
        r = RequestTimeout([])
        assert(False)
    except TypeError as e:
        assert(True)
    # Check if RequestTimeout throws an error when message is of type dict
    try:
        r = RequestTimeout({})
        assert(False)
    except TypeError as e:
        assert(True)
    # Check if RequestTimeout throws an

# Generated at 2022-06-21 22:42:05.491806
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError("Dummy message")

    assert err.message == "Dummy message"
    assert err.status_code == 500


# Generated at 2022-06-21 22:42:07.244294
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    err = InvalidUsage('Invalid Request')
    return err

# Generated at 2022-06-21 22:42:10.752213
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        raise HeaderExpectationFailed(message="My message")
    except HeaderExpectationFailed as her:
        assert her.status_code == 417
        assert her.message == "My message"

# Generated at 2022-06-21 22:42:24.926693
# Unit test for function abort
def test_abort():
    try:
        # if message is None, should use STATUS_CODES
        abort(404, None)
    except NotFound as e:
        # if the status code matches, should raise the corresponding
        # exception
        assert e.message == "Not Found"
        assert e.status_code == 404
        assert e.quiet is True
    try:
        # if status code is invalid, should raise SanicException
        abort(999)
    except SanicException as e:
        assert e.status_code == 999
        assert e.quiet is None
    try:
        # if status code is valid but message is invalid, should raise
        # SanicException
        abort(418, b'\x80')
    except UnicodeDecodeError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 22:42:35.236902
# Unit test for function abort
def test_abort():
    try :
        abort(404)
    except NotFound as e :
        assert e.status_code == 404
        assert e.message == 'Not Found'
        assert hasattr(e, 'quiet') and e.quiet == True
    try :
        abort(500)
    except ServerError as e :
        assert e.status_code == 500
        assert e.message == 'Internal Server Error'
        assert hasattr(e, 'quiet') and e.quiet == False
    try :
        abort(504, 'error504')
    except SanicException as e :
        assert e.status_code == 504
        assert e.message == 'error504'
        assert hasattr(e, 'quiet') and e.quiet == False

# Generated at 2022-06-21 22:42:39.946554
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("The header is not found")
    except HeaderNotFound as e:
        assert e.args[0] == "The header is not found"
        assert e.status_code == 400
    else:
        raise AssertionError("HeaderNotFound exception is not raised")

if __name__ == "__main__":
    import pytest

    pytest.main(["-s", __file__])

# Generated at 2022-06-21 22:42:45.351233
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    error = MethodNotSupported("An error message", method="GET", allowed_methods=["POST", "DELETE"])
    assert error.args[0] == "An error message"
    assert error.headers == {"Allow": "POST, DELETE"}


# Generated at 2022-06-21 22:42:49.612576
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Bad Gateway')
    except ServerError as e:
        assert str(e) == 'Bad Gateway'
        assert e.status_code == 500
    try:
        raise ServerError('Gateway Timeout', 504)
    except ServerError as e:
        assert str(e) == 'Gateway Timeout'
        assert e.status_code == 504


# Generated at 2022-06-21 22:42:55.335506
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException) as ex:
        abort(400)
    assert ex.value.status_code == 400
    assert ex.value.message == "Bad Request"

    with pytest.raises(NotFound):
        abort(404)
    with pytest.raises(InvalidUsage):
        abort(400)

    with pytest.raises(PayloadTooLarge):
        abort(413)



# Generated at 2022-06-21 22:42:59.084304
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound("Missing header.")
    except HeaderNotFound as header_not_found:
        assert header_not_found.status_code == 400

# Generated at 2022-06-21 22:43:18.915929
# Unit test for function add_status_code
def test_add_status_code():
    class TestClass(SanicException):
        pass

    # add status code first
    add_status_code(200)(TestClass)

    # add status code second
    new_code = 500

    @add_status_code(new_code)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == new_code
    assert _sanic_exceptions[new_code] == TestClass

    # add status code with quiet=True
    new_code = 501

    @add_status_code(new_code, quiet=True)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == new_code
    assert _sanic_exceptions[new_code] == TestClass
    assert TestClass.quiet is True

# Generated at 2022-06-21 22:43:22.116262
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    msg = 'Payload Too Large'
    ptl = PayloadTooLarge(msg)
    assert ptl.status_code == 413
    assert ptl.message == msg

# Generated at 2022-06-21 22:43:27.023427
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(404)
    class NotFound(SanicException):
        pass
    assert NotFound().status_code == 404
    assert NotFound(status_code=400).status_code == 400
    assert NotFound(status_code=500, quiet=True).quiet

# Generated at 2022-06-21 22:43:29.044214
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    test = HeaderNotFound('test')
    assert test.message == 'test'
    assert test.status_code == 400


# Generated at 2022-06-21 22:43:31.420860
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('The server is currently down for maintenance.')
    except ServerError as e:
        assert e.status_code == 500


# Generated at 2022-06-21 22:43:35.883991
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Test the constructor of class InvalidRangeType.
    sanic_exception = InvalidRangeType(message="Range Not Satisfiable", 
        content_range="bytes */100")
    # Test the property of class InvalidRangeType
    assert sanic_exception.message == "Range Not Satisfiable" and \
        sanic_exception.content_range == "bytes */100" and \
        sanic_exception.headers == {"Content-Range": "bytes */100"}


# Generated at 2022-06-21 22:43:39.646419
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    message = "test url build error"
    urlbuild_error = URLBuildError(message)
    assert urlbuild_error.status_code == 500
    assert str(urlbuild_error) == message

# Generated at 2022-06-21 22:43:43.214251
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported("message","method","allowed_methods")
    assert mns.message == "message"
    assert mns.method == "method"
    assert mns.allowed_methods == "allowed_methods"

# Generated at 2022-06-21 22:43:46.835715
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout) as e:
        raise RequestTimeout('The connection has timed out')
    assert e.value.message == 'The connection has timed out'
    assert e.value.status_code == 408
    assert e.value.quiet == True


# Generated at 2022-06-21 22:43:48.079077
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage):
        raise InvalidUsage("InValidUsage test")

# Generated at 2022-06-21 22:44:05.588396
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    a = InvalidSignal('Invalid Signal!')
    assert a.status_code == 500
    assert a.message == 'Invalid Signal!'
    assert a.quiet == True


# Generated at 2022-06-21 22:44:14.409161
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException("Test Message", status_code=500, quiet=False) is not None
    assert SanicException("Test Message", status_code=500, quiet=True) is not None
    assert SanicException("Test Message", status_code=500, quiet=None) is not None
    assert SanicException("Test Message", status_code=404, quiet=False) is not None
    assert SanicException("Test Message", status_code=404, quiet=True) is not None
    assert SanicException("Test Message", status_code=404, quiet=None) is not None


# Generated at 2022-06-21 22:44:16.316608
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    exception = PayloadTooLarge()
    assert exception.status_code == 413


# Generated at 2022-06-21 22:44:18.830946
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    err = ServiceUnavailable("The server is currently unavailable")
    assert err.message == "The server is currently unavailable"


# Generated at 2022-06-21 22:44:22.096367
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    Ex = InvalidUsage('invalid name', status_code = 400)
    assert Ex.__str__() == 'invalid name'
    assert Ex.status_code == 400
    assert Ex.quiet == True

# Generated at 2022-06-21 22:44:24.690174
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout("Request timeout", 408)
    assert(rt.status_code == 408)
    assert(rt.quiet == True)
    assert(rt.message == "Request timeout")


# Generated at 2022-06-21 22:44:26.463507
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("message", 100)
    except ContentRangeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 22:44:27.782707
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal()
    except InvalidSignal:
        pass


# Generated at 2022-06-21 22:44:29.729206
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        RequestTimeout('message')
    except RequestTimeout as e:
        assert True
    
test_RequestTimeout()

# Generated at 2022-06-21 22:44:34.839137
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("error_message", "/tmp/exception.py")
    except LoadFileException as load_file_error:
        assert "error_message" == load_file_error.args[0]
        assert "/tmp/exception.py" == load_file_error.args[1]

# Generated at 2022-06-21 22:45:09.712088
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError(message="Server error")
    except ServerError as e:
        assert "Server error" == e.args[0]
        assert 500 == e.status_code

# Generated at 2022-06-21 22:45:12.799846
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    # Check if constructor of class InvalidSignal works correctly
    try:
        raise InvalidSignal('Boom')
    except InvalidSignal as e:
        assert e.args[0] == 'Boom'


# Generated at 2022-06-21 22:45:14.453076
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden()
    except Forbidden as f:
        assert f.status_code == 403

# Generated at 2022-06-21 22:45:16.249714
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    exception = HeaderNotFound('message')
    assert exception.status_code == 400
    assert str(exception) == 'message'


# Generated at 2022-06-21 22:45:19.205844
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    exception = ContentRangeError(message="msg", content_range=1)
    assert exception.headers == {"Content-Range": "bytes */1"}

# Generated at 2022-06-21 22:45:23.506343
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("")
    except SanicException as e:
        assert e.status_code==503, "Service Unavailable status code expected."
        assert e.message=="", "Empty message expected."


# Generated at 2022-06-21 22:45:26.099284
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    """
    Test if the constructor of class HeaderExpectationFailed works properly
    """
    message = "Testing the constructor of HeaderExpectationFailed"
    HeaderExpectationFailed(message)

# Generated at 2022-06-21 22:45:30.051425
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound) as _exc:
        abort(404)
    assert "Not Found" in _exc.value.args[0]

# Generated at 2022-06-21 22:45:34.372441
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError('dummy')
    except PyFileError as error:
        assert error.args[0]  # == 'could not execute config file %s'
        assert error.args[1]  # == 'dummy'



# Generated at 2022-06-21 22:45:35.592315
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['OPTIONS', 'POST']
    MethodNotSupported('error message', 'GET', allowed_methods)

# Generated at 2022-06-21 22:46:47.426418
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden("message").status_code == 403
    assert Forbidden("message", status_code=403).status_code == 403
    assert Forbidden("message", quiet=True).status_code == 403
    assert Forbidden("message", quiet=True, status_code=403).status_code == 403
    assert Forbidden("message").message == "message"
    assert Forbidden("message").quiet is False
    assert Forbidden("message", quiet=True).quiet is True

# Generated at 2022-06-21 22:46:48.957964
# Unit test for constructor of class Forbidden
def test_Forbidden():
    with pytest.raises(Forbidden):
        raise Forbidden("test message", 403)


# Generated at 2022-06-21 22:46:51.432837
# Unit test for constructor of class Forbidden
def test_Forbidden():
  try:
    a = Forbidden("Forbidden")
  except Exception as e:
    if str(e)!="'Forbidden'":
      raise Exception("Wrong exception raised")
  else:
    raise Exception("Exception not raised")

# Generated at 2022-06-21 22:46:51.965917
# Unit test for constructor of class NotFound
def test_NotFound():
    NotFound('test')

# Generated at 2022-06-21 22:46:53.900623
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("InvalidRangeType", "content_range")
    except InvalidRangeType:
        assert InvalidRangeType

# Generated at 2022-06-21 22:46:56.404263
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('File not found', 'path', 'relative_url')
    except FileNotFound as err:
        message = err.args[0]
        assert message == 'File not found'

# Generated at 2022-06-21 22:46:58.533536
# Unit test for constructor of class FileNotFound

# Generated at 2022-06-21 22:47:01.498642
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    x = InvalidRangeType("hello", "world")
    assert x.message == "hello"
    assert x.headers == {"Content-Range": "bytes */world"}
    # TODO: assert x.status_code is 416

# Generated at 2022-06-21 22:47:06.999752
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    print("----------- test_InvalidUsage -----------")
    a = InvalidUsage(message="Invalid request body", status_code=400, quiet=True)
    print(a.message)
    print(a.status_code)
    print(a.quiet)
    print(type(a))


# Generated at 2022-06-21 22:47:08.799590
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    """
    Test for constructor of class LoadFileException
    """
    try:
        raise LoadFileException('content')
    except Exception as e:
        assert str(e) == 'content'

# Generated at 2022-06-21 22:49:41.350097
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    try:
        raise PayloadTooLarge('Payload is too large.')
    except PayloadTooLarge as e:
        assert e.status_code == 413
        assert e.quiet is True
        assert e.message == 'Payload is too large.'


# Generated at 2022-06-21 22:49:43.442096
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    msg = 'ContentRangeError'
    content_range = 25
    test_exc = ContentRangeError(msg, content_range)
    assert test_exc.headers == {
        "Content-Range": f"bytes */{content_range}"
    }

# Generated at 2022-06-21 22:49:47.106160
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('file not found', 'index.html', '/static/index.html')
    except FileNotFound as e:
        assert e.status_code == 404
        assert e.path == 'index.html'
        assert e.relative_url == '/static/index.html'


# Generated at 2022-06-21 22:49:51.828633
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("UrlBuildError")
    except Exception as e:
        assert issubclass(URLBuildError, SanicException)
        assert isinstance(e, SanicException)
        assert e.status_code == 500
        assert e.quiet == False


# Generated at 2022-06-21 22:49:53.841156
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError(Exception("Sanic Exception"))
    assert e is not None

# Generated at 2022-06-21 22:49:57.025046
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError('Test for ServerError')
    except ServerError as exception:
        assert exception.message == 'Test for ServerError'
        assert exception.status_code == 500
        assert exception.quiet == False
        assert type(exception) == ServerError


# Generated at 2022-06-21 22:50:01.355452
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    status_code = 400
    message = 'test message'
    quiet = True

    # Trigger __init__ method to initialize super class, SanicException
    obj = InvalidUsage(message=message, status_code=status_code, quiet=quiet)
    assert obj.args[0] == message
    assert obj.status_code == status_code
    assert obj.quiet == quiet
