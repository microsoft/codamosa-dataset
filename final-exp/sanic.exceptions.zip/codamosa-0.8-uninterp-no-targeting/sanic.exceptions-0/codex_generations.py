

# Generated at 2022-06-21 22:40:08.521041
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    from sanic.response import text

    @app.route('/')
    def handler(request):
        raise MethodNotSupported("POST method not supported.", "post", ["get", "put", "delete"])

    request, response = app.test_client.post('/')
    assert response.status == 405
    assert response.body == b'POST method not supported.'
    assert response.headers['Allow'] == 'get, put, delete'

# Generated at 2022-06-21 22:40:13.037941
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound(message='Test FileNotFound', path='/', relative_url='/abc')
    except FileNotFound as err:
        assert 'Test FileNotFound' == str(err)
        assert '/' == err.path
        assert '/abc' == err.relative_url


# Generated at 2022-06-21 22:40:18.232004
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exception = InvalidRangeType('message', None)
    assert exception.message == 'message'
    assert exception.status_code == 416
    assert exception.headers == {'Content-Range': 'bytes */None'}


if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-21 22:40:30.464658
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    import pytest
    # Test invocation of Unauthorized Exception with a Basic auth-scheme
    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    assert excinfo.match("Auth required.")
    # Test invocation of Unauthorized Exception with a Digest auth-scheme
    with pytest.raises(Unauthorized) as excinfo:
        raise Unauthorized("Auth required.",
                       scheme="Digest",
                       realm="Restricted Area",
                       qop="auth, auth-int",
                       algorithm="MD5",
                       nonce="abcdef",
                       opaque="zyxwvu")
    assert excinfo.match("Auth required.")
    # Test invocation of Unauthorized Exception with a Bearer auth-scheme

# Generated at 2022-06-21 22:40:33.529155
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    exc_obj = InvalidUsage(message="Internal error")
    assert exc_obj.message == "Internal error"
    assert exc_obj.status_code == 400
    assert exc_obj.quiet == True

# Generated at 2022-06-21 22:40:35.062519
# Unit test for constructor of class PyFileError
def test_PyFileError():
    pfe = PyFileError("abc")
    assert pfe.args[0] == "could not execute config file abc"

# Generated at 2022-06-21 22:40:40.561569
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('file not found', status_code=404)
    except LoadFileException as e:
        assert e.message == 'file not found'
        assert e.status_code == 404
        assert e.__str__() == 'file not found'


# Generated at 2022-06-21 22:40:43.687459
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    assert RequestTimeout("message", 408).message == "message"
    assert RequestTimeout("message", 408).status_code == 408
    assert RequestTimeout("message", 408).quiet == True


# Generated at 2022-06-21 22:40:48.814249
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    class Unathenticated(Unauthorized):
        def __init__(self, status_code=401, scheme='Basic', realm='Restricted Area'):
            super().__init__(f'Auth required.', status_code, scheme=scheme, realm=realm)

    e = Unathenticated()
    assert e.status_code == 401
    assert e.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

# Generated at 2022-06-21 22:40:57.193313
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    def test_msg():
        try:
            raise Unauthorized("Failed")
        except Unauthorized as e:
            assert e.message == "Failed"

    def test_status_code():
        try:
            raise Unauthorized("Failed", status_code=403)
        except Unauthorized as e:
            assert e.status_code == 403

    def test_auth_scheme():
        try:
            raise Unauthorized("Failed", status_code=403, scheme="Basic")
        except Unauthorized as e:
            assert e.headers == {
                "WWW-Authenticate": "Basic"
            }


# Generated at 2022-06-21 22:41:02.240950
# Unit test for constructor of class PyFileError
def test_PyFileError():
    file = "file"
    instance = PyFileError(file)
    assert instance.args[0] == "could not execute config file %s"
    assert instance.args[1] == file


# Generated at 2022-06-21 22:41:06.780774
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Parameterized constructor test case: status code
    total = 10
    content_range_error = ContentRangeError(
        "message", range(total))
    assert content_range_error.status_code == 416

    # Parameterized constructor test case: class inheritance
    assert isinstance(content_range_error, SanicException)

    # Parameterized constructor test case: headers
    expected_headers = {
        'Content-Range': f'bytes */{total}'
    }
    assert content_range_error.headers == expected_headers


# Generated at 2022-06-21 22:41:11.120662
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("test", 1)
    except Exception as e:
        assert repr(e) == "test"
        assert e.headers == {
            "Content-Range": "bytes */1"
        }

# Generated at 2022-06-21 22:41:15.676854
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("message", 400, True)
    except SanicException as e:
        assert e.status_code == 400
        assert e.args[0] == "message"
        assert e.quiet == True



# Generated at 2022-06-21 22:41:17.348550
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method_not_supported = MethodNotSupported("Hey", "GET", ["POST", "DELETE"])
    assert method_not_supported.headers == {"Allow": "POST, DELETE"}
    assert method_not_supported.message == "Hey"

# Generated at 2022-06-21 22:41:19.502928
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exc = Forbidden('Test exception')
    assert (exc.status_code == 403)
    assert (exc.args[0] == 'Test exception')

# Generated at 2022-06-21 22:41:21.931761
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("message")
    except Exception as e:
        assert isinstance(e, SanicException)
        assert e.status_code == 500
        assert e.message == "message"


# Generated at 2022-06-21 22:41:22.904269
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    exception = InvalidRangeType("message", None)
    assert exception.headers == {"Content-Range": "bytes */None"}

# Generated at 2022-06-21 22:41:24.884117
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError(message="Server error")
    assert err.message == "Server error"


# Generated at 2022-06-21 22:41:26.457679
# Unit test for constructor of class FileNotFound
def test_FileNotFound(): 
    try:
        raise FileNotFound("message", path="/foo/bar", relative_url="bar/foo")
    except FileNotFound as e:
        assert e.path == "/foo/bar"
        assert e.relative_url == "bar/foo"
    else:
        raise AssertionError("No exception raised")

# Generated at 2022-06-21 22:41:30.648122
# Unit test for constructor of class ServerError
def test_ServerError():
    err = ServerError('err')
    assert err.message == 'err'

# Generated at 2022-06-21 22:41:33.791754
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    # This is an example use of the class ServiceUnavailable
    try:
        raise ServiceUnavailable('this is a test')
    except ServiceUnavailable as test:
        assert test.status_code == 503
        assert test.message == 'this is a test'


# Generated at 2022-06-21 22:41:39.702344
# Unit test for constructor of class NotFound
def test_NotFound():
    exception = NotFound('message')
    assert isinstance(exception, NotFound)
    assert exception.status_code == 404
    assert exception.__str__() == 'message'
    assert exception.__repr__() == '<NotFound message>'


# Generated at 2022-06-21 22:41:44.568415
# Unit test for function add_status_code
def test_add_status_code():
    STATUS = 404
    @add_status_code(STATUS)
    class TestException(Exception):
        pass
    TestError = _sanic_exceptions[STATUS]
    assert TestError is TestException
    assert TestException.status_code is STATUS
    assert TestException.quiet is True



# Generated at 2022-06-21 22:41:47.651914
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    message = "It is a invalid message."
    exception = HeaderNotFound(message)
    assert exception.status_code == 400
    assert exception.message == f"It is a invalid message."

# Generated at 2022-06-21 22:41:50.738583
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    error = ContentRangeError("message", 5)
    assert(error.headers == {"Content-Range": "bytes */5"})
    assert(error.status_code == 416)
    assert(error.message == "message")

# Generated at 2022-06-21 22:41:57.839097
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # OK case
    test_err = Unauthorized(message="401 Dummy error message.",
                            scheme="Basic",
                            realm="Restricted Area")

    assert test_err.message == "401 Dummy error message."
    assert test_err.status_code == 401
    assert test_err.headers["WWW-Authenticate"] == 'Basic realm="Restricted Area"'

    # NG case: scheme is not provided
    with pytest.raises(TypeError):
        Unauthorized(message="401 Dummy error message.", realm="Restricted Area")

    # NG case: scheme is invalid authentication scheme
    with pytest.raises(ValueError):
        Unauthorized(message="401 Dummy error message.", scheme="Dummy", realm="Restricted Area")

# Generated at 2022-06-21 22:42:02.921311
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError('error', 'content_range')
    except ContentRangeError as e:
        assert e.status_code == 416
        assert e.headers['Content-Range'] == 'bytes */content_range'
        assert e.headers['Content-Range'] != 'abc'
        assert e.headers['Content-Range'] != 'bytes */abc'


# Generated at 2022-06-21 22:42:07.514599
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("error", 500, True)
    except ServerError as e:
        assert e.message == "error"
        assert e.status_code == 500
        assert e.quiet == True


# Generated at 2022-06-21 22:42:12.242911
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class Test100(SanicException):
        pass

    assert Test100.status_code == 100
    t100 = Test100("test")
    assert t100.status_code == 100
    assert repr(t100) == "Test100(status_code=100, message='test')"



# Generated at 2022-06-21 22:42:17.352055
# Unit test for constructor of class Forbidden
def test_Forbidden():
    ex = Forbidden("Forbidden")
    assert isinstance(ex, Forbidden)
    assert ex.status_code == 403

# Generated at 2022-06-21 22:42:24.265894
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    timeout_sanic_exception = RequestTimeout("Request timed out", 408)

    assert(timeout_sanic_exception.__class__.__name__ == "RequestTimeout")
    assert(timeout_sanic_exception.status_code == 408)
    assert(timeout_sanic_exception.message == "Request timed out")
    assert(timeout_sanic_exception.quiet == True)


# Generated at 2022-06-21 22:42:25.368689
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    error = LoadFileException(message="hello", status_code=100)
    assert error.status_code == 100
    assert error.message == "hello"

# Generated at 2022-06-21 22:42:29.060285
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    with pytest.raises(HeaderNotFound) as exception_info:
        raise HeaderNotFound('headernotfound')
    assert str(exception_info.value) == 'headernotfound'

# Generated at 2022-06-21 22:42:39.470495
# Unit test for function add_status_code
def test_add_status_code():
    # Add status_code 204
    default_status_code = 202

    @add_status_code(default_status_code, quiet=True)
    class CustomException(SanicException):
        pass

    e = CustomException(message="test", quiet=False)
    assert e.status_code == default_status_code
    assert e.message == "test"
    assert e.quiet is False
    e = CustomException(message="test2")
    assert e.status_code == default_status_code
    assert e.message == "test2"
    assert e.quiet is True
    e = CustomException(message="test3", quiet=True)
    assert e.status_code == default_status_code
    assert e.message == "test3"
    assert e.quiet is True

    # Add status code 400
    default

# Generated at 2022-06-21 22:42:48.613917
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Initialize a ContentRangeError object with 0 bytes
    content_range_error = ContentRangeError("0", 0)

    # Check the instance attributes
    assert content_range_error.args[0] == "0"
    assert content_range_error.headers == {"Content-Range": "bytes */0"}

    # Initialize a ContentRangeError object with 1024 bytes
    content_range_error = ContentRangeError("1024", 1024)

    # Check the instance attributes
    assert content_range_error.args[0] == "1024"
    assert content_range_error.headers == {"Content-Range": "bytes */1024"}

# Generated at 2022-06-21 22:42:50.848754
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError, message = "bytes */33"):
        raise ContentRangeError("Range Not Satisfiable", content_range = 33)

# Generated at 2022-06-21 22:42:53.490011
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pl = PayloadTooLarge('test', 1)
    assert pl.headers == {'Content-Length': '1'}
    assert pl.status_code == 413



# Generated at 2022-06-21 22:42:57.630471
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('File was not found')
    except LoadFileException as e:
        assert e.status_code == 500
        assert str(e) == 'File was not found'

# Generated at 2022-06-21 22:42:59.897256
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("data")
    except Exception as e:
        assert str(e)=="could not execute config file data"

# Generated at 2022-06-21 22:43:09.945854
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('Not Working')
    except ServiceUnavailable as e:
        assert str(e) == 'Not Working'
        assert e.status_code == 503
    else:
        assert False


# Generated at 2022-06-21 22:43:11.247106
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage("test")

# Generated at 2022-06-21 22:43:14.983364
# Unit test for function abort
def test_abort():
    with pytest.raises(NotFound):
        abort(404)

    with pytest.raises(SanicException):
        abort(600, message="Test message")

# Generated at 2022-06-21 22:43:26.794664
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(400)
    class UserException(SanicException):
        pass
    @add_status_code(500, quiet=True)
    class MyException(SanicException):
        pass

    assert issubclass(_sanic_exceptions[400], SanicException)
    assert _sanic_exceptions[400] is UserException
    assert issubclass(_sanic_exceptions[500], SanicException)
    assert _sanic_exceptions[500] is MyException

    try:
        raise UserException("User Exception")
    except SanicException as s:
        assert s.status_code == 400
        assert s.message == "User Exception"
    try:
        raise MyException("My Exception")
    except SanicException as s:
        assert s.status_code == 500

# Generated at 2022-06-21 22:43:28.505898
# Unit test for function add_status_code
def test_add_status_code():
    def test(): pass
    add_status_code(100)(test)
    assert test.status_code == 100

# Generated at 2022-06-21 22:43:36.261237
# Unit test for function add_status_code
def test_add_status_code():
    assert add_status_code(200)(SanicException).__name__ == 'SanicException'
    assert add_status_code(200)(SanicException).status_code == 200
    assert add_status_code(200, quiet=False)(SanicException).__name__ == 'SanicException'
    assert add_status_code(200, quiet=True)(SanicException).__name__ == 'SanicException'
    assert add_status_code(200, quiet=None)(SanicException).__name__ == 'SanicException'
    assert add_status_code(200, quiet=None)(SanicException).status_code == 200
    assert add_status_code(200, quiet=True)(SanicException).status_code == 200
    assert add_status_code(200, quiet=False)(SanicException).status_code == 200

# Generated at 2022-06-21 22:43:38.117545
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
  requestTimeout = RequestTimeout(message = "Timeout Request")
  assert requestTimeout.status_code == 408


# Generated at 2022-06-21 22:43:44.436382
# Unit test for function add_status_code
def test_add_status_code():
    test_num = 200

    # The decorator should add the status code to the class.
    @add_status_code(test_num)
    class TestClass(SanicException):
        pass

    assert TestClass.status_code == test_num

    # The decorator should add the class to _sanic_exceptions.
    assert _sanic_exceptions[test_num] is TestClass



# Generated at 2022-06-21 22:43:50.727619
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    # Test alternate init parameters of FileNotFound
    with pytest.raises(NotFound) as excinfo:
        raise FileNotFound(
            message='File was not found',
            path="test.txt",
            relative_url="test.txt",
        )

    # Test the constructor parameters
    assert excinfo.value.message == 'File was not found'
    assert excinfo.value.path == 'test.txt'
    assert excinfo.value.relative_url == 'test.txt'



# Generated at 2022-06-21 22:43:53.587992
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # Test with valid parameters
    exception_0 = LoadFileException(message="invalid file")
    assert exception_0.message == "invalid file"


# Generated at 2022-06-21 22:44:04.500384
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable("Service Unavailable exception")
    except SanicException as e:
        # Check type of exception
        assert type(e) is ServiceUnavailable
        # Check if message matches
        assert e.args[0] == "Service Unavailable exception"
        # Check if status code matches
        assert e.status_code == 503
        # Check if quiet is false
        assert e.quiet is True

# Generated at 2022-06-21 22:44:10.235232
# Unit test for function abort
def test_abort():
    try:
        abort(404, "Not found")
    except NotFound as e:
        assert type(e) == NotFound
        assert e.status_code == 404

    try:
        abort(403)
    except Forbidden as e:
        assert type(e) == Forbidden
        assert e.status_code == 403

# Generated at 2022-06-21 22:44:13.955845
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    exception = MethodNotSupported(message="test",
                                   method="op",
                                   allowed_methods=["get", "post"])
    assert exception.message == "test"
    assert exception.headers == {"Allow": "get, post"}

# Generated at 2022-06-21 22:44:15.859306
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    error = MethodNotSupported("msg", "method", ["method"])

    assert error.headers == {"Allow": "method"}

# Generated at 2022-06-21 22:44:18.431629
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    expected_msg = "a header is required"
    header_not_found = HeaderNotFound(message=expected_msg)
    assert header_not_found.message == expected_msg


# Generated at 2022-06-21 22:44:19.766596
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout):
        raise RequestTimeout("Request Timeout")

# Generated at 2022-06-21 22:44:22.268624
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError(message='message')
    assert error.message == 'message'
    assert isinstance(error, URLBuildError)


# Generated at 2022-06-21 22:44:24.197370
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    error = URLBuildError("error")
    assert(error.status_code == 500)
    assert(error.message == "error")

# Generated at 2022-06-21 22:44:25.281245
# Unit test for constructor of class NotFound
def test_NotFound():
    x = NotFound("error")
    assert x.status_code == 404


# Generated at 2022-06-21 22:44:27.865438
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    c = ContentRangeError("test", 123)
    assert c.status_code == 416

# Generated at 2022-06-21 22:44:44.094356
# Unit test for function abort
def test_abort():
    from pytest import raises
    from sanic.exceptions import ServerError, NotFound

    with raises(NotFound):
        abort(404)

    with raises(ServerError):
        abort(500)

# Generated at 2022-06-21 22:44:48.540523
# Unit test for function abort
def test_abort():
    with pytest.raises(SanicException) as error:
        abort(status_code=418)
    assert error.value.status_code == 418
    assert error.value.message == 'I\'m a teapot'



# Generated at 2022-06-21 22:44:49.501006
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    LoadFileException("message")

# Generated at 2022-06-21 22:44:52.154537
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():

    try:
        raise RequestTimeout("aa", 8)
    except RequestTimeout as e:
        assert e.args[0] == "aa"
        assert isinstance(e, RequestTimeout)



# Generated at 2022-06-21 22:44:53.920316
# Unit test for constructor of class Forbidden
def test_Forbidden():
    exception = Forbidden("What a pity!")
    assert exception.message == "What a pity!"
    assert exception.status_code == 403


# Generated at 2022-06-21 22:44:55.513829
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    obj = HeaderExpectationFailed("MESSAGE")
    assert obj.status_code == 417
    assert obj.message == "MESSAGE"

# Generated at 2022-06-21 22:44:57.199558
# Unit test for constructor of class NotFound
def test_NotFound():
    NotF = NotFound("Not Found")
    assert(NotF.message == "Not Found")

if __name__ == '__main__':
    test_NotFound()

# Generated at 2022-06-21 22:45:05.994718
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    # Test if initialize exception with content range succeed
    try:
        raise ContentRangeError("Range is unsatisfiable", content_range=1)
    except ContentRangeError as e:
        assert e.headers.get('Content-Range') == 'bytes */1'
        assert e.status_code == 416

    # Test if initialize exception without content range succeed
    try:
        raise ContentRangeError("Range is unsatisfiable", content_range=None)
    except ContentRangeError as e:
        assert e.headers.get('Content-Range') == 'bytes *'
        assert e.status_code == 416


# Generated at 2022-06-21 22:45:09.652865
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        with pytest.raises(ContentRangeError):
            raise ContentRangeError(message="test exception")
    except ContentRangeError as err:
        assert err.message == "test exception"
        assert err.content_range == "*/*"

# Generated at 2022-06-21 22:45:15.310006
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    """
    Unit test for constructor of class FileNotFound.
    """
    fnf = FileNotFound("test message.","test path.","test relative url.")

    assert(fnf.message == "test message.")
    assert(fnf.path == "test path.")
    assert(fnf.relative_url == "test relative url.")

if __name__ == "__main__":
    # Run unit tests
    test_FileNotFound()

# Generated at 2022-06-21 22:45:45.273681
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    expected_result = MethodNotSupported("method_n", 'POST', ['GET'])
    assert(expected_result.status_code == 405)
    assert(expected_result.message == 'method_n')

# Generated at 2022-06-21 22:45:48.177052
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError) as error:
        raise PyFileError("error")
    assert str(error.value) == "could not execute config file error"

# Generated at 2022-06-21 22:45:50.272477
# Unit test for constructor of class ServerError
def test_ServerError():
    message = "error message"
    status_code = 500
    with pytest.raises(ServerError):
        ServerError(message, status_code)


# Generated at 2022-06-21 22:45:51.208388
# Unit test for function abort
def test_abort():
    abort(405)

test_abort()

# Generated at 2022-06-21 22:46:02.343336
# Unit test for constructor of class SanicException
def test_SanicException():
    assert SanicException('error').message == 'error'
    assert SanicException('error').status_code is None
    assert SanicException('error').quiet is False
    assert SanicException('error', 100).message == 'error'
    assert SanicException('error', 100).status_code == 100
    assert SanicException('error', 100).quiet is False
    assert SanicException('error', status_code=100).message == 'error'
    assert SanicException('error', status_code=100).status_code == 100
    assert SanicException('error', status_code=100).quiet is False
    assert SanicException('error', quiet=True).message == 'error'
    assert SanicException('error', quiet=True).status_code is None
    assert SanicException('error', quiet=True).quiet is True
    assert San

# Generated at 2022-06-21 22:46:03.885613
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Whatever the given file
    assert str(PyFileError("file")) == "could not execute config file file"

# Generated at 2022-06-21 22:46:09.856338
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # TEST1: scheme is not None
    with pytest.raises(Unauthorized, match="Auth required."):
        raise Unauthorized("Auth required.", scheme="Basic",
                           realm="Restricted Area")

    # TEST2: scheme is None
    with pytest.raises(Unauthorized, match="Auth required."):
        raise Unauthorized("Auth required.", scheme=None)

# Generated at 2022-06-21 22:46:13.170810
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test")
    except ServerError as se:
        assert se.status_code == 500
        assert se.args[0] == "Test"

# Generated at 2022-06-21 22:46:17.376070
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound('404 error')
    except SanicException as ex:
        assert ex.status_code == 404
        assert ex.message == '404 error'
        assert ex.quiet == True

if __name__ == '__main__':
    test_NotFound()
    print('Test success')

# Generated at 2022-06-21 22:46:27.602017
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Test 1 message:", 404, False)
    except NotFound as e:
        assert e.status_code == 404
        assert not hasattr(e, 'quiet')
    try:
        raise NotFound("Test 2 message:", 404, True)
    except NotFound as e:
        assert e.status_code == 404
        assert e.quiet == True
    try:
        raise NotFound("Test 3 message:", 404, None)
    except NotFound as e:
        assert e.status_code == 404
        assert not hasattr(e, 'quiet')
    try:
        raise NotFound("Test 4 message:", 405, True)
    except NotFound as e:
        assert e.status_code == 405
        assert e.quiet == True

# Generated at 2022-06-21 22:47:28.756381
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    import pathlib, os
    file_path = pathlib.Path(os.path.abspath(".")) / "sanic_exceptions.py"
    try:
        raise LoadFileException("foo",file_path)
    except Exception as e:
        assert type(e) == LoadFileException
        assert e.args[0] == "foo"
        assert e.args[1] == file_path


# Generated at 2022-06-21 22:47:35.754662
# Unit test for function abort
def test_abort():
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    try:
        abort(500)
    except SanicException as e:
        assert e.status_code == 500
    try:
        abort(404, message="Not Found")
    except NotFound as e:
        assert e.message == "Not Found"



# Generated at 2022-06-21 22:47:44.499693
# Unit test for constructor of class ServerError
def test_ServerError():
    exception = ServerError("My ServerError message")
    assert(str(exception)) == "My ServerError message"
    assert(exception.status_code) == 500
    assert(exception.quiet) == None
    #print(exception.status_code)
    #print(exception.quiet)

    exception = ServerError("My ServerError message", status_code=400)
    assert(str(exception)) == "My ServerError message"
    assert(exception.status_code) == 400
    assert(exception.quiet) == None
    #print(exception.status_code)
    #print(exception.quiet)

    exception = ServerError("My ServerError message", status_code=500)
    assert(str(exception)) == "My ServerError message"

# Generated at 2022-06-21 22:47:48.489956
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    code = 408
    message = "Request Timeout"
    try:
        abort(code, message)
    except RequestTimeout as error:
        assert error.status_code == code
        assert str(error) == message


# Generated at 2022-06-21 22:47:52.325968
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    allowed_methods = ['GET','POST','PUT']
    mns = MethodNotSupported('Method Not Supported', 'DELETE', allowed_methods)
    assert mns.headers == {'Allow': 'GET,POST,PUT'}

# Generated at 2022-06-21 22:47:55.510457
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    error = ServiceUnavailable(
        "message",
        status_code=503,
        quiet=False)

    assert error.status_code == 503
    assert error.message == "message"
    assert error.quiet == False

# Generated at 2022-06-21 22:47:59.655372
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    path = "spec.txt"
    relative_url = "spec.txt"
    message = "File {} not found".format(path)
    _exception = FileNotFound(message, path, relative_url)
    assert _exception.path == path
    assert _exception.relative_url == relative_url
    assert _exception.status_code == 404
    assert _exception.message == message



# Generated at 2022-06-21 22:48:06.235612
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Test expected behavior
    test_object = InvalidRangeType(message='test', content_range='test')
    # Test use of invalid argument type
    try:
        test_object = InvalidRangeType(10, 10)
    except TypeError:
        pass
    # Test use of invalid argument value
    try:
        test_object = InvalidRangeType(message=None, content_range=None)
    except TypeError:
        pass
    # Test use of both invalid argument type and value
    try:
        test_object = InvalidRangeType(1, 2)
    except TypeError:
        pass
    # Test use of multiple invalid argument values
    try:
        test_object = InvalidRangeType(None, None)
    except TypeError:
        pass

# Generated at 2022-06-21 22:48:08.149039
# Unit test for constructor of class Forbidden
def test_Forbidden():
    error = Forbidden('403 forbidden')
    assert error.status_code == 403
    assert error.message == '403 forbidden'

# Generated at 2022-06-21 22:48:11.703201
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    error_message = "This is a test error"
    exception = LoadFileException(error_message)
    assert exception.status_code == 500
    assert exception.message == error_message