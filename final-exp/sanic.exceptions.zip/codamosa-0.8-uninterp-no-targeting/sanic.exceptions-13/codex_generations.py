

# Generated at 2022-06-21 22:40:12.937268
# Unit test for constructor of class SanicException
def test_SanicException():

    # test the quiet property of SanicException
    exception_quiet_true = SanicException(quiet=True)
    assert exception_quiet_true.quiet == True
    exception_quiet_false = SanicException(quiet=False)
    assert exception_quiet_false.quiet == False

    # test the status_code property of SanicException
    status_code = 404
    exception_status_code = SanicException(status_code=status_code)
    assert exception_status_code.status_code == status_code

    # test the message property of SanicException
    message = "not found"
    exception_message = SanicException(message=message)
    assert exception_message.__str__() == message



# Generated at 2022-06-21 22:40:14.837297
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    message, status_code = "HeaderExpectationFailed message", 417
    HeaderExpectationFailed(message=message, status_code=status_code)

# Generated at 2022-06-21 22:40:19.675994
# Unit test for constructor of class PyFileError
def test_PyFileError():
    f = 'some-file.py'
    try:
        raise PyFileError(f)
    except PyFileError as e:
        assert 'some-file.py' == e.file
        assert 'could not execute config file some-file.py' == str(e)



# Generated at 2022-06-21 22:40:22.799224
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        Exception("Error")
    except Exception as e:
        assert e.args[0] == "Error"



# Generated at 2022-06-21 22:40:25.933430
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    lfe = LoadFileException('test_message')
    assert lfe.message == 'test_message'
    assert lfe.status_code == 500


# Generated at 2022-06-21 22:40:29.650011
# Unit test for constructor of class NotFound
def test_NotFound():
    not_found = NotFound(message="Message",status_code=404)
    assert not_found.message == "Message"
    assert not_found.status_code == 404


# Generated at 2022-06-21 22:40:34.065261
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except Exception as e:
        print(e.args)


# Generated at 2022-06-21 22:40:37.947159
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(302)
    class MyError(SanicException):
        pass
    assert(MyError.status_code == 302)


# Generated at 2022-06-21 22:40:40.580634
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound('Test HeaderNotFound')
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'Test HeaderNotFound'


# Generated at 2022-06-21 22:40:41.638543
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden('forbidden', 403)
    assert forbidden.message

# Generated at 2022-06-21 22:40:52.627074
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    # Given
    exception = LoadFileException(message = "Config file not found",
                                  status_code = 404,
                                  path = r"C:\config.txt",
                                  relative_url = "config")
    # When & Then
    assert exception.message   == "Config file not found"
    assert exception.status_code == 404
    assert exception.path == "C:\config.txt"
    assert exception.relative_url == "config"


# Generated at 2022-06-21 22:41:01.524964
# Unit test for function abort
def test_abort():
    # Should abort with default exception message
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
    # Should abort with specified exception message
    message = "This is a custom message"
    try:
        abort(404, message)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == message
    # Should raise an exception with a user defined message
    message = "This is a custom message"
    try:
        abort(500, message)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == message

# Generated at 2022-06-21 22:41:06.297565
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    # create  method is supported
    try:
        raise MethodNotSupported("GET",["GET"])
    except MethodNotSupported as exc:
        assert exc.args[0] == "GET"
    # create method is not supported
    try:
        raise MethodNotSupported("POST",["GET"])
    except MethodNotSupported as exc:
        assert exc.args[0] == "POST"


# Generated at 2022-06-21 22:41:08.052920
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable):
        raise ServiceUnavailable('test')


# Generated at 2022-06-21 22:41:20.285308
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # 1. With a Basic auth-scheme, realm MUST be present
    try:
        raise Unauthorized("Auth required.", scheme="Basic")
    except Unauthorized as err:
        assert err.message == "Auth required."
        assert err.status_code == 401
        assert err.headers == {'WWW-Authenticate': 'Basic realm="None"'}

    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as err:
        assert err.message == "Auth required."
        assert err.status_code == 401
        assert err.headers == {'WWW-Authenticate': 'Basic realm="Restricted Area"'}

    # 2. With a Digest auth-scheme, things are a bit more complicated

# Generated at 2022-06-21 22:41:26.961269
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("filename")
    except PyFileError as e:
        try:
            # Python 3
            assert e.args[0] == "could not execute config file %s"
            assert e.args[1] == "filename"
        except AttributeError:
            # Python 2
            assert e.message == "could not execute config file %s"
            assert e.args[0] == "filename"


# Generated at 2022-06-21 22:41:30.393650
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("sample message", 10)
    except InvalidRangeType as ex:
        assert ex.message == "sample message"
        assert ex.status_code == 416
        assert ex.headers["Content-Range"] == "bytes */10"

# Generated at 2022-06-21 22:41:31.958008
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    invalidSignal = InvalidSignal("test message")
    assert invalidSignal.message == "test message"


# Generated at 2022-06-21 22:41:37.158100
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Test exception", None)
    except InvalidRangeType as e:
        assert(e.args[0] == "Test exception")
        assert(e.status_code == 416)
        assert(e.headers["Content-Range"] == "bytes */None")

# Generated at 2022-06-21 22:41:48.262607
# Unit test for function add_status_code
def test_add_status_code():
    decorator_map = {
        400: InvalidUsage,
        401: Unauthorized,
        404: NotFound,
        405: MethodNotSupported,
        408: RequestTimeout,
        413: PayloadTooLarge,
        416: ContentRangeError,
        417: HeaderExpectationFailed,
        500: ServerError,
        503: ServiceUnavailable,
    }

    global _sanic_exceptions
    status_code_list = decorator_map.keys()

    for status_code in status_code_list:
        decorator_map[status_code] = add_status_code(
            status_code
        )(decorator_map[status_code])

    _sanic_exceptions = decorator_map

    assert decorator_map[404] == NotFound
    assert decorator_map[400]

# Generated at 2022-06-21 22:42:00.492836
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    # Test for relative_url is None
    with pytest.raises(
        TypeError, match="missing 1 required positional argument: 'relative_url'"
    ):
        URLBuildError("test")
    # Test for relative_url is not None
    urlbuilderror = URLBuildError("test", "relative_url")
    assert urlbuilderror.__class__.__name__ == 'URLBuildError'
    assert issubclass(urlbuilderror.__class__, ServerError)
    assert issubclass(urlbuilderror.__class__, SanicException)
    assert isinstance(urlbuilderror, Exception)
    assert isinstance(urlbuilderror, SanicException)
    assert isinstance(urlbuilderror, ServerError)


# Generated at 2022-06-21 22:42:08.397097
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    test_message = "Auth required."
    test_scheme = "Basic"
    test_realm = "Restricted Area"
    test_args = {'realm' : test_realm}
    test_header = {"WWW-Authenticate": 'Basic realm="Restricted Area"'}
    try:
        raise Unauthorized(test_message, scheme=test_scheme, **test_args)
    except Unauthorized as e:
        assert e.args[0] == test_message
        assert e.status_code == 401
        assert e.headers == test_header
        assert e.args == (test_message,)

    try:
        raise Unauthorized(test_message, scheme=test_scheme)
    except Unauthorized as e:
        assert e.args[0] == test_message
        assert e.status_code

# Generated at 2022-06-21 22:42:14.339985
# Unit test for function add_status_code
def test_add_status_code():
    assert 404 in _sanic_exceptions
    assert 400 in _sanic_exceptions
    assert 405 in _sanic_exceptions
    assert 500 in _sanic_exceptions
    assert 503 in _sanic_exceptions
    assert 408 in _sanic_exceptions
    assert 413 in _sanic_exceptions
    assert 416 in _sanic_exceptions
    assert 417 in _sanic_exceptions
    assert 403 in _sanic_exceptions
    assert 401 in _sanic_exceptions

# Generated at 2022-06-21 22:42:26.621560
# Unit test for constructor of class SanicException
def test_SanicException():
    # test success
    message = "test"
    status_code = 404
    quiet = True
    sanic_exception = SanicException(message, status_code, quiet)
    assert sanic_exception.status_code == status_code
    assert sanic_exception.message == message
    assert sanic_exception.quiet == quiet
    assert sanic_exception.__class__ == SanicException

    # Test failure
    message = "test"
    status_code = 404
    quiet = True
    sanic_exception = SanicException(message, status_code, quiet)
    assert sanic_exception.status_code == status_code
    assert sanic_exception.message == message
    assert sanic_exception.quiet == quiet
    assert sanic_exception.__class__ == SanicException

# Generated at 2022-06-21 22:42:31.607796
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal.")
    except InvalidSignal as e:
        assert e.status_code == 500
        assert e.quiet == False
        assert e.message == "Invalid Signal."



# Generated at 2022-06-21 22:42:40.678055
# Unit test for function abort
def test_abort():
    from http import HTTPStatus as status
    try:
        abort(status.MISDIRECTED_REQUEST)
    except SanicException as e:
        assert e.status_code == status.MISDIRECTED_REQUEST
        assert e.message == STATUS_CODES[status.MISDIRECTED_REQUEST].decode("utf8")
    try:
        abort(status.MISDIRECTED_REQUEST, "Wrong Endpoint")
    except SanicException as e:
        assert e.status_code == status.MISDIRECTED_REQUEST
        assert e.message == "Wrong Endpoint"
    try:
        abort(status.NOT_FOUND)
    except NotFound as e:
        assert e.status_code == status.NOT_FOUND
        assert e.message == STATUS

# Generated at 2022-06-21 22:42:44.521200
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("Not Found")
    except NotFound as e:
        assert e.status_code == 404
        assert str(e) == "Not Found"

# Generated at 2022-06-21 22:42:46.765722
# Unit test for constructor of class PyFileError
def test_PyFileError():
    # Arrange
    file = "test"
    # Act
    error = PyFileError(file)
    # Assert
    assert str(error) == "could not execute config file test"

# Generated at 2022-06-21 22:42:50.282803
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    e = RequestTimeout("TestException", 408)
    assert e.status_code == 408
    assert e.quiet is False
    assert e.message == "TestException"

if __name__ == "__main__":
    test_RequestTimeout()

# Generated at 2022-06-21 22:42:54.043277
# Unit test for constructor of class PyFileError
def test_PyFileError():
    class Error(PyFileError):
        def __init__(self, file):
            super().__init__(file)
    e = Error("my_file.py")
    assert e.args[0] == "could not execute config file my_file.py"

# Generated at 2022-06-21 22:43:05.361702
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except SanicException as e:
        assert e.status_code == 404

# Generated at 2022-06-21 22:43:08.118810
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # Testing the constructor of class InvalidRangeType
    content_range = Mock()
    irange = InvalidRangeType("message", content_range)
    header = irange.headers
    assert header == {"Content-Range": "bytes */None"}



# Generated at 2022-06-21 22:43:12.720577
# Unit test for constructor of class NotFound
def test_NotFound():
    message = 'message'
    not_found = NotFound(message=message)
    assert not_found.status_code == 404
    assert not_found.message == message
    assert not_found.__str__() == '404: message'

# Generated at 2022-06-21 22:43:18.077071
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    try:
        raise FileNotFound('this is a message', 'some_path', 'some_url')
    except FileNotFound as e:
        assert e.status_code == 404
        assert e.message == 'this is a message'
        assert e.path == 'some_path'
        assert e.relative_url == 'some_url'

# Generated at 2022-06-21 22:43:21.811229
# Unit test for constructor of class SanicException
def test_SanicException():
    test_class = SanicException("test_message")
    assert test_class.message == "test_message" and test_class.status_code == None and test_class.quiet == False


# Generated at 2022-06-21 22:43:31.058788
# Unit test for function add_status_code
def test_add_status_code():
    # class decorator
    @add_status_code(300)
    class TestingClass(SanicException):
        pass
    assert TestingClass.status_code == 300
    assert TestingClass.quiet is None

    # class decorator with quiet argument
    @add_status_code(301)
    class TestingClass2(SanicException):
        pass
    assert TestingClass2.status_code == 301
    assert TestingClass2.quiet is True

    # regular function
    def reg_function():
        pass
    reg_function_quiet = add_status_code(1, quiet=True)(reg_function)
    assert reg_function_quiet.status_code == 1
    assert reg_function_quiet.quiet is True

# Generated at 2022-06-21 22:43:34.685715
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    e = HeaderNotFound("HeaderNotFound", "Missing header: sanic")
    assert e.status_code == 400
    assert e.quiet == True
    assert hasattr(e, 'message') == True
    assert hasattr(e, 'status_code') == True
    assert hasattr(e, 'quiet') == True


# Generated at 2022-06-21 22:43:37.313803
# Unit test for constructor of class NotFound
def test_NotFound():
    ex = NotFound("This is not found")
    assert ex.status_code == 404
    assert ex.message == "This is not found"


# Generated at 2022-06-21 22:43:47.667323
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(ServerError) as error:
        raise ServerError("Server Error")
    assert str(error.value) == "Server Error"
    assert error.value.quiet is True
    assert error.value.status_code == 500

    with pytest.raises(ServiceUnavailable) as error:
        raise ServiceUnavailable("UNAVAILABLE")
    assert str(error.value) == "UNAVAILABLE"
    assert error.value.quiet is True
    assert error.value.status_code == 503

    with pytest.raises(NotFound) as error:
        raise NotFound("Not Found")
    assert str(error.value) == "Not Found"
    assert error.value.quiet is True
    assert error.value.status_code == 404

# Generated at 2022-06-21 22:43:52.117610
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Error!")
    except SanicException as e:
        assert str(e) == "Error!"
        assert e.status_code == 500

if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-21 22:44:15.064959
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    try:
        raise HeaderNotFound(message="Header not found", status_code=400)
    except HeaderNotFound as e:
        assert e.message == "Header not found"
        assert e.status_code == 400
    else:
        raise



# Generated at 2022-06-21 22:44:18.367944
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    test_header_not_found = HeaderNotFound("HeaderNotFound")
    assert test_header_not_found is not None
    assert test_header_not_found.message is not None

# Generated at 2022-06-21 22:44:22.700926
# Unit test for function abort
def test_abort():
    """
    Test function abort
    """
    # status_code is not in SanicException
    with pytest.raises(SanicException):
        abort(123, "test")

    # status_code is in SanicException
    with pytest.raises(NotFound):
        abort(404, "test")

# Generated at 2022-06-21 22:44:24.128636
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        not_found = NotFound("/")
    except SanicException:
        print("SanicException occurred")



# Generated at 2022-06-21 22:44:26.237187
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    pltl = PayloadTooLarge(message='test', status_code=413)
    assert pltl.quiet == True
    assert pltl.status_code == 413

# Generated at 2022-06-21 22:44:30.034038
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    ex = MethodNotSupported('POST method not supported', 'POST', ['GET'])
    assert ex.headers == {'Allow': 'GET'}


# Generated at 2022-06-21 22:44:35.187447
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    message = "Error Message"
    status_code = 400
    sanic_exception = InvalidUsage(message, status_code)

    assert sanic_exception.message == message
    assert sanic_exception.status_code == status_code

test_InvalidUsage()


# Generated at 2022-06-21 22:44:39.086731
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Range Not Satisfiable", range(100))
    except InvalidRangeType as e:
        assert str(e) == "Range Not Satisfiable"
        assert e.status_code == 416
        assert e.headers == {"Content-Range": "bytes */100"}

# Generated at 2022-06-21 22:44:40.608139
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    su = ServiceUnavailable("Service Unavailable", 503)
    assert su.status_code == 503


# Generated at 2022-06-21 22:44:44.093224
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    expected_message = "some message"
    actual_message = HeaderNotFound(expected_message).args
    assert actual_message == (expected_message,)


# Generated at 2022-06-21 22:45:24.929606
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    assert InvalidUsage(message='test', status_code=None, quiet=None)


# Generated at 2022-06-21 22:45:26.974766
# Unit test for constructor of class PyFileError
def test_PyFileError():
    try:
        raise PyFileError("test")
    except PyFileError as e:
        assert str(e) == "could not execute config file test"



# Generated at 2022-06-21 22:45:30.521398
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType('Invalid Range', 10)
    except InvalidRangeType as e:
        assert e.message == 'Invalid Range'
        assert e.status_code == 416

# Generated at 2022-06-21 22:45:33.304531
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("Invalid Signal")
    except InvalidSignal as e:
        assert e.message == "Invalid Signal"

# Generated at 2022-06-21 22:45:36.467521
# Unit test for constructor of class NotFound
def test_NotFound():
    class NotFound(SanicException):
        """
        **Status**: 404 Not Found
        """

        pass

    assert hasattr(NotFound, 'status_code')
    assert True == hasattr(NotFound, 'quiet')


# Generated at 2022-06-21 22:45:39.036152
# Unit test for constructor of class ServerError
def test_ServerError():
    message = "Test ServerError"
    exception = ServerError(message)
    assert message == str(exception)
    assert 500 == exception.status_code
    assert not exception.quiet


# Generated at 2022-06-21 22:45:40.680172
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    mns = MethodNotSupported(message="test",method="test",allowed_methods="test")
    assert(mns.headers['Allow'] == 'test')

# Generated at 2022-06-21 22:45:44.887235
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    message = "testing"
    exception = RequestTimeout(message)
    assert exception.message == message
    assert exception.status_code == 408
    assert exception.quiet == True

# Generated at 2022-06-21 22:45:46.781534
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as error:
        assert error.status_code == 500


# Generated at 2022-06-21 22:45:49.854931
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    with pytest.raises(RequestTimeout) as ctx:
        raise RequestTimeout("Message: RequestTimeout")
    assert ctx.value.message == "Message: RequestTimeout"


# Generated at 2022-06-21 22:47:16.281269
# Unit test for constructor of class NotFound
def test_NotFound():
    notFound = NotFound("Not Found")
    assert notFound.status_code == 404
    assert notFound.message == "Not Found"

if __name__ == "__main__":
    test_NotFound()

# Generated at 2022-06-21 22:47:19.380445
# Unit test for constructor of class Forbidden
def test_Forbidden():
    # Given a forbidden message
    message = "Prohibited"
    # When we create an instance of Forbidden
    forbidden = Forbidden(message)
    # Then we expect the status_code is 403
    assert forbidden.status_code == 403
    # And we expect the message is "Prohibited"
    assert forbidden.message == message


# Generated at 2022-06-21 22:47:20.730787
# Unit test for constructor of class ServerError
def test_ServerError():
    error = ServerError("ERROR")
    assert error.message == "ERROR"
    assert error.status_code == 500


# Generated at 2022-06-21 22:47:26.689063
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method not supported"
    method = "DELETE"
    allowed_methods = ["DELETE", "POST"]
    method_not_supported = MethodNotSupported(message, method, allowed_methods)
    assert method_not_supported.status_code == 405
    assert method_not_supported.headers["Allow"] == "DELETE, POST"



# Generated at 2022-06-21 22:47:27.447773
# Unit test for constructor of class SanicException
def test_SanicException():
    with pytest.raises(SanicException):
        SanicException()

# Generated at 2022-06-21 22:47:37.063617
# Unit test for function abort
def test_abort():
    try:
        abort(500)
    except ServerError as e:
        assert e.status_code == 500
        assert e.message == 'Internal Server Error'
    try:
        abort(404)
    except NotFound as e:
        assert e.status_code == 404
        assert e.message == 'Not Found'
    try:
        abort(400)
    except InvalidUsage as e:
        assert e.status_code == 400
        assert e.message == 'Bad Request'
    try:
        abort(501)
    except SanicException as e:
        assert e.status_code == 501
        assert e.message == 'Not Implemented'

if __name__ == '__main__':
    test_abort()

# Generated at 2022-06-21 22:47:40.613333
# Unit test for constructor of class ServerError
def test_ServerError():
    # Arrange
    message = "message"
    status_code = 500

    # Act
    server_error = ServerError(message=message, status_code=status_code)

    # Assert
    assert server_error.message == message
    assert server_error.status_code == status_code



# Generated at 2022-06-21 22:47:43.026797
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    try:
        raise ServiceUnavailable('Service Unavailable')
    except ServiceUnavailable as e:
        assert e.status_code == 503
        assert e.quiet is True
        assert e.args == ('Service Unavailable',)

# Generated at 2022-06-21 22:47:45.177874
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test")
    except LoadFileException as err:
        assert str(err) == "test"


# Generated at 2022-06-21 22:47:52.918846
# Unit test for constructor of class SanicException
def test_SanicException():
    try:
        raise SanicException("some message", status_code=418, quiet=True)
    except SanicException as se:
        assert se.message == "some message"
        assert se.status_code == 418
        assert se.quiet == True
    try:
        raise SanicException("some message", status_code=500)
    except SanicException as se:
        assert se.message == "some message"
        assert se.status_code == 500
        assert se.quiet == False
