

# Generated at 2022-06-21 22:40:02.934897
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    with pytest.raises(ServerError):
        raise URLBuildError


# Generated at 2022-06-21 22:40:05.201954
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    e = ServiceUnavailable('hello','503')
    assert str(e) == 'hello'
    assert e.status_code == 503


# Generated at 2022-06-21 22:40:15.266799
# Unit test for function add_status_code
def test_add_status_code():
    """
    This method verifies that add_status_code function is executed properly by
    passing different inputs.
    """
    assert add_status_code(400, quiet=True) == class_decorator
    assert add_status_code(403, quiet=False) == class_decorator
    assert add_status_code(404) == class_decorator
    assert add_status_code(500, quiet=False) == class_decorator
    assert add_status_code(503) == class_decorator
    assert add_status_code(503, quiet=False) == class_decorator
    assert add_status_code(408) == class_decorator
    assert add_status_code(416) == class_decorator
    assert add_status_code(400) == class_decorator
   

# Generated at 2022-06-21 22:40:26.490086
# Unit test for constructor of class SanicException
def test_SanicException():
    e = SanicException("msg")
    assert e.status_code == None
    assert e.quiet == None
    assert e.message == "msg"

    e = SanicException("msg", status_code=200, quiet=True)
    assert e.status_code == 200
    assert e.quiet == True
    assert e.message == "msg"

    e = SanicException("msg", status_code=200, quiet=None)
    assert e.status_code == 200
    assert e.quiet == True
    assert e.message == "msg"

    e = SanicException("msg", status_code=500, quiet=None)
    assert e.status_code == 500
    assert e.quiet == None
    assert e.message == "msg"

# Generated at 2022-06-21 22:40:30.610229
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    """
    测试超时状态码是否正确
    :return:
    """
    timeout = RequestTimeout("Request Timeout")
    assert 408 == timeout.status_code

# Generated at 2022-06-21 22:40:34.351844
# Unit test for constructor of class PyFileError
def test_PyFileError():
    obj = PyFileError('test')
    assert obj.args[0] == "could not execute config file %s"
    assert obj.args[1] == 'test'

# Generated at 2022-06-21 22:40:46.101985
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    # Tests for HTTP status code 413
    # When a request entity is larger than limits defined by server; the server
    # MAY close the connection or return an Retry-After header field.

    # The server SHOULD generate a payload that includes useful information
    # for the user. In some cases, it could be the case that the server is
    # unable to produce such a payload.
    # In this case, the server needs to enable the user to see the reason
    # of the request failure.

    exc = PayloadTooLarge("Request entity too large")
    assert exc.status_code == 413
    assert exc.message == "Request entity too large"

    exc = PayloadTooLarge("Request entity too large",
                          "the server is unable to produce the payload")
    assert exc.message == "Request entity too large"

    # The server could terminate the connection without returning

# Generated at 2022-06-21 22:40:50.726363
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("yo", quiet=False)
    except NotFound as err:
        assert isinstance(err, SanicException)
        assert err.message == "yo"
        assert err.status_code == 404
        assert not err.quiet

# Generated at 2022-06-21 22:40:52.666240
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    e = URLBuildError("Testing URLBuildError")
    assert str(e) == 'Testing URLBuildError'


# Generated at 2022-06-21 22:40:55.625428
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("Test LoadFileException constructor")
    except BaseException:
        pass

# Generated at 2022-06-21 22:41:00.777408
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("MySanicException","SIGSEGV")
        assert False
    except Exception as e:
        assert e.args[0] == "MySanicException"
        assert e.args[1] == "SIGSEGV"

# Generated at 2022-06-21 22:41:02.889409
# Unit test for constructor of class SanicException
def test_SanicException():
    se = SanicException(message="Sanic Exception Message.", status_code=400)
    assert se.status_code == 400
    assert se.message == "Sanic Exception Message."

# Generated at 2022-06-21 22:41:06.013662
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    try:
        _sanic_exceptions[417] = HeaderExpectationFailed
        header_exception = HeaderExpectationFailed('Test Message', 417)
        assert header_exception.status_code == 417
    except Exception as e:
        print('Error in testing class HeaderExpectationFailed: ' + str(e))

# Generated at 2022-06-21 22:41:09.460390
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(412)
    class PreconditionFailed(SanicException):
        pass
    assert PreconditionFailed.status_code == 412



# Generated at 2022-06-21 22:41:15.031697
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden("Testing", content_type="application/json")
    except SanicException as e:
        assert e.headers['Content-Type'] == 'application/json'


if __name__ == "__main__":
    # Unit test for constructor of class Unauthorized
    test_Forbidden()

# Generated at 2022-06-21 22:41:16.265775
# Unit test for function add_status_code
def test_add_status_code():
    @add_status_code(100)
    class My100Error(SanicException):
        pass
    assert isinstance(_sanic_exceptions[100](), My100Error)

# Generated at 2022-06-21 22:41:17.740944
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    assert 'test exception' == LoadFileException('test exception').args[0]

# Generated at 2022-06-21 22:41:19.462005
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    FileNotFound("test", "/", "/")
    FileNotFound("test", "/", "relative_url")

# Generated at 2022-06-21 22:41:23.387955
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    # content_range is a class parameter of class InvalidRangeType
    content_range = None
    test_InvalidRangeType = InvalidRangeType("Error message", content_range)
    assert test_InvalidRangeType.content_range == None
    assert test_InvalidRangeType.message == "Error message"
    assert test_InvalidRangeType.status_code == None
    assert test_InvalidRangeType.headers == {"Content-Range": "bytes */None"}


# Generated at 2022-06-21 22:41:28.410420
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    rt = RequestTimeout("Test the RequestTimeout exception", 408)
    assert rt.status_code == 408
    assert rt.message == 'Test the RequestTimeout exception'
    assert rt.__str__() == 'Test the RequestTimeout exception'
    assert rt.__repr__() == 'Test the RequestTimeout exception'


# Generated at 2022-06-21 22:41:36.536798
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    fnf = FileNotFound('message', 'path', 'relative_url')
    assert fnf.message == 'message'
    assert fnf.path == 'path'
    assert fnf.relative_url == 'relative_url'

# Generated at 2022-06-21 22:41:39.870542
# Unit test for constructor of class Forbidden
def test_Forbidden():
    try:
        raise Forbidden(message="message", status_code=403)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_Forbidden()

# Generated at 2022-06-21 22:41:44.284098
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    content_range = ContentRange(1, 10000, 'bytes')
    content_range.check_range()
    assert 'bytes 0-10000/10000' == content_range.header()
    assert 'bytes 0-10000/10000' == str(content_range)
    assert content_range

# Generated at 2022-06-21 22:41:46.672074
# Unit test for constructor of class ServerError
def test_ServerError():
    result = ServerError('TestError')
    assert result.status_code == 500
    assert result.message == 'TestError'
    assert result.quiet == True

# Generated at 2022-06-21 22:41:51.227777
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    test = MethodNotSupported("{}", None, ['GET','POST','PUT','PATCH','DELETE','OPTION'])
    assert test.status_code == 405
    assert test.headers["Allow"] == ', '.join(['GET','POST','PUT','PATCH','DELETE','OPTION'])
    return test


# Generated at 2022-06-21 22:41:53.455680
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException(message="Load file error", status_code=404)


# Generated at 2022-06-21 22:41:56.811326
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    try:
        raise Unauthorized("Auth required.", scheme="Basic", realm="Restricted Area")
    except Unauthorized as err:
        assert err.headers['WWW-Authenticate'] == 'Basic realm="Restricted Area"'
    else:
        raise ValueError("Unauthorized exception not raised")

# Generated at 2022-06-21 22:41:58.557894
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    exc = InvalidSignal(message = "Invalid signal")
    assert exc.status_code == 400
    assert exc.message == "Invalid signal"

# Generated at 2022-06-21 22:42:01.901656
# Unit test for function add_status_code
def test_add_status_code():
    class MyException(SanicException):
        pass

    add_status_code(501, quiet=True)(MyException)

    assert isinstance(MyException().quiet, bool)
    assert isinstance(MyException.quiet, bool)
    assert MyException.status_code == 501
    assert MyException().status_code == 501
    assert MyException.__name__ == 'MyException'
    assert MyException().__class__.__name__ == 'MyException'

# Generated at 2022-06-21 22:42:08.074687
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as exc:
        raise ContentRangeError( 'test' ,0)
    assert exc.value.args[0] == 'test'
    assert exc.value.args[1] == 0
    assert exc.value.headers['Content-Range'] == 'bytes */0'
    assert exc.value.status_code == 416


# Generated at 2022-06-21 22:42:17.406310
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise SanicException(message="test", status_code=416)
    except SanicException as e:
        assert e.headers == {"Content-Range": "bytes */None"}

# Generated at 2022-06-21 22:42:24.761784
# Unit test for constructor of class PyFileError
def test_PyFileError():
    error = PyFileError("my_file")
    assert error.args == ("could not execute config file %s", "my_file")

    error = PyFileError(Path("my_file"))
    assert error.args == ("could not execute config file %s", "my_file")

    error = PyFileError(Path("my_file.py"))
    assert error.args == ("could not execute config file %s", "my_file.py")

# Generated at 2022-06-21 22:42:27.853294
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    message = "Method Not Supported"
    method = "POST"
    allowed_methods = ["GET", "PUT"]
    method_not_supported = MethodNotSupported(
        message, method, allowed_methods
    )



# Generated at 2022-06-21 22:42:30.520821
# Unit test for constructor of class Forbidden
def test_Forbidden():
    forbidden = Forbidden(message="403 Forbidden")
    assert forbidden.status_code == 403
    assert forbidden.message == "403 Forbidden"




# Generated at 2022-06-21 22:42:32.984893
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout()
    except RequestTimeout:
        pass
    else:
        assert False

# Generated at 2022-06-21 22:42:33.814373
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    exc = HeaderExpectationFailed("Expectation failed")


# Generated at 2022-06-21 22:42:34.875449
# Unit test for constructor of class PayloadTooLarge
def test_PayloadTooLarge():
    assert PayloadTooLarge("Payload Too Large", 413)

# Generated at 2022-06-21 22:42:38.398723
# Unit test for constructor of class SanicException
def test_SanicException():
    """
    Test case for SanicException
    """
    with pytest.raises(SanicException) as context:
        raise SanicException("")
    exception = context.value
    assert exception.message == ""
    assert exception.status_code == None


# Generated at 2022-06-21 22:42:42.102464
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    import pytest
    test_message = "Invalid Signal"
    test_object = InvalidSignal(test_message)

    assert test_object.message == test_message

# Generated at 2022-06-21 22:42:52.419883
# Unit test for constructor of class SanicException
def test_SanicException():
    err = SanicException("error message")
    assert type(err) == SanicException
    assert err.status_code == None
    assert err.message == "error message"
    assert err.quiet == None
    err2 = SanicException("another error message", status_code=404)
    assert err2.status_code == 404
    assert err2.message == "another error message"
    assert err2.quiet == None
    err3 = SanicException("yet another error message", status_code=500)
    assert err3.status_code == 500
    assert err3.message == "yet another error message"
    assert err3.quiet == None
    err4 = SanicException("yet another error message", status_code=500, quiet=False)
    assert err4.status_code == 500

# Generated at 2022-06-21 22:43:07.692691
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('this is a message')
    except Exception as e:
        assert e.args[0] == 'this is a message'
        assert e.status_code == 500

# Generated at 2022-06-21 22:43:11.137538
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    with pytest.raises(LoadFileException):
        raise LoadFileException("test")

if __name__=='__main__':
    test_LoadFileException()

# Generated at 2022-06-21 22:43:14.009874
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("test")
    except Exception as e:
        assert str(e) == "test"

# Generated at 2022-06-21 22:43:16.858590
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException('test of LoadFileException')
    except LoadFileException as err:
        assert err.args[0] == 'test of LoadFileException'

# Generated at 2022-06-21 22:43:23.072468
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    message = "Testing File Not Found"
    path = "Invalid/Path"
    relative_url = "relative/url/path"
    try:
        raise FileNotFound(message, path, relative_url)
    except FileNotFound as fnf:
        assert fnf.status_code == 404
        assert fnf.message == message
        assert fnf.path == path
        assert fnf.relative_url == relative_url

# Generated at 2022-06-21 22:43:25.276931
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
	assert isinstance(InvalidSignal("InvalidSignal"),InvalidSignal)


# Generated at 2022-06-21 22:43:26.972950
# Unit test for constructor of class ServiceUnavailable
def test_ServiceUnavailable():
    with pytest.raises(ServiceUnavailable) as error:
        raise ServiceUnavailable("Test message.")


# Generated at 2022-06-21 22:43:28.998433
# Unit test for constructor of class PyFileError
def test_PyFileError():
    with pytest.raises(PyFileError, match="could not execute config file"):
        raise PyFileError(file="test_name")

# Generated at 2022-06-21 22:43:32.043601
# Unit test for constructor of class HeaderExpectationFailed
def test_HeaderExpectationFailed():
    import pytest
    result = HeaderExpectationFailed('Your Header is not legit', 'Expectation')
    assert result.status_code == 417
    assert result.__str__() == 'Your Header is not legit'


# Generated at 2022-06-21 22:43:34.060576
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError()
    except ServerError as e:
        assert e.status_code == 500

# Generated at 2022-06-21 22:44:03.784781
# Unit test for constructor of class InvalidUsage
def test_InvalidUsage():
    with pytest.raises(InvalidUsage) as exc_info:
        raise InvalidUsage(message='Invalid Usage')
    assert str(exc_info.value) == 'Invalid Usage'
    assert exc_info.value.status_code == 400
    assert exc_info.value.quiet == True
    assert exc_info.value.__traceback__ == None


# Generated at 2022-06-21 22:44:06.566271
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    """
    This function tests the constructor of the class Unauthorized
    """
    # Should be able to create an object of the class Unauthorized
    obj = Unauthorized(
        message="some message",
        scheme="Basic",
        realm="Restricted Area"
    )
    assert obj.status_code == 401

# Generated at 2022-06-21 22:44:10.337332
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    err = InvalidSignal("Invalid Signal")
    assert isinstance(err, InvalidSignal)
    assert isinstance(err, SanicException)
    assert err.message == "Invalid Signal"
    assert err.status_code == None


# Generated at 2022-06-21 22:44:12.256869
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    cr = ContentRangeError('message', 3)
    assert cr.headers == {'Content-Range': 'bytes */3'}

# Generated at 2022-06-21 22:44:19.518518
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    try:
        raise ContentRangeError("error", 100)    # type: ignore
    except ContentRangeError as err:
        assert isinstance(err, Exception)
        assert isinstance(err, SanicException)
        assert isinstance(err, ContentRangeError)
        assert err.args == ("error",)
        assert err.message == "error"
        assert err.status_code == 416
        assert err.headers == {"Content-Range": f"bytes */100"}
    else:
        raise Exception("test_ContentRangeError() failed")

test_ContentRangeError()

# Generated at 2022-06-21 22:44:23.430060
# Unit test for constructor of class RequestTimeout
def test_RequestTimeout():
    try:
        raise RequestTimeout("RequestTimeout")
    except RequestTimeout as e:
        if not (e.status_code == 408 and e.message == "RequestTimeout"):
            raise e


if __name__ == '__main__':
    test_RequestTimeout()

# Generated at 2022-06-21 22:44:25.883403
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    message = 'this is message'
    content_range = {'total': 100}
    error = ContentRangeError(message, content_range)
    assert error.headers['Content-Range'] == 'bytes */100'

# Generated at 2022-06-21 22:44:28.027528
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    with pytest.raises(ContentRangeError) as excinfo:
        raise ContentRangeError(message="Range Not Satisfiable",content_range=100)
        assert excinfo.value=="Range Not Satisfiable"

# Generated at 2022-06-21 22:44:32.344455
# Unit test for constructor of class InvalidRangeType
def test_InvalidRangeType():
    try:
        raise InvalidRangeType("Range not satisfiable", 0)
    except InvalidRangeType as e:
        assert e.message == "Range not satisfiable"
        assert e.headers == {"Content-Range": f"bytes */{0}"}

# Generated at 2022-06-21 22:44:36.441562
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    with pytest.raises(Unauthorized) as err:
        raise Unauthorized("Test", realm="test")
        assert err.payload.realm == "test"
        assert err.payload.message == "Test"

# Generated at 2022-06-21 22:45:39.569550
# Unit test for constructor of class Unauthorized
def test_Unauthorized():
    # Check the constructor without kwargs
    try:
        e = Unauthorized("Auth required.",
                         scheme="Basic")
    except Exception as e:
        assert False

    # Check the constructor with kwargs
    try:
        e = Unauthorized("Auth required.",
                         scheme="Digest",
                         realm="Restricted Area",
                         qop="auth, auth-int",
                         algorithm="MD5",
                         nonce="abcdef",
                         opaque="zyxwvu")
    except Exception as e:
        assert False

    # Check the constructor with scheme=None
    try:
        e = Unauthorized("Auth required.")
    except Exception as e:
        assert True # Expected to raise exception

    # Check the constructor with kwargs, but scheme=None

# Generated at 2022-06-21 22:45:41.425624
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException("test LoadFileException")
    except LoadFileException as e:
        print("test_LoadFileException : ", e)


# Generated at 2022-06-21 22:45:45.273631
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError("Test")
    except Exception as e:
        pass
    assert e.args[0] == "Test"
    assert e.__class__.__name__ == "URLBuildError"

# Generated at 2022-06-21 22:45:48.785585
# Unit test for constructor of class MethodNotSupported
def test_MethodNotSupported():
    method_not_supported = MethodNotSupported("message", "method",["allowed" , "methods"])
    assert method_not_supported.headers == {"Allow": ", ".join(["allowed" , "methods"])}


# Generated at 2022-06-21 22:45:50.235289
# Unit test for function abort
def test_abort():
    try:
        abort(404)
    except NotFound:
        pass


# Generated at 2022-06-21 22:45:53.013180
# Unit test for constructor of class FileNotFound
def test_FileNotFound():
    e = FileNotFound("Test", "path", "rel_url")
    assert e.path == "path"
    assert e.relative_url == "rel_url"
    assert str(e) == "Test"
    assert e.__doc__.startswith("""
    **Status**: 404 Not Found
    """)

# Generated at 2022-06-21 22:45:57.292672
# Unit test for constructor of class SanicException
def test_SanicException():
    message = 'message'
    status_code = 500
    sanic_exception = SanicException(message, status_code)
    assert 'message' == sanic_exception.args[0]
    assert status_code == sanic_exception.status_code 


# Generated at 2022-06-21 22:46:00.727755
# Unit test for constructor of class ServerError
def test_ServerError():
    try:
        raise ServerError("Test Message")
    except ServerError as e:
        assert e.message == "Test Message"
        assert e.status_code == 500
    else:
        assert False, "ServerError not raised."

# Generated at 2022-06-21 22:46:04.125381
# Unit test for constructor of class HeaderNotFound
def test_HeaderNotFound():
    # Given
    expected_message = "some error"

    # When
    instance_HeaderNotFound = HeaderNotFound(message=expected_message)
    actual_message = instance_HeaderNotFound.args[0]

    # Then
    assert actual_message == expected_message

# Generated at 2022-06-21 22:46:05.584707
# Unit test for constructor of class SanicException
def test_SanicException():
    test = SanicException("Test Message",400)
    assert str(test) == "Test Message"

# Generated at 2022-06-21 22:48:01.910041
# Unit test for constructor of class NotFound
def test_NotFound():
    try:
        raise NotFound("NotFound")
    except NotFound as e:
        assert e.message == "NotFound"
        assert e.status_code == 404


# Generated at 2022-06-21 22:48:05.650188
# Unit test for constructor of class PyFileError
def test_PyFileError():
	file="testfile"
	try:
		raise PyFileError(file)
	except PyFileError as e:
		if file in str(e):
			print("test_PyFileError test pass")
		else:
			print("test_PyFileError test fail")



# Generated at 2022-06-21 22:48:09.510276
# Unit test for constructor of class URLBuildError
def test_URLBuildError():
    try:
        raise URLBuildError('error')
        assert False
    except URLBuildError as inst:
        assert inst.args[0] == 'error'
        assert issubclass(inst.__class__, ServerError)



# Generated at 2022-06-21 22:48:13.056110
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal(message="Message", status_code=999)
    except InvalidSignal as e:
        assert e.message == "Message"
        assert e.status_code == 999


# Generated at 2022-06-21 22:48:16.243193
# Unit test for constructor of class Forbidden
def test_Forbidden():
    x = Forbidden('Hello! I am a forbidden message :)')
    assert x.message == 'Hello! I am a forbidden message :)'
    assert x.status_code == 403


# Generated at 2022-06-21 22:48:20.913197
# Unit test for constructor of class Forbidden
def test_Forbidden():
    assert Forbidden("You are bad!").message == "You are bad!"
    assert Forbidden("You are bad!", 888).status_code == 888
    assert Forbidden("You are bad!", 888) == Forbidden("You are bad!", 888)



# Generated at 2022-06-21 22:48:23.058724
# Unit test for constructor of class InvalidSignal
def test_InvalidSignal():
    try:
        raise InvalidSignal("test")
    except InvalidSignal as e:
        assert e.status_code == 500
        assert e.quiet == False
        assert e.message == "test"


# Generated at 2022-06-21 22:48:24.667981
# Unit test for constructor of class ContentRangeError
def test_ContentRangeError():
    except1 = ContentRangeError(message="test message 1", content_range={"total": 1000})
    assert except1.headers["Content-Range"] == "bytes */1000"

# Generated at 2022-06-21 22:48:27.264941
# Unit test for constructor of class LoadFileException
def test_LoadFileException():
    try:
        raise LoadFileException()
    except LoadFileException as e:
        assert e.status_code == 500
        assert e.message == 'An error occurred while loading a file'

# Generated at 2022-06-21 22:48:29.977783
# Unit test for constructor of class NotFound
def test_NotFound():
    class_P = NotFound("Status", 404)
    assert class_P.message == "Status"
    assert class_P.status_code == 404

