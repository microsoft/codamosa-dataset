

# Generated at 2022-06-17 18:17:00.087012
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:09.396999
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short and long description
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short and long description and blank lines

# Generated at 2022-06-17 18:17:20.582213
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:31.856727
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:42.896861
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert doc

# Generated at 2022-06-17 18:17:54.632545
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:18:00.922674
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'


# Generated at 2022-06-17 18:18:10.027584
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'

# Generated at 2022-06-17 18:18:20.551198
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_func : some other function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description

# Generated at 2022-06-17 18:18:28.727278
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 0.1.0
        This is a deprecation warning.
    """
    docstring = NumpydocParser().parse(text)


# Generated at 2022-06-17 18:18:43.132610
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = inspect.cleandoc(docstring)
    parser = NumpydocParser()
    parsed_docstring = parser.parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short

# Generated at 2022-06-17 18:18:51.784032
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    A short description.

    A long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    Some notes.

    References
    ----------
    Some references.

    .. deprecated:: 0.1.0
        This is deprecated.
    """
    docstring = Nump

# Generated at 2022-06-17 18:19:04.997670
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        If something bad happens.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:19:15.044509
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_func : another function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:19:20.987589
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str, optional
        Description of arg2

    Raises
    ------
    ValueError
        Description of ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1"
   

# Generated at 2022-06-17 18:19:33.068507
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Raises
    ------
    ValueError
        If something goes wrong.

    Returns
    -------
    return_name : type
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring

# Generated at 2022-06-17 18:19:39.295731
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:48.643750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 42.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring

# Generated at 2022-06-17 18:19:58.905818
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        If something goes wrong.

    Warns
    -----
    UserWarning
        If something else goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:20:10.712700
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A description of arg1.
    arg2 : str
        A description of arg2.

    Returns
    -------
    int
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:20:25.105038
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    See Also
    --------
    other_function : Description of other function.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long

# Generated at 2022-06-17 18:20:34.064750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 0.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:20:43.098172
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    Warning
        A description of what might raise Warning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
   

# Generated at 2022-06-17 18:20:49.317371
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:20:57.182891
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = inspect.cleandoc(docstring)
    parser = NumpydocParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:21:07.817393
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:18.162776
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:28.946579
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:21:40.510351
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.  The long description
    is useful for e.g. providing examples of how to use the function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    arg3 : list
        Description of `arg3`

    Returns
    -------
    int
        Description of return value

    Other Parameters
    ----------------
    arg4 : dict
        Description of `arg4`
    arg5 : bool
        Description of `arg5`

    Raises
    ------
    ValueError
        Description of ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."

# Generated at 2022-06-17 18:21:48.124871
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:05.454831
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:14.318703
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional(default=None)
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:22:23.775329
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:34.438501
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 1.

    Returns
    -------
    str
        A description of the return value.
    """
    doc = NumpydocParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'A description of arg1.'

# Generated at 2022-06-17 18:22:45.691588
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the method parse of class NumpydocParser
    """
    text = """
    This is the short description.

    This is the long description.  The long description
    is used to explain in detail what the function does.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description.  The long description is used to explain in detail what the function does."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:22:57.448764
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:07.339670
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:23:18.007295
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.
    arg2 : type, optional
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:23:27.320760
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of error.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:23:36.996451
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int
        This is a description of arg2.
    arg3 : bool, optional
        This is a description of arg3.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of a raised ValueError.

    Warns
    -----
    UserWarning
        This is a description of a raised UserWarning.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-17 18:24:01.880612
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    :func:`some_other_function`
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:24:12.203670
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : bool, optional
        This is a description of arg3.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_

# Generated at 2022-06-17 18:24:22.350458
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
   

# Generated at 2022-06-17 18:24:32.023624
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1
    arg2 : int, optional
        Description of arg2 (default is 42)

    Returns
    -------
    str
        Description of return value
    """
    parser = NumpydocParser()
    parsed = parser.parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[0].description == "Description of arg1"
    assert parsed.meta

# Generated at 2022-06-17 18:24:41.368195
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:24:51.773492
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.

    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:25:03.672646
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring

# Generated at 2022-06-17 18:25:14.084559
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after

# Generated at 2022-06-17 18:25:24.538117
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:35.842021
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : str
        This is arg2.

    Returns
    -------
    int
        This is a return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:26:08.113685
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 0.
    arg3 : bool, optional
        Description of arg3. Default is True.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:26:17.068795
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert doc

# Generated at 2022-06-17 18:26:27.014306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : float, optional
        This is a description of arg3.
    arg4 : int, optional
        This is a description of arg4.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the ValueError exception.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:26:36.173677
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is the first argument.
    arg2 : int, optional
        This is the second argument.

    Returns
    -------
    str
        This is the return value.

    Raises
    ------
    ValueError
        This is a raised exception.

    Warns
    -----
    UserWarning
        This is a warning.

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring