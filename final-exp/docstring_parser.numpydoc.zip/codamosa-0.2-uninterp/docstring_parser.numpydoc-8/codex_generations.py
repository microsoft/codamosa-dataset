

# Generated at 2022-06-17 18:16:57.072257
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    kv_section = _KVSection("title", "key")
    assert kv_section.parse(text) == [
        DocstringMeta(["key"], description="value"),
        DocstringMeta(["key2"], description="values can also span...\n... multiple lines"),
    ]


# Generated at 2022-06-17 18:17:06.766193
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    assert section.parse("") == [DocstringMeta(["param"])]
    assert section.parse("\n") == [DocstringMeta(["param"])]
    assert section.parse("\n\n") == [DocstringMeta(["param"])]
    assert section.parse("\n\n\n") == [DocstringMeta(["param"])]
    assert section.parse("\n\n\n\n") == [DocstringMeta(["param"])]
    assert section.parse("\n\n\n\n\n") == [DocstringMeta(["param"])]
    assert section.parse("\n\n\n\n\n\n") == [DocstringMeta(["param"])]

# Generated at 2022-06-17 18:17:14.163947
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    assert list(_KVSection("title", "key").parse(text)) == [
        DocstringMeta(["key"], description="value"),
        DocstringMeta(["key2"], description="values can also span...\n... multiple lines"),
    ]


# Generated at 2022-06-17 18:17:19.900695
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description='arg_description'), DocstringMeta(['param'], description='descriptions can also span...\n    ... multiple lines')]


# Generated at 2022-06-17 18:17:26.984365
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:38.451017
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:17:46.928642
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:54.531560
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    assert section.parse(text) == [DocstringMeta(["param"], description="arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines")]


# Generated at 2022-06-17 18:18:03.645264
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    parser = _KVSection("title", "key")
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)
        print(inspect.cleandoc(value))
        print(parser._parse_item(key=match.group(), value=inspect.cleandoc(value)))


# Generated at 2022-06-17 18:18:08.756147
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    text = inspect.cleandoc(text)
    assert list(_KVSection("", "").parse(text)) == [
        ("key", "value"),
        ("key2 : type", "values can also span...\n... multiple lines"),
    ]



# Generated at 2022-06-17 18:18:26.523802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : str
        This is arg2.

    Returns
    -------
    int
        This is the return value.
    """
    parser = NumpydocParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'This is arg1.'

# Generated at 2022-06-17 18:18:35.491758
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Raises
    ------
    ValueError
        Description of ValueError.

    Returns
    -------
    return_name : type
        Description of return value.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:18:45.045060
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.
    arg2 : type
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the error.

    Warns
    -----
    UserWarning
        This is a description of the warning.

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function : This is a description of some_other_function.
    """
    )
    assert docstring.short

# Generated at 2022-06-17 18:18:53.293312
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            This is a description of arg1.
        arg2 : str
            This is a description of arg2.

        Returns
        -------
        str
            This is a description of the return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:19:05.521174
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str
        This is a description of arg2.
    arg3 : str, optional
        This is a description of arg3.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:19:15.556828
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name : type
            arg_description

        Returns
        -------
        return_name : type
            return_description
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"

# Generated at 2022-06-17 18:19:22.425300
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : list
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """


# Generated at 2022-06-17 18:19:34.118468
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args

# Generated at 2022-06-17 18:19:45.862668
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:55.320789
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    str
        The return value.

    Raises
    ------
    KeyError
        When a key is not found.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'param1']

# Generated at 2022-06-17 18:20:10.053186
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:19.347345
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('example')
    example
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:20:24.711843
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : bool
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:20:35.448310
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    RuntimeWarning
        A description of what might raise RuntimeWarning

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short

# Generated at 2022-06-17 18:20:44.249701
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:53.382791
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:21:05.492906
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:16.949280
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.

        Returns
        -------
        str
            Description of return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:21:28.099126
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
   

# Generated at 2022-06-17 18:21:40.139983
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """

    docstring = NumpydocParser().parse(text)


# Generated at 2022-06-17 18:21:55.857298
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_

# Generated at 2022-06-17 18:22:01.547049
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_func : does something else

    Notes
    -----
    This is a note.

    References
    ----------
    .. [1] A reference
    """

# Generated at 2022-06-17 18:22:11.193499
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:22:22.072653
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:32.892509
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        Short description.

        Long description.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required

        Raises
        ------
        ValueError
            A description of what might raise ValueError
        """
    )
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3


# Generated at 2022-06-17 18:22:44.645255
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for the case when text is None
    assert NumpydocParser().parse(None) == Docstring()

    # Test for the case when text is empty
    assert NumpydocParser().parse("") == Docstring()

    # Test for the case when text is not empty
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank

# Generated at 2022-06-17 18:22:57.068226
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:06.997918
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring

# Generated at 2022-06-17 18:23:17.773241
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Raises
        ------
        ValueError
            A description of what might raise ValueError
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg_name"]

# Generated at 2022-06-17 18:23:27.724417
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:42.514171
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str, optional
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring

# Generated at 2022-06-17 18:23:51.347250
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args

# Generated at 2022-06-17 18:24:02.622545
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : str
        arg_description

    arg_2 : int, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print(example)
    42
    """
    doc = NumpydocParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True


# Generated at 2022-06-17 18:24:12.740454
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param_1 : str
        This is a parameter.
    param_2 : int
        This is another parameter.

    Returns
    -------
    str
        This is a return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'param_1']
    assert docstring.meta[0].description == "This is a parameter."
    assert docstring.meta

# Generated at 2022-06-17 18:24:22.891944
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    arg_3 : type, optional
        Default is 'default_value'

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_func : does something else
    """

# Generated at 2022-06-17 18:24:32.387982
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:41.402974
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:51.773927
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:03.672702
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example)
    example

    Warnings
    --------
    This is a warning

    See Also
    --------
    other_func

    Notes
    -----
    This is a note

    References
    ----------
    This is a reference

    .. deprecated:: 0.1.0
        This is a deprecation warning
    """
   

# Generated at 2022-06-17 18:25:12.218962
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:26.881935
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print("hello")
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:25:37.193369
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1
    arg2 : int, optional
        Description of arg2
    arg3 : int, optional
        Description of arg3

    Returns
    -------
    str
        Description of return value

    Raises
    ------
    ValueError
        Description of exception
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:25:46.197798
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:56.922287
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:07.662006
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_func : some other function
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a short description.'

# Generated at 2022-06-17 18:26:16.774472
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : list
        This is a description of arg3.
    arg4 : list, optional
        This is a description of arg4.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short

# Generated at 2022-06-17 18:26:26.790058
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3. Default is 1.0.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:26:35.321020
# Unit test for method parse of class NumpydocParser