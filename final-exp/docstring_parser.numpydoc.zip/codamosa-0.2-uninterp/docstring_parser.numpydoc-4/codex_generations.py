

# Generated at 2022-06-17 18:16:56.800728
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    section = ParamSection("Parameters", "param")
    assert list(section.parse(text)) == [
        DocstringParam(
            args=["param", "arg_name"],
            description="arg_description",
            arg_name="arg_name",
            type_name=None,
            is_optional=False,
            default=None,
        ),
        DocstringParam(
            args=["param", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            arg_name="arg_2",
            type_name="type",
            is_optional=True,
            default=None,
        ),
    ]



# Generated at 2022-06-17 18:17:03.675095
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:17:11.687457
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.

    arg2 : type
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the error.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed

# Generated at 2022-06-17 18:17:19.015018
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(inspect.cleandoc(value))


# Generated at 2022-06-17 18:17:30.364092
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:17:37.176154
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.2
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].args == ["deprecation"]
    assert result[0].description == "This is a deprecation warning."
    assert result[0].version == "0.1.2"


# Generated at 2022-06-17 18:17:43.118184
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.0
        Use :func:`~.foo` instead.
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].args == ["deprecation"]
    assert result[0].description == "Use :func:`~.foo` instead."
    assert result[0].version == "0.1.0"


# Generated at 2022-06-17 18:17:46.355526
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.0\n    This is a deprecation warning"
    assert DeprecationSection("deprecated", "deprecation").parse(text) == [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning', version='1.0')]


# Generated at 2022-06-17 18:17:52.456656
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 0.1.2\n\n    This is deprecated."
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert next(result) == DocstringDeprecated(args=["deprecation"], description="This is deprecated.", version="0.1.2")


# Generated at 2022-06-17 18:17:57.964869
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.0
        This is a deprecation warning
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result == [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning', version='1.0')]


# Generated at 2022-06-17 18:18:14.359620
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    some_other_function
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-17 18:18:22.696499
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:33.171072
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:43.405689
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank

# Generated at 2022-06-17 18:18:52.042839
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:05.105286
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:19:10.953636
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_value : type
        Description of return_value.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:19.030362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param1 : type
        Description of param1.

    param2 : type, optional
        Description of param2.

    Returns
    -------
    return_name : type
        Description of return.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta

# Generated at 2022-06-17 18:19:29.976348
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_function : some other function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:19:37.882771
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:53.829112
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring_parsed = parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True

# Generated at 2022-06-17 18:20:02.221260
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:20:12.250950
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    some_other_function
    """
    docstring = inspect.cleandoc(docstring)
    parser = NumpydocParser()

# Generated at 2022-06-17 18:20:21.641717
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:31.883419
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:20:41.158594
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.
    arg3 : bool, optional
        A description of arg3.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert doc

# Generated at 2022-06-17 18:20:48.044115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    RuntimeWarning
        A description of what might warn

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_func : other function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:20:56.483112
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : str, optional
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:21:07.334425
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:17.862188
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:21:30.328927
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print(example)
    42

    See Also
    --------
    other_func
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:21:41.672587
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

    text = """
    Short description.

    Long description.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True


# Generated at 2022-06-17 18:21:54.822753
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    Some notes.

    References
    ----------
    Some references.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    parser = NumpydocParser()

# Generated at 2022-06-17 18:22:05.456530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print("hello")
    hello

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:22:14.318343
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:22:23.152260
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('''
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.

        Returns
        -------
        int
            Description of return value.
        ''')
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:22:34.006531
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:45.429634
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:52.357358
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    :func:`hello_world`
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:23:03.751060
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> example_code
    example_result

    Warnings
    --------
    This is a warning.

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert doc

# Generated at 2022-06-17 18:23:17.833076
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after

# Generated at 2022-06-17 18:23:27.756391
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.

    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:23:37.179607
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : str
            A description of arg1.
        arg2 : int, optional
            A description of arg2.
        arg3 : float, optional
            A description of arg3.
        arg4 : str, optional
            A description of arg4.

        Returns
        -------
        str
            A description of the return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:23:47.924645
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].type

# Generated at 2022-06-17 18:23:59.300664
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    ret1 : type
        Description of ret1.
    ret2 : type
        Description of ret2.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta

# Generated at 2022-06-17 18:24:10.034287
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:24:19.863188
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a test for the method parse of class NumpydocParser.
    Parameters
    ----------
    text : str
        The text to be parsed.
    Returns
    -------
    Docstring
        The parsed docstring.
    '''
    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'This is a test for the method parse of class NumpydocParser.'
    assert ret.long_description == 'The text to be parsed.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert ret.meta[0].args == ['param', 'text']
    assert ret.meta[0].description == 'The text to be parsed.'
    assert ret.meta[0].arg_name == 'text'

# Generated at 2022-06-17 18:24:30.295618
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:39.926270
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:50.801647
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:25:04.498508
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert parser.sections['Parameters'].title == 'Parameters'
    assert parser.sections['Parameters'].key == 'param'
    assert parser.sections['Parameters'].title_pattern == r'^(Parameters)\s*?\n{}\s*$'.format('-' * len('Parameters'))
    assert parser.sections['Parameters'].parse('parameter description') == [DocstringMeta(['param'], description='parameter description')]
    assert parser.sections['Parameters'].parse('parameter description\n\n') == [DocstringMeta(['param'], description='parameter description')]
    assert parser.sections['Parameters'].parse('parameter description\n\n\n') == [DocstringMeta(['param'], description='parameter description')]
    assert parser.sections['Parameters'].parse

# Generated at 2022-06-17 18:25:11.547739
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.title == "deprecated"
    assert section.key == "deprecation"
    assert section.title_pattern == "^\.\.\s*(deprecated)\s*::"
    assert section.parse("1.0.0\nThis is deprecated") == [DocstringDeprecated(args=['deprecation'], description='This is deprecated', version='1.0.0')]


# Generated at 2022-06-17 18:25:19.708673
# Unit test for function parse
def test_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    arg3 : bool, optional
        The third argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        When a value error is encountered.
    """
    docstring = parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args

# Generated at 2022-06-17 18:25:23.231096
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True
    assert y.key == "yields"
    assert y.title == "Yields"


# Generated at 2022-06-17 18:25:27.770781
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == "^\\.\\.\\s*(title)\\s*::"


# Generated at 2022-06-17 18:25:33.056040
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description=None)]


# Generated at 2022-06-17 18:25:36.934765
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False
    assert ReturnsSection("Yields", "yields").is_generator == True


# Generated at 2022-06-17 18:25:46.054342
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS

# Generated at 2022-06-17 18:25:51.509185
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == "^\.\.\s*(title)\s*::"


# Generated at 2022-06-17 18:25:53.025340
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False


# Generated at 2022-06-17 18:26:02.566508
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.0\n\n    This function is deprecated."
    assert list(DeprecationSection("deprecated", "deprecation").parse(text)) == [DocstringDeprecated(args=['deprecation'], description='This function is deprecated.', version='1.0')]


# Generated at 2022-06-17 18:26:07.108624
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description=None)]


# Generated at 2022-06-17 18:26:11.449612
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.title == "deprecated"
    assert section.key == "deprecation"
    assert section.title_pattern == r"^\.\.\s*(deprecated)\s*::"


# Generated at 2022-06-17 18:26:18.987476
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:27.193304
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Test for constructor of class DeprecationSection
    # Test for DeprecationSection with title and key
    title = "deprecated"
    key = "deprecation"
    deprecation_section = DeprecationSection(title, key)
    assert deprecation_section.title == title
    assert deprecation_section.key == key
    # Test for DeprecationSection with title and key
    title = "deprecated"
    key = "deprecation"
    deprecation_section = DeprecationSection(title, key)
    assert deprecation_section.title == title
    assert deprecation_section.key == key
    # Test for DeprecationSection with title and key
    title = "deprecated"
    key = "deprecation"

# Generated at 2022-06-17 18:26:33.058032
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:26:36.025085
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * len(title))
