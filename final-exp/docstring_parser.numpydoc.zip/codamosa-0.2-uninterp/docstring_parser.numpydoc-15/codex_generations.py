

# Generated at 2022-06-17 18:17:11.526171
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    type
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:17:18.643309
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:29.856651
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional (default=None)
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    parsed = NumpydocParser().parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta

# Generated at 2022-06-17 18:17:41.217651
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:17:54.053906
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : str
        This is arg2.

    Returns
    -------
    int
        This is return value.

    Raises
    ------
    ValueError
        This is a ValueError.
    """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring

# Generated at 2022-06-17 18:18:04.406097
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:15.014679
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello')
    hello

    Notes
    -----
    Notes go here.

    See Also
    --------
    other : class
        Other class in this module.

    References
    ----------
    .. [1] A reference.
    """
   

# Generated at 2022-06-17 18:18:24.348047
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:33.657443
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].type

# Generated at 2022-06-17 18:18:40.012690
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = _KVSection("title", "key")
    result = section.parse(text)
    assert result == [
        DocstringMeta(["key"], description="value"),
        DocstringMeta(["key2"], description="values can also span...\n... multiple lines"),
    ]


# Generated at 2022-06-17 18:18:54.113679
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:19:06.145817
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:16.050317
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:24.169772
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    Some other thing

    Notes
    -----
    This is a note.

    References
    ----------
    [1] Some reference
    """
    docstring = Numpyd

# Generated at 2022-06-17 18:19:34.819861
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:46.293450
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional (default=None)
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    ''')
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:19:57.502677
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_func : some other function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:20:09.759901
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:20:19.304707
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:20:27.728669
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A description of arg1.
    arg2 : str, optional
        A description of arg2.
    arg3 : str, optional(default=None)
        A description of arg3.

    Returns
    -------
    int
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning.

    Examples
    --------
    >>> print(example)
    42

    See Also
    --------
    other_func
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:20:38.144160
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"

# Generated at 2022-06-17 18:20:46.151574
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:54.581915
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:06.172679
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:21:17.052090
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('example')
    example
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:21:28.224318
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:21:35.334513
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-17 18:21:43.839061
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:55.583858
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of what might raise ValueError.

    Warns
    -----
    UserWarning
        Description of what might raise UserWarning.

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 0.1.0
        This is a deprecation warning.
    """

# Generated at 2022-06-17 18:22:05.875833
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    short description

    long description

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        if something goes wrong
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "short description"
    assert docstring.long_description == "long description"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "arg1 description"

# Generated at 2022-06-17 18:22:21.050316
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    [1] https://example.com
    """
    docstring = NumpydocParser().parse

# Generated at 2022-06-17 18:22:26.930780
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a test function.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : int, optional
        The second argument.

    Returns
    -------
    str
        The return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:22:35.391277
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:22:43.426553
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:56.444648
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name : type
            arg_description

        arg_2 : type, optional
            arg_2_description

        Raises
        ------
        ValueError
            A description of what might raise ValueError

        Returns
        -------
        return_name : type
            A description of this returned value
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:23:06.481924
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']

# Generated at 2022-06-17 18:23:17.291360
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:23:27.437854
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        If something goes wrong

    Warns
    -----
    UserWarning
        If something goes wrong

    See Also
    --------
    other_function

    Examples
    --------
    >>> print(example)
    example

    Notes
    -----
    This is a note

    References
    ----------
    [1] Some reference
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_

# Generated at 2022-06-17 18:23:37.057963
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:23:47.843307
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3. Default is 0.0.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    docstring = Nump

# Generated at 2022-06-17 18:24:02.006785
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:12.280756
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Attributes
    ----------
    attr_name
        attr_description

    Examples
    --------
    >>> print("hello world")
    hello world

    See Also
    --------
    other_func : some other function
    """
    parser = Numpyd

# Generated at 2022-06-17 18:24:22.423972
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:31.261174
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.
    arg3 : float, optional
        A description of arg3. Default is 0.0.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:24:38.745149
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:50.057374
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:02.445406
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
   

# Generated at 2022-06-17 18:25:10.674822
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:19.408434
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:25:27.834424
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'
    assert docstring.meta[1].args == ['param', 'arg_2']
   

# Generated at 2022-06-17 18:25:39.938063
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:49.153041
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> example()
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-17 18:25:58.685012
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 0.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:26:08.256491
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:26:17.150126
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:26:27.088874
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
   

# Generated at 2022-06-17 18:26:36.226805
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].type