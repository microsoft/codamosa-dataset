

# Generated at 2022-06-17 18:16:54.754499
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    assert section.parse(text) == [DocstringMeta(["param"], description=None)]


# Generated at 2022-06-17 18:16:58.898365
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.0\n"
    text += "   Use :func:`~foo.bar` instead."
    d = DeprecationSection("deprecated", "deprecation")
    assert d.parse(text) == [DocstringDeprecated(args=['deprecation'], description='Use :func:`~foo.bar` instead.', version='1.0')]

# Generated at 2022-06-17 18:17:04.498390
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = _KVSection("title", "key")
    items = list(section.parse(text))
    assert items[0].description == "value"
    assert items[1].description == "values can also span...\n... multiple lines"



# Generated at 2022-06-17 18:17:12.243790
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")

# Generated at 2022-06-17 18:17:21.671206
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta

# Generated at 2022-06-17 18:17:24.767730
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")
    for meta in section.parse(text):
        print(meta)


# Generated at 2022-06-17 18:17:27.257533
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].description == "This is a deprecation warning."
    assert result[0].version == "1.0"


# Generated at 2022-06-17 18:17:38.808580
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:44.171315
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description='arg_description'), DocstringMeta(['param'], description='descriptions can also span...\n... multiple lines')]


# Generated at 2022-06-17 18:17:47.628371
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.2\n    Use :func:`~foo.bar` instead."
    section = DeprecationSection("deprecated", "deprecation")
    meta = list(section.parse(text))
    assert meta[0].description == "Use :func:`~foo.bar` instead."
    assert meta[0].version == "1.2"

# Generated at 2022-06-17 18:17:57.537488
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    assert section.parse(text) == [DocstringMeta(['param'], description='arg_description'), DocstringMeta(['param'], description='descriptions can also span...\n... multiple lines')]


# Generated at 2022-06-17 18:18:03.908835
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description='arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines')]


# Generated at 2022-06-17 18:18:05.919987
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("title", "key")
    text = "text"
    assert section.parse(text) == [DocstringMeta(["key"], description="text")]


# Generated at 2022-06-17 18:18:17.041109
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.
    arg3 : list
        Description of arg3.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:18:21.821239
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description=None)]


# Generated at 2022-06-17 18:18:24.168916
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("title", "key")
    text = "value"
    assert section.parse(text) == [DocstringMeta(["key"], description="value")]


# Generated at 2022-06-17 18:18:30.963074
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:38.688318
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result[0].args == ['param', 'arg_name']
    assert result[0].description == 'arg_description'
    assert result[1].args == ['param', 'arg_2']
    assert result[1].description == 'descriptions can also span...\n... multiple lines'


# Generated at 2022-06-17 18:18:43.757109
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description='arg_description'), DocstringMeta(['param'], description='descriptions can also span...\n... multiple lines')]


# Generated at 2022-06-17 18:18:54.512735
# Unit test for method parse of class Section
def test_Section_parse():
    # Test for Section
    section = Section("Parameters", "param")
    assert section.parse("arg_name\n    arg_description") == [DocstringMeta(['param'], description='arg_description')]
    assert section.parse("arg_2 : type, optional\ndescriptions can also span...\n... multiple lines") == [DocstringMeta(['param'], description='descriptions can also span...\n... multiple lines')]
    # Test for ParamSection
    section = ParamSection("Parameters", "param")
    assert section.parse("arg_name\n    arg_description") == [DocstringParam(['param', 'arg_name'], description='arg_description', arg_name='arg_name', type_name=None, is_optional=None, default=None)]

# Generated at 2022-06-17 18:19:10.089482
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type, optional
        A description of this argument.

    arg_2 : type, optional
        A description of this argument.

    Returns
    -------
    return_name : type
        A description of this returned value.

    See Also
    --------
    some_other_function : This function does something similar.

    Notes
    -----
    Some notes about this function.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short

# Generated at 2022-06-17 18:19:18.594142
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:29.247951
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    result = NumpydocParser().parse(text)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param', 'arg1']
    assert result

# Generated at 2022-06-17 18:19:37.495074
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        description of arg1
    arg2 : type, optional
        description of arg2
    arg3 : type, optional
        description of arg3
        with multiple lines
    arg4 : type, optional
        description of arg4
        with multiple lines
        and default value
        Default is 1.0

    Returns
    -------
    return_name : type
        description of return_name
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after

# Generated at 2022-06-17 18:19:47.720538
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """

    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:58.158467
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"


# Generated at 2022-06-17 18:20:10.219847
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 1

# Generated at 2022-06-17 18:20:19.341052
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello')
    hello

    Warnings
    --------
    This is a warning.

    See Also
    --------
    Some other thing

    Notes
    -----
    Some notes.

    References
    ----------
    Some references.

    .. deprecated:: 1.0
        This is deprecated.
    """
   

# Generated at 2022-06-17 18:20:27.764013
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:20:35.800409
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta[1].args == ["param", "arg_2"]
   

# Generated at 2022-06-17 18:20:54.555193
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."

# Generated at 2022-06-17 18:21:06.172793
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for docstring with no sections
    text = """
    This is a short description.

    This is a long description.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0

    # Test for docstring with one section
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    doc

# Generated at 2022-06-17 18:21:11.177354
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:20.258189
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 1.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."
    assert doc

# Generated at 2022-06-17 18:21:29.991384
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:21:41.083934
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short and long description
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short and long description,
    # and a blank line after the long description
    assert NumpydocParser().parse(
        "short description\n\nlong description\n\n"
    )

# Generated at 2022-06-17 18:21:54.585047
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:05.394837
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1
        This is a description of arg1.
    arg2 : int
        This is a description of arg2.
    arg3 : int, optional
        This is a description of arg3.
    arg4 : int, optional(default=1)
        This is a description of arg4.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-17 18:22:14.315558
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:23.152490
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:43.217819
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:56.331530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short and long descriptions
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long description",
    )

    # Test for docstring with short and long descriptions and meta

# Generated at 2022-06-17 18:23:06.405578
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        if something goes wrong
    """
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta

# Generated at 2022-06-17 18:23:13.034502
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:24.636613
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:33.654514
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:23:44.546828
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:54.425705
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """

# Generated at 2022-06-17 18:24:05.723081
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:14.585988
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:24:35.595696
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:43.450265
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_1 : int
        A description of arg_1.
    arg_2 : str
        A description of arg_2.

    Returns
    -------
    int
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """

# Generated at 2022-06-17 18:24:52.969571
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world
    """

# Generated at 2022-06-17 18:25:03.998136
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is the first argument.
    arg2 : int
        This is the second argument.

    Returns
    -------
    str
        This is the return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:25:14.520483
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:24.935899
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.

    arg2 : int, optional
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."
    assert doc

# Generated at 2022-06-17 18:25:35.878147
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = parse(text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2

# Generated at 2022-06-17 18:25:41.381948
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:55.235470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1"

# Generated at 2022-06-17 18:26:06.623236
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert doc

# Generated at 2022-06-17 18:26:28.064994
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 42.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."