

# Generated at 2022-06-17 18:17:19.827440
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A positional argument.
    arg2 : str
        A keyword-only argument.
    *args
        Variable length argument list.
    **kwargs
        Arbitrary keyword arguments.

    Returns
    -------
    int
        The return value. True for success, False otherwise.

    Other Parameters
    ----------------
    arg3 : list
        Another argument.

    Raises
    ------
    ValueError
        When things go wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:17:31.046166
# Unit test for method parse of class Section
def test_Section_parse():
    text = '''
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")
    result = section.parse(text)
    assert result[0].args == ['param', 'arg_name']
    assert result[0].description == 'arg_description'
    assert result[0].arg_name == 'arg_name'
    assert result[0].type_name == None
    assert result[0].is_optional == False
    assert result[0].default == None
    assert result[1].args == ['param', 'arg_2']

# Generated at 2022-06-17 18:17:34.459028
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    result = section.parse(text)
    assert result == [DocstringMeta(['param'], description='arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines')]


# Generated at 2022-06-17 18:17:40.795306
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    a
        a
    b : int
        b
    """
    text = inspect.cleandoc(text)
    section = _KVSection("", "")
    assert list(section.parse(text)) == [
        DocstringMeta(["", "a"], description="a"),
        DocstringMeta(["", "b"], description="b"),
    ]



# Generated at 2022-06-17 18:17:47.543872
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    assert section.parse(text) == [DocstringMeta(['param'], description=None)]


# Generated at 2022-06-17 18:17:56.206028
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    docstring = section.parse(text)
    assert docstring == [DocstringMeta(['param', 'arg_name'], description='arg_description'), DocstringMeta(['param', 'arg_2'], description='descriptions can also span...\n... multiple lines')]


# Generated at 2022-06-17 18:18:03.130512
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    kv_section = _KVSection("title", "key")
    result = kv_section.parse(text)
    assert result is not None
    assert len(result) == 2
    assert result[0].description == "value"
    assert result[1].description == "values can also span...\n... multiple lines"


# Generated at 2022-06-17 18:18:10.983061
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:21.389472
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short and long description
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    # Test for docstring with short and long description, no blank line after short description

# Generated at 2022-06-17 18:18:26.640736
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:18:43.413873
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:18:52.076312
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:05.098047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:19:15.174566
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : float, optional
        This is a description of arg3.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 1

# Generated at 2022-06-17 18:19:21.029256
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == "arg_description"

# Generated at 2022-06-17 18:19:33.114651
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]

# Generated at 2022-06-17 18:19:39.318654
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str, optional
        This is a description of arg2.
    arg3 : float, optional
        This is a description of arg3.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 1

# Generated at 2022-06-17 18:19:48.645347
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print(example)
    """
    )

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:19:56.200095
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:20:02.958682
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:20:14.658078
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        A description of arg1.
    arg2 : type
        A description of arg2.

    Returns
    -------
    return_name : type
        A description of the returned value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.

    Warnings
    --------
    This is a warning.

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring

# Generated at 2022-06-17 18:20:24.239000
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:33.702596
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:40.958082
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        Short description.

        Long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.

        Returns
        -------
        str
            Description of return value.
        """
    )
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:20:54.818222
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:21:06.214362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:21:17.428635
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str, optional
        Description of arg2
    arg3 : float, optional
        Description of arg3

    Returns
    -------
    int
        Description of return value
    """
    parser = NumpydocParser()
    parsed_docstring = parser.parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:21:28.487457
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:40.366275
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_

# Generated at 2022-06-17 18:21:54.253166
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description
    arg3 : type, optional
        arg3 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:22:20.761652
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:22:26.781743
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:35.321995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    See Also
    --------
    other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring

# Generated at 2022-06-17 18:22:43.300869
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert parse("") == Docstring()

    # Test for docstring with only short description
    assert parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short and long description
    assert parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short and long description

# Generated at 2022-06-17 18:22:56.406864
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:23:06.445071
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    docstring_parsed = NumpydocParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True
    assert docstring_parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:23:13.061329
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:24.721700
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:36.330684
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:48.212873
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:24:24.179172
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_function
    """
    ret = NumpydocParser().parse(text)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."

# Generated at 2022-06-17 18:24:33.412862
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:24:42.020858
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:24:54.689340
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : str, optional
        Description of arg3.
    arg4 : str, optional
        Description of arg4.

    Returns
    -------
    int
        Description of return value.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:25:05.078652
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:14.731586
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2. Default is 'default'.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert doc

# Generated at 2022-06-17 18:25:22.430173
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring

# Generated at 2022-06-17 18:25:34.022816
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:43.990667
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:25:56.241308
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a docstring.

    Parameters
    ----------
    a : int
        The first parameter.
    b : str
        The second parameter.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If `a` is negative.

    See Also
    --------
    other_func : related function

    Examples
    --------
    >>> a = 5
    >>> b = 6
    >>> c = add(a, b)
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring."

# Generated at 2022-06-17 18:26:30.599954
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg_name"]

# Generated at 2022-06-17 18:26:37.304437
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str, optional
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1"
    assert docstring.meta[0].arg_name == 'arg1'