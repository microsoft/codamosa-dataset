

# Generated at 2022-06-17 18:16:53.989146
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 0.1\n   Use :func:`~.foo` instead."
    result = DeprecationSection("deprecated", "deprecation").parse(text)
    assert next(result).description == "Use :func:`~.foo` instead."

# Generated at 2022-06-17 18:16:58.495273
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.0
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    expected = [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning.', version='0.1.0')]
    assert result == expected

# Generated at 2022-06-17 18:17:02.652923
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    text = "1.0\n    A description of what might raise ValueError"
    result = section.parse(text)
    assert result[0].description == "A description of what might raise ValueError"
    assert result[0].version == "1.0"


# Generated at 2022-06-17 18:17:07.249433
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    assert section.parse(text) == [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning.', version='1.0')]


# Generated at 2022-06-17 18:17:14.071617
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.0\n    Use :func:`~.foo` instead."
    assert list(DeprecationSection("deprecated", "deprecation").parse(text)) == [
        DocstringDeprecated(
            args=["deprecation"],
            description="Use :func:`~.foo` instead.",
            version="1.0",
        )
    ]



# Generated at 2022-06-17 18:17:19.255189
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.0
        This is a deprecation warning
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].description == "This is a deprecation warning"
    assert result[0].version == "1.0"


# Generated at 2022-06-17 18:17:25.103445
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.0
        This is a deprecated function.
    """
    result = DeprecationSection("deprecated", "deprecation").parse(text)
    assert result[0].description == "This is a deprecated function."
    assert result[0].version == "0.1.0"


# Generated at 2022-06-17 18:17:31.282112
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:36.366056
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")

# Generated at 2022-06-17 18:17:38.452236
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = '.. deprecated:: 1.2.3\n    This is a deprecation warning'
    section = DeprecationSection('deprecated', 'deprecation')
    assert section.parse(text) == [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning', version='1.2.3')]


# Generated at 2022-06-17 18:18:17.378375
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta[1].args == ["param", "arg_2"]
   

# Generated at 2022-06-17 18:18:26.905498
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:18:35.812131
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_

# Generated at 2022-06-17 18:18:45.284838
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:53.471232
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:19:05.667059
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type, optional
        A description of this argument.

    arg_2 : type
        A description of this argument.

    Returns
    -------
    return_name : type
        A description of this returned value.

    Examples
    --------
    >>> print(example)
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg_name']

# Generated at 2022-06-17 18:19:15.676893
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description


# Generated at 2022-06-17 18:19:22.651270
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.
    arg3 : float, optional
        Description of arg3. Default is 2.0.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print(1)
    1
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."


# Generated at 2022-06-17 18:19:34.320504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert doc

# Generated at 2022-06-17 18:19:46.140187
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    :py:class:`~.SomeClass`
    :py:func:`~.some_function`
    """
    docstring = N

# Generated at 2022-06-17 18:20:00.465975
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:20:11.524041
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> example
    example
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-17 18:20:20.129792
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> example_usage()
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:20:28.386581
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:39.814653
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:20:47.109322
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print("hello world")
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    other_func : some other function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."


# Generated at 2022-06-17 18:20:56.750445
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert doc

# Generated at 2022-06-17 18:21:07.525176
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:21:18.394043
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:29.146537
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print(example)
    example

    See Also
    --------
    other_func : some other function
    other_class : some other class
    module.other_func : some other function from another module
    """

   

# Generated at 2022-06-17 18:21:42.884101
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:55.248034
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 0.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1.'
    assert docstring

# Generated at 2022-06-17 18:22:05.680200
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:14.341929
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len

# Generated at 2022-06-17 18:22:23.181999
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:34.007431
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:22:45.429137
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:22:57.333378
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.

    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:23:07.267286
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
   

# Generated at 2022-06-17 18:23:17.971309
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.
    It can span multiple lines.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description.\nIt can span multiple lines."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-17 18:23:36.259246
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.
    arg3 : float, optional, default=1.0
        A description of arg3.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
   

# Generated at 2022-06-17 18:23:48.143686
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.
        arg3 : bool, optional
            Description of arg3.

        Returns
        -------
        int
            Description of return value.
        """
    )

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["returns"]
    assert doc

# Generated at 2022-06-17 18:23:59.697991
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    SomeOtherClass
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-17 18:24:04.778590
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 1.
    arg3 : bool
        A description of arg3.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:24:10.012946
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.
    arg3 : type, optional
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return.

    Raises
    ------
    ValueError
        Description of ValueError.

    Warns
    -----
    UserWarning
        Description of UserWarning.

    Examples
    --------
    >>> example_code()
    example_result

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    parser = NumpydocParser()

# Generated at 2022-06-17 18:24:19.822219
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:30.246538
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:39.857272
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:24:50.730293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:25:03.151362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("Short description") == Docstring(
        short_description="Short description"
    )

    # Test for docstring with short and long description
    assert NumpydocParser().parse("Short description\n\nLong description") == Docstring(
        short_description="Short description",
        long_description="Long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short and long description and blank lines

# Generated at 2022-06-17 18:25:26.974525
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:37.233958
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:46.220416
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.

    arg2 : type, optional
        Description of arg2.

    arg3 : type, optional
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.

    See Also
    --------
    see_also
        Description of see_also.

    Examples
    --------
    >>> example
    example_output
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
   

# Generated at 2022-06-17 18:25:53.590740
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:02.766227
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:13.323023
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        If something bad happens.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:26:23.133861
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:33.330047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('example')
    example

    See Also
    --------
    other_func : some other function
    """
    docstring = NumpydocParser().parse(text)