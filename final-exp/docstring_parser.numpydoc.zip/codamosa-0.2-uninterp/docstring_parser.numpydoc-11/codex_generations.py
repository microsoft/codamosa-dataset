

# Generated at 2022-06-17 18:17:10.372160
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:21.021867
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True

# Generated at 2022-06-17 18:17:32.033261
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:39.427461
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:44.901529
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:55.317515
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:59.376867
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = '.. deprecated:: 1.0\n\n    This is a deprecated function.'
    section = DeprecationSection("deprecated", "deprecation")
    docstring = section.parse(text)
    assert docstring[0].description == 'This is a deprecated function.'
    assert docstring[0].version == '1.0'


# Generated at 2022-06-17 18:18:08.830093
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:18:19.280354
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring

# Generated at 2022-06-17 18:18:24.332529
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].args == ["deprecation"]
    assert result[0].description == "This is a deprecation warning."
    assert result[0].version == "1.0"


# Generated at 2022-06-17 18:18:36.419143
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:40.478154
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    doc = NumpydocParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:18:53.808668
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test for docstring with only long description
    assert NumpydocParser().parse("\nLong description.") == Docstring(
        short_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    )

    # Test for docstring with short and long description

# Generated at 2022-06-17 18:19:05.852489
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg_name']

# Generated at 2022-06-17 18:19:15.840037
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:23.709830
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello')
    hello
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:19:34.535402
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> example_code
    example_result

    Warnings
    --------
    This is a warning.

    See Also
    --------
    other_function
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:19:46.217916
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_value : type
        Description of return_value.
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:57.455673
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    SomeOtherClass
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-17 18:20:09.715039
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.
    arg3 : float, optional
        Description of arg3. Default is 1.0.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello')
    hello
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:20:23.277835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:20:32.873552
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.

    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:20:42.046813
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description

    Raises
    ------
    ValueError
        if something goes wrong

    Warns
    -----
    UserWarning
        if something goes wrong

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_function

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """)
    assert docstring

# Generated at 2022-06-17 18:20:55.066820
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:06.247700
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:17.103132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.
    arg3 : bool, optional
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]


# Generated at 2022-06-17 18:21:28.223240
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description. It can span multiple lines.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 3.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description. It can span multiple lines."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert doc

# Generated at 2022-06-17 18:21:40.178258
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:54.148113
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:05.291529
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:22:25.577655
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : str
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    See Also
    --------
    other_func

    Examples
    --------
    >>> print(this_func(1, 2, 3))
    6
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_

# Generated at 2022-06-17 18:22:30.846013
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2. Default is 1.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.

    Warns
    -----
    UserWarning
        Description of UserWarning.

    See Also
    --------
    other_func
    """

    parser = NumpydocParser()
    docstring = parser.parse(text)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:22:42.687382
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """

# Generated at 2022-06-17 18:22:56.097999
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for method parse of class NumpydocParser
    # This is a method
    text = """
    This is a method.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a method."
    assert docstring.long_description == "The first argument.\nThe second argument."
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[1].description

# Generated at 2022-06-17 18:23:06.208999
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.

    arg2 : type, optional
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']


# Generated at 2022-06-17 18:23:17.248837
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_func : does something else
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:23:27.437854
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:23:37.325235
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:48.103678
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Raises
    ------
    ValueError
        If something goes wrong.

    Returns
    -------
    return_name : type
        return description
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:23:59.695630
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:14.528273
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.

        Returns
        -------
        int
            Description of return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:24:23.669143
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 5.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:24:33.074542
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:24:40.044610
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : bool, optional
        This is a description of arg3.

    Returns
    -------
    str
        This is a description of the return value.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:24:51.395576
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:25:03.479785
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta[1].args == ["param", "arg_2"]
   

# Generated at 2022-06-17 18:25:12.092848
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param1 : type
        Description of param1.
    param2 : type, optional
        Description of param2.
    param3 : type, optional
        Description of param3.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "param1"]
    assert docstring.meta

# Generated at 2022-06-17 18:25:20.566599
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:25:28.562101
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True

# Generated at 2022-06-17 18:25:38.968287
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_

# Generated at 2022-06-17 18:26:01.685928
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:26:12.262621
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is arg1.
    arg2 : int
        This is arg2.

    Returns
    -------
    str
        This is the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:26:22.677935
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A description of arg1.
    arg2 : str
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:26:33.296897
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('''
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required

        Raises
        ------
        ValueError
            A description of what might raise ValueError
        ''')
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True