

# Generated at 2022-06-17 18:17:14.364401
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:21.613787
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key1
        value1
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    parser = _KVSection("title", "key")
    result = parser.parse(text)
    assert result is not None
    assert len(result) == 2
    assert result[0].args == ["key", "key1"]
    assert result[0].description == "value1"
    assert result[1].args == ["key", "key2"]
    assert result[1].description == "values can also span...\n... multiple lines"


# Generated at 2022-06-17 18:17:28.976088
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:37.226632
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = _KVSection("", "")
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:17:39.177279
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    parser = ParamSection("Parameters", "param")
    for meta in parser.parse(text):
        print(meta)


# Generated at 2022-06-17 18:17:47.335418
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning.

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function : some other function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description

# Generated at 2022-06-17 18:17:55.634794
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:18:02.309465
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    text = inspect.cleandoc(text)
    assert list(ParamSection("Parameters", "param").parse(text)) == [
        DocstringParam(
            args=["param", "key"],
            description="value",
            arg_name="key",
            type_name=None,
            is_optional=False,
            default=None,
        ),
        DocstringParam(
            args=["param", "key2"],
            description="values can also span...\n... multiple lines",
            arg_name="key2",
            type_name="type",
            is_optional=False,
            default=None,
        ),
    ]


# Generated at 2022-06-17 18:18:10.511798
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.

    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:18:17.702991
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """

    text = inspect.cleandoc(text)
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(value)


# Generated at 2022-06-17 18:18:35.248211
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    return_name : type
        return description
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "arg1 description"

# Generated at 2022-06-17 18:18:44.793905
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:18:53.138111
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:05.429156
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> example_code
    example_result

    See Also
    --------
    other_func
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:19:15.470897
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:19:22.030211
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:19:33.796099
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:19:45.572282
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:19:55.196320
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:20:02.616944
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:20:19.413722
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert doc

# Generated at 2022-06-17 18:20:27.798679
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    SomeOtherClass
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:20:35.828277
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'
    assert docstring.meta[1].args == ['param', 'arg_2']
   

# Generated at 2022-06-17 18:20:42.450270
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'

# Generated at 2022-06-17 18:20:48.928427
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:20:57.256022
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : int, optional
        The second argument.
    arg3 : float, optional
        The third argument.

    Returns
    -------
    str
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring

# Generated at 2022-06-17 18:21:07.872580
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:18.640997
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:21:29.272896
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.
    arg3 : bool
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:21:40.679824
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:05.901269
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:14.392243
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:22:23.826342
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : str
        This is arg2.

    Returns
    -------
    int
        This is a return value.

    Raises
    ------
    ValueError
        This is a raised exception.

    Warns
    -----
    UserWarning
        This is a warning.

    Examples
    --------
    >>> print('This is an example.')
    This is an example.

    See Also
    --------
    :py:func:`~.other_function`
        This is a related function.
    """


# Generated at 2022-06-17 18:22:34.498058
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg : int
        A positional argument.
    kwarg : str, optional
        A keyword-only argument.
    *args
        Variable length argument list.
    **kwargs
        Arbitrary keyword arguments.

    Returns
    -------
    None
        This method returns nothing.

    Raises
    ------
    ValueError
        If something bad happens.

    Warns
    -----
    UserWarning
        If something not so bad happens.

    See Also
    --------
    :py:func:`test_NumpydocParser_parse`
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long

# Generated at 2022-06-17 18:22:45.720779
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:52.673463
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:04.191293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of what might raise ValueError.
    """
    doc = NumpydocParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta

# Generated at 2022-06-17 18:23:16.423251
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:26.915920
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:36.839184
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str, optional
            Description of arg2.
        arg3 : bool
            Description of arg3.

        Returns
        -------
        int
            Description of return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:24:02.420810
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello world')
    hello world

    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert doc

# Generated at 2022-06-17 18:24:12.590494
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1.'
    assert doc

# Generated at 2022-06-17 18:24:22.750406
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:32.269688
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:24:41.403430
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]

# Generated at 2022-06-17 18:24:51.801312
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # Test for docstring with short description and long description
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        long_description="long description",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    # Test for docstring with short description and long description
    # with no blank line between them

# Generated at 2022-06-17 18:25:03.672726
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:25:14.130229
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"


# Generated at 2022-06-17 18:25:24.577973
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:25:35.837663
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:26:11.037110
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    :py:func:`some_other_function`
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:26:18.798924
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """

    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 2

    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:26:27.017806
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:26:35.489288
# Unit test for method parse of class NumpydocParser