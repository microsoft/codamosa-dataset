

# Generated at 2022-06-17 18:17:09.209660
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:20.444695
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")

# Generated at 2022-06-17 18:17:31.726182
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:42.779000
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:54.580417
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:18:00.821479
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert doc

# Generated at 2022-06-17 18:18:09.959391
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:18:20.477655
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:28.698148
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:36.380530
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")
    items = list(section.parse(text))
    assert len(items) == 2
    assert items[0].args == ["param", "arg_name"]
    assert items[0].description == "arg_description"
    assert items[0].arg_name == "arg_name"
    assert items[0].type_name is None
    assert items[0].is_optional is False
    assert items[0].default is None
    assert items[1].args == ["param", "arg_2"]

# Generated at 2022-06-17 18:18:54.252520
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        If something bad happens.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:06.236755
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:16.121339
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:24.392122
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:19:34.957256
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:46.329293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A description of arg1.
    arg2 : str, optional
        A description of arg2.
    arg3 : float, optional
        A description of arg3. Default is 1.0.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.

    Returns
    -------
    int
        A description of the return value.

    Examples
    --------
    >>> print(example())
    42
    """

# Generated at 2022-06-17 18:19:57.497056
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:20:09.763958
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        A description of arg1.
    arg2 : type, optional
        A description of arg2.

    Returns
    -------
    return_name : type
        A description of the returned value.

    Warnings
    --------
    This is a warning.

    See Also
    --------
    other_func : a function
        A description of other_func.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:20:19.304337
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:20:24.639788
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2. Default is 1.

    Returns
    -------
    str
        A description of the return value.
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:20:39.687849
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.

    .. deprecated:: 1.0
        This is a deprecation warning.
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short

# Generated at 2022-06-17 18:20:47.021696
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:20:56.731046
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:07.496449
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:21:18.010579
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A description of arg1.
    arg2 : str
        A description of arg2.

    Returns
    -------
    int
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:21:28.843946
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print("hello world")
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:21:40.476491
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:21:54.290378
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    Warning
        A description of what might raise Warning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_func : does something else

    Notes
    -----
    This is a note.

    References
    ----------
    [1] http://example.com
    """

# Generated at 2022-06-17 18:22:05.394651
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:22:14.258208
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:26.801201
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:35.346823
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.

    arg2 : type, optional
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of what might raise ValueError.
    """

# Generated at 2022-06-17 18:22:43.324652
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:49.587206
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2. Default is 1.
    arg3 : bool, optional
        Description of arg3. Default is False.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:22:58.669485
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring.meta[1].description == "Description of arg2."

# Generated at 2022-06-17 18:23:08.152297
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:18.507452
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1
    arg2 : int, optional
        Description of arg2

    Returns
    -------
    str
        Description of return value
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1"

# Generated at 2022-06-17 18:23:28.197920
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    :func:`some_other_function`
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is the short description."

# Generated at 2022-06-17 18:23:37.388975
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:23:48.208471
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:10.202440
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:20.140439
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:30.465122
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'
    assert docstring.meta[1].args == ['param', 'arg_2']
   

# Generated at 2022-06-17 18:24:40.065042
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is arg1.
    arg2 : str
        This is arg2.

    Returns
    -------
    str
        This is the return value.

    Raises
    ------
    ValueError
        This is a ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:24:50.903325
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:25:03.451802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required

        Raises
        ------
        ValueError
            A description of what might raise ValueError

        Warns
        -----
        UserWarning
            A description of what might raise UserWarning

        Examples
        --------
        >>> print(example)
        42
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long

# Generated at 2022-06-17 18:25:13.780125
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:24.208382
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:35.758671
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:25:45.461606
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:26.472132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # test for short description
    assert NumpydocParser().parse("short description") == Docstring(
        short_description="short description"
    )

    # test for long description
    assert NumpydocParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long description",
    )

    # test for short description with blank line after

# Generated at 2022-06-17 18:26:35.118445
# Unit test for method parse of class NumpydocParser