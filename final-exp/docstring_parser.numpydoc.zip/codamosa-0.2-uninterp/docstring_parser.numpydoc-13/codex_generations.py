

# Generated at 2022-06-17 18:17:19.829521
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.

    arg2 : int
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Examples
    --------
    >>> print(example())
    42
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:17:31.046404
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg

# Generated at 2022-06-17 18:17:36.213978
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()

    # Test for docstring with only short description
    docstring = NumpydocParser().parse("short description")
    assert docstring.short_description == "short description"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test for docstring with short description and long description
    docstring = NumpydocParser().parse("short description\n\nlong description")
    assert docstring.short_description == "short description"
    assert docstring.long_description == "long description"
    assert docstring.blank_after_short_description is True
    assert docstring.blank

# Generated at 2022-06-17 18:17:45.536471
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:55.495967
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:02.097833
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is the first argument.

    arg2 : int
        This is the second argument.

    Returns
    -------
    str
        This is the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "This is the first argument."
    assert docstring.meta

# Generated at 2022-06-17 18:18:10.388104
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:18:20.947043
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : str
            This is a description of arg1.
        arg2 : int, optional
            This is a description of arg2.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "This is a description of arg1."

# Generated at 2022-06-17 18:18:29.093520
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:33.790907
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:46.258586
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:54.140823
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:19:06.145712
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name : type
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta

# Generated at 2022-06-17 18:19:11.437925
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional, default=None
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_

# Generated at 2022-06-17 18:19:19.286350
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:30.338014
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a test docstring.

    Parameters
    ----------
    arg1 : str
        This is a test argument.
    arg2 : int, optional
        This is another test argument.

    Returns
    -------
    str
        This is a test return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a test argument.\nThis is another test argument."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "This is a test argument."
   

# Generated at 2022-06-17 18:19:38.089246
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:19:48.036022
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:58.381219
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional
        Description of arg3. Default is 'default'.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
   

# Generated at 2022-06-17 18:20:10.334270
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:20:23.543015
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    result = parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:20:33.092557
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-17 18:20:40.131587
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        This is a description of arg1.
    arg2 : str
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "This is a description of arg1."

# Generated at 2022-06-17 18:20:54.678076
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:21:06.210908
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:17.428523
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.
    arg3 : float, optional
        This is a description of arg3.
    arg4 : str, optional
        This is a description of arg4.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:21:23.815203
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:31.367460
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example())
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:21:41.434345
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A string argument.
    arg2 : int, optional
        An optional integer.
    arg3 : float, optional
        An optional float.

    Returns
    -------
    str
        A string.

    Raises
    ------
    ValueError
        If something bad happens.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:21:54.735615
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:22:07.316196
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'
    assert docstring.meta[1].args == ['param', 'arg_2']
   

# Generated at 2022-06-17 18:22:15.454945
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of the exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:22:24.166760
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.

    arg2 : type
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    See Also
    --------
    other_func
        This is a description of the other function.

    Notes
    -----
    This is a note.

    References
    ----------
    This is a reference.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:22:34.644253
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring

# Generated at 2022-06-17 18:22:45.809482
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:57.481355
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.
    """
    parser = NumpydocParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:23:07.376026
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:18.044271
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print(example)
    42
    ''')
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short

# Generated at 2022-06-17 18:23:27.923044
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:37.263476
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello')
    hello

    Warnings
    --------
    This is a warning.

    See Also
    --------
    other_function : another function
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert doc

# Generated at 2022-06-17 18:23:54.590338
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param1 : type
        Description of param1.
    param2 : type, optional
        Description of param2.
    param3 : type, optional
        Description of param3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.

    Warns
    -----
    UserWarning
        Description of UserWarning.

    Examples
    --------
    >>> example
    example

    See Also
    --------
    see_also

    Notes
    -----
    Note

    References
    ----------
    reference

    .. deprecated:: 1.0
        Deprecation warning.
    """
    docstring = NumpydocParser

# Generated at 2022-06-17 18:24:05.856937
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional (default=None)
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:24:14.673047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.

    arg2 : int, optional
        A description of arg2.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.

    Returns
    -------
    return_name : type
        A description of this returned value.

    another_type
        Return names are optional, types are required.

    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:24:23.749024
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value

    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> example_usage()
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
   

# Generated at 2022-06-17 18:24:33.134732
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:40.095884
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world
    """
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True


# Generated at 2022-06-17 18:24:50.947801
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the method parse of class NumpydocParser
    """
    # Test case 1
    text = """
    This is a test docstring.

    Parameters
    ----------
    arg1 : str
        This is the first argument.
    arg2 : int
        This is the second argument.

    Returns
    -------
    str
        This is the return value.
    """

# Generated at 2022-06-17 18:25:03.440591
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        This is a description of arg1.
    arg2 : type
        This is a description of arg2.

    Returns
    -------
    return_name : type
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of what might raise ValueError.
    """


# Generated at 2022-06-17 18:25:12.064611
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta[1].args == ['param', 'arg_2']
   

# Generated at 2022-06-17 18:25:20.561511
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:33.719530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:25:43.879364
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg_name : type
            arg_description

        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_name : type
            A description of this returned value

        another_type
            Return names are optional, types are required

        Raises
        ------
        ValueError
            A description of what might raise ValueError
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_

# Generated at 2022-06-17 18:25:56.188268
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:07.252256
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'arg_description'


# Generated at 2022-06-17 18:26:16.645306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn

    Examples
    --------
    >>> print('hello world')
    hello world

    Notes
    -----
    Some notes.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."

# Generated at 2022-06-17 18:26:26.670232
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of error.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:26:35.237236
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> print('hello')
    hello

    See Also
    --------
    other_func
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."