

# Generated at 2022-06-17 18:17:27.427795
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test method parse of class NumpydocParser"""
    parser = NumpydocParser()
    docstring = parser.parse("""
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Examples
    --------
    >>> example
    example
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2

# Generated at 2022-06-17 18:17:38.998448
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:47.222966
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:17:58.906908
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:08.427778
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:18.896778
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        If something bad happens.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:18:27.443343
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:36.194035
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional, default=None
        Description of arg3.

    Returns
    -------
    return_name : type
        Description of return_name.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:18:41.099425
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:18:53.859554
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:19:01.816477
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.2.3\n    This is deprecated"
    section = DeprecationSection("deprecated", "deprecation")
    meta = list(section.parse(text))
    assert meta[0].args == ["deprecation"]
    assert meta[0].description == "This is deprecated"
    assert meta[0].version == "1.2.3"

# Generated at 2022-06-17 18:19:03.745942
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 0.1.0\n\n    This is a deprecation warning"
    docstring = NumpydocParser().parse(text)
    assert docstring.meta[0].description == "This is a deprecation warning"
    assert docstring.meta[0].version == "0.1.0"


# Generated at 2022-06-17 18:19:08.822752
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    text = "1.0.0\n    A description of what might raise ValueError"
    result = section.parse(text)
    assert result[0].description == "A description of what might raise ValueError"
    assert result[0].version == "1.0.0"


# Generated at 2022-06-17 18:19:14.554296
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.2.3
        This is a deprecation warning.
    """
    section = DeprecationSection("deprecated", "deprecation")
    assert list(section.parse(text)) == [
        DocstringDeprecated(
            args=["deprecation"],
            description="This is a deprecation warning.",
            version="1.2.3",
        )
    ]


# Generated at 2022-06-17 18:19:18.211459
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    text = ".. deprecated:: 0.1.2\n\n    This is deprecated"
    result = next(section.parse(text))
    assert result.args == ["deprecation"]
    assert result.description == "This is deprecated"
    assert result.version == "0.1.2"


# Generated at 2022-06-17 18:19:21.603821
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """.. deprecated:: 1.0
        This is a deprecation warning"""
    d = DeprecationSection("deprecated", "deprecation")
    assert d.parse(text) == [DocstringDeprecated(args=['deprecation'], description='This is a deprecation warning', version='1.0')]


# Generated at 2022-06-17 18:19:33.501995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.
    arg3 : type, optional
        Description of arg3.
    arg4 : type, optional
        Description of arg4.

    Returns
    -------
    return_name : type
        Description of return_name.

    Raises
    ------
    ValueError
        Description of ValueError.
    '''
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-17 18:19:39.561218
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning

    Examples
    --------
    >>> example_code
    example_result

    See Also
    --------
    some_other_func
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:19:44.639123
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.0
        This is deprecated
    """
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text)
    assert result[0].version == "0.1.0"
    assert result[0].description == "This is deprecated"


# Generated at 2022-06-17 18:19:52.143178
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.1.0
        This is a deprecation warning
    """
    section = DeprecationSection("deprecated", "deprecation")
    docstring = section.parse(text)
    assert docstring[0].version == "0.1.0"
    assert docstring[0].description == "This is a deprecation warning"


# Generated at 2022-06-17 18:20:02.891530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:20:12.637207
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print(example)
    42
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:20:21.883916
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """)

    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]

# Generated at 2022-06-17 18:20:32.044437
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int
        Description of arg2.

    Returns
    -------
    str
        Description of return value.
    """
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:20:41.314737
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Examples
    --------
    >>> print('hello world')
    hello world

    Warnings
    --------
    This is a warning.

    See Also
    --------
    some_other_function
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-17 18:20:54.861652
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int, optional
        A description of arg2.
    arg3 : str, optional, default is 'foo'
        A description of arg3.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    result = NumpydocParser().parse(text)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False

# Generated at 2022-06-17 18:21:02.026219
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:12.110854
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    other_function : does something else
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-17 18:21:20.576380
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might warn UserWarning

    Examples
    --------
    >>> example_code()
    example_result

    Warnings
    --------
    This is a warning.

    See Also
    --------
    another_function
    """
    docstring = NumpydocParser().parse(text)


# Generated at 2022-06-17 18:21:30.147370
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:46.556247
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:21:56.551618
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    arg_3 : type
        Default is 0.

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    UserWarning
        A description of what might raise UserWarning
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long

# Generated at 2022-06-17 18:22:02.706245
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-17 18:22:12.370286
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:22.922460
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : int, optional
        The second argument.

    Returns
    -------
    str
        The return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name

# Generated at 2022-06-17 18:22:33.796496
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:22:45.247364
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of exception.

    Warns
    -----
    UserWarning
        Description of warning.

    Examples
    --------
    >>> print(1)
    1
    """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_

# Generated at 2022-06-17 18:22:57.270470
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:07.192108
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:23:17.932944
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Examples
    --------
    >>> print('hello')
    hello
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True


# Generated at 2022-06-17 18:23:36.331263
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:23:46.574377
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of error.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a description."
    assert docstring.long_description == "Description of arg1.\n\nDescription of arg2."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:23:53.750527
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.
    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    int
        This is a description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:24:04.705524
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str, optional
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "Description of arg1"
    assert doc

# Generated at 2022-06-17 18:24:09.921015
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:24:19.693993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type, optional
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.

    Raises
    ------
    ValueError
        Description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
   

# Generated at 2022-06-17 18:24:30.047688
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        A positional argument.
    arg2 : str
        A keyword-only argument.
    *args
        Variable length argument list.
    **kwargs
        Arbitrary keyword arguments.

    Raises
    ------
    ValueError
        If something bad happens.

    Returns
    -------
    int
        The return value. True for success, False otherwise.

    Examples
    --------
    >>> example()
    42
    '''
    doc = NumpydocParser().parse(text)
    assert doc.short_description == 'This is a short description.'
    assert doc.long_description == 'This is a long description.'
    assert doc.blank_after_short_description == True
    assert doc

# Generated at 2022-06-17 18:24:39.674269
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        Description of ValueError.

    Warns
    -----
    UserWarning
        Description of UserWarning.

    Examples
    --------
    >>> print(example())
    42
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta)

# Generated at 2022-06-17 18:24:50.695077
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:25:03.108203
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "arg1"
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:25:25.585974
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
   

# Generated at 2022-06-17 18:25:36.032390
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for docstring with no section
    text = """
    This is a docstring with no section.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a docstring with no section."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0

    # Test for docstring with one section
    text = """
    This is a docstring with one section.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:25:45.547597
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : type
        Description of arg2.

    Returns
    -------
    return_name : type
        Description of return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:25:56.714952
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-17 18:26:07.524571
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.

    Returns
    -------
    str
        A description of the return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "A description of arg1."

# Generated at 2022-06-17 18:26:16.710157
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        A description of arg1.
    arg2 : int
        A description of arg2.
    arg3 : bool, optional
        A description of arg3.

    Returns
    -------
    str
        A description of the return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:26:26.749172
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
        This is a description of arg1.

    arg2 : int, optional
        This is a description of arg2.

    Returns
    -------
    str
        This is a description of the return value.

    Raises
    ------
    ValueError
        This is a description of what might raise ValueError.

    Warns
    -----
    UserWarning
        This is a description of what might raise UserWarning.

    Examples
    --------
    >>> print('hello world')
    hello world

    See Also
    --------
    some_other_function : some other function
    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-17 18:26:35.294289
# Unit test for method parse of class NumpydocParser