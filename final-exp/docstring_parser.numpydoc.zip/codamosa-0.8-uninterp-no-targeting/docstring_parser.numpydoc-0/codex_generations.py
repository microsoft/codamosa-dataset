

# Generated at 2022-06-21 11:45:23.061119
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection("Yields", "yields")
    assert yield_section.title == "Yields"
    assert yield_section.key == "yields"
    assert yield_section.is_generator == True


if __name__ == "__main__":
    test_YieldsSection()

# Generated at 2022-06-21 11:45:26.615458
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    a
        a value
        """
    key = "a"
    value = "a value"
    kv = _KVSection("a", "a")
    assert list(kv.parse(text))[0].description == value


# Generated at 2022-06-21 11:45:29.599575
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test = NumpydocParser()
    test_section = Section("test_title", "test_key")
    test.add_section(test_section)
    assert test.sections == {'test_title': test_section}



# Generated at 2022-06-21 11:45:33.408481
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    kwargs = {
        "title": "title",
        "key": "key"
    }
    s = Section(**kwargs)
    parser = NumpydocParser()
    parser.add_section(s)
    parser.parse("test")

# Generated at 2022-06-21 11:45:41.403486
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test that the function correctly parses the docstring of a function
    defined below, by generating a parsed_docstring from the function's
    docstring and comparing it to the expected result."""


# Generated at 2022-06-21 11:45:44.439589
# Unit test for constructor of class _KVSection
def test__KVSection():
    KVSection_instance = _KVSection('test_title', 'test_key')
    assert(KVSection_instance.title == 'test_title')
    assert(KVSection_instance.key == 'test_key')
    assert(KVSection_instance._KVSection__title == 'test_title')
    assert(KVSection_instance._KVSection__key == 'test_key')


# Generated at 2022-06-21 11:45:46.576423
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_section = RaisesSection("Raises","raises")
    print(raise_section.title)
    print(raise_section.key)
    print(raise_section._KVSection__class__)
    print(raise_section.title_pattern)


# Generated at 2022-06-21 11:45:51.070576
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Param"
    key = "param"
    param_section = ParamSection(title, key)
    assert param_section.title == "Param"
    assert param_section.key == "param"

# Generated at 2022-06-21 11:45:55.034496
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.parse(""".. deprecated:: 0.1.1
        It's deprecated since version 0.1.1""")[0].args == ['deprecation']

# Generated at 2022-06-21 11:45:56.608619
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises")

# Generated at 2022-06-21 11:46:18.622407
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    assert ps.title == "Parameters"
    assert ps.key == "param"


# Generated at 2022-06-21 11:46:22.149192
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    regex = NumpydocParser().titles_re.search(".. deprecated::\n    1.2\n    Spam").re
    assert regex == re.compile(r'^\.\.\s*(deprecated)\s*::')


# Generated at 2022-06-21 11:46:31.794563
# Unit test for method parse of class Section
def test_Section_parse():
    """Test docstring parsing."""

    input_text = """\
        Parameters
        ----------
        arg_1
            Argument #1.

        arg_2 : str, optional
            Argument #2.

        arg_3 : type
            Argument #3.

        Other Parameters
        ----------------
        arg_4
            Argument #4.

        Returns
        -------
        list
            Return value.
        """


# Generated at 2022-06-21 11:46:35.564598
# Unit test for constructor of class ParamSection
def test_ParamSection():
    print("testing constructor of class ParamSection")
    #test the constructor
    ps = ParamSection("Parameters", "param")
    assert (ps.title == "Parameters")
    assert (ps.key == "param")


# Generated at 2022-06-21 11:46:36.761711
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raise", "raises")

# Generated at 2022-06-21 11:46:38.577668
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_section = ReturnsSection("Returns", "returns")
    assert return_section.is_generator == False

# Generated at 2022-06-21 11:46:46.067738
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = """
    .. title:: something
        possibly over multiple lines
    """
    parser = NumpydocParser()
    # Test the attributes of class ReturnsSection
    assert parser.sections["Returns"] == ReturnsSection(
        "Returns", "returns"
    )
    assert parser.sections["Returns"].title == "Returns"

    assert parser.sections["Returns"].title_pattern == r"^\.\.\s*(Returns)\s*::"
    assert parser.sections["Returns"].key == "returns"
    assert parser.sections["Returns"].parse(text) == DocstringReturns(
        args=[parser.sections["Returns"].key],
        description=None,
        type_name=None,
        is_generator=False,
        return_name=None,
    )


# Generated at 2022-06-21 11:46:52.295511
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        key
            value
        key2 : type
            value
    """
    expected = [
        DocstringMeta(["key"], description="value"),
        DocstringMeta(["key2", "type"], description="value"),
    ]
    assert list(ParamSection("Parameters", "param").parse(text)) == expected

# Generated at 2022-06-21 11:46:57.181176
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _SphinxSection_test = _SphinxSection("DeprecationWarning", "deprecated")
    assert _SphinxSection_test.title == "DeprecationWarning"
    assert _SphinxSection_test.key == "deprecated"


# Generated at 2022-06-21 11:47:08.535377
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from inspect import cleandoc as c
    from .decorated import NumpydocDecorated
    parser = NumpydocParser()
    assert parser.parse(None) == NumpydocDecorated()
    assert parser.parse("") == NumpydocDecorated()
    assert parser.parse(c("This is a short description")) == NumpydocDecorated(
        short_description="This is a short description"
    )
    assert parser.parse(c("This is a short description\n")) == NumpydocDecorated(
        short_description="This is a short description"
    )

# Generated at 2022-06-21 11:47:36.060127
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test constructor of _KVSection
    # successful test case
    section = _KVSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == r"^title\s*?\n----\s*$"
    

# Test for parse() in _KVSection

# Generated at 2022-06-21 11:47:47.885499
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    # test class Section:
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    assert param_section.title_pattern == "^{}\\s*?\\n{}\\s*$".format("Parameters", len("Parameters") * "-")
    # test class ParamSection:
    assert param_section._parse_item("arg_name", "arg_description") == DocstringParam(args=["param", "arg_name"], description='arg_description', arg_name='arg_name', type_name=None, is_optional=None, default=None)

# Generated at 2022-06-21 11:47:51.883007
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = YieldsSection("yields", "yields")
    assert parser.is_generator == True
    assert parser.key == "yields"
    assert parser.title == "yields"

# Generated at 2022-06-21 11:47:53.462500
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():  # noqa
    a = ReturnsSection("Returns","returns")

test_ReturnsSection()

# Generated at 2022-06-21 11:47:56.004104
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    docstring = """.. test::

Test for constructor of class NumpydocParser.

"""
    NumpydocParser().parse(docstring)

# Generated at 2022-06-21 11:48:03.457809
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep_section = DeprecationSection("deprecated", "deprecated")
    txt = inspect.cleandoc(
        """
    .. deprecated:: 1.2
        as of version 1.2 this does something new
        """
    )
    tags = dep_section.parse(txt)
    tags = list(tags)
    assert len(tags) == 1
    assert tags[0].version == '1.2'
    assert tags[0].description == 'as of version 1.2 this does something new'

# Generated at 2022-06-21 11:48:14.874100
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Unit test for method add_section of class NumpydocParser"""
    parser = NumpydocParser()
    # Add new "Some" section
    parser.add_section(Section('Some', 'some'))
    assert parser.sections['Some']
    # Replace "Example" section with another section
    parser.add_section(Section('Example', 'ex'))
    assert parser.sections['Example']
    assert parser.sections['Example'].key == 'ex'
    # Add new "Examples" section
    parser.add_section(Section('Examples', 'examples'))
    assert parser.sections['Examples']
    # Replace "Examples" section with "Example" section
    parser.add_section(Section('Examples', 'example'))
    assert parser.sections['Examples']

# Generated at 2022-06-21 11:48:16.786167
# Unit test for constructor of class Section
def test_Section():
    sections = Section(title="Test", key="test")


# Generated at 2022-06-21 11:48:19.048283
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section1 = Section("section1", "sec1")
    parser1 = NumpydocParser()
    assert not parser1.sections
    parser1.add_section(section1)
    assert parser1.sections


# Generated at 2022-06-21 11:48:24.052537
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p1 = ParamSection("Parameters", "param")
    p2 = ParamSection("Params", "param")
    assert p1.title == 'Parameters'
    assert p2.title == 'Params'
    assert p1.key == 'param'
    assert p2.key == 'param'
    assert p1.title_pattern == '^(Parameters)\s*?\n-------\s*$'
    assert p2.title_pattern == '^(Params)\s*?\n------\s*$'


# Generated at 2022-06-21 11:49:28.678434
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    f = YieldsSection("Yields", "yields")
    assert f.title == "Yields"
    assert f.key == "yields"
    assert f.is_generator == True


# Generated at 2022-06-21 11:49:31.048664
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    sec = DeprecationSection("Deprecated since version 1.0","deprecation")
    return sec.parse("1.0\n This is a test")

# Generated at 2022-06-21 11:49:35.774179
# Unit test for constructor of class Section
def test_Section():
    test_strings = [['yay', 'meta'],
                    ['nay', 'meta']]
    for test_string in test_strings:
        with pytest.raises(TypeError):
            section = Section(test_string[0], test_string[1])

# Generated at 2022-06-21 11:49:38.524739
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key").title=="title"
    assert Section("title", "key").key=="key"


# Generated at 2022-06-21 11:49:42.272645
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert(section.is_generator == False)
    assert(section.title == "Returns")
    assert(section.key == "returns")


# Generated at 2022-06-21 11:49:50.576285
# Unit test for function parse
def test_parse():
    text = """
    Sum.

    Parameters
    --------------
    a : int
        First number
    b : int
        Second number

    Returns
    --------------
    int
        Summation of two numbers

    Examples
    --------------
    >>> sum(2, 3)
    5
    """
    parser = NumpydocParser()
    result = parser.parse(text)
    result.meta.sort(key=lambda m: m.args)


# EOF

# Generated at 2022-06-21 11:49:58.985646
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Parameters", "param")
    assert None == s.parse("")
    assert [] == list(s.parse("\n"))
    assert [] == list(s.parse("foo\n"))
    assert [DocstringMeta(["param"], description="bar")] == list(s.parse("foo\nbar\n"))
    assert [DocstringMeta(["param"], description="bar")] == list(s.parse("foo\nbar"))
    assert [DocstringMeta(["param"], description="bar")] == list(s.parse("foo\nbar\n\n"))


# Generated at 2022-06-21 11:50:10.679878
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class MySection(Section):

        def __init__(self):
            super().__init__("Section Title", "key")

        @property
        def title_pattern(self):
            return r"^({})\s*?\n{}\s*$".format("MySection", "-"*len("MySection"))

        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            return DocstringMeta(
                [self.key],
                description = _clean_str("Description of my new section"),
            )

    parser = NumpydocParser()

    assert("Section Title" not in parser.sections)

    parser.add_section(MySection())

    assert("Section Title" in parser.sections)

    # Since the NumpydocParser now has a new section, a new title is recognized.
   

# Generated at 2022-06-21 11:50:16.873456
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("Test", "test")
    assert len(section.parse("")) == 0
    assert len(section.parse("\n")) == 0
    assert len(section.parse("\n\n")) == 0


# Generated at 2022-06-21 11:50:18.732861
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False


# Generated at 2022-06-21 11:50:55.967047
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser.__init__ != None

# Generated at 2022-06-21 11:51:01.088059
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """Test parsing of _KVSection."""

    _KVSection_1 = _KVSection("TEST", "TEST")
    text = "one : one_type\none_description\n\ntwo : two_type\ntwo_description"
    assert len(_KVSection_1.parse(text)) == 2
    text = "one : one_type\none_description"
    assert len(_KVSection_1.parse(text)) == 1


# Generated at 2022-06-21 11:51:14.752971
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import docpy

# Generated at 2022-06-21 11:51:23.117774
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = Section("test", "test")
    text = '''
    test1
        test1_value1
        test1_value2

    test2: test2_value2
        test2_value2

    test3
            test3_value
    '''
    text = inspect.cleandoc(text)
    print(text)
    for match in KV_REGEX.finditer(text):
        print(match.group())
    print(KV_REGEX.finditer(text))
    print(next(KV_REGEX.finditer(text)))


if __name__ == "__main__":
    test__KVSection_parse()

# Generated at 2022-06-21 11:51:31.970577
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:51:34.579864
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection("Yields", "yields")
    assert yield_section.is_generator == True

# Generated at 2022-06-21 11:51:42.636070
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    my_text = """
    arg_name
        arg_description
    arg_name2 : type, optional
        descriptions can also span...
        ... multiple lines
    """

    for match, next_match in _pairwise(KV_REGEX.finditer(my_text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = my_text[start:end]
        print(match.group(), value)


# Generated at 2022-06-21 11:51:53.205554
# Unit test for method parse of class Section
def test_Section_parse():
    sections = [
        Section("Example", "example"),
        Section("Examples", "example"),
        Section("Example", "example"),
        Section("Examples", "example"),
        Section("Example", "example"),
        Section("Examples", "example"),
    ]
    text = """
        Example
            this is an example

        Examples:
            this is an example

        Example
            this is an example

        Examples
            this is an example

        Example
            this is an example

        Examples
            this is an example

        """
    # text = inspect.cleandoc(text)

# Generated at 2022-06-21 11:51:56.339006
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_section = _KVSection("Parameters", "param")
    assert(isinstance(test_section,Section))
  

# Generated at 2022-06-21 11:52:03.617713
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    title = "Returns"
    key = "returns"
    assert title == title
    assert key == key
    title = "Return"
    key = "returns"
    assert title == title
    assert key == key
    title = "Yields"
    key = "yields"
    assert title == title
    assert key == key
    title = "Yield"
    key = "yields"
    assert title == title
    assert key == key

# Generated at 2022-06-21 11:53:07.807558
# Unit test for constructor of class _KVSection
def test__KVSection():
    x=_KVSection("title","key")
    assert x.title=="title"
    assert x.key=="key"


# Generated at 2022-06-21 11:53:09.876665
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser(sections = DEFAULT_SECTIONS)
    assert parser.sections is not None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 11:53:16.406809
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Create an instance of NumpydocParser
    numpydoc_parser = NumpydocParser()

    # Execute method parse
    docstring = numpydoc_parser.parse("""
    Function to read a csv file

    Short description of my function

    Long description of my function
        With numerous details

    Args:
        filename (str): Name of the file to read
            With some details
        sep (str): Separator between the columns

    Returns:
        Some returns
            With a lot of details
    """)

    # Assert that the docstring has the proper short_description attribute
    assert docstring.short_description == "Function to read a csv file"
    # Assert that the docstring has the proper blank_after_short_description attribute
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-21 11:53:27.765187
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    case_list = [
        "",
        "\n",
        "short\nlong\n\n",
        "short\n\nlong\n\n",
        "short\n\nlong",
        "short\nlong",
        "short",
        "short\n\n\n\nlong\n\n\n\n",
        "short\nlong\n\n\n\n",
        "short\n\n\n\nlong\n\n\n",
        "short\n\n\n\n\nlong\n\n",
    ]

# Generated at 2022-06-21 11:53:31.067049
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text='1.0 (first release)\n\nSome text'
    docs = DeprecationSection(title="Deprecated", key="deprecated")
    obj = docs.parse(text)
    for doc in obj:
        assert doc.description
test_DeprecationSection_parse()


# Generated at 2022-06-21 11:53:33.724161
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    sec_1 = RaisesSection("Raise","raise")
    assert sec_1._KVSection__key == "raise"
    assert sec_1._KVSection__title == "Raise"

# Generated at 2022-06-21 11:53:38.533894
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_section = "Raises\n-----\nValueError\n    A description of what might raise ValueError"
    ret = NumpydocParser().parse(test_section)
    assert len(ret.meta) == 1
    assert hasattr(ret.meta[0], "type_name")
    assert ret.meta[0].type_name == "ValueError"
    assert hasattr(ret.meta[0], "description")
    assert ret.meta[0].description == "A description of what might raise ValueError"
    assert hasattr(ret.meta[0], "args")
    assert ret.meta[0].args == ["raises", "ValueError"]

# Generated at 2022-06-21 11:53:42.276471
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "Parameters"
    key = "param"
    param = _KVSection(title, key)
    assert param.title == title
    assert param.key == key



# Generated at 2022-06-21 11:53:50.289978
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert (
        [
            DocstringDeprecated(
                args=["deprecated"],
                description=None,
                version=".. deprecated:: 3.1\n    \n    .. deprecated:: 3.2\n    \n    .. deprecated:: 3.4",
            )
        ]
        == DeprecationSection("deprecated", "deprecation").parse(
            ".. deprecated:: 3.1\n    \n    .. deprecated:: 3.2\n    \n    .. deprecated:: 3.4"
        )
    )

# Generated at 2022-06-21 11:53:55.245021
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    object1 = _SphinxSection("Parameters", "param")
    assert object1.title == "Parameters"
    assert object1.key == "param"
    assert object1.title_pattern == r"^\.\.\s*(Parameters)\s*::"
    object2 = _SphinxSection("Params", "param")
    assert object2.title == "Params"
    assert object2.key == "param"
    assert object2.title_pattern == r"^\.\.\s*(Params)\s*::"
