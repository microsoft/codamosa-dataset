

# Generated at 2022-06-21 11:45:24.588440
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    import unittest.mock
    mock_self = unittest.mock.MagicMock()
    mock_text = unittest.mock.MagicMock()
    expected = NumpydocParser().sections["Parameters"].parse(mock_text)
    actual = _KVSection.parse(mock_self, mock_text)
    assert actual == expected


# Generated at 2022-06-21 11:45:29.631420
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser([])
    parser.add_section(Section("MySection", "mysection"))
    text = """
    This is description.
    MySection
    -------
    My section's body
    """
    docstring = parser.parse(text)
    assert docstring.meta[0] == DocstringMeta(["mysection"], description="My section's body")
    assert docstring.short_description == "This is description."
    assert docstring.long_description == None

# Generated at 2022-06-21 11:45:32.487559
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """Test the constructor of class NumpydocParser."""
    assert issubclass(ReturnsSection, Section)
    assert issubclass(RaisesSection, Section)
    assert issubclass(YieldsSection, ReturnsSection)
    assert issubclass(DeprecationSection, Section)
    assert issubclass(ParamSection, Section)
    assert issubclass(_SphinxSection, Section)
    assert issubclass(_KVSection, Section)
    assert isinstance(NumpydocParser().sections, dict)


# Generated at 2022-06-21 11:45:40.938581
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    tp = NumpydocParser()
    t1 = tp.parse('\n'
                  'Test function.\n'
                  '\n'
                  'a b c d  \n'
                  '\n'
                  'Parameters\n'
                  '----------\n'
                  'x : int, optional\n'
                  '    Parameter a.\n'
                  '\n'
                  'y : string, optional\n'
                  '    Parameter b.\n'
                  '\n'
                  'z : int\n'
                  '    Parameter c.\n'
                  '\n'
                  'Returns\n'
                  '-------\n'
                  'no return.\n'
                  '\n')
    #TODO: fix the assert

    #assert t1.short_

# Generated at 2022-06-21 11:45:42.807194
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    p = NumpydocParser()
    section = Section("bad", "section")
    p.add_section(section)
    assert "bad" in p.sections
    assert section == p.sections["bad"]


# Generated at 2022-06-21 11:45:43.890094
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields","yields")
    assert y.is_generator == True

# Generated at 2022-06-21 11:45:56.607959
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").parse("""\
    deprecated

    """ ) == [DocstringDeprecated(args=['deprecation'], description=None,
                                  version=None)]
    assert DeprecationSection("deprecated", "deprecation").parse("""\
    deprecated

    blah blah blah

    """ ) == [DocstringDeprecated(args=['deprecation'],
                                  description='blah blah blah', version=None)]
    assert DeprecationSection("deprecated", "deprecation").parse("""\
    deprecated

    blah blah blah

    in version number
    """ ) == [DocstringDeprecated(args=['deprecation'],
                                  description='blah blah blah',
                                  version='in version number')]

# Generated at 2022-06-21 11:46:02.069581
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Use `assert` as a way to test if arguments are parsed correctly
    DS = DeprecationSection("deprecated", "deprecation")
    DS.parse("'18.12.0'\nA description\n")
    DS.parse("'18.12.0'\nA description\n")

# Generated at 2022-06-21 11:46:03.198350
# Unit test for constructor of class Section
def test_Section():
	pass


# Generated at 2022-06-21 11:46:08.366271
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    new_section = Section("Section Title", "Section Key")
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(new_section)
    assert numpydoc_parser.sections[new_section.title].key == new_section.key

# Generated at 2022-06-21 11:46:15.139321
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_section = YieldsSection("Yields", "yields")
    assert yields_section.is_generator == True


# Generated at 2022-06-21 11:46:24.459270
# Unit test for constructor of class Section
def test_Section():
    res = Section("Parameters", "param")
    assert res.title == "Parameters"
    assert res.key == "param"
    res = Section("Params", "param")
    assert res.title == "Params"
    assert res.key == "param"
    res = Section("Arguments", "param")
    assert res.title == "Arguments"
    assert res.key == "param"
    res = Section("Args", "param")
    assert res.title == "Args"
    assert res.key == "param"
    res = Section("Other Parameters", "other_param")
    assert res.title == "Other Parameters"
    assert res.key == "other_param"
    res = Section("Other Params", "other_param")
    assert res.title == "Other Params"

# Generated at 2022-06-21 11:46:27.518323
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert a.title == "Returns"
    assert a.key == "returns"
    assert a.is_generator == False


# Generated at 2022-06-21 11:46:32.859620
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    expected = DocstringDeprecated(
        args=["deprecation"], description='None', version='None')
    doc = DeprecationSection("deprecated", "deprecation")
    assert(doc.parse('version\n') == [expected])

# Generated at 2022-06-21 11:46:35.918157
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection('deprecated', 'deprecation')
    assert deprecation_section.title == 'deprecated'
    assert deprecation_section.key == 'deprecation'

# Generated at 2022-06-21 11:46:44.641927
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # assert parse("")
    assert parse("") == Docstring()
    # assert parse("""
    #     Does something

    #     Some longer description
    # """)
    assert parse("""
        Does something

        Some longer description
    """) == Docstring(
        short_description = "Does something",
        blank_after_short_description = True,
        blank_after_long_description = False,
        long_description = "Some longer description"
    )

    # assert parse("""
    #     Does something

    #     Some longer description

    #     Some extra paragraph
    # """)

# Generated at 2022-06-21 11:46:52.648568
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = RaisesSection("Rasises","raises")
    assert parser.title == "Rasises"
    assert parser.key == "raises"
    assert parser._parse_item("ValueError","A description of what might raise ValueError") == DocstringRaises(
            args=["raises", "ValueError"],
            description=_clean_str("A description of what might raise ValueError"),
            type_name="ValueError" if len("ValueError") > 0 else None,
        )

# Generated at 2022-06-21 11:47:04.997604
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_text = '''
    Test parse method.

    unit test for method parse of class NumpydocParser.

    Parameters
    ----------
    text :
          The input text to be parsed.

    Returns
    -------
    Docstring
        parsed docstring
    '''
    ret = parser.parse(test_text)
    assert ret.short_description.strip() == 'Test parse method.'
    assert ret.long_description.strip() == 'unit test for method parse of class NumpydocParser.'
    assert ret.meta[0].args[0] == 'param'
    assert ret.meta[0].args[1] == 'text'
    assert ret.meta[0].type_name == ''
    assert ret.meta[0].is_optional == False

# Generated at 2022-06-21 11:47:13.016525
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    class _Title():
        pass
        
    class _SphinxTitle(_SphinxSection,_Title):
        def __init__(self, title: str) -> None:
           super().__init__(title, self.__class__.__name__)
    title_instance = _SphinxTitle("title")
    assert isinstance(title_instance, _Title)
    assert isinstance(title_instance, Section)
    assert isinstance(title_instance, _SphinxSection)
    tit = title_instance.title
    assert tit == "title"
    title_instance.title = "new title"
    tit_new = title_instance.title
    assert tit_new == "new title"

# Generated at 2022-06-21 11:47:21.336100
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # this is the text in the docstring
    text = '.. deprecated :: 0.2.3\n    Use ``this`` instead.'

    # this is the expected result from running parse
    expected_result = DocstringDeprecated(args=['deprecation'], description='Use ``this`` instead.', version='0.2.3')

    # parse the text and compare the result
    assert DeprecationSection('deprecated', 'deprecation').parse(text).__next__() == expected_result

# Generated at 2022-06-21 11:47:30.370170
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    data = _SphinxSection('title', 'key')
    assert data.title == 'title'
    assert data.key == 'key'
    assert data.title_pattern == r'^\.\.\s*(title)\s*::'
    assert data.parse('anything')

# Unit test to verify the method parse in class _KVSection

# Generated at 2022-06-21 11:47:35.530015
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    a = DeprecationSection(".. deprecated:: 2.0\n.. deprecated:: 2.1\n    Deprecated, use :func:`the_new_func` instead.",
                           ".. deprecated:: 2.0\n.. deprecated:: 2.1\n    Deprecated, use :func:`the_new_func` instead.")
    a.parse('')


# Generated at 2022-06-21 11:47:40.969481
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    example_docstring = inspect.cleandoc("""
        .. deprecated:: 1.3.0
            Use :meth:`~some_other_method` instead.
        """)
    assert example_docstring == "deprecation\n    Use :meth:`~some_other_method` instead."


# Generated at 2022-06-21 11:47:51.268257
# Unit test for method parse of class Section
def test_Section_parse():
    # Test for all sections
    for section in DEFAULT_SECTIONS:
        try:
            assert isinstance(section.parse("Some example text."), T.Iterator)
        except AttributeError:
            continue
    # Test for _KVSection
    section = _KVSection("Parameters", "param")
    assert isinstance(section.parse("arg_name\n\targ_description"), T.Iterator)
    assert isinstance(section.parse("arg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines"), T.Iterator)
    # Test for _SphinxSection
    section = _SphinxSection("Deprecated", "deprecation")
    assert isinstance(section.parse("Some example text."), T.Iterator)
    # Test for ParamSection
    section = ParamSection

# Generated at 2022-06-21 11:47:55.141913
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields","yields")
    assert ys.title == "Yields"
    assert ys.key == "yields"
    assert ys.is_generator == True


# Generated at 2022-06-21 11:47:56.575063
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert isinstance(RaisesSection("Raises", "raises"), RaisesSection)

# Generated at 2022-06-21 11:48:01.611879
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises", "raises")
    text = """
    ValueError
        A description of what might raise ValueError
    """
    result = a.parse(text)
    assert(str(result)) == "(raises, ValueError, None, A description of what might raise ValueError)"


# Generated at 2022-06-21 11:48:05.718650
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """Test for the constructor of NumpydocParser"""
    try:
        x = NumpydocParser(sections={})
    except TypeError:
        pass



# Generated at 2022-06-21 11:48:12.159900
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Parameters", "param")
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines"""
    print(text)
    assert list(s.parse(text)) == [DocstringMeta(args=['param'], description='arg_description'), DocstringMeta(args=['param'], description='descriptions can also span...\n... multiple lines')]


# Generated at 2022-06-21 11:48:23.896923
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """Does the constructor of NumpydocParser initialize correctly"""
    # case 1: sections passed in, sections and title_patterns initialized correctly
    sections = {
            'Parameters': ParamSection('Parameters', 'param'),
            'Returns': ReturnsSection('Returns', 'returns')
    }
    tester = NumpydocParser(sections)
    assert tester.sections == sections
    assert tester.titles_re.pattern == r'^(Parameters)\s*?\n----*\s*$|^(Returns)\s*?\n----*\s*$'

    # case 2: no sections passed in, default sections initialized correctly
    tester = NumpydocParser()
    assert isinstance(tester.sections, dict)

# Generated at 2022-06-21 11:48:43.231048
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the NumpydocParser.parse method.
    """
    # Test for empty docstring
    assert NumpydocParser().parse("") == Docstring()
    # Test for short description only
    doc = NumpydocParser().parse("short desc")
    assert doc.short_description == "short desc"
    assert doc.long_description is None
    # Test for short description and long description with no blank lines
    doc = NumpydocParser().parse("short desc\n\nlong desc")
    assert doc.short_description == "short desc"
    assert doc.long_description == "long desc"
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    # Test for short description and long description with 1 blank line

# Generated at 2022-06-21 11:48:54.188275
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string = """
    short description

    long description

    Parameters
    ----------
    arg1 : str
        arg1 description
    arg2 : type, optional
        arg2 description

    Returns
    -------
    tuple
        description of return value
    """

    docstr = NumpydocParser().parse(doc_string)

    # Assert type is correct
    assert isinstance(docstr, Docstring)

    # Assert the values are correct
    assert docstr.short_description == 'short description'
    assert docstr.long_description == 'long description'
    assert len(docstr.meta) == 2
    assert docstr.meta[0].args[0] == 'param'
    assert docstr.meta[0].args[1] == 'arg1'

# Generated at 2022-06-21 11:48:59.904451
# Unit test for method parse of class Section
def test_Section_parse():

    # Create a Section
    section = Section("Parameters", "param")
    # Create a dummy text
    text = "key\n\tvalue"

    # Call the method parse
    for item in section.parse(text):
        assert item.args[0] == 'param'
        assert item.description == 'value'
        assert type(item) == DocstringMeta


# Generated at 2022-06-21 11:49:01.047928
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True

# Generated at 2022-06-21 11:49:02.968297
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    with pytest.raises(TypeError):
        # RaisesSection() must take exactly 2 arguments (0 given)
        RaisesSection()

# Generated at 2022-06-21 11:49:09.245214
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	print("test_DeprecationSection")
	print("Part 1: test with valid deprecation warning")
	test = ".. deprecated:: 2.0\n"
	test = test + "   use :func:`more_specific_function` instead"
	print("Input: " + str(test) + "\n")
	output = DeprecationSection("deprecated", "deprecation").parse(test)
	result = [DocstringDeprecated(args=['deprecation'], description='use :func:`more_specific_function` instead', version='2.0')]
	print("Output: " + str(result) + "\n")
	assert result == output
	print()
	print("Part 2: test with invalid deprecation warning")
	test = ".. deprecated:: 2.0\n"

# Generated at 2022-06-21 11:49:16.170350
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param").title == "Parameters"
    assert Section("Parameters", "param").key == "param"
    assert Section("Parameters", "param").title_pattern == "^Parameters\\s*?\n---*\\s*$"
    assert Section("Parameters", "param").parse(
        "hello\n-----------\nhaha\n"
    ) == [DocstringMeta(["param"], description="haha")]
    
    

# Generated at 2022-06-21 11:49:17.197558
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises")

# Generated at 2022-06-21 11:49:21.474368
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title='title'
    key='key'
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r'^\.\.\s*(' + title + ')\s*::'

# Generated at 2022-06-21 11:49:23.072647
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields","yields") != None

# Generated at 2022-06-21 11:49:56.036381
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('test') == Docstring(short_description = 'test')
    assert parse('test \n\n test') == Docstring(short_description = 'test', long_description = 'test', blank_after_short_description = True, blank_after_long_description = True)
    assert parse('test \n test') == Docstring(short_description = 'test', long_description = 'test', blank_after_short_description = False, blank_after_long_description = True)
    assert parse('test \n test \n') == Docstring(short_description = 'test', long_description = 'test', blank_after_short_description = False, blank_after_long_description = True)



# Generated at 2022-06-21 11:49:57.855630
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    temp = NumpydocParser()
    assert isinstance(temp, NumpydocParser)


# Generated at 2022-06-21 11:50:04.368537
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    args = '''
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    assert(_KVSection.parse(args) == '''
    
    
    
    
    
    
    
    
    
    ''')



# Generated at 2022-06-21 11:50:11.651852
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    section = _SphinxSection(title, key)
    assert section.title is title
    assert section.key is key
    assert section.title_pattern is r"^\.\.\s*(title)\s*::"

    title = "title"
    key = "key"
    section = _SphinxSection(title, key)
    assert section.title is title
    assert section.key is key
    assert section.title_pattern is r"^\.\.\s*(title)\s*::"



# Generated at 2022-06-21 11:50:23.890364
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Test for constructor with no input
    assert NumpydocParser().sections == DEFAULT_SECTIONS

    # Test for constructor with input
    input_sections = {s.title: s for s in DEFAULT_SECTIONS[:1]}
    assert NumpydocParser(input_sections).sections == input_sections

    # Test for add_section()
    input_section = DEFAULT_SECTIONS[1]
    parser = NumpydocParser(input_sections)
    parser.add_section(input_section)
    assert parser.sections == input_sections.update({input_section.title: input_section})
    assert parser.titles_re != re.compile(r"|".join(
        [input_sections[s].title_pattern for s in input_sections.keys()]
    ))

# Generated at 2022-06-21 11:50:28.686824
# Unit test for constructor of class _KVSection
def test__KVSection():
    test = RaisesSection("Raises", "raises")
    assert test.title == "Raises"
    assert test.key == "raises"
    assert test.title_pattern == r"^Raises\s*?\n\s*$"
    return test


# Generated at 2022-06-21 11:50:36.745823
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("title", "key")
    text = inspect.cleandoc("""
        key1
            value1
        key2 : type
            value2
        """)

    items = list(section.parse(text))
    assert len(items) == 2
    assert items[0].key == 'key1'
    assert items[0].value == 'value1'
    assert items[1].key == 'key2'
    assert items[1].value == 'value2'


# Generated at 2022-06-21 11:50:40.889391
# Unit test for constructor of class _KVSection
def test__KVSection():
    return_name = _KVSection("Return", "name")
    assert return_name.title == "Return"
    assert return_name.key == "name"
    assert return_name.title_pattern == r"^Return\s*?\n=+\s*$"


# Generated at 2022-06-21 11:50:54.075849
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """\
        First line of the docstring.

        Shortest possible description.

        Parameters
        ----------
        arg1
            Description of argument 1.
        arg2 : type
            Description of argument 2.

        Returns
        -------
        type1
            Description of return value 1.
        type2 : type
            Description of return value 2.

        Raises
        ------
        exception1
            Description of exception 1.
        exception2 : type
            Description of exception 2.

        """
    result = parser.parse(text)
    assert result.short_description == 'First line of the docstring.'
    assert result.long_description == 'Shortest possible description.'
    args, kwargs = zip(*((e.args, e.kwargs) for e in result.meta))
   

# Generated at 2022-06-21 11:50:57.104559
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = ""
    numpydoc_parser = NumpydocParser(text)
    assert numpydoc_parser.sections == {s.title: s for s in DEFAULT_SECTIONS}

# Generated at 2022-06-21 11:51:15.499957
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = \
    """
    """

    assert NumpydocParser().parse(text) == Docstring()

# Generated at 2022-06-21 11:51:17.844358
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_section = _SphinxSection("TestSection", "test")
    assert test_section.title_pattern == r'^\.\.\s*(TestSection)\s*::'

# Generated at 2022-06-21 11:51:23.242555
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sc_1 = _SphinxSection("Example","Example")
    print(sc_1.title_pattern)
    sc_2 = _SphinxSection("Examples","Examples")
    print(sc_2.title_pattern)
    sc_3 = _SphinxSection("Examples","Examples")
    print(sc_3.title_pattern)
    return True


# Generated at 2022-06-21 11:51:25.637423
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection("Yields", "yields")
    assert section.title == "Yields"
    assert section.key == "yields"


# Generated at 2022-06-21 11:51:35.123424
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "value"
    key = "key"
    # This section has key-value syntax
    KV_Section = _KVSection(title, key)
    # This section doesn't have key-value syntax
    Not_KV_Section = Section(title, key)
    # First we check the title of each section
    assert KV_Section.title == title
    assert Not_KV_Section.title == title
    # Then we check the key of each section
    assert KV_Section.key == key
    assert Not_KV_Section.key == key
    # Next we check the title_pattern of each _KVSection
    assert KV_Section.title_pattern == "{}\\s*?\n{}\\s*$".format(title, "-" * len(title))
    assert Not_KV_Section

# Generated at 2022-06-21 11:51:47.385217
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("hello") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("hello\n") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("hello\n\n") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 11:51:49.304373
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="TEST", key="TEST")
    assert section.title == "TEST"
    assert section.key == "TEST"


# Generated at 2022-06-21 11:51:51.887019
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    assert r.parse("""
        ValueError
            A description of what might raise ValueError
    """)

# Generated at 2022-06-21 11:51:55.593817
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    res = True
    try:
        rs = RaisesSection("Raises", "raises")
    except TypeError:
        res = False
    finally:
        assert res


# Generated at 2022-06-21 11:52:02.713123
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection("deprecated", "deprecation").parse("1") == [
        DocstringDeprecated(
            args=['deprecation'], description=None, version='1'
        )
    ]
    assert DeprecationSection("deprecated", "deprecation").parse("1\n2") == [
        DocstringDeprecated(
            args=['deprecation'], description='2', version='1'
        )
    ]

# Generated at 2022-06-21 11:53:06.492269
# Unit test for constructor of class Section
def test_Section():
    assert Section('Title', 'param').title == 'Title'
    assert Section('Title', 'param').key == 'param'
    assert Section('Title', 'param').title_pattern == r'^(Title)\s*?\n-{5}\s*$'


# Generated at 2022-06-21 11:53:10.333025
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("DeprecationWarning", "deprecated")
    ret = dep.parse(".. deprecated:: 0.2\n    Deprecated.")
    # print(ret)
    assert ret == "0.2"
    return ret


# Generated at 2022-06-21 11:53:23.074633
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Section without key-value-pairs
    assert(list(_KVSection("title","key").parse("abcd"))
           == [DocstringMeta(["key"], description=None)])
    # Section with one key-value-pair
    assert(list(_KVSection("title","key").parse("abcd\nkey\n    value"))
           == [DocstringMeta(["key"], description="abcd"),
               DocstringMeta(["key"], description="value", arg_name=None)])
    # Section with two key-value-pairs

# Generated at 2022-06-21 11:53:28.943117
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    from .sphinx import SphinxParser

    test_parser = NumpydocParser()
    assert test_parser.sections == DEFAULT_SECTIONS
    test_parser.add_section(
        SphinxParser.make_section(
            title='XXX',
            key='yyy',
            regex_type='_SphinxSection',
        )
    )
    assert test_parser.sections['XXX'].title == 'XXX'
    assert test_parser.sections['XXX'].key == 'yyy'

# Generated at 2022-06-21 11:53:35.331862
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    Test for method parse of class DeprecationSection
    """
    title = 'Deprecated'
    key = 'deprecation'
    section_parser = DeprecationSection(title, key)
    text = 'Deprecated since version N: Deprecation message'
    version = 'Deprecated since version N'
    desc = 'Deprecation message'
    meta = section_parser.parse(text)
    meta_list = list(meta)
    assert meta_list[0].__dict__['args'] == [key]
    assert meta_list[0].__dict__['description'] == desc
    assert meta_list[0].__dict__['version'] == version


# Generated at 2022-06-21 11:53:46.664883
# Unit test for function parse
def test_parse():
    text = """Description.

    This is a long description.
    This is a long description.
    This is a long description.
    This is a long description.
    This is a long description.
    This is a long description.

    Parameters
    ----------
    a : int
        A description of a.
    b : int, optional
        A description of b.

    Examples
    --------
    Example usage of this function.
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    """

    text = parse(text)
    print(text.short_description)
    print(text.long_description)
    print(text.meta)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:53:55.087546
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input = """
    def add(x: int, y: int) -> int:
        \"\"\"
        Return the sum of x and y.
        Parameters
        ----------
        x: int
            x is a number.
        y: int
            y is a number
        Returns
        -------
        The sum of x and y.
        \"\"\"
        return x + y
    """
    expected_short_description = "Return the sum of x and y."
    expected_long_description = None
    expected_blank_after_short_description = True
    expected_blank_after_long_description = True

# Generated at 2022-06-21 11:54:06.750252
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    def test_parse(text):
        parser = NumpydocParser()
        return parser.parse(text)


# Generated at 2022-06-21 11:54:16.520664
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Case 1
    # Tested function: function parse of class DeprecationSection
    # Input: DeprecationSection.parse(".. deprecated:: 0.40.0\n    "
    #                                 "This property will be removed in future versions.\
    #                                  Use :attr:`Driver.configured` instead."),
    # Expected output: DocstringDeprecated([deprecated],
    #                                      description="This property will be removed in future versions.
    #                                                   Use :attr:`Driver.configured` instead.",
    #                                      version=None)
    tries = DeprecationSection("deprecated", "deprecation")

# Generated at 2022-06-21 11:54:18.641137
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    assert raises.title == "Raises"
