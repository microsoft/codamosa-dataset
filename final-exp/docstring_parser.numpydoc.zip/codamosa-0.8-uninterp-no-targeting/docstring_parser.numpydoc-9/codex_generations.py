

# Generated at 2022-06-21 11:45:24.156597
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Test for default constructor
    np = NumpydocParser()
    assert np.sections == {s.title: s for s in DEFAULT_SECTIONS}

    # Test for constructor with sections given
    sections = T.Dict[str, Section]
    sections = {'title': Section('title', 'key')}
    np = NumpydocParser(sections)
    assert np.sections == sections


# Generated at 2022-06-21 11:45:29.458298
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    import numpydoc_parser
    text = '.. deprecated:: 1.2.0\n\n   This is the description of the deprecation.'
    section = numpydoc_parser.DeprecationSection("deprecated", "deprecation")
    deprecation = next(section.parse(text))
    assert deprecation.description == "This is the description of the deprecation."
    assert deprecation.version == "1.2.0"

# Generated at 2022-06-21 11:45:30.496083
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-21 11:45:33.665406
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    s = Section(title, key)

    assert (s.title == title)
    assert (s.key == key)


# Generated at 2022-06-21 11:45:36.170642
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Invalid regex
    #print(ReturnsSection.is_generator)
    #Invalid regex
    #print(ReturnsSection.is_generator)
    print(ReturnsSection.__dict__)



# Generated at 2022-06-21 11:45:39.815113
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = "key\nvalue\nkey2 : type\nvalues can also span...\n... multiple lines"
    for (match, next_match) in _pairwise(KV_REGEX.finditer(s)):
        print(s[match.end(): next_match.start() if next_match is not None else None])


# Generated at 2022-06-21 11:45:41.431984
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Generated at 2022-06-21 11:45:45.201536
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a = _SphinxSection("Parameters", "param")
    assert a.title == "Parameters"
    assert a.title_pattern == r"^\.\.\s*(Parameters)\s*::"
    assert a.key == "param"
    b = _SphinxSection("Params", "param")
    assert b.title == "Params"
    assert b.title_pattern == r"^\.\.\s*(Params)\s*::"
    assert b.key == "param"


# Generated at 2022-06-21 11:45:47.765423
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = "key\n    value\n    value2"
    assert not _KVSection(title="title", key="key").parse(text)

# Generated at 2022-06-21 11:45:51.404702
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    doctest = {1: "Parameters", 2: "Args", 3: "Raise"}
    NumpydocParser(doctest)


# Generated at 2022-06-21 11:46:04.450088
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parameter = ParamSection('Parameters', 'param')
    assert parameter.title == 'Parameters'
    assert parameter.key == 'param'


# Generated at 2022-06-21 11:46:06.862195
# Unit test for function parse
def test_parse():
    text = parse.__doc__
    assert text != ''
    assert parse(text) != ''

# Generated at 2022-06-21 11:46:15.260649
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from . import parse_decorator_docstring
    docstring = parse_decorator_docstring(
        '''
        a list of tuples
            Each tuple is of the form (target_name, dest_name) where
            target_name is the name of the attribute in self that we want to
            copy and dest_name is the name of the attribute to copy it to in
            the target.
        source_attributes
            The list of attributes to copy from self.
        '''
    )
    print(docstring)

# Generated at 2022-06-21 11:46:18.079195
# Unit test for constructor of class _KVSection
def test__KVSection():
    p = _KVSection("title", "key")
    assert p.title_pattern == r"^title\s*?\n{}*$"



# Generated at 2022-06-21 11:46:25.218671
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    input_str="""
        a
            a_description
        b : type
            b_description
            can also span...
            ...multiple lines
        c
            c_description
        """
    expected_output =[DocstringMeta(["a"], description="a_description"),
                      DocstringMeta(["b"], description="b_description\ncan also span...\n...multiple lines"),
                      DocstringMeta(["c"], description="c_description")]
    # testing parse method of _KVSection with ParamSection
    param_s = ParamSection("Parameters", "param")
    assert list(param_s.parse(input_str)) == expected_output


# Generated at 2022-06-21 11:46:26.608247
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns","returns")
    assert a is not None

# Generated at 2022-06-21 11:46:33.010566
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_obj = _KVSection('title','key')
    expected = 'title'
    actual = test_obj.title
    assert (expected == actual)
    
    expected = 'key'
    actual = test_obj.key
    assert (expected == actual)


# Generated at 2022-06-21 11:46:42.905870
# Unit test for constructor of class DeprecationSection

# Generated at 2022-06-21 11:46:46.729891
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection("Yields", "yields")
    assert yields.is_generator == True
    assert yields.key == "yields"
    assert yields.title == "Yields"


# Generated at 2022-06-21 11:46:53.642111
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    Returns:
        obj.

    Returns:
        obj2.

    Parameters:
        param : type
            Param description.

    """
    doc = parse(text)
    assert(doc.short_description == "Short description.")
    assert(len(doc.meta) == 6)



# Generated at 2022-06-21 11:47:11.378983
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS, "There should be no change."

    parser = NumpydocParser(DEFAULT_SECTIONS)
    assert parser.sections == DEFAULT_SECTIONS, (
        "There should be no change."
    )

    section = Section('title', 'key')
    parser = NumpydocParser([section])
    for k in parser.sections.keys():
        if k == 'title':
            assert parser.sections['title'] == section, (
                'The section named "title" should be replaced.'
            )
        else:
            assert parser.sections[k] == DEFAULT_SECTIONS[k], (
                'The section named "%s" should not be changed.' % k
            )

    parser.add_section(section)


# Generated at 2022-06-21 11:47:18.644869
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("Deprecated", "deprecated")
    text = """\
.. Deprecated::
    version_number
    You should not use the deprecated item."""

    meta = section.parse(text)
    meta = list(meta)[0]
    assert meta.args == ["deprecated"]
    assert meta.description == "You should not use the deprecated item."
    assert meta.version == "version_number"



# Generated at 2022-06-21 11:47:30.901986
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    assert len(text.split('\n')) == 7

    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        assert value == '    value\n' or value == '        values can also span...\n        ... multiple lines\n    '
    ## unit test for parse method of class _KVSection

# Generated at 2022-06-21 11:47:33.383415
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection('Raises' ,'raises')
    assert section.title == 'Raises'
    assert section.key == 'raises'

# Generated at 2022-06-21 11:47:45.639858
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description

    Parameters
    ----------
    arg1 : type
        Argument description.

    arg2 : type
        Argument description.

    Returns
    -------
    type
        Description of returned value.
    """
    result = parse(text)
    assert str(result) == text

    assert result.short_description == "Short description."
    assert result.long_description == "Long description"
    assert len(result.meta) == 2
    assert result.meta[0] == DocstringParam(
        args=["param", "arg1"],
        description="Argument description.",
        arg_name="arg1",
        type_name="type",
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-21 11:47:57.832278
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()
    docstring = numpydoc_parser.parse(
        """\
        Some model description without sections.

        Parameters
        ----------
        first_param : type
            First parameter description.

        Other Parameters
        ----------------
        other_param : type
            Other parameter description.

        Raises
        ------
        ValueError
            If value is not valid.

        Yields
        ------
        something : int
            Something yielded during the processing.

        See Also
        --------
        some_module : Some other module.
        """
    )

    assert docstring.short_description == "Some model description without sections."

# Generated at 2022-06-21 11:48:02.898639
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("Title", "key")
    assert(s.title == "Title")
    assert(s.key == "key")
    assert(s.title_pattern == "^(Title)\s*?\n{}\s*$".format("-" * len(s.title)))

# Generated at 2022-06-21 11:48:13.321502
# Unit test for function parse
def test_parse():
    text = """This is a docstring with a single
    return value.

    Parameters
    ----------
    first_thing : TypeA
        Description of first thing.
    second_thing : optional
        Description of second thing.
    third_thing : empty list by default
        Description of third thing.

    Returns
    -------
    int
        The sum.
    """
    docstring = parse(text)
    assert len(docstring.meta) == 4
    assert len(docstring.params) == 3
    assert len(docstring.returns) == 1
    assert docstring.short_description == 'This is a docstring with a single'
    assert docstring.long_description == 'return value.'

# Generated at 2022-06-21 11:48:18.409124
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    p = RaisesSection("Raises", "raises")
    assert p.title == 'Raises'
    assert p.key == 'raises'
    assert p.title_pattern == r'^(Raises)\s*?\n-+\s*$'


# Generated at 2022-06-21 11:48:25.868948
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    title = "Deprecation Warning"
    key = "deprecation"
    expected_description = """
        This method is deprecated.
        ``res.results`` is now a property.
    """
    expected_version = None

    # Test case: "\n" between "This method is deprecated." and
    # "``res.results`` is now a property."
    test_docstring = """
    .. deprecated:: 0.10.0
        This method is deprecated.
        ``res.results`` is now a property.
    """

    result = DeprecationSection(title, key).parse(
        inspect.cleandoc(test_docstring)
    ).__next__()

    assert result.description == expected_description
    assert result.version == expected_version

    # Test case: "." between "This method is deprecated" and
    #

# Generated at 2022-06-21 11:48:42.759394
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:48:53.747426
# Unit test for method parse of class Section
def test_Section_parse():
    # test 1
    # input
    title = "Parameter"
    key = "param"
    text = "param_1 : int\n\
            arg_1 description"
    # expected output
    result = Docstring()
    result.meta.append(DocstringParam(["param", "param_1"], "arg_1 description", "param_1", "int"))

    assert Section(title, key).parse(text) == result.meta


    # test 2
    # input
    title = "Other Parameters"
    key = "other_param"
    text = "arg_1 : string\n\
            arg_1 description\n\
            arg_2\n\
            arg_2 description"
    # expected output
    result = Docstring()

# Generated at 2022-06-21 11:48:57.387961
# Unit test for constructor of class Section
def test_Section():
    title = "Warnings"
    key = "warnings"
    s = Section(title, key)
    assert s.title == title
    assert s.key == key


# Generated at 2022-06-21 11:49:02.805277
# Unit test for function parse
def test_parse():
    assert parse('do some things\n\nArgs:\n    a: just a\n    b: just b\n') == Docstring(short_description='do some things', blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[DocstringMeta(args=['param', 'a'], description='just a'), DocstringMeta(args=['param', 'b'], description='just b')])

# Generated at 2022-06-21 11:49:06.108586
# Unit test for method parse of class Section
def test_Section_parse():
    result = Section("Section_title_header","Section_title_key").parse("Section_title_body")
    assert next(result) == DocstringMeta([ "Section_title_key" ], "Section_title_body")


# Generated at 2022-06-21 11:49:07.423623
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser

# Generated at 2022-06-21 11:49:12.278622
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    class ReturnsSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringReturns:
            m = RETURN_KEY_REGEX.match(key)
            if m is not None:
                return_name, type_name = m.group("name"), m.group("type")
            else:
                return_name = type_name = None

            return DocstringReturns(
                args=[self.key],
                description=_clean_str(value),
                type_name=type_name,
                is_generator=self.is_generator,
                return_name=return_name,
            )
    print('passed')
    return

# Generated at 2022-06-21 11:49:23.301360
# Unit test for method parse of class Section
def test_Section_parse():
    # Test different posibilities of parsing a title-value type text
    # Try cases like:
    title = 'Attributes'
    key = 'attribute'
    text = ' \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n aa: asfasdf \n \n asdfasdfsadfasdf \n \n bbb: asdfasdfasdf \n \n \n \n \n \n \n \n cccc: bbbb \n \n dddd: eeeee: ffffff'
    factory =  Section(title, key)

    parse_result = []
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end

# Generated at 2022-06-21 11:49:25.887285
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class MySection(Section):
        pass
    my_section = MySection("My section", "my_section")

    parser = NumpydocParser()

    # We don't want the default sections
    assert len(parser.sections) == 0

    parser.add_section(my_section)

    assert parser.sections == {"My section": MySection("My section", "my_section")}


# Generated at 2022-06-21 11:49:29.424647
# Unit test for method parse of class Section
def test_Section_parse():
    a = Section("title","param")
    # return line is just a random string
    # to check if the method works in general
    print(a.parse("   this is a test return line\n    ") == None)


# Generated at 2022-06-21 11:49:38.525870
# Unit test for function parse
def test_parse():
    text = """
    Function

    Parameters
    ----------
    x
        x value.

    y : float
        y value.
    """
    print(parse(text))

    text = """
    Function

    Parameters
    ----------
    self
    """
    print(parse(text))

# Generated at 2022-06-21 11:49:41.007834
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	r = RaisesSection("Raises", "raises")
	assert r.title == "Raises"
	assert r.key == "raises"
	assert r.title_pattern == r'^Raises\s*?\n---+\s*$'
	# assert r._parse_item("ValueError","Hello world") == DocstringRaises([args=[self.key, key]])

# Generated at 2022-06-21 11:49:48.209358
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Arguments", "param")
    assert param_section.title == "Arguments"
    assert param_section.key == "param"
    assert param_section.title_pattern == "^Arguments\s*?\n-----*$"
    assert param_section.parse("key\n    value") == iter([DocstringMeta([], description="key\n    value")])


# Generated at 2022-06-21 11:49:52.144147
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_obj = _KVSection("name","key")
    assert test_obj.title=="name", "title is not assigned correctly"
    assert test_obj.key=="key", "key is not assigned correctly"


# Generated at 2022-06-21 11:50:00.305711
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    param = ['a : int\ndescription', 'b : int\ndescription']
    kv_section = _KVSection('Parameters', 'parameter')
    output = list(kv_section.parse('\n'.join(param)))
    assert len(output) == 2
    assert output[0].args == ['parameter', 'a']
    assert output[0].description == 'description'
    assert output[1].args == ['parameter', 'b']
    assert output[1].description == 'description'

# Generated at 2022-06-21 11:50:06.544686
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    
    # Expected output
    expected_title = "Raises"
    expected_key = "raises"

    # Initialize a RaisesSection object
    testSection = RaisesSection(expected_title, expected_key)
    
    # Assert equality of expected and actual values
    assert testSection.title == expected_title
    assert testSection.key == expected_key


# Generated at 2022-06-21 11:50:14.797623
# Unit test for constructor of class ParamSection
def test_ParamSection():
    from .common import DocstringParam
    input_text = '''
    Parameters
    ----------
    p1
        first parameter
    p2 : type, optional
        second parameter
    '''
    print('Test case: ParamSection')
    print('Input:')
    print(input_text)
    sec_parser = ParamSection("Parameters", "param")
    params = list(sec_parser.parse(input_text))
    print('Output:')
    print(params)
    print('Should be:')

# Generated at 2022-06-21 11:50:23.633876
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = inspect.cleandoc(
        """
    A function that returns a string.
    You may either pass a string to it or use
    the default string.

    Parameters
    ----------
    Input: string
        The string to pass to the function.
        If this is not specified, a default
        string will be used.
    """
    )
    kv = _KVSection("", "")

    assert len(list(kv.parse(text))) == 1
    assert len(list(kv.parse(""))) == 0

# Generated at 2022-06-21 11:50:36.318929
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"

# Generated at 2022-06-21 11:50:38.129690
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_section = _SphinxSection("field","field")
    assert test_section._SphinxSection__title == "field"
    assert test_section._SphinxSection__key == "field"


# Generated at 2022-06-21 11:50:50.553322
# Unit test for method parse of class Section
def test_Section_parse():
    doc = '''
    .. deprecated:: 0.1.2

        You should stop using this. It's not very useful.
    '''
    section = DeprecationSection('deprecated', 'deprecation')
    assert_equals(section.parse(doc), [DocstringDeprecated(args=[section.key], description='You should stop using this. It\'s not very useful.', version='0.1.2')])


# Generated at 2022-06-21 11:50:54.152435
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	title = "Raises"
	key = "raises"
	test_obj = RaisesSection(title, key)
	return test_obj.title == title and test_obj.key == key


# Generated at 2022-06-21 11:50:55.273410
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert isinstance(NumpydocParser(), NumpydocParser)


# Generated at 2022-06-21 11:51:00.558945
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    first = _SphinxSection("arbitrary_title", "arbitrary_key")
    assert first.title == "arbitrary_title"
    assert first.key == "arbitrary_key"

    second = _SphinxSection("another_arbitrary_title", "another_arbitrary_key")
    assert second.title == "another_arbitrary_title"
    assert second.key == "another_arbitrary_key"


# Generated at 2022-06-21 11:51:03.559282
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = """
        returns: str
            Return name and type are required.
        """
    section = ReturnsSection("Returns", "returns")
    ret = section.parse(text)
    assert (isinstance(ret, ReturnsSection))



# Generated at 2022-06-21 11:51:05.569804
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters","param")
    if ps.title != "Parameters":
        assert False



# Generated at 2022-06-21 11:51:18.124878
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from darglint.docstring_parse import DocstringParam
    from darglint.docstring_parse.numpydoc import _KVSection
    ks = _KVSection("Parameters", "param")
    text = '''
        arg : str
            docstring
        arg2 : int, optional
            docstring
    '''
    result = ks.parse(text)
    assert isinstance(result, T.Iterable)
    result = tuple(result)
    assert isinstance(result[0], DocstringParam)
    assert isinstance(result[1], DocstringParam)
    assert result[0].type_name == "str"
    assert result[0].is_optional is False
    assert result[1].type_name == "int"
    assert result[1].is_optional is True

# Generated at 2022-06-21 11:51:23.131377
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydocparser = NumpydocParser()
    assert "Parameters" in numpydocparser.sections

    section = Section("Parameters", "param")
    numpydocparser.add_section(section)
    assert "Parameters" in numpydocparser.sections
    assert numpydocparser.sections["Parameters"] == section

# Generated at 2022-06-21 11:51:32.262960
# Unit test for function parse

# Generated at 2022-06-21 11:51:37.490436
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """[numpydoc_parser] Test parsing method parse of class NumpydocParser"""
    # Build a body of text as a docstring
    txt = """
    This is an example of a numpy-style docstring.  Those which
    follow the `'NumpyDoc'`_ standard.

    Parameters
    ----------
    foo : {'bar', 'baz'}, optional
        A positional parameter.
    bar : str, optional
        A keyword parameter.

    Returns
    -------
    str
        The return type is a string.

    """
    # Define a parser
    parser = NumpydocParser()
    # Parse the text
    docstring = parser.parse(txt)
    # Return the docstring
    return(docstring)

# Generated at 2022-06-21 11:51:53.437731
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.title_pattern == r"^Returns\s*?\n-*\s*$"
    assert type(section.parse("")) == type(itertools.tee)
    assert type(section.parse(" : ")) == type(itertools.tee)
    assert type(section.parse(" : \n")) == type(itertools.tee)
    assert type(section.parse(" : type\n")) == type(itertools.tee)

# Generated at 2022-06-21 11:52:05.483582
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    docstring = """
    Function to add two numbers.

    :param a: first number
    :param b: second number
    :returns: sum of the two numbers
    :rtype: int
    """

    parsed_docstring = parse(docstring)

# Generated at 2022-06-21 11:52:11.685548
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def func(a, b, *c, **d):
        """Short description.

        Long description.

        Parameters
        ----------
        a : type
            this param is documented

        b : type
            this param is documented

        Raises
        ------
        KeyError
            - In one line
            - In another line
        ValueError

        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required
        """
        return a + b

    result = NumpydocParser().parse(inspect.getdoc(func))
    print(result)


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-21 11:52:21.826063
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    c
    float
        int
    float
        c
        float
    """

    text = inspect.cleandoc(text)
    _KVSection("", "").parse(text)

    for match, next_match in _pairwise(_KVSection("", "")._KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        value = inspect.cleandoc(value)
        print(value)

# Generated at 2022-06-21 11:52:28.918867
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    default_parser = NumpydocParser()
    sphinx_parser = NumpydocParser([Section("something", "key")])
    assert str(default_parser.parse('smth\n-\nsmth2')) == str(Docstring([], short_description='smth',
         long_description='smth2', blank_after_short_description=False, blank_after_long_description=False))
    assert str(sphinx_parser.parse('.. something:: smth2')) == str(Docstring([DocstringMeta(['key'], description='smth2')],
          short_description=None, long_description=None,
          blank_after_short_description=False, blank_after_long_description=False))

# Generated at 2022-06-21 11:52:36.437414
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test1 = ReturnsSection('Returns', 'returns')
    assert test1.is_generator == False
    assert test1.title == 'Returns'
    assert test1.key == 'returns'

    test2 = ReturnsSection('Yields', 'yields')
    assert test2.is_generator == True
    assert test2.title == 'Yields'
    assert test2.key == 'yields'

# Generated at 2022-06-21 11:52:37.813237
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()
    NumpydocParser({})


# Generated at 2022-06-21 11:52:44.267812
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r1 = ReturnsSection("Returns", "returns")
    r2 = ReturnsSection("Returns", "yields")
    r3 = ReturnSection("Returns", "returns")
    r4 = ReturnsSection("Returns", "receives")

    assert(isinstance(r1, ReturnsSection))
    assert(isinstance(r2, YieldsSection))
    assert(not isinstance(r3, ReturnsSection))
    assert(not isinstance(r4, ReturnsSection))


# Generated at 2022-06-21 11:52:53.072497
# Unit test for function parse
def test_parse():
    doc = """Example function with types documented in the docstring.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    TODO: remove this example?
    """

    docstring = parse(doc)

    assert docstring.short_description == "Example function with types documented in the docstring."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description is None
    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].args == ["param", "param1"]

# Generated at 2022-06-21 11:52:57.202684
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = DeprecationSection("deprecated", "deprecation")
    text = """\
    .. Depreciation:: 0.1.0
    \n\
    this function is deprecated\
    """
    parsed_text = d.parse(text)
    assert all(
        isinstance(i, DocstringDeprecated) for i in parsed_text
    ), f"Not all converted to docstring"


# Generated at 2022-06-21 11:53:26.065282
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    string = '''    my_key
        my_value
    key1 : type1
        my_value1
    key2 : type2, optional
        my_value2
    key3 : type3(optional)
        my_value3
    key4 : type4
        my_value4
        Default is something
    key5 : type5
        my_value5
        Defaults to something
    key6
        my_value6
        Default=something'''


# Generated at 2022-06-21 11:53:27.941883
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    _RaisesSection = RaisesSection("Raises", "raises")
    assert type(_RaisesSection) is RaisesSection


# Generated at 2022-06-21 11:53:28.527509
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    pass

# Generated at 2022-06-21 11:53:31.312413
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r.title == "Returns"
    assert r.key == "returns"
    assert r.title_pattern == r"^\.\.\s*Returns\s*::"

# Generated at 2022-06-21 11:53:35.957499
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    """Unit test for constructor of class _SphinxSection.

    It is also a test for method parse in the superclass Section.
    """
    section = _SphinxSection("something", "something")
    assert section.title == "something"
    assert section.key == "something"
    assert str(section.title_pattern) == "^\\.\\.\\s*(something)\\s*::"
    assert section.parse("something") == [DocstringMeta(["something"], description=None)]

# Generated at 2022-06-21 11:53:48.344033
# Unit test for method parse of class Section
def test_Section_parse():
    # test case 1
    assert Section("Parameters", "param").parse("This is the body") == [DocstringMeta(["param"], description='This is the body')]
    # test case 2
    assert Section("Parameters", "param").parse("Here is\n\na description\nthat spans multiple lines\n") == [DocstringMeta(["param"], description='Here is\n\na description\nthat spans multiple lines\n')]
    # test case 3
    assert Section("Parameters", "param").parse("This is the body") == [DocstringMeta(["param"], description='This is the body')]
    # test case 4

# Generated at 2022-06-21 11:53:55.850622
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string = """A short summary with a newline

    Long description

    Parameters
    ----------
    param1 : int
        Description of param1
    param2 : str
        Description of param2
    param3 : bool, optional
        Description of param3

    Returns
    -------
    dict
        Return doc
    """

    parser = NumpydocParser()
    doc_structure = parser.parse(doc_string)
    assert doc_structure is not None, 'doc_structure should be not None'
    assert doc_structure.short_description == 'A short summary with a newline', 'doc_structure.short_description should be equal \'A short summary with a newline\''

# Generated at 2022-06-21 11:53:58.374513
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False
    assert YieldsSection("Yields", "yields").is_generator == True


# Generated at 2022-06-21 11:54:02.338890
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection("title", "key")
    assert sec.title == "title"
    assert sec.key == "key"
    assert sec.title_pattern == "^\.\. title\\s*::"
    

# Generated at 2022-06-21 11:54:14.112406
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test if method add_section overrides or adds a section
    """
    initial_title = 'Testing'
    test_title = 'Tested'
    test = NumpydocParser()

    # Remove the current section from the test instance
    test.add_section(Section(initial_title, 'test'))
    orig_sections = test.sections.copy()
    del test.sections[initial_title]

    # Add different section
    test.add_section(Section(test_title, 'no_test'))
    final_sections = test.sections.copy()

    # Compare initial and final set of titles
    initial_titles = list(orig_sections.keys())
    final_titles = list(final_sections.keys())
    assert set(initial_titles) != set(final_titles)

    #