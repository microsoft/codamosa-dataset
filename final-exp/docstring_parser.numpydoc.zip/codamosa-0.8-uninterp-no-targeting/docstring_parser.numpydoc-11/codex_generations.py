

# Generated at 2022-06-21 11:45:12.530044
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    my_parser = NumpydocParser()
    my_section = Section("my title", "my key")
    my_parser.add_section(my_section)
    assert my_section in my_parser.sections.values()
    assert my_section == my_parser.sections["my title"]
    assert None == my_parser.sections.get("Other Arguments")


# Generated at 2022-06-21 11:45:21.057274
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    first
        First description
    second : type, optional
        Second description

    """
    sections = [
        ParamSection("", "")
    ]
    parser = NumpydocParser(sections)

    docstring = parser.parse(text)

    for meta in docstring.meta:
        if meta.type == 'param':
            if meta.args[1] == 'first':
                assert meta.description == 'First description'
            if meta.args[1] == 'second':
                assert meta.description == 'Second description'
                assert meta.type_name == 'type'
                assert meta.is_optional == True



# Generated at 2022-06-21 11:45:31.281774
# Unit test for function parse
def test_parse():
    input = """
    short
    line 1
    line 2

    Parameters
    ----------

    param : type
        Description
    param2
        Description
    other param : type, optional
        Description
    """
    expected = Docstring(
        short_description="short",
        long_description=(
            "line 1\n"
            "line 2\n"
            "\n"
            "Parameters\n"
            "----------\n"
            "\n"
            "param : type\n"
            "    Description\n"
            "param2\n"
            "    Description\n"
            "other param : type, optional\n"
            "    Description\n"
        ),
    )

    assert parse(input) == expected

# Generated at 2022-06-21 11:45:31.984743
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection("title", "key")

# Generated at 2022-06-21 11:45:36.750367
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    print("RaisesSection")
    print("  Title:", raises.title)
    print("  Key:", raises.key)
    print("  Title Pattern:", raises.title_pattern)
    print("  Parsed:", raises.parse("ValueError\nA description."))


# Generated at 2022-06-21 11:45:40.909103
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"""
    expected = [
        DocstringMeta([ "param", "key"], description="value"),
        DocstringMeta([ "param", "key2"], description="values can also span...\n    ... multiple lines", type_name="type")
    ]
    kv_section = _KVSection("Parameters", "param")
    assert kv_section.parse(text) == expected


# Generated at 2022-06-21 11:45:46.480881
# Unit test for constructor of class ParamSection
def test_ParamSection():
    sections = [
        ParamSection("Parameters", "param"),
        ParamSection("Params", "param"),
        ParamSection("Other Parameters", "other_param"),
        ParamSection("Other Args", "other_param"),
        ParamSection("Receives", "receives"),
        ParamSection("Attribute", "attribute"),
        ParamSection("Warnings", "warnings"),
        ParamSection("Warning", "warnings"),
    ]
    for s in sections:
        assert s.title
        assert s.key
    for s1, s2 in zip(sections[:-1], sections[1:]):
        assert s1.title != s2.title
        assert s1.key != s2.key

# Generated at 2022-06-21 11:45:58.065329
# Unit test for function parse
def test_parse():
    """Test code

    Examples
    --------
    >>> import sys
    >>> sys.path.append("/Users/angel/miniconda3/lib/python3.7/site-packages/")
    >>> import pytest
    >>> pytest.main(["test_numpydoc_parser.py", "-v", "-s"])

     """
    text = """
    Function to plot some important information from the classification.

    This function visualizes the confusion matrix, the ROC curves  and
    the feature importance plot.
    It also stores the figures in a folder

    Parameters
    ----------
    conf_matrix : numpy array
        Confusion matrix.
    class_names : numpy array
        Array with the class names.
    feature_names : numpy array
        Array with the names of the features.
    """
    assert isinstance

# Generated at 2022-06-21 11:46:10.918547
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = inspect.cleandoc("""
        This is the docstring of a class
        
        Parameters
        ----------
        parametre_a : int
            the description of parametre_a
        
        Other Parameters
        ----------------
        parametre_b : list
            the description of parametre_b
        """)

    result_0 = NumpydocParser().parse(text_0)
    class_name = "NumpydocParser"
    assert result_0.meta[0].args == [class_name, "parametre_a"]
    assert result_0.meta[0].type_name == "int"
    assert result_0.meta[0].description == "the description of parametre_a"

# Generated at 2022-06-21 11:46:15.582229
# Unit test for constructor of class YieldsSection

# Generated at 2022-06-21 11:46:32.897072
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section('Title', 'key')
    text = "The method does some stuff\n"
    ds = sec.parse(text)
    for f in ds:
        assert f.args[0] == 'key'
        assert f.description == 'The method does some stuff'


# Generated at 2022-06-21 11:46:41.810309
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("NewSection", "new_section"))
    assert parser.sections.keys() == {'NewSection', 'Parameters', 'Params', 'Arguments', 'Args', 'Other Parameters',
                                      'Other Params', 'Other Arguments', 'Other Args', 'Receives', 'Receive', 'Raises',
                                      'Raise', 'Warns', 'Warn', 'Attributes', 'Attribute', 'Returns', 'Return', 'Yields',
                                      'Yield', 'Examples', 'Example', 'Warnings', 'Warning', 'See Also', 'Related', 'Notes',
                                      'Note', 'References', 'Reference', 'deprecated'}

# Generated at 2022-06-21 11:46:44.976712
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    t = _SphinxSection("T", "a")
    t.title == "T"
    t.key == "a"
    t.title_pattern == "^\.\.\s*(T)\s*::"

# Generated at 2022-06-21 11:46:53.099841
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = ParamSection("Test", "test")
    result = list(p.parse('key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines'))
    assert result[0].arg_name == 'key'
    assert result[0].description == 'value'
    assert result[1].arg_name == 'key2'
    assert result[1].description == 'values can also span...\n... multiple lines'


# Generated at 2022-06-21 11:47:05.370238
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from _pytest.monkeypatch import MonkeyPatch
    from .common import DocstringMeta
    from .numpydoc import test__KVSection_parse
    parser = _KVSection(title="Assertion", key="Test")
    parser._parse_item = lambda x, y: DocstringMeta([])
    assert parser.parse("") == []
    assert parser.parse("Test\n"
                        "    Test") == [DocstringMeta([])]
    assert parser.parse("Test2 : asd\n"
                        "    Test2") == [DocstringMeta([])]
    assert parser.parse("Test3\n"
                        "    Test3\n"
                        "Test4 : qwe\n"
                        "    Test4") == [DocstringMeta([])] * 2

# Generated at 2022-06-21 11:47:07.676745
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a=ReturnsSection("Returns", "returns")
    print(a.is_generator)
    print(a.title)


# Generated at 2022-06-21 11:47:11.497014
# Unit test for constructor of class _KVSection
def test__KVSection():
    print("test__KVSection:",end="")
    section = _KVSection("Parameters", "param")
    for i in section.title_pattern:
        if(i == "-"):
            print()
        else:
            print(i,end="")
    print()


# Generated at 2022-06-21 11:47:14.372134
# Unit test for method parse of class Section
def test_Section_parse():
    text = "ParamSection"
    section = Section(text, "param")
    assert section.parse(text) == DocstringMeta([text], description=text)


# Generated at 2022-06-21 11:47:17.444900
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	s = Section("s", "key")
	p = DeprecationSection("s", "key")
	assert s.title_pattern != p.title_pattern

# Generated at 2022-06-21 11:47:21.381156
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    #Test with sections
    sections = {
        "title": "param"
    }
    NumpydocParser(sections)

    #Test without sections
    NumpydocParser()


# Generated at 2022-06-21 11:47:38.869486
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_section = _KVSection(title="Parameters", key="param")
    text = """
            key
                value
            key2 : type
                values can also span...
                ... multiple lines
            """
    key_1 = "key"
    value_1 = "value"
    key_2 = "key2 : type"
    value_2 = """
            values can also span...
            ... multiple lines
            """

    params = [key_1, value_1, key_2, value_2]
    expected = kv_section.parse(text)

    assert key_1 in str(expected)
    assert value_1 in str(expected)
    assert key_2 in str(expected)
    assert value_2 in str(expected)


# Generated at 2022-06-21 11:47:49.814804
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    name = "title"
    meta_key = "key"
    # Valid syntax
    section = _SphinxSection(name, meta_key)
    assert(section.title_pattern == r"^\.\.\s*(title)\s*::")
    # Invalid syntax - more than one ":"
    section = _SphinxSection(name+":", meta_key)
    assert(section.title_pattern == r"^\.\.\s*(title:)\s*::")

    # Unit test for class DeprecationSection
    name = "deprecated"
    meta_key = "key"
    section = DeprecationSection(name, meta_key)
    assert(section.title_pattern == r"^\.\.\s*(deprecated)\s*::")

# Generated at 2022-06-21 11:48:00.145394
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Define simple docstring
    docstring1 = """
    Summarize the key information of a numpy-style docstring.

    Insert empty line.

    Parameters
    ----------
    text : str
        A numpy-style docstring.

    Returns
    -------
    description, meta : str, list
        The description text, and a list of meta-data.
    """

    # Define more complex docstring
    docstring2 = """
    Summarize the key information of a numpy-style docstring.

    Parameters
    ----------
    text : str
        A numpy-style docstring.

    Returns
    -------
    description, meta : str, list
        The description text, and a list of meta-data.
    """

    # Parse the simple docstring
    NumpydocParser_instance = Nump

# Generated at 2022-06-21 11:48:04.899919
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    s_title = "Raises"
    s_key = "raises"
    sec = RaisesSection(s_title, s_key)
    assert sec.title == s_title
    assert sec.key == s_key


# Generated at 2022-06-21 11:48:15.181851
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
        A shorter description of the function.

        This description can span lines and include common formatting
        e.g. **markdown**, _italics_ and even *math*: :math:`x**2 + y**2 = z**2`
        (using sphinx's :rst:role:`math` directive).

        Parameters
        ----------
        arg1 : int
            This is arg1.
        arg2 : str
            This is arg2.

        Returns
        -------
        namedtuple(['thing1', 'thing2'])
            This returns a namedtuple of two things.

        See Also
        --------
        other_func : companion function to this
        """

# Generated at 2022-06-21 11:48:18.397830
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds=DeprecationSection("deprecated","deprecation")
    assert ds.title=="deprecated"
    assert ds.key=="deprecation"
    assert ds.title_pattern==r"^\.\.\s*(deprecated)\s*::"
    print("Pass all tests")
    
#Unit test for constructor of class ReturnsSection

# Generated at 2022-06-21 11:48:20.394131
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection('Parameters','param') == _KVSection('Parameters','param')



# Generated at 2022-06-21 11:48:20.868967
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert 1 == 1

# Generated at 2022-06-21 11:48:24.025366
# Unit test for method parse of class Section
def test_Section_parse():
    assert ParamSection("Parameters", "param").parse("key") == []
    assert ParamSection("Parameters", "param").parse("key\n    value") == [DocstringMeta(['param', 'key'], description='value')]


# Generated at 2022-06-21 11:48:24.989995
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys is not None

# Generated at 2022-06-21 11:48:35.499002
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """
    Unit test for constructor of class RaisesSection
    :return: None
    """
    with pytest.raises(TypeError):
        RaisesSection(None, 'test')
    with pytest.raises(TypeError):
        RaisesSection('test', 1)
    assert RaisesSection('test', 'test')

# Generated at 2022-06-21 11:48:37.819558
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_title = 'Param'
    section_key = 'Param'
    kvsection = _KVSection(section_title, section_key)


# Generated at 2022-06-21 11:48:39.236474
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():

    assert( ReturnsSection("Returns", "returns").key == "returns")

# Unit test Section._pairwise

# Generated at 2022-06-21 11:48:41.045589
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # Test no pattern ending with ::
    try:
        _SphinxSection(".. title:: something", "")
        assert False
    except Exception:
        assert True


# Generated at 2022-06-21 11:48:44.559990
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = 'Parameters'
    key = 'param'
    p = _KVSection(title, key)
    assert p.title == 'Parameters'
    assert p.key == 'param'



# Generated at 2022-06-21 11:48:50.781442
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Test", "method")
    test_text = ("Test\n"
                 "----\n"
                 "This is the first text\n"
                 "This is the second text\n\n"
                 "This is the third text")
    expected = ([DocstringMeta(["method"], description=test_text)]
                if test_text else [])
    res = section.parse(test_text)
    assert res == expected

# Generated at 2022-06-21 11:48:54.138678
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {
        "title": Section("title", "key"),
        "title_params": Section("title", "param"),
    }
    parser = NumpydocParser(sections)
    assert parser.sections == sections


# Generated at 2022-06-21 11:48:55.797637
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param") == ParamSection("Parameters", "param")

# Generated at 2022-06-21 11:49:01.108158
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_text = \
'''
yields : type
    A description of this returned value
another_type
    Return names are optional, types are required
'''
    yield_parsed = YieldsSection('Yields', 'yields')
    result = yield_parsed.parse(yield_text)
    print(result)


# Generated at 2022-06-21 11:49:08.121735
# Unit test for method parse of class Section
def test_Section_parse():
    section_1 = Section("Parameters", "param")
    section_2 = Section("Params", "param")
    section_3 = Section("Arguments", "param")
    section_4 = Section("Args", "param")
    section_5 = Section("Other Parameters", "other_param")
    section_6 = Section("Other Params", "other_param")
    section_7 = Section("Other Arguments", "other_param")
    section_8 = Section("Other Args", "other_param")
    section_9 = Section("Receives", "receives")
    section_10 = Section("Receive", "receives")
    section_11 = Section("Raises", "raises")
    section_12 = Section("Raise", "raises")
    section_13 = Section("Warns", "warns")

# Generated at 2022-06-21 11:49:23.469275
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _SphinxSection.__init__("References", "references")

# Generated at 2022-06-21 11:49:32.868359
# Unit test for function parse
def test_parse():
    assert parse("").short_description is None
    assert parse("").long_description is None
    assert parse("").blank_after_short_description is False
    assert parse("").blank_after_long_description is False
    assert parse("").meta == []

    assert parse("a").short_description is not None
    assert parse("a").short_description == "a"
    assert parse("a").long_description is None
    assert parse("a").blank_after_short_description is False
    assert parse("a").blank_after_long_description is False
    assert parse("a").meta == []

    assert parse("a\n\n").short_description is not None
    assert parse("a\n\n").short_description == "a"
    assert parse("a\n\n").long_description is not None

# Generated at 2022-06-21 11:49:38.090222
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("title", "key")
    text = """title
        value
    """
    expected = "value".strip()
    text = inspect.cleandoc(text)
    actual = section.parse(text)
    assert actual
    assert actual[0].args == ["key"]



# Generated at 2022-06-21 11:49:41.731608
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = Section("Test", "test")
    parser = NumpydocParser()
    parser.add_section(test_section)
    assert parser.sections["Test"] == test_section


# Generated at 2022-06-21 11:49:42.887400
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    print("Description of ReturnsSection")



# Generated at 2022-06-21 11:49:47.648306
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert "Returns" == ReturnsSection("Returns", "returns").title
    assert "returns" == ReturnsSection("Returns", "returns").key
    assert "Returns" == ReturnsSection("Returns", "returns").title_pattern


# Generated at 2022-06-21 11:49:56.896039
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Valid testcases
    valid_testcases = [
        (("ValidSection", "ValidSection"), ("valid_section", "valid_section")),
        (("ValidSection", "ValidSection"), ("va1id_section", "va1id_section")),
        (("Valid_Section", "Valid_Section"), ("valid_section", "valid_section")),
        (("Valid_Section", "ValidSection"), ("valid_section", "valid_section")),
    ]

    # Invalid testcases
    invalid_testcases = [
        (("InValidSection", "InValidSection"), ("invalid_section", "invalid_section")),
    ]

    # Iterate valid testcases
    for valid_testcase in valid_testcases:
        test_title = valid_testcase[0][0]
        expected_key = valid_test

# Generated at 2022-06-21 11:50:08.464614
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = RaisesSection("Raises","raises")
    assert isinstance(parser._parse_item("ValueError", "A description of what might raise ValueError"), DocstringRaises), "class is DocstringRaises"
    assert parser._parse_item("ValueError", "A description of what might raise ValueError").args == ["raises", "ValueError"], "args is ['raises', 'ValueError']"
    assert parser._parse_item("ValueError", "A description of what might raise ValueError").description == "A description of what might raise ValueError", "description is A description of what might raise ValueError"
    assert parser._parse_item("ValueError", "A description of what might raise ValueError").type_name == "ValueError", "type_name is ValueError"

# Generated at 2022-06-21 11:50:09.520608
# Unit test for constructor of class ParamSection
def test_ParamSection():
    
    a = ParamSection("Test", "param")

# Generated at 2022-06-21 11:50:11.814310
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").title == "Returns"
    assert ReturnsSection("Returns", "returns").key == "returns"


# Generated at 2022-06-21 11:50:39.251572
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")

    assert s.title == "Parameters"
    assert s.key == "param"
    assert s.title_pattern == r"^Parameters\s*?\n{}\s*$".format("-" * 11)


# Generated at 2022-06-21 11:50:51.472009
# Unit test for function parse
def test_parse():
    test_docstring = '''a brief description
        of the function
    Parameters
    ----------
    arg_1 : str
        first argument
    arg_2 : type, optional
        second argument, default is True

    Raises
    ------
    ValueError
        When something wrong is provided.

    Returns
    -------
    returned_type
        Information about the returned object.

    See Also
    --------
    None
    '''
    res = NumpydocParser().parse(test_docstring)

# Generated at 2022-06-21 11:50:52.543799
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param")


# Generated at 2022-06-21 11:50:55.776465
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Hello", "hello")
    text = """Hello
------

Hello World
"""
    assert list(s.parse(text)) == [DocstringMeta(["hello"], description="Hello World")]



# Generated at 2022-06-21 11:51:00.965142
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydocParser = NumpydocParser()
    numpydocParser.add_section(Section("Hello", "hello"))
    match = re.search(r"Hello\s*?\n{4}\s*$", "Hello\n----\ntest\n")
    assert match is not None
    match = re.search(r"Hello\s*?\n{4}\s*$", "Hello\n----\n")
    assert match is not None

# Generated at 2022-06-21 11:51:03.909455
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection("", "").parse("a\n    b\nc\n    d")) == \
    [DocstringMeta(['',''],description='b'),
     DocstringMeta(['',''],description='d')]

# Generated at 2022-06-21 11:51:08.008797
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    title = "Raises"
    key = "raises"
    raises = RaisesSection(title, key)
    assert(title == raises.title)
    assert(key == raises.key)


# Generated at 2022-06-21 11:51:10.809992
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("Parameters", "param").title_pattern == r"^\.\.\s*(Parameters)\s*::"

# Generated at 2022-06-21 11:51:14.858962
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("deprecated", "deprecation")
    assert d.__class__ == DeprecationSection
    assert d.title == "deprecated"
    assert d.key == "deprecation"

# Generated at 2022-06-21 11:51:16.943691
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection(title="title", key="key")
    assert str(d) == "DeprecationSection(title='title', key='key')"

# Generated at 2022-06-21 11:51:45.665958
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection('title', 'key')
    assert s.title == 'title'
    assert s.key == 'key'


# Generated at 2022-06-21 11:51:52.276789
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    s = Section(title=title, key="key")
    assert s.title == title
    assert s.key == "key"
    def check(s):
        assert s.title_pattern == r"^({})\s*?\n{}\s*$".format(s.title, "-" * len(s.title))
    check(s)
    s = Section(title="Title", key="key")
    check(s)


# Generated at 2022-06-21 11:51:57.462617
# Unit test for constructor of class Section
def test_Section():
    assert Section('Parameters', 'parameter').title_pattern == '^(Parameters)\s*?\n-------\s*$'
    assert Section('Parameters', 'parameter').parse('args1') == [
        DocstringMeta(['parameter'], description='args1')
    ]


# Generated at 2022-06-21 11:52:07.860493
# Unit test for constructor of class _KVSection
def test__KVSection():
    # initialization with title and key
    test_KVSection = _KVSection("Parameters","param")
    assert test_KVSection.title == "Parameters"
    assert test_KVSection.key == "param"
    # test wrong initialization title (fail)
    try:
        test_KVSection2 = _KVSection("Paramaters","param")
    except NameError:
        print("test__KVSection: failed")
    # test wrong initialization key (fail)
    try:
        test_KVSection2 = _KVSection("Parameters","params")
    except NameError:
        print("test__KVSection: failed")
    # test initialization with wrong title and key (fail)

# Generated at 2022-06-21 11:52:20.428585
# Unit test for function parse
def test_parse():
    parser = NumpydocParser()
    test_cases = {
        "": {"short": None, "long": None},
        "a": {"short": "a", "long": None},
        "a\n": {"short": "a", "long": None},
        "a\nb": {"short": "a", "long": "b"},
        "a\n\nb": {"short": "a", "long": "\nb"},
        "a\n\n\nb": {"short": "a", "long": "\n\nb"}
    }
    for text, expected in test_cases.items():
        assert parser.parse(text).short_description == expected["short"]
        assert parser.parse(text).long_description == expected["long"]



# Generated at 2022-06-21 11:52:26.882160
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = """
    cookies
        milk
        milk milk milk milk milk milk milk milk milk milk milk milk milk milk milk milk milk milk milk 
    """
    s = inspect.cleandoc(s)
    matchs = KV_REGEX.finditer(s)
    for match, next_match in _pairwise(matchs):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = s[start:end]
        print(match.group())
        print(inspect.cleandoc(value))


# Generated at 2022-06-21 11:52:34.886922
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_text = '''
    .. deprecated:: 1.0.0
    
        This is deprecated.
    '''
    ret = NumpydocParser().parse(test_text)
    assert ret.meta[0].args[0] == 'deprecation'
    assert ret.meta[0].description == 'This is deprecated.'
    assert ret.meta[0].version == '1.0.0'


# Generated at 2022-06-21 11:52:37.150253
# Unit test for constructor of class Section
def test_Section():
    sec = Section(title="ID", key="key")
    assert sec.title == "ID"
    assert sec.key == "key"


# Generated at 2022-06-21 11:52:41.049648
# Unit test for constructor of class Section
def test_Section():
    test_title = 'This is a test title'
    test_key = 'test'
    test_section = Section(test_title, test_key)
    assert test_section.title == test_title
    assert test_section.key == test_key


# Generated at 2022-06-21 11:52:50.581291
# Unit test for function parse
def test_parse():
    def foo(bar, baz = 3, quux=False):
        """Compute stuff

        Parameters
        ----------
        bar : array-like
            First input
        baz : int, optional
            Second input. Default is 3.
        quux : bool, optional
            A boolean flag. Default is False.

        Returns
        -------
        None

        Raises
        ------
        ValueError
            When something goes wrong.

        Examples
        --------
        >>> foo(bar=5, baz=6)
        >>> foo(5, 6)

        .. deprecated:: 0.2
            Use :func:`bar` instead.

        References
        ----------
        See [1]_, [2]_, [3]_
        """
        pass

    d = parse(foo.__doc__)

    assert d.short_