

# Generated at 2022-06-21 11:45:20.750152
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    x = ReturnsSection('Returns', 'returns')
    x.is_generator = True


# Generated at 2022-06-21 11:45:29.594366
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert len(DEFAULT_SECTIONS) == 32
    assert DEFAULT_SECTIONS[0].title == "Parameters"
    assert DEFAULT_SECTIONS[0].key == "param"
    assert DEFAULT_SECTIONS[0].title_pattern == r"^Parameters\s*?\n-{9}\s*$"

    # Unit test for class Section
    assert Section("Title", "key").title == "Title"
    assert Section("Title", "key").key == "key"

    # Unit test for Property title_pattern of class Section
    assert Section("Title", "key").title_pattern == r"^Title\s*?\n-{5}\s*$"

    # Unit test for function _pairwise of module numpydoc_parser
    my_list = []

# Generated at 2022-06-21 11:45:35.890190
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text1 = """
lorem ipsum
    dolor sit amet
jeo
    tes
"""
    
    text2 = """
lorem ipsum : int64
    dolor sit amet
jeo
    tes
"""

    text3 = """
lorem ipsum : int64, optional
    dolor sit amet
jeo
    tes
"""

    text4 = """
lorem ipsum : int64(optional)
    dolor sit amet
jeo
    tes
"""
    
    text5 = """
lorem ipsum : int64,optional
    dolor sit amet
jeo
    tes
"""

# Generated at 2022-06-21 11:45:38.792126
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    """Unit test for constructor of class _SphinxSection"""
    sec = _SphinxSection("title", "key")
    assert sec.title == "title"
    assert sec.key == "key"
    assert sec.title_pattern == "^\\.\\.\\s*(title)\\s*::"



# Generated at 2022-06-21 11:45:43.727033
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Instantiate the parser with the default sections
    parser = NumpydocParser()
    assert set(parser.sections.keys()) == set(
        [section.title for section in DEFAULT_SECTIONS]
    )

    # Add a new section that does not match any of the default sections
    new_section = Section('A section with a title that does not match any of the default sections', 'key')
    parser.add_section(new_section)
    assert set(parser.sections.keys()) == set(
        [section.title for section in DEFAULT_SECTIONS + [new_section]]
    )

    # Add a new section that matches a default section
    new_section = Section('Raises', 'key2')
    parser.add_section(new_section)

# Generated at 2022-06-21 11:45:44.357807
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("Example", "example")

# Generated at 2022-06-21 11:45:57.069344
# Unit test for function parse
def test_parse():
    """test numpy-style docstring parser and check parsed docstring from
    EMAExplorer.py and EMAWorkbench.py.
    """
    from .common import Docstring, DocstringMeta
    from .format import format as formatter
    from .parse_sphinx import parse as sphinx_parser
    import os

    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

    with open('../../EMAToolkit/src/EMAexplorer/EMAexplorer.py', 'r') as f:
        example_1 = f.read()

# Generated at 2022-06-21 11:45:59.227740
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sections = NumpydocParser()
    assert sections.sections["Returns"].is_generator == False


# Generated at 2022-06-21 11:46:01.625652
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False


# Unit test of method parse

# Generated at 2022-06-21 11:46:03.255600
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert(isinstance(_KVSection('title', 'key'), Section))


# Generated at 2022-06-21 11:46:22.972650
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "some title"
    key = "some key"
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^\.\.\s*(some title)\s*::"



# Generated at 2022-06-21 11:46:24.913246
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated::
    """
    assert len(DeprecationSection("deprecated", "deprecation").parse(text)) == 1


# Generated at 2022-06-21 11:46:28.136608
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("param","param")
    assert ps.title == "param"
    assert ps.key == "param"
    assert ps.title_pattern == r"^(param)\s*?\n---*\s*$"


# Generated at 2022-06-21 11:46:32.324320
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    p = NumpydocParser()
    assert p.sections['Parameters'].title == 'Parameters'
    assert p.sections['Parameters'].key == 'param'



# Generated at 2022-06-21 11:46:34.861646
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    assert(param_section.title == "Parameters")
    assert(param_section.key == "param")


# Generated at 2022-06-21 11:46:38.438031
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_RaisesSection = RaisesSection("Raises", "raises")
    assert test_RaisesSection.title == "Raises", "Not the right title"
    assert test_RaisesSection.key == "raises"


# Generated at 2022-06-21 11:46:44.480236
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    assert r.title_pattern == "^Raises\\s*?\n\\s*$"
    assert r.parse("ValueError\nA description of what might raise ValueError") 
    assert not r.parse("")
    assert not r.parse("Raises")
    assert not r.parse("Raises\n")
    assert not r.parse("Raises\n\n")
    assert not r.parse("Raises\n----")


# Generated at 2022-06-21 11:46:57.739539
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Testing Parameters section
    test_section_param = _KVSection('Parameters', 'param')
    # test for key-value pair
    test_section_param_text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines"""
    # test for key-value pair
    test_section_param_text_1 = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
        """
    # test for key-value pair with no description
    test_section_param_text_2 = """
    arg_name

    arg_2 : type, optional
        """
    # test for key-value pair with no description and no key
    test_section_param_text_3

# Generated at 2022-06-21 11:47:00.325064
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert_equal(ReturnsSection("Returns", "returns").is_generator, False)
    assert_equal(ReturnsSection("Returns", "returns").key, "returns")


# Generated at 2022-06-21 11:47:10.993468
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class testSection1(Section):
        def __init__(self):
            Section.__init__(self, 'Parameters', 'p')
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            return [DocstringMeta(['p'], description='test')]
    class testSection2(Section):
        def __init__(self):
            Section.__init__(self, 'Arguments', 'arg')
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            return [DocstringMeta(['arg'], description='test')]
    class testSection3(Section):
        def __init__(self):
            Section.__init__(self, 'Params', 'p')

# Generated at 2022-06-21 11:47:23.972913
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    f = DeprecationSection("Deprecated", "deprecated")
    assert f.title == "Deprecated"
    assert f.key == "deprecated"

# Generated at 2022-06-21 11:47:27.249206
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == 27
    for section in DEFAULT_SECTIONS:
        assert parser.sections[section.title] == section
        assert parser.sections[section.title].title == section.title
        assert parser.sections[section.title].key == section.key


# Generated at 2022-06-21 11:47:37.654132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        This function does something.

        Parameters
        ----------
        argument : str
            This is an argument.
        keyword : int, optional
            This is a keyword argument.
        *args, **kwargs
            These will be passed to some other thing.

        Returns
        -------
        int
            An integer.
    """
    ret = parse(text)
    assert ret.short_description == "This function does something."
    assert len(ret.meta) == 3
    assert ret.meta.params.argument.arg_name == "argument"
    assert ret.meta.params.argument.description == "This is an argument."
    assert ret.meta.params.keyword.arg_name == "keyword"
    assert ret.meta.params.keyword.description == "This is a keyword argument."
    assert ret.meta

# Generated at 2022-06-21 11:47:47.240572
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    """Unit test for constructor of class YieldsSection"""
    # Test with assigned value
    yields_section = YieldsSection("Yields", "yields")
    assert yields_section.key == "yields"
    assert yields_section.title == "Yields"
    assert yields_section.is_generator == True
    # Test with None value
    yields_section2 = YieldsSection(None, None)
    assert yields_section2.key == None
    assert yields_section2.title == None
    assert yields_section2.is_generator == True


# Generated at 2022-06-21 11:47:58.730231
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    testText1 = '.. deprecated:: 2.0\n\n    something else'
    testText2 = '.. deprecated:: 2.0\n\n    something else\n\nfoo'
    testText3 = '.. deprecated:: 2.0\n\n    something else\n\n'
    deprecationSection = DeprecationSection('deprecated', 'deprecation')

    parsed1 = list(deprecationSection.parse(testText1))
    parsed2 = list(deprecationSection.parse(testText2))
    parsed3 = list(deprecationSection.parse(testText3))
    assert parsed1[0].version == '2.0'
    assert parsed1[0].description == 'something else'
    assert parsed2[0].version == '2.0'

# Generated at 2022-06-21 11:48:06.055922
# Unit test for method parse of class Section
def test_Section_parse():

    body_text = """my_param
        description of my param"""
    section = Section(title="Parameters",key="param")
    meta_list = list(section.parse(body_text))
    assert len(meta_list)==1
    assert meta_list[0].args == ['param']
    assert meta_list[0].description == 'description of my param'



# Generated at 2022-06-21 11:48:07.182926
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Return", "returns")

# Generated at 2022-06-21 11:48:16.648463
# Unit test for function parse
def test_parse():
    if __name__ == '__main__':
        import unittest

        class TestParse(unittest.TestCase):
            def test_basic_parse(self):
                # This is the most basic docstring format.
                source = """
                Short summary.

                Longer description. Blah blah blah.

                Parameters
                ----------
                arg1 : int
                    First argument.

                Returns
                -------
                int
                    The return value.
                """
                docstring = parse(source)
                self.assertEqual(docstring.short_description, "Short summary.")
                self.assertEqual(
                    docstring.long_description,
                    "Longer description. Blah blah blah.",
                )
                self.assertEqual(len(docstring.meta), 2)


# Generated at 2022-06-21 11:48:21.197161
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_section = RaisesSection("Raises", "raises")
    assert test_section.title == "Raises"
    assert test_section.key == "raises"
    assert test_section.title_pattern == r"^(Raises)\s*?\n-----\s*$"


# Generated at 2022-06-21 11:48:26.271789
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r_section=ReturnsSection("Returns", "returns")
    r_section.is_generator=True
    r_section._parse_item("key", "value")    
    assert isinstance(r_section, Section)
    assert r_section.is_generator
    assert r_section.key == "returns"
    assert r_section.title == "Returns"
    
    r_section.is_generator=False


# Generated at 2022-06-21 11:48:30.532500
# Unit test for method parse of class Section
def test_Section_parse():
    pass

# Generated at 2022-06-21 11:48:34.801682
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = _KVSection('test', 'test')
    text = '''
    key_a
        value_a
    key_b
        value_b
        value_b2
    
    something else
    foo : int, optional
        something other than a key-value pair
    '''
    res = s.parse(text)
    print(res)


if __name__ == '__main__':
    test__KVSection_parse()

# Generated at 2022-06-21 11:48:37.363773
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == NumpydocParser().sections
    if __name__ == '__main__':
        print("Test of class NumpydocParser passed.")


# Generated at 2022-06-21 11:48:40.061245
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = """
            mat_type
                A matrix type.
            """
    assert next(_KVSection("mat_type", "mat_type").parse(text)) == DocstringMeta(["mat_type"], "A matrix type.")



# Generated at 2022-06-21 11:48:49.405166
# Unit test for function parse
def test_parse():
    input_text = '''This function adds two numbers

Args:
    a: The first number
    b: The second number

Returns:
    The sum of two numbers.

Attributes:
    x: A number
    y: A number

'''
    expected_output = '''This function adds two numbers

    Args:
        a: The first number
        b: The second number

    Returns:
        The sum of two numbers.

    Attributes:
        x: A number
        y: A number

'''
    parsed = NumpydocParser().parse(input_text)
    assert str(parsed) == expected_output

# Generated at 2022-06-21 11:49:00.180175
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    doctxt = """
    .. deprecated:: 1.0
        Use something else instead.
    """
    ds = DeprecationSection("deprecated", "deprecation")
    deps = list(ds.parse(doctxt))
    assert len(deps) == 1
    assert deps[0].version == "1.0"
    assert deps[0].description == "Use something else instead."


if __name__ == "__main__":
    import sys

    text = open(sys.argv[1]).read()

    ds = parse(text)
    print(ds)
    print()
    print(ds.short_description)
    print()
    if ds.long_description is not None:
        print(ds.long_description)
        print()

# Generated at 2022-06-21 11:49:01.694840
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    func = ReturnsSection("Returns", "returns")
    func.parse("return_name : type\n A description of this returned value")


# Generated at 2022-06-21 11:49:02.747275
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    print(YieldsSection)


# Generated at 2022-06-21 11:49:07.422796
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    obj = RaisesSection("Raises", "raises")
    assert (obj.title == "Raises")
    assert (obj.key == "raises")
    assert (obj.title_pattern == "^Raises\s*?\n-*$")

    obj = RaisesSection("Raise", "raises")
    assert (obj.title == "Raise")
    assert (obj.key == "raises")
    assert (obj.title_pattern == "^Raise\s*?\n-*$")


# Generated at 2022-06-21 11:49:11.025826
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.parse("ValueError\nThis is the error")[0].description == "This is the error"


# Generated at 2022-06-21 11:49:30.765115
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:49:34.101260
# Unit test for constructor of class Section
def test_Section():
    s = Section('arg1', 'arg2')
    assert s.title == 'arg1'
    assert s.key == 'arg2'


# Generated at 2022-06-21 11:49:35.609004
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """Unit test for constructor of class NumpydocParser"""
    #Test 1
    NumpydocParser()
    #Test 2
    NumpydocParser(DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:49:40.140676
# Unit test for constructor of class Section
def test_Section():
    section = Section('Parameters','param')
    assert section.title == 'Parameters'
    assert section.key == 'param'
    assert section.title_pattern == r'^(Parameters)\s*?\n{}\s*$'.format(len('Parameters'))


# Generated at 2022-06-21 11:49:43.281390
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    numpydocParser = DeprecationSection("deprecated", "deprecation")
    assert isinstance(numpydocParser, DeprecationSection)


# Generated at 2022-06-21 11:49:54.678447
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_string = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    ret = Docstring()
    ret = NumpydocParser().parse(kv_string)
    assert ret.short_description == None
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 2
    assert ret.meta[0].args == 'key'
    assert ret.meta[0].description == 'value'
    assert ret.meta[1].args == 'key2'
    assert ret.meta[1].description == 'values can also span...\n... multiple lines'



# Generated at 2022-06-21 11:50:00.304991
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _title = "_SphinxSection"
    _key = "key"
    _test = _SphinxSection(_title, _key)
    assert _test.title == _title, "Title of class _SphinxSection is wrong!"
    assert _test.key == _key, "Key of class _SphinxSection is wrong!"

# Generated at 2022-06-21 11:50:09.375795
# Unit test for function parse
def test_parse():
    assert parse("""Kokokokokokokoko
    Parameters
    ----------
    aaa :
    """
                 ) == Docstring(
        short_description="Kokokokokokokoko",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param", None],
                description="",
                arg_name=None,
                type_name=None,
                is_optional=False,
                default=None,
            )
        ],
    )

# Generated at 2022-06-21 11:50:09.925613
# Unit test for method parse of class Section
def test_Section_parse():
    pass

# Generated at 2022-06-21 11:50:11.935915
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("title", "key").title_pattern == "^\.\.\s*(title)\s*::"


# Generated at 2022-06-21 11:50:28.308163
# Unit test for function parse
def test_parse():
    import numpy as np
    p = parse(np.random.sample.__doc__)
    print(p)
    assert type(p) is Docstring
    assert type(p.short_description) is str
    assert type(p.long_description) is str
    assert type(p.blank_after_short_description) is bool
    assert type(p.blank_after_long_description) is bool
    assert type(p.meta) is list
    assert type(p.meta[0]) is DocstringMeta
    assert type(p.meta[0].args) is list
    assert type(p.meta[0].args[0]) is str
    assert type(p.meta[0].description) is str

# Generated at 2022-06-21 11:50:36.905540
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Parameters"
    key = "param"
    title_pattern = r"^\.\.\s*({})\s*::".format(title)
    s = _SphinxSection(title, key)
    if(s.title == title):
        print("Pass")
    else:
        print("Fail")
    if(s.key == key):
        print("Pass")
    else:
        print("Fail")
    if(s.title_pattern == title_pattern):
        print("Pass")
    else:
        print("Fail")

# Generated at 2022-06-21 11:50:45.171606
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    # Since the method is based on regular expression, we first use the regular
    # expression to separate the text from key and value, then based on the
    # method of class KVSection to parse key and value by a self-defined method
    # _parse_item.
    pairs = [
        (KV_REGEX.finditer(text).group())
        for match, next_match in _pairwise(KV_REGEX.finditer(text))
    ]
    kv_parser = _KVSection(title='Parameters', key='param')
    # The value of each pair will be cleaned with inspect.cleandoc first
    # before parsing.

# Generated at 2022-06-21 11:50:51.881251
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    docstring = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    docstring = inspect.cleandoc(docstring)
    section = _KVSection("Test Section", "")
    assert (list(section.parse(docstring))[0].description == 'value')



# Generated at 2022-06-21 11:50:54.115033
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section.parse(Section, "test").__next__() == DocstringMeta([], description='test')

# Generated at 2022-06-21 11:50:56.161109
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection('Deprecated', 'deprecated')
    assert d != ""
    assert d.key != ""
    assert d.title != ""


# Generated at 2022-06-21 11:51:00.490032
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # test case: lack of title
    with pytest.raises(Exception):
        _SphinxSection(title='')
    # test case: normal case
    sec = _SphinxSection(title='param')
    assert sec.title == 'param'
    assert sec.title_pattern == '^\.\.\\s*(param)\\s*::'

# Generated at 2022-06-21 11:51:05.000733
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    s = DeprecationSection("Deprecated", "deprecated")
    m = s.parse(
        """.. deprecated:: 2.0
        Use one of the new methods instead.
    """
    )
    m = next(m)
    assert m.version == "2.0"
    assert (
        m.description
        == "Use one of the new methods instead.\n"
    )

# Generated at 2022-06-21 11:51:12.717120
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    parser = ParamSection(title, key)
    assert parser.title == title
    assert parser.key == key
    assert parser.title_pattern == r'^(Parameters)\s*?\n------*\s*$'
    # assert parser.parse(text) == 
    #   
    #   
    # assert parser._parse_item(key, value) == 



# Generated at 2022-06-21 11:51:16.507544
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """ Unit test for constructor of class ParamSection """
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"


# Generated at 2022-06-21 11:51:29.546211
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("Parameters", "param")
    assert kv.title == "Parameters"
    assert kv.key == "param"

# Generated at 2022-06-21 11:51:32.225038
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    p = _SphinxSection("Parameters", "param")
    assert(p.title == "Parameters")
    assert(p.key == "param")


# Generated at 2022-06-21 11:51:38.210225
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection("Yields", "yields")
    assert section.is_generator is True
    assert section._parse_item("a", "abc") == DocstringReturns(
            args=['yields'],
            description='abc',
            type_name='a',
            is_generator=True,
            return_name=None
        )

# Generated at 2022-06-21 11:51:42.249260
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("Parameters", "param")
    assert s.title=="Parameters"
    assert s.key=="param"
    assert s.title_pattern==r"^Parameters\s*?\n-*$"


# Generated at 2022-06-21 11:51:45.042789
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("a","b").title_pattern == r"^\.\.\s*(a)\s*::"
    return


# Generated at 2022-06-21 11:51:46.829626
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser.__init__.__doc__



# Generated at 2022-06-21 11:51:51.887797
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    test_obj = ParamSection(title, key)

    assert test_obj.title == title
    assert test_obj.key == key
    assert test_obj.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * len(title))


# Generated at 2022-06-21 11:51:55.132632
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    assert raises.title == "Raises"
    assert raises.key == "raises"


# Generated at 2022-06-21 11:51:56.495247
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")


# Generated at 2022-06-21 11:52:07.187422
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    Returns:
        Returns:
            Returns:
                Returns:
                    Returns:

    Returns:
        Returns:
            Returns:
                Returns:
                    Returns:

    Returns:
            Returns:
                Returns:
                    Returns:


    Returns:
        Returns:
            Returns:
                Returns:
                    Returns:

    """

    #assert list(parse(text).meta) == []


# Generated at 2022-06-21 11:52:36.868046
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    Arguments
        x : int
            A integer value.

        y : float
            A float value (default is 1.0).
    """
    text = inspect.cleandoc(text)
    ret = Docstring()
    ret.meta.extend(_KVSection("Arguments", "param").parse(text))
    print(ret.meta)


# Generated at 2022-06-21 11:52:41.127366
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rst = RaisesSection("Raises", "raises")
    assert(rst.title == "Raises")
    assert(rst.key == "raises")
    assert(rst.title_pattern == "^Raises\\s*?\n----\\s*$")


# Generated at 2022-06-21 11:52:47.966148
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    class def_ReturnsSection(ReturnsSection):
        def __init__(self):
            super(ReturnsSection, self).__init__(self, "Returns", "returns")        
    
    # test object
    ret_sec = def_ReturnsSection()
    assert ret_sec.is_generator == False
    assert ret_sec.title == "Returns"
    assert ret_sec.key == "returns"
    assert ret_sec.title_pattern == r"^Returns\s*?\n=+\s*$"
    
    # test function parse()
    text1 = "return_name : type\n    A description of this returned value\nanother_type\n    Return names are optional, types are required\n"
    text2 = "\n"
    text3 = ""

# Generated at 2022-06-21 11:52:56.364280
# Unit test for method parse of class Section
def test_Section_parse():
    dict = nan = float('nan')

    text = '''
    Parameters

    ----------

    param1 : int
        This is the first parameter.
        It is of type int
        and it is not optional
        so it will be required to have a value by the user

    param2 : float, optional
        This is the second parameter.
        It is of type float and it is optional.
        The default value is 4.5
    '''

    def test1():
        print('Test 1.1')
        section = Section('parameters', 'param')
        meta = section.parse(text)

        assert(meta[0].args == ['param', 'param1'])
        assert(meta[0].arg_name == 'param1')
        assert(meta[0].type_name == 'int')

# Generated at 2022-06-21 11:53:02.434064
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # RaisesSection(title,key)
    # title = 'Raises', key = 'raises'
    raisesSection = RaisesSection('Raises','raises')
    assert raisesSection.title == 'Raises'
    assert raisesSection.key == 'raises'
    assert isinstance(raisesSection,Section) == True
    assert isinstance(raisesSection,_KVSection) == True


# Generated at 2022-06-21 11:53:06.226844
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert(section.is_generator == False)

# For dev purposes
if __name__ == "__main__":
    print("Test for class ReturnsSection")
    test_ReturnsSection()

# Generated at 2022-06-21 11:53:12.572713
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated::
        Use the new (and faster) :method:`~util.pm_util.process_pm_file` instead.
    """
    result = DeprecationSection("deprecated", "deprecation").parse(text)
    expected = DocstringDeprecated(
        args=[],
        description="Use the new (and faster) :method:`~util.pm_util.process_pm_file` instead.",
        version=None,
    )
    assert next(result) == expected



# Generated at 2022-06-21 11:53:13.996448
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection("Yields", "yields")

# Generated at 2022-06-21 11:53:17.432513
# Unit test for constructor of class Section
def test_Section():
    sec = Section("title", "key")
    assert sec.title == "title"
    assert sec.key == "key"


# Generated at 2022-06-21 11:53:22.646090
# Unit test for constructor of class Section
def test_Section():
    # Test if the variable title is assigned the right value
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    
    # Test if the variable key is assigned the right value
    section = Section("Parameters", "param")
    assert section.key == "param"


# Generated at 2022-06-21 11:54:12.445288
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator == True
    assert YieldsSection._KVSection.is_generator == True

# Generated at 2022-06-21 11:54:14.444749
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")
    assert(s.title == "Parameters")
    assert(s.key == "param")


# Generated at 2022-06-21 11:54:23.029076
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = '''
    parameters:
        a: maybe
            this is a
    otherparameters:
        b: maybe
            this is b
    a: maybe
    b: maybe
    '''

    from .powershell import PowerShellParser

    my_section_parser = NumpydocParser()
    my_section_parser.add_section(PowerShellParser.default_sections[0])
    results = my_section_parser.parse(text)
    assert len(results.meta) == 7

# Generated at 2022-06-21 11:54:31.011367
# Unit test for function parse
def test_parse():
    assert parse("""\
    Converts a value in degrees to radians.

    Parameters
    ----------
    deg : {float, array_like of floats}
        The value(s) in degrees.

    Returns
    -------
    float or array_like of floats
        The value(s) in radians.

    Notes
    -----
    A special case is :math:`0^\circ` which is taken to be :math:`0`.

    Examples
    --------
    >>> np.deg2rad(90)
    1.5707963267948966
    """) == test_parse_parseresult()
