

# Generated at 2022-06-21 11:45:33.182232
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    def f():
        raise ValueError('This is a ValueError')
    try:
        f()
    except ValueError as ve:
        print('ValueError Triggered!')
        print(ve)
    try:
        f()
    except NameError as ne:
        print('NameError Triggered! Error: ' + str(ne))

test_RaisesSection()

# Generated at 2022-06-21 11:45:34.079609
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param")

# Generated at 2022-06-21 11:45:37.223866
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert section.title == title
    assert section.title_pattern == "^(Parameters)\s*?\n---*\s*$"
    assert section.key == key

# Generated at 2022-06-21 11:45:38.671410
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    RaisesSection("Raises", "raises").parse("ValueError\n\tA description of what might raise ValueError")

# Generated at 2022-06-21 11:45:45.077905
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    obj = ReturnsSection()
    # Test that exceptions raise exception when invalid input is received
    with pytest.raises(ValueError):
        obj.parse(1)

    # Test that class attribute is_generator is False after initialization
    assert obj.is_generator == False

    # Test that class attribute key is equal to returns
    assert obj.key == 'returns'

    # Test that class attribute key is equal to Returns
    assert obj.title == 'Returns'

    # Test that class attribute parser returns a generator
    assert iter(obj.parse('Returns'))

    # Test that parser raises an exception when missing a key
    with pytest.raises(ValueError):
        obj.parse('Returns:\nvalue')

    # Test that parser returns an object of type DocstringReturns

# Generated at 2022-06-21 11:45:47.189118
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections["Arguments"] == ParamSection("Arguments", "param")

# Generated at 2022-06-21 11:45:50.325342
# Unit test for constructor of class Section
def test_Section():
    testSection = Section('title', 'key')
    assert testSection.title == 'title'
    assert testSection.key == 'key'


# Generated at 2022-06-21 11:45:53.525592
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"

# Generated at 2022-06-21 11:45:56.693981
# Unit test for constructor of class Section
def test_Section():
    section = Section("Name",":")
    assert section.title == "Name"
    assert section.key == ":"
    assert section.title_pattern == "^(Name)\s*?\n---\s*$"


# Generated at 2022-06-21 11:46:04.559066
# Unit test for method parse of class Section
def test_Section_parse():
    docstring_section = "Parameters\n---------"
    docstring_section += "\narg1: int\n    A description of arg1\n"
    docstring_section += "arg2: float\n    A description of arg2"
    assert Section.parse(inspect.cleandoc(docstring_section)) == [DocstringMeta(["param", "arg1"], description=None),
                                                                  DocstringMeta(["param", "arg2"], description=None)]


# Generated at 2022-06-21 11:46:37.688312
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Provide a valid argument string
    dep_sec = DeprecationSection("deprecated", "deprecation")
    # test for title_pattern
    assert dep_sec.title_pattern == r"^\.\.\s*(deprecated)\s*::"
    # test for key
    assert dep_sec.key == "deprecation"
    # test for title
    assert dep_sec.title == "deprecated"

# Generated at 2022-06-21 11:46:43.093437
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    _KVSection_example = _KVSection("xxx", "xxx")

    expected = DocstringMeta(["xxx"], description="xxx")
    assert list(_KVSection_example.parse("xxx")) == [expected]

    expected = DocstringMeta(["xxx"], description="yyy\nxxx")
    assert list(_KVSection_example.parse("xxx\n\txxx\n\tyyy\n")) == [expected]



# Generated at 2022-06-21 11:46:52.531602
# Unit test for method parse of class Section
def test_Section_parse():
    # test basic Section object
    result = list(Section('test', 'test').parse('here is the doc. \n'))
    assert len(result) == 1
    assert result[0].args == ['test']
    assert result[0].description == 'here is the doc.'

    result = list(Section('test', 'test').parse('here is the doc. \n' * 2))
    assert len(result) == 1
    assert result[0].args == ['test']
    assert result[0].description == 'here is the doc. \n here is the doc.'


# Generated at 2022-06-21 11:46:54.094690
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test = RaisesSection("Raises", "raises")
    if test == None:
        raise AssertionError("The constructor of the class RaisesSection is not working properly")


# Generated at 2022-06-21 11:46:58.945896
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("a", "A")
    text = inspect.cleandoc(
        """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    )
    assert len(list(section.parse(text))) == 2

# Generated at 2022-06-21 11:47:01.460545
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    p = ReturnsSection("Returns")
    print("Created ReturnsSection")
    print("------------------")
    print("title: ", p.title)
    print("key: ", p.key)
    print("title_pattern: ", p.title_pattern)
    print("------------------")


# Generated at 2022-06-21 11:47:11.818108
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
   pars = NumpydocParser()
   docstr = """Returns the square of x
       
        :param x: x is a number
        :type x: int
        :rtype: int
        :return: returns the square of x

        Examples
        --------
        >>> a = 5
        >>> pow(a, 2)
        25
        >>> pow(a, 3)
        125
        """
   ret = pars.parse(docstr)
   print(ret)


# Generated at 2022-06-21 11:47:13.650334
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection('deprecation', 'deprecated')
    assert dep
    

# Generated at 2022-06-21 11:47:26.787515
# Unit test for method add_section of class NumpydocParser

# Generated at 2022-06-21 11:47:37.290232
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters","param")
    print(p.title_pattern)
    print(p._parse_item("arg_name", "arg_description"))
    print(inspect.cleandoc("arg_2 : type, optional"))
    print(p._parse_item("arg_2 : type, optional", "descriptions can also span...\n... multiple lines"))
    print(p._parse_item("arg_3 : type", "descriptions can also span...\n... Default is ...\n... multiple lines"))
    print(p.parse("arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines\narg_3 : type\n    descriptions can also span...\n    ... Default is ...\n    ... multiple lines"))

# Generated at 2022-06-21 11:47:47.870492
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    doc = NumpydocParser()


# Generated at 2022-06-21 11:47:59.075187
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sections = DEFAULT_SECTIONS
    parser = NumpydocParser(sections)
    r = ReturnsSection("Returns", "returns")
    v = r.parse("return_name : type\n"
               "A description of this returned value\n"
               "another_type\n"
               "Return names are not optional, types are required")
    assert v.__next__().__dict__ == {'args': ['returns'], 'description': 'Return names are not optional, types are required', 'type_name': 'another_type',
                                     'is_generator': False, 'return_name': None}

# Generated at 2022-06-21 11:48:01.234193
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	assert YieldsSection("yields", "yield")

# Generated at 2022-06-21 11:48:05.190949
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raisesSection = RaisesSection("Raises", "raises")
    assert raisesSection.title == "Raises"
    assert raisesSection.key == "raises"


# Generated at 2022-06-21 11:48:06.426654
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rais = RaisesSection("Raises", "raises")
    assert rais.title == "Raises"
    assert rais.key == "raises"

# Generated at 2022-06-21 11:48:10.221038
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    obj = DocstringDeprecated(args=[], description="Test Deprecation Section", version="0.0")
    assert obj.args == []
    assert obj.description == "Test Deprecation Section"
    assert obj.version =="0.0"

# Generated at 2022-06-21 11:48:12.946421
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    print("Testing the constructor of class YieldsSection...")
    ys = YieldsSection("yields","yields")
    if ys:
        print("Testing completed successfully!")


# Generated at 2022-06-21 11:48:17.348241
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returns_section = ReturnsSection("Returns", "returns")
    assert returns_section.is_generator == False
    assert returns_section.key == "returns"
    assert returns_section.title == "Returns"

# Generated at 2022-06-21 11:48:20.393934
# Unit test for constructor of class Section
def test_Section():
    # Declare a section with title and key
    s = Section("Test", "test")
    assert s.title == "Test"
    assert s.key == "test"


# Generated at 2022-06-21 11:48:28.744000
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Section_0", "section_0"))


# Generated at 2022-06-21 11:49:02.891704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    simple_doc = "test"
    assert parser.parse(simple_doc).to_dict() == {'examples': [], 'see_also': [], 'notes': [], 'warnings': [], 'references': [], 'deprecation': [], 'meta': [], 'long_description': None, 'blank_after_long_description': False, 'blank_after_short_description': False, 'short_description': 'test'}
    short_long_doc = """test
    test
    test
    """

# Generated at 2022-06-21 11:49:13.085494
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    lines = [
        "key",
        "    value",
        "key2 : type",
        "    values can also span...",
        "    ... multiple lines",
    ]
    clean_text = inspect.cleandoc("\n".join(lines))

    parser = _KVSection("title", "key")

    ret = parser.parse(clean_text)

    values = [m.description for m in ret]
    assert values == ["value", "values can also span...\n... multiple lines"]


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 11:49:16.641142
# Unit test for constructor of class Section
def test_Section():
    assert Section('Section', 'section').title is 'Section'
    assert Section('Section', 'section').key is 'section'
    assert Section('Section', 'section').title_pattern == '^Section\s*?\n------*\s*$'


# Generated at 2022-06-21 11:49:18.236376
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS

# Generated at 2022-06-21 11:49:29.331112
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    import pytest
    from numpydoc.numpydoc import ReturnsSection
    from numpydoc.numpydoc import DocstringReturns
    lines = \
        [
            'Returns',
            '    return_name: type',
            '        A description of this returned value',
            '    another_type',
            '        Return names are optional, types are required'
        ]
    doc = DocstringReturns(
            args=[lines[0]],
            description='        A description of this returned value',
            type_name='type',
            is_generator=False,
            return_name='return_name')
    factory = ReturnsSection(lines[0], lines[0])
    assert factory.parse(lines[1:]) == [doc]

# Generated at 2022-06-21 11:49:41.623623
# Unit test for function parse
def test_parse():
    def fn():
        """
        this is the numpy docstring

        :param x: foo
        :param y: bar
        :return: foobar
        """

    doc = NumpydocParser().parse(inspect.getsource(fn))
    assert doc.short_description == "this is the numpy docstring"
    assert len(doc.meta) == 1
    assert len(doc.meta[0].args) == 2
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "x"
    assert doc.meta[0].description == "foo"
    assert len(doc.meta[1].args) == 2
    assert doc.meta[1].args[0] == "param"

# Generated at 2022-06-21 11:49:47.241353
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = "is_generator"
    return_name = "return_name"
    assert ReturnsSection(args,description,type_name, is_generator,return_name)

# Generated at 2022-06-21 11:49:54.637643
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()
    assert(numpydoc_parser.sections['Raises'] is not None)
    assert(numpydoc_parser.sections['Raise'] is not None)
    assert(numpydoc_parser.sections['Warns'] is not None)
    assert(numpydoc_parser.sections['Warn'] is not None)
    assert(numpydoc_parser.sections['Notes'] is not None)
    assert(numpydoc_parser.sections['Note'] is not None)

# Generated at 2022-06-21 11:49:55.852205
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    class ReturnsSection:
        pass

# Generated at 2022-06-21 11:49:58.924979
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("title", "key")
    assert kv.title == "title"
    assert kv.key == "key"



# Generated at 2022-06-21 11:50:25.832035
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns", "returns")
    text = inspect.cleandoc('''
        return_name : type - optional
            A description of this returned value
        another_type
            Return names are optional, types are required
        a_type
        ''')

    meta_list = list(rs.parse(text))
    assert len(meta_list) == 3
    assert meta_list[0].args == ["returns"]
    assert meta_list[0].return_name == "return_name"
    assert meta_list[0].type_name == "type"
    assert meta_list[0].is_optional
    assert meta_list[1].args == ["returns"]
    assert meta_list[1].return_name is None
    assert meta_list[1].type_name == "another_type"

# Generated at 2022-06-21 11:50:30.341391
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    x = DeprecationSection("deprecated", "deprecation")
    x.parse("1.1.1\nblah blah blah") == [DocstringDeprecated(['deprecation'], 'blah blah blah', '1.1.1')]



# Generated at 2022-06-21 11:50:31.600467
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection._parse_item()

# Generated at 2022-06-21 11:50:34.248287
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection(title="Raises", key="raises")
    assert isinstance(section, Section)

# Generated at 2022-06-21 11:50:42.757607
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Test_1: check that two instances of the YieldsSection class are the same
    check1 = YieldsSection
    check2 = YieldsSection
    assert check1 is check2
    # Test_2: check that the is_generator is set to True by default
    check1 = YieldsSection
    check2 = ReturnsSection
    assert check1.is_generator and not check2.is_generator
    # Test_3: check that the attribue _is_generator is set to True by default
    check1 = YieldsSection
    check2 = ReturnsSection
    assert check1.is_generator and not check2.is_generator

# Generated at 2022-06-21 11:50:48.056305
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("hello", "key"))
    assert("hello" in parser.sections and parser.sections["hello"].title == "hello" and parser.sections["hello"].key == "key")

# Generated at 2022-06-21 11:50:51.237357
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    testObj = _SphinxSection(title="Parameters", key="param")
    assert testObj.title_pattern == "^\.\.\s*(Parameters)\s*::"

# Generated at 2022-06-21 11:50:59.357919
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    input_text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    expected_result = """<ul>
        <li>key = value</li>
        <li>key2 = values can also span...
            ... multiple lines</li></ul>"""
    result = _KVSection("test", "test").parse(input_text)
    result_str = "<ul>"
    for item in result:
        result_str += "<li>{0} = {1}</li>".format(item.args[1], item.description)
    result_str += "</ul>"
    assert result_str == expected_result

# Generated at 2022-06-21 11:51:03.600002
# Unit test for constructor of class Section
def test_Section():
    section = Section('title', 'key')
    assert section.title == 'title'
    assert section.key == 'key'
    assert section.title_pattern == '^(title)\\s*?\\ntitle\\s*$'
    assert section.parse('') == [DocstringMeta(['key'])]


# Generated at 2022-06-21 11:51:16.243542
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # test description
    description = 'This is testing description'
    # test tag
    tag = 'param'
    # test key
    key = 'arg'
    # test value
    value = 'type'
    # test optional
    optional = True
    # test default
    default = 'something'

    # create an instance of ParamSection class
    expr = ParamSection(tag, key)

    # create an instance of DocStringParam class
    param = DocstringParam(args=[tag, key], description=description, arg_name=key, type_name=value,
                           is_optional=optional, default=default)
    result = expr._parse_item(key, description)

    # assert that the two created instance are equal
    assert param == result


# Generated at 2022-06-21 11:51:44.582044
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
  assert _SphinxSection("title", "key").title_pattern == r"^\.\.\s*(title)\s*::"


# Generated at 2022-06-21 11:51:52.400245
# Unit test for method parse of class Section
def test_Section_parse():
    text = r"""Parameters
    ----------
    value : {str, int}
        Value to be added to object.
        
    Returns
    -------
    int
        Sum of original object and value
"""
    assert len(ParamSection("Parameters", "param").parse(text)) == 1
    assert len(ReturnsSection("Returns", "returns").parse(text)) == 1
    assert len(YieldsSection("Yields", "yields").parse(text)) == 0
    assert len(RaisesSection("Raises", "raises").parse(text)) == 0



# Generated at 2022-06-21 11:52:04.487937
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class Docstring_test(Docstring):
        def __init__(self):
            self.short_description = None
            self.long_description = None
            self.blank_after_short_description = False
            self.blank_after_long_description = False
            self.meta = []
    class DocstringParam_test(DocstringParam):
        def __init__(self, args, description=None, arg_name=None,
                     type_name=None, is_optional=False, default=None):
            self.args = args
            self.description = description
            self.arg_name = arg_name
            self.type_name = type_name
            self.is_optional = is_optional
            self.default = default


# Generated at 2022-06-21 11:52:09.750714
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:52:18.008735
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection(): 
    # Test init
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    # Test title and key attribute
    assert deprecation_section.title=="deprecated"
    assert deprecation_section.key=="deprecation"
    # Test title_pattern attribute
    assert deprecation_section.title_pattern == r"^\.\.\s*(deprecated)\s*::"


# Generated at 2022-06-21 11:52:21.556606
# Unit test for method parse of class Section
def test_Section_parse():
    assert list(Section(title="Parameters:", key='param').parse('a\nb\nc')) == [DocstringMeta(['param'],description='a\nb\nc')]


# Generated at 2022-06-21 11:52:32.138144
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    desc = '''
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    '''

    doc = NumpydocParser()
    section = _KVSection("Parameters", "param")
    res = doc.parse(desc).meta
    print(res)
    expected = '''[DocstringMeta(args=['param', 'key'], description='value'), DocstringMeta(args=['param', 'key2'], description='values can also span...\\n... multiple lines'), DocstringMeta(args=['param', 'type'], description='None')]'''
    for i in range(len(res)):
        assert str(res[i]) == expected


# Generated at 2022-06-21 11:52:36.960570
# Unit test for constructor of class _KVSection
def test__KVSection():
    from pyta.check_functions import _KVSection
    my_section =  _KVSection(title = 'Parameters', key = 'param')
    assert my_section.title == 'Parameters'
    assert my_section.key == 'param'


# Generated at 2022-06-21 11:52:47.126982
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    # Test for input is None
    try:
        parser.add_section(None)
    except Exception:
        raise ValueError("Input can not be null")
    # Test different input
    parser.add_section(
        Section(
            title="Raises",
            key="Raise",
        )
    )
    parser.add_section(
        Section(
            title="Returns",
            key="Return",
        )
    )
    parser.add_section(
        Section(
            title="Optional",
            key="Optional",
        )
    )
    parser.add_section(
        Section(
            title="Params",
            key="Params",
        )
    )

# Generated at 2022-06-21 11:52:55.780586
# Unit test for function parse
def test_parse():
    input_string = r"""
    test_parse.

    Parameters
    ----------
    arg_1 : type
        A description of arg_1.
    arg_2 : type, optional
        Default is 1.

    Returns
    -------
    return_1
        A description of return_1

    Raises
    ------
    ValueError
        If something is wrong.
    TypeError
        If something else is wrong."""


# Generated at 2022-06-21 11:53:16.255415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parameters
    ----------
    a : int
        The first integer

    b : float, optional
        The first float, defaults to 0.0
    """
    res = NumpydocParser().parse(text)
    assert res.meta[0].type == 'param'
    assert res.meta[0].description.split('\n')[0] == 'The first integer'

    assert res.meta[1].type == 'param'
    assert res.meta[1].description.split('\n')[0] == 'The first float, defaults to 0.0'

# Generated at 2022-06-21 11:53:20.081578
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"


# Generated at 2022-06-21 11:53:23.182704
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("Deprecated", "deprecated")
    assert dep.title == "Deprecated"
    assert dep.key == "deprecated"


# Generated at 2022-06-21 11:53:26.744323
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    actual = ReturnsSection("Returns", "returns")
    expected = ReturnsSection("Returns","returns")
    assert actual.title == expected.title
    assert actual.key == expected.key
    assert actual.is_generator == expected.is_generator
    assert actual.object == expected.object

# Generated at 2022-06-21 11:53:32.853771
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    docstring = '''
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines'''
    docstring = inspect.cleandoc(docstring)
    docstring = _KVSection(None, None).parse(docstring)
    docstring = list(docstring)
    assert docstring[0].arg_name == 'arg_name'
    assert docstring[0].type_name is None
    assert docstring[0].is_optional is False
    assert docstring[0].default is None


# Generated at 2022-06-21 11:53:43.460340
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	#with open('tests/test_docstrings.txt', 'r') as in_file:
	doc_path = os.getcwd().split('/')
	doc_path = doc_path[:doc_path.index('tests')]
	doc_path = '/'.join(doc_path) + '/'
	with open(doc_path + 'tests/test_docstrings.txt', 'r') as in_file:
		docstring = ""
		for i in range(12):
			docstring +=  in_file.readline()
			print(docstring)
		docstring = inspect.cleandoc(docstring) + '\n'
		print(docstring)

# Generated at 2022-06-21 11:53:49.782568
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    assert "See also" in np.sections
    assert "See alsoa" not in np.sections
    
    np.add_section(Section("See alsoa", "see_also"))
    assert "See alsoa" in np.sections
    assert "See alsoa" not in DEFAULT_SECTIONS


# Generated at 2022-06-21 11:53:58.281431
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    docstr = NumpydocParser()
    assert len(docstr.sections) == len(DEFAULT_SECTIONS)
    assert docstr.sections['Returns'] == ReturnsSection("Returns", "returns")

    docstr.add_section(Section("Hello", "hello"))
    assert len(docstr.sections) == len(DEFAULT_SECTIONS)+1
    assert docstr.sections['Hello'] == Section("Hello", "hello")

    #replace Hello section
    assert docstr.sections['Hello'] != Section("Returns", "returns")
    docstr.add_section(Section("Hello", "returns"))
    assert docstr.sections['Hello'] == Section("Hello", "returns")


# Generated at 2022-06-21 11:54:03.565585
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert(section._parse_item("ValueError","A description of what might raise ValueError") == DocstringRaises(args=["raises", "ValueError"], description="A description of what might raise ValueError", type_name='ValueError'))


# Generated at 2022-06-21 11:54:09.324831
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

    sections = parser.sections
    assert type(sections) == dict
    assert len(sections) == 28

    for section in sections.values():
        assert type(section) == Section
        assert isinstance(section.title_pattern, str)
        assert isinstance(section.parse(''), T.Iterable)
        assert isinstance(section.parse('\n'), T.Iterable)
        assert isinstance(section.parse('\n\n'), T.Iterable)
        assert isinstance(section.parse('\n\n\n'), T.Iterable)
        assert isinstance(section.parse('\n\n\n\n'), T.Iterable)
        assert isinstance(section.parse('\n\n\n\n\n'), T.Iterable)

# Generated at 2022-06-21 11:54:24.492425
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert bool(_SphinxSection("a", "b")) == True

# Generated at 2022-06-21 11:54:29.349928
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    my_text = '.. note::\n  This is a note\n'
    expected = 'note'
    actual = _SphinxSection("note", "note").title
    if not (expected == actual):
        raise Exception("test__SphinxSection failed: {}, {}".format(expected, actual))
