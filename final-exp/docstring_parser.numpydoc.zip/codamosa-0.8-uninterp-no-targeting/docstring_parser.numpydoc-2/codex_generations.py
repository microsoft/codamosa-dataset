

# Generated at 2022-06-21 11:45:14.153518
# Unit test for function parse
def test_parse():
    def func():
        """This is a short description.

        This is a long description.

        Parameters
        ----------
        this : that
            Isn't this cool?

        Returns
        -------
        None
            No one ever reads this.

        Raises
        ------
        SomeError
            Because you didn't listen.
        """
        pass


# Generated at 2022-06-21 11:45:18.462332
# Unit test for constructor of class Section
def test_Section():
    section_title = Section("Parameters", "param")
    assert(str(section_title.key) == 'param')
    assert(str(section_title.title) == 'Parameters')
    assert(str(section_title.title_pattern) == '^(Parameters)\\s*?\\n-*\\s*$')



# Generated at 2022-06-21 11:45:21.133028
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises").parse("KeyError\nKey error description.\n")


# Generated at 2022-06-21 11:45:32.061183
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    input_text = """
    key1
        value1
    key2
        value2
    """
    input_text = inspect.cleandoc(input_text)
    input_section = ParamSection("section_name", "section_key")
    actual = [x for x in input_section.parse(input_text)]

# Generated at 2022-06-21 11:45:35.718229
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    docstr = ".. deprecated:: 0.1\n    This is deprecated"
    d = NumpydocParser()
    # DeprecationSection is added as the last section
    d.add_section(DeprecationSection("deprecated", "deprecation"))
    ret = d.parse(docstr)
    assert ret.meta[-1].version == "0.1"
    assert ret.meta[-1].description == "This is deprecated"


# Generated at 2022-06-21 11:45:38.164646
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Title", "key")
    text = "value"
    output = section.parse(text)
    assert(list(output) == [DocstringMeta(["key"], "value")])

# Generated at 2022-06-21 11:45:44.759009
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Test method add_section of class NumpydocParser."""
    # Create parser
    parser = NumpydocParser()
    # Add section
    parser.add_section(ParamSection("New Parameters", "new_param"))
    # Test if new section is actually added
    assert "New Parameters" in parser.sections
    assert "new_param" == parser.sections["New Parameters"].key

    # Test if method _setup is working
    parser._setup()
    assert parser.titles_re.search("\nNew Parameters\n-------------\n")

    # Test if the added section is parsed correctly
    file_path = "docs/example_docstrings/numpy_style_docstring.txt"
    with open(file_path, "r") as f:
        text = f.read()

# Generated at 2022-06-21 11:45:57.108850
# Unit test for constructor of class ParamSection
def test_ParamSection():
    KEY = "key"
    initial_text = "title\n----\nkey\n\tvalue\nkey2: type, optional\n\tdescriptions can span\n\tmultiple lines"
    expected_result = [
        DocstringParam(args=[KEY, 'key'], description='value', arg_name='key', type_name='', is_optional=False, default=None),
        DocstringParam(args=[KEY, 'key2'], description='descriptions can span\nmultiple lines', arg_name='key2', type_name='type', is_optional=True, default=None)
    ]
    section = ParamSection("title", KEY)
    actual_result = list(section.parse(initial_text))

# Generated at 2022-06-21 11:46:00.841345
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    assert raises.title == "Raises", "Title is incorrect"
    assert raises.key == "raises", "Key is incorrect"


# Generated at 2022-06-21 11:46:13.324639
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:46:28.260146
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    doc = section.parse(" 1.1.1 \n\n some desc ")
    for i in doc:
        print(i)



# Generated at 2022-06-21 11:46:34.727985
# Unit test for method parse of class Section
def test_Section_parse():
    """Test for parsing of a docstring section."""
    pattern = r"a section$"
    title = 'a section'
    key = 'a'
    text = 'a section\n---------\ncan be parsed'
    section = Section(title, key)
    result = section.parse(text)
    assert re.match(pattern, result.__repr__())

# Generated at 2022-06-21 11:46:39.080768
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	text = "Deprecated since version 0.14.0: This function will be removed in version 0.16.0."
	dep = DeprecationSection("deprecated", "deprecation")
	match = dep.title_pattern
	print(re.search(match, text))
	print(dep.parse(text))

# Generated at 2022-06-21 11:46:50.122185
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    Hello, world!
    Parameters
    ----------
    name : string
        name of the person to greet.
    Returns
    -------
    greeting : string
        a greeting.
    """
    parser = NumpydocParser()
    assert parser.titles_re is None
    assert parser.parse(text).meta[0].args == ['param', 'name']
    assert parser.sections['Parameters'].parse(text).next().args == ['param', 'name']

    new_section = Section('Name', 'name')
    parser.add_section(new_section)
    assert parser.titles_re.findall(text)[0] == 'Parameters'
    assert parser.parse(text).meta[0].args == ['param', 'name']

# Generated at 2022-06-21 11:47:03.104740
# Unit test for method parse of class Section
def test_Section_parse():
    """Unit test for method parse of class Section"""
    parser = NumpydocParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("    \n") == Docstring()
    assert parser.parse("test").meta == []
    assert parser.parse("test\n").meta == []
    assert parser.parse("test\n  ").meta == []
    assert parser.parse("test\n    ").long_description is None
    assert parser.parse("test\n\n").long_description is None
    assert parser.parse("test\n\n  ").long_description == ""
    assert parser.parse("test\nmore\n").long_description is None
    assert parser.parse("test\nmore\n  ").long_description == "more"

# Generated at 2022-06-21 11:47:04.084521
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    obj = NumpydocParser()

# Generated at 2022-06-21 11:47:13.202569
# Unit test for method parse of class _KVSection
def test__KVSection_parse():

    # Tests for parameters
    # It will return a DocstringMeta for each parameter
    param_content = '''param_1 : int
        It should return a DocstringMeta for this parameter
        param_2 (optional)
        It should return a DocstringMeta for this parameter
        param_3 : str, optional
        It should return a DocstringMeta for this parameter
        param_4, optional: str
        It should return a DocstringMeta for this parameter
        param_5, optional (str)
        It should return a DocstringMeta for this parameter
        param_6 (optional): str
        It should return a DocstringMeta for this parameter
        param_7: str, optional
            It should return a DocstringMeta for this parameter'''

    param_section = ParamSection("Parameters", "param")
    sections = param_section.parse(param_content)

# Generated at 2022-06-21 11:47:26.465602
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = DeprecationSection("Deprecated", "deprecated")
    text = """
    .. deprecated:: 0.1
        A description of what might raise ValueError
    """

    assert parser.parse(text) == [DocstringDeprecated(
        args=["deprecated"], description="A description of what might raise ValueError", version="0.1"
        )]

    text = """
    .. deprecated:: 0.1
        A description of what might raise ValueError
    .. deprecated:: 0.1
        A description of what might raise ValueError
    """

    assert parser.parse(text) == [DocstringDeprecated(
        args=["deprecated"], description="A description of what might raise ValueError", version="0.1"
        )]


# Generated at 2022-06-21 11:47:32.463612
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #Function that evaluates if the parsed docstring is the same as the original
    def test_numpy_docstring(doc, original_doc):
        assert doc.short_description == original_doc.short_description
        assert doc.long_description == original_doc.long_description
        assert doc.blank_after_short_description == original_doc.blank_after_short_description
        assert doc.blank_after_long_description == original_doc.blank_after_long_description
        assert doc.meta == original_doc.meta

    parser = NumpydocParser()

    #Test a docstring with parameters, returns, raises and examples

# Generated at 2022-06-21 11:47:36.445727
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    valid_value = DeprecationSection("Deprecated", "deprecation")
    assert valid_value.title == "Deprecated"
    assert valid_value.key == "deprecation"
    assert valid_value.title_pattern == '^\.\.\\s*(Deprecated)\\s*::'


# Generated at 2022-06-21 11:47:45.804119
# Unit test for constructor of class Section
def test_Section():
    section=Section("title","key")
    assert(section.title=="title")
    assert(section.key=="key")
    assert(section.title_pattern == "^(title)\s*?\n{}\s*$".format("-" * len("title")))
    assert(list(section.parse("text"))==[DocstringMeta(args=['key'], description=_clean_str("text"))])



# Generated at 2022-06-21 11:47:49.430993
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert str(_SphinxSection('Examples','examples').title_pattern) == '^\\.\\.\\s*(Examples)\\s*::'
    

# Generated at 2022-06-21 11:47:53.737298
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    factory = DeprecationSection('deprecated', 'deprecation')
    assert factory.title == 'deprecated'
    assert factory.key == 'deprecation'
    print('Unit test for constructor of class DeprecationSection passed.')

# Generated at 2022-06-21 11:47:56.202205
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    import doctest
    doctest.run_docstring_examples(DeprecationSection.parse, globals())


# Generated at 2022-06-21 11:48:04.383477
# Unit test for method parse of class Section
def test_Section_parse():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    text = """
    random value

    other_param : type
        long description
        """
    expected = [DocstringMeta(args=[key], description="random value"),
                DocstringParam(args=[key, "other_param"], description="long description", arg_name="other_param", type_name="type", is_optional=False, default=None)]
    assert(section.parse(text) == expected)


# Generated at 2022-06-21 11:48:15.066798
# Unit test for function parse
def test_parse():
    assert parse('''
Params
-------
text
    short description
    long description
    some more
    ...
    description

Param 2
    description
    ...
    ...
''') == Docstring('short description\nlong description\nsome more\n'\
        '...\ndescription', '', \
        [DocstringParam(['param', 'text'], 'short description\nlong description\nsome more\n...\ndescription'),\
            DocstringParam(['param', 'Param 2'], 'description\n...\n...')])

# Generated at 2022-06-21 11:48:17.348935
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section=YieldsSection("Yields", "yields")
    assert section.is_generator==True

# Generated at 2022-06-21 11:48:22.208720
# Unit test for method parse of class Section
def test_Section_parse():
    text = '''
        .. deprecated:: 0.4.0
            Deprecated in favor of ``new_name``.
        '''
    Sec = DeprecationSection("deprecated", "deprecation")
    p = DeprecationSection('deprecated', 'deprecation')
    dep_test = p.parse(text)
    
    assert Sec.parse(text)[0].description == dep_test[0].description
    assert Sec.parse(text)[0].version == dep_test[0].version


# Generated at 2022-06-21 11:48:29.916643
# Unit test for function parse
def test_parse():
    s = '''takes an argument and returns the sum
    Parameters
    ----------
        arg : int
            An argument

    Returns
    -------
        The sum of ``arg`` and 1.'''
    assert parse(s) == Docstring(
        short_description='takes an argument and returns the sum',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringParam(args=['param', 'arg'], description='An argument', arg_name='arg', type_name='int'), 
            DocstringReturns(args=['returns'], description='The sum of ``arg`` and 1.', type_name=None, is_generator=False, return_name=None)
        ]
    )

# Generated at 2022-06-21 11:48:33.323299
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = NumpydocParser()
    item = parser.sections.get('Yields')
    assert item is not None
    assert item.title == 'Yields'
    assert item.key == 'yields'

    assert type(item) == YieldsSection
    assert item.is_generator == True

# Generated at 2022-06-21 11:48:50.880246
# Unit test for method parse of class Section
def test_Section_parse():
    class TestSection(Section):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta(
                args=[key], description=inspect.cleandoc(value)
            )
    test_section = TestSection("Parameters", "param")
    text = """\
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    result = inspect.cleandoc(text)
    test = list(test_section.parse(result))
    assert test[0].args == ['arg_name']
    assert test[0].description == 'arg_description'
    assert test[1].args == ['arg_2']

# Generated at 2022-06-21 11:48:58.951051
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    with open("./test/testfiles/test_DeprecationSection_parse.rst") as f:
        text = f.read()
    factory = DeprecationSection("Deprecation Warning", "deprecated")
    doc = factory.parse(text)
    doc = list(doc)
    assert len(doc) == 2
    assert doc[0].version == "3.3"
    assert doc[0].description == "This function is deprecated"
    assert doc[1].version == "2.6"
    assert doc[1].description == "This method is deprecated"


# Generated at 2022-06-21 11:49:00.168879
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldSection = YieldsSection('Yields', 'yields')
    assert yieldSection.is_generator == True


# Generated at 2022-06-21 11:49:10.784607
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = _KVSection("Parameters", "param")
    text = "arg_name\n    arg_description\nother_param : type, optional\n    descriptions can also span...\n    ... multiple lines"
    params = list(s.parse(text))
    assert len(params) == 2
    assert params[0].arg_name == "arg_name"
    assert params[0].description == "arg_description"
    assert params[0].type_name is None
    assert params[0].is_optional is None
    assert params[0].default is None
    assert params[1].arg_name == "other_param"
    assert params[1].description == "descriptions can also span..."
    assert params[1].type_name == "type"
    assert params[1].is_optional is True
    assert params

# Generated at 2022-06-21 11:49:21.963890
# Unit test for method parse of class Section
def test_Section_parse():

    class _TestSection(Section):
        pass

    text = '''
        Parameters
        ----------
        file : file_like
            The file to read.  A filename, a file object opened for reading
            or a StringIO object.
   
        Returns
        -------
        out : int
            The number of lines.
    '''

    test_sec = _TestSection("Parameters", "param")
    parsed_result = test_sec.parse(text)

    assert parsed_result is not None
    assert len(parsed_result) == 2

    # Test first element of parsed_result
    assert parsed_result[0].args == ["param", "file"]
    assert parsed_result[0].description == """The file to read.  A filename, a file object opened for reading
            or a StringIO object."""

    # Test second

# Generated at 2022-06-21 11:49:24.912544
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    testObj = ReturnsSection("Returns", "returns")
    assert testObj.title == "Returns"
    assert testObj.key == "returns"


# Generated at 2022-06-21 11:49:30.345117
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection.is_generator == False
    assert ReturnsSection.is_generator == 0
    assert ReturnsSection.__doc__ == 'Parser for numpydoc raises sections.\n\n    E.g. any section that looks like this:\n        return_name : type\n            A description of this returned value\n        another_type\n            Return names are optional, types are required\n    '


# Generated at 2022-06-21 11:49:42.941577
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("\n") == Docstring()

    assert parser.parse("one line").long_description is None
    assert parser.parse("one line").short_description == "one line"

    assert parser.parse("one.\n\nTwo.").long_description == "Two."
    assert parser.parse(
        "one\n.\n\nTwo."
    ).long_description == "Two."  # dot is at end of short description
    assert parser.parse("one\n\nTwo.").long_description == "Two."
    assert parser.parse("one\n\nTwo").long_description == "Two"

    assert parser.parse("one.\n\nTwo.").short_description == "one."

# Generated at 2022-06-21 11:49:54.114951
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc('''
        Parameters:
            arg1 (str): description


        Returns:
            int
    ''')
    docstring = parse(text)
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'arg1'
    assert docstring.meta[0].type_name == 'str'
    assert docstring.meta[0].description == 'description'
    assert docstring.meta[1].args[0] == 'returns'
    assert docstring.meta[1].type_name == 'int'
    assert docstring.meta[1].is_generator == False



# Generated at 2022-06-21 11:49:55.626740
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

# Generated at 2022-06-21 11:50:13.249582
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    with open('./examples/deprecation_section.txt', 'r') as f:
        lines = f.readlines()
    text = '\n'.join(lines)
    section = DeprecationSection('Deprecated', 'deprecation')
    parsed_text = next(section.parse(text))
    assert parsed_text.description == 'See the partial function ' \
                                      'in the functools module.'



# Generated at 2022-06-21 11:50:25.712659
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():

        # Make an empty class
        class A:
            def __init__(self,s):
                self.s = s
            def __repr__(self):
                return repr(self.__dict__)

        #test zero
        test_kws = A(".. deprecated:: 1.2.3")
        assert test_kws.s == '.. deprecated:: 1.2.3'
        #test one
        test_kws = A(".. deprecated:: 1.2.3\nThis is deprecation.\n")
        assert test_kws.s == '.. deprecated:: 1.2.3\nThis is deprecation.\n'
        #test two
        test_kws = A(".. deprecated:: 1.2.3\nThis is deprecation.\n\n")

# Generated at 2022-06-21 11:50:38.077500
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section_returns = ReturnsSection("Returns", "returns")
    assert "Returns" not in numpydoc_parser.sections
    numpydoc_parser.add_section(section_returns)
    assert "Returns" in numpydoc_parser.sections
    numpydoc_parser.add_section(section_returns)

# Generated at 2022-06-21 11:50:39.485805
# Unit test for constructor of class Section
def test_Section():
    assert Section("param", "parameter").title == 'param'
    assert Section("param", "parameter").key == 'parameter'


# Generated at 2022-06-21 11:50:51.935363
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    # test 1
    text = '.. deprecated:: 0.2\n'\
           '   Use :class:`URLField` instead.'
    docstring = parser.parse(text)
    assert docstring.long_description is None
    assert not docstring.blank_after_long_description
    assert docstring.blank_after_short_description
    assert docstring.short_description is None
    assert len(docstring.meta) == 1
    deprecation_meta = docstring.meta[0]
    assert "deprecation" in deprecation_meta.args
    assert deprecation_meta.description is not None
    assert "0.2" in deprecation_meta.description
    assert "Use :class:`URLField` instead" in deprecation_meta.description

   

# Generated at 2022-06-21 11:50:55.656238
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    exp_title_pattern = "^\.\.\s*(Parameter)\s*:"
    act_title_pattern = _SphinxSection("Parameter", "param").title_pattern
    assert exp_title_pattern == act_title_pattern

# Generated at 2022-06-21 11:50:58.817963
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection('Returns', 'returns').__class__ == ReturnsSection
    assert ReturnsSection('Returns', 'returns').is_generator == False
    assert ReturnsSection('Returns', 'returns').key == 'returns'


# Generated at 2022-06-21 11:51:01.144892
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    s = ReturnsSection('Returns','returns')
    #print(s.title)
    #print(s.is_generator)
    assert True

# Generated at 2022-06-21 11:51:11.979951
# Unit test for constructor of class Section
def test_Section():
    image_dir = "/home/yasemin/Desktop/cavab/cavab-project/cavab/deployment/languages/documentation/data/images/"

    assert Section("Aaa", "aaa").title == "Aaa"
    assert Section("Aaa", "aaa").title_pattern == "^Aaa\\s*?\\n{1}\\s*$"
    assert Section("Aaa", "aaa").key == "aaa"

    doc = "Bbb"
    assert Section("Aaa", "aaa").parse(doc) == DocstringMeta(args=["aaa"], description="Bbb")



# Generated at 2022-06-21 11:51:21.050060
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section('Parameters', 'param')
    text = """
        param:
            comment
        param2: type
            comment2
    """
    sec_meta = sec.parse(text)
    assert sec_meta[0] == DocstringMeta([sec.key], description=_clean_str('comment'))
    assert sec_meta[1] == DocstringMeta([sec.key], description=_clean_str('comment2'))

    sec1 = Section('Params', 'other_param')
    text1 = """
        param:
            comment
        param2: type
            comment2
    """
    sec1_meta = sec1.parse(text1)
    assert sec1_meta[0] == DocstringMeta([sec1.key], description=_clean_str('comment'))

# Generated at 2022-06-21 11:51:51.038272
# Unit test for constructor of class Section
def test_Section():    
    title = 'Parameters'
    key = 'param'
    S = Section(title, key)
    assert S.title_pattern == r"^({})\s*?\n{}\s*$".format(S.title, "-" * len(S.title))


# Generated at 2022-06-21 11:51:53.009508
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    ps = ParamSection(title, key)

    return ps


# Generated at 2022-06-21 11:52:04.974627
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-21 11:52:07.980146
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    title = "Yields"
    key = "yields"
    return_ = YieldsSection(title, key)
    assert return_.is_generator == True
    assert return_.key == key
    assert return_.title == title

# Generated at 2022-06-21 11:52:11.161691
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test __init__
    kvs = _KVSection(title="test", key="test")
    assert kvs.title == "test"
    assert kvs.key == "test"


# Generated at 2022-06-21 11:52:13.410598
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")
    assert(s.title == "Parameters")
    assert(s.key == "param")
    

# Generated at 2022-06-21 11:52:25.932936
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert re.match(KV_REGEX, "_KVSection_parse")
    assert re.match(KV_REGEX, ":")
    assert re.match(KV_REGEX, "")
    assert re.match(KV_REGEX, ":")
    assert re.match(KV_REGEX, "arg_name")
    assert re.match(KV_REGEX, "arg_description")
    assert re.match(KV_REGEX, "arg_2 : type, optional")
    assert re.match(KV_REGEX, "arg_name\n\n     arg_description\n ")
    assert re.match(KV_REGEX, "arg_2 : type, optional")
    assert re.match(KV_REGEX, "arg_2 : type, optional")
   

# Generated at 2022-06-21 11:52:33.245045
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection(key="deprecation", title="Deprecated")
    text = """Deprecated since version 3.0
        This method will be removed in future versions."""
    parses = section.parse(text)
    line1 = "Deprecated since version 3.0"
    line2 = "This method will be removed in future versions."
    assert next(parses).description == line1+"\n"+line2


# Generated at 2022-06-21 11:52:44.355931
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Setup
    text1 = inspect.cleandoc(
        """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    )
    text2 = inspect.cleandoc(
        """
    key
        value
    key2 : type
    """
    )
    text3 = inspect.cleandoc(
        """
        key
            value
        key2 : type
            values can also span...
                ... multiple lines
    """
    )
    text4 = inspect.cleandoc(
        """
            key
                value
            key2 : type
                values can also span...
                    ... multiple lines
        """
    )
    # Exercise
    KVP1 = [item for item in _KVSection('name','key').parse(text1)]
    K

# Generated at 2022-06-21 11:52:46.107639
# Unit test for constructor of class _KVSection
def test__KVSection():
    out = _KVSection("Parameters", "param")
    assert(out is not None)


# Generated at 2022-06-21 11:53:49.679134
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    lines = 'header_line\n\
              key1\n\
              key2\n'
    section = Section("title", "key")
    lines_num = len(lines.split('\n'))
    match = lines_num - 1
    assert section.parse(lines) is not None
    assert len(section.parse(lines)) == match
    return True


# Generated at 2022-06-21 11:53:52.401260
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    another_type = ReturnsSection("Returns", "returns")
    assert another_type is not None
    assert another_type.key == "returns"
    assert another_type.is_generator == False

# Generated at 2022-06-21 11:54:02.973927
# Unit test for function parse
def test_parse():
    text = """
    Test function.

    Single line summary

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ...multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    result = parse(text)
    assert result.short_description == "Test function."
    assert result.long_description == "Single line summary"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta.meta[0].args == ['param', 'arg_name']
    assert result.meta.meta[0].description == "arg_description"
    assert result.meta.meta[1].args == ['param', 'arg_2']

# Generated at 2022-06-21 11:54:03.974053
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert (_SphinxSection('Example', 'examples').title == 'Example')


# Generated at 2022-06-21 11:54:07.845953
# Unit test for constructor of class Section
def test_Section():
    expected_args = "a_section"
    expected_key = "a_key"
    section = Section(expected_args, expected_key)
    assert section.title == expected_args
    assert section.key == expected_key
    assert section.title_pattern == r"^(a_section)\s*?\n{}\s*$".format("-"* len(section.title))
    assert section.parse("any_text") == [DocstringMeta([expected_key], description=_clean_str("any_text"))]



# Generated at 2022-06-21 11:54:12.351525
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    x = _SphinxSection(title="whatever", key="something")
    assert x.title == "whatever"
    assert x.key == "something"
    assert x.title_pattern == r"^\.\.\s*(whatever)\s*::"


# Generated at 2022-06-21 11:54:14.676400
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    try:
        section = RaisesSection('Raises','Warning')
    except:
        print("Failed to construct")
    else:
        print("Correctly construct")


# Generated at 2022-06-21 11:54:21.012614
# Unit test for method parse of class Section
def test_Section_parse():
    # param section
    title = "Arguments"
    key = "param"
    section = Section(title, key)
    text = "text of the section"
    parsed_section = section.parse(text)
    assert type(parsed_section) == tuple
    assert type(parsed_section[0]) == DocstringMeta


# Generated at 2022-06-21 11:54:21.578208
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection(title="Returns", key="returns")

# Generated at 2022-06-21 11:54:30.653593
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    print("Starting DeprecationSection.parse")
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("Deprecated", "deprecated"))
    docstring = parser.parse("""
    .. deprecated:: 1.0
        this is deprecated and you should not use it
    """)
    # Test deprecated section
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['deprecated']
    assert docstring.meta[0].description == 'this is deprecated and you should not use it'
    print("Done DeprecationSection.parse")


if __name__ == "__main__":
    test_DeprecationSection_parse()