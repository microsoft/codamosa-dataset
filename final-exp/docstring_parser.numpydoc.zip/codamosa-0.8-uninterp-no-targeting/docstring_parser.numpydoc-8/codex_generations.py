

# Generated at 2022-06-21 11:45:15.535713
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sec = DeprecationSection(".. deprecated", "Deprecation")
    assert sec.title_pattern == r"^\.\.\s*\(Deprecation\)\s*::"
    assert sec.parse("Deprecated since version 1.0.0:\n\n"
                     "Will be removed in future release.") == [
                         DocstringDeprecated(args=["deprecated"], description="Will be removed in future release.", version="1.0.0"
                         )]


# Generated at 2022-06-21 11:45:20.108502
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters","param")
    text = "arg1\nDescription of arg1"
    assert(list(section.parse(text)) == [DocstringMeta(['param'], description = 'Description of arg1')])


# Generated at 2022-06-21 11:45:22.784883
# Unit test for constructor of class _KVSection
def test__KVSection():
    try:
        _KVSection("Parameters", "param")
    except Exception:
        assert False, "Constructor of class _KVSection did not pass unit test"


# Generated at 2022-06-21 11:45:24.951509
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
  returns_section = ReturnsSection("Returns", "returns")
  assert returns_section.title == "Returns"
  assert returns_section.key == "returns"


# Generated at 2022-06-21 11:45:34.326148
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sec = DeprecationSection("Deprecation warning", "deprecation")
    assert sec.title == "Deprecation warning"
    assert sec.key == "deprecation"
    assert sec.title_pattern == r"^\.\.\s*(Deprecation warning)\s*::"
    assert sec.parse("something") == [DocstringDeprecated(
        args=["deprecation"],
        description=None,
        version="something"
    )]
    assert sec.parse("something\nfew lines") == [DocstringDeprecated(
        args=["deprecation"],
        description="few lines",
        version="something"
    )]

# Generated at 2022-06-21 11:45:35.835583
# Unit test for constructor of class _KVSection
def test__KVSection():
    with pytest.raises(TypeError):
        _KVSection()



# Generated at 2022-06-21 11:45:37.345161
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_instance = ReturnsSection("Returns", "returns")
    assert test_instance

# Generated at 2022-06-21 11:45:38.837525
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np = NumpydocParser()
    assert isinstance(np,NumpydocParser)


# Generated at 2022-06-21 11:45:39.556878
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """ Unit test for constructor of class ParamSection"""
    assert ParamSection("Parameters", "param")

# Generated at 2022-06-21 11:45:45.009702
# Unit test for method parse of class Section
def test_Section_parse():
    test_list_str = [
        ("Parameters\n---------\n: arg_name\n    arg_description",
         "arg_description"),
        ("Args\n-----\nsome arg\n    arg_description",
         "arg_description"),
        ("Args\n-----\narg_2 : type, optional\n    descriptions can also span...\n    ...",
         "descriptions can also span...\n    ...")]
    test_list_DocstringMeta = [
        DocstringMeta(["param", "arg_name"], "arg_description"),
        DocstringMeta(["args", "some arg"], "arg_description"),
        DocstringMeta(["args", "arg_2"], "descriptions can also span...\n    ...")]

# Generated at 2022-06-21 11:46:01.927575
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    meta = section.parse("deprecated\nText of deprecation")
    assert(meta[0].description == "Text of deprecation")
    assert(meta[0].version == "deprecated")
    meta = section.parse("deprecated:\nText of deprecation")
    assert(meta[0].description == "Text of deprecation")
    assert(meta[0].version == "deprecated:")

# Generated at 2022-06-21 11:46:06.215876
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {s.title: s for s in DEFAULT_SECTIONS}
    parser = NumpydocParser(sections=sections)
    assert parser is not None
    assert parser.sections == sections


# Unit tests for parse()

# Generated at 2022-06-21 11:46:18.619964
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Parameters", "param"))
    parser.add_section(Section("Raises", "raises"))
    parser.add_section(Section("Returns", "returns"))
    parser.add_section(Section("Example", "examples"))
    parser.add_section(Section("Warning", "warnings"))
    parser.add_section(Section("Note", "notes"))
    parser.add_section(Section("Yield", "yields"))
    parser.add_section(Section("See Also", "see_also"))
    parser.add_section(Section("Related", "see_also"))
    parser.add_section(Section("Reference", "references"))
    parser.add_section(Section("Attributes", "attribute"))

# Generated at 2022-06-21 11:46:23.076430
# Unit test for method parse of class Section
def test_Section_parse():
    doc = """
    Parameters
    ----------
    kwargs : str
        Something
    """
    section = ParamSection("Parameters", "param")
    assert section.parse(doc) == [DocstringParam(args=[section.key,"kwargs"], description="Something",arg_name="kwargs",type_name="str",is_optional=False)]


# Generated at 2022-06-21 11:46:29.804569
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is a one-line summary

This is a
longer description.

Notes
-----
Notes can span multiple lines.

.. deprecated:: 1.0.0
   Please use something else
"""
    expected_short_desc = "This is a one-line summary"
    expected_long_desc = (
        "This is a\nlonger description."
        + "\n"
        + "\nNotes\n-----\nNotes can span multiple lines."
        + "\n\n.. deprecated:: 1.0.0\n   Please use something else"
    )
    actual_short_desc, actual_long_desc = NumpydocParser().parse(text).as_tuple()[:2]
    assert expected_short_desc == actual_short_desc
    assert expected_long_desc == actual_long_desc

# Generated at 2022-06-21 11:46:40.729065
# Unit test for function parse
def test_parse():
    """Test parsing of a numpydoc docstring."""
    from .common import Docstring


# Generated at 2022-06-21 11:46:42.386992
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    s = YieldsSection("Yields", "yield")
    print(s)


# Generated at 2022-06-21 11:46:50.811958
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #import doctest
    #doctest.testmod()
    parser = NumpydocParser()
    example = """
    A quick example:

    >>> parse('2 + 3')
    5
    """
    doc = parser.parse(example)
    assert doc.short_description == "A quick example"
    assert doc.long_description == "parse('2 + 3')\n5"
    assert len(doc.meta) == 0
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-21 11:47:03.617894
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test method add_section
    """

    class MyParamSection(Section):
        def __init__(self, title: str, key: str) -> None:
            self.title = title
            self.key = key

        @property
        def title_pattern(self) -> str:
            return r"^({})\s*?\n{}\s*$".format(self.title, "-" * len(self.title))

        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    test_section = MyParamSection("Test", "test")

    assert test_section.title == "Test"

    doc = """
    Test
    ---
    This is a test section

    """

# Generated at 2022-06-21 11:47:05.757092
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("title", "key").title == "title"
    assert _SphinxSection("title", "key").key == "key"


# Generated at 2022-06-21 11:47:11.075126
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"


# Generated at 2022-06-21 11:47:23.674623
# Unit test for function parse
def test_parse():
    assert parse('').short_description == None
    assert parse('').long_description == None
    assert parse('').blank_after_short_description == False
    assert parse('').blank_after_long_description == False
    assert parse('').meta == []

    assert parse('describe the function').short_description == 'describe the function'
    assert parse('describe the function').long_description == None
    assert parse('describe the function').blank_after_short_description == False
    assert parse('describe the function').blank_after_long_description == False
    assert parse('describe the function').meta == []

    assert parse('describe the function\n\ndetails\n').short_description == 'describe the function'
    assert parse('describe the function\n\ndetails\n').long_

# Generated at 2022-06-21 11:47:27.695910
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    assert(section.title == "Parameters")
    assert(section.key == "param")
    assert(section.title_pattern == "^Parameters\s*?\n---------\s*$")

# Generated at 2022-06-21 11:47:37.038861
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text= """
    :param name:
        This is a name. 
        This is a name.
        This is a name.
        This is a name.
    :param type: This is a type.
    :type type: int
    :param age: 
        This is an age.
        This is an age.
        This is an age.
    :type age: int
    :param gender: This is a gender.
    :type gender: char
    :returns: Nothing
    :rtype: void
    
    
    """
    # test = NumpydocParser()
    # print(test.parse(text))
    print(parse(text))

test_NumpydocParser_parse()

# Generated at 2022-06-21 11:47:46.957094
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    example_string = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    example_string = inspect.cleandoc(example_string)

    expected_meta = [
        DocstringMeta(args=["key"], description="value"),
        DocstringMeta(
            args=["key2 : type"], description="values can also span..."
        ),
    ]

    example_section = _KVSection(title="key", key="key")
    meta_list = example_section.parse(example_string)

    assert tuple(expected_meta) == tuple(meta_list)

# Generated at 2022-06-21 11:47:48.709535
# Unit test for constructor of class YieldsSection

# Generated at 2022-06-21 11:47:57.744298
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = inspect.cleandoc("""\
        Returns
            name: Lorem ipsum dolor sit amet, consectetur adipiscing elit,
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
            nisi ut aliquip ex ea commodo consequat.
    """)
    ReturnsSection("Returns", "returns").parse(text)


if __name__ == "__main__":
    print(parse.__doc__)

# Generated at 2022-06-21 11:48:05.374681
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep_sec = DeprecationSection("deprecation","deprecated")
    text = "deprecated\n" \
           "--------------\n" \
           "v2.0\n" \
           "--\n" \
           "Use something else instead"
    res = dep_sec.parse(text)
    result = [next(res)]
    assert result[0].description == "Use something else instead"

# Generated at 2022-06-21 11:48:08.268929
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = NumpydocParser()
    assert parser.sections["deprecated"].title == "deprecated"
    assert parser.sections["deprecated"].key == "deprecation"

# Generated at 2022-06-21 11:48:17.191239
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection('deprecated', 'deprecation').parse('since 11.0\n deprecation text\\') == [DocstringDeprecated(args=['deprecation'], description='deprecation text\\', version='since 11.0')]
    assert DeprecationSection('deprecated', 'deprecation').parse('since 11.0\n deprecation text') == [DocstringDeprecated(args=['deprecation'], description='deprecation text', version='since 11.0')]
    assert DeprecationSection('deprecated', 'deprecation').parse('since 11.0\n') == [DocstringDeprecated(args=['deprecation'], description=None, version='since 11.0')]

# Generated at 2022-06-21 11:48:23.321979
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections['See Also'] == Section("See Also", "see_also"), 'Constructor of class NumpydocParser is wrong!'


# Generated at 2022-06-21 11:48:25.097776
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines"""
    parser = ParamSection("Parameters", "param")
    for item in parser.parse(text):
        assert type(item) == DocstringParam

# Generated at 2022-06-21 11:48:27.186865
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True


# Generated at 2022-06-21 11:48:28.870883
# Unit test for constructor of class ParamSection
def test_ParamSection():
    obj = ParamSection("Parameters", "param")
    assert obj.title == 'Parameters'
    assert obj.key == 'param'

# Generated at 2022-06-21 11:48:32.846431
# Unit test for constructor of class Section
def test_Section():
    t = "Params"
    k = "param"
    test_section = Section(t, k)

    assert test_section.title == t
    assert test_section.key == k
    assert test_section.title_pattern == r'^(Params)\s*?\n-{5}\s*$'


# Generated at 2022-06-21 11:48:39.915164
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = ParamSection("Parameters", "param")
    docstr = """a : int
        des1

    b : str
    des2
    """
    res = p.parse(docstr)
    # First param
    assert res[0].description == 'des1'
    assert res[0].arg_name == 'a'
    assert res[0].type_name == 'int'
    assert res[0].is_optional is False
    # Second param
    assert res[1].description == 'des2'
    assert res[1].arg_name == 'b'
    assert res[1].type_name == 'str'
    assert res[1].is_optional is False


# Generated at 2022-06-21 11:48:46.667983
# Unit test for function parse
def test_parse():
    """Testing function parse
    """
    title =  '''Params
    ----------
    foo : str
        foo
        bar
    bar : int
        bar
    '''
    full_text = '''
    short
    long
    ''' + title
    ds = parse(full_text)
    assert ds.short_description == 'short', \
            "Parse did not work properly testing the short description"

# Generated at 2022-06-21 11:48:57.496741
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class TestClass:
        def f1(self, arg1):
            """Single line docstring with no parameters.

            This method has a single line docstring,
            which should be parsed into a single short description line,
            with no long description or meta information
            """
            pass

        def f2(self, arg1, arg2 = None):
            """Single line docstring with parameters.

            This method has a single line docstring,
            which should be parsed into a single short description line,
            with no long description or meta information, but with parameters
            """
            pass


# Generated at 2022-06-21 11:49:01.881864
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_section = RaisesSection("Raises", "test")
    assert test_section.title == "Raises"
    assert test_section.key == "test"
    assert test_section.title_pattern == r'^Raises\s*?\n{}\s*$'.format("-" * 6)


# Generated at 2022-06-21 11:49:07.508874
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """para_name
            para_desc
        para_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    expected = [('para_name','para_desc'), ('para_2','descriptions can also span...\n... multiple lines')]
    res = list(_KVSection('','').parse(text))
    assert res[0].args == expected[0][0]
    assert res[0].description == expected[0][1]
    assert res[1].args == expected[1][0]
    assert res[1].description == expected[1][1]


# Generated at 2022-06-21 11:49:15.723954
# Unit test for constructor of class ParamSection
def test_ParamSection():
    para = ParamSection("Parameters", "param")
    assert para.title == "Parameters"
    assert para.key == "param"
    assert para.title_pattern == "^Parameters\\s*?\n-*\\s*$"


# Generated at 2022-06-21 11:49:18.238222
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    expt = '../ This is a title ::'
    title = 'This is a title'
    key = 'key'
    parse = _SphinxSection(title, key)
    assert parse.title_pattern == expt



# Generated at 2022-06-21 11:49:29.331136
# Unit test for function parse
def test_parse():
    import pytest
    

# Generated at 2022-06-21 11:49:32.165330
# Unit test for constructor of class ParamSection
def test_ParamSection():
    paramSection = ParamSection("Parameters", "param")
    assert (paramSection.title == 'Parameters')
    assert (paramSection.key == 'param')


# Generated at 2022-06-21 11:49:37.593007
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    s = Section(title, key)
    assert s.title == title
    assert s.key == key
    assert s.title_pattern == "^(Parameters)\s*?\n-{}\s*$".format(len(title))


# Generated at 2022-06-21 11:49:42.158028
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert section.title == "Raises"
    assert section.key == "raises"

    assert section.title_pattern == "^(Raises)\\s*?\\n\\-*\s*$"


# Generated at 2022-06-21 11:49:45.614803
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test = "ValueError\na description of what might raise ValueError"
    parser = _KVSection.parse(test)
    print(parser)



# Generated at 2022-06-21 11:49:48.094809
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").__class__.__name__ == "DeprecationSection"

# Generated at 2022-06-21 11:49:52.734140
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    import unittest

    class Test__KVSection_parse(unittest.TestCase):

        def _test_inner(self, text, expected):
            section = _KVSection("header", "key")
            actual = list(section.parse(text))
            self.assertEqual(expected, actual)

        def test_0(self):
            text = ""
            expected = []
            self._test_inner(text=text, expected=expected)

        def test_1(self):
            text = "key\n    value"
            expected = [DocstringMeta(args=['key'], description='value')]
            self._test_inner(text=text, expected=expected)

        def test_2(self):
            text = "key\n    value\nkey2\n    value2"

# Generated at 2022-06-21 11:49:53.873351
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters","param")

# Generated at 2022-06-21 11:50:12.521668
# Unit test for function parse
def test_parse():
    doc = """
    Short description

    description...
    spanning multiple lines

    Parameters
    ----------
    arg1
        Desc1
    arg2 : type, optional
        Desc2

    Returns
    -------
    return_name : type
        Desc

    See Also
    --------
    other : func
        other...
    """
    expected = """
    Short description

    description...
    spanning multiple lines

    Parameters
    ----------
    arg1
        Desc1
    arg2 : type, optional
        Desc2

    Returns
    -------
    return_name : type
        Desc

    See Also
    --------
    other : func
        other...
    """

    actual = Docstring.from_string(doc).dump()
    assert actual == expected

# Generated at 2022-06-21 11:50:14.702481
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    #assert len(DEFAULT_SECTIONS) == 34
    assert len(NumpydocParser().sections) == 34


# Generated at 2022-06-21 11:50:15.994052
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()


# Generated at 2022-06-21 11:50:26.338957
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # This test is just here to show that the default parse method of _KVSection works
    # correctly. The parser is complicated and there are many other tests that cover
    # the individual methods of the parser.

    # The param section parser that is used by default, with is inherited from _KVSection
    section_parser = ParamSection("Parameters", "parameter")
    # Parsing of a sample docstring as it would be parsed with the default parser
    section_parser.parse("""
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """)

    return True



# Generated at 2022-06-21 11:50:38.589652
# Unit test for function parse
def test_parse():
    # Testcase 1
    text = """
    Blah
    blah

    This is the short description.

    And the long description.

    :param name: For nothing
    :type name: str
    :returns: Nothing
    """
    res = parse(text)
    assert isinstance(res, Docstring)
    assert res.short_description == "This is the short description."
    assert res.long_description == "And the long description.\n"

    # Testcase 2
    text = """
    Blah
    blah

    This is the short description.

    And the long description.


    :param name: For nothing
    :type name: str
    :returns: Nothing
    """
    res = parse(text)
    assert isinstance(res, Docstring)

# Generated at 2022-06-21 11:50:50.062486
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_text = """
    Parameters
    ----------
    x : int
        The number which will be incremented.

    Returns
    -------
    int
        The number x + 1
        """

    test_split = """
    Parameters
    ----------
    x : int
        The number which will be incremented.

    Returns
    -------
    int
        The number x + 1
        """.split(sep="\n", maxsplit=1)

    test_value = inspect.cleandoc(test_split[-1])

    test_section = """
    Parameters
    ----------
    x : int
        The number which will be incremented.

    Returns
    -------
    int
        The number x + 1
        """.split(sep="\n", maxsplit=1)[1]

    test_title = inspect

# Generated at 2022-06-21 11:51:01.100406
# Unit test for function parse
def test_parse():
    """Unit test for function parse()"""
    docstr = '''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg_name : type, optional
        arg_description

    other_args : other_type(optional)
        other_description

    Returns
    -------
    return_name : return_type, optional
        return_description

    See Also
    --------
    other_func : description of other_func
    '''
    ret = parse(docstr)
    print(ret)
    assert ret.short_description == 'This is a short description.'
    assert ret.long_description == 'This is a long description.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    print(ret.meta)
   

# Generated at 2022-06-21 11:51:05.774642
# Unit test for method parse of class Section
def test_Section_parse():
    instance = ParamSection(title='Parameters', key='param')
    dictionary = {'param': 'test'}
    try:
        assert isinstance(instance.parse(dictionary), DocstringMeta)
    except Exception as e:
        print(e)


# Generated at 2022-06-21 11:51:12.204621
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section_title = 'Parameters'
    section_key = 'param'
    parser = ParamSection(section_title, section_key)
    result = parser.title
    expected = 'Parameters'
    assert result == expected, "Error"
    result = parser.key
    expected = 'param'
    assert result == expected, "Error"


# Generated at 2022-06-21 11:51:16.462413
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "parameters"
    key = "param"
    test_class = _KVSection(title, key)

    assert test_class.title_pattern == '^(parameters)\s*?\n------\s*$'

# Generated at 2022-06-21 11:51:29.012733
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="Parameters", key="param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Unit tests for properties of class Section

# Generated at 2022-06-21 11:51:30.194851
# Unit test for method parse of class Section
def test_Section_parse():
    Section.parse("Some text that is not empty")



# Generated at 2022-06-21 11:51:37.043572
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from .common import DocstringMeta, DocstringParam
    from .common import TYPE_ANY

# Generated at 2022-06-21 11:51:49.057738
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class _KVSectionTest:
        def _parse_item(self, key: str, value: str) -> DocstringReturns:
            m = RETURN_KEY_REGEX.match(key)
            if m is not None:
                return_name, type_name = m.group("name"), m.group("type")
            else:
                return_name = type_name = None

            return DocstringReturns(
                args=[self.key],
                description=_clean_str(value),
                type_name=type_name,
                is_generator=self.is_generator,
                return_name=return_name,
            )

    section = _KVSectionTest()
    section.key = "returns"

# Generated at 2022-06-21 11:51:54.173409
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = Section("test_title", "test_key")
    test_section.parse("test\ntest\n")
    test_parser = NumpydocParser()
    test_parser.add_section(test_section)
    assert(test_parser.sections["test_title"] == test_section)
    assert(test_parser.sections["test_title"].description == 'test\ntest\n')


# Generated at 2022-06-21 11:51:58.340385
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    with open("./test_numpydoc_ok.txt", "r") as f:
        examples = f.read()
    examples = parse(examples)
    assert examples.meta[-1].args == ('yields', )

# Generated at 2022-06-21 11:52:08.369934
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np = NumpydocParser()
    assert np.sections == {s.title: s for s in DEFAULT_SECTIONS}

# Generated at 2022-06-21 11:52:12.818325
# Unit test for constructor of class _KVSection
def test__KVSection():
    sample_section = _KVSection("param", "param")
    assert sample_section.title_pattern == r"^param\s*?\n-\s*$"
    assert sample_section.title == "param"
    assert sample_section.key == "param"



# Generated at 2022-06-21 11:52:23.884997
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    #testcase: a certain line format
    expected_version="1.0"
    expected_description="A description"
    dps=DeprecationSection("deprecated", "deprecation")
    text=f"{expected_version}\n{expected_description}\n"
    ret=next(dps.parse(text))
    assert ret.version==expected_version
    assert ret.description==expected_description
    #testcase: argument text without line break
    text="This is a Deprecation Warning"
    ret=next(dps.parse(text))
    assert ret.version==None
    assert ret.description==text.strip()


# Generated at 2022-06-21 11:52:32.461172
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Arrange
    kv_section = _KVSection(title="title", key="key")
    text = "key\n    value\nkey2 : type\n    values can also span...\n    ..."
    
    # Act
    result = kv_section.parse(text)
    result_list = list(result)

    # Assert
    assert len(result_list) == 2
    assert result_list[0].description == "value"
    assert result_list[1].description == "values can also span..."


# Generated at 2022-06-21 11:52:46.200514
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Test if we can create an instance of ReturnsSection
    assert ReturnsSection("Returns", "returns") is not None

# Generated at 2022-06-21 11:52:48.881899
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert (section.title == "deprecated")
    assert (section.key == "deprecation")
    

# Generated at 2022-06-21 11:52:57.206202
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:53:05.286861
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    class A():
        def f(self):
            """
            Cette fonction commente toute les parties de la classe

            Parameters
            ----------
            self : type
                Description du paramètre

            Returns
            -------
            return_name :
                Description du retour
            """
            pass
    a = A()
    doc = parse(inspect.cleandoc(a.f.__doc__))
    assert doc.meta[0].type == "yields"
    assert doc.meta[0].return_type == None

# Generated at 2022-06-21 11:53:07.242217
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS


# Generated at 2022-06-21 11:53:09.108672
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert(YieldsSection("Yields", "yields")) == ["Yields","yields"]

# Generated at 2022-06-21 11:53:11.497364
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    tester = RaisesSection("Raises", "raises")
    assert tester.title == "Raises"
    assert tester.key == "raises"


# Generated at 2022-06-21 11:53:24.454440
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # assert that a docstring section with a Deprecation warning can be parsed
    deprecation_text = """.. deprecated:: v0.0
    :now: 2018-01-01
    :type: attribute
    :reason: this module has been replaced
    :alt: use `foo` instead

    Do not use this - it has been replaced with the `foo` module.
    """
    deprecation_parser = DeprecationSection("deprecated", "deprecation")
    actual = deprecation_parser.parse(deprecation_text)
    expected = (
        DocstringDeprecated(
            args=['deprecation'],
            description='Do not use this - it has been replaced with the `foo` module.',
            version='v0.0',
        ),
    )

    assert actual == expected

# Generated at 2022-06-21 11:53:32.938131
# Unit test for method parse of class Section
def test_Section_parse():
    test_string = "title\n----\ntest"
    for test_section in DEFAULT_SECTIONS:
        actual_string = test_section.parse(test_string)
        actual_string = str(actual_string).strip('[<>()]')
        title = test_section.title
        if title in ["Parameters", "Params", "Arguments", "Args", "Other Parameters", "Other Params", "Other Arguments", "Other Args", "Receives", "Receive"]:
            expected_string = "Meta([\"param\"]","description=\"test\""
        elif title in ["Raises", "Raise", "Warns", "Warn"]:
            expected_string = "Meta([\"raises\"]","description=\"test\""

# Generated at 2022-06-21 11:53:38.878138
# Unit test for function parse
def test_parse():
    def fn():
        """
        Test function for numpydoc parser.

        Parameters
        ----------
        arg1 : int
            This is arg1
        arg2, optional
            This is arg2

        Returns
        -------
        int
            This is a return value

        Raises
        ------
        ValueError
            This is a raised exception
        """

# Generated at 2022-06-21 11:54:09.498995
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """Test method parse of _KVSection.

    :returns: None
    """
    class _TestSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringParam:
            return DocstringParam(
                args=[self.key, key],
                description=_clean_str(value),
                arg_name=key,
                type_name=None,
                is_optional=False,
                default=None,
            )
    test_text = inspect.cleandoc("""\
    subject1

        description1

    subject2
        description2


    subject3

        description3

    subject4 : type, optional
        description4

        can span multiple lines
    """)
    parser = NumpydocParser()

# Generated at 2022-06-21 11:54:17.271068
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class ExampleSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key], description=_clean_str(value))
    example_section = ExampleSection("Example", "examples")
    parser = NumpydocParser()
    parser.add_section(example_section)
    docstring = parser.parse(
        "Example:\n    Example of the class, doesn't actually do anything.\n"
    )
    assert len(docstring.meta) == 1
    assert docstring.meta[0].description == "Example of the class, doesn't actually do anything."
    assert docstring.meta[0].args[0] == "examples"


# Generated at 2022-06-21 11:54:28.856987
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Should raise an error because the key of the new section is not unique
    try:
        NumpydocParser().add_section(Section("Key 1", "key1"))
        NumpydocParser().add_section(Section("Key 2", "key1"))
        raise Exception("Should have raised a ValueError")
    except ValueError:
        pass
    # Should work fine
    NumpydocParser().add_section(Section("Key 1", "key1"))
    NumpydocParser().add_section(Section("Key 2", "key2"))
    # Should raise an error because the title of the new section is not unique
    try:
        NumpydocParser().add_section(Section("Key", "key1"))
        raise Exception("Should have raised a ValueError")
    except ValueError:
        pass
