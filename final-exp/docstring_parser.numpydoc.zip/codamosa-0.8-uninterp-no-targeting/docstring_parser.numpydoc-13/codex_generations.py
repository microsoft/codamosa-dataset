

# Generated at 2022-06-21 11:45:10.493195
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser().parse("")

# Generated at 2022-06-21 11:45:15.404257
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key")
    assert(isinstance(s, Section) == True)
    assert(s.title == "title")
    assert(s.key == "key")
    assert(isinstance(s.title_pattern, str) == True)

# Generated at 2022-06-21 11:45:26.063377
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():

   class CustomSection1(Section):
      """Custom section 1"""
      pass

   class CustomSection2(Section):
      """Custom section 2"""
      pass

   class CustomSection3(Section):
      """Custom section 3"""
      pass

   title1 = "customone"
   title2 = "customtwo"
   title3 = "customthree"
   key1 = "customkey1"
   key2 = "customkey2"
   key3 = "customkey3"

   section1 = CustomSection1(title1, key1)
   section2 = CustomSection2(title2, key2)
   section3 = CustomSection1(title3, key3)

   parser = NumpydocParser()
   parser.add_section(section1)
   parser.add_section(section2)

# Generated at 2022-06-21 11:45:28.338469
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Generate the expected result and then compare with the result returned 
    by the method parse of class NumpydocParser.
    """
    #TODO
    pass



# Generated at 2022-06-21 11:45:35.111247
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    def _parse_item(self, key: str, value: str) -> DocstringRaises:
        return DocstringRaises(
            args=[self.key, key],
            description=_clean_str(value),
            type_name=key if len(key) > 0 else None,
        )
    raised = RaisesSection("Raises", "key")

    # string that is not empty
    assert raised._parse_item("ValueError", "A description of what might raise ValueError") == DocstringRaises(['key', 'ValueError'], description='A description of what might raise ValueError', type_name='ValueError')

    # string that is empty
    assert raised._parse_item("ValueError", "") == DocstringRaises(['key', 'ValueError'], description='', type_name='ValueError')

    # string that is

# Generated at 2022-06-21 11:45:36.986430
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # Test for correct input
    a=RaisesSection("Raises", "raise")
    assert isinstance(a,RaisesSection)


# Generated at 2022-06-21 11:45:38.750043
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True


# Generated at 2022-06-21 11:45:45.127359
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parameters
    ----------
    hi : type, optional
       This is some long description that spans multiple lines

    numpydoc.Docstring

    Raises
    ------
    numpydoc.DocstringRaises
        First exception

    Returns
    -------
    numpydoc.DocstringReturns
        Some description

    Yields
    ------
    numpydoc.DocstringReturns
        A yielded value

    Warnings
    --------
    Nothing

    Examples
    --------
    >>> import this

    See Also
    --------
    ``this``

    Notes
    -----
    These are some notes

    References
    ----------
    These are some references

    .. deprecated:: 0.0.1
       Use something else
    """

    parser = NumpydocParser()
    parsed_docstring = parser.parse

# Generated at 2022-06-21 11:45:49.599391
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert(DeprecationSection("deprecated", "deprecation").parse("v1.45\nReason") == [DocstringDeprecated(args = ['deprecation'], description = 'Reason', version = 'v1.45')])
    

# Generated at 2022-06-21 11:45:56.737135
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    obj = NumpydocParser()
    section_title_keyword_args = [
        ("Section1", "section1"),
        ("Section2", "section2"),
    ]
    for section_title, keyword_arg in section_title_keyword_args:
        obj.add_section(Section(section_title, keyword_arg))
    for section_title, keyword_arg in section_title_keyword_args:
        assert obj.sections[section_title].key == keyword_arg

# Generated at 2022-06-21 11:46:30.799080
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # RaisesSection takes in two mandatory parameters:
    # The first is the title of the section which is a string
    # The second is the key which is a string
    test = RaisesSection("Raises", "raises")
    if test.title != "Raises" and test.key != "raises":
        raise AssertionError()

    # Even though we specified "Raises" as the title and "raises" as key,
    # the title_pattern is different because it concatenated "Raises"
    # with "--".
    if test.title_pattern != "^Raises\s*?\n---\s*$":
        raise AssertionError()


# Generated at 2022-06-21 11:46:37.972841
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from docstring_parser import NumpydocParser
    class NumpydocParser1(NumpydocParser):
        def __init__(self, sections: T.Optional[T.Dict[str, Section]] = None):
            """Setup sections.

            :param sections: Recognized sections or None to defaults.
            """
            sections = sections or DEFAULT_SECTIONS
            self.sections = {s.title: s for s in sections}
            self._setup()

        def _setup(self):
            self.titles_re = re.compile(
                r"|".join(s.title_pattern for s in self.sections.values()),
                flags=re.M,
            )


# Generated at 2022-06-21 11:46:42.672883
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    """Unit test for constructor of class _SphinxSection"""

    with pytest.raises(TypeError) as test_support:
        _SphinxSection("Parameters", "param").parse("body")
    assert (
        str(test_support.value) == "Can't instantiate abstract class _SphinxSection with abstract methods parse"
    )



# Generated at 2022-06-21 11:46:52.983632
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = 'Deprecated since version 0.9.0 : deprecated'
    parser = NumpydocParser()
    if not parser.parse('Deprecated since version 0.9.0 : deprecated').deprecated:
        print('parse fails')
        return
    if not parser.parse('Deprecated since version 0.9.0 : deprecated').deprecated.version == '0.9.0':
        print('parse fails to assign version')
        return
    if not parser.parse('Deprecated since version 0.9.0 : deprecated').deprecated.description == 'deprecated':
        print('parse fails to assign description')
        return


# Generated at 2022-06-21 11:47:05.261334
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np_parser = NumpydocParser()
    assert np_parser.sections is not None
    assert np_parser.sections["Parameters"] is not None
    assert np_parser.sections["Parameters"].title == "Parameters"
    assert np_parser.sections["Parameters"].key == "param"
    assert np_parser.sections["Parameters"].title_pattern == r"^Parameters\s*?\n-*\s*$"
    assert np_parser.titles_re is not None

# Generated at 2022-06-21 11:47:06.757803
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    npd_parser = NumpydocParser()


# Generated at 2022-06-21 11:47:12.324848
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for method parse of class NumpydocParser"""
    from .common import DocstringReturns
    
    text = """
        A short description.

        A long description.
        Spanning multiple lines.
        """
    
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'A short description.'
    assert docstring.long_description == 'A long description.' \
                                         '\nSpanning multiple lines.'

# Generated at 2022-06-21 11:47:16.657202
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == 31
    assert len(parser.sections['Parameters'].title_pattern) == 13
    pass

## Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:47:29.324805
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
        something
            description...
            ... over multiple lines

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        type_name
            Return names are optional, types are required
    """

    result = parser.parse(text)

    expected_short_description = 'something'
    expected_blank_after_short_description = True
    expected_blank_after_long_description = True
    expected_long_description = 'description...\n... over multiple lines'


# Generated at 2022-06-21 11:47:30.847058
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_parser = NumpydocParser()
    assert test_parser


# Generated at 2022-06-21 11:47:39.400779
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection('title', 'key').title == 'title' and _SphinxSection('title', 'key').key == 'key'

# Generated at 2022-06-21 11:47:42.151466
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    try:
        NumpydocParser()
    except Exception as e:
        print(e)
        assert False
    assert True


# Generated at 2022-06-21 11:47:51.110216
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    This is a test
    Parameters:
        name1 (type1): description1
        name2 (type2): description2
        name3 (type3): description3
    """
    # Initialize the parser
    p = NumpydocParser()
    d = p.parse(text)
    assert len(d.meta) == 3
    # Add section
    s = Section('Methods','method')
    p.add_section(s)
    assert len(p.sections) == 2
    d2 = p.parse(text)
    assert len(d2.meta) == 3

if __name__ == "__main__":
    test_NumpydocParser_add_section()

# Generated at 2022-06-21 11:47:54.070218
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    result = ReturnsSection("Returns", "returns")
    assert result.is_generator == False, "test_ReturnsSection: assert failure"

test_ReturnsSection()

# Generated at 2022-06-21 11:47:57.565724
# Unit test for function parse
def test_parse():
    docstring = '''This docstring has only a one line descriptive string.'''
    expected = Docstring(short_description='This docstring has only a one line descriptive string.')
    parsed = parse(docstring)
    assert parsed == expected



# Generated at 2022-06-21 11:48:05.191493
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section()
        Section(123)
        Section("section", 123)
    test_section=Section("section", "meta")
    assert test_section.title == "section"
    assert test_section.key == "meta"
    assert test_section.title_pattern == "^(section)\s*?\n------*\s*$"


# Generated at 2022-06-21 11:48:06.337144
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection("", "")


# Generated at 2022-06-21 11:48:07.431317
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert isinstance(_KVSection("title", "key"), _KVSection)



# Generated at 2022-06-21 11:48:08.985904
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_section = ReturnsSection("Returns", "returns")


# Generated at 2022-06-21 11:48:15.143929
# Unit test for method parse of class Section
def test_Section_parse():
    meta = Section(title="param", key="param")

    text = """
    arg_1 : type
        arg_1_description
    arg_2 : type, optional
        arg_2_description

    """

    retour = []

    for m in meta.parse(text):
        retour.append(m)

    expected_args = ["param", "arg_1", "arg_1_description", "type", False, None]

    assert retour[0].args == expected_args


# Generated at 2022-06-21 11:48:26.820801
# Unit test for constructor of class _KVSection
def test__KVSection():
    try:
        _KVSection('title', '')
    except Exception:
        print('_KVSection constructor fail')

# Generated at 2022-06-21 11:48:29.153763
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section(title="title", key="key").parse('text\ntext') == [DocstringMeta(['key'], description='text\ntext')]


# Generated at 2022-06-21 11:48:36.974807
# Unit test for method parse of class Section
def test_Section_parse():
    # Initialize a section object
    section = Section("Parameters", "param")

    # Test 1: Parse a valid text
    text = """
    a : int
        First parameter
    b : str, optional
        Second parameter
    """
    valid_result = [
        DocstringMeta(["param", "a"], description="First parameter", arg_name="a", type_name="int", is_optional=False),
        DocstringMeta(["param", "b"], description="Second parameter", arg_name="b", type_name="str", is_optional=True)
    ]
    result = section.parse(text)
    assert valid_result == list(result)

    # Test 2: Parse another valid text
    text = """
    c
        Third parameter
    d, optional
        Fourth parameter
    """

# Generated at 2022-06-21 11:48:40.736514
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_sec = _KVSection("", "")
    text = """     key_1
                  value_1


                  key_2
                    value_2"""
    assert list(kv_sec.parse(text)) == [
        DocstringMeta([""], description="value_1"),
        DocstringMeta([""], description="value_2"),
    ]



# Generated at 2022-06-21 11:48:46.614151
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = '''
        ValueError
            A description of what might raise ValueError

        KeyError
            Another description
    '''
    text_list = text.splitlines()
    text = "\n    ".join(text_list)
    return_value = RaisesSection("Raises", "raises").parse(text)
    assert len(return_value) == 2


# Generated at 2022-06-21 11:48:50.140132
# Unit test for function parse
def test_parse():
    text = '''\
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    '''
    print(str(parse(text)))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:48:53.501350
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_returns = ReturnsSection("Returns", "returns")
    if len(test_returns.key) <= 0 or test_returns.key != "returns":
        raise ValueError("Construction with title and key failed!")


# Generated at 2022-06-21 11:48:54.983185
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False

# Generated at 2022-06-21 11:49:04.669146
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    text1 = "0.1.2\n    some description"
    text2 = "0.1.2\n    \n   \n  \n some description"
    text3 = "0.1.2\nsome description\n   \n  \n"
    text4 = "    0.1.2\n   some description"
    text5 = "    0.1.2\n   some description\n   \n  \n"
    text6 = "    0.1.2\n   \n   \n  \n some description"
    text7 = "    0.1.2\n   some description\n   \n  \n"

# Generated at 2022-06-21 11:49:07.186065
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")
    assert s.title == "Parameters"
    assert s.key == "param"


# Generated at 2022-06-21 11:49:30.216370
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section = ParamSection("Key_word", "key_word")
    numpydoc_parser.add_section(section)
    assert(numpydoc_parser.sections.get("Key_word")) == section
    assert(numpydoc_parser.sections.get("Key_word")) == section


# Generated at 2022-06-21 11:49:38.036178
# Unit test for constructor of class ParamSection
def test_ParamSection():
    my_ParamSection = ParamSection("You", "param")
    assert my_ParamSection.title == "You"
    assert my_ParamSection.key == "param"
    assert my_ParamSection.title_pattern == "^(You)\\s*?\\n-----*\\s*$"
    # Test that the "key" is not added to arugments list
    assert my_ParamSection.parse("This is a value\nIt is type\n")[0].args == ["param"]

# Generated at 2022-06-21 11:49:43.057605
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv = _KVSection("Parameters", "param")
    result = kv.parse("arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines")
    for i in result:
        print(i)


# Generated at 2022-06-21 11:49:52.100220
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import DocstringDeprecated
    from .numpydoc import DeprecationSection
    ds = DeprecationSection("deprecated", "deprecation")
    actual = ds.parse("""\
    Deprecated since version 1.0.0

    This is description of deprecation.
    """)
    expected = [DocstringDeprecated(
        args=["deprecation"],
        description="This is description of deprecation.",
        version="1.0.0",
    )]
    assert actual == expected


# Generated at 2022-06-21 11:50:01.324649
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = inspect.cleandoc("""
    Parse the numpy-style docstring into its components.
    .. deprecated:: 0.0.1
        Now using version 0.0.2
    """)
    section = DeprecationSection("deprecated", "deprecation")
    deprecations = [e for e in section.parse(text)]
    assert len(deprecations) == 1
    assert deprecations[0].version == "0.0.1"
    assert deprecations[0].description == "Now using version 0.0.2"


# Generated at 2022-06-21 11:50:09.276733
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    text = '''ValueError
        A description of what might raise ValueError'''
    assert(section.parse(text) == (DocstringRaises(['raises', 'ValueError'], 'A description of what might raise ValueError', 'ValueError'),))
    text2 = '''
        A description of what might raise ValueError'''
    assert(section.parse(text2) == (DocstringRaises(['raises'], 'A description of what might raise ValueError', None),))

# Generated at 2022-06-21 11:50:20.315547
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # prepare test files
    import pytest
    import tempfile
    import os
    import sys
    import shutil
    from pathlib import Path
    from sphinx.util.pycompat import execfile_

    def test_NumpydocParser_files_path():
        return Path(__file__).parent / "test_files"

    def mk_temp_dir():
        tempdir = tempfile.mkdtemp(prefix="doxygen-")
        return Path(tempdir)

    def setup_module(module):
        module.tmpdir = mk_temp_dir()

    def teardown_module(module):
        shutil.rmtree(module.tmpdir)

    def setup_function(function):
        function.old_syspath = sys.path[:]

# Generated at 2022-06-21 11:50:32.852094
# Unit test for constructor of class _KVSection
def test__KVSection():
    rais = _KVSection("Raises", "raises")
    text = "ValueError\n    A description of what might raise ValueError\n"
    ret = _clean_str(text)
    assert ret == "A description of what might raise ValueError"
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        assert _clean_str(value) == "A description of what might raise ValueError"

# Generated at 2022-06-21 11:50:39.890058
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    """
    .. deprecated:: 0.1.0
        Deprecation message.
    """
    print("TEST: DeprecationSection")
    deprec = DeprecationSection('deprecated', 'deprecation')
    text = """.. deprecated:: 0.1.0
        Deprecation message.
    """
    dep_mes = deprec.parse(inspect.cleandoc(text))
    for dep in dep_mes:
        print(dep.version)



# Generated at 2022-06-21 11:50:42.454337
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert a.title == "Returns"
    assert a.key == "returns"
    return a


# Generated at 2022-06-21 11:51:09.804612
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("Deprecated", "deprecated")
    assert section.title == "Deprecated"
    assert section.key == "deprecated"

# Generated at 2022-06-21 11:51:14.357262
# Unit test for constructor of class _KVSection
def test__KVSection():
    titles = "Arguments"
    keys = "Args"

    a = _KVSection(titles, keys)
    assert isinstance(a, _KVSection)
    assert a.title == titles
    assert a.key == keys


# Generated at 2022-06-21 11:51:15.361125
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-21 11:51:18.495572
# Unit test for constructor of class ParamSection
def test_ParamSection():
    s=ParamSection('Parameters', 'param')
    assert s.title == 'Parameters'
    assert s.key == 'param'
    assert s.title_pattern == r'^(Parameters)\s*?\n----\s*$'


# Generated at 2022-06-21 11:51:26.507186
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = """
    Returns a list of attribute names.

    :param arg1:
        The arg1

    :param arg2: The arg2

    :returns: a list of attribute names
    """
    r = NumpydocParser().parse(text)
    assert r.short_description == "Returns a list of attribute names."
    assert r.long_description == "The arg1\n\nThe arg2"
    assert r.meta[0].description == "The arg1"
    assert r.meta[1].description == "The arg2"
    assert r.meta[2].description == "a list of attribute names"

# Generated at 2022-06-21 11:51:29.543749
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields","yields")
    assert ys.title == "Yields"
    assert ys.key == "yields"
    assert ys.is_generator == True

# Generated at 2022-06-21 11:51:33.249202
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section('section', 'section')
    assert s.parse('first line \nsecond line') == DocstringMeta(['section'], description='first line\nsecond line')
    assert s.parse('') == DocstringMeta(['section'], description='')


# Generated at 2022-06-21 11:51:45.149452
# Unit test for function parse
def test_parse():
    docstr = """
    This function does something.

    :param foo: A string
    :type foo: str
    :param bar: An int
    :type bar: int
    :param spaz: A bool

    :raises TypeError: if `foo` is not a string or `bar` is not an int
    :raises ValueError: if `spaz` is not a bool
    """

# Generated at 2022-06-21 11:51:48.230466
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    t = DeprecationSection("Deprecation Warning", "deprecation")
    assert t.title_pattern == r"^\.\.\s*(Deprecation Warning)\s*::"

# Generated at 2022-06-21 11:51:50.458535
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"



# Generated at 2022-06-21 11:52:43.030291
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = Section('test', 'test')
    parser = NumpydocParser()

    assert parser.sections.get('test', None) is None
    assert parser.parse('.. test::\n\n    ').meta == []

    parser.add_section(section)

    assert parser.parse('.. test::\n    test\n\n    ').meta == [DocstringMeta(['test'], 'test')]

# Generated at 2022-06-21 11:52:48.371333
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    for i in range(4):
        # Create test strings
        text = []
        for j in range(i):
            text += ["line " + str(j) + "\n"]
        text = "".join(text)
        # Test parse
        r = section.parse(text)
        p = next(r)
        assert p.args == ["deprecation"]

# Generated at 2022-06-21 11:52:50.292926
# Unit test for constructor of class Section
def test_Section():
    assert Section("Name", "name").title == "Name"
    assert Section("Name", "name").key == "name"


# Generated at 2022-06-21 11:52:51.516217
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields")

# Generated at 2022-06-21 11:52:53.698991
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_numpydocparser = NumpydocParser()
    assert type(test_numpydocparser) == NumpydocParser


# Generated at 2022-06-21 11:52:59.996764
# Unit test for constructor of class _KVSection
def test__KVSection():
    """Tests for the _KVSection class.

    :return: True if all tests pass, False if at least one fails.
    """

    # Test regex for the section title
    section_title_test_re_str = _KVSection("key", "value").title_pattern
    m = re.match(section_title_test_re_str, "key\n---")
    assert m.groups()[0] == "key"

    # Test incorrect regex for the section title
    m = re.search("bla", "key\n---")
    assert m is None

    # Test regex for key-value pairs
    section_key_value_test_re_str = r"[^\s].*$"
    m = re.match(section_key_value_test_re_str, "key")

# Generated at 2022-06-21 11:53:06.293788
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    example_sections = [
        Section("Parameters", "param"),
        Section("Args", "param"),
        Section("Raises", "raises"),
        Section("Return", "returns"),
        Section("Returns", "returns"),
        Section("Notes", "notes")
    ]
    parser = NumpydocParser(example_sections)
    assert parser.sections == {s.title: s for s in example_sections}

# Generated at 2022-06-21 11:53:09.817583
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == r"^title\s*?\n-*\s*$"



# Generated at 2022-06-21 11:53:11.765525
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    subsection = RaisesSection("Raises", "raises")
    if subsection.title != "Raises":
        raise AssertionError()

# Generated at 2022-06-21 11:53:17.969849
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test = YieldsSection("Yields","yields")
    assert (test.title == "Yields")
    assert (test.key == "yields")
    assert (test.title_pattern == r"^\.\.\s*(Yields)\s*::")
    assert (test.is_generator == True)