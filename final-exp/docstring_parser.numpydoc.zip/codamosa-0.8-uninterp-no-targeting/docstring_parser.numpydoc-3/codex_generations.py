

# Generated at 2022-06-21 11:45:22.930647
# Unit test for constructor of class _KVSection
def test__KVSection():
    args = "Parameters"
    key = "parameters"
    sec = _KVSection(title=args, key=key)
    assert sec.title == "Parameters"
    assert sec.key == "parameters"
    assert sec.title_pattern == "^(Parameters)\s*?\n-*$"


# Generated at 2022-06-21 11:45:23.808649
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection("hi","hello")

# Generated at 2022-06-21 11:45:24.764450
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("Examples", "examples")

# Generated at 2022-06-21 11:45:27.365237
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test = NumpydocParser()
    assert test.sections['Returns'].title == 'Returns'
    assert test.sections['Returns'].key == 'returns'



# Generated at 2022-06-21 11:45:34.495392
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters:", "param").parse("arg_name\n\targ_description") == [DocstringParam(args=['param', 'arg_name'], description='arg_description', arg_name='arg_name', type_name=None, is_optional=False, default=None)]
    assert ParamSection("Parameters:", "param").parse("arg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines") == [DocstringParam(args=['param', 'arg_2'], description='descriptions can also span...\n... multiple lines', arg_name='arg_2', type_name='type', is_optional=True, default=None)]

# Generated at 2022-06-21 11:45:36.340340
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection(title='Raises',key='raises')
    if a is not None:
        print(a)


# Generated at 2022-06-21 11:45:42.017757
# Unit test for function parse
def test_parse():
    """
    Test parse function
    """
    test_text = """test func
    Params
    ------
    input : str
        It is a test
    Raises
    ------
    ValueError
        If input is non-string
    Returns
    -------
    int
        The number of characters in the input string
    Warnings
    --------
    This is a test warning
    """
    result = parse(test_text)
    assert len(result.meta) == 4
    assert result.meta[0].args == ['param', 'input']
    assert result.meta[1].args == ['raises', 'ValueError']
    assert result.meta[2].args == ['returns']
    assert result.meta[3].args == ['warnings']

# Generated at 2022-06-21 11:45:45.147772
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_cases = [
        '',
        'a',
        'abcd efg',
        'abcd efg ',
        'abcd efg \n',
        'abcd efg \n\n'
    ]
    for docstring in test_cases:
        doc = parse(docstring)
        assert doc.short_description == docstring
        assert doc.long_description is None



# Generated at 2022-06-21 11:45:51.082832
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        short description
        Longer description. This can span multiple lines.

        Parameters
        ----------
        fn : str or list of str or callable
            Path to data file, or list of files.
            Files must contain two columns, the last being
            interpreted as temperature values.
            Alternatively, a function returning a numpy
            array with the same format can be given.
        tmin : float, optional
            Minimum temperature.
        tmax : float, optional
            Maximum temperature.
        random_state : int or RandomState instance, optional
            Controls random number generation.

        Returns
        -------
        csvfile : csvfile object
            An object representing the csv file.
        """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-21 11:45:51.920338
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    pass

# Generated at 2022-06-21 11:45:58.069351
# Unit test for method parse of class Section
def test_Section_parse():
    class EmptySection(Section):
        def __init__(self):
            super().__init__("", "")
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            pass

    es = EmptySection()
    assert es.parse("") == []



# Generated at 2022-06-21 11:46:00.065954
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields").is_generator == True
    return


# Generated at 2022-06-21 11:46:06.807137
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Kaka", "kaka")
    text = inspect.cleandoc("""
        kaka1
            bla bla bla bla
        kaka2
            bla bla bla bla
    """)
    print(text)
    r = s.parse(text)
    assert r is not None
    print(r)



# Generated at 2022-06-21 11:46:11.749855
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "Key"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^(Title)\s*?\n-*\s*$"


# Generated at 2022-06-21 11:46:18.080171
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_obj = YieldsSection("Yields","yields")
    assert yield_obj.is_generator == True
    return_obj = ReturnsSection("Returns","returns")
    assert return_obj.is_generator == False
    assert yield_obj.title == "Yields"
    assert return_obj.title == "Returns"


# Generated at 2022-06-21 11:46:21.301866
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises","raises")
    assert rs._parse_item("ValueError", "A description") == DocstringRaises(args=["raises","ValueError"], description="A description", type_name="ValueError")


# Generated at 2022-06-21 11:46:30.722344
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section1 = Section("Parameters", "param")
    section2 = Section("TestParameters", "test_param")
    section3 = Section("TestParameters", "test_param2")
    
    parser = NumpydocParser()
    
    parser.add_section(section1)
    parser.add_section(section2)
    parser.add_section(section3)
    
    sections = parser.sections
    assert sections["Parameters"].title == "Parameters"
    assert sections["Parameters"].key == "param"
    assert sections["TestParameters"].title == "TestParameters"
    assert sections["TestParameters"].key == "test_param2"
    
    
    
    
    
if __name__ == "__main__":
    test_NumpydocParser_add_section()

# Generated at 2022-06-21 11:46:41.324693
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text1 = """\
.. deprecated:: 1.2.1
    This function is deprecated, use ``fun_name("")`` instead."""
    text2 = """\
.. deprecated::
    This function is deprecated, use ``fun_name("")`` instead."""
    text3 = """\
.. deprecated:: 1.2.1
    This function is deprecated, use ``fun_name("")`` instead.

    Another paragraph here."""
    text4 = """\
.. deprecated:: 1.2.1
    This function is deprecated, use ``fun_name("")`` instead.

    Another paragraph here.

    And another paragraph here."""
    dep1 = next(DeprecationSection("deprecated", "deprecation").parse(text1))
    dep2 = next(DeprecationSection("deprecated", "deprecation").parse(text2))

# Generated at 2022-06-21 11:46:42.555134
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection("Yields", "yields")

# Generated at 2022-06-21 11:46:43.597738
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    pass



# Generated at 2022-06-21 11:47:00.956306
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection(title='Parameters', key='param')
    string = (
        "arg_name\n"
        "\targ_description\n"
        "arg_2 : type, optional\n"
        "\tdescriptions can also span...\n"
        "\t... multiple lines\n"
    )
    b = a.parse(string)
    c = [_ for _ in b]
    d = c[0]
    assert d.args == ['param', 'arg_name']
    assert d.description == 'arg_description'
    assert d.arg_name == 'arg_name'
    assert d.type_name == 'type'
    assert d.is_optional is True
    assert d.default == None

# Generated at 2022-06-21 11:47:04.575685
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    test_Section = Section(title, key)
    assert test_Section.title == "Title"
    assert test_Section.key == "key"


# Generated at 2022-06-21 11:47:07.821715
# Unit test for method parse of class Section
def test_Section_parse():
    sec=Section("aa","bb")
    assert sec.title=="aa", "title is not set correctly"
    assert sec.key == "bb", "key is not set correctly"
    assert sec.parse("text")==[DocstringMeta(['bb'], description='text')], "parse method is not implemented correctly"

# Generated at 2022-06-21 11:47:13.228897
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = """RuntimeError
        A description of what might raise RuntimeError"""
    rs = RaisesSection("Raises", "raises")

    expected_result = DocstringRaises(
            args=["raises", "RuntimeError"],
            description="A description of what might raise RuntimeError",
            type_name="RuntimeError",
        )

    assert(list(rs.parse(text))[0] == expected_result)


if __name__ == "__main__":
    test_RaisesSection()

# Generated at 2022-06-21 11:47:21.977229
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("Deprecated", "deprecation"))
    parsed = parser.parse('''
        .. deprecated:: 0.0

            This function is deprecated.
    ''')
    assert len(parsed.meta) == 1
    dep = parsed.meta[0]
    assert isinstance(dep, DocstringDeprecated)
    assert dep.version == '0.0'
    assert dep.description == 'This function is deprecated.'

# Generated at 2022-06-21 11:47:33.778734
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Test the function when the input is None, or the input is empty.
    assert(NumpydocParser().parse("") == Docstring())
    # Test the function when the input is an empty docstring
    assert(NumpydocParser().parse("") == Docstring())
    # Test the function when the input is a docstring with a short description
    assert(NumpydocParser().parse("This is a docstring.").short_description == "This is a docstring.")
    # Test the function when the input is a docstring with a short description and a long description
    assert(NumpydocParser().parse("This is a docstring.\nIt has two lines.").long_description == "It has two lines.")
    # Test the function when the input is a docstring with a short description, a long description and a section

# Generated at 2022-06-21 11:47:46.304689
# Unit test for function parse
def test_parse():
    """Function test example."""
    def _parse_test_cases(run_case) -> T.Tuple[str, Docstring]:
        # pylint: disable=unused-variable
        text = """
        A short summary


        A longer description that may include math
        using $\LaTeX$ equations:

        .. math::

            f(a) = a + 1
            E(t) = \\int^t f(a)

        :param param1: a parameter
            that spans multiple lines
        :param param2: a parameter

            with a blank line in between
        :type param1: type
        :type param2: type
        :returns:
            description of return value

        :raises RuntimeError: if something bad happened
        :raises ImportError: if something else bad happened
        """

# Generated at 2022-06-21 11:47:58.202098
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import Docstring, DocstringMeta, DocstringParam
    from .common import DocstringRaises, DocstringReturns, DocstringDeprecated

    # 1. Test whether there is a title and a description
    text = """
    A function with title and description
    ===========
    This function does some dummy things.
    """
    assert NumpydocParser().parse(text) == Docstring(
        short_description="A function with title and description",
        long_description="This function does some dummy things.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # 2. Test whether the parser can handle a docstring without any title and
    #    meta section
    text = """
    This function does some dummy things.
    """
    assert Numpyd

# Generated at 2022-06-21 11:48:02.048100
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	test = DeprecationSection("title", "key")
	testText = test.title
	trueText = "title"
	result = testText == trueText
	assert result


# Generated at 2022-06-21 11:48:06.617694
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert not parser.sections.get("test")
    parser.add_section(Section("test", "test"))
    assert parser.sections.get("test")

# Generated at 2022-06-21 11:48:21.240431
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns","returns")
    ReturnsSection("Return","returns")
    YieldsSection("Yields","yields")
    YieldsSection("Yield","yields")


# Generated at 2022-06-21 11:48:26.000279
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "0.1.0\n" \
           "\n" \
           "A method that soon will be deprecated."
    parser = NumpydocParser()
    section = DeprecationSection("deprecated", "deprecation")
    deprecated = list(section.parse(text))[0]
    assert deprecated.version == "0.1.0"
    assert deprecated.description == "A method that soon will be deprecated."

# Generated at 2022-06-21 11:48:32.250837
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = YieldsSection("Yields", "yields")
    assert parser.is_generator is True
    assert parser.title == "Yields"
    assert parser.key == "yields"
    assert parser.title_pattern == "^\.\.\s*(Yields)\s*::"
    assert parser._parse_item("a", "b") == DocstringReturns(
        args=['yields'],
        description='b',
        type_name=None,
        is_generator=True,
        return_name='a',
    )

# Generated at 2022-06-21 11:48:41.189861
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:48:46.981760
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    parser.add_section(Section('Parameters', 'parameters'))
    assert parser.sections['Parameters'].title == 'Parameters'
    assert parser.sections['Parameters'].key == 'parameters'
    assert parser.sections['Parameters'].title_pattern == r'^(Parameters)\s*?\n{}\s*$'


# Generated at 2022-06-21 11:48:49.358903
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [Section("Params", "param"), ParamSection("Parameters", "param")]
    NumpydocParser(sections)


# Generated at 2022-06-21 11:49:00.134682
# Unit test for function parse
def test_parse():
    docstring = """
    This is a docstring
    This is a long description.

    This is a long description line 2.


    Parameters
    ----------
    arg : type
        arg description
    kwarg : type, optional
        kwarg description, default: default_description

    Returns
    -------
    returns : type
        returns description

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    output = parse(docstring)
    assert output.short_description == "This is a docstring"
    assert output.long_description == "This is a long description.\n\nThis is a long description line 2."
    assert len(output.meta) == 3
    assert output.meta[0].args == ['param', 'arg']
    assert output.meta[0].kwargs

# Generated at 2022-06-21 11:49:01.617525
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == 30
    assert parser.sections['Parameters'].title == 'Parameters'

# Generated at 2022-06-21 11:49:03.275926
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [
        Section("Parameters", "param")
    ]
    parser = NumpydocParser(sections)

# Generated at 2022-06-21 11:49:12.851460
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep = DeprecationSection("deprecation", "deprecation")
    docstring = dep.parse("1.0.0\nMy deprecation message")
    assert docstring.args[0] == "deprecation"
    assert docstring.description == "My deprecation message"
    assert docstring.version == "1.0.0"

    docstring = dep.parse("My deprecation message")
    assert docstring.args[0] == "deprecation"
    assert docstring.description == "My deprecation message"
    assert docstring.version is None


# Generated at 2022-06-21 11:49:33.320076
# Unit test for function parse
def test_parse():
    """Test the parse method."""
    s = """
    A docstring.

    :param x: Parameter description goes here.
    """

    assert len(parse(s).meta) == 1

    s = """
    A docstring.

    Parameters
    ----------

    :param x: Parameter description goes here.
    """

    assert len(parse(s).meta) == 1

    # numpydoc deprecated section
    s = """
    A docstring.

    .. deprecated:: 3.4a
        Some text.
    """

    assert len(parse(s).meta) == 1
    assert parse(s).meta[0].args == ["deprecation"]

    # section not found

# Generated at 2022-06-21 11:49:41.788408
# Unit test for method parse of class Section
def test_Section_parse():
    # Defining the parameters
    title = "Parameters"
    key = "param"
    text = '''arg_name
                arg_description
            arg_2 : type, optional
                descriptions can also span...
                ... multiple lines'''

    # Calling the method with the defined parameters
    assert(parse(text).long_description == None)
    assert(parse(text).short_description == None)
    assert(parse(text).blank_after_short_description == False)
    assert(parse(text).blank_after_long_description == True)

# Generated at 2022-06-21 11:49:53.948696
# Unit test for constructor of class Section
def test_Section():
    titles = ["Parameters", "Params", "Arguments", "Args", "Other Parameters", "Other Params", "Other Arguments", "Other Args", "Receives", "Receive", "Raises", "Raise", "Warns", "Warn", "Attributes", "Attribute", "Returns", "Return", "Yields", "Yield", "Examples", "Example", "Warnings", "Warning", "See Also", "Related", "Notes", "Note", "References", "Reference", "deprecated"]

# Generated at 2022-06-21 11:49:55.479314
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
	NumpydocParser()


# Generated at 2022-06-21 11:50:01.197381
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    doc_string = "arg1\nSome description\narg2 : type\nMultiple lines description"
    parser = NumpydocParser()
    parser._KVSection.parse(parser, doc_string)
    assert doc_string == "arg1\nSome description\narg2 : type\nMultiple lines description"


# Generated at 2022-06-21 11:50:03.538003
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # RaisesSection without any argument
    assert RaisesSection('Raises', 'raises') is not None


# Generated at 2022-06-21 11:50:05.233105
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters', 'param') is not None


# Generated at 2022-06-21 11:50:09.608804
# Unit test for function parse
def test_parse():
    test_str = """
    '''
    
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    
    """
    assert parse(test_str)


# Generated at 2022-06-21 11:50:13.068678
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection('Raises', 'raises')
    assert raises_section.key == 'raises'
    assert raises_section.title == 'Raises'
    assert raises_section.title_pattern == r'^(Raises)\s*?\n---\s*$'

# Generated at 2022-06-21 11:50:17.689561
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    ds = DeprecationSection("Deprecation Warning", "deprecation")
    text = "0.1\nA description of this deprecated method\n"
    meta = ds.parse(text)
    assert meta.description == "A description of this deprecated method"


# Generated at 2022-06-21 11:50:38.590391
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    doc = DeprecationSection("", "").parse("2.0\n\nThe description")
    assert len(list(doc)) == 1
    # Check that the version when present is OK
    assert list(doc)[0].version == "2.0"
    assert list(doc)[0].description.strip() == "The description"
    # Check that the version when not present we have None
    doc = DeprecationSection("", "").parse("\n\nThe description")
    assert list(doc)[0].version == None
    assert list(doc)[0].description.strip() == "The description"

if __name__ == "__main__":
    pass

# Generated at 2022-06-21 11:50:40.571674
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("section","section")
    text = "\nsection\n------"
    assert list(section.parse(text)) == [DocstringMeta(["section"], description="")]


# Generated at 2022-06-21 11:50:41.904091
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator == True

# Generated at 2022-06-21 11:50:52.723269
# Unit test for function parse
def test_parse():
    s = """
    Short description.

    Long description.

    Parameters:
    -----------
    x : int
        blah blah blah

    Returns:
    --------
    x : int
        blah blah blah
    """
    doc = parse(s)
    assert doc.short_description == 'Short description.'
    assert doc.long_description == 'Long description.'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "x"]
    assert doc.meta[1].args == ["returns"]


# Generated at 2022-06-21 11:50:55.081229
# Unit test for constructor of class Section
def test_Section():
    new_section = Section('Test', 'test')
    print(new_section.title)
    print(new_section.key)


# Generated at 2022-06-21 11:50:57.863150
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds = DeprecationSection("Deprecated", "deprecation")
    assert ds.title == "Deprecated"
    assert ds.key == "deprecation"



# Generated at 2022-06-21 11:51:00.655635
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raiseSection = RaisesSection("Raises", "raises")
    assert(raiseSection.title is "Raises")
    assert(raiseSection.key is "raises")


# Generated at 2022-06-21 11:51:04.293539
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = _KVSection(title="par", key="p")
    text = """key
        value
    key2 : type
        values can also span...
        ... multiple lines"""
    print(s.parse(text))


# Generated at 2022-06-21 11:51:14.819188
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
            arg_name
                arg_description
            arg_2 : type, optional
                descriptions can also span...
                ... multiple lines
            '''
    text = inspect.cleandoc(text)
    section = _KVSection("Parameters","param")
    result = section.parse(text)
    expected = DocstringParam(
            args=['param', 'arg_name'],
            description=_clean_str("arg_description"),
            arg_name='arg_name',
            type_name=None,
            is_optional=False,
            default=None
        )
    assert result == expected

# Generated at 2022-06-21 11:51:24.711935
# Unit test for constructor of class ParamSection
def test_ParamSection():
    print("test_ParamSection:")
    # Arrange
    param = ParamSection("Parameters", "param")
    # Act
    result_title = param.title
    result_key = param.key
    result_title_pattern = param.title_pattern
    result_parse = param.parse(
        text="arg_name\n    arg_description\n\narg_2 : type, optional")
    # Assert
    assert result_title_pattern == r"^Parameters\s*?\n-{9}\s*$"
    assert result_title == "Parameters"
    assert result_key == "param"
    for item in result_parse:
        val = item.description
        assert val == "arg_description" or val == "arg_description\n\n"



# Generated at 2022-06-21 11:51:51.841324
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Test", "test"))
    return parser


# Generated at 2022-06-21 11:52:02.916545
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # normal case
    section = _SphinxSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"

    # numpy-style title
    section = _SphinxSection("Title", "key")
    assert section.title == "Title"
    assert section.key == "key"

    # numpy-style title
    section = _SphinxSection("Title", "key")
    assert section.title == "Title"
    assert section.key == "key"

    # title with trailing space
    section = _SphinxSection("Title ", "key")
    assert section.title == "Title"
    assert section.key == "key"


# Generated at 2022-06-21 11:52:04.676417
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection(title='Warning', key='warnings').title == 'Warning'


# Generated at 2022-06-21 11:52:11.634109
# Unit test for method parse of class Section
def test_Section_parse():
    docvalue = """
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    parser = NumpydocParser()
    docvalue = parser.parse(docvalue)
    assert type(docvalue) is Docstring
    assert docvalue.short_description == 'None'
    assert docvalue.long_description is None
    assert docvalue.blank_after_short_description == False
    assert docvalue.blank_after_long_description == False
    assert docvalue.meta[0].description == 'arg_description'
    assert docvalue.meta[1].description == 'descriptions can also span...\n... multiple lines'
   

# Generated at 2022-06-21 11:52:20.217375
# Unit test for constructor of class Section
def test_Section():
    expected_title = "Parameters"
    expected_key = "param"

    section = Section(expected_title, expected_key)
    assert section.title == expected_title
    assert section.key == expected_key
    assert section.title_pattern == "^(Parameters)\s*?\n----------\s*$"
    assert section.parse("arg_description") == [DocstringMeta(['param'], description='arg_description')]


# Generated at 2022-06-21 11:52:26.500453
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    x = RaisesSection("Raises", "raises")
    assert x.title == "Raises"
    assert x.key == "raises"
    assert x.title_pattern == "^Raises\\s*?\n{3}$"
    assert x._parse_item("item_1", "value1 value2")
    assert x._parse_item("item_2", "value1 value2")
    assert x._parse_item("item_3", "")
    assert x.parse("key\n    value")


# Generated at 2022-06-21 11:52:38.849579
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Default test
    numpydoc_parser_default = NumpydocParser()
    assert(dict == type(numpydoc_parser_default.sections))
    assert(len(numpydoc_parser_default.sections) == 28)
    for section in numpydoc_parser_default.sections:
        assert(str == type(numpydoc_parser_default.sections[section].title))
        assert(str == type(numpydoc_parser_default.sections[section].key))
    assert(bool == type(numpydoc_parser_default._setup()))

    # Custom test
    numpydoc_parser_custom = NumpydocParser(sections=[Section('Parameter', 'param')])
    assert(len(numpydoc_parser_custom.sections) == 1)

# Generated at 2022-06-21 11:52:39.903112
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("param","title") is not None

#Unit test for constructor of class RaisesSection

# Generated at 2022-06-21 11:52:45.905769
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import os, sys, unittest
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "py2rb.py")
    with open(path) as f:
        docstr = f.read()
    doc = NumpydocParser().parse(docstr)
    assert doc.short_description == "Convert Python to Ruby using 2to3 and sed."
    assert doc.long_description == "This script converts Python 2 code to Ruby 2.3\nusing the 2to3 Python library and a set of sed scripts."
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 6
    assert doc.meta[0].args == ['param', 'python_source']

# Generated at 2022-06-21 11:52:48.722750
# Unit test for method parse of class Section
def test_Section_parse():
    a = Section("Example", "examples")
    dict = {"Example" : a}
    new_text = "Example1"
    dict["Example"].parse(new_text)


# Generated at 2022-06-21 11:53:39.300120
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    import numpydoc
    numpydoc.NumpydocParser()

# Generated at 2022-06-21 11:53:40.758908
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()

# Generated at 2022-06-21 11:53:49.167875
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("t", "title")
    text = '''a
        a description
    b : int
        b description
    '''
    docstring_meta = section.parse(text)
    docstring_meta_list = list(docstring_meta)
    assert len(docstring_meta_list) == 2
    assert docstring_meta_list[0].description == "a description"
    assert docstring_meta_list[1].description == "b description"


# Generated at 2022-06-21 11:53:52.616963
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_parser = RaisesSection("Raises", "raises")
    assert raises_parser.key == "raises"
    assert raises_parser.title == "Raises"
    assert raises_parser.title_pattern == r"^(Raises)\s*?\n\-*Raises\s*$"

# Generated at 2022-06-21 11:54:04.166368
# Unit test for method parse of class Section
def test_Section_parse():
    assert len(Section("Section", "tag").parse("")) == 0
    assert list(Section("Section", "tag").parse("\n"))[0].args == ["tag"]
    assert list(Section("Section", "tag").parse("\n\n"))[0].args == ["tag"]
    assert (
        list(Section("Section", "tag").parse("\n\n\n"))[0].description == ""
    )
    assert list(Section("Section", "tag").parse("text\n"))[0].description == "text"
    assert (
        list(Section("Section", "tag").parse("text\n\n"))[0].description == "text"
    )
    assert (
        list(Section("Section", "tag").parse("text\n\n\n"))[0].description == "text"
    )



# Generated at 2022-06-21 11:54:09.796882
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    #deprecation = DocstringDeprecated(args=[], description='', version='')
    parsed_string = DeprecationSection("", "")
    parsed_string1 = DeprecationSection("deprecated", "DeprecationWarning")
    assert parsed_string.parse("") == ""
    assert parsed_string.parse("Hello World") == "Hello World"
    assert parsed_string.parse("DeprecationWarning 1") == "DeprecationWarning 1"
    assert parsed_string1.parse("Deprecated since version 1.0") == "Deprecated since version 1.0"

# Generated at 2022-06-21 11:54:16.520906
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    param1
    \tparam1_desc

    param2 : int
    \tparam2_desc
    """
    text = inspect.cleandoc(text)
    section = ParamSection("Parameters", "param")
    meta_list = list(
        section.parse(text)
    )
    assert meta_list[0].args == ['param', 'param1']
    assert meta_list[0].description == 'param1_desc'
    assert meta_list[1].args == ['param', 'param2']
    assert meta_list[1].description == 'param2_desc'



# Generated at 2022-06-21 11:54:22.201024
# Unit test for function parse
def test_parse():
    def foo(*args, **kwargs):
        """\
        Some function.

        Parameters
        ----------

        thing : type
            If it exists, this is it.
        hello : dict
            This is a dict parameter.
        bar
            This is bar :param bar: parameter.
        """

    assert parse(foo.__doc__)

# Generated at 2022-06-21 11:54:23.368200
# Unit test for constructor of class _KVSection
def test__KVSection():
    dummy = _KVSection("", "")
    assert not hasattr(dummy, 'title_patter')


# Generated at 2022-06-21 11:54:26.348458
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    with pytest.raises(NotImplementedError):
        title = "title"
        key = "key"
        _SphinxSection(title, key)