

# Generated at 2022-06-21 11:45:20.543533
# Unit test for function parse
def test_parse():
    """Test of the main function parse"""


# Generated at 2022-06-21 11:45:24.585875
# Unit test for constructor of class Section
def test_Section():
    title = "Test title"
    key = "Test key"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == "^(" + title + ")\s*?\n{}\s*$".format("-" * len(title))

# Generated at 2022-06-21 11:45:34.121473
# Unit test for constructor of class ParamSection
def test_ParamSection():
    kv_pattern = re.compile(r".*?:.*")
    kv_pattern_optional = re.compile(r".*?:.*, optional")
    kv_pattern_optional_parens = re.compile(r".*?:.*\(optional\)")
    kv_pattern_default = re.compile(r".*?:.*Default(?: is | = |: |s to |)\s*.*")
    text1 = 'arg_name\n' +\
            '    arg_description\n' +\
            'arg_2 : type, optional\n' +\
            '    descriptions can also span...\n' +\
            '    ... multiple lines'
    text2 = 'arg_name\n' +\
            '    arg_description'

# Generated at 2022-06-21 11:45:36.296623
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert isinstance(ReturnsSection("Returns", "returns"), ReturnsSection)
    assert isinstance(ReturnsSection("Return", "returns"), ReturnsSection)


# Generated at 2022-06-21 11:45:39.627134
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("section_title","section_key")
    assert section.title == "section_title"
    assert section.key == "section_key"
    assert section.title_pattern == "^\\.\\.\\s*(section_title)\\s*::"


# Generated at 2022-06-21 11:45:44.901602
# Unit test for method parse of class Section
def test_Section_parse():
    def doc_str(text):
        return inspect.cleandoc(text)

    def test_Section_parse_simple(title):
        code = f"""
        {title}
            Something
        """
        res = [DocstringMeta([title], description="Something")]
        assert Section(title, title).parse(doc_str(code)) == res
        code = f"""
        {title}
            Something
            Something
        """
        res = [DocstringMeta([title], description="Something\nSomething")]
        assert Section(title, title).parse(doc_str(code)) == res

    def test_Section_parse_multiple(title):
        code = f"""
        {title}
            Something
            Something
        {title}
            Something
            Something
        """

# Generated at 2022-06-21 11:45:57.146680
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """
        foo(bar, baz)
        function foo

        Parameters
        ----------
        bar : string
            param_bar (default: 'baz')
        baz : list
            param_baz (default: None)

        Returns
        -------
        bar_baz
            bar_baz

        Raises
        ------
        ValueError
            raise_baz

        Examples
        --------
        >>> foo(bar, baz)
        foobarbaz
        """

# Generated at 2022-06-21 11:46:09.833665
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():    
    np = NumpydocParser()
    # test specifying the known sections

# Generated at 2022-06-21 11:46:12.478003
# Unit test for method parse of class Section
def test_Section_parse():
    assert NumpydocParser().sections["Raises"].parse("ValueError\n not_included")[0].args[1] == "ValueError"

# Generated at 2022-06-21 11:46:23.144778
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    items = '''
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span multiple lines
    '''
    text = inspect.cleandoc(items)
    parser = _KVSection("Parameters", "param")
    meta = list(parser.parse(text))
    meta0 = meta[0]
    assert meta0.args == ['param', 'arg_name']
    assert meta0.arg_name == 'arg_name'
    assert meta0.type_name == None
    assert meta0.is_optional == False
    assert meta0.default == None
    meta1 = meta[1]
    assert meta1.args == ['param', 'arg_2']
    assert meta1.arg_name == 'arg_2'
    assert meta1.type_name == 'type'


# Generated at 2022-06-21 11:46:46.804942
# Unit test for method parse of class Section
def test_Section_parse():
    Section("Parameters", "param").parse("arg_name\n    arg_description")
    Section("Params", "param").parse("arg_name\n    arg_description")
    Section("Arguments", "param").parse("arg_name\n    arg_description")
    Section("Args", "param").parse("arg_name\n    arg_description")
    Section("Other Parameters", "other_param").parse("arg_name\n    arg_description")
    Section("Other Params", "other_param").parse("arg_name\n    arg_description")
    Section("Other Arguments", "other_param").parse("arg_name\n    arg_description")
    Section("Other Args", "other_param").parse("arg_name\n    arg_description")

# Generated at 2022-06-21 11:46:53.162267
# Unit test for method parse of class Section
def test_Section_parse():
    s=Section(title="Testing", key="test")
    text = "Simple testing"
    expected_value = DocstringMeta([s.key], description="Simple testing")
    returned_value = s.parse(text)
    assert next(returned_value) == expected_value

#Unit test for method parse of class ParamSection

# Generated at 2022-06-21 11:46:57.529067
# Unit test for method parse of class Section
def test_Section_parse():
    text = """Parameters
    ----------
    x : float
        The value x"""
    s = Section("Parameters", "param")
    assert s.parse(text) == [["param"], "The value x"]


# Generated at 2022-06-21 11:47:04.295096
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section('Parameters', 'param').parse('') == None
    assert Section('Parameters', 'param').parse('param1') == \
            [DocstringMeta(['param'], description='param1')]
    assert Section('Parameters', 'param').parse('param1\nparam2\nparam3') == \
            [
                DocstringMeta(['param'], description='param1'),
                DocstringMeta(['param'], description='param2'),
                DocstringMeta(['param'], description='param3')
            ]
    assert next(Section('Parameters', 'param').parse('param1\nparam2')) == \
            DocstringMeta(['param'], description='param1')

# Generated at 2022-06-21 11:47:11.788354
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    Parameters
    ----------
    a : int
        a is an integer
    b : float
        b is a float
    """
    section = Section("Parameters", "param")
    docstring_meta_list = list(section.parse(text))
    assert isinstance(docstring_meta_list[0], DocstringMeta)
    assert docstring_meta_list[0].description == "a is an integer"
    assert docstring_meta_list[1].description == "b is a float"
    assert docstring_meta_list[0].args[0] == "param"
    assert docstring_meta_list[1].args[0] == "param"


# Generated at 2022-06-21 11:47:16.898607
# Unit test for method parse of class Section
def test_Section_parse():
    class DummySection(Section):
        pass

    section = DummySection("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == "^(title)\\s*?\\n{4}\\s*$"


# Generated at 2022-06-21 11:47:18.772149
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection(title="Returns", key="returns")


# Generated at 2022-06-21 11:47:23.010269
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection('.. title:: something','key').title_pattern == r'^\.\.\s*(.. title:: something)\s*::'
    assert _SphinxSection('.. title:: something','key')


# Generated at 2022-06-21 11:47:33.065251
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    expected_objects = [
        DocstringMeta(["param", "arg_name"], description="arg_description"),
        DocstringMeta(
            ["param", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            type_name="type",
            is_optional=True,
        ),
    ]
    source = """\
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    actual_objects = ParamSection("Parameters", "param").parse(source)
    test_result = expected_objects == list(actual_objects)
    return test_result


# Generated at 2022-06-21 11:47:35.529983
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("args", "kwargs")
    assert section.title_pattern == r"^\.\.\s*(args)\s*::"


# Generated at 2022-06-21 11:48:03.895189
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    params = ["Yields", "yields"]
    return_doc = YieldsSection(params[0], params[1])
    assert return_doc.title == params[0]
    assert return_doc.key == params[1]

# Generated at 2022-06-21 11:48:07.238209
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator is False
    assert ReturnsSection("Yields", "yields").is_generator is True

# Generated at 2022-06-21 11:48:11.746141
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    .. deprecated:: 1.2.0
        The long_description of deprecation
    """
    depr = NumpydocParser().parse(text)
    assert depr.meta[0].args[0] == 'deprecation'
    assert depr.meta[0].description == 'The long_description of deprecation'
    assert depr.meta[0].version == '1.2.0'

    # Check that the underscore is removed
    text = """
    .. warning::

        We will remove all undocumented classes and methods in a future
        release, including those in private modules.

        If a class or method is not documented, please raise a GitHub issue
        in https://github.com/scikit-learn/scikit-learn/issues.
    """
    warn = NumpydocParser().parse(text)

# Generated at 2022-06-21 11:48:17.203145
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test = _SphinxSection("key", "value")
    assert test.title_pattern == "^\.\.\s*(key)\s*::"
    assert test.parse(".. key::\n    value") == [DocstringMeta(["value"], description=None)]


# Generated at 2022-06-21 11:48:20.616865
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_section = RaisesSection('Raises','raises')

    assert(test_section.title == 'Raises')
    assert(test_section.key == 'raises')


# Generated at 2022-06-21 11:48:26.387047
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    testparser = NumpydocParser()
    testsection = Section("test_section", "test")
    result1 = testparser.parse("""
    test_section
    -----------
    test_key : str
        test_value
    """)
    testparser.add_section(testsection)
    result2 = testparser.parse("""
    test_section
    -----------
    test_key : str
        test_value
    """)
    assert result1.meta == result2.meta

# Generated at 2022-06-21 11:48:29.783681
# Unit test for method parse of class Section
def test_Section_parse():
    with open("test_cases.txt", "r") as f:
        ds = f.read()
        f.close()
    expected = [DocstringParam(["param", "arg1"], description=None)]
    assert(Section("Parameters", "param").parse(ds) == expected)

# Generated at 2022-06-21 11:48:32.337442
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    new_section = Section("Extra", "extra")
    parser = NumpydocParser()
    parser.add_section(new_section)
    assert parser.sections["Extra"] is new_section

# Generated at 2022-06-21 11:48:41.339353
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    string = """
    a : int
        a comment
    b : Optional[int]
        another comment
    """
    parser = _KVSection("", "")
    res = [x.as_dict() for x in parser.parse(string)]

# Generated at 2022-06-21 11:48:44.442684
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section("Parameters","param")
    print(sec1.title)
    print(sec1.title_pattern)
    print(sec1.key)

# Generated at 2022-06-21 11:49:18.421844
# Unit test for function parse
def test_parse():
    expected = [DocstringParam(args=["param", "x"], description="x value",
                               type_name="int", is_optional=True,
                               default="0"),
                DocstringParam(args=["param", "y"], description="y value",
                               type_name="int", is_optional=True,
                               default="0"),
                DocstringReturns(args=["returns"], description="result",
                                 type_name="int"),
                DocstringMeta(args=["see_also"], description="function2"),
                DocstringMeta(args=["deprecation"], description="use function3() instead",
                              version="0.7")]

# Generated at 2022-06-21 11:49:23.008568
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Test with a title of Parameters
    parser = ParamSection("Parameters", "param")
    # Test with a title of Params
    parser = ParamSection("Params", "param")
    # Test with a title of Arguments
    parser = ParamSection("Arguments", "param")
    # Test with a title of Args
    parser = ParamSection("Args", "param")
    # Test with a title of Other Parameters
    parser = ParamSection("Other Parameters", "other_param")
    # Test with a title of Other Params
    parser = ParamSection("Other Params", "other_param")
    # Test with a title of Other Arguments
    parser = ParamSection("Other Arguments", "other_param")
    # Test with a title of Other Args
    parser = ParamSection("Other Args", "other_param")
    # Test with

# Generated at 2022-06-21 11:49:32.110699
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # no type
    p1 = ParamSection("Parameters", "param")
    # with type
    p2 = ParamSection("Params", "other_param")
    # with type, optional
    p3 = ParamSection("Arguments", "receive")
    # with type, optional, space
    p4 = ParamSection("Args", "examples")
    assert p1.title == "Parameters"
    assert p2.title == "Params"
    assert p3.title == "Arguments"
    assert p4.title == "Args"
    assert p1.key == "param"
    assert p2.key == "other_param"
    assert p3.key == "receive"
    assert p4.key == "examples"



# Generated at 2022-06-21 11:49:44.504381
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """

    :return:
    """
    from .common import DocstringParam, DocstringReturns, DocstringRaises, DocstringDeprecated
    p = NumpydocParser()
    db = p.parse("""
    text.

    Parameters
    ----------
    a : int
        Comment for a
    b : string
        Comment for b

    Returns
    -------
    out: int


    Raises
    ------
    KeyError
        When a key error

    """
    )
    assert len(db.meta) == 3
    assert isinstance(db.meta[0], DocstringParam)
    assert isinstance(db.meta[1], DocstringReturns)
    assert isinstance(db.meta[2], DocstringRaises)

    p = NumpydocParser()

# Generated at 2022-06-21 11:49:55.714526
# Unit test for method parse of class Section
def test_Section_parse():
    param_section_object = ParamSection("Parameters", "param")
    param_section_text = """Parameters
    ----------
    arg_name
        arg_description

    arg_2 : type, optional
        ...

    arg_3 : type, optional (optional)
        ...

    arg_4 : type (optional)
        ...

    arg_5 : type, *optional*
        ...

    arg_6 : type, `optional`
        ...

    arg_7 : type, **optional**
        ...

    arg_8 : type, ~~optional~~
        ...
    """


# Generated at 2022-06-21 11:50:00.968941
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    x = DeprecationSection('deprecated', 'deprecation')
    print(x)
    assert x.title == 'deprecated'
    assert x.key == 'deprecation'
    assert x.title_pattern == '^\.\.\\s*(deprecated)\\s*::'


# Generated at 2022-06-21 11:50:10.509412
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv = _KVSection("Parameters", "param")

    text = inspect.cleandoc("""
    a
        b

    c
        d
    """)

    assert list(kv.parse(text)) == [
        DocstringMeta(['param', 'a'], description='b'),
        DocstringMeta(['param', 'c'], description='d')
    ]

    text = inspect.cleandoc("""
    a
        b

    c
    """)

    assert list(kv.parse(text)) == [
        DocstringMeta(['param', 'a'], description='b'),
        DocstringMeta(['param', 'c']),
    ]



# Generated at 2022-06-21 11:50:15.236145
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    # Test init
    s = Section(title, key)
    assert s.title == "title"
    assert s.key == "key"
    # Test title_pattern
    assert s.title_pattern == "^(title)\s*?\n{}\s*$".format("-" * len(title))
    # Test parse
    assert s.parse("") == []
    assert s.parse("None") == [DocstringMeta(["key"], description="None")]


# Generated at 2022-06-21 11:50:20.910953
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("""
    short description

    long description
        also on multiple lines
    """) == Docstring(
        short_description="short description",
        long_description="long description also on multiple lines",
        blank_after_short_description=True,
        blank_after_long_description=True
    )



# Generated at 2022-06-21 11:50:30.391018
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections['Parameters'].title == 'Parameters'
    assert parser.sections['Parameters'].key == 'param'
    assert parser.sections['Raises'].title == 'Raises'
    assert parser.sections['Raises'].key == 'raises'
    assert parser.sections['deprecated'].title == 'deprecated'
    assert parser.sections['deprecated'].key == 'deprecation'
    assert parser.sections['Args'].title == 'Args'
    assert parser.sections['Args'].key == 'param'



# Generated at 2022-06-21 11:50:44.690658
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection('Parameters', 'param')


# Generated at 2022-06-21 11:50:57.360501
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    new_section = Section("Test", "test")
    assert new_section.title == "Test"
    assert new_section.key == "test"
    assert new_section.title_pattern == "^(Test)\s*?\n{}\s*$".format("-" * len("Test"))
    
    # New object of class NumpydocParser
    np_1 = NumpydocParser()
    return_section = ReturnsSection("Returns", "returns")
    #print("1: {}".format(np_1.sections))
    #print("2: {}".format(np_1.sections["Returns"]))
    np_1.add_section(return_section)
    #print("3: {}".format(np_1.sections))
    #print("4: {}".format(np_1.sections["Returns"]

# Generated at 2022-06-21 11:50:58.672915
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection.__init__ != None

# Generated at 2022-06-21 11:51:07.001080
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	section = DeprecationSection("deprecated", "deprecation")
	assert section.title == "deprecated"
	#assert section.key == "deprecation"
	assert section.title_pattern == "^\.\.\\s*(deprecated)\\s*::"
	assert section.parse("0.0.1\nThe comment") == (DocstringDeprecated(args=['deprecation'], description='The comment', version='0.0.1'),)
	assert section.parse("0.1\nThe comment\nSomething") == (DocstringDeprecated(args=['deprecation'], description='The comment\nSomething', version='0.1'),)
	assert section.parse("The comment") == (DocstringDeprecated(args=['deprecation'], description='The comment', version=None),)

# Generated at 2022-06-21 11:51:18.788233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    local_text = (
        "Single line\n"
        "description\n"
        "\n"
        "Multi-line description\n"
        "with an empty line\n"
        "\n"
        "args : int\n"
        "    An integer argument.\n"
        "\n"
        "Returns\n"
        "-------\n"
        "bool\n"
        "    True if successful, False otherwise.\n"
    )

# Generated at 2022-06-21 11:51:20.215223
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_section = RaisesSection("Raises", "raises")
    assert raise_section.titles_re.match("Raises\n-----")

# Generated at 2022-06-21 11:51:25.856701
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_title = "title"
    test_key = "key"
    test_title_pattern = r"^\.\.\s*(title)\s*::"

    my_section = _SphinxSection(test_title, test_key)
    assert test_title == my_section.title
    assert test_key == my_section.key
    assert test_title_pattern == my_section.title_pattern



# Generated at 2022-06-21 11:51:31.838034
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    
    title = 'numpy docstring parser tests'
    key = 'test_numpy_docstring'
    title_pattern = r"^({})\s*?\n{}\s*$".format(title, "-" * len(title))
    section = Section(title = title, key = key)
    
    parser.add_section(section)

    assert parser.sections[title] == section
    assert parser.titles_re.pattern == title_pattern
    

# Generated at 2022-06-21 11:51:34.446161
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # just check
    assert _SphinxSection("Parameters","param").title_pattern == r"^\.\.\s*(Parameters)\s*::"

# Generated at 2022-06-21 11:51:41.252923
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text_1=".. deprecated:: 1.0\n\nThis feature was removed in version 1.0"
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse(text_1)
    expected = [DocstringDeprecated(args=['deprecation'], description='This feature was removed in version 1.0', version='1.0')]
    assert list(result) == expected

# Generated at 2022-06-21 11:51:55.534388
# Unit test for method parse of class Section
def test_Section_parse():
    # test 1
    text = "Parameters\n---------\n\nparam1 : type\n    description\n\n"
    result = list(ParamSection("Parameters","param").parse(text))
    expected = [DocstringParam(args=['param','param1'],description='description',arg_name='param1',type_name='type',is_optional=False,default=None)]
    assert(result == expected)

    # test 2
    text = "Params\n---------\n\nparam1 : type\n    description\n\n"
    result = list(ParamSection("Params", "param").parse(text))
    expected = [DocstringParam(args=['param', 'param1'], description='description', arg_name='param1', type_name='type', is_optional=False, default=None)]
   

# Generated at 2022-06-21 11:52:04.225906
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    This test method is used to test that the output that is generated by the 
    method parse of class DeprecationSection is correct.
    """
    method = DeprecationSection("deprecated", "deprecation")
    text = ".. deprecated:: 1.2\nDeprecation description"
    assert (
        method.parse(text).__next__().description == "Deprecation description"
    ), "Deprecation description doesn't match the input."
    assert (method.parse(text).__next__().version == "1.2"), "Version doesn't match the input."

# Generated at 2022-06-21 11:52:06.332414
# Unit test for constructor of class _KVSection
def test__KVSection():
    parse_section = _KVSection('title', 'key')
    print(parse_section.title,"\n",
          parse_section.title_pattern,"\n",
          parse_section.key,"\n")


# Generated at 2022-06-21 11:52:09.453157
# Unit test for constructor of class Section
def test_Section():
    title = 'test_title'
    key = 'key'
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r'^(test_title)\s*?\n\s*$'



# Generated at 2022-06-21 11:52:17.319276
# Unit test for method parse of class Section
def test_Section_parse():
    # Test for class Section
    sect = Section('Example','Example')
    text = """Example
    -------
    >>> print('Hello World')
    Hello World"""
    result = []
    for e in sect.parse(text):
        result.append(e)
    assert result[0].description == "\n    >>> print('Hello World')\n    Hello World"
    assert result[0].args == ['Example']

# Generated at 2022-06-21 11:52:20.164923
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds = DeprecationSection('deprecated')
    assert ds.title == 'deprecated'
    assert ds.key == 'deprecation'

# Generated at 2022-06-21 11:52:23.164929
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sections = [
        DeprecationSection("deprecated", "deprecation"),
    ]
    assert sections[0].title == "deprecated"
    assert sections[0].key == "deprecation"


# Generated at 2022-06-21 11:52:27.031161
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [
        Section("Test", "test"),
        Section("Unittest", "unittest")
    ]
    NumpydocParser(sections)

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 11:52:29.082579
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("a", "b").title == "a"



# Generated at 2022-06-21 11:52:37.243457
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = inspect.cleandoc(
        """
        key1
            value
        key2
            value2
    """
    )

    def _parse_item(key: str, value: str) -> DocstringMeta:
        return DocstringMeta([key], description=_clean_str(value))

    assert list(_KVSection(None, None).parse(text)) == [
        DocstringMeta(["key1"], description="value"),
        DocstringMeta(["key2"], description="value2"),
    ]

# Generated at 2022-06-21 11:52:58.166114
# Unit test for method parse of class Section
def test_Section_parse():
    # test parse of name and type
    Section_obj = Section("Parameters", "param")
    result = Section_obj.parse("arg_name")
    assert result == [DocstringMeta(["param"], description="arg_name")]

    # test parse of name, type and description
    Section_obj = Section("Parameters", "param")
    result = Section_obj.parse("arg_name \n  arg_description")
    assert result == [DocstringMeta(["param"], description="arg_name \n  arg_description")]


# Generated at 2022-06-21 11:52:59.580908
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser().sections == DEFAULT_SECTIONS

# Generated at 2022-06-21 11:53:04.064456
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert(section.title == "deprecated")
    assert(section.key == "deprecation")
    assert(section.title_pattern == r"^\.\.\s*(deprecated)\s*::")

# Generated at 2022-06-21 11:53:07.030035
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert DEFAULT_SECTIONS == parser.sections
    assert parser.sections is not DEFAULT_SECTIONS


# Generated at 2022-06-21 11:53:13.279963
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    This function tests the class NumpydocParser.

    Parameters
    ----------
    name : str
        some name

    Returns
    -------
    bool : return true or false
    """
    doc = parse(text)
    assert isinstance(doc, Docstring)
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "name"
    assert doc.meta[0].arg_name == "name"
    assert doc.meta[1].type_name == "bool"

# Generated at 2022-06-21 11:53:18.131981
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    title, key = "Yields", "yields"
    yield_sect = YieldsSection(title, key)
    assert yield_sect.title == title
    assert yield_sect.key == key


# Generated at 2022-06-21 11:53:24.779627
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    import json
    deprecationSection = DeprecationSection("Deprecation Warning", "deprecated")
    section = deprecationSection.parse("Deprecated since version 2.3: Use another_function instead")
    assert len(list(section)) == 1
    assert list(section)[0].args == ["deprecated"]
    assert list(section)[0].description == "Use another_function instead"
    assert list(section)[0].version == "2.3"

# Generated at 2022-06-21 11:53:28.982225
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sections = {s.title: s for s in DEFAULT_SECTIONS}
    add_section = Section("New Key", "new_key")
    sections["New Key"] = add_section
    parser =  NumpydocParser()
    assert parser.sections != sections
    parser.add_section(add_section)
    assert parser.sections == sections


# Generated at 2022-06-21 11:53:36.347850
# Unit test for function parse
def test_parse():
    text = """
    First line of function
    Second line of function

    Parameters
    ----------
    a : int
        first parameter
    b : float, optional
        second parameter
    """

    ds = parse(text)
    assert ds.short_description == "First line of function"
    assert ds.blank_after_short_description == True
    assert ds.long_description == "Second line of function"
    assert ds.blank_after_long_description == False
    assert len(ds.meta) == 1
    assert len(ds.meta[0].args) == 2
    assert ds.meta[0].args[0] == "param"
    assert ds.meta[0].args[1] == "a"
    assert ds.meta[0].description == "first parameter"
    assert len

# Generated at 2022-06-21 11:53:41.607297
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section_instance = _SphinxSection('Title','Key')
    assert section_instance.title == 'Title'
    assert section_instance.key == 'Key'
    assert section_instance.title_pattern == '^\.\.\\s*(Title)\\s*::'
    assert section_instance.parse('Stuff') is None


# Generated at 2022-06-21 11:53:56.471012
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse('') == Docstring()



# Generated at 2022-06-21 11:54:01.064598
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    assert np.sections.keys() != {'Test_Section_1'}
    np.add_section(Section('Test_Section_1', 'test_section_key_1'))
    assert np.sections.keys() == {'Test_Section_1'}

# Generated at 2022-06-21 11:54:03.017195
# Unit test for method parse of class Section
def test_Section_parse():
    text = '.. title:: something\n    possibly over multiple lines'
    section = Section('title', 'title')
    docs = section.parse(text)
    assert docs == [DocstringMeta(['title'], description=None)]



# Generated at 2022-06-21 11:54:05.620561
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection('Deprecated', 'deprecated').title == 'Deprecated'
    assert DeprecationSection('Deprecate', 'deprecated').title == 'Deprecate'
    assert DeprecationSection('Deprecated', 'deprecated').key == 'deprecated'
    assert DeprecationSection('Deprecate', 'deprecated').key == 'deprecated'

# Generated at 2022-06-21 11:54:10.180583
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section(title="Raises", key="raises")
    test_input = "test_key\ntest_value"
    test = section.parse(test_input)
    assert inspect.cleandoc(test_input) == test[0].description


# Generated at 2022-06-21 11:54:18.588015
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    
    # Test whether setup is working properly
    a = YieldsSection("Yields", "yields")
    assert a.is_generator == True
    assert a.key == "yields"
    assert a.title == "Yields"
    
    # Test whether _parse_item and parse are working properly
    a = YieldsSection("Yields", "yields")
    b = "return_name : type A description of this returned value"
    assert a.parse(b) == (DocstringReturns(args=['yields'], description=None, type_name=None, is_generator=True, return_name=None),)

# Generated at 2022-06-21 11:54:30.012775
# Unit test for function parse
def test_parse():
    import pytest
    ds = """
    Test func

    test

    Parameters
    ----------
    x
        first parameter
    y : str
        second parameter, optional
    z: str, optional
        third parameter, optional
    Returns
    -------
    r : str
        return values
    Notes
    -----
    notes
    """
    ds = NumpydocParser().parse(ds)
    #print(dir(ds))
    #print(ds.short_description, ds.long_description, ds.blank_after_short_description, ds.blank_after_long_description)
    #for m in ds.meta:
    #    print(m.args, m.type_name, m.description)
    ret = parse(ds)
    assert ret.short_description == "Test func"
