

# Generated at 2022-06-21 11:45:12.317612
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection(title="Parameters",
                   key="param")
    assert s.title == "Parameters"
    assert s.key == "param"


# Generated at 2022-06-21 11:45:17.511811
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    section = Section(title, key)
    assert section
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == '^'+title+'\s*?\n'+'-'*len(title)+'\s*$'


# Generated at 2022-06-21 11:45:27.198949
# Unit test for function parse
def test_parse():
    text = """
    Description goes here.

    Parameters
    ----------
    foo : int
        foo is a integer

    Returns
    -------
    True or False
    """

    doc = parse(text)
    assert type(doc) == Docstring
    assert doc.short_description == "Description goes here."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'foo']
    assert doc.meta[0].description == 'foo is a integer'
    assert doc.meta[1].args == ['returns']
    assert doc.meta[1].description == 'True or False'

# Generated at 2022-06-21 11:45:31.984868
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = \
    """
    a : str
        b value
    c
        d value
    """
    section = _KVSection("Key-value Section", "key_value")
    result = list(section.parse(text))
    expected = [
        DocstringMeta(['key_value', 'a'], description='b value'),
        DocstringMeta(['key_value', 'c'], description='d value')
    ]
    assert result == expected



# Generated at 2022-06-21 11:45:34.175574
# Unit test for constructor of class _KVSection
def test__KVSection():
	my_Section = _KVSection("Parameters","param")
	assert(my_Section.key == "param")
	assert(my_Section.title == "Parameters")
	return "test__KVSection passed"


# Generated at 2022-06-21 11:45:36.001752
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Section", "key")
    print(s.parse("this is a test\n  And this is a test"))

# Generated at 2022-06-21 11:45:43.239795
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # expected = DocstringDeprecated(
    #     args=["deprecation"], description=_clean_str(value), version=_clean_str(version)
    # )
    title = "deprecated"
    key = "deprecation"
    value = "Deprecated since version 1.0.0: This method has been deprecated. Instead, use method 'text' with keyword argument 'instant=True' to get the string value of the widget."
    version = "1.0.0"
    test = DeprecationSection(title, key)
    result = test.parse(value)
    expected = DocstringDeprecated(
        args=["deprecation"], description=_clean_str(value), version=_clean_str(version)
    )
    print(expected)
    assert expected == result, "Result does not match expected output."

# Generated at 2022-06-21 11:45:44.331132
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sec = ReturnsSection("Returns", "returns")
    assert sec.is_generator == False


# Generated at 2022-06-21 11:45:57.070519
# Unit test for method parse of class _KVSection
def test__KVSection_parse():

    text = """
    Some text

    Raises:
        KeyError:
            If key is not found.
        ValueError:
            If key is found but value is None.
        TypeError:
            If both key and value are None.
    """

    factory = RaisesSection("Raises", "raises")
    meta = list(factory.parse(text))

    assert len(meta) == 3
    assert meta[0].args == ['raises', 'KeyError']
    assert meta[0].description == "If key is not found."
    assert meta[1].args == ['raises', 'ValueError']
    assert meta[1].description == "If key is found but value is None."
    assert meta[2].args == ['raises', 'TypeError']

# Generated at 2022-06-21 11:46:02.816721
# Unit test for constructor of class _KVSection
def test__KVSection():
    test = Section("Parameters", "param")
    assert test.title == "Parameters"
    assert test.key == "param"
    # Testing title_pattern
    pattern = test.title_pattern
    assert pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * 9)


# Generated at 2022-06-21 11:46:10.508200
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    pass
    # TO_DO: instantiate NumpydocParser
    # TO_DO: add section
    # TO_DO: add sections already defined
    # TO_DO: add sections already defined with different parameters

# Generated at 2022-06-21 11:46:11.141195
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert(NumpydocParser().sections)

# Generated at 2022-06-21 11:46:22.352919
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
    arg_description
    arg_2 : type, optional
    descriptions can also span...
    ... multiple lines"""

    factory = ParamSection("Parameters", "param")
    title = "Parameters"
    ret = factory.parse(text)
    assert len(ret) == 2
    assert ret[1].description == "arg_description"
    assert ret[1].arg_name == "arg_name"
    assert ret[1].type_name == None
    assert ret[1].is_optional == None
    assert ret[1].default == None
    assert ret[0].description == "descriptions can also span..."
    assert ret[0].arg_name == "arg_2"
    assert ret[0].type_name == "type"
    assert ret[0].is_optional == True
   

# Generated at 2022-06-21 11:46:31.983998
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test1 = """Test function for NumpydocParser
    
    This function has many different parts, some of which exist, some of which don't.
    
    Parameters
    ----------
    param_one : str
        First parameter
    param_two : bool, optional
        Second parameter
    param_three : int
        Third parameter
        Default is 1
    
    Raises
    ------
    ValueError
        Something bad happened.
    
    Warns
    -----
    Warning
        A warning
    
    Returns
    -------
    return_one : str
        A string
    return_two : bool
        A little boolean
    """

    parser = NumpydocParser()
    test = parser.parse(test1)

    assert len(test.meta) == 2

# Generated at 2022-06-21 11:46:34.372854
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Test the function parse of class DeprecationSection"""
    section = DeprecationSection("deprecated", "deprecation")
    text = """
    .. deprecated:: 0.1
        Test
    """ 
    ret = section.parse(text)
    assert ret.args == ['deprecation']
    assert ret.version == '0.1'
    assert ret.description == "Test"



# Generated at 2022-06-21 11:46:40.073156
# Unit test for function parse
def test_parse():
    docstring = """
Harmonic oscillator.

.. math::

    \\omega^2x = F_{\\text{ext}}

with unitary time-evolution operator

.. math::

    U(t) = \\exp\\left[-i \\omega t \\hat{a}^\\dagger \\hat{a}\\right]

Parameters
----------
omega : float
    the oscillating frequency

Returns
-------
U(t) : float
    the unitary time-evolution operator"""

    ret = parse(docstring)
    assert len(ret.meta) == 1

    param_dict_list = [meta for meta in ret.meta if meta.tags[0] == "param"]
    assert len(param_dict_list) == 1
    param_dict = param_dict_list[0]

# Generated at 2022-06-21 11:46:41.054990
# Unit test for constructor of class Section
def test_Section():
    assert Section('Title', 'title')


# Generated at 2022-06-21 11:46:53.099816
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    # TODO: Add more tests
    res = numpydoc_parser.parse(doc_text)
    #print(res)
    assert res.short_description == "This is new function."
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == True
    assert res.long_description == "This is the long description.\n\nAnd more."
    assert res.meta == [
        DocstringMeta(
            [
                "param",
                "arg1",
            ],
            description="This is argument 1.",
            arg_name="arg1",
            type_name="int",
            is_optional=False,
            default=None,
        ),
    ]
    return


# Generated at 2022-06-21 11:46:55.420286
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("Parameters", "param")
    assert(kv._KVSection__title == "Parameters")
    assert(kv._KVSection__key == "param")
    assert(kv.title_pattern == "^(Parameters)\s*?\n---*\s*$")


# Generated at 2022-06-21 11:46:59.314669
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    """Unit test for constructor of class ReturnsSection."""
    section = ReturnsSection("Returns", "returns")
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.is_generator == False


# Generated at 2022-06-21 11:47:08.535069
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    ndp = NumpydocParser()
    assert ndp.sections['Parameters'].title_pattern == r'^Parameters\s*?\n{}\s*$'.format('-' * len('Parameters'))
    assert ndp.sections['Parameters'].parse('test_key\n    test_text')[0].args[1] == 'test_key'
    assert ndp.sections['Parameters'].parse('test_key\n    test_text')[0].description == 'test_text'


# Generated at 2022-06-21 11:47:11.379055
# Unit test for constructor of class Section
def test_Section():
    unit_test_section = Section("title", "key")

    assert(unit_test_section.title == "title")
    assert(unit_test_section.key == "key")


# Generated at 2022-06-21 11:47:15.172990
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("Deprecated", "deprecated")
    assert d.parse("1.0\nHello world") == [
        DocstringDeprecated(args=["deprecated"], description="Hello world", version="1.0")
    ]

# Generated at 2022-06-21 11:47:18.893088
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    section = Section(title, key)

    assert section.title == title
    assert section.key == key


# Generated at 2022-06-21 11:47:31.110057
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    p = NumpydocParser()
    assert len(p.sections) == 24

    m = """
        Raises
        ------
        RuntimeError
            When the world is ending
    """

    t = p.parse(m)
    assert len(t.meta) == 1
    assert t.meta[0].args == ['raises', 'RuntimeError']
    assert t.meta[0].description == 'When the world is ending'

    m = """
        Raises
            ------
        RuntimeError
            When the world is ending
    """

    t = p.parse(m)
    assert len(t.meta) == 0

    # add section
    p.add_section(Section("Raises", "raises"))

    # check that the section is really added
    assert len(p.sections) == 25

    # Test new

# Generated at 2022-06-21 11:47:40.120084
# Unit test for function parse

# Generated at 2022-06-21 11:47:50.593598
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:48:00.508228
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test parsing of docstring with no meta information
    parser = NumpydocParser()
    docstring = parser.parse(
        """
This is the short description.

This is the long description.
"""
    )
    assert docstring.short_description == "This is the short description."
    assert docstring.blank_after_short_description
    assert docstring.long_description == "This is the long description."
    assert not docstring.blank_after_long_description
    assert not docstring.meta
    
    # Test parsing of docstring with meta information
    parser = NumpydocParser()

# Generated at 2022-06-21 11:48:12.499487
# Unit test for method parse of class Section
def test_Section_parse():
    # Test for Section ParamSection
    param1=ParamSection("Parameters", "param")
    param1_text="""
    arg_name_a
        arg_description_a
    arg_name_b
        arg_description_b
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    result_param1 = param1.parse(param1_text)

# Generated at 2022-06-21 11:48:14.734174
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields") is not None

# Generated at 2022-06-21 11:48:25.413637
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Test normal case
    pa = ParamSection("Parameters", "param")
    assert pa.title == "Parameters"

    # Test if function _gen_regex_pattern() can handle the case of empty title
    pa = ParamSection("", "param")
    assert pa.title_pattern == r"^\s*?\n\s*$"


if __name__ == "__main__":
    test_ParamSection()

# Generated at 2022-06-21 11:48:27.186074
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser

# Generated at 2022-06-21 11:48:30.358553
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_section = YieldsSection("Yields", "yields")
    assert test_section.title == "Yields"
    assert test_section.key == "yields"
    assert test_section.is_generator == True


# Generated at 2022-06-21 11:48:32.414384
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section1 = _SphinxSection("title", "key")
    assert section1.title_pattern == "^\.\.\s*(title)\s*::"



# Generated at 2022-06-21 11:48:41.442851
# Unit test for method parse of class Section
def test_Section_parse():
    section1 = Section("Parameters", "param")
    section2 = Section("Raises", "raises")
    section3 = Section("Returns", "returns")

    assert section1.title == "Parameters"
    assert section1.key == "param"
    assert section2.title == "Raises"
    assert section2.key == "raises"
    assert section3.title == "Returns"
    assert section3.key == "returns"

    text1 = '''
        a
            a
        b : type
            b b
        c, optional
            c c
    '''

# Generated at 2022-06-21 11:48:52.479909
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse(
    """
    This is a short description of the function defined below.

    This is the second line of the short description.
    It is meant to be a small amount of information.

    This is the long description. It is meant to be
    much more detailed.

    Parameters
    ----------
    a : int
        param a

    b : float, optional
        param b

    Other Parameters
    ----------------
    c : float
        other param c

    Returns
    -------
    out : float
        the sum

    Other Returns
    -------------
    out2 :
        the average

    Raises
    ------
    NotImplementedError
        If this function isn't complete
    """
)
    assert type(docstring) == Docstring
    assert len(docstring.meta) == 8


# Generated at 2022-06-21 11:49:02.889693
# Unit test for function parse
def test_parse():
    text = '''
        Title

        Short description.

        Long description.

        Parameters
        ----------
        arg_name : type, optional
            Extended description of the argument.

        Raises
        ------
        RuntimeError : str
            description of what raises this error.

        Returns
        -------
        return_name : type
            Extended description of the return value.

        Yields
        ------
        gen_item_name : type
            Extended description of the yielded item.

        Examples
        --------
        >>> some_code
        42

        Notes
        -----
        Some notes.

        References
        ----------

        .. deprecated:: some version
            Extended description of what's deprecated.
        '''
    docstr = parse(text)
    assert(docstr.short_description == 'Title')

# Generated at 2022-06-21 11:49:05.101296
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parmeters", "parameter")
    header = "Parameters"
    text = "\nhello\n"
    result = list(section.parse(text))
    assert result[0].description == text

# Generated at 2022-06-21 11:49:10.772313
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv = _KVSection("title", "key")
    text = """
key
    value
key2 : type
    values can also span...
    ... multiple lines

"""

    #Test with _KVSection.parse(self, text)
    result = kv.parse(text)


# Generated at 2022-06-21 11:49:12.540321
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	RaisesSection("Raises", "raises")
	pass

# Generated at 2022-06-21 11:49:17.619144
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert isinstance(NumpydocParser(), NumpydocParser)

# Generated at 2022-06-21 11:49:26.709722
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = """
    Parameters:
        param1 (int): Description of param1
        param2 (str): Description of param2
    Returns:
        int: Description of return value
        str: Description of return value
    """
    doc = NumpydocParser()
    doc.sections = DEFAULT_SECTIONS
    print(doc.sections)
    print(doc.titles_re)
    print(doc.sections["Parameters"].key)
    print(doc.sections["Returns"].key)
    print(doc.sections["Parameters"].parse(text))
    print(doc.sections["Returns"].parse(text))


# Generated at 2022-06-21 11:49:31.401633
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecated"
    key = "deprecated"
    depSection = DeprecationSection(title, key)
    text = "2014.06\nDescription"
    parsed_result = depSection.parse(text)
    res = [DocstringDeprecated(['deprecated'], 'Description', '2014.06')]
    assert list(parsed_result) == res

# Generated at 2022-06-21 11:49:43.884368
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    def test_RaisesSection_class_is_instance_of_Section():
        assert(isinstance(RaisesSection("Raises", "Raises"), Section))
    def test_RaisesSection_title_is_given_to_RaisesSection():
        test_title="Raises"
        assert(RaisesSection(test_title, test_title).title==test_title)
    def test_RaisesSection_key_is_given_to_RaisesSection():
        test_key="Raises"
        assert(RaisesSection(test_key, test_key).key==test_key)
    def test_RaisesSection_title_is_attribute_of_RaisesSection():
        assert(hasattr(RaisesSection("title", "key"), "title"))

# Generated at 2022-06-21 11:49:47.312095
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key").title == "title"
    assert Section("title", "key").key == "key"



# Generated at 2022-06-21 11:49:52.292929
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("title", "key")
    assert kv.title == "title"
    assert kv.key == "key"
    assert kv.title_pattern == r"^(title)\s*?\n{}\s*$".format("-" * 5)


# Generated at 2022-06-21 11:50:05.134976
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text1 = 'ValueError\ndescription one'
    text2 = 'description two'
    text3 = 'description three'
    text4 = 'description four'
    text5 = 'description five'
    text6 = 'description six'
    text7 = 'description seven'
    
    nd_parser1 = NumpydocParser()
    nd_parser1.add_section(RaisesSection('Raises', 'raises'))
    nd_parser1.parse(text1)
    
    nd_parser2 = NumpydocParser()
    nd_parser2.add_section(RaisesSection('Raise', 'raises'))
    nd_parser2.parse(text2)
    
    nd_parser3 = NumpydocParser()
    nd_parser3.add_section

# Generated at 2022-06-21 11:50:12.255734
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # invalid parameter: title should be of type string, but input a list
    try:
        section = RaisesSection([1, 2, 3], "key")
    except TypeError:
        pass
    # invalid parameter: key should be of type string, but input a list
    try:
        section = RaisesSection("title", [1, 2, 3])
    except TypeError:
        pass
    # test normal case
    section = RaisesSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-21 11:50:16.241352
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldsSection = YieldsSection("Yields", "yields")
    yield_s = yieldsSection.is_generator
    assert yield_s == True
    assert yieldsSection.title == 'Yields'
    assert yieldsSection.key == 'yields'


# Generated at 2022-06-21 11:50:23.636307
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
	description = "description"
	type_name = "type_name"
	return_name = "return_name"
	test_ReturnSection = ReturnsSection(description, return_name)
	test_ReturnSection.type_name = type_name
	test_ReturnSection.return_name = return_name
	assert test_ReturnSection.type_name == type_name
	assert test_ReturnSection.return_name == return_name


# Generated at 2022-06-21 11:50:31.841620
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")

# Generated at 2022-06-21 11:50:38.536329
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	print()
	text1 = "ValueError\nA description of what might raise ValueError"
	raises_section = RaisesSection("Raises", "raises")
	for meta in raises_section._KVSection.parse(text1):
		print(meta.type_name + " " + meta.description)


if __name__ == "__main__":
	test_RaisesSection()

# Generated at 2022-06-21 11:50:43.202398
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    txt = '''
            Returns
            The type of the first element
            '''
    Parser = YieldsSection('Yields','a')
    res = Parser.parse(txt)
    assert isinstance(res,YieldsSection)
    assert res.is_generator
    assert res.key == 'a'
    assert res.title == 'Yields'


# Generated at 2022-06-21 11:50:45.981049
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("testReturn", "test")
    print(a.title)
    print(a.key)



# Generated at 2022-06-21 11:50:51.612979
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection(title='Title', key='key')

    assert(s.title == 'Title')
    assert(s.key == 'key')
    assert(s.title_pattern == '^\.\.\\s*(Title)\\s*::')

# Generated at 2022-06-21 11:51:00.810820
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text="""
    This is a fake method.
    This is a fake method.
    This is a fake method.
    This is a fake method.
    This is a fake method.

    Parameters
    ----------
    a : int

    Examples
    --------
    >>> a = 1
    >>> a
    1
    """
    assert(parse(text).short_description == "This is a fake method.")
    assert(parse(text).long_description == "This is a fake method. This is a fake method. This is a fake method. This is a fake method. This is a fake method.\n")
    assert(parse(text).meta[0].args[0] == "param")
    assert(parse(text).meta[0].args[1] == "a")

# Generated at 2022-06-21 11:51:03.154341
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    try:
        test_parser = NumpydocParser()
        assert True
    except:
        assert False, "test_NumpydocParser failed"


# Generated at 2022-06-21 11:51:04.655051
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters','param') == Section('Parameters','param')

# Generated at 2022-06-21 11:51:10.532459
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 0.1.2\n    Replaced by :func:`alternative`"
    assert DeprecationSection("deprecated", "deprecation").parse(text).description == "Replaced by :func:`alternative`"
    return
test_DeprecationSection_parse()


# Generated at 2022-06-21 11:51:12.202479
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection('Returns', 'returns').is_generator == False

# Generated at 2022-06-21 11:51:31.837941
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    depSect = DeprecationSection(". ..deprecated: ", "deprecation")
    assert depSect.title_pattern == "^\\.\\.\\s*\\.\\.deprecated:\\s*::"
    assert depSect.title == ". ..deprecated: "
    assert depSect.key == "deprecation"



# Generated at 2022-06-21 11:51:43.032263
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = ParamSection("Parameters", "param")
    # Parse all multiline sections
    # TODO: Rewrite this test when RefSection is complete
    text1 = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    text2 = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
        arg_3 : type (default is 3)
            descriptions can have default values
    """
    for text in [text1, text2]:
        text = inspect.cleandoc(text)
        parsed = section.parse(text)
        assert len(list(parsed)) == 2

# Generated at 2022-06-21 11:51:46.995714
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    TokenizedString.append(other: Union[str, Tuple[str, str, int]])
        Append tokenized other to this TokenizedString.
    """
    parser = NumpydocParser()
    parser.parse(text)

# Generated at 2022-06-21 11:51:55.689588
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = """
    This is the short description.

    This is the long description.  It
    runs over multiple lines.
    """
    result = NumpydocParser().parse(text)
    expected = Docstring(
        short_description="This is the short description.",
        blank_after_short_description=True,
        long_description="This is the long description.  It\nruns over multiple lines.",
        blank_after_long_description=True,
    )
    assert result == expected

    text = """
    This is the short description.
    This is the long description.
    """
    result = NumpydocParser().parse(text)

# Generated at 2022-06-21 11:51:57.850810
# Unit test for constructor of class ParamSection
def test_ParamSection():
    a = ParamSection("Parameters", "param")
    assert a.title == "Parameters"


# Generated at 2022-06-21 11:52:07.833751
# Unit test for constructor of class RaisesSection
def test_RaisesSection():

    # Test without parameters
    raisesSection = RaisesSection("Raises", "raises")

    # Assertion of attributes
    assert raisesSection.title == "Raises"
    assert raisesSection.key == "raises"
    assert raisesSection.title_pattern == r"^(Raises)\s*?\n{}\s*$".format("-" * len("Raises"))

    # Test with parameters
    raisesSection = RaisesSection("Raise", "raises")

    # Assertion of attributes
    assert raisesSection.title == "Raise"
    assert raisesSection.key == "raises"
    assert raisesSection.title_pattern == r"^(Raise)\s*?\n{}\s*$".format("-" * len("Raise"))


# Generated at 2022-06-21 11:52:12.042736
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {
        "title_a": Section("title_a", "key_a"),
        "title_b": Section("title_b", "key_b"),
    }
    np = NumpydocParser(sections)
    assert np != None


# Generated at 2022-06-21 11:52:16.532479
# Unit test for constructor of class Section
def test_Section():
    title = "Test"
    key = "test"
    test = _SphinxSection(title, key)
    assert (test.title == title and test.key == key)

# Generated at 2022-06-21 11:52:21.545242
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("User Section", "user_section")
    parser.add_section(section)
    assert(parser.sections["User Section"] == section)
    assert("UserSection" in parser.titles_re.pattern)
    
    

# Generated at 2022-06-21 11:52:24.146764
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    Parser = RaisesSection("Raises", "raises")
    assert Parser.key == "raises"
    assert Parser.title == "Raises"

# Generated at 2022-06-21 11:53:09.958745
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Use default configuration
    NumpydocParser()
    # Use custom configuration
    NumpydocParser(sections=[Section("Arguments", "args")])


# Generated at 2022-06-21 11:53:15.710035
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Get a section from supported sections
    temp = YieldsSection("Yields", "yields")
    assert temp.title == "Yields"
    assert temp.key == "yields"
    assert temp.is_generator == True
    assert temp.title_pattern == r"^\.\.\s*(Yields)\s*::"
    

# Generated at 2022-06-21 11:53:18.597290
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    DeprecationSection("deprecated", "deprecation").parse("12.3.1\n")

# Generated at 2022-06-21 11:53:24.016528
# Unit test for method parse of class Section
def test_Section_parse():
    section = ParamSection("Parameters", "param")
    text = """\
    f
        Apply func to each element of the list.
    """
    expected = [
        DocstringParam(args=["param", "f"], description="Apply func to each element of the list.")
    ]
    actual = section.parse(text)
    assert expected == list(actual)

# Generated at 2022-06-21 11:53:32.465523
# Unit test for method parse of class Section
def test_Section_parse():
    class ExampleSection(Section):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta(
                args=[key], description=_clean_str(value),
            )
    section = ExampleSection("Example", "example")
    assert section.parse("Example\n---\n\nFirst\nSecond\n\n\n") == [
        DocstringMeta(
            args=["First"],
            description="Second",
        )
    ]
    assert section.parse("Example\n---\nFirst\nSecond\n") == [
        DocstringMeta(
            args=["First"],
            description="Second",
        )
    ]

# Generated at 2022-06-21 11:53:38.929031
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    try:
        newYieldSection = YieldsSection("Yields", "yields")
        # If the the constructor of YieldsSection is correct, then the variable is_generator
        # should be set to True.
        # If the variable is_generator is set to True, then the test is successful and the
        # return value should be 1.
        if newYieldSection.is_generator == True:
            return 1
    except Exception:
        print("There was an error creating a new instance of YieldsSection")


# Generated at 2022-06-21 11:53:45.473060
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print('Executing deprecation section test ...')
    title = 'Deprecated'
    key = 'deprecated'
    s = DeprecationSection(title, key)
    assert(s.title == 'Deprecated')
    assert(s.key == 'deprecated')
    print('Finished deprecation section test')
    return 0


# Generated at 2022-06-21 11:53:53.306977
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    from .common import DocstringDeprecated
    ds_dep = DeprecationSection('Deprecated', 'deprecated')
    assert ds_dep.title == 'Deprecated'
    assert ds_dep.key == 'deprecated'
    assert ds_dep.parse('1.0\n\nFunction does not work properly') == [DocstringDeprecated(args=['deprecated'], description='Function does not work properly', version='1.0')]
    assert ds_dep.parse('1.0') == [DocstringDeprecated(args=['deprecated'], description=None, version='1.0')]


# Generated at 2022-06-21 11:53:55.910100
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("Parameters", "param")
    assert s.title == "Parameters"
    assert s.key == "param"
    return


# Generated at 2022-06-21 11:54:07.610929
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1:
    """
    Some docstring.

    Parameters
    ----------
    arg_1 : type, optional
        A description of arg_1
    arg_2
        A description of arg_2

    Returns
    -------
    return : type
    """
    s = NumpydocParser().parse(inspect.cleandoc(test_NumpydocParser_parse.__doc__))
    assert s.short_description == 'Some docstring.'
    assert s.long_description == None
    assert s.blank_after_short_description == True
    assert s.blank_after_long_description == False
    assert len(s.meta) == 2
    assert s.meta[0].description == 'A description of arg_1'
    assert s.meta[0].arg_name == 'arg_1'
