

# Generated at 2022-06-21 11:45:23.357128
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    """Check that the constructor works as expected"""
    args = ["Returns", "returns"]
    section = ReturnsSection(*args)
    assert(section.title_pattern == r"^\.\.\s*Returns\s*::")
    assert(section.key == "returns")
    assert(section.title == "Returns")
    assert(str(section.is_generator) == "False")

# Generated at 2022-06-21 11:45:32.700757
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():

    # Test case 1
    text = """
    .. deprecated:: 1.0
        Use foo instead.
    """
    m = NumpydocParser().parse(text)
    assert m.meta[0].description == "Use foo instead."
    assert m.meta[0].version == "1.0"

    # Test case 2
    text = """
    .. deprecated:: 1.0
        ..Use foo instead.
    """
    m = NumpydocParser().parse(text)
    assert m.meta[0].description == "Use foo instead."
    assert m.meta[0].version == "1.0"

    # Test case 3
    text = """
    .. deprecated:: 1.0
        ..Use foo instead.
        ..Aha
    """
    m = NumpydocParser().parse(text)

# Generated at 2022-06-21 11:45:34.787407
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    m = RaisesSection("Raises", "raises")
    assert m.title == "Raises"
    assert m.key == "raises"

# Generated at 2022-06-21 11:45:41.699172
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Returns the number of bytes in an object
    :param object: object whose size has to be checked.
    :return: number of bytes for the object.
    :rtype: int
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Returns the number of bytes in an object"
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "object"]
    assert docstring.meta[0].description == "object whose size has to be checked."
    assert docstring.meta[1].args == ["return"]
    assert docstring.meta[1].description == "number of bytes for the object."

# Generated at 2022-06-21 11:45:45.443325
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class TitleSection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))
    new_parser = NumpydocParser()
    new_parser.add_section(TitleSection("Title", "title"))
    docstring = new_parser.parse("Title\n---\n Hi, I'm a title\n")
    assert docstring.meta[0].args[0] == "title"

# Generated at 2022-06-21 11:45:48.351911
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    try:
        s = _SphinxSection("\u00A7" + "a", "b")
    except:
        return False
    return True



# Generated at 2022-06-21 11:45:51.512566
# Unit test for constructor of class ParamSection
def test_ParamSection():
    instance = ParamSection("Parameters", "param")
    assert(isinstance(instance, ParamSection))


# Generated at 2022-06-21 11:46:00.157890
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:46:12.687631
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("") == Docstring()

    text = """
    Short description.

    Long description.

    Parameters
    ----------
    x : type
        Param description
    """
    d = parse(text)
    assert d.short_description == "Short description."

    long_desc = "Long description."
    assert d.long_description == long_desc

    d_expected = Docstring(
        short_description="Short description.",
        long_description=long_desc,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[
            DocstringParam(
                args=["param", "x"],
                type_name="type",
                description="Param description",
            )
        ],
    )
    assert d == d_expected

# Generated at 2022-06-21 11:46:15.376506
# Unit test for constructor of class Section
def test_Section():
    sec = Section('Parameters', 'param')
    assert sec.title == 'Parameters'
    assert sec.key == 'param'

# Generated at 2022-06-21 11:46:24.948832
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    '''Testing method parse of class _KV_Section'''
    # text with no key-value type of text
    param_text = '''
        param_name
            param_description
        '''
    expected_result = {'args': ['param', 'param_name'],
                       'description': 'param_description'}
    kv_section = _KVSection("Parameters", "param")
    result = next(kv_section.parse(param_text))
    assert result.__dict__ == expected_result


# Generated at 2022-06-21 11:46:28.182773
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
   SECTION = _SphinxSection("title section","key attribute")
   assert SECTION.title == "title section"
   assert SECTION.key == "key attribute"
   assert SECTION.title_pattern == r"^\.\.\s*(title section)\s*::"

# Generated at 2022-06-21 11:46:36.074700
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    content = """
    .. deprecated:: 0.3.1
        Use `other_param` instead.

    """
    meta = parser.parse(content).meta
    assert meta[0].args[0] == "deprecation"
    assert meta[0].args[1] == "version"
    assert meta[0].args[2] == "0.3.1"
    assert meta[0].description == "Use `other_param` instead."

# Generated at 2022-06-21 11:46:39.483140
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = ParamSection("Raises", "raises")
    if r.title == "Raises" and r.key == "raises":
        print("passed")
    else:
        print("failed")


# Generated at 2022-06-21 11:46:45.309195
# Unit test for constructor of class Section
def test_Section():
    # We will test _pairwise function by printing it's output.
    # Following is an example of expected output.
    # For example, if we pass the iterable as
    # [ 11, 22, 33, 44, 55 ]
    # Then the output will be
    # (11, 22)
    # (22, 33)
    # (33, 44)
    # (44, 55)
    # (55, None)
    dummy_iterable = [ 1, 2, 3, 4 ]
    for n in _pairwise(dummy_iterable):
        print(n)
    return


# Generated at 2022-06-21 11:46:58.431913
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:47:09.588356
# Unit test for function parse
def test_parse():
    def f(x):
        """Test function

        :param x: parameter x
        :returns: int
        """
        return x

    doc = f.__doc__

    assert parse(doc).short_description == "Test function"
    assert parse(doc).meta[0].description == "parameter x"
    assert parse(doc).meta[0].arg_name == "x"
    assert parse(doc).meta[1].description is None
    assert parse(doc).meta[1].type_name == "int"
    assert parse(doc).meta[1].return_name is None
    assert parse(doc).long_description is None

    doc = """
    Test function

    :param x: parameter x
    :returns: int

    This is a long description
    """


# Generated at 2022-06-21 11:47:12.882916
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Return","returns")
    rs._parse_item("return_name : type", "A description of this returned value")
    rs._parse_item("another_type", "Return names are optional, types are required")

# Generated at 2022-06-21 11:47:20.621193
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    Example docstring:
        .. deprecated :: 0.5
            ``field`` has been deprecated. Please use ``f`` instead.
    """
    expected_description = "``field`` has been deprecated. Please use ``f`` instead."
    parser = NumpydocParser()
    result = parser.parse(f".. deprecated :: 0.5\n    {expected_description}")
    assert result.meta[0].description == expected_description



# Generated at 2022-06-21 11:47:21.858689
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser

# Generated at 2022-06-21 11:47:31.325905
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    sec = YieldsSection("Yields", "yields")
    doc = sec.parse("double_value \n twice")
    print(doc)
    assert doc[0].type_name == "double_value"
    assert doc[0].description == "twice"

# Generated at 2022-06-21 11:47:40.241718
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    assert(type(section) == Section)
    assert(section.title == "Parameters")
    assert(section.key == "param")
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    assert(type(section.parse(text)) == list)
    assert(len(section.parse(text)) == 2)
    assert(type(section.parse(text)[0]) == DocstringMeta)
    assert(type(section.parse(text)[1]) == DocstringMeta)
    assert(len(section.parse(text)[0].args) == 2)
    assert(section.parse(text)[0].args[0] == "param")

# Generated at 2022-06-21 11:47:49.532999
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Content in section
    # item_key_0
    #   item_description_0
    # item_key_1
    #   item_description_1
    mock_text = "item_key_0\n  item_description_0\nitem_key_1\n  item_description_1"
    # Expected list of parsed meta
    expected = [
        DocstringMeta(["key", "item_key_0"], "item_description_0"),
        DocstringMeta(["key", "item_key_1"], "item_description_1"),
    ]

    _KVSection("title", "key").parse(mock_text) == expected

# Generated at 2022-06-21 11:47:53.298310
# Unit test for method parse of class Section
def test_Section_parse():
    example = Section("example_title", "example_key")
    
    assert example.parse("example_text") == [
        DocstringMeta(["example_key"], description='example_text')
    ]



# Generated at 2022-06-21 11:48:01.712654
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    ps.title = "Parameters"
    ps.key = "param"
    assert ps.title_pattern == r"^Parameters\s*?\n{}\s*$".format("-" * len(ps.title))
    ps.parse("arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines\n")
    ps.parse("arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines")
    ps.parse("arg_name\n\targ_description")
    ps.parse("arg_name\targ_description")
    ps.parse("arg_name arg_description")

# Generated at 2022-06-21 11:48:03.267502
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").key == "deprecation"

# Generated at 2022-06-21 11:48:07.343014
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("deprecated", "d")
    assert (d.title == "deprecated")
    assert (d.key == "d")


# Generated at 2022-06-21 11:48:16.741459
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """Unit test for constructor of class NumpydocParser."""
    valid_string = "this is a valid string"

    assert NumpydocParser(None).sections == DEFAULT_SECTIONS

    # Test default sections
    instances = NumpydocParser()
    assert isinstance(instances.sections, dict)
    assert len(instances.sections) == len(DEFAULT_SECTIONS)
    assert all(isinstance(v, Section) for v in instances.sections.values())
    assert "Parameters" in instances.sections.keys()
    assert "Params" in instances.sections.keys()
    assert "Arguments" in instances.sections.keys()
    assert "Args" in instances.sections.keys()
    assert "Other Parameters" in instances.sections.keys()
    assert "Other Params" in instances.sections.keys

# Generated at 2022-06-21 11:48:24.201906
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class CustomNoteSection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    # Case 1: called function add_section of class NumpydocParser
    parser = NumpydocParser()
    parser.add_section(CustomNoteSection("Note", "note"))
    assert parser.sections["Note"].key
    assert parser.sections["Note"].title
    assert parser.sections["Note"].parse
    assert parser.titles_re


# Generated at 2022-06-21 11:48:28.024551
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(
        _KVSection("Parameters", "param").parse(
            "arg_name\n    arg_description\n"
            "arg_2 : type, optional\n"
            "    descriptions can also span...\n"
            "    ... multiple lines\n"
        )
    ) == [
        DocstringMeta(["param", None], description="arg_description"),
        DocstringParam(
            args=["param", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            arg_name="arg_2",
            type_name="type",
            is_optional=True,
        )
    ]

# Generated at 2022-06-21 11:48:44.242332
# Unit test for constructor of class Section
def test_Section():
  section = Section("Parameters", "param")
  print(section.title)


# Generated at 2022-06-21 11:48:54.785100
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #Test the short description
    text = inspect.cleandoc("""
        This function calculates the square root of a given number.
        
        Parameters
        ----------
        argument : int
            The number whose square root is to be calculated
            This argument can be positive or negative.
        """)
    assert parse(text).short_description == \
        "This function calculates the square root of a given number."
    #Test long description
    assert parse(text).long_description == \
        "Parameters\n----------\nargument : int\n"+\
        "    The number whose square root is to be calculated\n"+\
        "    This argument can be positive or negative."
    assert parse(text).blank_after_long_description
    assert parse(text).blank_after_short_description
    #Test parameter

# Generated at 2022-06-21 11:49:03.442191
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    class TestSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta(self.key, description=_clean_str(value))

    section = TestSection('test','test')
    assert ("test", "value") in [(m.key, m.description) for m in section.parse(text)]
    assert ("test", "values can also span...multiple lines") in [(m.key, m.description) for m in section.parse(text)]


# Generated at 2022-06-21 11:49:15.589067
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()
    actual = p.parse("""
    Numpy-style docstring

    Parameters
    ----------
    arg_1 : int
        Description can span multiple
        lines
    arg_2 : str, optional
        Default is "something".

    Returns
    -------
    str
        A description of the return value
    """)


# Generated at 2022-06-21 11:49:19.338260
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = NumpydocParser()
    assert parser
    parser.add_section(YieldsSection("Yield", "yield"))
    assert parser.sections["Yield"].is_generator == True


# Generated at 2022-06-21 11:49:24.523285
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
.. deprecated:: 1.0
   deprecated
   hello
    """
    section = DeprecationSection('deprecated', 'deprecated')
    doc = DocstringDeprecated(
        args=['deprecated'], description="deprecated hello", version="1.0")
    assert list(section.parse(text)) == [doc]

# Generated at 2022-06-21 11:49:32.208769
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = """
A pretty short description.

    """
    parser = NumpydocParser([Section("Params", "param")])
    doc_string = parser.parse(text)
    assert (
        doc_string.short_description
        == "A pretty short description.\n\n"
    )
    assert (
        doc_string.long_description is None
    )
    assert (
        doc_string.blank_after_long_description is False
    )
    assert (
        doc_string.blank_after_short_description is True
    )
    assert(
        len(doc_string.meta) == 0
    )


# Generated at 2022-06-21 11:49:35.169491
# Unit test for constructor of class RaisesSection
def test_RaisesSection():

    raises = RaisesSection("Raises", "raises")

    assert raises.title == "Raises"
    assert raises.key == "raises"

# Generated at 2022-06-21 11:49:37.872223
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"

# Generated at 2022-06-21 11:49:40.088253
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    with pytest.raises(NotImplementedError):
        sec = _SphinxSection("title", "key")
    assert sec.title == "title"
    assert sec.title_pattern == "^\\.\\.\\s*(title)\\s*::"
    assert sec.key == "key"



# Generated at 2022-06-21 11:50:18.572340
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = dict(sections=DEFAULT_SECTIONS)
    numpydoc_parser = NumpydocParser(sections)
    value_expected = sections
    value_received = numpydoc_parser.sections
    assert value_expected == value_received

# Generated at 2022-06-21 11:50:30.845634
# Unit test for function parse
def test_parse():
    def my_function():
        """
        Function description
        and so on
        with a blank line

        Parameters
        ----------
        arg1 : int
            argument description 1

        arg2 : str, optional
            argument description 2

        Raises
        ------
        ValueError
            If something when wrong

        Returns
        -------
        int
            The answer

        Warns
        -----
        default::RuntimeWarning
            Something not so bad may happen

        .. deprecated:: 1.2.3
            Use something else

        """

    ds = parse(my_function.__doc__)
    assert ds.short_description == "Function description"
    assert (
        ds.long_description
        == "and so on\nwith a blank line"  # noqa E501
    )
    assert ds.blank_after_short

# Generated at 2022-06-21 11:50:42.180732
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # constructor with no argument
    def test_no_argument():
        np = NumpydocParser()
        assert np.sections == {s.title: s for s in DEFAULT_SECTIONS}

    # constructor with argument sections 
    # the section with title "Return" is replaced
    def test_sections_argument():
        sections = [
            ReturnsSection("Returns", "returns"),
            ReturnsSection("Return", "returns"),
            YieldsSection("Yields", "yields"),
            YieldsSection("Yield", "yields"),
        ]
        np = NumpydocParser(sections=sections)
        assert np.sections == {s.title: s for s in sections} 

    test_no_argument()
    test_sections_argument()



# Generated at 2022-06-21 11:50:54.365955
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from tests.unittests.base import base_parse
    from pydantic_docstring import DocstringDeprecated
    docstring = DocstringDeprecated([
        "deprecated",
        "12.0.0",
        "test",
    ],
        version="12.0.0",
        description="test",
        deprecated_message=None,
        resource_type=None,
        resource_name=None,
    )
    assert base_parse(
        DeprecationSection(
            'deprecated',
            'deprecated',
        ),
        "12.0.0\ntest",
        docstring,
        '.. deprecated:: 12.0.0\n'
        '\n'
        '    test',
    )

# Generated at 2022-06-21 11:51:02.172791
# Unit test for function parse
def test_parse():
    text = """
    Parameters
    ----------
    arg1: int
        this is arg1.
    arg2, optional
        this is arg2.
    arg3, default is 'a'
        this is arg3
    arg4 : tuple
        this is arg4
    arg5, default=5.5: int
        this is arg5
    arg6, optional, default is 'b'
        this is arg6
    arg7, optional, default=5.5
        this is arg7
    arg8(optional): List[int]
        this is arg8
    """


# Generated at 2022-06-21 11:51:05.187114
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert_section = ParamSection("Parameters", "param")
    assert assert_section.key == "param"
    assert assert_section.title == "Parameters"


# Generated at 2022-06-21 11:51:09.508727
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "TestSection"
    key = "TestKey"
    sphinxSection = _SphinxSection(title, key)
    assert sphinxSection is not None


# Generated at 2022-06-21 11:51:16.243794
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    Test if the method parse of class DeprecationSection 
    returns a DeprecationSection object
    """
    parserComp = NumpydocParser(sections=[DeprecationSection("Deprecated", "deprecation")])
    docstring = parserComp.parse("Deprecated since version 0.1:\nThis method is deprecated.")
    assert isinstance(docstring.meta[0], DocstringDeprecated)

# Generated at 2022-06-21 11:51:17.484478
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection(title="Returns", key="returns")



# Generated at 2022-06-21 11:51:22.506680
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("title","key")
    text = sec.title + "\n" + ("-" * len(sec.title)) + "\n" + "bar"
    res = sec.parse(text)
    assert "key" in res.__next__().args
    assert "bar" in res.__next__().description


# Generated at 2022-06-21 11:51:54.111290
# Unit test for function parse
def test_parse():
    """
    Test for parse.
    """
    assert parse('').short_description is None
    assert parse('').long_description is None
    assert parse('').meta == []

    doc = """\
        One line summary
        and another.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of arg1
        arg2 : str
            Description of arg2

        Examples
        --------
        Examples should be written in doctest format, and
        should illustrate how to use the function.

        >>> a = [1, 2, 3]
        >>> print([x + 3 for x in a])
        [4, 5, 6]

        """
    assert parse(doc).short_description == "One line summary and another."

# Generated at 2022-06-21 11:51:59.319245
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    # Add an new section
    numpydoc_parser.add_section(Section("Hazard", "hazardous"))
    # Replace an existing section
    numpydoc_parser.add_section(Section("Parameters", "parameters"))

# Generated at 2022-06-21 11:52:08.869459
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""
    A short description.

    A long description.

    Parameters
    ----------
    param : type
        An optional description of param
    other_param : other_type
        An optional description of param
    another_param : str
        An optional description of param

    Raises
    ------
    Exception
        An optional description of what might raise Exception

    Other Parameters
    ----------------
    another_param : str
        An optional description of another_param
    yet_another_param : str
        An optional description of yet_another_param

    Returns
    -------
    type
        An optional description of what is returned
    """)

    result = parse(docstring)
    assert isinstance(result, Docstring)
    assert result.short_description == 'A short description.'
    assert result.long_description

# Generated at 2022-06-21 11:52:13.244060
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    kv = RaisesSection("Raises", "raises")
    assert kv.title == "Raises"
    assert kv.key == "raises"
    assert kv.title_pattern == r"^Raises\s*?\n---\s*$"


# Generated at 2022-06-21 11:52:21.544956
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = ParamSection("Parameters", "param")
    if parser.title != "Parameters":
        raise AssertionError(parser.title)
    if parser.key != "param":
        raise AssertionError(parser.key)
    if parser.title_pattern != r"^Parameters\s*?\n\s*$":
        raise AssertionError(parser.title_pattern)


# Generated at 2022-06-21 11:52:23.618377
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    obj = RaisesSection("Raises", "raises")
    print(obj)


# Generated at 2022-06-21 11:52:36.293753
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    short description line1

    short description line2

    long description line1

    long description line2

    long description line3


    Parameters
    ----------
    param : function
        A function that returns nothing.

    other_param : *args
        *args

    other_param : **kwargs
        **kwargs

    Returns
    -------
    str
        Description of return value
    """

# Generated at 2022-06-21 11:52:37.290181
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert  NumpydocParser().parse is not None

# Generated at 2022-06-21 11:52:44.501502
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Code
    text = inspect.cleandoc("""\
    .. deprecated:: 2.0.0

        Use 'parse' method of class NumpydocParser instead of this function
    """)
    section = DeprecationSection("deprecated", "deprecation")
    for meta in section.parse(text):
        assert meta.args == ['deprecation']
        assert meta.description == "Use 'parse' method of class NumpydocParser instead of this function"
        assert meta.version == "2.0.0"



# Generated at 2022-06-21 11:52:45.904110
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    test_section = DeprecationSection("deprecation", "deprecated")
    assert test_section.title == "deprecation"

# Generated at 2022-06-21 11:53:10.652226
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection('Returns', 'returns')
    assert rs.title == 'Returns'
    assert rs.key == 'returns'
    assert rs.is_generator == False
    rs1 = ReturnsSection('Yields', 'yields')
    assert rs1.is_generator == True

if __name__ == "__main__":
    test_ReturnsSection()

# Generated at 2022-06-21 11:53:13.761814
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-21 11:53:19.678960
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    
    test_text = "Deprecated since version 4.0\nThe description of this module"
    parser = NumpydocParser()

    for section in parser.sections:
        if parser.sections[section].title == 'deprecated':
            parser.sections[section].parse(test_text)



# Generated at 2022-06-21 11:53:29.485673
# Unit test for function parse
def test_parse():
    test_docstring = """
    This is a test docstring of function. 
    
    Parameters
    ----------
    a : int
        The test parameter a.
    b : str
        The test parameter b.
    
    Returns
    -------
    c : float
        The test parameter c.
    """

    test_output = parse(test_docstring)
    assert test_output.short_description is "This is a test docstring of function."
    assert test_output.blank_after_short_description is True
    assert test_output.blank_after_long_description is False
    assert test_output.long_description is None
    assert len(test_output.meta) == 3

    test_param_a = test_output.meta[0]
    assert test_param_a.name == "param"

# Generated at 2022-06-21 11:53:33.394196
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test the method add_section of class NumpydocParser.
    """
    new_section = Section("New Section", "new_section")
    parser = NumpydocParser()
    parser.add_section(new_section)
    assert len(parser.sections) == len(DEFAULT_SECTIONS) + 1

# Generated at 2022-06-21 11:53:35.339402
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert(DEFAULT_SECTIONS == list(parser.sections.values()))


# Generated at 2022-06-21 11:53:37.178776
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection(None,None).parse("something")) == [None]


# Generated at 2022-06-21 11:53:41.151453
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ts = ReturnsSection("Returns", "returns")
    assert type(ts) is ReturnsSection
    assert ts.title == "Returns"
    assert ts.key == "returns"
    assert ts.is_generator == False


# Generated at 2022-06-21 11:53:52.029058
# Unit test for method parse of class Section
def test_Section_parse():
    from datetime import datetime
    s = Section("Parameters", "param")
    text = 'Parameters\n----------\n    arg_name:\n        arg_description    arg_2 : type, optional\n        descriptions can also span...\n        ... multiple lines'
    assert s.parse(text) == [DocstringMeta(['param'], arg_name='arg_name', type_name=None, is_optional=False, default=None, description='arg_description'), DocstringMeta(['param'], arg_name='arg_2', type_name='type', is_optional=True, default=None, description='descriptions can also span...\n        ... multiple lines')]

if __name__ == "__main__":
    test_Section_parse()

# Generated at 2022-06-21 11:53:53.663067
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters","param")
    assert p.title == "Parameters"
    assert p.key == "param"