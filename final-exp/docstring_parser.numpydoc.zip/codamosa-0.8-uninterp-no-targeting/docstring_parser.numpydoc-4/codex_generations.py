

# Generated at 2022-06-21 11:45:14.673465
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    assert deprecation_section.key == "deprecation"
    assert deprecation_section.title == "deprecated"
    assert deprecation_section.title_pattern == "^\.\.\s*(deprecated)\s*::"



# Generated at 2022-06-21 11:45:25.239430
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a docstring.

    Parameters
    ----------
    an_argument : str
        A description of this argument.

    another_argument : str, optional
        A description of this argument.

    Returns
    -------
    bool
        False or True.
    '''
    doc = parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "Parameters\n----------\nan_argument : str\n    A description of this argument.\nanother_argument : str, optional\n    A description of this argument.\nReturns\n-------\nbool\n    False or True."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-21 11:45:27.700468
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    import pytest
    obj = _KVSection("str", "str")
    with pytest.raises(NotImplementedError):
        obj.parse("str")


# Generated at 2022-06-21 11:45:36.791393
# Unit test for function parse
def test_parse():
    import textwrap
    print("Test function: parse")
    text = """Short description

    Long description
    which spans multiple lines

    Parameters
    ----------
    arg_name
        Description of an arg
    arg_2 : type, optional
        Description of an optional arg

    Returns
    -------
    return_name : type
        Description of returned value
    another_type
        Return names are optional, types are required

    Yields
    -------
    type
        Description of generated value
    """

    d = parse(text)
    print(d)
    assert d.short_description == 'Short description'
    assert d.long_description == 'Long description which spans multiple lines'
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is True
    assert list(d.meta)

# Generated at 2022-06-21 11:45:39.144793
# Unit test for method parse of class Section
def test_Section_parse():
    doc = "Section\n-------\nSection text"
    section = Section("Section", "key")

    assert list(section.parse(doc)) == [DocstringMeta(["key"],description="Section text")]



# Generated at 2022-06-21 11:45:44.665019
# Unit test for method parse of class Section
def test_Section_parse():
    from inspect import cleandoc
    from .yaml import dump
    section = Section("Parameters", "param")
    assert section.parse(cleandoc("\n  ")) == []
    assert section.parse(cleandoc("\na")) == [
        DocstringMeta(["param"], description="a")
    ]
    assert section.parse(cleandoc("\na  ")) == [
        DocstringMeta(["param"], description="a")
    ]
    assert section.parse(cleandoc("\n  a")) == [
        DocstringMeta(["param"], description="a")
    ]
    assert section.parse(cleandoc("\na\nb\n")) == [
        DocstringMeta(["param"], description="a"),
        DocstringMeta(["param"], description="b"),
    ]
    assert section.parse

# Generated at 2022-06-21 11:45:46.124100
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r1 = RaisesSection("Raises", "raises")
    assert(r1.title == "Raises")
    assert(r1.key == "raises")


# Generated at 2022-06-21 11:45:57.898357
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection('Deprecation Warning', 'deprecated')
    assert dep.parse('') == (None,)
    assert dep.parse('\n') == (None,)
    assert dep.parse('\n\n') == (None,)
    assert dep.parse('\t') == (None,)
    assert dep.parse('\t\n') == (None,)
    assert dep.parse('\t\n\n') == (None,)
    assert dep.parse('\t\t') == (None,)
    assert dep.parse('\t\t\n') == (None,)
    assert dep.parse('\t\t\n\n') == (None,)
    assert dep.parse(' ') == (None,)
    assert dep.parse(' \n') == (None,)

# Generated at 2022-06-21 11:46:06.000911
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # [must] add a new section in the dictionary of NumpydocParser
    # [must] test if the new section is in the dictionary of NumpydocParser
    # [must] test if the new section is added at the end of the dictionary of NumpydocParser
    # [must] test if the regular expressions for parsing is updated
    # [must] test the method add_section with a None parameter
    # [must] test the method add_section with an empty parameter
    pass

# Generated at 2022-06-21 11:46:09.562628
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_section = YieldsSection("Yields", "yields")
    assert test_section.is_generator == True, "YieldsSection's is_generator does not work"

# Generated at 2022-06-21 11:46:19.650151
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_returns = ReturnsSection("Returns", "returns")
    test_returns1 = ReturnsSection("Return", "returns")
    assert test_returns.key == "returns"
    assert test_returns.title == "Returns"
    assert test_returns1.key == "returns"
    assert test_returns1.title == "Return"


# Generated at 2022-06-21 11:46:22.626509
# Unit test for constructor of class Section
def test_Section():
    assert(Section("Parameters", "param").title == "Parameters")
    assert(Section("Parameters", "param").key == "param")


# Generated at 2022-06-21 11:46:25.645309
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    with open('README', 'r') as f:
        text = f.read()
    t = NumpydocParser()
    t.parse(text)


# Generated at 2022-06-21 11:46:29.969040
# Unit test for constructor of class _KVSection
def test__KVSection():
    key_value_section_test = _KVSection('Parameters', 'param')
    assert key_value_section_test.title == 'Parameters'
    assert key_value_section_test.key == 'param'
    assert key_value_section_test.title_pattern == r'^Parameters\s*?\n{}\s*$'.format('-' * len('Parameters'))

# Generated at 2022-06-21 11:46:32.586641
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_section = ReturnsSection("Returns")
    assert(return_section.is_generator == False)

# Generated at 2022-06-21 11:46:38.036150
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    new_section = ParamSection("New_Section", "new_param")
    numpydoc_parser.add_section(new_section)
    text = "New_Section\n------------\n key\n     value"
    assert list(numpydoc_parser.parse(text).meta)[0].args == ['new_param', 'key']

# Generated at 2022-06-21 11:46:44.976404
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Arrange
    text = """
    Key
        Value
    Key2 : type
        Values can also span...
        ... multiple lines
    """
    class TestClass(_KVSection):
        def _parse_item(self, key, value):
            return key + ":" + value
    test = TestClass("title", "key")

    # Act
    result = test.parse(text)

    # Assert
    assert(list(result) == list(["Key:Value", "Key2 : type:Values can also span...\n... multiple lines"]))


# Generated at 2022-06-21 11:46:48.754109
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert(y.title_pattern == "^\.\.\s*(Yields)\s*::")


# Generated at 2022-06-21 11:46:51.102382
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection.title_pattern == r"^\.\.\s*({})\s*::"

# Generated at 2022-06-21 11:47:03.781465
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")

# Generated at 2022-06-21 11:47:23.067896
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section('Parameters','param')
    value = 'required \n param'
    assert list(section.parse(value)) == [DocstringMeta(['param'], description='required')]


# Generated at 2022-06-21 11:47:24.997362
# Unit test for method parse of class Section
def test_Section_parse():
    parse = Section("Criteria", "criteria").parse("summary of the criteria")
    for i in parse:
        print(i)


# Generated at 2022-06-21 11:47:27.449790
# Unit test for constructor of class _KVSection
def test__KVSection():
    section=_KVSection("Parameters", "param")
    assert section.title=="Parameters"
    assert section.key=="param"


# Generated at 2022-06-21 11:47:30.344571
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = """
    error1
        description of error
    error2
        description of error
    """
    # TODO: Uncomment this once libcst supports exceptions, currently it doesn't.
    # r = ReRaisesSection("Raises", "raises")
    # r.parse(text)
    assert True

# Generated at 2022-06-21 11:47:34.018850
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises")
    assert RaisesSection("Raise", "raises")
    assert RaisesSection("Warns", "warns")
    assert  RaisesSection("Warn", "warns")

# Generated at 2022-06-21 11:47:41.610310
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:47:43.019254
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")


# Generated at 2022-06-21 11:47:49.281475
# Unit test for function parse
def test_parse():
    def func():
        """This is a numpydoc-style docstring without anything special in it.

        :returns: something
        """

    assert parse(func.__doc__) == Docstring(
        short_description=func.__doc__.splitlines()[0],
        long_description=inspect.cleandoc(func.__doc__.strip()),
        meta=[DocstringReturns(args=["returns"], type_name=None)],
    )

# Generated at 2022-06-21 11:47:59.824662
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """A function.

    Parameters
    ----------
    x : int
        A number.
    y : int
        Another number.

    Raises
    ------
    ValueError
        If x is zero.

    Returns
    -------
    int
        The sum of x and y.

    Examples
    --------
    >>> add(1, 1)
    2

    >>> add(3, 7)
    10

    Notes
    -----
    This is a note.

    See Also
    --------
    sub : A function that subtracts two numbers.
    mul : A function that multiplies two numbers.

    References
    ----------
    [1] Jones, J., Smith, S., & Brown, B. (2014).
    The title of the work. http://dx.doi.org/10.0000/00001
    """
   

# Generated at 2022-06-21 11:48:03.215995
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Parameters", "param")
    print("title:", sec.title)
    print("key:", sec.key)
    print("title_pattern:", sec.title_pattern)

# Generated at 2022-06-21 11:48:24.372029
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    docstring = """
        d
            A description of this function.
            The description can span multiple lines.
        c : type
            A description of c's type.
        a : int
            This will be parse to some something.
        b : Optional[str]
            If something bad happens, it will be do something else.
            The description can span multiple lines.
    """
    Docs = NumpydocParser()
    Docs.parse(docstring)


__all__ = (
    "parse",
    "Section",
    "ParamSection",
    "RaisesSection",
    "ReturnsSection",
    "YieldsSection",
    "DeprecationSection",
    "NumpydocParser",
)

# Generated at 2022-06-21 11:48:28.315258
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class _TestKVSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([key], description=_clean_str(value))
    section = _TestKVSection('id', 'key')
    doc = '''
    key
        value
    key2
        values can also span...
            ... multiple lines
    '''
    doc = inspect.cleandoc(doc)
    expected = [DocstringMeta(['key'], description='value'),
                DocstringMeta(['key2'], description='values can also span...\n\t... multiple lines')]
    assert section.parse(doc) == expected



# Generated at 2022-06-21 11:48:36.015657
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections1 = [ParamSection("Parameters", "param"),
                 ParamSection("Params", "param")]
    sections2 = [ReturnsSection("Returns", "returns"),
                 YieldsSection("Yields", "yields")]
    parser1 = NumpydocParser(sections1)
    parser2 = NumpydocParser(sections2)
    assert parser1.sections == {"Parameters": ParamSection("Parameters", "param"), 
                                "Params": ParamSection("Params", "param")}
    assert parser2.sections == {"Returns": ReturnsSection("Returns", "returns"), 
                                "Yields": YieldsSection("Yields", "yields")}
    parser3 = NumpydocParser()

# Generated at 2022-06-21 11:48:42.150302
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    section = Section(title=title, key=key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^(title)\s*?\n{}\s*$".format(
        "-" * len(title)
    )
    assert section.parse(text="") == DocstringMeta([key])


# Generated at 2022-06-21 11:48:53.156175
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    class _SphinxSectionTester(_SphinxSection):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    title = None
    key = None
    try:
        tester = _SphinxSectionTester(title, key)
        assert(False)
    except TypeError:
        assert(True)

    title = "title"
    key = ""
    try:
        tester = _SphinxSectionTester(title, key)
        assert(False)
    except TypeError:
        assert(True)

    title = ""
    key = "key"

# Generated at 2022-06-21 11:48:54.586039
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    obj = RaisesSection("Raises", "raises")
    assert obj != None

# Generated at 2022-06-21 11:48:57.441344
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np = NumpydocParser()

    assert(isinstance(np.sections, dict))
    assert(np.titles_re is not None)

# Generated at 2022-06-21 11:49:01.151552
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecated"
    key = "deprecation"
    ds = DeprecationSection(title, key)
    pattern = r"^\.\.\s*(" + title + ")\s*::"
    assert ds.title_pattern == pattern


# Generated at 2022-06-21 11:49:05.901266
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kvSection = _KVSection('', '')
    kvSection._parse_item = lambda key, value: DocstringParam(args=[''], description=_clean_str(value))
    text = '''
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    '''
    kvSection.parse(text)

# Generated at 2022-06-21 11:49:12.226984
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_section = ReturnsSection("Returns", "returns")
    assert test_section.key == "returns", "Returns section key should be 'returns'"
    assert test_section.title == "Returns", "Returns section title should be 'Returns'"
    assert test_section.is_generator == False, "Generator name should be false"


# Generated at 2022-06-21 11:49:38.209112
# Unit test for method parse of class Section
def test_Section_parse():
    test_section = Section("test_section","test")
    assert(test_section.parse("test text") == [DocstringMeta(["test"],description = "test text")])

# Generated at 2022-06-21 11:49:39.431620
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection("Yields", "yields")
    assert section.is_generator == True 


# Generated at 2022-06-21 11:49:47.103070
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    '''A unittest for the DeprecationSection class'''
    text = "1.0.0\na description"
    hasCode = True
    for match in DeprecationSection("deprecated", "deprecation").parse(text):
        if len(match.description) == 0: hasCode = False
    assert hasCode == True
    assert match.description == "a description"
    assert match.version == "1.0.0"

# Generated at 2022-06-21 11:49:56.672908
# Unit test for constructor of class _KVSection
def test__KVSection():
    ParamSection("Parameters", "param")
    ParamSection("Params", "param")
    ParamSection("Arguments", "param")
    ParamSection("Args", "param")
    ParamSection("Other Parameters", "other_param")
    ParamSection("Other Params", "other_param")
    ParamSection("Other Arguments", "other_param")
    ParamSection("Other Args", "other_param")
    ParamSection("Receives", "receives")
    ParamSection("Receive", "receives")
    RaisesSection("Raises", "raises")
    RaisesSection("Raise", "raises")
    RaisesSection("Warns", "warns")
    RaisesSection("Warn", "warns")
    ParamSection("Attributes", "attribute")
    ParamSection("Attribute", "attribute")
    Returns

# Generated at 2022-06-21 11:50:03.423298
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    ndp = NumpydocParser()
    first_section = Section("First Section", "first")
    second_section = Section("Second Section", "second")
    ndp.add_section(first_section)
    ndp.add_section(second_section)
    assert ndp.sections["First Section"] == first_section
    assert ndp.sections["Second Section"] == second_section

# Generated at 2022-06-21 11:50:05.348327
# Unit test for method parse of class Section
def test_Section_parse():
    string = """Section
    -
    Returns:
        docstring"""

    test = Section("Section", "Section")
    a = test.parse(string)
    assert(a is not None)
    assert(next(a).description == string.strip().split("\n")[1].strip())



# Generated at 2022-06-21 11:50:09.705850
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert isinstance(s, Section)
    assert s.title == "title"
    assert s.key == "key"
    assert s.title_pattern == "^\\.\\.\\s*(title)\\s*::"


# Generated at 2022-06-21 11:50:11.392158
# Unit test for constructor of class ParamSection
def test_ParamSection():
    print("test_ParamSection")
    ps = ParamSection("Parameters","param")
    print(ps.title)


# Generated at 2022-06-21 11:50:13.132646
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	parser = NumpydocParser()
	assert parser is not None

# Generated at 2022-06-21 11:50:17.741819
# Unit test for method parse of class Section
def test_Section_parse():
    p = NumpydocParser()
    assert str(p.parse('a\n------\nb')) == str(Docstring(short_description='a', long_description='b', blank_after_short_description=True, blank_after_long_description=True, meta=[]))

# Generated at 2022-06-21 11:51:05.671994
# Unit test for constructor of class _KVSection
def test__KVSection():
    try:
        _KVSection("Parameters", "param")
    except:
        raise AssertionError("Fail to construct a _KVSection object")

# Generated at 2022-06-21 11:51:14.917001
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """Tests for ParamSection"""
    assert ParamSection("Parameters", "param").title == "Parameters"
    assert ParamSection("Parameters", "param").key == "param"
    assert ParamSection("Parameters", "param").title_pattern == "^Parameters\\s*?\n-{9}\\s*$"
    assert ParamSection("Parameters", "param").parse("x") is not None
    assert ParamSection("Parameters", "param")._parse_item("key", "value").args == ["param", "key"]

# Generated at 2022-06-21 11:51:24.801906
# Unit test for function parse
def test_parse():
    docstring = '''
        This is a new module for doing things.

        It's not complete, but it should do.

        Parameters
        ----------
        arg1 : int
            An integer argument.
        arg2 : str
            A string argument.
        arg3 : optional
            An optional argument.

        Returns
        -------
        dict
            A dictionary of items.

        Raises
        ------
        ValueError
            If things are not done correctly.

        Examples
        --------
        Example usage follows.
        Here's some more example text.
    '''

# Generated at 2022-06-21 11:51:27.094209
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    t = RaisesSection("Raises", "raises")
    assert(t.title == "Raises")
    assert(t.key == "raises")



# Generated at 2022-06-21 11:51:33.287947
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser_default = NumpydocParser()
    parser_customized = NumpydocParser({
        "test_section": ParamSection("test_section", "test_key"),
    })

    assert DEFAULT_SECTIONS == list(parser_default.sections.values())
    assert list(parser_customized.sections.values()) == [ParamSection("test_section", "test_key")]
    assert parser_default._setup() == None
    assert parser_customized._setup() == None


# Generated at 2022-06-21 11:51:41.352234
# Unit test for method parse of class Section
def test_Section_parse():
    # method parse of section has been designed to operate over
    # the entire body of a docstring section. 
    # This test checks the method works with a section containing
    # only a single argument
    section = Section(title = 'Test', key = 'test')
    text = """
    FirstParam
        FirstParam description
    """
    res = next(section.parse(text))
    assert res.args == ['test', 'FirstParam']
    assert res.description == 'FirstParam description'


# Generated at 2022-06-21 11:51:52.235122
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """Parses the numpy-style docstring into its components.
    :returns: parsed docstring"""
    result = parser.parse(text)
    assert result.short_description is not None
    assert result.short_description == "Parses the numpy-style docstring into its components."
    assert result.long_description is None
    assert result.meta is not None
    assert len(result.meta) is 1
    assert result.meta[0].args == ['returns']
    assert result.meta[0].description == "parsed docstring"
    text = """Short description
    Long description
    Parameters
    ----------
    section : Section
        the section"""
    result = parser.parse(text)
    assert result.short_description is not None
    assert result

# Generated at 2022-06-21 11:52:04.263137
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

# Generated at 2022-06-21 11:52:07.995911
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # first test
    assert RaisesSection("Raises", "raises")
    # second test
    assert RaisesSection("Raise", "raises")
    # third test
    assert RaisesSection("Warns", "warns")
    # fourth test
    assert RaisesSection("Warn", "warns")


# Generated at 2022-06-21 11:52:12.523708
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection(title="Returns", key="returns")
    assert r.title == "Returns"
    assert r.key == "returns"
    assert r.is_generator is False
    assert r.title_pattern == r"^\.\.\s*Returns\s*::"


# Generated at 2022-06-21 11:53:06.555313
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    dummy_title = "_SphinxSection"
    dummy_key = "dummy_key"
    dummy_section = _SphinxSection(dummy_title, dummy_key)

    assert dummy_section.title_pattern == r"^\.\.\s*(_SphinxSection)\s*::", \
        "Constructor of class _SphinxSection not well constructed"

# Generated at 2022-06-21 11:53:10.424665
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("Parameters", "param")
    res = sec.parse("arg_name\n\targ_description")

    assert next(res).args == ["param", "arg_name"]
    assert next(res).description == "arg_description"

# Generated at 2022-06-21 11:53:13.437005
# Unit test for constructor of class Section
def test_Section():
    test_Section = Section(title = "Parameters", key = "param")
    assert test_Section.title == "Parameters"
    assert test_Section.key == "param"


# Generated at 2022-06-21 11:53:19.733025
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # The text to be tested
    text = """Deprecated: The iteration over the test is wrong, the test is not properly initialized.
    """
    doc = NumpydocParser().parse(text)
    for i in doc.meta:
        print(i.args)
        print(i.description)
        print(i.version)

# Generated at 2022-06-21 11:53:28.193485
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # test
    p = NumpydocParser()
    text = """
    Deprecated since version 1.12.0: $f(x)$ is deprecated.
    It will be removed in version 2.0.0.

    $f(x)$ will be replaced by $f_\mathrm{other}(x)$.
    """
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    parse_result = deprecation_section.parse(text)
    # check
    assert len(parse_result) == 1
    assert parse_result[0].description == ""
    assert parse_result[0].version == "version 1.12.0"

# Generated at 2022-06-21 11:53:30.049261
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param").title == 'Parameters'
    assert ParamSection("Parameters", "param").key == 'param'

# Generated at 2022-06-21 11:53:33.045648
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    text = '''
.. deprecated:: version_number
    description
'''
    assert DeprecationSection('deprecated', 'deprecation').parse(text) == [DocstringDeprecated(args=['deprecation'], description='description', version='version_number')]

# Generated at 2022-06-21 11:53:37.230542
# Unit test for function parse
def test_parse():
    import re
    import collections

    # remove newline from string, this is needed because doctest adds newline
    def test(text):
        text = re.sub("\n", "", text)
        return parse(text)

    assert test("") == Docstring("", None, None, False, False)
    assert test("a") == Docstrin

# Generated at 2022-06-21 11:53:38.640826
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation") != None


# Generated at 2022-06-21 11:53:40.977449
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == 25
