

# Generated at 2022-06-21 11:45:45.489594
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection("title","key").parse("")) == []
    assert list(_KVSection("title","key").parse("something")) == []
    assert list(_KVSection("title","key").parse("key\nvalue")) == [DocstringMeta([], description='value')]
    assert list(_KVSection("title","key").parse("key\nvalue\nkey2\nvalue2")) == [DocstringMeta([], description='value'), DocstringMeta([], description='value2')]


# Generated at 2022-06-21 11:45:49.181589
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raisesSection = RaisesSection("Raises", "raises")
    # negative test, it raises ValueError when no text is given
    raisesSection._parse_item("A", "")


# Generated at 2022-06-21 11:45:59.376760
# Unit test for function parse
def test_parse():
    text = \
    """
    A nifty little function to do
    
    some things

    Parameters
    ----------

    n : int
       some stuff
    a : int, optional
       more stuff
       
    Returns
    -------
    
    out : int
       some output
    """
    parsed = parse(text)

    assert parsed.short_description == "A nifty little function to do"
    assert parsed.long_description == "some things"
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

    assert len(parsed.meta) == 2
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].args == ["param", "n"]

# Generated at 2022-06-21 11:46:01.875951
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    if __name__=="__main__":
        YieldsSection("Yields", "yields")

# Generated at 2022-06-21 11:46:12.906401
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Example docstring
    TEMPLATE = """
    .. deprecated:: 1.0
        This module is deprecated
    """
    doc = NumpydocParser()
    # Check that the section was not in the list
    assert 'deprecated' not in doc.sections
    # Adding a new section
    doc.add_section(DeprecationSection("deprecated", "deprecation"))
    # Check that the section was added to the list
    assert 'deprecated' in doc.sections
    # Parse the docstring and check that it was properly parsed
    assert doc.parse(TEMPLATE).meta == [DocstringMeta(['deprecation'], version='1.0', description='This module is deprecated')]


# Generated at 2022-06-21 11:46:17.771809
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection("", "")
    assert a.title == ""
    assert a.key == ""

    b = _KVSection("Parameters", "param")
    assert b.title == "Parameters"
    assert b.key == "param"



# Generated at 2022-06-21 11:46:24.773091
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    desc1 = 'function_name\n\nThis is a function documentation\nThis function does something\n\nArgs:\n    a (int): something\n    b (int): something else\n'
    desc2 = 'function_name\n\nThis is a function documentation\nThis function does something\n\nParameters:\n    a (int): something\n    b (int): something else\n'
    np = NumpydocParser()
    s = Section('Parameters', 'param')
    np.add_section(s)
    doc1 = parse(desc1)
    doc2 = parse(desc2)
    assert doc1 == doc2

# Generated at 2022-06-21 11:46:33.605995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    print(parser.parse(''))

    # Here is an example for the short_description, long_description, blank_after_short_description, blank_after_long_description, meta:
    # short_description: 'Function to compute the average rank of a list of numbers'
    # long_description : 'This function computes the size of a list of numbers'
    # blank_after_short_description: True
    # blank_after_long_description: False
    # meta: [DocstringMeta args=['param'], DocstringParam args=['param', 'x'], DocstringMeta args=['param'], DocstringParam args=['param', 'weights'], DocstringMeta args=['returns'], DocstringReturns args=['returns'], DocstringReturns args=['returns']]
    text

# Generated at 2022-06-21 11:46:42.074812
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    input_text = "key\n\tvalue\nkey2 : type\n\tdescriptions can also span...\n\t... multiple lines"
    expected_docstring_meta = [DocstringMeta([], description="value"), DocstringMeta([], description="descriptions can also span...\n... multiple lines")]
    output_docstring_meta = list(ParamSection("", "").parse(input_text))
    assert len(output_docstring_meta) == len(expected_docstring_meta)
    assert all(m1 == m2 for m1, m2 in zip(output_docstring_meta, expected_docstring_meta))


# Generated at 2022-06-21 11:46:44.864671
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"


# Generated at 2022-06-21 11:46:56.903831
# Unit test for constructor of class Section
def test_Section():
    """
    >>> import libdocstring.numpydoc as npd
    >>> s = npd.Section(title="T",key="K")
    >>> s.title
    'T'
    >>> s.key
    'K'
    >>> s.title_pattern
    '^(T)\\s*?\\n-*\\s*$'
    >>> s.parse("Text")
    (<libdocstring.numpydoc.DocstringMeta object at 0x7f5b5c7e19e8>)
    """


# Generated at 2022-06-21 11:47:00.850779
# Unit test for constructor of class _KVSection
def test__KVSection():
    r = _KVSection("Parameters", "param")
    assert r.title == "Parameters"
    assert r.key == "param"
    assert r.title_pattern == "^Parameters\s*?\n----\s*$"

# Generated at 2022-06-21 11:47:11.376810
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    print("Testing constructor of NumpydocParser class")
    test_section_1 = Section("Title_1","key_1")
    test_section_2 = Section("Title_2","key_2")
    test_section_3 = Section("Title_3","key_3")
    test_section_4 = Section("Title_4","key_4")
    test_section_1_result = [test_section_1, test_section_2, test_section_3, test_section_4]
    test_sections_list = {"Title_1":test_section_1,"Title_2":test_section_2,"Title_3":test_section_3,"Title_4":test_section_4}
    test_NumpydocParser = NumpydocParser(test_sections_list)
    assert test_Numpyd

# Generated at 2022-06-21 11:47:24.090702
# Unit test for constructor of class Section
def test_Section():
    # Test the Section class
    # Test 1
    # title = Parameter
    # key = param
    # Expectation: title = Parameter , key = param
    # Actual: title = Parameter , key = param
    print("Test 1")
    obj = Section(title = "Parameter", key = "param")
    assert obj.title == "Parameter"
    assert obj.key == "param"
    print(obj)
    print("Title: " + obj.title)
    print("Key: " + obj.key)
    print("Title_pattern: " + obj.title_pattern)
    # Test 2
    # title = Args
    # key = args
    # Expectation: title = Args , key = args
    # Actual: title = Args , key = args
    print("Test 2")

# Generated at 2022-06-21 11:47:33.119045
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """ \
    numpy_title
    ------------
    numpy_section
    ------------
    """
    npparser = NumpydocParser()
    npparser.add_section(Section("numpy_title", "numpy_title"))
    doc_string = npparser.parse(text)

    assert doc_string is not None
    assert doc_string.short_description == "numpy_title"
    assert doc_string.long_description == None
    assert (
        doc_string.meta[0].description
        == "numpy_section ------------ "
    )




# Generated at 2022-06-21 11:47:40.475373
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    '''
    text = inspect.cleandoc(text)
    class _KVSectionMock(object):
        def _parse_item(self, key, value):
            return (key, value)
    _KVSectionInstance = _KVSectionMock()
    _KVSectionInstance.key = 'key'
    result = list(_KVSectionInstance.parse(text))
    expected = [
        ('key', 'value'),
        ('key2 : type', 'values can also span...\n... multiple lines')
    ]
    assert result == expected



# Generated at 2022-06-21 11:47:43.869768
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("TEST", "test"))
    assert parser.sections["TEST"] == Section("TEST", "test")

# Generated at 2022-06-21 11:47:47.885560
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection('Parameters', 'param')
    assert section._KVSection__title == 'Parameters'
    assert section._KVSection__key == 'param'
    assert section.title == 'Parameters'
    assert section.key == 'param'


# Generated at 2022-06-21 11:47:51.356929
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section = Section("Hello", "hello")
    numpydoc_parser.add_section(section)
    assert "Hello" in numpydoc_parser.sections.keys()
    assert numpydoc_parser.sections["Hello"] == section

# Generated at 2022-06-21 11:47:52.893828
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("Parameters", "param")



# Generated at 2022-06-21 11:48:10.377134
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Sample docstring
    docstring = """
    Test docstring

    This is a long description yay
    yay

    Parameters
    ----------
    name : string
        The name of the person.

    Returns
    -------
    None

    Raises
    ------
    Exception
        Error while deleting.
    """
    result = NumpydocParser().parse(docstring)
    assert (result.short_description == "Test docstring")
    assert (result.long_description == "This is a long description yay\nyay")
    assert (result.blank_after_short_description)
    assert (result.blank_after_long_description)
    assert (len(result.meta) == 3)  # 3 sections in the docstring

# Generated at 2022-06-21 11:48:21.921045
# Unit test for constructor of class _KVSection
def test__KVSection():
    p1 = _KVSection("Parameters", "param")
    assert p1.title == "Parameters"
    assert p1.key == "param"
    assert p1.parse("toto") == (DocstringMeta(["param"], description="toto"),)
    assert p1.title_pattern == "^Parameters\s*?\n-*$"
    p2 = _KVSection("Params", "param")
    assert p2.parse("toto") == (DocstringMeta(["param"], description="toto"),)
    p3 = _KVSection("Arguments", "param")
    assert p3.parse("toto") == (DocstringMeta(["param"], description="toto"),)
    p4 = _KVSection("Args", "param")

# Generated at 2022-06-21 11:48:29.751697
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test case 1:
    # Test method parse of class NumpydocParser
    def test_case_NumpydocParser_parse_1():
        test_NumpydocParser_parse_title = "Test case 1: Test method parse of class NumpydocParser"
        print_test_title(test_NumpydocParser_parse_title)

        # Test statements

# Generated at 2022-06-21 11:48:30.583427
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection("Parameters", "param")

# Generated at 2022-06-21 11:48:39.099824
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    parser = NumpydocParser()
    parser.add_section(ReturnsSection("Returns", "returns"))
    text = '''
    .. Returns::

        int
    
        Return times

        Return names are optional, types are required
    '''
    doc = parser.parse(text)
    assert doc.meta[0].meta_class == "returns"
    assert doc.meta[0].args == ["returns"]
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].return_name is None
    assert doc.meta[0].description == "Return times"
    assert doc.meta[1].type_name is None
    assert doc.meta[1].return_name is None
    assert doc.meta[1].description == "Return names are optional, types are required"


# Generated at 2022-06-21 11:48:48.607319
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        one
        two
            three
        four
            five
            six
    """
    ret = NumpydocParser({
        'one': Section('one', 'one'),
        'two': Section('two', 'two')
    }).parse(text)

    assert ret.meta[0].key == 'one'
    assert ret.meta[0].description == 'two'
    assert ret.meta[0].args == ['one', None]

    assert ret.meta[1].key == 'two'
    assert ret.meta[1].description == 'three'
    assert ret.meta[1].args == ['two', 'four']



# Generated at 2022-06-21 11:48:57.766451
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    my_text = 'foo_key\n    foo_value\n    foo_value_2\nbar_key : type\n    bar_value'

    parser = _KVSection('','')

    my_list = parser.parse(my_text)

    assert len(my_list) == 2
    assert my_list[0]._values['key'] == 'foo_key'
    assert my_list[0]._values['value'] == 'foo_value\nfoo_value_2'
    assert my_list[1]._values['key'] == 'bar_key'
    assert my_list[1]._values['value'] == 'bar_value'

# Generated at 2022-06-21 11:49:01.754604
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert section.title == "Raises"
    assert section.key == "raises"
    assert section.title_pattern == "^(Raises)\\s*?\\n{}\\s*$".format("-" * len("Raises"))


# Generated at 2022-06-21 11:49:13.488149
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    title = "Returns"
    key = "returns"
    sections = [ReturnsSection(title,key)]
    parser = NumpydocParser(sections)

    def foo():
        """
        This is a test function

        Returns
        -------
        int
            an integer, because
        """

    # Test the definition of foo
    docstring = parse(foo.__doc__)
    # 1 - test the number of sections
    assert(len(parser.sections) == 1)
    # 2 - test the key of the only section
    assert(parser.sections[parser.sections.keys()[0]].key == key)
    # 3 - test the title of the only section
    assert(parser.sections[parser.sections.keys()[0]].title == title)
    # 4 - test short description

# Generated at 2022-06-21 11:49:24.691852
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    title = "TestSection"
    key = "testkey"
    metas = "\n".join(["param1", "", "desc1", "param2 : int", "", "desc2"])

    class TestSection(Section):
        title = title
        key = key

        def _parse_item(self, key: str, value: str) -> DocstringParam:
            return DocstringParam(args=[self.key, key], description=value)

    parser = NumpydocParser()
    parser.add_section(TestSection())
    docstr = parser.parse(metas)

    # Assert multiple parameters were parsed
    assert len(docstr.meta) == 2
    # Assert first parameter had the expected name and description

# Generated at 2022-06-21 11:49:33.873337
# Unit test for method parse of class Section
def test_Section_parse():
    """
    Test the function parse of the class Section.
    """
    class DummySection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    dummy_section = DummySection("title", "key")
    assert dummy_section.parse("Description") == \
           [DocstringMeta(args=['key'],
                          description='Description')]



# Generated at 2022-06-21 11:49:35.052291
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param");

# Generated at 2022-06-21 11:49:35.817278
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns")


# Generated at 2022-06-21 11:49:36.740239
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    return r


# Generated at 2022-06-21 11:49:46.343762
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """A
          B
            C
          D
            E
            F
          G
            H
          """

    def func(key: str, value: str) -> DocstringMeta:
        return DocstringMeta([key, value], description=_clean_str(value))

    p = _KVSection("2", "2")
    p.parse=func
    # print(p._parse_item(text, text))
    sections = p.parse(text)
    sectionList = [i.__dict__ for i in sections]
    print(sectionList)



# Generated at 2022-06-21 11:49:53.776310
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    .. title:: something
        possibly over multiple lines
    """

    docstring = NumpydocParser()
    docstring.add_section(Section("title", "mykey"))
    parsed = docstring.parse(text)
    assert parsed.meta[0].args == ['mykey']
    assert parsed.meta[0].description == 'possibly over multiple lines'


if __name__ == "__main__":
    from .tests import pytest

    pytest.main(__file__)

# Generated at 2022-06-21 11:49:59.602138
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_text = '''
    test_key
        test_value
    '''
    factory = _KVSection('test_title', 'test_key')
    ret = factory.parse(test_text)
    assert 'test_key' == ret.args[1]
    assert 'test_value' == ret.description


# Generated at 2022-06-21 11:50:05.025994
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = 'deprecated :: Use "def func_foo(x, y)" instead.'
    factory = NumpydocParser().sections['deprecated']
    assert factory.parse(text) == [DocstringDeprecated(args=['deprecated'], description='Use "def func_foo(x, y)" instead.', version=None)]

# Generated at 2022-06-21 11:50:07.504482
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Parameters", "param")
    print(s._pairwise(KV_REGEX.finditer(text)))
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(match.group())


# Generated at 2022-06-21 11:50:10.117712
# Unit test for constructor of class _KVSection
def test__KVSection():
    n = _KVSection('title', 'key')
    title = n.title
    key = n.key
    assert title == 'title'
    assert key == 'key'

# Generated at 2022-06-21 11:50:15.558222
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    return_val = RaisesSection("test_key","test_value")
    return_val.parse("Text")

# Generated at 2022-06-21 11:50:16.714435
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser().sections

# Generated at 2022-06-21 11:50:20.644410
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("title", "key")
    # Test return of property title_pattern
    assert kv.title_pattern == "^title\n-*$"


# Generated at 2022-06-21 11:50:30.186589
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test 1
    meta = _KVSection("Examples", "examples").parse(
        text="""
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    )
    assert meta is not None
    assert len(meta) == 2
    # Test 2
    meta = _KVSection("Example", "examples").parse(
        text="""
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    )
    assert meta is not None
    assert len(meta) == 2


# Generated at 2022-06-21 11:50:41.651871
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('Single line desc\n\nLong desc')
    assert docstring.short_description == 'Single line desc'
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == 'Long desc'
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0
    docstring = parser.parse('Single line desc\nLong desc')
    assert docstring.short_description == 'Single line desc'
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == 'Long desc'
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0

# Generated at 2022-06-21 11:50:54.559211
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kvtext = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    kvtext = inspect.cleandoc(kvtext)
    # print(kvtext)
    # value = _KVSection('aa', 'bb').parse(kvtext)
    # print(value)
    # for i in value:
    #     print(i)



# Generated at 2022-06-21 11:50:56.005696
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection('title','key')
    return a

# Generated at 2022-06-21 11:50:59.813153
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection('titre','titre')
    assert s.title == 'titre'
    assert s.key == 'titre'
    assert s.title_pattern == r'^\.\.\s*(titre)\s*::'



# Generated at 2022-06-21 11:51:05.334387
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = NumpydocParser()
    # pass example string
    example = '''
        ValueError
            A description of what might raise ValueError
        '''
    match = RaisesSection("Raises", "raises").parse(example)
    assert next(match) == DocstringRaises(
        args=["raises", "ValueError"],
        description="A description of what might raise ValueError",
        type_name="ValueError" if len("ValueError") > 0 else None
    )


# Generated at 2022-06-21 11:51:17.909938
# Unit test for function parse
def test_parse():
    result = parse("""
    function
        description.

        Parameters
        ----------
        var1 : type
            description.

        Returns
        -------
        var2 : type
            description.
    """)

    assert result.short_description == "function"
    assert result.long_description == "description."
    assert len(result.meta) == 2

    assert result.meta[0].args == ["param", "var1"]
    assert result.meta[0].type_name == "type"
    assert result.meta[0].description == "description."

    assert result.meta[1].args == ["returns"]
    assert result.meta[1].type_name == "type"
    assert result.meta[1].description == "description."

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:51:43.490663
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    This function is a unit test to check the functionality of the add_section method of the NumpydocParser class.
    It runs a series of test and prints out Pass or Fail.
    """
    print('Starting test_NumpydocParser_add_section')

# Generated at 2022-06-21 11:51:53.842821
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    for title in ['',
                  ' ' * 50,
                  'foo' * 50,
                  ' ' * 50 + 'foo' * 50,
                  'foo' * 50 + ' ' * 50,
                  'foo' * 50 + ' ' * 50 + 'foo' * 50,
                  'foo' * 50 + ' ' * 100 + 'foo' * 50,
                  'foo']:
        s = _SphinxSection(title, 'key')
        title_pattern = s.title_pattern
        assert title_pattern.startswith('^')
        assert title_pattern.endswith('$')
        title_pattern = title_pattern[1:-1] # remove ^ and $
        assert title_pattern.count('(') == 1
        assert title_pattern.count(')') == 1
        assert title_pattern.find('(')

# Generated at 2022-06-21 11:51:59.942312
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    new_section = Section("New Section", "new_section")
    parser = NumpydocParser()
    assert('New Section' not in parser.sections)
    parser.add_section(new_section)
    assert('New Section' in parser.sections)
    assert(new_section == parser.sections['New Section'])



# Generated at 2022-06-21 11:52:01.468837
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    pars = NumpydocParser()
    pars.add_section(Section("MyTitle", "mykey"))
    assert pars.sections["MyTitle"].title == "MyTitle"
    assert pars.sections["MyTitle"].key == "mykey"

# Generated at 2022-06-21 11:52:03.291398
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").parse("1.0.0\nDeprecated") == [DocstringDeprecated([deprecation], version="1.0.0",description="Deprecated")]

# Generated at 2022-06-21 11:52:06.073336
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert NumpydocParser().parse(""".. deprecated:: 6.0
       Use :func:`bar` instead.""")


if __name__ == "__main__":
    test_DeprecationSection_parse()

# Generated at 2022-06-21 11:52:14.578535
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    A short description.

    More detailed description.

    Args:
        arg1 (int): Description of arg1.
        arg2 (:obj:`list` of :obj:`str`): Description of arg2.

    Returns:
        str: Description of return value.
    """
    metadata = parse(text)
    assert metadata['short_description'] == "A short description."
    assert metadata['long_description'] == "More detailed description."
    assert metadata['blank_after_short_description'] == True
    assert metadata['blank_after_long_description'] == True


# Generated at 2022-06-21 11:52:20.620312
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	assert RaisesSection("Raises", "raises").title == "Raises"
	assert RaisesSection("Raises", "raises").key == "raises"
	assert RaisesSection("Raises", "raises").title_pattern == "^Raises\s*?\n---*$"


# Generated at 2022-06-21 11:52:24.321250
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises", "raises")
    assert a.title == "Raises"
    assert a.key == "raises"
    assert a.title_pattern == "^(Raises)\\s*?\\n----\\s*$"



# Generated at 2022-06-21 11:52:27.366094
# Unit test for constructor of class ParamSection
def test_ParamSection():
    #Test 1
    a = ParamSection("Parameters", "param")
    assert a.title == 'Parameters'
    assert a.key == 'param'


# Generated at 2022-06-21 11:52:47.884686
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .version_aliases import parse_version
    section = DeprecationSection("deprecated", "deprecation")
    text = """
    .. deprecated:: 1.0
        Please stay away!
    """
    expected = DocstringDeprecated(
        args=[section.key],
        description="Please stay away!",
        version=parse_version("1.0"),
    )
    actual = list(section.parse(text))[0]
    assert expected == actual


# Generated at 2022-06-21 11:52:56.289560
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc(
    """
    Single line function description

    Parameters
    ----------
    arg1 : type of arg1
        Description of arg1.
    arg2 (optional) : type of optional arg2
        Description of arg2.
    some_keyword : type of some_keyword
        Description of some_keyword.

    Returns
    -------
    return_value : type of return_value
        Description of return_value.
    """
    )

    docstring = parse(text)
    assert docstring.short_description == "Single line function description"
    assert docstring.blank_after_short_description
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is False


# Generated at 2022-06-21 11:53:02.733233
# Unit test for function parse
def test_parse():
    text = """
    foo
        bar
        baz
    """

    parsed = parse(text)
    assert parsed.blank_after_short_description == True
    assert parsed.short_description == 'foo'
    assert parsed.blank_after_long_description == True
    assert parsed.long_description == 'bar\n\nbaz'
    assert parsed.meta == [DocstringMeta(['other'], 'bar\n\nbaz')]



# Generated at 2022-06-21 11:53:07.402693
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "ParamSection_test")
    assert p.title == "Parameters"
    assert p.key == "ParamSection_test"
    assert p.title_pattern == "^(Parameters)\\s*?\n{}\\s*$".format("-"*12)


# Generated at 2022-06-21 11:53:09.482137
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    assert Section(title,key).title == title
    assert Section(title,key).key == key


# Generated at 2022-06-21 11:53:18.425177
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Test function for NumpyDocParser test
    Parameters
    ----------
    x: int
        This is an integer.
    y: float
        This is a float.
    Returns
    -------
    result: str
        This is a string describing the results.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.meta[0].args == ["param", "x"]
    assert docstring.meta[1].args == ["param", "y"]
    assert docstring.meta[2].args == ["returns"]



# Generated at 2022-06-21 11:53:22.967441
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    text = """
    ValueError
        A description of what might raise ValueError
    """
    docString = r.parse(text)
    assert next(docString).description == "A description of what might raise ValueError"

# Generated at 2022-06-21 11:53:28.474632
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    text = "Deprecated since version 0.1.3:\nThis is a deprecation test."
    assert parser.parse(text) == \
        Docstring(
            short_description="",
            meta=[
                DocstringDeprecated(
                    args=["deprecation"],
                    description="This is a deprecation test.",
                    version="0.1.3",
                )
            ],
        )


# Generated at 2022-06-21 11:53:29.701727
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator == True


# Generated at 2022-06-21 11:53:31.455947
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # UNIT UNDER TEST
    deprec = DeprecationSection("Deprecated", "deprecated")
    assert deprec.title == "Deprecated"

# Generated at 2022-06-21 11:53:49.916849
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    This method tests the add_section() method of class NumpydocParser.
    """
    # setup
    parser = NumpydocParser()
    parser.add_section(Section("testing", "testing"))
    section_list = parser.sections
    # assertion
    AssertionError(isinstance(section_list, dict))



# Generated at 2022-06-21 11:53:51.297457
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	Section.__init__
	RaisesSection.__init__


# Generated at 2022-06-21 11:53:55.586638
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    Section1 = RaisesSection("Raises", "raises")
    # if parse parameter of  method parse is not a string
    assert Section1.parse(123) == None
    # if parse parameter of  method parse is a string
    Section1 = RaisesSection("Raises", "raises")
    assert Section1.parse('ValueError')

# Generated at 2022-06-21 11:54:01.736688
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    First line

    Second line
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "First line"
    assert docstring.long_description == "Second line"
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-21 11:54:02.927095
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
	NumpydocParser()

# Generated at 2022-06-21 11:54:11.233615
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    doc = "Test Method"
    def test_method(self):
        """
        Docstring

        Test
            Test
        """
    docstring = NumpydocParser().parse(inspect.getdoc(test_method))
    assert not docstring.meta
    section = Section("Test", "test")
    NumpydocParser().add_section(section)
    docstring = NumpydocParser().parse(inspect.getdoc(test_method))
    assert docstring.meta


# Generated at 2022-06-21 11:54:13.759316
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("test", "test")

    assert list(section.parse("test")) == [DocstringMeta(args=["test"], description="test")]



# Generated at 2022-06-21 11:54:21.276943
# Unit test for function parse
def test_parse():
    #desc = 'Function to calculate X-ray scattering of an arbitrary shape.'
    desc = 'something'
    #doc = """Parameters
    #----------
    #something
    #    something
    #Args:
    #    something
    #Raise
    #    something"""
    doc = """something"""
    assert parse(doc).short_description == desc
    assert parse(doc).long_description == None
    assert parse(doc).meta == []



# Generated at 2022-06-21 11:54:23.746074
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields").is_generator == True
    return True


# Generated at 2022-06-21 11:54:33.006220
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test that the method add_section of class NumpydocParser
    adds the section to the parser using the title as key
    """

    text = """This is a docstring.

    Parameters
    ----------
    parameter1 : int
        A first parameter.
    parameter2 : float, optional
        A second parameter.

    Returns
    -------
    value
        If the function returns a value.

    Yields
    ------
    value
        If the function yields values.

    Raises
    ------
    Exception
        If the function raises an exception.

    Example
    -------
    Example usage of this function.

    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    title_list = list(docstring.meta.keys())

    # add new section