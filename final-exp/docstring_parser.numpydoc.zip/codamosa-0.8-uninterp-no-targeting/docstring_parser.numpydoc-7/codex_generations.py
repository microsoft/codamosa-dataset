

# Generated at 2022-06-21 11:45:27.963152
# Unit test for constructor of class Section
def test_Section():
    section = Section("Test", "key")
    assert section.title == "Test"
    assert section.key == "key"


# Generated at 2022-06-21 11:45:31.448658
# Unit test for function parse
def test_parse():
    print(parse("""
    This is a test docstring

    Parameters
    ----------
    a : int
        description
    b : str
        description
    value
        description

    Returns
    -------
    result : int
        description

    Raises
    ------
    ValueError
        If invalid argument is passed
    """))


# Generated at 2022-06-21 11:45:34.282987
# Unit test for method parse of class Section
def test_Section_parse():
    assert list(Section("Parameters", "param").parse("a\n    b")) == [
        DocstringMeta(["param"], description="b")
    ]



# Generated at 2022-06-21 11:45:40.790527
# Unit test for method parse of class Section
def test_Section_parse():

    class TestSection(Section):
        def __init__(self):
            super().__init__(title="1111", key="2222")

        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key, key], description=value)

    text = """
    1111
    -----

    key1
    key2 : type
    """

    assert list(TestSection().parse(text)) == [
        DocstringMeta(["2222", "key1"], description=""),
        DocstringMeta(["2222", "key2"]),
    ]



# Generated at 2022-06-21 11:45:41.728809
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection('deprecated', 'deprecation')

# Generated at 2022-06-21 11:45:47.740084
# Unit test for constructor of class ParamSection

# Generated at 2022-06-21 11:45:57.466644
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    numpy_doc_text= """
    Yields
    ------
    type
        The reduced version of the input. If the input contains a single
        element, that element is returned.
    """
    numpy_doc_text='''
    Yields
    ------
    type
        The reduced version of the input. If the input contains a single
        element, that element is returned.
    '''
    sec=YieldsSection('Yields', 'yields')
    section_string=sec.parse(numpy_doc_text)
    for m in section_string:
        print(m.__dict__)

# Generated at 2022-06-21 11:46:10.051823
# Unit test for function parse
def test_parse():
    text = """\
    Single-line description goes here.

    This can also be a longer description that spans multiple lines.
    If it does span multiple lines, each new line should be indented.

    Parameters
    ----------
    arg_name
        Description of an argument. If the description spans
        multiple lines, each new line should be indented.

    arg_2 :
        Multi-line descriptions of arguments can be written
        this way.
    """

    parsed = parse(text)


# Generated at 2022-06-21 11:46:13.912552
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("Parameters", "param")
    assert sec.parse("a\n    a's description") == [
        DocstringMeta(["param"], "a's description")
    ]



# Generated at 2022-06-21 11:46:18.178215
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    param = ParamSection("Parameters", "param")
    assert list(param.parse("""first : int
    first param description
    second : int
    second param description""")) == [
        DocstringParam(
            ['param', 'first'],
            description='first param description',
            arg_name='first',
            type_name='int',
            is_optional=False,
            default=None,
        ),
        DocstringParam(
            ['param', 'second'],
            description='second param description',
            arg_name='second',
            type_name='int',
            is_optional=False,
            default=None,
        ),
    ]

    raises = RaisesSection("Raises", "raises")

# Generated at 2022-06-21 11:46:26.210522
# Unit test for constructor of class _KVSection
def test__KVSection():
    pass

# Generated at 2022-06-21 11:46:30.132919
# Unit test for constructor of class Section
def test_Section():
    par = Section('Parameters','param')
    assert par.title == 'Parameters'
    assert par.key == 'param'
    assert par.title_pattern == r'^Parameters\s*?\n\-{9}\s*$'
    assert par.parse('') == []
    assert par.parse('') is not None

# Generated at 2022-06-21 11:46:34.160607
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_section = YieldsSection("Yields", "yields")
    assert yields_section.title == "Yields"
    assert yields_section.key == "yields"
    assert yields_section.is_generator == True

# Generated at 2022-06-21 11:46:43.701081
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Testing DeprecationSection.parse method"""
    dp =  DeprecationSection("Deprecated", "deprecation")
    
    dp_input_1 = "deprecation warning"
    dp_output_1 = [DocstringDeprecated(args=['deprecation'], description=None, version=None)]
    assert dp.parse(dp_input_1) == dp_output_1 

    dp_input_2 = ".. deprecation::\n   deprecation warning message"
    dp_output_2 = [DocstringDeprecated(args=['deprecation'], description='deprecation warning message', version=None)]
    assert dp.parse(dp_input_2) == dp_output_2
   

# Generated at 2022-06-21 11:46:47.846027
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    expected_key = "raises"
    expected_title = "Raises"

    section = RaisesSection(expected_title, expected_key)

    assert section.title == expected_title
    assert section.key == expected_key


# Generated at 2022-06-21 11:46:53.041291
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    examples = [
    ".. deprecated:: 3.1",
    ".. deprecated:: 3.1\n   some comment\n   more lines...\n"
    ]
    for example in examples:
        assert _SphinxSection('deprecated','deprecated').title_pattern in example

# Generated at 2022-06-21 11:47:05.317412
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Parsing a docstring with numpydoc-style sections
    text = """
    Function to test parsing

    This is a very descriptive
    long description


    Parameters
    ----------
    param : int
        Describe the int in a long
        line

    arg : str
        Describe the str

    See Also
    --------
    test_section
    """

# Generated at 2022-06-21 11:47:14.481493
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    N = NumpydocParser()

# Generated at 2022-06-21 11:47:16.594313
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection('deprecated', 'deprecation')

# Generated at 2022-06-21 11:47:19.481437
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser_hello = _KVSection('hello', 'hello')
    parser_hello.parse('hello, world!\n')


# Generated at 2022-06-21 11:47:33.271737
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    input_string = "Returns a value."
    result = ReturnsSection("Returns", "returns").parse(input_string).next()
    expected_result = DocstringReturns(
        [
            "returns"
        ],
        None,
        None,
        None,
        False
    )
    assert result.args == expected_result.args
    assert result.description == expected_result.description
    assert result.type_name == expected_result.type_name
    assert result.is_generator == expected_result.is_generator
    assert result.return_name == expected_result.return_name
    assert result.bases == expected_result.bases


# Generated at 2022-06-21 11:47:35.709669
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections['Parameters'].title_pattern == r'^Parameters\s*?\n-*\s*$'

# Generated at 2022-06-21 11:47:45.152336
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "This func will be deprecated in version 3.2"
    assert list(DeprecationSection("deprecated", "deprecation").parse(text)) == \
        [DocstringDeprecated(args=['deprecation'], description='None', version='3.2')]
    text = "This func will be deprecated in version 3.2\n"\
           "because it is too slow"
    assert list(DeprecationSection("deprecated", "deprecation").parse(text)) == \
        [DocstringDeprecated(args=['deprecation'], description='because it is too slow', version='3.2')]

# Generated at 2022-06-21 11:47:52.237176
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = NumpydocParser()
    x = a.parse(r"""
    This is a test.

    Parameters
    ----------
    x : int
        test x
    y : int
        test y
    """)
    assert x.short_description == 'This is a test.', "Wrong short description for NumpydocParser parse function."
    assert str(x.meta[0]) == 'param : x : int : \n test x', "Wrong meta data for NumpydocParser parse function."
    assert str(x.meta[1]) == 'param : y : int : \n test y', "Wrong meta data for NumpydocParser parse function."


# Generated at 2022-06-21 11:48:01.191867
# Unit test for function parse
def test_parse():
    text = """
    This is a function.
    It is not a really useful function.
    Parameters
    ----------
    param : str
        Parameter one.
    param2 : bool, optional
        Parameter two. Default is True.
    Returns
    -------
    None
    """
    ret = parse(text)
    assert ret.short_description == 'This is a function.'
    assert ret.long_description == 'It is not a really useful function.'
    assert len(ret.meta) == 3
    assert ret.meta[0].description == 'This is a function.'
    assert ret.meta[1].args == ['param', 'param2']
    assert ret.meta[1].description == 'Parameter two. Default is True.'
    assert ret.meta[2].args == ['returns']

# Generated at 2022-06-21 11:48:10.222427
# Unit test for constructor of class ParamSection
def test_ParamSection():
	par = ParamSection('Parameters','param')
	assert par.title_pattern == '^(Parameters)\s*?\n{}\s*$'.format('-' * len('Parameters'))
	assert par.parse(inspect.cleandoc('key: type, optional\n\tvalue')) == (DocstringParam(
            args=['param', 'key'],
            description='value',
            arg_name='key',
            type_name='type',
            is_optional=True,
            default=None,
        ),)


# Generated at 2022-06-21 11:48:16.684225
# Unit test for method parse of class Section
def test_Section_parse():
    section_parser = Section("Parameters", "param")
    title = "Parameters"
    text = """
        Parameters
        ----------
        x

            description
        """
    text_cleaned = inspect.cleandoc(text)

    y = section_parser.parse(text_cleaned)
    for meta in y:
        assert meta.args == ['param']
        print(meta.description)



# Generated at 2022-06-21 11:48:26.435043
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
        Parameters
        ----------
        a: int
            a is an integer.
        b: float
            b is a float.

        Returns
        -------
        c: int
            c is a square of a.
    """

    docstring_parser = NumpydocParser()

    # Check that the default sections are recognized

# Generated at 2022-06-21 11:48:32.269496
# Unit test for method parse of class Section
def test_Section_parse():
    title = 'Parameters'
    key = 'param'
    content = 'arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines'
    param = Section(title, key)
    assert str(param.parse(content)) == "[<DocstringMeta(['param', 'arg_name'], description='arg_description', params=[])>, <DocstringMeta(['param', 'arg_2'], description='descriptions can also span...\n    ... multiple lines', params=[])>]"
    # test _parse_item()
    # _parse_item() return a DocstringParam
    # the method DocstringParam have a function __repr__()
    # so we can use string representation to compare
    # and the output is 
    # <DocstringParam(['

# Generated at 2022-06-21 11:48:36.884239
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    body_text = 'Type, optional\n' + \
                'Description of this section'
    expected_meta = DocstringReturns(
        args=['returns'],
        description=_clean_str('Description of this section'),
        type_name=None,
        is_generator=False,
        return_name=None
    )
    parser = ReturnsSection('Returns', 'returns')
    assert next(parser.parse('\n' + body_text)) == expected_meta

# Generated at 2022-06-21 11:48:44.595701
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    from .common import DocstringMeta

    class MySection(Section):
        """Test for method add_section."""

        def parse(self, text):
            yield DocstringMeta([self.key], description="{}:{}".format(self.title, text))

    parser = NumpydocParser()
    parser.add_section(MySection("hello", "hello"))

    docstring = parser.parse("hello:\nThis is a description of the test.")
    assert docstring.meta[0].description == "hello:This is a description of the test."

# Generated at 2022-06-21 11:48:49.820380
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """One-line description.

More information, possibly spanning multiple lines.

Args:
    arg1 : optional, type
        Description of arg1
    arg2 : another_optional, another_type, optional
        Description of arg2. Default is 5.
    arg3 : another_optional, another_type(optional)
        Description of arg3. Optional.

Returns:
    (int) : The return value. 5

Raises:
    AttributeError
        The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError
        If `param2` is equal to `param1`.

"""
    parser = NumpydocParser()
    doc = parser.parse(docstring)
    doc2 = parse(docstring)
    # Test doc
    assert doc.short_

# Generated at 2022-06-21 11:49:00.536385
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection("Example","Example")
    text = (
    '''
    Name 1
       This is the first example.
       This is the first example.
       This is the first example.
       This is the first example.

    Name 2
       This is the second example.
       This is the second example.
       This is the second example.
       This is the second example.

    Name 3
       This is the third example.
       This is the third example.
       This is the third example.
       This is the third example.
    ''')
    text = inspect.cleandoc(text)

# Generated at 2022-06-21 11:49:04.873923
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    s = Section(title, key)
    assert s.title == title
    assert s.key == key
    assert s.title_pattern == r"^({})\s*?\n{}\s*$".format(title, "-"*len(title))
    assert s.parse("test") == [DocstringMeta(["param"], description="test")]


# Generated at 2022-06-21 11:49:06.552877
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("deprecated", "deprecation")
    # Test property Attributes
    dep.title
    dep.key
    dep.title_pattern
    dep.parse()

# Generated at 2022-06-21 11:49:14.462495
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """.. deprecated:: 0.10.0
            This function is no longer supported; Please use the
            ``indices`` method."""

    ds = DeprecationSection("deprecated", "deprecation").parse(text)
    ds = [ x for x in ds]
    assert (ds[0].version == "0.10.0")
    assert (ds[0].description == "This function is no longer supported; Please use the\n``indices`` method.")

# Generated at 2022-06-21 11:49:25.626544
# Unit test for function parse
def test_parse():
    parser = NumpydocParser()
    section1 = Section(title="Returns", key="returns")
    parser.add_section(section1)

    section2 = Section(title="## Returns", key="returns")
    parser.add_section(section2)

    section3 = Section(title="Returns:", key="returns")
    parser.add_section(section3)

    section4 = Section(title="Returns", key="Returns")
    parser.add_section(section4)

    assert parser.titles_re.search(text="Returns").group() == "Returns"
    assert parser.titles_re.search(text="## Returns").group() == "## Returns"
    assert parser.titles_re.search(text="Returns:").group() == "Returns:"

# Generated at 2022-06-21 11:49:31.841916
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # Parser for numpydoc sections with sphinx-style syntax.
    # E.g. sections that look like this:
    #     .. title:: something
    #         possibly over multiple lines
    section_obj = _SphinxSection('title', None)
    assert(section_obj.title == 'title')
    assert(not section_obj.key)
    assert(section_obj.title_pattern == r'^\.\.\s*(title)\s*::')


# Generated at 2022-06-21 11:49:33.127169
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")

# Generated at 2022-06-21 11:49:39.709429
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # Test case 1, title_pattern should be "^\.\.\s*(argument)\s*::"
    title = "argument"
    key = "arg"
    section = _SphinxSection(title, key)
    title_pattern = section.title_pattern
    assert title_pattern == "^\.\.\s*(argument)\s*::", "Should be: ^\.\.\s*(argument)\s*::"

# Generated at 2022-06-21 11:49:51.535382
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = NumpydocParser().sections
    assert len(sections) == len(DEFAULT_SECTIONS)
    for section in sections.values():
        assert isinstance(section, Section)

# Generated at 2022-06-21 11:49:55.532029
# Unit test for constructor of class Section
def test_Section():
    expected = Section("See Also", "see_also")
    assert expected.title == "See Also"
    assert expected.key == "see_also"
    assert re.match(expected.title_pattern, "See Also\n--------")


# Generated at 2022-06-21 11:49:58.132875
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # instantiate a NumpydocParser
    parser = NumpydocParser()
    assert parser.sections['Parameters'].key == 'param'


# Generated at 2022-06-21 11:50:10.251212
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Create a string to test the method
    test_string = "arg_name\r\narg_description\r\narg_2 : type, optional\r\n\r\ndescriptions can also span...\r\n... multiple lines"
    # Parse the string
    test_parse = ParamSection("Parameters", "param").parse(test_string)
    assert isinstance(test_parse,list)
    assert isinstance(test_parse[0],DocstringParam)
    assert test_parse[0].description == 'arg_description'
    assert test_parse[0].type_name == 'type'
    assert test_parse[0].is_optional == True
    assert test_parse[0].default == None
    assert test_parse[1].description == 'descriptions can also span...\n... multiple lines'


# Generated at 2022-06-21 11:50:14.549970
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == r"^(Parameters)\s*?\n-----\s*$"



# Generated at 2022-06-21 11:50:24.229431
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
    1

    2 

    3

    4 : int
    '''
    text = inspect.cleandoc(text)
    assert text
    kv_reg = re.compile(r'^[^\s].*$', flags=re.M)
    for match, next_match in _pairwise(kv_reg.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(inspect.cleandoc(value))


# Generated at 2022-06-21 11:50:36.767303
# Unit test for method parse of class Section
def test_Section_parse():
    test_text = """
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    ------
    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """

    test_text = inspect.cleandoc(test_text)
    test_result = ParseNumpy(test_text)
    

    assert len(test_result) == 2
    assert test_result[0].description == "arg_description"
    assert test_result[0].type_name == "type"
    assert test_result[0].is_optional == True
    

    assert test_result[1].description == "A description of what might raise ValueError"

# Generated at 2022-06-21 11:50:37.904741
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = ParamSection("Parameters", "param")
    assert parser.title == "Parameters"
    assert parser.key == "param"


# Generated at 2022-06-21 11:50:44.245110
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Setup test
    numpydocParser = NumpydocParser()
    numpydocParser._setup = Mock()
    numpydocParser.sections = Mock()
    numpydocParser.sections.__setitem__ = Mock()

    # Test
    test_section = Section("testTitle", "testKey")
    numpydocParser.add_section(test_section)

    # Assertions
    numpydocParser._setup.assert_called_once_with()
    numpydocParser.sections.__setitem__.assert_called_once_with("testTitle", test_section)

# Generated at 2022-06-21 11:50:56.937309
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("","").parse(text="") == []
    assert _KVSection("","").parse(text="test") == []
    assert _KVSection("","").parse(text="test\n") == []
    assert _KVSection("","").parse(text="test\ntest") == []
    assert _KVSection("","").parse(text="test\n test") == []
    assert _KVSection("","").parse(text="test\n  test") == []
    assert _KVSection("","").parse(text="test\n    test") == []
    assert _KVSection("","").parse(text="test\n      test") == []
    assert _KVSection("","").parse(text="test\n\n  test") == []

# Generated at 2022-06-21 11:51:19.199388
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("hello", "hi")
    assert _clean_str(section.parse("aaa\n\n\nbbb\n")[0].description) == "aaa"
    assert list(section.parse("aaa\n\n\nbbb\n"))[0].args == ["hi"]
    assert _clean_str(section.parse("")[0].description) is None
    assert list(section.parse(""))[0].args == ["hi"]


# Generated at 2022-06-21 11:51:21.288892
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section_obj = RaisesSection("Raise", "raise")
    answer = RaisesSection("Raises", "raises")
    assert section_obj != answer, "this test is to test the constructor of class RaisesSection"
    
    

# Generated at 2022-06-21 11:51:24.225278
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # test for correct constructor of ReturnsSection
    assert ReturnsSection("Returns", "returns").title == "Returns"
    assert ReturnsSection("Returns", "returns").key == "returns"
    assert ReturnsSection("Returns", "returns").is_generator == False


# Generated at 2022-06-21 11:51:33.444816
# Unit test for function parse

# Generated at 2022-06-21 11:51:36.812218
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
  sec = _SphinxSection("This", "is")
  pattern = sec.title_pattern
  assert pattern == r"^\.\.\s*(This)\s*::", pattern

# Generated at 2022-06-21 11:51:41.819152
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	section = DeprecationSection("deprecated", "deprecation")
	assert section.title == "deprecated"
	assert section.key == "deprecation"
	assert section.title_pattern.startswith('^\.\.\s*(deprecated)')

# Generated at 2022-06-21 11:51:49.962764
# Unit test for function parse
def test_parse():
    # create default parser
    parser = NumpydocParser()
    # get docstring of parse method
    docstring = inspect.getdoc(parser.parse)
    # parse docstring
    doc = parser.parse(docstring)

    # check parse
    assert doc.short_description == "Parse the numpy-style docstring into its components."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.long_description == """\
    :returns: parsed docstring"""
    assert len(doc.meta) == 0



# Generated at 2022-06-21 11:52:01.017343
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    k1 = 'arg_name'
    v1 = 'arg_description'
    k2 = 'arg_2 : type, optional'
    v2 = 'descriptions can also span...'
    v2 += '... multiple lines'
    text = '%s\n%s\n%s\n%s' % (k1, v1, k2, v2)
    # make section
    title = 'Parameters'
    key = 'param'
    factory = _KVSection(title, key)
    ret = factory.parse(text)
    assert len(ret) == 2
    assert ret[0].args[1] == k1
    assert ret[0].description == v1
    assert ret[1].args[1] == 'arg_2'
    assert ret[1].description == v2
    assert ret

# Generated at 2022-06-21 11:52:09.452423
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import DocstringDeprecated
    from .numpydoc import DeprecationSection
    text_test_1 = """
This is deprecated and will be removed in a future version.
"""
    text_test_2 = """
This is deprecated and will be removed in version 0.0.1.
"""

    for text, version in zip([text_test_1, text_test_2], [None, '0.0.1']):
        deprecate_section = DeprecationSection("Deprecation", "deprecation")
        result = deprecate_section.parse(text)
        assert next(result) == DocstringDeprecated(
            args=['deprecation'], description='This is deprecated and will be removed in a future version.', version=version
        )

# Generated at 2022-06-21 11:52:13.410697
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = r""".. deprecated:: 1.3

.. deprecated:: 1.3
    Deprecated because of a, b, and c."""
    ans = parse(text)
    assert ans.meta[0].description == "Deprecated because of a, b, and c."


# Generated at 2022-06-21 11:52:37.721830
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection(title="title", key="key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == "^\.\.\\s*(title)\\s*::"



# Generated at 2022-06-21 11:52:47.805750
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p1 = ParamSection("Parameters", "param")
    assert p1.title == "Parameters"
    assert p1.key == "param"
    assert p1.title_pattern == "^Parameters\s*?\n---*\s*$"
    assert len(p1.parse("")) == 0
    p2 = p1.parse("a_name\n    a_value")
    assert len(p2) == 1
    assert p2[0].args == ['param', 'a_name']
    assert p2[0].arg_name == 'a_name'
    assert p2[0].type_name == None
    assert p2[0].is_optional == False
    assert p2[0].default == None
    assert p2[0].description == "a_value"
    p3 = p1.parse

# Generated at 2022-06-21 11:52:51.069071
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    title = "Parameters"
    key = "param"
    sections = [Section(title, key)]
    numpydoc_parser = NumpydocParser(sections)
    assert numpydoc_parser.sections[title] is sections[0]



# Generated at 2022-06-21 11:52:55.441485
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_title = "Test_title"
    test_key = "Test_key"
    section = _KVSection(test_title, test_key)
    assert section.title == test_title
    assert section.key == test_key
    assert section.title_pattern == r"^({})\s*?\n{}\s*$".format(test_title, "-" * len(test_title))

# Generated at 2022-06-21 11:52:58.034455
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_obj = YieldsSection("Yields", "yields")
    assert(test_obj.is_generator == True)


# Generated at 2022-06-21 11:53:03.128458
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Creating a new instance of ParamSection
    paramSection = ParamSection("Parameters", "param")
    # Assert that the title of this instance is "Parameters"
    assert paramSection.title == "Parameters"
    # Assert that the key of this instance is "param"
    assert paramSection.key == "param"


# Generated at 2022-06-21 11:53:06.919831
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    c = YieldsSection("Yields", "yields")
    assert c.is_generator == True
    assert c.key == "yields"
    assert c.title == "Yields"


# Generated at 2022-06-21 11:53:09.207326
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection('parameters','param')
    assert section.title == 'parameters'
    assert section.key == 'param'


# Generated at 2022-06-21 11:53:15.455751
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def test_function():
        '''
        function foo

        This is the short description for foo.

        This is the long description for foo. It can have multiple
        lines.

        Parameters
        ----------
        username : str
            can be a one-liner or several
            lines
        level : int, default=1
            a number between 1 and 999

        Returns
        ------
        int
            the meaning of life

        Raises
        ------
        IndexError
            when the universe is overcrowded
        '''
        ret = None
        # TODO: add your code here
        return ret
    ret = NumpydocParser().parse(test_function.__doc__)
    print(ret)

# Generated at 2022-06-21 11:53:18.771477
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert isinstance(_KVSection.__init__(RaisesSection("Raises", "raises")), Section)


# Generated at 2022-06-21 11:53:50.706465
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-21 11:53:55.273412
# Unit test for constructor of class Section
def test_Section():
    title = "test_title"
    key = "test_key"
    S = Section(title, key)
    assert S.title == title
    assert S.key == key
    assert S.title_pattern == r"^(test_title)\s*?\n{}\s*$".format(
        "-" * len(title)
    )

# Generated at 2022-06-21 11:54:06.888130
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = NumpydocParser()
    parser.parse(
        """
        This function does something.

        Parameters
        ----------
        param_1 : str
            Description of `param_1`.
        param_2 : int
            Description of `param_2` which spans
            multiple lines.
        other_param : bool, optional
            Description of `other_param`.
        """
    )


# Generated at 2022-06-21 11:54:09.339277
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = {
        "deprecated": None
    }

# Generated at 2022-06-21 11:54:16.235203
# Unit test for function parse
def test_parse():
  """
  >>> parse.__doc__
  'Parse the numpy-style docstring into its components.\\n\\n    :returns: parsed docstring\\n    '
  >>> doc = parse.__doc__
  >>> parse(doc)
  Docstring(short_description='Parse the numpy-style docstring into its components.', blank_after_short_description=False, blank_after_long_description=True, long_description=None, meta=<DocstringMeta: returns: parsed docstring>)
  """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 11:54:21.011529
# Unit test for constructor of class _KVSection
def test__KVSection():
    d = _KVSection("section", "key")
    assert d.title == "section"
    assert d.key == "key"
    assert d.title_pattern == r"^(section)\s*?\n-*\s*$"



# Generated at 2022-06-21 11:54:31.457883
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("Deprecated", "deprecated")
    desc = inspect.cleandoc('''
    DEPRECATED as of 0.10.0.
    
    The `~astropy.units.Quantity` should be used instead.  This class
    will be removed in a future version.
    ''')
    ret = section.parse(desc)
    ret_list = list(ret)
    assert ret_list, "ret_list should not be Null"
    assert len(ret_list) == 1, "should be one element"
    meta = ret_list[0]
    assert meta.args == ['deprecated'], "args should be deprecation"
    assert meta.description == desc.strip(), "description should be same"

# Generated at 2022-06-21 11:54:36.953395
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    text = ".. deprecated:: 0.1.0\n   a\n   b\n"
    title = "deprecated"
    key = "deprecation"
    ex_ = DeprecationSection(title=title, key=key)
    re_ = ex_.parse(text=text)
    assert next(re_).description == "a\n   b"