

# Generated at 2022-06-11 21:26:45.753494
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = \
        """
        Returns a Docstring instance.

        Returns
        -------
        Docstring
            The parsed docstring.
        """
    obj = NumpydocParser()
    out_obj = obj.parse(docstr)
    assert out_obj.short_description == 'Returns a Docstring instance.'
    assert out_obj.meta[0].description == 'The parsed docstring.'


# Generated at 2022-06-11 21:26:55.909415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import common
    from . import parser
    from . import test_numpydoc_parser

    parser = NumpydocParser(sections=test_numpydoc_parser.DEFAULT_SECTIONS)

    text = '''
    This is a description of the class. It may span multiple lines.

    Parameters
    ----------
    param_one : str, optional
        Description of param_one

    param_two : int
        Description of param_two

    Another_Section
        This section is not on its own line and is not underlined.
        It is thus invalid and should be ignored.

    Returns
    -------
    obj
        The object that was created.

    '''

    doc = parser.parse(text)
    assert len(doc.meta) == 2

# Generated at 2022-06-11 21:27:08.252285
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:16.796952
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import os
    test_file_path = os.path.join(os.path.dirname(__file__), "test.txt")
    with open(test_file_path) as f:
        docstring = f.read()
    result = parse(docstring)
    assert len(result.param) == 4
    assert len(result.attribute) == 3
    assert len(result.other_param) == 1
    assert len(result.receives) == 2



# Generated at 2022-06-11 21:27:24.034785
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_text = """This is a test docstring.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2 : int, optional
        Description of arg2.
    arg3 : bool, optional(default=True)
        Description of arg3.

    Returns
    -------
    arg2 : int
        Description of returned arg2.
    arg3 : bool
        Description of returned arg3.

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """
    test_result = parse(test_text)
    # test the returned Docstring has expected structure
    assert test_result.short_description == "This is a test docstring."
    assert test_result.long_description is None
    assert test_result.blank_after_short_description
    assert not test

# Generated at 2022-06-11 21:27:32.588555
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = NumpydocParser()

    # Test for case where text is None
    text = None
    docstring = a.parse(text)
    assert not docstring.is_valid()

    text = ""
    docstring = a.parse(text)
    assert not docstring.is_valid()

    # Test for case where title is missing
    text = """
        
        This is the short description.

        This is the long description.
        """
    docstring = a.parse(text)
    assert docstring.is_valid()
    assert docstring.short_description is not None
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description is not None
    assert docstring.long_description == "This is the long description."

    # Test for case where title is present


# Generated at 2022-06-11 21:27:42.576892
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    given_text = """
    Multiply each element in the input array by a scalar value.

    Parameters
    ----------
        array : ~numpy.ndarray
            Array to be multiplied.

    Examples
    --------
        >>> my_func(np.array([[1,2],[3,4]]))
        ValueError: Input array must be two-dimensional.

    Returns
    -------
        ~numpy.ndarray
            Output array.

    """
    expected_result = Docstring()
    expected_result.long_description = "Multiply each element in the input array by a scalar value."
    expected_result.short_description = "Multiply each element in the input array by a scalar value."

# Generated at 2022-06-11 21:27:52.219500
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse(
        inspect.cleandoc(
            """Parameters
    ----------
    :param input_layer: The input layer.
    :type input_layer: InputLayer.
    """
        )
    )
    print(docstring.format())

    docstring_other = NumpydocParser().parse(
        inspect.cleandoc(
            """Other Parameters
    ----------------
    :param input_layer: The input layer.
    :type input_layer: InputLayer.
    """
        )
    )
    print(docstring_other.format())


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:28:02.750453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = inspect.cleandoc('''
        >>> x = 0
        >>> x += 1
        >>>
        >>> y = x
        >>> z = y
        >>> z += 1
    ''')
    assert a == ">>> x = 0\n>>> x += 1\n\n>>> y = x\n>>> z = y\n>>> z += 1"
    b = inspect.cleandoc('''
        Args:
          x:
             aaaaaa
             aaaaaa
             aaaaaa
             aaaaaa
        Returns:
          True
    ''')
    assert b == "Args:\n  x:\n     aaaaaa\n     aaaaaa\n     aaaaaa\n     aaaaaa\nReturns: True"
    n = NumpydocParser()

# Generated at 2022-06-11 21:28:10.445375
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parameters
    ----------
    param_1
        Description of parameter ``param``, which has a
        multi-line description.
        Second line of description.
    param_2 : type
        Description of parameter ``param_2``, which has a
        multi-line description.
        Second line of description, optionally with a
        trailing newline.
    
    Raises
    ------
    ValueError
        Description of `ValueError` exception
        which has a multi-line description.
        Second line of description.
    
    KeyError
        Description of `KeyError` exception
        which has a multi-line description.
        Second line of description.
    """
    doc = NumpydocParser().parse(text)
    # Check length of lists
    assert len(doc.meta) == 2

# Generated at 2022-06-11 21:28:23.103515
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    from textwrap import dedent
    from .common import DocstringReturns
    from .common import DocstringMeta
    from .common import DocstringDeprecated
    from .common import DocstringParam
    from .common import DocstringRaises


    #
    # Test no return text.
    #
    txt = ""
    print(txt)
    ds = NumpydocParser().parse(txt)
    print(ds.short_description)
    print(ds.long_description)
    print(ds.meta)


    #
    # Test simple short return text.
    #
    txt = "This is a short description of the function."
    print(txt)
    ds = NumpydocParser().parse(txt)
    print(ds.short_description)
    print(ds.long_description)
    print

# Generated at 2022-06-11 21:28:28.255834
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open('sample_numpydoc.rst', 'r') as f:
        t = f.read()
    print(NumpydocParser().parse(t))

if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:28:38.228628
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test with empty string
    input = ""
    output = parse(input)
    assert output.short_description is None
    assert output.long_description is None
    assert output.blank_after_short_description is False
    assert output.blank_after_long_description is False
    assert output.meta == []

    # Test with only short description
    input = "Short description of the class"
    output = parse(input)
    assert output.short_description == input
    assert output.long_description is None
    assert output.blank_after_short_description is False
    assert output.blank_after_long_description is False
    assert output.meta == []

    # Test with both short description and long description
    input = """Short description of the class
    
    Long description of the class.
    """

# Generated at 2022-06-11 21:28:46.655750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test numpy method parsing.
    assert parse("foo\nbar").short_description == "foo"
    assert parse("foo\nbar").long_description == "bar"
    assert parse("foo\n\nbar").long_description == "bar"
    assert parse("foo\n\n\nbar").long_description == "bar"

    # Test parameter parsing.
    assert (
        parse("foo\nbar\nParameters\n----------\nbaz").long_description
        == "bar"
    )
    assert parse("foo\nbar\nParameters\nbaz").long_description == "bar"
    assert parse("foo\nbar\nParameters\n----------\nbaz").meta[0].description == "baz"
    assert parse("foo\nbar\nParameters\n----------\nbaz").meta[0].args

# Generated at 2022-06-11 21:28:57.938842
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Calculate distance, azimuth and back-azimuth between two geographic points.

    :param point1: the first point
    :type point1: :class:`~obspy.core.util.geodetics.Point`
    :param point2: the second point
    :type point2: :class:`~obspy.core.util.geodetics.Point`
    :param a: optional WGS84 semi major axis
    :type a: float, optional
    :param f: optional WGS84 flattening
    :type f: float, optional
    :param kwargs: options for IUGG formulas
    :type kwargs: dict, optional
    :return: distance, azimuth, back-azimuth
    :rtype: tuple
    """
    text = inspect.cleandoc

# Generated at 2022-06-11 21:29:05.002673
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    one line description

    long description
        possibly multi
        line
    """
    ret = NumpydocParser().parse(text)
    assert ret.short_description == "one line description"
    assert ret.long_description == "long description\npossibly multi\nline"
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False


# Generated at 2022-06-11 21:29:13.918176
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    string_1 = """This is a method.
        Parameters
        ----------
        x : int
            The X coordinate.
        y : int
            The Y coordinate.
        Returns
        -------
        Point
            The point of coordinates (x, y).
        """
    result_1 = parse(string_1)
    assert result_1.short_description == 'This is a method.'
    assert result_1.long_description is None
    assert result_1.blank_after_short_description is False
    assert result_1.blank_after_long_description is True
    assert len(result_1.meta) == 2
    # parameter x
    x = result_1.meta[0]
    assert x.args == ['param', 'x']
    assert x.description == 'The X coordinate.'
    assert x.type_name

# Generated at 2022-06-11 21:29:27.598019
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import print_meta
    from . import numpydoc
    src = '''
    Blah.

    Notes
    -----
    A note.
    '''

    parsed = numpydoc.parse(src)
    # print_meta(parsed)
    assert isinstance(parsed, numpydoc.Docstring)
    assert parsed.short_description == "Blah."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert parsed.long_description == ''
    assert len(parsed.meta) == 1
    assert repr(parsed.meta[0]) == repr(numpydoc.DocstringMeta([numpydoc.DocstringMeta.NOTE], description='A note.'))



# Generated at 2022-06-11 21:29:38.331068
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """NumpydocParser.parse"""
    parser = NumpydocParser()

    # Empty docstring should return empty docstring
    assert parser.parse("") == Docstring()

    # Empty docstring should return empty docstring
    assert parser.parse(" \n \n \n") == Docstring()

    # No sections should return empty docstring
    assert parser.parse("Short description") == Docstring(
        short_description="Short description"
    )

    # No sections should return empty docstring
    assert parser.parse("Short description\n\nLong description") == Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long description",
    )

    # docstring should be trimmed

# Generated at 2022-06-11 21:29:50.684335
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("""\
    Short-ish description.

    Longer description.

    This can be over multiple lines.

    Parameters
    ----------
    arg: str
        A function argument.
    """
    ) == Docstring(
        short_description="Short-ish description.",
        blank_after_short_description=True,
        long_description="Longer description.\n\nThis can be over multiple lines.",
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["param", "arg"], description="A function argument."
            )
        ],
    )

# Generated at 2022-06-11 21:30:04.574897
# Unit test for function parse
def test_parse():
    docstring = """
        First line of description.

        Second line of description.

        Parameters
        ----------
        param1 : str
            Description of param1.
        param2 : int
            Description of param2.
            Second paragraph of description.

        Returns
        -------
        str
            Description of return value.

    """
    doc = parse(docstring)

    assert doc.short_description == "First line of description."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False
    assert doc.long_description == "Second line of description."
    assert len(doc.meta) == 2

    assert doc.meta[0].key == 'param'
    assert doc.meta[0].description == 'Description of param1.'
    assert doc.meta[0].arg_name

# Generated at 2022-06-11 21:30:10.269660
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser_1 = NumpydocParser()
    section_1 = Section('New Section', 'new_section')
    parser_1.add_section(section_1)
    assert parser_1.sections['New Section'] == section_1
    assert parser_1.sections['Raises'] == DEFAULT_SECTIONS[7]

    parser_2 = NumpydocParser()
    section_2 = Section('Raises', 'raises')
    parser_2.add_section(section_2)
    assert parser_2.sections['Raises'] == section_2


# Generated at 2022-06-11 21:30:15.911683
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '    A string\n        value\n'
    section = ParamSection("Parameters", "param")
    assert list(section.parse(text)) == [
        DocstringParam(
            args=['param'],
            description='A string',
            arg_name='A string',
            type_name=None,
            is_optional=None,
            default='value',
        )
    ]

    text = '    A string\n        value and a default\n'
    assert list(section.parse(text)) == [
        DocstringParam(
            args=['param'],
            description='A string',
            arg_name='A string',
            type_name=None,
            is_optional=None,
            default='value',
        )
    ]


# Generated at 2022-06-11 21:30:25.811324
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(
        _KVSection(title="", key="").parse(
            text="""
            arg_name
                arg_description
            arg_2 : type, optional
                descriptions can also span...
                ... multiple lines
            """
        )
    ) == [
        DocstringParam(
            args=["", "arg_name"],
            description="arg_description",
            arg_name="arg_name",
            type_name=None,
            is_optional=None,
            default=None,
        ),
        DocstringParam(
            args=["", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            arg_name="arg_2",
            type_name="type",
            is_optional=True,
            default=None,
        ),
    ]



# Generated at 2022-06-11 21:30:33.731720
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sections = NumpydocParser()
    class Section:
        title = 'title'
        title_pattern = "^title$"
        key = 'test_key'
        def parse(self, text):
            return ['test_value']
    sections.add_section(Section())
    assert sections.sections['title'] is not None
    assert sections.sections['title'].title == 'title'
    assert sections.sections['title'].title_pattern == "^title$"
    assert sections.sections['title'].key == 'test_key'
    assert sections.sections['title'].parse('test') == ['test_value']

# Generated at 2022-06-11 21:30:40.190815
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # create an object of class RaisesSection
    class_obj_test_RaisesSection = RaisesSection("Raises", "raises")
    assert class_obj_test_RaisesSection.title == "Raises", "title not assigned correctly"
    assert class_obj_test_RaisesSection.key == "raises", "key not assigned correctly"



# Generated at 2022-06-11 21:30:52.104475
# Unit test for method parse of class Section
def test_Section_parse():
    # It's a generator (yield)
    actual = RaisesSection('Raises', 'Raises').parse('ValueError \n \n aaa')
    expect = [DocstringRaises(args=['Raises', 'ValueError'], description='aaa', type_name='ValueError')]
    assert list(actual) == expect
    # It's a generator (yield)
    actual = ParamSection('Parameters', 'param').parse('arg_name \n \n aaa')
    expect = [DocstringParam(args=['param', 'arg_name'], description='aaa', arg_name='arg_name', type_name=None, is_optional=None, default=None)]
    assert list(actual) == expect


# Generated at 2022-06-11 21:31:00.596503
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-11 21:31:01.908291
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    ndp = NumpydocParser()
    assert ndp is not None

# Generated at 2022-06-11 21:31:06.577489
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # construct instance
    Par = RaisesSection('Raises', 'raises')
    # test _parse_item
    item = Par._parse_item('ValueError', 'A description of what might raise ValueError')
    assert item.args == ['raises', 'ValueError']
    assert item.type_name == 'ValueError'
    assert item.description == 'A description of what might raise ValueError'


# Generated at 2022-06-11 21:31:13.859131
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    doc = """
    title
    ----
    one
    two
    three"""
    assert (NumpydocParser(sections=[Section('title', 'title')]).parse(doc)) == DocstringMeta(['title'], description='one\ntwo\nthree')



# Generated at 2022-06-11 21:31:23.019541
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_sections = DEFAULT_SECTIONS
    test_parser = NumpydocParser(test_sections)

    for section in test_sections:
        assert section.title in test_parser.sections

    # get a random string as section title
    section_titles = list(test_parser.sections.keys())
    random_title = section_titles[0]

    # add a section
    test_section = Section(random_title, random_title)
    test_parser.add_section(test_section)

    # check the new section
    assert len(test_parser.sections) == len(test_sections) + 1
    assert test_parser.sections[random_title] == test_section

# Generated at 2022-06-11 21:31:26.632233
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = 'Parameter'
    key = 'param'
    ParSect = ParamSection(title,key)
    assert ParSect.title == title
    assert ParSect.key == key


# Generated at 2022-06-11 21:31:28.117669
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Parameters", "param")
    assert param.key == 'param'
    assert param.title == 'Parameters'


# Generated at 2022-06-11 21:31:34.739867
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a=_SphinxSection("arg_name", "key")
    b=_SphinxSection("arg_2", "key2")
    assert a.title_pattern == r"^\.\.\s*(arg_name)\s*::"
    assert b.title_pattern == r"^\.\.\s*(arg_2)\s*::"
    assert a.key == "key"
    assert b.key == "key2"


# Generated at 2022-06-11 21:31:38.223831
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.is_generator == False

if __name__ == "__main__":
    test_ReturnsSection()

# Generated at 2022-06-11 21:31:39.243474
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "key")


# Generated at 2022-06-11 21:31:42.976942
# Unit test for function parse
def test_parse():
    text = """
    A docstring
    
    Parameters
    ----------
    param_1 : str
        Parameter one desc
    
    param_2 : int
        Parameter two desc
    """
    docstring = parse(text)
    assert docstring.short_description == "A docstring"
    assert len(docstring.meta) == 2
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[1].type_name == "int"


# Generated at 2022-06-11 21:31:52.936555
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():

    desc = inspect.cleandoc("""
            The usage of this method is deprecated,
            and it should not be used in new code.
            Instead you should use the class method
            :meth:`.BaseDataset.search` all
            the time.
            """)
    version = inspect.cleandoc("""
            v0.11.0
            """)
    expected_output = DocstringDeprecated(['deprecation'], desc, version)

    section = _SphinxSection("deprecated", "deprecation")
    output = list(section.parse(desc + "\n" + version))

    assert output == [expected_output]

# Generated at 2022-06-11 21:31:55.731944
# Unit test for function parse
def test_parse():
    text = parse.__doc__
    assert text

    section = text.split('\n\n')[0]
    assert section

    match = re.search(r'^:returns?:', section)
    assert match

# Generated at 2022-06-11 21:32:06.686596
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test the method add_section() of class NumpydocParser
    """
    
    title = 'test'
    key = 'test_key'
    text = 'test'
    section = Section(title=title, key=key)
    parser = NumpydocParser()
    parser.add_section(section=section)
    assert parser.sections[title] == section
    assert parser.titles_re.pattern == r'|^(test)\s*?\n----------\s*$'
    assert parser.parse(text=text) == Docstring()

# Generated at 2022-06-11 21:32:10.244278
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returned = ReturnsSection("Returns", "returns")
    if returned.title != "Returns":
        raise AssertionError("Should be Returns")
    if returned.key != "returns":
        raise AssertionError("Should be returns")


# Generated at 2022-06-11 21:32:21.111956
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Tests that the add_section method of the NumpydocParser class
    is functioning properly.

    :returns: `True` if the test was ran without error, `False` if not.
    """

# Generated at 2022-06-11 21:32:25.824043
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    expected_args = ['raises', 'ValueError']
    expected_description = 'A description of what might raise ValueError'
    expected_type_name = 'ValueError'
    expected_result = RaisesSection('Raises', 'raises')
    actual_result = expected_result._pa

# Generated at 2022-06-11 21:32:31.693466
# Unit test for method parse of class Section
def test_Section_parse():
    test = Section("Parameters", "par")
    assert test.parse("\n") == [DocstringMeta(["par"], description=None)]
    assert test.parse("\n\n") == [DocstringMeta(["par"], description=None)]
    assert test.parse("\n\n\n") == [DocstringMeta(["par"], description=None)]


# Generated at 2022-06-11 21:32:40.821442
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class NewSection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    new_section = NewSection("Title", "key")

    parser = NumpydocParser()
    parser.add_section(new_section)
    assert new_section.title in parser.sections
    assert new_section.title_pattern in parser.titles_re.pattern
    docstring = parser.parse(
        """
        .. Title:: Test title
            Some text

        Some more text
        """
    )
    assert len(docstring.meta) == 1
    assert docstring.meta[0].key == "key"
    assert docstring.meta[0].args == ["key"]

# Generated at 2022-06-11 21:32:42.634813
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    class_ = ReturnsSection("Returns", "returns")
    assert class_.is_generator == False

# Generated at 2022-06-11 21:32:44.842943
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = RaisesSection("Raises", "raises")
    print(text.title)
    print(text.key)


# Generated at 2022-06-11 21:32:48.245626
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    s = _SphinxSection(title, key)
    assert s.title == title
    assert s.key == key


# Generated at 2022-06-11 21:32:51.400277
# Unit test for method parse of class Section
def test_Section_parse():
    assert(Section("Hello", "HELLO").parse("*") ==
    [DocstringMeta([DocstringMeta, 'HELLO'], '*')])


# Generated at 2022-06-11 21:33:02.266678
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("""
    This is a docstring

    Parameters
    ----------
    returns : str
    """) == Docstring(
        short_description = "This is a docstring",
        meta = [
            DocstringMeta(["param", "returns"], description="", type_name="str")
        ],
        long_description = "",
    )

# Generated at 2022-06-11 21:33:12.246835
# Unit test for function parse
def test_parse():
    text = """
    This function returns the sum
    of x and y.

    Parameters
    ----------
    x : int
        first number
    y : int
        another number

    Returns
    -------
    int
    """
    doc = parse(text)
    assert doc.short_description == "This function returns the sum of x and y."
    assert doc.long_description == "of x and y"
    assert doc.meta == [
        DocstringMeta(["param", "x"], description="first number", type_name="int"),
        DocstringMeta(["param", "y"], description="another number", type_name="int"),
        DocstringMeta(["returns"], description=None, type_name="int"),
    ]

# Generated at 2022-06-11 21:33:25.187045
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Parse Param Section
    m = ParamSection("Parameters", "param")
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    meta = m.parse(text)
    docstring_meta = next(meta)
    assert docstring_meta == DocstringMeta(["param", "arg_name"], "arg_description")
    docstring_meta = next(meta)
    assert docstring_meta == DocstringMeta(["param", "arg_2"], "descriptions can also span...\n... multiple lines")
    # Parse Other Param Section
    m = ParamSection("Other Parameters", "other_param")

# Generated at 2022-06-11 21:33:26.974519
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """m = NumpydocParser().parse(docstring)"""
    pass


# Generated at 2022-06-11 21:33:34.247425
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser.sections['Returns'].title == 'Returns'
    assert numpydoc_parser.sections['Returns'].key == 'returns'
    assert numpydoc_parser.sections['Returns'].title_pattern == '^Returns\\s*?\\n={1}\\s*$'
    section = Section('New_Section', 'new_section')
    assert section.title == 'New_Section'
    assert section.key == 'new_section'
    assert section.title_pattern == '^New_Section\\s*?\\n={1}\\s*$'
    numpydoc_parser.add_section(section)
    assert numpydoc_parser.sections['New_Section'].title == 'New_Section'
   

# Generated at 2022-06-11 21:33:45.407806
# Unit test for function parse
def test_parse():
    # Tests for docstring function parse
    text = """
    Something
        Description

    Parameters
        p1 : type1
            Description 1

        p2 : type2
            Description 2

    Returns
        return_types

    Raises
        r1
            Description 3

        r2
            Description 4

    Examples
        Examples

    Warnings
        Warnings

    Note
        Note

    References
        References

    """
    pythondoc = parse(text)
    # Tests for function parse
    assert pythondoc.short_description == 'Something'
    assert pythondoc.long_description == 'Description'
    assert pythondoc.blank_after_short_description == True
    assert pythondoc.blank_after_long_description == False

# Generated at 2022-06-11 21:33:47.665586
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    s = YieldsSection("Yields", "yields")

    assert s.is_generator == True

# Generated at 2022-06-11 21:33:55.423334
# Unit test for method parse of class Section
def test_Section_parse():
    test_text = 'Parameters\n----------\nkey\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines'
    test_section = Section('Parameters', 'param')
    test_yields = list(test_section.parse(test_text))
    assert test_yields == [DocstringMeta(['param'], description="value"), DocstringMeta(['param'], description="values can also span...\n    ... multiple lines")]

# Unit tests for method parse of class _KVSection

# Generated at 2022-06-11 21:34:03.250409
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = ("""Personality
        An object containing a personality file.
        The class of this object is an auto-generated subclass of ``dict``
        (inherited from ``jsonref.JsonRef``) with attribute-style access.
        This means you can read/write JSON keys from it like attributes.
        """
    )
    factory = Section('Personality', 'personality')
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        print(inspect.cleandoc(value))
    
    # print(factory.parse(inspect.cleandoc(value)))
    # print([factory.parse(inspect.

# Generated at 2022-06-11 21:34:08.347549
# Unit test for method parse of class Section
def test_Section_parse():
    text = """This is some docstring.
    
    Parameters
    ----------
    This is some parameter description.
    """
    result = Section('Parameters', 'param').parse(text)
    compare = [DocstringMeta(['param'], description='This is some parameter description.')]
    assert result == compare


# Generated at 2022-06-11 21:34:13.857851
# Unit test for constructor of class Section
def test_Section():
    s = Section('Parameters', 'param')
    print(s.title_pattern)
    assert s.title == 'Parameters'
    assert s.key == 'param'


# Generated at 2022-06-11 21:34:23.388267
# Unit test for constructor of class Section
def test_Section():
    title1 = "Parameters"
    key1 = "param"
    title2 = "Args"
    key2 = "args"
    title3 = "Raises"
    key3 = "raises"
    title4 = "Other"
    key4 = "Other"
    title5 = "Notes"
    key5 = "notes"
    title6 = "See Also"
    key6 = "see_also"
    title7 = "Warns"
    key7 = "warns"
    title8 = "Returns"
    key8 = "returns"
    title9 = "Yields"
    key9 = "yields"
    title10 = "References"
    key10 = "references"
    title11 = "deprecated"
    key11 = "deprecation"
 

# Generated at 2022-06-11 21:34:33.637381
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # test parse, method
    section = NumpydocParser().parse(text="""\
    .. deprecated:: version
    deprecated message
    """)
    assert section.meta[0].args == ['deprecation']
    assert section.meta[0].version == 'version'
    assert section.meta[0].description == 'deprecated message'
    # test clean, method
    section = NumpydocParser().parse(text="""\
    .. deprecated:: version\
    deprecated message
    """)
    assert section.meta[0].args == ['deprecation']
    assert section.meta[0].version == 'version'
    assert section.meta[0].description == 'deprecated message'
    # test with markdown

# Generated at 2022-06-11 21:34:35.439129
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Arguments", "param")



# Generated at 2022-06-11 21:34:42.986303
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    test

    lets go
    """
    sec = Section(title="test", key="key")
    d = sec.parse(text)
    assert d[0].args == ['key']
    assert d[0].description == 'lets go'
    assert d[0].arg_name == d[0].type_name == d[0].is_optional == d[0].default == d[0].return_name == d[0].is_generator == None


# Generated at 2022-06-11 21:34:51.019056
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():

    # Testing for an allowed input
    a = DeprecationSection("deprecated", "deprecation")
    assert a.title == "deprecated"
    assert a.key == "deprecation"

    # Testing for an not allowed input (deprecated is only allowed as title)
    b = False
    try:
        DeprecationSection("deprecation", "deprecated")
    except TypeError:
        b = True
    assert b

    # Testing for an not allowed input (title should be a string)
    c = False
    try:
        DeprecationSection(1, "deprecated")
    except TypeError:
        c = True
    assert c

    # Testing for an not allowed input (key should be a string)
    d = False

# Generated at 2022-06-11 21:34:52.395223
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("a","b")


# Generated at 2022-06-11 21:34:54.801087
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    isinstance(r, ReturnsSection)



# Generated at 2022-06-11 21:35:02.290744
# Unit test for constructor of class Section
def test_Section():
    title = "hello"
    key = "world"

    # Test the constructor
    s = Section(title, key)
    assert s.title == "hello"
    assert s.key == "world"

    # Test the property title_pattern:
    # Default key
    if len(s.title) > 0:
        str_to_match = "^(hello)\s*?\n{}\s*$".format("-" * len(s.title))
    else:
        str_to_match = "^(hello)\s*?\n\s*$"
    assert(s.title_pattern == str_to_match)

# Test for function _clean_str

# Generated at 2022-06-11 21:35:04.735349
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert section.title == "Raises"
    assert section.key == "raises"

# Generated at 2022-06-11 21:35:10.686307
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass



# Generated at 2022-06-11 21:35:14.893221
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    a = _KVSection('title', 'key')
    a.parse('key1\n    value1\nkey2: type\n    value2\n        multi-lines')


# Generated at 2022-06-11 21:35:22.786440
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kvsection = _KVSection("Parameters", "param")
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines"""
    arg1 = DocstringParam(
        args=["param", "arg_name"],
        description="arg_description",
        arg_name="arg_name",
        type_name=None,
        is_optional=False,
        default=None,
    )
    arg2 = DocstringParam(
        args=["param", "arg_2"],
        description="descriptions can also span...",
        arg_name="arg_2",
        type_name="type",
        is_optional=True,
        default=None,
    )

# Generated at 2022-06-11 21:35:28.266096
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    pattern = re.compile(r"^\.\.\s*(type)\s*::")

    title = "type"
    key = "type"

    try:
        result = pattern.match(".. type ::").groups()[0]
        assert result == title
    except:
        print("Test result don't match!")

# Generated at 2022-06-11 21:35:30.014878
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True

# Generated at 2022-06-11 21:35:39.244730
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    text = '''
    Parameters
    ----------
    a : type
        a1_description
        a2_description
    b
        b_description

    Returns
    -------
    r1 : type1
        r1_description
    r2
        r2_description
    '''
    title = 'Examples'
    section = Section(title=title, key='examples')
    parser.add_section(section)
    ret = parser.parse(text)
    assert(ret.meta[3].args[0] == 'examples')
    assert(ret.meta[3].description == 'Examples')
    assert(ret.meta[4].args[0] == 'returns')
    assert(ret.meta[4].description == 'Returns')

# Generated at 2022-06-11 21:35:41.865251
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecation", "deprecated")
    assert section.title == "deprecation"
    assert section.key == "deprecated"


# Generated at 2022-06-11 21:35:53.796356
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import DocstringMeta
    from .common import DocstringDeprecated

    class TestDeprecationSection (Section):
        def __init__(self, title: str, key: str) -> None:
            Section.__init__(self, title, key)
        def parse(self, text: str) -> T.Iterable[DocstringDeprecated]:
            raw_text = "DeprecationWarning\nDeprecated since version 1.1: use print() instead."
            version, desc, *_ = raw_text.split(sep="\n", maxsplit=1) + [None, None]
            if desc is not None:
                desc = "Deprecated since version 1.1: use print() instead."

# Generated at 2022-06-11 21:36:03.502273
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    import inspect
    import typing as T
    import re

    from .common import (
        Docstring,
        DocstringDeprecated,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
    )

    def _pairwise(iterable: T.Iterable, end=None) -> T.Iterable:
        a, b = itertools.tee(iterable)
        next(b, None)
        return itertools.zip_longest(a, b, fillvalue=end)
    # Unit test for class Section

# Generated at 2022-06-11 21:36:09.446375
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_obj = _KVSection("Parameters", "param")
    test_text = "arg_name \n arg_description \n \n arg_2 : type, optional \n descriptions can also span... \n ... multiple lines"
    res = test_obj.parse(test_text)
    ans = ['arg_description', 'arg_description']
    assert next(iter(res)).description in ans
    assert next(iter(res)).description in ans

