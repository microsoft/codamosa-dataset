

# Generated at 2022-06-11 21:26:33.930088
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Unit test for method parse of class DeprecationSection"""
    deprecationSection = DeprecationSection('deprecated', 'deprecation')
    actual = next(deprecationSection.parse('Deprecated in version 1.2.0.\n'
                                           '    A descrption of why this was deprecated.\n\n'))
    expected = DocstringDeprecated(['deprecation'],
                                   'A descrption of why this was deprecated.',
                                   '1.2.0')
    assert actual == expected


# Generated at 2022-06-11 21:26:40.992460
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    title = 'Some title:'
    key = 'key'
    text = '1.1.0\nSome text'
    result = DeprecationSection(title, key).parse(text)
    answer = [DocstringDeprecated(args=[key], description='Some text', version='1.1.0')]
    assert str(next(iter(result))) == str(next(iter(answer)))


# Generated at 2022-06-11 21:26:45.471979
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from uuid import uuid4
    title = str(uuid4())
    version = str(uuid4())
    description = str(uuid4())
    text = '{}\n{}\n{}\n'.format(title, version, description)
    section = DeprecationSection(title=title, key='key')
    doc_meta = next(section.parse(text))
    assert doc_meta.description == description
    assert doc_meta.version == version

# Generated at 2022-06-11 21:26:53.928239
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    t = ParamSection("Parameters", "param")
    text = '''this
        is a test
            to make sure that _KVSection.parse works correctly.
        Next
            Multiline description
            should still be picked up correctly.'''

    parsed = [t._parse_item(x[0], x[1]) for x in zip(
        ['this', 'Next'],
        ['is a test\nto make sure that _KVSection.parse works correctly.',
        'Multiline description\nshould still be picked up correctly.'])
    ]
    assert parsed == t.parse(text)


# Generated at 2022-06-11 21:26:58.421958
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """:returns: parsed docstring"""
    
    docstr = """
    docstr = """
    parsed_docstr = NumpydocParser().parse(docstr)
    assert parsed_docstr == 5
    
    
    
    
# Unit tests for method test_NumpydocParser_parse
test_NumpydocParser_parse()

# Generated at 2022-06-11 21:27:09.843817
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    deprecation_section.title = "deprecated"
    deprecation_section.key = "deprecation"
    doc_string_deprecated_0 = DocstringDeprecated(
        args=[deprecation_section.key],
        description=None,
        version=None,
    )
    doc_string_deprecated_1 = DocstringDeprecated(
        args=[deprecation_section.key],
        description="A description of what might raise ValueError",
        version="ValueError",
    )
    assert [d for d in deprecation_section.parse("")] == [doc_string_deprecated_0]

# Generated at 2022-06-11 21:27:20.759202
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    # Section
    section = DeprecationSection("deprecated", "deprecation")

    # Numpy formatted docstring
    text = ".. deprecated :: 0.9.0 \n   Use something else instead!"

    # Parsed docstring
    res = DocstringDeprecated(
            args=["deprecation"], description=_clean_str("Use something else instead!"), version=_clean_str("0.9.0")
        )

    # Parsing text
    doc_list = section.parse(text)


    # Test if parse returns the expected result
    assert res in doc_list

    # Test if parse returns the expected type
    assert isinstance(doc_list, list)



# Generated at 2022-06-11 21:27:28.643006
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    import unittest
    

    sec = DeprecationSection('deprecated', 'deprecation')
    text = '.. deprecated:: 1.0 \n' \
           '   Text describing the deprecated function. \n' \
           '   A second line.'
    a1 = sec.parse(text)
    for i in a1:
        a = i
    assert a.args == ['deprecation']
    assert a.description == 'Text describing the deprecated function. \n   A second line.'
    assert a.version == '1.0'

# Generated at 2022-06-11 21:27:41.477344
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("deprecated", "deprecation"))
    string1 = ".. deprecated:: 0.1.0\n   Some explanation."
    string2 = ".. deprecated:: 0.1.0"
    string3 = ".. deprecated:: 0.1.0\n   Some explanation.\n   Some extra lines."
    string4 = ".. deprecated::\n   Some explanation.\n   Some extra lines."
    string5 = ".. deprecated:: 0.1.0\n Some explanation."
    string6 = """.. deprecated:: 0.1.0
                                                Some explanation.
                                              """
    result1 = parser.parse(string1)
    result2 = parser.parse(string2)
    result3 = parser.parse(string3)
    result4

# Generated at 2022-06-11 21:27:43.921046
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    DeprecationSection("deprecated", "deprecation").parse("asd 1.0\n asdasdasd")


# Generated at 2022-06-11 21:28:22.868591
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    Test docstring

    Parameters
    ------------
    a : int
        a is a variable
    b : str
        b is a string variable
    c, optional
        c is a variable with default value

    Returns
    ------------
    int
        type of the output
    """
    result = parser.parse(docstring)
    assert result.short_description == "Test docstring"
    assert result.long_description is None
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is True
    assert len(result.meta) == 3
    for meta in result.meta:
        if meta.args == ['param', 'a']:
            assert meta.description == "a is a variable"
            assert meta.type

# Generated at 2022-06-11 21:28:35.362098
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_text = inspect.cleandoc(
        """
        Method for testing for method parse of class NumpydocParser.

        Parameters
        ----------

        param_1 : str
            This is the parameter_1.
        param_2 : int
            This is the parameter_2.
            With the wrapper around it.

        Returns
        -------
            True
        """
    )
    parser = NumpydocParser()
    res = parser.parse(docstring_text)
    assert res.__class__.__name__ == 'Docstring'
    assert res.short_description == 'Method for testing for method parse of class NumpydocParser.'
    assert res.long_description == None
    assert len(res.meta) == 2
    for meta in res.meta:
        assert meta.__class__.__name__

# Generated at 2022-06-11 21:28:45.305420
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    out = []
    def write(text):
        out.append(text.strip())
    #
    # Example docstring taken from https://numpydoc.readthedocs.io/en/latest/format.html#sections
    #
    text = '''This is a silly function

It does nothing fancy

Parameters
----------
a : int
    The first parameter
b : float
    The second parameter
c : (int, float), optional
    The third parameter

Returns
-------
result : int
    The result

Raises
------
NotImplementedError
    The implementation does nothing
'''
    doc = parse(text)
    doc.show(out=write)

# Generated at 2022-06-11 21:28:57.202083
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text_in = """
    short_description
    this is longer, it can span multiple lines.

    Parameters
    ----------
    arg
        An argument **with** *markdown*
    df : pd.DataFrame
        Another argument **with** *markdown*

    Keyword Arguments
    -----------------
    kwarg : keyword argument
        Keyword argument description

    Other Parameters
    ----------------
    other_keyword : other keyword
        Another keyword argument
    """

# Generated at 2022-06-11 21:29:08.711099
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def foo(*args):
        """
        Short description.

        Long description
        Can span over
        multiple lines.

        Parameters
        ----------
        arg_name : type
            arg_description
        arg_2: AnotherType, optional
            Descriptions can also span...
            ... multiple lines
        AnotherName
            Return names are optional, types are required.

        Raises
        ------
        ValueError
            A description of what might raise ValueError.

        Returns
        -------
        return_name : type
            A description of this returned value.

        Yields
        ------
        return_name : type
            A description of this yielded value.

        Examples
        --------
        >>> numpydocParser = NumpydocParser()
        >>> text = """

# Generated at 2022-06-11 21:29:16.908508
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def trial_method(a, b, c=None):
        """
        Trial method.

        Method description
        ------------------

        This method is a trial method, it's so trial that it doesn't really do anything.

        Parameters
        ----------
        A : (float)
            First parameter.
        B : (float, optional)
            Second parameter.
        C : (float, optional)
            Third parameter. Default is None.

        Returns
        -------
        (int)
            One.

        Examples
        --------
        >>> trial_method(a, b, c)

        """
        return 1

    target_docstring = Docstring()
    target_docstring.short_description = 'Trial method.'

# Generated at 2022-06-11 21:29:28.071196
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('''
    Parameters
    ----------
    index : {str, int, tuple, Series, DataFrame}
        The indexing key.
    '''.strip())
    assert str(docstring).startswith('''
        short_description:
        blank_after_short_description: True
        blank_after_long_description: True
        long_description:
        meta:
        - args:
          - param
          - index
          description: >-
            The indexing key.
          arg_name: index
          type_name: None
          is_optional: False
          default: None
    '''.strip()) == True

# Generated at 2022-06-11 21:29:38.658181
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # Test case 1
    text = """Parse the numpy-style docstring into its components.
    param n: numpydoc.docscrape.Docstring
    param j: numpydoc.docscrape.Docstring
    param k: numpydoc.docscrape.Docstring

    Returns: parsed docstring
    """
    result = parser.parse(text)
    assert len(result.meta) == 5

    # Test case 2

# Generated at 2022-06-11 21:29:51.081388
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def func_for_test(a, b, c):
        '''
        Short description

        Long description

        Parameters
        ----------
        a :
            param1

        b(optional) : string
            param2

        c : int, optional
            param3, defaults to 5

        Raises
        ------
        ValueError
            a is zero

        Returns
        -------
        string
            return1

        Examples
        --------
        >>> func_for_test(5, 'hello', 7)
        >>> func_for_test(5, 'hello')
        >>> func_for_test(5, 'hello', c= 7)

        Notes
        -----
        This is a note

        References
        -----
        https://www.google.com
        '''
        pass

# Generated at 2022-06-11 21:30:01.981456
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    t_str = """
    Return a copy of the string S with leading whitespace removed.\
    If chars is given and not None, remove characters in chars instead.\
    If chars is unicode, S will be converted to unicode before stripping

    :param str S: string
    :param typle chars: string
    """
    t_ret = parse(t_str)
    assert (t_ret.short_description == 'Return a copy of the string S with leading whitespace removed.')
    assert (t_ret.long_description == 'If chars is given and not None, remove characters in chars instead.\
    If chars is unicode, S will be converted to unicode before stripping')
    assert (t_ret.meta[0].arg_name == 'S')
    assert (t_ret.meta[0].type_name == 'str')

# Generated at 2022-06-11 21:30:18.053893
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Yields
    ------
    returns : type
        A description of this returned value

    See Also
    --------
    something, another thing

    References
    ----------
    something, another thing

    Examples
    --------
    >>> some example

    Notes
    -----
    Make sure you do this

    Warns
    -----
    You did something stupid
    """


# Generated at 2022-06-11 21:30:27.284748
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:30:33.541856
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = '''
    Parse the numpy-style docstring into its components.

    This function was modified by USER.

    :returns: parsed docstring
    '''

    parsed = NumpydocParser().parse(text)
    expected = Docstring().parse(
        {
            "short_description": "Parse the numpy-style docstring into its components.",
            "long_description": "This function was modified by USER.",
        }
    )

    assert expected == parsed

# Generated at 2022-06-11 21:30:40.856657
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class TestNumpydocParser:
        def __init__(self):
            self.parser = NumpydocParser()
            self.text = ""
            self.parser.parse(text)
            self.try_output = "TEST"
        def output(self):
            print(self.try_output)
    # Test if catches are working
    try:
        TestNumpydocParser()
    except:
        print("An exception occurred")

# Generated at 2022-06-11 21:30:53.542370
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:05.135363
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    a = NumpydocParser().parse(text)
    b = Docstring()
    b.short_description = None
    b.long_description = None
    b.blank_after_short_description = False
    b.blank_after_long_description = False
    c = DocstringMeta(['param', 'arg_name'], description='arg_description')
    d = DocstringMeta(['param', 'arg_2'], description='descriptions can also span...\n... multiple lines',)
    b.meta.append(c)
    b.meta.append(d)

# Generated at 2022-06-11 21:31:18.070634
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import unittest
    class TestNumpydocParserParse(unittest.TestCase):
        def _compare(self, parser, text, ret):
            self.assertEqual(parser.parse(text), ret)
        def test_empty(self):
            self._compare(NumpydocParser(), "", Docstring())
        def test_short_desc(self):
            self._compare(NumpydocParser(), "short desc", Docstring(short_description="short desc"))
        def test_long_desc(self):
            self._compare(NumpydocParser(), "short desc\n\nlong desc", Docstring(short_description="short desc", blank_after_short_description=True, long_description="long desc", blank_after_long_description=False))


# Generated at 2022-06-11 21:31:29.990058
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docString = """
    Short description.

    Long description.

    Parameters
    ----------
    foo : str
        Foo parameter.

    bar : int
        Bar parameter.

    Returns
    -------
    None
    """

    parser = NumpydocParser()

    docStringParsed = parser.parse(docString)
    # short_description:
    assert docStringParsed.short_description is "Short description."
    # long_description:
    assert docStringParsed.long_description is "Long description."
    # blank_after_short_description:
    assert docStringParsed.blank_after_short_description == True
    # blank_after_long_description:
    assert docStringParsed.blank_after_long_description == False
    # meta:

# Generated at 2022-06-11 21:31:41.505119
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    text_0 = '''
    This is a simple test
    '''
    text_1 = '''
    This is a simple test
    Parameters
    ----------
    something : str
        parameter help
    '''
    text_2 = """
    This is a simple test
    Parameters
    ----------
    something : str
        parameter help
    Raises
    ------
    ValueError
        description
    """
    text_3 = """
    This is a simple test
    Parameters
    ----------
    something : str
        parameter help
    Raises
    ------
    ValueError
        description
    Returns
    -------
    str
        description
    """
    # Act
    ds_0 = NumpydocParser().parse(text_0)
    ds_1 = NumpydocParser

# Generated at 2022-06-11 21:31:49.245186
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short summary of the method

    Longer description. Can go over several lines.

    Parameters
    ----------
    arg_name
        A positional argument, has no type.
    arg_type : str
        A str argument, with a type and a short description.
        The description can span multiple lines.

    Returns
    -------
    None

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """


# Generated at 2022-06-11 21:32:06.175672
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """test_parse"""
    text = inspect.cleandoc("""
    Single line
    description.

    Parameters
    ----------
    param_1 : type
        A single string.

    Returns
    -------
    str
        Processed string.

    Raises
    -------
    ValueError
    """)

    doc = parse(text)
    assert doc.short_description == "Single line description."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert not doc.long_description

    assert len(doc.meta) == 2
    param = 'param_1'
    param_type = 'type'
    param_description = 'A single string.'
    return_description = 'Processed string.'
    assert doc.meta[0].description == param_description

# Generated at 2022-06-11 21:32:15.365385
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()


# Generated at 2022-06-11 21:32:21.447247
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1
    str_1 = """
    A simple example of a docstring.

    Parameters
    ----------
    a : int
        a is an integer
    b : str
        b is a string

    Returns
    -------
    c : bool
        c is a boolean value
    """

# Generated at 2022-06-11 21:32:33.032941
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ndp = NumpydocParser()
    docstring = ndp.parse('''
    A short description of foo.
    
        Multiple lines of text, explaining
        the function in greater detail
    
    Some more text - extra info about foo
    
    This function does nothing.
    
    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    
    Returns
    -------
    int
        The return value.
    
    Other Parameters
    ----------------
    urspruenglich: bool
        A flag to indicate that something has its origins in something else.
    ''')
    assert docstring.short_description == 'A short description of foo.'

# Generated at 2022-06-11 21:32:41.740903
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # The function parse opens the file and reads the docstring and
    # splits into parts, i.e. the short and the long descriptions,
    # the parameters, the returns
    # The docstring has these parts (See README.md):
    # - short description
    # - parameters:
    #   - name
    #   - type
    #   - description
    # - returns:
    #   - type
    #   - description
    # - long description
    #

    # Test parsing of docstring into its parts
    #

    # Get path to test program
    from os.path import dirname
    from os import getcwd
    from os.path import abspath
    abs_dir = abspath(dirname(__file__))
    abs_dir_cwd = abspath(getcwd())
    # abs_dir

# Generated at 2022-06-11 21:32:50.974506
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:00.688113
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """This is the unit test for testing the NumpydocParser.parse method.

    It is meant to be run using pytest.

    """
    # Unit test for proper docstring parsing

# Generated at 2022-06-11 21:33:11.736753
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str1 = """\
    short_description
    longer description that can have
    multiple lines
    """

    str2 = """\
    short_description

    longer description that can have
    multiple lines
    """

    str3 = """\
    short_description\n\n\n
    longer description that can have
    multiple lines
    """
    strs = [str1, str2, str3]

    parser = NumpydocParser()

    for st in strs:
        print(parser.parse(st).short_description)
        print(parser.parse(st).blank_after_short_description)
        print(parser.parse(st).long_description)
        print(parser.parse(st).blank_after_long_description)
        print()
if __name__ == "__main__":
    test_

# Generated at 2022-06-11 21:33:14.339302
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse('test').short_description == 'test'



# Generated at 2022-06-11 21:33:26.240439
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:46.399472
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Empty docstring
    docstring = ''
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description is None
    assert docstring_obj.long_description is None
    assert docstring_obj.blank_after_short_description is False
    assert docstring_obj.blank_after_long_description is False
    assert len(docstring_obj.meta) == 0

    # Only short description docstring
    docstring = 'A short description of the function.'
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == 'A short description of the function.'
    assert docstring_obj.long_description is None
    assert docstring_obj.blank_after_short_description is False
    assert docstring_obj.blank_after_long_description is False
   

# Generated at 2022-06-11 21:33:57.730084
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ds = NumpydocParser()

# Generated at 2022-06-11 21:34:08.548887
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert not NumpydocParser().parse(None)
    assert not NumpydocParser().parse("\n")
    assert not NumpydocParser().parse("")

    assert NumpydocParser().parse("Test short description").short_description == "Test short description"
    assert NumpydocParser().parse("Test short description\n").short_description == "Test short description"
    assert NumpydocParser().parse("Test short description\n\n").short_description == "Test short description"
    assert NumpydocParser().parse("Test short description\n\nTest long description").short_description == "Test short description"
    assert NumpydocParser().parse("Test short description\nTest long description").short_description == "Test short description"

# Generated at 2022-06-11 21:34:15.312842
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.parse("""
    short desc
    
    long desc

    first subsection

    Parameters
    ----------
    arg1 : type
        arg1 description
    arg2 : type, optional
        arg2 description

    Raises
    ------
    keyerror
        raise description

    Returns
    -------
    None

    Examples
    --------
    example text
    
    """)

# Generated at 2022-06-11 21:34:24.159081
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("haha\n") == Docstring(
        long_description=None,
        short_description='haha',
        meta=[],
        blank_after_long_description=False,
        blank_after_short_description=False,
    )
    assert parser.parse("haha") == Docstring(
        long_description=None,
        short_description='haha',
        meta=[],
        blank_after_long_description=False,
        blank_after_short_description=False,
    )

# Generated at 2022-06-11 21:34:34.154762
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case = "line 1\nline 2\nParameters\nparam1\n\tparam1-desc\nYields\nyields1\n\tyields1-desc"
    parser = NumpydocParser()
    docstring = parser.parse(test_case)
    assert docstring.short_description == "line 1\nline 2"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == None
    assert [x.args[0] for x in docstring.meta] == ['param', 'param', 'yields']
    assert [x.args[1] for x in docstring.meta] == ['param1', 'param1', 'yields1']

# Generated at 2022-06-11 21:34:45.849894
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    
    def test_function():
        """...

        Parameters
        ----------
        arg1: int
            Description of arg1.

        Returns
        -------
        int
            Description of arg1.
        """
        return 1

    docstring = inspect.getdoc(test_function)

    # remove any lines starting with space and ending with colon (:)
    docstring_parsed = re.sub(r"\n\s*[\w\s]*:", "\n", docstring)

    docstring_org = NumpydocParser().parse(docstring_parsed)

# Generated at 2022-06-11 21:34:56.312382
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:04.089337
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    import sys

    import pytest

    from .fixtures.numpydoc import (
        DOCSTRING_META_EMPTY,
        DOCSTRING_META_EMPTY_SPHINX_KEY,
        DOCSTRING_META_LONG,
        DOCSTRING_META_SHORT,
        DOCSTRING_META_SIMPLE_BLANK,
        DOCSTRING_META_SIMPLE_MULTIPLE,
        DOCSTRING_META_SIMPLE_SINGLE,
        DOCSTRING_NO_META,
        DOCSTRING_NO_META_BLANK,
        DOCSTRING_NO_META_BLANK_LONG,
    )

    # Empty

    assert NumpydocParser().parse("") == DOCSTRING_META_EMPTY

    # No

# Generated at 2022-06-11 21:35:16.847103
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:41.534077
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def docstring_equal(res, expect):
        if res != expect:
            print([res])
            print([expect])
            return False
        return True

    text = "short description line\nlong description line\n\n" \
            "Parameters\n----------\n" \
            "arg_name\n    arg_description\narg_two : type\n    arg_description"

    def test_NumpydocParser_parse_match_param(pattern, line, res):
        m = re.search(pattern, line)
        if not m or not docstring_equal(m.group(), res):
            print(m.group())
            print(res)
            return False
        return True

    numpydoc_parser = NumpydocParser()

# Generated at 2022-06-11 21:35:52.964939
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        from pydocstring.composites import (
            Docstring,
            DocstringMeta,
            DocstringParam,
            DocstringRaises,
            DocstringReturns,
        )
        from pydocstring.tags import (
            UNKNOWN_PARAM,
            UNKNOWN_RAISES,
            UNKNOWN_RETURNS,
        )
    except ModuleNotFoundError:
        pass


# Generated at 2022-06-11 21:36:03.245117
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    One-line summary of the function's purpose.

    Extended description of function.

    Parameters
    ----------
    param1 : int
        Description of `param1`.
    param2 : str, optional
        Description of `param2`. Defaults to 'foo'.
    *args
        Variable length argument list.
    **kwargs
        Arbitrary keyword arguments.

    Returns
    -------
    bool
        True if successful, False otherwise.

    Other Parameters
    ----------------
    str parameter
        Description of `param`.

    '''

    description = '''
    One-line summary of the function's purpose.

    Extended description of function.
    '''


# Generated at 2022-06-11 21:36:14.083428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pudb; pu.db
    # Simple docstring
    docstring = '''
    This is a simple docstring.

    It has a section that looks like this:
        Arguments
        ---------
        arg_1 : int
            `arg_1` is the first argument
        ...
    '''
    docstring = inspect.cleandoc(docstring)
    output = NumpydocParser().parse(docstring)