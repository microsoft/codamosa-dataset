

# Generated at 2022-06-11 21:26:51.571152
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    sample_docstring = """
    Parameters
    ----------
    name : str
        A name that can be used in multiple places in
        the docs.

    Returns
    -------
    str
    """
    result = NumpydocParser().parse(sample_docstring)
    assert result.long_description == ""
    assert result.short_description == ""
    assert len(result.meta) == 2
    assert result.meta[0].args == ["param", "name"]
    assert result.meta[0].description == "A name that can be used in multiple places in\nthe docs."
    assert result.meta[1].args == ["returns"]
    assert result.meta[1].description == ""

# Generated at 2022-06-11 21:26:59.483852
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .test_common import doc_test_data

    for test_data in doc_test_data:
        docstring = parse(test_data["docstring"])

        assert docstring.short_description == test_data["short_description"]
        assert docstring.long_description == test_data["long_description"]
        assert (
            docstring.blank_after_short_description
            == test_data["blank_after_short_description"]
        )
        assert (
            docstring.blank_after_long_description
            == test_data["blank_after_long_description"]
        )

        # Skip meta data tests unless meta data expected

# Generated at 2022-06-11 21:27:10.507772
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:17.998902
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstr = '''
    parameters:
        a: int
            a
        b: int
            b
    '''
    doc = parser.parse(docstr)
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['param', 'b']
    assert doc.meta[0].description == 'b'



# Generated at 2022-06-11 21:27:29.442778
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:41.555508
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Short description here.

    Long description can go...
    ...over multiple lines

    My custom section!
        more stuff about my custom section

    Parameters
    ----------
    arg_string : str
        A description of arg_string
    arg_int : int
        A description of arg_int
        can span multiple lines

    Returns
    -------
    return_string : str
        A description of return_string

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    See Also
    --------
    https://docs.python.org/3.7/library/inspect.html
    """
    # Create an instance of NumpydocParser
    parser = NumpydocParser()

    # Call method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:51.371309
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Test function of NumpydocParser.

    :param str x: value of x
    :param str y: value of y
    :returns: 
    value of y
    :raises ValueError: When value not found
    :raises TypeError: When type not found
    """
    assert NumpydocParser().parse(text).meta[0].type == "param"
    assert NumpydocParser().parse(text).meta[1].type == "returns"
    assert NumpydocParser().parse(text).meta[2].type == "raises"
    assert NumpydocParser().parse(text).meta[3].type == "raises"


# Generated at 2022-06-11 21:28:01.789965
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    A longer description of the function, which can span
    multiple lines.

    Parameters
    ----------
    a : array_like
        A longer description of `a`, which can span multiple lines.
    b : int
        A longer description of `b`, which can span multiple lines.
        Default is 5.

    Returns
    -------
    c : int
        A longer description of `c`, which can span multiple lines.

    See Also
    --------
    a
    b
    c

    Examples
    --------
    >>> a([1, 2, 3])
    [4, 5, 6]

    >>> b(5, 6)
    11

    >>> c(5, 6)
    11

    """
    parser = NumpydocParser()
    docstring = parser.parse(docstring)

# Generated at 2022-06-11 21:28:08.520401
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def test_fun(a, b):
        """test function

        Parameters
        ----------
        a: int
            the first number
        b: int
            the second number

        Returns
        -------
        the sum, if all the following conditions are met:
            1. the two numbers are not equal
            2. the two numbers are not None
            3. the two numbers are integers
        """
    fun_docstring = inspect.getdoc(test_fun)
    numpydoc_parser = NumpydocParser()
    result = numpydoc_parser.parse(fun_docstring)

# Generated at 2022-06-11 21:28:19.412633
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    A short description of the function.

    Longer description of the function.

    This can also span multiple lines.
    But the previous blank lines must be present.

    Parameters
    ----------
    arg1
        This is a description of what arg1 is.
    arg2 : int
        This is a description of what arg2 is.
    arg3 : str, optional
        This is a description of what arg3 is.
    arg4 (optional)
        This is a description of what arg4 is.
        This can span multiple lines.

    Notes
    -----
    Note section.

    Returns
    -------
    A string.
    """)

    assert(docstring.short_description == "A short description of the function.")

# Generated at 2022-06-11 21:28:37.404436
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Docstring with all sections.

    Parameters
    ----------
    param1 : type
        parameter 1
    param2 : type (optional)
        parameter 2

    Returns
    -------
    returns : type
        returns something

    Raises
    ------
    ValueError
        a thing went wrong
    '''

    result = NumpydocParser().parse(text)

    expected = Docstring()
    expected.short_description = "Docstring with all sections."
    expected.long_description = "parameter 1\nparameter 2"
    expected.blank_after_short_description = False
    expected.blank_after_long_description = False

# Generated at 2022-06-11 21:28:43.496589
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.add_section(RaisesSection("Raise", "raises"))
    docstring = parser.parse("""\
    This function does something that can raise a ValueError.

    Raises
    ------
    ValueError : if it goes wrong.
    """)
    assert docstring.short_description == "This function does something that can raise a ValueError."
    assert docstring.meta[0].args == ['raises', 'ValueError']

# Generated at 2022-06-11 21:28:55.472553
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:06.383693
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_str = """
    The calculator program.

    This program can add, subtract, multiply and divide.

    Usage:
        calculator add <number1> <number2> ...
        calculator subtract <number1> <number2> ...
        calculator multiply <number1> <number2> ...
        calculator divide <dividend> <divisor> <quotient>

    Arguments:
        number1 <float> The first number.
        number2 <float> The second number.
        dividend <float> The dividend.
        divisor <float> The divisor.
        quotient <float> The quotient. [default: 1]

    Options:
        -h, --help  Show this screen.
    """
    ret = NumpydocParser().parse(doc_str)

# Generated at 2022-06-11 21:29:15.540387
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse(
        """
    Short Description
    ================

    Long Description
    ----------------
    The long description can span more lines.

    Parameters
    ----------
    arg_name : str
        argument description
    arg_2 : int, optional
        argument description with type and optional flag

    Returns
    -------
    return_name : int
        return description
        """
    )
    assert docstring.short_description == "Short Description"
    assert docstring.blank_after_short_description
    assert docstring.long_description == "Long Description\nThe long description can span more lines."
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 1
    section = list(docstring.meta)[0]
    assert section.args == ["param"]


# Generated at 2022-06-11 21:29:28.111290
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup
    text = """A short description.

    This is a long description that spans multiple lines.
    It can have subsections that look like this:

    - Some markdown bullets
    - With multiple elements
    - Like this

    Parameters
    ----------
    arg : str
        The first argument.
    arg2 : int, optional
        The second argument.

    Raises
    ------
    ValueError
        If things go wrong.

    Returns
    -------
    dict
        Whatever was returned.

    Examples
    --------
    >>> NumpydocParser.parse()
    True
    """

# Generated at 2022-06-11 21:29:38.697927
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:51.081585
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    example = """
        Example docstring
        text
        
        Parameters
        ----------
        arg_name : type, optional
            some text
        """
    parser = NumpydocParser()
    
    # Act
    result = parser.parse(example)
    
    # Assert
    
    assert result.short_description is not None
    assert result.short_description == "Example docstring"
    assert result.long_description is not None
    assert result.long_description == "text"
    assert result.blank_after_short_description is not None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description is not None
    assert result.blank_after_long_description == True
    assert result.meta is not None

# Generated at 2022-06-11 21:30:01.981673
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    with open("./tests/test_data/test_NumpydocParser_parse/test_docstring.txt") as file:
        text = file.read()
    docstring = parser.parse(text)

    docstring_return = Docstring()
    with open("./tests/test_data/test_NumpydocParser_parse/docstring_return.txt") as file:
        docstring_return_str = file.read()
        docstring_return.from_json(docstring_return_str)
    # docstring_return.from_json(
    #    '{"type": "Docstring", "args": [], "kwargs": {"short_description": "This is a test.", "long_description": "This is a test\nThis is a test", "blank_

# Generated at 2022-06-11 21:30:10.616306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    This is an example method.

    The first line is short description. The rest is long
    description.  The long description is optional and may be
    several paragraphs.

    Parameters
    ----------
    arg1 : str
        description of arg1

    arg2 : int, optional
        description of arg2

    Other Parameters
    ----------------
    arg3
        description of arg3

    attr1 : int
        description of attr1

    Raises
    ------
    ValueError
        when value is invalid


    Returns
    -------
    retval : bool
        True when valid, False otherwise
    """

    parser = NumpydocParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is an example method."

# Generated at 2022-06-11 21:30:24.912789
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_docstring = '''
    Parameter section:

    para : type

        description

    para2 : type
        description

    Raises section:

    ValueError
        description

    Return section:

    return_name : type
        description

    Another return:

    return_name2

        description

    Examples section:

    Examples
        description
    '''
    parsed_example = parse(test_docstring)

# Generated at 2022-06-11 21:30:34.526178
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
This is a typical numpydoc docstring.

:param arg1: The first parameter.
:type arg1: int
:param arg2: The second parameter.
:type arg2: str, optional
:returns: Description of return value
:rtype: bool"""
    docstring = parse(text)

    assert docstring.short_description == "This is a typical numpydoc docstring."
    assert docstring.long_description == None

    assert len(docstring.meta) == 3
    param1 = docstring.meta[0]
    assert isinstance(param1, DocstringParam)
    assert param1.args == ["param", "arg1"]
    assert param1.description == "The first parameter."
    assert param1.type_name == "int"
    assert param1.is_optional

# Generated at 2022-06-11 21:30:39.590548
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
Parameters
---------

name : str

"""
    docstring = NumpydocParser().parse(text)
    assert(docstring.meta[0].args[1] == "name")
    assert(docstring.meta[0].type_name == "str")



# Generated at 2022-06-11 21:30:49.931965
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Utility module for testing

    Parameters
    ----------
    a : int
        First thing
    b : str, optional
        Second thing

    Returns
    -------
    out : int
        Sum of things
    """

    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "Utility module for testing"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description is None
    assert len(docstring.meta.param) == 2
    assert len(docstring.meta.returns) == 1

# Generated at 2022-06-11 21:30:59.788474
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test for short_description
    short_desc_text = "Short description, please\n"
    short_desc_example = Docstring(short_description="Short description, please")
    assert NumpydocParser().parse(short_desc_text) == short_desc_example

    short_desc_text_1 = "Short description, please\n\n    Long description"
    short_desc_example_1 = Docstring(
        short_description="Short description, please",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="    Long description",
    )
    assert NumpydocParser().parse(short_desc_text_1) == short_desc_example_1

    # test for long_description
    long_desc_text = "    Long description"


# Generated at 2022-06-11 21:31:08.175795
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """Parameters
    ----------
    a : int

        The a parameter
    b : float

        The b parameter
    c : bool

        The c parameter
        """
    expected_result = Docstring()
    expected_result.short_description = None
    expected_result.blank_after_short_description = False
    expected_result.long_description = None
    expected_result.blank_after_long_description = False

# Generated at 2022-06-11 21:31:17.749325
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """\
    Returns

    x : type
        description
    """
    parser = NumpydocParser()
    docstring_obj = parser.parse(docstring)
    assert docstring_obj == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[DocstringReturns(
            args=['returns'],
            description='description',
            type_name='type',
            is_generator=False,
            return_name='x')
        ],
    )

# Generated at 2022-06-11 21:31:29.634071
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is a function.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    Examples
    --------
    >>> example_of_good_indentation()
    True
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a function."

# Generated at 2022-06-11 21:31:32.854728
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse('') == {'short_description': None, 'long_description': None, 'blank_after_short_description': False, 'blank_after_long_description': False, 'meta': []}



# Generated at 2022-06-11 21:31:44.687164
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:57.243374
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Testing all inputs of the method parse. The method must return an instance of the class Docstring.
    docstring = NumpydocParser().parse('')
    assert isinstance(docstring, Docstring)
    docstring = NumpydocParser().parse('Testing')
    assert isinstance(docstring, Docstring)
    docstring = NumpydocParser().parse('Testing\nTesting')
    assert isinstance(docstring, Docstring)
    docstring = NumpydocParser().parse('This is a short description.\n\nThis is the long description')
    assert isinstance(docstring, Docstring)
    docstring = NumpydocParser().parse('This is a short description.\n\nThis is the long description\n\n\n')
    assert isinstance(docstring, Docstring)

# Generated at 2022-06-11 21:32:02.741553
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    """

    d = parse(docstring)
    assert d.meta[0].args == ['returns']

# Generated at 2022-06-11 21:32:12.999530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    run_parallel
        Run a function in parallel.

        Short description of the function.

        Long description of the function.

        Parameters
        ----------
        arg1 : type
            Description of arg1

        arg2 : type, optional
            Description of arg2, the default is None

        Returns
        -------
        return_name : type
            Description of the return value
    '''
    ret = NumpydocParser().parse(text)
    assert isinstance(ret, Docstring)
    assert ret.short_description == 'Run a function in parallel.'
    assert ret.long_description == 'Short description of the function.\n\nLong description of the function.'
    assert len(ret.meta) == 3
    assert isinstance(ret.meta[0], DocstringParam)

# Generated at 2022-06-11 21:32:20.042293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = '''
    This is a short description
    This is a long description and can also span over multiple lines

    Parameters:
        arg1 : type
            description of arg1

        arg2 : str, optional
            description of arg2

    Raises:
        ValueError
            description of ValueError
    '''

    docstring_class = NumpydocParser()
    docstring_object = docstring_class.parse(docstring)
    assert docstring_object is not None

# Generated at 2022-06-11 21:32:31.847750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Unit test for method parse of class NumpydocParser
    """
    text = '''
    Parameters
    ----------
    argname : type
        arg_description

    Other Parameters
    ----------------
    arg2name : type, optional
        arg2_description

    Returns
    -------
    return_name : type
        return_description

    See Also
    --------
    other_function

    Notes
    -----
    Note description

    '''

    ret = NumpydocParser().parse(text)

    assert ret.short_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.long_description is None

    assert len(ret.meta) == 5


# Generated at 2022-06-11 21:32:40.857692
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:46.292843
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This function returns the mean of a matrix.

    Parameters
    ----------
    x : int
        one integer
    y : float
        one float

    Returns
    -------
    total: float
        the sum of both values

    Examples
    --------
    >>> x = 49.
    >>> y = 99.
    >>> mean_example(x, y)
    74.
    """

    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "This function returns the mean of a matrix."

# Generated at 2022-06-11 21:32:54.237422
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ndp = NumpydocParser()

    # empty docstring
    assert ndp.parse("").short_description is None

    # short description only, no title
    assert ndp.parse("Some short description").short_description == "Some short description"

    # short description only, with title
    assert ndp.parse("Some short description\n\nParameters\n---------")\
        .short_description == "Some short description"

    # short description, no long description
    assert ndp.parse("Some short description\n\nParameters\n---------") \
        .long_description is None

    # short description, long description, no meta
    assert ndp.parse("Some short description\n\nSome long description") \
        .long_description == "Some long description"

    # short description, long description, multiple meta
    assert ndp

# Generated at 2022-06-11 21:33:02.334707
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import docstring
    p = docstring.NumpydocParser()
    test_docstring = "    This is a numpydoc style docstring.\n"
    test_docstring += "\n"
    test_docstring += "    Parameters\n"
    test_docstring += "    ----------\n"
    test_docstring += "    arg : str\n"
    test_docstring += "        Some information about arg\n"
    test_docstring += "\n"
    test_docstring += "    Raises\n"
    test_docstring += "    ------\n"
    test_docstring += "    Exception\n"
    test_docstring += "        The raised exception.\n"
    test_docstring += "    "

# Generated at 2022-06-11 21:33:08.550110
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse.__doc__
    assert isinstance(docstring, Docstring)
    assert docstring.short_description.strip() == "Parse numpy-style docstring into its components."
    assert docstring.long_description.strip() == ":returns: parsed docstring"

# unit tests for class NumpyDocParser

# Generated at 2022-06-11 21:33:20.147577
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:31.167730
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_for_test = """
    This is a test.
    What a test.
    Parameters
    ----------
    test1
    something very long and detailed
    test2
        something, with :type and :param
    test3
        something, with :param and :type
    test4 : int
    something with a type
    test5, : int
    something with a type, no :param
    Raises
    ------
    KeyError
        When a key is not found.
    ValueError
        When a value is not found.
    Examples
    --------
    >>> test()
    """

    ret = NumpydocParser().parse(text_for_test)
    assert ret.short_description=='This is a test.\nWhat a test.'

# Generated at 2022-06-11 21:33:42.418265
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:53.506465
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("string") == Docstring(
        short_description="string",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert NumpydocParser().parse("string\nlonger") == Docstring(
        short_description="string",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="longer",
        meta=[],
    )

# Generated at 2022-06-11 21:34:02.249746
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    Long description.

    Parameters
    ----------

    a : int
        The first parameter.
    b
        The second parameter.
    c : str
        The third parameter.
    d, optional
        The fourth parameter.
    e : {'a', 'b', 'c'}, optional
        The fifth parameter.

    Returns
    -------

    x : int
        Return value.
    y
        Another return value.
    z : str
        Yet another return value.

    Warns
    -----

    ValueError
        When the input is incorrect.

    Raises
    ------

    ValueError
        When the input is incorrect.
    """

    d = parse(text)

    # Docstring.short_description
    assert d.short_description == "This is the short description."

# Generated at 2022-06-11 21:34:12.531031
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:22.821391
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # NumpydocParser object
    n_parser = NumpydocParser()

    #String of the numpy-style docstring
    parsed_docstring = """
    First line of docstring
    
    Second line of docstring
    
    Parameters
    ----------
    param1 : int
        Description of a parameter
    
    Returns
    -------
    return1 : int
        Description of a returned value
    
    Examples
    --------
    >>> example1
    """

    #Parsed docstring
    docstr = n_parser.parse(parsed_docstring)

    #Verify parsed docstring
    assert(docstr.short_description == "First line of docstring")
    assert(docstr.long_description == "Second line of docstring")
    assert(docstr.blank_after_long_description)

# Generated at 2022-06-11 21:34:33.247359
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Description of function (short).

    Description of function (long).
    Optional paragraph with more information.

    Parameters
    ----------
    key1 : int, optional
        Description of key 1.

    key2 : str
        Description of key 2.

    Returns
    -------
    int
        Description of return value.
    """
    # result
    ret = Docstring()
    ret.short_description = "Description of function (short)."
    ret.long_description = "Description of function (long).\n"
    ret.long_description += "Optional paragraph with more information."
    # param key

# Generated at 2022-06-11 21:34:44.676494
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Short description.

    Longer description, which may include math
    and equations:

        E = mc^2

    Parameters
    ----------
    arg : int
        Description of `arg`.

    Returns
    -------
    int
        Description of return value.

    """
    ret = parse(docstring)
    assert ret.short_description == "Short description."
    print(ret.long_description)
    assert ret.long_description == "Longer description, which may include math\nand equations:\n\n    E = mc^2"
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 2
    assert len(ret.meta[0].args) == 1
    assert ret.meta[0].args

# Generated at 2022-06-11 21:34:52.071515
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ds_object = Docstring()
    ds_object.short_description = 'Example of docstring'
    ds_object.long_description = 'This function is used to make an example of docstring'
    ds_object.blank_after_short_description = True
    ds_object.blank_after_long_description = False

    # Parameters
    param1_obj = DocstringParam()
    param1_obj.args = ['param', 'int_first']
    param1_obj.description = 'an integer for testing'
    param1_obj.arg_name = 'int_first'
    param1_obj.type_name = 'int'
    param1_obj.default = None

    param2_obj = DocstringParam()
    param2_obj.args = ['param', 'int_second']
   

# Generated at 2022-06-11 21:35:03.349747
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Summary line
   
    Extended description

    Parameters:
    arg1 : int
        Description of arg1
    arg2
        Description of arg2

    Returns:
    str
        Description of return value

    """
    

# Generated at 2022-06-11 21:35:16.482923
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    result = parse("""
    this is the short description
    which might span multiple lines

    and here are some paragraphs in the
    long description

    Parameters
    ----------
    argname
        description of arg

    Returns
    -------
    None
    """)
    assert result.short_description == "this is the short description"
    assert result.long_description == "and here are some paragraphs in the long description"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False

# Generated at 2022-06-11 21:35:23.333035
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:35:33.873165
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring, DocstringMeta, DocstringParam

    parser = NumpydocParser()
    doc_string_mock = "This is a mock for numpy docstring.\n\n" \
                      "Parameters\n" \
                      "----------\n" \
                      "a_parameter : type of the parameter\n" \
                      "   This is a test parameter.\n" \
                      "another_parameter : type of the parameter\n" \
                      "   This is a test parameter.\n" \
                      "   Default is 0."
    docstring = parser.parse(doc_string_mock)
    assert doc_string_mock == docstring.text

# Generated at 2022-06-11 21:35:41.586990
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1: Numpy style docstring
    text = """
    The :func:`~show_docstring_numpy_style` function parses a Numpy style docstring.

    :param text: string to parse
    :type text: str
    :returns: parsed docstring
    :rtype: Docstring

    :raises ValueError:
    :raises KeyError:

    As an example:

    >>> from docstring_parser import NumpydocParser
    >>> NumpydocParser().parse("""

# Generated at 2022-06-11 21:35:53.268151
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:36:03.334595
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    inp = """A function that does something.
    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : bool
        Description of `arg2`. The description
        can span multiple lines
    Returns
    -------
    bool
        Description of the return value
    """
    out = parse(inp)
    assert out.short_description == "A function that does something."
    assert out.blank_after_short_description == False
    assert out.blank_after_long_description == False
    assert out.long_description == None
    assert out.meta[0].args == [ "param", "arg1" ]
    assert out.meta[0].description == "Description of `arg1`"
    assert out.meta[0].arg_name == "arg1"

# Generated at 2022-06-11 21:36:14.158018
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """
        test docstring.

        :param arg: meaningful argument.

        :param arg2: meaningful argument.
        :type arg2: type_of_arg2

        :return: what this function returns
        :rtype: return_type
        """
    d = NumpydocParser().parse(doc)
    assert d.short_description == "test docstring."
    assert d.long_description == ""
    assert d.blank_after_long_description is False
    assert d.blank_after_short_description is True
    assert d.meta[0].args == ["param", "arg"]
    assert d.meta[0].description == "meaningful argument."
    assert d.meta[1].args == ["param", "arg2"]
    assert d.meta[1].description == "meaningful argument."