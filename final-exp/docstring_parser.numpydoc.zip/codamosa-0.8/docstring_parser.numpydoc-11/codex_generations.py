

# Generated at 2022-06-11 21:27:23.338534
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    text = "test subject\n:param test_arg_1: this text is going to be parsed\n:param test_arg_2(optional): this text is going to be parsed\n:returns: return description, returns description not needed\n:raises Exception: this text is going to be parsed"
    result = obj.parse(text)
    assert type(result) == Docstring
    assert type(result.long_description) == str
    assert type(result.meta) == list
    for item in result.meta:
        assert type(item) == DocstringMeta
        assert type(item.args) == list
        assert type(item.description) == str




# Generated at 2022-06-11 21:27:25.253414
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-11 21:27:33.186993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(Section("My Title", "other_param"))

# Generated at 2022-06-11 21:27:42.883689
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = "this is the short description"
    b = "this is the long description"
    c = """
    Parameters
    ----------
    arg1 : type
        this is a parameter
    args2 : type
        parameter with multi-line description
    """
    doc = a + b + c
    c2 = inspect.cleandoc(c)
    print(doc)
    print(c2)
    parser = NumpydocParser()
    m = parser.parse(doc)
    print(m)
    assert m.short_description == a
    assert m.long_description == b
    assert len(m.meta) == 2
    assert m.meta[0].description == 'this is a parameter'
    assert m.meta[1].description == 'parameter with multi-line description'

# Generated at 2022-06-11 21:27:53.204750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    t = NumpydocParser().parse
    assert t('') == Docstring()
    assert t('\n') == Docstring()
    assert t(' \n\n') == Docstring()
    assert t('\n''Docstring text.\n\n''More text.\n') == Docstring(
        short_description='Docstring text.',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description='More text.'
    )
    assert t('\n''Docstring text.\n''More text.\n') == Docstring(
        short_description='Docstring text.',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description='More text.'
    )

# Generated at 2022-06-11 21:28:03.937161
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.
        Indented line.

    Parameters
    ----------
    arg1
        Description of arg1.
    arg2 : str
        Description of arg2.

    Raises
    ------
    AttributeError
        If any attribute is missing.
    ValueError
        If a value is invalid.
    """

    result = NumpydocParser().parse(text)

# Generated at 2022-06-11 21:28:12.256850
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring
    from .common import DocstringReturns
    from .common import DocstringParam
    from .common import DocstringExample
    
    parser = NumpydocParser()

# Generated at 2022-06-11 21:28:22.474725
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:34.552877
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def method():
        """This is a method.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_value
            A description of this returned value

        Raises
        ------
            SomethingSomethingError
                if something is broken

        Example
        -------
        >>> foo()
        """
    parser = NumpydocParser()
    result = parser.parse(method.__doc__)

# Generated at 2022-06-11 21:28:42.780038
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class TestClass:
        def __init__(self, a, b='b'):
            '''
            :param a: a param
            :param b: b param

            Short description
            Long description
            '''

        def func(self):
            '''
            :param self: self param

            Short description
            Long description
            '''

    from . import parser
    from . import common

    test_class = TestClass(1)

    dict_parse = parser.parse(TestClass.__init__.__doc__)
    assert isinstance(dict_parse, common.Docstring)
    assert dict_parse.short_description == 'Short description'
    assert dict_parse.long_description == 'Long description'

    dict_parse = parser.parse(TestClass.func.__doc__)

# Generated at 2022-06-11 21:28:59.605952
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:09.813631
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    desc = """This is a test function.

Parameters
----------
x : int
    input x
y : int
    input y

Raises
------
Exception
    If x > y

Returns
-------
x,y
    If x < y else x-y,y-x
"""
    desc = inspect.cleandoc(desc)
    parser = NumpydocParser()

    doc = parser.parse(desc)

    assert doc.short_description == "This is a test function."
    assert doc.long_description == "Parameters\n----------\nx : int\n    input x\ny : int\n    input y\n\nRaises\n------\nException\n    If x > y\n\nReturns\n-------\nx,y\n    If x < y else x-y,y-x"

# Generated at 2022-06-11 21:29:17.622331
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()
    obj = p.parse("""
    Test function:
    Computes the sum of the two input array.

    Parameters
    ----------
    a: array
        array of integers
        default: 1

    b: array, optional
       array of booleans
       default: True

    Returns
    -------
    out: array
        The sum of a and b
    """)

    assert obj.short_description == "Test function"
    assert obj.blank_after_short_description == True
    assert obj.blank_after_long_description == True
    assert len(obj.meta) == 2

    meta = obj.meta[0]
    assert meta.args == ["param", "a"]
    assert meta.description == "array of integers"
    assert meta.arg_name == "a"


# Generated at 2022-06-11 21:29:29.423115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    test doc
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    Parameters
    ----------
    
    
    
    
    
    
    
    
    
    test_arg : type
        test_arg_description
        can be multiline
    
    test_arg2 : type
        test_arg2_description
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    Returns
    -------
    ret : type
        Return description
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """
    doc = Nump

# Generated at 2022-06-11 21:29:39.734710
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    Parameters
    ----------
    arg1: type, optional
        The first parameter
        which is long enough
        to be a ''long'' description.

        It can also contain indented
        paragraphs.

    arg2 : type, optional, default='foo', aliases=['arg3']
        The second parameter

    attr1: type
        The first attribute
    attr2:
        The second attribute
    """

    doc = parse(text)

    # test short description
    assert doc.short_description == ""

    # test blank after short description
    assert doc.blank_after_short_description == False

    # test blank after long description
    assert doc.blank_after_long_description == True

    # test long description
    assert not doc.long_description

    assert len(doc.meta) == 2

   

# Generated at 2022-06-11 21:29:49.626198
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test how NumpydocParser() parse docstring.
    """
    # Example docstring
    example_doc = """
    Example
        Single line description

        Long description
            can be several lines

        Long description
            can be several lines
    """
    # Execute
    output = NumpydocParser().parse(example_doc)
    # Assert
    assert output.short_description == 'Example'
    assert output.long_description == 'Long description\r\ncan be several lines\r\n\r\nLong description\r\ncan be several lines'


# Generated at 2022-06-11 21:29:56.893567
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1: typical docstring
    text = '''
    Parameters
    ----------
    x : int
        Parameter of function

    Returns
    -------
    y : float
        Result of function
    '''
    ret = parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is True
    assert len(ret.meta) == 2
    assert ret.meta[0].description == "Parameter of function"
    assert ret.meta[0].type_name == "int"
    assert ret.meta[0].arg_name == "x"
    assert ret.meta[0].is_optional == False
    assert ret.meta[0].default is None
    assert ret.meta

# Generated at 2022-06-11 21:30:08.012052
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    inStr = r"""
    Test Numpy-style docstring
    Test Numpy-style docstring
    Test Numpy-style docstring
    Parameters
    ----------
    Test Numpy-style docstring
    Test Numpy-style docstring
    Test Numpy-style docstring
    Raises
    ------
    Test Numpy-style docstring
    Test Numpy-style docstring
    Test Numpy-style docstring
    """
    parser = NumpydocParser()
    outStr = parser.parse(inStr)
    assert outStr.short_description == 'Test Numpy-style docstring'
    assert outStr.blank_after_short_description == False
    assert outStr.long_description == 'Test Numpy-style docstring\nTest Numpy-style docstring\nTest Numpy-style docstring'
   

# Generated at 2022-06-11 21:30:18.238999
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = '''
    Args:
        arg_name: string
            A description of this arg,
            which spans multiple lines.
    Returns: something
    Deprecated since version 1.8: use ``blabla`` instead.
    '''
    res = NumpydocParser().parse(docstring)

# Generated at 2022-06-11 21:30:21.610368
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-11 21:30:34.526387
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:44.241127
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:56.412373
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''\
    This function does something.

    Parameters
    ----------
    param1 : int
        the first param
    param2 : str
        the second param

    Other Parameters
    ----------------
    opt1 : optional
        an optional param
    opt2 : optional, default 42
        another optional param

    Returns
    -------
    bool
        True if successful, False otherwise.
    '''

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This function does something."
    assert not docstring.blank_after_short_description
    assert docstring.long_description == ''
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 6

# Generated at 2022-06-11 21:31:06.683548
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parse the numpy-style docstring into its components.

    Parameters:
        text: string to parse: docstring

    Returns: Docstring
        parsed docstring

    Returns: boolean
        something else

    Warns: IndexError
        guess what, something went wrong.

    Raises: ValueError
        when something went wrong.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Parse the numpy-style docstring into its components."

# Generated at 2022-06-11 21:31:18.588398
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:30.578292
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:38.063301
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    sample = """Simple example function

    Parameters
    ----------
    a : int
        The first parameter.
    b : str, optional
        The second parameter.

    Returns
    -------
    int, float
        Sum of the two parameters.

    See Also
    --------
    something()
    """


# Generated at 2022-06-11 21:31:47.633947
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Testing a docstring section with no argument (no :), e.g.
    # Raises
    #   SomeException.
    test_docstring1 = '''
    This is a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long description.
    Raises
        SomeException.
    '''
    doc_parsed = NumpydocParser().parse(test_docstring1)
    assert doc_parsed.meta[0].description == "SomeException."

    # Testing a docstring

# Generated at 2022-06-11 21:31:53.703301
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parse the numpy-style docstring into its components.
    Parameters
    ----------
    text: str
        The docstring to be parsed.
    Returns
    -------
    docstring: Docstring
        The parsed docstring.
    """
    print(NumpydocParser().parse(text))



if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:32:05.704703
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = r"""
    This is a docstring.
    With multiple lines.
    """.strip()

    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "With multiple lines."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert not doc.meta

    text = r"""
    This is a docstring.

    With multiple lines.
    """.strip()

    doc = NumpydocParser().parse(text)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "With multiple lines."
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
   

# Generated at 2022-06-11 21:32:20.768753
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    a = '''
    Create a new Docstring.

    This can be used to create a custom docstring object from a string.

    Parameters
    ----------
    docstring : str
        The docstring as a string.

    Returns
    -------
    Docstring
        A parsed docstring.
    '''
    b = parser.parse(a)

# Generated at 2022-06-11 21:32:32.488409
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text="""
    brief description

    detailed description
    with two sentences.

    Parameters
    ----------
    arg1 : type
        Description of arg1
    arg2 : type (optional)
        Description of arg2
        over two lines
    arg3, optional
        Description of arg3

    Other Parameters
    ----------------
    arg4
        Description of arg4


    See Also
    --------
    other_function
    """
    parser = NumpydocParser([
        ParamSection("Parameters", "parameter"),
        ParamSection("Other Parameters", "other_parameter"),
        Section("See Also", "see_also"),
    ])
    doc = parser.parse(text)
    assert doc.short_description=="brief description"
    assert doc.long_description=="detailed description\nwith two sentences."
    assert doc

# Generated at 2022-06-11 21:32:41.331894
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test simple
    text = "Short description\nlong description\nyield: optional: anything"
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "Short description"
    assert doc.long_description == "long description"
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["yield", "optional"]
    assert doc.meta[0].description == "anything"

    # test with two different type of sections
    text = "Short description\n\nYield:\n\tDescription of yield\n\nParameters\n\tDescription of parameters"
    doc = NumpydocParser().parse(text)
    assert doc.short_description == "Short description"
    assert len(doc.meta) == 2

# Generated at 2022-06-11 21:32:50.601425
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Note: this is not a test file
    class Test:
        def __init__(self, text):
            self.text = text

        def __repr__(self):
            p = parse(self.text)
            s = "\n".join(
                (
                    "",
                    "short_description = [{}]".format(p.short_description),
                    "long_description = [{}]".format(p.long_description),
                    "blank_after_short_description = [{}]".format(
                        p.blank_after_short_description
                    ),
                    "blank_after_long_description = [{}]".format(
                        p.blank_after_long_description
                    ),
                    "meta =",
                )
            )

# Generated at 2022-06-11 21:32:59.860932
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    nd = NumpydocParser()

    short_description = """
    This is a short description.
    """
    long_description = """
    This is a long description.
    """
    meta = """
    This is a meta description.
    """

    desc = short_description + long_description + meta

    meta_chunk = "Parameters\n----------\n" + meta
    desc_chunk = short_description + long_description

    assert nd.parse(desc).short_description == desc_chunk.strip()
    assert nd.parse(desc).meta == [
        DocstringMeta(["param"], description="This is a meta description.")
    ]
    assert nd.parse(desc).long_description == long_description.strip()

# Generated at 2022-06-11 21:33:04.823859
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d = NumpydocParser().parse("a\nb\nc\nd")
    assert(d.long_description == "b\nc")
    assert(d.short_description == "a")
    assert(d.blank_after_short_description)
    assert(d.blank_after_long_description)



# Generated at 2022-06-11 21:33:14.873158
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	text = """
		Parser for numpy-style docstrings.

		Convert numpy-style docstrings to a dictionary of numpydoc.Docstring
		elements.

		The parser is flexible, but assumes the docstring is formatted in a
		certain way. It must follow the numpy-style (described below), with
		type annotations separated by ``:``::

			def parse(text: str) -> Docstring:
				"""

# Generated at 2022-06-11 21:33:21.940436
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # create test object
    ndp = NumpydocParser()

    # test for method parse with no doc string
    assert not ndp.parse("")

    # test for method parse with a valid doc string
    assert ndp.parse("This is a test doc string.")

    # test for method parse with invalid syntax
    assert ndp.parse("This is a test doc string.\n")



# Generated at 2022-06-11 21:33:32.779765
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # No docstring
    assert parser.parse("") == Docstring()

    # Short description only, stripped
    assert parser.parse("     \nHello world") == Docstring(
        short_description="Hello world", long_description=None
    )

    # Long description only, stripped
    assert parser.parse(
        "Hello world\n   \nThis is a long description"
    ) == Docstring(
        short_description=None,
        long_description="This is a long description",
        blank_after_long_description=False,
    )

    # Short and long descriptions, blank after short, stripped

# Generated at 2022-06-11 21:33:34.113594
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser


# Generated at 2022-06-11 21:33:46.947684
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = str(parser.parse("""
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
        eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
        enim ad minim veniam, quis nostrud exercitation ullamco laboris
        nisi ut aliquip ex ea commodo consequat.

        :param a: a parameter
        :param b: another parameter
        :returns: A value
        :raises ValueError: for some reason
        :raises RuntimeError: because reasons
    """))

# Generated at 2022-06-11 21:33:58.118562
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_object = NumpydocParser()

# Generated at 2022-06-11 21:34:01.785758
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    d = "Test for parse() of NumpydocParser"
    doc = Docstring(short_description=d)
    doc.meta.append(DocstringMeta(["notes"], description=d))
    assert obj.parse(d) == doc

# Generated at 2022-06-11 21:34:12.235049
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:22.610110
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Short description

        Long description can span multiple
        lines.

        Parameters
        ----------
        arg_name : type, optional
            Argument description

        Raises
        ------
        ValueError
            When something goes wrong

        Examples
        --------
        >>> hello()
        Hello, world.

        References
        ----------
        Some reference
    """

    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "Short description"
    assert docstring.long_description == (
        "Long description can span multiple\n" "lines."
    )
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

    assert docstring.meta[0].key == ["param", "arg_name"]
    assert docstring

# Generated at 2022-06-11 21:34:33.027289
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    Short description

    Long description

    Parameters
    ----------
    x : int
        A number

    Returns
    -------
    result : int
        x + 1
    """
    parsed = parser.parse(docstring)
    assert parsed.long_description == "Long description"
    assert parsed.short_description == "Short description"
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert len(parsed.meta) == 2
    assert parsed.meta[0].name == 'param'
    assert parsed.meta[0].args[0] == 'param'
    assert parsed.meta[0].args[1] == 'x'
    assert parsed.meta[0].description == 'A number'

# Generated at 2022-06-11 21:34:44.399150
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the method parse of NumpydocParser class.
    """

    text = """Docstring for a class.
    Parameters:
        param1 : int
            Description of `param1`.
        param2 : str
            Description of `param2`.
    Returns:
        str
            Description of the return value.
        int
            Description of the second return value.
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Docstring for a class."
    assert docstring.long_description == """
    Parameters:
        param1 : int
            Description of `param1`.
        param2 : str
            Description of `param2`.
    Returns:
        str
            Description of the return value.
        int
            Description of the second return value.
    """
   

# Generated at 2022-06-11 21:34:51.954432
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:01.820635
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    test_text = """
    For example, ``_get_base_docstring(obj)`` will do the following
    things:

    *   If ``obj`` has an ``_np_doc_base`` attribute, return it
    *   If ``obj`` is a NumPy ufunc, return the docstring of its
        wrapped function
    *   Otherwise, return the docstring of ``obj``'s base
        :class:`~numpy.ndarray` constructor
        """

# Generated at 2022-06-11 21:35:14.655945
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # test case 1: no type, default value, optional, no blank
    text = "test function"
    assert NumpydocParser().parse(text).short_description == "test function"

    # test case 2: has type, default value, no blank
    text = "test function\nParameters\n----------\nparam1 : type\n    param1 description"
    assert NumpydocParser().parse(text).short_description == "test function"
    assert NumpydocParser().parse(text).meta[0].arg_name == "param1"
    assert NumpydocParser().parse(text).meta[0].type_name == "type"

    # test case 3: no type, no blank, optional
    text = "test function\nParameters\n----------\nparam1, optional\n    param1 description"

# Generated at 2022-06-11 21:35:30.277114
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Docstring for abc.

    Parameters
    ----------
    arg_1: type: str
        Description for arg_1.
    arg_2 : type: str, optional
        Description for arg_2.

    Returns
    -------
    type1
        Description for return.

    Raises
    ------
    TypeError
        Description for TypeError.
    '''
    text = inspect.cleandoc(text)
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "Docstring for abc."

# Generated at 2022-06-11 21:35:41.451947
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a short description
    This is a long description

    Parameters
    ----------
    param_1 : str, optional
        Describes param 1.
    param_2 : int
        Describes param 2.
    other_param_1
        Describes another param.

    Returns
    -------
    ret_1 : int
        Describes return 1.
    ret_2 : str
        Describes return 2.

    Raises
    ------
    AttributeError
        If the attribute is not found.
    ValueError
        If the value is invalid.
    '''
    res = parse(text)
    assert res.short_description == 'This is a short description'
    assert res.long_description == 'This is a long description'
    assert res.blank_after_short_description == True
    assert res

# Generated at 2022-06-11 21:35:52.850980
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:36:03.245468
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    A quick brown fox jumps over the lazy dog

    Parameters
    ----------

    arg1 : int
        An integer argument.

    arg2 : list of str
        A list of strings.

    Raises
    ------
    ValueError
        If `arg2` is empty.

    Returns
    -------
    str
        The joined string.
    """

    doc = NumpydocParser().parse(docstring)
    assert doc.short_description == "A quick brown fox jumps over the lazy dog"
    assert doc.long_description is None
    assert len(doc.meta) == 2
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[1].args[0] == "raises"


# Generated at 2022-06-11 21:36:14.082728
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Unit test for NumpydocParser_parse
    """
    # Given
    text = """
    The text before the section
    Parameters
    ----------
    param_1 : int
        This is the first parameter
    param_2 : str
        This is the second parameter
    Raises
    ------
    TypeError
        The raised error.
    Warning
        The warning.
    """
    # When
    docstring = NumpydocParser().parse(text)
    # Then
    assert docstring.short_description == "The text before the section"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    assert docstring.meta[0].args == ['param', 'param_1']
   