

# Generated at 2022-06-11 21:26:49.084168
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    expected = [
        DocstringParam(
            args=["param", "arg_name"],
            description="arg_description",
            arg_name="arg_name",
            type_name=None,
            is_optional=None,
            default=None,
        ),
        DocstringParam(
            args=["param", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            arg_name="arg_2",
            type_name="type",
            is_optional=True,
            default=None,
        ),
    ]
    actual = list(_KVSection(title="Parameters", key="param").parse(
        "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    ))
   

# Generated at 2022-06-11 21:26:58.999575
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    items = parser.parse('''
    A docstring for this class, including a section header.

    Parameters
    ----------
    param_a
        Parameter A.
    param_b : int
        Parameter B.
    param_c, optional
        Parameter C.

    Returns
    -------
    return_thing
        Return value.

    Raises
    ------
    TypeError
        If the input is wrong.
    ''')


# Generated at 2022-06-11 21:27:07.006417
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key1
        value1
    key2 : type2
        value2
    """
    parser = _KVSection(title="title_test", key="key_test")
    text_parsed = [
        x.description
        for x in parser.parse(inspect.cleandoc(text))
        if x.description is not None
    ]
    assert(text_parsed == ["value1", "value2"])


# Generated at 2022-06-11 21:27:19.417050
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Init unit test
    text = """
    Short Description

    Long Description

    Parameters
    ----------
    arg1 : int > 2
        arg1 description

    arg2 : str, optional
        arg2 description

    Raises
    ------
    TypeError:
        When arg1 is not an int

    Examples
    --------
    >>> import os
    >>> my_function()
    """
    # Parse the text
    docstring = NumpydocParser().parse(text)
    # Assert the parsed docstring
    assert docstring.short_description == "Short Description"
    assert docstring.long_description == "Long Description"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    # Assert the parameters

# Generated at 2022-06-11 21:27:26.161702
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """longitude
        Longitude of the view point (in degrees east)
      latitude
        Latitude of the view point (in degrees north)
    """
    values = ["Longitude of the view point (in degrees east)", "Latitude of the view point (in degrees north)"]
    result = _KVSection.parse(text)
    assert result
    assert len(result) == 2
    assert [i.value for i in result] == values

# Generated at 2022-06-11 21:27:32.836910
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    expected_list = [
        DocstringParam(
            args=["param", "arg_name"],
            description="arg_description"
        ),
        DocstringParam(
            args=["param", "arg_2"],
            description="descriptions can also span...\n... multiple lines",
            type_name="type",
            is_optional=True
        ),
    ]
    section = ParamSection("Parameters", "param")
    assert list(section.parse(text)) == expected_list

# Generated at 2022-06-11 21:27:38.087901
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text =\
        '''
        Parameters
        ----------
        a : int, optional
            A number.
        b : int, optional
            Another number.
        '''

    param = ParamSection('Parameters', 'param')

    for meta in param.parse(text):
        print(meta)

if __name__ == "__main__":
    test__KVSection_parse()

# Generated at 2022-06-11 21:27:45.838988
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    desc = """A method to multiplies a and b

:param a: A number
:type a: int
:param b: A number
:type b: int
:param c: A number
:type c: int
:returns: int -- The product of a and b"""
    p = NumpydocParser()
    d = p.parse(desc)
    assert(d.short_description=="A method to multiplies a and b")
    assert(d.long_description==":param a: A number\n:type a: int\n:param b: A number\n:type b: int\n:param c: A number\n:type c: int\n:returns: int -- The product of a and b")
    assert(d.blank_after_short_description)

# Generated at 2022-06-11 21:27:49.916576
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser().parse(inspect.cleandoc(
        """
        Quick summary
        Long summary

        Parameters
        ----------
        p1 : type
            description

        Returns
        -------
        out : type
            another description

        Warnings
        --------
        warning 1
        warning 2

        """
        )
    )



# Generated at 2022-06-11 21:27:51.126861
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    doctest.testmod(raise_on_error=True)

# Generated at 2022-06-11 21:28:04.125365
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    raw_docstring = """test_parse

    This is the long description for test_parse.

    Parameters
    ----------
    param_1
        This is some extra info about the param_1 parameter. It can span
        multiple lines if need be.
    param_2 : int, optional
        This is some extra info about the param_2 parameter. It can span
        multiple lines if need be.

    Returns
    -------
    str
        This is some info about the return value.

    Warns
    -------
    None
        This function does not throw any warnings.

    Raises
    -------
    ValueError
        This is some info about the ValueError exception.
    """

    def compare(a, b):
        assert a.short_description == b.short_description
        assert a.long_description == b.long_description

# Generated at 2022-06-11 21:28:12.341827
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def my_test_func(param1, param2):
        """This is a test docstring.

        Params:
            param1: First parameter
            param2: Second parameter

        Raises:
            KeyError: No such key
            ValueError: No such value

        Other Parameters:
            key: value

        Returns:
            Something else
        """
        pass

    docstr = parse(my_test_func.__doc__)
    assert len(docstr.meta) == 4

    assert docstr.meta[0].args == ["param", "param1"]
    assert docstr.meta[0].description == "First parameter"
    assert docstr.meta[0].arg_name == "param1"

    assert docstr.meta[1].args == ["param", "param2"]

# Generated at 2022-06-11 21:28:22.475340
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:31.786877
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    A test method with a docstring conforming to the numpydoc
    guide.

    Parameters
    ----------
    x : float
        The parameter x.
    y : bool, optional
        The parameter y. Default is True
    z : bool
        The parameter z.

    Returns
    -------
    float
        The return value.

    Examples
    --------
    This is an example
    >>> print(parse('hi'))
    None

    See Also
    --------
    some_other_method : Description of what this is related to.
    """
    parse(text)

# Generated at 2022-06-11 21:28:42.575388
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:50.236782
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    short desc line 1
    short desc line 2
    long desc line 1
    long desc line 2
    long desc line 3

    Parameters
    ----------
    param1: int, optional
        description 1.
    param2: float, optional(default=0.5)
        description 2.

    Raises
    ------
    ValueError
        description 3

    Returns
    -------
    spamegg : str
        description 4
    spam : str
        description 5
    '''
    expected_short_description = 'short desc line 1\nshort desc line 2\n'
    expected_long_description = 'long desc line 1\nlong desc line 2\nlong desc line 3\n'

# Generated at 2022-06-11 21:28:54.704737
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """Returns the base parameters of the given parameter, if possible

    Parameters
    ----------
    parameters : typing.Sequence[typing.Any]
        The parameters to convert
    """

    result = NumpydocParser().parse(doc)
    assert isinstance(result,Docstring)
    assert isinstance(result.short_description, str)
    assert isinstance(result.long_description, str)
    assert isinstance(result.blank_after_short_description, bool)
    assert isinstance(result.blank_after_long_description, bool)
    assert isinstance(result.meta, list)
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringMeta)

#Unit test for method _setup of class NumpydocParser

# Generated at 2022-06-11 21:29:02.320559
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()


# Generated at 2022-06-11 21:29:12.556741
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class FakeSection:
        def __init__(self):
            self.title = "Title"
            self.key = "Key"
        def parse(self,text):
            return [DocstringMeta.from_str(f"{self.key} <{text}>")]

    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(FakeSection())

    docstring = Docstring.from_str(
        """\
Description

.. Title:: Parameters
    Param1
        Desc1
    Param2: Type2, optional
        Desc2
    .. Title:: Retourne
        Retourne: Type3
            Desc3
Notes:
  - Title
  - Description
"""
    )

# Generated at 2022-06-11 21:29:27.173441
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Unit test for method parse of class NumpydocParser
    npd_obj = NumpydocParser()

# Generated at 2022-06-11 21:29:40.126785
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pytest
    tp = NumpydocParser()

# Generated at 2022-06-11 21:29:52.260945
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    arg_name = "attributes"
    arg_description = "A list of attributes, where each attribute is one of the following types:"
    argtype_value = "pandas.Series"
    argtype_description = "A pandas.Series with a DatetimeIndex"
    argtype_value_optional = "pandas.DataFrame"
    argtype_description_optional = "A pandas.DataFrame with a DatetimeIndex"
    argtype_value_default = "numpy.array"
    argtype_description_default = "A numpy.array with a datetime64 dtype"

# Generated at 2022-06-11 21:30:03.011180
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_string = r'''Parse the numpy-style docstring into its components.
    :param body: method body
    :returns: parsed docstring
    '''
    docstring = parser.parse(test_string)

    assert docstring.short_description == "Parse the numpy-style docstring into its components."
    assert docstring.long_description == None

    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'body'
    assert docstring.meta[0].description == 'method body'

    assert docstring.meta[1].args[0] == 'returns'
    assert docstring.meta[1].args[1] == None

# Generated at 2022-06-11 21:30:04.610336
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse(text="Test test") == Docstring()



# Generated at 2022-06-11 21:30:11.949883
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    t = NumpydocParser()
    # Valid docstring examples
    assert t.parse('''
    """
    :param a: None
    """
    ''').meta == [DocstringMeta([
        'param'
    ], [], {
        'args': ['param', 'a']
    })]
    assert t.parse('''
    """
    :param a: None
        :type a: bool
    """
    ''').meta == [DocstringMeta([
        'param'
    ], [], {
        'args': ['param', 'a'],
        'arg_name': 'a',
        'type_name': 'bool'
    })]

# Generated at 2022-06-11 21:30:20.551686
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc_string = """
    The first argument of the log-likelihood function.

    Parameters
    ----------
    model : Model
        The model object.
    params : array of float
        The parameter under evaluation.
    indices : array of int
        The indices of the parameters to consider.

    Returns
    -------
    loglike : float
        The evaluated log-likelihood function.
    """
    parsed_doc_string = parser.parse(doc_string)
    assert parsed_doc_string.short_description == "The first argument of the log-likelihood function."
    assert parsed_doc_string.long_description == "The model object.\n\nThe parameter under evaluation.\n\nThe indices of the parameters to consider."
    assert parsed_doc_string.blank_after_long_description

# Generated at 2022-06-11 21:30:28.080007
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    docstring = """
        Parameters
        ----------
        val: int
            Some value.
        word: str
            Word to say.
        times: int, optional
            How many times to say it.

        Returns
        -------
        str
            The concatenated word.
        """

    parser = NumpydocParser()
    parsed_docstring = parser.parse(docstring)

    # Test parsed elements
    assert parsed_docstring.short_description == ""
    assert parsed_docstring.long_description == None
    assert parsed_docstring.metas[0].args == ['param', 'val']
    assert parsed_docstring.metas[1].args == ['param', 'word']
    assert parsed_docstring.metas[2].args == ['param', 'times']

# Generated at 2022-06-11 21:30:36.685175
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .numpydoc import parse
    from .common import Docstring, DocstringParam, DocstringReturns, \
        DocstringRaises
    from .common import DocstringMeta, DocstringDeprecated

    class TestSection(Section):
        def __init__(self, title: str, key: str):
            super().__init__(title, key)
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))


# Generated at 2022-06-11 21:30:45.126868
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringParam, DocstringReturns, DocstringMeta
    from .exceptions import InvalidType

    numpydoc_parser = NumpydocParser()

    # Default
    test_docstring = """\
        This is a test docstring.

        Parameters
        ----------
        a : int
            Some integer parameter

        b : str
            Some string parameter
    """

    docstring = numpydoc_parser.parse(test_docstring)


# Generated at 2022-06-11 21:30:57.137072
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # The test string
    text = """
    The first line is always used as the short summary, and should be of the form
    "<entity> does <something>", such as "Compute the FFT of some data."
    The next few lines are also a short description and are not indented.
    [Default]
    The remaining part of the docstring is indented and contains a longer description,
    which may include equations etc.

    Parameters
    ----------
    arg : str
        Description of `arg`.
        Can contain multiple lines
    arg2 : {'foo', 'bar'}, optional
        Description of `arg2`,
        default: 'foo'
        [Default is 'foo']

    Returns
    -------
    bool
        Description of the return value
    """

    # The expected result

# Generated at 2022-06-11 21:31:08.237377
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Unittest for method parse of class NumpydocParser.
    # @author: Zhibin
    # @create_at: 2019-01-25

    text = """\
    This is a test.

    Parameters
    ----------
    arg1 : str
        arg1 description.
    arg2 : str, optional
        arg2 description.
    arg3 : str (optional)
        arg3 description.
    arg4 : str, default is 0
        arg4 description.
    arg5 : int, default is 0
        arg5 description.

    Returns
    -------
    returns : int
        return description."""

    docstring = NumpydocParser().parse(text)
    assert docstring.long_description is not None
    meta = docstring.meta
    assert meta[0].arg_name == "arg1"


# Generated at 2022-06-11 21:31:19.718068
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import (
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
    )
    ds = NumpydocParser().parse("""\
    test_NumpydocParser_parse

        Short description of `f`.

        Long description of ``f``.
        Description may span multiple lines.

        Parameters
        ----------
            arg : int
                A positional argument.
            kw : str, optional
                A keyword-only argument.
            *args
                Positional arguments.
            **kwargs
                Keyword arguments.

        Returns
        -------
            int
                Return value.
            str
                Another return value.
    """)
    assert ds.short_description == "Short description of `f`."

# Generated at 2022-06-11 21:31:31.681558
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("\nTesting NumpydocParser.parse...")
    parser = NumpydocParser()
    # Method parse should return an object of class Docstring
    expected = Docstring()
    expected.short_description = "A test description"
    expected.long_description = "This is the long description"
    expected.blank_after_short_description = False
    expected.blank_after_long_description = False

# Generated at 2022-06-11 21:31:38.831223
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a doctest sample.

    :param arg1: 1st Positional argument, does nothing
    :type arg1: int
    :param arg2: 2nd Positional argument, does nothing
    :type arg2: str
    :param arg3: 3rd Positional argument, does nothing
    :type arg3: str

    :returns: Return a string with a concatenated version of all arguments.

    :raises TypeError: if any argument is not a string

    """
    docstring = NumpydocParser().parse(text)

    assert str(docstring) == text

    assert docstring.short_description == "This is a doctest sample."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == ""
    assert docstring.blank_after_long

# Generated at 2022-06-11 21:31:41.400081
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()
    assert len(p.sections) == 31
    assert any(s.title == 'Returns' for s in p.sections)
    assert any(s.title == 'Returns' for s in p.sections)
    assert any(s.title == 'Yields' for s in p.sections)

# Generated at 2022-06-11 21:31:49.224343
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:53.670643
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Testcase for NumpydocParser class
    """
    text = """
    Parse the numpy-style docstring into its components.

    :param a: input param
    :param b: input param
    :returns: Nothing
    :raises KeyError: Raises an exception
    """
    doc = NumpydocParser().parse(text)
    assert doc.long_description == "Parse the numpy-style docstring " \
                                   "into its components."
    assert doc.short_description == "Parse the numpy-style docstring " \
                                    "into its components."
    assert not doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].type == 'param'

# Generated at 2022-06-11 21:32:05.663871
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
myfunction(arg1, arg2, arg3):
    This is a test function that does nothing useful.
    This is a test. It has a long description.

    Parameters
    ----------
    arg1 : str
        First argument.
    arg2 : int
        Second argument.
    arg3 : function
        Function that does something.

    Returns
    -------
    str
        The answer.
    '''

    # Clean according to PEP-0257
    text = inspect.cleandoc(text)

    # Find first title and split on its position
    titles_re = re.compile(r"^Parameters\s*?\n-+\s*$")
    match = titles_re.search(text)
    if match:
        desc_chunk = text[: match.start()]
        meta

# Generated at 2022-06-11 21:32:14.831754
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:23.573729
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:35.625516
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    This function is to check if the parsed docstring components are correct
    """
    text = inspect.cleandoc(
        """
    This is a docstring, which is used to test the parse function
    in the module numpydoc.

    Parameters
    ----------
    this is a parameter : str, optional
        with some description spanning multiple lines

    Returns
    -------
    a_return : str
        this is a return with description

    Raises
    ------
    a_raise_type
        description of what may raise this error
    """
    )


# Generated at 2022-06-11 21:32:43.044395
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringRaises
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import DocstringParam
    from .common import DocstringMeta
    from .common import Docstring

    numpydoc_parser = NumpydocParser()
    description = """\
        This function does nothing.

        But it does it very well. 

        Parameters
        ----------
        arg1 : int
            arg1 decription

        arg2 : str
            arg2 decription

        arg3 : bool
            arg3 decription

        arg4, optional
            arg4 decription

        arg5, optional, default=3 
            arg5 decription

        Returns
        -------
        return_name : return_type
            return_description

        """

# Generated at 2022-06-11 21:32:54.523919
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:00.462457
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:11.557705
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text_1 = '''This is a test string
    Parameters
    ----------
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    '''
    doc_1 = parser.parse(text_1)
    assert isinstance(doc_1.short_description, str)
    assert doc_1.short_description == 'This is a test string'
    assert isinstance(doc_1.long_description, None)
    assert doc_1.blank_after_short_description == True
    assert doc_1.blank_after_long_description == False
    assert doc_1.meta[0].args == ["param", "key"]
    assert doc_1.meta[0].type_name == None

# Generated at 2022-06-11 21:33:21.173588
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_txt = """
    Parameters
    ----------
    y : array()
        The dependent variable.

    x : array(2)
        The independent variables.
    """
    expected_txt = """
    Parameters
    ----------
    y : array()
        The dependent variable.

    x : array(2)
        The independent variables.
    """
    parser = NumpydocParser()
    parsed = parser.parse(test_txt)
    assert parsed.long_description == expected_txt
    assert len(parsed.meta) == 2

# Generated at 2022-06-11 21:33:30.139876
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = """Test docstring

    Parameters
    ----------
    a : int
        This is a parameter.

    b : str
        This is another parameter.

    Raises
    ------
    ValueError
        Raised if a non-integer is used.

    Returns
    -------
    result : int
        Result of the computation.

    """
    res = parse(s)
    # print(res)
    assert res.meta[0].args[1] == 'a'
    assert res.meta[2].args[1] == 'ValueError'
    assert res.meta[3].args[1] == 'result'


# Generated at 2022-06-11 21:33:40.655334
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = '''Single line description.
    Another line.
    
    This is the long description.
    
    Parameters
    ----------
    arg1 : type
        This is the description of arg1.
    
    arg2 : AnotherType
        Another description.
    
    Raises
    ------
    ValueError
        If arg1 is of a wrong type.
    
    Other Parameters
    ----------------
    kwarg1
    
    kwarg2 : A third type
    
    Returns
    -------
    return_type
        The return value description.
    
    See Also
    --------
    :func:`module.function`
    '''
    parser = NumpydocParser()
    result = parser.parse(doc)
    assert result
    assert result.short_description == 'Single line description.'
    assert result

# Generated at 2022-06-11 21:33:48.424761
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string = """
    Some description
    
    Parameters
    ----------
    stuff : int
        Stuff.
    items : list of str
        Items to do stuff to.
    other : str, optional
        If provided, do this instead.
    
    Raises
    ------
    ValueError
        If there is not enough stuff.
    RuntimeError
        If things break.
    
    Returns
    -------
    result : str
        The result of doing stuff to items.
    """
    result = parse(doc_string)
    assert result.short_description == 'Some description'

# Generated at 2022-06-11 21:33:59.081398
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	parser = NumpydocParser()
	text_parse = parser.parse(""""
    Description of the function

    Description with multiple lines

    :param arg1: description for arg1
    :type arg1: str
    :param arg2: description for arg2
    :type arg2: int, optional
    :param arg3: description for arg3
    :type arg3: int
    :param arg4: description for arg4 with default value
    :type arg4: str
    :default arg4: default_value
    :returns: None
    :rtype: int
	""")
	assert text_parse.short_description == " Description of the function"

	assert text_parse.long_description == """ Description with multiple lines"""

	assert text_parse.meta[0].args[0] == "param"
	assert text_

# Generated at 2022-06-11 21:34:13.941702
# Unit test for function parse
def test_parse():
    # Function to test the parsing of numpy docstring style
    def func(a, b=1, c=None):
        """Function with parameters
        
        This function has parameters that need to be described.
        
        Parameters
        ----------
        a : int
            The first number.
        b : int, optional
            The second number.
        c : int, optional
            The third number.
        
        Returns
        -------
        int
            The sum of the three numbers.
        """
        return a + b + c

    docstring = parse(func.__doc__)
    assert len(docstring.meta) == 2
    assert len(docstring.meta.param) == 3
    assert len(docstring.meta.returns) == 1
    assert docstring.short_description == 'Function with parameters'
    assert docstring

# Generated at 2022-06-11 21:34:19.529519
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """My code

    .. deprecated:: 1.0.1
       Use my_code instead.
    """

    docstring = NumpydocParser().parse(text)
    assert len(docstring.meta) == 1
    assert isinstance(docstring.meta[0], DocstringDeprecated)
    assert docstring.meta[0].version == "1.0.1"



# Generated at 2022-06-11 21:34:30.139139
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = Section("Parameters", "param")
    text = """Parameters
    ----------
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    result = list(section.parse(text))
    assert len(result) == 2
    assert isinstance(result[0], DocstringMeta)
    assert result[0].description is not None
    assert result[0].description == "value"
    assert result[1].description == "values can also span...\n... multiple lines"
    assert result[0].args == ["param", "key"]
    assert result[1].args == ["param", "key2"]
    assert result[1].type_name is not None
    assert result[1].type_name == "type"

#

# Generated at 2022-06-11 21:34:33.318086
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    target = Section("Raises","raise")
    # Assert none-null
    assert target is not None
    # Assert none-null title
    assert target.title is not None
    # Assert none-null key
    assert target.key is not None


# Generated at 2022-06-11 21:34:42.340783
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Test the add_section method of class NumpydocParser

    :return: True if the test passed
    """
    ndp = NumpydocParser()
    new_section = Section("NewSection", "new_section")
    old_sections = ndp.sections

    assert new_section.title not in old_sections
    ndp.add_section(new_section)
    assert new_section.title in ndp.sections
    assert old_sections != ndp.sections
    assert ndp.titles_re.match(r"^(?!NewSection)\s*$") is None
    return True

# Generated at 2022-06-11 21:34:47.703336
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    result = deprecation_section.parse("https://github.com/google/eng-edu/blob/master/ml/guides/text_classification/implementing_a_cnn.ipynb")
    result = list(result)

    assert len(result) == 1
    assert result[0].args == ["deprecation"]



# Generated at 2022-06-11 21:34:58.761275
# Unit test for function parse
def test_parse():
    d = """
    Single line description

        >>> a = 1
        >>> b = 2
        >>> c = a + b

        Single line description continued
    """
    dd = parse(d)
    assert dd.short_description == 'Single line description'
    assert dd.long_description == """
    >>> a = 1
    >>> b = 2
    >>> c = a + b

    Single line description continued
    """
    assert dd.blank_after_short_description == True
    assert dd.blank_after_long_description == True

    d = """
    Single line description

        >>> a = 1
        >>> b = 2
        >>> c = a + b

        Single line description continued

    """
    dd = parse(d)
    assert dd.short_description == 'Single line description'

# Generated at 2022-06-11 21:35:09.421585
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # the version
    # version is the first line of the text
    version = "0.0.0"
    section = DeprecationSection("Deprecation Warning", version)

    # the beginning of the deprecated method
    head_text = ".. deprecated:: " + version
    assert section.title_pattern == r"^\.\.\s*(Deprecation Warning)\s*::"

    description = "Use foo() instead."

    # the end of the deprecated method
    tail_text = description
    text = head_text + "\n\t" + tail_text

    meta = section.parse(text)
    assert str(meta.__next__()) == "Deprecated(Deprecation Warning: Use foo() instead.)"

# Generated at 2022-06-11 21:35:17.427344
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    Args
    ----------
    :param df: blah blah blah

    :param table_name:
        hey this is a table name

    :param schema: default is default

    :param if_exists: default is fail
    """
    sections = [_KVSection("Args", "Arg")]
    ret = Docstring()
    parser = NumpydocParser(sections=sections)
    ret = parser.parse(text)
    assert isinstance(ret, Docstring)



# Generated at 2022-06-11 21:35:29.427304
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Short description.

        Long description.

        Contains a :class:`ParamSection` and a :class:`RaisesSection`.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Raises
        ------
        ValueError
            A description of what might raise ValueError
        """
    parsed = NumpydocParser().parse(text)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta[0].args == ["param", "arg_name"]
    assert parsed.meta[0].description == "arg_description"

# Generated at 2022-06-11 21:35:49.450410
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section.parse(" **Parameters**: \n   * **a** -- The first parameter.\n   * **b** -- The second parameter.").count(" * **a** -- The first parameter.") == 1
    assert Section.parse(" **Parameters**: \n   * **a** -- The first parameter.\n   * **b** -- The second parameter.").count(" * **b** -- The second parameter.") == 1
    assert Section.parse(" **Parameters**: \n   * **a** -- The first parameter.\n   * **b** -- The second parameter.").count("**Parameters**: \n") == 1


# Generated at 2022-06-11 21:35:55.576362
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = '.. deprecated:: 2.0\n   Use :func:`numpy.array` instead.'
    result = DeprecationSection("deprecated","deprecation").parse(text)
    expected = [DocstringDeprecated(args=['deprecation'], description='Use :func:`numpy.array` instead.', version='2.0')]
    assert list(result) == expected

# Generated at 2022-06-11 21:35:58.489187
# Unit test for method parse of class Section
def test_Section_parse():
    text = "This is a description\nThis is another description\n"
    x = Section("title", "key").parse(text)
    assert next(x).description == text


# Generated at 2022-06-11 21:36:09.177594
# Unit test for method parse of class Section
def test_Section_parse():
    text = '''
    Raises

        ValueError
            A description of what might raise ValueError
        Exception

            Another description
    '''
    correct = [DocstringRaises([
        'raises',
        'ValueError'
    ],description='A description of what might raise ValueError'),
    DocstringRaises([
        'raises',
        'Exception'
    ],description='Another description')]

    sec = RaisesSection("Raises","raises")
    result = list(sec.parse(text))

    assert(result[0].args == correct[0].args)
    assert(result[1].args == correct[1].args)
    assert(result[0].description == correct[0].description)
    assert(result[1].description == correct[1].description)


# Generated at 2022-06-11 21:36:14.617010
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_string = "key1\n\tvalue 1\nkey2 : type\n\tvalue 2\n"
    result = list(_KVSection("", "").parse(test_string))
    assert len(result) == 2
    assert result[0].args == ["", "key1"]
    assert result[1].args == ["", "key2"]