

# Generated at 2022-06-11 21:26:36.841917
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    # clean docstring
    text = inspect.cleandoc(
        """
    Does the thing.

    Parameters
    ----------
    x : int
        x is the first variable

    y : float, optional
        y is the second variable.

    z : str, optional
        z is the third variable (default is 'foo')

    foo : object, optional
        foo is the fourth variable.

    Raises
    ------
    IndexError
        If n is not in the range [0..size(a)-1].

    Notes
    -----
    This description can go on for multiple lines.
    """
    )

    # parse docstring
    doc = parser.parse(text)
    print(doc.__dict__)
    print(doc.meta)


# Generated at 2022-06-11 21:26:46.937164
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    f=open('test_numpydoc.txt','r')
    text=f.read()
    ret=NumpydocParser().parse(text)
    assert ret.short_description == "Calculates the value of P(A and B)"""
    assert ret.long_description == "Calculates the probability of events A and B occuring, given that P(A) = p and P(B) = q. The formula is given by the multiplication rule: P(A and B) = P(A) * P(B)."""
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert isinstance(ret.meta[0],DocstringReturns)
    assert ret.meta[0].args == ["returns"]

# Generated at 2022-06-11 21:26:57.401638
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Parse docstring for empty string input
    assert list(DeprecationSection("deprecated", "deprecation").parse("")) == []

    # Parse docstring for single-line input
    assert list(DeprecationSection("deprecated", "deprecation").parse("test version")) == [DocstringDeprecated(args=['deprecation'], description=None, version='test version')]

    # Parse docstring for multi-line input
    assert list(DeprecationSection("deprecated", "deprecation").parse("test version\n    test description")) == [DocstringDeprecated(args=['deprecation'], description='test description', version='test version')]

# Generated at 2022-06-11 21:27:09.166231
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = DeprecationSection("Deprecated Warning","deprecated_warning")
    assert d.key == "deprecated_warning"
    assert d.title == "Deprecated Warning"
    assert d.title_pattern == r"^\.\.\s*(Deprecated Warning)\s*::"
    assert d.parse("0.1\ntest") == [DocstringDeprecated(['deprecated_warning'], 'test', "0.1")]
    assert d.parse("0.1\ndescription starts in one line\nand continues in the next") == [DocstringDeprecated(['deprecated_warning'], 'description starts in one line\nand continues in the next', '0.1')]

# Generated at 2022-06-11 21:27:21.178590
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
    param1
        this is the first param
    param2
        this is the second param
    '''

# Generated at 2022-06-11 21:27:28.994920
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert len(DeprecationSection('deprecation', 'params').parse('.. deprecated:: 0.1.0\n\n    This function is deprecated.'))==1
    assert len(DeprecationSection('deprecation', 'params').parse('.. deprecated:: 0.1.0\n\n    This function is deprecated.\n    '))==1
    assert DeprecationSection('deprecation', 'params').parse('.. deprecated:: 0.1.0\n\n    This function is deprecated.\n    ')[0].description=='This function is deprecated.'


# Generated at 2022-06-11 21:27:36.124133
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """.. deprecated:: 1.2.3
        This is a warning message."""
    section = DeprecationSection("deprecated", "deprecation")
    result = list(section.parse(text))
    expect= [
        Deprecated(description="This is a warning message.", version="1.2.3")
        ]
    assert result == expect

# Generated at 2022-06-11 21:27:42.611176
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    docstring = """.. deprecated:: 0.1.0
        Use :func:`parse` instead"""

    docstringParsed = NumpydocParser().parse(docstring)

    assert len(docstringParsed.meta) == 1
    assert docstringParsed.meta[0].args == ['deprecation']
    assert docstringParsed.meta[0].description == 'Use :func:`parse` instead'
    assert docstringParsed.meta[0].version == '0.1.0'


# Generated at 2022-06-11 21:27:52.536790
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    This is the unit test for method parse of class DeprecationSection
    """
    numpyParser = NumpydocParser()
    numpyParser.add_section(DeprecationSection("Deprecated", "deprecated"))
    docstring = numpyParser.parse(""".. deprecated:: 1.1.0
    A description of deprecated stuff
    A description of deprecated stuff
    """)
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args[0] == "deprecation"
    assert docstring.meta[0].description == "A description of deprecated stuff\nA description of deprecated stuff"
    assert docstring.meta[0].version == "1.1.0"


# Generated at 2022-06-11 21:27:59.108615
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "Deprecated since version 0.0.0 in favor of something else\n"
    text = text + "because this thing does not do anything."
    result = DeprecationSection("deprecated", "deprecation").parse(text)
    assert result.args[0] == "deprecation"
    assert result.description == "because this thing does not do anything."
    assert result.version == "0.0.0"


# Generated at 2022-06-11 21:28:11.238778
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    '''Unit test for NumpydocParser.parse(text)'''
    import pdb; pdb.set_trace()

# Generated at 2022-06-11 21:28:21.946020
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
        Use this function to find the number of spaces
        Defines the maximum number of spaces
        :param number: the number of spaces
        :param number_of_spaces: the number of spaces
        '''

# Generated at 2022-06-11 21:28:34.129583
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:42.344419
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """
    This is a really really really really really really long description.
    And it continues here.

    Parameters
    ----------
    x : int
        The x value.
    y : int
        The y value.

    Returns
    -------
    None

    Raises
    ------
    None

    """
    ret = NumpydocParser().parse(doc)
    assert ret.short_description == "This is a really really really really really really long description. And it continues here."
    assert ret.blank_after_short_description
    assert ret.long_description == "None"
    assert ret.blank_after_long_description

# Generated at 2022-06-11 21:28:49.820363
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("\n-----------Start of testing method parse in NumpydocParser-----------")
    # Test input
    input_text = inspect.cleandoc("""
    Does something

    Parameters
    ----------
    param1
        A description of param1
    param2 : type, optional
        A description of param2

    Returns
    -------
    str
        A description of the return value.
    """)

    # Expected output

# Generated at 2022-06-11 21:29:00.050987
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:10.238384
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    np = NumpydocParser()

# Generated at 2022-06-11 21:29:17.805438
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This docstring conforms to the numpy standard. It contains a parameter,
    a return, and a raise statement, as well as an example.
    
    Parameters
    ----------
    arg1 : int
        A parameter, with a description on a new line.
    arg2 : bool, optional
        A optional parameter with a description on a new line.
    
    Raises
    ------
    KeyError
        If a key is not found.
    
    Returns
    -------
    something
        Return a value.
    
    Examples
    --------
    
    >>> print('Hello World!')
    Hello World!
    
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)

# Generated at 2022-06-11 21:29:29.453428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "This is a short summary.\n\nThis is a long summary.\n\n\n"
    text += "Parameters\n----------\n"
    text += "arg_name\n    arg_description\n"
    text += "arg_2 : type, optional\n    descriptions can also span...\n"
    text += "    ... multiple lines\n"
    text += "Raises\n------\n"
    text += "ValueError\n    A description of what might raise ValueError\n"
    text += "Warns\n-----\n"
    text += "RuntimeWarning\n    A description of what might raise RuntimeWarning\n"
    text += "Returns\n-------\n"
    text += "return_name : type\n    A description of this returned value\n"

# Generated at 2022-06-11 21:29:39.734661
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    first line
    second line
            first line of a paragraph
            second line of a paragraph
        title1
            value1
            value2
            value3
        title2
            value4
            value5
    """
    docstring = NumpydocParser.NumpydocParser().parse(text)
    assert (docstring.meta == [DocstringMeta(args=['title1'],description='value1'),DocstringMeta(args=['title1'],description='value2'),DocstringMeta(args=['title1'],description='value3'),DocstringMeta(args=['title2'],description='value4'),DocstringMeta(args=['title2'],description='value5')])
    assert (docstring.short_description == 'first line')

# Generated at 2022-06-11 21:29:54.304120
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
 
    # parse(self, text: str) -> Docstring:

# Generated at 2022-06-11 21:30:05.061415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Parameters
    ----------
    arg_name : type, optional
        stuff

    arg_2
        stuff

    Raises
    -------
    ValueError

        stuff

    '''

    text_cleaned = '''
Parameters
----------
arg_name : type, optional
    stuff

arg_2
    stuff

Raises
-------
ValueError

    stuff

'''

    parser = NumpydocParser()

    result = parser.parse(text).show_as_dict()

# Generated at 2022-06-11 21:30:16.483547
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text="""
    This is the docstring's long description.

    Parameters
    ----------
    arg_name
        arg_description
    
    arg_2 : type, optional (default is "default_value")
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """


# Generated at 2022-06-11 21:30:26.247727
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string = """
    The ``NumpydocParser`` class parses numpy docstrings into their components.

    Numpy docstrings are parsed into their components
    (short description, blank lines after short description,
    long description, blank lines after the long description,
    and a dictionary of meta components).
    See: https://numpydoc.readthedocs.io/en/latest/format.html
    for an overview of numpy docstring format.

    Parameters
    ----------
    section_titles: list of str
        A list of numpy docstring section titles to parse.
        Default: ['parameters', 'return', 'raises', 'other parameters']
    """
    result = parse(doc_string)

    assert 'The ``NumpydocParser`` class parses numpy docstrings into their components.' == result.short

# Generated at 2022-06-11 21:30:35.436458
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
        Short description over
            multiple
           lines.

        Long description over
           multiple
          lines.

        Parameters
        ----------
        arg1 : int
            Description for arg1.
        arg2 : str, optional
            Description for arg2 defaults to 'default'.

        Raises
        ------
        ValueError
            Description of what raises
            ValueError.
        KeyError
            Description of what raises
            KeyError.

        Returns
        -------
        return1
            Description of return1.
        return2 : int
            Description of return2.
    '''

    parser = NumpydocParser()
    docstring = parser.parse(text)

    print("Short description over multiple lines.")
    for ele in docstring.short_description:
        print(ele)

    print("Long description over multiple lines.")


# Generated at 2022-06-11 21:30:45.047720
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:51.366577
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # parse the docstring using the NumpydocParser.parse() function
    parser = NumpydocParser()
    try:
        # parse the docstring
        parsed_docstring = parser.parse(test_docstring)
    except:
        print("FAILED: parse_numpydoc.NumpydocParser.parse()")


# Generated at 2022-06-11 21:30:55.831431
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse('''
    """Reads in the input data and does ll the preprocessing necessary
    """
    ''')
    assert docstring.short_description == 'Reads in the input data and does ll the preprocessing necessary'


# Generated at 2022-06-11 21:31:06.318018
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:18.422683
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test method parse of NumpydocParser class
    """
    text = """
    A short summary line
    A longer description that can span several lines(but less than 72 characters)

    Parameters
    ----------
    arg_1 : type
        Description of the arg_1 can be over many lines
        each line should begin with at least 4 spaces
        and the last line should have no additional spaces
    arg_2 : (type1, type2)
        Description of the arg_2
    arg_3 : {type1, type2}
        Description of the arg_3
    arg_4 : {'key1': type1, 'key2': type2}
        Description of the arg_4

    Returns
    -------
    type
        Description of the return value
    """
    parser = NumpydocParser()

# Generated at 2022-06-11 21:31:31.364835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    npp = NumpydocParser()
    text = """
        Short description.

        Long description.

        Parameters
        ----------
        a : int
            A description of parameter a.
        b : str
            A description of parameter b.

        Returns
        -------
        str
            A description of the return value.

        Raises
        ------
        ValueError
            Raised if something.

        Warns
        -----
        UserWarning
            Warns if something.

        Example
        -------
        >>> c = a + b
        >>> c
        >>> c.foo()
            """
    assert isinstance(npp.parse(text), Docstring)


# Generated at 2022-06-11 21:31:43.571243
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NUMPY = """\
    One line summary.

    Separate line, in this case the description of what the function does.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    Other Parameters
    ----------------
    arg3 : float
        The third parameter.
    arg4 : list of int
        The fourth parameter.

    """


# Generated at 2022-06-11 21:31:55.104796
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    actual = NumpydocParser().parse("""
        Short description.

        Long description.

        Parameters
        ----------
        model : nn.Module, optional (default=None)
            Parameters will be learned.
        """)

    expected = Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param", "model"],
                description="Parameters will be learned.",
                arg_name="model",
                type_name="nn.Module",
                is_optional=True,
                default=None,
            )
        ],
    )
    assert actual.short_description == expected.short_description
    assert actual.blank_after_short_

# Generated at 2022-06-11 21:32:06.617744
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Testing NumpydocParser.parse"""
    parser = NumpydocParser()
    docstr = """This is a short description.

    And this is a long description.
    It spans many, many lines.

    And now we have a new paragraph.

    Parameters
    ----------
    param : type
        description of param param

    Returns
    -------
    name : type
        description of return value

    """
    parsed = parser.parse(docstr)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "And this is a long description.\n" + \
                                      "It spans many, many lines.\n\n" + \
                                      "And now we have a new paragraph."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_

# Generated at 2022-06-11 21:32:15.602193
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # with the default sections
    numpydoc_simple_1 = """\
        Here is a simple example of numpy docstring

        Parameters
        ----------
        a : type
            arg1 description

        Returns
        -------
        description

        Raises
        ------
        ValueError
            description of ValueError
    """
    numpydoc_simple_2 = inspect.cleandoc(numpydoc_simple_1)
    numpy_docstring = NumpydocParser().parse(numpydoc_simple_1)
    assert numpy_docstring.short_description == "Here is a simple example of numpy docstring"
    assert numpy_docstring.long_description == None
    numpy_docstring = NumpydocParser().parse(numpydoc_simple_2)
    assert numpy_doc

# Generated at 2022-06-11 21:32:23.774086
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("") == Docstring()

    method = "test_NumpydocParser_parse"

    parser.add_section(Section("test", "test"))
    assert parser.parse("test\n---\n") == Docstring(meta=[DocstringMeta(["test"])])
    assert parser.parse("test\n---\nkey\n    value\n") == Docstring(
        meta=[DocstringMeta(["test"], description="key\n    value")]
    )

    parser.add_section(Section("test2", "test2"))
    assert parser.parse("test\n---\ntest2\n---\n") == Docstring(
        meta=[DocstringMeta(["test"]), DocstringMeta(["test2"])]
    )

# Generated at 2022-06-11 21:32:34.121362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # https://numpydoc.readthedocs.io/en/latest/format.html
    parser = NumpydocParser()
    docstring = """golden function

This function is beautiful.

Parameters
----------
arg : str
    An argument without a default.
kwarg : bool=True
    A keyword argument with a default value.

Returns
-------
None
"""
    ret = parser.parse(docstring)
    assert ret.short_description == "golden function"
    assert (
        ret.long_description
        == "This function is beautiful.\n\nParameters\n----------\narg : str\n    An argument without a default.\nkwarg : bool=True\n    A keyword argument with a default value.\n\nReturns\n-------\nNone"
    )

# Generated at 2022-06-11 21:32:42.204344
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text ="""Bar charts are useful for displaying relationships in the data; Scatter charts for displaying the spread in the data and histograms for displaying the distribution of the data.
    Parameters
    ----------
    arg_1 : int
        Description of arg_1
    arg_2 : str
        Description of arg_2

    Returns
    -------
    None
    
    Raises
    ------
    Exception
        If `arg_1` and `arg_2` are equal
    """

    doc = NumpydocParser().parse(text)
    print(doc.short_description)
    print(doc.long_description)
    for m in doc.meta:
        print(m)

if __name__ == '__main__':
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:32:51.228835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = NumpydocParser().parse("""
test : int
    a test

another test : str, optional
    another test
        """)
    assert docstr.short_description == 'test'
    assert docstr.long_description == None
    assert docstr.blank_after_long_description == False
    assert docstr.blank_after_short_description == True
    assert len(docstr.meta) == 2
    assert len(docstr.meta[0].args) == 2
    assert len(docstr.meta[1].args) == 2
    assert len(docstr.meta[0].description.split('\n')) == 1
    assert len(docstr.meta[1].description.split('\n')) == 2
    assert docstr.meta[0].description.strip() == 'a test'


# Generated at 2022-06-11 21:32:58.911969
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import unittest
    class TestCases(unittest.TestCase):
        def test_1(self):
            ds = NumpydocParser.parse(self, " test ")
            self.assertIsNone(ds.short_description)
            self.assertIsNone(ds.long_description)

    # I'm in a class, so I can't use unittest.main()
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestCases)
    runner = unittest.TextTestRunner()
    runner.run(suite)



# Generated at 2022-06-11 21:33:03.010191
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .test_docstring import test_parse_numpydoc
    test_parse_numpydoc()

# Generated at 2022-06-11 21:33:04.186843
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    s = YieldsSection("Yield","yield")
    assert s.is_generator

# Generated at 2022-06-11 21:33:10.943813
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = """
    this is a method
    description
    """
    b = """
    this is a method
    description
    """
    c = """
    this is a method
    description
    """
    d = """
    this is a method
    description
    """
    e = """
    this is a method
    description
    """
    f = """
    this is a method
    description
    """

if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:33:15.983693
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    a: type
        value
    b: type
        value 2
    """
    section = ParamSection("Params", "param")
    expected = [DocstringParam(args=["param", "a"], type_name="type", description="value"),
        DocstringParam(args=["param", "b"], type_name="type", description="value 2")]
    assert section.parse(text) == expected


# Generated at 2022-06-11 21:33:23.673495
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    pass_section = ParamSection("Pass", "pass")
    parser.add_section(pass_section)
    assert parser.sections.get("Pass") == pass_section
    assert parser.sections.get("See Also")
    assert parser.sections.get("Related")
    assert not parser.sections.get("TEST")
    parser.add_section(Section("Example", "examples"))
    assert parser.sections.get("Example")


# Generated at 2022-06-11 21:33:26.003949
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"


# Generated at 2022-06-11 21:33:27.276199
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection
    assert isinstance(y, Section)

# Generated at 2022-06-11 21:33:34.923530
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Define some strings that contain a useful example for the coder
    key = "test"
    value = "Test description\nThis can span multiple lines."
    param_name = "test_name"
    param_type_name = "param_type_name"
    param_optional = "param_optional"
    param_default = "param_default"

    # Instantiate a _KVSection
    kv_section = _KVSection(title = key, key = value)

    # Call parse function
    kv_section._parse_item(param_name, param_type_name)

# Generated at 2022-06-11 21:33:45.745345
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    This docstring is intended to be a summary of a function or method.
    It should be one or two lines long, and written in imperative style.

    :param a: First parameter
        Parameter ``a`` has a type.
    
    :param b: Second parameter
        Parameter ``b`` has *no* type.
    
    :param c: Third parameter with a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really
    long description

    :return: Returns nothing
    """
    docstring = parser.parse(text)

# Generated at 2022-06-11 21:33:52.286981
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_text = "ValueError \n error description"
    section = RaisesSection("Raise", "raises")
    test_docstring = section.parse(test_text)
    expected_docstring = [DocstringRaises(args=["raises", "ValueError"], description=_clean_str("error description"), type_name="ValueError")]

    assert(expected_docstring == list(test_docstring))


# Generated at 2022-06-11 21:34:00.621762
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    expected = {'args': ['deprecation'], 'description': 'Some description'}
    section = DeprecationSection(title='deprecation', key='deprecation')
    text = '0.24.0\nSome description'
    actual = section.parse(text).__next__().__dict__
    assert actual == expected, 'Not the same'

# Generated at 2022-06-11 21:34:02.691993
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_parameter = ParamSection("Parameters", "param")
    return section_parameter


# Generated at 2022-06-11 21:34:12.898480
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #Example description
    text = '''Example of Sphinx and Numpydoc
    .. section:: section_1
    .. code-block:: python
        code 1
        code 2
    .. section:: section_2
    .. section:: section_3
    .. code-block:: python
        code 3
    .. code-block:: python
        code 4
    .. section:: section_4
    .. code-block:: python
        code 5
    '''

    splited_text = text.splitlines()
    parsed = NumpydocParser().parse(text)
    all_sections = parsed.meta
    number_of_sections = len(all_sections)
    #Starting count of code-blocks at the end of the text
    number_of_codeblocks_at_end_of_text = 2
    assert number_of_sections == 3

# Generated at 2022-06-11 21:34:20.235744
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert parser.titles_re.search('.. deprecation:: 0.3.0')

    # This is not a valid Numpydoc section
    parser.add_section(Section(title='Key', key='key'))
    assert parser.titles_re.search('.. key::')

    # An section with empty title will break the parser
    with pytest.raises(ValueError):
        parser.add_section(Section(title='', key='key'))

# Generated at 2022-06-11 21:34:27.946838
# Unit test for function parse
def test_parse():
    text = r"""
    Docstring of the test function

    Example:
        >>> test('a')
        True
        >>> test('b')
        False

    Parameters
    ----------
    text : str
        The text to be tested
    """
    doc = parse(text)
    print(doc.short_description)
    print(doc.long_description)
    for meta in doc.meta:
        if isinstance(meta, DocstringMeta):
            print(meta.args)
            print(meta.description)


# Generated at 2022-06-11 21:34:35.954028
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # setup
    with open('./src/4_numpydocParser/test_input.rst', 'r') as f:
        input = f.read()
    numpydocParser = NumpydocParser()
    # test
    parser_output = numpydocParser.parse(input)
    # check
    assert parser_output.short_description == 'Lorem ipsum'
    assert parser_output.blank_after_short_description == True

# Generated at 2022-06-11 21:34:46.602517
# Unit test for function parse
def test_parse():
    text = """
    The short description.

    The long description.

    It can span multiple paragraphs.

    Parameters
    ----------
    param_1 : int
       A description of this parameter.

       With additional details.

    param_2, optional : float
       Another parameter.

    Returns
    -------
    str
       A string return value.
    """
    doc = parse(text)
    assert doc.short_description == "The short description."
    assert doc.long_description == "The long description.\n\nIt can span multiple paragraphs."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    param_1 = doc.meta[0]
    assert param_1.args == ["param", "param_1"]
    assert param

# Generated at 2022-06-11 21:34:48.562815
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Parameters", "param")
    assert _clean_str(inspect.cleandoc("test")) == "test"


# Generated at 2022-06-11 21:34:55.866462
# Unit test for constructor of class _KVSection
def test__KVSection():
    expected_key = "other_param"
    expected_value = """
                    A description of this value
                    which spans multiple lines
                    """
    key = "other_param"
    value = """
        A description of this value
        which spans multiple lines
        """
    kv_section = _KVSection(key, value)
    assert kv_section.title == expected_key
    assert kv_section.key == expected_key
    assert kv_section.value == expected_value


# Generated at 2022-06-11 21:34:58.425994
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    """
    >>> print(_SphinxSection("Object","object").title_pattern)
    \.\.\s*(Object)\s*::
    """

# Generated at 2022-06-11 21:35:16.389119
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:20.180383
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = DeprecationSection("Deprecation Warning", "deprecated")
    dep_text = inspect.cleandoc("""
            Deprecated since version 1.2.3: Use foo() instead.

            This is a deprecation warning!
            """)
    assert len(list(d.parse(dep_text))) == 1



# Generated at 2022-06-11 21:35:26.379766
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Test case
    test_NumpydocParser = NumpydocParser()
    test_NumpydocParser.add_section(Section("Test", "test"))

    # Expected result
    expected_result = {
        "Test": Section("Test", "test")
    }

    # Assertion
    assert test_NumpydocParser.sections == expected_result



# Generated at 2022-06-11 21:35:29.684139
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section_test = Section("Monk", "marteau")
    test_parser = NumpydocParser()
    assert section_test not in test_parser.sections.values()
    test_parser.add_section(section_test)
    assert section_test in test_parser.sections.values()

# Generated at 2022-06-11 21:35:38.991711
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    import unittest
    from unittest.mock import patch
    from .common import DocstringDeprecated

    class DeprecationSectionTestCase(unittest.TestCase):
        def test_parse_with_version(self):
            with patch('numpydoc.numpydoc.DocstringDeprecated') as mock:
                inst = DeprecationSection('deprecated', 'deprecation')
                inst.parse('0.1\ndescription\n')
            mock.assert_called_once_with(args=['deprecation'], description='description', version='0.1')

        def test_parse_without_version(self):
            with patch('numpydoc.numpydoc.DocstringDeprecated') as mock:
                inst = DeprecationSection('deprecated', 'deprecation')
                inst.parse

# Generated at 2022-06-11 21:35:47.102884
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    @property
    def title_pattern(self):
        """Return a regular expression pattern matching this section's header.
    
        This pattern will match this instance's ``title`` attribute in
        an anonymous group.
        """
        return r'^.\.\s*({})\s*::'.format(self.title)
    a = _SphinxSection('a', 'b')
    assert a.title_pattern == r'^.\.\s*(a)\s*::'
    assert a.title == 'a'
    assert a.key == 'b'


# Generated at 2022-06-11 21:35:51.677399
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    def test_parse(text: str) -> str:
        return text[9:]

    my_parser = NumpydocParser()
    my_parser.add_section(Section("Test Section", "test", test_parse))

    test_docstring = """
test: Something
test section
something else.
    """

    expected_meta = [
        DocstringMeta(["test"], "test section\nsomething else."),
    ]

    assert my_parser.parse(test_docstring) == Docstring(
        short_description="Something",
        meta=expected_meta
    )

# Generated at 2022-06-11 21:36:01.470867
# Unit test for function parse
def test_parse():
    def fn():
        """This is a multiline test function.
        Parameters
        ----------
        value :  int
            The value.

        Other Parameters
        ----------------
        type_: object
            The other value.

        Returns
        -------
        return_name: int
            The return value.
        """
        pass
    res = parse(inspect.getdoc(fn))
    assert res.meta == [
        DocstringMeta(args=["param", "value"], arg_name="value", type_name="int"),
        DocstringMeta(args=["other_param", "type_"], arg_name="type_"),
        DocstringMeta(args=["returns"], return_name="return_name", type_name="int"),
    ]


# Generated at 2022-06-11 21:36:11.560305
# Unit test for method parse of class _KVSection

# Generated at 2022-06-11 21:36:16.956056
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert isinstance(a.title, str), "ReturnsSection.title must be string"
    assert isinstance(a.key, str), "ReturnsSection.key must be string"
    assert isinstance(a.is_generator, bool), "ReturnsSection.is_generator must be boolean"
    assert isinstance(a.title_pattern, str), "ReturnsSection.title_pattern must be string"
