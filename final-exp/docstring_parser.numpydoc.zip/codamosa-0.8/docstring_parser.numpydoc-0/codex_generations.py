

# Generated at 2022-06-11 21:26:45.428242
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = '''
    Short description.

    Longer description.

    Parameters
    ----------
    arg_name : type [optional]
        arg_description
    arg_2
        arg_2_description

    Raises
    -------
    ValueError
        A description of what might raise ValueError

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Other Parameters
    ----------------
    key : type [optional]
        description
    '''

    ret = parse(docstring)
    assert ret.short_description == 'Short description.'
    assert ret.long_description == 'Longer description.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False

    # Check meta

# Generated at 2022-06-11 21:26:55.873554
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test = NumpydocParser()
    
    # Test only descriptions
    text = "This is a test. This is only a test."
    expected = Docstring(short_description="This is a test.",
                         long_description="This is only a test.",
                         blank_after_short_description=True,
                         blank_after_long_description=True)
    assert test.parse(text) == expected

    # Test only empty descriptions
    text = ""
    expected = Docstring()
    assert test.parse(text) == expected

    # Test only meta
    text = """Parameters
------------
meta1 : str
    This has a description
meta2 : int
    This is another meta item
    that spans multiple lines.
Warnings
--------
This is a warning
This is another warning
"""

# Generated at 2022-06-11 21:27:08.212019
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:16.343981
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Args:
        arg_1 (str): arg_1 description
            arg_description can span more than one line
        arg_2 (str, optional): arg_2 description
            default is abcd
        arg_3 : int, optional
            default is 1234
    """
    docstring = parse(text)
    assert len(docstring.meta) == 3
    assert docstring.meta[2].default == "1234"

# Generated at 2022-06-11 21:27:22.097486
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def parse_test(text: str, result: str) -> None:
        assert parse(text) == eval(result)

    parse_test('', 'Docstring()')
    parse_test('A short description', 'Docstring(short_description="A short description")')
    parse_test('A short description\n\nA long description', 'Docstring(blank_after_short_description=True, blank_after_long_description=True, long_description="A long description", short_description="A short description")')


# Generated at 2022-06-11 21:27:22.986580
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-11 21:27:31.333336
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    Parse the numpy-style docstring into its components.

    Returns
    -------
    parsed docstring
        The parsed docstring.
    """
    expected = Docstring(
        short_description="Parse the numpy-style docstring into its components.",
        long_description="Returns\n-------\nparsed docstring\n    The parsed docstring.",
        meta=[DocstringReturns(
            args=['returns'],
            description='parsed docstring',
            type_name=None,
            is_generator=False,
            return_name=None,
        )],
    )
    actual = NumpydocParser().parse(text)
    assert expected == actual



# Generated at 2022-06-11 21:27:42.261977
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # This first test uses the default numpydoc parser (no keyword arguments)
    # and tests the parsing of the docstring of method __init__ of class 
    # NMEA.NMEA
    def test_default_parser_parse_init_method_docstring():
        import geotweet.NMEA.NMEA
        import geotweet.NMEA.numpy_docstring_parser

        nmea_obj = geotweet.NMEA.NMEA.NMEA()
        numpydoc_parser = geotweet.NMEA.numpy_docstring_parser.NumpydocParser()
        docstring = numpydoc_parser.parse(nmea_obj.__init__.__doc__)

        assert docstring.short_description == "Create an NMEA object."


# Generated at 2022-06-11 21:27:52.767219
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def fn():
        """A one-line summary.

        A longer description of the function with some examples,
        (note the blank line before the examples).

        Examples
        --------
        Examples should have the form:

        >>> a = "an example"
        >>> print(a)

        """
        pass

    src = inspect.getsource(fn)
    ds = NumpydocParser().parse(src)[0]
    assert ds.short_description == "A one-line summary."
    assert ds.long_description == (
        "A longer description of the function with some examples,\n"
        "(note the blank line before the examples)."
    )

# Generated at 2022-06-11 21:28:03.582879
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:11.260118
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.parse("")
    parser.add_section(Section("A", "a"))
    parser.parse("A\n----\nHello world\n")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 21:28:21.947210
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import common
    my_parser = NumpydocParser()

# Generated at 2022-06-11 21:28:34.131035
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:42.343946
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    
    # test for the method parse of class NumpydocParser
    # a string with contains no docstring is parsed
    assert NumpydocParser().parse(None).short_description == None
    
    # a string with no docstring is parsed
    assert NumpydocParser().parse("").short_description == None
    
    # a short docstring is parsed
    assert NumpydocParser().parse( "A short function docstring")\
        .short_description == "A short function docstring"
    
    # a long docstring is parsed
    assert NumpydocParser().parse( "A short function docstring\n" +
        "A much longer description")\
        .long_description == "A much longer description"
    
    # a docstring containing a paramater is parsed

# Generated at 2022-06-11 21:28:49.846583
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Simple one-liner docstring
    assert NumpydocParser().parse("something") == Docstring(
        short_description="something"
    )

    # One-liner with only whitespace
    assert NumpydocParser().parse("         ") == Docstring(
        short_description=None
    )

    # Docstring with only whitespace
    assert NumpydocParser().parse("   \n         \n  \n     ") == Docstring(
        short_description=None
    )

    # Multiline docstring

# Generated at 2022-06-11 21:28:51.268635
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = Docstring()
    test_doc = NumpydocParser().parse(doc.__doc__)
    assert test_doc.short_description == "Holds various metadata."

# Generated at 2022-06-11 21:29:00.956470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    text = ".. deprecated:: 2.0\n    Use :meth:`~.XlsxWriter.worksheet.Worksheet.write_rich_string`"
    docstring = numpydoc_parser.parse(text)

    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 1

    assert docstring.meta[0].args == ["deprecation"]
    assert docstring.meta[0].description == "Use :meth:`~.XlsxWriter.worksheet.Worksheet.write_rich_string`"

# Generated at 2022-06-11 21:29:11.041894
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test case 1
    fail_text = """\
    The `~.IntervalIndex.get_loc` method is responsible for converting the key
    into a location suitable for indexing.

    One example of where this is useful is if you need to slice the
    ``IntervalIndex`` with a scalar or array-like object.

    Parameters
    ----------
    key :
        The value(s) you wish to index with. This may not be contained in the
        ``IntervalIndex`` if `method` is not 'pad' or 'backfill'.

    Returns
    -------
    loc :
        The location of the key in the ``IntervalIndex``.
    """
    test_case_1 = NumpydocParser().parse(fail_text)

# Generated at 2022-06-11 21:29:16.452553
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """ Testing numpydoc parser
    """
    text = """\
        One line summary.

        Long description.

        Parameters
        ----------
        a : int
            First param.
        b : str
            Second param.

        Returns
        -------
        str
            Return value.
    """
    parsed_docstring = parse(text)
    assert parsed_docstring.short_description == "One line summary."
    assert len(parsed_docstring.long_description) == 16
    assert len(parsed_docstring.meta) == 2



# Generated at 2022-06-11 21:29:28.605686
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:29:47.220299
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Example 1: Simple functions
    assert NumpydocParser().parse('"""\nThis is a doc-string.\n    """') == \
         Docstring(short_description='This is a doc-string',
                   blank_after_short_description=True,
                   blank_after_long_description=False,
                   long_description=None,
                   meta=[])
    assert NumpydocParser().parse('"""\nA doc-string\n\n    More lines.\n    """') == \
         Docstring(short_description='A doc-string',
                   blank_after_short_description=True,
                   blank_after_long_description=False,
                   long_description='More lines.',
                   meta=[])

# Generated at 2022-06-11 21:29:55.760563
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_example = """
    really short description
    longer description that is indented and spans multiple lines
        with a code block
    Parameters
    ----------
    first_param: int
        description

    second_param : int, optional, default 1
        description

    third_param
        default value is 25
        description spans multiple lines
        and it is indented
        so that it looks neat

    fourth_param : str
        with optional (default: "default_value")
    """

    parser = NumpydocParser()
    doc_parsed = parser.parse(doc_example)

    def _extract_description(description: T.Optional[str]) -> str:
        return description or ""

    short_description = _extract_description(doc_parsed.short_description)
    long_description = _extract_description

# Generated at 2022-06-11 21:30:06.910057
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = NumpydocParser().parse('''
        Convert a PIL Image or numpy.ndarray to a Trimesh object.

        Parameters
        ----------
        data : (PIL.Image, numpy.ndarray)
        plugin : str, optional
          Which rendering plugin to use.
          Defaults to 'pyglet'.
        **kwargs : dict
          Passed to plugin specific backend.
          See the plugin documentation for details.

        Returns
        ----------
        mesh : Trimesh object
    ''')
    assert doc.short_description == "Convert a PIL Image or numpy.ndarray to a Trimesh object."

# Generated at 2022-06-11 21:30:17.645364
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_parser = NumpydocParser()

# Generated at 2022-06-11 21:30:27.049474
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    desc = NumpydocParser().parse("""
        This is a short description.

        This is a long description.
        """)

    assert desc.short_description == 'This is a short description.'
    assert desc.long_description == 'This is a long description.'
    assert desc.blank_after_short_description == False
    assert desc.blank_after_long_description == True

    desc = NumpydocParser().parse("""
        This is a short description.

        This is a long description.


        Another one.
        """)

    assert desc.short_description == 'This is a short description.'
    assert desc.long_description == 'This is a long description.\n\n    Another one.'
    assert desc.blank_after_short_description == False
    assert desc.blank_after_long_description == True

# Generated at 2022-06-11 21:30:35.552704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test method parse of class NumpydocParser
    
    The testcase is based on data from _pytest/python_api.py in the Pytest source.
    """
    test_string = """

This is a docstring.

It spans multiple lines. 

Lines are split with '\n'.
   
    Parameters
    ----------
    x
        First parameter
    y
        Second parameter
    z
        Third parameter
    """
    result = NumpydocParser().parse(test_string)
    assert result.short_description == "This is a docstring."
    assert result.long_description == "It spans multiple lines.\n\nLines are split with '\n'."


# Generated at 2022-06-11 21:30:44.430772
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class Cls:
        """This is a short description.

        This is a long description.

        Parameters
        ----------
        arg
            A description of arg.
        arg_type : type
            A description of arg_type.
        arg_default : type, optional
            A description of arg_default.

        Raises
        ------
        ValueError
            A description of what might raise ValueError.
        RuntimeError
            A description of what might raise RuntimeError.

        Returns
        -------
        return_type
            A description of return_type.
        """


# Generated at 2022-06-11 21:30:56.541140
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    global parser
    parser = NumpydocParser()
    text = """
    Parses the numpy-style docstring into its components.

    Parameters
    ----------
    text : str
        The docstring text to parse.

    Returns
    -------
    Docstring
        Parsed structure.
    """
    result = parser.parse(text)

    #test expected values of docstring
    assert result.short_description == "Parses the numpy-style docstring into its components."
    assert result.long_description == None
    assert result.blank_after_long_description == True
    assert result.blank_after_short_description == True

    #test expected values of meta
    assert len(result.meta) == 2
    #test expected value of parameter
    assert result.meta[0].args == ['param', 'text']


# Generated at 2022-06-11 21:31:06.788842
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:18.588019
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Some description.

        Parameters
        ----------
        foo
            Some argument description.
            It can span multiple lines.
        bar : str, optional
            Another argument.

        Returns
        -------
        result : int
            result from function
        """
    ret = Docstring()
    ret.short_description = "Some description."
    ret.long_description = """
        Parameters
        ----------
        foo
            Some argument description.
            It can span multiple lines.
        bar : str, optional
            Another argument.

        Returns
        -------
        result : int
            result from function"""
    ret.blank_after_short_description = True
    ret.blank_after_long_description = True

# Generated at 2022-06-11 21:31:34.802601
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_docstring = """
    **Example Docstring**:

    **Example Docstring**:
    **Example Docstring**:

    **Example Docstring**:


    Parameters
    ----------
    a : integer
        The parameter `a`...

            It can span multiple lines

    b : str, optional
        The parameter `b`...

    Returns
    -------
    int

    Warns
    -----
    UserWarning
        Never actually raises a `UserWarning`

    """

    ds = NumpydocParser().parse(example_docstring)
    assert ds.short_description == "Example Docstring"

    assert ds.long_description == "Example Docstring\nExample Docstring\nExample Docstring\nExample Docstring"
    assert 'Parameter' in ds.meta_objects()

# Generated at 2022-06-11 21:31:46.065903
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Prepare a test docstring
    text = """
X
    X
Y
    Y
    Z

    Z
A
    B
        C
            D
    E
        F
            G
    H
        I
            J
K
    L
        M
            N
"""
    # Prepare expected results
    expected_results = Docstring()
    expected_results.short_description = "X"
    expected_results.blank_after_short_description = False
    expected_results.long_description = "X\n\nY\n    Y\n    Z\n\n    Z"
    expected_results.blank_after_long_description = True

# Generated at 2022-06-11 21:31:56.649547
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstr1 = """
        Short description.

        Long description.

        Parameters
        ----------
        param_1 : str
            Parameter 1 description
        param_2 : int
            Parameter 2 description

        Returns
        -------
        str
            Return value description

        Other Parameters
        ----------------
        param_3 : List[int]
            Parameter 3 description

        Examples
        --------
        >>> example_1()
        'example 1'
        >>> example_2()
        'example 2'
        >>> example_3()
        'example 3'
    """
    result = parser.parse(docstr1)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert len(result.meta) == 8
    assert result.meta

# Generated at 2022-06-11 21:32:07.761604
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : str
        Description of `arg1` (with type annotation).
    arg2
        Description of `arg2` (with no type annotation).
    arg3 : int, optional
        Description of `arg3` (with type annotation and an optional flag).

    Returns
    -------
    arg1
        Description of return value of the same name as an argument.
    arg2
        Description of `arg2`, which appears in the Returns section.
        This continues for more lines.
    arg3 : str
        The return type annotation is explicitly given as a string.
    """

# Generated at 2022-06-11 21:32:16.591064
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:24.244060
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = '''
    Parameters
    ----------
    kappa : type, optional
        default value
        default value
    lambda2 : type, optional
        default value
        default value
    '''
    result = parser.parse(doc)
    assert result.short_description == ''
    assert result.long_description == ''
    assert result.blank_after_long_description == False
    assert result.blank_after_short_description == False
    assert result.meta[0].key == 'param'
    assert result.meta[0].args == ['kappa']
    assert result.meta[0].description == 'default value default value'
    assert result.meta[0].arg_name == 'kappa'
    assert result.meta[0].type_name == 'type'
    assert result

# Generated at 2022-06-11 21:32:32.817443
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for method parse of class NumpydocParser"""

    parser = NumpydocParser()
    docstring = parser.parse(DOCSTRING)

    assert docstring.short_description == 'A short description'

# Generated at 2022-06-11 21:32:41.590582
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc(
    """
    This function does something.

    Parameters
    ----------
    a : int
        First parameter.
    b : float (optional)
        Second parameter.
    c : str
        Third parameter.

    Returns
    -------
    int
        The return value.

    Raises
    ------
    ValueError
        If something goes wrong.

    .. deprecated:: 0.1.0
        This function is deprecated.
    """
    )
    ret = NumpydocParser().parse(text)
    assert(ret.short_description == "This function does something.")
    assert(ret.blank_after_short_description)
    assert(ret.long_description == "No long description")
    assert(not ret.blank_after_long_description)

# Generated at 2022-06-11 21:32:47.457099
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of `arg1` (with type annotations).
        arg2 : str
            Description of `arg2` (with type annotations).
        *args
            Variable length argument list.
        **kwargs
            Arbitrary keyword arguments.

        Returns
        -------
        int
            Description of return value.
        """
    docstring = NumpydocParser().parse(text)
    assert docstring

# Generated at 2022-06-11 21:32:58.237132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    newline = '\n'
    expected = Docstring()
    expected.short_description = 'Log an object to the logger'
    expected.blank_after_short_description = True
    expected.blank_after_long_description = False

# Generated at 2022-06-11 21:33:10.247972
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:18.729398
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    NumpydocParser().parse("")
    NumpydocParser().parse("A sample docstring")
    NumpydocParser().parse("A sample docstring\n")
    NumpydocParser().parse("A sample docstring\nanother line")
    NumpydocParser().parse("A sample docstring\n another line")
    NumpydocParser().parse("A sample docstring\n another line\n")
    NumpydocParser().parse("A sample docstring\n\nanother line")
    NumpydocParser().parse("A sample docstring\n\nanother line\n")
    NumpydocParser().parse("A sample docstring\n\n another line\n")
    NumpydocParser().parse("A sample docstring\n\n another line\n\n")
    Numpydoc

# Generated at 2022-06-11 21:33:30.394146
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    test_parser

    Short description.

    Params
    ------
    x : int, optional
        Some description of x which spans
        multiple lines.

    y : float, optional
        Some description of y.

    Returns
    -------
    None.

    """
    docstring = NumpydocParser().parse(text)

# Generated at 2022-06-11 21:33:37.976995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  from os import getcwd
  from os.path import join
  from pathlib import Path
  from rpdk.core.plugin import load_plugin
  from rpdk.core.pluginmanager import parse_plugin_metadata
  from rpdk.core.project import PROJECT_BASE_DIR
  from rpdk.core.scaffold import init_scaffold
  from rpdk.core.scaffold.manager import SCAFFOLD_REPO_NAME
  from rpdk.core.service.resolver import resolve_service

  # Load One plugin metadata
  plugin_path = join(PROJECT_BASE_DIR, "rpdk", "jsonschema", "plugin")
  parsed_plugin = parse_plugin_metadata(plugin_path)

  # Load plugin using Pluginmanager

# Generated at 2022-06-11 21:33:47.066795
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    prepare data for the next epoch.  The prepare method is called at the
    beginning of each epoch.  Subclasses should override this method to
    implement the logic to prepare the data.

    Parameters
    ----------
    dataset : gluon.data.Dataset
        The dataset that returns data.
    epoch : int
        The index of epoch.
    pre_transform : mxnet.gluon.data.transforms.Transform
        The transform to be applied on input.
    pre_sampler : Sampler
        The sampler to be used before the data is fed into the dataloader.

    Returns
    -------
    mxnet.gluon.data.DataLoader
        The dataloader for next epoch.

    """

    docstring = NumpydocParser().parse(docstring)

# Generated at 2022-06-11 21:33:48.222606
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert True



# Generated at 2022-06-11 21:33:58.966731
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:10.070236
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_text = '''\
    Short summary.

    This is a longer description that can span multiple lines.

    Parameters
    ----------
    arg1 : str
        Description of arg1.
    arg2, arg3 : int
        Description of arg2 and arg3.
    arg4 : array-like
        Description of arg4.

    Keyword Arguments
    -----------------
    kw1 : str
        Description of kw1.
    kw2, kw3 : int
        Description of kw2 and kw3.
    kw4 : array-like
        Description of kw4.

    Returns
    -------
    int
        Description of return value.
    '''
    docstring = NumpydocParser().parse(docstring_text)
    assert isinstance(docstring, Docstring)

# Generated at 2022-06-11 21:34:14.812384
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    def yes():
        """\
        "Returns\n"

# Generated at 2022-06-11 21:34:23.982949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test function
    def test():
        """
        This is the short description.

        This is the long description.

        Parameters
        ----------
        a : int
            The first parameter.
        b : int
            The second parameter.

        Returns
        -------
        str
            An informative message.
        """
        pass

    doc = NumpydocParser().parse(test.__doc__)
    assert isinstance(doc, Docstring)

    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True

    assert isinstance(doc.meta, list)

    assert isinstance(doc.meta[0], DocstringParam)
    assert doc

# Generated at 2022-06-11 21:34:45.849490
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_examples = """
        Parse the numpy-style docstring into its components.

        :returns: parsed docstring

        Examples
        --------
        >>> text = '''
        ... Parse the numpy-style docstring into its components.
        ...
        ... :returns: parsed docstring
        ...
        ... Examples
        ... --------
        ... >>> text = '''
        ...
        ... Parse the numpy-style docstring into its components.
        ...
        ... :returns: parsed docstring
        ... '''
        ... '''
        ... >>> parse(text)
        ...
        ... '''
        ... >>> parse(text)
        ... '''
        """
    print(text_examples)
    print(NumpydocParser().parse(text_examples))



# Generated at 2022-06-11 21:34:56.311397
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #test_NumpydocParser_parse_with_no_desc_str
    no_desc_str = """
    Parameters
    ----------
    input : str
        input string
    output: str
        output string

    Returns
    -------
    out : str
        string

    See Also
    --------
    func1: a function
    func2: another func
    """
    parser = NumpydocParser()
    out = parser.parse(no_desc_str)
    assert out.short_description is None
    assert out.long_description is None
    assert not out.blank_after_short_description
    assert not out.blank_after_long_description
    assert len(out.meta) == 3
    assert out.meta[0].args == ["param", "input"]
    assert out.meta[0].type

# Generated at 2022-06-11 21:35:05.952044
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def validate_docstring(
        text: str, short: str, long: T.Optional[str], meta: T.List[DocstringMeta]
    ):
        docstring = parse(text)
        assert docstring.short_description == short
        assert docstring.long_description == long
        assert docstring.meta == meta

    def validate_parameter(
        text: str,
        args: T.Tuple[str, str],
        description: T.Optional[str],
        is_optional: T.Optional[bool],
        default: T.Optional[str],
        type_name: T.Optional[str],
    ):
        docstring = parse(text)
        parameter = next(
            (meta for meta in docstring.meta if meta.key == "param"), None
        )
        assert parameter

# Generated at 2022-06-11 21:35:18.311626
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def test_numpy_docstrings(*args):
        print(len(args))
        print(len(args[0]))
        print(len(args[1]))
        print(len(args[2]))
        print(len(args[3]))
        print(len(args[4]))
        print(len(args[5]))
        print(len(args[6]))
        print(len(args[7]))
        print(len(args[8]))
        print(len(args[9]))
        print(len(args[10]))
        print(len(args[11]))
        print(len(args[12]))
        print(len(args[13]))
        print(len(args[14]))
        print(len(args[15]))
        print

# Generated at 2022-06-11 21:35:29.952325
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "Test method parse of class NumpydocParser.\n"
    text = text + "\n"
    text = text + "Parameters\n"
    text = text + "----------\n"
    text = text + "a: int\n"
    text = text + "    int number\n"
    text = text + "b : float, optional\n"
    text = text + "    float number (default is 3.14)\n"
    text = text + "\n"
    text = text + "Returns\n"
    text = text + "-------\n"
    text = text + "c : int\n"
    text = text + "    integer number\n"
    text = text + "d : float\n"
    text = text + "    float number\n"

# Generated at 2022-06-11 21:35:40.985773
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = "short desc\n\nlong desc\n\nParameters\n----------\na : int\n    desc\n"
    doc = parser.parse(text)
    assert doc == Docstring(
        short_description=text[:12],
        long_description="long desc",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[DocstringParam(args=["param", "a"], arg_name="a", type_name="int", description="desc")]
    )
    text = "short desc\n\n"
    doc = parser.parse(text)

# Generated at 2022-06-11 21:35:52.173478
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    '''
    This is a test function that test the NumpydocParser_parse function
    :return:
    '''
    text = '''
            This function fits a model with iterative reweighted least squares.

    Parameters
    ----------
    X : array-like or sparse matrix, shape (n_samples, n_features)
        Training data.
    y : ndarray, shape (n_samples,)
        Target values.
    sample_weight : ndarray, shape (n_samples,) optional
        Weights applied to each individual sample (1. for unweighted).
    '''
    ret = parse(text)
    assert ret.short_description == 'This function fits a model with iterative reweighted least squares.'
    assert ret.blank_after_short_description == False
    assert ret.blank_after

# Generated at 2022-06-11 21:36:02.832838
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:36:13.681798
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from collections import namedtuple
    import textwrap
    from pprint import pprint
    from .compat import json

    npd = NumpydocParser()

    test_case = namedtuple("test_case", ["before", "after"])