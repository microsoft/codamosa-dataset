

# Generated at 2022-06-11 21:26:31.665451
# Unit test for method parse of class Section
def test_Section_parse():
    assert next(Section("Parameters","param").parse("text")) == DocstringMeta(["param"], description='text')
    with pytest.raises(StopIteration):
        next(NumpydocParser().parse(""))



# Generated at 2022-06-11 21:26:33.354230
# Unit test for method parse of class Section
def test_Section_parse():
    a = Section("Test", "test")
    text = """
    This is a test string.
    """
    text = inspect.cleandoc(text)
    assert a.parse(text)[0].description == "This is a test string."


# Generated at 2022-06-11 21:26:42.300726
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    params
        my_param: int
            This is a documented param
        your_param
            This is a param without type"""
    params = """
        my_param: int
            This is a documented param
        your_param
            This is a param without type"""

    param = ParamSection("params", "param")

    sections = param.parse(params)
    for idx, section in enumerate(sections):
        section.key = param.key
        assert section.args == [param.key, idx]



# Generated at 2022-06-11 21:26:54.641946
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    with open(__file__.replace('.py','.txt')) as fi:
        docstring_content = ''.join(fi.readlines())

    numpy_docstring = NumpydocParser()
    numpy_docstring.add_section(RaisesSection("Raises", "raises"))
    numpy_docstring.add_section(ReturnsSection("Returns", "returns"))
    numpy_docstring.add_section(YieldsSection("Yields", "yields"))

    doc = numpy_docstring.parse(docstring_content)
    #print('\n'.join([str(a) for a in doc.meta]))
    #print(doc.short_description)
    #print(doc.long_description)
    #print(doc.blank_after_short_description)
    #

# Generated at 2022-06-11 21:26:58.980620
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring = numpydoc_parser.parse("""
    Parameters
    ----------
    text: str
        the source text.

    Returns
    -------
    Docstring
    """
    )
    print(docstring)



# Generated at 2022-06-11 21:27:10.190646
# Unit test for method parse of class Section
def test_Section_parse():
    # create a dummy docstring
    dummyDocstring = parse("""
    Parameters
    ----------
    arg_name
        A description of an argument
    arg_2: int, optional
        Another description
    
    """)
    # check whether parse returns a Docstring object
    assert isinstance(dummyDocstring, Docstring), 'returned object is not a Docstring instance'
    # check whether parse returned a Docstring object with a non-empty meta attribute
    assert len(dummyDocstring.meta) != 0, 'meta attribute of Docstring is empty'
    # check whether parse returned a Docstring object with a first element of type DocstringParam
    assert isinstance(dummyDocstring.meta[0], DocstringParam), 'first element of meta attribute has wrong type'
    # check whether the returned DocstringParam object has all the expected attributes
   

# Generated at 2022-06-11 21:27:21.457502
# Unit test for method parse of class _KVSection
def test__KVSection_parse():

    # Case 1
    text = '''key
        value
    key2 : type
        values can also span...
        ... multiple lines'''

    # Case 2
    text = '''key
            value'''

    # Case 3
    text = ''

    # Case 4
    text = '''
        value'''

    # Case 5
    text = '''key
        value
    key2 : type
        values can also span...
        ... multiple lines'''

    # Case 6
    text = '''key
        value
    key2 : type
        values can also span...
        ... multiple lines
    '''

    # Case 7
    text = '''
    key
        value
    key2 : type
        values can also span...
        ... multiple lines'''

# Generated at 2022-06-11 21:27:31.232571
# Unit test for method parse of class Section
def test_Section_parse():
    param_section = ParamSection("Parameters", "param")
    raises_section = RaisesSection("Raises", "raises")
    returns_section = ReturnsSection("Returns", "returns")

    # ParamSection
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """

    meta_list = param_section.parse(text)
    assert len(meta_list) == 2
    meta = meta_list[1]
    assert isinstance(meta, DocstringParam)
    assert meta.args == ['param', 'arg_2']
    assert meta.description == 'descriptions can also span...\n... multiple lines'
    assert meta.arg_name == 'arg_2'
    assert meta.type_name == 'type'


# Generated at 2022-06-11 21:27:42.225338
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:52.735380
# Unit test for method parse of class Section

# Generated at 2022-06-11 21:28:08.558145
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    raw_docstring = """A sample docstring.

    This is a sample docstring written in the
    Numpy style. It provides a long description.

    Parameters
    ----------
    arg_name : type
        A description of this parameter.

    arg_2:
        This description spans multiple lines.

    Returns
    -------
    name: str
        A description of this return value.

    Examples
    --------
    >>> func(arg_name)

    The docstring for a method may reference the arguments and
    return values to generate help for the user.

    .. deprecated:: 1.0
        This function is deprecated
    """

# Generated at 2022-06-11 21:28:19.457711
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  s = NumpydocParser()
  print("Testing NumpydocParser.parse")
  print("Case 1: docstring is None")
  if s.parse(None) is not None:
    return False
  print("Case 2: docstring is empty string")
  if s.parse("") is not None:
    return False
  print("Case 3: docstring is valid string")
  text = "This is the short description.\n\nThis is the long description."
  if s.parse(text).short_description is None or s.parse(text).long_description is None:
    return False
  print("Case 4: docstring is valid string according to NumpyDoc")

# Generated at 2022-06-11 21:28:31.654596
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """Do something.

This function does something.

Parameters
----------
param1 : int
   the first parameter

param2 : str (optional)
   the second parameter

Returns
-------
str
   the result
"""
    docstring = parser.parse(text)
    assert docstring.short_description == 'Do something.'
    assert docstring.long_description == 'This function does something.'
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    meta = docstring.meta
    assert len(meta) == 1
    assert meta[0].args == ['returns']
    assert meta[0].description == 'the result'
    assert meta[0].type_name == 'str'

# Generated at 2022-06-11 21:28:40.313992
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import unittest
    class TestNumpydocParserParse(unittest.TestCase):
        def setUp(self):
            self.txt = """\
                test_func docstring

                first line of long description
                second line of long description

                Parameters
                ----------
                arg1 : str, int
                    arg1 description
                arg2 : list, optional
                    arg2 description
                arg3, optional, default='test'
                    arg3 description with default

                Returns
                -------
                bool

                Examples
                --------
                line 1 of examples
                line 2 of examples

                Notes
                -----
                line 1 of notes

            """
            self.docstring = NumpydocParser().parse(self.txt)


# Generated at 2022-06-11 21:28:50.221809
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:51.345017
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print(NumpydocParser().parse.__doc__)
    raise Exception
    return

# Generated at 2022-06-11 21:29:01.015028
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    # ========== test ==========
    # Returns a docstring of example
    # ========== test ==========
    ret = parser.parse('example:\n    print(1)\n')
    assert ret.short_description == 'example'
    assert (ret.meta[0]).meta_key == 'examples'
    assert (ret.meta[0]).description == 'example:\n    print(1)\n'
    # ========== test ==========
    # Returns a docstring of code example
    # ========== test ==========
    ret = parser.parse('example1:\n    print(1)\nexample2:\n    print(2)\n')
    assert ret.short_description == 'example1'
    assert (ret.meta[0]).meta_key == 'examples'

# Generated at 2022-06-11 21:29:11.212883
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Args:
        arg (int): A description of arg.
        kwarg : str, optional
            A description of kwarg.
    Raises:
        ValueError
            A description of what might raise ValueError
    Warns:
        DeprecationWarning
            A description of what might trigger a deprecation warning.
    Yields:
        int
            A description of a returned value.
        return_name : str, optional
            A description of this returned value.
    Returns:
        int
            A description of a returned value.
    Examples:
        This is a simple example.
    Notes:
        There are important notes here.
    '''
    result = NumpydocParser().parse(text)
    result_meta = result.meta

# Generated at 2022-06-11 21:29:17.895193
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:22.914337
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Function definition

    Parameters
    ----------
    x: str
        The string for test
    y: int
        The integer for test

    Returns
    -------
    bool
        The bool for test

    '''
    doc = NumpydocParser().parse(text)
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'x']
    assert doc.meta[0].arg_name == 'x'
    assert doc.meta[0].type_name == 'str'
    assert doc.meta[1].args == ['param', 'y']
    assert doc.meta[1].arg_name == 'y'
    assert doc.meta[1].type_name == 'int'
    assert doc.meta[2].args == ['returns']
    assert doc

# Generated at 2022-06-11 21:29:37.522173
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:46.447375
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:55.403596
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import unittest
    # Text without any section
    text = '''
    class method

    A class method is a method that is bound to a class rather than its object.
    It doesn't require creation of a class instance, much like staticmethod.
    '''
    actual = NumpydocParser().parse(text)
    expected = Docstring(short_description='class method', 
        blank_after_short_description=False,
        long_description='A class method is a method that is bound to a class rather than its object.\nIt doesn\'t require creation of a class instance, much like staticmethod.', 
        blank_after_long_description=False)
    unittest.TestCase().assertEqual(actual, expected)

    # Text with only one section

# Generated at 2022-06-11 21:30:05.303873
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None
    )
    assert parser.parse("foo\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None
    )
    assert parser.parse("foo\n\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None
    )

# Generated at 2022-06-11 21:30:13.653115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """Shows the metrics for train, validation, and test sets

    Parameters:
    -----------
    metrics: dict
        dict with key for each metric containing list with values for each epoch
    Returns:
    -----------
    List of lists of metrics according to the order in 'entries'
    """
    docstring_json = parser.parse(docstring)
    print(docstring_json)

test_NumpydocParser_parse()

# Generated at 2022-06-11 21:30:17.518592
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    strval = "testing numpy style docstring parsing"
    ret = NumpydocParser().parse(strval)
    assert ret.short_description == "testing numpy style docstring parsing"


# Generated at 2022-06-11 21:30:26.976752
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	result = NumpydocParser().parse("This is a test.")
	assert(result.short_description=="This is a test." and result.long_description==None)

	result = NumpydocParser().parse("This is a test.\nAnd so is this\n")
	assert(result.short_description=="This is a test." and result.long_description=="And so is this" and result.blank_after_short_description==False and result.blank_after_long_description==True)

	result = NumpydocParser().parse("This is a test.\n\nAnd so is this\n")

# Generated at 2022-06-11 21:30:36.046267
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    prs = NumpydocParser()
    docs = '''Example section
    .. code:: python
        numpydoc_parser.go()
    Errata
        This is wrong.


    Parameters
    ----------
    items : list, optional
        The items to use for the test.
    collection : list, default None
        The items to use for the test.
    '''
    ret = prs.parse(docs)
    assert ret.short_description == "Example section"
    assert (ret.long_description is None)
    assert (ret.meta[0].meta is None)
    assert (ret.meta[0].args == ['examples'])
    assert (ret.meta[0].description == 'Example section')
    assert (ret.meta[1].meta is None)

# Generated at 2022-06-11 21:30:44.748689
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test the NumpydocParser.parse method."""

    long_description = "Long description"
    short_description = "Short description"
    param_name = "param"
    param_type = "param_type"
    param_description = "param_description"
    param_default = "param_default"
    comment = "comment"
    output = "output"
    output_type = "output_type"
    output_description = "output_description"
    deprecated_version = "0.0.1"
    deprecated_description = "deprecated_description"


# Generated at 2022-06-11 21:30:56.786960
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''Test Description Long
    Test Description Long
    Test Description Long

    Parameters
    ----------
    a : int
        Argument A.
    b : str, optional
        Argument B.

    Raises
    ------
    ValueError
        Error message.

    Warning
    -------
    Warning message.

    Returns
    -------
    :obj:`int`
        Some integer.

    Yields
    ------
    int
        Some integer.

    Examples
    --------
    >>> a = NumpydocParser()
    >>> a.parse('description')
    <class 'inspectx.numpydoc_parser.Docstring'>

    See Also
    --------
    inspectx.numpydoc_parser.Section : Section class
    '''

    expected_return_value = Docstring()
    expected_return_value

# Generated at 2022-06-11 21:31:08.093990
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()
    assert NumpydocParser().parse("\n") == Docstring()


# Generated at 2022-06-11 21:31:19.634802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
"""
Compute squared Euclidean distance matrix.

This method computes the squared Euclidean distance between each pair of
row vectors in X and Y.

Parameters
----------
X : ndarray
    (M, K) ndarray of M row-vectors in K dimensions
Y : ndarray
    (N, K) ndarray of N row-vectors in K dimensions

Returns
-------
D :
    (M, N) ndarray of Euclidean distance between vectors
"""
    )
    assert docstring.short_description == "Compute squared Euclidean distance matrix."
    assert docstring.long_description == """
This method computes the squared Euclidean distance between each pair of
row vectors in X and Y.
"""
    assert doc

# Generated at 2022-06-11 21:31:31.641186
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:33.671233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    text = """
    """
    result = numpydoc_parser.parse(text)
    assert result == Docstring()

# Generated at 2022-06-11 21:31:45.429576
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    Sample docstring.

    Parameters
    ----------
    arg1 : type1
        description
    arg2 : type2, optional
        description
    arg3, optional
        description
    arg4, type4, optional (default: 42)
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "Sample docstring."
    assert not parsed.blank_after_short_description
    assert not parsed.blank_after_long_description
    assert parsed.long_description is None

# Generated at 2022-06-11 21:31:56.132930
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class DummySection(Section):

        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            return DocstringMeta([self.key], description=_clean_str(text))

    class DummyReturnSection(ReturnsSection):

        def _parse_item(self, key: str, value: str) -> DocstringReturns:
            return DocstringReturns(
                args=[self.key],
                description=_clean_str(value),
                type_name=key if len(key) > 0 else None,
            )

    # Set up the test cases to be checked for each of the sections

# Generated at 2022-06-11 21:32:07.511118
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """\
        A short description

        A longer description

        Parameters
        ----------
        param1 : str
            Description of param1
        param2 : list
            Description of param2

        param3, optional
            Description of param3

        Other Parameters
        ----------------
        att1 : int
            Description of att1

        Raises
        ------
        ValueError
            Description of ValueError
        Exception : str
            Description of Exception

        Returns
        -------
        str
            Description of return value
        """ # noqa: E501


# Generated at 2022-06-11 21:32:16.396897
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringMeta, DocstringReturns
    ndp = NumpydocParser()
    result = ndp.parse('Some short description.\n\n    Some long\n    description.')
    assert result.short_description == 'Some short description.'
    assert result.long_description == 'Some long\n    description.'
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False
    assert result.meta == []
    # Verify example sections
    result = ndp.parse('Examples\n--------\n\n    >>> example_code()\n    42\n')
    assert result.meta == [DocstringMeta(['examples'], '    >>> example_code()\n    42\n')]
    # Verify deprecated sections

# Generated at 2022-06-11 21:32:24.180962
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:29.035581
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_file = open("test_numpydoc.txt", "r")
    example_str = example_file.read()
    assert NumpydocParser().parse(example_str).short_description == "Example short description"


# Generated at 2022-06-11 21:32:58.294025
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:33:10.282297
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    '''
    Test of the method parse of class NumpydocParser
    '''

    # Docstring without section titles
    text = 'without section titles.'
    ret = NumpydocParser().parse(text)
    expected = Docstring()
    expected.short_description = 'without section titles.'
    expected.blank_after_long_description = True
    assert ret == expected

    # Docstring with section titles but not the title for Parameters
    text = 'with section titles but not the title for Parameters\n' \
           '- - - - - -\n' \
           'Attribute1\n' \
           '    Description of Attribute1\n' \
           'Attribute2 : type\n' \
           '    Description of Attribute2'
    ret = NumpydocParser().parse(text)
    expected = Docstring

# Generated at 2022-06-11 21:33:17.192633
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse('''
    This is a one-line description.

    This is a multi-line description.

    This line is ignored.

    Parameters
    ----------
    filename : str
        Name of the file.
    ''') == Docstring(
        short_description='This is a one-line description.',
        blank_after_short_description=False,
        long_description='This is a multi-line description.',
        blank_after_long_description=False,
        meta=[
            DocstringMeta(['param', 'filename'], 'Name of the file.', type_name='str')
        ]
    )

# Generated at 2022-06-11 21:33:29.239046
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str1 = """This is a sentence with a param: foo.
    Parameters:
    -----------
    foo : str
        A string parameter.
    """
    d = NumpydocParser().parse(str1)
    assert d.short_description == "This is a sentence with a param: foo."
    assert d.long_description == "Parameters:\n-----------\nfoo : str\n    A string parameter."

    str2 = """This is a sentence with a param: foo.
    Parameters:
    -----------
    foo : str, optional
        A string parameter.
    """
    d = NumpydocParser().parse(str2)
    assert d.short_description == "This is a sentence with a param: foo."

# Generated at 2022-06-11 21:33:37.501060
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc("""
        This docstring has sections::

            A short description.

            Long description sentence.

        Parameters
        ----------
        str1 : str, optional
            Description of str1.
        str2 : str, optional
           A long description of str2.

        Returns
        -------
        str
            Description of returned value.
        int
            Description of returned value.
    """)
    doc = NumpydocParser().parse(text)
    assert len(doc.meta) == 2
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "str1"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].is_optional == True
    assert doc.meta[1].arg_name

# Generated at 2022-06-11 21:33:46.791043
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc(
        """
        A multi-line summary.

        A multi-line description.

        Parameters
        ----------
        first : type
            A description of the first argument.
        second : type, optional
            A description of the second argument.
        third : type(optional)
            A description of the third argument.

        Other Parameters
        ----------------
        fourth : type
            A description of the fourth argument.
        fifth : type(optional)
            A description of the fifth argument.
        sixth : type, optional
            A description of the sixth argument.
        seventh : type(optional)
            A description of the seventh argument.

        Returns
        -------
        docstring.Docstring
            Parsed docstring.
        """
    )


# Generated at 2022-06-11 21:33:58.078267
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:08.945086
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc("""
        First line of summary

        Parameters
        ----------
        first_param
            This is a string
        second_param : int
            This is an integer, optional

        Returns
        -------
        This is the return type
            This is the return value.

        Yields
        ------
        This is a yield type
            This is a yielded value.

        Empty section
        -------------

        Returns
        -------

        Warning
        -------
        some warning

        Warnings
        --------
        some warning
        """)


# Generated at 2022-06-11 21:34:20.648150
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    method(arg_1, arg_2,
           arg_3 : int,
           arg_4 : str, optional
           arg_5 : int = 20)

        method(arg_1, arg_2,

    Parameters
    ----------
    arg_1 : int
        The first param.
    arg_2 : str
        The second param.
    arg_3 : bool
        The third param.
    arg_4 : list of ints
        The fourth param.

    Returns
    -------
    int
        The return value.

    """
    parser = NumpydocParser()
    docstring = parser.parse(text)


# Generated at 2022-06-11 21:34:25.034446
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.add_section(Section("Test", "test"))
    docstring = parser.parse("Test\n------\nDescription text\n")
    assert docstring.meta[0].args == ["test"]
    assert docstring.meta[0].description == "Description text"



# Generated at 2022-06-11 21:35:18.658921
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Testcase for the method NumpydocParser.parse"""
    # NumpydocParser.parse


# Generated at 2022-06-11 21:35:29.991024
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    string1 = inspect.cleandoc('''
    This is a description.

    Parameters
    ----------
    A
        This is the description of key A.
    B
        This is the description of key B.
    C
        This is the description of key C.

    Returns
    -------
    var1
        This is the description of var1.
    var2
        This is the description of var2.
    ''')

    string2 = inspect.cleandoc('''
    This is a description.
    ''')

    string3 = inspect.cleandoc('''
    This is a description.

    Returns
    -------
    var1
        This is the description of var1.
    var2
        This is the description of var2.
    ''')


# Generated at 2022-06-11 21:35:39.213648
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()

    docstring = """
    Some short description.

    Some longer description.

    Parameters
    ----------
    arg_a : int, optional
        some description for arg_a.

    arg_b : str
        some description for arg_b.
    Raises
    ------
    Exception
        some description for the exception.
    """
    parsed = numpydoc_parser.parse(docstring)

    assert parsed.short_description == 'Some short description.'
    assert parsed.long_description == 'Some longer description.'

    assert parsed.meta[0].key == 'arg_a'
    assert parsed.meta[0].type_name == 'int'
    assert parsed.meta[0].is_optional == True

# Generated at 2022-06-11 21:35:50.434680
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test that NumpydocParser.parse() can parse a numpy docstring.
    """
    doc = """
    """
    # Assert that doc is parsed as an empty docstring
    assert(NumpydocParser().parse(doc) == Docstring())

    # Numpy docstring example

# Generated at 2022-06-11 21:36:01.199198
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("hello world") == parse("hello world") == Docstring(
        short_description="hello world",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert NumpydocParser().parse("hello world\n    and more") == parse("hello world\n    and more") == Docstring(
        short_description="hello world",
        long_description="and more",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:36:11.323453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    docstring = '''
    This has a short description and a long one.

    Blah blah blah.

    Parameters
    ----------
    x : int
        The first number.
    y : float, optional
        The default is 1.0.

    Returns
    -------
    z : float
        The addition of x and y.

    See Also
    --------
    None.

    References
    ----------
    None.

    '''

    actual_result = NumpydocParser().parse(docstring)