

# Generated at 2022-06-11 21:26:33.781942
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:26:45.233760
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring = ('This is a test.\n\n'
                 'Parameters\n'
                 '----------\n'
                 'a, b: int\n'
                 '    This is a test.')
    result = numpydoc_parser.parse(docstring)

# Generated at 2022-06-11 21:26:48.635787
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:26:58.888789
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "Title\n=====\n\nShort description\n\nLong description.\n\nParameters\n----------\nx : int\n    Put a description of x here\n\nReturns\n-------\nstr\n    Put a description of the return value here\n"
    nd = NumpydocParser()
    doc = nd.parse(text)
    assert doc.short_description == "Short description"
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description  == False
    assert doc.meta.args == [
        "param",
        "x",
    ]
    assert doc.meta.description == "Put a description of x here"

# Generated at 2022-06-11 21:27:10.123341
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    DeprecationSection_obj = DeprecationSection("deprecated", "deprecation")
    assert DeprecationSection_obj.parse("deprecation warning") == [DocstringDeprecated(args=['deprecation'], description=None, version=None)]
    assert DeprecationSection_obj.parse("deprecated\nDeprecation warning") == [DocstringDeprecated(args=['deprecation'], description='Deprecation warning', version=None)]
    assert DeprecationSection_obj.parse("Deprecated\nDeprecation warning") == [DocstringDeprecated(args=['deprecation'], description=' Deprecation warning', version='Deprecated')]

# Generated at 2022-06-11 21:27:17.949532
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("Deprecated", "deprecated")
    deprecation_warning: DocstringDeprecated = section.parse("2.0\n"
                                                             "This function is deprecated.")[0]
    assert deprecation_warning.args == ['deprecated']
    assert deprecation_warning.version == '2.0'
    assert deprecation_warning.description == "This function is deprecated."

# Generated at 2022-06-11 21:27:27.311379
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # arrange
    deprecation_parser = DeprecationSection("Deprecated", "deprecated")
    text = "0.1\nA description of this"

    # act
    result = deprecation_parser.parse(text)

    # assert
    assert(len(result) == 1)
    assert(type(result[0]).__name__ == "DocstringDeprecated")
    assert(result[0].args[0] == "deprecated")
    assert(result[0].description == "A description of this")
    assert(result[0].version == "0.1")


# Generated at 2022-06-11 21:27:31.646968
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    @property
    def property_func(self):
        """This is a property.

        .. property:: prop_name

            This is the property's doc string.
        """
        pass
    docstring = property_func.__doc__
    parsed = NumpydocParser().parse(docstring)
    assert parsed.short_description == 'This is a property.'


# Generated at 2022-06-11 21:27:41.393521
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = inspect.cleandoc("""
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """)
    
    section = _KVSection("Parameters", "param")
    parse = section.parse(text)
    doc = inspect.cleandoc("""
        arg_name : None
            arg_description
    """)
    assert(doc == str(parse))

    doc = inspect.cleandoc("""
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """)
    assert(doc == str(next(parse)))

    assert(next(parse, None) is None)


# Generated at 2022-06-11 21:27:45.569838
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    class TestDeprecationSection(DeprecationSection):
        def parse(self, text: str) -> T.Iterable[DocstringDeprecated]:
            yield DocstringDeprecated(args=[self.key], description=None, version=None)
    obj = TestDeprecationSection("deprecated", "deprecation")
    result = obj.parse(".. deprecated:: 1.2.0\n\nDeprecated in version 1.2.0")
    assert result is not None


# Generated at 2022-06-11 21:28:03.845192
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    l_docstring = numpydoc_parser.parse(
        """
        docstring

        this is a docstring.

        Parameters:
            p1 : int
                p1 parameter
            p2 (optional): float
                p2 parameter

        Raises:
            ValueError
                if an error occurs

        Examples:

            foo(1)
                some example
        """
    )

# Generated at 2022-06-11 21:28:12.210622
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def cust_parse(arg1, arg2, arg3=None, arg4=None, arg5=None, arg6=None):
        """Short description.

        Long description, typically a few sentences long.

        Parameters
        ----------
        arg1 : type
            Description for arg1
        arg2 : type
            Description for arg2
        arg3 : type
            Description for arg3
        Other Parameters
        ----------------
        arg4 : type, optional
            Description for arg4
        arg5 : type, optional
            Description for arg5
        arg6 : type, optional
            Description for arg6

        Returns
        -------
        return : type
            Description of return value
        """
        pass


    parser = NumpydocParser()
    doc = parser.parse(cust_parse.__doc__)

    assert doc.short_

# Generated at 2022-06-11 21:28:22.443930
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Case 1 (empty string)
    text = ''
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0
    assert len(docstring.errors) == 0
    assert len(docstring.warnings) == 0

    # Case 2 (one-line docstring)
    text = 'This is a one-line docstring.'
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'This is a one-line docstring.'
    assert docstring.long_description == None
    assert docstring.blank_after_

# Generated at 2022-06-11 21:28:28.917483
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
Short description

    Long description
    """
    expected = Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        long_description="Long description",
        blank_after_long_description=True,
    )

    actual = NumpydocParser().parse(text)

    assert actual == expected



# Generated at 2022-06-11 21:28:38.558095
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short summary.

    Full summary.

    Parameters
    ----------
    arg1 : str
        Description of arg1
    arg2 : optional, int
        Description of arg2

    Returns
    -------
    bool
        True if success, False otherwise.

    Examples
    --------
    >>> function_name(42)
    True

    >>> function_name("arg")
    False
    """
    docstring = Docstring()
    docstring.short_description = "Short summary."
    docstring.long_description = "Full summary."
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True

    arg1 = DocstringParam(args=["param", "arg1"],
                          description="Description of arg1")

# Generated at 2022-06-11 21:28:46.110278
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    function
    --------
    function : blabla

    Parameters
    ----------
    arg: blabla
        description

    x : blabla
        description

    Returns
    -------
    blabla

    See Also
    --------
    blabla
    """
    ret = NumpydocParser().parse(text)
    print(ret)
    assert ret.short_description == "function"
    assert ret.meta[0].description == "function : blabla"
    assert len(ret.meta) == 3
    for i in range(1, len(ret.meta)):
        assert len(ret.meta[i].args) == 2


# Generated at 2022-06-11 21:28:57.580261
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test numpydoc parsing.
    """
    from .common import (
        Docstring,
        DocstringDeprecated,
        DocstringReturns,
        DocstringRaises,
        DocstringParam,
    )
    from .common import DocstringMeta

    parser = NumpydocParser()
    text = """
    Test function

    Short description

    Long(er) description

    Parameters
    ----------
    arg1
        first arg

    arg2, optional
        second arg

    Returns
    -------
    None
        always
    """

    docstring = parser.parse(text)


# Generated at 2022-06-11 21:29:08.833345
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Class declaration
    nparser = NumpydocParser()
    # Prepare some parameters

# Generated at 2022-06-11 21:29:16.995952
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringReturn
    from .numpydoc import parse


# Generated at 2022-06-11 21:29:29.010808
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """A simple example docstring.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str, optional
        Description of `arg2` (default: None)
    *args
        Variable length argument list.
    **kwargs
        Arbitrary keyword arguments.

    Returns
    -------
    bool
        True if successful, False otherwise.

    Other Parameters
    ----------------
    other : int
        Description of `other`
    other2 : str, optional
        Description of `other2` (default: None)
    other3 : class 'list'
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "A simple example docstring."
    assert docstring.blank_

# Generated at 2022-06-11 21:29:41.215513
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = """
        This is the short description.

        This is the long description.
        It can span several lines.

        Parameters
        ----------
        arg1 : int
            Description of arg1
        arg2 : :obj:`list` of :obj:`str`
            Description of arg2

        Returns
        -------
        str
            Description of return value

        See Also
        --------
        some, other, functions
        """
    docstring = NumpydocParser().parse(docstr)
    assert(docstring.short_description == "This is the short description.")
    assert(docstring.long_description == "This is the long description.\nIt can span several lines.")
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)


# Generated at 2022-06-11 21:29:52.821488
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = """\
    Convert a YAML dict instance to a nested dict for a Python module.

    In other words, convert a nested dict instance to a dict-of-dict.

    Parameters
    ----------
    ydict : dict
        YAML dict instance.

    Returns
    -------
    dict
    """
    docstring = parser.parse(doc)
    assert docstring.short_description == "Convert a YAML dict instance to a nested dict for a Python module."
    assert docstring.long_description == "In other words, convert a nested dict instance to a dict-of-dict."
    assert docstring.meta[0].args == ['param', 'ydict']
    assert docstring.meta[0].description == "YAML dict instance."

# Generated at 2022-06-11 21:30:03.371822
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1:
    assert parse(
        """\
        Test function.

        Showing
        param section.

        Parameters
        ----------
        foo : str
            Foo parameter.
        """
    ) == Docstring(
        short_description="Test function.",
        long_description="Showing\nparam section.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param", "foo"],
                description="Foo parameter.",
                arg_name="foo",
                type_name="str",
            )
        ],
    )

    # Test case 2:

# Generated at 2022-06-11 21:30:08.122527
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = 'The number of errors.\n\n' + \
           'Deprecated and will be removed in a future version.\n' + \
           '    Use the value in ``count``.\n' + \
           '    Default is 0.\n'
    ret = NumpydocParser().parse(text)
    print(ret)


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:30:09.571830
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert(parse('Simple string'))

# Generated at 2022-06-11 21:30:18.883143
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:27.661711
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test for funtion parse in NumpydocParser
    parser = NumpydocParser()

# Generated at 2022-06-11 21:30:36.461047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydocParser = NumpydocParser()
    text = "Single line description"
    docstring = numpydocParser.parse(text)
    assert docstring.short_description == "Single line description"

    text = "Single line description\ndescription with two lines"
    docstring = numpydocParser.parse(text)
    assert docstring.short_description == "Single line description"
    assert docstring.long_description == "description with two lines"

    text = "Single line description\n\ndescription with two lines"
    docstring = numpydocParser.parse(text)
    assert docstring.short_description == "Single line description"
    assert docstring.long_description == "description with two lines"

    text = "Single line description\n\n\ndescription with two lines"
    docstring

# Generated at 2022-06-11 21:30:44.988373
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    sample_doc = """
        aa

        bb.

        cc
        .. param:: aa
            A
        .. param:: bb
            B
        .. param:: cc
            C
        .. returns:: dd
            D
        .. returns:: ee
            E
    """
    parsed = NumpydocParser().parse(sample_doc)
    assert parsed.references == []
    assert parsed.notes == []
    assert parsed.see_also == []
    assert parsed.warnings == []
    assert parsed.examples == []
    assert parsed.warns == []
    assert parsed.raises == []
    assert parsed.other_param == []
    assert parsed.receives == []
    assert parsed.attribute == []
    assert parsed.param.__len__() == 3
    assert parsed.yields == []

# Generated at 2022-06-11 21:30:56.984342
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:16.929372
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """First line
    Second line
    Parameters
    ----------
    arg_1 : str
      First arg

    arg_2 : int, optional
      Second arg with default 42

    other_parameters
    ----------------
    arg_3
      Third arg

    Raises
    ------
    ValueError
      The `arg_1` cannot not be `None`.
    """

    docstring = parser.parse(text)
    assert docstring.short_description == 'First line'
    assert docstring.long_description == 'Second line'
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 4
    
    param_1 = docstring.meta[0]

# Generated at 2022-06-11 21:31:27.729909
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = parser.parse("""this is a module
""")
    assert doc == Docstring(
        short_description="this is a module",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )
    doc = parser.parse("""this is a module
that shows some sections

param foo
    description of foo
param bar
    description of bar
param baz : str
    description of baz

Returns:
    something
""")

# Generated at 2022-06-11 21:31:36.770174
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:46.842499
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = """
    Short description test.

    Longer description test.

    Parameters
    ----------
    arg1
        arg1 description
    arg2 : int
        arg2 description, optional
        default: 42
    arg3 : other_param
        arg3 description
    arg4 : raises
        arg4 description
    arg5 : returns
        arg5 description
    arg6 : yields
        arg6 description
    arg7 : examples
        arg7 description
    arg8 : see_also
        arg8 description
    arg9 : notes
        arg9 description
    arg10 : references
        arg10 description
    arg11 : deprecated
        This is deprecated.

    Returns
    -------
    name1
        name1 description
    name2 : dict
        name2 description

    """
    ds = parse(p)

# Generated at 2022-06-11 21:31:56.939055
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    actual_docstring = NumpydocParser().parse("""
    Parses the numpy-style docstring into its components.

    :param text: section body text. Should be cleaned with
                 ``inspect.cleandoc`` before parsing.
    :returns: parsed docstring
    :raises Exception: if the text is not valid
    """
    )


# Generated at 2022-06-11 21:32:07.940108
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def _test(section_string, expected):
        docstring = parse(section_string)
        assert docstring.short_description == expected[0]
        assert docstring.long_description == expected[1]
        assert docstring.blank_after_short_description == expected[2]
        assert docstring.blank_after_long_description == expected[3]
        assert docstring.meta == expected[4]


# Generated at 2022-06-11 21:32:16.748474
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:24.262276
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    npd = NumpydocParser()
    docstr = """\
    Testfunction.

    :param int param1:
    :param float param2:
    :param float param3:

    """
    sections = npd.parse(docstr)
    assert sections.short_description == 'Testfunction.'
    assert sections.long_description is None
    assert sections.blank_after_short_description
    assert sections.blank_after_long_description
    assert len(sections.meta) == 1
    assert sections.meta[0].args[0] == 'param'
    assert sections.meta[0].description == 'int param1'
    assert sections.meta[0].arg_name == 'param1'
    assert sections.meta[0].type_name == 'int'
    assert not sections.meta[0].is_optional


# Generated at 2022-06-11 21:32:34.304843
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # single
    text = '''
    test_NumpydocParser_parse

    :param int a: a
        a's description
    :returns:
        ret
    '''
    docstring = NumpydocParser().parse(text)    
    assert type(docstring) == Docstring
    assert docstring.short_description == 'test_NumpydocParser_parse'
    assert docstring.blank_after_short_description == False
    assert docstring.meta == [DocstringParam(args=['param', 'a'], description='a\'s description', arg_name='a', type_name='int', is_optional=None, default=None), DocstringReturns(args=['returns'], description='ret', type_name=None, is_generator=False, return_name=None)]
    assert docstring

# Generated at 2022-06-11 21:32:42.486678
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	npdp = NumpydocParser()

# Generated at 2022-06-11 21:32:59.275293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """\
    sample docstring.

    This is a sample docstring that can be parsed.
    Multiple lines of text are allowed in short and long descriptions.

    Parameters
    ----------
    x
        parameter x.
    y : str
        parameter y.
    z : (int, int)
        parameter z.

    Returns
    -------
    The return value.

    Raises
    ------
    ValueError
        A description of what might raise ValueError.
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "sample docstring."
    assert parsed_docstring.long_description == "This is a sample docstring that can be parsed.\nMultiple lines of text are allowed in short and long descriptions."
    assert parsed_docstring.blank_after_short_description == True

# Generated at 2022-06-11 21:33:10.514111
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .sample_data import simple_numpydoc_docstring

    numpy_parser = NumpydocParser()

    docstring = numpy_parser.parse(simple_numpydoc_docstring)

    assert docstring.short_description == "A short summary of the class."
    assert docstring.long_description == """\
Longer summary of the class.

  More detailed description of the class, if applicable.

"""
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == """\
Longer summary of the class.

  More detailed description of the class, if applicable.

"""
    assert len(docstring.meta) == 4

    assert docstring.meta[0].args == ['param', 'k']

# Generated at 2022-06-11 21:33:18.903878
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from ..test.test_common import assert_docstring_equals
    from ..test.test_numpydoc_parser import test_data

    parser = NumpydocParser()

    for test_case, expected_docstring in test_data.items():
        # Skip anything that is not a test case
        if "test_" not in test_case:
            continue

        if "_example" in test_case:
            # Skip anything that is not an example
            continue

        if "_without_blank_line" in test_case:
            # Skip anything that is not an example
            continue

        # Run the test and compare results
        assert_docstring_equals(
            parser.parse(getattr(test_data, test_case)),
            expected_docstring,
            test_case,
        )

# Generated at 2022-06-11 21:33:30.445230
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:41.276743
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Create a test NumpydocParser
    a = NumpydocParser()

    # Test case 1: No sections
    assert a.parse('') == Docstring()

    # Test case 2: Only one section
    b = ".. deprecated:: 2.1\n    Use :func:`scipy.misc.logsumexp` instead"
    result = Docstring()
    result.meta.append(DocstringDeprecated(args=['deprecation'], description=None, version='2.1'))
    assert a.parse(b) == result

    # Test case 3: Two or more sections
    c = """
    .. deprecated:: 2.1
        Use :func:`scipy.misc.logsumexp` instead
    .. versionadded:: 1.2.0"""
    result = Docstring()
    result.meta

# Generated at 2022-06-11 21:33:48.727986
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:59.307510
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:08.943374
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """This is a docstring

Args:
    arg1 (int): The first argument
    arg2 (str): The second argument

Returns:
    (int): Integer return value
"""
    doc = parser.parse(text)
    assert doc.short_description == "This is a docstring"
    assert doc.long_description is None
    assert len(doc.meta) == 2
    assert doc.meta[0] == DocstringParam(args=["param", "arg1"], description="The first argument")
    assert doc.meta[1] == DocstringReturns(args=["returns"], description="Integer return value")


# Generated at 2022-06-11 21:34:11.584711
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    '''
    print(NumpydocParser().parse(text))

# Generated at 2022-06-11 21:34:22.123477
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test"""

    docstring =\
    """Parses docstring into short description, long description and meta information.

    Meta information is currently limited to Parameters, Returns and Examples.

    Parameters
    ----------
    text : string
        The docstring text.

    Returns
    -------
    parsed docstring
    """

    # Test case: Parse docstring without NumpyDoc format
    docstring_test = "This function parses a docstring"

    # Test case: Parse docstring with NumpyDoc format
    docstring_test_numpydoc =\
    """Parses docstring into short description, long description and meta information.
    Meta information is currently limited to Parameters, Returns and Examples.
    Parameters
    ----------
    text : string
        The docstring text.
    Returns
    -------
    parsed docstring"""



# Generated at 2022-06-11 21:34:36.302590
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:46.861385
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()

# Generated at 2022-06-11 21:34:57.849194
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser=NumpydocParser()
    text=numpydoc_parser.parse("""
        Method docstring.

        Parameters
        ----------
        arg1 : int
            The first argument.
        arg2 : str
            The second argument.

        Returns
        -------
        str
            The return value.

        Other Parameters
        ----------------
        arg3 : str
            The third argument.

        Raises
        ------
        AttributeError
            The error raised.

        Examples
        --------
        pretty print example here

        Notes
        -----
        .. [1] A citation
        .. [2] Another citation

        References
        ----------
        .. [1] Reference 1
        .. [2] Reference 2
        """)
    print(text.long_description)
    print(text.short_description)


# Generated at 2022-06-11 21:35:07.654336
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test long name of the match group works (via ParamSection)
    s = "Parameters\n----------\na : int\n\nArgs\n----\nb : str\n    c"
    params = list(NumpydocParser([ParamSection("Parameters", "param")]).parse(s).meta)
    assert params[0].arg_name == "a"
    assert params[0].type_name == "int"
    assert params[0].is_optional is False
    assert params[1].arg_name == "b"
    assert params[1].type_name is None
    assert params[1].is_optional is False
    assert params[1].description == "c"

test_NumpydocParser_parse()

# Generated at 2022-06-11 21:35:10.879497
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    r = NumpydocParser().parse(text)
    assert Docstring.__dict__ == r.__dict__

test_NumpydocParser_parse()

# Generated at 2022-06-11 21:35:19.765930
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Unit test for method parse of class NumpydocParser
    test_string = """
    Parameters
    ----------
    param_1 : str, optional
        First parameter.
    param_2 : int
        Second parameter.
    """
    parsed = Docstring()
    parsed.meta = [DocstringParam(['param', 'param_1'], 'First parameter.', 'param_1', 'str', True), 
    DocstringParam(['param', 'param_2'], 'Second parameter.', 'param_2', 'int', False)]

    assert NumpydocParser().parse(test_string) == parsed


# Generated at 2022-06-11 21:35:30.858038
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    def _get_doc(section_title):
        parser = NumpydocParser()

        def _method_with_doc(self):
            """
            Parameters
            ----------
            self: my_type

            Returns
            -------
            int

            Other Parameters
            ----------------
            my_type: foo

            Notes
            -----
            See More:
                https://github.com/sphinx-contrib/napoleon

            """
            return self

        method_with_doc = _method_with_doc

        method_with_doc.__doc__ = inspect.cleandoc(method_with_doc.__doc__)
        docstring = parser.parse(method_with_doc.__doc__)
        return next(
            meta for meta in docstring.meta if meta.args[0] == section_title
        )

# Generated at 2022-06-11 21:35:40.308142
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doctxt = r"""
    This is a one line summary
    This is a long description
    that can span
    multiple lines

    Parameters
    ----------
    param1 : string
        this is param1
    """
    docstr = NumpydocParser().parse(doctxt)
    assert docstr.short_description == "This is a one line summary"
    assert docstr.long_description == "This is a long description\nthat can span\nmultiple lines"
    assert docstr.meta[0].args[0] == 'param'
    assert docstr.meta[0].args[1] == 'param1'
    assert docstr.meta[0].description == 'this is param1'



# Generated at 2022-06-11 21:35:51.702158
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Test numpy-style docstring parsing.

        Parameters
        ----------
        first param : type
            A description of this param
        second_param (optional)
            Optional parameters are...
            ...allowed, too.
        third_param
            If a param needs a longer description

            it can span multiple lines.

        Raises
        ------
        TypeError
            This section can contain multiple items

        Returns
        -------
        str
            A description of the returned value

        Warnings
        --------
        This section can contain multiple items

        Note
        ----
        The second item will be ignored as there is no
        two line gap

        Yields
        ------
        str
            A yield statement
    """

# Generated at 2022-06-11 21:36:02.365148
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1
        arg1 description.
    arg2 : int, optional
        arg2 description.

    Returns
    -------
    bool
        Return value description.

    Raises
    ------
    ValueError
        If something bad happened
    """
    parsed = NumpydocParser().parse(text)

    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False

    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "arg1 description."
    assert parsed.meta[0].arg_name == "arg1"