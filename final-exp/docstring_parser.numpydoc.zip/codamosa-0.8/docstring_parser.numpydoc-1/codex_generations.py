

# Generated at 2022-06-11 21:26:45.674670
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_docstring = """
    test_docstring
    -------

    Parameters
    ----------
    param: int, optional
        Description of parameter
        Default is 1
    other_param
        Description of other_param
    attribute: int(readonly), optional
        Description of attribute
        Default is 0

    Returns
    -------
    int
        Description of returned type
   
    Raises
    ------
    ValueError
        Raises ValueError
    OtherError
        Raises OtherError
    """

    expected_short_description = 'test_docstring'
    expected_long_description = 'test_docstring'
    expected_blank_after_short_description = True
    expected_blank_after_long_description = False

# Generated at 2022-06-11 21:26:55.909637
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("") == Docstring() == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Docstring!") == Docstring(
        short_description="Docstring!",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("Docstring!\n") == Docstring(
        short_description="Docstring!",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:27:08.251074
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the short description.

    This is the long description.

    The long description is optional.

    Parameters
    ----------
    arg1 : int
    arg2 : str, optional
      Default is 'hello'

    Raises
    ------
    ValueError
        When you do something wrong.

    Yields
    ------
    int
        The next number

    Examples
    --------
    >>> parse('foo')
    ['foo']

    """
    parse_result = NumpydocParser().parse(text)

    assert parse_result.short_description == "This is the short description."
    assert parse_result.long_description == "This is the long description."
    assert parse_result.blank_after_short_description == True
    assert parse_result.blank_after_long_description == True
    param

# Generated at 2022-06-11 21:27:11.875774
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    expected = """
        """
    # Act
    a = NumpydocParser()
    actual = a.parse(expected)
    # Assert
    assert actual == expected


# Generated at 2022-06-11 21:27:22.375466
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    
    docstring = """
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring

    :Parameters:
        - `foo`: foo is a keyword
        - `bar`: bar is a kw, too
        - `baz`: baz is a kw also
        - `quux`: quux is a kw likewise
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "Parse the numpy-style docstring into its components."
    assert parsed.blank_after_short_description

# Generated at 2022-06-11 21:27:26.435683
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Does something.

Parameters
----------
arg : int
    A number.

Returns
-------
str
    A string.
"""
    result = parse(text)
    assert result.short_description == "Does something."
    assert len(result.meta) == 2

# Generated at 2022-06-11 21:27:28.110696
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    Args:
        arg_1: This is arg_1, a str.
        arg_2: This is arg_2, an int, optional
    """
    assert parse(text).meta[1].arg_name == 'arg_2'


# Generated at 2022-06-11 21:27:41.436762
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Here we test the method parse
    """
    short_description = "This is a short description"
    long_description = "This is a long description"
    blank_after_short_description = True
    blank_after_long_description = True

    #Test for method parse of class NumpydocParser without arguments
    assert NumpydocParser().parse("") == Docstring()

    #Test for method parse of class NumpydocParser with long_description
    assert NumpydocParser().parse("\n".join([short_description, long_description])) == Docstring(
        short_description=short_description,
        long_description=long_description,
        blank_after_short_description=blank_after_short_description,
        blank_after_long_description=blank_after_long_description,
    )

# Generated at 2022-06-11 21:27:47.363460
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    np = NumpydocParser()


# Generated at 2022-06-11 21:27:55.665379
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection("key_value_section", "key_value")
    text = ""
    ret = parser.parse(text)
    for item in ret:
        assert(len(item.args) == 2)
        assert(item.args[0] == "key_value")
        assert(item.args[1] == None)
        assert(item.key == None)
        assert(item.value == None)
    text = "key_1\n    value_1\nkey_2 : type\n    values can also span...\n    ... multiple lines"
    ret = parser.parse(text)
    i = 0
    for item in ret:
        assert(len(item.args) == 2)
        assert(item.args[0] == "key_value")

# Generated at 2022-06-11 21:28:08.167065
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Basic text
    # Assume basic short desc + long desc
    doc = inspect.cleandoc('''
    This is a very simple fast efficient awesome method!
    
    The :class:`~awesome.AwesomeClass` is great! ''')
    parsed = NumpydocParser().parse(doc)
    assert parsed.short_description == 'This is a very simple fast efficient awesome method!'
    assert parsed.long_description == 'The :class:`~awesome.AwesomeClass` is great!'
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False


    # Short desc and long desc with no blank lines

# Generated at 2022-06-11 21:28:09.724839
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert type(parser.parse("test")) is Docstring


# Generated at 2022-06-11 21:28:20.615406
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    # test return all None
    text = ""
    res = parser.parse(text)
    assert res.short_description is None
    assert res.long_description is None
    assert res.blank_after_short_description is None
    assert res.blank_after_long_description is None

    # test return all None
    text = '''
    '''
    res = parser.parse(text)
    assert res.short_description is None
    assert res.long_description is None
    assert res.blank_after_short_description is None
    assert res.blank_after_long_description is None

    # test return all None
    text = '''
   
    '''
    res = parser.parse(text)
    assert res.short_description is None
    assert res.long

# Generated at 2022-06-11 21:28:33.085566
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    p = NumpydocParser()
    # Example from https://numpydoc.readthedocs.io/en/latest/format.html

# Generated at 2022-06-11 21:28:44.217534
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringParam

    def func(arg1, arg2: int = 2, *args, **kwargs):
        """Short description

        With a blank line.

        Long description
        """
        pass

    nd = NumpydocParser()
    ds = nd.parse(func.__doc__)
    assert ds.short_description == "Short description"
    assert ds.long_description == "With a blank line."
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == True

    # test params section
    param_list = list(filter(lambda dm: dm.object_type == "param", ds.meta))
    assert len(param_list) == 1

# Generated at 2022-06-11 21:28:50.020743
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    print(parser)
    print(parser.sections)
    print(parser.sections.keys())
    print(parser.sections['Parameters'])
    print(parser.sections['Parameters'].title)
    print(parser.sections['Parameters'].key)

    print(parser.titles_re.search('Parameters\n----------'))

# Generated at 2022-06-11 21:29:00.180561
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    short description.

    long description.

    Parameters
    ----------
    var : int
        variable description.

    Raises
    ------
    ValueError
        description.
    """

    docstring = parse(text)
    assert docstring.short_description == "short description."
    assert docstring.long_description == "long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-11 21:29:10.356897
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:29:17.853863
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test parsing a numpy-style docstring to its components,
    including its long description and meta data.

    Note: This test case is a subset of the full test case 
    in test_numpy.py which tests a more complex numpy-style docstring.
    """


# Generated at 2022-06-11 21:29:29.453504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for method parse of class NumpydocParser"""
    def test_fun(a, b=100, *args, c:float, d, **kwargs):
        """The first line is the short description

        Parameters
        ----------
        a: int
            a is the first parameter.
        b: int, optional
            b is the second parameter with default value 100.
        *args:
            arbitrary number of positional arguments.
        c: float
            c is a floating point number.
        d: str
            d is a string.
        **kwargs:
            arbitrary number of keyword arguments.

        Returns
        -------
        int:
            the sum of a, b, c and d

        Raises
        ------
        TypeError
            If a is not an int.
        """
        return a + b + c + d



# Generated at 2022-06-11 21:29:40.250439
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse('''
    Single line description.
    
    Parameters
    ----------
    var1 : str
        All the information about var1.
    var2 : int, optional
        All the information about var2.
    ''')
    assert(docstring.short_description == 'Single line description.')
    assert(docstring.long_description == 'All the information about var1.')
    assert(docstring.meta[1].args == ['param', 'var2'])
    assert(docstring.meta[1].is_optional == True)
    assert(docstring.meta[0].type_name == 'str')

# Generated at 2022-06-11 21:29:52.338816
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = r'''
    Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`
    Returns
    -------
    int
        Description of return value.
    '''

    docstring = parser.parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description.\n'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1'

# Generated at 2022-06-11 21:30:03.079106
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = inspect.cleandoc(
        """Parameters
        ----------
        param_a : type
            description of param_a
        param_b : type
            description of param_b

        Returns
        -------
        return_a : type
            description of return_a
        """
    )
    result = NumpydocParser().parse(docstring)

    assert result.long_description is None
    assert result.short_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert len(result.meta) == 2

    assert result.meta[0].args == ["param", "param_a"]
    assert result.meta[0].type_name == "type"
    assert result.meta[0].description == "description of param_a"

# Generated at 2022-06-11 21:30:10.950075
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:16.424980
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:26.186470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import numpy as np

    def test_function():
        """
        This is a test function

        Parameters
        ----------
        a : int
            this is parameter a

        Returns
        -------
        b : int
            this is return b

        Examples
        --------
        >>> import pandas as pd
        >>> pd.testing.assert_series_equal(
        ...     pd.Series([1.0]),
        ...     pd.Series([2.0])
        ... )
        """


# Generated at 2022-06-11 21:30:35.376561
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_str = """
    Test method for class TNSparseModel

    Parameters
    ----------
    x : :class:`~tnsparse.model.model.TNSparseModel`
        The :class:`~tnsparse.model.model.TNSparseModel` object counts from
        which to generate a TNSparseModel
    y : :class:`~tnsparse.model.model.TNSparseModel`
        The :class:`~tnsparse.model.model.TNSparseModel` object counts from
        which to generate a TNSparseModel
    """
    parser = NumpydocParser()
    result = parser.parse(test_str)
    assert result.short_description == "Test method for class TNSparseModel"
    assert result.long_description.strip() == "Parameters"

# Generated at 2022-06-11 21:30:44.949406
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for successful parse
    test_docstr =\
"""Calculate the magnitude of a complex number.

Parameters
----------
z : complex
    Input complex number.

Returns
-------
float
    Magnitude of the input complex number.

Raises
------
TypeError
    If the input is not a complex number.
"""
    #Test that this docstring produces the correct Docstring object

# Generated at 2022-06-11 21:30:56.624427
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    class MockNumpyDocParser:
        """A class that mocks the NumpydocParser class."""
        def __init__(self, sections=None):
            pass
        def parse(self, text):
            return Docstring()

    from ..common import DocstringParser

    # Mock the numpydoc parser class (NumpydocParser) so that
    # it returns an empty Docstring
    DocstringParser.REGISTERED_PARSERS["numpy_style"] = MockNumpyDocParser

    docstring = """
    Short description

    Long description

    Parameters
    ----------
    name: str
        a sample parameter

    Examples
    --------
    >>> foo
    1
    """

    assert NumpydocParser().parse(docstring) == Docstring()

# Generated at 2022-06-11 21:31:06.860047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = None
    assert str(NumpydocParser().parse(text)) == 'Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])'
    text = '''
    This docstring has no metadata section.

    It has a longer description,
    but no blank lines separating
    the short and long descriptions.
    '''
    assert str(NumpydocParser().parse(text)) == 'Docstring(short_description=\'This docstring has no metadata section.\', long_description=\'It has a longer description,\nbut no blank lines separating\nthe short and long descriptions.\', blank_after_short_description=False, blank_after_long_description=False, meta=[])'

# Generated at 2022-06-11 21:31:21.595779
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for NumpydocParser.parse()"""
    # Parameter section

# Generated at 2022-06-11 21:31:33.074738
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test no parameters
    case_1 = """
        This is a short description
        This is a long description
    """
    docstring = Docstring()
    docstring.short_description = "This is a short description"
    docstring.long_description = "This is a long description"
    docstring.blank_after_short_description = False
    docstring.blank_after_long_description = True
    assert NumpydocParser().parse(case_1) == docstring

    # test with parameters

# Generated at 2022-06-11 21:31:44.926453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test method parse of class NumpydocParser"""
    text = """Parameters
    ----------
        arg_name : type (optional)
            arg_description
        arg_2 : type (optional)
            arg_description
        arg_3 : type (optional)
            arg_description

    Returns
    -------
    Returns something"""

    ret = NumpydocParser().parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is True
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ['param', 'arg_name']
    assert ret.meta[0].description == 'arg_description'
    assert ret.meta[0].arg_name

# Generated at 2022-06-11 21:31:55.746663
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Unit test for method parse of class NumpydocParser
    
    """
    # Test docstring
    doc = "This is a description\n"
    doc += " of the docstring.\n"
    doc += "Notes\n"
    doc += "- A note.\n"
    doc += "- Another note.\n"
    doc += "Pandas\n"
    doc += "------\n"
    doc += ":param df: a Pandas Dataframe\n"
    doc += ":type df: Dataframe\n"
    doc += ":return: same dataframe\n"
    doc += ":rtype: Dataframe\n"

    print('\n+++++')
    print(__doc__)
    print('+++++')

# Generated at 2022-06-11 21:32:07.173568
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    Parse the Numpy-style docstring into its components.

    :param text: docstring.
    :type text: str

    :returns: parsed docstring
    :rtype: typing.Docstring

    .. warning:: Warnings go here.

    .. note::
        Notes go here.

    These are some examples.

    .. deprecated:: 10.11.2
        Use `parse_sphinx` instead.

    """

# Generated at 2022-06-11 21:32:16.086703
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Testing the NumpyDocParser parse function
    """
    docstring_1 = \
        """Single line description.

        Additional description that spans multiple lines.

        Parameters
        ----------
        first : str, optional
            Description of `first` that spans multiple lines.
        second : int, optional
            Description of `second`.

        Example
        -------
        >>> parse()
        <Docstring>
        """
    docstring_2 = \
        """Single line description.

        Additional description that spans multiple lines.

        Parameters
        ----------
        first
            Description of `first` that spans multiple lines.
        second : int, optional
            Description of `second`.
        third

        Example
        -------
        >>> parse()
        <Docstring>
        """

# Generated at 2022-06-11 21:32:21.979561
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_1 = """
    This is a docstring, in case you couldn't tell.

    Parameters
    ----------
    arg : str
        string argument.
    kwarg : int
        int argument.
        also spans multiple lines

    Returns
    -------
    other : str
        description of return value.
    """

    example_2 = """
    This is a docstring, in case you couldn't tell.

    Parameters
    ----------
    arg : str
        string argument.
    kwarg : int, optional
        int argument.
        also spans multiple lines

    Returns
    -------
    other : str
        description of return value.
    """


# Generated at 2022-06-11 21:32:33.484725
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ds_txt = """\
    Short description
    Long description

    Parameters
    ----------
    arg1 ...

    Arguments
    ---------
    arg2

    Other Parameters
    ----------------
    arg3 ...

    Other Args
    ----------
    arg4
    """
    ds = NumpydocParser().parse(ds_txt)
    assert ds.short_description == 'Short description'
    assert ds.long_description == 'Long description'
    assert len(ds.meta) == 4
    assert ds.meta[0].args == ['param', 'arg1']
    assert ds.meta[1].args == ['param', 'arg2']
    assert ds.meta[2].args == ['other_param', 'arg3']

# Generated at 2022-06-11 21:32:42.100879
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """First line.
   Second line.

Synopsis

   Parameters
   ----------
   arg1 : type, optional
       arg1 description.

   arg2 : type, optional
       arg2 description.
           arg2 description cont.

   Returns
   -------
   rtype
       The return description.

   Notes
   -----
   Notes description.

   Example
   -------
   Examples description.

   Warning
   -------
   Warning description.

   References
   ----------
   References description.

   Related
   -------
   Related description.
"""
    )

    assert docstring.short_description == "First line."
    assert docstring.blank_after_short_description is False
    assert docstring.long_description == "Second line."
    assert docstring

# Generated at 2022-06-11 21:32:51.201270
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def test_parse(tests: T.Dict[str, T.Dict[str, str]]):
        for doc, result in tests.items():
            parser = NumpydocParser(sections=result["sections"])
            parsed = parser.parse(doc)
            assert parsed.short_description == result["short_description"]
            assert parsed.long_description == result["long_description"]


# Generated at 2022-06-11 21:33:02.166675
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_docstring = """Short description.

Long description

    of multiple lines.

Parameters
----------
a : str
    Parameter a.
b : int, optional
    Parameter b.

Returns
-------
out : float
    The return value.
"""

# Generated at 2022-06-11 21:33:06.515262
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:33:15.629476
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:16.254352
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-11 21:33:27.830835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_of_parse = """
    parse(text)

    Parse the numpy-style docstring into its components.

    Parameters
    ----------
    text : str
        the docstring to parse

    Returns
    -------
    docstring : Docstring
        a parsed docstring
    """

# Generated at 2022-06-11 21:33:36.767555
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print('Testing method parse of class NumpydocParser')

    text = '''
    Parses docstring in numpy-style.

    :param text: docstring text
    :returns: parsed docstring
    '''

    ds = parse(text)
    assert ds.short_description == 'Parses docstring in numpy-style.'

    meta = ds.meta
    assert len(meta) == 1
    assert meta[0].args == ['param', 'text']
    assert meta[0].description == 'docstring text'
    assert meta[0].arg_name == 'text'
    assert meta[0].type_name is None
    assert meta[0].is_optional is None
    assert meta[0].default is None

    print('OK')



# Generated at 2022-06-11 21:33:46.433311
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # text is defined as a numpy docstring with various sections
    text = """
        docstring
        ----------

        Short description.

        Parameters
        ----------
        param1 : type
            Description of `param1`.
        param2 : type, optional
            Description of `param2`.

        Keyword Arguments
        -----------------
            kwarg1 : type
                Description of `kwarg1`.
            kwarg2 : type
                Description of `kwarg2`.

        Yields
        ------
        return_type
            Description of yielded value.
        """

    # ret is the parsed docstring by NumpydocParser
    ret = NumpydocParser().parse(text)

    # expected is the expected output of ret

# Generated at 2022-06-11 21:33:57.775303
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text='some text'

    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'some text'
    assert ret.meta == []

    text='some text\n\nlong text'
    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'some text'
    assert ret.long_description == 'long text'
    assert ret.meta == []

    text='some text\n\n\nlong text'
    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'some text'
    assert ret.long_description == 'long text'
    assert ret.meta == []

    text='some text\n\nlong text\n\n\n'
    ret = NumpydocParser().parse(text)


# Generated at 2022-06-11 21:34:08.647468
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1
    text_1 = """
    This is a method used to test if the parser works correctly.

    Parameters
    ----------
    a : str
        a is a string parameter
    b : int, optional
        b is a integer parameter
    c : float, optional
        c is a float parameter
    d : bool, optional
        d is a boolean parameter
    """
    docstring_1 = parse(text_1)

# Generated at 2022-06-11 21:34:20.447834
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	import doctest
	doctest.testmod(NumpydocParser)
	from NumpydocParser import NumpydocParser

# Generated at 2022-06-11 21:34:33.567750
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    nd_parser = NumpydocParser()
    param_text = """
    foo
        a foo argument
    bar : int, optional
        a bar argument. Default is 42.
    baz : (int, int), optional
        a baz argument. Default is (0, 0).
    """
    raises_text = """
    ValueError
        if something went wrong
    """
    returns_text = """
    out : str, optional
        the output
    """
    yields_text = """
    out : str, optional
        the output
    """
    deprecation_text = """
    v2.1.0
        deprecation warning

    """
    example_text = """
    >>> foo(42)
    """

# Generated at 2022-06-11 21:34:45.177635
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #testdoc1 = """\
    #    This is a docstring.

    #    Parameters
    #    ----------
    #    x : int
    #        x is an integer
    #    y : bool
    #        y is a boolean

    #    Returns
    #    -------
    #    z : str
    #        z is a string
    #"""

    testdoc2 = """\

Short description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """


# Generated at 2022-06-11 21:34:56.266229
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc_dict = {}
    doc_dict["Returns: Tuple containing:"] = Docstring()
    doc_dict["Raises: Tuple containing:"] = Docstring()
    doc_dict['Returns: (Tuple containing:)'] = Docstring()
    doc_dict['Raises: (Tuple containing:)'] = Docstring()
    doc_dict['Examples: Tuple containing:'] = Docstring()
    doc_dict['Examples: (Tuple containing:)'] = Docstring()
    doc_dict['Example: Tuple containing:'] = Docstring()
    doc_dict['Example: (Tuple containing:)'] = Docstring()
    doc_dict["See Also:"] = Docstring()

    doc_dict["Returns:\n   Tuple containing:\n"] = Docstring()
    doc

# Generated at 2022-06-11 21:35:04.087093
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()

# Generated at 2022-06-11 21:35:16.845650
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class A:
        '''
        Parameters:
        a (int):
            a value
        b: int = 1
            a value
        Returns:
        int: A value
        '''
        pass
    docstring = parse(A.__doc__)
    assert docstring.params[0].name == 'a'
    assert docstring.params[0].type_name == 'int'
    assert docstring.params[0].descr == 'a value'
    assert docstring.params[1].name == 'b'
    assert docstring.params[1].type_name == 'int'
    assert docstring.params[1].default == '1'
    assert docstring.params[1].descr == 'a value'
    assert docstring.returns[0].type_name == 'int'
    assert docstring

# Generated at 2022-06-11 21:35:28.744923
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:39.437319
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    case_0 = """
        This is an example

        Parameters
        ----------
        arg1 : int
            arg1 description

        arg2 : str, optional
            arg2 description

        Other Parameters
        ----------------
        other : str
            other description
    """
    case_1 = """
        Short description.

        Long description.

        Parameters
        ----------
        param1 : int
            param1 description

        param2 : str, optional
            param2 description

        Raises
        ------
        TypeError
            If `param2` is not a string.

        Other Parameters
        ----------------
        other : str
            other description

        See Also
        --------
        :class:`SomeClass`
    """


# Generated at 2022-06-11 21:35:50.723027
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:54.554618
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser().parse(text = '''This function returns **true** if **true**.
    :returns: boolean
    ''')
    print("NumpydocParser parse method is Tested")

# Generated at 2022-06-11 21:36:04.461219
# Unit test for method parse of class NumpydocParser