

# Generated at 2022-06-11 21:26:53.890249
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:05.787577
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # simple case
    text = """
        Parse the numpy-style docstring into its components.

        :returns: parsed docstring
    """
    d = parse(text)
    assert d.short_description == 'Parse the numpy-style docstring into its components.'
    assert d.long_description == None
    assert d.meta[0].args == ['returns']
    assert d.meta[0].descriptions == "parsed docstring"
    assert d.meta[0].return_name == None
    assert d.meta[0].type_name == None

    # one section
    text = """
        Parse the numpy-style docstring into its components.

        Parameters
        ----------
        text: str
            The input text

        :returns: parsed docstring
    """
    d = parse

# Generated at 2022-06-11 21:27:17.460595
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:27:28.993567
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''\
    A simple example
        Some longer description.

    Parameters
    ----------
    arg : type
        Description of arg.

    Returns
    -------
    return_name
        Description of return.
    '''
    assert NumpydocParser().parse(text) == Docstring(
        short_description='A simple example',
        long_description='Some longer description.',
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=['param', 'arg'],
                type_name='type',
                description='Description of arg.',
            ),
            DocstringMeta(args=['returns'], description='Description of return.'),
        ],
    )

# Generated at 2022-06-11 21:27:41.225230
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_doc_1 = """
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    Raise ValueError
        A description of what might raise ValueError
    """

    parser = NumpydocParser()
    doc = parser.parse(str_doc_1)

    assert doc.short_description == 'Parse the numpy-style docstring into its components.'
    assert doc.long_description == None

    for meta in doc.meta:
        assert meta.args == ['returns']
        assert meta.description == 'parsed docstring'
        assert meta.arg_name == None
        assert meta.type_name == None
        assert meta.is_optional == None
        assert meta.default == None
        assert meta.version == None



# Generated at 2022-06-11 21:27:52.221482
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Tests the method parse of class NumpydocParser"""

    # we start with a simple example

# Generated at 2022-06-11 21:28:02.750543
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Parameters
    ----------
    x: int
        Longer description of x.

    y: float
        Longer description of y.

    Returns
    -------
    out: ndarray
        Array of shape (3,), with values from 0 to 2.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_long_description == True
    assert docstring.blank_after_short_description == True
    parameters = [meta for meta in docstring.meta if meta.key == 'param']

# Generated at 2022-06-11 21:28:10.445182
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # simple test
    docstring = '''
    This is a simple docstring.

    Parameters
    ----------
    
    arg1: str
        argument 1
    
    arg2: str
        argument 2

    Returns
    -------

    str
        Return value: a string
    '''

    test_docstring = parse(docstring)

# Generated at 2022-06-11 21:28:20.693420
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Testing.
    Parameters
    ----------
    param1: int
        The first parameter.
    param2
        The second parameter.
    Returns
    -------
    int
        A return value.
    """
    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'Testing.'
    assert ret.long_description == None
    assert 'param1' in [meta.arg_name for meta in ret.meta if meta.key == 'param']
    assert 'param2' in [meta.arg_name for meta in ret.meta if meta.key == 'param']
    assert 'int' == [meta.type_name for meta in ret.meta if meta.key == 'returns'][0]

# Generated at 2022-06-11 21:28:31.055852
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
Parse the numpy-style docstring into its components.

:returns: parsed docstring
    """

    docstring_parser = NumpydocParser()
    parsed_docstring = docstring_parser.parse(docstring)

    assert parsed_docstring.short_description == "Parse the numpy-style docstring into its components."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True
    assert parsed_docstring.long_description == ":returns: parsed docstring"
    assert parsed_docstring.meta[0].description == "parsed docstring"

# Generated at 2022-06-11 21:28:40.384665
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    N = NumpydocParser()
    text = '''This is a very long description of a function.
           Parameters
           ----------
           nums: int
               number of items to be added
    '''

    assert(N.parse(text).long_description == "This is a very long description of a function.")

# Generated at 2022-06-11 21:28:50.221626
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        Short description.

        Long description.

        Parameters
        ----------
        arg : int
            An argument.
        arg2 : Optional[str]
            Another argument.

        Returns
        -------
        int
            Description of return value.
        """
    )

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."

    # Meta
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["returns"]
    assert docstring.meta[0].description == "Description of return value."
    assert docstring.meta[0].type_name == "int"

    # Params
    assert len(docstring.params) == 2

# Generated at 2022-06-11 21:29:00.307495
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_docstring = f"""
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Yields
    ------
    return_name : type
        A description of this yielded value
    another_type
        Yield names are optional, types are required

    Examples
    --------
    >>> example

    Warnings
    --------
    >>> warning

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """

    test_Docstring = parse(test_docstring)
    assert test_Docstring.short

# Generated at 2022-06-11 21:29:10.474656
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring
    from .numpydoc import NumpydocParser
    docstring = NumpydocParser().parse("""\
        Test numpy-style docstring

        :param str arg1: The first argument.
        :param arg2: The second argument.
        :type arg2: int, optional
        :param arg3: The third argument.
        :type arg3: int, optional
        :param arg4: The fourth argument.
        :type arg4: int, optional
        :type arg5: int, optional

        :returns: None
        :rtype: NoneType
        :raises AttributeError: When something bad happens
        """)
    
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Test numpy-style docstring"
    assert doc

# Generated at 2022-06-11 21:29:17.900951
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # Test short description
    short_desc = "A short description."
    long_desc = "A long description.\n"

    docstring = short_desc + long_desc
    result = parser.parse(docstring)
    assert result.short_description == short_desc
    assert result.long_description == long_desc.strip()
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True

    docstring = short_desc + "\n" + long_desc
    result = parser.parse(docstring)
    assert result.short_description == short_desc
    assert result.long_description == long_desc.strip()
    assert result.blank_after_short_description == True

# Generated at 2022-06-11 21:29:29.483502
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """short description
long description of the method

Raises
------

ValueError
    Raises an exception

Returns
-------

return1 : str
    str with length > 0

return2 : int
    int > 0

Warns
------

TypeError
    If something bad happens
"""
    ds = parser.parse(text)

    assert ds.short_description == "short description"

    assert ds.long_description == "long description of the method"

    assert len(ds.meta) == 4

    assert ds.meta[0].args == ["raises", "ValueError"]
    assert ds.meta[0].type_name == "ValueError"
    assert ds.meta[0].description == "Raises an exception"

    assert d

# Generated at 2022-06-11 21:29:39.768917
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    ds = """
    Short summary

    Long summary

    Parameters
    ----------
    a : bool
        short
        long

    b : float, optional
        short

    c : float, optional, defaults to 3.2
        short
        long


    Returns
    -------
    ret : float

    """
    res = parse(ds)
    assert(res.short_description == "Short summary")
    assert(res.long_description == "Long summary")
    assert(res.blank_after_short_description == True)
    assert(res.blank_after_long_description == True)
    assert(res.meta[0].args == ["param", "a"])
    assert(res.meta[1].args == ["param", "b"])

# Generated at 2022-06-11 21:29:51.975389
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from ..tests.helpers import generate_test_case, call_parse_fn
    from .common import Docstring

    fn = NumpydocParser().parse
    yield from generate_test_case(fn, [("""
        Short description.

        Longer description.
        """, {
        'short_description': "Short description.",
        'long_description': "Longer description.",
        'meta': [],
    })])


# Generated at 2022-06-11 21:29:54.535131
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse('"Parses an numpydoc formatted docstring"\n')
    assert docstring is not None

# Generated at 2022-06-11 21:30:05.154138
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''This is a short description

    This is a long description,
    which can be continued over several lines.

    Parameters
    ----------
    arg_name : type
        arg_description
    arg2 : type, optional
        arg2_description

    Returns
    -------
    return_1, return_2
        return_description

    Raises
    ------
    ValueError
        If something breaks

    See Also
    --------
    some_func
    '''
    doc = ('This is a short description\n\nThis is a long description, '
           'which can be continued over several lines.\n\n')

# Generated at 2022-06-11 21:30:12.181381
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.__class__ == RaisesSection

# Generated at 2022-06-11 21:30:16.170332
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """
    Testcase for the constructor of class RaisesSection
    """
    temp = RaisesSection('Raises', 'raises')
    assert temp._KVSection__parse_item('KeyError', 'Not Found') is not None
    assert temp._KVSection__parse_item('KeyError', 'Not Found').args[0] == 'raises'


# Generated at 2022-06-11 21:30:26.019817
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection.__name__ == "_KVSection"
    assert _KVSection.__doc__ == """Base parser for numpydoc sections with key-value syntax.

    E.g. sections that look like this:
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    assert _KVSection.__init__.__name__ == "__init__"
    assert _KVSection.__init__.__doc__ == "Constructor of class _KVSection"
    assert _KVSection._parse_item.__name__ == "_parse_item"
    assert _KVSection._parse_item.__doc__ == "Parse_item of class _KVSection"
    assert _KVSection.parse.__name__ == "parse"
    assert _

# Generated at 2022-06-11 21:30:35.253475
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def func(x:int, y:int)->int:
        """
        :param x: this is the param named x
        :param y: this is the param named y
        :return: the sum of x and y

        this is the long description
        """

# Generated at 2022-06-11 21:30:42.614241
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()

    parser.add_section(ParamSection("NewParams", "new_params"))
    assert "NewParams" in parser.sections.keys()
    assert len(parser.sections.keys()) == len(DEFAULT_SECTIONS) + 1

    parser.add_section(ParamSection("Params", "params"))
    assert "Params" in parser.sections.keys()
    assert len(parser.sections.keys()) == len(DEFAULT_SECTIONS) + 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 21:30:55.427177
# Unit test for function parse
def test_parse():
    text1 = """
    Args:
        a: description
        b (int): description
    Returns
        whatever
     """
    text2 = """
    Parameters
        a: description
        b (int): description
    Returns
        whatever
     """
    text3 = """
    Args
        a: description
        b (int): description
    Returns
        whatever
     """
    text4 = """
    Args
        a: description
        b (int): description
    Returns
        whatever
     """
    text5 = """
    Parameters
        a: description
        b (int): description
    Returns
        whatever
     """
    d1 = parse(text1)
    d2 = parse(text2)
    d3 = parse(text3)
    d4 = parse(text4)
    d5 = parse

# Generated at 2022-06-11 21:30:59.402714
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    test_section = Section("Test", "test")
    parser.add_section(test_section)
    assert "Test" in parser.sections
    assert len(parser.sections) == len(DEFAULT_SECTIONS) + 1
    assert parser.sections["Test"] == test_section


# Unit tests for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:01.226689
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection(title="Parameters", key="param")
    assert isinstance(p, ParamSection)


# Generated at 2022-06-11 21:31:08.207141
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = """
    Raises
        ValueError
             A description of what might raise ValueError
        ValueError
    """

    sections = {}
    sections['Raises'] = _KVSection("Raises","raises")
    numpydocParser = NumpydocParser(sections)
    docstring = numpydocParser.parse(text)
    assert (docstring.meta[0].args == ('raises', 'ValueError'))
    assert (docstring.meta[0].description == 'A description of what might raise ValueError')
    assert (docstring.meta[1].description == None)
    assert (docstring.meta[1].args == ('raises', 'ValueError'))

# Generated at 2022-06-11 21:31:10.561321
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    patternMatched = [r"^\.\.\s*(deprecated)\s*::"]

    assert(DeprecationSection("deprecated", "deprecation").title_pattern in patternMatched)
    #assert(a)


# Generated at 2022-06-11 21:31:16.185326
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Title", "Key")
    assert sec.title == "Title"
    assert sec.key == "Key"


# Generated at 2022-06-11 21:31:20.162815
# Unit test for method parse of class Section
def test_Section_parse():
    title = "Arguments"
    key = "param"
    section = Section(title, key)
    param = DocstringParam(["param","arg1"])
    text = title + "\n" + "-"*len(title) + "\n" + "arg1\n"
    assert section.parse(text) == [param]



# Generated at 2022-06-11 21:31:25.040502
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    short description

    long description
    """
    ret = NumpydocParser().parse(text)
    assert ret.short_description == "short description"
    assert ret.long_description == "long description"
    assert ret.meta == []



# Generated at 2022-06-11 21:31:35.088479
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test data
    test_text = "3.0.0\n" +\
                "    First line of the deprecation message.\n" +\
                "    Second line of the deprecation message.\n"

    parser = NumpydocParser()

    # Expected results
    exp_DocstringDeprecated = DocstringDeprecated(
        args=['deprecation'], 
        description='First line of the deprecation message. Second line of the deprecation message.', 
        version='3.0.0'
    )

    # Run parser
    res = parser._parse_deprecation_message(test_text)

    # Compare actual vs. expected results
    assert res == exp_DocstringDeprecated, \
            "Unit test of method parse of class DeprecationSection failed"

# Generated at 2022-06-11 21:31:46.243052
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert not DeprecationSection("deprecation", "deprecation").parse("")
    assert not DeprecationSection("deprecation", "deprecation").parse("\n")
    assert not DeprecationSection("deprecation", "deprecation").parse(".. versionadded:: 0.1.1\n")
    assert len(tuple(DeprecationSection("deprecation", "deprecation").parse(".. versionadded:: 0.1.1\nA description"))) == 1

    expected = DocstringDeprecated(["deprecation"], "A description", "0.1.1")
    actual = tuple(DeprecationSection("deprecation", "deprecation").parse(".. versionadded:: 0.1.1\n" +
        "A description\n"))[0]
    assert actual._kwargs == expected._kwargs

# Generated at 2022-06-11 21:31:55.066045
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    string = ".. deprecated:: 0.3.0\n\
        Widget.get will be deprecated, use Widget.post instead"
    assert DeprecationSection(title=None, key=None).parse(text=string).description == "Widget.get will be deprecated, use Widget.post instead"
    assert DeprecationSection(title=None, key=None).parse(text=string).version == "0.3.0"
    assert DeprecationSection(title=None, key=None).parse(text=string).args == [None]

#Unit test for method parse of class MetaSection

# Generated at 2022-06-11 21:32:06.582330
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    from .common import Docstring
    from .numpydoc import NumpydocParser


# Generated at 2022-06-11 21:32:09.956259
# Unit test for constructor of class ParamSection
def test_ParamSection():
    print("Unit test for constructor of class ParamSection")
    p1 = ParamSection("Parameters", "param")
    assert p1.title == "Parameters"
    assert p1.key == "param"
    print("test for ParamSection passed")


# Generated at 2022-06-11 21:32:20.942010
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    assert parser.parse("")
    assert parser.parse(None)

    text = inspect.cleandoc('''
        A function.

        Parameters
        ----------
        a : type
            This is a.
        b : type
            This is b.

        Returns
        -------
        returns
            This is it.
    ''')

    expected = inspect.cleandoc('''

        A function.
    ''')
    assert parser.parse(text).short_description == expected

    assert parser.parse(text).short_description_end == 15


# Generated at 2022-06-11 21:32:23.082018
# Unit test for function parse
def test_parse():
    """ Unit test for function parse
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:32:31.376805
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection("Yields", "yields")
    assert section.title == "Yields"
    assert section.key == "yields"
    assert section.is_generator == True


# Generated at 2022-06-11 21:32:32.757963
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    ndp = NumpydocParser() 


# Generated at 2022-06-11 21:32:34.726570
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returns = ReturnsSection("Returns", "returns")
    assert returns.title == "Returns"
    assert returns.key == "returns"

# Generated at 2022-06-11 21:32:36.213585
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser is not None


# Generated at 2022-06-11 21:32:38.360590
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection.__init__.func_code.co_argcount == 3


# Generated at 2022-06-11 21:32:42.384005
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns", "returns")
    assert(rs.title == "Returns")
    assert(rs.key == "returns")
    assert(rs.is_generator == False)
    
    

# Generated at 2022-06-11 21:32:44.344492
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sections = NumpydocParser()
    sections.add_section(Section("Test", "test"))


# Generated at 2022-06-11 21:32:52.821247
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    paragraph = ".. sourcecode:: \n    from os import path\n    from qrcode.constants import DEFAULT_MODULE_SIZE\n    from qrcode.image.base import BaseImage\n\nThis is a test of our parser."
    paragraphs = paragraph.split("\n\n")
    assert paragraphs == [".. sourcecode:: \n    from os import path\n    from qrcode.constants import DEFAULT_MODULE_SIZE\n    from qrcode.image.base import BaseImage", "This is a test of our parser."]


# Generated at 2022-06-11 21:32:57.600627
# Unit test for method parse of class Section
def test_Section_parse():
    if __name__ == "__main__":
        text = "\nAttributes\n----------\n    a : type\n        return the value of a squared\n"
        section = ParamSection("Attributes", "attributes")
        result = section.parse(text)
        result = list(result)
        print(result)



# Generated at 2022-06-11 21:33:06.720215
# Unit test for constructor of class RaisesSection
def test_RaisesSection():

    # This is a test to make sure the constructor of RaisesSection works
    raisesSection = RaisesSection("Raises", "raises")

    assert(isinstance(raisesSection, RaisesSection))
    assert(isinstance(raisesSection, _KVSection))
    assert(isinstance(raisesSection, Section))
    assert(raisesSection._parse_item("ValueError", "Description") == DocstringRaises(["raises", "ValueError"], description="Description", type_name="ValueError"))


# Generated at 2022-06-11 21:33:18.250229
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title_pattern = _SphinxSection("title", "key").title_pattern
    assert title_pattern == r"^\.\.\s*(title)\s*::"


# Generated at 2022-06-11 21:33:30.140451
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()
    assert NumpydocParser().parse("test") == Docstring(short_description = "test")
    assert NumpydocParser().parse("test\nmore") == Docstring(short_description = "test", blank_after_short_description = True, long_description = "more")
    assert NumpydocParser().parse("test\nmore\n") == Docstring(short_description = "test", blank_after_short_description = True, blank_after_long_description = True, long_description = "more")
    assert NumpydocParser().parse("test\n\nmore\n") == Docstring(short_description = "test", blank_after_short_description = True, blank_after_long_description = True, long_description = "more")
   

# Generated at 2022-06-11 21:33:37.861943
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Unit test for method parse of class DeprecationSection"""
    check_numpy_syntax = False
    try:
        DeprecationSection("deprecated", "deprecation").parse("""
        Deprecated since version 0.1.0: Deprecation warning.
        """)
        check_numpy_syntax = True
    except Exception as e:
        pass
        # print(e)
        # pass
    finally:
        assert check_numpy_syntax

    check_numpy_syntax = False
    try:
        DeprecationSection("deprecated", "deprecation").parse("""
        Deprecated since version 0.1.0:
        this is a deprecation warning
        """)
        check_numpy_syntax = True
    except Exception as e:
        pass
        # pass
       

# Generated at 2022-06-11 21:33:40.189443
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection(title='Yields', key='yields')
    assert section.is_generator == True

# Generated at 2022-06-11 21:33:42.828725
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    if not isinstance(ReturnsSection("Returns", "returns"), ReturnsSection):
        raise AssertionError("ReturnsSection class does not properly initialize object")
    return True


# Generated at 2022-06-11 21:33:47.764775
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # base example: title: 'something', key: 'something'
    parser = _SphinxSection('something', 'something')
    assert parser.title == 'something'
    assert parser.key == 'something'
    assert parser.title_pattern == '^\\.\\.\\s*(something)\\s*::'


# Generated at 2022-06-11 21:33:58.603627
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section('Parameters', 'param')
    # print(section.title_pattern)

    text ="""
    b : {'C', 'F', 'A'}, optional
        Specifies whether the data is C- or Fortran-contiguous by default,
        or whether it should be made contiguous at all.

    order : {'C', 'F', 'A', 'K'}, optional
        Controls the memory layout order of the result. 'C' means C-order,
        'F' means F-order, 'A' means 'F' if a is Fortran contiguous, 'C'
        otherwise. 'K' means match the layout of a as closely as possible.
        (Note that this function and :func:`numpy.asarray` are very
        similar, but have different default values for their
        ``order`` parameters.)
    """
   

# Generated at 2022-06-11 21:34:04.531885
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import DocstringMeta, DocstringDeprecated
    assert DeprecationSection("Deprecation", "deprecated").parse("""\
        Removed in 0.2.0

        This is an empty test field
        """) == [DocstringDeprecated(
            args=["deprecated"],
            description="This is an empty test field",
            version="Removed in 0.2.0"
        )]

    assert DeprecationSection("Deprecation", "deprecated").parse("""\
        Removed in 0.2.0
        """) == [DocstringDeprecated(
            args=["deprecated"],
            description=None,
            version="Removed in 0.2.0"
        )]

# Unit Test for method parse of class ParamSection

# Generated at 2022-06-11 21:34:13.906436
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  """Unit test for parse of class NumpydocParser"""
  class TestCase:
    def __init__(self, name, text, expected, docstring = None):
      self.name = name
      self.text = text
      self.expected = expected
      self.docstring = docstring


# Generated at 2022-06-11 21:34:18.748733
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r'^(Parameters)\s*?\n{}\s*$'.format('-' * len(title))



# Generated at 2022-06-11 21:34:48.162581
# Unit test for function parse

# Generated at 2022-06-11 21:34:54.292419
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_text = """
    a
        a's description
    b : int, optional
        b's description can span multiple lines
    """
    kv = _KVSection("", "")
    result = kv.parse(test_text)
    expected = [
        ("a", "a's description"),
        ("b : int, optional", "b's description can span multiple lines")
    ]
    assert list(result) == expected

# Generated at 2022-06-11 21:34:57.557872
# Unit test for constructor of class Section
def test_Section():
    sec = Section("section_title", "section_key")
    assert(sec.title == "section_title")
    assert(sec.key == "section_key")


# Generated at 2022-06-11 21:35:02.981552
# Unit test for constructor of class ParamSection
def test_ParamSection():
    from .common import DocstringParam
    a = ParamSection("Args","param")

    # test argument
    assert isinstance(a, ParamSection)

    assert a.title == "Args"
    assert a.key == "param"
    assert a.title_pattern == "^(Args)\s*?\n---*\s*$"
    assert a.__doc__ != None


# Generated at 2022-06-11 21:35:08.268581
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    expected = DocstringReturns(
        args=["returns"], description=_clean_str("value"),
        type_name="type", is_generator=False, return_name=None)
    assert (ReturnsSection("Returns", "returns")._parse_item("", "value") ==
            expected)


# Generated at 2022-06-11 21:35:11.766352
# Unit test for constructor of class Section
def test_Section():
    title = "Returns"
    key = "returns"
    mySection = Section(title=title, key=key)
    assert mySection.title == title
    assert mySection.key == key


# Generated at 2022-06-11 21:35:14.317385
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_string = "This is a test string."
    test_parser = NumpydocParser(sections=[Section("This", "i")])
    test_parser._setup()
    test_parser.titles_re = re.compile("This", re.M)
    assert test_parser.parse(test_string) == usual_parse(test_string)

# Generated at 2022-06-11 21:35:22.563218
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:33.303512
# Unit test for function parse
def test_parse():
    from .parser import parse
    text="""
    Parameters:
    a_arg (int): A special argument.
               Default is 1
    other_arg (str) : an other argument
    Returns:
        str: a returned value
        int: a generator value
    """
    doc = parse(text)
    print(doc)
    print(doc.short_description)
    print(doc.meta)
    print(doc.long_description)

    arg = doc.get_param('a_arg')
    assert arg.type_name == 'int'
    assert arg.is_optional == False
    arg2 = doc.get_param('other_arg')
    assert arg2.type_name == 'str'
    assert arg2.is_optional == False
    y = doc.get_return('Yields')

# Generated at 2022-06-11 21:35:38.713779
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class test_Section(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))

    parser = NumpydocParser()
    assert parser.sections['Parameters'] is None

    section = test_Section("Parameters", "param")
    parser.add_section(section)
    assert parser.sections['Parameters'] == section