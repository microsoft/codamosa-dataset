

# Generated at 2022-06-11 21:27:07.824451
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    # testing without docstring
    assert str(parser.parse("")) == ''
    # testing with docstring
    assert parser.parse("This is a docstring.") == 'This is a docstring.'


# Generated at 2022-06-11 21:27:19.934663
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:31.430063
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    expect = Docstring()
    expect.short_description = 'Returns True or False.'
    expect.blank_after_short_description = True
    expect.blank_after_long_description = True
    expect.long_description = None

# Generated at 2022-06-11 21:27:33.464196
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("") == Docstring()

# Generated at 2022-06-11 21:27:43.009022
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:53.259679
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:00.887070
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def f(p):
        return parse(p)

    assert f("Hello, world!").short_description == "Hello, world!"
    assert f("Hello, world!").long_description == None
    assert f("Hello, world!\n\nA longer description").short_description == "Hello, world!"
    assert f("Hello, world!\n\nA longer description").long_description == "A longer description"
    assert f("Hello, world!\nA longer description").short_description == "Hello, world!"
    assert f("Hello, world!\nA longer description").long_description == "A longer description"
    assert f("Hello, world!\n").short_description == "Hello, world!"
    assert f("Hello, world!\n").long_description == None

# Generated at 2022-06-11 21:28:09.317662
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:20.223328
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test empty docstring
    assert NumpydocParser().parse("").to_dict() == {}

    # test short description and long description
    assert (
        NumpydocParser()
        .parse("""
        Short description.

        Long description
        """)
        .to_dict()
        == {
            "short_description": "Short description.",
            "long_description": "Long description",
            "blank_after_short_description": True,
            "blank_after_long_description": False,
            "meta": [],
        }
    )

    # test no blank before long description

# Generated at 2022-06-11 21:28:32.671441
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = \
    '''
    This is an example.

    This is a long description.

        This is another example.

        .. deprecated:: 1.0
           Deprecation warning goes here.

    :param param1: This is a parameter.
    :param param2: This is a parameter with a default value.
    :param param3: This is a parameter.
    :type param3: str
    :param param4: This is a parameter.
               this line is considered part of the description.
    :returns: description of returns
    :rtype: str
    :raises keyError: raises description
    :raises ImportError: raises description
    :raises ValueError: raises description
    '''
    text = inspect.cleandoc(text)
    parser = NumpydocParser()

# Generated at 2022-06-11 21:28:49.664727
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def my_function(a: str, b: str = "hi") -> T.List[float]:
        """Short description.

        This is a longer description.

        Parameters
        ----------
        a
            Description of a.
        b
            Description of b, which defaults to "hi".

        Returns
        -------
        list of floats
            The return value.
        """
        pass

    parsed = NumpydocParser().parse(inspect.getdoc(my_function))

    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description is False
    assert parsed.blank_after_long_description is True
    assert parsed.long_description == "This is a longer description."

    assert len(parsed.meta) == 2

# Generated at 2022-06-11 21:29:00.017049
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''\
        Summarize the Duck class here.

        Long description of the Duck class.
        Parameters
        ----------
        param1 : int
            Description of param1

        Returns
        -------
        int
            Description of return value

        Notes
        -----
        Notes about the Duck class.
    '''

# Generated at 2022-06-11 21:29:10.197948
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:17.780150
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This is the short description.

        This is the long description.
        """
    )
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."

    docstring = parser.parse(
        """
        This is the short description.

        This is the long description.
        """
    )
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."


# Generated at 2022-06-11 21:29:29.453505
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    parser = NumpydocParser()
    
    # Teste de descrição longa
    text = 'Summary line.\n\n    Extended description of function.\n        '
    docstring = parser.parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description of function.'

    # Teste de descrição longa com espaços e tabulações no início das linhas
    text = 'Summary line.\n\n    Extended description of function.\n        '
    docstring = parser.parse(text)
    assert docstring.short_description == 'Summary line.'
    assert docstring.long_description == 'Extended description of function.'

    # Teste de descrição longa com espa

# Generated at 2022-06-11 21:29:30.691170
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #TODO: implement
    pass


# Generated at 2022-06-11 21:29:40.401962
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring, DocstringMeta
    docstring = Docstring()
    docstring.short_description = 'a function'
    docstring.long_description = 'with a docstring'
    docstring.blank_after_short_description = False
    docstring.blank_after_long_description = False
    docstring.meta = [
        DocstringMeta(['param', 'test'], 'test', 'test of type test'),
        DocstringMeta(['other_param', 'arg1'], 'some other test', ''),
        DocstringMeta(['warns'], 'not a real warning', 'Warning'),
        DocstringMeta(['attribute'], 'not a description', 'foo.bar')]
    np = NumpydocParser()

# Generated at 2022-06-11 21:29:52.419321
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test parsing parameters
    docstring1 = """
        Parameter1
            Parameter 1 description
        Parameter2 : float, optional
            Parameter 2 description
            Default is 123.456
        Parameter3 : (float, str), optional
            Parameter 3 description
        """

    parameters = NumpydocParser().parse(docstring1).meta["param"]
    assert len(parameters) == 3
    assert parameters[0].arg_name == "Parameter1"
    assert parameters[0].is_optional is False
    assert parameters[0].type_name == None
    assert parameters[0].default == None
    assert parameters[0].description == "Parameter 1 description"
    assert parameters[1].arg_name == "Parameter2"
    assert parameters[1].is_optional is True

# Generated at 2022-06-11 21:30:03.184471
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Parsing test example.
    """
    test_string = """
    Parsing test example.
    
    Parameters
    ----------
    param1 : str
        First parameter.
    param2 : int, optional
        Second parameter, optional.
    """
    parser = NumpydocParser()
    result = parser.parse(test_string)
    assert parser.sections['Parameters'].title == 'Parameters'

# Generated at 2022-06-11 21:30:11.039949
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:27.021655
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:30:36.076230
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = \
    """
    This is the short description.
    
    This is the long description.  The long description
    spans multiple lines.
    
    :param foo: This parameter is deprecated.
        It has the wrong-style name.
    
    :param bar: This parameter is documented properly.
    
    :raises ValueError: This is a short description of the ValueError
        exception.  The description spans multiple lines.
    
    :raises KeyError: This is a short description of the KeyError
        exception.  The description spans multiple lines.
    
    :returns: This is a description of the return value.
    
    """
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "This is the short description."

# Generated at 2022-06-11 21:30:42.922508
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    This is a summary
    :param name: The name to say hello to
    :type name: str
    :param loud: Whether to shout or not
    :type loud: bool
    :returns: The greeting message
    :rtype: str
    """
    docstring = parser.parse(docstring)
    assert docstring.meta[0].args == ['param', 'name']
    assert docstring.meta[1].args == ['param', 'loud']
    assert docstring.meta[2].args == ['returns']



# Generated at 2022-06-11 21:30:55.628314
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : str
         This is arg1.
    arg2 : int
        This is arg2.
    arg3 : str, optional
         This is arg3.

    Returns
    -------
    list
        This is the return value.
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description."

# Generated at 2022-06-11 21:31:06.318783
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d = NumpydocParser().parse("""\
        This is a multi-line description.
        The extra newline at the end should also be stripped.
        The extra newline at the beginning should also be stripped.


        Parameters
        ----------
        x
            Description of x

        y : type
            Description of y

        Returns
        -------
        output

        See Also
        --------
        another_function
        """)
    assert d.short_description == "This is a multi-line description."
    assert d.long_description == "The extra newline at the end should also be stripped.The extra newline at the beginning should also be stripped."
    assert d.meta[0].args[0] == "param"
    assert d.meta[0].args[1] == "x"
    assert d.meta[0].type_

# Generated at 2022-06-11 21:31:18.422001
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:30.413798
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # text = "a\n\nb\n\n\n\nc: d\n\n\ne: f\n\ng: h\n\ni: j\n\n.. k\n\n.. l\n\nm\n\nn"
    text = "l\n\n.. k\n\nc: d\n\nb\n\ne: f\n\ng: h\n\ni: j\n\nm\n\n\n\na\n\nn"
    # print(text)
    parser = NumpydocParser()
    doc = parser.parse(text)
    # print("DOC", doc)
    print("DOC.data", doc.data)
    print("DOC.long_description", doc.long_description)
    print("DOC.short_description", doc.short_description)


# Generated at 2022-06-11 21:31:37.950492
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:31:47.332903
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpy_text = '''This is the docstring for a module.
    Its text is copied from the numpydoc documentation and
    should contain all information how to design docstrings
    as per the rules of numpydoc. The implementation here is
    specifically designed for the case of pandas.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : {'foo', 'bar'}, optional
        The second parameter.
    param3 : str
        The third parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    See Also
    --------
    other_func
    '''
    docstring = NumpydocParser().parse(numpy_text)
    assert len(docstring.meta) == 4

# Generated at 2022-06-11 21:31:56.964718
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  test_text = '''
  test_parse is a test.

  Parameters
    ----------
    name
        name of test
    size
        size of test
  
  Raises
    ------
    KeyError
        if key is not a valid key

  Returns
    -------
    out : type of output
        description of output
  '''

  doc = NumpydocParser().parse(test_text)
  print(f"short_description: {doc.short_description}")
  print(f"long_description: {doc.long_description}")
  print(f"blank_after_short_description: {doc.blank_after_short_description}")
  print(f"blank_after_long_description: {doc.blank_after_long_description}")
  

# Generated at 2022-06-11 21:32:01.873845
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields")


# Generated at 2022-06-11 21:32:07.316631
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param").title == "Parameters"
    assert ParamSection("Parameters", "param").key == "param"
    assert str(type(ParamSection("Parameters", "param").title_pattern)) == "<class 'str'>"
    assert str(type(ParamSection("Parameters", "param").parse(''))) == "<class 'generator'>"


# Generated at 2022-06-11 21:32:16.227162
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    sec = _KVSection('Parameters', 'param')
    text = """
        arg_name
            arg_description
        arg_2 : type
            descriptions can also span...
            ... multiple lines
        arg_3 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    desc = sec.parse(inspect.cleandoc(text))

    assert [tuple(v) for v in desc] == [
        ('param', 'arg_name', 'arg_description', None, None, None),
        ('param', 'arg_2', 'descriptions can also span...\n... multiple lines', 'type', 'type', False),
        ('param', 'arg_3', 'descriptions can also span...\n... multiple lines', 'type', 'type', True)
    ]

# Generated at 2022-06-11 21:32:20.382094
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    result = ReturnsSection("Returns", "returns")
    assert result.__class__.__name__ == 'ReturnsSection'
    assert result.title == "Returns"
    assert result.key == "returns"
    assert result.is_generator == False



# Generated at 2022-06-11 21:32:22.482709
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()
    NumpydocParser([])
    NumpydocParser([Section("1", "2")])


# Generated at 2022-06-11 21:32:33.674409
# Unit test for function parse
def test_parse():
    # No docstring
    assert parse("") == Docstring()

    # Only a short description
    doc = parse("Short description.")
    assert doc == Docstring(
        short_description="Short description.", long_description=None
    )

    # Short and long descriptions
    doc = parse("Short\ndescription.\n\nLong description.")
    assert doc == Docstring(
        short_description="Short description.",
        long_description="Long description.",
    )

    # Short and long descriptions with a blank line before the long description
    doc = parse("Short description.\n\nLong description.")
    assert doc == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
    )

    # Short and long descriptions with multiple blank lines before the long
    #

# Generated at 2022-06-11 21:32:34.680358
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _SphinxSection('title','key')

# Generated at 2022-06-11 21:32:42.678860
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Method description

This is the method description. It can span multiple lines.

Parameters
----------
first : str
    This is the first parameter.
second : str, optional
    This is the second parameter.

Returns
-------
    str
        Some string."""

    ret = parse(text)
    assert ret.short_description == 'Method description'
    assert ret.long_description == 'This is the method description. It can span multiple lines.'
    assert ret.meta[0].args == ['param', 'first']
    assert ret.meta[0].description == 'This is the first parameter.'
    assert ret.meta[1].args == ['param', 'second']
    assert ret.meta[1].description == 'This is the second parameter.'
    assert ret.meta[2].args == ['returns']
    assert ret.meta

# Generated at 2022-06-11 21:32:53.363526
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    doc = NumpydocParser()
    assert doc.sections["Parameters"].title == "Parameters"
    assert doc.sections["Parameters"].key == "param"
    assert doc.sections["Params"].title == "Params"
    assert doc.sections["Params"].key == "param"
    assert doc.sections["Arguments"].title == "Arguments"
    assert doc.sections["Arguments"].key == "param"
    assert doc.sections["Args"].title == "Args"
    assert doc.sections["Args"].key == "param"
    assert doc.sections["Other Parameters"].title == "Other Parameters"
    assert doc.sections["Other Parameters"].key == "other_param"
    assert doc.sections["Other Params"].title == "Other Params"

# Generated at 2022-06-11 21:32:54.869169
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
  a = ReturnsSection("Returns", "returns")

# Generated at 2022-06-11 21:33:02.468190
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """Test to determine if the constructor works in class RaisesSection.
    """
    section = RaisesSection("Raises", "raises")
    assert section.title == "Raises"
    assert section.key == "raises"


# Generated at 2022-06-11 21:33:03.759217
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    param = RaisesSection('Raises', 'raises')
    print(param)

# Generated at 2022-06-11 21:33:08.858036
# Unit test for constructor of class ParamSection
def test_ParamSection():
    Section = ParamSection("Parameters", "param")
    assert Section.title == "Parameters", "Section title parameter is not set correctly"
    assert Section.key == "param", "Section key parameter is not set correctly"
    assert Section.title_pattern == "^Parameters\s*?\n---*$", "Section title_pattern is not set correctly"


# Generated at 2022-06-11 21:33:10.113516
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returnSection = ReturnsSection("name", "returns")
    assert(returnSection.is_generator == False)

# Generated at 2022-06-11 21:33:11.382636
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param").key == "param"


# Generated at 2022-06-11 21:33:16.049490
# Unit test for method parse of class Section
def test_Section_parse():
    S = Section(title='Title', key='key')
    assert list(S.parse(text='foo\n  bar')) == [
        DocstringMeta(args=['key'], description='foo\n  bar')
    ]


# Generated at 2022-06-11 21:33:19.763036
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    if __name__ == '__main__':
        _test = _SphinxSection("test", "key")
        assert _test.title_pattern.find(".. test") != -1

# Generated at 2022-06-11 21:33:30.883281
# Unit test for function parse
def test_parse():
    """
    >>> from pprint import pprint
    >>> docstring = """

# Generated at 2022-06-11 21:33:40.756644
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringReturns, Docstring
    import pprint
    test_str = '''Residuals of the fit (y_true - y_pred)\n\n\nReturns\n-------\nresid : array-like of shape=(n_samples,) or (n_samples, n_outputs)\n    The residuals, also called the residual sum of squares.'''
    p = NumpydocParser()
    doc = p.parse(test_str)
    # pprint.pprint(doc.asdict())
    assert doc.returns[0].description == 'The residuals, also called the residual sum of squares.'
    assert doc.returns[0].type_name == 'resid'

# Generated at 2022-06-11 21:33:42.601415
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    returns = YieldsSection("Yields","Yields")
    assert returns



# Generated at 2022-06-11 21:33:56.944749
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from pydantic.parse import parse_obj_as
    text = """
.. warning:: This method may not be called in Python 2 code.

    It returns a int in Python 2 but an int in Python 3.

.. deprecated:: 1.0
    Use ``.foo`` instead.
"""
    output = parse(text)
    assert parse_obj_as(T.List[T.Dict[str, T.Any]], output.meta) == [{'args': ['deprecation'],
  'description': ' Use ``.foo`` instead.',
  'version': '1.0'}]

# Generated at 2022-06-11 21:33:59.023253
# Unit test for constructor of class Section
def test_Section():
    s = Section("Title", "key")
    assert s.title == "Title"
    assert s.key == "key"


# Generated at 2022-06-11 21:34:06.732077
# Unit test for constructor of class Section
def test_Section():
    sections = [ParamSection("Parameters", "param"),
                Section("Examples", "examples"),
                RaisesSection("Raises", "raises"),
                Section("See Also", "see_also"),
                DeprecationSection("deprecated", "deprecation")]
    print(sections[0].title_pattern)
    print(sections[1].title_pattern)
    print(sections[2].title_pattern)
    print(sections[3].title_pattern)
    print(sections[4].title_pattern)


# Generated at 2022-06-11 21:34:16.006729
# Unit test for function parse
def test_parse():
    text = """
    Function to subtract second argument from first argument.

    Parameters
    ----------
    arg1 : int
        First argument.

    arg2 : int
        Second argument.

    Returns
    -------
    int
        First argument minus second argument.

    """

    test_docstring = parse(text)

    # Test short description is not None
    assert test_docstring.short_description is not None
    # Test short description is correct
    assert test_docstring.short_description == "Function to subtract second argument from first argument."

    # Test long description is not None
    assert test_docstring.long_description is not None
    # Test long description is correct

# Generated at 2022-06-11 21:34:18.237378
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser is not None
    # test default sections
    assert numpydoc_parser.sections == {s.title: s for s in DEFAULT_SECTIONS}


# Generated at 2022-06-11 21:34:29.009326
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = inspect.cleandoc("""
        Summary line here.

        Extended description here.

        Parameters
        ----------
        arg_name : str
            arg_description

        Other Parameters
        ----------------
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Raises
        ------
        ValueError
            A description of what might raise ValueError

        Returns
        -------
        return_name : type
            A description of this returned value
    """)

    p = NumpydocParser()
    d = p.parse(s)
    assert d.short_description == "Summary line here."
    assert d.long_description == "Extended description here."
    assert d.meta[0].args == ["param", "arg_name"]
    assert d.meta[0].description == "arg_description"

# Generated at 2022-06-11 21:34:32.166724
# Unit test for constructor of class Section
def test_Section():
    # Constructor of class Section
    title = "Title"
    key = "key"
    s = Section(title=title,key=key)
    assert s.title == title
    assert s.key == key


# Generated at 2022-06-11 21:34:32.965460
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")

# Generated at 2022-06-11 21:34:40.367746
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = """
    TypeError
        low >= 0
    KeyError
        low == -1
    """
    section = RaisesSection("Raises", "raises")
    res = list(section.parse(text))
    assert (res[0].type_name, res[0].description) == ("TypeError", "low >= 0")
    assert (res[1].type_name, res[1].description) == ("KeyError", "low == -1")



# Generated at 2022-06-11 21:34:41.862679
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert "Returns" in NumpydocParser().sections



# Generated at 2022-06-11 21:34:53.760282
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Testing ParamSection constructor

    # expected result
    expected_title = 'Param'
    expected_key = 'param'

    # test
    test_param = ParamSection(expected_title, expected_key)

    # asserting
    assert test_param.title == expected_title
    assert test_param.key == expected_key
    assert test_param.title_pattern == r'^({})\s*?\n{}\s*$'.format(expected_title, '-' * len(expected_title))


# Generated at 2022-06-11 21:34:58.264169
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("title", "key")
    assert section.title == "title"
    assert section.title_pattern == r"^(title)\s*?\n-*\s*$"
    assert section.key == "key"



# Generated at 2022-06-11 21:35:00.305918
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return1 = ReturnsSection("Returns","returns")
    assert return1.title == "Returns"
    assert return1.key == "returns"

# Generated at 2022-06-11 21:35:04.384976
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "title"
    key = "key"
    sec = _KVSection(title,key)
    title2 = sec.title
    key2 = sec.key
    assert(title == title2 and key == key2)


# Generated at 2022-06-11 21:35:09.582624
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key")
    assert s.title == "title"
    assert s.key == "key"
    assert s.title_pattern == "^{}\\s*?\\n{}\\s*$".format("title", "-" * len("title"))
    

# Generated at 2022-06-11 21:35:20.354972
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    Meta = DocstringMeta
    parser = _KVSection(title='', key='')
    assert list(parser.parse('')) == []
    assert list(parser.parse('key\n    value')) == [Meta([], description='value')]
    assert list(parser.parse('key1\n    value1\nkey2 : type\n    value2')) == [Meta([], description='value1'), Meta([], description='value2')]
    assert list(parser.parse('key1\n    value1\nkey2 : type\nkey3 : type\n    value3')) == [Meta([], description='value1'), Meta([], description='value3')]
    assert list(parser.parse('key : type\n    value\nkey2')) == [Meta([], description='value')]
    assert list

# Generated at 2022-06-11 21:35:31.934057
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:40.780251
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """Unit test for method parse of class _KVSection"""

    test = _KVSection("Parameters", "param")
    assert(inspect.cleandoc("arg_name\n    arg_description") == test.parse(
        inspect.cleandoc("arg_name\n    arg_description")
    )[0].description)
    assert(inspect.cleandoc("arg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines") == test.parse(
        inspect.cleandoc("arg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines")
    )[0].description)
    

# Generated at 2022-06-11 21:35:51.920259
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    f = NumpydocParser().parse

# Generated at 2022-06-11 21:35:54.825180
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"


# Generated at 2022-06-11 21:36:06.753271
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.key == "raises"


# Generated at 2022-06-11 21:36:15.933021
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    from . import numpydoc
    doc = numpydoc.parse(text)

    assert doc.meta[0].args[0] == 'param'
    assert doc.meta[0].args[1] == 'arg_name'
    assert doc.meta[0].description == 'arg_description'
    assert doc.meta[1].args[0] == 'param'
    assert doc.meta[1].args[1] == 'arg_2'
    assert doc.meta[1].description == 'descriptions can also span...\n... multiple lines'
