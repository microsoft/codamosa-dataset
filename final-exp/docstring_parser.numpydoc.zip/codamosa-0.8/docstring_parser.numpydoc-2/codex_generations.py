

# Generated at 2022-06-11 21:26:34.958643
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:26:45.428261
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test case 1
    text1 = """
    This is the short description.

    This is the long description.
    """
    ret1 = NumpydocParser().parse(text1)
    assert ret1.short_description == "This is the short description."
    assert ret1.long_description == "This is the long description."
    assert ret1.blank_after_short_description is False
    assert ret1.blank_after_long_description is False
    assert ret1.meta == list()

    # test case 2

# Generated at 2022-06-11 21:26:55.872879
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:08.213290
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    teststring = """
        Today we are going to learn some numpy.
        I hope you are following me.

        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required

        Other Parameters
        ----------------
        other_arg_1 : int
            An argument that doesn't fit in the other categories.
        other_arg_2
            No type because who cares
    """
    docstring = parse(teststring)
    assert docstring.short_description == "Today we are going to learn some numpy. I hope you are following me."

# Generated at 2022-06-11 21:27:20.316858
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = '''
        Test description
        Long description.

        Parameters
            a: Test
                Test
            c (optional): Test
                Test
            d : Test, optional
                Test
            e : Test, (optional)
                Test
            f : Test, optional(
                Test
            g : Test (optional)
                Test

        Returns:
            Test
    '''
    parsed = parser.parse(doc)
    assert parsed.long_description == 'Long description.'
    assert parsed.short_description == 'Test description'
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.meta
    assert len(parsed.meta) == 15
    assert parsed.meta[1].args[0] == 'param'

# Generated at 2022-06-11 21:27:31.070318
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Unit test for method parse of class NumpydocParser
    def test_NumpydocParser_parse():

        # Test for method parse: no docstring
        def test_parse_no_docstring():
            actual = NumpydocParser().parse("")
            expected = Docstring()
            # We don't care about the order of the members of the Docstring
            # class, but we do care about their values.
            assert actual == expected

        # Test for method parse: regular case
        def test_parse_regular():
            text = """
            Sample docstring.

            Parameters
            ----------
            arg_name : str
                random parameter description

            Other Parameters
            ----------------
            other_param : int, optional
                random other parameter description

            Returns
            -------
            int
                A random return description
            """

# Generated at 2022-06-11 21:27:42.151910
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:27:52.671857
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """

        This is the short description.

        This is the long description.  The long description may contain
        multiple paragraphs.

        Parameters
        ----------
        arg1 : str
            Description of arg1
        arg2, arg3 : int, optional
            Description of arg2.

        .. deprecated:: 0.2.0
            Deprecated in release 0.2.0.

        Returns
        -------
        bool
            Description of return value
    """
    parser = NumpydocParser([])
    parsed_docstring = parser.parse(docstring)

    # Unit test for the short description
    assert parsed_docstring.short_description == "This is the short description."
    assert parsed_docstring.short_description is not None
    assert parsed_docstring.short_description is not ""
    assert parsed_docstring.short

# Generated at 2022-06-11 21:28:03.501277
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    msg = "Unit test for method parse of class NumpydocParser"
    print(msg)

    text = """
        Lorem ipsum dolor sit amet

        :param foo: bar

        Consectetur adipiscing elit

        Returns
        -------
        qux : int
            Say goodbye to foo.
    """
    docstring = parse(text)
    assert docstring.short_description == "Lorem ipsum dolor sit amet"
    assert docstring.long_description == "Consectetur adipiscing elit"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    param = docstring.meta[0]
    assert type(param) == DocstringParam
   

# Generated at 2022-06-11 21:28:11.791993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test if method parse of class NumpydocParser
    """

# Generated at 2022-06-11 21:28:34.167526
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a signature with positional arguments
    some of them have default values.

    Parameters
    ----------
    arg1 : str, optional
        Argument one with a very long description that I need to split
        across multiple lines. The actual argument value is 'default'.
    arg2 : int
        Integer argument two.
    arg3 : str, optional
        Argument three, defaults to None.
    kwarg1 : str
        Keyword-only argument with a default value of 'foobar'.
    kwarg2 : bool
        Keyword-only argument with no default value.
        The description continues on this line after the type annotation.

    Returns
    -------
    str
        Result of the function call.

    Other Parameters
    ----------------
    arg4 : int, optional
        Integer argument four. Totally optional!
    '''

   

# Generated at 2022-06-11 21:28:42.378608
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test function
    def test_func(a, b: int, c: int = 0, d=0, *args, **kwargs) -> int:
        """This is a docstring.

        :param a: This is the first parameter.
        :param b: This is the second parameter.
        :param c: This is the third parameter.
        :param d: This is the fourth parameter.
        :returns: Return value.
        :raises ValueError: Exception raised.
        :raises ValueError: Another exception raised.
        """
        print(a)
        print(b)
        print(c)
        print(d)
        print(args)
        print(kwargs)
    d = NumpydocParser().parse(test_func.__doc__)

# Generated at 2022-06-11 21:28:49.897091
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with pytest.raises(TypeError):
        parse()

    text = ""
    assert parse(text) == Docstring()

    text = "This is the short description.\n"
    assert parse(text) == Docstring(
        short_description="This is the short description."
    )

    text = "This is the short description.\n\n"
    assert parse(text) == Docstring(
        short_description="This is the short description.",
        blank_after_short_description=True,
    )

    text = "This is the short description.\n\nHere is the long description."

# Generated at 2022-06-11 21:29:00.083809
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:29:10.276904
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the docstring of a function.
    And this is the first line of the long description.
    
    .. Parameters::
        param1 : str
            This is the description of `param1`.
        param2 : str, optional
            This is the description of `param2`.
    
    .. Returns::
        return_value : int
            This is the description of the return value.
    """
    expected_short_description = "This is the docstring of a function."
    expected_blank_after_short_description = False
    expected_blank_after_long_description = False
    expected_long_description = "And this is the first line of the long description."
    expected_meta_args_0 = ["parameters", "param1"]

# Generated at 2022-06-11 21:29:17.436729
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Test Docstring
        Description of Test Docstring
        Parameters
        ----------
        arg1: str
            Description of arg1
        arg2: int
            Description of arg2
        arg3, optional
            Description of arg3
        arg4
        Returns:
            bool, a boolean indicating the result of test
        Raises:
            KeyError
                Raised when key is not present
    """
    result = NumpydocParser().parse(text)
    assert result.short_description == 'Test Docstring'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.long_description == 'Description of Test Docstring'
    assert(len(result.meta) == 4)

# Generated at 2022-06-11 21:29:29.292058
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # Return early if docstring is empty
    docstring = parser.parse('')
    assert docstring is not None
    assert docstring.short_description == None
    assert docstring.long_description == None

    # Return early if nothing matches regex pattern
    docstring = parser.parse('no matches')
    assert docstring is not None
    assert docstring.short_description == "no matches"
    assert docstring.long_description == None

    # Test simple matching
    docstring = parser.parse('short_description\n\nWarning\nwarning description')
    assert docstring is not None
    assert docstring.short_description == "short_description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long

# Generated at 2022-06-11 21:29:39.632424
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case = """
    hello world
    Parameters
    ----------
    foo : type
        description
    one : type, optional
        optional description
        """
    parser = NumpydocParser()
    result = parser.parse(test_case)
    assert result.short_description == "hello world"
    assert len(result.meta) == 1
    assert result.meta[0].description == "description"
    assert result.meta[0].type_name == "type"
    assert result.meta[0].arg_name == "foo"
    assert result.meta[0].is_optional is False
    assert result.meta[0].default is None


# Generated at 2022-06-11 21:29:51.852208
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Hello, world!

    Parameters
    ----------
    arg : str
        argument 1

    another_arg : int, optional
        argument 2
    """
    parser = NumpydocParser()
    ret = parser.parse(text)
    assert ret.short_description == "Hello, world!"
    assert ret.long_description == "Parameters\n----------\narg : str\n    argument 1\nanother_arg : int, optional\n    argument 2"
    assert ret.meta[0].args == ['param', 'arg']
    assert ret.meta[1].args == ['param', 'another_arg']


# Generated at 2022-06-11 21:30:02.698028
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        This is a description
        of the function

        Parameters
        ----------
        arg1 : int
            First argument, must be 1
        arg2 : str
            Second argument, with an optional
            default value

        Raises
        ------
        ValueError
            if you pass in an incorrectly-formatted argument
        """

    result = NumpydocParser().parse(text)
    assert len(result.__dict__) == 7
    assert result.short_description == "This is a description"
    assert result.long_description == "of the function"
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 2

    assert result.meta[0].args == ["param", "arg1"]
    assert result.meta[0].description

# Generated at 2022-06-11 21:30:08.604965
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False
    assert ReturnsSection("Yields", "yields").is_generator == True


# Generated at 2022-06-11 21:30:18.651755
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert list(Section("Deprecation warning", ".. title:: Deprecation warning").parse("3.7\n deprecation text")) == [DocstringMeta(["..", "title", "Deprecation", "warning"], description="3.7\n deprecation text")]

    assert list(Section("Deprecation warning", ".. title:: Deprecation warning").parse(" text")) == [DocstringMeta(["..", "title", "Deprecation", "warning"], description=" text")]

    assert list(Section("Deprecation warning", ".. title:: Deprecation warning").parse("\n text ")) == [DocstringMeta(["..", "title", "Deprecation", "warning"], description="\n text ")]

    assert list(Section("Deprecation warning", ".. title:: Deprecation warning").parse("\n text \n"))

# Generated at 2022-06-11 21:30:21.722724
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = DeprecationSection("deprecated", "deprecation")
    parser = NumpydocParser()
    parser.add_section(section)
    assert parser.sections[section.title] == section


# Generated at 2022-06-11 21:30:22.749690
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
	_SphinxSection("a", "b")

# Generated at 2022-06-11 21:30:30.914526
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    _KVSection_text = '''arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines'''
    assert [e.type_name for e in _KVSection(title=None, key=None).parse(_KVSection_text)] == ['type', None, None]
    assert [e.is_optional for e in _KVSection(title=None, key=None).parse(_KVSection_text)] == [True, None, None]


# Generated at 2022-06-11 21:30:32.177724
# Unit test for constructor of class YieldsSection

# Generated at 2022-06-11 21:30:42.988704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    This is the short description

    This is the long description.

    Parameters
    ----------
    arg : str
        This is the parameter description.

    arg_2 : int, optional
        This is the parameter description for optional parameters.

    Returns
    -------
    str
        This is the return description."""

    parsed = parser.parse(docstring)
    assert parsed.short_description == "This is the short description"
    assert parsed.long_description == "This is the long description."
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == True
    param = parsed.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "arg"
    assert param.type

# Generated at 2022-06-11 21:30:47.014740
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    from .common import Docstring

    text = """.. title:: something
        possibly over multiple lines"""

    numpydoc_docstring = NumpydocParser().parse(text)
    assert(isinstance(numpydoc_docstring, Docstring))

# Generated at 2022-06-11 21:30:54.100854
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # default section count
    default_section_count = len(NumpydocParser().sections)
     
    # add new section
    new_section = Section("Author", "author")
    new_parser = NumpydocParser()
    new_parser.add_section(new_section)
    
    # check if the new sections has been added
    assert len(new_parser.sections) == default_section_count + 1

# Generated at 2022-06-11 21:31:00.775065
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text='''
    Parameters
    ----------
    val : int
        A number
    '''
    doc1 = parse(text)
    assert len(doc1._meta) == 1

    doc2 = NumpydocParser().add_section(
        Section("Parameters", "parameter")
    ).add_section(
        Section("Parameters2", "parameter2")
    ).parse(text)
    assert len(doc2._meta) == 2

    doc3 = NumpydocParser(
        [Section("Parameters", "parameter")]
    ).add_section(
        Section("Parameters", "parameter2")
    ).parse(text)
    assert len(doc3._meta) == 1

# Generated at 2022-06-11 21:31:09.213714
# Unit test for constructor of class Section
def test_Section():
    Sections = Section("parameters", "param")
    assert Sections.title == "parameters"
    assert Sections.key == "param"
    assert Sections.title_pattern == "^parameters\\s*?\n-{10}\\s*$"


# Generated at 2022-06-11 21:31:20.225186
# Unit test for constructor of class ParamSection
def test_ParamSection():
    key1 = "param"
    param_desc1 = "arg_description"
    param_name1 = "arg_name"
    param_type1 = "type"
    param_isopt1 = True
    param_def1 = "default_value"

    key2 = "other_param"
    param_desc2 = "arg_description"
    param_name2 = "arg_2"
    param_type2 = "type"
    param_isopt2 = True
    param_def2 = "default_value"

    param_section1 = ParamSection(key1, "name")
    param_section2 = ParamSection(key2, "name")


# Generated at 2022-06-11 21:31:21.337911
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = 'DEPRECATED'
    key = 'deprecated'
    _KVSection(title,key)


# Generated at 2022-06-11 21:31:32.850518
# Unit test for function parse
def test_parse():
    text = """
    Short description

    Long description over multiple
    lines.

    Parameters
    ----------
    arg1 : int
        the first arg
    arg2 : str
        the second arg
    arg3 : float, optional
        the third arg

    Other Parameters
    ----------------
    arg4 : bool
        the fourth arg

    Returns
    -------
    out1 : int
        the first output
    out2 : float
        the second output
    """
    result = parse(text)

# Generated at 2022-06-11 21:31:35.212802
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key").title == "title"
    assert Section("title", "key").key == "key"


# Generated at 2022-06-11 21:31:46.348448
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    This is a test function
    It will do something

    Parameters
    ----------
    arg1: int
        description of arg1
    arg2: str = "test" (optional)
        description of arg2

    Returns
    -------
    str
        description of return value
    """
    parser = NumpydocParser()
    section = ParamSection("Return", "returns")
    parser.add_section(section)
    docstring = parser.parse(text)
    meta = docstring.meta
    assert isinstance(docstring.meta[0],DocstringParam)
    assert meta[0].arg_name == "arg1"
    assert meta[0].type_name == "int"
    assert meta[0].default == None
    assert meta[0].is_optional == False

# Generated at 2022-06-11 21:31:49.979165
# Unit test for constructor of class Section
def test_Section():
    s = Section(title='title', key='key')
    assert s.title == 'title'
    assert s.key == 'key'


# Generated at 2022-06-11 21:32:01.358508
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Text is empty
    assert str(NumpydocParser().parse('')) == str(Docstring())

    # Text is None
    assert str(NumpydocParser().parse(text=None)) == str(Docstring())

    # Text is not correctly formatted
    assert str(NumpydocParser().parse('Name: None\n----------------------\n\n')) == str(Docstring())
    assert str(NumpydocParser().parse('----------------------\n\nName: None\n----------------------\n\n')) == str(Docstring())
    assert str(NumpydocParser().parse('Name: None\n----------------------\n\n----------------------\n\n')) == str(Docstring())

# Generated at 2022-06-11 21:32:11.871126
# Unit test for function parse
def test_parse():

    def f(y: int, *, x: float = 0.0) -> T.List[int]:
        """Some test function.

        :params x: float
            some float parameter
        :params y: float
            some float parameter
        :returns:
            some return statement
        :deprecated:
            deprecated in version 1.0
        :raise ValueError:
            raise ValueError
        :warns  UserWarning:
            warns UserWarning
        :examples:
            Here something happens

        """
        pass

    test_docstring = f.__doc__

    docstring = parse(test_docstring)

    assert docstring.short_description == "Some test function."
    assert docstring.long_description == "Here something happens"
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-11 21:32:18.456818
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    print("Testing _SphinxSection constructor")
    s = _SphinxSection("Parameters", "param")
    print("Testing _SphinxSection.title_pattern")
    print(s.title_pattern)
    s = _SphinxSection("Params", "param")
    print("Testing _SphinxSection.title_pattern with 'Params'")
    print(s.title_pattern)


# Generated at 2022-06-11 21:32:30.780602
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section(title = "deprecated", key = "deprecation")
    text = "1.111\n    description"
    r = [DocstringMeta(args=['deprecation'], description='description', arg_name=None, arg_type=None, arg_is_optional=None)]
    assert s.parse(text) == r



# Generated at 2022-06-11 21:32:33.392995
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key")
    assert s.title == "title"
    assert s.key == "key"

# Unit tests for method Section.title_pattern

# Generated at 2022-06-11 21:32:42.051812
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Testing NumpydocParser.parse")
    assert parse("""
        Simple short description.

        Little bit longer summation.

        Parameters
        ----------
        a_param : int
            Integer parameter.
    """) == Docstring(
        short_description="Simple short description.",
        long_description="Little bit longer summation.",
        meta=[
            DocstringMeta(
                args=["param", "a_param"],
                arg_name="a_param",
                type_name="int",
                is_optional=False,
                description="Integer parameter.",
            )
        ],
    )

# Generated at 2022-06-11 21:32:47.324294
# Unit test for constructor of class Section
def test_Section():
    title1 = 'parameter'
    key1 = 'parameter_name'
    title2 = 'parameter_type'
    key2 = 'parameter_type'
    # test initialization
    assert Section(title1, key1) == Section(title1, key1)
    assert Section(title2, key2) == Section(title2, key2)
    # test title_pattern
    assert Section(title1, key1).title_pattern == r'^(parameter)\s*?\n{}\s*$'.format('-' * len(title1))
    assert Section(title2, key2).title_pattern == r'^(parameter_type)\s*?\n{}\s*$'.format('-' * len(title2))

    #Unit test for function parse()

# Generated at 2022-06-11 21:32:49.031863
# Unit test for constructor of class ParamSection
def test_ParamSection():
    Section("Parameters", "param")
    assert (1==1)


# Generated at 2022-06-11 21:32:50.479580
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser != None


# Generated at 2022-06-11 21:32:52.688450
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    title = "Parameters"
    key = "param"
    assert(NumpydocParser().sections[title].key == key)



# Generated at 2022-06-11 21:32:58.152503
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    
    title = "deprecated"
    key = "deprecation"
    inputs = "0.2\n\nThe function x is deprecated.\n"
    version = "0.2"
    description = "The function x is deprecated."
    assert DeprecationSection(title, key).parse(inputs) == [DocstringDeprecated(args=[key], description=description, version=version)]

# Generated at 2022-06-11 21:33:00.037528
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection


# Generated at 2022-06-11 21:33:05.418507
# Unit test for method parse of class Section
def test_Section_parse():
    numpydoc_parser = NumpydocParser()
    text = '''
            key
                value

            key2 : type
                values can also span...
                ... multiple lines
    '''
    assert numpydoc_parser.parse(text) == {'key': 'value', 'key2':'value'}

# Generated at 2022-06-11 21:33:17.044465
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert len(parser.sections) == 24
    parser.add_section(Section("Testing", "testing"))
    assert len(parser.sections) == 25
    parser.add_section(Section("Testing", "testing2"))
    assert len(parser.sections) == 25



# Generated at 2022-06-11 21:33:23.513860
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
  sec = RaisesSection("Raises", "raises")
  assert sec.title == 'Raises'
  assert sec.key == 'raises'
  assert sec.parse("ValueError\nA description of what might raise ValueError") == (
    DocstringRaises(['raises', 'ValueError'], 'A description of what might raise ValueError', 'ValueError'))


# Generated at 2022-06-11 21:33:25.686628
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Generated at 2022-06-11 21:33:29.619258
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "something"
    key = "foo"

    x = _SphinxSection(title, key)
    assert x.title == title
    assert x.key == key

    parts = ".. title:: something\n\nhello world"
    assert x.title_pattern in parts
    if x.title_pattern in parts:
        assert parts.find(x.title_pattern) == 0

# Generated at 2022-06-11 21:33:35.893430
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("deprecated", "deprecation")
    assert dep.title_pattern == "^\.\.\s*deprecated\s*::"
    #assert dep.parse("0.1\nThis function will be removed in version 1.0") == \
        #DocstringDeprecated(args=['deprecation'], description='This function will be removed in version 1.0', version='0.1')
    #assert dep.parse("") == DocstringDeprecated(args=['deprecation'], description=None, version='')

# Generated at 2022-06-11 21:33:46.050692
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Set up a dummy text to pass through the parser
    text = """
    This line should be ignored.

    This is the short description.

    This is the long description.
    It spans multiple lines.
    And should be concatenated with a newline.

    This is a Parameters section.

    :param name: a str
        This is a description.
        It spans mutliple lines.
        But no empty line should be added after it.
        The parameter name should be parsed as a name.
    :type name: str
    :return: Something

    :type: int
        This should raise an error.

    :return name: Something
        This should raise an error.

    :returns: Something
        This is the return section.
    """
    # Call the parser
    ret = parse(text)

    # Expected results
   

# Generated at 2022-06-11 21:33:57.244544
# Unit test for method parse of class Section
def test_Section_parse():
    # no content after the header
    section = Section("Test", "test")
    doc = section.parse("Test\n----")
    doc_ = DocstringMeta([section.key], description = None)
    assert doc.args == doc_.args
    assert doc.description == doc_.description

    # one line content after the header
    section = Section("Test", "test")
    doc = section.parse("Test\n----\nThis is a test section.")
    doc_ = DocstringMeta([section.key], description = "This is a test section.")
    assert doc.args == doc_.args
    assert doc.description == doc_.description

    # multi-line content after the header
    section = Section("Test", "test")

# Generated at 2022-06-11 21:34:01.159822
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection('title','key').title == 'title'
    assert DeprecationSection('title','key').key == 'key'
    assert DeprecationSection('title','key').parse(text=' 2.0.0\ncode\t\t ') == [DocstringDeprecated(args=['key'], description='code', version='2.0.0')]

# Generated at 2022-06-11 21:34:05.665725
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p1 = ParamSection("Parameters","param")
    assert p1.title == "Parameters"
    assert p1.key == "param"
    assert p1.title_pattern == "^(Parameters)\s*?\n----------\s*$"


# Generated at 2022-06-11 21:34:14.571306
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds = DeprecationSection("deprecated", "deprecation")
    assert ds.title == "deprecated"
    assert ds.key == "deprecation"
    assert ds.title_pattern == r"^\.\.\s*(deprecated)\s*::"
    def parse(text: str) -> T.Iterable[DocstringDeprecated]:
        return ds.parse(text)
    # Unit test for function parse of class DeprecationSection
    # case 1
    yield_value = parse("")
    assert not yield_value
    # case 2
    yield_value = parse("1.0.0\nDeprecated")
    assert [DocstringDeprecated(['deprecation'], None, '1.0.0')] == list(yield_value)
    # case 3
    yield_value

# Generated at 2022-06-11 21:34:28.188729
# Unit test for constructor of class Section
def test_Section():
    obj = Section("Parameters","param")
    assert obj is not None


# Generated at 2022-06-11 21:34:32.422962
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test creation of _KVSection instance
    kvs = _KVSection("Params", "param")
    assert kvs.title == "Params"
    assert kvs.key == "param"
    assert kvs.title_pattern == r'^(Params)\s*?\n---+\s*$'


# Generated at 2022-06-11 21:34:34.291263
# Unit test for constructor of class Section
def test_Section():
    section = Section("Returns", "returns")
    assert section.title == "Returns"
    assert section.key == "returns"


# Generated at 2022-06-11 21:34:45.971720
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np = NumpydocParser()
    assert isinstance(np, NumpydocParser)

# Generated at 2022-06-11 21:34:49.041837
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "test_title"
    key = "test_key"
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == "^\.\.\\s*(test_title)\\s*::"

# Generated at 2022-06-11 21:34:54.745261
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    obj = NumpydocParser()
    text = "another_version\n\na_description"
    res = obj.parse(text)

    assert res.meta[0].args == ['deprecation', 'another_version']
    assert res.meta[0].description == 'a_description'
    assert res.meta[0].version == 'another_version'

# Generated at 2022-06-11 21:34:59.083996
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.is_generator == False
    assert section.key == "returns"
    assert section.title == "Returns"
    assert section.title_pattern == '^Returns\s*?\n-+\s*$'


# Generated at 2022-06-11 21:35:11.075633
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep_sec = DeprecationSection("deprecated", "deprecation")
    assert dep_sec.title == "deprecated"
    assert dep_sec.key == "deprecation"
    assert dep_sec.title_pattern == r"^\.\.\s*deprecated\s*::"
    assert dep_sec.parse("1.1\nThis function is deprecated.") == [DocstringDeprecated(args=['deprecation'],description='This function is deprecated.',version='1.1')]
    assert dep_sec.parse("This function is deprecated.\n1.1") == [DocstringDeprecated(args=['deprecation'],description='This function is deprecated.',version=None)]

# Generated at 2022-06-11 21:35:14.363112
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Generated at 2022-06-11 21:35:21.911155
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parameters
    ----------
    xs : list of int
        List of numbers

    Returns
    -------
    int
        The mean of xs
    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "Parameters"
    assert docstring.long_description == "list of int\n    List of numbers"
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "xs"
    assert docstring.meta[0].description == "List of numbers"
    assert docstring.meta[1].args[0] == "returns"
    assert docstring.meta[1].type_name == "int"

# Generated at 2022-06-11 21:35:56.102265
# Unit test for constructor of class Section
def test_Section():
    # Test basic constructor
    title = "testSection"
    key = "testSectionKey"
    testSection = Section(title, key)
    assert testSection.title == title
    assert testSection.key == key

    # Test for matching title pattern
    assert testSection.title_pattern == "^({})\s*?\n{}\s*$".format(title, "-"*len(title))

    # Test for parsing
    text = "testSectionText"
    assert testSection.parse(text) == [DocstringMeta([key], description=text)]
    assert testSection.parse("") == [DocstringMeta([key], description=None)]


# Generated at 2022-06-11 21:36:00.123638
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    x = DeprecationSection("Deprecation Warning", "deprecated")
    assert x.title == "Deprecation Warning"
    assert x.key == "deprecated"
    assert x.parse(".\n.. Deprecation Warning::\n  1.0.0\n  Description\n")

# Generated at 2022-06-11 21:36:10.699329
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = \
    """
    Parse a numpy-style docstring into its components.

    :param text: docstring text
    :type text: str
    :returns: parsed docstring
    :rtype: Docstring
    """
    assert type(parse(docstring)) == Docstring
    docstring = \
    """
    Parse a numpy-style docstring into its components.

    :param text: docstring text
    :type text: str
    :returns: parsed docstring
    :rtype: Docstring
    :deprecated: 1.0
    """
    assert type(parse(docstring)) == Docstring