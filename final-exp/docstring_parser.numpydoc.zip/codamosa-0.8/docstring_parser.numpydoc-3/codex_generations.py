

# Generated at 2022-06-11 21:26:45.285838
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:26:53.951868
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """NumpydocParser parse method test"""
    docstring = "This is a docstring.\n\nParameters\n----------\na : int\n    This is an int.\n    A second line.\nb : str\n    This is a string.\n\nReturns\n-------\nstr\n    This is what is returned.\n"
    parsed_docstring = NumpydocParser().parse(docstring)
    return parsed_docstring.__dict__

# Generated at 2022-06-11 21:27:02.836430
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection("Sample", "sample")
    sample_text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    result = parser.parse(sample_text)
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0].__dict__ == {'args': ['sample', 'key'], 'description': 'value'}
    assert result[1].__dict__ == {'args': ['sample', 'key2'], 'description': 'values can also span...\n... multiple lines'}


# Generated at 2022-06-11 21:27:07.378415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert(parse("") == Docstring())
    assert(parse("\n") == Docstring())
    assert(parse("\n\n") == Docstring())
    assert(parse("\n\n\n") == Docstring())



# Generated at 2022-06-11 21:27:19.538459
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring, DocstringRaises, DocstringReturns, DocstringMeta
    from .common import DocstringParam, DocstringDeprecated

    def test_numpydoc_docstring(docstring_string: str) -> Docstring:
        parser = NumpydocParser()
        docstring = parser.parse(docstring_string)

# Generated at 2022-06-11 21:27:30.555074
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_docstring_1 = (
    """
    This is a docstring that does not follow any style or convention. There is
    no obvious way for a program to parse it.
    """
    )
    test_docstring_2 = (
    """
    Blah blah blah.

    First para.

    Another para.
    """
    )
    test_docstring_3 = (
    """
    Summary line.

    Extended description.
    """
    )
    test_docstring_4 = (
    """
    Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2
    Returns
    -------
    int
        Description of return value
    """
    )


# Generated at 2022-06-11 21:27:41.307124
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    pattern = re.compile(r'^(?P<key>.*)\s*?\n(?P<value>.*)$', re.MULTILINE)
    kv_str = '''
    key1
        value1
    key2
        value2
    '''
    ls = []
    for match, next_match in _pairwise(pattern.finditer(kv_str)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = kv_str[start:end]
        ls.append((match.group('key'), value))
    assert ls == [('key1', 'value1'), ('key2', 'value2')]

# Generated at 2022-06-11 21:27:52.219091
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # This test case is based on the examples
    class Container:
        def __init__(self, text: str) -> None:
            self.__doc__ = text

        def _get_doc_(self) -> Docstring:
            return parse(text=self.__doc__)


# Generated at 2022-06-11 21:27:58.681522
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    a = "param"
    b = "returns"
    assert a in (NumpydocParser().parse("Returns\n-----\n" + a)).meta[0].args
    assert b in (NumpydocParser().parse("Returns\n-----\n" + b)).meta[0].args
    assert "returns" in (NumpydocParser().parse("Returns\n-----\n" + b)).meta[0].args



# Generated at 2022-06-11 21:28:07.720773
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_text = '''
        我
            只
            是
            不
            过
            生活
        生活
            是
            无
            聊
        无聊
            好吗
            好吗好吗
    '''
    test_text = inspect.cleandoc(test_text)
    from .common import DocstringMeta
    meta_args = [['我','生活','无聊'],['生活','无聊'],['无聊','好吗','好吗好吗']]

# Generated at 2022-06-11 21:28:23.044520
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    text = """ABC
    This is short description
    This is long description
    Parameters
    ----------
    param1 : type
        Arguments description
    :param param2:
        Arguments description
    :type param1: type
        Arguments description
    :raises ValueError:
        Error description
    :returns: Value
    :yields: Value
    :yields: Value
    See Also
    ----------
    Example
    -------
    Example
    -------
    """
    # Exercise
    docstring = NumpydocParser().parse(text)

    # Verify
    assert docstring.short_description == 'This is short description'
    assert docstring.long_description == 'This is long description'
    assert docstring.meta[0].args == ['param', 'param1']

# Generated at 2022-06-11 21:28:35.526172
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:45.377402
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:57.287551
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """Parses a HOCON string.

Parameters
----------
hoconString : string
    a valid HOCON string.

Raises
------
ConfigException
    if the HOCON string is invalid.

Examples
--------
>>> my_obj = HOCONConverter().parse("""

# Generated at 2022-06-11 21:29:03.606107
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = '''
    Some short description

    Some long description
    that spans
    multiple lines

    Parameters
    ----------
    param_1 : type, optional
        some param
    param 2 : another_type, optional
        another param
    param_3 : last_type
        This param does not have a default
    param4 : type, optional
        Default is 'value'

    Attributes
    ----------
    some_attribute : type
        some attribute
    another_attribute
        some attribute without a type

    Returns
    -------
    type
        some returned value
    '''

# Generated at 2022-06-11 21:29:06.429581
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser.parse(None) is not None

test_NumpydocParser_parse()

# Generated at 2022-06-11 21:29:15.573658
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = f"""
    Short description.

    Long description. Can be multiline.

    Parameters
    ----------
    arg_name : str
        arg_description

    arg_2 : int
        arg_2_description

    Returns
    -------
    str
        return_description
    """

# Generated at 2022-06-11 21:29:28.111307
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # The text to be tested
    text = r"""
Loads specified dataset.

Parameters
----------
dataset : str
    Name of dataset to load. Can be either ``'iris'`` or ``'wine'``.

Returns
-------
A tuple ``(X, y)`` where ``X`` is the 2-D array of shape ``(n_samples, n_features)``,
and ``y`` is the 1-D array of shape ``(n_samples,)`` representing the classification target.
"""
    # The expected results

# Generated at 2022-06-11 21:29:38.658095
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Example docstring
    docstring = """
    This is a test function docstring.

    Parameters
    ----------
    first_param : array_like
        The first parameter.
    second_param : int, optional
        The second parameter.

    Returns
    -------
    str
        The return value.
    """
    # Parse docstring
    docstring = NumpydocParser().parse(docstring)
    # Check results
    assert docstring.short_description == "This is a test function docstring."
    assert docstring.long_description == None
    # Check parameter
    assert docstring.meta[0].args == ['param', 'first_param']
    assert docstring.meta[0].type_name == 'array_like'
    assert docstring.meta[0].description == 'The first parameter.'
    # Check

# Generated at 2022-06-11 21:29:51.081248
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:01.899108
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse(__doc__)
    assert docstring.short_description == "Numpydoc-style docstring parsing."
    assert docstring.long_description.startswith(
        ".. seealso:: https://numpydoc.readthedocs.io/en/latest/format.html"
    )
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description



# Generated at 2022-06-11 21:30:10.616175
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:30:11.949950
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import _test_data

    parser = NumpydocParser()
    _test_data.test(parser.parse)

# Generated at 2022-06-11 21:30:13.935212
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse('fun(x, y, z)') == Docstring(short_description='fun(x, y, z)')



# Generated at 2022-06-11 21:30:17.682105
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = 'Sample docstring to test the parse method'
    result = parser.parse(docstring)
    assert result is not None


# Generated at 2022-06-11 21:30:27.083166
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_method = NumpydocParser().parse

    # Ensures that no docstring is returned if text is empty
    assert test_method("") == DocString()

    # Tests the short_description, long_description and blank_after_long_description attributes
    # of the DocString returned
    input_string = """
    This is the short description
    
    This is the long description
    """
    result_string = DocString(
        short_description = "This is the short description",
        long_description = "This is the long description",
        blank_after_short_description = False,
        blank_after_long_description = True,
        meta = [],
    )
    assert test_method(input_string) == result_string

    # Tests the blank_after_long_description attribute of the DocString returned
    input_

# Generated at 2022-06-11 21:30:31.713899
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a description.
    """
    p = NumpydocParser()
    s = p.parse(text)
    assert s.short_description == 'This is a description.'
    assert s.meta == []
    assert s.long_description is None



# Generated at 2022-06-11 21:30:42.462310
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Compute some random data.

    Parameters
    ----------
    arg1 : int
        first argument's description

    arg2 : str, optional (default: 'str')
        second argument's description

    arg3 : None, optional (default: None)
        third argument's description

    Returns
    -------
    some : list
        Description of `some`.
    """
    expected_result = DocstringMeta(['param', 'arg1'], description='first argument\'s description', arg_name='arg1', type_name='int')
    expected_result_2 = DocstringMeta(['param', 'arg2'], description='second argument\'s description', arg_name='arg2', type_name='str', is_optional=True, default='str')

# Generated at 2022-06-11 21:30:55.266472
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:01.808257
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_text = """\

    Parameters
    ----------
    arg_name : str
        arg_description

    arg_2 : type, optional
        description can also span
        multiple lines
    Related
    -------
    say_hi : str
        A function which says hi
    """


# Generated at 2022-06-11 21:31:19.428380
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Intro paragraph.

    Parameters
    ----------
    arg_a : str, optional
        Description of arg_a.

    Returns
    -------
    A return value, optional
        Description of return value.

    Notes
    -----
    Notes go here.
    """

# Generated at 2022-06-11 21:31:31.406711
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    assert parser.parse("").short_description is None

    docstring = parser.parse("short_description")
    assert docstring.short_description == "short_description"

    docstring = parser.parse("short_description\n")
    assert docstring.short_description == "short_description"

    docstring = parser.parse("short_description\nlong_description")
    assert docstring.short_description == "short_description"
    assert docstring.long_description == "long_description"

    docstring = parser.parse("short_description\n\nlong_description")
    assert docstring.short_description == "short_description"
    assert docstring.long_description == "long_description"
    assert docstring.blank_after_short_description == True

    docstring = parser

# Generated at 2022-06-11 21:31:43.571793
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = """
    A short summary
    A long description

    Parameters
    ----------
    arg1 : str
        A description of arg1

    Arguments
    ---------
    arg2 : int, optional
        A description of arg2 with a default of 5

    Returns
    -------
    ret1 : bool
        A description of ret1

    Raises
    ------
    ValueError
        A description of what might raise ValueError

    Warns
    -----
    RuntimeWarning
        A description of what might cause this warning

    Yields
    ------
    ret2 : int
        A description of ret2

    Examples
    --------
    >>> This is an example of what foo() might do
    66

    Notes
    -----
    Here are some notes

    """
    doc = parse(docstr)

# Generated at 2022-06-11 21:31:55.104378
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:06.616766
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import textwrap
    parser = NumpydocParser()
    text = textwrap.dedent("""
        This is a short description.

        This is a long description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str, optional
            Description of arg2.
        arg3 : float
            Description of arg3. Default is 10.0.

        Raises
        ------
        TypeError
            Description of TypeError.
        ValueError
            Description of ValueError.

        Returns
        -------
        str
            Description of return value 1.

        int
            Description of return value 2.

        Examples
        --------
        This is an example.

        Another example.

        See Also
        --------
        Some other function
        """)
    ret = parser.parse(text)

# Generated at 2022-06-11 21:32:15.603412
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    document_example = inspect.cleandoc("""\
    This function will add two numbers

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : int
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """)

    doc_string = Docstring()
    doc_string.short_description = "This function will add two numbers"
    doc_string.long_description = None
    doc_string.blank_after_short_description = True
    doc_string.blank_after_long_description = True

# Generated at 2022-06-11 21:32:21.620478
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # empty docstring
    assert parser.parse("") == Docstring()

    # simple docstring
    assert parser.parse("Short summary.") == Docstring(
        short_description="Short summary.", blank_after_short_description=False
    )

    # docstring with empty long description
    assert parser.parse("Short summary.\n") == Docstring(
        short_description="Short summary.", blank_after_short_description=True
    )

    # simple docstring
    assert parser.parse("Short summary.\n\nLong description.") == Docstring(
        short_description="Short summary.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
    )

    # docstring with empty long description

# Generated at 2022-06-11 21:32:33.210901
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test the docstring parsing
    doc = """Test of docstring parsing.

:param param1: First parameter
:type param1: type1
:param param2: Second parameter
:returns: return type2
    """

    parser = NumpydocParser()
    docstring = parser.parse(doc)
    assert docstring.short_description == "Test of docstring parsing."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    pars = docstring.meta[0].description
    assert pars == "First parameter"
    ptype = docstring.meta[0].type_name
    assert ptype == "type1"
    pars = docstring.meta[1].description

# Generated at 2022-06-11 21:32:41.888770
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("some text") == Docstring(
        short_description="some text",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("some text\n\nWith a long description") == Docstring(
        short_description="some text",
        long_description="With a long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )



# Generated at 2022-06-11 21:32:51.053874
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_str = """\
    This is a numpydoc-style formatted docstring.

    It may contain description in reStructuredText format.
    For example:

    Parameters
    ----------
    arg1 : int
        Param 1 documentation

    arg2 : int
        Param 2 documentation

    Returns
    -------
    str
        A string with the formatted values.
    """
    
    example_docstring = NumpydocParser().parse(example_str)
    assert example_docstring.short_description == "This is a numpydoc-style formatted docstring."
    assert example_docstring.long_description == "It may contain description in reStructuredText format.\nFor example:"
    assert example_docstring.blank_after_short_description == True

# Generated at 2022-06-11 21:33:09.850102
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:18.270897
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse('') == Docstring()
    assert parser.parse('   \t\n\n') == Docstring()

    # Parse description
    docstring_text = 'Some short description.\nCan have multiple lines.'
    assert parser.parse(docstring_text) == Docstring(
        short_description='Some short description.',
        long_description='Can have multiple lines.',
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    # Parse section names and add a new section type
    assert parser.parse('Returns\n--------\nThis is the returns section') == Docstring(
        meta=[DocstringMeta(['returns'], description='This is the returns section')]
    )
    assert parser.parse

# Generated at 2022-06-11 21:33:30.141502
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = """
    Long description

    Parameters
    ----------
    arg_1 : type, optional
        Description
    arg_2 : type
        Description
    other_arg : type or None
        Description
    arg3 : int = 3
        Description
    arg_4 : {'a', 'b', 'c'}, optional
        Description
    arg_5
        Description

    Returns
    -------
    return_1 : type
        Description
    another_return_type
        Description

    Raises
    ------
    ValueError
        Description
    """

    parser = NumpydocParser()
    doc = parser.parse(docstr)

    assert doc.short_description == "Long description"

# Generated at 2022-06-11 21:33:37.838365
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:47.007965
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Args:
        a: an integer.
        b: another integer.
        
        A long description
        
        
        Another long description
    Returns:
        Returns a negative value if ``a < b``, returns a positive value
    if ``a > b``, and returns zero if ``a == b``.
    
    Raises:
        ValueError: If ``a`` or ``b`` are not integers.
    
    Warns:
        UserWarning: If ``a`` or ``b`` are not integers.
    
    .. deprecated:: 3.2
        Will be removed in version 3.3. Use ``do_something()`` instead.
    """
    numpydoc_parser = NumpydocParser()
    docstring = numpydoc_parser.parse(text)
    # verify short_description


# Generated at 2022-06-11 21:33:58.125002
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""\
        test_NumpyDocstringParser_parse

        Single line\
        test_NumpyDocstringParser_parse

        Single line with 
        indent

        Params
        ------
        text (str):
            Docstring text
        Returns
        -------
        Docstring: Parsed docstring
        """
    )

# Generated at 2022-06-11 21:34:09.038770
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    SUM_OF_INTEGERS_DOCSTRING = """
        Sum of integers from the sequence.

        Parameters
        ----------
        sequence : Input Sequence.

        Returns
        --------
        The sum : int
    """

##        sum = 0
##        for i in range(1, N+1):
##           sum = sum + i
##
##        # Return the sum
##        return sum
##
##"""

    def parse_test(docstring):
        doc = NumpydocParser().parse(docstring)
        print("Parsed docstring:", doc)
        print("type(doc) = ", type(doc), "; dir(doc) = ", dir(doc))
        for s in dir(doc):
            print("\t{}".format(getattr(doc, s)))
        print()

# Generated at 2022-06-11 21:34:17.467252
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    long_description = """
    Long description

    Can span multiple lines
    """

    value = """Something else

    And
    more
    things
    """


# Generated at 2022-06-11 21:34:25.241367
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_string = (
        """
        Short description

        Long description

        Parameters
        ----------
        a : ndarray
            this is param ``a``
        b : str
            this is param ``b``

        Returns
        -------
        ndarray
            This is the return value

        """
    )
    docstring = parser.parse(test_string)
    assert docstring.short_description == "Short description"
    assert (
        docstring.long_description
        == "Long description\n\nParameters\n----------\n"
    )

# Generated at 2022-06-11 21:34:31.013672
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d = """
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : type
        Arg 1 description.
    arg2
        Arg 2 description.

    Other Parameters
    ----------------
    arg3 : type, optional
        Arg 3 description.
        It can span multiple lines.

    Raises
    ------
    ValueError
        If `arg1` or `arg2` is invalid.

    Returns
    -------
    type
        Description of the return value.

    Examples
    --------
    >>> func(3)
    "foo"

    See Also
    --------
    other_func : Some other function.
    """

    res = NumpydocParser().parse(d)
    assert res.short_description == "Short description."
    assert res.long_description == "Long description."

# Generated at 2022-06-11 21:34:50.453427
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:56.322209
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # NumpydocParser.parse('') return a Docstring()
    assert NumpydocParser().parse('') == Docstring()
    # NumpydocParser.parse('Test') return a Docstring(short = 'Test')
    assert NumpydocParser().parse('Test') == Docstring(short='Test')
    # NumpydocParser.parse('Test\nTest') return a Docstring(short = 'Test', long = 'Test')
    assert NumpydocParser().parse('Test\nTest') == Docstring(short='Test', long='Test')
    # NumpydocParser.parse('Test1\n\nTest2') return a Docstring(short = 'Test1', long = 'Test2')

# Generated at 2022-06-11 21:35:06.000414
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_string = inspect.cleandoc(
        """
    Tests the parser.
    Parameters
    ----------
    arg1 : str
        You can specify the type here
        and default as well
        default is 123
    Returns
    -------
    foo : str
        description of the return value
        span multiple lines
        if you want
    """
    )

    result = parser.parse(test_string)

    assert result.short_description == "Tests the parser."
    assert result.long_description == "Parameters\n\nReturns"
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False

    assert len(result.meta) == 2

    param1 = result.meta[0]

# Generated at 2022-06-11 21:35:18.310894
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pytest



# Generated at 2022-06-11 21:35:29.948758
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:39.182272
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:35:50.332233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input_string = """
        This my function.

        Parameters
        ----------
        arg1 : int
            The first argument
        arg2 : str
            The second argument

        Returns
        -------
        arg1 * arg2 : str
            The product of ``arg1`` and ``arg2``
    """
    parser = NumpydocParser()
    result = parser.parse(input_string)

# Generated at 2022-06-11 21:36:01.119917
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = parse("""
    short desc

    long desc

    Params
    --------
    a : int
        b

    Returns
    --------
    bool
        c

    Raises
    --------
    ValueError
        d

    Warns
    --------
    TypeError
        e
    """)

    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ['param', 'a']
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[0].is_optional == False
    assert docstring.meta[0].default is None
    assert docstring.meta[0].description == 'b'

    assert docstring.meta[1].args == ['returns']
    assert docstring.meta[1].type_name == 'bool'
   

# Generated at 2022-06-11 21:36:11.242970
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # 1. Test multiple lines
    text = """
    short description

    Parameters
    ----------
    arg : Type
        arg description

    arg2 : Type
        arg description

    arg3 : array_like
        arg description

    Returns
    -------
    float
        arg description
    """
    docstring = parse(text)

    assert len(docstring.meta) == 4
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg"
    assert docstring.meta[0].type_name == "Type"
    assert docstring.meta[0].description == "arg description"
    assert docstring.meta[0].default is None
    assert docstring.meta[0].is_optional == False

# Generated at 2022-06-11 21:36:16.660495
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docdict = parser.parse(ParserTestDoc)
    #print(docdict)



# def main():
#     parser = NumpydocParser()
#     docdict = parser.parse(ParserTestDoc)
#     print(docdict)


# if __name__ == "__main__":
#     main()

# TODO: Parse notes and warnings sections properly,
#       currently, just yields a docstring.meta