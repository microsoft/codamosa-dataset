

# Generated at 2022-06-11 21:26:35.630374
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Short description

    Long description:

        - list of things
        - and another thing


    Parameters
    ----------
    foo : str
        First param.
    bar : int, optional
        Second param that defaults to None.
        Default is 5.
    qux : list
        Third param.

    Returns
    -------
    ret : str
        Return value.
    """
    print([meta.description for meta in parse(docstring).meta])


# Unit test of method add_section of class NumpydocParser

# Generated at 2022-06-11 21:26:46.027889
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection('title', 'key')
    text = 'arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines'
    assert list(section.parse(text)) == [
        DocstringParam(
            args=['key', 'arg_name'],
            description='arg_description',
            arg_name='arg_name',
            type_name=None,
            is_optional=False,
            default=None
        ),
        DocstringParam(
            args=['key', 'arg_2'],
            description='descriptions can also span...\n... multiple lines',
            arg_name='arg_2',
            type_name='type',
            is_optional=True,
            default=None
        )
    ]



# Generated at 2022-06-11 21:26:57.677737
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("").meta == []
    assert parser.parse("func()") == Docstring(short_description="func()")
    
    assert parser.parse("""
    func()
    """) == Docstring(
        short_description="func()",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    
    assert parser.parse("""
    func()
    \n
    """) == Docstring(
        short_description="func()",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-11 21:27:05.688530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str = """
    Parses a numpydoc-style docstring.
    """
    test_dict = {'short_description': 'Parses a numpydoc-style docstring.', 'blank_after_short_description': False, 'long_description': None, 'blank_after_long_description': False, 'meta': []}
    print(NumpydocParser().parse(str))
    return NumpydocParser().parse(str) == test_dict


# Generated at 2022-06-11 21:27:12.885221
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    input_text = """
    This is an example.

    Arguments
    ---------
    a : type
        Long description
    b : optional, type
        Long description
    """
    output_text = [{'name': 'a', 'type_name': 'type', 'is_optional': False, 'default': None},
                    {'name': 'b', 'type_name': 'type', 'is_optional': True, 'default': None}]

    result = []
    ps = ParamSection("Arguments", "param")
    for i in ps.parse(input_text):
        dict = {'name': i.arg_name, 'type_name': i.type_name, 'is_optional': i.is_optional, 'default': i.default}
        result.append(dict)

    assert output_text == result



# Generated at 2022-06-11 21:27:22.852281
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    test 1
        test 2
    test 3 : type
        test 4
        Default is 4
    test 5
        Default is 5
    '''
    ret = NumpydocParser().parse(text)
    assert len(ret.meta) == 5  # parse all the fields
    # test if optional/non-optional fields are parsed correctly
    for i in range(4):
        assert ret.meta[i].is_optional == bool(i % 2), i
    assert ret.meta[4].is_optional == False
    # test if default values are parsed correctly
    for i in range(5):
        assert ret.meta[i].default == (i + 1) * 'test ', i
    return ret

if __name__ == "__main__":
    print(test_NumpydocParser_parse())

# Generated at 2022-06-11 21:27:28.481658
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection(title="Parameters", key="param")
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    it = section.parse(text)
    print([item.as_dict() for item in it])

# Generated at 2022-06-11 21:27:41.130279
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines"""
    kv_section = _KVSection("", "")
    list_of_docstring_meta = list(kv_section.parse(text))
    assert len(list_of_docstring_meta) == 2
    assert list_of_docstring_meta[0].args == ["", "arg_name"]
    assert list_of_docstring_meta[0].description == "arg_description"
    assert list_of_docstring_meta[1].args == ["", "arg_2"]
    assert list_of_docstring_meta[1].description == "descriptions can also span...\n... multiple lines"

# Generated at 2022-06-11 21:27:52.219128
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ("A one-line summary that does not use variable names or the\n"
    "function name.\n\n"
    "Several sentences providing an extended description. Refer to\n"
    "variables using back-ticks, e.g. `var`.\n\n"
    "Parameters\n"
    "----------\n"
    "arg1 : int\n"
    "    Description of `arg1`\n"
    "arg2 : str\n"
    "    Description of `arg2`\n"
    "Returns\n"
    "-------\n"
    "One : boolean\n"
    "    True or False\n"
    "Notes\n"
    "-----\n"
    "This is a line in the notes.\n")
    parser = NumpydocParser

# Generated at 2022-06-11 21:28:02.750586
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Case 1: text = None, expected result: ret = Docstring()
    print("Case 1: text = None, expected result: ret = Docstring()\n")
    text = None
    expected_ret = Docstring()
    verified_ret = NumpydocParser().parse(text)
    print("Result: \n")
    print(verified_ret)
    assert expected_ret == verified_ret, "Test failed"

    # Case 2: text = """
    #                 This is a one-liner.
    #                 """
    #   # Expected result:
    #       ret.short_description = 'This is a one-liner.'
    #       ret.long_description = None
    #       ret.meta = []

# Generated at 2022-06-11 21:28:16.029756
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_text = """
    Params
    ------
    df : Pandas DataFrame
        Dataframe with data to be processed.
    variables : list of str
        List of variable names to be processed
    """

    doc = parse(example_text)
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_long_description
    assert doc.blank_after_short_description
    assert len(doc.meta) == 1
    assert len(doc.meta[0].args) == 2
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "df"

# Generated at 2022-06-11 21:28:25.089145
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    short description

    long description
        with an indented line

    Parameters
    ----------
    param : bool
        blah blah blah
    other_param : int, optional
        this is optional

    Returns
    -------
    bool
        whatever

    """

    doc = parse(text)
    assert doc.short_description == "short description"
    assert doc.long_description == "long description\n    with an indented line"
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 2
    param, returns = doc.meta
    assert param.args == ["param", "param"]
    assert param.description == "blah blah blah"
    assert param.arg_name == "param"

# Generated at 2022-06-11 21:28:36.876649
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test the parse method of class NumpydocParser.
    """
    parser = NumpydocParser()

    docstring = """Short summary.

    Longer summary

    Parameters
    ----------
    x : float64
        x coordinate.
    y : float64
        y coordinate.

    Return
    ------
    float64
        The length of the vector from the origin to point (x, y).

    See Also
    --------
    numpy.docstring : NumPy's docstring formatting guidelines.
    """


# Generated at 2022-06-11 21:28:46.304735
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:28:57.703699
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''The function returns the square root of its argument.
    Parameters
    ----------
    x: ndarray
        the argument
    Returns
    -------
    ndarray
        Square root of `x`.
    '''
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'The function returns the square root of its argument.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'x'
    assert docstring.meta[0].description == 'the argument'
    assert docstring.meta[1].args[0]

# Generated at 2022-06-11 21:29:06.001995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    npdoc = NumpydocParser()
    doc = npdoc.parse("""\
        Parse a string into its components.

        :returns: parsed docstring
    """)
    assert doc.short_description == "Parse a string into its components."
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == [DocstringMeta(args=['returns'], description='parsed docstring')]



# Generated at 2022-06-11 21:29:15.125048
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()

    # Parsing case
    # - param without type but with default value
    # - includes description for the param
    # - includes description for the param
    #

# Generated at 2022-06-11 21:29:28.033748
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
        :param a: Description of a
        :type a: str
        :param b: Description of b
        :type b: str
        :param c: Description of c
        :type c: str
        :return: Description of return
        :rtype: str
    '''
    p = NumpydocParser()
    output = p.parse(text)
    assert len(output.meta) == 4
    assert output.meta[0].args == ['param', 'a']
    assert output.meta[0].description == 'Description of a'
    assert output.meta[1].args == ['param', 'b']
    assert output.meta[1].description == 'Description of b'
    assert output.meta[2].args == ['param', 'c']

# Generated at 2022-06-11 21:29:35.939535
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    method = NumpydocParser()
    print(method.parse("""
    Short description.
    
    Long description.
    
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type
        descriptions can also span...
        ... multiple lines
    
    Other Parameters
    ----------------
    other_param
        other_description
    other_2 : type
        other descriptions can also span...
        ... multiple lines
    
    Raises
    -------
    ValueError
        A description of what might raise ValueError
    """))


# Generated at 2022-06-11 21:29:38.919091
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = 'Default is \n  value.\n\t'
    result = ''
    result = NumpydocParser().parse(doc)
    assert result == 'Default is value.'


# Generated at 2022-06-11 21:29:53.572056
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def _parse_meta(meta: T.List[DocstringMeta]) -> T.Dict[str, T.List[str]]:
        return {
            m.args[0]: [arg for arg in m.args[1:] if arg]
            for m in meta
            if len(m.args) > 0 and m.args[0] != ""
        }

    # no docstring
    assert parse("").meta == []

    # simple docstring
    assert parse("short\n\nlong").short_description == "short"
    assert parse("short\n\nlong").long_description == "long"

    # no long description
    assert parse("short").short_description == "short"
    assert parse("short").long_description is None

    # no short description, only long
    assert parse("\nlong").short_description

# Generated at 2022-06-11 21:30:04.575478
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        This is a short description.

        This is a long description, possibly extending to several lines.

        Parameters
        ----------
        argname : str
            A description of this argument

        args : List[int], optional
            An optional argument, by default is None.

        yield : int

        Returns
        -------
        returnname
            A description of the returned value

        Raises
        ------
        KeyError
            A description of why a ``KeyError`` may be raised.

        Examples
        --------
        >>> print(argname)
            A print of argname, the argument

        See Also
        --------
        The pandas docs
            :ref:`pandas.DataFrame`

        .. deprecated:: 0.2.2
            A description of the deprecation warning
        """
    result = NumpydocParser().parse

# Generated at 2022-06-11 21:30:16.449233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """One line description of some function.

    Longer description which can span multiple lines.

    Parameters
    ----------
    a : type
        A description of ``a`` which can span
        multiple lines.
    b : int, optional
        A description of ``b``.
    """
    parsed_docstring = NumpydocParser().parse(docstring)
    assert(parsed_docstring.short_description == "One line description of some function.")
    assert(parsed_docstring.long_description == "Longer description which can span multiple lines.")
    assert(len(parsed_docstring.meta) == 2)
    assert(len(parsed_docstring.meta[0].args) == 2)
    assert(parsed_docstring.meta[0].args[0] == "param")

# Generated at 2022-06-11 21:30:26.218146
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse('').__dict__ == {'short_description': None, 'long_description': None, 'meta': []}
    assert NumpydocParser().parse(' ').__dict__ == {'short_description': '', 'long_description': None, 'meta': []}
    docstring = NumpydocParser().parse('Hello World!')
    assert docstring.__dict__ == {'short_description': 'Hello World!', 'long_description': None, 'meta': []}
    docstring = NumpydocParser().parse('Hello World!\n\n')

# Generated at 2022-06-11 21:30:35.407152
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:44.996898
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Testcase 1
    test = "Testcase 1"
    test_string = """
    short description

    Example
        >>> example_code
        code_result
    """
    test_string_result = Docstring(
        short_description="short description",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=None,
        meta=[
            DocstringMeta(
                ["examples"],
                description="""
                    >>> example_code
                    code_result
                    """,
            )
        ],
    )
    assert NumpydocParser().parse(test_string) == test_string_result, test

    # Testcase 2
    test = "Testcase 2"

# Generated at 2022-06-11 21:30:51.745763
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    print (parser.parse("""
    Test function to demonstrate wrapping
    of parameters.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : numbers.Real
        The second argument.
    *arg3 :
        The third argument.
    **kwargs :
        Keyword arguments.
    """))
    
    

# Generated at 2022-06-11 21:31:00.388102
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pprint
    from os import path
    from argparse import Namespace
    from docstring_parser import docstring_parser
    import sys
    #Add current path to sys to make test work under jenkins
    sys.path.append(path.abspath(path.join(path.dirname(__file__), '..')))
    #Add docstrings_parser path to sys to make test work under jenkins
    sys.path.append(path.abspath(path.join(path.dirname(__file__), '..', '..', '..', 'docstring_parser')))

    #Test Paths to file
    docstring_parser_file_path = path.join(path.dirname(__file__), '..', '..', '..', 'docstring_parser', 'docstring_parser.py')


# Generated at 2022-06-11 21:31:08.599058
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("") == Docstring()

    docstring = NumpydocParser().parse("""
    This is the short description.

    This is the long description.
    It should be complete sentences,

    This is a valid paragraph.

    This is the second paragraph of the long description.

    The long description may be several paragraphs.
    """)


# Generated at 2022-06-11 21:31:19.879385
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """\
    A description of what this class does

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    type : type, optional
        Description (default is 1)

    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required

    Warnings
    --------
    A warning about something or other

    Examples
    --------
    >>> some_example_code(arg_name=arg_value)
    """
    result = parser.parse(text)
    result = list(result.meta)
    result = [type(x) for x in result]

# Generated at 2022-06-11 21:31:33.960652
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import (
        Docstring,
        DocstringDeprecated,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
    )

    text = """\
    First line of docstring.

    One more line.

    Parameters
    ----------
    param1 : int
        Description of param1.
    param2 : None, optional
        Description of param2.

    Raises
    ------
    ValueError
        Description of what might raise ValueError.
    KeyError
        Description of what might raise KeyError.

    Returns
    -------
    int
        Description of the return value.

    .. deprecated:: 1.0
        Description of deprecation warning.

    """


# Generated at 2022-06-11 21:31:45.619166
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:56.274107
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:59.421105
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(text)
    return docstring

# Generated at 2022-06-11 21:32:08.529603
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    ndp = NumpydocParser()


# Generated at 2022-06-11 21:32:17.139045
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    This is a docstring.

    This is the first sentence of the long description.

    This is the second sentence of the long description.

    Parameters
    ----------
    name : str
        A name.
    optional_param : int, optional
        An optional parameter.

    Other Parameters
    ----------------
    other_param : bool
        Another parameter.

    Attributes
    ----------
    attr : int
        An attribute.

    Returns
    -------
    int
        A return value.

    """

    parser = NumpydocParser()

# Generated at 2022-06-11 21:32:23.851342
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''From a :class:`~abc.ABCMeta` object, you can query the class
                hierarchy and ask if a class is a subclass of another class.
                For example, here we define two classes, `A` and `B`, and
                then ask if `B` is a subclass of `A`.
                >>> class A(metaclass=ABCMeta): pass
                ... class B(A): pass
                ... A.register(tuple)
                ... issubclass(B, A)
                True
                >>> issubclass(tuple, A)
                True
                >>> issubclass(str, A)
                False
                '''
    ret = parse(text)
    print(ret)

# Generated at 2022-06-11 21:32:34.173888
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a short description.

    This is a long description.

    Parameters
    ----------
    a : int
        A parameter.
    b : float, optional
        Another parameter (default is 1.0).

    Returns
    -------
    bool
        Whether to continue.
    '''  
    
    text = inspect.cleandoc(text)
    numpydoc_parser = NumpydocParser()

    # Find first title and split on its position
    match = numpydoc_parser.titles_re.search(text)
    if match:
        desc_chunk = text[: match.start()]
        meta_chunk = text[match.start() :]
    else:
        desc_chunk = text
        meta_chunk = ""

    # Break description into short and

# Generated at 2022-06-11 21:32:42.427597
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    """
    docstring_parser = NumpydocParser()

# Generated at 2022-06-11 21:32:47.645504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is the example function.

    Some more info.

    Parameters
    ----------
    this : this is a type
        this is an explanation
    that : int
        this is a default explanation: 3

    Returns
    -------
    str
        this is an explanation
    """
    docstring = parse(text)
    assert docstring.short_description == "This is the example function."
    assert docstring.long_description == "Some more info."
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "this"
    assert (
        docstring.meta[0].description == "this is an explanation"
    )

# Generated at 2022-06-11 21:32:56.366653
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test all the input and output format
    # 1, test with short and long description, with or without meta keys
    # 2, test with short description only and all meta keys
    # 3, test with long description only and all meta keys
    # 4, test with no description and all meta keys
    # 5, test with short and long description and only some meta keys
    # 6, test with no description and only some meta keys
    # 7, test with only some meta keys

    ## change this to run a single test case
    TEST_CASE = 1


# Generated at 2022-06-11 21:33:03.962653
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Description Comment
    Second Comment
    Parameters
    ----------
    param1: int
        Description of param1.
    param2: str, optional
        Description of param2.
    Returns
    -------
    type
        Description of return value.
    """
    assert parse(text).short_description == "Description Comment Second Comment"
    assert len(parse(text).meta) == 4
    assert isinstance(parse(text).meta[0], DocstringReturns)
    assert isinstance(parse(text).meta[1], DocstringParam)
    assert isinstance(parse(text).meta[2], DocstringParam)
    assert parse(text).meta[0].description == "Description of return value."
    assert parse(text).meta[1].description == "Description of param1."

# Generated at 2022-06-11 21:33:10.066877
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # 1. Test case: text =
    text = """
    docstring

    parameters
    ----------
    docstring

    """

    parser = NumpydocParser()
    result = parser.parse(text)
    expected = Docstring(
        short_description="docstring",
        meta=[
            DocstringMeta(
                args=["parameters"],
                description="docstring",
            )
        ],
    )
    assert result == expected

# Generated at 2022-06-11 21:33:18.422704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()

# Generated at 2022-06-11 21:33:30.191560
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # Check docstring with no sections
    docstring = parser.parse("The short description\n\nThe long description.")
    assert docstring.short_description == "The short description"
    assert docstring.long_description == "The long description."
    assert docstring.meta == []

    # Check docstring with no short description
    docstring = parser.parse("\n\nThe long description.")
    assert docstring.short_description == None
    assert docstring.long_description == "The long description."
    assert docstring.meta == []

    # Check docstring with no long description
    docstring = parser.parse("The short description.")
    assert docstring.short_description == "The short description."
    assert docstring.long_description == None
    assert docstring.meta == []

   

# Generated at 2022-06-11 21:33:37.469545
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from pprint import pprint

    example = """
    This is the ``caption`` of the method.
    The description will span multiple lines.

    Parameters
    ----------
        arg_name : str
            arg_description
        arg_2 : type, optional
            arg_s_description can also span...
            ... multiple lines

    Returns
    -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional, types are required

    Raises
    ------
        TypeError
            A description of what might raise TypeError

    Raises
    ------
        ValueError
            A description of what might raise ValueError
    """

    result = NumpydocParser().parse(example)
    pprint(result)

# Generated at 2022-06-11 21:33:45.097802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import numpydoc
    docstring = """Short description.

    Long description

    Parameters
    ----------
    arg1
        description for arg1
    arg2 : type (optional)
        description for arg2

    Examples
    --------
    >>> example_call() # doctest: +SKIP
    example_output()

    See Also
    --------
    some_callable : some helpful callable
    """
    expected = numpydoc.parse(docstring)
    result = numpydoc.NumpydocParser().parse(docstring)
    assert result == expected
    
    

# Generated at 2022-06-11 21:33:56.386794
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:03.740456
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Calling the main function
    text = """
A short summary of this class

This is a long description of this class. It spans multiple lines,
and should be used to describe the class in detail (what it does, what
that does, etc).

Parameters
----------
thing1 : str
    The first thing.
thing2 : int, optional
    The first thing.

Returns
-------
thing : str
    The first thing.
other_thing : int
    The second thing.
"""
    result = parse(text)
    # Expected result

# Generated at 2022-06-11 21:34:13.480360
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Short summary

    Longer summary

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    """

    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "Short summary"
    assert docstring.long_description == "Longer summary"
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg_name"]
    assert docstring.meta[0].description == \
        "arg_description"
    assert docstring.meta[1].args == ["raises", "ValueError"]

# Generated at 2022-06-11 21:34:25.145080
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:34.599466
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a nice function.

    It does a great job.

    Parameters
    ----------
    x : int
        Number of items to keep.
    y : boolean, optional
        If true, use this formula. Default is False.

    Returns
    -------
    list
        A list of to-keep items.
    '''

# Generated at 2022-06-11 21:34:45.070880
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d_obj = NumpydocParser().parse("""
    Numpydoc-style docstring parsing.

    | seealso:: https://numpydoc.readthedocs.io/en/latest/format.html
    """.strip())
    print(repr(d_obj))
    print(d_obj.raw)
    # print(d_obj.short_description)
    # print(d_obj.long_description)
    # print(d_obj.meta)
    print(d_obj.short_description)
    print(d_obj.long_description)
    print(d_obj.meta)
    print([block.args for block in d_obj.meta])



# Generated at 2022-06-11 21:34:56.169813
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:04.038807
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test 1
    parser = NumpydocParser()
    # f = open("/home/francois/Documents/fjavi_dev/antares3_api/src/helios/antares3/mapper.py", "r")
    # text = f.read()
    # f.close()
    text = """
    Parse the numpy-style docstring into its components.
    """
    docstring = parser.parse(text)
    docstring.short_description == "Parse the numpy-style docstring into its components."
    # test 2
    parser = NumpydocParser()
    text = """
        Parse the numpy-style docstring into its components.

        :returns: parsed docstring
    """
    docstring = parser.parse(text)
    docstring.short_description

# Generated at 2022-06-11 21:35:16.847041
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = '''
    Function to test NumpydocParser class
    
    Arguments:
        param1: type is optional
            Default is None
        param2: type is optional
            Default is None
    Returns:
        int
            A number that is always the same
    '''
    docstring = parser.parse(text)
    assert docstring.short_description == 'Function to test NumpydocParser class'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta[0].args[1] == 'param1'
    assert docstring.meta[0].type_name is None
    assert docstring.meta[0].default is None

# Generated at 2022-06-11 21:35:28.789300
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Short description in one line. Longer description in multiple lines.

    Parameters
    ----------
    arg1 : type
        Description of arg1.
    arg2 : (type1, type2)
        Description of arg2.
    arg3
        Description of arg3.

    Returns
    -------
    return_value : type
        Description of return_value.

    Raises
    ------
    Exception1
        Description of Exception1.
    Exception2
        Description of Exception2.

    Examples
    --------
    >>> print('example')
    example
    '''
    result = NumpydocParser().parse(text)
    assert result.short_description == 'Short description in one line. Longer description in multiple lines.'

# Generated at 2022-06-11 21:35:39.147445
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringMeta, DocstringReturns
    result = NumpydocParser().parse('''\
        hello world

        :param test: test
        :type test: int
        :raises: test
        :returns: test
        :rtype: ints
    ''')
    assert result.short_description == 'hello world'
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert len(result.meta) == 2
    assert result.meta[0] == DocstringMeta(['param', 'test'], 'test', 'int')
    assert result.meta[1] == DocstringReturns(['returns'], 'test', 'ints')

# Generated at 2022-06-11 21:35:50.281645
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """Returns a DataFrame of the same shape as self and whose columns are the values.

    Parameters
    ----------
    function : callable
        Function to apply to each column or row.
    axis : {index (0), columns (1)}
        Axis to iterate over.

    Returns
    -------
    DataFrame
        The transformed DataFrame.
    """
    parsed_docstring = parse(docstring)
    assert parsed_docstring.meta[0].key == "param"
    assert parsed_docstring.meta[0].args == ['param', 'function']
    assert parsed_docstring.meta[0].description == 'Function to apply to each column or row.'
    assert parsed_docstring.meta[1].key == "param"
    assert parsed_docstring.meta[1].args == ['param', 'axis']
   

# Generated at 2022-06-11 21:35:53.476857
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is some text.
    """
    result = parse(text)
    assert result.blank_after_long_description == True


# Generated at 2022-06-11 21:36:07.887256
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = '''
    This is a docstring test.

    Parameters
    ----------
    x: int
        x is an int
    y: str
        y is a str

    Returns
    -------
    z: float
    '''
    parser = NumpydocParser()
    parsed_doc = parser.parse(doc)

    # Check short desc
    assert parsed_doc.short_description == 'This is a docstring test.'

    # Check long desc
    assert parsed_doc.long_description is None

    # Check other properties
    assert parsed_doc.blank_after_short_description
    assert not parsed_doc.blank_after_long_description

    # Check meta
    assert len(parsed_doc.meta) == 2
    assert len(parsed_doc.meta[0].args) == 2
   

# Generated at 2022-06-11 21:36:12.297530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    def test_NumpydocParser_parse(self, text = """
    text += '"""{}"""):\n'.format(text)
    text += """    parser = NumpydocParser()\n        parsed = parser.parse(text)\n        self.assertEqual(parsed, Docstring())"""
    return text