

# Generated at 2022-06-11 21:26:37.266079
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d = Docstring()

# Generated at 2022-06-11 21:26:47.254429
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:26:54.522731
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    string = """
    .. deprecated::
    """
    section = DeprecationSection('deprecation', 'deprecated')
    output = list(section.parse(string))
    assert len(output) == 1
    assert output[0].description == None
    assert output[0].version == None


# Generated at 2022-06-11 21:27:02.729923
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    title = "Deprecated"
    dep_section = DeprecationSection(title, "deprecation")
    text = """explain why it's deprecated
    and when it will get removed
    Version: 1.3
    """
    ret = dep_section.parse(text)
    for i in ret:
        if i.description != "explain why it's deprecated and when it will get removed":
            assert False
        if i.version != "1.3":
            assert False
        if i.args != ["deprecation"]:
            assert False
    assert True

# Generated at 2022-06-11 21:27:09.540321
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    a1 = ".. deprecated:: 1.0.0"
    a2 = "    Overly assertive."
    a3 = "\n"
    aTest1 = DocstringDeprecated(["deprecation"],description="Overly assertive.",version="1.0.0")
    aTest2 = DeprecationSection("deprecated","deprecation").parse(a1+a2+a3)
    assert aTest1 == aTest2[0]


# Generated at 2022-06-11 21:27:20.538816
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = \
    """
    :param arg: short description
    :type arg: int

    long description
    """

    doc = parse(docstring)
    assert doc.short_description == 'short description'
    assert doc.long_description == 'long description'
    assert len(doc.meta) == 1
    assert isinstance(doc.meta[0], DocstringParam)
    param = doc.meta[0]
    assert param.args == ['param', 'arg']
    assert param.description == 'short description'
    assert param.arg_name == 'arg'
    assert param.type_name == 'int'
    assert param.is_optional is None
    assert param.default is None



# Generated at 2022-06-11 21:27:31.093093
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Unit test for method parse of class NumpydocParser.
    """
    np = NumpydocParser()
    ret_1 = np.parse('Short description.\n\nLong description.')
    assert ret_1.short_description is not None
    assert ret_1.long_description is not None

    ret_2 = np.parse('Short description.')
    assert ret_2.short_description is not None
    assert ret_2.long_description is None

    ret_3 = np.parse('Short description.\n\nBoth ``int``.\nLong description.')
    assert ret_3.short_description is not None
    assert ret_3.long_description is not None
    assert len(ret_3.meta) == 0


# Generated at 2022-06-11 21:27:42.151378
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = """The Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

Parameters
----------
param1 : type
    param1's details
param2
    param2's details

Attributes
----------
att1
    att1's details
att2 : type
    att2's detail
"""
    ds = parse(s)

# Generated at 2022-06-11 21:27:52.672293
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:03.490985
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:28:20.096218
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Unit test for method parse of class DeprecationSection"""
    input = inspect.cleandoc("""
    .. deprecated:: 1.9
        This method is deprecated. Use :meth:`.DataFrame.index` or
        :attr:`.DataFrame.index` instead.
    """)
    expected = DocstringDeprecated(args=['deprecation'],
                                   description=inspect.cleandoc("""
    This method is deprecated. Use :meth:`.DataFrame.index` or
    :attr:`.DataFrame.index` instead.
    """),
                                   version='1.9')

    actual = DeprecationSection("deprecated", "deprecation").parse(input).__next__()
    assert actual == expected

# Generated at 2022-06-11 21:28:29.322580
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    docstring_text = '.. deprecated:: 1.3.0\n   Use :func:`foo` instead.'
    section_title = 'deprecated'
    key = 'deprecation'
    expected_DocstringMeta = DocstringMeta(['deprecation'], description='Use :func:`foo` instead.', version='1.3.0')

    # Unit test DeprecationSection.parse
    section = DeprecationSection(section_title, key)
    actual_DocstringMeta = next(section.parse(docstring_text))

    assert(actual_DocstringMeta == expected_DocstringMeta)

# Generated at 2022-06-11 21:28:37.572239
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
        .. deprecated:: 1.2.3
            Some description of the deprecation here.
    """
    text = inspect.cleandoc(text)
    dep_match = re.search('deprecated::\s+(\S+)\s*', text)
    if dep_match:
        version = dep_match.group(1).lstrip()
        desc = inspect.cleandoc(text[dep_match.end():]).strip()
    else:
        desc = None
    assert(version == "1.2.3")
    assert(desc == "Some description of the deprecation here.")


# Generated at 2022-06-11 21:28:43.542013
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_str = ".. deprecated:: 2.3\n    use instead\n"
    test_class = DeprecationSection("deprecated", "deprecation")
    test_result_expected = [DocstringDeprecated(
        args=[test_class.key], description="use instead", version="2.3"
    )]
    test_result_actual = test_class.parse(test_str)

    assert test_result_actual == test_result_expected


# Generated at 2022-06-11 21:28:46.991398
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("Deprecated", "deprecated")
    deprecation_section.parse("""
    deprecation
        This function is deprecated.
    """)



# Generated at 2022-06-11 21:28:52.384481
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    result = DeprecationSection("deprecated", "deprecation").parse(
        "0.11\n Use :func:``pydocstyle.foo`` instead."
    )
    expect = [DocstringDeprecated(args=['deprecation'],
        description="Use pydocstyle.foo instead.", version='0.11')]
    assert list(result) == expect

# Generated at 2022-06-11 21:28:56.675840
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_text = '.. deprecated:: something\n   description'
    test_object = DeprecationSection("deprecated", "deprecation")
    assert(next(test_object.parse(test_text)).description == 'description')


# Generated at 2022-06-11 21:29:00.461616
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    _input = ".. deprecated:: 2.0.0\n\n    A description of deprecation"

    expected = DocstringDeprecated(
        args=["deprecation"], description="A description of deprecation", version="2.0.0"
    )

    actual = NumpydocParser().parse(_input)

    assert actual == expected



# Generated at 2022-06-11 21:29:02.009949
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert str(next(DeprecationSection('Deprecated', 'deprecated').parse('version \n description'))) == "deprecation('Deprecated', version=version, description=description)"

# Generated at 2022-06-11 21:29:06.733221
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():


    parser = NumpydocParser()
    docstr = '.. deprecated:: 0.0.1\n'\
             '\n'\
             '   An old function.\n'
    assert parser.parse(docstr).meta[0].description == 'An old function.'



# Generated at 2022-06-11 21:29:17.877521
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text0 = """
    short description

    long description
        other params

        .. warning::
            Annotations have to include only the :class:`~prince.utils.DfUtils` class
            as it contains methods to handle all data container returned in this module.

    Returns
    -------
    music21.metadata.Metadata
        The Metadata object.
    """
    ds = NumpydocParser().parse(text0)
    assert ds.short_description == 'short description'
    assert ds.long_description == 'long description\nother params\n\n.. warning::\n\n    Annotations have to include only the :class:`~prince.utils.DfUtils` class\n    as it contains methods to handle all data container returned in this module.'

# Generated at 2022-06-11 21:29:22.715801
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the parse method of the NumpydocParser class
    """
    docstring = parse(
        """
        This is a test to check the parse method of the
        NumpydocParser class.

        Parameters
        ----------
        arg_x:
            The x arg is used for testing

        Raises
        ------
        Error
            If the test is a failure

        Returns
        -------
        Nothing
            The test should not return anything
        """
    )

    assert docstring.short_description == "This is a test to check the parse method of the NumpydocParser class."
    assert docstring.long_description == "The x arg is used for testing\n\nIf the test is a failure\n\nThe test should not return anything"




# Generated at 2022-06-11 21:29:28.593264
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(__doc__)
    # There might be a better way to test this but this seems to work
    assert(docstring.long_description == "Numpydoc-style docstring parsing.\n"
                         "\n"
                         ".. seealso:: https://numpydoc.readthedocs.io/en/"
                         "latest/format.html")

# Generated at 2022-06-11 21:29:39.031581
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydocparser = NumpydocParser()
    numpydocparser.parse("a\n -------\n a\n \n b\n -------\n b\n  \n")
    numpydocparser.parse("a\n -------\n a\n \n b\n")
    numpydocparser.parse("a\n -------\n a\n \n")
    numpydocparser.parse("a\n -------\n a\n \n b\n -------\n b\n -------\n b\n  \n")
    numpydocparser.parse("a\n -------\n a\n \n b\n -------\n b\n -------\n b\n  \n -------\n c\n  \n")
    numpydocparser.parse("a")
    nump

# Generated at 2022-06-11 21:29:50.584970
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("test_NumpydocParser_parse")
    raw = """
    Test function

    Parameters
    ----------
    some_param : int
        Description
    another_param : int
        Description

    Raises
    ------
    RuntimeError
        Description

    Returns
    -------
    return : int
        Description
    another_return : int
        Description

    Example
    -------

    Source:
        <https://github.com/numpy/numpy/blob/v1.16.1/numpy/lib/type_check.py#L602>
    """
    ds = parse(raw)
    print(ds.__dict__)


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:29:51.512062
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass



# Generated at 2022-06-11 21:30:02.379036
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    n_parser = NumpydocParser()

# Generated at 2022-06-11 21:30:10.675852
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class DummySection(Section):
        def parse(self, text):
            yield DocstringMeta([self.key, "1"], description="1.1")
            yield DocstringMeta([self.key, "2"], description="1.2")
            yield DocstringMeta([self.key, "3"], description="1.3")

    parser = NumpydocParser()
    parser.add_section(DummySection("Dummy", "dummy"))
    doc = parser.parse(
        """
        Short Description

        Long Description line 1
        Long Description line 2

        Dummy
            1.1
        Dummy
            1.2
        Dummy
            1.3

        """
    )

    assert doc.short_description == "Short Description"

# Generated at 2022-06-11 21:30:16.221428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = '''
    Return metadata on the variables in a file.

    Parameters
    ----------
    filename : str
        The name of the file.

    Returns
    -------
    metainfo : dict
        A dictionary with the keys 'meta', 'var_name', 'var_type', 'count',
        'shape', 'size', 'nbytes', 'chunks', 'chunksizes', 'filters',
        'fletcher32', 'dimensions', 'attrs' and 'groups'.  The values are
        arrays with the same length as the number of variables in the file.  The
        value of the key 'groups' is a list of all groups in the file.
    '''

    result = parse(docstring)

# Generated at 2022-06-11 21:30:26.052754
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:30:37.042355
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	parser = NumpydocParser()

	assert parser.parse('') == Docstring()

	assert parser.parse('Function a\n') == Docstring(
		short_description='Function a',
		blank_after_short_description=False,
		blank_after_long_description=False,
		long_description=None,
		meta=[]
	)

	assert parser.parse('Function a\n\nFunction b\n') == Docstring(
		short_description='Function a',
		blank_after_short_description=True,
		blank_after_long_description=False,
		long_description='Function b',
		meta=[]
	)


# Generated at 2022-06-11 21:30:48.034993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Some function.

Some longer description which spans multiple lines.

Parameters
----------
arg1 : arg type
    arg description
arg2 : arg, optional
    arg description
    can span multiple lines.
arg3 : arg
    arg description
    default is 5.

Raises
------
TypeError
    if something bad happens.
ValueError

Returns
-------
None"""
    result = NumpydocParser().parse(text)
    assert(isinstance(result, Docstring))
    assert(result.short_description == "Some function.")
    assert(result.blank_after_short_description == False)
    assert(result.blank_after_long_description == True)
    assert(result.long_description == 'Some longer description which spans multiple lines.')

# Generated at 2022-06-11 21:30:58.328644
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = '''This function is used to report test status.

Parameters
----------
report_id : int
    This is the ID of the test report.
case_name : str
    This is a string of the test case name
result : str
    This is the result of the test, can only be 'PASSED'/'FAILED'
message : str
    This is a message to record the log message.
    This field can contain multiple lines by using '\\n' as linebreak

Example
-------
    from xtf_utils.xtf_util import XtfReport
    XtfReport.report(1, "pkt_capture", "PASSED", "This is a test message")
    '''
    assert isinstance(parse(text), Docstring)

# Generated at 2022-06-11 21:31:07.800060
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test for method parse of class NumpydocParser
    """
    docstring: str = inspect.cleandoc('''
        The title of your function
        -----------------------

        The purpose of your function


        Parameters
        ----------
        val : int
            a dummy parameter

        Other Params
        ------------
        arg : int
            another dummy parameter

        Notes
        -----
        This is an example of a numpydoc format docstring, which comes in
        handy when using sphinx to generate documentation.

        Returns
        -------
        int
            some return value

        Raises
        ------
        ValueError
            If something went wrong with the operation.
    ''')

    parser: NumpydocParser = NumpydocParser()
    parse_res: Docstring = parser.parse(docstring)
   

# Generated at 2022-06-11 21:31:19.427622
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = """
    Short description.

    Long description.

    Parameters
    ----------
    foo : int
        Description of foo.
    bar, baz : float, optional
        Description of bar, baz.
    qux : array_like
        Description of qux.
    quux : str
        Description of quux.

    Returns
    -------
    out : int
        Description of the return.

    Raises
    ------
    ValueError
        If something is wrong.

    Examples
    --------
    Examples can be given using either the ``Example`` or ``Examples``
    sections. Sections support any reStructuredText formatting, including
    literal blocks::

        #>>> x, y = 1, 2
        #>>> x, y = y, x
    """
    parsed = parser.parse

# Generated at 2022-06-11 21:31:31.446917
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:38.667944
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = r"""
    Calculate the chowder of your dreams.

    Parameters
    ----------
    a_clam : int
        Number of clams in your chowder.
    a_fish : string
        Name of the fish in your chowder.
    clam_to_fish_ratio : float, optional
        Proportion of clams to fish in your chowder.

    Notes
    -----
    This document was described using numpy-style docstrings.
    """

# Generated at 2022-06-11 21:31:46.113507
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:31:56.707504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    ds = """
        Multiply a and b.

        Parameters
        ----------
        a : int
            The first number.

        b : int, optional
            The second number. Defaults to 2.

        Returns
        -------
        int
            The product of a and b.
    """
    ps = NumpydocParser()

    parsed_ds = ps.parse(ds)
    assert parsed_ds.short_description == 'Multiply a and b.'
    assert parsed_ds.long_description is None
    assert parsed_ds.blank_after_short_description is True
    assert parsed_ds.blank_after_long_description is False

    assert parsed_ds.meta is not None
    assert len(parsed_ds.meta) == 3

    param = parsed_ds.meta[0]

# Generated at 2022-06-11 21:32:07.793728
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class Test:
        def __init__(self):
            self.numpydoc = NumpydocParser()
    test = Test()
    doc = test.numpydoc.parse(text='')
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.meta == []
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False


# Generated at 2022-06-11 21:32:21.144872
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    # Example docstrings taken from the numpydoc documentation
    # https://numpydoc.readthedocs.io/en/latest/format.html

    # Example 1
    text = """Does something really important.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    bool
        True if everything is ok.

    """
    # The asserts are in the docstring, so that the documentation is correct
    # In the unit test, we just call the function for coverage.
    docstring = parser.parse(text)
    assert docstring.short_description == 'Does something really important.'
    assert docstring.long_description is None

# Generated at 2022-06-11 21:32:32.817802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # no title
    test_text = """\
    This is a docstring.

    Mainly in one line.

    Not much to say.
    """
    result = parse(test_text)
    assert result.short_description == 'This is a docstring.'
    assert result.long_description == 'Mainly in one line.\n\nNot much to say.'
    assert len(result.meta) == 0

    # no short description
    test_text = """\
    Parameters
    ----------
    x
        A parameter.
    """
    result = parse(test_text)
    assert result.short_description is None
    assert len(result.meta) == 1
    assert result.meta[0].args == ['param', 'x']
    assert result.meta[0].arg_name == 'x'

# Generated at 2022-06-11 21:32:41.590146
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	parser = NumpydocParser()
	doc = parser.parse("""First Line
			Second Line
			
				Description of function

			Parameters:
			----------
				arg1 : type
					description of arg1
				return: type
					description of return value
				
			Warnings:
			-----------
				description of warnings""")
	assert(doc.short_description == "First Line")
	assert(doc.long_description == 'Second Line\n\n				Description of function')
	assert(doc.blank_after_short_description == True)
	assert(doc.blank_after_long_description == False)

# Generated at 2022-06-11 21:32:50.868584
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:32:57.244701
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import __version__
    from . import __doc__
    from . import __author__
    parser = NumpydocParser()
    docstring = parser.parse(__doc__)
    assert docstring.short_description == "Module for numpydoc docstring format."
    assert docstring.long_description
    assert docstring.meta[2].args == ['param', 'text']
    assert docstring.meta[2].type_name == 'str'


# Generated at 2022-06-11 21:33:00.746053
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    """
    assert NumpydocParser().parse(text).__dict__ == \
        Docstring().__dict__



# Generated at 2022-06-11 21:33:11.772842
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:33:24.881308
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is a short description.

    This is a long
    description.

    Parameters
    ----------
    x : str
        This is x.
    y : str
        This is y.

    Returns
    -------
    str
        The concatenation of x and y.

    Other Parameters
    ----------------
    z : str, optional
        This is z.  Defaults to "z".
    """
    doc = parse(text)
    expected = """This is a short description.

This is a long
description.

Parameters
----------
x : str
    This is x.
y : str
    This is y.

Returns
-------
str
    The concatenation of x and y.

Other Parameters
----------------
z : str, optional
    This is z.  Defaults to "z".
"""

   

# Generated at 2022-06-11 21:33:35.104424
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a docstring example.
    It has a single, mandatory positional argument (name) and
    a keyword argument.
    There is no return value.

    Parameters
    ----------
    name : type
        The name of the person.

    value : int
        The person's age.  Default is 0.

    Raises
    ------
    TypeError
        If name is not a string.
    '''
    result = NumpydocParser().parse(text)
    assert result.short_description == 'This is a docstring example.'
    assert len(result.meta) == 4
    assert result.meta[0].args == ['param', 'name']
    assert result.meta[0].type_name == 'type'
    assert result.meta[0].is_optional == False

# Generated at 2022-06-11 21:33:45.775018
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  input_text = """\
    This is the short description.

    This is the long description.  It can span multiple lines.

    Parameters
    ----------
    param1
        The first parameter.
    param2 : int
        The second parameter with type.

    Returns
    -------
    return_type
        Description of return value.

    Other Parameters
    ----------------
    kw1 : {'option1', 'option2'}
        Keyword with fixed options.
    kw2 : int, optional
        Another optional keyword with type.
    """
  expected_short_desc = "This is the short description."
  expected_blank_after_short_desc = False
  expected_long_desc = "This is the long description.  It can span multiple lines."
  expected_blank_after_long_desc = True
  expected_docstring

# Generated at 2022-06-11 21:33:56.239993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
        args: list of numpy arrays
            The list of numpy arrays to be processed.
        buffer_size: int
            Optional buffer size. If not specified,
             default is used.
        attribute: type
            Description of the attribute.
        returns:
            Description of the return type.
        """

    text_long = """\
        args: list of numpy arrays
            The list of numpy arrays to be processed.
        buffer_size: int
            Optional buffer size. If not specified,
             default is used.
        attribute: type
            Description of the attribute.
        returns:
            Description of the return type.
            """


# Generated at 2022-06-11 21:34:03.662911
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class WithNumpyDoc:
        """
        Parameters
        ----------
        a: type
            a argument
        b : type
            b argument
            b's description over multiple lines
        Returns
        -------
        c : type_c
            c's description
        Raises
        ------
        NameError
            When variable name is not defined
        AttributeError
            When we try to assign variable to name
        """

        def __init__(self, a, b):
            self.a = a
            self.b = b

        def some_method(self):
            return self.a

        def some_other_method(self):
            raise NameError("some message")

        def some_third_method(self):
            self.a.some_attr = 1

    doc = parse(inspect.getdoc(WithNumpyDoc))

# Generated at 2022-06-11 21:34:10.153880
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    This is unit test for method parse of class NumpydocParser.
    """
    from .numpydoc import parse

    st = '''
    ::

        The long description of the function.
    '''
    d = parse(st)
    assert d.long_description == 'The long description of the function.'
    # test if no docstring
    assert len(parse('').meta) == 0



# Generated at 2022-06-11 21:34:18.006226
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class testNumpydocParser(NumpydocParser):
        def __init__(self):
            super(testNumpydocParser, self).__init__()

    def test_empty_input():
        text = ""
        parser = testNumpydocParser()
        assert parser.parse(text).short_description == None
        assert parser.parse(text).long_description == None
        assert parser.parse(text).meta == []

    def test_empty_description_input():
        text = """
Parameters
----------
    """
        parser = testNumpydocParser()
        assert parser.parse(text).short_description == None
        assert parser.parse(text).long_description == None

    def test_short_description_input():
        text = "A short description"
        parser = testNumpydocParser()

# Generated at 2022-06-11 21:34:25.403132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-11 21:34:34.692268
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:34:46.173803
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Positive test case
    test_docstring = """A test docstring
    with two lines

    Parameters
    ----------
    test : str
        A test parameter.
    """
    parsed_docstring = parse(test_docstring)
    assert parsed_docstring.short_description == "A test docstring with two lines"
    assert parsed_docstring.long_description is None
    assert parsed_docstring.meta[0].description == "A test parameter."
    assert parsed_docstring.meta[0].type_name == "str"
    assert parsed_docstring.meta[0].arg_name == "test"
    assert parsed_docstring.meta[0].is_optional is False

    # Negative test case

# Generated at 2022-06-11 21:34:56.836983
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-11 21:35:04.278183
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
        A sweet docstring with a bunch of stuff in it. Should be long enough to
        qualify as such.

        Parameters
        ----------
        :param foo: some sort of foo
        :type foo: int
        :param bar: a sometype of bar
        :type bar: str, optional
        :param baz: a sort of baz with a default of True
        :rtype: bool, default=True

        Returns
        -------
        int
            returns something

        Raises
        ------
        ValueError
            if something bad happens

        Warns
        -----
        RuntimeWarning
            if something else bad happens

        Warns
        -----
        DeprecationWarning
            if even worse badness happens

        Other Stuff
        -----------
        This is just a freeform thing.
        '''
    docstring = N

# Generated at 2022-06-11 21:35:12.496727
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """\
    This is a docstring.

    This is the longer description.

    Parameters
    ----------
    argument : type
        The first argument.
    argument2 : type
        The second argument.

    Returns
    -------
    int
        The return value.

    See Also
    --------
    otherfunc : Related function
    thirdfunc : Another related function
    """
    doc = parser.parse(text)
    print(doc.__dict__)


# Generated at 2022-06-11 21:35:29.260700
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print('Executing test_NumpydocParser_parse...')
    import os
    import json
    import pytest

    TEST_DIR = os.path.abspath(os.path.dirname(__file__))
    JSON_FILE = os.path.join(TEST_DIR, "numpydoc.json")

    with open(JSON_FILE) as f:
        test_cases = json.load(f)

    def parse_and_compare(test_case: dict) -> None:
        doc = NumpydocParser().parse(test_case["doc"])
        for key in doc.data:
            assert getattr(doc, key) == test_case["expected"][key]
        for key in doc.meta:
            assert getattr(doc, key) == test_case["expected"][key]

# Generated at 2022-06-11 21:35:35.810630
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This function does something.

    Parameters
    ----------
    arg1 : str
        The first argument.
    arg2 : int, optional
        The second argument.

    Returns
    -------
    bool
        Description of return value.

    References
    ----------
    Something here.
    """
    d = NumpydocParser().parse(text)
    print(d.meta)
    print(d.meta[0].description)

if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-11 21:35:42.643992
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
    """This is a test docstring.

    This code checks if the parse method is working properly. This method should also be able to 
    read and parse the following:

    Parameters:
    -----------
    arg1 : type
        arg1 description, can also be multi-line.
    arg2 (optional) : type
        arg2 description, this time ending with optional.
    arg3 : type
        arg3 description, default is 'test'.
    arg4 : type, optional
        arg4 description, default is 'test' and being optional.

    Returns:
    --------
    return1
        return1 description, no return name specified.
    return2 : type
        return2 description, return name and type specified.
    """
    )

# Generated at 2022-06-11 21:35:54.650680
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    ndp = NumpydocParser()
    docstring = ndp.parse('test_method\nsome descriptions')
    assert docstring.meta == []
    assert docstring.short_description == 'test_method'
    assert docstring.long_description == 'some descriptions'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    text = '''
    test_method

    parameters:

    c:
        c, should also be treated as param

    d:
        d, should also be treated as param, default is 1
    '''
    docstring = ndp.parse(text)
    assert len(docstring.meta) == 2

    param_c = docstring.meta[0]
    assert isinstance(param_c, DocstringParam)


# Generated at 2022-06-11 21:36:04.523845
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    """
    assert parser.parse(text) == Docstring()

    text = "with a description"
    expected = Docstring(short_description = 'with a description',
                         long_description = None,
                         blank_after_short_description = False,
                         blank_after_long_description = False,
                         meta = [])
    assert parser.parse(text) == expected

    text = """
    with a description

    with a long description
    """
    expected = Docstring(short_description = 'with a description',
                         long_description = 'with a long description',
                         blank_after_short_description = False,
                         blank_after_long_description = False,
                         meta = [])
    assert parser.parse(text) == expected


# Generated at 2022-06-11 21:36:15.073204
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = '''
    first line (short description)
    second line (long description)
    :param arg_name: arg_description
    :param arg_2: arg_2_description
    :returns: return_description
    :deprecated: version
        deprecation_description
    :raises TypeError: raises_description
    '''
    docstring = parser.parse(docstring)