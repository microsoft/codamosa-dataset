

# Generated at 2022-06-25 16:23:43.193180
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    expected = str('KV_REGEX.finditer(text)')
    actual = _KVSection('', '')._parse_item('', '')
    assert expected == actual


# Generated at 2022-06-25 16:23:53.448867
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = 'r'
    str_1 = '\x16+\x11$\x0f\x1a\x07'
    section_0 = _KVSection(str_0, str_1)
    dict_0 = dict()
    dict_0[str_1] = str_0
    dict_0[str_1] = str_0
    dict_0[str_0] = str_1
    dict_0[str_1] = str_0
    dict_0[str_1] = str_0
    dict_0[str_1] = str_1
    dict_0[str_0] = str_1
    dict_0[str_0] = str_1
    dict_0[str_1] = str_1

# Generated at 2022-06-25 16:23:58.042790
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = 'LNF77sM*VaB9D0/WS].'
    section_0 = Section(str_0, str_0)
    section_0.parse(str_0)

# Generated at 2022-06-25 16:24:05.049982
# Unit test for method parse of class Section
def test_Section_parse():
    str_0 = 'LNF77sM*VaB9D0/WS].'
    section_0 = Section(str_0, str_0)
    text_0 = 'LNF77sM*VaB9D0/WS].'
    assert (section_0.parse(text_0) is None)


# Generated at 2022-06-25 16:24:08.422289
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    docstring = """
        Parameters
        ----------
        arg
            description
        arg2
            description
        """
    parser = NumpydocParser()
    parsed = parser.parse(docstring)
    assert parsed.meta[0].args == ["param", "arg"]
    assert parsed.meta[1].args == ["param", "arg2"]



# Generated at 2022-06-25 16:24:10.117490
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    str_0 = '1.1.0\n    A description of what might raise ValueError'
    DeprecationSection.parse(str_0)



# Generated at 2022-06-25 16:24:15.105742
# Unit test for method parse of class Section
def test_Section_parse():
    text_0 = 'eR(WkI!_Yj$&oOvH0'
    section_0 = Section(text_0, text_0)
    docstringmeta_0 = section_0.parse(text_0)
    assert (docstringmeta_0 == [DocstringMeta(['eR(WkI!_Yj$&oOvH0'], 'eR(WkI!_Yj$&oOvH0')])


# Generated at 2022-06-25 16:24:19.610721
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'LNF77sM*VaB9D0/WS].'
    numpydocparser_0 = NumpydocParser()
    numpydocparser_0.add_section(section_0)
    docstring_1 = numpydocparser_0.parse(str_0)


# Generated at 2022-06-25 16:24:23.448872
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Test DeprecationSection: parse"""
    obj = DeprecationSection('arg1', 'arg2')

    returned = obj.parse('arg1')
    assert returned
    assert returned[0].description == None
    assert returned[0].version == 'arg1'

    returned = obj.parse('')
    assert returned


# Generated at 2022-06-25 16:24:27.451408
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    title_0 = '4>@}Uh%u'
    text_0 = 'G7iK?`X}[7b'
    deprecation_section_0 = DeprecationSection(title_0, title_0)
    deprecation_section_0.parse(text_0)


# Generated at 2022-06-25 16:24:43.101605
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = 'Docstring text'
    ret = NumpydocParser().parse(docstring)
    assert ret is not None


# Generated at 2022-06-25 16:24:52.467949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    input_str_1 = """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg_1 : str
            Description of `arg_1`

        arg_2 : int, optional
            Description of `arg_2`, defaults to 1

        Returns
        -------
        str
            Description of return value.
    """

# Generated at 2022-06-25 16:25:03.185855
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # docstring below is the equivalent of

    # """
    #     A function.

    #     Args:
    #         x: the X value
    #     """,
    docstring = """
A function.

Args:
    x: the X value
"""

    result = NumpydocParser().parse(docstring)

    # Check for the relevant fields
    assert result

    # args
    assert result.meta[0].args[0] == "args"
    assert result.meta[0].args[1] == "x"

    # short_description
    assert result.short_description == "A function."

    # long_description
    assert result.long_description == "A function."

    # blank_after_short_description
    assert result.blank_after_short_description == True

    # blank_after

# Generated at 2022-06-25 16:25:14.076867
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring, DocstringParam, DocstringReturns
    docstring = """
    Another quick docstring example.

    Parameters
    ----------
    param1 : float
        Description of param1
    param2 : str, optional
        Description of param2
    param3 : Optional[float]
        Description of param3

    Other Parameters
    ----------------
    param3 : float
        Description of param3

    Raises
    ------
    ValueError
        If something goes wrong

    Returns
    -------
    Tuple[float, str]
        A tuple of two things

    Yields
    ------
    float
        A floating point value
    """

# Generated at 2022-06-25 16:25:21.865755
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    if numpydoc_parser_0 is not None:
        str_0 = "  This is some text.\n"
    if numpydoc_parser_0 is not None:
        docstring_0 = numpydoc_parser_0.parse(str_0)


# Generated at 2022-06-25 16:25:32.148919
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    str_0 = "str_0"
    docstring_0 = numpydoc_parser_0.parse(str_0)
    str_1 = "str_1"
    numpydoc_parser_0.parse(str_1)
    # Test case 1
    # Test case 1
    str_2 = "str_2"
    str_3 = "str_3"
    docstring_1 = numpydoc_parser_0.parse(str_3)
    str_4 = "str_4"
    numpydoc_parser_0.parse(str_4)
    # Test case 2
    # Test case 2
   

# Generated at 2022-06-25 16:25:37.910250
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    """Test method parse of class NumpydocParser"""
    docstring = """This function adds two numbers

    Parameters
    ----------
    a: int, optional
        the first number
    b: int, optional
        the second number

    Returns
    -------
    int
        the result of the addition
    """
    assert numpydoc_parser_0.parse(docstring = docstring) == Docstring()


# Generated at 2022-06-25 16:25:49.435448
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("") == Docstring()
    assert numpydoc_parser_0.parse("    ") == Docstring()
    assert numpydoc_parser_0.parse("\n\n") == Docstring()
    assert numpydoc_parser_0.parse("   \n  \n") == Docstring()
    assert (
        numpydoc_parser_0.parse("   This is a description\n  \n")
        == Docstring(
            short_description="This is a description",
            blank_after_short_description=False,
            long_description=None,
            blank_after_long_description=False,
            meta=[],
        )
    )

# Generated at 2022-06-25 16:26:02.845240
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_2 = numpydoc_parser_1.parse(
        """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of `arg1`

        arg2 : str
            Description of `arg2`

        Returns
        -------
        int
            Description of return value

        """
    )

# Generated at 2022-06-25 16:26:14.570231
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc("""
        Foo bar.

        Parameters
        ----------
        x : int
            x parameter
        y : float
            y parameter
        z : str
            z parameter

        Raises
        ------
        ValueError
            On failure
    """)

    dd = numpydoc_parser_0.parse(text)
    # print(json.dumps(dd, indent=2))

    assert dd.short_description == 'Foo bar.'
    assert dd.long_description is None
    assert dd.blank_after_short_description is False
    assert dd.blank_after_long_description is False

    assert len(dd.meta) == 2
    for i in range(2):
        assert dd.meta[i].args == ['param']

# Generated at 2022-06-25 16:26:23.507100
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        numpydoc_parser_0 = NumpydocParser()
        numpydoc_parser_0.parse('')
    except:
        print('Test case failed')


# Generated at 2022-06-25 16:26:29.018467
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydocparser = NumpydocParser()
    numpydocparser.parse(text='Some string')
    docstring = numpydocparser.parse(text='Some string')
    assert docstring.short_description == 'Some string'

# Generated at 2022-06-25 16:26:35.100844
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:26:37.061298
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:26:41.956148
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_2 = None
    expect_retval_3 = None

    actual_retval_4 = numpydoc_parser_1.parse(text_2)

    assert actual_retval_4 == expect_retval_3, "Test case failed. Expected: {}, Actual: {}".format(expect_retval_3, actual_retval_4)


# Generated at 2022-06-25 16:26:55.197306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """Parses a numpydoc-style docstring.

Parameters
----------
text : str
    the text to parse

Returns
-------
obj : Docstring
    the parsed docstring
"""
    numpydoc_docstring_0 = numpydoc_parser_0.parse(text_0)
    assert numpydoc_docstring_0.short_description == "Parses a numpydoc-style docstring."
    numpydoc_docstring_meta_0 = numpydoc_docstring_0.meta[0]
    assert numpydoc_docstring_meta_0.args == ['param', 'text']

# Generated at 2022-06-25 16:27:07.499618
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = '''
Test.

.. deprecated:: 3.2
   This is deprecated.

Parameters
----------
arg1
    description
arg2 : str
    description

Returns
-------
type
    description
'''
    test_case_0()
    test_case_1()
    res = parse(doc)
    assert res.short_description == 'Test.'
    assert len(res.meta) == 7
    assert res.meta[0].args == ['param', 'arg1']
    assert res.meta[0].description == 'description'
    assert res.meta[1].args == ['param', 'arg2']
    assert res.meta[1].description == 'description'
    assert res.meta[1].type_name == 'str'
    assert res.meta[2].args == ['returns']

# Generated at 2022-06-25 16:27:15.909885
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    string_0 = '''
    This is a docstring with one line of description and no sections.
    '''
    docstring_0 = numpydoc_parser_0.parse(string_0)
    assert docstring_0.short_description == 'This is a docstring with one line of description and no sections.'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:27:28.082306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import sys
    import platform

    # must call the method with self
    if platform.system() == "Windows":
        file = "C:/Users/Algotree/OneDrive - University of North Carolina at Chapel Hill/Documents/engr401/"
    elif platform.system() == "Darwin":
        file = "/Users/Algotree/OneDrive - University of North Carolina at Chapel Hill/Documents/engr401/"
    else:
        file = "/home/goloschokin/engr401/"
    sys.stdout = open(file + "test_cases/test_output/test_NumpydocParser_parse_output.txt", "w")

    print("Test case 0:")

# This is the main function

# Generated at 2022-06-25 16:27:40.550120
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    global numpydoc_parser_0
    text = "hello"
    result = numpydoc_parser_0.parse(text)
    assert result.short_description == "hello", \
        "Parse docstring error: self.short_description: %r != %r" % (
            result.short_description, "hello")
    assert result.long_description is None, \
        "Parse docstring error: self.long_description: %r != %r" % (
            result.long_description, None)
    assert len(result.meta) == 0, \
        "Parse docstring error: len(self.meta): %r != %r" % (
            len(result.meta), 0)

if __name__ == "__main__":
    numpydoc_parser_0 = Numpydoc

# Generated at 2022-06-25 16:27:55.887460
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring =  """
    This is a short description.

    And this is a long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    arg_3 : default = 1
        descriptions can also span...
        ... multiple lines
    another_arg
        another_arg_description
    another_arg_2 : type
        another_arg_2_description
    """
    ret = numpydoc_parser_1.parse(docstring)
    assert isinstance(ret,Docstring)
    assert ret.short_description == "This is a short description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after

# Generated at 2022-06-25 16:27:56.470073
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-25 16:28:04.102650
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('Short description.\n\nLong description.')
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:28:13.271065
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # setup
    numpydoc_parser_1 = NumpydocParser()

    # input args
    text_2 = None

    # expected results
    assert_1 = None

    # method to test
    results_1 = numpydoc_parser_1.parse(
        text_2
    )

    # compare results
    assert results_1 == assert_1

    # setup
    numpydoc_parser_2 = NumpydocParser()

    # input args
    text_3 = ""

    # expected results
    assert_2 = None

    # method to test
    results_2 = numpydoc_parser_2.parse(
        text_3
    )

    # compare results
    assert results_2 == assert_2

    # setup
    numpydoc_parser_3 = Numpyd

# Generated at 2022-06-25 16:28:18.985829
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    s = """
        Parses text and returns a Docstring.
        """
    docstring_0 = Docstring()
    docstring_0.short_description = "Parses text and returns a Docstring."
    docstring_0.blank_after_short_description = True
    docstring_0.meta = []
    assert numpydoc_parser_0.parse(s) == docstring_0


# Generated at 2022-06-25 16:28:32.331020
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # NumpydocParser: instance of NumpydocParser
    numpydoc_parser = NumpydocParser()

# Generated at 2022-06-25 16:28:41.720790
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "str -> str\n\n" + """Test
    function.
""".strip()
    got = numpydoc_parser_0.parse(text)
    assert got.long_description == """Test
    function.""".strip()
    assert got.blank_after_long_description is True
    assert got.short_description == "Test Function"
    assert got.meta[0].description == "Test\n    function.".strip()
    assert got.blank_after_short_description is True
    assert got.meta[0].args[0] == "returns"


# Generated at 2022-06-25 16:28:49.877353
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_obj_0 = NumpydocParser()
    docstring_str_0 = parse.__doc__
    docstring_obj_0 = numpydoc_parser_obj_0.parse(docstring_str_0)
    docstring_obj_1 = Docstring()
    docstring_obj_1.long_description = 'Parse the numpy-style docstring into its components.\n\n    :returns: parsed docstring'
    docstring_obj_1.short_description = 'Parse the numpy-style docstring into its components.'
    assert(docstring_obj_0 == docstring_obj_1)


# Generated at 2022-06-25 16:29:01.315921
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_1 = NumpydocParser({'Parameters': Section(title='Parameters', key='param')})
    numpydoc_parser_2 = NumpydocParser({'Parameters': ParamSection(title='Parameters', key='param')})
    numpydoc_parser_3 = NumpydocParser({'Parameters': RaisesSection(title='Parameters', key='raises')})
    numpydoc_parser_4 = NumpydocParser({'Parameters': ReturnsSection(title='Parameters', key='returns')})
    numpydoc_parser_5 = NumpydocParser({'Parameters': YieldsSection(title='Parameters', key='yields')})

# Generated at 2022-06-25 16:29:11.523443
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'foo\nbar\n'
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == 'foo'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is None
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:29:30.188916
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import DocstringMeta, DocstringReturns, DocstringRaises
    from .common import DocstringParam, DocstringDeprecated

    test_text = """
    Test a docstring with a short description, long description,
    and meta section.

        Parameters
        ----------
        a
            A parameter with a somewhat
            long description that spans
            multiple lines.
        b: str
            Another parameter.

        Returns
        -------
        result : int
            Return value
    """

    result = NumpydocParser().parse(test_text)
    assert result.short_description == "Test a docstring with a short "\
        "description, long description,\nand meta section."

# Generated at 2022-06-25 16:29:41.460505
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    txt = """docstring of a function.
    """
    docstring = numpydoc_parser.parse(txt)
    assert docstring.short_description == 'docstring of a function.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == None
    assert docstring.meta == []

    txt = """docstring of a function.
    This is the long description of the docstring
    """
    docstring = numpydoc_parser.parse(txt)
    assert docstring.short_description == 'docstring of a function.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description

# Generated at 2022-06-25 16:29:52.392492
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    res_Docstring = numpydoc_parser_0.parse(text=None)
    assert isinstance(res_Docstring, docstrings.Docstring) == True
    assert docstrings.inconsistent(res_Docstring, 0) == False
    assert docstrings.inconsistent(res_Docstring, 1) == False
    assert docstrings.inconsistent(res_Docstring, 2) == False
    assert docstrings.inconsistent(res_Docstring, 3) == False
    assert docstrings.inconsistent(res_Docstring, 4) == False
    assert docstrings.inconsistent(res_Docstring, 5) == False
    assert docstrings.inconsistent(res_Docstring, 6) == False
    assert docstrings.inconsistent

# Generated at 2022-06-25 16:29:57.119825
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case for parsing a docstring without a title
    text = """
    This is a docstring without a title
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring without a title"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0

    # Test case for parsing a docstring with a title
    text = """
    This is a docstring with a title
    """
    docstring = parse(text)
    assert docstring.short_description == "This is a docstring with a title"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False


# Generated at 2022-06-25 16:30:10.249212
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-25 16:30:12.894685
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # [0] Setup
    # [] Run
    # [] Verify
    pass

# Generated at 2022-06-25 16:30:23.914024
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """\
    This is a description.

    Parameters
    ----------
    x : int
        The x parameter
    """

    result_expected = Docstring(
        description='This is a description.\n    ',
        short_description='This is a description.',
        blank_after_short_description=True,
        meta=[
            DocstringMeta(
                args=["param", "x"],
                description='The x parameter',
                arg_name="x",
                type_name="int",
                is_optional=False,
            )
        ],
    )

    result_actual = NumpydocParser().parse(docstring)
    assert result_actual == result_expected, \
        f"Expected: {result_expected}\nActual: {result_actual}"



# Generated at 2022-06-25 16:30:34.259024
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Ensure that the parser is producing expected results

    """
    # Set up data
    text1 = """This is a numpy style docstring test of the method parse.

    Parameters
    ----------
    key_0 : int
        Description of key_0
    key_1 : str, optional
        Description of key_1. Default is 'value'

    Returns
    -------
    ret : bool
        True on success
    """

    text2 = """This is a numpy style docstring test of the method parse
    with no parameters list.

    Returns
    -------
    ret : bool
        True on success
    """

    text3 = """This is a numpy style docstring test of the method parse
    with a deprecation warning.

    version_0.0.1
        This version is deprecated
    """


# Generated at 2022-06-25 16:30:44.196695
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    case_0_string_input = """
    Simple example function with types documented in the docstring.
    Parameters
    ----------
    param1: int
        The first parameter.
    param2: int, optional
        The second parameter.
    Returns
    -------
    string
        A description of what was returned.
    """

    case_0_result = NumpydocParser().parse(case_0_string_input)


# Generated at 2022-06-25 16:30:57.369852
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:10.318117
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_docstring = """
    docstring text
    """
    docstring = numpydoc_parser_0.parse(test_docstring)
    print(docstring)
    assert docstring.short_description == "docstring text"


# Generated at 2022-06-25 16:31:22.953629
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = """\
    example_func(arg1, arg2,
                arg3=val1, arg4='val2', arg5=None,
                arg6=('tuple value "with quotes"',),
                arg7=((1, 2), (3, 4)),
                arg8={'key': 'value'},
                arg9=True, arg10=False)

    Returns:
        A useful value.

    Raises:
        ValueError: If `arg1` is equal to or less than 0.
    """

    docstring: Docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "example_func(arg1, arg2,"


# Generated at 2022-06-25 16:31:32.004071
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import inspect
    from goodtablesio.parsers.numpydoc import parse
    from goodtablesio.parsers.numpydoc import NumpydocParser

    # Test parsing a docstring with no sections
    test_docstring_0 = '''A short description.

    And a longer one.
    '''
    assert parse(test_docstring_0) == Docstring(
        short_description='A short description.',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description='And a longer one.',
        meta=[]
    )

    # Test parsing a docstring with a single section

# Generated at 2022-06-25 16:31:37.656618
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "\n        testing\n        """
    result_0 = numpydoc_parser_0.parse(text_0)
    assert result_0.__class__ == Docstring

# Generated at 2022-06-25 16:31:49.394447
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 =  """This is a docstring;
    multiline...

    Parameters
    ----------
    arg1 : str
        a string argument
    arg2 : int
        an integer argument

    Returns
    -------
    str
        a string"""
    docstring_0 = numpydoc_parser_0.parse(str_0)
    str_1 =  """This is\n    a docstring;\n    multiline...\n\n    Parameters\n    ----------\n    arg1 : str\n        a string argument\n    arg2 : int\n        an integer argument\n\n    Returns\n    -------\n    str\n        a string"""
    assert str_1 == str(docstring_0)
    str

# Generated at 2022-06-25 16:31:51.182480
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()


# Generated at 2022-06-25 16:31:57.325244
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:32:09.708318
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:32:15.397495
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numdocparser = NumpydocParser()
    with open("./tests/test_numpydoc_parser/test_case_0.txt") as f:
        s = f.read()
        result = numdocparser.parse(s)
        # assert result.summary == "A test function"
        assert result.short_description == "A test function"
        assert result.long_description == "This is a test function"


if __name__ == "__main__":
    test_case_0()
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:32:27.096785
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:32:56.162170
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_1 = """
A short description.

A longer description.
"""
    docstring_0 = numpydoc_parser_0.parse(str_1)
    str_2 = docstring_0.short_description
    assert str_2 == "A short description."
    str_3 = docstring_0.long_description
    assert str_3 == "A longer description."
    bool_0 = docstring_0.blank_after_short_description
    assert bool_0 == True
    bool_1 = docstring_0.blank_after_long_description
    assert bool_1 == True
    assert docstring_0.meta == []



# Generated at 2022-06-25 16:33:02.198659
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Set up test case
    text = """
    # Docstring for "method foo" in class A.

    Short description of class A.

    Long
    description of class A.
    Can span multiple lines.

    Parameters
    ----------
    arg1:
        Description of arg1.
    arg2: int, optional
        Description of arg2.
        Default is 4.
    other_arg:
        Description of other_arg.

    Returns
    -------
    int
        Description of return value.
        Can span multiple lines.
        Default is 42.

    Raises
    ------
    ValueError
        If ...
    """

    numpydoc_parser_0 = NumpydocParser()
    # Invoke method
    output = numpydoc_parser_0.parse(text)
    # Check output