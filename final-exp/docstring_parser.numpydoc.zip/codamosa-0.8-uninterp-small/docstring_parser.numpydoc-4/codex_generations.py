

# Generated at 2022-06-25 16:23:47.979571
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
        This is a description.
        Parameters
            param1 : int
                description for param1
            param2 : str
                description for param2
        Returns
            returns : tuple
                description for return
        Raises
            ValueError
                if something is wrong
        """)

    assert docstring.short_description == "This is a description."
    assert docstring.long_description is None

    assert len(docstring.meta) == 4

    assert docstring.meta[0].key == "param"
    assert docstring.meta[0].args == ["param", "param1"]
    assert docstring.meta[0].description == "description for param1"

    assert docstring.meta[1].key == "param"

# Generated at 2022-06-25 16:23:58.397009
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = inspect.cleandoc(
"""Synopsis 
========

This is a synopsis.

Description
===========

This is a description.

Parameters
==========

param_1
    param_1 description.
param_2(optional)
    param_2 description.
"""
    )
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "Synopsis"
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == inspect.cleandoc(
    """This is a synopsis.

    Description
    ===========

    This is a description.
    """
    )
    assert docstring_0.blank

# Generated at 2022-06-25 16:24:01.481238
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_meta_0 = numpydoc_parser_0.parse('    str : object\n\n        Return (str(object)).')
    print(docstring_meta_0)


# Generated at 2022-06-25 16:24:11.245536
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    A short description.

    A long description can span
    multiple
    lines.

    Parameters
    ----------
    arg_name : type, optional
        a description for arg_name. This
        can span multiple lines.
    arg2 : str
        also optional, also has default.
        Default is "foo".
    arg3 : bool, optional
        Also has default.
        Default is True.
    arg4 : None
        Also has default.
        Default is None.
    arg5 : None, optional
        Also has default.
        Default is None.
    arg6 : None, optional(optional)
        Also has default.
        Default is None.

    Yields
    ------
    str
        A description of the yielded item.
    int
        A description of another yielded item.
    """

# Generated at 2022-06-25 16:24:23.811980
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ' a string '
    assert numpydoc_parser_0.parse(text_0).short_description == "a string"

    # Creation of tuple 'docstring_meta_0'
    docstring_meta_0 = (
        DocstringMeta([], description="a string"),
    )

    # Creation of tuple 'docstring_0'
    docstring_0 = (
        Docstring(
            short_description="a string",
            long_description=None,
            meta=docstring_meta_0,
        ),
    )
    assert numpydoc_parser_0.parse(text_0) == docstring_0[0]

    # Creation of tuple 'docstring_meta_1'

# Generated at 2022-06-25 16:24:36.908861
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'yolo'
    Docstring_0 = numpydoc_parser_0.parse(text_0)
    assert Docstring_0.long_description == None
    assert Docstring_0.short_description == 'yolo'
    assert Docstring_0.blank_after_long_description == False
    assert Docstring_0.blank_after_short_description == False
    text_1 = 'yo lo'
    Docstring_1 = numpydoc_parser_0.parse(text_1)
    assert Docstring_1.long_description == None
    assert Docstring_1.short_description == 'yo lo'
    assert Docstring_1.blank_after_long_description == False
    assert Docstring_1.blank_

# Generated at 2022-06-25 16:24:46.581929
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    method_name = "parse"
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    assert numpydoc_parser_0.parse(text_0) == parse(text_0)

    test_case_0()
    numpydoc_parser_0.parse(text_0)



# Generated at 2022-06-25 16:24:56.707827
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_1 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('\n    This is a docstring.\n    \n    It contains a short description, a long description,\n    and a number of sections.\n    ')
    docstring_1 = numpydoc_parser_1.parse('Look, a docstring!')
    docstring_meta_0 = DocstringMeta(['notes'], description='Notes:\n\n    This is a paragraph of notes.\n    ')
    docstring_meta_1 = DocstringMeta(['warns'], description='Warnings:\n\n    This is a paragraph of warnings.\n    ')
    docstring_meta_

# Generated at 2022-06-25 16:25:09.946439
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:25:19.078618
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    func_with_numpydoc_0 = Docstring()
    func_with_numpydoc_0.short_description = "  \n"
    func_with_numpydoc_0.long_description = None
    func_with_numpydoc_0.blank_after_short_description = True
    func_with_numpydoc_0.blank_after_long_description = False

# Generated at 2022-06-25 16:25:40.099498
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(ParamSection("Params", "params"))
    numpydoc_parser.add_section(ReturnsSection("Returns", "returns"))

    text = """Returns the 2-D gaussian kernel.

    The gaussian kernel is used to smooth an image.

    Args:
        sigma : float
            Standard deviation of the gaussian filter.
        size : int
            Size of the filter.

    Returns:
        A 2D gaussian kernel
            lalal
    """

    docstring = numpydoc_parser.parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Returns the 2-D gaussian kernel."

# Generated at 2022-06-25 16:25:48.440334
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # setup
    numpydoc_parser = NumpydocParser()
    # Test data:
    text = '''
    I'm a text without sections
    '''
    # Exercise
    res = numpydoc_parser.parse(text)
    # Verify
    assert res.meta == []
    assert res.short_description == "I'm a text without sections"
    assert res.long_description == None
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == False
    # Teardown


# Generated at 2022-06-25 16:25:52.652358
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Call method parse on object numpydoc_parser_0
    assert callable(getattr(numpydoc_parser_0, "parse"))
    try:
        assert numpydoc_parser_0.parse(text="") == Docstring()
    except Exception as e:
        raise Exception(
            f"NumpydocParser.parse(text='', **kwargs) raised {type(e)}"
        ) from e

# Generated at 2022-06-25 16:26:05.171237
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:26:16.064121
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''
        summary

        longer description which can
        span multiple lines
    '''
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert(docstring_0.short_description == "summary")
    assert(docstring_0.long_description == "longer description which can\nspan multiple lines")
    assert(docstring_0.blank_after_short_description == True)
    assert(docstring_0.blank_after_long_description == False)
    assert(len(docstring_0.meta) == 0)


# Generated at 2022-06-25 16:26:29.075350
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    numpydoc_parser = NumpydocParser()

# Generated at 2022-06-25 16:26:32.565531
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """The velocity in the x-direction, :math:`v_x`."""
    docstring = numpydoc_parser_0.parse(text)
    if(docstring.long_description ==  """The velocity in the x-direction, :math:`v_x`."""):
        return True
    else:
        return False


# Generated at 2022-06-25 16:26:42.748477
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_1 = "/**\n   Test....\n\nparam foo: anno...\n\n   more text\n*/"
    assert numpydoc_parser_0.parse(text_1) == Docstring(
        short_description="Test....",
        long_description="param foo: anno...\n\n   more text",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param", "foo"], description="anno...", type_name=None
            )
        ],
    )

# Generated at 2022-06-25 16:26:47.627580
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = test_case_0()
    assert numpydoc_parser_0.parse("") == ""



# Generated at 2022-06-25 16:26:56.261237
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:11.683134
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("")
    assert docstring_0.meta == []
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.format == None

# Generated at 2022-06-25 16:27:20.564303
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    example_docstring = """single line

first line of long description
second line of long description

Parameters
----------
param : str
    Description for `param`.

returns : int (optional)
    Description for `returns`.

Raises
------
ValueError
    Description for `ValueError`.
"""

# Generated at 2022-06-25 16:27:23.418834
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = Docstring()
    assert numpydoc_parser_0.parse("") == docstring_0


# Generated at 2022-06-25 16:27:36.811420
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()

    # line 1 of docstring
    # line 2 of docstring
    # """
    # Example 1
    # ---------
    #
    # """
    try:
        assert numpydoc_parser_0.parse("""line 1 of docstring\nline 2 of docstring""") == \
               parse("""line 1 of docstring\nline 2 of docstring""")
    except:
        print("TEST FAILED:", parse("""line 1 of docstring\nline 2 of docstring"""))
        raise

    # Example 2
    # ---------
    #
    # """
    # line 1 of docstring
    # line 2 of docstring
    # """

# Generated at 2022-06-25 16:27:44.403869
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    from .reference_parser import parse as old_parse

    # hard to test this programmatically, so just compare against the old results
    parser = NumpydocParser()
    cases = [
        # simple case
        ('foo(a, b)', 'description', 'description'),

    ]
    for raw_text, short_description, long_description in cases:
        res_new = parser.parse(raw_text)
        res_old = old_parse(raw_text)
        assert res_new.short_description == res_old.short_description
        assert res_new.long_description == res_old.long_description
        assert res_new.blank_after_short_description == res_old.blank_after_short_description
        assert res_new.blank_after_long_description == res_old.blank_after_long

# Generated at 2022-06-25 16:27:54.424630
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:59.869108
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:28:07.362455
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    d1, d2 = numpydoc_parser.parse('not numpydoc'), numpydoc_parser.parse('a\nb')
    assert d1.short_description == 'not numpydoc'
    assert d2.short_description == 'a'
    assert d2.long_description == 'b'



# Generated at 2022-06-25 16:28:14.996339
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    time domain time series analysis

    This module provides time domain analysis tools.

    Parameters
    ----------
    data : ndarray
        Real time series data.
        Example:
            >>> data = numpy.arange(100)

    Raises
    ------
    TypeError
        If data is not a numpy data array.
    """

    expected = '''time domain time series analysis

This module provides time domain analysis tools.

Parameters
----------
data : ndarray
    Real time series data.
    Example:
        >>> data = numpy.arange(100)

Raises
------
TypeError
    If data is not a numpy data array.
    '''

    ret = parse(text)
    assert ret.short_description == 'time domain time series analysis'
    assert ret.blank_after_

# Generated at 2022-06-25 16:28:21.925176
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    case_0 = [numpydoc_parser_0.parse("")]
    case_0_expect = [Docstring()]
    assert case_0 == case_0_expect
    case_1 = [numpydoc_parser_0.parse("This is a docstring without sections.")]
    case_1_expect = [Docstring("This is a docstring without sections.")]
    assert case_1 == case_1_expect
    case_2 = [
        numpydoc_parser_0.parse("""This is a docstring
with sections.


Parameters
----------
arg_name
    arg_description
arg_2 : type, optional
    descriptions can also span...
    ... multiple lines
""")
    ]
    case_

# Generated at 2022-06-25 16:28:39.562048
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = 'a\n\nb\n\nc'
    assert numpydoc_parser_0.parse(text) == Docstring(short_description='a', long_description='b', blank_after_short_description=True, blank_after_long_description=False, meta=[])
    text = 'a\n\nb\n\nc'
    assert numpydoc_parser_0.parse(text) == Docstring(short_description='a', long_description='b', blank_after_short_description=True, blank_after_long_description=False, meta=[])
    text = 'a\n\nb\n\nc'

# Generated at 2022-06-25 16:28:49.539577
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = """test test test"""
    numpydoc_parser_0 = NumpydocParser()
    expected_0 = Docstring(
        short_description="test test test",
        blank_after_long_description=True,
        blank_after_short_description=False,
    )
    assert numpydoc_parser_0.parse(text_0) == expected_0
    text_1 = """test title
-------------

param_1
    param 1 description
param_2 : type
    param 2 description

return
    return description
    """
    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:28:55.339744
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "Parse numpy-style docstrings."
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == text_0


# Generated at 2022-06-25 16:29:03.565352
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:29:06.366531
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("Simple test.") == parse("Simple test.")


# Generated at 2022-06-25 16:29:13.259998
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    doc_string_0 = """Computes the area enclosed by a Bézier curve.

    Parameters
    ----------
    x, y : array_like
        The coordinates of the Bézier curve.
    """

    # Test case 0 is just a smoke test at the moment
    result = numpydoc_parser_0.parse(doc_string_0)
    assert result is not None


# Generated at 2022-06-25 16:29:18.353252
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydicParser()
    text_0 = "parsed docstring"
    ret = numpydoc_parser_0.parse(text_0)
    ret.short_description is "parsed docstring"


# integration test

# Generated at 2022-06-25 16:29:24.980113
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
    parse(text)
        Parse the numpy-style docstring into its components.

        Returns
        -------
        docstring : Docstring
            Parsed docstring
    """
    numpydoc_parser_0.parse(text_0)



# Generated at 2022-06-25 16:29:36.955434
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class A:
        """
        Description
        -----------
        Short description.
        This can span over multiple lines.
        Long description.

        Params
        ------
        a : str
            Optional a.
        b : int
            Required b.
        Returns
        -------
        op
            Optional operation result.
        Raises
        ------
        ValueError
            Description of what might raise ValueError.
        """
        pass

    numpydoc_parser_1 = NumpydocParser()
    docstring = numpydoc_parser_1.parse(inspect.getdoc(A))

    assert docstring.short_description == "Short description."
    assert docstring.long_description == "This can span over multiple lines.\nLong description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-25 16:29:49.937680
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse("""\
    An example docstring.

    This docstring has only one line in its short description.
    The long description can span
    multiple
    lines.

    Attributes
    ----------
    var1 : int
        First attr

    var2 : str
        Second attr

    Parameters
    ----------
    arg1 : int
        First arg

    arg2 : str, optional
        Second arg, default is 5
    """)
    assert docstring.short_description == "An example docstring."

    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description


# Generated at 2022-06-25 16:30:02.123393
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import (
        Docstring,
        DocstringMeta,
    )
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:30:15.755181
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parsed_docstring_0 = NumpydocParser().parse('')
    assert parsed_docstring_0.short_description == None
    assert parsed_docstring_0.long_description == None
    assert parsed_docstring_0.blank_after_short_description == False
    assert parsed_docstring_0.blank_after_long_description == False
    assert parsed_docstring_0.meta == []

    parsed_docstring_1 = NumpydocParser().parse('This is a short description.\n')
    assert parsed_docstring_1.short_description == 'This is a short description.'
    assert parsed_docstring_1.long_description == None
    assert parsed_docstring_1.blank_after_short_description == False
    assert parsed_docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:30:25.590313
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    numpydoc_parser_0 = NumpydocParser()
    text = """
    Return an image with the same shape and data type as a, but 
    with its pixels shifted by a number of pixels specified by shifts.
    """

    # Act
    expected = Docstring()
    expected.short_description = "Return an image with the same shape and data type as a, but with its pixels shifted by a number of pixels specified by shifts."
    expected.blank_after_short_description = True
    expected.long_description = None
    expected.blank_after_long_description = False

    actual = numpydoc_parser_0.parse(text)

    # Assert
    assert expected.short_description == actual.short_description
    assert expected.blank_after_short_description == actual.blank_after_short

# Generated at 2022-06-25 16:30:32.330286
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "something something"
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "something something"
    assert not docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert not docstring_0.long_description
    assert not len(docstring_0.meta)

# Generated at 2022-06-25 16:30:41.374065
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ''
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    

# Generated at 2022-06-25 16:30:49.422601
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    param_section_0 = ParamSection("Parameters", "param")
    param_section_0_expected = ParamSection("Parameters", "param")
    param_section_1 = ParamSection("Params", "param")
    param_section_2 = ParamSection("Arguments", "param")
    param_section_3 = ParamSection("Args", "param")
    param_section_4 = ParamSection("Other Parameters", "other_param")
    param_section_5 = ParamSection("Other Params", "other_param")
    param_section_6 = ParamSection("Other Arguments", "other_param")
    param_section_7 = ParamSection("Other Args", "other_param")
    param_section_8 = ParamSection("Receives", "receives")

# Generated at 2022-06-25 16:30:59.480825
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    input_str_1 = """\
    Sample docstring
    --------------------------
    :param int x: The first sample argument
    :param float y: The second sample argument
    :return: A single float sample return value
    :rtype: float
    :raises ValueError: If x is less than zero.
    """
    # test an case with expected positive outcome

# Generated at 2022-06-25 16:31:09.026659
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse('This function is an alias for `strftime`') == Docstring(
        short_description='This function is an alias for `strftime`')
    assert numpydoc_parser_0.parse('other_param : int\n    Another parameter') == Docstring(
        short_description=None,
        long_description=None,
        meta=[DocstringMeta(['other_param', 'int'], description='Another parameter')])

# Generated at 2022-06-25 16:31:11.659896
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "A quick brown fox"
    NumpydocParser().parse(text)



# Generated at 2022-06-25 16:31:17.244199
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ""
    numpydoc_parser_0 = NumpydocParser()
    ret_value = numpydoc_parser_0.parse(text)

    # test assertion(s)
    assert ret_value.short_description is None
    assert ret_value.blank_after_short_description is None
    assert ret_value.blank_after_long_description is None
    assert ret_value.long_description is None
    assert ret_value.meta == []



# Generated at 2022-06-25 16:31:31.558132
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    s = '        Initialize self.  See help(type(self)) for accurate signature.'
    result = numpydoc_parser_0.parse(s)
    assert(result.short_description == 'Initialize self.  See help(type(self)) for accurate signature.')
    assert(result.long_description == None)
    assert(result.blank_after_short_description == True)
    assert(result.blank_after_long_description == None)
    assert(len(result.meta) == 0)
    

# Generated at 2022-06-25 16:31:38.883610
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    actual_return_0 = numpydoc_parser_0.parse("""
        Test method for parse of class NumpydocParser

        Returns
        -------
        Docstring
            Test Docstring
    """)
    expected_return_0 = Docstring()
    expected_return_0.long_description = "Test Docstring"
    expected_return_0.short_description = "Test method for parse of class NumpydocParser"

    expected_return_0.meta.append(DocstringReturns(args=["returns"], description="Test Docstring", return_name=None, type_name=None, is_generator=False))

    assert actual_return_0 == expected_return_0

# Generated at 2022-06-25 16:31:49.982533
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = '''
Returns a list of lists of length 3, comprising all the orders of a given
size.

Parameters
----------
size : int
    An integer between 0 and 11.

Returns
-------
orders : list of lists
    All the orders of size ``size``.'''
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:52.067583
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    assert(numpydoc_parser.parse(''))

# Generated at 2022-06-25 16:32:04.865292
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:32:13.614517
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''
        Parameters
        ----------
        
        string_0 : str
            Description of string_0
        
        keyword_0 : str, optional
            Description of keyword_0. (default is None)
    '''
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert docstring_0.meta[0].args == ['param', 'string_0']

# Generated at 2022-06-25 16:32:20.539193
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    doc = numpydoc_parser.parse("""
Add this to that.

    This is a short
    description.

    Parameters
    ----------
    this : int
        Short description of this.

    that : str, optional
        Short description of that.


        And a long description of that.

        Default is 'default'.

    Returns
    -------
    something : str
        Something will be returned.

    Yields
    ------
    something : str
        Something will be yielded.

    Examples
    --------
    >>> something
    'something'

    See Also
    --------
    something : reference to something


    """)

    assert doc.short_description is None

# Generated at 2022-06-25 16:32:30.432552
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = (
        "This is an example docstring.\n\n"
        "Additional lines in the long description.\n\n"
        "Examples\n--------\n\n"
        ">>> some_example_code(1, 2)\n\n"
        "Returns\n-------\n"
        "int\n"
        "    an integer"
    )
    parseddocstring = parse(docstring)
    assert parseddocstring.short_description == 'This is an example docstring.'
    assert parseddocstring.long_description == (
        'Additional lines in the long description.'
    )
    assert parseddocstring.blank_after_short_description == True
    assert parseddocstring.blank_after_long_description == False

# Generated at 2022-06-25 16:32:41.002820
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:32:48.130886
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse(text="") == docstring_0
    assert numpydoc_parser_0.parse(text=" ") == docstring_0
    assert numpydoc_parser_0.parse(
        text="Module level Docstring.\n\nThis is the long description of the module."
    ) == docstring_1
    assert numpydoc_parser_0.parse(
        text="Module level Docstring.\n\nThis is the long description of the module.\n"
    ) == docstring_1
    assert numpydoc_parser_0.parse(
        text="Module level Docstring.\nThis is the long description of the module."
    ) == docstring_1
    assert nump

# Generated at 2022-06-25 16:32:57.022872
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse("")
    numpydoc_parser_0.parse("\n")
    numpydoc_parser_0.parse("\n\n")
