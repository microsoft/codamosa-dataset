

# Generated at 2022-06-25 16:23:43.919781
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_1 = 'param\n    param_desc\ntype\n    type_desc'
    result_2 = numpydoc_parser_0.parse(text_1)
    assert False


# Generated at 2022-06-25 16:23:53.617041
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # create NumpydocParser
    numpydoc_parser_0 = NumpydocParser()

    # test
    docstring = numpydoc_parser_0.parse(
        "This does something.\n"
        "\n"
        ":param x: The x parameter\n"
        ":type x: int\n"
        ":returns: A value\n"
        ":rtype: int\n"
        ":raises ValueError: If x is too big\n"
    )

    assert len(docstring.meta) == 4
    params = [m for m in docstring.meta if m.key == "param"]
    assert len(params) == 1
    assert params[0].args == ["param", "x"]
    assert params[0].description == "The x parameter"


# Generated at 2022-06-25 16:24:04.300334
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_str_0 = ''
    docstring_0 = numpydoc_parser_0.parse(text_str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description
    assert docstring_0.blank_after_short_description
    assert docstring_0.meta == []
    text_str_1 = '"Sphinx-style docstring parser."\n'
    docstring_1 = numpydoc_parser_0.parse(text_str_1)
    assert docstring_1.short_description == '"Sphinx-style docstring parser."'
    assert docstring_1.long_description is None

# Generated at 2022-06-25 16:24:10.127604
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # test case 0
    text_0 = 'key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines'
    numpydoc_parser_0 = NumpydocParser()
    for x_0 in numpydoc_parser_0.parse(text_0).meta:
        print(str(x_0.description))


# Generated at 2022-06-25 16:24:16.159859
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = _KVSection("Parameters", "param")
    sample_input_0 = inspect.cleandoc("""
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """)

# Generated at 2022-06-25 16:24:19.416459
# Unit test for method parse of class _KVSection

# Generated at 2022-06-25 16:24:26.227773
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "test0"
    docstring_0 = numpydoc_parser_0.parse(text_0)
    text_1 = ""
    docstring_1 = numpydoc_parser_0.parse(text_1)
    text_2 = "This is a test\nIt has\nmany lines"
    docstring_2 = numpydoc_parser_0.parse(text_2)
    text_3 = "This is a test\n\nIt has\nmany lines"
    docstring_3 = numpydoc_parser_0.parse(text_3)
    text_4 = "This is a test\n\n\nIt has\nmany lines"
    docstring_4 = numpydoc_

# Generated at 2022-06-25 16:24:35.242781
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert (
        list(ParamSection("param", "param").parse(_CASE_PARAM_0))
        == _PARSED_PARAM_0
    ), "test failed"
    assert (
        list(RaisesSection("raises", "raises").parse(_CASE_RAISES_0))
        == _PARSED_RAISES_0
    ), "test failed"


# Generated at 2022-06-25 16:24:39.771091
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0._KVSection_parse()


# Generated at 2022-06-25 16:24:43.134085
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_str = "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    l0 = list(numpydoc_parser_0.parse(text=test_str))
    assert len(l0) == 1



# Generated at 2022-06-25 16:25:00.329953
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_parse_0 = NumpydocParser()
    c_p_0 = _KVSection("Parameters", "param")
    # case when key is not None
    assert c_p_0._parse_item("a", "b") == None
    # case when key is None
    assert c_p_0._parse_item(None, "b") == None


# Generated at 2022-06-25 16:25:09.059977
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    doc = numpydoc_parser.parse("""\
DOCSTRING

Parameters
----------
one
    A required string argument that must be an integer.
two
    Optional string argument. True by default.
    Default is True.

Returns
-------
an_integer
    String that must be an integer.
""")

    assert len(doc.meta) == 2
    assert len(list(doc.param_list)) == 2
    assert len(list(doc.returns_list)) == 1


# Generated at 2022-06-25 16:25:18.631429
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:25:23.300177
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.parse('') == Docstring()
    assert numpydoc_parser_1.parse('Method\n') == Docstring()


# Generated at 2022-06-25 16:25:33.786555
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    output = numpydoc_parser_0.parse('''
        Parameters
        ----------
        arg
            some val
        arg2 : type
            another value''')

# Generated at 2022-06-25 16:25:40.571150
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    # Test with a known input.

# Generated at 2022-06-25 16:25:51.092325
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "This is a short description\n" + \
        "This text can be broken into multiple lines\n" + \
        "    - If it really needs to be.\n\n" + \
        "Parameters\n" + \
        "----------\n" + \
        "arg1 : int\n" + \
        "    Describes arg1, which is an integer.\n" + \
        "arg2 : str\n" + \
        "    Describes arg2, which is a string.\n"
    docstring = parse(text)
    assert docstring.short_description == "This is a short description"
    assert docstring.long_description == "This text can be broken into multiple lines\n    - If it really needs to be."
    assert docstring.blank_after_short_description == False


# Generated at 2022-06-25 16:25:56.985235
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    m = _KVSection("section_title", "section_key")
    text = inspect.cleandoc("""\
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """)
    for obj in m.parse(text):
        pass


# Generated at 2022-06-25 16:25:58.480672
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_1 = NumpydocParser()


# Generated at 2022-06-25 16:26:07.736967
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    text_0 = inspect.cleandoc(text_0)
    key_0 = "test"
    section_0 = _KVSection(key_0, 'test')
    pass_0 = True
    try:
        section_0.parse(text_0)
    except Exception as e:
        pass_0 = False
        print(e)

    assert pass_0 == True


# Generated at 2022-06-25 16:26:18.495282
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = '''\
    Returns True if all elements are true, else False.  
    '''
    docstring = numpydoc_parser_0.parse(str_0)
    assert docstring.short_description == 'Returns True if all elements are true, else False.  '
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == None
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:26:28.665672
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = test_case_0()
    docstring_0 = parse(docstring_1)
    print(docstring_0)
    assert type(docstring_0) is 'Docstring'
    assert docstring_0.short_description == 'The ``my_transform`` function.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.long_description == 'A very long description of the function,\nwith multiple lines.'
    assert len(docstring_0.meta) == 9


# Generated at 2022-06-25 16:26:39.901671
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()

    import re
    import typing as T
    import inspect

    class ReturnSection(Section):
        """Parser for numpydoc raises sections.
        E.g. any section that looks like this:
            return_name : type
                A description of this returned value
            another_type
                Return names are optional, types are required
        """
        is_generator = False

        def _parse_item(self, key: str, value: str) -> DocstringReturns:
            m = RETURN_KEY_REGEX.match(key)
            if m is not None:
                return_name, type_name = m.group("name"), m.group("type")
            else:
                return_name = type_name = None


# Generated at 2022-06-25 16:26:50.155571
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import parse_doctest
    from .common import DocstringReturns, DocstringParam, Docstring
    from .common import DocstringMeta, DocstringDeprecated, DocstringRaises

    cls = NumpydocParser
    doctest = parse_doctest(cls.parse, module=__name__)

    def t(text: str, expected: Docstring):
        parsed = cls().parse(text)
        if parsed != expected:
            print(parsed)
            print(expected)
        assert parsed == expected


# Generated at 2022-06-25 16:26:58.607265
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup
    numpydoc_parser_0 = NumpydocParser()

    # Assert pre-conditions

# Generated at 2022-06-25 16:27:00.057473
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()


# Generated at 2022-06-25 16:27:04.454376
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    parameter_text_1 = """\
    """
    numpydoc_parser_1.parse(parameter_text_1)
    return


# Generated at 2022-06-25 16:27:11.854346
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:27:20.315162
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Function to do something.

    Parameters
    ----------
    first : str
        First parameter. Default is "first".
    second : int, optional
        Second parameter. Default is None.

    Returns
    -------
    int
        Result of doing something.

    Raises
    ------
    ValueError
        If something bad happens.

    Warns
    -----
    UserWarning
        If something weird happens.

    """
    doc = numpydoc_parser_0.parse(text)
    assert doc.short_description == "Function to do something."
    assert doc.meta[0].args == ['param', 'first']
    assert doc.meta[0].description == "First parameter. Default is \"first\"."
    assert doc.meta[1].args == ['param', 'second']

# Generated at 2022-06-25 16:27:32.312484
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    with mock.patch(
        "autosummarize.numpydoc_parser.inspect.cleandoc", autospec=True
    ) as mock_inspect_cleandoc:
        mock_inspect_cleandoc.return_value = mock.MagicMock(spec=str)
        mock_inspect_cleandoc.side_effect = ["", "", "", "", "", "", "", ""]
        with mock.patch("autosummarize.numpydoc_parser.Docstring") as MockDocstring:
            numpydoc_parser_0.parse("")
            numpydoc_parser_0.parse("")
            numpydoc_parser_0.parse("")
            numpydoc_parser_0

# Generated at 2022-06-25 16:27:42.599451
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:53.340824
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """Test docstring

Parameters
----------
arg_name
    arg_description
arg_2 : type, optional
    descriptions can also span...
    ... multiple lines

Returns
-------
return_name : type
    A description of this returned value
another_type
    Return names are optional, types are required

Raises
------
ValueError
    A description of what might raise ValueError

Yields
------
yield_name : str
    A description of this yielded value
"""
    actual = numpydoc_parser_0.parse(text_0)

# Generated at 2022-06-25 16:27:55.757529
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Testing NumpydocParser.parse()...")
    print("Method NumpydocParser.parse() not yet implemented.")


# Executes unit tests for class NumpydocParser.

# Generated at 2022-06-25 16:28:08.138803
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Example from numpydoc docs and then cleaned up
    text = """
    Parameters
    ----------
    first
        The first parameter.
    second : type
        The second with a very long
        multi-line description.
        Default is 2.

    Returns
    -------
    function : function type
        The return value.

    """

    result = parse(text)
    assert result.short_description is None
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert len(result.meta) == 4

# Generated at 2022-06-25 16:28:11.696448
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #
    # Test example 0.
    #
    numpydoc_parser_0 = NumpydocParser()

    text_0 = "Sample docstring for NUMPY-DOCSTRINGS."

    result_0 = numpydoc_parser_0.parse(text_0)



# Generated at 2022-06-25 16:28:24.079596
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is the short description.
    
And now the long, possibly multi-line, description.

Parameters
---------
arg1
    Arg1 description.
arg2 : type, optional
    Arg2 description, can also span...
    ... multiple lines

Returns
-------

return1
    Return1 description.
return2 : type
    Return2 description.

Raises
------

ValueError
    Raises a value error when there's a problem.
"""
    result = parse(text)
    assert result.short_description == "This is the short description."
    assert result.long_description == "And now the long, possibly multi-line, description."
    for e in result.meta:
        if e.args == ['param', 'arg1']:
            assert e.description == "Arg1 description."

# Generated at 2022-06-25 16:28:35.544965
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    args_0 = None
    numpydoc_parser_0 = NumpydocParser()
    return_value_0 = numpydoc_parser_0.parse(args_0)
    assert return_value_0.blank_after_long_description is None
    assert return_value_0.blank_after_short_description is None
    assert return_value_0.long_description is None
    assert return_value_0.meta == []
    assert return_value_0.short_description is None


# Generated at 2022-06-25 16:28:48.302776
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:28:59.905503
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    result = parse("""\
    This docstring has sections that are not standard.
    This is the description.
    
    Parameters:
        first (str): the first parameter
        second (str, optional): the second parameter
    
    Returns:
        bool
            if something is true
    """)
    assert result.short_description == "This docstring has sections that are not standard."
    assert result.blank_after_short_description
    assert result.long_description == "This is the description."
    assert result.blank_after_long_description

    result = parse("""\
    Parameters
    ----------
    this
        is a description
    that
        spans multiple lines
    """)
    assert result.short_description == None
    assert result.long_description == None

# Generated at 2022-06-25 16:29:06.712848
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = "Returns the value list that belongs to the given key."
    docstring_2 = numpydoc_parser_1.parse(text_1)
    assert docstring_2.short_description == text_1


# Generated at 2022-06-25 16:29:17.752755
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    docstring_0 = numpydoc_parser_0.parse(r"""
    This is a short description.

    And this is a long description.
    """)

    assert docstring_0.meta == [] and docstring_0.short_description == r"This is a short description." and docstring_0.long_description == r"And this is a long description."

# Generated at 2022-06-25 16:29:21.120816
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()



# Generated at 2022-06-25 16:29:31.428638
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    #Test 0
    docstring_0 = numpydoc_parser_0.parse("Short\n\nLong\n\nParams\n-----\n\nargh : int\n    Descr\n")
    assert docstring_0.short_description == "Short"
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    #Test 1
    docstring_1 = numpydoc_parser_0.parse("Short\nLong\n\nParams\n-----\n\nargh : int\n    Descr\n")
    assert docstring_1.short_description == "Short"
    assert docstring_1.blank_after_short_description

# Generated at 2022-06-25 16:29:39.704832
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("Test for parse docstring\n")
    assert docstring_0.short_description == "Test for parse docstring"
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:29:47.240154
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    numpydoc_parser_0 = NumpydocParser()
    text_0: str = ""

    # Act
    ret_0 = numpydoc_parser_0.parse(text_0)

    # Assert
    assert ret_0.short_description is None
    assert ret_0.long_description is None
    assert ret_0.meta == []


# Generated at 2022-06-25 16:29:58.585853
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
    Compute the (quickly, normally) Fourier Transform.

    This is a simple docstring example for test.

    :param A: The input array.
    :param B: Another input array, optional.
    :return: The transformed array.
    :raises: UserWarning
    """
    expected_0 = Docstring()
    expected_0.short_description = 'Compute the (quickly, normally) Fourier Transform.'
    expected_0.long_description = 'This is a simple docstring example for test.'
    expected_0.blank_after_short_description = False
    expected_0.blank_after_long_description = False
    expected_0.meta = []

# Generated at 2022-06-25 16:30:10.890112
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # test case for parse
    docstring_text_0 = 'attribute : int\n    Describes the type of this endpoint.'
    docstring_meta_0 = [DocstringMeta(['attribute', 'attribute'],
                                      'Describes the type of this endpoint.',
                                      arg_name='attribute',
                                      type_name='int')]
    # execute
    docstring_0 = numpydoc_parser_0.parse(docstring_text_0)
    docstring_meta_1 = docstring_0.meta
    # check
    assert docstring_meta_1 == docstring_meta_0, 'test_case 0 failed'

# Generated at 2022-06-25 16:30:21.598943
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import sys
    import io

    # redirect stdout to io object to perform test on captured output
    captured_stdout = io.StringIO()
    sys.stdout = captured_stdout

    # test 1
    text = """This is a description.
    """
    ds = numpydoc_parser_0.parse(text)
    assert ds.short_description == "This is a description."

    # test 2
    text = """This is a description.
    With a long description.
    """
    ds = numpydoc_parser_0.parse(text)
    assert ds.short_description == "This is a description."
    assert ds.long_description == "With a long description."
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_

# Generated at 2022-06-25 16:30:30.821978
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """\
    This is a short description.

    This is a long description.

    This is a third description.
    """
    docstring_0 = numpydoc_parser_0.parse(text)
    assert docstring_0.short_description == "This is a short description."
    assert docstring_0.long_description == "This is a long description.\n\nThis is a third description."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == True


# Generated at 2022-06-25 16:30:41.863456
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is a short description.

    This is a long description.
    It continues here.

    Parameters
    ----------
    arg_name : type, optional
        Argument description.

    arg_name : string
        Another argument

    Returns
    -------
    return_name : type
        Return value description.
    '''
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse(text=text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description.\nIt continues here."
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "arg_name"
   

# Generated at 2022-06-25 16:30:54.026233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    str_0 = "This is an example docstring."

    d = numpydoc_parser_0.parse(str_0)

# Generated at 2022-06-25 16:31:01.314266
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # &%NumpydocParser_parse.1
    text = """
    This is a line.

    This is a second line.
    """
    # &%NumpydocParser_parse.2

    # &%NumpydocParser_parse.3
    expected = Docstring(
        short_description='This is a line.',
        long_description='This is a second line.',
        blank_after_short_description=True,
        blank_after_long_description=False,
    )   
    # &%NumpydocParser_parse.4
    result = NumpydocParser().parse(text)
    # &%NumpydocParser_parse.5
    assert result == expected
    # &%NumpydocParser_parse.6

# Generated at 2022-06-25 16:31:09.194181
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:22.173360
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_meta_0 = DocstringMeta(['param', 'a'], description='First param.')
    docstring_meta_1 = DocstringMeta(['param', 'b'], description='Second param.')
    docstring_meta_2 = DocstringMeta(['param', 'c'], description='Third param.')
    docstring_meta_3 = DocstringMeta(['other_param', 'd'], description='Fourth param.')
    docstring_meta_4 = DocstringMeta(['other_param', 'e'], description='Fifth param.')
    docstring_meta_8 = DocstringMeta(['returns'], description='Returns sum of first two params.')

# Generated at 2022-06-25 16:31:32.226317
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = '''
    Unit test for method parse of class NumpydocParser

    This function takes a single string argument and returns the
    parsed numpydoc docstring.

    :param text: The text to parse
    :type text: str

    :returns: parsed docstring.
    :rtype: Docstring'''
    docstring_0 = numpydoc_parser_0.parse(str_0)
    str_1 = 'Unit test for method parse of class NumpydocParser'
    assert docstring_0.short_description == str_1
    assert docstring_0.blank_after_short_description

# Generated at 2022-06-25 16:31:41.528066
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
        This is the short description.

        This is the long description.  It can include
        multiple paragraphs, and lists
        like this:

          * item 1
          * item 2

        1) Another ordered list:
        2) item 1
        3) item 2
        """
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "This is the short description."
    assert docstring_0.blank_after_short_description == False

# Generated at 2022-06-25 16:31:53.133827
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Example call to parse
    text_str_0 = """Basic example for str.__contains__.

"""
    result_obj_0 = numpydoc_parser_0.parse(text = text_str_0)
    assert result_obj_0.short_description == "Basic example for str.__contains__."
    assert result_obj_0.long_description == None
    assert result_obj_0.blank_after_short_description == True
    assert result_obj_0.blank_after_long_description == False
    assert result_obj_0.meta == []

    numpydoc_parser_1 = NumpydocParser()
    # Example call to parse

# Generated at 2022-06-25 16:32:04.892293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test case 0
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "Not a docstring."
    result_0 = numpydoc_parser_0.parse(text_0)
    assert str(result_0) == "\n".join(
        [
            "Docstring(",
            "    short_description=None,",
            "    long_description=None,",
            "    blank_after_short_description=False,",
            "    blank_after_long_description=False,",
            "    meta=[]",
            ")",
        ]
    )

    # test case 1
    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:32:09.178441
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_test_0 = numpydoc_parser_1.parse("The world is round")
    numpydoc_parser_test_0.short_description
    numpydoc_parser_test_0.long_description

if __name__ == "__main__":
    test_case_0()
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:32:14.302491
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser.parse(NumpydocParser, "") == NumpydocParser()
    assert NumpydocParser.parse(NumpydocParser, "one line") == NumpydocParser()
    assert NumpydocParser.parse(NumpydocParser, "one\ntwo") == NumpydocParser()
    assert NumpydocParser.parse(NumpydocParser, "one\ntwo\nthree") == NumpydocParser()

# Generated at 2022-06-25 16:32:37.712504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser_0 = NumpydocParser()
    empty_str = ''
    assert NumpydocParser_0.parse(empty_str) == Docstring()

# Generated at 2022-06-25 16:32:43.049764
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_0 = numpydoc_parser_1.parse('This is a good docstring.\n\n')
    assert docstring_0.short_description == 'This is a good docstring.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == ''

# test _pairwise

# Generated at 2022-06-25 16:32:46.525477
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('')
    assert docstring_0.long_description is None
    assert docstring_0.short_description is None
    assert len(docstring_0.meta) == 0
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == False

# Generated at 2022-06-25 16:32:47.842000
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()


# Generated at 2022-06-25 16:32:58.526468
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    with open("lang/docs/test_data/NumpydocParser_parse.txt") as fp:
        test_string = fp.read()
    fp.close()

    docstring = parse(test_string)