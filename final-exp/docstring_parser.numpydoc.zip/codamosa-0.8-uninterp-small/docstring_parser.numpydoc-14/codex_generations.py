

# Generated at 2022-06-25 16:24:07.882697
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser(sections={})
    text = '"""Numpydoc-style docstring parsing.\n\n.. seealso:: https://numpydoc.readthedocs.io/en/latest/format.html\n"""'
    obj.parse(text)


# Generated at 2022-06-25 16:24:12.807687
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()


# Generated at 2022-06-25 16:24:22.611047
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Parameters
    text = """
    Parameters

    ========
    arg_1
        Type: ``str``. The first parameter.
        More detailed description of first arg.

    arg_2 : int
        The second parameter.

    arg_3 (optional)
        Type: ``bool``. The third parameter.
    """

    # Return type annotation
    ret = Docstring()

    # Setup
    parser = NumpydocParser()

    # Call function
    ret = parser.parse(text)
    assert ret is not None
    assert ret.short_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.long_description is None
    assert len(ret.meta) == 3

# Generated at 2022-06-25 16:24:27.061843
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # case 0
    args_0 = 'FromXtJl7VuRtuH/he=V'
    args_1 = 'oa'
    return_0 = ReturnsSection(args_0, args_1)
    args_2 = 'z2(M'
    args_3 = 'l[6'
    return_1 = RaisesSection(args_2, args_3)
    args_4 = 'R*'
    return_2 = ParamSection(args_4, args_4)
    str_1 = 'd\x0bD'
    return_3 = DeprecationSection(str_1, str_1)
    return_4 = YieldsSection(str_1, str_1)
    args_5 = 'yokT*'
    args_6 = 'mj'
    return_

# Generated at 2022-06-25 16:24:39.797907
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    arg_0 = 'x[`s`s3\x7fkp\x7fA4\x7fo^'
    arg_1 = '\x7f[gX\x7f'
    arg_2 = '\x7fc\x7ft`}`c'
    arg_3 = '[X~\x7f\x7f}t\x7f\x7f{~\x7f'
    arg_4 = '\x7f\x7f~l\x7f\x7fY'
    arg_5 = '\x7f\x7f\x7f7{O\x7f\x7f\x7f\x7f\x7f\x7f|\x7f\x7f'

# Generated at 2022-06-25 16:24:48.066168
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    param_section_0 = ParamSection('Parameters', 'param')
    param_section_1 = ParamSection('Params', 'param')
    param_section_2 = ParamSection('Arguments', 'param')
    param_section_3 = ParamSection('Args', 'param')
    param_section_4 = ParamSection('Other Parameters', 'other_param')
    param_section_5 = ParamSection('Other Params', 'other_param')
    param_section_6 = ParamSection('Other Arguments', 'other_param')
    param_section_7 = ParamSection('Other Args', 'other_param')
    param_section_8 = ParamSection('Receives', 'receives')
    param_section_9 = ParamSection('Receive', 'receives')

# Generated at 2022-06-25 16:24:49.344342
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = 'h'
    ret_0 = NumpydocParser().parse(text_0)
    


# Generated at 2022-06-25 16:25:00.645512
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open('/home/jtluong/workspace/docstring_mapper/tests/fixtures/pep257_example.py') as f:
        docstring = f.read()
    # docstring = 'One-line summary of the object\'s purpose.'
    # print(docstring)
    parser = NumpydocParser()
    d = parser.parse(docstring)
    # print(d)
    # print(d.meta)
    # print(d.meta)
    # print(d.short_description)
    # print(d.long_description)
    print(d.meta)
    print(d.meta[0].description)
    print(d.meta[0].args)
    # print(docstring)


if __name__ == "__main__":
    test_Numpyd

# Generated at 2022-06-25 16:25:13.015851
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser_0 = NumpydocParser()
    str_0 = 'qO8){;$7[y[}\r`p6^-('
    raises_section = RaisesSection(str_0, str_0)
    parser_0.add_section(raises_section)
    str_1 = 'sXHzpJ+r'
    docstring_0 = parser_0.parse(str_1)
    assert docstring_0.short_description == 'sXHzpJ+r'
    assert docstring_0.long_description == None
    assert docstring_0.meta == [ ]
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    dictionary_0 = docstring_0.as_dict
    assert dictionary

# Generated at 2022-06-25 16:25:19.400678
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'tsee, @oal=_as,[bsmee[ag'
    section_0 = Section(str_0, str_0)
    str_1 = 'p,y[]g.\r&[;$xo'
    section_1 = RaisesSection(str_1, str_1)
    list_0 = [section_1, section_0]
    parser_0 = NumpydocParser(list_0)
    str_2 = 'a;$&bd'
    docstring_0 = parser_0.parse(str_2)
    assert docstring_0.short_description == ''
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:25:35.177958
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    parser = NumpydocParser()

    # Teardown
    parser = None

    # Test
    parser.parse(str)

# Generated at 2022-06-25 16:25:43.139012
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'qO8){;$7[y[}\r`p6^-('
    str_1 = 'i7Vu4z4:_&Zf=a9c%`'
    str_2 = 'i7Vu4z4:_&Zf=a9c%`'
    str_3 = 'i7Vu4z4:_&Zf=a9c%`'
    str_4 = 'i7Vu4z4:_&Zf=a9c%`'
    str_5 = 'i7Vu4z4:_&Zf=a9c%`'
    param_section_0 = ParamSection(str_0, str_1)
    param_section_1 = ParamSection(str_2, str_3)
    param_section_2

# Generated at 2022-06-25 16:25:52.174814
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:04.821864
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    warning_0 = ''
    long_desc_chunk_0 = -1.424670922083652
    long_desc_chunk_1 = 'qO8){;$7[y[}\r`p6^-('
    warn_0 = RaisesSection(long_desc_chunk_0, long_desc_chunk_1)
    str_0 = 'qO8){;$7[y[}\r`p6^-('
    yields_section_0 = YieldsSection(str_0, str_0)
    param_0 = 'pl`#O+F;X4'
    str_1 = 'IduV$l*)+:!}3sCJ2'
    param_section_1 = ParamSection(param_0, str_1)
    note_0 = _Sph

# Generated at 2022-06-25 16:26:15.766453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'e.p7ypdCm>HW8VxOplB&'
    numpydocparser_0 = NumpydocParser()
    numpydocparser_1 = NumpydocParser({str_0: numpydocparser_0})
    assert hasattr(numpydocparser_1, '__getitem__')
    assert hasattr(numpydocparser_1, '__setitem__')
    assert hasattr(numpydocparser_1, '__delitem__')
    str_1 = 'M<]~{Zb`k*`}(lNf=A)'
    assert numpydocparser_1[str_0].title == str_0
    assert numpydocparser_1[str_0].key == str_0
    nump

# Generated at 2022-06-25 16:26:29.038421
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    data = 'p$;HdJ5.5+CC85|)w\n%+B"\\\x14\x0b\x0b\x1d'
    data_ = inspect.cleandoc(data)
    assert obj.parse(data_) == Docstring()

    data = '$]aJxR\x16\x1d\x0b\x1d8=\x17~;\n`4Lp"x]oR\x0b\x07'
    data_ = inspect.cleandoc(data)
    assert obj.parse(data_) == Docstring()

    data = '7h%\x1b\x0b\x0b\x075\x19\x1d\x07\n0#'
   

# Generated at 2022-06-25 16:26:35.406288
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Local variable: str_0
    str_0 = '#<&B)w$V7|Pc%$q7~'
    # Local variable: str_1
    str_1 = 'RK<$w7V,(@c}/7'
    # Local variable: str_2
    str_2 = '~>0~0C,6[yJ6'
    # Local variable: str_3
    str_3 = 'B_S#<oF#{K[1B'
    # Local variable: str_4
    str_4 = 'KPqg3&%p]sIsy'
    # Local variable: str_5
    str_5 = '(k[S{;N&|;0}C'
    # Local variable: str_6

# Generated at 2022-06-25 16:26:48.510734
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '# Some comment'
    numpydocparser_0 = NumpydocParser()
    result = numpydocparser_0.parse(text)


if __name__ == '__main__':
    import sys
    import doctest

    if not sys.argv[1:] or sys.argv[1] in {"-h", "--help"}:
        print(__doc__)
        sys.exit(2)
    elif sys.argv[1] in {"-v", "--verbose"}:
        logging.basicConfig(level=logging.DEBUG)
        del sys.argv[1]
    elif sys.argv[1] in {"-q", "--quiet"}:
        logging.basicConfig(level=logging.WARNING)
        del sys.argv[1]

   

# Generated at 2022-06-25 16:26:58.127556
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()
    str_0 = 'qO8){;$7[y[}\r`p6^-('
    str_1 = 'qO8){;$7[y[}\r`p6^-('
    str_2 = 'qO8){;$7[y[}\r`p6^-('
    docstring_meta_0 = DocstringMeta(args=[str_0, str_1], description=str_2)
    str_3 = 'qO8){;$7[y[}\r`p6^-('
    docstring_param_0 = DocstringParam(args=[str_0, str_1], description=str_3)
    docstring_meta_1 = DocstringMeta(args=[str_0], description=str_1)

# Generated at 2022-06-25 16:27:08.995002
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from sklearn.base import BaseEstimator, TransformerMixin, clone

    class _BaseEstimator(BaseEstimator):
        """Base class for all estimators in scikit-learn

        Notes
        -----
        All estimators should specify all the parameters that can be set
        at the class level in their ``__init__`` as explicit keyword
        arguments (no ``*args`` or ``**kwargs``).
        """

        @classmethod
        def _get_param_names(cls):
            """Get parameter names for the estimator"""
            # fetch the constructor or the original constructor before
            # deprecation wrapping if any
            init = getattr(cls.__init__, 'deprecated_original', cls.__init__)

# Generated at 2022-06-25 16:27:29.378303
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:39.939497
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_0 = parse('Other Arguments\n-------------\n\n    function(m)\n    \n\n\nReturns\n-------\n\n    n : int\n\n    n!')
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    
    assert docstring_0.meta[0].args == ['param', 'm']
    
    assert docstring_0.meta[1].args == ['return', None]
    assert docstring_0.meta[1].type_name == 'int'
    assert docstring_0.meta[1].return_name == None

# Generated at 2022-06-25 16:27:45.128639
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Tests parse(self, text: str)"""
    text = 'Parameters\n----------\nother_param1\n    Description of other_param1'
    docstring = parse(text)
    assert docstring.short_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.long_description is None
    assert len(docstring.meta) > 0
    assert docstring.meta[0].args == ['other_param1']
    assert docstring.meta[0].description == 'Description of other_param1'



# Generated at 2022-06-25 16:27:54.817396
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("")
    assert docstring == Docstring()

    docstring = parser.parse("Single line description")
    docstring_correct = Docstring()
    docstring_correct.short_description = "Single line description"
    assert docstring == docstring_correct

    docstring = parser.parse(
        """Single line description

        Longer description
        spanning multiple lines.
        """
    )
    docstring_correct = Docstring()
    docstring_correct.short_description = "Single line description"
    docstring_correct.long_description = "Longer description spanning multiple lines."
    assert docstring == docstring_correct

    docstring = parser.parse(
        """Single line description

    Longer description
    spanning multiple lines.
    """
    )

# Generated at 2022-06-25 16:27:57.373640
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Custom test string'
    docstring_0 = parse(str_0)
    assert docstring_0.long_description == 'Custom test string'


# Generated at 2022-06-25 16:27:59.530655
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    parser = NumpydocParser()
    docstring_0 = parser.parse(str_0)

# Generated at 2022-06-25 16:28:11.243612
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = NumpydocParser().parse(str_0)

    assert docstring_0.short_description == 'Other Arguments'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []

    str_1 = 'Parameters'
    docstring_1 = NumpydocParser().parse(str_1)

    assert docstring_1.short_description == 'Parameters'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring

# Generated at 2022-06-25 16:28:23.994598
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse("""
    This is a docstring.

    Parameters
    ----------
    arg1
        A description of arg1
    arg2 : type, optional
        Another description

    Returns
    -------
    return 1
        Return description 1
    return 2 : type
        Return description 2

    Notes
    -----
    This is a note
    """)

    assert docstring.short_description == "This is a docstring."

# Generated at 2022-06-25 16:28:30.113653
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring) == True

# Generated at 2022-06-25 16:28:31.772474
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()

# Test class NumpydocParser

# Generated at 2022-06-25 16:28:46.070191
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test case #0
    str_0 = 'Other Arguments'
    docstring_0 = NumpydocParser().parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    # Test case #1
    str_1 = 'Other Arguments\n---------------\n'
    docstring_1 = NumpydocParser().parse(str_1)
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description == False
    assert doc

# Generated at 2022-06-25 16:28:52.210988
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = " This is a docstring.                                         \n"
    str_0 += "                                                              \n"
    str_0 += " Some other stuff here.                                       \n"
    str_0 += "                                                              \n"
    str_0 += " Parameters                                                   \n"
    str_0 += " ----------                                                   \n"
    str_0 += " first_param : type                                           \n"
    str_0 += "     Description of first_param                               \n"
    str_0 += " second_param : type, optional                                \n"
    str_0 += "     Description of second_param                              \n"
    str_0 += " third_param : type, optional                                 \n"

# Generated at 2022-06-25 16:28:55.530715
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input_0 = 'Other Arguments'
    output_0 = NumpydocParser().parse(input_0)
    assert output_0 == Docstring()


# Generated at 2022-06-25 16:29:03.663704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()


# Generated at 2022-06-25 16:29:06.983155
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Parameters\n---------------\n\nother_arg : type, optional   \n    description\nother_arg2 : type, optional   \n    description'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:29:18.964336
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test 0
    docstring_0 = parse('')
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == None
    assert len(docstring_0.meta) == 0

    # Test 1
    docstring_0 = parse('Parameters\n----------\na : int\n    The identity of the object.\nb : int\n    The negative class.\n\nutility_function : int\n    A function that does something useful.\n\nNotes\n-----\nThese can span multiple lines.\n\n')
    assert docstring_0.short_description == 'Parameters'
    assert docstring_0.blank_after_long

# Generated at 2022-06-25 16:29:20.528037
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:29:22.503588
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_1 = 'Other Arguments'
    docstring_1 = parse(str_1)


# Generated at 2022-06-25 16:29:32.744053
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # TODO: use fixture
    obj = NumpydocParser()
    str_0 = """
    This is the short description.
    This is the long description.
    
    Other Arguments
        arg : int
            This is the description.
    
    Returns
        Returns whatever."""
    docstring_0 = parse(str_0)
    # Meta section descriptions are cleaned
    assert docstring_0.meta[0].description == 'This is the description.'
    # Section titles are recognized case-insensitively
    str_1 = """
    This is the short description.
    This is the long description.
    
    other arguments
        arg : int
            This is the description.
    
    Returns
        Returns whatever."""
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:29:44.799887
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert True == isinstance(NumpydocParser().parse(''), Docstring)
    assert False == (
        NumpydocParser().parse('').short_description == 'Other Arguments'
    )
    assert True == (
        NumpydocParser().parse('Other Arguments').short_description ==
        'Other Arguments'
    )
    assert True == (
        NumpydocParser().parse('Other Arguments').long_description == None
    )
    assert False == (
        NumpydocParser().parse('Other Arguments').long_description ==
        'Other Arguments'
    )
    assert True == (
        NumpydocParser().parse('Other Arguments').meta.args == [
            'param',
            None,
        ]
    )

# Generated at 2022-06-25 16:29:59.381524
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1
    
    str_1 = """
    Parameters:
        param_1 (int): doc for param_1
        param_2 (bool): doc for param_2

    Returns:
        dict

    Examples:
        examples_1
        examples_2
    """
    ret_1 = parse(str_1)

# Generated at 2022-06-25 16:30:03.481244
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Test case 0
    str_0 = 'Other Arguments'
    assert docstring_0 == numpydoc_parser_0.parse(str_0),'Output mismatch'

# Generated at 2022-06-25 16:30:16.628346
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """ Parse the numpy-style docstring into its components.
    """
    # String that contains a numpy doc string

# Generated at 2022-06-25 16:30:30.822362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test empty docstring
    parser = NumpydocParser()
    assert parser.parse(None).long_description is None
    assert parser.parse('').long_description is None

    # Test simple docstring
    parser = NumpydocParser()
    docstring = parser.parse('a')
    assert docstring.short_description == 'a'
    assert docstring.meta == []

    # Tests for short/long_description

    # Test short description change
    parser = NumpydocParser()
    docstring = parser.parse('a\nb\n')
    assert docstring.short_description == 'a'
    assert docstring.long_description == 'b'

    # Test that long_description is not empty
    parser = NumpydocParser()
    docstring = parser.parse('a\n\nb ')

# Generated at 2022-06-25 16:30:41.866124
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring_test_0 = parse("Args\n----\n    arg_1: (type)\n        description\n    arg_2\n        description")

    assert(len(docstring_test_0.meta) == len(docstring_test_0.meta))
    assert(docstring_test_0.meta[0].description == docstring_test_0.meta[0].description)
    assert(docstring_test_0.meta[1].description == docstring_test_0.meta[1].description)

test_case_0()
test_NumpydocParser_parse()

# class NumpydocParserTests(TestCase):
#     def test_main_attributes(self):
#         f = lambda s: parse(s)

#         self

# Generated at 2022-06-25 16:30:49.715232
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ## Test case 0:
    str_0 = inspect.cleandoc(r'''
    Other Arguments
    -----------------
    other_params : dict
        Additional keyword arguments for the
        :class:`~django.models.Field` class.

    example : str
        Another kwarg which is used as an example.
    ''')
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None

# Generated at 2022-06-25 16:30:59.632632
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ".. deprecated:: 0.4.2\n   Deprecated in version 0.4.2, will be removed in 0.5.\n\n   "
    docstring_0 = parse(str_0)
    assert docstring_0.meta[0].args == ['deprecation']
    assert docstring_0.meta[0].description == 'Deprecated in version 0.4.2, will be removed in 0.5.'
    str_1 = ".. deprecated:: 0.4.2\n   Deprecated in version 0.4.2, will be removed in 0.5\n   .. deprecated:: 0.6.1\n      Deprecated in version 0.6.1, will be removed in 0.7\n      \n      "
    docstring_1 = parse(str_1)
    assert docstring_1

# Generated at 2022-06-25 16:31:02.932838
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = NumpydocParser().parse(str_0)



# Generated at 2022-06-25 16:31:04.418010
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = 'Other Arguments'
    assert NumpydocParser().parse(docstring) == 'Other Arguments'

# Generated at 2022-06-25 16:31:05.821809
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:31:16.657812
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    instance = NumpydocParser()
    str_0 = 'Other Arguments'
    docstring_0 = instance.parse(str_0)
    str_1 = 'Other Arguments\n------------\nother_param : type\n'
    docstring_1 = instance.parse(str_1)

# Generated at 2022-06-25 16:31:17.644274
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parse('Other Arguments')

# Generated at 2022-06-25 16:31:20.842115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import docstring_parsers
    docstring_parsers.numpydoc.NumpydocParser.parse('Other Arguments')


# Generated at 2022-06-25 16:31:30.070693
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open('test_input/test_input_NumpydocParser_parse.txt', 'r') as file:
        text = file.read()
    doc = parse(text)

    assert doc.short_description is None
    assert doc.long_description is None

    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['other_param']
    assert doc.meta[0].annotation is None
    assert doc.meta[0].description == '\n    A parameter with a name containing\n'



# Generated at 2022-06-25 16:31:43.797283
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()
    docstring_0 = p.parse('Other Arguments')
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)
    meta_0 = docstring_0.meta
    assert(len(meta_0) == 1)
    obj_0 = meta_0[0]
    assert(obj_0.args[0] == 'param')
    assert(obj_0.args[1] == 'arg_name')
    assert(obj_0.arg_name == 'arg_name')
    assert(obj_0.type_name == None)

# Generated at 2022-06-25 16:31:55.834217
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)
    str_1 = 'Other Arguments : list of int'
    docstring_1 = parse(str_1)
    str_2 = 'Other Arguments : list of int \n\n test \n\n'
    docstring_2 = parse(str_2)
    str_3 = 'test : str \n test2 : str \n\n'
    docstring_3 = parse(str_3)
    str_4 = 'test : str \n test2 : str \n\n test3: str, optional \n test4: str \n\n test5: str, optional\n test6: str, optional\n'
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:31:57.679926
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:32:08.142475
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring = numpydoc_parser.parse('''
        Parameter that is passed unchanged to all models in the pipeline.
        See sklearn.pipeline.Pipeline.set_params for details.
    ''')
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "param"
    assert docstring.meta[0].description == 'Parameter that is passed unchanged to all models in the pipeline.\nSee sklearn.pipeline.Pipeline.set_params for details.'

# Generated at 2022-06-25 16:32:16.017433
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test 1
    str_1 = 'name : int\n    The name of the person'
    docstring_1 = parse(str_1)

    assert isinstance(docstring_1, Docstring)

    assert docstring_1.short_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.long_description is None

    assert len(docstring_1.meta) == 1

    assert isinstance(docstring_1.meta[0], DocstringParam)
    assert docstring_1.meta[0].args == ['param', 'name']
    assert docstring_1.meta[0].description == None
    assert docstring_1.meta[0].arg_name == 'name'
   

# Generated at 2022-06-25 16:32:27.385181
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Some short description\n\nSome longer description.\n'
    expected_0 = Docstring(
        short_description='Some short description',
        long_description='Some longer description.',
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
        )
    actual_0 = NumpydocParser().parse(str_0)
    assert actual_0 == expected_0

    str_1 = 'Some short description\nSome longer description.\n'
    expected_1 = Docstring(
        short_description='Some short description',
        long_description='Some longer description.',
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
        )
    actual_1 = Nump

# Generated at 2022-06-25 16:32:53.180053
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case with an example
    str_1 = """
        Parameters
        ----------
        a : int
            First parameter.

        b : float
            Second parameter.

        Returns
        -------
        a * b

        Examples
        --------
        >>> print(hello(1, 2))
        2
    """

    docstring_1 = parse(str_1)

    assert docstring_1.short_description == ""
    assert docstring_1.long_description is None

    assert docstring_1.blank_after_short_description is True
    assert docstring_1.blank_after_long_description is False


# Generated at 2022-06-25 16:32:56.640579
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'Other Arguments'
    docstring_0 = parse(str_0)

if __name__ == '__main__':
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:33:09.645671
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    str_0 = 'Other Arguments'
    docstring_0 = NumpydocParser().parse(str_0)
    assert not docstring_0.meta
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.is_param_list_tuple is False
    assert docstring_0.is_rtype_tuple is False

    # Test case 1
    str_1 = ''
    docstring_1 = NumpydocParser().parse(str_1)
    assert not docstring_1.meta
    assert docstring_1.short_description is None
    assert doc